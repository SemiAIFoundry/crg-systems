/** Independent bounded reader/integrity verifier for the portable .crg ZIP. */
import { createHash } from "node:crypto";
import { inflateRawSync } from "node:zlib";
import { canonicalJson, decodeJson, isObject } from "./canonical.mjs";

const REQUIRED_MEMBERS = [
  "manifest.json", "case.json", "schemas/referenced-schema-manifest.json",
  "audit/events.jsonl", "README.md",
];
const REQUIRED_FIELDS = [
  "bundle_format_version", "crg_spec_version", "root_case_object",
  "object_inventory", "artifact_inventory", "proof_inventory", "content_hashes",
  "external_references", "schema_identities", "quantity_registry_version",
  "rule_table_version", "signatures", "encryption", "redaction_state",
  "export_authority", "creation_tool", "requested_verification_level",
];
const REFERENCE_FIELDS = [
  "immutable_identity", "expected_content_hash", "retrieval_policy", "required_access",
  "validity", "offline_behavior", "unavailable_behavior",
];
const MAX_MEMBERS = 4096;
const MAX_EXPANDED = 256 * 1024 * 1024;
const MAX_RATIO = 100;

function digest(bytes) {
  return `sha256:${createHash("sha256").update(bytes).digest("hex")}`;
}

function safeName(name) {
  return name && !name.startsWith("/") && !name.includes("\\")
    && !name.split("/").some((part) => part === ".." || part === "");
}

function findEocd(bytes) {
  const floor = Math.max(0, bytes.length - 65557);
  for (let offset = bytes.length - 22; offset >= floor; offset -= 1) {
    if (bytes.readUInt32LE(offset) === 0x06054b50) return offset;
  }
  throw new TypeError("ZIP end-of-central-directory record is absent");
}

export function readZip(bytes) {
  if (!Buffer.isBuffer(bytes)) bytes = Buffer.from(bytes);
  const eocd = findEocd(bytes);
  const disk = bytes.readUInt16LE(eocd + 4);
  const centralDisk = bytes.readUInt16LE(eocd + 6);
  const entries = bytes.readUInt16LE(eocd + 10);
  const centralSize = bytes.readUInt32LE(eocd + 12);
  const centralOffset = bytes.readUInt32LE(eocd + 16);
  const commentLength = bytes.readUInt16LE(eocd + 20);
  if (disk !== 0 || centralDisk !== 0 || entries > MAX_MEMBERS) {
    throw new TypeError("multi-disk or over-member-limit ZIP is unsupported");
  }
  if (centralOffset + centralSize > eocd || eocd + 22 + commentLength > bytes.length) {
    throw new TypeError("ZIP central directory or comment exceeds the archive");
  }
  const members = new Map();
  let cursor = centralOffset;
  let expanded = 0;
  let compressedTotal = 0;
  for (let index = 0; index < entries; index += 1) {
    if (cursor + 46 > eocd || bytes.readUInt32LE(cursor) !== 0x02014b50) {
      throw new TypeError("malformed ZIP central-directory entry");
    }
    const flags = bytes.readUInt16LE(cursor + 8);
    const method = bytes.readUInt16LE(cursor + 10);
    const compressedSize = bytes.readUInt32LE(cursor + 20);
    const uncompressedSize = bytes.readUInt32LE(cursor + 24);
    const nameLength = bytes.readUInt16LE(cursor + 28);
    const extraLength = bytes.readUInt16LE(cursor + 30);
    const memberCommentLength = bytes.readUInt16LE(cursor + 32);
    const localOffset = bytes.readUInt32LE(cursor + 42);
    const next = cursor + 46 + nameLength + extraLength + memberCommentLength;
    if (next > eocd) throw new TypeError("ZIP central-directory name exceeds archive");
    const name = bytes.subarray(cursor + 46, cursor + 46 + nameLength).toString("utf8");
    if (!safeName(name) || members.has(name)) throw new TypeError(`unsafe or duplicate ZIP member ${name}`);
    if ((flags & 0x1) !== 0) throw new TypeError(`encrypted ZIP member is unsupported: ${name}`);
    if (![0, 8].includes(method)) throw new TypeError(`ZIP method ${method} is unsupported: ${name}`);
    if (localOffset + 30 > bytes.length || bytes.readUInt32LE(localOffset) !== 0x04034b50) {
      throw new TypeError(`local ZIP header is malformed: ${name}`);
    }
    const localName = bytes.readUInt16LE(localOffset + 26);
    const localExtra = bytes.readUInt16LE(localOffset + 28);
    const dataOffset = localOffset + 30 + localName + localExtra;
    const dataEnd = dataOffset + compressedSize;
    if (dataEnd > bytes.length) throw new TypeError(`compressed member exceeds ZIP: ${name}`);
    const compressed = bytes.subarray(dataOffset, dataEnd);
    const payload = method === 0 ? Buffer.from(compressed) : inflateRawSync(compressed, {
      maxOutputLength: Math.min(MAX_EXPANDED, uncompressedSize + 1),
    });
    if (payload.length !== uncompressedSize) throw new TypeError(`size mismatch for ZIP member ${name}`);
    expanded += payload.length;
    compressedTotal += Math.max(1, compressed.length);
    if (expanded > MAX_EXPANDED) throw new TypeError("ZIP expanded-size limit exceeded");
    members.set(name, payload);
    cursor = next;
  }
  if (cursor !== centralOffset + centralSize) throw new TypeError("ZIP central-directory size mismatch");
  // Apply the ratio to the whole container. Enforcing it on each traversal
  // prefix would incorrectly reject a legitimate highly-compressible first
  // member even when the complete bundle is below the declared bound.
  if (expanded > compressedTotal * MAX_RATIO) throw new TypeError("ZIP expansion-ratio limit exceeded");
  return { members, comment: bytes.subarray(eocd + 22, eocd + 22 + commentLength) };
}

function inventory(violations, members, entries, rows, kind, prefix, suffix) {
  const paths = new Set();
  if (!Array.isArray(rows)) { violations.push(`manifest ${kind} inventory is malformed`); return paths; }
  for (const row of rows) {
    if (!isObject(row)) { violations.push(`malformed ${kind} inventory entry`); continue; }
    const path = String(row.path ?? "");
    const stated = String(row.content_hash ?? "");
    paths.add(path);
    const hex = stated.startsWith("sha256:") ? stated.slice(7) : "invalid";
    if (path !== `${prefix}${hex}${suffix}`) violations.push(`${kind} is not content addressed: ${path}`);
    const payload = members.get(path);
    if (!payload) { violations.push(`missing ${kind} declared in inventory: ${path}`); continue; }
    if (digest(payload) !== stated) violations.push(`${kind} hash mismatch: ${path}`);
    if (!(path in entries)) violations.push(`${kind} absent from content_hashes: ${path}`);
    if (row.byte_length !== undefined && BigInt(row.byte_length) !== BigInt(payload.length)) {
      violations.push(`${kind} byte length mismatch: ${path}`);
    }
    if (kind === "object") {
      try { decodeJson(payload.toString("utf8")); }
      catch (_error) { violations.push(`object is not exact canonical JSON: ${path}`); }
    }
  }
  return paths;
}

export function verifyBundleBytes(bytes) {
  const violations = [];
  let archive;
  try { archive = readZip(bytes); }
  catch (error) { return { ok: false, status: "FAILED", violations: [error.message] }; }
  const { members, comment } = archive;
  for (const required of REQUIRED_MEMBERS) {
    if (!members.has(required)) violations.push(`required member is missing: ${required}`);
  }
  if (!members.has("manifest.json")) return { ok: false, status: "FAILED", violations };
  const manifestBytes = members.get("manifest.json");
  let manifest;
  try { manifest = decodeJson(manifestBytes.toString("utf8")); }
  catch (error) { violations.push(`manifest.json is not exact JSON: ${error.message}`); }
  if (!isObject(manifest)) return { ok: false, status: "FAILED", violations };
  if (canonicalJson(manifest) !== manifestBytes.toString("utf8")) {
    violations.push("manifest.json bytes are not canonical RFC 8785 JSON");
  }
  const manifestHash = digest(manifestBytes);
  try {
    const anchor = decodeJson(comment.toString("utf8"));
    if (String(anchor.manifest_hash ?? "") !== manifestHash) violations.push("manifest hash mismatch");
  } catch (_error) { violations.push("archive comment does not carry readable manifest metadata"); }
  for (const field of REQUIRED_FIELDS) if (!(field in manifest)) violations.push(`manifest missing ${field}`);
  if (String(manifest.bundle_format_version ?? "") !== "1.0.0") violations.push("unsupported bundle format version");
  const content = manifest.content_hashes;
  const entries = isObject(content) && isObject(content.entries) ? content.entries : Object.create(null);
  if (!isObject(content) || !isObject(content.entries)) violations.push("manifest content_hashes is malformed");
  if (content?.algorithm !== undefined && String(content.algorithm) !== "sha256") violations.push("unsupported hash algorithm");
  for (const [name, stated] of Object.entries(entries)) {
    const payload = members.get(name);
    if (!payload) violations.push(`missing member declared in content_hashes: ${name}`);
    else if (digest(payload) !== String(stated)) violations.push(`content hash mismatch for ${name}`);
  }
  const objectPaths = inventory(violations, members, entries, manifest.object_inventory,
    "object", "objects/sha256/", ".json");
  const artifactPaths = inventory(violations, members, entries, manifest.artifact_inventory,
    "artifact", "artifacts/sha256/", "");
  inventory(violations, members, entries, manifest.proof_inventory,
    "proof", "proofs/sha256/", "");
  for (const name of members.keys()) {
    if (name.startsWith("objects/sha256/") && !objectPaths.has(name)) violations.push(`undeclared object: ${name}`);
    if (name.startsWith("artifacts/sha256/") && !artifactPaths.has(name)) violations.push(`undeclared artifact: ${name}`);
  }
  const root = manifest.root_case_object;
  if (!isObject(root)) violations.push("root_case_object is malformed");
  else {
    const path = String(root.path ?? "case.json");
    const payload = members.get(path);
    if (!payload) violations.push(`missing root case object: ${path}`);
    else if (digest(payload) !== String(root.content_hash ?? "")) violations.push("root case object hash mismatch");
  }
  if (Array.isArray(manifest.external_references)) {
    for (const reference of manifest.external_references) {
      if (!isObject(reference)) { violations.push("malformed external reference"); continue; }
      for (const field of REFERENCE_FIELDS) if (!(field in reference)) violations.push(`external reference missing ${field}`);
    }
  }
  return { ok: violations.length === 0, status: violations.length ? "FAILED" : "VERIFIED",
    manifest_hash: manifestHash, member_count: members.size, violations };
}
