/** Independent JSON-side verifier for the A1.3-A1.6 advancement records. */
import { contentHash, get, hashWithout, isObject } from "./canonical.mjs";

const HASH = /^sha256:[0-9a-f]{64}$/;
const SEMVER = /^(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)$/;
const FORMS = new Set(["DECLARATIVE", "EXECUTABLE", "AGGREGATE", "PROFILE", "DATA_RESOURCE"]);

class InvalidAdvancementRecord extends TypeError {}

function exact(value, fields, label) {
  if (!isObject(value)) throw new InvalidAdvancementRecord(`${label} must be an object`);
  const actual = Object.keys(value).sort();
  const expected = [...fields].sort();
  if (JSON.stringify(actual) !== JSON.stringify(expected)) {
    throw new InvalidAdvancementRecord(`${label} fields differ`);
  }
  return value;
}

function hash(value, label) {
  if (typeof value !== "string" || !HASH.test(value)) {
    throw new InvalidAdvancementRecord(`${label} is not a SHA-256 identity`);
  }
  return value;
}

function sortedStrings(value, label) {
  if (!Array.isArray(value) || value.some((item) => typeof item !== "string" || item.length === 0)) {
    throw new InvalidAdvancementRecord(`${label} is not a string array`);
  }
  const sorted = [...new Set(value)].sort((a, b) => Buffer.from(a).compare(Buffer.from(b)));
  if (JSON.stringify(value) !== JSON.stringify(sorted)) {
    throw new InvalidAdvancementRecord(`${label} is not UTF-8 sorted and unique`);
  }
  return value;
}

function result(status, record, hashField, report = {}) {
  return {
    ok: true,
    status,
    artifact_hash: record[hashField],
    authority: "INDEPENDENT_JSON_VERIFICATION_ONLY",
    execution_authorized: false,
    report,
  };
}

function event(record) {
  exact(record, [
    "record_type", "schema_version", "protocol_version", "minimum_reader_version",
    "event_id", "event_type", "actor", "case_id", "branch_id", "proposal_id",
    "action_id", "causal_parent_ids", "ordering_relation", "sequence", "idempotency_key",
    "deduplication_key", "correlation_id", "occurred_at", "delivery", "transport",
    "transaction", "payload_hash", "authority", "execution_authorized", "event_hash",
  ], "agent event");
  if (record.record_type !== "AgentEvent" || record.schema_version !== "1.0.0"
      || record.protocol_version !== "1.0.0" || record.minimum_reader_version !== "1.0.0") {
    throw new InvalidAdvancementRecord("agent event ABI differs");
  }
  if (record.authority !== "EVENT_CARRIER_ONLY" || record.execution_authorized !== false
      || record.event_hash !== hashWithout(record, "event_hash")) {
    throw new InvalidAdvancementRecord("agent event identity/authority differs");
  }
  const parents = sortedStrings(record.causal_parent_ids, "causal parents");
  if (!Number.isSafeInteger(record.sequence) || record.sequence < 1
      || ((record.ordering_relation === "ROOT") !== (parents.length === 0))) {
    throw new InvalidAdvancementRecord("agent event causal order differs");
  }
  const delivery = exact(record.delivery, ["delivery_id", "attempt", "max_attempts", "ack_required", "acknowledged_event_id", "retry_of_event_id"], "delivery");
  if (!Number.isSafeInteger(delivery.attempt) || delivery.attempt < 1 || delivery.attempt > delivery.max_attempts
      || ((delivery.attempt === 1) !== (delivery.retry_of_event_id === null))) {
    throw new InvalidAdvancementRecord("agent event retry relation differs");
  }
  const transaction = exact(record.transaction, ["transaction_id", "phase", "request_hash", "prior_phase_event_id"], "transaction");
  const allowed = {
    ASSESS: new Set(["assessment.requested", "assessment.completed"]),
    COMMIT: new Set(["commitment.proposed", "commitment.dispositioned", "action.recorded"]),
    ACKNOWLEDGE: new Set(["acknowledgement.recorded"]),
  };
  if (!allowed[transaction.phase]?.has(record.event_type)
      || ((transaction.phase === "ASSESS") !== (transaction.prior_phase_event_id === null))) {
    throw new InvalidAdvancementRecord("agent event transaction relation differs");
  }
  if (transaction.phase === "COMMIT" && record.proposal_id === null) throw new InvalidAdvancementRecord("COMMIT event lacks proposal");
  if (record.event_type === "action.recorded" && record.action_id === null) throw new InvalidAdvancementRecord("action event lacks action");
  if (transaction.phase === "ACKNOWLEDGE") {
    if (!delivery.ack_required || delivery.acknowledged_event_id === null) throw new InvalidAdvancementRecord("acknowledgement relation differs");
  } else if (delivery.acknowledged_event_id !== null) throw new InvalidAdvancementRecord("non-ack event binds acknowledgement");
  return result("VERIFIED_AGENT_EVENT", record, "event_hash");
}

function transactionReceipt(record, bindings) {
  exact(record, [
    "record_type", "schema_version", "profile", "transaction_id", "events",
    "sequence_start", "sequence_end", "acknowledged_event_ids",
    "unacknowledged_event_ids", "status", "authority", "execution_authorized",
    "receipt_hash",
  ], "agent transaction receipt");
  if (record.record_type !== "AgentTransactionReceipt" || record.schema_version !== "1.0.0"
      || record.profile !== "crg-agent-transaction/assess-commit-ack@1"
      || record.authority !== "TRANSACTION_EVIDENCE_ONLY"
      || record.execution_authorized !== false
      || record.receipt_hash !== hashWithout(record, "receipt_hash")) {
    throw new InvalidAdvancementRecord("agent transaction identity/authority differs");
  }
  if (!Array.isArray(bindings.events) || bindings.events.length === 0) {
    throw new InvalidAdvancementRecord("agent transaction requires source events");
  }
  const source = new Map();
  for (const item of bindings.events) {
    event(item);
    if (source.has(item.event_id) || item.transaction.transaction_id !== record.transaction_id) {
      throw new InvalidAdvancementRecord("agent transaction source inventory differs");
    }
    source.set(item.event_id, item);
  }
  const ordered = [...source.values()].sort((a, b) => a.sequence - b.sequence
    || Buffer.from(a.event_id).compare(Buffer.from(b.event_id)));
  const prior = new Set();
  const sequences = [];
  for (const item of ordered) {
    if (item.causal_parent_ids.some((parent) => !prior.has(parent))) {
      throw new InvalidAdvancementRecord("agent transaction causal closure differs");
    }
    prior.add(item.event_id);
    sequences.push(item.sequence);
  }
  for (let index = 1; index < sequences.length; index += 1) {
    if (sequences[index] !== sequences[index - 1] + 1) {
      throw new InvalidAdvancementRecord("agent transaction sequence differs");
    }
  }
  if (!Array.isArray(record.events) || record.events.length !== ordered.length) {
    throw new InvalidAdvancementRecord("agent transaction event rows differ");
  }
  const accepted = new Set(["ACCEPTED", "ACKNOWLEDGED", "RETRY_SCHEDULED"]);
  const statusById = new Map();
  for (const row of record.events) {
    exact(row, [
      "event_id", "event_hash", "event_type", "phase", "sequence",
      "causal_parent_ids", "request_hash", "payload_hash", "ingestion_status",
    ], "agent transaction row");
    if (!accepted.has(row.ingestion_status) || statusById.has(row.event_id)) {
      throw new InvalidAdvancementRecord("agent transaction ingestion result differs");
    }
    statusById.set(row.event_id, row.ingestion_status);
  }
  const expectedRows = ordered.map((item) => ({
    event_id: item.event_id,
    event_hash: item.event_hash,
    event_type: item.event_type,
    phase: item.transaction.phase,
    sequence: item.sequence,
    causal_parent_ids: item.causal_parent_ids,
    request_hash: item.transaction.request_hash,
    payload_hash: item.payload_hash,
    ingestion_status: statusById.get(item.event_id),
  }));
  if ([...statusById.keys()].some((id) => !source.has(id))
      || JSON.stringify(record.events) !== JSON.stringify(expectedRows)
      || record.sequence_start !== sequences[0]
      || record.sequence_end !== sequences[sequences.length - 1]) {
    throw new InvalidAdvancementRecord("agent transaction event/source binding differs");
  }
  const acknowledged = [...new Set(ordered
    .filter((item) => item.event_type === "acknowledgement.recorded")
    .map((item) => item.delivery.acknowledged_event_id))].sort();
  const required = new Set(ordered
    .filter((item) => item.event_type !== "acknowledgement.recorded" && item.delivery.ack_required)
    .map((item) => item.event_id));
  const unacknowledged = [...required].filter((id) => !acknowledged.includes(id)).sort();
  if (JSON.stringify(record.acknowledged_event_ids) !== JSON.stringify(acknowledged)
      || JSON.stringify(record.unacknowledged_event_ids) !== JSON.stringify(unacknowledged)
      || record.status !== (unacknowledged.length === 0 ? "ACKNOWLEDGED" : "OPEN")) {
    throw new InvalidAdvancementRecord("agent transaction acknowledgement differs");
  }
  const phases = ordered.map((item) => item.transaction.phase);
  if (phases[0] !== "ASSESS" || !phases.includes("COMMIT")
      || phases[phases.length - 1] !== "ACKNOWLEDGE") {
    throw new InvalidAdvancementRecord("agent transaction phase closure differs");
  }
  return result("VERIFIED_AGENT_TRANSACTION_RECEIPT", record, "receipt_hash", {
    transaction_id: record.transaction_id,
    status: record.status,
  });
}

function lock(record) {
  exact(record, [
    "record_type", "schema_version", "resolver", "root_requests", "selected_features", "platform",
    "packages", "dependency_graph", "conflict_graph", "namespace_authority", "overrides",
    "host_capabilities", "semantic_composition_root", "resolution_admission_root", "authority",
    "execution_authorized", "lock_hash",
  ], "resolved profile lock");
  if (record.record_type !== "ResolvedProfileLock" || record.schema_version !== "1.0.0"
      || record.authority !== "RESOLUTION_RECORD_ONLY" || record.execution_authorized !== false
      || record.lock_hash !== hashWithout(record, "lock_hash")) {
    throw new InvalidAdvancementRecord("resolved profile lock identity/authority differs");
  }
  const resolver = exact(record.resolver, ["id", "version", "composition_abi"], "resolver");
  if (resolver.id !== "crg-generate.package-resolver" || !SEMVER.test(resolver.version) || !SEMVER.test(resolver.composition_abi)) {
    throw new InvalidAdvancementRecord("resolver identity differs");
  }
  const ids = record.packages.map((row) => row.package_id);
  const sorted = [...new Set(ids)].sort((a, b) => Buffer.from(a).compare(Buffer.from(b)));
  if (JSON.stringify(ids) !== JSON.stringify(sorted)) throw new InvalidAdvancementRecord("package order differs");
  const authority = new Map(record.namespace_authority.map((row) => [row.namespace, sortedStrings(row.publishers, "publishers")]));
  const provided = new Set(sortedStrings(record.host_capabilities, "host capabilities"));
  for (const row of record.packages) {
    exact(row, [
      "package_id", "namespace", "publisher", "version", "package_form", "manifest_hash",
      "domain_manifest_hash", "archive_digest", "selected_features", "provides_capabilities",
      "requires_capabilities", "registry_origin", "mirror_state", "trust_state",
    ], "resolved package");
    if (!SEMVER.test(row.version) || !FORMS.has(row.package_form) || !authority.get(row.namespace)?.includes(row.publisher)) {
      throw new InvalidAdvancementRecord("resolved package identity/authority differs");
    }
    [row.manifest_hash, row.domain_manifest_hash, row.archive_digest].forEach((item) => hash(item, "package hash"));
    sortedStrings(row.selected_features, "selected features");
    sortedStrings(row.provides_capabilities, "provided capabilities").forEach((item) => provided.add(item));
    sortedStrings(row.requires_capabilities, "required capabilities");
    const trust = exact(row.trust_state, ["snapshot_hash", "status", "signature_status", "advisory_status", "revocation_status"], "trust state");
    if (trust.status !== "CURRENT" || trust.signature_status !== "VERIFIED"
        || !new Set(["CLEAR", "ACKNOWLEDGED"]).has(trust.advisory_status)
        || trust.revocation_status !== "ACTIVE") throw new InvalidAdvancementRecord("package trust is inadmissible");
  }
  for (const row of record.packages) {
    if (row.requires_capabilities.some((item) => !provided.has(item))) throw new InvalidAdvancementRecord("capability closure differs");
  }
  const semanticRows = record.packages.map((row) => ({
    package_id: row.package_id, version: row.version, package_form: row.package_form,
    manifest_hash: row.manifest_hash, domain_manifest_hash: row.domain_manifest_hash,
    selected_features: row.selected_features,
  }));
  const semantic = contentHash({
    composition_abi: resolver.composition_abi, root_requests: record.root_requests,
    selected_features: record.selected_features, packages: semanticRows,
    dependency_graph: record.dependency_graph,
  });
  if (record.semantic_composition_root !== semantic) throw new InvalidAdvancementRecord("semantic root differs");
  const resolutionMaterial = Object.fromEntries(Object.entries(record).filter(([key]) => !new Set(["semantic_composition_root", "resolution_admission_root", "lock_hash"]).has(key)));
  if (record.resolution_admission_root !== contentHash(resolutionMaterial)) throw new InvalidAdvancementRecord("resolution root differs");
  return result("VERIFIED_RESOLVED_PROFILE_LOCK", record, "lock_hash");
}

function context(record, bindings) {
  exact(record, [
    "record_type", "schema_version", "profile", "inputs", "semantic_composition_root",
    "host_policy_action_mapping_root", "execution_deployment_root", "resolution_admission_root",
    "authority", "execution_authorized", "context_hash",
  ], "assessment context");
  if (record.record_type !== "AssessmentContextRoots" || record.schema_version !== "1.0.0"
      || record.profile !== "crg-assessment-context/four-root@1"
      || record.authority !== "ASSESSMENT_CONTEXT_ONLY" || record.execution_authorized !== false
      || record.context_hash !== hashWithout(record, "context_hash")) throw new InvalidAdvancementRecord("assessment context identity differs");
  const inputs = exact(record.inputs, ["resolved_profile_lock_hash", "action_mapping_profile_hash", "host_policy_snapshot_hash", "execution_profile_hash", "deployment_profile_hash"], "context inputs");
  Object.values(inputs).forEach((item) => hash(item, "context input"));
  if (record.host_policy_action_mapping_root !== contentHash({action_mapping_profile_hash: inputs.action_mapping_profile_hash, host_policy_snapshot_hash: inputs.host_policy_snapshot_hash})) throw new InvalidAdvancementRecord("host-policy root differs");
  if (record.execution_deployment_root !== contentHash({execution_profile_hash: inputs.execution_profile_hash, deployment_profile_hash: inputs.deployment_profile_hash})) throw new InvalidAdvancementRecord("execution root differs");
  if (bindings.lock) {
    lock(bindings.lock);
    if (inputs.resolved_profile_lock_hash !== bindings.lock.lock_hash
        || record.semantic_composition_root !== bindings.lock.semantic_composition_root
        || record.resolution_admission_root !== bindings.lock.resolution_admission_root) throw new InvalidAdvancementRecord("context lock binding differs");
  }
  return result("VERIFIED_ASSESSMENT_CONTEXT_ROOTS", record, "context_hash");
}

function profile(record) {
  exact(record, [
    "record_type", "schema_version", "profile_id", "profile_version", "package_lock_hash", "wire",
    "capability_handles", "ambient_authority", "permissions", "data_classification", "budgets",
    "termination", "runtime", "determinism", "audit", "limitations", "authority",
    "execution_authorized", "contract_hash",
  ], "execution profile");
  if (record.record_type !== "ExecutionProfileContract" || record.schema_version !== "1.0.0"
      || record.authority !== "EXECUTION_CONTRACT_ONLY" || record.execution_authorized !== false
      || record.contract_hash !== hashWithout(record, "contract_hash")) throw new InvalidAdvancementRecord("execution profile identity differs");
  const runtime = exact(record.runtime, ["isolation_profile", "support_level", "policy_hash", "runner", "kernel", "platform", "image_identity", "kernel_enforced"], "runtime");
  const supported = runtime.support_level === "SUPPORTED";
  if (!new Set(["PROCESS_REFERENCE", "OCI_KERNEL"]).has(runtime.isolation_profile)
      || !new Set(["SUPPORTED", "EXPERIMENTAL"]).has(runtime.support_level)
      || supported !== (runtime.isolation_profile === "OCI_KERNEL" && runtime.kernel_enforced === true)) throw new InvalidAdvancementRecord("support/isolation relation differs");
  if (record.ambient_authority.time !== "DENIED" || record.ambient_authority.randomness !== "DENIED"
      || record.determinism.time_source !== "NONE" || record.determinism.randomness_source !== "NONE") throw new InvalidAdvancementRecord("ambient time/randomness admitted");
  if (supported && (record.permissions.length || record.capability_handles.length || record.limitations.length || record.determinism.replay_required !== true)) throw new InvalidAdvancementRecord("supported profile is not pure deterministic execution");
  if (record.termination.timeout_action !== "KILL_PROCESS_GROUP" || record.termination.partial_output !== "REFUSED") throw new InvalidAdvancementRecord("termination contract differs");
  return result("VERIFIED_EXECUTION_PROFILE_CONTRACT", record, "contract_hash", {support_level: runtime.support_level});
}

function receipt(record, bindings) {
  exact(record, [
    "record_type", "schema_version", "execution_profile_hash", "request_hash", "reply_hash", "outcome",
    "side_effects", "side_effect_disposition", "invocation_record_hash", "environment_hash",
    "audit_chain_hash", "authority", "action_authorized", "receipt_hash",
  ], "execution receipt");
  if (!bindings.profile) throw new InvalidAdvancementRecord("execution receipt requires profile binding");
  profile(bindings.profile);
  if (record.record_type !== "ExecutionReceipt" || record.schema_version !== "1.0.0"
      || record.receipt_hash !== hashWithout(record, "receipt_hash")
      || record.execution_profile_hash !== bindings.profile.contract_hash
      || record.authority !== "EXECUTION_EVIDENCE_ONLY" || record.action_authorized !== false
      || record.side_effects.length !== 0 || record.side_effect_disposition !== "NONE_PERMITTED") throw new InvalidAdvancementRecord("execution receipt identity/authority differs");
  const success = record.outcome.status === "SUCCEEDED";
  if (success !== (record.outcome.failure_category === "OK")) throw new InvalidAdvancementRecord("execution outcome differs");
  if (bindings.invocation) {
    if (record.invocation_record_hash !== contentHash(bindings.invocation)
        || record.request_hash !== bindings.invocation.input_hash
        || record.reply_hash !== (bindings.invocation.output_hash || null)
        || record.environment_hash !== bindings.invocation.environment_hash
        || bindings.invocation.policy_hash !== bindings.profile.runtime.policy_hash) throw new InvalidAdvancementRecord("invocation binding differs");
  }
  return result("VERIFIED_EXECUTION_RECEIPT", record, "receipt_hash");
}

function packageManifest(record) {
  exact(record, ["record_type", "schema_version", "format_profile", "package_form", "domain_manifest", "domain_manifest_hash", "control_files", "excluded_from_archive", "path_policy", "payload_inventory", "payload_root", "manifest_hash"], "package manifest");
  if (record.record_type !== "CanonicalPackageManifest" || record.schema_version !== "1.0.0"
      || record.format_profile !== "crg-canonical-package/ustar@1" || !FORMS.has(record.package_form)
      || record.manifest_hash !== hashWithout(record, "manifest_hash")
      || record.domain_manifest_hash !== contentHash(record.domain_manifest)
      || record.payload_root !== contentHash(record.payload_inventory)) throw new InvalidAdvancementRecord("package manifest identity differs");
  return result("VERIFIED_CANONICAL_PACKAGE_MANIFEST", record, "manifest_hash");
}

function packageEnvelope(record, bindings) {
  exact(record, ["record_type", "schema_version", "manifest_hash", "archive", "signed_content_hash", "detached_signature", "transparency", "retrieval", "revocation", "envelope_hash"], "package envelope");
  if (record.record_type !== "PackageDistributionEnvelope" || record.schema_version !== "1.0.0"
      || record.envelope_hash !== hashWithout(record, "envelope_hash")) throw new InvalidAdvancementRecord("package envelope identity differs");
  hash(record.archive.sha256, "archive digest");
  if (record.archive.media_type !== "application/vnd.crg.package.v1.tar" || record.retrieval.archive_digest !== record.archive.sha256) throw new InvalidAdvancementRecord("archive/retrieval identity differs");
  const signed = contentHash({manifest_hash: record.manifest_hash, archive_digest: record.archive.sha256, media_type: record.archive.media_type});
  if (record.signed_content_hash !== signed) throw new InvalidAdvancementRecord("signed-content identity differs");
  if (bindings.manifest) {
    packageManifest(bindings.manifest);
    if (record.manifest_hash !== bindings.manifest.manifest_hash) throw new InvalidAdvancementRecord("envelope/manifest binding differs");
  }
  return result("VERIFIED_PACKAGE_DISTRIBUTION_ENVELOPE", record, "envelope_hash");
}

/** Independently reconstruct one existing crg-feedback TransitionRecord. */
export function verifyTransitionRecord(record) {
  try {
    if (!isObject(record)) throw new InvalidAdvancementRecord("transition record must be an object");
    const required = new Set([
      "record_id", "plan_id", "status", "level", "source_config_id",
      "target_config_id", "final_config_id", "returned_to_source",
      "started_ticks", "finished_ticks", "checkpoint", "rollback_plan",
      "audit_spec", "clock", "steps", "postcondition_results", "refusals", "audit",
    ]);
    const optional = new Set(["checkpoint_token", "rollback_of", "approver_identity"]);
    if ([...required].some((field) => !Object.hasOwn(record, field))
        || Object.keys(record).some((field) => !required.has(field) && !optional.has(field))) {
      throw new InvalidAdvancementRecord("transition record fields differ");
    }
    for (const field of ["record_id", "plan_id", "source_config_id", "target_config_id", "final_config_id"]) {
      if (typeof record[field] !== "string" || record[field].length === 0) {
        throw new InvalidAdvancementRecord(`${field} must be a non-empty string`);
      }
    }
    const statuses = new Set(["PLANNED", "AUTHORIZED", "COMPLETED", "ROLLED_BACK", "ROLLBACK_FAILED", "REFUSED"]);
    const levels = new Set(["L0_OFFLINE", "L1_SUPERVISED", "L2_AUTOMATED_BOUNDED", "L3_ADAPTIVE_CERTIFIED"]);
    if (!statuses.has(record.status) || !levels.has(record.level)) {
      throw new InvalidAdvancementRecord("transition status or maturity level is unsupported");
    }
    if (!Number.isSafeInteger(record.started_ticks) || record.started_ticks < 0
        || !Number.isSafeInteger(record.finished_ticks) || record.finished_ticks < record.started_ticks) {
      throw new InvalidAdvancementRecord("transition interval is invalid");
    }
    const returned = record.final_config_id === record.source_config_id;
    if (record.returned_to_source !== returned) {
      throw new InvalidAdvancementRecord("returned_to_source differs from the final configuration");
    }
    const checkpoint = exact(record.checkpoint,
      ["checkpoint_id", "configuration_id", "configuration_hash", "captured_at_ticks", "restorable", ...(Object.hasOwn(record.checkpoint ?? {}, "contents_hash") ? ["contents_hash"] : [])],
      "checkpoint");
    if (checkpoint.configuration_id !== record.source_config_id || checkpoint.restorable !== true
        || !HASH.test(checkpoint.configuration_hash)
        || !Number.isSafeInteger(checkpoint.captured_at_ticks) || checkpoint.captured_at_ticks < 0) {
      throw new InvalidAdvancementRecord("checkpoint does not bind a restorable source configuration");
    }
    if (Object.hasOwn(checkpoint, "contents_hash") && !HASH.test(checkpoint.contents_hash)) {
      throw new InvalidAdvancementRecord("checkpoint contents hash is invalid");
    }
    const rollbackFields = ["rollback_id", "checkpoint_id", "steps", "bounded_ticks", "restores_consistency"];
    if (Object.hasOwn(record.rollback_plan ?? {}, "verification_signal")) rollbackFields.push("verification_signal");
    const rollback = exact(record.rollback_plan, rollbackFields, "rollback plan");
    if (rollback.checkpoint_id !== checkpoint.checkpoint_id || !Array.isArray(rollback.steps)
        || rollback.steps.length === 0 || rollback.steps.some((step) => typeof step !== "string" || step.length === 0)
        || !Number.isSafeInteger(rollback.bounded_ticks) || rollback.bounded_ticks < 1
        || typeof rollback.restores_consistency !== "boolean") {
      throw new InvalidAdvancementRecord("rollback plan is incomplete or names another checkpoint");
    }
    const auditSpecFields = ["audit_id", "sink", "retained_fields"];
    if (Object.hasOwn(record.audit_spec ?? {}, "signer")) auditSpecFields.push("signer");
    const auditSpec = exact(record.audit_spec, auditSpecFields, "audit spec");
    if (typeof auditSpec.audit_id !== "string" || !auditSpec.audit_id
        || typeof auditSpec.sink !== "string" || !auditSpec.sink
        || !Array.isArray(auditSpec.retained_fields) || auditSpec.retained_fields.length === 0) {
      throw new InvalidAdvancementRecord("audit specification is incomplete");
    }
    const clockFields = ["tick_unit", "clock_source", "clock_trust_level", "wall_clock"];
    if (Object.hasOwn(record.clock ?? {}, "monotonic_ticks")) clockFields.push("monotonic_ticks");
    exact(record.clock, clockFields, "transition clock");

    if (!Array.isArray(record.steps) || !Array.isArray(record.postcondition_results)
        || !Array.isArray(record.refusals) || !Array.isArray(record.audit)) {
      throw new InvalidAdvancementRecord("transition evidence rows must be arrays");
    }
    for (const step of record.steps) {
      const fields = ["name", "at_ticks", "ok"];
      if (Object.hasOwn(step ?? {}, "detail")) fields.push("detail");
      exact(step, fields, "transition step");
      if (!Number.isSafeInteger(step.at_ticks) || step.at_ticks < record.started_ticks
          || step.at_ticks > record.finished_ticks || typeof step.ok !== "boolean") {
        throw new InvalidAdvancementRecord("transition step is outside the attempt interval");
      }
    }
    const postconditions = record.postcondition_results.map((row) => {
      const fields = ["condition_id", "signal", "comparator", "threshold", "satisfied"];
      if (Object.hasOwn(row ?? {}, "observed")) fields.push("observed");
      if (Object.hasOwn(row ?? {}, "detail")) fields.push("detail");
      exact(row, fields, "postcondition result");
      if (typeof row.satisfied !== "boolean" || !isObject(row.threshold)
          || (Object.hasOwn(row, "observed") && !isObject(row.observed))) {
        throw new InvalidAdvancementRecord("postcondition result is invalid");
      }
      return row.satisfied;
    });
    const refusalReasons = record.refusals.map((row) => {
      const fields = ["reason", "detail"];
      if (Object.hasOwn(row ?? {}, "subject")) fields.push("subject");
      exact(row, fields, "refusal");
      if (typeof row.reason !== "string" || !row.reason || typeof row.detail !== "string" || !row.detail) {
        throw new InvalidAdvancementRecord("refusal is incomplete");
      }
      return row.reason;
    });
    let priorTicks = -1;
    record.audit.forEach((row, index) => {
      const fields = ["sequence", "at_ticks", "event"];
      if (Object.hasOwn(row ?? {}, "detail")) fields.push("detail");
      exact(row, fields, "audit entry");
      if (row.sequence !== index + 1 || !Number.isSafeInteger(row.at_ticks)
          || row.at_ticks < priorTicks || typeof row.event !== "string" || !row.event) {
        throw new InvalidAdvancementRecord("audit order or contents differ");
      }
      priorTicks = row.at_ticks;
    });

    let disposition = "NO_ACTION_RECORDED";
    if (record.status === "COMPLETED") {
      if (record.final_config_id !== record.target_config_id || returned
          || refusalReasons.length || postconditions.some((value) => !value)) {
        throw new InvalidAdvancementRecord("COMPLETED transition outcome differs");
      }
      disposition = "ACTION_COMPLETED";
    } else if (record.status === "ROLLED_BACK") {
      if (!returned || !record.rollback_of) throw new InvalidAdvancementRecord("ROLLED_BACK lineage differs");
      disposition = "ACTION_ROLLED_BACK";
    } else if (record.status === "ROLLBACK_FAILED") {
      if (!record.rollback_of || !refusalReasons.includes("ROLLBACK_FAILED")) {
        throw new InvalidAdvancementRecord("ROLLBACK_FAILED lineage differs");
      }
      disposition = "ROLLBACK_FAILED";
    } else if (record.status === "REFUSED") {
      if (!refusalReasons.length) throw new InvalidAdvancementRecord("REFUSED transition has no reason");
      disposition = "ACTION_NOT_CONFIRMED";
    }
    return {
      ok: true, status: "VERIFIED_TRANSITION_RECORD", artifact_hash: contentHash(record),
      authority: "INDEPENDENT_JSON_VERIFICATION_ONLY", execution_authorized: false,
      report: {
        status: record.status, disposition,
        action_occurred: new Set(["COMPLETED", "ROLLED_BACK", "ROLLBACK_FAILED"]).has(record.status),
        rollback_occurred: new Set(["ROLLED_BACK", "ROLLBACK_FAILED"]).has(record.status),
        refusal_reasons: refusalReasons,
      },
    };
  } catch (error) {
    if (!(error instanceof InvalidAdvancementRecord || error instanceof TypeError || error instanceof RangeError)) throw error;
    return {
      ok: false, status: "FAILED", artifact_hash: null,
      authority: "INDEPENDENT_JSON_VERIFICATION_ONLY", execution_authorized: false,
      violations: [error.message], report: {},
    };
  }
}

export function verifyMultiAgentOperation(bundle) {
  try {
    exact(bundle, ["grants", "proposals", "conflict", "reconciliation"], "multi-agent bundle");
    if (!Array.isArray(bundle.grants) || bundle.grants.length === 0
        || !Array.isArray(bundle.proposals) || bundle.proposals.length === 0) {
      throw new InvalidAdvancementRecord("multi-agent bundle requires grants and proposals");
    }
    const grants = new Map();
    const agents = [];
    for (const grant of bundle.grants) {
      exact(grant, [
        "record_type", "schema_version", "grant_id", "agent_id", "organization",
        "tenant_id", "roles", "case_ids", "branch_ids", "permitted_actions",
        "budget", "revoked", "authority", "execution_authorized", "grant_hash",
      ], "agent grant");
      if (grant.record_type !== "AgentOperationGrant" || grant.schema_version !== "1.0.0"
          || grant.authority !== "DEPLOYMENT_SCOPED_AGENT_GRANT"
          || grant.execution_authorized !== false || grant.revoked !== false
          || grant.grant_hash !== hashWithout(grant, "grant_hash")) {
        throw new InvalidAdvancementRecord("agent grant identity or authority differs");
      }
      for (const field of ["roles", "case_ids", "branch_ids", "permitted_actions"]) {
        sortedStrings(grant[field], `grant ${field}`);
      }
      exact(grant.budget, ["max_proposals", "max_cost_units", "max_elapsed_ticks"], "agent budget");
      for (const value of Object.values(grant.budget)) {
        if (!Number.isSafeInteger(value) || value < 1) throw new InvalidAdvancementRecord("agent budget differs");
      }
      agents.push(grant.agent_id);
      grants.set(grant.grant_hash, grant);
    }
    if (JSON.stringify(agents) !== JSON.stringify([...new Set(agents)].sort())) {
      throw new InvalidAdvancementRecord("agent grants must be sorted and unique");
    }

    const proposals = [];
    for (const proposal of bundle.proposals) {
      exact(proposal, [
        "record_type", "schema_version", "proposal_id", "grant_hash", "agent_id",
        "organization", "tenant_id", "case_id", "branch_id", "action",
        "expected_parent_version", "causal_parent_ids", "event_hash", "payload_hash",
        "cost_units", "elapsed_ticks", "authority", "execution_authorized", "proposal_hash",
      ], "agent proposal");
      const grant = grants.get(proposal.grant_hash);
      if (!grant || proposal.record_type !== "AgentProposalRecord" || proposal.schema_version !== "1.0.0"
          || proposal.authority !== "PROPOSAL_ONLY" || proposal.execution_authorized !== false
          || proposal.proposal_hash !== hashWithout(proposal, "proposal_hash")
          || proposal.agent_id !== grant.agent_id || proposal.organization !== grant.organization
          || proposal.tenant_id !== grant.tenant_id || !grant.case_ids.includes(proposal.case_id)
          || !grant.branch_ids.includes(proposal.branch_id) || !grant.permitted_actions.includes(proposal.action)) {
        throw new InvalidAdvancementRecord("agent proposal identity, authority, or scope differs");
      }
      hash(proposal.event_hash, "proposal event hash");
      hash(proposal.payload_hash, "proposal payload hash");
      sortedStrings(proposal.causal_parent_ids, "proposal causal parents");
      for (const [field, minimum] of [["expected_parent_version", 1], ["cost_units", 0], ["elapsed_ticks", 0]]) {
        if (!Number.isSafeInteger(proposal[field]) || proposal[field] < minimum) {
          throw new InvalidAdvancementRecord(`proposal ${field} differs`);
        }
      }
      proposals.push(proposal);
    }
    const proposalIds = proposals.map((value) => value.proposal_id);
    if (JSON.stringify(proposalIds) !== JSON.stringify([...new Set(proposalIds)].sort())) {
      throw new InvalidAdvancementRecord("proposals must be sorted and unique");
    }
    for (const grant of grants.values()) {
      const selected = proposals.filter((proposal) => proposal.grant_hash === grant.grant_hash);
      if (selected.length > grant.budget.max_proposals
          || selected.reduce((sum, row) => sum + row.cost_units, 0) > grant.budget.max_cost_units
          || selected.reduce((sum, row) => sum + row.elapsed_ticks, 0) > grant.budget.max_elapsed_ticks) {
        throw new InvalidAdvancementRecord("proposal use exceeds the agent budget");
      }
    }

    let conflict = bundle.conflict;
    if (conflict !== null) {
      exact(conflict, [
        "record_type", "schema_version", "conflict_id", "case_id", "branch_id",
        "expected_parent_version", "proposal_ids", "resolution_status",
        "arrival_order_authoritative", "last_writer_wins", "authority",
        "execution_authorized", "conflict_hash",
      ], "agent conflict");
      const ids = sortedStrings(conflict.proposal_ids, "conflict proposal ids");
      const selected = proposals.filter((proposal) => ids.includes(proposal.proposal_id));
      const anchor = selected[0];
      if (conflict.record_type !== "AgentConflictRecord" || conflict.schema_version !== "1.0.0"
          || selected.length !== ids.length || selected.length < 2
          || selected.some((row) => row.case_id !== anchor.case_id || row.branch_id !== anchor.branch_id
            || row.expected_parent_version !== anchor.expected_parent_version)
          || new Set(selected.map((row) => row.payload_hash)).size < 2
          || conflict.case_id !== anchor.case_id || conflict.branch_id !== anchor.branch_id
          || conflict.expected_parent_version !== anchor.expected_parent_version
          || conflict.resolution_status !== "RECONCILIATION_REQUIRED"
          || conflict.arrival_order_authoritative !== false || conflict.last_writer_wins !== false
          || conflict.authority !== "CONFLICT_EVIDENCE_ONLY" || conflict.execution_authorized !== false
          || conflict.conflict_hash !== hashWithout(conflict, "conflict_hash")) {
        throw new InvalidAdvancementRecord("agent conflict relationship differs");
      }
    }

    const reconciliation = bundle.reconciliation;
    if (reconciliation !== null) {
      exact(reconciliation, [
        "record_type", "schema_version", "reconciliation_id", "conflict_hash",
        "proposal_ids", "selected_proposal_id", "resolved_by", "resolution_authority",
        "rationale", "arrival_order_authoritative", "last_writer_wins", "mutation_applied",
        "authority", "execution_authorized", "reconciliation_hash",
      ], "agent reconciliation");
      if (conflict === null || reconciliation.record_type !== "AgentReconciliationRecord"
          || reconciliation.schema_version !== "1.0.0" || reconciliation.conflict_hash !== conflict.conflict_hash
          || JSON.stringify(reconciliation.proposal_ids) !== JSON.stringify(conflict.proposal_ids)
          || (reconciliation.selected_proposal_id !== null
            && !conflict.proposal_ids.includes(reconciliation.selected_proposal_id))
          || !new Set(["HUMAN", "ADMITTED_POLICY"]).has(reconciliation.resolution_authority)
          || reconciliation.arrival_order_authoritative !== false || reconciliation.last_writer_wins !== false
          || reconciliation.mutation_applied !== false || reconciliation.execution_authorized !== false
          || reconciliation.authority !== "RECONCILIATION_DECISION_ONLY"
          || reconciliation.reconciliation_hash !== hashWithout(reconciliation, "reconciliation_hash")) {
        throw new InvalidAdvancementRecord("agent reconciliation relationship differs");
      }
    }
    return {
      ok: true, status: "VERIFIED_MULTI_AGENT_COORDINATION", artifact_hash: contentHash(bundle),
      authority: "INDEPENDENT_JSON_VERIFICATION_ONLY", execution_authorized: false,
      report: {
        grant_count: bundle.grants.length, proposal_count: proposals.length,
        conflict_recorded: conflict !== null, reconciled: reconciliation !== null,
        mutation_applied: false, execution_authorized: false,
      },
    };
  } catch (error) {
    if (!(error instanceof InvalidAdvancementRecord || error instanceof TypeError || error instanceof RangeError)) throw error;
    return {
      ok: false, status: "FAILED", artifact_hash: null,
      authority: "INDEPENDENT_JSON_VERIFICATION_ONLY", execution_authorized: false,
      violations: [error.message], report: {},
    };
  }
}

export function verifyAdvancementRecord(record, bindings = {}) {
  try {
    switch (get(record, "record_type")) {
      case "AgentEvent": return event(record);
      case "AgentTransactionReceipt": return transactionReceipt(record, bindings);
      case "ResolvedProfileLock": return lock(record);
      case "AssessmentContextRoots": return context(record, bindings);
      case "ExecutionProfileContract": return profile(record);
      case "ExecutionReceipt": return receipt(record, bindings);
      case "CanonicalPackageManifest": return packageManifest(record);
      case "PackageDistributionEnvelope": return packageEnvelope(record, bindings);
      default: throw new InvalidAdvancementRecord("unsupported advancement record type");
    }
  } catch (error) {
    if (!(error instanceof InvalidAdvancementRecord || error instanceof TypeError || error instanceof RangeError)) throw error;
    return {
      ok: false, status: "FAILED", artifact_hash: null,
      authority: "INDEPENDENT_JSON_VERIFICATION_ONLY", execution_authorized: false,
      violations: [error.message], report: {},
    };
  }
}
