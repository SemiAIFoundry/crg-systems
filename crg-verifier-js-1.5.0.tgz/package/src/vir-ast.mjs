/** Typed, deterministic, resource-bounded CRG-VIR value language (§24). */
import { ArithError, Rational, ZERO, interval, rational } from "./rational.mjs";

export const AST_VERSION = "0.2.0";
const REFERENCES = new Set(["object_ref", "geometry_ref", "proof_ref"]);

export class VirProgramError extends Error {
  constructor(message) {
    super(message);
    this.name = "VirProgramError";
  }
}

class Quantity {
  constructor(value, unit) { this.value = value; this.unit = unit; Object.freeze(this); }
}

class IntervalValue {
  constructor(lo, hi) { this.lo = lo; this.hi = hi; Object.freeze(this); }
}

class SetValue {
  constructor(values) { this.values = Object.freeze([...values]); Object.freeze(this); }
}

class MapValue {
  constructor(value) { this.value = Object.freeze({ ...value }); Object.freeze(this); }
}

function own(value, key) {
  return value !== null && typeof value === "object" &&
    Object.prototype.hasOwnProperty.call(value, key);
}

function object(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function exact(value) {
  try { return rational(value); }
  catch (error) {
    if (error instanceof ArithError) throw new VirProgramError(error.message);
    throw error;
  }
}

function decodeUntyped(value) {
  if (typeof value === "boolean" || typeof value === "string" || typeof value === "bigint") {
    return value;
  }
  if (typeof value === "number") {
    throw new VirProgramError("binary floating point is prohibited in CRG-VIR");
  }
  if (Array.isArray(value)) return value.map(decodeUntyped);
  if (object(value)) {
    if (own(value, "exact") || (own(value, "numerator") && own(value, "denominator"))) {
      return exact(value);
    }
    if (own(value, "lo") && own(value, "hi")) {
      const [lo, hi] = interval(value);
      return new IntervalValue(lo, hi);
    }
    if (own(value, "value") && own(value, "unit")) {
      return new Quantity(exact(value.value), String(value.unit));
    }
    const result = Object.create(null);
    for (const key of Object.keys(value)) result[String(key)] = decodeUntyped(value[key]);
    return new MapValue(result);
  }
  if (value === null) return null;
  throw new VirProgramError(`unsupported literal value ${typeof value}`);
}

export function validateValue(value, declaredType) {
  const kind = String(declaredType);
  if (kind === "boolean") {
    if (typeof value !== "boolean") throw new VirProgramError("boolean input is not a JSON boolean");
    return value;
  }
  if (kind === "integer") {
    const decoded = exact(value);
    if (decoded.d !== 1n) throw new VirProgramError("integer input has a fractional value");
    return decoded.n;
  }
  if (kind === "rational" || kind === "decimal") return exact(value);
  if (kind === "interval") {
    try {
      const [lo, hi] = interval(value);
      return new IntervalValue(lo, hi);
    } catch (error) {
      if (error instanceof ArithError) throw new VirProgramError(error.message);
      throw error;
    }
  }
  if (kind === "quantity") {
    if (!object(value) || !own(value, "value") || !String(value.unit ?? "")) {
      throw new VirProgramError("quantity input requires value and non-empty unit");
    }
    return new Quantity(exact(value.value), String(value.unit));
  }
  if (kind === "vector") {
    if (!Array.isArray(value)) throw new VirProgramError("vector input is not a finite sequence");
    return value.map(decodeUntyped);
  }
  if (kind === "matrix") {
    if (!Array.isArray(value)) throw new VirProgramError("matrix input is not a finite row sequence");
    const rows = value.map((row) => validateValue(row, "vector"));
    if (rows.length > 0 && rows.some((row) => row.length !== rows[0].length)) {
      throw new VirProgramError("matrix rows have different lengths");
    }
    return rows;
  }
  if (kind === "set") {
    if (!Array.isArray(value)) throw new VirProgramError("set input is not a finite collection");
    const decoded = value.map(decodeUntyped);
    for (let i = 0; i < decoded.length; i += 1) {
      if (decoded.slice(0, i).some((other) => equalValue(other, decoded[i]))) {
        throw new VirProgramError("set input contains duplicate values");
      }
    }
    return new SetValue(decoded);
  }
  if (kind === "map") {
    if (!object(value)) throw new VirProgramError("map input is not an object");
    const decoded = Object.create(null);
    for (const key of Object.keys(value)) decoded[key] = decodeUntyped(value[key]);
    return new MapValue(decoded);
  }
  if (REFERENCES.has(kind)) {
    if (typeof value !== "string" || value.length === 0) {
      throw new VirProgramError(`${kind} input must be a non-empty string`);
    }
    return value;
  }
  throw new VirProgramError(`unsupported CRG-VIR type ${JSON.stringify(kind)}`);
}

function equalValue(a, b) {
  if ((a instanceof Rational || typeof a === "bigint") &&
      (b instanceof Rational || typeof b === "bigint")) return numeric(a).eq(numeric(b));
  if (a instanceof IntervalValue && b instanceof IntervalValue) return a.lo.eq(b.lo) && a.hi.eq(b.hi);
  if (a instanceof Quantity && b instanceof Quantity) return a.unit === b.unit && a.value.eq(b.value);
  if (a instanceof SetValue && b instanceof SetValue) {
    return a.values.length === b.values.length &&
      a.values.every((value) => b.values.some((other) => equalValue(value, other)));
  }
  if (a instanceof MapValue && b instanceof MapValue) {
    const ak = Object.keys(a.value).sort(); const bk = Object.keys(b.value).sort();
    return ak.length === bk.length && ak.every((key, i) => key === bk[i] && equalValue(a.value[key], b.value[key]));
  }
  if (Array.isArray(a) && Array.isArray(b)) {
    return a.length === b.length && a.every((value, i) => equalValue(value, b[i]));
  }
  return a === b;
}

function numeric(value) {
  if (value instanceof Rational) return value;
  if (typeof value === "bigint") return new Rational(value);
  throw new VirProgramError("value used as an exact scalar has the wrong type");
}

function intervalValue(value) {
  if (value instanceof IntervalValue) return value;
  const scalar = numeric(value);
  return new IntervalValue(scalar, scalar);
}

function finite(value, budget) {
  let result;
  if (Array.isArray(value)) result = value;
  else if (value instanceof SetValue) result = value.values;
  else if (value instanceof MapValue) result = Object.keys(value.value).sort().map((k) => value.value[k]);
  else throw new VirProgramError("value is not a finite collection");
  budget.collection(result.length);
  return result;
}

function arithmetic(op, a, b) {
  if (a instanceof Quantity || b instanceof Quantity) {
    if (!(a instanceof Quantity) || !(b instanceof Quantity) || a.unit !== b.unit) {
      throw new VirProgramError("quantity arithmetic requires matching units");
    }
    if (op === "add") return new Quantity(a.value.add(b.value), a.unit);
    if (op === "subtract") return new Quantity(a.value.sub(b.value), a.unit);
    throw new VirProgramError(`${op} is not defined for two quantities`);
  }
  if (a instanceof IntervalValue || b instanceof IntervalValue) {
    const x = intervalValue(a); const y = intervalValue(b);
    if (op === "add") return new IntervalValue(x.lo.add(y.lo), x.hi.add(y.hi));
    if (op === "subtract") return new IntervalValue(x.lo.sub(y.hi), x.hi.sub(y.lo));
    if (op === "exact_divide") {
      if (y.lo.lte(ZERO) && y.hi.gte(ZERO)) throw new VirProgramError("interval divisor contains zero");
      const r1 = new Rational(1n).div(y.lo); const r2 = new Rational(1n).div(y.hi);
      const reciprocal = r1.lte(r2) ? new IntervalValue(r1, r2) : new IntervalValue(r2, r1);
      return arithmetic("multiply", x, reciprocal);
    }
    const products = [x.lo.mul(y.lo), x.lo.mul(y.hi), x.hi.mul(y.lo), x.hi.mul(y.hi)];
    let lo = products[0]; let hi = products[0];
    for (const p of products) { if (p.lt(lo)) lo = p; if (p.gt(hi)) hi = p; }
    return new IntervalValue(lo, hi);
  }
  const x = numeric(a); const y = numeric(b);
  if (op === "add") return x.add(y);
  if (op === "subtract") return x.sub(y);
  if (op === "multiply") return x.mul(y);
  return x.div(y);
}

function pow(base, exponent) {
  if (exponent.d !== 1n) throw new VirProgramError("integer_power exponent is not an integer");
  let n = exponent.n; let x = base; let result = new Rational(1n);
  if (n < 0n) { x = new Rational(1n).div(x); n = -n; }
  while (n > 0n) { if (n & 1n) result = result.mul(x); x = x.mul(x); n >>= 1n; }
  return result;
}

class Budget {
  constructor(operations, collection, depth) {
    this.operations = operations; this.maxCollection = collection; this.maxDepth = depth;
  }
  spend(depth) {
    if (depth > this.maxDepth) throw new VirProgramError(`program nesting depth ${depth} exceeds max_depth ${this.maxDepth}`);
    this.operations -= 1;
    if (this.operations < 0) throw new VirProgramError("program exceeded its max_operations budget");
  }
  collection(length) {
    if (length > this.maxCollection) throw new VirProgramError(`finite collection has ${length} items, exceeding max_collection ${this.maxCollection}`);
  }
}

function evaluate(node, env, budget, depth) {
  if (!object(node)) throw new VirProgramError("every expression node must be an object");
  budget.spend(depth);
  const op = String(node.op ?? "");
  if (op === "literal") return validateValue(node.value, String(node.type ?? ""));
  if (op === "input") {
    const name = String(node.name ?? "");
    if (!Object.prototype.hasOwnProperty.call(env, name)) throw new VirProgramError(`program input ${JSON.stringify(name)} is not bound`);
    return env[name];
  }
  const one = (key = "value") => evaluate(node[key], env, budget, depth + 1);
  const two = () => [one("left"), one("right")];
  if (["add", "subtract", "multiply", "exact_divide"].includes(op)) return arithmetic(op, ...two());
  if (op === "integer_power") {
    const [base, exponent] = two();
    if (base instanceof IntervalValue) {
      const e = numeric(exponent); if (e.d !== 1n || e.n < 0n) throw new VirProgramError("interval power requires a non-negative integer");
      const candidates = [pow(base.lo, e), pow(base.hi, e)];
      if (base.lo.lte(ZERO) && base.hi.gte(ZERO) && e.n % 2n === 0n) candidates.push(ZERO);
      let lo = candidates[0]; let hi = candidates[0]; for (const v of candidates) { if (v.lt(lo)) lo = v; if (v.gt(hi)) hi = v; }
      return new IntervalValue(lo, hi);
    }
    return pow(numeric(base), numeric(exponent));
  }
  if (["sum", "minimum", "maximum"].includes(op)) {
    const values = finite(one("collection"), budget);
    if (values.length === 0) { if (op === "sum") return ZERO; throw new VirProgramError(`${op} of an empty collection is undefined`); }
    if (op === "sum") return values.reduce((a, b) => arithmetic("add", a, b));
    return values.map(numeric).reduce((a, b) => op === "minimum" ? (a.lte(b) ? a : b) : (a.gte(b) ? a : b));
  }
  if (op === "dot_product") {
    const [left, right] = two(); const a = finite(left, budget); const b = finite(right, budget);
    if (a.length !== b.length) throw new VirProgramError("dot-product dimension mismatch");
    return a.reduce((total, value, i) => total.add(numeric(value).mul(numeric(b[i]))), ZERO);
  }
  if (op === "absolute_value") {
    const value = one();
    if (value instanceof IntervalValue) {
      const a = value.lo.abs(); const b = value.hi.abs();
      return new IntervalValue(value.lo.lte(ZERO) && value.hi.gte(ZERO) ? ZERO : (a.lte(b) ? a : b), a.gte(b) ? a : b);
    }
    return numeric(value).abs();
  }
  if (op === "interval_construct") {
    const [a, b] = two(); const lo = numeric(a); const hi = numeric(b);
    if (hi.lt(lo)) throw new VirProgramError("interval upper bound is below lower bound");
    return new IntervalValue(lo, hi);
  }
  if (op === "interval_contains") {
    const [a, b] = two(); const x = intervalValue(a); const y = intervalValue(b);
    return x.lo.lte(y.lo) && y.hi.lte(x.hi);
  }
  if (op === "unit_convert") {
    const value = one(); if (!(value instanceof Quantity)) throw new VirProgramError("unit_convert requires a quantity");
    const source = String(node.from_unit ?? value.unit); const target = String(node.to_unit ?? "");
    if (value.unit !== source || !target) throw new VirProgramError("unit conversion source/target does not match the quantity");
    return new Quantity(value.value.mul(exact(node.factor)), target);
  }
  if (op === "equal" || op === "not_equal") { const [a, b] = two(); const same = equalValue(a, b); return op === "equal" ? same : !same; }
  if (op === "less_than" || op === "greater_than") { const [a, b] = two(); return op === "less_than" ? numeric(a).lt(numeric(b)) : numeric(a).gt(numeric(b)); }
  if (op === "dominance") {
    const [left, right] = two(); const a = finite(left, budget); const b = finite(right, budget);
    if (a.length !== b.length) throw new VirProgramError("dominance dimension mismatch");
    const directions = Array.isArray(node.directions) && node.directions.length ? node.directions.map((v) => String(v).toUpperCase()) : a.map(() => "MINIMIZE");
    if (directions.length !== a.length) throw new VirProgramError("dominance directions dimension mismatch");
    let weak = true; let strict = false;
    for (let i = 0; i < a.length; i += 1) {
      const x = numeric(a[i]); const y = numeric(b[i]);
      if (directions[i] === "MINIMIZE") { weak = weak && x.lte(y); strict = strict || x.lt(y); }
      else if (directions[i] === "MAXIMIZE") { weak = weak && x.gte(y); strict = strict || x.gt(y); }
      else throw new VirProgramError(`unknown optimization direction ${JSON.stringify(directions[i])}`);
    }
    return weak && strict;
  }
  if (op === "member_of") { const [item, collection] = two(); return finite(collection, budget).some((v) => equalValue(item, v)); }
  if (op === "and" || op === "or") {
    if (!Array.isArray(node.args)) throw new VirProgramError(`${op} requires an args list`);
    budget.collection(node.args.length); const values = node.args.map((arg) => evaluate(arg, env, budget, depth + 1));
    if (values.some((v) => typeof v !== "boolean")) throw new VirProgramError(`${op} operands must be boolean`);
    return op === "and" ? values.every(Boolean) : values.some(Boolean);
  }
  if (op === "not") { const value = one(); if (typeof value !== "boolean") throw new VirProgramError("not operand must be boolean"); return !value; }
  if (op === "implies") { const [a, b] = two(); if (typeof a !== "boolean" || typeof b !== "boolean") throw new VirProgramError("implication operands must be boolean"); return !a || b; }
  if (op === "conditional") { const condition = one("condition"); if (typeof condition !== "boolean") throw new VirProgramError("conditional test must be boolean"); return one(condition ? "then" : "else"); }
  if (["for_all", "exists", "bounded_reduce"].includes(op)) {
    const collection = finite(one("collection"), budget); const variable = String(node.var ?? "");
    if (!variable || Object.prototype.hasOwnProperty.call(env, variable)) throw new VirProgramError("bound variable is empty or shadows an existing input");
    const values = collection.map((item) => evaluate(node.body, { ...env, [variable]: item }, budget, depth + 1));
    if (op === "for_all" || op === "exists") {
      if (values.some((v) => typeof v !== "boolean")) throw new VirProgramError(`${op} body must return boolean`);
      return op === "for_all" ? values.every(Boolean) : values.some(Boolean);
    }
    const reducer = String(node.reducer ?? "");
    if (!["add", "minimum", "maximum", "and", "or"].includes(reducer)) throw new VirProgramError(`unsupported bounded reducer ${JSON.stringify(reducer)}`);
    if (values.length === 0) { if (!own(node, "initial")) throw new VirProgramError("empty bounded reduction requires an initial value"); return one("initial"); }
    return values.slice(1).reduce((result, value) => {
      if (reducer === "add") return arithmetic("add", result, value);
      if (reducer === "minimum") return numeric(result).lte(numeric(value)) ? numeric(result) : numeric(value);
      if (reducer === "maximum") return numeric(result).gte(numeric(value)) ? numeric(result) : numeric(value);
      if (typeof result !== "boolean" || typeof value !== "boolean") throw new VirProgramError(`${reducer} reduction requires booleans`);
      return reducer === "and" ? result && value : result || value;
    }, values[0]);
  }
  throw new VirProgramError(`operation ${JSON.stringify(op)} is outside the executable baseline profile`);
}

function boundedInteger(value, name) {
  let integer;
  try {
    const decoded = rational(value); if (decoded.d !== 1n) throw new Error(); integer = decoded.n;
  } catch (_error) { throw new VirProgramError(`${name} is not an integer`); }
  if (integer <= 0n || integer > BigInt(Number.MAX_SAFE_INTEGER)) throw new VirProgramError(`${name} must be a positive bounded integer`);
  return Number(integer);
}

export function evaluateProgram(program, inputs, declaredInputs, limits) {
  if (!object(program)) throw new VirProgramError("program is not an object");
  if (String(program.ast_version ?? "") !== AST_VERSION) throw new VirProgramError(`program AST version is not ${JSON.stringify(AST_VERSION)}`);
  if (!object(inputs) || !object(declaredInputs)) throw new VirProgramError("program inputs and declarations must be maps");
  const declared = Object.keys(declaredInputs).sort(); const supplied = Object.keys(inputs).sort();
  if (declared.length !== supplied.length || declared.some((v, i) => v !== supplied[i])) throw new VirProgramError("input binding mismatch");
  const env = Object.create(null); for (const name of declared) env[name] = validateValue(inputs[name], String(declaredInputs[name]));
  const budget = new Budget(boundedInteger(limits.max_operations, "max_operations"), boundedInteger(limits.max_collection, "max_collection"), boundedInteger(limits.max_depth, "max_depth"));
  const result = evaluate(program.expression, env, budget, 1);
  if (String(program.result_type ?? "") === "boolean") {
    if (typeof result !== "boolean") throw new VirProgramError("program declared boolean but evaluated to another type");
  } else {
    throw new VirProgramError("this verifier requires a boolean certificate-authorizing result");
  }
  return result;
}
