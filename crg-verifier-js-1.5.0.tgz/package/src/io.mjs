/**
 * Reading an input completely, without a callback and without a surprise.
 *
 * `fs.readFileSync(0)` looks like the obvious way to slurp standard input,
 * and it is wrong: when the parent process leaves the pipe in non-blocking
 * mode -- which is what happens when a test harness or a shell pipeline
 * feeds this program -- the first read raises EAGAIN and the document is
 * silently seen as unreadable.  A verifier that reported FAILED because the
 * pipe was not ready yet would be producing a verdict about the operating
 * system and labelling it a verdict about the certificate, so the read is
 * written out and retried to genuine end of file.
 *
 * Only `node:fs` is used.  Nothing here interprets the bytes.
 */
import { openSync, closeSync, readSync } from "node:fs";

const CHUNK = 1 << 16;
const IDLE = new Int32Array(new SharedArrayBuffer(4));

function pause(milliseconds) {
  // A synchronous sleep, so the read loop stays a read loop: introducing an
  // event loop here would make the order of reads depend on scheduling.
  Atomics.wait(IDLE, 0, 0, milliseconds);
}

/** Read a file descriptor to end of file and decode it as UTF-8. */
export function readAll(fd) {
  const chunks = [];
  const buffer = Buffer.alloc(CHUNK);
  for (;;) {
    let bytes;
    try {
      bytes = readSync(fd, buffer, 0, CHUNK, null);
    } catch (error) {
      if (error.code === "EAGAIN") {
        pause(2);
        continue;
      }
      if (error.code === "EOF") break;
      throw error;
    }
    if (bytes === 0) break;
    chunks.push(Buffer.from(buffer.subarray(0, bytes)));
  }
  return Buffer.concat(chunks).toString("utf8");
}

/** Read `path` as UTF-8 text; `-` means standard input. */
export function readTextFrom(path) {
  if (path === "-" || path === undefined || path === null) return readAll(0);
  const fd = openSync(path, "r");
  try {
    return readAll(fd);
  } finally {
    closeSync(fd);
  }
}
