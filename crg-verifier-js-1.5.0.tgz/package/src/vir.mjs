/**
 * CRG Verification Intermediate Representation, verification side (spec 24).
 *
 * CRG-VIR is the restricted, deterministic carrier that brings
 * certificate-authorizing logic into the independent verifier without
 * bringing the producer's code with it (24.1).  A VIR document is *total*:
 * it carries the coordinate schema, the retained signatures, the claim, the
 * derivation, the tolerances, the generator sets a regret witness needs, and
 * every hash the claim references.  `verifyVir` therefore runs with no other
 * file present, no server, and no network -- the point of 25.1.
 *
 * The verifier never executes producer code.  It decodes the document,
 * re-derives every asserted quantity from the carried data, and evaluates
 * only the closed, typed, resource-bounded JSON AST in `vir-ast.mjs`.
 * 24.4's prohibitions are also enforced structurally before evaluation.
 *
 * There is no emitter here, and that is deliberate.  This package is the
 * *second* implementation of 25.5; giving it a producer would let a document
 * be written and checked by the same code, which is the one thing an
 * independent verifier must not be able to do.
 */
import { ArithError, fmt, rational } from "./rational.mjs";
import { CanonicalError, get, has, hashWithout, isHash, isObject } from "./canonical.mjs";
import { verifyCertificate, pyOr, pyRepr, pyStr, truthy } from "./certificate.mjs";
import { Level, Status, VerificationResult } from "./result.mjs";
import { VirProgramError, evaluateProgram } from "./vir-ast.mjs";

export const VIR_VERSION = "0.2.0";

/**
 * The baseline CRG-VIR profile (24.3).  An operation outside this set needs
 * a registered extension checker, which 24.6 says is not automatically part
 * of the minimal trusted core.
 */
export const BASELINE_OPERATIONS = new Set(
  ("add subtract multiply exact_divide integer_power sum minimum maximum dot_product " +
    "absolute_value interval_construct interval_contains unit_convert equal not_equal " +
    "less_than greater_than dominance member_of and or not implies for_all exists " +
    "conditional bounded_reduce").split(" "),
);

/** The declared types of 24.2. */
export const BASELINE_TYPES = new Set(
  ("boolean integer rational decimal interval quantity vector matrix set map " +
    "object_ref geometry_ref proof_ref").split(" "),
);

/**
 * 24.4.  Any of these as an object key makes the document inadmissible: it
 * would require the verifier to reach outside itself.
 */
export const PROHIBITED_KEYS = new Set(
  ("code source_code eval exec import imports module entry_point callable plugin shell " +
    "command url uri endpoint http https network socket filesystem file_path filepath env " +
    "environment getenv random rng seed_source wall_clock now recursion while goto").split(" "),
);

export const REQUIRED_KEYS = [
  "vir_version", "program_id", "inputs", "output_claim_type", "operations",
  "program", "limits", "coordinate_schema", "registry", "claim", "tolerances", "hashes",
];

function asObject(value) {
  return isObject(value) ? value : Object.create(null);
}

function asArray(value) {
  return Array.isArray(value) ? value : [];
}

function pySorted(values) {
  return [...values].sort((a, b) => (a < b ? -1 : a > b ? 1 : 0));
}

/** Depth-first scan for the prohibited construct names of 24.4. */
function scanProhibited(value, path = "$") {
  const found = [];
  if (isObject(value)) {
    for (const key of Object.keys(value)) {
      const declarationMetadata = path.endsWith(".declaration.sandbox_requirements");
      if (!declarationMetadata && PROHIBITED_KEYS.has(pyStr(key).toLowerCase())) found.push(`${path}.${key}`);
      found.push(...scanProhibited(value[key], `${path}.${key}`));
    }
  } else if (Array.isArray(value)) {
    value.forEach((item, index) => {
      found.push(...scanProhibited(item, `${path}[${index}]`));
    });
  }
  return found;
}

function astOperations(value, found = new Set()) {
  if (isObject(value)) {
    const operation = get(value, "op");
    if (operation !== undefined && operation !== null && operation !== "literal" && operation !== "input") {
      found.add(pyStr(operation));
    }
    for (const key of Object.keys(value)) astOperations(value[key], found);
  } else if (Array.isArray(value)) {
    for (const item of value) astOperations(item, found);
  }
  return found;
}

/** Python `int(value)` for the integer-ish things a limits block can hold. */
function toBigInt(value) {
  if (typeof value === "bigint") return value;
  if (typeof value === "string") {
    const trimmed = value.trim();
    if (!/^[+-]?\d+$/.test(trimmed)) throw new ArithError(`${pyRepr(value)} is not an integer`);
    return BigInt(trimmed);
  }
  if (typeof value === "number" && Number.isSafeInteger(value)) return BigInt(value);
  if (value === true) return 1n;
  if (value === false) return 0n;
  throw new ArithError(`cannot read ${pyStr(value)} as an integer limit`);
}

/**
 * Verify a CRG-VIR document standalone (spec 24, 25).
 *
 * No file, server, solver, or network is consulted.  Everything the claim
 * needs is either inside the document or the claim is not verifiable, and
 * the second case is a failure, not a pass with a caveat (6.6).
 */
export function verifyVir(vir, { clock = null, clockSource = "none-supplied" } = {}) {
  const result = new VerificationResult();
  if (!isObject(vir)) {
    result.record("vir_structure", false, "CRG-VIR document is not a JSON object");
    result.status = Status.FAILED;
    return result.finish();
  }
  const missing = REQUIRED_KEYS.filter((key) => !has(vir, key));
  if (
    !result.record(
      "vir_structure",
      missing.length === 0,
      missing.length > 0
        ? `missing required fields ${pyStr(missing)}`
        : `all ${REQUIRED_KEYS.length} required CRG-VIR fields present (24.5)`,
    )
  ) {
    result.status = Status.FAILED;
    return result.finish();
  }

  result.record(
    "vir_version",
    pyStr(get(vir, "vir_version")) === VIR_VERSION,
    `document declares ${pyRepr(get(vir, "vir_version") ?? null)}; this verifier implements ` +
      `${pyRepr(VIR_VERSION)} (spec 24.5, 15.2)`,
  );

  // 24.5: content hash over the document, excluding the hash block itself.
  const stated = get(asObject(pyOr(get(vir, "hashes"), Object.create(null))), "program_hash") ?? null;
  let recomputed = null;
  try {
    recomputed = hashWithout(vir, "hashes");
    result.record("vir_canonical_form", true, "document is canonically encodable");
  } catch (error) {
    if (!(error instanceof CanonicalError)) throw error;
    recomputed = null;
    result.record("vir_canonical_form", false, error.message);
  }
  result.record(
    "vir_program_hash",
    truthy(stated) && isHash(pyStr(stated)) && recomputed === stated,
    `stated ${stated}, recomputed ${recomputed}`,
  );

  // 24.4: prohibited behavior.
  const prohibited = scanProhibited(vir);
  result.record(
    "vir_no_prohibited_constructs",
    prohibited.length === 0,
    prohibited.length > 0
      ? `document names prohibited constructs at ${pyStr(prohibited)} (24.4)`
      : "no code, plugin, URL, path, environment, randomness, or clock reference",
  );

  // 24.2 / 24.3: declared types and the baseline operation profile.
  const inputs = asObject(pyOr(get(vir, "inputs"), Object.create(null)));
  const declaredTypes = new Set(Object.keys(inputs).map((k) => pyStr(inputs[k])));
  const unknown = pySorted([...declaredTypes].filter((t) => !BASELINE_TYPES.has(t)));
  result.record(
    "vir_declared_types",
    unknown.length === 0,
    unknown.length > 0
      ? `input types outside the CRG-VIR type set: ${pyStr(unknown)} (24.2)`
      : `declared input types ${pyStr(pySorted([...declaredTypes]))} are all baseline types`,
  );
  const operations = new Set(asArray(pyOr(get(vir, "operations"), [])).map(pyStr));
  const extensions = pySorted([...operations].filter((o) => !BASELINE_OPERATIONS.has(o)));
  const undeclared = pySorted([...astOperations(get(vir, "program"))].filter((o) => !operations.has(o)));
  result.record(
    "vir_operation_profile",
    extensions.length === 0 && undeclared.length === 0,
    undeclared.length > 0
      ? `program uses undeclared operations ${pyStr(undeclared)} (24.3, 24.5)`
      : extensions.length > 0
      ? `operations ${pyStr(extensions)} are outside the baseline profile and require a ` +
        "registered extension checker, which is not part of the minimal trusted core (24.3, 24.6)"
      : `${operations.size} operations, all inside the baseline profile (24.3)`,
  );

  // 24.5: bounded resource limits, declared and respected.
  const limits = asObject(pyOr(get(vir, "limits"), Object.create(null)));
  const registry = asObject(pyOr(get(vir, "registry"), Object.create(null)));
  const entries = asArray(pyOr(get(registry, "entries"), []));
  const schema = asObject(pyOr(get(vir, "coordinate_schema"), Object.create(null)));
  const dimension = asArray(pyOr(get(schema, "coordinates"), [])).length;
  const limitNames = ["max_candidates", "max_dimension", "max_generators", "max_operations",
    "max_collection", "max_depth"];
  const breaches = limitNames.filter((n) => !has(limits, n)).map((n) => `${n} is not declared`);
  if (breaches.length === 0) {
    const generators = Math.max(
      asArray(pyOr(get(registry, "full_generators"), [])).length,
      asArray(pyOr(get(registry, "retained_generators"), [])).length,
    );
    for (const [actual, name] of [
      [entries.length, "max_candidates"],
      [dimension, "max_dimension"],
      [generators, "max_generators"],
    ]) {
      let declaredLimit;
      try {
        declaredLimit = toBigInt(limits[name]);
      } catch (error) {
        if (!(error instanceof ArithError)) throw error;
        breaches.push(`${name} is not an integer limit`);
        continue;
      }
      if (BigInt(actual) > declaredLimit) {
        breaches.push(`${actual} exceeds ${name} ${pyStr(limits[name])}`);
      }
    }
  }
  result.record(
    "vir_bounded_limits",
    breaches.length === 0,
    breaches.length > 0
      ? breaches.join("; ")
      : `declared limits present and respected (${entries.length} candidates, ` +
        `dimension ${dimension})`,
  );

  // 24.1 / 25.1: the document is self-contained.
  const external = asArray(pyOr(get(vir, "external_references"), []));
  result.record(
    "vir_self_contained",
    external.length === 0 && entries.length > 0 && truthy(schema),
    external.length > 0
      ? `document requires ${external.length} external references`
      : !truthy(schema)
        ? "no coordinate schema is carried"
        : entries.length === 0
          ? "no retained registry is carried"
          : "schema, registry, claim, tolerances, and hashes are all carried inline",
  );
  result.record(
    "vir_output_claim_type",
    pyStr(get(vir, "output_claim_type")) === "DECISION_CERTIFICATE_CLAIM",
    `declared output claim type ${pyRepr(get(vir, "output_claim_type") ?? null)}`,
  );

  // -- the claim itself -------------------------------------------------
  const claim = asObject(pyOr(get(vir, "claim"), Object.create(null)));
  const innerRegistry = Object.create(null);
  for (const key of Object.keys(registry)) innerRegistry[key] = registry[key];
  innerRegistry.schema = schema;
  const inner = verifyCertificate(claim, { registry: innerRegistry, clock, clockSource });
  result.checks.push(...inner.checks);
  result.violations.push(...inner.violations);
  result.warnings.push(...inner.warnings);
  Object.assign(result.report, inner.report);
  Object.assign(result.report, {
    vir_program_id: get(vir, "program_id") ?? null,
    vir_version: get(vir, "vir_version") ?? null,
  });

  // 24.5 requires a deterministic evaluation result.
  const evaluation = asObject(pyOr(get(vir, "evaluation"), Object.create(null)));
  result.record(
    "vir_deterministic_result",
    truthy(get(evaluation, "deterministic")) &&
      pyStr(get(evaluation, "result_claim")) === pyStr(get(claim, "outcome")),
    `declared result ${pyRepr(get(evaluation, "result_claim") ?? null)} against claim outcome ` +
      `${pyRepr(get(claim, "outcome") ?? null)}`,
  );

  // The tolerance the claim was decided under must be the tolerance the
  // document declares, or the carried program is not the program that
  // produced the claim.
  let agree;
  let detail;
  try {
    const tolerances = asObject(pyOr(get(vir, "tolerances"), Object.create(null)));
    const declaredTau = rational(has(tolerances, "policy_tolerance") ? tolerances.policy_tolerance : 0n);
    const claimScope = asObject(pyOr(get(claim, "scope"), Object.create(null)));
    const claimTau = rational(has(claimScope, "tie_tolerance") ? claimScope.tie_tolerance : 0n);
    agree = declaredTau.eq(claimTau);
    detail = agree
      ? `tolerance ${fmt(declaredTau)} matches the claim scope`
      : `CRG-VIR declares tolerance ${fmt(declaredTau)} but the claim was decided ` +
        `at ${fmt(claimTau)}`;
  } catch (error) {
    if (!(error instanceof ArithError)) throw error;
    agree = false;
    detail = `tolerance is not exactly decodable: ${error.message}`;
  }
  result.record("vir_tolerance_binding", agree, detail);

  // 24.1-24.5: execute the carried typed program with a verifier-owned
  // certificate result.  A document cannot assert its own successful
  // recomputation and thereby turn a forged claim into an affirmative result.
  let programOk = false;
  let programDetail;
  try {
    const programResult = evaluateProgram(
      asObject(pyOr(get(vir, "program"), Object.create(null))),
      {
        certificate_recomputed: Boolean(inner.ok),
        claim_selected: asArray(pyOr(get(claim, "selected"), [])),
        evaluated_selected: asArray(pyOr(get(evaluation, "selected"), [])),
        claim_outcome: pyStr(pyOr(get(claim, "outcome"), "UNDECLARED")),
        evaluated_outcome: pyStr(pyOr(get(evaluation, "result_claim"), "UNDECLARED")),
      },
      inputs,
      limits,
    );
    programOk = programResult === true;
    programDetail = programOk
      ? "typed CRG-VIR program evaluated deterministically to true"
      : `typed CRG-VIR program evaluated to ${pyRepr(programResult)}, not true`;
  } catch (error) {
    if (!(error instanceof VirProgramError)) throw error;
    programDetail = `typed CRG-VIR program refused: ${error.message}`;
  }
  result.record("vir_typed_program", programOk, programDetail);

  result.finish();
  if (inner.status === Status.UNVERIFIABLE_REDACTED) result.ok = false;
  result.status = result.ok || inner.status === Status.UNVERIFIABLE_REDACTED
    ? inner.status
    : inner.status === Status.EXPIRED
      ? Status.EXPIRED
      : Status.FAILED;
  Object.assign(result.report, {
    final_status: result.status,
    level_attempted: Level.V3,
    level_achieved: result.ok
      ? (result.status === Status.REPLAY_BOUND ? Level.V2 : Level.V3)
      : "NONE",
  });
  return result;
}
