/**
 * Independent verifier for the CRG v1.1 safe-commitment artifact.
 *
 * Normative basis: Master Specification 20, 26, 27, 29 and the registered
 * `crg-safe-commitment/finite-exact@1` profile.  This implementation is
 * reasoned directly from those obligations.  It does not call the producer,
 * Python, a solver, a network service, or the host clock.  Exact arithmetic is
 * BigInt rational arithmetic from this verifier's own trusted core.
 */
import {
  contentHash, get, hashWithout, isObject,
} from "./canonical.mjs";
import {
  ArithError, Rational, ZERO, fmt, minimum, positivePartSup, rational,
} from "./rational.mjs";
import { deriveClaimScope, requiredObjectFor } from "./certificate.mjs";
import { Level, Status, VerificationResult } from "./result.mjs";

export const SAFE_COMMITMENT_SCHEMA_VERSION = "1.1.0";
export const SAFE_COMMITMENT_PROFILE = "crg-safe-commitment/finite-exact@1";
export const REGRET_PROFILE = "crg-regret/strict-separation-finite-exact@1";
export const BOUND_PROFILE = "crg-regret-bound/fixed-additive-finite-exact@1";

export const DEFAULT_COMMITMENT_LIMITS = Object.freeze({
  maxEntries: 100_000,
  maxDimension: 256,
  maxDecisions: 4_096,
  maxPolicies: 1_024,
  maxGenerators: 250_000,
  maxPruningAssessments: 1_000_000,
});

const POLICIES = new Set([
  "retain-all", "fiber-preserving", "retain-all-signatures", "universal-monotone",
  "additive-price-visible", "retain-all-winners", "argmin-hitting", "bounded-regret",
]);
const ADDITIVE = new Set(["weighted_sum", "linear", "additive", "additive_price", "dot", "price_vector"]);
const PRUNING_CONDITIONS = [
  "VALID_LOWER_OR_OUTER_BOUND",
  "FEASIBLE_INCUMBENT_OR_UPPER_WITNESS",
  "SCOPE_MATCH",
  "DERIVATION_PERMITS_COMPARISON",
  "INTERVAL_SAFE_COMPARISON",
  "TIE_POLICY_PRESERVED",
  "REQUIRED_GEOMETRY_PRESERVED",
  "COMPLETENESS_IMPLICATIONS_VALID",
  "DEPENDENCIES_VALID",
  "PRUNING_CERTIFICATE_EMITTED",
];

function array(value, label) {
  if (!Array.isArray(value)) throw new TypeError(`${label} must be an array`);
  return value;
}

function text(value, label) {
  if (typeof value !== "string" || value.length === 0) {
    throw new TypeError(`${label} must be a non-empty string`);
  }
  return value;
}

function ownEntries(value, label) {
  if (!isObject(value)) throw new TypeError(`${label} must be an object`);
  return Object.entries(value);
}

function withinLimit(value, limit, label) {
  if (!Number.isSafeInteger(value) || value < 0 || value > limit) {
    throw new RangeError(`${label} ${value} exceeds registered limit ${limit}`);
  }
}

function sealed(record, hashKey) {
  if (!isObject(record)) return [false, `${hashKey} carrier must be an object`];
  const stated = get(record, hashKey);
  if (typeof stated !== "string") return [false, `${hashKey} is absent`];
  try {
    const actual = hashWithout(record, hashKey);
    return [stated === actual, `stated ${stated}; recomputed ${actual}`];
  } catch (error) {
    return [false, `canonical hashing failed: ${error.message}`];
  }
}

function point(raw, dimension = null) {
  const values = array(raw, "signature").map((value) => rational(value));
  if (values.length === 0) throw new ArithError("a signature must be non-empty");
  if (dimension !== null && values.length !== dimension) {
    throw new ArithError(`signature dimension ${values.length} differs from ${dimension}`);
  }
  return values;
}

function pointKey(value) {
  return value.map((coordinate) => coordinate.toString()).join("\u001f");
}

function comparePoint(left, right) {
  for (let index = 0; index < left.length; index += 1) {
    const order = left[index].cmp(right[index]);
    if (order !== 0) return order;
  }
  return 0;
}

function weaklyDominates(left, right) {
  if (left.length !== right.length) throw new ArithError("dimension mismatch in dominance test");
  return left.every((value, index) => value.lte(right[index]));
}

function dominates(left, right) {
  return weaklyDominates(left, right) && left.some((value, index) => value.lt(right[index]));
}

function uniquePoints(values) {
  const table = new Map();
  for (const value of values) table.set(pointKey(value), value);
  return [...table.values()].sort(comparePoint);
}

function pareto(values) {
  const points = uniquePoints(values);
  return points.filter((candidate) => !points.some(
    (other) => pointKey(other) !== pointKey(candidate) && dominates(other, candidate),
  ));
}

function cross(origin, first, second) {
  return first[0].sub(origin[0]).mul(second[1].sub(origin[1]))
    .sub(first[1].sub(origin[1]).mul(second[0].sub(origin[0])));
}

function planarK(values) {
  const frontier = pareto(values);
  if (frontier.some((value) => value.length !== 2)) {
    throw new TypeError("additive-price-visible verification supports planar geometry only");
  }
  const hull = [];
  for (const value of frontier) {
    while (hull.length >= 2 && cross(hull[hull.length - 2], hull[hull.length - 1], value).lte(ZERO)) {
      hull.pop();
    }
    hull.push(value);
  }
  return hull;
}

function setEqual(left, right) {
  return left.size === right.size && [...left].every((value) => right.has(value));
}

function setSubset(left, right) {
  return [...left].every((value) => right.has(value));
}

function parseRegistry(registry, limits) {
  const raw = array(get(registry, "entries"), "registry.entries");
  withinLimit(raw.length, limits.maxEntries, "registry entry count");
  if (raw.length === 0) throw new TypeError("safe commitment requires a non-empty represented family");
  const entries = new Map();
  let dimension = null;
  for (const item of raw) {
    if (!isObject(item)) throw new TypeError("every registry entry must be an object");
    const identifier = text(get(item, "realization_id"), "realization identity");
    if (entries.has(identifier)) throw new TypeError(`duplicate realization identity ${identifier}`);
    const value = point(get(item, "signature"), dimension);
    if (dimension === null) {
      dimension = value.length;
      withinLimit(dimension, limits.maxDimension, "signature dimension");
    }
    entries.set(identifier, { raw: item, point: value });
  }
  return entries;
}

function registryBindingFailures(registry, entries, limits) {
  const failures = [];
  const bundle = get(registry, "bundle");
  if (!isObject(bundle)) return ["registry.bundle must be an object"];
  if (get(registry, "bundle_id") !== get(bundle, "bundle_id")) {
    failures.push("registry bundle identity differs from the sealed bundle");
  }
  let raw;
  try {
    raw = array(get(bundle, "realizations"), "sealed bundle realizations");
    withinLimit(raw.length, limits.maxEntries, "sealed bundle realization count");
  } catch (error) {
    return failures.concat(error.message);
  }
  const projected = new Map();
  try {
    for (const item of raw) {
      if (!isObject(item)) throw new TypeError("every sealed-bundle realization must be an object");
      const identifier = text(get(item, "realization_id"), "sealed-bundle realization identity");
      if (projected.has(identifier)) throw new TypeError(`duplicate sealed-bundle realization ${identifier}`);
      projected.set(identifier, {
        point: point(get(item, "signature")),
        legality: get(item, "legality"),
        attributes: get(item, "attributes", Object.create(null)),
        evidenceClass: get(item, "evidence_class"),
      });
    }
  } catch (error) {
    return failures.concat(`sealed bundle cannot be projected exactly: ${error.message}`);
  }
  if (!setEqual(new Set(projected.keys()), new Set(entries.keys()))) {
    failures.push("registry.entries identities differ from the sealed bundle");
    return failures;
  }
  for (const identifier of [...entries.keys()].sort()) {
    const entry = entries.get(identifier);
    const source = projected.get(identifier);
    if (pointKey(entry.point) !== pointKey(source.point)) {
      failures.push(`registry entry ${identifier} signature differs from the sealed bundle`);
    }
    if (get(entry.raw, "legality") !== source.legality) {
      failures.push(`registry entry ${identifier} legality differs from the sealed bundle`);
    }
    if (get(entry.raw, "evidence_class") !== source.evidenceClass) {
      failures.push(`registry entry ${identifier} evidence_class differs from the sealed bundle`);
    }
    if (!sameCanonical(get(entry.raw, "attributes", Object.create(null)), source.attributes)) {
      failures.push(`registry entry ${identifier} attributes differ from the sealed bundle`);
    }
  }
  return failures;
}

function retainedBundleHash(registry, retained) {
  const bundle = get(registry, "bundle");
  if (!isObject(bundle)) throw new TypeError("sealed bundle is unavailable for retained-family reconstruction");
  const raw = array(get(bundle, "realizations"), "sealed bundle realizations");
  const selected = new Set(retained);
  return contentHash({
    ...bundle,
    bundle_id: `${get(bundle, "bundle_id")}::retained`,
    realizations: raw.filter((item) => isObject(item) && selected.has(get(item, "realization_id"))),
  });
}

function representatives(entries, desiredPoints) {
  const desired = new Set(desiredPoints.map(pointKey));
  const represented = new Set();
  const retained = new Set();
  for (const identifier of [...entries.keys()].sort()) {
    const key = pointKey(entries.get(identifier).point);
    if (desired.has(key) && !represented.has(key)) {
      represented.add(key);
      retained.add(identifier);
    }
  }
  return retained;
}

function fixedWeight(value) {
  let result;
  if (Array.isArray(value)) {
    if (value.length !== 2) throw new ArithError("a price range must have two endpoints");
    const low = rational(value[0]);
    const high = rational(value[1]);
    if (!low.eq(high)) throw new ArithError("a ranged price is outside the fixed-additive profile");
    result = low;
  } else if (isObject(value) && !Object.prototype.hasOwnProperty.call(value, "exact")) {
    const lowRaw = get(value, "lo", get(value, "low", get(value, "min")));
    const highRaw = get(value, "hi", get(value, "high", get(value, "max")));
    if (lowRaw === undefined || highRaw === undefined) {
      throw new ArithError("a price mapping must declare both endpoints");
    }
    const low = rational(lowRaw);
    const high = rational(highRaw);
    if (!low.eq(high)) throw new ArithError("a ranged price is outside the fixed-additive profile");
    result = low;
  } else {
    result = rational(value);
  }
  if (result.lt(ZERO)) throw new ArithError("an additive price must be nonnegative");
  return result;
}

function coordinateOrder(scope, registry) {
  const objective = get(scope, "objective_family", Object.create(null));
  const declared = get(objective, "coordinate_order");
  if (Array.isArray(declared) && declared.length > 0) return declared.map(String);
  const coordinates = array(get(get(registry, "schema", Object.create(null)), "coordinates"), "schema coordinates");
  if (coordinates.length === 0) throw new TypeError("coordinate schema has no canonical order");
  return coordinates.map((coordinate) => text(get(coordinate, "identifier"), "coordinate identifier"));
}

function objectiveValue(value, objective, order) {
  const kind = String(get(objective, "type", "")).trim().toLowerCase();
  if (!ADDITIVE.has(kind)) throw new ArithError(`objective family ${kind} is not fixed additive`);
  const weights = get(objective, "weights", Object.create(null));
  if (!isObject(weights)) throw new ArithError("objective weights must be an object");
  if (value.length !== order.length) throw new ArithError("coordinate order and signature dimension differ");
  let total = ZERO;
  for (let index = 0; index < value.length; index += 1) {
    const coefficient = Object.prototype.hasOwnProperty.call(weights, order[index])
      ? fixedWeight(weights[order[index]]) : new Rational(1n);
    total = total.add(coefficient.mul(value[index]));
  }
  return total;
}

function entryFeasible(entry, scope) {
  if (String(get(entry.raw, "legality", "LEGAL")) !== "LEGAL") return false;
  const attributes = get(entry.raw, "attributes", Object.create(null));
  if (!isObject(attributes)) throw new TypeError("registry entry attributes must be an object");
  const declared = get(attributes, "feasible", get(attributes, "feasibility"));
  if (declared === false || (typeof declared === "string" && ["INFEASIBLE", "UNKNOWN"].includes(declared.toUpperCase()))) {
    return false;
  }
  const domain = get(scope, "technology_domain", Object.create(null));
  if (!isObject(domain)) throw new TypeError("technology_domain must be an object");
  for (const [name, bounds] of Object.entries(domain)) {
    if (!Object.prototype.hasOwnProperty.call(attributes, name) || !Array.isArray(bounds) || bounds.length !== 2) continue;
    const observed = rational(attributes[name]);
    if (observed.lt(rational(bounds[0])) || observed.gt(rational(bounds[1]))) return false;
  }
  return true;
}

function argminHitting(entries, family, registry, forceAllTies = false) {
  const retained = new Set();
  let found = false;
  for (const decision of array(get(family, "decisions", []), "family decisions")) {
    const scope = get(decision, "scope", Object.create(null));
    const objective = get(scope, "objective_family", Object.create(null));
    if (!["finite_ledger", "case_ledger", "ledger"].includes(String(get(objective, "type", "")).toLowerCase())) {
      continue;
    }
    found = true;
    const order = coordinateOrder(scope, registry);
    const cases = array(get(objective, "cases", []), "finite-ledger cases");
    if (cases.length === 0) throw new TypeError("argmin-hitting requires finite named cases");
    for (const declaredCase of cases) {
      const values = new Map();
      for (const [identifier, entry] of entries) {
        if (!entryFeasible(entry, scope)) continue;
        values.set(identifier, objectiveValue(entry.point, declaredCase, order));
      }
      if (values.size === 0) throw new TypeError("a finite-ledger case has no established feasible realization");
      const optimum = minimum(values.values());
      const winners = [...values.entries()].filter(([, value]) => value.eq(optimum)).map(([id]) => id).sort();
      const allTies = forceAllTies || Boolean(get(scope, "retain_all_ties", true));
      for (const identifier of allTies ? winners : winners.slice(0, 1)) retained.add(identifier);
    }
  }
  if (!found) throw new TypeError("argmin-hitting requires a finite-ledger decision");
  return retained;
}

function protectedIds(entries, declaration) {
  const protectedSet = new Set(array(get(declaration, "protected_ids", []), "protected_ids").map(String));
  const missing = [...protectedSet].filter((identifier) => !entries.has(identifier));
  if (missing.length) throw new TypeError(`protected identities are absent: ${missing.sort().join(", ")}`);
  for (const [field, values] of ownEntries(get(declaration, "protected_classes", Object.create(null)), "protected_classes")) {
    const allowed = array(values, `protected class ${field}`);
    for (const [identifier, entry] of entries) {
      const attributes = get(entry.raw, "attributes", Object.create(null));
      if (isObject(attributes) && allowed.some((value) => value === get(attributes, field))) {
        protectedSet.add(identifier);
      }
    }
  }
  return protectedSet;
}

function familyProtectedIds(entries, family) {
  const protectedSet = new Set();
  for (const decision of array(get(family, "decisions", []), "family decisions")) {
    const objective = get(get(decision, "scope", Object.create(null)), "objective_family", Object.create(null));
    for (const field of ["protected_ids", "required_retained_identities"]) {
      for (const identifier of array(get(objective, field, []), field)) protectedSet.add(String(identifier));
    }
  }
  const missing = [...protectedSet].filter((identifier) => !entries.has(identifier));
  if (missing.length) throw new TypeError(`future decision family protects absent identities: ${missing.sort().join(", ")}`);
  return protectedSet;
}

function expectedRetained(entries, family, registry, declaration) {
  const policy = String(get(declaration, "policy", ""));
  if (!POLICIES.has(policy)) throw new TypeError(`unknown retention policy ${policy}`);
  const parameters = get(declaration, "parameters", Object.create(null));
  if (!isObject(parameters)) throw new TypeError("policy parameters must be an object");
  const points = [...entries.values()].map((entry) => entry.point);
  let retained;
  const proposal = get(parameters, "retained_ids");
  if (proposal !== undefined) {
    if (policy !== "bounded-regret") {
      throw new TypeError("retained_ids is registered only for bounded-regret proposals");
    }
    const proposed = array(proposal, "retained_ids");
    if (proposed.length === 0) throw new TypeError("an empty retained family has unbounded regret");
    retained = new Set(proposed.map(String));
    const missing = [...retained].filter((identifier) => !entries.has(identifier));
    if (missing.length) throw new TypeError(`retained identities are absent: ${missing.sort().join(", ")}`);
  } else if (["retain-all", "fiber-preserving"].includes(policy)) {
    retained = new Set(entries.keys());
  } else if (policy === "retain-all-signatures") {
    retained = representatives(entries, points);
  } else if (["universal-monotone", "bounded-regret"].includes(policy)) {
    retained = representatives(entries, pareto(points));
  } else if (policy === "additive-price-visible") {
    retained = representatives(entries, planarK(points));
  } else if (["argmin-hitting", "retain-all-winners"].includes(policy)) {
    retained = argminHitting(entries, family, registry, policy === "retain-all-winners");
  } else {
    throw new TypeError(`unsupported retention policy ${policy}`);
  }
  for (const identifier of protectedIds(entries, declaration)) retained.add(identifier);
  for (const identifier of familyProtectedIds(entries, family)) retained.add(identifier);
  return retained;
}

function preservation(required, entries, retained, decision, registry) {
  const full = [...entries.values()].map((entry) => entry.point);
  const kept = [...retained].sort().map((identifier) => entries.get(identifier).point);
  if (required === "REALIZATION_REGISTRY_AND_FIBERS") {
    return [setEqual(retained, new Set(entries.keys())), "all realization identities and fibers"];
  }
  if (required === "R") {
    return [setEqual(new Set(full.map(pointKey)), new Set(kept.map(pointKey))), "exact signature set R"];
  }
  if (required === "GAMMA") {
    return [setEqual(new Set(pareto(full).map(pointKey)), new Set(pareto(kept).map(pointKey))), "Pareto frontier Gamma"];
  }
  if (required === "K") {
    return [setEqual(new Set(planarK(full).map(pointKey)), new Set(planarK(kept).map(pointKey))), "planar additive-price body K"];
  }
  if (required === "ARGMIN_HITTING_SET") {
    const target = argminHitting(entries, { decisions: [decision] }, registry);
    return [setSubset(target, retained), "finite-ledger argmin-hitting set"];
  }
  if (required === "BOUNDED_REGRET_REPRESENTATION") {
    return [true, "typed bounded-regret fact required"];
  }
  throw new TypeError(`unknown required retained object ${required}`);
}

function pointJson(value) {
  return value.map((coordinate) => ({ exact: coordinate.toString() }));
}

function sameCanonical(left, right) {
  try {
    return contentHash(left) === contentHash(right);
  } catch {
    return false;
  }
}

function previewFailures(evaluation, entries, retained) {
  const failures = [];
  const groups = new Map();
  for (const identifier of [...retained].sort()) {
    const value = entries.get(identifier).point;
    const key = pointKey(value);
    if (!groups.has(key)) groups.set(key, { point: value, ids: [] });
    groups.get(key).ids.push(identifier);
  }
  const expectedFibers = [...groups.values()].sort((left, right) => comparePoint(left.point, right.point))
    .map((group) => ({ signature: pointJson(group.point), realization_ids: group.ids }));
  if (!sameCanonical(get(evaluation, "retained_fibers"), expectedFibers)) {
    failures.push("retained-fiber preview differs from independent reconstruction");
  }
  const preview = get(evaluation, "geometry_preview");
  if (!isObject(preview)) return failures.concat("geometry_preview must be an object");
  const points = uniquePoints([...retained].map((identifier) => entries.get(identifier).point));
  if (!sameCanonical(get(preview, "R"), points.map(pointJson))) failures.push("R preview differs from retained exact signatures");
  const gamma = pareto(points);
  if (!sameCanonical(get(preview, "GAMMA"), gamma.map(pointJson))) failures.push("Gamma preview differs from retained Pareto frontier");
  const kPreview = get(preview, "K");
  if (points.length > 0 && points[0].length === 2) {
    if (!sameCanonical(kPreview, planarK(points).map(pointJson))) failures.push("K preview differs from retained planar additive-price body");
  } else if (!(isObject(kPreview) && ["UNSUPPORTED_PROFILE", "UNAVAILABLE"].includes(get(kPreview, "status")))) {
    failures.push("non-planar K preview must state an unsupported or unavailable profile");
  }
  return failures;
}

function verifyRegret(witness, limits, {
  registry, entries, retainedIds, decision,
}) {
  const failures = [];
  const [integrity, detail] = sealed(witness, "witness_hash");
  if (!integrity) failures.push(detail);
  if (get(witness, "verification_program") !== REGRET_PROFILE) failures.push("unknown regret verification program");
  const objective = get(witness, "objective", Object.create(null));
  if (get(objective, "family") !== "CONTINUOUS_STRICTLY_INCREASING_COERCIVE") {
    failures.push("objective is outside the registered regret family");
  }
  if (get(objective, "construction") !== "STRICT_INCREASING_COERCIVE_SEPARATION") {
    failures.push("regret objective uses an unknown constructive separation");
  }
  const membership = get(witness, "family_membership_proof", Object.create(null));
  if (!(isObject(membership)
    && get(membership, "profile") === REGRET_PROFILE
    && get(membership, "epsilon_strictly_positive") === true
    && get(membership, "construction") === "positive-part sup plus positive additive term")) {
    failures.push("regret family-membership proof is absent or outside the profile");
  }
  if (get(witness, "full_registry_hash") !== get(registry, "bundle_hash")) {
    failures.push("regret full-family reference is not the sealed registry");
  }
  try {
    if (get(witness, "retained_registry_hash") !== retainedBundleHash(registry, retainedIds)) {
      failures.push("regret retained-family reference differs from the evaluated retention set");
    }
  } catch (error) {
    failures.push(`retained-family reference cannot be reconstructed: ${error.message}`);
  }
  if (!isObject(decision)) failures.push("regret evidence names no decision in the future family");
  else if (get(witness, "validity") !== get(get(decision, "scope", Object.create(null)), "validity")) {
    failures.push("regret validity differs from the bound future decision");
  }
  if (!sameCanonical(get(witness, "completeness"), get(registry, "completeness"))) {
    failures.push("regret completeness differs from the represented family");
  }
  const basis = get(get(registry, "completeness", Object.create(null)), "basis_type");
  const expectedScope = ["EXHAUSTIVE_DECLARED_UNIVERSE", "GENERATOR_CLOSED"].includes(basis)
    ? "GLOBAL" : "RELATIVE";
  if (get(witness, "scope") !== expectedScope) {
    failures.push(`regret scope must be ${expectedScope} for completeness basis ${basis}`);
  }
  if (!sameCanonical(get(witness, "dependencies"), [...entries.keys()].sort())) {
    failures.push("regret dependencies do not equal the represented family identities");
  }
  if (get(witness, "evidence_class") !== "EXACT") {
    failures.push("the finite exact regret profile requires EXACT evidence");
  }
  let full; let retained; let lost; let anchor; let epsilon; let statedFull; let statedRetained; let statedGap;
  try {
    const fullRaw = array(get(witness, "full_generators"), "full generators");
    const retainedRaw = array(get(witness, "retained_generators"), "retained generators");
    withinLimit(fullRaw.length, limits.maxGenerators, "full generator count");
    withinLimit(retainedRaw.length, limits.maxGenerators, "retained generator count");
    full = fullRaw.map((value) => point(value));
    retained = retainedRaw.map((value) => point(value));
    lost = point(get(get(witness, "lost_element", Object.create(null)), "signature"));
    anchor = point(get(objective, "anchor"));
    epsilon = rational(get(objective, "epsilon"));
    statedFull = rational(get(witness, "full_infimum"));
    statedRetained = rational(get(witness, "retained_infimum"));
    statedGap = rational(get(witness, "gap"));
  } catch (error) {
    return failures.concat(`regret evidence is not exactly decodable: ${error.message}`);
  }
  const expectedFull = pareto([...entries.values()].map((entry) => entry.point));
  const expectedRetained = pareto([...retainedIds].map((identifier) => entries.get(identifier).point));
  if (!sameCanonical(full.map(pointJson), expectedFull.map(pointJson))) {
    failures.push("regret full generators differ from the sealed family frontier");
  }
  if (!sameCanonical(retained.map(pointJson), expectedRetained.map(pointJson))) {
    failures.push("regret retained generators differ from the evaluated retained frontier");
  }
  if (pointKey(lost) !== pointKey(anchor) || !full.some((value) => pointKey(value) === pointKey(lost))) {
    failures.push("lost signature/anchor is not in the full generator set");
  }
  if (retained.length === 0) return failures.concat("retained generator set is empty");
  if (!epsilon.gt(ZERO)) return failures.concat("regret objective epsilon is not strictly positive");
  const separation = minimum(retained.map((value) => positivePartSup(value, anchor)));
  if (separation === null || !separation.gt(ZERO)) failures.push("lost point remains inside the retained upper region");
  const phi = (value) => positivePartSup(value, anchor)
    .add(epsilon.mul(value.reduce((sum, coordinate) => sum.add(coordinate), ZERO)));
  const fullInfimum = minimum(full.map(phi));
  const retainedInfimum = minimum(retained.map(phi));
  if (fullInfimum === null || retainedInfimum === null) return failures.concat("a regret infimum is undefined");
  const gap = retainedInfimum.sub(fullInfimum);
  if (!fullInfimum.eq(statedFull) || !retainedInfimum.eq(statedRetained) || !gap.eq(statedGap)) {
    failures.push(`regret infima/gap do not match independent reconstruction (${fmt(fullInfimum)}, ${fmt(retainedInfimum)}, ${fmt(gap)})`);
  }
  if (!gap.gt(ZERO)) failures.push("reconstructed regret gap is not strictly positive");
  for (const [name, value] of [["numeric", get(witness, "numeric_interval")], ["evidence", get(witness, "evidence_interval")]]) {
    try {
      if (!rational(get(value, "lo")).eq(gap) || !rational(get(value, "hi")).eq(gap)) {
        failures.push(`${name} interval does not equal the exact regret gap`);
      }
    } catch (error) {
      failures.push(`${name} interval is not exactly decodable: ${error.message}`);
    }
  }
  return failures;
}

function verifyBound(fact, limits, {
  registry, entries, retainedIds, decision,
}) {
  const failures = [];
  const [integrity, detail] = sealed(fact, "fact_hash");
  if (!integrity) failures.push(detail);
  if (get(fact, "proof_profile") !== BOUND_PROFILE) failures.push("unknown bounded-regret proof profile");
  const scope = isObject(decision) ? get(decision, "scope", Object.create(null)) : Object.create(null);
  if (!isObject(decision)) failures.push("bounded-regret fact names no decision in the future family");
  try {
    const objective = get(fact, "objective_family", Object.create(null));
    if (!ADDITIVE.has(String(get(objective, "type", "")).toLowerCase())) throw new ArithError("bound objective is not additive");
    if (String(get(objective, "quantification", "EACH_OBJECTIVE")) !== "EACH_OBJECTIVE") {
      throw new ArithError("coupled robust aggregate is outside the bound profile");
    }
    const order = array(get(fact, "coordinate_order"), "coordinate order").map(String);
    const rawValues = array(get(fact, "full_values"), "full values");
    withinLimit(rawValues.length, limits.maxEntries, "bound value count");
    const values = new Map();
    for (const item of rawValues) {
      const identifier = text(get(item, "realization_id"), "bound realization identity");
      if (values.has(identifier)) throw new TypeError("bound values contain duplicate identities");
      values.set(identifier, point(get(item, "signature"), order.length));
    }
    const retained = new Set(array(get(fact, "retained_ids"), "bound retained ids").map(String));
    if (values.size === 0 || retained.size === 0 || !setSubset(retained, new Set(values.keys()))) {
      throw new TypeError("bound fact has an empty or unknown retained set");
    }
    const fullMinimum = minimum([...values.values()].map((value) => objectiveValue(value, objective, order)));
    const retainedMinimum = minimum([...retained].map((identifier) => objectiveValue(values.get(identifier), objective, order)));
    const computed = retainedMinimum.sub(fullMinimum);
    const stated = rational(get(fact, "bound"));
    const tolerance = rational(get(fact, "tolerance"));
    const expectedValues = new Map([...entries].map(([identifier, entry]) => [identifier, entry.point]));
    if (!setEqual(new Set(values.keys()), new Set(expectedValues.keys()))
      || [...values].some(([identifier, value]) => pointKey(value) !== pointKey(expectedValues.get(identifier)))) {
      failures.push("bounded-regret full values differ from the sealed registry");
    }
    if (!setEqual(retained, retainedIds)) {
      failures.push("bounded-regret retained identities differ from the evaluated policy");
    }
    let expectedOrder = [];
    try {
      expectedOrder = coordinateOrder(scope, registry);
    } catch (error) {
      failures.push(`bound decision coordinate order is invalid: ${error.message}`);
    }
    if (!sameCanonical(order, expectedOrder)) {
      failures.push("bounded-regret coordinate order differs from the bound decision");
    }
    const declaredObjective = {
      ...get(scope, "objective_family", Object.create(null)), coordinate_order: expectedOrder,
    };
    if (!sameCanonical(objective, declaredObjective)) {
      failures.push("bounded-regret objective family differs from the bound future decision");
    }
    const declaredBound = get(get(scope, "objective_family", Object.create(null)), "bounded_regret", Object.create(null));
    try {
      const declaredTolerance = rational(get(declaredBound, "tolerance"));
      if (!tolerance.eq(declaredTolerance) || get(declaredBound, "accept_approximation") !== true) {
        failures.push("bounded-regret tolerance/acceptance differs from the bound decision");
      }
    } catch (error) {
      failures.push(`bound decision tolerance is not exact: ${error.message}`);
    }
    if (!sameCanonical(get(fact, "completeness"), get(registry, "completeness"))) {
      failures.push("bounded-regret completeness differs from the represented family");
    }
    if (!sameCanonical(get(fact, "dependencies"), [...entries.keys()].sort())) {
      failures.push("bounded-regret dependencies do not equal the represented family identities");
    }
    if (computed.lt(ZERO)) failures.push("retained family reports a negative regret");
    if (!computed.eq(stated)) failures.push(`stated bound ${fmt(stated)} differs from reconstructed ${fmt(computed)}`);
    if (Boolean(get(fact, "accepted")) !== computed.lte(tolerance)) failures.push("accepted flag does not equal bound <= tolerance");
    if (String(get(fact, "evidence_class")) !== "EXACT") failures.push("fixed-additive profile requires EXACT evidence");
  } catch (error) {
    failures.push(`bounded-regret fact is not reconstructible: ${error.message}`);
  }
  return failures;
}

function verifyPruning(assessment) {
  const failures = [];
  const conditions = get(assessment, "conditions");
  if (!Array.isArray(conditions) || conditions.length !== 10) return ["a pruning assessment must expose exactly ten conditions"];
  const numbers = conditions.map((condition) => get(condition, "number"));
  if (!numbers.every((value, index) => Number(value) === index + 1)) failures.push("pruning condition numbers must be ordered 1..10");
  const identifiers = conditions.map((condition) => get(condition, "identifier"));
  if (!sameCanonical(identifiers, PRUNING_CONDITIONS)) {
    failures.push("pruning condition identifiers differ from the §29.2 ordered contract");
  }
  const statuses = conditions.map((condition) => String(get(condition, "status", "")));
  if (statuses.some((value) => !["PASS", "FAIL", "NOT_REACHED"].includes(value))) failures.push("a pruning condition uses an unknown status");
  const authorized = Boolean(get(assessment, "authorized"));
  if (authorized !== statuses.every((value) => value === "PASS")) failures.push("pruning authorization does not equal all ten conditions passing");
  const certificate = get(assessment, "certificate");
  if (authorized) {
    if (!isObject(certificate)) failures.push("authorized pruning has no certificate");
    else {
      const [integrity, detail] = sealed(certificate, "certificate_hash");
      if (!integrity) failures.push(detail);
      if (get(certificate, "pruned_id") !== get(assessment, "candidate_id")) failures.push("pruning certificate names a different candidate");
      for (const field of ["tie_policy_satisfied", "geometry_preserved", "dependencies_valid"]) {
        if (get(certificate, field) !== true) failures.push(`authorized pruning certificate has ${field}=false`);
      }
    }
  } else if (certificate !== undefined) failures.push("unauthorized pruning carries a certificate");
  return failures;
}

/** Verify one portable `SafeCommitmentArtifact`, fail closed and total. */
export function verifySafeCommitment(artifact, options = {}) {
  const result = new VerificationResult();
  const limits = { ...DEFAULT_COMMITMENT_LIMITS, ...(options.limits ?? {}) };
  result.report.artifact_type = "SafeCommitmentArtifact";
  result.report.profile = isObject(artifact) ? get(artifact, "profile") : undefined;
  result.report.level_attempted = Level.V3;
  result.report.level_achieved = "NONE";
  if (!isObject(artifact)) {
    result.record("artifact_shape", false, "safe-commitment artifact must be an object");
    return result.finish();
  }
  result.record(
    "registered_profile",
    get(artifact, "schema_version") === SAFE_COMMITMENT_SCHEMA_VERSION && get(artifact, "profile") === SAFE_COMMITMENT_PROFILE,
    `schema/profile must be ${SAFE_COMMITMENT_SCHEMA_VERSION}/${SAFE_COMMITMENT_PROFILE}`,
  );
  let [ok, detail] = sealed(artifact, "artifact_hash");
  result.record("artifact_integrity", ok, detail);

  let family = get(artifact, "family", Object.create(null));
  if (isObject(family)) {
    [ok, detail] = sealed(family, "family_hash");
    result.record("family_integrity", ok, detail);
  } else {
    result.record("family_integrity", false, "family must be an object");
    family = Object.create(null);
  }

  const decisionById = new Map();
  const familyErrors = [];
  try {
    const decisions = array(get(family, "decisions"), "future decisions");
    withinLimit(decisions.length, limits.maxDecisions, "future decision count");
    if (decisions.length === 0) throw new TypeError("future decision family is empty");
    for (const decision of decisions) {
      const identifier = text(get(decision, "decision_id"), "future decision identity");
      if (decisionById.has(identifier)) throw new TypeError(`duplicate future decision ${identifier}`);
      const scope = get(decision, "scope", Object.create(null));
      const derivation = get(decision, "derivation", Object.create(null));
      const objective = { ...get(scope, "objective_family", Object.create(null)) };
      objective.quantification = get(objective, "quantification", get(scope, "quantification", "EACH_OBJECTIVE"));
      if (get(scope, "observation_level") === "REALIZATION") objective.realization_sensitivity = true;
      const [needed] = requiredObjectFor(objective);
      if (get(derivation, "decision_class") !== get(scope, "observation_level")) {
        familyErrors.push(`decision ${identifier} scope/derivation decision classes disagree`);
      }
      if (get(derivation, "required_object") !== needed) {
        familyErrors.push(`decision ${identifier} derivation states ${get(derivation, "required_object")}; independent mapping requires ${needed}`);
      }
      decisionById.set(identifier, decision);
    }
  } catch (error) {
    familyErrors.push(error.message);
  }
  result.record(
    "future_decision_family_sound", familyErrors.length === 0,
    familyErrors.length ? familyErrors.join("; ") : `${decisionById.size} future decisions have sufficient objects`,
  );

  const registry = get(artifact, "registry", Object.create(null));
  let entries = new Map();
  let registryOk = false;
  let registryDetail = "registry unavailable";
  try {
    entries = parseRegistry(registry, limits);
    const bundle = get(registry, "bundle");
    const bindingFailures = registryBindingFailures(registry, entries, limits);
    registryOk = bindingFailures.length === 0
      && isObject(bundle) && contentHash(bundle) === get(registry, "bundle_hash")
      && contentHash(get(bundle, "schema")) === contentHash(get(registry, "schema"))
      && contentHash(get(bundle, "completeness")) === contentHash(get(registry, "completeness"));
    registryDetail = bindingFailures.length
      ? bindingFailures.join("; ")
      : `${entries.size} unique exact registry entries bound to the sealed bundle`;
  } catch (error) {
    registryDetail = error.message;
  }
  result.record("registry_reconstructed", registryOk, registryDetail);

  const declarations = get(artifact, "policies", []);
  const evaluations = get(artifact, "evaluations", []);
  const declarationById = new Map();
  const evaluationById = new Map();
  let structureOk = Array.isArray(declarations) && Array.isArray(evaluations);
  try {
    withinLimit(declarations.length, limits.maxPolicies, "policy count");
    withinLimit(evaluations.length, limits.maxPolicies, "evaluation count");
    for (const declaration of declarations) {
      const identifier = text(get(declaration, "policy_id"), "policy identity");
      if (declarationById.has(identifier)) structureOk = false;
      declarationById.set(identifier, declaration);
    }
    for (const evaluation of evaluations) {
      const identifier = text(get(evaluation, "policy_id"), "evaluation identity");
      if (evaluationById.has(identifier)) structureOk = false;
      evaluationById.set(identifier, evaluation);
    }
    structureOk = structureOk && declarationById.size > 0
      && setEqual(new Set(declarationById.keys()), new Set(evaluationById.keys()));
  } catch {
    structureOk = false;
  }
  result.record("policy_comparison_structure", structureOk, "policy declarations and evaluations have a one-to-one identity mapping");

  const policyFailures = [];
  let regretCount = 0; let boundCount = 0; let pruningCount = 0;
  if (entries.size > 0 && structureOk) {
    for (const identifier of [...declarationById.keys()].sort()) {
      const declaration = declarationById.get(identifier);
      const evaluation = evaluationById.get(identifier);
      const status = String(get(evaluation, "status", ""));
      const policy = String(get(declaration, "policy", ""));
      if (!["CERTIFIED", "CERTIFIED_BOUNDED", "REFUSED"].includes(status)) {
        policyFailures.push(`${identifier}: unknown evaluation status ${status}`);
      }
      if (get(evaluation, "family_id") !== get(family, "family_id")) {
        policyFailures.push(`${identifier}: evaluation is bound to a different family`);
      }
      if (get(evaluation, "policy") !== policy) {
        policyFailures.push(`${identifier}: evaluation policy differs from its declaration`);
      }
      let expected = new Set(entries.keys());
      let supported = false;
      try {
        expected = expectedRetained(entries, family, registry, declaration);
        supported = true;
      } catch (error) {
        if (status !== "REFUSED") policyFailures.push(`${identifier}: unsupported policy was not refused: ${error.message}`);
      }
      const stated = new Set(array(get(evaluation, "retained_ids", []), "retained_ids").map(String));
      const pruned = new Set(array(get(evaluation, "pruned_ids", []), "pruned_ids").map(String));
      const unknownRetained = [...stated].filter((value) => !entries.has(value));
      if (unknownRetained.length) {
        policyFailures.push(`${identifier}: retained set names absent identities ${unknownRetained.sort().join(", ")}`);
      }
      const knownStated = new Set([...stated].filter((value) => entries.has(value)));
      if (supported && !setEqual(stated, expected)) policyFailures.push(`${identifier}: retained set differs from independent reconstruction`);
      if (!supported && !setEqual(stated, new Set(entries.keys()))) {
        policyFailures.push(`${identifier}: unsupported policy did not conservatively retain the full family`);
      }
      const complement = new Set([...entries.keys()].filter((value) => !stated.has(value)));
      if (!setEqual(pruned, complement)) policyFailures.push(`${identifier}: pruned set is not the registry complement`);
      for (const failure of previewFailures(evaluation, entries, knownStated)) {
        policyFailures.push(`${identifier}/preview: ${failure}`);
      }
      if (get(declaration, "family_id") !== get(family, "family_id")) policyFailures.push(`${identifier}: policy is bound to a different family`);
      const refusals = get(evaluation, "refusals", []);
      if (status === "REFUSED" && (!Array.isArray(refusals) || refusals.length === 0)) policyFailures.push(`${identifier}: refusal has no stated reason`);
      if (["CERTIFIED", "CERTIFIED_BOUNDED"].includes(status) && Array.isArray(refusals) && refusals.length) {
        policyFailures.push(`${identifier}: certified policy carries unresolved refusals`);
      }
      const results = new Map();
      for (const item of array(get(evaluation, "decision_results", []), "decision results")) {
        const decisionId = text(get(item, "decision_id"), "decision result identity");
        if (results.has(decisionId)) {
          policyFailures.push(`${identifier}: duplicate decision result ${decisionId}`);
        }
        results.set(decisionId, item);
      }
      if (supported) {
        if (!setEqual(new Set(results.keys()), new Set(decisionById.keys()))) policyFailures.push(`${identifier}: decision result coverage is incomplete`);
        const states = new Set([...results.values()].map((item) => get(item, "status")));
        const expectedStatus = [...states].some((value) => ["BLOCKED_GEOMETRY_LOSS", "REFUSED"].includes(value))
          || (Array.isArray(refusals) && refusals.length)
          ? "REFUSED"
          : states.has("PRESERVED_WITH_BOUNDED_REGRET") ? "CERTIFIED_BOUNDED" : "CERTIFIED";
        if (status !== expectedStatus) policyFailures.push(`${identifier}: aggregate status does not match decision results (${expectedStatus})`);
        for (const [decisionId, decision] of decisionById) {
          const required = String(get(get(decision, "derivation", Object.create(null)), "required_object", ""));
          try {
            const [preserved, basis] = preservation(required, entries, knownStated, decision, registry);
            const claimed = get(results.get(decisionId), "status");
            if (required === "BOUNDED_REGRET_REPRESENTATION") {
              const facts = array(get(evaluation, "regret_bounds", []), "regret bounds")
                .filter((fact) => get(fact, "decision_id") === decisionId);
              const accepted = facts.length === 1 && Boolean(get(facts[0], "accepted"));
              if (claimed === "PRESERVED_WITH_BOUNDED_REGRET" && !accepted) {
                policyFailures.push(`${identifier}/${decisionId}: bounded preservation has no accepted fact`);
              }
              if (!["PRESERVED", "PRESERVED_WITH_BOUNDED_REGRET", "BLOCKED_GEOMETRY_LOSS", "REFUSED"].includes(claimed)) {
                policyFailures.push(`${identifier}/${decisionId}: unknown bounded-regret result ${claimed}`);
              }
            } else if (preserved && claimed !== "PRESERVED") {
              policyFailures.push(`${identifier}/${decisionId}: ${basis} is preserved but status is ${claimed}`);
            } else if (!preserved && claimed !== "BLOCKED_GEOMETRY_LOSS") {
              policyFailures.push(`${identifier}/${decisionId}: ${basis} is lost but status is ${claimed}`);
            }
          } catch (error) {
            policyFailures.push(`${identifier}/${decisionId}: ${error.message}`);
          }
        }
      }
      const seenWitnessDecisions = new Set();
      for (const witness of array(get(evaluation, "regret_evidence", []), "regret evidence")) {
        regretCount += 1;
        if (!isObject(witness)) {
          policyFailures.push(`${identifier}/regret: witness must be an object`);
          continue;
        }
        const decisionId = get(witness, "decision_id");
        if (seenWitnessDecisions.has(decisionId)) {
          policyFailures.push(`${identifier}/regret: duplicate witness for decision ${decisionId}`);
        }
        seenWitnessDecisions.add(decisionId);
        if (get(results.get(decisionId), "status") !== "BLOCKED_GEOMETRY_LOSS") {
          policyFailures.push(`${identifier}/regret: witness is not bound to a geometry-loss decision result`);
        }
        for (const failure of verifyRegret(witness, limits, {
          registry, entries, retainedIds: knownStated, decision: decisionById.get(decisionId),
        })) policyFailures.push(`${identifier}/regret: ${failure}`);
      }
      const seenBoundDecisions = new Set();
      for (const fact of array(get(evaluation, "regret_bounds", []), "regret bounds")) {
        boundCount += 1;
        if (!isObject(fact)) {
          policyFailures.push(`${identifier}/bound: fact must be an object`);
          continue;
        }
        const decisionId = get(fact, "decision_id");
        if (seenBoundDecisions.has(decisionId)) {
          policyFailures.push(`${identifier}/bound: duplicate bound for decision ${decisionId}`);
        }
        seenBoundDecisions.add(decisionId);
        if (get(results.get(decisionId), "status") !== "PRESERVED_WITH_BOUNDED_REGRET") {
          policyFailures.push(`${identifier}/bound: fact is not bound to a bounded-regret decision result`);
        }
        for (const failure of verifyBound(fact, limits, {
          registry, entries, retainedIds: knownStated, decision: decisionById.get(decisionId),
        })) policyFailures.push(`${identifier}/bound: ${failure}`);
      }
      const assessments = array(get(evaluation, "pruning_assessments", []), "pruning assessments");
      pruningCount += assessments.length;
      if (pruningCount > limits.maxPruningAssessments) {
        policyFailures.push(
          `${identifier}/pruning: pruning assessment count ${pruningCount} exceeds ` +
            `registered limit ${limits.maxPruningAssessments}`,
        );
        continue;
      }
      const assessmentPairs = new Set();
      for (const assessment of assessments) {
        if (!isObject(assessment)) {
          policyFailures.push(`${identifier}/pruning: assessment must be an object`);
          continue;
        }
        const candidateId = get(assessment, "candidate_id");
        const decisionId = get(assessment, "decision_id");
        const pair = `${candidateId}\u001f${decisionId}`;
        if (assessmentPairs.has(pair)) {
          policyFailures.push(`${identifier}/pruning: duplicate assessment ${candidateId}/${decisionId}`);
        }
        assessmentPairs.add(pair);
        if (!pruned.has(candidateId) || !decisionById.has(decisionId)) {
          policyFailures.push(`${identifier}/pruning: assessment is not bound to a pruned candidate/decision`);
        }
        for (const failure of verifyPruning(assessment)) policyFailures.push(`${identifier}/pruning: ${failure}`);
      }
      const expectedPairs = new Set();
      for (const candidateId of pruned) {
        for (const decisionId of decisionById.keys()) expectedPairs.add(`${candidateId}\u001f${decisionId}`);
      }
      if (!setEqual(assessmentPairs, expectedPairs)) {
        policyFailures.push(`${identifier}/pruning: assessments do not cover every pruned candidate/decision pair`);
      }
    }
  }

  result.record(
    "retention_policies_reconstructed", policyFailures.length === 0,
    policyFailures.length ? policyFailures.join("; ") : `${declarationById.size} policies independently reconstructed`,
  );
  result.record(
    "regret_evidence_reconstructed", !policyFailures.some((failure) => failure.includes("/regret:")),
    `${regretCount} full regret witnesses independently recomputed`,
  );
  result.record(
    "regret_bounds_reconstructed", !policyFailures.some((failure) => failure.includes("/bound:")),
    `${boundCount} typed regret bounds independently recomputed`,
  );
  result.record(
    "pruning_conditions_complete", !policyFailures.some((failure) => failure.includes("/pruning:")),
    `${pruningCount} pruning assessments expose all ten conditions`,
  );

  result.finish();
  if (get(artifact, "schema_version") !== SAFE_COMMITMENT_SCHEMA_VERSION || get(artifact, "profile") !== SAFE_COMMITMENT_PROFILE) {
    result.status = Status.UNSUPPORTED_PROFILE;
  } else if (result.ok) {
    const scope = deriveClaimScope(get(registry, "completeness", Object.create(null)));
    result.status = ["FULL_DECLARED_UNIVERSE", "GENERATOR_CLOSED_FAMILY"].includes(scope)
      ? Status.VERIFIED : Status.VERIFIED_RELATIVE;
  } else result.status = Status.FAILED;
  result.report.artifact_type = "SafeCommitmentArtifact";
  result.report.profile = get(artifact, "profile");
  result.report.level_attempted = Level.V3;
  result.report.level_achieved = result.ok ? Level.V3 : "NONE";
  result.report.policy_count = declarationById.size;
  result.report.regret_witness_count = regretCount;
  result.report.regret_bound_count = boundCount;
  result.report.pruning_assessment_count = pruningCount;
  result.report.resource_limits = limits;
  result.report.profile_coverage = {
    geometry: "FINITE_EXACT_R_GAMMA_AND_PLANAR_K",
    regret_witness: REGRET_PROFILE,
    regret_bound: BOUND_PROFILE,
    unsupported: ["NONPLANAR_K", "CONTINUOUS_OR_RANGED_REGRET_BOUND", "UNREGISTERED_RETENTION_POLICY"],
  };
  return result;
}
