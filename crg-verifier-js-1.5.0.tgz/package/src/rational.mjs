/**
 * Exact rational and closed-interval arithmetic on `BigInt`.
 *
 * Normative basis: 14.2 (numeric representations), 22.1-22.3 (enclosure,
 * evidence, tolerance, strict winner), 24.3 (required CRG-VIR operations).
 *
 * Not one value on the certificate-authorizing path is a JavaScript
 * `Number`.  `Number` is IEEE 754 binary64: it cannot hold 1/3, it cannot
 * hold 2**53 + 1, and a verifier that compared two objective values through
 * it would be asserting a conclusion its arithmetic does not support (22.6).
 * Every quantity below is a pair of arbitrary-precision integers, normalized
 * so the denominator is positive and gcd(n, d) = 1, which makes equality
 * structural and comparison total.
 *
 * An interval is a plain two-element array `[lo, hi]` of `Rational`.  Arrays
 * rather than a class, so every operation here is visibly total and free of
 * side effects.
 */

/** A value is not an admissible exact number or interval. */
export class ArithError extends Error {
  constructor(message) {
    super(message);
    this.name = "ArithError";
  }
}

function absBig(value) {
  return value < 0n ? -value : value;
}

function gcdBig(a, b) {
  let x = absBig(a);
  let y = absBig(b);
  while (y !== 0n) {
    const t = x % y;
    x = y;
    y = t;
  }
  return x;
}

/** An exact rational number: sign on the numerator, denominator > 0, reduced. */
export class Rational {
  constructor(numerator, denominator = 1n) {
    let n = BigInt(numerator);
    let d = BigInt(denominator);
    if (d === 0n) throw new ArithError("a rational with denominator zero is not a number");
    if (d < 0n) {
      n = -n;
      d = -d;
    }
    const g = gcdBig(n, d);
    if (g > 1n) {
      n /= g;
      d /= g;
    }
    if (n === 0n) d = 1n;
    this.n = n;
    this.d = d;
    Object.freeze(this);
  }

  add(other) {
    return new Rational(this.n * other.d + other.n * this.d, this.d * other.d);
  }

  sub(other) {
    return new Rational(this.n * other.d - other.n * this.d, this.d * other.d);
  }

  mul(other) {
    return new Rational(this.n * other.n, this.d * other.d);
  }

  div(other) {
    if (other.n === 0n) throw new ArithError("exact division by zero");
    return new Rational(this.n * other.d, this.d * other.n);
  }

  neg() {
    return new Rational(-this.n, this.d);
  }

  abs() {
    return this.n < 0n ? this.neg() : this;
  }

  /** -1, 0, or 1. Cross-multiplication is exact because both denominators are positive. */
  cmp(other) {
    const left = this.n * other.d;
    const right = other.n * this.d;
    if (left < right) return -1;
    if (left > right) return 1;
    return 0;
  }

  eq(other) { return this.n === other.n && this.d === other.d; }
  lt(other) { return this.cmp(other) < 0; }
  lte(other) { return this.cmp(other) <= 0; }
  gt(other) { return this.cmp(other) > 0; }
  gte(other) { return this.cmp(other) >= 0; }

  get isZero() { return this.n === 0n; }

  /** `n` for an integer, `n/d` otherwise -- the encoding the wire format uses. */
  toString() {
    return this.d === 1n ? this.n.toString(10) : `${this.n}/${this.d}`;
  }
}

export const ZERO = new Rational(0n);
export const ONE = new Rational(1n);

/** `n` or `n/d` (spec 14.2 rational string form). */
export function fmt(value) {
  return value.toString();
}

// ---------------------------------------------------------------------------
// decoding
// ---------------------------------------------------------------------------
const FRACTION_RE = /^([+-]?)(\d+)\s*\/\s*(\d+)$/;
const DECIMAL_RE = /^([+-]?)(\d*)(?:\.(\d*))?(?:[eE]([+-]?\d+))?$/;

function pow10(exponent) {
  return 10n ** BigInt(exponent);
}

/** Decode `n`, `n/d`, `1.25`, or `1.25e-3` exactly. */
export function parseRational(text) {
  const trimmed = String(text).trim();
  if (trimmed === "") throw new ArithError("the empty string is not an exact rational");

  const fraction = FRACTION_RE.exec(trimmed);
  if (fraction) {
    const [, sign, numerator, denominator] = fraction;
    if (BigInt(denominator) === 0n) {
      throw new ArithError(`${JSON.stringify(trimmed)} has a zero denominator`);
    }
    const n = BigInt(numerator) * (sign === "-" ? -1n : 1n);
    return new Rational(n, BigInt(denominator));
  }

  const decimal = DECIMAL_RE.exec(trimmed);
  if (!decimal) throw new ArithError(`${JSON.stringify(trimmed)} is not an exact rational`);
  const [, sign, whole = "", frac, exp] = decimal;
  const fractionDigits = frac ?? "";
  if (whole === "" && fractionDigits === "") {
    throw new ArithError(`${JSON.stringify(trimmed)} is not an exact rational`);
  }
  let numerator = BigInt((whole === "" ? "0" : whole) + fractionDigits);
  if (sign === "-") numerator = -numerator;
  let denominator = pow10(fractionDigits.length);
  if (exp !== undefined) {
    const e = Number.parseInt(exp, 10);
    if (!Number.isSafeInteger(e) || Math.abs(e) > 100000) {
      throw new ArithError(`exponent ${exp} is out of the admissible range`);
    }
    if (e >= 0) numerator *= pow10(e);
    else denominator *= pow10(-e);
  }
  return new Rational(numerator, denominator);
}

/**
 * Decode an exact rational from any canonical CRG numeric encoding.
 *
 * Accepted: `Rational`; `BigInt`; a decimal or `n/d` string; `{"exact": ...}`;
 * `{"value": ...}` alone; `{"numerator": n, "denominator": d}`.  A JS
 * `Number` and a boolean are both refused: neither can authorize a
 * comparison (spec 14.2, 22.6).
 */
export function rational(value) {
  if (value instanceof Rational) return value;
  if (typeof value === "boolean") throw new ArithError("a boolean is not an exact number");
  if (typeof value === "bigint") return new Rational(value);
  if (typeof value === "number") {
    throw new ArithError(
      "a JavaScript Number is binary floating point and cannot authorize a comparison " +
        "(spec 14.2, 22.6); carry the value as an integer or as an exact string",
    );
  }
  if (typeof value === "string") return parseRational(value);
  if (value !== null && typeof value === "object" && !Array.isArray(value)) {
    if (Object.prototype.hasOwnProperty.call(value, "exact")) return rational(value.exact);
    const keys = Object.keys(value);
    if (Object.prototype.hasOwnProperty.call(value, "value") && keys.length === 1) {
      return rational(value.value);
    }
    if (
      Object.prototype.hasOwnProperty.call(value, "numerator") &&
      Object.prototype.hasOwnProperty.call(value, "denominator")
    ) {
      return new Rational(asInteger(value.numerator), asInteger(value.denominator));
    }
  }
  throw new ArithError(`cannot read ${describe(value)} as an exact number`);
}

function asInteger(value) {
  if (typeof value === "bigint") return value;
  if (typeof value === "string") {
    const parsed = parseRational(value);
    if (parsed.d !== 1n) throw new ArithError(`${value} is not an integer`);
    return parsed.n;
  }
  throw new ArithError(`${describe(value)} is not an exact integer`);
}

function describe(value) {
  if (value === null) return "null";
  if (Array.isArray(value)) return "array";
  return typeof value;
}

/**
 * Decode a closed exact interval from any canonical encoding.
 *
 * A `DecisionValue` record (22.2) is accepted directly: its
 * `combined_interval` is the conservative merge the specification requires
 * at decision time, so that is the field read.
 */
export function interval(value) {
  let lo;
  let hi;
  if (value !== null && typeof value === "object" && !Array.isArray(value) && !(value instanceof Rational)) {
    for (const key of ["combined_interval", "interval"]) {
      if (Object.prototype.hasOwnProperty.call(value, key)) return interval(value[key]);
    }
    if (
      Object.prototype.hasOwnProperty.call(value, "lo") &&
      Object.prototype.hasOwnProperty.call(value, "hi")
    ) {
      lo = rational(value.lo);
      hi = rational(value.hi);
    } else if (Object.prototype.hasOwnProperty.call(value, "numerical_interval")) {
      return interval(value.numerical_interval);
    } else {
      lo = rational(value);
      hi = lo;
    }
  } else if (Array.isArray(value)) {
    if (value.length !== 2) {
      throw new ArithError("an interval given as a sequence MUST have exactly two bounds");
    }
    lo = rational(value[0]);
    hi = rational(value[1]);
  } else {
    lo = rational(value);
    hi = lo;
  }
  if (hi.lt(lo)) throw new ArithError(`inverted interval [${fmt(lo)}, ${fmt(hi)}]`);
  return [lo, hi];
}

// ---------------------------------------------------------------------------
// operations (spec 24.3)
// ---------------------------------------------------------------------------
export function iadd(a, b) {
  return [a[0].add(b[0]), a[1].add(b[1])];
}

export function isub(a, b) {
  return [a[0].sub(b[1]), a[1].sub(b[0])];
}

export function imul(a, b) {
  const products = [a[0].mul(b[0]), a[0].mul(b[1]), a[1].mul(b[0]), a[1].mul(b[1])];
  let lo = products[0];
  let hi = products[0];
  for (const p of products) {
    if (p.lt(lo)) lo = p;
    if (p.gt(hi)) hi = p;
  }
  return [lo, hi];
}

export function intervalEqual(a, b) {
  return a[0].eq(b[0]) && a[1].eq(b[1]);
}

/** Specification 22.3: `U_a + tau < L_b`.  Nothing weaker is a win. */
export function strictlyBelow(a, b, tau = ZERO) {
  return a[1].add(tau).lt(b[0]);
}

/** Every admissible difference between `a` and `b` lies inside tau. */
export function withinTolerance(a, b, tau) {
  return b[1].sub(a[0]).lte(tau) && a[1].sub(b[0]).lte(tau);
}

/** Weak dominance in the minimize convention: `x <= y` coordinatewise. */
export function weaklyDominates(x, y) {
  if (x.length !== y.length) throw new ArithError("dimension mismatch in dominance test");
  return x.every((a, i) => a.lte(y[i]));
}

/** Strict Pareto dominance: `<=` everywhere and `<` somewhere. */
export function dominates(x, y) {
  return weaklyDominates(x, y) && x.some((a, i) => a.lt(y[i]));
}

/**
 * `||(x - a)^+||_inf` -- the largest coordinatewise excess of x over a.
 *
 * Zero exactly when `x` weakly dominates `a`, which is the exact test for
 * `a` lying in the upper region generated by `x` (19.3).
 */
export function positivePartSup(x, a) {
  if (x.length !== a.length) throw new ArithError("dimension mismatch");
  let worst = ZERO;
  for (let i = 0; i < x.length; i += 1) {
    const excess = x[i].sub(a[i]);
    if (excess.gt(worst)) worst = excess;
  }
  return worst;
}

/** Exact minimum over a finite collection, or null when it is empty. */
export function minimum(values) {
  let best = null;
  for (const value of values) {
    if (best === null || value.lt(best)) best = value;
  }
  return best;
}

/** Exact sum over a finite collection. */
export function sum(values) {
  let total = ZERO;
  for (const value of values) total = total.add(value);
  return total;
}
