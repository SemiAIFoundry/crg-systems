/**
 * RFC 8785 (JCS) canonicalization, exact JSON decoding, and SHA-256 content
 * hashing -- the JavaScript side of the independent verifier.
 *
 * Normative basis: master specification 14.2 (numeric representations),
 * 14.3 (canonicalization), 14.4 (hashing); RFC 8785 sections 3.1, 3.2.1,
 * 3.2.2.2, 3.2.3, 3.2.4.
 *
 * Written from the RFC and from the observable wire format, not translated
 * from the Python canonicalizer.  Specification 25.5 asks the independent
 * implementation to *expose* a canonicalization disagreement; an
 * implementation that inherits the producer's serializer cannot.
 *
 * Two deliberate departures from a naive JSON round trip:
 *
 *   1. Integers are decoded as `BigInt`, never as `Number`.  A CRG content
 *      hash is only meaningful if the integer that went in is the integer
 *      that comes out, and `Number` silently truncates past 2**53 - 1.
 *   2. A JSON number carrying a fraction or an exponent is REFUSED at the
 *      decoding boundary and a JS float is REFUSED at the encoding
 *      boundary (14.2).  A binary float has no canonical decimal image, so
 *      admitting one would make a certificate's hash depend on the
 *      writer's formatting.
 */
import { createHash } from "node:crypto";

export const HASH_PREFIX = "sha256:";
const HASH_RE = /^sha256:[0-9a-f]{64}$/;

/** A value has no admissible canonical encoding, or the input is not I-JSON. */
export class CanonicalError extends TypeError {
  constructor(message) {
    super(message);
    this.name = "CanonicalError";
  }
}

// ---------------------------------------------------------------------------
// object model
// ---------------------------------------------------------------------------
// Decoded JSON objects are null-prototype objects.  Nothing decoded from an
// untrusted document may reach `Object.prototype`, so a document carrying a
// `__proto__` or `constructor` member is inert data here rather than a
// prototype-pollution vector.

/** A fresh, prototype-free map suitable for holding decoded JSON members. */
export function emptyObject() {
  return Object.create(null);
}

/** True for a decoded JSON object (not an array, not null). */
export function isObject(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

/** Own-property test that is safe on prototype-free objects. */
export function has(value, key) {
  return isObject(value) && Object.prototype.hasOwnProperty.call(value, key);
}

/** `value[key]` when present, otherwise `fallback` (Python `dict.get`). */
export function get(value, key, fallback = undefined) {
  return has(value, key) ? value[key] : fallback;
}

/** Own enumerable keys of a decoded JSON object. */
export function keysOf(value) {
  return isObject(value) ? Object.keys(value) : [];
}

// ---------------------------------------------------------------------------
// RFC 8785 3.2.3: ordering of object members
// ---------------------------------------------------------------------------
/**
 * Compare two property names as arrays of UTF-16 code units, treating each
 * code unit as an unsigned integer, with the shorter string preceding the
 * longer when one is a prefix of the other (RFC 8785 3.2.3).
 *
 * A JavaScript string already *is* an array of UTF-16 code units, so `<`
 * would give the same answer; the loop is written out because the rule is
 * the one place where UTF-8 and UTF-16 orderings disagree (a key beginning
 * with an astral-plane character sorts by its leading surrogate 0xD800..
 * 0xDBFF, hence *before* a key beginning with U+E000..U+FFFF, while the
 * UTF-8 byte ordering of the same two keys is the reverse), and a verifier
 * should not leave that resting on an operator's default behaviour.
 */
export function compareCodeUnits(a, b) {
  const n = Math.min(a.length, b.length);
  for (let i = 0; i < n; i += 1) {
    const x = a.charCodeAt(i);
    const y = b.charCodeAt(i);
    if (x !== y) return x < y ? -1 : 1;
  }
  if (a.length === b.length) return 0;
  return a.length < b.length ? -1 : 1;
}

// ---------------------------------------------------------------------------
// RFC 8785 3.2.2.2: serialization of strings
// ---------------------------------------------------------------------------
const SHORT_ESCAPE = {
  0x08: "\\b",
  0x09: "\\t",
  0x0a: "\\n",
  0x0c: "\\f",
  0x0d: "\\r",
};

function serializeString(text) {
  let out = '"';
  for (let i = 0; i < text.length; i += 1) {
    const code = text.charCodeAt(i);
    if (code === 0x22) {
      out += '\\"';
    } else if (code === 0x5c) {
      out += "\\\\";
    } else if (code < 0x20) {
      // Shortest escape first; everything else in the C0 range as \u00hh
      // in lowercase hexadecimal.
      out += SHORT_ESCAPE[code] ?? `\\u${code.toString(16).padStart(4, "0")}`;
    } else if (code >= 0xd800 && code <= 0xdbff) {
      const low = text.charCodeAt(i + 1);
      if (!(low >= 0xdc00 && low <= 0xdfff)) {
        throw new CanonicalError(
          `lone high surrogate U+${code.toString(16).toUpperCase()} in a JSON string; ` +
            "RFC 8785 3.2.2.2 requires a compliant implementation to terminate",
        );
      }
      out += text[i] + text[i + 1];
      i += 1;
    } else if (code >= 0xdc00 && code <= 0xdfff) {
      throw new CanonicalError(
        `lone low surrogate U+${code.toString(16).toUpperCase()} in a JSON string; ` +
          "RFC 8785 3.2.2.2 requires a compliant implementation to terminate",
      );
    } else {
      // Outside the ASCII control range and not " or \: emitted as is.
      out += text[i];
    }
  }
  return `${out}"`;
}

// ---------------------------------------------------------------------------
// encoding
// ---------------------------------------------------------------------------
function encode(value) {
  if (value === null) return "null";
  if (value === true) return "true";
  if (value === false) return "false";
  if (typeof value === "string") return serializeString(value);
  if (typeof value === "bigint") return value.toString(10);
  if (typeof value === "number") {
    // 14.2: no binary floating point in canonical CRG content.  A safe
    // integer supplied programmatically is admitted and written without an
    // exponent; anything else is refused rather than rounded.
    if (!Number.isSafeInteger(value)) {
      throw new CanonicalError(
        `binary floating point (${value}) is inadmissible in canonical CRG content ` +
          "(spec 14.2); supply an integer, a decimal string, or a rational string",
      );
    }
    return value.toString(10);
  }
  if (Array.isArray(value)) {
    return `[${value.map(encode).join(",")}]`;
  }
  if (value instanceof Map) {
    const members = [...value.keys()];
    for (const key of members) {
      if (typeof key !== "string") {
        throw new CanonicalError(`object keys MUST be strings, got ${typeof key}`);
      }
    }
    members.sort(compareCodeUnits);
    return `{${members
      .map((key) => `${serializeString(key)}:${encode(value.get(key))}`)
      .join(",")}}`;
  }
  if (isObject(value)) {
    const members = Object.keys(value);
    members.sort(compareCodeUnits);
    return `{${members.map((key) => `${serializeString(key)}:${encode(value[key])}`).join(",")}}`;
  }
  if (value === undefined) {
    throw new CanonicalError("undefined has no canonical JSON encoding");
  }
  throw new CanonicalError(`no canonical encoding for ${typeof value}`);
}

/** Canonical (RFC 8785) JSON text for `value`. */
export function canonicalJson(value) {
  return encode(value);
}

/** Canonical JSON encoded as UTF-8 (RFC 8785 3.2.4). */
export function canonicalBytes(value) {
  return Buffer.from(canonicalJson(value), "utf8");
}

/** `sha256:<hex>` over the canonical encoding of `value` (spec 14.4). */
export function contentHash(value) {
  return HASH_PREFIX + createHash("sha256").update(canonicalBytes(value)).digest("hex");
}

/**
 * Content hash of `mapping` with `excluded` members removed.
 *
 * A self-describing record cannot contain its own hash in its own hash
 * preimage; 14.3 requires the signature-excluded fields to be declared, and
 * this is the verifier's side of that rule.
 */
export function hashWithout(mapping, ...excluded) {
  if (!isObject(mapping)) {
    throw new CanonicalError("hashWithout expects a JSON object");
  }
  const drop = new Set(excluded);
  const kept = emptyObject();
  for (const key of Object.keys(mapping)) {
    if (!drop.has(key)) kept[key] = mapping[key];
  }
  return contentHash(kept);
}

/** True for an algorithm-tagged SHA-256 content hash (spec 14.4). */
export function isHash(value) {
  return typeof value === "string" && HASH_RE.test(value);
}

// ---------------------------------------------------------------------------
// decoding (RFC 8259 / I-JSON, with 14.2 numeric discipline)
// ---------------------------------------------------------------------------
const WHITESPACE = new Set([0x20, 0x09, 0x0a, 0x0d]);

class Reader {
  constructor(text) {
    this.text = text;
    this.i = 0;
  }

  fail(message) {
    throw new CanonicalError(`${message} at offset ${this.i}`);
  }

  skipWhitespace() {
    while (this.i < this.text.length && WHITESPACE.has(this.text.charCodeAt(this.i))) {
      this.i += 1;
    }
  }

  peek() {
    return this.i < this.text.length ? this.text[this.i] : "";
  }

  expect(character) {
    if (this.peek() !== character) this.fail(`expected ${JSON.stringify(character)}`);
    this.i += 1;
  }

  literal(word, value) {
    if (this.text.startsWith(word, this.i)) {
      this.i += word.length;
      return value;
    }
    return this.fail(`expected ${word}`);
  }

  value() {
    this.skipWhitespace();
    const c = this.peek();
    if (c === "") this.fail("unexpected end of input");
    if (c === "{") return this.object();
    if (c === "[") return this.array();
    if (c === '"') return this.string();
    if (c === "t") return this.literal("true", true);
    if (c === "f") return this.literal("false", false);
    if (c === "n") return this.literal("null", null);
    if (c === "-" || (c >= "0" && c <= "9")) return this.number();
    return this.fail(`unexpected character ${JSON.stringify(c)}`);
  }

  object() {
    this.expect("{");
    const out = emptyObject();
    this.skipWhitespace();
    if (this.peek() === "}") {
      this.i += 1;
      return out;
    }
    for (;;) {
      this.skipWhitespace();
      if (this.peek() !== '"') this.fail("object member name must be a string");
      const key = this.string();
      if (Object.prototype.hasOwnProperty.call(out, key)) {
        // RFC 8785 3.1: "JSON objects MUST NOT exhibit duplicate property
        // names."  Last-wins would make the content hash depend on the
        // parser, which is the whole thing canonicalization exists to stop.
        this.fail(`duplicate object member ${JSON.stringify(key)}`);
      }
      this.skipWhitespace();
      this.expect(":");
      out[key] = this.value();
      this.skipWhitespace();
      const c = this.peek();
      if (c === ",") {
        this.i += 1;
        continue;
      }
      if (c === "}") {
        this.i += 1;
        return out;
      }
      this.fail("expected ',' or '}'");
    }
  }

  array() {
    this.expect("[");
    const out = [];
    this.skipWhitespace();
    if (this.peek() === "]") {
      this.i += 1;
      return out;
    }
    for (;;) {
      out.push(this.value());
      this.skipWhitespace();
      const c = this.peek();
      if (c === ",") {
        this.i += 1;
        continue;
      }
      if (c === "]") {
        this.i += 1;
        return out;
      }
      this.fail("expected ',' or ']'");
    }
  }

  string() {
    this.expect('"');
    let out = "";
    for (;;) {
      if (this.i >= this.text.length) this.fail("unterminated string");
      const c = this.text[this.i];
      const code = this.text.charCodeAt(this.i);
      if (c === '"') {
        this.i += 1;
        return out;
      }
      if (code < 0x20) this.fail("unescaped control character in string");
      if (c !== "\\") {
        out += c;
        this.i += 1;
        continue;
      }
      this.i += 1;
      const esc = this.text[this.i];
      this.i += 1;
      switch (esc) {
        case '"': out += '"'; break;
        case "\\": out += "\\"; break;
        case "/": out += "/"; break;
        case "b": out += "\b"; break;
        case "f": out += "\f"; break;
        case "n": out += "\n"; break;
        case "r": out += "\r"; break;
        case "t": out += "\t"; break;
        case "u": {
          const hex = this.text.slice(this.i, this.i + 4);
          if (!/^[0-9a-fA-F]{4}$/.test(hex)) this.fail("malformed \\u escape");
          this.i += 4;
          out += String.fromCharCode(parseInt(hex, 16));
          break;
        }
        default:
          this.fail(`unknown escape \\${esc}`);
      }
    }
  }

  number() {
    const start = this.i;
    if (this.peek() === "-") this.i += 1;
    const digitsStart = this.i;
    while (this.i < this.text.length && this.text[this.i] >= "0" && this.text[this.i] <= "9") {
      this.i += 1;
    }
    if (this.i === digitsStart) this.fail("number has no integer part");
    const integerPart = this.text.slice(start, this.i);
    if (/^-?0\d/.test(integerPart)) this.fail("leading zero in number");
    const rest = this.text[this.i];
    if (rest === "." || rest === "e" || rest === "E") {
      // 14.2: exact numerics travel as integers or as strings.  A decoded
      // non-integer number would enter a comparison with an unbounded
      // rounding error attached, so it is refused here, not rounded.
      this.fail(
        "decoded a non-integer JSON number; CRG content MUST carry exact numerics " +
          "as integers, strings, or rational objects (spec 14.2)",
      );
    }
    return BigInt(integerPart);
  }
}

/**
 * Decode JSON text into the exact object model above: integers as `BigInt`,
 * objects as prototype-free maps, and non-integer numbers refused.
 */
export function decodeJson(text) {
  const reader = new Reader(text);
  const value = reader.value();
  reader.skipWhitespace();
  if (reader.i !== reader.text.length) reader.fail("trailing content after JSON value");
  return value;
}
