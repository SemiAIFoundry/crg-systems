/** Independent A1.1 ActionMappingProfile reconstruction and resolution. */
import { get, hashWithout, isHash, isObject } from "./canonical.mjs";
import { Status, VerificationResult } from "./result.mjs";

const TOP_FIELDS = [
  "record_type", "schema_version", "profile_id", "profile_version",
  "authority", "execution_authorized", "mappings", "unknown_action_result",
  "unsupported_action_result", "profile_hash",
];
const MAPPING_FIELDS = ["action_class", "scope", "subject", "target", "assessment", "host_policy"];
const SEMVER = /^(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)$/;
const ACTION = /^[A-Z][A-Z0-9_]*$/;
const IDENTIFIER = /^[a-z][a-z0-9._/@/-]*$/;
const PERMISSION = /^[a-z][a-z0-9_-]*:[a-z][a-z0-9_-]*$/;

const ASSESSMENT_RECORD_TYPES = new Set([
  "SafeCommitmentArtifact", "PhaseAnalysisRecord", "CertifiedDeltaRecord",
  "LifecycleAuthorization", "ContinuedValidityView", "DecisionChallengeRecord",
]);
const ROLES = new Set([
  "Viewer", "Contributor", "Registry Importer", "Generator Author",
  "Pack Publisher", "Evidence Steward", "Qualification Author",
  "Decision Approver", "Certificate Signer", "Federation Operator",
  "Security Administrator", "Auditor", "System Administrator",
]);
const PERMISSIONS = new Set([
  "case:read", "case:create", "case:update", "case:branch", "case:merge",
  "case:migrate", "case:validate", "registry:import", "generator:run",
  "generator:author", "geometry:build", "query:compile", "decision:evaluate",
  "decision:certify", "certificate:read", "certificate:sign",
  "certificate:revoke", "change:classify", "change:approve", "conversion:plan",
  "evidence:read", "evidence:register", "evidence:retire", "contract:assemble",
  "qualification:plan", "experiment:record", "pack:publish", "pack:install",
  "federation:issue_envelope", "federation:evaluate_private",
  "federation:revoke", "bundle:import", "bundle:export", "object:redact",
  "object:erase", "object:legal_hold", "retention:manage", "retention:enforce",
  "key:manage", "key:destroy", "tenant:manage", "identity:manage",
  "policy:manage", "audit:read", "audit:export", "job:manage",
  "system:configure", "lifecycle:publish", "lifecycle:read",
  "lifecycle:signature_verify", "lifecycle:approval_issue",
  "lifecycle:approval_withdraw", "lifecycle:authorization_evaluate",
  "lifecycle:validity_publish", "measurement:capture", "measurement:read",
  "measurement:export", "measurement:delete", "measurement:retention",
]);

class InvalidActionMapping extends TypeError {}

function exactObject(value, fields, label) {
  if (!isObject(value)) throw new InvalidActionMapping(`${label} must be an object`);
  const actual = Object.keys(value).sort();
  const expected = [...fields].sort();
  if (actual.length !== expected.length || actual.some((key, index) => key !== expected[index])) {
    throw new InvalidActionMapping(`${label} fields differ`);
  }
  return value;
}

function nonemptyText(value, label, pattern = null) {
  if (typeof value !== "string" || value.length === 0 || (pattern && !pattern.test(value))) {
    throw new InvalidActionMapping(`${label} is invalid`);
  }
  return value;
}

function sortedStrings(value, label, { nonempty = false } = {}) {
  if (!Array.isArray(value) || (nonempty && value.length === 0)
      || value.some((item) => typeof item !== "string" || item.length === 0)) {
    throw new InvalidActionMapping(`${label} must be a${nonempty ? " non-empty" : ""} string array`);
  }
  const expected = [...new Set(value)].sort();
  if (value.length !== expected.length || value.some((item, index) => item !== expected[index])) {
    throw new InvalidActionMapping(`${label} must be sorted and unique`);
  }
  return value;
}

function reconstruct(record, result) {
  exactObject(record, TOP_FIELDS, "profile");
  if (get(record, "record_type") !== "ActionMappingProfile" || get(record, "schema_version") !== "1.0.0") {
    throw new InvalidActionMapping("profile type/version differs");
  }
  nonemptyText(get(record, "profile_id"), "profile_id", IDENTIFIER);
  nonemptyText(get(record, "profile_version"), "profile_version", SEMVER);
  result.record(
    "authority_boundary",
    get(record, "authority") === "NON_AUTHORIZING" && get(record, "execution_authorized") === false,
    "profile is non-authorizing and cannot execute a host action",
  );
  if (get(record, "unknown_action_result") !== "REFUSED_UNKNOWN_ACTION"
      || get(record, "unsupported_action_result") !== "REFUSED_UNSUPPORTED_ACTION_CONTEXT") {
    throw new InvalidActionMapping("fail-closed action results differ");
  }
  if (!isHash(get(record, "profile_hash")) || get(record, "profile_hash") !== hashWithout(record, "profile_hash")) {
    throw new InvalidActionMapping("profile_hash differs from independent canonical reconstruction");
  }
  const mappings = get(record, "mappings");
  if (!Array.isArray(mappings) || mappings.length === 0) {
    throw new InvalidActionMapping("mappings must be a non-empty array");
  }
  const actions = [];
  mappings.forEach((raw, index) => {
    const label = `mappings[${index}]`;
    const mapping = exactObject(raw, MAPPING_FIELDS, label);
    const action = nonemptyText(get(mapping, "action_class"), `${label}.action_class`, ACTION);
    actions.push(action);
    const scope = exactObject(get(mapping, "scope"), ["domain", "resource_type"], `${label}.scope`);
    nonemptyText(get(scope, "domain"), `${label}.scope.domain`, IDENTIFIER);
    nonemptyText(get(scope, "resource_type"), `${label}.scope.resource_type`, IDENTIFIER);
    const subject = exactObject(
      get(mapping, "subject"), ["allowed_actor_kinds", "required_roles"], `${label}.subject`,
    );
    sortedStrings(get(subject, "allowed_actor_kinds"), `${label}.allowed_actor_kinds`, { nonempty: true });
    const roles = sortedStrings(get(subject, "required_roles"), `${label}.required_roles`);
    if (roles.some((role) => !ROLES.has(role))) throw new InvalidActionMapping(`${label}.required_roles names an unknown role`);
    const target = exactObject(
      get(mapping, "target"), ["case_id_required", "branch_id_required", "causal_parent_required"], `${label}.target`,
    );
    if (Object.values(target).some((flag) => typeof flag !== "boolean")) {
      throw new InvalidActionMapping(`${label}.target flags are invalid`);
    }
    const assessment = exactObject(
      get(mapping, "assessment"), ["record_type", "profile", "required_statuses", "required_evidence", "verifier"], `${label}.assessment`,
    );
    nonemptyText(get(assessment, "record_type"), `${label}.assessment.record_type`);
    nonemptyText(get(assessment, "profile"), `${label}.assessment.profile`, IDENTIFIER);
    if (!ASSESSMENT_RECORD_TYPES.has(get(assessment, "record_type"))) {
      throw new InvalidActionMapping(`${label}.assessment record type is unsupported`);
    }
    sortedStrings(get(assessment, "required_statuses"), `${label}.required_statuses`, { nonempty: true });
    sortedStrings(get(assessment, "required_evidence"), `${label}.required_evidence`, { nonempty: true });
    const verifier = exactObject(get(assessment, "verifier"), ["program", "profile"], `${label}.verifier`);
    nonemptyText(get(verifier, "program"), `${label}.verifier.program`, IDENTIFIER);
    nonemptyText(get(verifier, "profile"), `${label}.verifier.profile`, IDENTIFIER);
    const policy = exactObject(
      get(mapping, "host_policy"), ["policy_id", "policy_version", "permission"], `${label}.host_policy`,
    );
    nonemptyText(get(policy, "policy_id"), `${label}.host_policy.policy_id`, IDENTIFIER);
    nonemptyText(get(policy, "policy_version"), `${label}.host_policy.policy_version`, SEMVER);
    nonemptyText(get(policy, "permission"), `${label}.host_policy.permission`, PERMISSION);
    if (!PERMISSIONS.has(get(policy, "permission"))) throw new InvalidActionMapping(`${label}.host_policy permission is unknown`);
  });
  const expectedActions = [...new Set(actions)].sort();
  if (actions.length !== expectedActions.length || actions.some((action, index) => action !== expectedActions[index])) {
    throw new InvalidActionMapping("action mappings are not sorted and unique");
  }
  result.record("profile_shape", true, `${mappings.length} closed action mappings reconstructed`);
  result.record("profile_identity", true, "profile_hash matches independent canonical hashing");
  result.record("assessment_bindings", true, "every mapping binds assessment, evidence, and verifier identities");
  result.record("host_policy_bindings", true, "every mapping binds a versioned host-policy permission");
  return mappings;
}

export function verifyActionMappingProfile(value) {
  const result = new VerificationResult();
  try {
    const mappings = reconstruct(value, result);
    if (result.violations.length === 0) {
      result.status = "VERIFIED_NON_AUTHORIZING_MAPPING";
      result.report = {
        artifact_type: "ActionMappingProfile",
        mapping_count: mappings.length,
        profile_hash: get(value, "profile_hash"),
        execution_authorized: false,
      };
    } else result.status = Status.FAILED;
  } catch (error) {
    if (!(error instanceof InvalidActionMapping || error instanceof TypeError || error instanceof RangeError)) throw error;
    result.record("profile_decode", false, error.message);
    result.status = Status.FAILED;
  }
  return result.finish();
}

export function resolveActionRequirement(profile, context) {
  const verified = verifyActionMappingProfile(profile);
  if (!verified.ok) throw new InvalidActionMapping("cannot resolve an invalid action mapping profile");
  if (!isObject(context)) throw new InvalidActionMapping("action context must be an object");
  const actionClass = get(context, "action_class");
  const mapping = profile.mappings.find((item) => item.action_class === actionClass);
  const base = {
    action_class: actionClass,
    authority: "NON_AUTHORIZING",
    execution_authorized: false,
    profile_hash: profile.profile_hash,
  };
  if (!mapping) return { ...base, status: profile.unknown_action_result };
  const target = mapping.target;
  const supported = mapping.subject.allowed_actor_kinds.includes(get(context, "actor_kind"))
    && (!target.case_id_required || Boolean(get(context, "case_id")))
    && (!target.branch_id_required || Boolean(get(context, "branch_id")))
    && (!target.causal_parent_required || Boolean(get(context, "causal_parent_id")));
  if (!supported) return { ...base, status: profile.unsupported_action_result };
  return {
    ...base,
    assessment: mapping.assessment,
    host_policy: mapping.host_policy,
    mapping_hash: hashWithout({ ...mapping, _excluded: null }, "_excluded"),
    scope: mapping.scope,
    status: "ASSESSMENT_REQUIRED",
    subject: mapping.subject,
    target: {
      case_id: get(context, "case_id", null),
      branch_id: get(context, "branch_id", null),
      causal_parent_id: get(context, "causal_parent_id", null),
    },
  };
}
