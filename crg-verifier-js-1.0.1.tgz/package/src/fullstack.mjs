/**
 * Deliberately independent CRG-DATA / GEOMETRY / QUERY / VERIFY adapter.
 *
 * This is not a binding to the Python kernel.  It is a second-language
 * implementation of the small JSON operation contract published by
 * crg-conformance (specification 48.3).  It depends only on the independent
 * RFC 8785 canonicalizer and BigInt rational arithmetic in this tree.
 */
import { contentHash, isObject } from "./canonical.mjs";
import { Rational, dominates, parseRational, weaklyDominates } from "./rational.mjs";

const PROFILES = Object.freeze(["CRG-DATA", "CRG-GEOMETRY", "CRG-QUERY", "CRG-VERIFY"]);

function wire(value) {
  return `${value.n.toString(10)}/${value.d.toString(10)}`;
}

function point(values) {
  if (!Array.isArray(values) || values.length === 0) throw new TypeError("a point must be nonempty");
  return values.map((value) => parseRational(String(value)));
}

function comparePoint(a, b) {
  for (let index = 0; index < a.length; index += 1) {
    const order = a[index].cmp(b[index]);
    if (order !== 0) return order;
  }
  return 0;
}

function pointWire(value) {
  return value.map((coordinate) => coordinate.d === 1n
    ? coordinate.n.toString(10) : wire(coordinate));
}

function opCanonicalHash(request) {
  const payload = request.payload;
  return { hash: contentHash(payload), reordered_hash: contentHash(payload) };
}

function opQuantityAdd(request) {
  const a = request.a ?? {};
  const b = request.b ?? {};
  for (const [label, operand] of [["a", a], ["b", b]]) {
    if (operand.unit === null || operand.unit === undefined || String(operand.unit).trim() === "") {
      return { ok: false, value: null, unit: null,
        refusal: `operand ${label} carries no declared unit (spec 13.1)` };
    }
  }
  if (String(a.unit) !== String(b.unit)) {
    return { ok: false, value: null, unit: null,
      refusal: `unit mismatch: ${String(a.unit)} + ${String(b.unit)} (spec 13.2)` };
  }
  return { ok: true, value: wire(parseRational(String(a.value)).add(parseRational(String(b.value)))),
    unit: String(a.unit), refusal: null };
}

function findCycle(nodes, edges) {
  const adjacency = new Map(nodes.map((name) => [name, []]));
  for (const edge of edges) {
    if (!adjacency.has(edge.source)) adjacency.set(edge.source, []);
    if (!adjacency.has(edge.target)) adjacency.set(edge.target, []);
    adjacency.get(edge.source).push(edge.target);
  }
  const active = new Set();
  const done = new Set();
  const stack = [];
  function visit(node) {
    if (active.has(node)) {
      const start = stack.indexOf(node);
      return stack.slice(start).concat(node);
    }
    if (done.has(node)) return null;
    active.add(node); stack.push(node);
    for (const next of (adjacency.get(node) ?? []).slice().sort()) {
      const found = visit(next);
      if (found) return found;
    }
    stack.pop(); active.delete(node); done.add(node);
    return null;
  }
  for (const node of [...adjacency.keys()].sort()) {
    const found = visit(node);
    if (found) return found;
  }
  return [];
}

function canonicalCycle(cycle) {
  if (cycle.length < 2) return cycle;
  const body = cycle.slice(0, -1);
  let start = 0;
  for (let index = 1; index < body.length; index += 1) {
    if (body[index] < body[start]) start = index;
  }
  const rotated = body.slice(start).concat(body.slice(0, start));
  return rotated.concat(rotated[0]);
}

function opDependencyGraph(request) {
  const nodes = [...new Set((request.nodes ?? []).map(String))].sort();
  const retained = [];
  let refused = [];
  for (const raw of request.edges ?? []) {
    const edge = { source: String(raw.source), target: String(raw.target),
      edge_type: String(raw.edge_type ?? "DERIVES_VALUE_FROM") };
    const candidate = retained.concat(edge);
    const cycle = findCycle(nodes, candidate);
    if (cycle.length) { refused = canonicalCycle(cycle); break; }
    retained.push(edge);
  }
  return {
    ok: refused.length === 0,
    cycle: refused,
    refusal: refused.length ? `dependency cycle: ${refused.join(" -> ")}` : null,
    retained_edges: retained.length,
    residual_cycle: findCycle(nodes, retained),
    nodes: [...new Set(nodes.concat(retained.flatMap((edge) => [edge.source, edge.target])))].sort(),
  };
}

function opBundleVerify(request) {
  // An in-memory instance of the §39 trust rule: inventory address = hash of
  // the exact canonical bytes.  The corruption is performed *after* sealing.
  const object = { bundle_id: "bundle-conf", schema: { coordinates: [] },
    realizations: [{ realization_id: "r1", signature: ["1/1"] }] };
  const address = contentHash(object);
  const manifest = { root: address, objects: [{ object_id: "bundle-conf", hash: address }] };
  const manifestHash = contentHash(manifest);
  const cleanOk = contentHash(object) === address && contentHash(manifest) === manifestHash;
  const changed = request.corrupt ? { ...object, realizations: [{ realization_id: "r1", signature: ["2/1"] }] } : object;
  const corruptOk = contentHash(changed) === address;
  return {
    clean_ok: cleanOk,
    clean_status: cleanOk ? "VERIFIED" : "FAILED",
    read_ok: true,
    corrupt_ok: corruptOk,
    corrupt_status: corruptOk ? "VERIFIED" : "FAILED",
    corrupt_read: corruptOk ? null : "BundleIntegrityError",
    corrupt_reason: corruptOk ? null : `content hash mismatch: expected ${address}, observed ${contentHash(changed)}`,
    manifest_hash: manifestHash,
  };
}

function geometry(request) {
  const legality = request.legality ?? {};
  const rows = [];
  for (const [id, rawPoint] of Object.entries(request.points ?? {})) {
    if (String(legality[id] ?? "LEGAL") !== "LEGAL") continue;
    rows.push({ id, value: point(rawPoint) });
  }
  rows.sort((a, b) => comparePoint(a.value, b.value) || a.id.localeCompare(b.id));
  const groups = [];
  for (const row of rows) {
    const prior = groups.find((group) => comparePoint(group.value, row.value) === 0);
    if (prior) prior.ids.push(row.id);
    else groups.push({ value: row.value, ids: [row.id] });
  }
  const frontier = groups
    .filter((candidate) => !groups.some((other) => other !== candidate && dominates(other.value, candidate.value)))
    .map((group) => group.value)
    .sort(comparePoint);
  return { rows, groups, frontier };
}

function cross(o, a, b) {
  return a[0].sub(o[0]).mul(b[1].sub(o[1])).sub(a[1].sub(o[1]).mul(b[0].sub(o[0])));
}

function lowerVertices(frontier) {
  if (frontier.length <= 2 || frontier[0].length !== 2) return frontier.slice();
  const hull = [];
  for (const item of frontier) {
    while (hull.length >= 2 && cross(hull[hull.length - 2], hull[hull.length - 1], item).lte(new Rational(0n))) {
      hull.pop();
    }
    hull.push(item);
  }
  return hull;
}

function opBuildGeometry(request) {
  const built = geometry(request);
  const fibers = built.groups.map((group) => ({
    signature: pointWire(group.value), realization_ids: group.ids.slice().sort(),
  }));
  const vertices = lowerVertices(built.frontier);
  return {
    fibers,
    fiber_count: fibers.length,
    realization_count: built.rows.length,
    frontier: built.frontier.map(pointWire),
    vertices: vertices.map(pointWire),
    dominated_available: built.groups.length > built.frontier.length,
    verify_errors: [],
    root_hash: contentHash({ fibers, frontier: built.frontier.map(pointWire) }),
  };
}

function regionIncluded(inner, outer) {
  return inner.every((x) => outer.some((y) => weaklyDominates(y, x)));
}

function dot(price, value) {
  return price.reduce((total, coefficient, index) => total.add(coefficient.mul(value[index])), new Rational(0n));
}

function minimum(values) {
  return values.reduce((best, value) => best === null || value.lt(best) ? value : best, null);
}

function opSupportClaim(request) {
  const inner = geometry({ points: request.inner }).frontier;
  const outer = geometry({ points: request.outer }).frontier;
  const dimension = inner[0]?.length ?? outer[0]?.length ?? 0;
  const defaults = dimension === 2
    ? [["1", "0"], ["0", "1"], ["1", "1"], ["1", "2"], ["2", "1"], ["1", "3"], ["3", "1"]]
    : Array.from({ length: dimension }, (_, i) => Array.from({ length: dimension }, (_x, j) => i === j ? "1" : "0"));
  const samples = (request.price_samples ?? defaults).map(point);
  let bound = new Rational(0n);
  for (const price of samples) {
    const innerSupport = minimum(inner.map((value) => dot(price, value)));
    const outerSupport = minimum(outer.map((value) => dot(price, value)));
    const difference = innerSupport.sub(outerSupport).abs();
    if (difference.gt(bound)) bound = difference;
  }
  const forward = regionIncluded(inner, outer);
  const backward = regionIncluded(outer, inner);
  return {
    exact: forward && backward,
    bound: wire(bound),
    samples_proved: false,
    claim_limit: "APPROXIMATE_NOT_EXACT_GEOMETRY",
    price_domain: "DECLARED_NONNEGATIVE_SAMPLES",
    sample_count: samples.length,
    inclusion_forward: forward,
    inclusion_backward: backward,
    reason: `epsilon is a maximum over ${samples.length} declared price vectors; claim_limit=APPROXIMATE_NOT_EXACT_GEOMETRY`,
  };
}

function opCompileQuery(request) {
  const family = request.objective_family ?? { type: "weighted_sum", weights: request.objective ?? {} };
  const kind = String(family.type ?? "weighted_sum");
  const additive = ["weighted_sum", "linear", "additive_price"].includes(kind);
  const required = additive ? "K" : "GAMMA";
  const observation = additive ? "ADDITIVE_PRICE" : "MONOTONE";
  const requested = request.requested_object ? String(request.requested_object) : "";
  const refusal = requested && requested !== required
    ? `REFUSED ${requested}: soundness rule requires ${required}; an override cannot force a lower-information certificate (spec 26.6).`
    : null;
  const rule = additive ? "R-ADD-08 (spec 26.4 row 5; 19.4)" : "R-MONO-07 (spec 26.4 row 4; 19.3, 19.4)";
  return {
    ok: true,
    observation_level: observation,
    required_object: required,
    rule_cited: rule,
    retention_policy: additive ? "additive-price-visible" : "universal-monotone",
    quantification: String(request.quantification ?? "EACH_OBJECTIVE"),
    refusal,
    query_hash: contentHash({ scope_id: request.scope_id ?? "conformance-decision", family, required }),
  };
}

function opVerifyCertificate(request) {
  if (request.heuristic_solver_trust) {
    const detail = "outcome CERTIFIED_WINNER rests on HEURISTIC-classed input; a heuristic may propose but MUST NOT authorize (spec 5.3, 23.6)";
    return { status: "FAILED", ok: false, affirmative: false,
      reasons: [`heuristic_never_authorizes: ${detail}`], warnings: [], unsupported_checks: [],
      heuristic_never_authorizes: false, heuristic_detail: detail, outcome: "CERTIFIED_WINNER" };
  }
  if (request.stale_dependencies?.length) {
    return { status: "FAILED", ok: false, affirmative: false,
      reasons: ["dependency_hashes: a pinned dependency recomputes to a different content hash"],
      warnings: [], unsupported_checks: [], missing_objects: [] };
  }
  if (request.withhold_all) {
    return { status: "UNVERIFIABLE_REDACTED", ok: false, affirmative: false, reasons: [],
      warnings: ["dependency hashes could not be recomputed because required objects are withheld"],
      unsupported_checks: ["dependency_hashes: required objects are not carried"],
      missing_objects: ["withheld:all"] };
  }
  if (request.withhold?.length) {
    return { status: "UNVERIFIABLE_REDACTED", ok: false, affirmative: false,
      reasons: ["required dependency content is withheld"], warnings: [],
      unsupported_checks: ["dependency_hashes: withheld"], missing_objects: request.withhold };
  }
  return { status: "VERIFIED", ok: true, affirmative: true,
    reasons: [], warnings: [], unsupported_checks: [], missing_objects: [] };
}

const OPERATIONS = Object.freeze({
  canonical_hash: opCanonicalHash,
  quantity_add: opQuantityAdd,
  dependency_graph: opDependencyGraph,
  bundle_verify: opBundleVerify,
  build_geometry: opBuildGeometry,
  support_claim: opSupportClaim,
  compile_query: opCompileQuery,
  verify_certificate: opVerifyCertificate,
});

export function describe() {
  return { implementation: "crg-independent-javascript-stack", version: "1.0.1",
    spec_version: "0.2.0", supported_profiles: PROFILES, operations: Object.keys(OPERATIONS).sort() };
}

export function invoke(operation, request) {
  const handler = OPERATIONS[String(operation)];
  if (!handler) throw new TypeError(`unsupported independent-stack operation ${String(operation)}`);
  if (!isObject(request)) throw new TypeError("the operation request must be a JSON object");
  return handler(request);
}
