# CRG Verifier for Node.js

`crg-verifier-js` independently verifies CRG bundles, certificates, canonical
JSON, exact rational arithmetic, and CRG-VIR programs. It uses only Node.js
built-ins and does not contact a network service.

Requires Node.js 22 or newer.

```sh
npm install --global ./crg-verifier-js-1.0.1.tgz
crg-verify-js --help
crg-bundle-verify-js /path/to/case.crg
```

Research and noncommercial use are permitted with the attribution required by
`LICENSE.md`. A separate written license from Semi AI Foundry, LLC is required
only for commercial use; see `COMMERCIAL_LICENSE.md`.
