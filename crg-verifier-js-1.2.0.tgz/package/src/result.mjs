/**
 * The verification result, the status vocabulary, and the level ladder.
 *
 * Normative basis: 25.2 (verification levels), 25.3 (verification report),
 * 25.4 (final verification statuses), 45.4 (time statuses).
 *
 * `ok` is false whenever anything failed.  A check that could not be
 * *attempted* is recorded through `unsupported`, which is never silently a
 * pass: it lands in the report's unsupported list and raises a warning, so a
 * reader can tell "checked and held" from "not checked" (6.11, 25.3).
 * v1.2 record verifiers reuse this closed result vocabulary so an additive
 * artifact cannot invent a weaker success status.
 */

/** Final verification statuses (spec 25.4). */
export const Status = Object.freeze({
  VERIFIED: "VERIFIED",
  VERIFIED_RELATIVE: "VERIFIED_RELATIVE",
  VERIFIED_WITH_BOUNDED_REMAINDER: "VERIFIED_WITH_BOUNDED_REMAINDER",
  INTEGRITY_ONLY: "INTEGRITY_ONLY",
  REPLAY_BOUND: "REPLAY_BOUND",
  PARTIALLY_VERIFIED: "PARTIALLY_VERIFIED",
  FAILED: "FAILED",
  EXPIRED: "EXPIRED",
  REVOKED: "REVOKED",
  TIME_INDETERMINATE: "TIME_INDETERMINATE",
  UNVERIFIABLE_REDACTED: "UNVERIFIABLE_REDACTED",
  UNSUPPORTED_PROFILE: "UNSUPPORTED_PROFILE",
});

/** Time statuses (spec 45.4). */
export const TimeStatus = Object.freeze({
  CURRENT: "CURRENT",
  NOT_YET_VALID: "NOT_YET_VALID",
  STALE: "STALE",
  EXPIRED: "EXPIRED",
  TIME_INDETERMINATE: "TIME_INDETERMINATE",
  CLOCK_POLICY_VIOLATION: "CLOCK_POLICY_VIOLATION",
});

/** Verification levels (spec 25.2). */
export const Level = Object.freeze({
  V0: "V0",
  V1: "V1",
  V2: "V2",
  V3: "V3",
  V4: "V4",
  ORDER: ["V0", "V1", "V2", "V3", "V4"],
});

export class VerificationResult {
  constructor() {
    this.ok = false;
    /** @type {Array<{name: string, passed: boolean, detail: string}>} */
    this.checks = [];
    this.violations = [];
    this.warnings = [];
    this.status = Status.FAILED;
    this.report = {};
  }

  record(name, passed, detail) {
    const value = Boolean(passed);
    this.checks.push({ name, passed: value, detail });
    if (!value) this.violations.push(`${name}: ${detail}`);
    return value;
  }

  /** A check that holds vacuously; recorded so the report stays total. */
  note(name, detail) {
    this.checks.push({ name, passed: true, detail });
  }

  warn(message) {
    this.warnings.push(message);
  }

  /** A check that could not be attempted.  Never silently a pass. */
  unsupported(name, detail) {
    // Unsupported is not a disproved assertion, so it is kept out of the
    // violations list.  It is nevertheless not a passed check: withholding
    // an input must never manufacture a successful verification level.
    this.checks.push({ name, passed: false, detail: `UNSUPPORTED: ${detail}` });
    if (!this.report.unsupported_checks) this.report.unsupported_checks = [];
    this.report.unsupported_checks.push(`${name}: ${detail}`);
    this.warn(`${name} could not be attempted: ${detail}`);
  }

  finish() {
    const unsupported = Array.isArray(this.report.unsupported_checks)
      ? this.report.unsupported_checks
      : [];
    this.ok = this.violations.length === 0 && unsupported.length === 0;
    const unsupportedNames = new Set(
      unsupported.filter((item) => typeof item === "string").map((item) => item.split(":", 1)[0]),
    );
    // Bundle verification calls finish cumulatively; always refresh these
    // views instead of freezing the first level's values.
    this.report.checks_passed = this.checks.filter((c) => c.passed).map((c) => c.name);
    this.report.checks_failed = this.checks
      .filter((c) => !c.passed && !unsupportedNames.has(c.name))
      .map((c) => c.name);
    this.report.checks_unsupported = this.checks
      .filter((c) => !c.passed && unsupportedNames.has(c.name))
      .map((c) => c.name);
    return this;
  }

  toJSON() {
    return {
      ok: this.ok,
      status: this.status,
      checks: this.checks.map((c) => ({ check: c.name, passed: c.passed, detail: c.detail })),
      violations: [...this.violations],
      warnings: [...this.warnings],
      report: this.report,
    };
  }
}
