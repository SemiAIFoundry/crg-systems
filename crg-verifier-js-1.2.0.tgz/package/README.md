# CRG Verifier for Node.js

`crg-verifier-js` independently verifies CRG bundles, certificates, canonical
JSON, exact rational arithmetic, and CRG-VIR programs. It uses only Node.js
built-ins and does not contact a network service.

The v1.2 bundle path also recognizes the additive certified-phase,
certified-delta, comparative-change, and Decision Challenge records and keeps
their non-authorizing and independent-replay boundaries explicit. The package
identity remains `1.1.0` until the dedicated release-finalization commit.

Requires Node.js 22 or newer.

```sh
npm install --global ./crg-verifier-js-1.2.0.tgz
crg-verify-js --help
crg-bundle-verify-js /path/to/case.crg
```

Safe-commitment artifacts using the registered finite/exact v1.1 profile can
be verified directly from a file or standard input:

```sh
node bin/crg-safe-commitment-verify-js.mjs /path/to/safe-commitment.json
cat /path/to/safe-commitment.json | node bin/crg-safe-commitment-verify-js.mjs -
```

This path independently reconstructs registered retention sets, finite exact
R and Gamma preservation, planar K preservation, finite-ledger hitting sets,
constructive regret witnesses, and fixed-additive exact regret bounds. It
reports verification level `V3` only when every proof-bearing claim is
reconstructed. Non-planar K, ranged or continuous regret-bound semantics, and
unregistered retention policies are refused under this profile.

Research and noncommercial use are permitted with the attribution required by
`LICENSE.md`. A separate written license from Semi AI Foundry, LLC is required
only for commercial use; see `COMMERCIAL_LICENSE.md`.
