"""Deployment-owned trust controls for the CRG decision lifecycle.

This module is the authority boundary which the portable lifecycle records do
not (and cannot) provide for themselves.  A request may carry a signature and
may select an already-registered action, but it cannot nominate the public
keys, subjects, approval roles, separation-of-duties policy, or clock policy
used to judge it.

The canonical context contains public verification material only.  Private
keys and credentials are deliberately not representable here.
"""
from __future__ import annotations

from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from crg_model.canonical import canonical_bytes, content_hash

from .profile import PRODUCTION_CRYPTO_AVAILABLE

__all__ = [
    "LIFECYCLE_TRUST_PROFILE",
    "LIFECYCLE_TRUST_SCHEMA_VERSION",
    "LIFECYCLE_AUTHORITY_PROFILE",
    "LIFECYCLE_OPERATION_PERMISSIONS",
    "LifecycleTrustError",
    "validate_lifecycle_trust_context",
    "lifecycle_trust_context_root",
    "build_lifecycle_authority_snapshot",
    "validate_lifecycle_authority_snapshot",
    "lifecycle_operation_permission",
    "lifecycle_operation_permitted",
    "selected_lifecycle_policy",
    "verify_lifecycle_signature",
]

LIFECYCLE_TRUST_PROFILE = "crg.lifecycle-trust-context"
LIFECYCLE_TRUST_SCHEMA_VERSION = "1.0.0"
LIFECYCLE_AUTHORITY_PROFILE = "crg.lifecycle-authority-snapshot"

# Operations not named here retain the existing, non-authorizing
# ``lifecycle:publish`` permission.  These five operations can create or
# consume an authority fact and therefore have deliberately narrower verbs.
LIFECYCLE_OPERATION_PERMISSIONS = {
    "RECORD_SIGNATURE_VERIFICATION": "lifecycle:signature_verify",
    "ISSUE_APPROVAL": "lifecycle:approval_issue",
    "ISSUE_APPROVAL_WITHDRAWAL": "lifecycle:approval_withdraw",
    "EVALUATE_LIFECYCLE_AUTHORIZATION": "lifecycle:authorization_evaluate",
    "BUILD_CONTINUED_VALIDITY": "lifecycle:validity_publish",
}

_CLOCK_TRUST = {
    "NONE_SUPPLIED": 0,
    "LOCAL_DECLARED": 1,
    "SYNCHRONIZED": 2,
    "ATTESTED": 3,
}


class LifecycleTrustError(ValueError):
    """Deployment lifecycle trust configuration is absent or inconsistent."""


def _mapping(value: Any, where: str) -> Dict[str, Any]:
    if hasattr(value, "to_canonical"):
        value = value.to_canonical()
    if not isinstance(value, Mapping):
        raise LifecycleTrustError(f"{where} must be a JSON object")
    return dict(value)


def _closed(
    value: Any, where: str, required: Sequence[str], optional: Sequence[str] = ()
) -> Dict[str, Any]:
    item = _mapping(value, where)
    required_set = set(required)
    allowed = required_set | set(optional)
    missing = required_set - set(item)
    unknown = set(item) - allowed
    if missing:
        raise LifecycleTrustError(f"{where} omits {sorted(missing)}")
    if unknown:
        raise LifecycleTrustError(f"{where} has unsupported fields {sorted(unknown)}")
    return item


def _text(value: Any, where: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise LifecycleTrustError(f"{where} must be a non-empty string")
    return value


def _string_list(value: Any, where: str, *, nonempty: bool = False) -> Tuple[str, ...]:
    if not isinstance(value, (list, tuple)):
        raise LifecycleTrustError(f"{where} must be an array")
    result = tuple(_text(item, f"{where}[]") for item in value)
    if nonempty and not result:
        raise LifecycleTrustError(f"{where} must not be empty")
    if len(set(result)) != len(result):
        raise LifecycleTrustError(f"{where} contains duplicates")
    return tuple(sorted(result))


def _policy(value: Any, where: str) -> Dict[str, Any]:
    item = _closed(
        value,
        where,
        (
            "policy_id",
            "required_roles",
            "incompatible_role_pairs",
            "distinct_subjects_for_required_roles",
            "authority",
            "actions",
        ),
    )
    roles = _string_list(item["required_roles"], f"{where}.required_roles", nonempty=True)
    actions = _string_list(item["actions"], f"{where}.actions", nonempty=True)
    pairs = []
    if not isinstance(item["incompatible_role_pairs"], (list, tuple)):
        raise LifecycleTrustError(f"{where}.incompatible_role_pairs must be an array")
    for index, raw in enumerate(item["incompatible_role_pairs"]):
        if not isinstance(raw, (list, tuple)) or len(raw) != 2:
            raise LifecycleTrustError(
                f"{where}.incompatible_role_pairs[{index}] must name exactly two roles"
            )
        pair = tuple(sorted((_text(raw[0], where), _text(raw[1], where))))
        if pair[0] == pair[1]:
            raise LifecycleTrustError(f"{where} contains a self-incompatible role")
        pairs.append(pair)
    if len(set(pairs)) != len(pairs):
        raise LifecycleTrustError(f"{where} contains duplicate incompatible role pairs")
    if not isinstance(item["distinct_subjects_for_required_roles"], bool):
        raise LifecycleTrustError(
            f"{where}.distinct_subjects_for_required_roles must be boolean"
        )
    return {
        "policy_id": _text(item["policy_id"], f"{where}.policy_id"),
        "required_roles": list(roles),
        "incompatible_role_pairs": [list(pair) for pair in sorted(pairs)],
        "distinct_subjects_for_required_roles": item[
            "distinct_subjects_for_required_roles"
        ],
        "authority": _text(item["authority"], f"{where}.authority"),
        "actions": list(actions),
    }


def validate_lifecycle_trust_context(value: Any) -> Dict[str, Any]:
    """Return the canonical closed deployment trust context.

    Only production Ed25519 public keys are admitted.  The optional crypto
    provider may be unavailable at configuration time, but use of such a key
    will then fail closed during verification.
    """

    item = _closed(
        value,
        "lifecycle trust context",
        (
            "profile",
            "schema_version",
            "context_id",
            "context_version",
            "organization",
            "trusted_keys",
            "subjects",
            "policies",
            "clock_policy",
        ),
    )
    if item["profile"] != LIFECYCLE_TRUST_PROFILE:
        raise LifecycleTrustError(f"unsupported lifecycle trust profile {item['profile']!r}")
    if item["schema_version"] != LIFECYCLE_TRUST_SCHEMA_VERSION:
        raise LifecycleTrustError(
            f"unsupported lifecycle trust schema {item['schema_version']!r}"
        )
    organization = _text(item["organization"], "lifecycle trust organization")

    keys_raw = _mapping(item["trusted_keys"], "lifecycle trusted_keys")
    keys: Dict[str, Dict[str, Any]] = {}
    for key_id, raw in sorted(keys_raw.items()):
        key_id = _text(key_id, "lifecycle key id")
        key = _closed(
            raw,
            f"lifecycle trusted_keys[{key_id!r}]",
            (
                "profile",
                "algorithm",
                "public_key",
                "subject_id",
                "organization",
                "revoked",
            ),
        )
        if key["profile"] != "Ed25519" or key["algorithm"] != "ed25519":
            raise LifecycleTrustError(
                f"lifecycle key {key_id!r} is not the production Ed25519 profile"
            )
        public = _text(key["public_key"], f"lifecycle key {key_id!r} public_key")
        if public.startswith("ed25519-pub:"):
            public = public.split(":", 1)[1]
        try:
            public_bytes = bytes.fromhex(public)
        except ValueError as error:
            raise LifecycleTrustError(
                f"lifecycle key {key_id!r} is not hexadecimal"
            ) from error
        if len(public_bytes) != 32:
            raise LifecycleTrustError(f"lifecycle key {key_id!r} is not a 32-byte Ed25519 key")
        if not isinstance(key["revoked"], bool):
            raise LifecycleTrustError(f"lifecycle key {key_id!r} revoked must be boolean")
        key_org = _text(key["organization"], f"lifecycle key {key_id!r} organization")
        if key_org != organization:
            raise LifecycleTrustError(
                f"lifecycle key {key_id!r} belongs to a different organization"
            )
        keys[key_id] = {
            "profile": "Ed25519",
            "algorithm": "ed25519",
            "public_key": public,
            "subject_id": _text(key["subject_id"], f"lifecycle key {key_id!r} subject_id"),
            "organization": key_org,
            "revoked": key["revoked"],
        }
    if not keys:
        raise LifecycleTrustError("lifecycle trust context has no public verification keys")

    subjects_raw = _mapping(item["subjects"], "lifecycle subjects")
    subjects: Dict[str, Dict[str, Any]] = {}
    for subject_id, raw in sorted(subjects_raw.items()):
        subject_id = _text(subject_id, "lifecycle subject id")
        subject = _closed(
            raw,
            f"lifecycle subjects[{subject_id!r}]",
            ("organization", "approval_roles", "key_ids"),
        )
        subject_org = _text(subject["organization"], f"subject {subject_id!r} organization")
        if subject_org != organization:
            raise LifecycleTrustError(
                f"lifecycle subject {subject_id!r} belongs to a different organization"
            )
        approval_roles = _string_list(
            subject["approval_roles"], f"subject {subject_id!r} approval_roles", nonempty=True
        )
        key_ids = _string_list(subject["key_ids"], f"subject {subject_id!r} key_ids", nonempty=True)
        for key_id in key_ids:
            if key_id not in keys:
                raise LifecycleTrustError(
                    f"lifecycle subject {subject_id!r} names unknown key {key_id!r}"
                )
            if keys[key_id]["subject_id"] != subject_id:
                raise LifecycleTrustError(
                    f"lifecycle key {key_id!r} is bound to another subject"
                )
        subjects[subject_id] = {
            "organization": subject_org,
            "approval_roles": list(approval_roles),
            "key_ids": list(key_ids),
        }
    if not subjects:
        raise LifecycleTrustError("lifecycle trust context has no registered subjects")
    for key_id, key in keys.items():
        if key["subject_id"] not in subjects:
            raise LifecycleTrustError(
                f"lifecycle key {key_id!r} names unregistered subject {key['subject_id']!r}"
            )
        if key_id not in subjects[key["subject_id"]]["key_ids"]:
            raise LifecycleTrustError(
                f"lifecycle key {key_id!r} is not declared by its registered subject"
            )

    policies_raw = _mapping(item["policies"], "lifecycle policies")
    policies: Dict[str, Dict[str, Any]] = {}
    action_owner: Dict[str, str] = {}
    for policy_id, raw in sorted(policies_raw.items()):
        policy = _policy(raw, f"lifecycle policies[{policy_id!r}]")
        if policy["policy_id"] != policy_id:
            raise LifecycleTrustError(
                f"lifecycle policy map key {policy_id!r} disagrees with its policy_id"
            )
        known_roles = {role for subject in subjects.values() for role in subject["approval_roles"]}
        unknown_roles = set(policy["required_roles"]) - known_roles
        pair_roles = {
            role
            for pair in policy["incompatible_role_pairs"]
            for role in pair
        }
        unknown_roles.update(pair_roles - known_roles)
        if unknown_roles:
            raise LifecycleTrustError(
                f"lifecycle policy {policy_id!r} requires unassignable roles {sorted(unknown_roles)}"
            )
        for action in policy["actions"]:
            if action in action_owner:
                raise LifecycleTrustError(
                    f"lifecycle action {action!r} is assigned to multiple policies"
                )
            action_owner[action] = policy_id
        policies[policy_id] = policy
    if not policies:
        raise LifecycleTrustError("lifecycle trust context has no authorization policy")

    clock = _closed(
        item["clock_policy"],
        "lifecycle clock_policy",
        ("policy_id", "allowed_sources", "minimum_trust", "authority"),
    )
    minimum = _text(clock["minimum_trust"], "lifecycle clock minimum_trust")
    if minimum not in _CLOCK_TRUST or minimum == "NONE_SUPPLIED":
        raise LifecycleTrustError("lifecycle clock policy requires a usable trust level")
    clock_policy = {
        "policy_id": _text(clock["policy_id"], "lifecycle clock policy_id"),
        "allowed_sources": list(
            _string_list(clock["allowed_sources"], "lifecycle allowed clock sources", nonempty=True)
        ),
        "minimum_trust": minimum,
        "authority": _text(clock["authority"], "lifecycle clock authority"),
    }

    return {
        "profile": LIFECYCLE_TRUST_PROFILE,
        "schema_version": LIFECYCLE_TRUST_SCHEMA_VERSION,
        "context_id": _text(item["context_id"], "lifecycle context_id"),
        "context_version": _text(item["context_version"], "lifecycle context_version"),
        "organization": organization,
        "trusted_keys": keys,
        "subjects": subjects,
        "policies": policies,
        "clock_policy": clock_policy,
    }


def lifecycle_trust_context_root(value: Any) -> str:
    return content_hash(validate_lifecycle_trust_context(value))


def _principal(value: Any) -> Dict[str, Any]:
    item = _mapping(value, "authenticated lifecycle principal")
    subject_id = _text(item.get("subject_id"), "authenticated principal subject_id")
    tenant_id = _text(item.get("tenant_id"), "authenticated principal tenant_id")
    roles = _string_list(item.get("roles") or (), "authenticated principal roles", nonempty=True)
    attributes = item.get("attributes") or {}
    if not isinstance(attributes, Mapping):
        raise LifecycleTrustError("authenticated principal attributes must be an object")
    organization = _text(
        attributes.get("organization") or item.get("organization"),
        "authenticated principal organization",
    )
    return {
        "subject_id": subject_id,
        "tenant_id": tenant_id,
        "roles": list(roles),
        "organization": organization,
        "authentication_method": _text(
            item.get("authentication_method") or "unspecified",
            "authenticated principal method",
        ),
    }


def _clock(value: Any, policy: Mapping[str, Any]) -> Dict[str, Any]:
    item = _closed(
        value,
        "deployment lifecycle clock",
        (
            "verifier_evaluation_time",
            "verifier_clock_source",
            "verifier_clock_trust_level",
        ),
    )
    from datetime import datetime

    instant = _text(item["verifier_evaluation_time"], "lifecycle clock time")
    try:
        datetime.fromisoformat(instant.replace("Z", "+00:00"))
    except ValueError as error:
        raise LifecycleTrustError("deployment lifecycle clock is not ISO-8601") from error
    source = _text(item["verifier_clock_source"], "lifecycle clock source")
    trust = _text(item["verifier_clock_trust_level"], "lifecycle clock trust")
    if source not in set(policy["allowed_sources"]):
        raise LifecycleTrustError(f"clock source {source!r} is not deployment-approved")
    if trust not in _CLOCK_TRUST or _CLOCK_TRUST[trust] < _CLOCK_TRUST[policy["minimum_trust"]]:
        raise LifecycleTrustError(
            f"clock trust {trust!r} is below deployment policy {policy['minimum_trust']!r}"
        )
    return {
        "verifier_evaluation_time": instant,
        "verifier_clock_source": source,
        "verifier_clock_trust_level": trust,
    }


def build_lifecycle_authority_snapshot(
    trust_context: Any, principal: Any, clock: Any
) -> Dict[str, Any]:
    """Bind one authenticated request to immutable deployment authority state."""

    context = validate_lifecycle_trust_context(trust_context)
    principal_doc = _principal(principal)
    subject = context["subjects"].get(principal_doc["subject_id"])
    if subject is None:
        raise LifecycleTrustError(
            f"authenticated subject {principal_doc['subject_id']!r} is not registered for lifecycle authority"
        )
    if principal_doc["organization"] != subject["organization"]:
        raise LifecycleTrustError("authenticated organization disagrees with deployment subject binding")
    clock_doc = _clock(clock, context["clock_policy"])
    policy_roots = {
        policy_id: content_hash(policy) for policy_id, policy in context["policies"].items()
    }
    return {
        "profile": LIFECYCLE_AUTHORITY_PROFILE,
        "schema_version": LIFECYCLE_TRUST_SCHEMA_VERSION,
        "trust_context": context,
        "trust_context_root": content_hash(context),
        "policy_roots": policy_roots,
        "clock": clock_doc,
        "clock_root": content_hash(clock_doc),
        "principal": principal_doc,
        "principal_binding_root": content_hash(
            {
                "principal": principal_doc,
                "registered_subject": subject,
                "trust_context_root": content_hash(context),
            }
        ),
    }


def validate_lifecycle_authority_snapshot(value: Any) -> Dict[str, Any]:
    item = _closed(
        value,
        "lifecycle authority snapshot",
        (
            "profile",
            "schema_version",
            "trust_context",
            "trust_context_root",
            "policy_roots",
            "clock",
            "clock_root",
            "principal",
            "principal_binding_root",
        ),
    )
    if item["profile"] != LIFECYCLE_AUTHORITY_PROFILE:
        raise LifecycleTrustError(f"unsupported lifecycle authority profile {item['profile']!r}")
    if item["schema_version"] != LIFECYCLE_TRUST_SCHEMA_VERSION:
        raise LifecycleTrustError("unsupported lifecycle authority schema")
    rebuilt = build_lifecycle_authority_snapshot(
        item["trust_context"], item["principal"], item["clock"]
    )
    if rebuilt != item:
        raise LifecycleTrustError(
            "lifecycle authority roots do not match the deployment context, policy, clock, or principal"
        )
    return rebuilt


def lifecycle_operation_permission(operation: str) -> str:
    return LIFECYCLE_OPERATION_PERMISSIONS.get(str(operation), "lifecycle:publish")


def lifecycle_operation_permitted(operation: str, roles: Sequence[str]) -> bool:
    from .roles import role_permits

    return role_permits(roles, lifecycle_operation_permission(operation))


def selected_lifecycle_policy(snapshot: Any, action: str) -> Dict[str, Any]:
    authority = validate_lifecycle_authority_snapshot(snapshot)
    matches = [
        policy
        for policy in authority["trust_context"]["policies"].values()
        if str(action) in policy["actions"]
    ]
    if len(matches) != 1:
        raise LifecycleTrustError(
            f"action {action!r} has no unique deployment lifecycle policy"
        )
    # The producer record uses the pre-existing policy shape; action routing
    # is authority metadata and is not copied into the approval policy record.
    policy = dict(matches[0])
    policy.pop("actions", None)
    return policy


def verify_lifecycle_signature(
    signed_content: Any, signature: Any, authority_snapshot: Any
) -> Dict[str, Any]:
    """Actually verify an Ed25519 lifecycle signature under deployment keys.

    A structured negative judgment is returned for unknown, revoked, malformed,
    unavailable, or invalid cryptography.  No branch falls back to a caller's
    ``verified`` assertion.
    """

    authority = validate_lifecycle_authority_snapshot(authority_snapshot)
    context = authority["trust_context"]
    if not isinstance(signature, Mapping):
        return {"verified": False, "status": "REFUSED", "reason": "signature is not an object"}
    required = {
        "profile", "algorithm", "key_id", "key_reference", "value",
        "payload_hash", "excluded_fields",
    }
    if set(signature) - (required | {"created_at"}) or not required.issubset(signature):
        return {
            "verified": False,
            "status": "REFUSED",
            "reason": "signature fields are missing or unsupported",
        }
    if signature.get("profile") != "Ed25519" or signature.get("algorithm") != "ed25519":
        return {
            "verified": False,
            "status": "UNSUPPORTED_PROFILE",
            "reason": "lifecycle authority requires the production Ed25519 profile",
        }
    key_id = str(signature.get("key_id") or "")
    key = context["trusted_keys"].get(key_id)
    if key is None:
        return {
            "verified": False,
            "status": "REFUSED",
            "reason": f"no deployment-trusted lifecycle key {key_id!r}",
        }
    if key["revoked"]:
        return {
            "verified": False,
            "status": "REFUSED",
            "reason": f"deployment lifecycle key {key_id!r} is revoked",
        }
    if tuple(signature.get("excluded_fields") or ()):
        return {
            "verified": False,
            "status": "REFUSED",
            "reason": "lifecycle approval signatures may not exclude payload fields",
        }
    expected_reference = f"ed25519-pub:{key['public_key']}"
    if signature.get("key_reference") != expected_reference:
        return {
            "verified": False,
            "status": "REFUSED",
            "reason": "signature key reference does not match deployment key material",
        }
    if signature.get("payload_hash") != content_hash(signed_content):
        return {
            "verified": False,
            "status": "REFUSED",
            "reason": "signature payload hash does not match signed lifecycle content",
        }
    if not PRODUCTION_CRYPTO_AVAILABLE:
        return {
            "verified": False,
            "status": "UNSUPPORTED_PROFILE",
            "reason": "Ed25519 provider unavailable; production crypto is required",
        }
    value = str(signature.get("value") or "")
    prefix, separator, encoded = value.partition(":")
    if prefix != "ed25519" or not separator:
        return {"verified": False, "status": "REFUSED", "reason": "malformed Ed25519 value"}
    try:
        signature_bytes = bytes.fromhex(encoded)
    except ValueError:
        return {"verified": False, "status": "REFUSED", "reason": "signature is not hexadecimal"}
    if len(signature_bytes) != 64:
        return {
            "verified": False,
            "status": "REFUSED",
            "reason": "Ed25519 signature is not exactly 64 bytes",
        }
    try:
        from cryptography.exceptions import InvalidSignature
        from cryptography.hazmat.primitives.asymmetric import ed25519

        ed25519.Ed25519PublicKey.from_public_bytes(bytes.fromhex(key["public_key"])).verify(
            signature_bytes, canonical_bytes(signed_content)
        )
    except (InvalidSignature, ValueError):
        return {
            "verified": False,
            "status": "REFUSED",
            "reason": "Ed25519 signature does not verify over canonical lifecycle content",
        }
    return {
        "verified": True,
        "status": "VERIFIED",
        "reason": f"Ed25519 verified with deployment key {key_id!r}",
        "key_id": key_id,
        "subject_id": key["subject_id"],
        "organization": key["organization"],
        "trust_context_root": authority["trust_context_root"],
        "clock_root": authority["clock_root"],
    }
