"""Runtime maturity levels and transition control (specification 32.4, 32.5).

Normative basis: master specification 32.4 (runtime maturity levels), 32.5
(transition requirements and fail-closed conditions), 45 (clock and time
discipline, in particular 45.1 and 45.6), 6.6 (fail closed), and 5.3 (a
heuristic may not silently authorize a runtime transition).

Four things are structural here rather than procedural.

**L0 cannot execute.**  32.4 grants L0 the power to *recommend* a
transition and nothing else, so :func:`authorize` at L0 returns an
authorization whose permitted action is ``RECOMMEND_ONLY`` and
:func:`execute` refuses it by name.  There is no flag that turns an L0
recommendation into an execution.

**L1 needs a person.**  Not a boolean, not a config key: a named
:class:`Approver` holding a :class:`Capability` that permits the level and
the action and that has not expired against the *supplied* clock.

**L2 and L3 are opt-in.**  32.4 says the initial production release SHOULD
target L0 and L1.  This implementation therefore treats L2 and L3 as
present but closed: they require a declared :class:`SafetyCase` that names
the level, and L3 additionally requires domain-specific safety controls
declared present and verified.  Absent that, they refuse.  L2 additionally
verifies membership in a previously certified envelope -- the pair *and*
the exact parameter bounds -- because "only within a previously certified
envelope" is a containment test, not a label.

**The clock is supplied, never read.**  No wall-clock call appears in this
package; a standing test greps for one.  Freshness is measured in
monotonic ticks (45.6), so no wall-clock adjustment can extend a freshness
window, and a clock that cannot supply a monotonic reading yields
``UNRESOLVED_CLOCK_STATUS`` rather than a guess.

The 32.5 plan requirements are enforced as a completeness check with no
defaults.  Fourteen items are named in the specification; a
:class:`TransitionPlan` missing any of them raises
:class:`IncompletePlan` listing every one that is absent.  A defaulted
phase guard or a defaulted rollback would be worse than a missing one,
because it would look like a decision.
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field, replace
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

from crg_model.canonical import content_hash
from crg_model.envelope import EvidenceClass
from crg_model.numeric import Exact, Interval

from etq_evidence.clock import (
    ClockTrust,
    TimeStatus,
    ValidityWindow,
    VerificationClock,
    evaluate_time,
)

__all__ = [
    "TransitionError",
    "IncompletePlan",
    "TransitionRefused",
    "MaturityLevel",
    "RefusalReason",
    "PermittedAction",
    "TransitionStatus",
    "Refusal",
    "TransitionClock",
    "TelemetryAuthentication",
    "TelemetrySample",
    "TelemetryFreshness",
    "PhaseGuard",
    "Margin",
    "Hysteresis",
    "DwellRequirement",
    "ExpectedBenefit",
    "TransitionCost",
    "QuiescencePlan",
    "Checkpoint",
    "StateConversionPlan",
    "Postcondition",
    "PostconditionResult",
    "RollbackPlan",
    "AuditSpec",
    "AuditEntry",
    "Capability",
    "Approver",
    "SafetyCase",
    "CertifiedEnvelope",
    "EnvelopeMembership",
    "TransitionCertificate",
    "Configuration",
    "TransitionRequirements",
    "GateReport",
    "TransitionPlan",
    "AuthorizationResult",
    "TransitionStep",
    "TransitionRecord",
    "TransitionExecutor",
    "TRANSITION_PLAN_REQUIRED_ITEMS",
    "FAIL_CLOSED_CONDITIONS",
    "plan_transition",
    "authorize",
    "execute",
    "rollback",
]


# --------------------------------------------------------------------------
# errors
# --------------------------------------------------------------------------


class TransitionError(ValueError):
    """Base class for refusals raised by transition control."""


class IncompletePlan(TransitionError):
    """A transition plan is missing one or more required items of 32.5."""

    def __init__(self, missing: Sequence[str]) -> None:
        self.missing: Tuple[str, ...] = tuple(missing)
        super().__init__(
            "a transition plan is incomplete; specification 32.5 requires every item "
            f"of {list(TRANSITION_PLAN_REQUIRED_ITEMS)} and these are absent: "
            f"{list(self.missing)}.  Missing items are not defaulted: a defaulted "
            "phase guard or rollback would present an omission as a decision"
        )


class TransitionRefused(TransitionError):
    """A fail-closed refusal (32.5, 6.6).  Carries the distinct reasons."""

    def __init__(self, refusals: Sequence["Refusal"]) -> None:
        self.refusals: Tuple[Refusal, ...] = tuple(refusals)
        if not self.refusals:  # pragma: no cover - defensive
            raise ValueError("a refusal must state at least one reason")
        detail = "; ".join(f"{r.reason}: {r.detail}" for r in self.refusals)
        super().__init__(f"transition refused -- {detail}")

    @property
    def reason(self) -> str:
        """The first (primary) refusal reason."""
        return self.refusals[0].reason

    @property
    def reasons(self) -> Tuple[str, ...]:
        return tuple(r.reason for r in self.refusals)


# --------------------------------------------------------------------------
# 32.4 maturity levels
# --------------------------------------------------------------------------


class MaturityLevel:
    """The four runtime maturity levels of specification 32.4."""

    L0_OFFLINE = "L0_OFFLINE"
    L1_SUPERVISED = "L1_SUPERVISED"
    L2_AUTOMATED_BOUNDED = "L2_AUTOMATED_BOUNDED"
    L3_ADAPTIVE_CERTIFIED = "L3_ADAPTIVE_CERTIFIED"

    ALL = (L0_OFFLINE, L1_SUPERVISED, L2_AUTOMATED_BOUNDED, L3_ADAPTIVE_CERTIFIED)
    ORDER: Dict[str, int] = {level: index for index, level in enumerate(ALL)}

    #: 32.4: "Initial production release SHOULD target L0 and L1."
    INITIAL_RELEASE = frozenset({L0_OFFLINE, L1_SUPERVISED})
    #: Consequently these two are present but closed by default.
    REQUIRE_OPT_IN = frozenset({L2_AUTOMATED_BOUNDED, L3_ADAPTIVE_CERTIFIED})

    #: L0 recommends; it does not execute.
    MAY_EXECUTE = frozenset({L1_SUPERVISED, L2_AUTOMATED_BOUNDED, L3_ADAPTIVE_CERTIFIED})
    #: L1 requires a named authorized operator.
    REQUIRES_APPROVER = frozenset({L1_SUPERVISED})
    #: L2 acts only inside a previously certified envelope.
    REQUIRES_CERTIFIED_ENVELOPE = frozenset({L2_AUTOMATED_BOUNDED})
    #: L3 acts only under declared domain-specific safety controls.
    REQUIRES_SAFETY_CONTROLS = frozenset({L3_ADAPTIVE_CERTIFIED})

    DESCRIPTION: Dict[str, str] = {
        L0_OFFLINE: "CRG recommends a transition but does not execute it",
        L1_SUPERVISED: "an authorized operator approves a generated transition plan",
        L2_AUTOMATED_BOUNDED: (
            "the system transitions only within a previously certified envelope"
        ),
        L3_ADAPTIVE_CERTIFIED: (
            "the system may generate and certify new transitions online under "
            "domain-specific safety controls"
        ),
    }

    @classmethod
    def check(cls, level: str) -> str:
        if level not in cls.ALL:
            raise TransitionError(
                f"unknown maturity level {level!r}; specification 32.4 defines "
                f"{', '.join(cls.ALL)}"
            )
        return level


class PermittedAction:
    """What an authorization permits."""

    RECOMMEND_ONLY = "RECOMMEND_ONLY"
    EXECUTE = "EXECUTE"
    NONE = "NONE"


class TransitionStatus:
    PLANNED = "PLANNED"
    AUTHORIZED = "AUTHORIZED"
    COMPLETED = "COMPLETED"
    ROLLED_BACK = "ROLLED_BACK"
    ROLLBACK_FAILED = "ROLLBACK_FAILED"
    REFUSED = "REFUSED"

    ALL = frozenset({PLANNED, AUTHORIZED, COMPLETED, ROLLED_BACK, ROLLBACK_FAILED, REFUSED})


class RefusalReason:
    """Distinct fail-closed refusal reasons.

    They are distinct because they have distinct remedies.  Stale telemetry
    means wait and re-read; an invalid certificate means re-certify; a
    context mismatch means the plan was made for a different system; a
    failed postcondition means the transition happened and must be undone;
    an expired capability means the human's authorization lapsed.  A single
    ``REFUSED`` code would send all five to the same wrong place.
    """

    # -- the seven conditions 32.5 names ------------------------------
    STALE_TELEMETRY = "STALE_TELEMETRY"
    INVALID_CERTIFICATE = "INVALID_CERTIFICATE"
    CONTEXT_MISMATCH = "CONTEXT_MISMATCH"
    FAILED_POSTCONDITION = "FAILED_POSTCONDITION"
    EXPIRED_CAPABILITY = "EXPIRED_CAPABILITY"
    MISSING_ROLLBACK = "MISSING_ROLLBACK"
    UNRESOLVED_CLOCK_STATUS = "UNRESOLVED_CLOCK_STATUS"

    # -- authorization and gate refusals ------------------------------
    UNAUTHENTICATED_TELEMETRY = "UNAUTHENTICATED_TELEMETRY"
    LEVEL_MAY_NOT_EXECUTE = "LEVEL_MAY_NOT_EXECUTE"
    APPROVER_REQUIRED = "APPROVER_REQUIRED"
    OUTSIDE_CERTIFIED_ENVELOPE = "OUTSIDE_CERTIFIED_ENVELOPE"
    SAFETY_CASE_NOT_DECLARED = "SAFETY_CASE_NOT_DECLARED"
    SAFETY_CONTROLS_NOT_DECLARED = "SAFETY_CONTROLS_NOT_DECLARED"
    NOT_AUTHORIZED = "NOT_AUTHORIZED"
    PHASE_GUARD_CLOSED = "PHASE_GUARD_CLOSED"
    INSUFFICIENT_MARGIN = "INSUFFICIENT_MARGIN"
    HYSTERESIS_NOT_SATISFIED = "HYSTERESIS_NOT_SATISFIED"
    DWELL_NOT_MET = "DWELL_NOT_MET"
    NO_EXPECTED_BENEFIT = "NO_EXPECTED_BENEFIT"
    QUIESCENCE_NOT_REACHED = "QUIESCENCE_NOT_REACHED"
    CHECKPOINT_FAILED = "CHECKPOINT_FAILED"
    EXECUTION_FAULT = "EXECUTION_FAULT"
    ROLLBACK_FAILED = "ROLLBACK_FAILED"

    ALL = frozenset(
        {
            STALE_TELEMETRY,
            INVALID_CERTIFICATE,
            CONTEXT_MISMATCH,
            FAILED_POSTCONDITION,
            EXPIRED_CAPABILITY,
            MISSING_ROLLBACK,
            UNRESOLVED_CLOCK_STATUS,
            UNAUTHENTICATED_TELEMETRY,
            LEVEL_MAY_NOT_EXECUTE,
            APPROVER_REQUIRED,
            OUTSIDE_CERTIFIED_ENVELOPE,
            SAFETY_CASE_NOT_DECLARED,
            SAFETY_CONTROLS_NOT_DECLARED,
            NOT_AUTHORIZED,
            PHASE_GUARD_CLOSED,
            INSUFFICIENT_MARGIN,
            HYSTERESIS_NOT_SATISFIED,
            DWELL_NOT_MET,
            NO_EXPECTED_BENEFIT,
            QUIESCENCE_NOT_REACHED,
            CHECKPOINT_FAILED,
            EXECUTION_FAULT,
            ROLLBACK_FAILED,
        }
    )


#: The exact list of 32.5: "The module shall fail closed on ..."
FAIL_CLOSED_CONDITIONS: Tuple[str, ...] = (
    RefusalReason.STALE_TELEMETRY,
    RefusalReason.INVALID_CERTIFICATE,
    RefusalReason.CONTEXT_MISMATCH,
    RefusalReason.FAILED_POSTCONDITION,
    RefusalReason.EXPIRED_CAPABILITY,
    RefusalReason.MISSING_ROLLBACK,
    RefusalReason.UNRESOLVED_CLOCK_STATUS,
)


@dataclass(frozen=True)
class Refusal:
    """One fail-closed refusal, with its distinct reason (32.5, 6.6)."""

    reason: str
    detail: str
    subject: str = ""

    def __post_init__(self) -> None:
        if self.reason not in RefusalReason.ALL:
            raise TransitionError(f"unknown refusal reason {self.reason!r}")

    def to_canonical(self) -> dict:
        record = {"reason": self.reason, "detail": self.detail}
        if self.subject:
            record["subject"] = self.subject
        return record


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------


def _new_id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4()}"


def _as_exact(value: Any, what: str) -> Exact:
    if isinstance(value, Exact):
        return value
    if isinstance(value, float):
        raise TransitionError(
            f"{what} is a binary float; runtime transition control uses exact "
            "rationals so a margin comparison cannot be decided by rounding (14.2)"
        )
    try:
        return Exact(value)
    except (TypeError, ValueError) as exc:
        raise TransitionError(f"{what} is not an exact quantity: {exc}") from exc


def _as_ticks(value: Any, what: str) -> int:
    if isinstance(value, bool) or isinstance(value, float):
        raise TransitionError(
            f"{what} must be an integer count of monotonic ticks (spec 45.1, 45.6)"
        )
    if not isinstance(value, int):
        raise TransitionError(f"{what} must be an integer tick count, got {type(value)!r}")
    return int(value)


def _exact_map(values: Optional[Mapping[str, Any]], what: str) -> Dict[str, Exact]:
    out: Dict[str, Exact] = {}
    for key, value in (values or {}).items():
        out[str(key)] = _as_exact(value, f"{what}[{key!r}]")
    return out


def _canonical_exact_map(values: Mapping[str, Exact]) -> dict:
    return {key: value.to_canonical() for key, value in sorted(values.items())}


# --------------------------------------------------------------------------
# clock (45)
# --------------------------------------------------------------------------


@dataclass(frozen=True)
class TransitionClock:
    """A clock the caller supplies for runtime transition control (45.1, 45.3).

    Two domains, kept apart exactly as 45.1 requires.  ``monotonic_ticks``
    is the local monotonic reading and is the *only* thing freshness, dwell,
    and timeout are measured against (45.6), so a wall-clock adjustment
    cannot extend a freshness window -- there is no code path by which it
    could.  ``wall_clock`` is the supplied :class:`VerificationClock` used
    for certificate and capability validity (45.2), and it is never
    consulted for freshness.

    A clock with ``monotonic_ticks=None`` is the honest representation of
    "this controller has no monotonic reading it will assert".  It produces
    ``UNRESOLVED_CLOCK_STATUS``, which 32.5 lists as a fail-closed
    condition, rather than a substituted wall-clock reading.
    """

    monotonic_ticks: Optional[int] = None
    tick_unit: str = "millisecond"
    source: str = "none-supplied"
    trust_level: str = ClockTrust.NONE_SUPPLIED
    wall_clock: VerificationClock = field(default_factory=VerificationClock.absent)

    def __post_init__(self) -> None:
        if self.trust_level not in ClockTrust.ALL:
            raise TransitionError(f"unknown clock trust level {self.trust_level!r} (45.3)")
        if self.monotonic_ticks is not None:
            object.__setattr__(
                self, "monotonic_ticks", _as_ticks(self.monotonic_ticks, "monotonic_ticks")
            )
        if self.monotonic_ticks is None and self.trust_level != ClockTrust.NONE_SUPPLIED:
            raise TransitionError(
                "a clock with no monotonic reading cannot declare a trust level (45.3)"
            )
        if not isinstance(self.wall_clock, VerificationClock):
            raise TransitionError("wall_clock must be an etq_evidence VerificationClock (45.2)")

    @classmethod
    def absent(cls) -> "TransitionClock":
        return cls()

    @classmethod
    def declared(
        cls,
        monotonic_ticks: int,
        source: str,
        *,
        tick_unit: str = "millisecond",
        trust_level: str = ClockTrust.LOCAL_DECLARED,
        wall_clock: Optional[VerificationClock] = None,
    ) -> "TransitionClock":
        return cls(
            monotonic_ticks=monotonic_ticks,
            tick_unit=tick_unit,
            source=source,
            trust_level=trust_level,
            wall_clock=wall_clock or VerificationClock.absent(),
        )

    def advanced(self, ticks: int) -> "TransitionClock":
        """A later reading of the same clock.  Ticks only ever increase."""
        delta = _as_ticks(ticks, "tick advance")
        if delta < 0:
            raise TransitionError(
                "a monotonic clock does not run backwards; a negative advance would "
                "let a caller manufacture freshness (spec 45.6)"
            )
        if self.monotonic_ticks is None:
            raise TransitionError("cannot advance a clock with no monotonic reading")
        return replace(self, monotonic_ticks=self.monotonic_ticks + delta)

    @property
    def resolved(self) -> bool:
        return self.monotonic_ticks is not None

    def to_canonical(self) -> dict:
        record: dict = {
            "tick_unit": self.tick_unit,
            "clock_source": self.source,
            "clock_trust_level": self.trust_level,
            "wall_clock": self.wall_clock.to_canonical(),
        }
        if self.monotonic_ticks is not None:
            record["monotonic_ticks"] = int(self.monotonic_ticks)
        return record


def _clock_refusal(clock: Optional[TransitionClock], subject: str) -> Optional[Refusal]:
    """32.5: fail closed on unresolved clock status."""
    if clock is None or not isinstance(clock, TransitionClock):
        return Refusal(
            reason=RefusalReason.UNRESOLVED_CLOCK_STATUS,
            detail=(
                "no TransitionClock was supplied.  Runtime transition control never "
                "reads the machine clock; the caller supplies the evaluation instant "
                "(spec 45.3) and its absence is a refusal, not a default"
            ),
            subject=subject,
        )
    if not clock.resolved:
        return Refusal(
            reason=RefusalReason.UNRESOLVED_CLOCK_STATUS,
            detail=(
                "the supplied clock asserts no monotonic reading; runtime freshness "
                "MUST use monotonic time (spec 45.6) and an indeterminate clock "
                "MUST NOT be represented as current (45.5)"
            ),
            subject=subject,
        )
    return None


# --------------------------------------------------------------------------
# telemetry (32.5: authenticated telemetry, telemetry freshness)
# --------------------------------------------------------------------------


@dataclass(frozen=True)
class TelemetryAuthentication:
    """Authentication binding for a telemetry sample (32.5).

    ``digest`` is a content hash over the sample's own canonical body.
    Verification recomputes it, so authentication here is a check and not a
    boolean the producer sets to True.
    """

    scheme: str
    signer_id: str
    digest: str

    def to_canonical(self) -> dict:
        return {"scheme": self.scheme, "signer_id": self.signer_id, "digest": self.digest}


@dataclass(frozen=True)
class TelemetrySample:
    """An authenticated telemetry reading stamped with a monotonic instant.

    ``observed_ticks`` is a monotonic reading from the same clock domain the
    controller later evaluates against (45.1).  ``observed_wall`` is
    reportable provenance only; nothing computes freshness from it.
    """

    source_id: str
    observed_ticks: int
    signals: Mapping[str, Exact] = field(default_factory=dict)
    phases: Mapping[str, str] = field(default_factory=dict)
    dwell_ticks: Mapping[str, int] = field(default_factory=dict)
    authentication: Optional[TelemetryAuthentication] = None
    observed_wall: Optional[str] = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "observed_ticks", _as_ticks(self.observed_ticks, "observed_ticks"))
        object.__setattr__(self, "signals", _exact_map(self.signals, "telemetry signal"))
        object.__setattr__(
            self, "phases", {str(k): str(v) for k, v in (self.phases or {}).items()}
        )
        object.__setattr__(
            self,
            "dwell_ticks",
            {
                str(k): _as_ticks(v, f"dwell_ticks[{k!r}]")
                for k, v in (self.dwell_ticks or {}).items()
            },
        )

    def body(self) -> dict:
        return {
            "source_id": self.source_id,
            "observed_ticks": int(self.observed_ticks),
            "signals": _canonical_exact_map(self.signals),
            "phases": dict(sorted(self.phases.items())),
            "dwell_ticks": {k: int(v) for k, v in sorted(self.dwell_ticks.items())},
        }

    def expected_digest(self) -> str:
        return content_hash(self.body())

    def signed_by(self, signer_id: str, scheme: str = "sha256-content-digest") -> "TelemetrySample":
        """Return this sample with a recomputable authentication binding."""
        return replace(
            self,
            authentication=TelemetryAuthentication(
                scheme=scheme, signer_id=signer_id, digest=self.expected_digest()
            ),
        )

    @property
    def authenticated(self) -> bool:
        if self.authentication is None:
            return False
        return self.authentication.digest == self.expected_digest()

    def signal(self, name: str) -> Optional[Exact]:
        return self.signals.get(name)

    def to_canonical(self) -> dict:
        record = dict(self.body())
        record["authenticated"] = self.authenticated
        if self.authentication is not None:
            record["authentication"] = self.authentication.to_canonical()
        if self.observed_wall is not None:
            record["observed_wall"] = self.observed_wall
        return record


@dataclass(frozen=True)
class TelemetryFreshness:
    """The declared freshness window, in monotonic ticks (32.5, 45.6)."""

    max_age_ticks: int
    declared_by: str = "operator"
    tick_unit: str = "millisecond"

    def __post_init__(self) -> None:
        object.__setattr__(self, "max_age_ticks", _as_ticks(self.max_age_ticks, "max_age_ticks"))
        if self.max_age_ticks < 0:
            raise TransitionError("a freshness window must not be negative")

    def to_canonical(self) -> dict:
        return {
            "max_age_ticks": int(self.max_age_ticks),
            "tick_unit": self.tick_unit,
            "declared_by": self.declared_by,
        }


def telemetry_refusals(
    telemetry: TelemetrySample,
    freshness: TelemetryFreshness,
    clock: TransitionClock,
    *,
    subject: str,
) -> List[Refusal]:
    """Authentication and freshness checks against a supplied clock (32.5, 45.6)."""
    refusals: List[Refusal] = []
    if not telemetry.authenticated:
        refusals.append(
            Refusal(
                reason=RefusalReason.UNAUTHENTICATED_TELEMETRY,
                detail=(
                    "the telemetry sample carries no verifiable authentication binding; "
                    "32.5 requires authenticated telemetry and an unauthenticated "
                    "reading is refused rather than trusted"
                ),
                subject=subject,
            )
        )
    clock_refusal = _clock_refusal(clock, subject)
    if clock_refusal is not None:
        refusals.append(clock_refusal)
        return refusals
    age = int(clock.monotonic_ticks) - int(telemetry.observed_ticks)
    if age < 0:
        refusals.append(
            Refusal(
                reason=RefusalReason.UNRESOLVED_CLOCK_STATUS,
                detail=(
                    f"the telemetry sample is stamped {abs(age)} ticks in the future of "
                    "the supplied monotonic clock; the two readings are not from one "
                    "monotonic domain and the freshness question is undecidable (45.1)"
                ),
                subject=subject,
            )
        )
    elif age > int(freshness.max_age_ticks):
        refusals.append(
            Refusal(
                reason=RefusalReason.STALE_TELEMETRY,
                detail=(
                    f"telemetry age {age} {clock.tick_unit} ticks exceeds the declared "
                    f"freshness window {int(freshness.max_age_ticks)}; measured on the "
                    "supplied monotonic clock, so no wall-clock adjustment can extend "
                    "the window (spec 45.6, 32.5)"
                ),
                subject=subject,
            )
        )
    return refusals


# --------------------------------------------------------------------------
# 32.5 plan components
# --------------------------------------------------------------------------


@dataclass(frozen=True)
class PhaseGuard:
    """A phase the system must be in before the transition may proceed (32.5)."""

    guard_id: str
    signal: str
    permitted_values: Tuple[str, ...]
    description: str = ""

    def __post_init__(self) -> None:
        values = tuple(str(v) for v in self.permitted_values)
        if not values:
            raise TransitionError(
                "a phase guard that permits nothing is not a guard; declare the "
                "phases in which the transition may proceed (32.5)"
            )
        object.__setattr__(self, "permitted_values", values)

    def evaluate(self, telemetry: TelemetrySample) -> Optional[Refusal]:
        observed = telemetry.phases.get(self.signal)
        if observed is None:
            return Refusal(
                reason=RefusalReason.PHASE_GUARD_CLOSED,
                detail=(
                    f"telemetry reports no value for phase signal {self.signal!r}; an "
                    "unobserved guard is closed, not open (spec 6.6)"
                ),
                subject=self.guard_id,
            )
        if observed not in self.permitted_values:
            return Refusal(
                reason=RefusalReason.PHASE_GUARD_CLOSED,
                detail=(
                    f"phase signal {self.signal!r} reads {observed!r}; the guard permits "
                    f"{list(self.permitted_values)}"
                ),
                subject=self.guard_id,
            )
        return None

    def to_canonical(self) -> dict:
        record = {
            "guard_id": self.guard_id,
            "signal": self.signal,
            "permitted_values": list(self.permitted_values),
        }
        if self.description:
            record["description"] = self.description
        return record


@dataclass(frozen=True)
class Margin:
    """A required exact margin on a telemetry signal (32.5)."""

    quantity: str
    required: Exact
    unit: str = ""
    description: str = ""

    def __post_init__(self) -> None:
        object.__setattr__(self, "required", _as_exact(self.required, "required margin"))

    def evaluate(self, telemetry: TelemetrySample) -> Optional[Refusal]:
        observed = telemetry.signal(self.quantity)
        if observed is None:
            return Refusal(
                reason=RefusalReason.INSUFFICIENT_MARGIN,
                detail=(
                    f"telemetry reports no value for margin quantity {self.quantity!r}; "
                    "an unobserved margin is not a satisfied one"
                ),
                subject=self.quantity,
            )
        if observed < self.required:
            return Refusal(
                reason=RefusalReason.INSUFFICIENT_MARGIN,
                detail=(
                    f"observed margin {observed} on {self.quantity!r} is below the "
                    f"required {self.required}; compared as exact rationals"
                ),
                subject=self.quantity,
            )
        return None

    def to_canonical(self) -> dict:
        record = {"quantity": self.quantity, "required": self.required.to_canonical()}
        if self.unit:
            record["unit"] = self.unit
        if self.description:
            record["description"] = self.description
        return record


@dataclass(frozen=True)
class Hysteresis:
    """Separate entry and exit thresholds (32.5).

    A zero-width band is refused at construction.  Equal thresholds are not
    hysteresis; they are the chatter hysteresis exists to prevent, and
    accepting them would let a plan claim a property it does not have.
    """

    quantity: str
    enter_threshold: Exact
    exit_threshold: Exact
    direction: str = "ABOVE"

    DIRECTIONS = ("ABOVE", "BELOW")

    def __post_init__(self) -> None:
        object.__setattr__(self, "enter_threshold", _as_exact(self.enter_threshold, "enter"))
        object.__setattr__(self, "exit_threshold", _as_exact(self.exit_threshold, "exit"))
        if self.direction not in self.DIRECTIONS:
            raise TransitionError(
                f"hysteresis direction must be one of {list(self.DIRECTIONS)}"
            )
        if self.enter_threshold == self.exit_threshold:
            raise TransitionError(
                "hysteresis with equal entry and exit thresholds has zero band width "
                "and does not suppress chatter; declare a separated band (32.5)"
            )
        if self.direction == "ABOVE" and self.enter_threshold < self.exit_threshold:
            raise TransitionError(
                "an ABOVE hysteresis needs enter_threshold above exit_threshold"
            )
        if self.direction == "BELOW" and self.enter_threshold > self.exit_threshold:
            raise TransitionError(
                "a BELOW hysteresis needs enter_threshold below exit_threshold"
            )

    @property
    def band_width(self) -> Exact:
        difference = self.enter_threshold - self.exit_threshold
        return difference if difference > Exact(0) else Exact(0) - difference

    def evaluate(self, telemetry: TelemetrySample) -> Optional[Refusal]:
        observed = telemetry.signal(self.quantity)
        if observed is None:
            return Refusal(
                reason=RefusalReason.HYSTERESIS_NOT_SATISFIED,
                detail=f"telemetry reports no value for {self.quantity!r}",
                subject=self.quantity,
            )
        entered = (
            observed >= self.enter_threshold
            if self.direction == "ABOVE"
            else observed <= self.enter_threshold
        )
        if not entered:
            return Refusal(
                reason=RefusalReason.HYSTERESIS_NOT_SATISFIED,
                detail=(
                    f"observed {observed} on {self.quantity!r} has not crossed the "
                    f"{self.direction} entry threshold {self.enter_threshold}; the exit "
                    f"threshold is {self.exit_threshold}"
                ),
                subject=self.quantity,
            )
        return None

    def to_canonical(self) -> dict:
        return {
            "quantity": self.quantity,
            "enter_threshold": self.enter_threshold.to_canonical(),
            "exit_threshold": self.exit_threshold.to_canonical(),
            "direction": self.direction,
            "band_width": self.band_width.to_canonical(),
        }


@dataclass(frozen=True)
class DwellRequirement:
    """How long the trigger condition must have held, in monotonic ticks (32.5)."""

    condition_id: str
    minimum_ticks: int
    tick_unit: str = "millisecond"

    def __post_init__(self) -> None:
        object.__setattr__(self, "minimum_ticks", _as_ticks(self.minimum_ticks, "minimum_ticks"))
        if self.minimum_ticks < 0:
            raise TransitionError("a dwell requirement must not be negative")

    def evaluate(self, telemetry: TelemetrySample) -> Optional[Refusal]:
        observed = telemetry.dwell_ticks.get(self.condition_id)
        if observed is None:
            return Refusal(
                reason=RefusalReason.DWELL_NOT_MET,
                detail=(
                    f"telemetry reports no dwell time for condition "
                    f"{self.condition_id!r}; an unobserved dwell is not a satisfied one"
                ),
                subject=self.condition_id,
            )
        if int(observed) < int(self.minimum_ticks):
            return Refusal(
                reason=RefusalReason.DWELL_NOT_MET,
                detail=(
                    f"condition {self.condition_id!r} has held for {int(observed)} ticks; "
                    f"{int(self.minimum_ticks)} are required"
                ),
                subject=self.condition_id,
            )
        return None

    def to_canonical(self) -> dict:
        return {
            "condition_id": self.condition_id,
            "minimum_ticks": int(self.minimum_ticks),
            "tick_unit": self.tick_unit,
        }


@dataclass(frozen=True)
class ExpectedBenefit:
    """The benefit the transition is expected to deliver (32.5).

    Carries its own evidence class: a benefit predicted by a compact model
    is ``MODELED`` and stays ``MODELED`` in the audit record.
    """

    quantity: str
    value: Exact
    unit: str = ""
    basis: str = ""
    evidence_class: str = EvidenceClass.MODELED

    def __post_init__(self) -> None:
        object.__setattr__(self, "value", _as_exact(self.value, "expected benefit"))
        if self.evidence_class not in EvidenceClass.ALL:
            raise TransitionError(
                f"expected benefit evidence class {self.evidence_class!r} is not a "
                "class of specification 5.3"
            )

    @property
    def positive(self) -> bool:
        return self.value > Exact(0)

    def to_canonical(self) -> dict:
        record = {
            "quantity": self.quantity,
            "value": self.value.to_canonical(),
            "evidence_class": self.evidence_class,
        }
        if self.unit:
            record["unit"] = self.unit
        if self.basis:
            record["basis"] = self.basis
        return record


@dataclass(frozen=True)
class TransitionCost:
    """Total transition cost with its components (32.5).

    The declared total is checked against the component sum exactly.  A
    total that does not equal its parts is a plan that has lost track of
    what the transition costs, and the comparison is exact so it cannot be
    smoothed over by rounding.
    """

    components: Mapping[str, Exact]
    total: Exact
    unit: str = ""

    def __post_init__(self) -> None:
        components = _exact_map(self.components, "cost component")
        if not components:
            raise TransitionError(
                "a total transition cost must be decomposed into declared components "
                "(32.5); an undecomposed total is not auditable"
            )
        object.__setattr__(self, "components", components)
        object.__setattr__(self, "total", _as_exact(self.total, "total transition cost"))
        summed = Exact(0)
        for value in components.values():
            summed = summed + value
        if summed != self.total:
            raise TransitionError(
                f"declared total transition cost {self.total} does not equal the exact "
                f"sum of its components {summed} (32.5)"
            )

    @classmethod
    def of(cls, components: Mapping[str, Any], unit: str = "") -> "TransitionCost":
        exact_components = _exact_map(components, "cost component")
        total = Exact(0)
        for value in exact_components.values():
            total = total + value
        return cls(components=exact_components, total=total, unit=unit)

    def to_canonical(self) -> dict:
        record = {
            "components": _canonical_exact_map(self.components),
            "total": self.total.to_canonical(),
        }
        if self.unit:
            record["unit"] = self.unit
        return record


@dataclass(frozen=True)
class QuiescencePlan:
    """How the system is brought to a quiescent state before conversion (32.5)."""

    mode: str
    drain_ticks: int
    verification_signal: str
    required: bool = True

    def __post_init__(self) -> None:
        object.__setattr__(self, "drain_ticks", _as_ticks(self.drain_ticks, "drain_ticks"))
        if not str(self.mode).strip():
            raise TransitionError("a quiescence plan must declare its mode")
        if not str(self.verification_signal).strip():
            raise TransitionError(
                "a quiescence plan must name the signal that verifies quiescence was "
                "reached; an unverified drain is an assumption (32.5)"
            )

    def to_canonical(self) -> dict:
        return {
            "mode": self.mode,
            "drain_ticks": int(self.drain_ticks),
            "verification_signal": self.verification_signal,
            "required": self.required,
        }


@dataclass(frozen=True)
class Checkpoint:
    """The restorable checkpoint the rollback returns to (32.5)."""

    checkpoint_id: str
    configuration_id: str
    configuration_hash: str
    captured_at_ticks: int
    contents_hash: str = ""
    restorable: bool = True

    def __post_init__(self) -> None:
        object.__setattr__(
            self, "captured_at_ticks", _as_ticks(self.captured_at_ticks, "captured_at_ticks")
        )
        if not self.restorable:
            raise TransitionError(
                "a checkpoint declared non-restorable cannot support the rollback that "
                "32.5 requires; do not plan a transition against it"
            )

    def to_canonical(self) -> dict:
        record = {
            "checkpoint_id": self.checkpoint_id,
            "configuration_id": self.configuration_id,
            "configuration_hash": self.configuration_hash,
            "captured_at_ticks": int(self.captured_at_ticks),
            "restorable": self.restorable,
        }
        if self.contents_hash:
            record["contents_hash"] = self.contents_hash
        return record


@dataclass(frozen=True)
class StateConversionPlan:
    """The state conversion the transition performs (32.5).

    Built from a ``crg_convert.ConversionRecord`` where one exists, so the
    retained and moved fractions in a transition plan are the exact
    rationals the OID-CRG-004 assignment produced rather than a restated
    estimate.
    """

    conversion_id: str
    source_layout: str
    target_layout: str
    retained_fraction: Exact
    moved_fraction: Exact
    conversion_record_hash: str = ""
    rollback_behavior: str = ""

    def __post_init__(self) -> None:
        object.__setattr__(
            self, "retained_fraction", _as_exact(self.retained_fraction, "retained_fraction")
        )
        object.__setattr__(
            self, "moved_fraction", _as_exact(self.moved_fraction, "moved_fraction")
        )
        if self.retained_fraction + self.moved_fraction != Exact(1):
            raise TransitionError(
                f"retained {self.retained_fraction} and moved {self.moved_fraction} "
                "fractions must partition the logical space exactly (spec 31.5)"
            )

    @classmethod
    def from_conversion_record(
        cls,
        record: Any,
        *,
        source_layout: str = "",
        target_layout: str = "",
        rollback_behavior: str = "",
    ) -> "StateConversionPlan":
        return cls(
            conversion_id=getattr(record, "record_id", _new_id("conv")),
            source_layout=source_layout or getattr(record.source_space, "identifier", ""),
            target_layout=target_layout or getattr(record.target_space, "identifier", ""),
            retained_fraction=record.retained_fraction,
            moved_fraction=record.moved_fraction,
            conversion_record_hash=content_hash(
                {
                    "record_id": getattr(record, "record_id", ""),
                    "retained_fraction": record.retained_fraction.to_canonical(),
                    "moved_fraction": record.moved_fraction.to_canonical(),
                }
            ),
            rollback_behavior=rollback_behavior or getattr(record, "rollback_behavior", ""),
        )

    @property
    def affects_consistency(self) -> bool:
        """Any movement at all can leave state split across configurations."""
        return self.moved_fraction > Exact(0)

    def to_canonical(self) -> dict:
        record = {
            "conversion_id": self.conversion_id,
            "source_layout": self.source_layout,
            "target_layout": self.target_layout,
            "retained_fraction": self.retained_fraction.to_canonical(),
            "moved_fraction": self.moved_fraction.to_canonical(),
        }
        if self.conversion_record_hash:
            record["conversion_record_hash"] = self.conversion_record_hash
        if self.rollback_behavior:
            record["rollback_behavior"] = self.rollback_behavior
        return record


@dataclass(frozen=True)
class Postcondition:
    """A condition that must hold after the transition (32.5)."""

    condition_id: str
    signal: str
    comparator: str
    threshold: Exact
    description: str = ""

    COMPARATORS = (">=", ">", "<=", "<", "==")

    def __post_init__(self) -> None:
        if self.comparator not in self.COMPARATORS:
            raise TransitionError(
                f"unknown postcondition comparator {self.comparator!r}; use one of "
                f"{list(self.COMPARATORS)}"
            )
        object.__setattr__(self, "threshold", _as_exact(self.threshold, "postcondition threshold"))

    def evaluate(self, telemetry: TelemetrySample) -> "PostconditionResult":
        observed = telemetry.signal(self.signal)
        if observed is None:
            return PostconditionResult(
                condition_id=self.condition_id,
                signal=self.signal,
                comparator=self.comparator,
                threshold=self.threshold,
                observed=None,
                satisfied=False,
                detail=(
                    f"post-transition telemetry reports no value for {self.signal!r}; "
                    "an unobserved postcondition has not been met (spec 6.6)"
                ),
            )
        satisfied = {
            ">=": observed >= self.threshold,
            ">": observed > self.threshold,
            "<=": observed <= self.threshold,
            "<": observed < self.threshold,
            "==": observed == self.threshold,
        }[self.comparator]
        return PostconditionResult(
            condition_id=self.condition_id,
            signal=self.signal,
            comparator=self.comparator,
            threshold=self.threshold,
            observed=observed,
            satisfied=bool(satisfied),
            detail=(
                ""
                if satisfied
                else f"observed {observed} fails {self.signal} {self.comparator} {self.threshold}"
            ),
        )

    def to_canonical(self) -> dict:
        record = {
            "condition_id": self.condition_id,
            "signal": self.signal,
            "comparator": self.comparator,
            "threshold": self.threshold.to_canonical(),
        }
        if self.description:
            record["description"] = self.description
        return record


@dataclass(frozen=True)
class PostconditionResult:
    condition_id: str
    signal: str
    comparator: str
    threshold: Exact
    observed: Optional[Exact]
    satisfied: bool
    detail: str = ""

    def to_canonical(self) -> dict:
        record = {
            "condition_id": self.condition_id,
            "signal": self.signal,
            "comparator": self.comparator,
            "threshold": self.threshold.to_canonical(),
            "satisfied": self.satisfied,
        }
        if self.observed is not None:
            record["observed"] = self.observed.to_canonical()
        if self.detail:
            record["detail"] = self.detail
        return record


@dataclass(frozen=True)
class RollbackPlan:
    """How the system returns to the checkpointed source configuration (32.5)."""

    rollback_id: str
    checkpoint_id: str
    steps: Tuple[str, ...]
    bounded_ticks: int
    restores_consistency: bool = True
    verification_signal: str = ""

    def __post_init__(self) -> None:
        steps = tuple(str(s) for s in self.steps)
        if not steps:
            raise TransitionError(
                "a rollback plan with no steps is not a rollback; 32.5 fails closed on "
                "missing rollback where consistency may be affected"
            )
        object.__setattr__(self, "steps", steps)
        object.__setattr__(self, "bounded_ticks", _as_ticks(self.bounded_ticks, "bounded_ticks"))
        if self.bounded_ticks <= 0:
            raise TransitionError(
                "a rollback must be bounded in time; an unbounded rollback is not a "
                "recovery path"
            )

    def to_canonical(self) -> dict:
        record = {
            "rollback_id": self.rollback_id,
            "checkpoint_id": self.checkpoint_id,
            "steps": list(self.steps),
            "bounded_ticks": int(self.bounded_ticks),
            "restores_consistency": self.restores_consistency,
        }
        if self.verification_signal:
            record["verification_signal"] = self.verification_signal
        return record


@dataclass(frozen=True)
class AuditSpec:
    """What is recorded about the transition and where (32.5, 6.4)."""

    audit_id: str
    sink: str
    retained_fields: Tuple[str, ...]
    signer: str = ""

    def __post_init__(self) -> None:
        fields = tuple(str(f) for f in self.retained_fields)
        if not fields:
            raise TransitionError(
                "an audit specification must name the fields it retains; an audit that "
                "retains nothing is not an audit (32.5)"
            )
        object.__setattr__(self, "retained_fields", fields)
        if not str(self.sink).strip():
            raise TransitionError("an audit specification must name its sink")

    def to_canonical(self) -> dict:
        record = {
            "audit_id": self.audit_id,
            "sink": self.sink,
            "retained_fields": list(self.retained_fields),
        }
        if self.signer:
            record["signer"] = self.signer
        return record


@dataclass(frozen=True)
class AuditEntry:
    """One appended audit line, stamped on the supplied monotonic clock."""

    sequence: int
    at_ticks: int
    event: str
    detail: str = ""

    def to_canonical(self) -> dict:
        record = {
            "sequence": int(self.sequence),
            "at_ticks": int(self.at_ticks),
            "event": self.event,
        }
        if self.detail:
            record["detail"] = self.detail
        return record


# --------------------------------------------------------------------------
# authorization primitives
# --------------------------------------------------------------------------


@dataclass(frozen=True)
class Capability:
    """A time-bounded grant permitting a holder to authorize transitions.

    Validity is an issuer assertion judged against the *supplied* wall
    clock (45.2, 45.3).  With no clock the status is
    ``TIME_INDETERMINATE``, which does not authorize -- 45.5 forbids
    representing an indeterminate time claim as current, and 6.6 forbids an
    affirmative result from an unresolved one.
    """

    capability_id: str
    holder: str
    permitted_levels: Tuple[str, ...]
    permitted_actions: Tuple[str, ...]
    validity: ValidityWindow = field(default_factory=ValidityWindow)

    def __post_init__(self) -> None:
        levels = tuple(str(level) for level in self.permitted_levels)
        for level in levels:
            MaturityLevel.check(level)
        object.__setattr__(self, "permitted_levels", levels)
        object.__setattr__(
            self, "permitted_actions", tuple(str(a) for a in self.permitted_actions)
        )

    def judge(self, clock: TransitionClock):
        return evaluate_time(self.validity, clock.wall_clock)

    def refusal(self, *, level: str, action: str, clock: TransitionClock) -> Optional[Refusal]:
        if level not in self.permitted_levels:
            return Refusal(
                reason=RefusalReason.NOT_AUTHORIZED,
                detail=(
                    f"capability {self.capability_id!r} permits levels "
                    f"{list(self.permitted_levels)} and not {level}"
                ),
                subject=self.holder,
            )
        if action not in self.permitted_actions:
            return Refusal(
                reason=RefusalReason.NOT_AUTHORIZED,
                detail=(
                    f"capability {self.capability_id!r} permits actions "
                    f"{list(self.permitted_actions)} and not {action!r}"
                ),
                subject=self.holder,
            )
        judgment = self.judge(clock)
        if judgment.time_status in (TimeStatus.EXPIRED, TimeStatus.STALE):
            return Refusal(
                reason=RefusalReason.EXPIRED_CAPABILITY,
                detail=(
                    f"capability {self.capability_id!r} of {self.holder!r} evaluates "
                    f"{judgment.time_status} against the supplied clock "
                    f"({judgment.verifier_clock_source}): {judgment.detail}"
                ),
                subject=self.holder,
            )
        if judgment.time_status != TimeStatus.CURRENT:
            return Refusal(
                reason=RefusalReason.EXPIRED_CAPABILITY,
                detail=(
                    f"capability {self.capability_id!r} evaluates "
                    f"{judgment.time_status} against the supplied clock and therefore "
                    "does not authorize; an indeterminate or not-yet-valid grant MUST "
                    "NOT be represented as current (spec 45.5, 6.6)"
                ),
                subject=self.holder,
            )
        return None

    def to_canonical(self) -> dict:
        return {
            "capability_id": self.capability_id,
            "holder": self.holder,
            "permitted_levels": list(self.permitted_levels),
            "permitted_actions": list(self.permitted_actions),
            "validity": self.validity.to_canonical(),
        }


#: The action a capability must permit to authorize an executable transition.
AUTHORIZE_TRANSITION = "AUTHORIZE_TRANSITION"


@dataclass(frozen=True)
class Approver:
    """A named authorized operator (32.4, L1).

    The identity is required and must be a real name: 32.4 says "an
    authorized operator approves", and an approval attributed to
    ``"system"`` or ``""`` is an unattributed approval.
    """

    identity: str
    role: str
    capability: Capability

    def __post_init__(self) -> None:
        if not str(self.identity).strip():
            raise TransitionError(
                "an approver must be named; 32.4 L1 requires an authorized operator, "
                "and an anonymous approval is not one"
            )
        if self.capability.holder != self.identity:
            raise TransitionError(
                f"capability {self.capability.capability_id!r} is held by "
                f"{self.capability.holder!r}, not by approver {self.identity!r}"
            )

    def to_canonical(self) -> dict:
        return {
            "identity": self.identity,
            "role": self.role,
            "capability": self.capability.to_canonical(),
        }


@dataclass(frozen=True)
class SafetyCase:
    """The explicit opt-in required to run above the initial-release levels.

    32.4 says the initial production release SHOULD target L0 and L1.  This
    implementation honours that by making L2 and L3 unreachable without a
    declared safety case that names the level.  L3 additionally requires
    ``domain_safety_controls`` to be non-empty and ``controls_verified``
    true, because 32.4 grants L3 only "under domain-specific safety
    controls" and an unverified control is a plan, not a control.
    """

    case_id: str
    domain: str
    opt_in_levels: Tuple[str, ...]
    declared_by: str
    domain_safety_controls: Tuple[str, ...] = ()
    controls_verified: bool = False
    reference: str = ""

    def __post_init__(self) -> None:
        levels = tuple(str(level) for level in self.opt_in_levels)
        for level in levels:
            MaturityLevel.check(level)
        object.__setattr__(self, "opt_in_levels", levels)
        object.__setattr__(
            self, "domain_safety_controls", tuple(str(c) for c in self.domain_safety_controls)
        )
        if not str(self.declared_by).strip():
            raise TransitionError("a safety case must name who declared it")

    def permits(self, level: str) -> bool:
        return level in self.opt_in_levels

    @property
    def controls_declared_present(self) -> bool:
        return bool(self.domain_safety_controls) and self.controls_verified

    def to_canonical(self) -> dict:
        record = {
            "case_id": self.case_id,
            "domain": self.domain,
            "opt_in_levels": list(self.opt_in_levels),
            "declared_by": self.declared_by,
            "domain_safety_controls": list(self.domain_safety_controls),
            "controls_verified": self.controls_verified,
        }
        if self.reference:
            record["reference"] = self.reference
        return record


# --------------------------------------------------------------------------
# certified envelope (32.4, L2)
# --------------------------------------------------------------------------


@dataclass(frozen=True)
class EnvelopeMembership:
    """The result of testing a transition against a certified envelope."""

    inside: bool
    envelope_id: str
    source_config_id: str
    target_config_id: str
    checked_parameters: Tuple[str, ...] = ()
    violations: Tuple[str, ...] = ()
    detail: str = ""

    def to_canonical(self) -> dict:
        record = {
            "inside": self.inside,
            "envelope_id": self.envelope_id,
            "source_config_id": self.source_config_id,
            "target_config_id": self.target_config_id,
            "checked_parameters": list(self.checked_parameters),
        }
        if self.violations:
            record["violations"] = list(self.violations)
        if self.detail:
            record["detail"] = self.detail
        return record


@dataclass(frozen=True)
class CertifiedEnvelope:
    """A previously certified set of transitions (32.4, L2).

    Membership is a containment test over two things at once: the ordered
    configuration pair must be one the certificate enumerated, and every
    parameter the envelope bounds must lie inside its exact interval.  Both
    halves matter -- a certified pair driven to uncertified parameters is
    outside the envelope just as surely as an uncertified pair.

    A parameter the envelope bounds but the configuration does not declare
    is a violation, not a pass.  The envelope certified a region; a
    configuration that does not say where it sits in that region has not
    been shown to sit inside it.
    """

    envelope_id: str
    certificate_id: str
    permitted_pairs: Tuple[Tuple[str, str], ...]
    parameter_bounds: Mapping[str, Interval] = field(default_factory=dict)
    validity: ValidityWindow = field(default_factory=ValidityWindow)
    basis: str = ""

    def __post_init__(self) -> None:
        pairs = tuple((str(a), str(b)) for a, b in self.permitted_pairs)
        if not pairs:
            raise TransitionError(
                "a certified envelope that permits no transition cannot bound L2 "
                "operation; enumerate the certified configuration pairs (32.4)"
            )
        object.__setattr__(self, "permitted_pairs", pairs)
        bounds: Dict[str, Interval] = {}
        for name, interval in (self.parameter_bounds or {}).items():
            if not isinstance(interval, Interval):
                raise TransitionError(
                    f"parameter bound for {name!r} must be an exact Interval, got "
                    f"{type(interval)!r}"
                )
            bounds[str(name)] = interval
        object.__setattr__(self, "parameter_bounds", bounds)

    def contains(
        self, source_config: "Configuration", target_config: "Configuration"
    ) -> EnvelopeMembership:
        violations: List[str] = []
        pair = (source_config.config_id, target_config.config_id)
        if pair not in self.permitted_pairs:
            violations.append(
                f"the pair {pair[0]!r} -> {pair[1]!r} is not among the certified "
                f"transitions {[list(p) for p in self.permitted_pairs]}"
            )
        for name, interval in sorted(self.parameter_bounds.items()):
            value = target_config.parameters.get(name)
            if value is None:
                violations.append(
                    f"the envelope bounds parameter {name!r} but the target "
                    "configuration does not declare it; an undeclared parameter has "
                    "not been shown to lie inside the certified region"
                )
                continue
            if value < interval.lo or value > interval.hi:
                violations.append(
                    f"parameter {name!r} = {value} lies outside the certified interval "
                    f"[{interval.lo}, {interval.hi}]"
                )
        return EnvelopeMembership(
            inside=not violations,
            envelope_id=self.envelope_id,
            source_config_id=source_config.config_id,
            target_config_id=target_config.config_id,
            checked_parameters=tuple(sorted(self.parameter_bounds)),
            violations=tuple(violations),
            detail=(
                "the transition lies inside the previously certified envelope"
                if not violations
                else "the transition lies outside the previously certified envelope"
            ),
        )

    def to_canonical(self) -> dict:
        record = {
            "envelope_id": self.envelope_id,
            "certificate_id": self.certificate_id,
            "permitted_pairs": [list(p) for p in self.permitted_pairs],
            "parameter_bounds": {
                name: interval.to_canonical()
                for name, interval in sorted(self.parameter_bounds.items())
            },
            "validity": self.validity.to_canonical(),
        }
        if self.basis:
            record["basis"] = self.basis
        return record

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())


@dataclass(frozen=True)
class TransitionCertificate:
    """A certificate binding an envelope to a subject digest (32.5, 45.2).

    ``subject_hash`` is recomputed at verification time.  A certificate that
    does not bind what it is presented for is ``INVALID_CERTIFICATE``,
    which is a different fact from an expired capability and gets a
    different refusal reason.
    """

    certificate_id: str
    issuer: str
    subject_hash: str
    validity: ValidityWindow = field(default_factory=ValidityWindow)

    def verify(self, subject_hash: str, clock: TransitionClock) -> Optional[Refusal]:
        if self.subject_hash != subject_hash:
            return Refusal(
                reason=RefusalReason.INVALID_CERTIFICATE,
                detail=(
                    f"certificate {self.certificate_id!r} binds subject digest "
                    f"{self.subject_hash!r} but the presented subject digests to "
                    f"{subject_hash!r}; the certificate does not certify this envelope"
                ),
                subject=self.certificate_id,
            )
        judgment = evaluate_time(self.validity, clock.wall_clock)
        if judgment.time_status != TimeStatus.CURRENT:
            return Refusal(
                reason=RefusalReason.INVALID_CERTIFICATE,
                detail=(
                    f"certificate {self.certificate_id!r} evaluates "
                    f"{judgment.time_status} against the supplied clock "
                    f"({judgment.verifier_clock_source}): {judgment.detail}"
                ),
                subject=self.certificate_id,
            )
        return None

    def to_canonical(self) -> dict:
        return {
            "certificate_id": self.certificate_id,
            "issuer": self.issuer,
            "subject_hash": self.subject_hash,
            "validity": self.validity.to_canonical(),
        }


# --------------------------------------------------------------------------
# configurations
# --------------------------------------------------------------------------


@dataclass(frozen=True)
class Configuration:
    """A runtime configuration the system may occupy.

    ``entry_requirements`` is declared on the configuration being entered,
    which is where the answer to "what must hold before we go there" lives.
    ``plan_transition`` reads it and refuses if it is absent, rather than
    synthesizing a guard nobody wrote.
    """

    config_id: str
    label: str = ""
    phase: str = ""
    parameters: Mapping[str, Exact] = field(default_factory=dict)
    layout_label: str = ""
    partition_count: Optional[int] = None
    entry_requirements: Optional["TransitionRequirements"] = None

    def __post_init__(self) -> None:
        if not str(self.config_id).strip():
            raise TransitionError("a configuration needs an identity")
        object.__setattr__(self, "parameters", _exact_map(self.parameters, "configuration parameter"))
        if self.partition_count is not None:
            count = _as_ticks(self.partition_count, "partition_count")
            if count < 1:
                raise TransitionError("partition_count must be at least one")
            object.__setattr__(self, "partition_count", count)

    def to_canonical(self) -> dict:
        record = {
            "config_id": self.config_id,
            "parameters": _canonical_exact_map(self.parameters),
        }
        for key, value in (
            ("label", self.label),
            ("phase", self.phase),
            ("layout_label", self.layout_label),
        ):
            if value:
                record[key] = value
        if self.partition_count is not None:
            record["partition_count"] = int(self.partition_count)
        return record

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())


@dataclass(frozen=True)
class TransitionRequirements:
    """The 32.5 items a target configuration declares for entry.

    Every field is required.  There is no partially-declared requirements
    object: an operator who has thought about the phase guard but not the
    rollback has not finished, and a plan built from that is the exact
    thing 32.5 forbids.
    """

    phase_guard: PhaseGuard
    margin: Margin
    hysteresis: Hysteresis
    dwell: DwellRequirement
    expected_benefit: ExpectedBenefit
    total_cost: TransitionCost
    quiescence: QuiescencePlan
    postconditions: Tuple[Postcondition, ...]
    rollback: RollbackPlan
    audit: AuditSpec
    telemetry_freshness: TelemetryFreshness
    state_conversion: Optional[StateConversionPlan] = None
    certificate: Optional[TransitionCertificate] = None
    safety_case: Optional[SafetyCase] = None

    def __post_init__(self) -> None:
        conditions = tuple(self.postconditions or ())
        if not conditions:
            raise TransitionError(
                "a transition must declare at least one postcondition; 32.5 fails "
                "closed on failed postconditions, which presupposes there are some"
            )
        object.__setattr__(self, "postconditions", conditions)


# --------------------------------------------------------------------------
# the plan (32.5)
# --------------------------------------------------------------------------

#: The fourteen items 32.5 says a transition plan MUST include, in the order
#: the specification lists them.
TRANSITION_PLAN_REQUIRED_ITEMS: Tuple[str, ...] = (
    "authenticated_telemetry",
    "telemetry_freshness",
    "phase_guard",
    "margin",
    "hysteresis",
    "dwell",
    "expected_benefit",
    "total_cost",
    "quiescence",
    "checkpoint",
    "state_conversion",
    "postconditions",
    "rollback",
    "audit",
)


@dataclass(frozen=True)
class GateReport:
    """Evaluation of the trigger gates against the plan's telemetry."""

    refusals: Tuple[Refusal, ...] = ()

    @property
    def satisfied(self) -> bool:
        return not self.refusals

    def to_canonical(self) -> dict:
        return {
            "satisfied": self.satisfied,
            "refusals": [r.to_canonical() for r in self.refusals],
        }


@dataclass
class TransitionPlan:
    """A transition plan carrying every item required by 32.5.

    The fourteen required items are keyword-only with no defaults, so
    omitting one is a ``TypeError`` at the call site.  Passing ``None``
    explicitly -- the way a partially built plan arrives from a
    configuration loader -- raises :class:`IncompletePlan` naming every
    absent item.  Neither path produces a plan with a synthesized field.

    ``authorization`` is not one of the fourteen.  It is attached by
    :func:`authorize` and read by :func:`execute`, which is how an
    unauthorized plan is prevented from executing without changing the
    ``execute(plan, *, executor, clock)`` signature.
    """

    plan_id: str
    source_config: Configuration
    target_config: Configuration
    clock: TransitionClock
    context_fingerprint: str
    authenticated_telemetry: Optional[TelemetrySample] = None
    telemetry_freshness: Optional[TelemetryFreshness] = None
    phase_guard: Optional[PhaseGuard] = None
    margin: Optional[Margin] = None
    hysteresis: Optional[Hysteresis] = None
    dwell: Optional[DwellRequirement] = None
    expected_benefit: Optional[ExpectedBenefit] = None
    total_cost: Optional[TransitionCost] = None
    quiescence: Optional[QuiescencePlan] = None
    checkpoint: Optional[Checkpoint] = None
    state_conversion: Optional[StateConversionPlan] = None
    postconditions: Optional[Tuple[Postcondition, ...]] = None
    rollback: Optional[RollbackPlan] = None
    audit: Optional[AuditSpec] = None
    envelope: Optional[CertifiedEnvelope] = None
    certificate: Optional[TransitionCertificate] = None
    safety_case: Optional[SafetyCase] = None
    gates: GateReport = field(default_factory=GateReport)
    status: str = TransitionStatus.PLANNED
    authorization: Optional["AuthorizationResult"] = None

    def __post_init__(self) -> None:
        missing = [
            name
            for name in TRANSITION_PLAN_REQUIRED_ITEMS
            if getattr(self, name, None) in (None, (), [])
        ]
        if missing:
            raise IncompletePlan(missing)
        self.postconditions = tuple(self.postconditions or ())
        if not isinstance(self.clock, TransitionClock):
            raise TransitionError("a transition plan must carry the supplied clock (45.3)")
        if self.rollback.checkpoint_id != self.checkpoint.checkpoint_id:
            raise TransitionError(
                f"rollback plan {self.rollback.rollback_id!r} targets checkpoint "
                f"{self.rollback.checkpoint_id!r} but the plan checkpoints "
                f"{self.checkpoint.checkpoint_id!r}; a rollback to a checkpoint that "
                "was never taken is not a rollback (32.5)"
            )
        if self.checkpoint.configuration_id != self.source_config.config_id:
            raise TransitionError(
                "the checkpoint must capture the source configuration; rollback "
                "returns the system to where it started (32.5)"
            )

    @property
    def missing_items(self) -> Tuple[str, ...]:
        return tuple(
            name
            for name in TRANSITION_PLAN_REQUIRED_ITEMS
            if getattr(self, name, None) in (None, (), [])
        )

    @property
    def complete(self) -> bool:
        return not self.missing_items

    def to_canonical(self) -> dict:
        record: dict = {
            "plan_id": self.plan_id,
            "status": self.status,
            "source_config": self.source_config.to_canonical(),
            "target_config": self.target_config.to_canonical(),
            "context_fingerprint": self.context_fingerprint,
            "clock": self.clock.to_canonical(),
            "authenticated_telemetry": self.authenticated_telemetry.to_canonical(),
            "telemetry_freshness": self.telemetry_freshness.to_canonical(),
            "phase_guard": self.phase_guard.to_canonical(),
            "margin": self.margin.to_canonical(),
            "hysteresis": self.hysteresis.to_canonical(),
            "dwell": self.dwell.to_canonical(),
            "expected_benefit": self.expected_benefit.to_canonical(),
            "total_cost": self.total_cost.to_canonical(),
            "quiescence": self.quiescence.to_canonical(),
            "checkpoint": self.checkpoint.to_canonical(),
            "state_conversion": self.state_conversion.to_canonical(),
            "postconditions": [p.to_canonical() for p in self.postconditions],
            "rollback": self.rollback.to_canonical(),
            "audit": self.audit.to_canonical(),
            "gates": self.gates.to_canonical(),
        }
        if self.envelope is not None:
            record["envelope"] = self.envelope.to_canonical()
        if self.certificate is not None:
            record["certificate"] = self.certificate.to_canonical()
        if self.safety_case is not None:
            record["safety_case"] = self.safety_case.to_canonical()
        return record

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())


def context_fingerprint_of(
    source_config: Configuration,
    target_config: Configuration,
    envelope: Optional[CertifiedEnvelope],
) -> str:
    """The context a plan was made for (32.5 context mismatch)."""
    return content_hash(
        {
            "source_config": source_config.fingerprint(),
            "target_config": target_config.fingerprint(),
            "envelope": envelope.fingerprint() if envelope is not None else "",
        }
    )


def plan_transition(
    source_config: Configuration,
    target_config: Configuration,
    *,
    envelope: Optional[CertifiedEnvelope],
    telemetry: TelemetrySample,
    clock: TransitionClock,
) -> TransitionPlan:
    """Build a complete 32.5 transition plan, or refuse.

    Refuses before building on the conditions that make the *inputs*
    untrustworthy: an unresolved clock (32.5), unauthenticated telemetry
    (32.5), and telemetry stale against the supplied monotonic clock
    (32.5, 45.6).  A plan derived from stale readings would be a plan for a
    system state that no longer exists, so it is not produced at all.

    The trigger gates -- phase guard, margin, hysteresis, dwell, expected
    benefit -- are *evaluated* here and recorded in ``plan.gates``, not
    raised.  An L0 deployment must be able to see a recommendation together
    with the reason it is not currently actionable; :func:`authorize`
    refuses on any unsatisfied gate.
    """
    if not isinstance(source_config, Configuration) or not isinstance(
        target_config, Configuration
    ):
        raise TransitionError("plan_transition requires Configuration endpoints")
    if source_config.config_id == target_config.config_id:
        raise TransitionError(
            "source and target configurations are identical; there is no transition "
            "to plan"
        )
    if not isinstance(telemetry, TelemetrySample):
        raise TransitionError("plan_transition requires a TelemetrySample (32.5)")

    requirements = target_config.entry_requirements
    if requirements is None:
        raise IncompletePlan(
            [
                name
                for name in TRANSITION_PLAN_REQUIRED_ITEMS
                if name not in ("authenticated_telemetry", "checkpoint")
            ]
        )

    clock_refusal = _clock_refusal(clock, source_config.config_id)
    if clock_refusal is not None:
        raise TransitionRefused([clock_refusal])

    refusals = telemetry_refusals(
        telemetry, requirements.telemetry_freshness, clock, subject=telemetry.source_id
    )
    if refusals:
        raise TransitionRefused(refusals)

    checkpoint = Checkpoint(
        checkpoint_id=f"ckpt-{source_config.config_id}",
        configuration_id=source_config.config_id,
        configuration_hash=source_config.fingerprint(),
        captured_at_ticks=int(clock.monotonic_ticks),
    )
    rollback = replace(requirements.rollback, checkpoint_id=checkpoint.checkpoint_id)

    conversion = requirements.state_conversion
    if conversion is None:
        conversion = _derive_state_conversion(source_config, target_config)

    gate_refusals: List[Refusal] = []
    for gate in (requirements.phase_guard, requirements.margin, requirements.hysteresis,
                 requirements.dwell):
        refusal = gate.evaluate(telemetry)
        if refusal is not None:
            gate_refusals.append(refusal)
    if not requirements.expected_benefit.positive:
        gate_refusals.append(
            Refusal(
                reason=RefusalReason.NO_EXPECTED_BENEFIT,
                detail=(
                    f"the declared expected benefit is {requirements.expected_benefit.value}; "
                    "a transition with no positive expected benefit pays its cost for "
                    "nothing (32.5)"
                ),
                subject=requirements.expected_benefit.quantity,
            )
        )
    if conversion.affects_consistency and not rollback.restores_consistency:
        gate_refusals.append(
            Refusal(
                reason=RefusalReason.MISSING_ROLLBACK,
                detail=(
                    f"the state conversion moves {conversion.moved_fraction} of the "
                    "logical space, so consistency may be affected, and the declared "
                    "rollback does not restore consistency (32.5)"
                ),
                subject=rollback.rollback_id,
            )
        )

    return TransitionPlan(
        plan_id=_new_id("plan"),
        source_config=source_config,
        target_config=target_config,
        clock=clock,
        context_fingerprint=context_fingerprint_of(source_config, target_config, envelope),
        authenticated_telemetry=telemetry,
        telemetry_freshness=requirements.telemetry_freshness,
        phase_guard=requirements.phase_guard,
        margin=requirements.margin,
        hysteresis=requirements.hysteresis,
        dwell=requirements.dwell,
        expected_benefit=requirements.expected_benefit,
        total_cost=requirements.total_cost,
        quiescence=requirements.quiescence,
        checkpoint=checkpoint,
        state_conversion=conversion,
        postconditions=requirements.postconditions,
        rollback=rollback,
        audit=requirements.audit,
        envelope=envelope,
        certificate=requirements.certificate,
        safety_case=requirements.safety_case,
        gates=GateReport(refusals=tuple(gate_refusals)),
    )


def _derive_state_conversion(
    source_config: Configuration, target_config: Configuration
) -> StateConversionPlan:
    """Derive the conversion plan from declared partition counts via crg-convert.

    Uses the OID-CRG-004 assignment so the retained fraction in a transition
    plan is the exact optimum, not the ``min/max`` closed form that is wrong
    on non-nested partitions (31.2).
    """
    if source_config.partition_count is None or target_config.partition_count is None:
        raise IncompletePlan(["state_conversion"])
    from crg_convert.layout import Layout, convert  # local import: optional dependency path

    record = convert(
        Layout(source_config.partition_count, label=source_config.layout_label or "source"),
        Layout(target_config.partition_count, label=target_config.layout_label or "target"),
    )
    return StateConversionPlan.from_conversion_record(
        record,
        source_layout=source_config.layout_label or source_config.config_id,
        target_layout=target_config.layout_label or target_config.config_id,
        rollback_behavior="restore from checkpoint",
    )


# --------------------------------------------------------------------------
# authorization (32.4)
# --------------------------------------------------------------------------


@dataclass(frozen=True)
class AuthorizationResult:
    """The outcome of authorizing a plan at a maturity level (32.4)."""

    authorized: bool
    permitted_action: str
    level: str
    plan_id: str
    approver_identity: Optional[str] = None
    refusals: Tuple[Refusal, ...] = ()
    envelope_membership: Optional[EnvelopeMembership] = None
    safety_case_id: Optional[str] = None
    basis: str = ""

    @property
    def may_execute(self) -> bool:
        return self.authorized and self.permitted_action == PermittedAction.EXECUTE

    @property
    def reasons(self) -> Tuple[str, ...]:
        return tuple(r.reason for r in self.refusals)

    def to_canonical(self) -> dict:
        record: dict = {
            "authorized": self.authorized,
            "permitted_action": self.permitted_action,
            "may_execute": self.may_execute,
            "level": self.level,
            "plan_id": self.plan_id,
            "refusals": [r.to_canonical() for r in self.refusals],
        }
        if self.approver_identity:
            record["approver_identity"] = self.approver_identity
        if self.envelope_membership is not None:
            record["envelope_membership"] = self.envelope_membership.to_canonical()
        if self.safety_case_id:
            record["safety_case_id"] = self.safety_case_id
        if self.basis:
            record["basis"] = self.basis
        return record


def authorize(
    plan: TransitionPlan, *, level: str, approver: Optional[Approver] = None
) -> AuthorizationResult:
    """Authorize a plan at a maturity level (32.4), attaching the result.

    Returns rather than raises, because a refusal to authorize is a normal
    and reportable outcome -- an L0 deployment expects one on every plan.
    The result is attached to ``plan.authorization``; :func:`execute` reads
    it there and refuses anything that does not permit execution.

    Level by level:

    * **L0** authorizes ``RECOMMEND_ONLY``.  The gate report is included so
      the recommendation carries its own caveats, and no approver is
      consulted, because there is nothing to approve.
    * **L1** requires a named :class:`Approver` whose capability permits L1
      and ``AUTHORIZE_TRANSITION`` and has not expired against the plan's
      supplied clock.
    * **L2** additionally requires the declared safety-case opt-in, a valid
      certificate over the envelope, and membership of the transition in
      that envelope.
    * **L3** additionally requires domain-specific safety controls declared
      present and verified.
    """
    if not isinstance(plan, TransitionPlan):
        raise TransitionError(f"authorize expects a TransitionPlan, got {type(plan)!r}")
    MaturityLevel.check(level)
    refusals: List[Refusal] = []
    membership: Optional[EnvelopeMembership] = None

    clock_refusal = _clock_refusal(plan.clock, plan.plan_id)
    if clock_refusal is not None:
        refusals.append(clock_refusal)

    # -- L0: recommendation only, and that is the whole permission ------
    if level == MaturityLevel.L0_OFFLINE:
        result = AuthorizationResult(
            authorized=True,
            permitted_action=PermittedAction.RECOMMEND_ONLY,
            level=level,
            plan_id=plan.plan_id,
            refusals=plan.gates.refusals,
            basis=(
                "specification 32.4 L0: CRG recommends a transition but does not "
                "execute it.  This authorization permits reporting the plan and "
                "nothing else; execute() refuses it"
            ),
        )
        plan.authorization = result
        plan.status = TransitionStatus.PLANNED
        return result

    # -- levels above the initial release require explicit opt-in -------
    if level in MaturityLevel.REQUIRE_OPT_IN:
        case = plan.safety_case
        if case is None or not case.permits(level):
            refusals.append(
                Refusal(
                    reason=RefusalReason.SAFETY_CASE_NOT_DECLARED,
                    detail=(
                        f"{level} is above the initial production release, which 32.4 "
                        "says SHOULD target L0 and L1.  It requires an explicit opt-in: "
                        "a SafetyCase on the plan whose opt_in_levels name this level.  "
                        + (
                            "No safety case was declared"
                            if case is None
                            else f"the declared case {case.case_id!r} opts in to "
                            f"{list(case.opt_in_levels)}"
                        )
                    ),
                    subject=plan.plan_id,
                )
            )
        if level in MaturityLevel.REQUIRES_SAFETY_CONTROLS:
            if case is None or not case.controls_declared_present:
                refusals.append(
                    Refusal(
                        reason=RefusalReason.SAFETY_CONTROLS_NOT_DECLARED,
                        detail=(
                            "32.4 grants L3 only 'under domain-specific safety "
                            "controls'; the safety case must declare non-empty "
                            "domain_safety_controls and record them as verified.  An "
                            "unverified control is a plan, not a control"
                        ),
                        subject=plan.plan_id,
                    )
                )

    # -- L2: only within a previously certified envelope ----------------
    if level in MaturityLevel.REQUIRES_CERTIFIED_ENVELOPE:
        if plan.envelope is None:
            refusals.append(
                Refusal(
                    reason=RefusalReason.OUTSIDE_CERTIFIED_ENVELOPE,
                    detail=(
                        "no certified envelope was supplied; 32.4 L2 permits the system "
                        "to transition only within a previously certified envelope, and "
                        "the absence of one is outside every envelope"
                    ),
                    subject=plan.plan_id,
                )
            )
        else:
            certificate = plan.certificate
            if certificate is None:
                refusals.append(
                    Refusal(
                        reason=RefusalReason.INVALID_CERTIFICATE,
                        detail=(
                            f"envelope {plan.envelope.envelope_id!r} is presented without "
                            "a certificate; an uncertified envelope is not a previously "
                            "certified one (32.4, 32.5)"
                        ),
                        subject=plan.envelope.envelope_id,
                    )
                )
            else:
                certificate_refusal = certificate.verify(
                    plan.envelope.fingerprint(), plan.clock
                )
                if certificate_refusal is not None:
                    refusals.append(certificate_refusal)
            membership = plan.envelope.contains(plan.source_config, plan.target_config)
            if not membership.inside:
                refusals.append(
                    Refusal(
                        reason=RefusalReason.OUTSIDE_CERTIFIED_ENVELOPE,
                        detail=(
                            "the transition is outside the previously certified "
                            f"envelope {plan.envelope.envelope_id!r}: "
                            + "; ".join(membership.violations)
                        ),
                        subject=plan.envelope.envelope_id,
                    )
                )

    # -- an operator, where the level names one -------------------------
    approver_identity: Optional[str] = None
    if level in MaturityLevel.REQUIRES_APPROVER:
        if approver is None:
            refusals.append(
                Refusal(
                    reason=RefusalReason.APPROVER_REQUIRED,
                    detail=(
                        "32.4 L1: an authorized operator approves a generated "
                        "transition plan.  No approver was supplied, and an "
                        "unapproved plan is not a supervised transition"
                    ),
                    subject=plan.plan_id,
                )
            )
        else:
            approver_identity = approver.identity
            capability_refusal = approver.capability.refusal(
                level=level, action=AUTHORIZE_TRANSITION, clock=plan.clock
            )
            if capability_refusal is not None:
                refusals.append(capability_refusal)
    elif approver is not None:
        approver_identity = approver.identity
        capability_refusal = approver.capability.refusal(
            level=level, action=AUTHORIZE_TRANSITION, clock=plan.clock
        )
        if capability_refusal is not None:
            refusals.append(capability_refusal)

    # -- trigger gates, and the missing-rollback check they carry -------
    # ``plan.gates`` already holds the phase-guard, margin, hysteresis,
    # dwell, expected-benefit and missing-rollback findings computed at
    # planning time against the plan's telemetry.  They are re-reported
    # here rather than re-evaluated, so a gate cannot be satisfied by
    # different telemetry than the plan was built from.
    refusals.extend(plan.gates.refusals)

    authorized = not refusals
    result = AuthorizationResult(
        authorized=authorized,
        permitted_action=PermittedAction.EXECUTE if authorized else PermittedAction.NONE,
        level=level,
        plan_id=plan.plan_id,
        approver_identity=approver_identity,
        refusals=tuple(refusals),
        envelope_membership=membership,
        safety_case_id=plan.safety_case.case_id if plan.safety_case else None,
        basis=MaturityLevel.DESCRIPTION[level],
    )
    plan.authorization = result
    plan.status = TransitionStatus.AUTHORIZED if authorized else TransitionStatus.REFUSED
    return result


# --------------------------------------------------------------------------
# execution and rollback
# --------------------------------------------------------------------------


class TransitionExecutor:
    """The interface a domain adapter implements to carry out a transition.

    CRG is domain neutral (3.3): this package decides *whether* a
    transition may proceed and *what* must hold afterwards, and knows
    nothing about how to drain a queue or repartition a cache.  Every
    method here is the domain's.
    """

    def context_fingerprint(self) -> str:
        """The live context digest, compared against the plan's (32.5)."""
        raise NotImplementedError

    def quiesce(self, quiescence: QuiescencePlan) -> bool:
        raise NotImplementedError

    def capture_checkpoint(self, checkpoint: Checkpoint) -> str:
        """Capture and return an opaque restore token."""
        raise NotImplementedError

    def convert_state(self, conversion: StateConversionPlan) -> bool:
        raise NotImplementedError

    def apply_configuration(self, config: Configuration) -> str:
        """Apply the configuration and return the identity now active."""
        raise NotImplementedError

    def observe(self) -> TelemetrySample:
        """Post-transition telemetry for postcondition evaluation."""
        raise NotImplementedError

    def restore(self, checkpoint: Checkpoint, token: str) -> str:
        """Restore the checkpoint and return the identity now active."""
        raise NotImplementedError


_EXECUTOR_METHODS = (
    "context_fingerprint",
    "quiesce",
    "capture_checkpoint",
    "convert_state",
    "apply_configuration",
    "observe",
    "restore",
)


@dataclass(frozen=True)
class TransitionStep:
    """One executed step, stamped on the supplied monotonic clock."""

    name: str
    at_ticks: int
    ok: bool
    detail: str = ""

    def to_canonical(self) -> dict:
        record = {"name": self.name, "at_ticks": int(self.at_ticks), "ok": self.ok}
        if self.detail:
            record["detail"] = self.detail
        return record


@dataclass
class TransitionRecord:
    """The audit record of an attempted transition (32.5).

    ``final_config_id`` is where the system actually ended up.  For a
    rolled-back transition it is the source configuration, and
    ``returned_to_source`` says so directly, so a reader does not have to
    infer recovery from the absence of an error.
    """

    record_id: str
    plan_id: str
    status: str
    level: str
    source_config_id: str
    target_config_id: str
    final_config_id: str
    started_ticks: int
    finished_ticks: int
    checkpoint: Checkpoint
    rollback_plan: RollbackPlan
    audit_spec: AuditSpec
    clock: TransitionClock
    checkpoint_token: str = ""
    steps: Tuple[TransitionStep, ...] = ()
    postcondition_results: Tuple[PostconditionResult, ...] = ()
    refusals: Tuple[Refusal, ...] = ()
    audit: Tuple[AuditEntry, ...] = ()
    rollback_of: Optional[str] = None
    approver_identity: Optional[str] = None

    def __post_init__(self) -> None:
        if self.status not in TransitionStatus.ALL:
            raise TransitionError(f"unknown transition status {self.status!r}")

    @property
    def returned_to_source(self) -> bool:
        return self.final_config_id == self.source_config_id

    @property
    def rolled_back(self) -> bool:
        return self.status == TransitionStatus.ROLLED_BACK

    @property
    def reasons(self) -> Tuple[str, ...]:
        return tuple(r.reason for r in self.refusals)

    @property
    def failed_postconditions(self) -> Tuple[PostconditionResult, ...]:
        return tuple(p for p in self.postcondition_results if not p.satisfied)

    def to_canonical(self) -> dict:
        record: dict = {
            "record_id": self.record_id,
            "plan_id": self.plan_id,
            "status": self.status,
            "level": self.level,
            "source_config_id": self.source_config_id,
            "target_config_id": self.target_config_id,
            "final_config_id": self.final_config_id,
            "returned_to_source": self.returned_to_source,
            "started_ticks": int(self.started_ticks),
            "finished_ticks": int(self.finished_ticks),
            "checkpoint": self.checkpoint.to_canonical(),
            "rollback_plan": self.rollback_plan.to_canonical(),
            "audit_spec": self.audit_spec.to_canonical(),
            "clock": self.clock.to_canonical(),
            "steps": [s.to_canonical() for s in self.steps],
            "postcondition_results": [p.to_canonical() for p in self.postcondition_results],
            "refusals": [r.to_canonical() for r in self.refusals],
            "audit": [a.to_canonical() for a in self.audit],
        }
        if self.checkpoint_token:
            record["checkpoint_token"] = self.checkpoint_token
        if self.rollback_of:
            record["rollback_of"] = self.rollback_of
        if self.approver_identity:
            record["approver_identity"] = self.approver_identity
        return record

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())


class _Audit:
    """Append-only audit accumulator stamped on the supplied clock."""

    def __init__(self, at_ticks: int) -> None:
        self._entries: List[AuditEntry] = []
        self._at = int(at_ticks)

    def append(self, event: str, detail: str = "") -> None:
        self._entries.append(
            AuditEntry(
                sequence=len(self._entries) + 1, at_ticks=self._at, event=event, detail=detail
            )
        )

    @property
    def entries(self) -> Tuple[AuditEntry, ...]:
        return tuple(self._entries)


def _check_executor(executor: Any) -> None:
    missing = [name for name in _EXECUTOR_METHODS if not callable(getattr(executor, name, None))]
    if missing:
        raise TransitionError(
            f"the executor does not implement the TransitionExecutor interface; "
            f"missing: {missing}"
        )


def execute(
    plan: TransitionPlan, *, executor: Any, clock: TransitionClock
) -> TransitionRecord:
    """Execute an authorized plan against a domain executor, or refuse.

    Fail-closed checks run first and in this order: authorization (which
    carries the L0 refusal and every level rule), unresolved clock,
    telemetry freshness re-checked against the *execution* clock, and
    context match.  Freshness is deliberately re-checked: a plan authorized
    ten seconds ago against telemetry that has since aged out is exactly
    the case 32.5 names, and an authorization is not a licence to act on
    old readings.

    After the configuration is applied, every postcondition is evaluated
    against fresh telemetry.  A single failure triggers :func:`rollback` to
    the checkpoint, and the record this function returns is the rollback
    record: status ``ROLLED_BACK``, ``final_config_id`` the source, and the
    failed postconditions retained so the operator can see what went wrong.
    An executor that raises is treated the same way -- a fault mid-flight
    is precisely when the checkpoint earns its keep.
    """
    if not isinstance(plan, TransitionPlan):
        raise TransitionError(f"execute expects a TransitionPlan, got {type(plan)!r}")
    _check_executor(executor)

    authorization = plan.authorization
    if authorization is None:
        raise TransitionRefused(
            [
                Refusal(
                    reason=RefusalReason.NOT_AUTHORIZED,
                    detail=(
                        "the plan has not been authorized; call authorize() first.  A "
                        "heuristic recommendation may not silently authorize a runtime "
                        "transition (spec 5.3)"
                    ),
                    subject=plan.plan_id,
                )
            ]
        )
    if authorization.permitted_action == PermittedAction.RECOMMEND_ONLY:
        raise TransitionRefused(
            [
                Refusal(
                    reason=RefusalReason.LEVEL_MAY_NOT_EXECUTE,
                    detail=(
                        f"{authorization.level} authorizes "
                        f"{PermittedAction.RECOMMEND_ONLY} only.  Specification 32.4: at "
                        "L0 'CRG recommends a transition but does not execute it.'  "
                        "Raise the deployment to L1 with an authorized operator to act "
                        "on this plan"
                    ),
                    subject=plan.plan_id,
                )
            ]
        )
    if not authorization.may_execute:
        raise TransitionRefused(
            authorization.refusals
            or (
                Refusal(
                    reason=RefusalReason.NOT_AUTHORIZED,
                    detail="the authorization does not permit execution",
                    subject=plan.plan_id,
                ),
            )
        )

    clock_refusal = _clock_refusal(clock, plan.plan_id)
    if clock_refusal is not None:
        raise TransitionRefused([clock_refusal])

    refusals = telemetry_refusals(
        plan.authenticated_telemetry,
        plan.telemetry_freshness,
        clock,
        subject=plan.authenticated_telemetry.source_id,
    )
    if refusals:
        raise TransitionRefused(refusals)

    live_context = executor.context_fingerprint()
    if live_context != plan.context_fingerprint:
        raise TransitionRefused(
            [
                Refusal(
                    reason=RefusalReason.CONTEXT_MISMATCH,
                    detail=(
                        f"the executor reports context {live_context!r} but the plan was "
                        f"built for {plan.context_fingerprint!r}; the plan's guards, "
                        "margins and envelope were certified against a different system "
                        "state (32.5)"
                    ),
                    subject=plan.plan_id,
                )
            ]
        )

    started = int(clock.monotonic_ticks)
    audit = _Audit(started)
    audit.append("AUTHORIZED", f"{authorization.level} by {authorization.approver_identity}")
    steps: List[TransitionStep] = []
    checkpoint_token = ""
    postcondition_results: Tuple[PostconditionResult, ...] = ()
    execution_refusals: List[Refusal] = []

    def record_of(status: str, final_config_id: str) -> TransitionRecord:
        return TransitionRecord(
            record_id=_new_id("transition"),
            plan_id=plan.plan_id,
            status=status,
            level=authorization.level,
            source_config_id=plan.source_config.config_id,
            target_config_id=plan.target_config.config_id,
            final_config_id=final_config_id,
            started_ticks=started,
            finished_ticks=int(clock.monotonic_ticks),
            checkpoint=plan.checkpoint,
            rollback_plan=plan.rollback,
            audit_spec=plan.audit,
            clock=clock,
            checkpoint_token=checkpoint_token,
            steps=tuple(steps),
            postcondition_results=postcondition_results,
            refusals=tuple(execution_refusals),
            audit=audit.entries,
            approver_identity=authorization.approver_identity,
        )

    try:
        if plan.quiescence.required:
            quiesced = bool(executor.quiesce(plan.quiescence))
            steps.append(TransitionStep("QUIESCE", started, quiesced))
            audit.append("QUIESCE", plan.quiescence.mode)
            if not quiesced:
                execution_refusals.append(
                    Refusal(
                        reason=RefusalReason.QUIESCENCE_NOT_REACHED,
                        detail=(
                            f"the executor did not reach quiescence in mode "
                            f"{plan.quiescence.mode!r}; converting state that is still "
                            "in flight is what quiescence exists to prevent (32.5)"
                        ),
                        subject=plan.plan_id,
                    )
                )
                plan.status = TransitionStatus.REFUSED
                return record_of(TransitionStatus.REFUSED, plan.source_config.config_id)

        checkpoint_token = str(executor.capture_checkpoint(plan.checkpoint))
        steps.append(TransitionStep("CHECKPOINT", started, bool(checkpoint_token)))
        audit.append("CHECKPOINT", plan.checkpoint.checkpoint_id)
        if not checkpoint_token:
            execution_refusals.append(
                Refusal(
                    reason=RefusalReason.CHECKPOINT_FAILED,
                    detail=(
                        "the executor returned no restore token; without a checkpoint "
                        "there is no rollback, and 32.5 fails closed on missing "
                        "rollback where consistency may be affected"
                    ),
                    subject=plan.checkpoint.checkpoint_id,
                )
            )
            plan.status = TransitionStatus.REFUSED
            return record_of(TransitionStatus.REFUSED, plan.source_config.config_id)

        converted = bool(executor.convert_state(plan.state_conversion))
        steps.append(TransitionStep("CONVERT_STATE", started, converted))
        audit.append("CONVERT_STATE", plan.state_conversion.conversion_id)

        active = str(executor.apply_configuration(plan.target_config))
        steps.append(TransitionStep("APPLY", started, active == plan.target_config.config_id))
        audit.append("APPLY", active)

        observed = executor.observe()
        if not isinstance(observed, TelemetrySample):
            raise TransitionError("executor.observe() must return a TelemetrySample")
        steps.append(TransitionStep("OBSERVE", started, True))
        postcondition_results = tuple(p.evaluate(observed) for p in plan.postconditions)
        failed = [p for p in postcondition_results if not p.satisfied]
        if failed:
            execution_refusals.append(
                Refusal(
                    reason=RefusalReason.FAILED_POSTCONDITION,
                    detail=(
                        "post-transition telemetry does not satisfy "
                        + ", ".join(f"{p.condition_id} ({p.detail})" for p in failed)
                        + "; the transition is undone rather than left in place (32.5)"
                    ),
                    subject=plan.plan_id,
                )
            )
            audit.append("POSTCONDITION_FAILED", ", ".join(p.condition_id for p in failed))
            attempted = record_of(TransitionStatus.REFUSED, active)
            plan.status = TransitionStatus.REFUSED
            return rollback(attempted, executor=executor)

    except TransitionRefused:
        raise
    except Exception as exc:  # noqa: BLE001 - a fault mid-flight is why we checkpoint
        execution_refusals.append(
            Refusal(
                reason=RefusalReason.EXECUTION_FAULT,
                detail=(
                    f"the executor raised {type(exc).__name__}: {exc}; the transition is "
                    "rolled back to the checkpoint rather than left half-applied"
                ),
                subject=plan.plan_id,
            )
        )
        audit.append("EXECUTION_FAULT", f"{type(exc).__name__}: {exc}")
        attempted = record_of(TransitionStatus.REFUSED, plan.target_config.config_id)
        plan.status = TransitionStatus.REFUSED
        if not checkpoint_token:
            return attempted
        return rollback(attempted, executor=executor)

    audit.append("COMPLETED", plan.target_config.config_id)
    plan.status = TransitionStatus.COMPLETED
    return record_of(TransitionStatus.COMPLETED, plan.target_config.config_id)


def rollback(record: TransitionRecord, *, executor: Any) -> TransitionRecord:
    """Return the system to the checkpointed source configuration (32.5).

    Restores through the executor and then *verifies* the outcome: the
    configuration the executor reports active must be the source
    configuration the checkpoint captured.  If it is not, the returned
    record is ``ROLLBACK_FAILED`` with a distinct refusal reason -- an
    unverified rollback claim is the one thing worse than no rollback,
    because it reports a recovery that did not happen.

    Returns a new record rather than mutating the attempted one, so the
    audit retains both the attempt and the recovery (6.4).
    """
    if not isinstance(record, TransitionRecord):
        raise TransitionError(f"rollback expects a TransitionRecord, got {type(record)!r}")
    _check_executor(executor)
    if not record.checkpoint_token:
        raise TransitionRefused(
            [
                Refusal(
                    reason=RefusalReason.MISSING_ROLLBACK,
                    detail=(
                        f"record {record.record_id!r} holds no checkpoint token; there "
                        "is nothing to restore from and consistency may be affected "
                        "(32.5)"
                    ),
                    subject=record.record_id,
                )
            ]
        )

    at_ticks = int(record.clock.monotonic_ticks or record.finished_ticks)
    audit = _Audit(at_ticks)
    for entry in record.audit:
        audit.append(entry.event, entry.detail)
    audit.append("ROLLBACK_BEGIN", record.rollback_plan.rollback_id)

    steps = list(record.steps)
    refusals = list(record.refusals)
    try:
        active = str(executor.restore(record.checkpoint, record.checkpoint_token))
    except Exception as exc:  # noqa: BLE001
        steps.append(TransitionStep("ROLLBACK", at_ticks, False, f"{type(exc).__name__}: {exc}"))
        refusals.append(
            Refusal(
                reason=RefusalReason.ROLLBACK_FAILED,
                detail=(
                    f"the executor raised {type(exc).__name__} during restore: {exc}.  "
                    "The system is in an undetermined configuration and requires "
                    "manual intervention"
                ),
                subject=record.rollback_plan.rollback_id,
            )
        )
        audit.append("ROLLBACK_FAILED", f"{type(exc).__name__}: {exc}")
        return replace(
            record,
            record_id=_new_id("transition"),
            status=TransitionStatus.ROLLBACK_FAILED,
            final_config_id="UNDETERMINED",
            steps=tuple(steps),
            refusals=tuple(refusals),
            audit=audit.entries,
            rollback_of=record.record_id,
        )

    restored = active == record.source_config_id
    steps.append(
        TransitionStep(
            "ROLLBACK",
            at_ticks,
            restored,
            f"restored to {active!r}",
        )
    )
    if not restored:
        refusals.append(
            Refusal(
                reason=RefusalReason.ROLLBACK_FAILED,
                detail=(
                    f"the executor reports configuration {active!r} active after "
                    f"restore, but the checkpoint captured {record.source_config_id!r}; "
                    "the rollback is not verified and is not reported as successful"
                ),
                subject=record.rollback_plan.rollback_id,
            )
        )
        audit.append("ROLLBACK_FAILED", f"active={active}")
        return replace(
            record,
            record_id=_new_id("transition"),
            status=TransitionStatus.ROLLBACK_FAILED,
            final_config_id=active,
            steps=tuple(steps),
            refusals=tuple(refusals),
            audit=audit.entries,
            rollback_of=record.record_id,
        )

    audit.append("ROLLED_BACK", record.source_config_id)
    return replace(
        record,
        record_id=_new_id("transition"),
        status=TransitionStatus.ROLLED_BACK,
        final_config_id=record.source_config_id,
        steps=tuple(steps),
        refusals=tuple(refusals),
        audit=audit.entries,
        rollback_of=record.record_id,
    )
