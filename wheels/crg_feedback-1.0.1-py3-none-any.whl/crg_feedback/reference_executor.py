"""Deterministic in-memory transition executor for integration and pilot rehearsal.

This is a reference adapter for exercising the public :mod:`crg_feedback`
transition boundary.  It never controls physical equipment and MUST NOT be used
as a production safety case.  Its value is narrower and concrete: applications
can rehearse supervised execution, checkpoints, postcondition failure, and
verified rollback without replacing the domain-neutral transition kernel with a
mock that silently skips a required method.

The executor reads no clock and invents no telemetry.  The caller supplies the
post-transition :class:`~crg_feedback.transition.TelemetrySample`, just as a
real adapter would supply a reading from its authenticated telemetry channel.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Tuple

from crg_model.canonical import content_hash

from .transition import (
    Checkpoint,
    Configuration,
    QuiescencePlan,
    StateConversionPlan,
    TelemetrySample,
    TransitionError,
    TransitionExecutor,
)

__all__ = ["ReferenceTransitionExecutor"]


class ReferenceTransitionExecutor(TransitionExecutor):
    """Stateful, deterministic implementation of the seven executor methods.

    Failure switches are explicit constructor inputs and are recorded by the
    operation log.  They exist to exercise incident and rollback paths; no
    random failure or machine state can change an outcome.
    """

    def __init__(
        self,
        *,
        context_fingerprint: str,
        active_configuration: Configuration,
        observation: TelemetrySample,
        quiescence_succeeds: bool = True,
        conversion_succeeds: bool = True,
        apply_error: Optional[str] = None,
        restore_succeeds: bool = True,
    ) -> None:
        if not context_fingerprint:
            raise TransitionError("a reference executor requires a live context fingerprint")
        if not isinstance(active_configuration, Configuration):
            raise TransitionError("active_configuration must be a Configuration")
        if not isinstance(observation, TelemetrySample):
            raise TransitionError("observation must be a TelemetrySample")
        self._context = str(context_fingerprint)
        self._active = active_configuration
        self._observation = observation
        self._quiescence_succeeds = bool(quiescence_succeeds)
        self._conversion_succeeds = bool(conversion_succeeds)
        self._apply_error = str(apply_error) if apply_error else None
        self._restore_succeeds = bool(restore_succeeds)
        self._snapshots: Dict[str, Configuration] = {}
        self._operations: List[Tuple[str, str]] = []

    @property
    def active_configuration_id(self) -> str:
        return self._active.config_id

    @property
    def operations(self) -> Tuple[Tuple[str, str], ...]:
        """Immutable ordered operation evidence for integration assertions."""
        return tuple(self._operations)

    def context_fingerprint(self) -> str:
        self._operations.append(("CONTEXT", self._context))
        return self._context

    def quiesce(self, quiescence: QuiescencePlan) -> bool:
        self._operations.append(("QUIESCE", quiescence.mode))
        return self._quiescence_succeeds

    def capture_checkpoint(self, checkpoint: Checkpoint) -> str:
        if checkpoint.configuration_id != self._active.config_id:
            self._operations.append(("CHECKPOINT_REFUSED", checkpoint.checkpoint_id))
            return ""
        token = content_hash(
            {
                "executor_profile": "REFERENCE_IN_MEMORY_V1",
                "checkpoint": checkpoint.to_canonical(),
                "active_configuration": self._active.to_canonical(),
            }
        )
        self._snapshots[token] = self._active
        self._operations.append(("CHECKPOINT", token))
        return token

    def convert_state(self, conversion: StateConversionPlan) -> bool:
        self._operations.append(("CONVERT_STATE", conversion.conversion_id))
        return self._conversion_succeeds

    def apply_configuration(self, config: Configuration) -> str:
        self._operations.append(("APPLY", config.config_id))
        if self._apply_error:
            raise RuntimeError(self._apply_error)
        self._active = config
        return self._active.config_id

    def observe(self) -> TelemetrySample:
        self._operations.append(("OBSERVE", self._observation.source_id))
        return self._observation

    def restore(self, checkpoint: Checkpoint, token: str) -> str:
        self._operations.append(("RESTORE", checkpoint.checkpoint_id))
        snapshot = self._snapshots.get(token)
        if not self._restore_succeeds or snapshot is None:
            return self._active.config_id
        if snapshot.config_id != checkpoint.configuration_id:
            return self._active.config_id
        self._active = snapshot
        return self._active.config_id
