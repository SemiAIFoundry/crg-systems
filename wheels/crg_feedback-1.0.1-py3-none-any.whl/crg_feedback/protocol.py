"""The physical-evaluator protocol of specification 32.1.

Normative basis: master specification 32.1 (physical-evaluator protocol),
with 5.3 (evidence classes), 28.6 (illegal, infeasible, ungenerated,
unevaluated, and unsupported states remain distinct), and 6.6 (fail closed)
applied throughout.

Two prohibitions govern this module, and both are prohibitions on
*collapsing distinctions*:

**A tool failure MUST NOT be interpreted as physical infeasibility.**
``TOOL_FAILURE``, ``CONVERGENCE_FAILURE`` and ``PHYSICAL_INFEASIBILITY`` are
three responses with three downstream effects.  Only the third is a
statement about the world; the first two are statements about the
evaluator.  :data:`ResponseKind.ESTABLISHES_INFEASIBILITY` has exactly one
member, and :func:`feasibility_update` routes everything else away from
``INFEASIBLE``.  A failure returns the realization to ``UNEVALUATED`` --
an absence of knowledge, which is what a crashed solver produces.

**A compact-model success MUST NOT be represented as physical signoff.**
``MODELED_RESULT`` carries evidence class ``MODELED``; ``MEASURED_RESULT``
carries ``MEASURED``; the two are separate rows of the 5.3 table and there
is no path between them.  :func:`promote_evidence_class` refuses the
promotion by name, :func:`signoff_status` grants ``PHYSICAL_SIGNOFF`` only
to measurement, and :func:`register_witness` writes the response's own
evidence class into the realization bundle so the class survives the trip.

Eleven response kinds are defined because 32.1 lists eleven.  A caller who
only wants ten still gets eleven; ``UNCERTAINTY_RESULT`` is not optional
just because it is easy to fold into ``MODELED_RESULT``.
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from fractions import Fraction
from typing import Any, Callable, Dict, Mapping, Optional, Sequence, Tuple

from crg_model.canonical import content_hash
from crg_model.envelope import EvidenceClass
from crg_model.numeric import Exact, Interval
from crg_model.records import RealizationBundle, RealizationRecord

__all__ = [
    "ProtocolError",
    "EvaluatorRefusal",
    "ResponseKind",
    "FeasibilityEffect",
    "SignoffStatus",
    "REQUEST_REQUIRED_ITEMS",
    "EvaluatorRequest",
    "EvaluatorResponse",
    "FeasibilityUpdate",
    "WitnessRecord",
    "submit",
    "register_witness",
    "feasibility_update",
    "apply_feasibility",
    "signoff_status",
    "promote_evidence_class",
    "meets_requested_evidence_level",
]


class ProtocolError(ValueError):
    """Raised when the 32.1 protocol itself is violated.

    This is never raised to report a physical fact.  A refusal about the
    world is an :class:`EvaluatorResponse`, not an exception.
    """


class EvaluatorRefusal(ProtocolError):
    """Raised when a caller asks the module to erase a 32.1 distinction."""


# --------------------------------------------------------------------------
# 32.1 response kinds
# --------------------------------------------------------------------------


class ResponseKind:
    """The eleven responses an external evaluator may return (32.1).

    The class attributes below are not a taxonomy for reporting; they are
    the routing table.  Every downstream effect in this package is looked up
    here rather than re-derived, so there is one place where the
    tool-failure/infeasibility distinction lives.
    """

    CONSTRUCTIVE_WITNESS = "CONSTRUCTIVE_WITNESS"
    PHYSICAL_INFEASIBILITY = "PHYSICAL_INFEASIBILITY"
    PARTIAL_EVALUATION = "PARTIAL_EVALUATION"
    MODELED_RESULT = "MODELED_RESULT"
    MEASURED_RESULT = "MEASURED_RESULT"
    SENSITIVITY_RESULT = "SENSITIVITY_RESULT"
    UNCERTAINTY_RESULT = "UNCERTAINTY_RESULT"
    TOOL_FAILURE = "TOOL_FAILURE"
    CONVERGENCE_FAILURE = "CONVERGENCE_FAILURE"
    UNAUTHORIZED = "UNAUTHORIZED"
    UNSUPPORTED = "UNSUPPORTED"

    ALL = (
        CONSTRUCTIVE_WITNESS,
        PHYSICAL_INFEASIBILITY,
        PARTIAL_EVALUATION,
        MODELED_RESULT,
        MEASURED_RESULT,
        SENSITIVITY_RESULT,
        UNCERTAINTY_RESULT,
        TOOL_FAILURE,
        CONVERGENCE_FAILURE,
        UNAUTHORIZED,
        UNSUPPORTED,
    )

    #: The single kind that may mark a realization infeasible (32.1).
    #: A tool failure is not in this set and never will be.
    ESTABLISHES_INFEASIBILITY = frozenset({PHYSICAL_INFEASIBILITY})

    #: The evaluator broke, not the physics.  These carry no evidence and
    #: leave the realization UNEVALUATED (28.6).
    FAILURES = frozenset({TOOL_FAILURE, CONVERGENCE_FAILURE})

    #: The evaluator declined to answer.  Also not a physical fact.
    REFUSALS = frozenset({UNAUTHORIZED, UNSUPPORTED})

    #: Responses that carry evidence about the candidate.
    RESULTS = frozenset(
        {
            CONSTRUCTIVE_WITNESS,
            PHYSICAL_INFEASIBILITY,
            PARTIAL_EVALUATION,
            MODELED_RESULT,
            MEASURED_RESULT,
            SENSITIVITY_RESULT,
            UNCERTAINTY_RESULT,
        }
    )

    #: Responses from which a witness may be registered against a bundle.
    #: An infeasibility is evidence, but it is not a witness: there is
    #: nothing realizable to record.
    WITNESS_REGISTRABLE = frozenset(
        {CONSTRUCTIVE_WITNESS, MEASURED_RESULT, MODELED_RESULT, PARTIAL_EVALUATION}
    )

    #: Responses that reveal something about the physical world and may
    #: therefore seed challenger generation (32.3).  Deliberately excludes
    #: the failures: a crashed solver reveals no bottleneck.
    REVEALS_BOTTLENECK = frozenset(
        {
            PHYSICAL_INFEASIBILITY,
            MEASURED_RESULT,
            MODELED_RESULT,
            SENSITIVITY_RESULT,
            UNCERTAINTY_RESULT,
            PARTIAL_EVALUATION,
        }
    )

    @classmethod
    def check(cls, kind: str) -> str:
        if kind not in cls.ALL:
            raise ProtocolError(
                f"unknown evaluator response kind {kind!r}; specification 32.1 "
                f"defines exactly {len(cls.ALL)}: {', '.join(cls.ALL)}"
            )
        return kind


#: Evidence classes each response kind may carry (5.3 applied to 32.1).
#:
#: ``MODELED_RESULT`` admits ``MODELED`` and nothing else; ``MEASURED_RESULT``
#: admits ``MEASURED`` and nothing else.  That single-element pair is the
#: structural form of "a compact-model success MUST NOT be represented as
#: physical signoff".  A ``PHYSICAL_INFEASIBILITY`` may be established by
#: measurement or by model, so it admits several -- but it must say which,
#: and the class it names travels with the verdict.
ADMISSIBLE_EVIDENCE_CLASSES: Dict[str, frozenset] = {
    ResponseKind.CONSTRUCTIVE_WITNESS: frozenset({EvidenceClass.CONSTRUCTIVE}),
    ResponseKind.PHYSICAL_INFEASIBILITY: frozenset(
        {
            EvidenceClass.MEASURED,
            EvidenceClass.MODELED,
            EvidenceClass.BOUNDED,
            EvidenceClass.EXACT,
        }
    ),
    ResponseKind.PARTIAL_EVALUATION: frozenset(
        {EvidenceClass.MEASURED, EvidenceClass.MODELED, EvidenceClass.BOUNDED}
    ),
    ResponseKind.MODELED_RESULT: frozenset({EvidenceClass.MODELED}),
    ResponseKind.MEASURED_RESULT: frozenset({EvidenceClass.MEASURED}),
    ResponseKind.SENSITIVITY_RESULT: frozenset(
        {EvidenceClass.MEASURED, EvidenceClass.MODELED, EvidenceClass.BOUNDED}
    ),
    ResponseKind.UNCERTAINTY_RESULT: frozenset(
        {EvidenceClass.MEASURED, EvidenceClass.MODELED, EvidenceClass.BOUNDED}
    ),
    # The four non-results carry no evidence class at all.  ``None`` is the
    # honest value; a failure that reported an evidence class would be
    # asserting knowledge it does not have.
    ResponseKind.TOOL_FAILURE: frozenset(),
    ResponseKind.CONVERGENCE_FAILURE: frozenset(),
    ResponseKind.UNAUTHORIZED: frozenset(),
    ResponseKind.UNSUPPORTED: frozenset(),
}

#: The class assumed when a result declares none.  Absent from the failure
#: and refusal kinds by construction.
DEFAULT_EVIDENCE_CLASS: Dict[str, Optional[str]] = {
    ResponseKind.CONSTRUCTIVE_WITNESS: EvidenceClass.CONSTRUCTIVE,
    ResponseKind.MODELED_RESULT: EvidenceClass.MODELED,
    ResponseKind.MEASURED_RESULT: EvidenceClass.MEASURED,
}


class FeasibilityEffect:
    """What a response does to a realization's recorded legality (28.6).

    The five states of 28.6 stay five.  ``UNCHANGED`` is a sixth *effect*,
    not a sixth state: a measured objective value teaches nothing about
    legality and must not overwrite it in either direction.
    """

    LEGAL = "LEGAL"
    INFEASIBLE = "INFEASIBLE"
    UNEVALUATED = "UNEVALUATED"
    UNSUPPORTED = "UNSUPPORTED"
    UNCHANGED = "UNCHANGED"

    ALL = frozenset({LEGAL, INFEASIBLE, UNEVALUATED, UNSUPPORTED, UNCHANGED})

    #: Effects that write a determinate negative fact into the record.
    DETERMINATE_NEGATIVE = frozenset({INFEASIBLE})


#: Response kind -> feasibility effect.  The whole headline invariant of the
#: module is readable in this one table.
FEASIBILITY_EFFECT: Dict[str, str] = {
    ResponseKind.CONSTRUCTIVE_WITNESS: FeasibilityEffect.LEGAL,
    ResponseKind.PHYSICAL_INFEASIBILITY: FeasibilityEffect.INFEASIBLE,
    ResponseKind.PARTIAL_EVALUATION: FeasibilityEffect.UNEVALUATED,
    # A value is not a verdict.  An evaluator that finds a constraint
    # violated must say PHYSICAL_INFEASIBILITY and name the constraint.
    ResponseKind.MODELED_RESULT: FeasibilityEffect.UNCHANGED,
    ResponseKind.MEASURED_RESULT: FeasibilityEffect.UNCHANGED,
    ResponseKind.SENSITIVITY_RESULT: FeasibilityEffect.UNCHANGED,
    ResponseKind.UNCERTAINTY_RESULT: FeasibilityEffect.UNCHANGED,
    # The two failures.  Neither is a fact about the candidate.
    ResponseKind.TOOL_FAILURE: FeasibilityEffect.UNEVALUATED,
    ResponseKind.CONVERGENCE_FAILURE: FeasibilityEffect.UNEVALUATED,
    ResponseKind.UNAUTHORIZED: FeasibilityEffect.UNEVALUATED,
    ResponseKind.UNSUPPORTED: FeasibilityEffect.UNSUPPORTED,
}


class SignoffStatus:
    """What a response may be represented as (32.1, second prohibition)."""

    #: An identified physical measurement.  The only status that is signoff.
    PHYSICAL_SIGNOFF = "PHYSICAL_SIGNOFF"
    #: A compact, analytical, statistical, or simulation model succeeded.
    #: Useful, rankable, publishable -- and not signoff.
    MODEL_SUPPORTED = "MODEL_SUPPORTED"
    #: A realizable witness was exhibited.
    WITNESS_SUPPORTED = "WITNESS_SUPPORTED"
    #: Bounded evidence short of either.
    BOUND_SUPPORTED = "BOUND_SUPPORTED"
    #: Nothing was established.
    NOT_SUPPORTED = "NOT_SUPPORTED"

    ALL = frozenset(
        {PHYSICAL_SIGNOFF, MODEL_SUPPORTED, WITNESS_SUPPORTED, BOUND_SUPPORTED, NOT_SUPPORTED}
    )


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------


def _new_id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4()}"


def _reject_float(value: Any, what: str) -> Any:
    """Refuse binary floating point anywhere on the evaluator boundary (14.2)."""
    if isinstance(value, float):
        raise ProtocolError(
            f"{what} is a binary float; supply an exact representation "
            "(integer, decimal string, rational string, Exact, or Interval)"
        )
    if isinstance(value, Mapping):
        for key, item in value.items():
            _reject_float(item, f"{what}[{key!r}]")
    elif isinstance(value, (list, tuple, set, frozenset)):
        for index, item in enumerate(value):
            _reject_float(item, f"{what}[{index}]")
    return value


def _freeze_mapping(value: Optional[Mapping[str, Any]], what: str) -> Dict[str, Any]:
    if value is None:
        return {}
    if not isinstance(value, Mapping):
        raise ProtocolError(f"{what} must be a mapping, got {type(value)!r}")
    _reject_float(value, what)
    return {str(k): v for k, v in value.items()}


def _tuple_of_str(value: Optional[Sequence[Any]]) -> Tuple[str, ...]:
    if value is None:
        return ()
    if isinstance(value, str):
        raise ProtocolError("a bare string is not a sequence of declared items")
    return tuple(str(v) for v in value)


def _canonical_value(value: Any) -> Any:
    """Best-effort canonical encoding for evaluator payload values."""
    if isinstance(value, (Exact, Interval)):
        return value.to_canonical()
    if isinstance(value, Fraction):
        return Exact(value).to_canonical()
    if isinstance(value, Mapping):
        return {str(k): _canonical_value(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_canonical_value(v) for v in value]
    if isinstance(value, float):
        raise ProtocolError("binary float in evaluator payload (spec 14.2)")
    return value


# --------------------------------------------------------------------------
# 32.1 request
# --------------------------------------------------------------------------

#: Everything 32.1 says an external evaluator "shall receive".  A request
#: missing any of these is not a request; it is an under-specified job that
#: an evaluator would have to guess at, and guessing is what this whole
#: module exists to prevent.
REQUEST_REQUIRED_ITEMS: Tuple[str, ...] = (
    "realization_id",
    "embedding_candidate",
    "technology_contract",
    "requested_evidence_level",
    "tool_config",
    "objective",
    "constraints",
    "requested_outputs",
    "timeout",
    "resource_policy",
    "confidentiality_policy",
)


@dataclass(frozen=True)
class EvaluatorRequest:
    """What an external evaluator shall receive (32.1).

    ``timeout_ticks`` is an integer count of monotonic ticks, not a wall
    duration and not a float (45.1: monotonic local time governs timeout).
    ``requested_evidence_level`` is an evidence class from 5.3, and asking
    for ``MEASURED`` does not entitle the caller to treat a ``MODELED``
    answer as one -- see :func:`meets_requested_evidence_level`.
    """

    realization_id: str
    embedding_candidate: str
    technology_contract: str
    requested_evidence_level: str
    tool_config: Mapping[str, Any]
    objective: str
    constraints: Tuple[str, ...]
    requested_outputs: Tuple[str, ...]
    timeout_ticks: int
    resource_policy: Mapping[str, Any]
    confidentiality_policy: str
    request_id: str = field(default_factory=lambda: _new_id("req"))
    tick_unit: str = "millisecond"
    requested_by: str = "crg-feedback"
    notes: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        missing = [
            name
            for name, value in (
                ("realization_id", self.realization_id),
                ("embedding_candidate", self.embedding_candidate),
                ("technology_contract", self.technology_contract),
                ("requested_evidence_level", self.requested_evidence_level),
                ("tool_config", self.tool_config),
                ("objective", self.objective),
                ("constraints", self.constraints),
                ("requested_outputs", self.requested_outputs),
                ("timeout", self.timeout_ticks),
                ("resource_policy", self.resource_policy),
                ("confidentiality_policy", self.confidentiality_policy),
            )
            if value is None or (isinstance(value, str) and not value.strip())
        ]
        if missing:
            raise ProtocolError(
                "an evaluator request is incomplete; specification 32.1 requires "
                f"every item of {list(REQUEST_REQUIRED_ITEMS)} -- missing: {missing}"
            )
        if self.requested_evidence_level not in EvidenceClass.ALL:
            raise ProtocolError(
                f"requested_evidence_level {self.requested_evidence_level!r} is not "
                "an evidence class of specification 5.3"
            )
        if isinstance(self.timeout_ticks, float):
            raise ProtocolError("timeout must be an integer tick count, not a float (45.1)")
        if int(self.timeout_ticks) <= 0:
            raise ProtocolError("timeout must be a positive tick count (32.1)")
        outputs = _tuple_of_str(self.requested_outputs)
        if not outputs:
            raise ProtocolError("a request must name at least one requested output (32.1)")
        if len(set(outputs)) != len(outputs):
            raise ProtocolError("requested_outputs contains a duplicate")
        object.__setattr__(self, "requested_outputs", outputs)
        object.__setattr__(self, "constraints", _tuple_of_str(self.constraints))
        object.__setattr__(self, "notes", _tuple_of_str(self.notes))
        object.__setattr__(self, "timeout_ticks", int(self.timeout_ticks))
        object.__setattr__(self, "tool_config", _freeze_mapping(self.tool_config, "tool_config"))
        object.__setattr__(
            self, "resource_policy", _freeze_mapping(self.resource_policy, "resource_policy")
        )
        if not self.constraints:
            raise ProtocolError(
                "a request must state its constraints; an empty constraint list is a "
                "declaration that nothing constrains the candidate, which 32.1 "
                "requires the caller to make explicitly via a named 'none' constraint"
            )

    def to_canonical(self) -> dict:
        return {
            "request_id": self.request_id,
            "realization_id": self.realization_id,
            "embedding_candidate": self.embedding_candidate,
            "technology_contract": self.technology_contract,
            "requested_evidence_level": self.requested_evidence_level,
            "tool_config": _canonical_value(self.tool_config),
            "objective": self.objective,
            "constraints": list(self.constraints),
            "requested_outputs": list(self.requested_outputs),
            "timeout_ticks": int(self.timeout_ticks),
            "tick_unit": self.tick_unit,
            "resource_policy": _canonical_value(self.resource_policy),
            "confidentiality_policy": self.confidentiality_policy,
            "requested_by": self.requested_by,
            "notes": list(self.notes),
        }

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())


# --------------------------------------------------------------------------
# 32.1 response
# --------------------------------------------------------------------------


@dataclass(frozen=True)
class EvaluatorResponse:
    """One of the eleven responses of 32.1.

    The constructor enforces that a response says enough to be acted on:
    an infeasibility names its violated constraints (32.1 says so in the
    same breath), a witness carries a witness, a failure carries a
    diagnostic, and a result carries an evidence class admissible for its
    kind.  A response that cannot pass those checks is not downgraded to a
    weaker kind; it is refused, so the evaluator author fixes it.
    """

    kind: str
    request_id: str
    realization_id: str
    evaluator_identity: str
    response_id: str = field(default_factory=lambda: _new_id("resp"))
    evidence_class: Optional[str] = None
    witness: Optional[Mapping[str, Any]] = None
    values: Mapping[str, Any] = field(default_factory=dict)
    violated_constraints: Tuple[str, ...] = ()
    covered_outputs: Tuple[str, ...] = ()
    sensitivities: Mapping[str, Any] = field(default_factory=dict)
    uncertainty: Mapping[str, Any] = field(default_factory=dict)
    bottlenecks: Tuple[str, ...] = ()
    tool_identity: str = ""
    tool_version: str = ""
    method: str = ""
    determinism: str = "UNDECLARED"
    confidentiality: str = "as-requested"
    detail: str = ""

    def __post_init__(self) -> None:
        ResponseKind.check(self.kind)
        object.__setattr__(
            self, "violated_constraints", _tuple_of_str(self.violated_constraints)
        )
        object.__setattr__(self, "covered_outputs", _tuple_of_str(self.covered_outputs))
        object.__setattr__(self, "bottlenecks", _tuple_of_str(self.bottlenecks))
        object.__setattr__(self, "values", _freeze_mapping(self.values, "values"))
        object.__setattr__(
            self, "sensitivities", _freeze_mapping(self.sensitivities, "sensitivities")
        )
        object.__setattr__(self, "uncertainty", _freeze_mapping(self.uncertainty, "uncertainty"))
        if self.witness is not None:
            object.__setattr__(self, "witness", _freeze_mapping(self.witness, "witness"))

        admissible = ADMISSIBLE_EVIDENCE_CLASSES[self.kind]
        evidence_class = self.evidence_class
        if evidence_class is None and admissible:
            evidence_class = DEFAULT_EVIDENCE_CLASS.get(self.kind)
            if evidence_class is None:
                raise ProtocolError(
                    f"{self.kind} must declare which evidence class of 5.3 it carries; "
                    f"admissible here: {sorted(admissible)}"
                )
            object.__setattr__(self, "evidence_class", evidence_class)
        if evidence_class is not None:
            if evidence_class not in EvidenceClass.ALL:
                raise ProtocolError(
                    f"evidence_class {evidence_class!r} is not a class of specification 5.3"
                )
            if not admissible:
                raise ProtocolError(
                    f"{self.kind} carries no evidence about the candidate and MUST NOT "
                    f"declare an evidence class; got {evidence_class!r}.  A tool failure "
                    "that reported evidence would be asserting knowledge it does not have "
                    "(spec 32.1)"
                )
            if evidence_class not in admissible:
                raise ProtocolError(
                    f"{self.kind} may not carry evidence class {evidence_class!r}; "
                    f"admissible: {sorted(admissible)} (spec 5.3, 32.1)"
                )

        if self.kind == ResponseKind.PHYSICAL_INFEASIBILITY and not self.violated_constraints:
            raise ProtocolError(
                "specification 32.1 requires physical infeasibility to be returned "
                "'with identified violated constraints'; an unexplained infeasibility "
                "is indistinguishable from a tool failure and is refused"
            )
        if self.kind == ResponseKind.CONSTRUCTIVE_WITNESS and not self.witness:
            raise ProtocolError("a constructive witness response must carry the witness")
        if self.kind == ResponseKind.PARTIAL_EVALUATION and not self.covered_outputs:
            raise ProtocolError(
                "a partial evaluation must name the outputs it did cover; otherwise it "
                "is a tool failure and should say so"
            )
        if self.kind == ResponseKind.SENSITIVITY_RESULT and not self.sensitivities:
            raise ProtocolError("a sensitivity result must carry sensitivities")
        if self.kind == ResponseKind.UNCERTAINTY_RESULT and not self.uncertainty:
            raise ProtocolError("an uncertainty result must carry uncertainty components")
        if self.kind in ResponseKind.FAILURES and not self.detail.strip():
            raise ProtocolError(
                f"{self.kind} must carry a diagnostic detail; an opaque failure invites "
                "the reader to guess, and the available wrong guess is 'infeasible'"
            )
        if self.kind in ResponseKind.REFUSALS and not self.detail.strip():
            raise ProtocolError(f"{self.kind} must state what was refused and why")
        if self.kind in (ResponseKind.FAILURES | ResponseKind.REFUSALS):
            if self.violated_constraints:
                raise EvaluatorRefusal(
                    f"{self.kind} named violated constraints.  A failure of the "
                    "evaluator is not a violation by the candidate; report "
                    "PHYSICAL_INFEASIBILITY if a constraint was genuinely violated "
                    "(spec 32.1)"
                )
            if self.witness:
                raise EvaluatorRefusal(f"{self.kind} may not carry a witness")

    # -- classification ------------------------------------------------
    @property
    def establishes_infeasibility(self) -> bool:
        """True only for ``PHYSICAL_INFEASIBILITY`` (32.1)."""
        return self.kind in ResponseKind.ESTABLISHES_INFEASIBILITY

    @property
    def is_failure(self) -> bool:
        return self.kind in ResponseKind.FAILURES

    @property
    def is_refusal(self) -> bool:
        return self.kind in ResponseKind.REFUSALS

    @property
    def carries_evidence(self) -> bool:
        return self.evidence_class is not None

    @property
    def is_physical_signoff(self) -> bool:
        """Only an identified physical measurement is signoff (32.1, 5.3)."""
        return signoff_status(self) == SignoffStatus.PHYSICAL_SIGNOFF

    @property
    def feasibility_effect(self) -> str:
        return FEASIBILITY_EFFECT[self.kind]

    def to_canonical(self) -> dict:
        record: dict = {
            "response_id": self.response_id,
            "request_id": self.request_id,
            "realization_id": self.realization_id,
            "kind": self.kind,
            "evaluator_identity": self.evaluator_identity,
            "feasibility_effect": self.feasibility_effect,
            "signoff_status": signoff_status(self),
            "determinism": self.determinism,
            "confidentiality": self.confidentiality,
        }
        if self.evidence_class is not None:
            record["evidence_class"] = self.evidence_class
        if self.witness:
            record["witness"] = _canonical_value(self.witness)
        if self.values:
            record["values"] = _canonical_value(self.values)
        if self.violated_constraints:
            record["violated_constraints"] = list(self.violated_constraints)
        if self.covered_outputs:
            record["covered_outputs"] = list(self.covered_outputs)
        if self.sensitivities:
            record["sensitivities"] = _canonical_value(self.sensitivities)
        if self.uncertainty:
            record["uncertainty"] = _canonical_value(self.uncertainty)
        if self.bottlenecks:
            record["bottlenecks"] = list(self.bottlenecks)
        for key, value in (
            ("tool_identity", self.tool_identity),
            ("tool_version", self.tool_version),
            ("method", self.method),
            ("detail", self.detail),
        ):
            if value:
                record[key] = value
        return record

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())


#: Response kind + evidence class -> what the result may be represented as.
def signoff_status(response: EvaluatorResponse) -> str:
    """Classify what a response may be *represented* as (32.1).

    The rule is a single line: ``PHYSICAL_SIGNOFF`` requires evidence class
    ``MEASURED``.  A ``MODELED_RESULT`` therefore lands on
    ``MODEL_SUPPORTED`` no matter how completely it succeeded, which is the
    prohibition "a compact-model success MUST NOT be represented as
    physical signoff" expressed as a total function.
    """
    if response.evidence_class == EvidenceClass.MEASURED:
        return SignoffStatus.PHYSICAL_SIGNOFF
    if response.evidence_class == EvidenceClass.MODELED:
        return SignoffStatus.MODEL_SUPPORTED
    if response.evidence_class == EvidenceClass.CONSTRUCTIVE:
        return SignoffStatus.WITNESS_SUPPORTED
    if response.evidence_class in (EvidenceClass.BOUNDED, EvidenceClass.EXACT):
        return SignoffStatus.BOUND_SUPPORTED
    return SignoffStatus.NOT_SUPPORTED


def promote_evidence_class(response: EvaluatorResponse, target: str) -> EvaluatorResponse:
    """Refuse every promotion the evidence-class table forbids (5.3, 32.1).

    Exists so that the prohibition has a name a caller can trip over.  The
    only permitted call is the identity one; anything else raises, and
    ``MODELED -> MEASURED`` raises with the specific citation because it is
    the promotion an impatient integrator actually reaches for.
    """
    if target not in EvidenceClass.ALL:
        raise ProtocolError(f"{target!r} is not an evidence class of specification 5.3")
    if response.evidence_class is None:
        raise EvaluatorRefusal(
            f"{response.kind} carries no evidence class and none can be conferred on it; "
            "a failed or refused evaluation produced no evidence to reclassify (32.1)"
        )
    if response.evidence_class == EvidenceClass.MODELED and target == EvidenceClass.MEASURED:
        raise EvaluatorRefusal(
            "a MODELED result may not be promoted to MEASURED.  Specification 32.1: "
            "'A compact-model success MUST NOT be represented as physical signoff.'  "
            "Measurement is a separate evidence class of 5.3 and is produced only by "
            "an identified physical measurement -- run one and return a "
            "MEASURED_RESULT of its own"
        )
    if response.evidence_class != target:
        raise EvaluatorRefusal(
            f"evidence class {response.evidence_class} may not be rewritten to {target}; "
            "the classes of 5.3 shall remain distinct"
        )
    return response


def meets_requested_evidence_level(
    request: EvaluatorRequest, response: EvaluatorResponse
) -> bool:
    """Did the response answer at the level the request asked for (32.1)?

    Deliberately not a lattice.  ``MEASURED`` is satisfied only by
    ``MEASURED``; a ``MODELED`` answer to a ``MEASURED`` request is a real
    answer to a different question, and reporting it as satisfaction is the
    exact substitution 32.1 prohibits.  ``MEASURED`` does satisfy a request
    for ``MODELED``, because measurement is not a weaker claim.
    """
    wanted = request.requested_evidence_level
    got = response.evidence_class
    if got is None:
        return False
    if got == wanted:
        return True
    if wanted == EvidenceClass.MODELED and got == EvidenceClass.MEASURED:
        return True
    if wanted == EvidenceClass.BOUNDED and got in (
        EvidenceClass.MEASURED,
        EvidenceClass.EXACT,
        EvidenceClass.CONSTRUCTIVE,
    ):
        return True
    return False


# --------------------------------------------------------------------------
# submission
# --------------------------------------------------------------------------

Evaluator = Callable[[EvaluatorRequest], EvaluatorResponse]


def submit(request: EvaluatorRequest, evaluator: Evaluator) -> EvaluatorResponse:
    """Send a 32.1 request to an external evaluator and return its response.

    Everything that can go wrong on the transport becomes a
    ``TOOL_FAILURE``, never a ``PHYSICAL_INFEASIBILITY``: an evaluator that
    raises, returns the wrong type, names an unknown kind, or answers a
    different request has told us nothing about the physics.  That
    conversion is the point of this function -- it is where an integrator
    would otherwise write ``except Exception: mark_infeasible(...)``.

    A protocol violation that the *caller* committed (an incomplete
    request) is raised, not converted; there is no evaluator to blame.
    """
    if not isinstance(request, EvaluatorRequest):
        raise ProtocolError(
            f"submit expects an EvaluatorRequest, got {type(request)!r}"
        )
    if not callable(evaluator):
        raise ProtocolError("evaluator must be callable")

    def tool_failure(detail: str) -> EvaluatorResponse:
        return EvaluatorResponse(
            kind=ResponseKind.TOOL_FAILURE,
            request_id=request.request_id,
            realization_id=request.realization_id,
            evaluator_identity=getattr(evaluator, "identity", "unidentified-evaluator"),
            detail=detail,
        )

    try:
        response = evaluator(request)
    except Exception as exc:  # noqa: BLE001 - the conversion is the contract
        return tool_failure(
            f"the evaluator raised {type(exc).__name__}: {exc}.  Specification 32.1: "
            "'A tool failure MUST NOT be interpreted as physical infeasibility.'"
        )

    if not isinstance(response, EvaluatorResponse):
        return tool_failure(
            f"the evaluator returned {type(response)!r}, which is not an "
            "EvaluatorResponse; nothing about the candidate was established"
        )
    if response.request_id != request.request_id:
        return tool_failure(
            f"the evaluator answered request {response.request_id!r} but "
            f"{request.request_id!r} was submitted; the answer belongs to a different "
            "context and is discarded rather than attributed"
        )
    if response.realization_id != request.realization_id:
        return tool_failure(
            f"the evaluator answered about realization {response.realization_id!r} but "
            f"{request.realization_id!r} was submitted"
        )
    if response.kind == ResponseKind.PARTIAL_EVALUATION:
        unknown = set(response.covered_outputs) - set(request.requested_outputs)
        if unknown:
            return tool_failure(
                f"the partial evaluation reports outputs that were never requested: "
                f"{sorted(unknown)}"
            )
        if set(response.covered_outputs) == set(request.requested_outputs):
            raise ProtocolError(
                "a PARTIAL_EVALUATION covering every requested output is not partial; "
                "return the result kind that names its evidence class instead (32.1)"
            )
    return response


# --------------------------------------------------------------------------
# feasibility effect
# --------------------------------------------------------------------------


@dataclass(frozen=True)
class FeasibilityUpdate:
    """What a response did, or refused to do, to a realization's legality.

    ``recorded_legality`` is the state the record holds afterwards.  For a
    tool failure it equals ``prior_legality``: a failure adds no knowledge,
    and it must not remove any either -- a crashed re-run does not un-prove
    an earlier measurement.
    """

    realization_id: str
    response_id: str
    response_kind: str
    effect: str
    prior_legality: str
    recorded_legality: str
    evidence_class: Optional[str]
    violated_constraints: Tuple[str, ...]
    basis: str

    @property
    def marks_infeasible(self) -> bool:
        return self.recorded_legality == FeasibilityEffect.INFEASIBLE

    @property
    def leaves_unevaluated(self) -> bool:
        return self.recorded_legality == FeasibilityEffect.UNEVALUATED

    def to_canonical(self) -> dict:
        record = {
            "realization_id": self.realization_id,
            "response_id": self.response_id,
            "response_kind": self.response_kind,
            "effect": self.effect,
            "prior_legality": self.prior_legality,
            "recorded_legality": self.recorded_legality,
            "basis": self.basis,
        }
        if self.evidence_class is not None:
            record["evidence_class"] = self.evidence_class
        if self.violated_constraints:
            record["violated_constraints"] = list(self.violated_constraints)
        return record


_EFFECT_BASIS: Dict[str, str] = {
    FeasibilityEffect.INFEASIBLE: (
        "PHYSICAL_INFEASIBILITY is the only response of 32.1 that establishes "
        "infeasibility, and it named the violated constraints"
    ),
    FeasibilityEffect.LEGAL: "a constructive witness exhibited a realizable candidate",
    FeasibilityEffect.UNEVALUATED: (
        "the evaluator, not the candidate, failed to deliver; specification 32.1 "
        "forbids reading this as physical infeasibility, so the candidate keeps "
        "the status it already had and remains unevaluated where it was"
    ),
    FeasibilityEffect.UNSUPPORTED: "the evaluator does not support this request",
    FeasibilityEffect.UNCHANGED: (
        "the response reports values, not a legality verdict; an evaluator that "
        "found a constraint violated must return PHYSICAL_INFEASIBILITY and name it"
    ),
}


def feasibility_update(
    response: EvaluatorResponse, prior_legality: str = FeasibilityEffect.UNEVALUATED
) -> FeasibilityUpdate:
    """Compute the legality consequence of a response without applying it.

    The routing table is :data:`FEASIBILITY_EFFECT`.  ``INFEASIBLE`` appears
    in it exactly once.
    """
    effect = FEASIBILITY_EFFECT[response.kind]
    if effect in (FeasibilityEffect.UNCHANGED, FeasibilityEffect.UNEVALUATED):
        recorded = prior_legality
    else:
        recorded = effect
    return FeasibilityUpdate(
        realization_id=response.realization_id,
        response_id=response.response_id,
        response_kind=response.kind,
        effect=effect,
        prior_legality=prior_legality,
        recorded_legality=recorded,
        evidence_class=response.evidence_class,
        violated_constraints=response.violated_constraints,
        basis=_EFFECT_BASIS[effect],
    )


def apply_feasibility(
    response: EvaluatorResponse, bundle: RealizationBundle
) -> FeasibilityUpdate:
    """Apply a response's legality consequence to a realization bundle.

    Only ``PHYSICAL_INFEASIBILITY`` can write ``INFEASIBLE``.  A tool or
    convergence failure writes nothing at all and returns an update whose
    ``recorded_legality`` is unchanged.
    """
    record = _find_realization(bundle, response.realization_id)
    update = feasibility_update(response, prior_legality=record.legality)
    if update.recorded_legality != record.legality:
        record.legality = update.recorded_legality
        if update.evidence_class is not None:
            record.evidence_class = update.evidence_class
    return update


def _find_realization(bundle: RealizationBundle, realization_id: str) -> RealizationRecord:
    if not isinstance(bundle, RealizationBundle):
        raise ProtocolError(f"expected a RealizationBundle, got {type(bundle)!r}")
    for record in bundle.realizations:
        if record.realization_id == realization_id:
            return record
    raise ProtocolError(
        f"realization {realization_id!r} is not in bundle {bundle.bundle_id!r}; a "
        "response about an unknown candidate is discarded rather than appended "
        "(spec 6.6)"
    )


# --------------------------------------------------------------------------
# witness registration
# --------------------------------------------------------------------------


@dataclass(frozen=True)
class WitnessRecord:
    """The registration of an evaluator result against a realization bundle.

    ``evidence_class`` is the class the *response* carried, copied here and
    written into the bundle's realization record.  It is never widened on
    the way in: a witness registered from a ``MODELED_RESULT`` reaches the
    bundle as ``MODELED``, and ``physical_signoff`` is False for it.
    """

    witness_id: str
    bundle_id: str
    realization_id: str
    response_id: str
    response_kind: str
    evidence_class: str
    signoff_status: str
    method: str
    evaluator_identity: str
    witness_payload: Mapping[str, Any]
    covered_outputs: Tuple[str, ...]
    recorded_legality: str
    response_fingerprint: str

    @property
    def physical_signoff(self) -> bool:
        return self.signoff_status == SignoffStatus.PHYSICAL_SIGNOFF

    def to_canonical(self) -> dict:
        record = {
            "witness_id": self.witness_id,
            "bundle_id": self.bundle_id,
            "realization_id": self.realization_id,
            "response_id": self.response_id,
            "response_kind": self.response_kind,
            "evidence_class": self.evidence_class,
            "signoff_status": self.signoff_status,
            "physical_signoff": self.physical_signoff,
            "evaluator_identity": self.evaluator_identity,
            "recorded_legality": self.recorded_legality,
            "response_fingerprint": self.response_fingerprint,
        }
        if self.method:
            record["method"] = self.method
        if self.witness_payload:
            record["witness_payload"] = _canonical_value(self.witness_payload)
        if self.covered_outputs:
            record["covered_outputs"] = list(self.covered_outputs)
        return record

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())


def _content_reference(response: EvaluatorResponse) -> str:
    """A deterministic content hash of a response, excluding its random id.

    Two evaluations that produced the same physical fact -- same request,
    realization, kind, evidence class, values, and provenance -- yield the
    same reference, so the certificate that pins them is reproducible.
    """
    body = {k: v for k, v in response.to_canonical().items() if k != "response_id"}
    return content_hash(body)


def register_witness(
    response: EvaluatorResponse, bundle: RealizationBundle
) -> WitnessRecord:
    """Register an evaluator result against its realization in ``bundle``.

    The realization record is updated in place with the *response's own*
    evidence class and the witness reference, and the legality consequence
    of :func:`apply_feasibility` is applied at the same time.  Nothing is
    upgraded: registering a modeled result leaves the realization at
    evidence class ``MODELED``, and the returned record reports
    ``physical_signoff`` False.

    Failures, refusals, and infeasibilities are not registrable.  A failure
    has no content; an infeasibility has content but no witness, and is
    applied through :func:`apply_feasibility` instead.
    """
    if not isinstance(response, EvaluatorResponse):
        raise ProtocolError(f"expected an EvaluatorResponse, got {type(response)!r}")
    if response.kind not in ResponseKind.WITNESS_REGISTRABLE:
        if response.kind in ResponseKind.ESTABLISHES_INFEASIBILITY:
            raise EvaluatorRefusal(
                "a PHYSICAL_INFEASIBILITY exhibits no realizable witness; apply it "
                "with apply_feasibility, which records INFEASIBLE and the violated "
                "constraints (spec 32.1)"
            )
        raise EvaluatorRefusal(
            f"{response.kind} establishes nothing about the candidate and cannot be "
            "registered as a witness; specification 32.1 keeps evaluator failure "
            "separate from physical fact"
        )
    if response.evidence_class is None:  # pragma: no cover - guarded by __post_init__
        raise ProtocolError(f"{response.kind} reached registration with no evidence class")

    record = _find_realization(bundle, response.realization_id)
    update = feasibility_update(response, prior_legality=record.legality)

    # The witness reference written into the realization record enters the
    # bundle hash and hence the certificate identity, so it MUST be
    # deterministic (spec 6.5).  ``response_id`` defaults to a uuid4, which
    # would make identical physical evidence produce different certificate
    # hashes and defeat certificate pinning (spec 15.2).  Derive the
    # reference from the response's *content* instead, excluding the random
    # id, so the same evaluation always yields the same reference.
    witness_reference = _content_reference(response)
    record.witness = witness_reference
    # The class travels; it is not widened, not defaulted, not inherited
    # from the bundle.  This assignment is the carry-through the spec's
    # signoff prohibition depends on.
    record.evidence_class = response.evidence_class
    if update.recorded_legality != record.legality:
        record.legality = update.recorded_legality

    return WitnessRecord(
        witness_id=_new_id("witness"),
        bundle_id=bundle.bundle_id,
        realization_id=response.realization_id,
        response_id=response.response_id,
        response_kind=response.kind,
        evidence_class=response.evidence_class,
        signoff_status=signoff_status(response),
        method=response.method,
        evaluator_identity=response.evaluator_identity,
        witness_payload=dict(response.witness or {}),
        covered_outputs=response.covered_outputs,
        recorded_legality=record.legality,
        response_fingerprint=response.fingerprint(),
    )
