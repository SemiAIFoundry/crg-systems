"""Witness refinement and challenger generation (specification 32.2, 32.3).

Normative basis: master specification 32.2 (prioritize additional physical
evaluations by expected reduction in decision ambiguity, possible-winner
set, regret, uncertainty, qualification burden, or physical risk), 32.3
(physical feedback MAY trigger new challenger generation), and 5.3, which
sets the ceiling for everything here.

Both outputs of this module are ``HEURISTIC`` evidence (5.3).  A heuristic
"may propose realizations, rank candidates, prioritize evaluations" -- which
is exactly and only what a ranking and a challenger proposal are -- and it
"may not silently authorize" realization legality, certified pruning, or a
runtime transition.  So :class:`RankedEvaluation` and
:class:`ChallengerProposal` both carry ``evidence_class = HEURISTIC`` and
both report ``authorizes = False``.  A proposal is an input to generation,
never a substitute for it.

The ranking follows the ratio form of 34.4 -- expected reduction over
declared cost -- because 32.2's "expected reduction in ..." has no other
sensible denominator, and because the ETQ side of the system already ranks
this way.  Two disciplines carry over.  Reductions in different dimensions
are never compared: a possible-winner-set reduction of 3 and a regret
reduction of 3 share a number and nothing else, so mixing dimensions
raises.  And a positive reduction at zero declared cost is *tiered* above
the ratio, not scored as an infinity.

Challenger generation refuses to run on the failure kinds.  A tool crash
reveals no bottleneck, and inventing a "changed placement" challenger from
one would be the 32.1 prohibition wearing a different hat.
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Mapping, Optional, Sequence, Tuple

from crg_model.canonical import content_hash
from crg_model.envelope import EvidenceClass
from crg_model.numeric import Exact

from .protocol import EvaluatorResponse, ResponseKind

__all__ = [
    "RefinementError",
    "ReductionDimension",
    "ChallengerAxis",
    "EvaluationCandidate",
    "ExpectedReduction",
    "RankingTier",
    "RankedEvaluation",
    "ChallengerContext",
    "ChallengerProposal",
    "prioritize_evaluations",
    "propose_challengers",
]


class RefinementError(ValueError):
    """Raised when a refinement request cannot be answered as asked."""


def _new_id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4()}"


def _as_exact(value: Any, what: str) -> Exact:
    if isinstance(value, Exact):
        return value
    if isinstance(value, float):
        raise RefinementError(
            f"{what} is a binary float; supply an integer, a decimal string, a "
            "rational string, or an Exact (spec 14.2)"
        )
    try:
        return Exact(value)
    except (TypeError, ValueError) as exc:
        raise RefinementError(f"{what} is not an exact quantity: {exc}") from exc


# --------------------------------------------------------------------------
# 32.2 dimensions
# --------------------------------------------------------------------------


class ReductionDimension:
    """The six quantities 32.2 says evaluations SHOULD be prioritized by.

    They are not interchangeable and are not summed.  A plan that wants to
    trade regret against qualification burden must declare the exchange
    rate itself and present a single derived dimension; this module will
    not invent one.
    """

    DECISION_AMBIGUITY = "DECISION_AMBIGUITY"
    POSSIBLE_WINNER_SET = "POSSIBLE_WINNER_SET"
    REGRET = "REGRET"
    UNCERTAINTY = "UNCERTAINTY"
    QUALIFICATION_BURDEN = "QUALIFICATION_BURDEN"
    PHYSICAL_RISK = "PHYSICAL_RISK"

    ALL = (
        DECISION_AMBIGUITY,
        POSSIBLE_WINNER_SET,
        REGRET,
        UNCERTAINTY,
        QUALIFICATION_BURDEN,
        PHYSICAL_RISK,
    )

    @classmethod
    def check(cls, dimension: str) -> str:
        if dimension not in cls.ALL:
            raise RefinementError(
                f"unknown reduction dimension {dimension!r}; specification 32.2 lists "
                f"{', '.join(cls.ALL)}"
            )
        return dimension


class RankingBasis:
    """Whether a declared reduction is an expectation or a worst case (32.2)."""

    EXPECTED = "EXPECTED"
    WORST_CASE = "WORST_CASE"

    ALL = frozenset({EXPECTED, WORST_CASE})

    @classmethod
    def check(cls, basis: str) -> str:
        if basis not in cls.ALL:
            raise RefinementError(f"unknown ranking basis {basis!r}")
        return basis


@dataclass(frozen=True)
class ExpectedReduction:
    """A declared reduction in one 32.2 dimension.

    Both an expected and a worst-case figure may be declared; the ranking
    uses whichever basis the caller asked for, and never silently
    substitutes one for the other.
    """

    dimension: str
    expected: Exact
    worst_case: Optional[Exact] = None
    basis_note: str = ""

    def __post_init__(self) -> None:
        ReductionDimension.check(self.dimension)
        object.__setattr__(self, "expected", _as_exact(self.expected, "expected reduction"))
        if self.worst_case is not None:
            object.__setattr__(
                self, "worst_case", _as_exact(self.worst_case, "worst-case reduction")
            )

    def reduction(self, basis: str = RankingBasis.EXPECTED) -> Exact:
        RankingBasis.check(basis)
        if basis == RankingBasis.WORST_CASE:
            if self.worst_case is None:
                raise RefinementError(
                    "a worst-case ranking was requested but this candidate declared "
                    "only an expected reduction; the expected figure is not a "
                    "worst-case bound and is not substituted for one"
                )
            return self.worst_case
        return self.expected

    def to_canonical(self) -> dict:
        record = {
            "dimension": self.dimension,
            "expected": self.expected.to_canonical(),
        }
        if self.worst_case is not None:
            record["worst_case"] = self.worst_case.to_canonical()
        if self.basis_note:
            record["basis_note"] = self.basis_note
        return record


@dataclass(frozen=True)
class EvaluationCandidate:
    """A physical evaluation that could be commissioned next (32.2)."""

    candidate_id: str
    realization_id: str
    description: str = ""
    request_id: Optional[str] = None
    attributes: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not str(self.candidate_id).strip():
            raise RefinementError("an evaluation candidate needs an identity")
        object.__setattr__(self, "attributes", dict(self.attributes or {}))

    def to_canonical(self) -> dict:
        record = {
            "candidate_id": self.candidate_id,
            "realization_id": self.realization_id,
        }
        if self.description:
            record["description"] = self.description
        if self.request_id:
            record["request_id"] = self.request_id
        return record


class RankingTier:
    """Tiers, highest first.  Tier dominates score.

    An informative candidate with no declared cost is not infinitely good;
    it is *unquotable*, so it is tiered above the ratio rather than given
    one.  A candidate whose cost could not be evaluated at all is tiered
    below everything, because an unpriced evaluation is not schedulable.
    """

    INFORMATIVE_ZERO_COST = 3
    INFORMATIVE = 2
    UNINFORMATIVE = 1
    COST_NOT_DECLARED = 0

    NAME: Dict[int, str] = {
        INFORMATIVE_ZERO_COST: "INFORMATIVE_ZERO_COST",
        INFORMATIVE: "INFORMATIVE",
        UNINFORMATIVE: "UNINFORMATIVE",
        COST_NOT_DECLARED: "COST_NOT_DECLARED",
    }


@dataclass(frozen=True)
class RankedEvaluation:
    """One candidate's place in the 32.2 prioritization.

    Heuristic by construction (5.3): the rank orders work, it does not
    authorize any of it.
    """

    rank: int
    candidate: EvaluationCandidate
    dimension: str
    basis: str
    reduction: Exact
    cost: Optional[Exact]
    score: Optional[Exact]
    tier: int
    informative: bool
    excluded_reason: Optional[str] = None
    evidence_class: str = EvidenceClass.HEURISTIC

    @property
    def candidate_id(self) -> str:
        return self.candidate.candidate_id

    @property
    def tier_name(self) -> str:
        return RankingTier.NAME[self.tier]

    @property
    def authorizes(self) -> bool:
        """Always False.  A heuristic ranking may prioritize, never authorize (5.3)."""
        return False

    def to_canonical(self) -> dict:
        record: dict = {
            "rank": self.rank,
            "candidate": self.candidate.to_canonical(),
            "dimension": self.dimension,
            "basis": self.basis,
            "reduction": self.reduction.to_canonical(),
            "tier": self.tier,
            "tier_name": self.tier_name,
            "informative": self.informative,
            "evidence_class": self.evidence_class,
            "authorizes": self.authorizes,
        }
        if self.cost is not None:
            record["cost"] = self.cost.to_canonical()
        if self.score is not None:
            record["score"] = self.score.to_canonical()
        if self.excluded_reason:
            record["excluded_reason"] = self.excluded_reason
        return record

    def render(self) -> str:
        score = "n/a" if self.score is None else str(self.score)
        return (
            f"{self.rank:>2}. {self.candidate_id:<24} {self.tier_name:<20} "
            f"reduction={self.reduction} cost={self.cost} score={score}"
        )


AmbiguityFn = Callable[[EvaluationCandidate], ExpectedReduction]
CostFn = Callable[[EvaluationCandidate], Any]


def prioritize_evaluations(
    candidates: Sequence[EvaluationCandidate],
    *,
    ambiguity_fn: AmbiguityFn,
    cost_fn: CostFn,
    basis: str = RankingBasis.EXPECTED,
) -> List[RankedEvaluation]:
    """Order candidate physical evaluations by 32.2's expected reduction.

    ``ambiguity_fn`` returns the :class:`ExpectedReduction` a candidate is
    credited with; ``cost_fn`` returns its declared cost as an exact
    quantity.  Both are required and neither has a default: 32.2 ranks by a
    declared reduction over a declared cost, and a module that invented
    either would be ranking on its own opinion.

    Every candidate appears in the result, including the uninformative and
    the unpriced -- a refinement plan must record what it declined as
    clearly as what it chose.  Ordering is total and deterministic: tier,
    then score, then reduction, then candidate identity.
    """
    RankingBasis.check(basis)
    if not callable(ambiguity_fn):
        raise RefinementError("ambiguity_fn must be callable (spec 32.2)")
    if not callable(cost_fn):
        raise RefinementError(
            "cost_fn must be callable; 32.2 prioritizes by expected reduction, which "
            "is meaningless without the cost it is weighed against"
        )

    items = tuple(candidates or ())
    for candidate in items:
        if not isinstance(candidate, EvaluationCandidate):
            raise RefinementError(
                f"expected EvaluationCandidate, got {type(candidate)!r}"
            )
    ids = [c.candidate_id for c in items]
    if len(set(ids)) != len(ids):
        raise RefinementError("duplicate evaluation candidate identity")

    dimension: Optional[str] = None
    scored: List[Tuple[Tuple[Any, ...], RankedEvaluation]] = []

    for candidate in items:
        effect = ambiguity_fn(candidate)
        if not isinstance(effect, ExpectedReduction):
            raise RefinementError(
                f"ambiguity_fn returned {type(effect)!r} for {candidate.candidate_id!r}; "
                "an ExpectedReduction naming its 32.2 dimension is required"
            )
        if dimension is None:
            dimension = effect.dimension
        elif effect.dimension != dimension:
            raise RefinementError(
                f"candidates declare reductions in different 32.2 dimensions "
                f"({dimension} versus {effect.dimension}); the six dimensions of 32.2 "
                "do not share a scale and are not ranked against one another"
            )

        reduction = effect.reduction(basis)
        informative = reduction > Exact(0)

        cost: Optional[Exact] = None
        excluded: Optional[str] = None
        try:
            cost = _as_exact(cost_fn(candidate), f"cost of {candidate.candidate_id!r}")
        except RefinementError as exc:
            excluded = f"COST_NOT_DECLARED: {exc}"
        except Exception as exc:  # noqa: BLE001 - a cost model that raises is undeclared cost
            excluded = f"COST_NOT_DECLARED: cost_fn raised {type(exc).__name__}: {exc}"

        if cost is not None and cost < Exact(0):
            excluded = "COST_NOT_DECLARED: a negative declared cost is not a cost"
            cost = None

        score: Optional[Exact] = None
        if excluded is not None:
            tier = RankingTier.COST_NOT_DECLARED
            informative = False
        elif not informative:
            tier = RankingTier.UNINFORMATIVE
            if cost is not None and cost > Exact(0):
                score = reduction / cost
        elif cost == Exact(0):
            tier = RankingTier.INFORMATIVE_ZERO_COST
        else:
            tier = RankingTier.INFORMATIVE
            score = reduction / cost

        ranked = RankedEvaluation(
            rank=0,
            candidate=candidate,
            dimension=effect.dimension,
            basis=basis,
            reduction=reduction,
            cost=cost,
            score=score,
            tier=tier,
            informative=informative,
            excluded_reason=excluded,
        )
        sort_key = (
            -tier,
            -(score.value if score is not None else 0),
            -reduction.value,
            candidate.candidate_id,
        )
        scored.append((sort_key, ranked))

    scored.sort(key=lambda pair: pair[0])
    ordered: List[RankedEvaluation] = []
    for position, (_, ranked) in enumerate(scored, start=1):
        ordered.append(
            RankedEvaluation(
                rank=position,
                candidate=ranked.candidate,
                dimension=ranked.dimension,
                basis=ranked.basis,
                reduction=ranked.reduction,
                cost=ranked.cost,
                score=ranked.score,
                tier=ranked.tier,
                informative=ranked.informative,
                excluded_reason=ranked.excluded_reason,
            )
        )
    return ordered


# --------------------------------------------------------------------------
# 32.3 challenger generation
# --------------------------------------------------------------------------


class ChallengerAxis:
    """The eight changes 32.3 gives as examples of new challengers.

    The list is exemplary in the specification ("Examples include"), so
    :class:`ChallengerContext` accepts extension axes -- but it accepts
    them only when they are declared, so an undeclared axis is a typo
    rather than a silent new degree of freedom.
    """

    CHANGED_OWNERSHIP = "CHANGED_OWNERSHIP"
    CHANGED_RECOMPUTATION = "CHANGED_RECOMPUTATION"
    CHANGED_HIERARCHY = "CHANGED_HIERARCHY"
    CHANGED_REPLICATION = "CHANGED_REPLICATION"
    CHANGED_INTERFACE = "CHANGED_INTERFACE"
    CHANGED_PLACEMENT = "CHANGED_PLACEMENT"
    CHANGED_PACKAGING = "CHANGED_PACKAGING"
    CHANGED_RECOVERY_MODE = "CHANGED_RECOVERY_MODE"

    ALL = (
        CHANGED_OWNERSHIP,
        CHANGED_RECOMPUTATION,
        CHANGED_HIERARCHY,
        CHANGED_REPLICATION,
        CHANGED_INTERFACE,
        CHANGED_PLACEMENT,
        CHANGED_PACKAGING,
        CHANGED_RECOVERY_MODE,
    )

    #: Canonical ordering index, used so proposal order does not depend on
    #: mapping iteration order.
    ORDER: Dict[str, int] = {axis: index for index, axis in enumerate(ALL)}


@dataclass(frozen=True)
class ChallengerContext:
    """What the caller declares about how challengers may be formed (32.3).

    ``bottleneck_axes`` maps a revealed bottleneck -- a violated constraint
    name, or a bottleneck the evaluator named explicitly -- to the axes
    that could plausibly relieve it.  The mapping is the caller's domain
    knowledge, not this module's: CRG is domain neutral (3.3), and which
    axis relieves a thermal limit is a domain-pack question.

    ``permitted_axes`` bounds the result.  An axis the deployment cannot
    change produces no proposal, which keeps a refinement loop from
    generating challengers nobody can build.
    """

    incumbent_realization_id: str
    bottleneck_axes: Mapping[str, Sequence[str]]
    permitted_axes: Tuple[str, ...] = ChallengerAxis.ALL
    extension_axes: Tuple[str, ...] = ()
    generator_hint: str = ""
    max_proposals: Optional[int] = None
    notes: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(self, "extension_axes", tuple(str(a) for a in self.extension_axes))
        object.__setattr__(self, "permitted_axes", tuple(str(a) for a in self.permitted_axes))
        object.__setattr__(self, "notes", tuple(str(n) for n in self.notes))
        known = set(ChallengerAxis.ALL) | set(self.extension_axes)
        unknown = [a for a in self.permitted_axes if a not in known]
        if unknown:
            raise RefinementError(
                f"permitted_axes names axes that are neither in 32.3 nor declared as "
                f"extension_axes: {unknown}"
            )
        mapping: Dict[str, Tuple[str, ...]] = {}
        for bottleneck, axes in (self.bottleneck_axes or {}).items():
            if isinstance(axes, str):
                raise RefinementError(
                    f"bottleneck_axes[{bottleneck!r}] is a bare string; supply a sequence"
                )
            resolved = tuple(str(a) for a in axes)
            bad = [a for a in resolved if a not in known]
            if bad:
                raise RefinementError(
                    f"bottleneck_axes[{bottleneck!r}] names unknown challenger axes {bad}"
                )
            mapping[str(bottleneck)] = resolved
        object.__setattr__(self, "bottleneck_axes", mapping)
        if self.max_proposals is not None and int(self.max_proposals) < 1:
            raise RefinementError("max_proposals must be at least one when declared")

    def axes_for(self, bottleneck: str) -> Tuple[str, ...]:
        declared = self.bottleneck_axes.get(bottleneck, ())
        return tuple(a for a in declared if a in self.permitted_axes)

    def to_canonical(self) -> dict:
        record = {
            "incumbent_realization_id": self.incumbent_realization_id,
            "bottleneck_axes": {k: list(v) for k, v in self.bottleneck_axes.items()},
            "permitted_axes": list(self.permitted_axes),
        }
        if self.extension_axes:
            record["extension_axes"] = list(self.extension_axes)
        if self.generator_hint:
            record["generator_hint"] = self.generator_hint
        if self.max_proposals is not None:
            record["max_proposals"] = int(self.max_proposals)
        if self.notes:
            record["notes"] = list(self.notes)
        return record


@dataclass(frozen=True)
class ChallengerProposal:
    """A proposed new challenger triggered by physical feedback (32.3).

    Heuristic evidence (5.3).  It proposes a realization; it does not
    generate one, does not assert its legality, and does not authorize any
    pruning that would follow.  The proposal is handed to a registered
    generator, which evaluates legality under 28.3 as usual.
    """

    proposal_id: str
    axis: str
    bottleneck: str
    incumbent_realization_id: str
    source_response_id: str
    source_response_kind: str
    rationale: str
    generator_hint: str = ""
    evidence_class: str = EvidenceClass.HEURISTIC

    @property
    def authorizes(self) -> bool:
        """Always False.  A heuristic may propose realizations only (5.3)."""
        return False

    def to_canonical(self) -> dict:
        record = {
            "proposal_id": self.proposal_id,
            "axis": self.axis,
            "bottleneck": self.bottleneck,
            "incumbent_realization_id": self.incumbent_realization_id,
            "source_response_id": self.source_response_id,
            "source_response_kind": self.source_response_kind,
            "rationale": self.rationale,
            "evidence_class": self.evidence_class,
            "authorizes": self.authorizes,
        }
        if self.generator_hint:
            record["generator_hint"] = self.generator_hint
        return record

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())


def revealed_bottlenecks(response: EvaluatorResponse) -> Tuple[str, ...]:
    """The bottlenecks a response actually revealed (32.3).

    An infeasibility reveals its violated constraints, which 32.1 requires
    it to identify.  A result may additionally name bottlenecks it found.
    A tool failure, a convergence failure, an unauthorized request and an
    unsupported request reveal nothing: they are facts about the evaluator.
    """
    if response.kind not in ResponseKind.REVEALS_BOTTLENECK:
        return ()
    found: List[str] = []
    for item in list(response.violated_constraints) + list(response.bottlenecks):
        if item not in found:
            found.append(item)
    return tuple(found)


def propose_challengers(
    response: EvaluatorResponse, context: ChallengerContext
) -> List[ChallengerProposal]:
    """Propose new challengers from physical feedback (32.3).

    Returns an empty list -- not an exception -- when the response reveals
    no bottleneck, because "MAY trigger" means a run that triggers nothing
    is a normal run.  It returns an empty list for every failure and
    refusal kind for the same reason 32.1 gives: a crashed tool has not
    told us that anything about the design is wrong, so inventing a
    redesign from it would be reading tool failure as physical fact.

    Ordering is deterministic: bottleneck order as revealed, then the 32.3
    axis order.
    """
    if not isinstance(response, EvaluatorResponse):
        raise RefinementError(f"expected an EvaluatorResponse, got {type(response)!r}")
    if not isinstance(context, ChallengerContext):
        raise RefinementError(f"expected a ChallengerContext, got {type(context)!r}")

    proposals: List[ChallengerProposal] = []
    for bottleneck in revealed_bottlenecks(response):
        axes = sorted(
            set(context.axes_for(bottleneck)),
            key=lambda a: (ChallengerAxis.ORDER.get(a, len(ChallengerAxis.ALL)), a),
        )
        for axis in axes:
            rationale = (
                f"physical feedback {response.kind} identified bottleneck "
                f"{bottleneck!r} on realization {context.incumbent_realization_id!r}; "
                f"{axis} is declared responsive to it (spec 32.3).  This is a "
                "heuristic proposal: legality is decided by the generator under 28.3"
            )
            proposals.append(
                ChallengerProposal(
                    proposal_id=_new_id("challenger"),
                    axis=axis,
                    bottleneck=bottleneck,
                    incumbent_realization_id=context.incumbent_realization_id,
                    source_response_id=response.response_id,
                    source_response_kind=response.kind,
                    rationale=rationale,
                    generator_hint=context.generator_hint,
                )
            )
    if context.max_proposals is not None:
        proposals = proposals[: int(context.max_proposals)]
    return proposals
