"""crg-geometry: canonical exact R, Gamma, and K, and certified envelopes.

Reference implementation of sections 19 (canonical CRG geometry) and 20
(certified geometry approximations) of the CRG Operational Systems Master
Specification v0.2.0.

Every certifying path in this package is exact rational arithmetic over
``crg_model.numeric.Exact``; binary floating point appears nowhere, because
19.4's irredundant vertex set and 20.3's value-function bound are both
decided by comparisons that floating point cannot make soundly.
"""
from .construct import build_K, build_R, build_gamma
from .exact_lp import LinearProgramError, convex_combination_below, solve_feasibility
from .pareto import (
    dominated_by_any,
    pareto_minimal,
    signature_sort_key,
    signature_values,
    sort_signatures,
)
from .phase import (
    PHASE_ANALYSIS_SCHEMA_VERSION,
    PhaseAnalysisRecord,
    PhaseBoundary,
    PhaseDegeneracy,
    PhasePolicy,
    PhaseProfile,
    PhaseRegion,
    PhaseStability,
    PhaseTie,
    PhaseVerificationError,
    UnsupportedPhaseProfileError,
    build_phase_analysis,
    phase_analysis_from_canonical,
    require_verified_phase_analysis,
    verify_phase_analysis,
)
from .support import (
    EmptyRegionError,
    NegativePriceError,
    certified_envelope,
    default_price_samples,
    dominates_region,
    region_generators,
    region_included,
    support_error_bound,
    support_value,
)
from .verify import verify_K, verify_R, verify_gamma, verify_geometry

__all__ = [
    "build_R",
    "build_gamma",
    "build_K",
    "pareto_minimal",
    "support_value",
    "dominates_region",
    "verify_geometry",
    "support_error_bound",
    "certified_envelope",
    "default_price_samples",
    "region_generators",
    "region_included",
    "signature_values",
    "signature_sort_key",
    "sort_signatures",
    "dominated_by_any",
    "solve_feasibility",
    "convex_combination_below",
    "verify_R",
    "verify_gamma",
    "verify_K",
    "NegativePriceError",
    "EmptyRegionError",
    "LinearProgramError",
    "PhaseProfile",
    "PHASE_ANALYSIS_SCHEMA_VERSION",
    "UnsupportedPhaseProfileError",
    "PhaseVerificationError",
    "PhasePolicy",
    "PhaseRegion",
    "PhaseBoundary",
    "PhaseTie",
    "PhaseDegeneracy",
    "PhaseStability",
    "PhaseAnalysisRecord",
    "build_phase_analysis",
    "phase_analysis_from_canonical",
    "verify_phase_analysis",
    "require_verified_phase_analysis",
]

__version__ = "1.2.0"
SPEC_VERSION = "0.2.0"
