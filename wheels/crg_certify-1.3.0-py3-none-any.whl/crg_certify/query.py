"""Decision-query language and soundness compiler.

Normative basis: master specification section 26 (decision-query language
and soundness compiler), with the safe-commitment consequences of section
19 (canonical geometry) and section 29 (safe commitment).

The compiler answers exactly one question: *what is the minimum CRG object
that still preserves every decision this query declares must remain valid?*
It answers it from a versioned, data-first mapping table (26.4) and emits a
:class:`~crg_model.records.DerivationRecord` that cites the rule it used and
records every lower-information alternative it rejected (26.5, 26.6).

Three rules govern this module and are enforced structurally:

* a user override MUST NOT force an unsafe lower-information certificate
  (26.6) -- a requested object weaker than the required object becomes a
  recorded refusal, never a downgrade;
* an additive-price family remains additive whether its weights are a single
  fixed vector, a range, or a set -- all nonnegative additive prices see
  exactly `K` (19.4, 26.4);
* a continuous coordinatewise monotone but *non-additive* family (max,
  weighted max, bottleneck) is NOT visible to `K` and requires `Gamma`
  (19.3, 26.4).

No binary floating point enters this module: every numeric literal is
carried as an exact rational string and converted through
:class:`crg_model.numeric.Exact`.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from fractions import Fraction
from typing import Any, Callable, Dict, List, Mapping, Optional, Tuple

from crg_model.canonical import content_hash
from crg_model.numeric import Exact
from crg_model.records import DecisionScope, DerivationRecord, ObservationLevel

__all__ = [
    "COMPILER_VERSION",
    "MAPPING_TABLE_VERSION",
    "MAPPING_TABLE",
    "MappingRule",
    "QueryError",
    "Quantification",
    "RetentionPolicy",
    "INFORMATION_ORDER",
    "ADDITIVE_TYPES",
    "MONOTONE_NONADDITIVE_TYPES",
    "ATTAINABILITY_TYPES",
    "NONMONOTONE_TYPES",
    "REALIZATION_TYPES",
    "LEDGER_TYPES",
    "parse_query",
    "compile_query",
    "mapping_table_digest",
    "ledger_case_scopes",
    "bind_schema",
]

COMPILER_VERSION = "crg-certify/query@0.2.0"

#: Version of the normative decision-observation mapping table (spec 26.4).
#: Any change to :data:`MAPPING_TABLE` semantics MUST bump this string; a
#: certificate pins it so a verifier can reject a table it does not know.
MAPPING_TABLE_VERSION = "1"

VIR_PROGRAM = "crg-vir/derivation-check@1"


class QueryError(ValueError):
    """Raised when a query cannot be parsed or is semantically inadmissible."""


class Quantification:
    """Specification 26.3."""

    EACH_OBJECTIVE = "EACH_OBJECTIVE"
    ROBUST_AGGREGATE = "ROBUST_AGGREGATE"

    ALL = frozenset({EACH_OBJECTIVE, ROBUST_AGGREGATE})


class RetentionPolicy:
    """Specification 29.3 retention policies, as canonical identifiers."""

    RETAIN_ALL = "retain-all"
    FIBER_PRESERVING = "fiber-preserving"
    RETAIN_ALL_SIGNATURES = "retain-all-signatures"
    UNIVERSAL_MONOTONE = "universal-monotone"
    ADDITIVE_PRICE_VISIBLE = "additive-price-visible"
    RETAIN_ALL_WINNERS = "retain-all-winners"
    ARGMIN_HITTING = "argmin-hitting"
    BOUNDED_REGRET = "bounded-regret"
    MARGIN_BASED = "margin-based"
    ROBUSTNESS_NEIGHBORHOOD = "robustness-neighborhood"

    ALL = frozenset(
        {
            RETAIN_ALL,
            FIBER_PRESERVING,
            RETAIN_ALL_SIGNATURES,
            UNIVERSAL_MONOTONE,
            ADDITIVE_PRICE_VISIBLE,
            RETAIN_ALL_WINNERS,
            ARGMIN_HITTING,
            BOUNDED_REGRET,
        }
    )

    #: Names established by specification 29.3 for which this finite/exact
    #: profile does not yet register constructive semantics.  The compiler
    #: recognizes them as specification terms but refuses to authorize a
    #: reduction rather than silently guessing at margin or neighborhood
    #: meaning.
    DECLARED_UNSUPPORTED = frozenset({MARGIN_BASED, ROBUSTNESS_NEIGHBORHOOD})
    SPECIFICATION_ALL = ALL | DECLARED_UNSUPPORTED

    #: Spelling variants accepted from user queries.
    ALIASES = {
        "RETAIN_ALL": RETAIN_ALL,
        "RETAIN_ALL_REALIZATIONS": RETAIN_ALL,
        "FIBER_PRESERVING": FIBER_PRESERVING,
        "RETAIN_ALL_SIGNATURES": RETAIN_ALL_SIGNATURES,
        "UNIVERSAL_MONOTONE": UNIVERSAL_MONOTONE,
        "UNIVERSAL_MONOTONE_RETENTION": UNIVERSAL_MONOTONE,
        "ADDITIVE_PRICE_VISIBLE": ADDITIVE_PRICE_VISIBLE,
        "ADDITIVE_PRICE_VISIBLE_RETENTION": ADDITIVE_PRICE_VISIBLE,
        "RETAIN_ALL_WINNERS": RETAIN_ALL_WINNERS,
        "RETAIN_ALL_WINNERS_IN_A_DECLARED_LEDGER": RETAIN_ALL_WINNERS,
        "FINITE_LEDGER_ARGMIN_HITTING": ARGMIN_HITTING,
        "ARGMIN_HITTING": ARGMIN_HITTING,
        "MINIMUM_ARGMIN_HITTING_SET": ARGMIN_HITTING,
        "BOUNDED_REGRET": BOUNDED_REGRET,
        "BOUNDED_REGRET_RETENTION": BOUNDED_REGRET,
        "MARGIN_BASED": MARGIN_BASED,
        "MARGIN_BASED_RETENTION": MARGIN_BASED,
        "ROBUSTNESS_NEIGHBORHOOD": ROBUSTNESS_NEIGHBORHOOD,
        "ROBUSTNESS_NEIGHBORHOOD_RETENTION": ROBUSTNESS_NEIGHBORHOOD,
    }


#: Required-object information order.  A larger number strictly dominates in
#: retained information.  ``ARGMIN_HITTING_SET`` and
#: ``BOUNDED_REGRET_REPRESENTATION`` sit below the geometric chain because
#: each is sufficient only under an extra declared closure condition.
INFORMATION_ORDER: Dict[str, int] = {
    "REALIZATION_REGISTRY_AND_FIBERS": 5,
    "R": 4,
    "GAMMA": 3,
    "K": 2,
    "ARGMIN_HITTING_SET": 1,
    "BOUNDED_REGRET_REPRESENTATION": 0,
}

#: The geometric quotient chain, strongest first.  Refusals are emitted for
#: every member strictly weaker than the required object.
GEOMETRIC_CHAIN: Tuple[str, ...] = ("REALIZATION_REGISTRY_AND_FIBERS", "R", "GAMMA", "K")

# -- objective-family taxonomy -----------------------------------------------
#: Nonnegative additive price families.  Fixed vector, range, or set: all of
#: them see exactly K (spec 19.4, 26.4).
ADDITIVE_TYPES = frozenset(
    {"weighted_sum", "linear", "additive", "additive_price", "dot", "price_vector"}
)

#: Continuous coordinatewise monotone but non-additive families.  These are
#: NOT determined by support values of nonnegative price vectors and MUST NOT
#: be reduced to K (spec 26.4 row "continuous coordinatewise monotone").
MONOTONE_NONADDITIVE_TYPES = frozenset(
    {
        "max",
        "weighted_max",
        "bottleneck",
        "min_max",
        "minmax",
        "makespan",
        "chebyshev",
        "weighted_chebyshev",
        "monotone",
        "monotone_family",
        "lexicographic",
        "quantile",
        "leximin",
        "p_norm",
    }
)

#: Families that need exact joint attainability of a signature point.
ATTAINABILITY_TYPES = frozenset(
    {
        "attainability",
        "exact_point",
        "exact_signature",
        "signature_attainability",
        "feasibility_of_point",
        "equality_target",
    }
)

#: Families that are not coordinatewise monotone at all.
NONMONOTONE_TYPES = frozenset(
    {"nonmonotone", "ratio", "difference", "target_distance", "balance", "variance", "spread"}
)

#: Families whose value depends on something outside the signature.
REALIZATION_TYPES = frozenset(
    {
        "realization_attribute",
        "declared_value",
        "schedule",
        "topology",
        "ownership",
        "placement",
        "layout",
        "transition_cost",
        "embedding",
        "artifact",
    }
)

#: A finite named set of technology and objective cases (spec 26.4).
LEDGER_TYPES = frozenset({"finite_ledger", "case_ledger", "ledger"})

#: Query keys that make a decision realization-sensitive (spec 19.6, 26.4).
REALIZATION_SENSITIVITY_KEYS = frozenset(
    {
        "identity",
        "realization_identity",
        "schedule",
        "topology",
        "placement",
        "layout",
        "ownership",
        "embedding",
        "transition",
        "transition_cost",
        "artifact",
        "provenance",
        "fiber",
        "fiber_sensitive",
    }
)

_KNOWN_TYPES = (
    ADDITIVE_TYPES
    | MONOTONE_NONADDITIVE_TYPES
    | ATTAINABILITY_TYPES
    | NONMONOTONE_TYPES
    | REALIZATION_TYPES
    | LEDGER_TYPES
)


# ---------------------------------------------------------------------------
# exact scalar handling -- no binary floating point may enter the compiler
# ---------------------------------------------------------------------------
def _exact_str(value: Any) -> str:
    """Canonical exact-rational string for a query scalar."""
    if isinstance(value, float):
        raise QueryError(
            "binary floating point is not admissible in a decision query; "
            "supply an integer, a decimal string, or a rational string"
        )
    if isinstance(value, bool):
        raise QueryError("boolean is not an admissible numeric scalar")
    return str(Exact(value))


def _is_numeric_scalar(value: Any) -> bool:
    if isinstance(value, bool):
        return False
    if isinstance(value, (int, Fraction, Exact)):
        return True
    if isinstance(value, str):
        try:
            Fraction(value)
        except (ValueError, ZeroDivisionError):
            return False
        return True
    return False


# ---------------------------------------------------------------------------
# minimal, dependency-free query text parsing
# ---------------------------------------------------------------------------
_NUM_RE = re.compile(r"^[+-]?(\d+(\.\d*)?|\.\d+)$|^[+-]?\d+/\d+$")


def _scalar(token: str) -> Any:
    token = token.strip()
    if len(token) >= 2 and token[0] == token[-1] and token[0] in "\"'":
        return token[1:-1]
    lowered = token.lower()
    if lowered in ("true", "yes", "on"):
        return True
    if lowered in ("false", "no", "off"):
        return False
    if lowered in ("null", "none", "~", ""):
        return None
    if _NUM_RE.match(token):
        # Kept as text so no float ever materializes.
        return token
    return token


def _inline_sequence(token: str) -> List[Any]:
    body = token.strip()[1:-1].strip()
    if not body:
        return []
    return [_scalar(part) for part in body.split(",")]


def _inline_mapping(token: str) -> Dict[str, Any]:
    body = token.strip()[1:-1].strip()
    if not body:
        return {}
    out: Dict[str, Any] = {}
    for part in body.split(","):
        key, _, value = part.partition(":")
        out[key.strip()] = _value_token(value)
    return out


def _value_token(token: str) -> Any:
    token = token.strip()
    if token.startswith("[") and token.endswith("]"):
        return _inline_sequence(token)
    if token.startswith("{") and token.endswith("}"):
        return _inline_mapping(token)
    return _scalar(token)


def _strip_comment(line: str) -> str:
    out = []
    quote = None
    for ch in line:
        if quote:
            out.append(ch)
            if ch == quote:
                quote = None
            continue
        if ch in "\"'":
            quote = ch
            out.append(ch)
            continue
        if ch == "#":
            break
        out.append(ch)
    return "".join(out).rstrip()


def _lines(text: str) -> List[Tuple[int, str]]:
    result: List[Tuple[int, str]] = []
    for raw in text.splitlines():
        if "\t" in raw.replace(raw.lstrip("\t"), ""):
            raise QueryError("tabs are not admissible indentation in a query document")
        stripped = _strip_comment(raw)
        if not stripped.strip() or stripped.strip() == "---":
            continue
        indent = len(stripped) - len(stripped.lstrip(" "))
        result.append((indent, stripped.strip()))
    return result


def _parse_block(lines: List[Tuple[int, str]], index: int, indent: int) -> Tuple[Any, int]:
    if index >= len(lines):
        return {}, index
    if lines[index][1].startswith("- "):
        items: List[Any] = []
        while index < len(lines) and lines[index][0] == indent and lines[index][1].startswith("- "):
            items.append(_value_token(lines[index][1][2:]))
            index += 1
        return items, index
    mapping: Dict[str, Any] = {}
    while index < len(lines) and lines[index][0] == indent:
        content = lines[index][1]
        if ":" not in content:
            raise QueryError(f"query line is neither a mapping nor a list item: {content!r}")
        key, _, rest = content.partition(":")
        key = key.strip()
        rest = rest.strip()
        index += 1
        if rest:
            mapping[key] = _value_token(rest)
            continue
        if index < len(lines) and lines[index][0] > indent:
            value, index = _parse_block(lines, index, lines[index][0])
            mapping[key] = value
        else:
            mapping[key] = {}
    return mapping, index


def _parse_document(text: str) -> Dict[str, Any]:
    """Parse the restricted mapping/sequence/scalar document form.

    JSON is accepted directly; otherwise the indentation-based subset used by
    the specification examples (26.7) is parsed.  Numeric scalars are never
    converted to binary floating point at any point.
    """
    stripped = text.strip()
    if stripped.startswith("{") or stripped.startswith("["):
        parsed = json.loads(stripped, parse_float=str, parse_int=str)
        if not isinstance(parsed, dict):
            raise QueryError("a decision query must be a mapping")
        return parsed
    lines = _lines(text)
    if not lines:
        raise QueryError("empty decision query")
    value, index = _parse_block(lines, 0, lines[0][0])
    if index != len(lines):
        raise QueryError("inconsistent indentation in decision query")
    if not isinstance(value, dict):
        raise QueryError("a decision query must be a mapping")
    return value


# ---------------------------------------------------------------------------
# canonical query normalization (spec 26.2)
# ---------------------------------------------------------------------------
def _as_mapping(value: Any, field: str) -> Dict[str, Any]:
    if value is None:
        return {}
    if isinstance(value, Mapping):
        return dict(value)
    raise QueryError(f"query field {field!r} must be a mapping")


def _normalize_weights(raw: Any) -> Optional[Dict[str, List[str]]]:
    """Normalize every weight to an exact ``[lo, hi]`` pair.

    A fixed weight becomes a degenerate pair.  A declared set of weights
    becomes its exact hull pair together with the recorded members; the hull
    is what the additive-price argument needs, and the members are retained in
    the canonical query so the hash distinguishes them.
    """
    if raw is None:
        return None
    if not isinstance(raw, Mapping):
        raise QueryError("objective weights must be a mapping from coordinate to weight")
    weights: Dict[str, List[str]] = {}
    for coordinate, value in raw.items():
        if isinstance(value, Mapping):
            lo = value.get("lo", value.get("min"))
            hi = value.get("hi", value.get("max"))
            if lo is None or hi is None:
                raise QueryError(f"weight range for {coordinate!r} needs both bounds")
            pair = [_exact_str(lo), _exact_str(hi)]
        elif isinstance(value, (list, tuple)):
            if not value:
                raise QueryError(f"empty weight set for coordinate {coordinate!r}")
            members = [Exact(_exact_str(v)) for v in value]
            pair = [str(min(members, key=lambda e: e.value)), str(max(members, key=lambda e: e.value))]
        elif _is_numeric_scalar(value):
            pair = [_exact_str(value), _exact_str(value)]
        else:
            raise QueryError(f"weight for coordinate {coordinate!r} is not an exact scalar or range")
        if Exact(pair[1]) < Exact(pair[0]):
            raise QueryError(f"weight range for {coordinate!r} is inverted")
        weights[str(coordinate)] = pair
    return weights


def _normalize_objective(raw: Any) -> Dict[str, Any]:
    family = _as_mapping(raw, "objective_family")
    kind = str(family.get("type", family.get("kind", "unknown"))).strip().lower()
    normalized: Dict[str, Any] = {"type": kind}

    weights = _normalize_weights(family.get("weights"))
    if weights is not None:
        normalized["weights"] = weights
        normalized["weights_are_ranges"] = any(w[0] != w[1] for w in weights.values())

    if "monotone" in family:
        normalized["monotone"] = bool(family["monotone"])
    if "additive" in family:
        normalized["additive"] = bool(family["additive"])
    if family.get("target") is not None:
        normalized["target"] = [_exact_str(v) for v in family["target"]]
    if family.get("coordinate_order") is not None:
        normalized["coordinate_order"] = [str(c) for c in family["coordinate_order"]]
    if family.get("partial_family_policy") is not None:
        policy = str(family["partial_family_policy"]).upper()
        if policy not in ("BLOCK", "HEURISTIC_INCUMBENT"):
            raise QueryError("partial_family_policy must be BLOCK or HEURISTIC_INCUMBENT")
        normalized["partial_family_policy"] = policy
    if family.get("protected_ids"):
        normalized["protected_ids"] = [str(i) for i in family["protected_ids"]]

    cases = family.get("cases")
    if cases is not None:
        if not isinstance(cases, (list, tuple)) or not cases:
            raise QueryError("a finite ledger must declare a non-empty list of cases")
        normalized_cases = []
        for position, case in enumerate(cases):
            case_map = _as_mapping(case, "objective_family.cases[]")
            entry = _normalize_objective(case_map)
            entry["case_id"] = str(case_map.get("id", case_map.get("case_id", f"case-{position}")))
            if entry["type"] in LEDGER_TYPES:
                raise QueryError("a ledger case may not itself be a ledger")
            normalized_cases.append(entry)
        normalized["cases"] = normalized_cases
    return normalized


def _normalize_sensitivity(raw: Any) -> List[str]:
    if raw is None:
        return []
    if isinstance(raw, Mapping):
        return sorted(str(k) for k, v in raw.items() if bool(v))
    if isinstance(raw, (list, tuple)):
        return sorted(str(v) for v in raw)
    if isinstance(raw, str):
        return [raw]
    if isinstance(raw, bool):
        return ["identity"] if raw else []
    raise QueryError("realization_sensitivity must be a mapping, list, string, or boolean")


def _normalize_domain(raw: Any) -> Dict[str, Any]:
    domain = _as_mapping(raw, "technology_domain")
    out: Dict[str, Any] = {}
    for key, value in domain.items():
        if isinstance(value, (list, tuple)):
            out[str(key)] = [_exact_str(v) if _is_numeric_scalar(v) else str(v) for v in value]
        elif _is_numeric_scalar(value):
            out[str(key)] = _exact_str(value)
        elif isinstance(value, bool):
            out[str(key)] = value
        else:
            out[str(key)] = str(value)
    return out


def parse_query(text_or_dict: Any) -> dict:
    """Parse a decision query into its canonical form (spec 26.2).

    Accepts a mapping, a JSON document, or the restricted indentation-based
    document form used by specification example 26.7.  The result is a plain
    canonicalizable mapping: every numeric leaf is an exact rational string, so
    the query hash is stable and binary floating point can never enter the
    compiled scope.
    """
    if isinstance(text_or_dict, Mapping):
        raw = dict(text_or_dict)
    elif isinstance(text_or_dict, str):
        raw = _parse_document(text_or_dict)
    else:
        raise QueryError(f"cannot interpret {type(text_or_dict)!r} as a decision query")

    # The specification example nests everything under ``decision_scope``.
    if "decision_scope" in raw and isinstance(raw["decision_scope"], Mapping):
        merged = dict(raw)
        merged.pop("decision_scope")
        merged.update(dict(raw["decision_scope"]))
        raw = merged

    # Normalization is idempotent: an already-canonical query re-normalizes to
    # itself, so a query hash is stable under re-parsing.
    decision_id = str(raw.get("id", raw.get("decision_id", "decision")))
    quantification = str(raw.get("quantification", Quantification.EACH_OBJECTIVE)).upper()
    if quantification not in Quantification.ALL:
        raise QueryError(
            f"unknown objective quantification {quantification!r}; "
            "spec 26.3 requires EACH_OBJECTIVE or ROBUST_AGGREGATE"
        )

    ties = _as_mapping(raw.get("ties"), "ties")
    tolerance = ties.get("policy_tolerance", ties.get("tolerance", 0))
    retain_all = ties.get("retain_all", ties.get("retain_all_ties", True))

    uncertainty = _as_mapping(raw.get("uncertainty"), "uncertainty")
    retention = _as_mapping(raw.get("retention"), "retention")
    regret = _as_mapping(raw.get("bounded_regret"), "bounded_regret")
    if raw.get("bounded_regret_tolerance") is not None:
        regret = dict(regret)
        regret.setdefault("tolerance", raw["bounded_regret_tolerance"])

    requested = (
        raw.get("requested_object")
        or raw.get("require_object")
        or retention.get("requested_object")
        or retention.get("object")
    )

    canonical: Dict[str, Any] = {
        "canonical_query_version": "1",
        "decision_id": decision_id,
        "objective_family": _normalize_objective(raw.get("objective_family")),
        "quantification": quantification,
        "technology_domain": _normalize_domain(raw.get("technology_domain")),
        "feasibility": _as_mapping(raw.get("feasibility"), "feasibility"),
        "uncertainty": {"mode": str(uncertainty.get("mode", "exact"))},
        "robustness": _as_mapping(raw.get("robustness"), "robustness"),
        "price_domain": _as_mapping(raw.get("price_domain"), "price_domain"),
        "ties": {"policy_tolerance": _exact_str(tolerance), "retain_all": bool(retain_all)},
        "realization_sensitivity": _normalize_sensitivity(raw.get("realization_sensitivity")),
        "required_retained_identities": [
            str(i) for i in (raw.get("required_retained_identities") or [])
        ],
        "retention": {},
        "bounded_regret": {},
        "validity": str(raw["validity"]) if raw.get("validity") else None,
        "authority": str(raw["authority"]) if raw.get("authority") else None,
        "requested_object": str(requested).upper() if requested else None,
    }

    if retention.get("policy"):
        declared = str(retention["policy"])
        canonical["retention"]["policy"] = RetentionPolicy.ALIASES.get(
            declared.upper(), declared.lower()
        )
        # The spelling the user actually wrote is preserved, so re-parsing a
        # canonical query is idempotent and its hash is stable.
        canonical["retention"]["declared_policy"] = str(
            retention.get("declared_policy", declared)
        )
    if regret:
        if regret.get("tolerance") is not None:
            canonical["bounded_regret"]["tolerance"] = _exact_str(regret["tolerance"])
        canonical["bounded_regret"]["accept_approximation"] = bool(
            regret.get("accept_approximation", regret.get("accept", False))
        )
    if canonical["requested_object"] and canonical["requested_object"] not in INFORMATION_ORDER:
        raise QueryError(
            f"requested object {canonical['requested_object']!r} is not a CRG retained object"
        )
    return canonical


# ---------------------------------------------------------------------------
# the normative decision-observation mapping table (spec 26.4)
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class MappingRule:
    """One row of the normative decision-observation mapping table (26.4)."""

    rule_id: str
    spec_citation: str
    decision_class: str
    required_object: str
    description: str
    predicate: Callable[[dict], bool]

    def to_canonical(self) -> dict:
        return {
            "rule_id": self.rule_id,
            "spec_citation": self.spec_citation,
            "decision_class": self.decision_class,
            "required_object": self.required_object,
            "description": self.description,
        }


def _objective_type(query: dict) -> str:
    return str(query["objective_family"].get("type", "unknown"))


def _weights(query: dict) -> Dict[str, List[str]]:
    return query["objective_family"].get("weights") or {}


def _all_weights_nonnegative(query: dict) -> bool:
    weights = _weights(query)
    if not weights:
        # An unweighted additive family is the all-ones price vector.
        return True
    return all(Exact(pair[0]) >= Exact(0) for pair in weights.values())


def _declared_nonmonotone(query: dict) -> bool:
    family = query["objective_family"]
    return family.get("monotone") is False


def _is_realization_sensitive(query: dict) -> bool:
    if _objective_type(query) in REALIZATION_TYPES:
        return True
    if query["required_retained_identities"]:
        return True
    sensitivity = set(query["realization_sensitivity"])
    return bool(sensitivity & REALIZATION_SENSITIVITY_KEYS) or bool(
        sensitivity - REALIZATION_SENSITIVITY_KEYS
    )


def _needs_exact_region(query: dict) -> bool:
    kind = _objective_type(query)
    if kind in ATTAINABILITY_TYPES or kind in NONMONOTONE_TYPES:
        return True
    if _declared_nonmonotone(query):
        return True
    # A price family admitting a negative weight is not monotone in the
    # minimize convention, so neither K nor Gamma is sufficient.
    if kind in ADDITIVE_TYPES and not _all_weights_nonnegative(query):
        return True
    return False


def _is_unknown_semantics(query: dict) -> bool:
    return _objective_type(query) not in _KNOWN_TYPES


def _is_robust_aggregate(query: dict) -> bool:
    return query["quantification"] == Quantification.ROBUST_AGGREGATE


def _is_finite_ledger(query: dict) -> bool:
    return _objective_type(query) in LEDGER_TYPES and bool(query["objective_family"].get("cases"))


def _accepts_bounded_regret(query: dict) -> bool:
    regret = query.get("bounded_regret") or {}
    if not regret.get("accept_approximation"):
        return False
    tolerance = regret.get("tolerance")
    return tolerance is not None and Exact(tolerance) > Exact(0)


def _is_monotone_nonadditive(query: dict) -> bool:
    return _objective_type(query) in MONOTONE_NONADDITIVE_TYPES


def _is_additive_price(query: dict) -> bool:
    return (
        _objective_type(query) in ADDITIVE_TYPES
        and _all_weights_nonnegative(query)
        and query["quantification"] == Quantification.EACH_OBJECTIVE
    )


#: Specification 26.4, evaluated in order.  The first matching row wins; the
#: order encodes "strongest requirement first", so a query that is both
#: realization sensitive and additive still yields the realization registry.
MAPPING_TABLE: Tuple[MappingRule, ...] = (
    MappingRule(
        rule_id="R-REAL-01",
        spec_citation="26.4 row 1-2; 19.6",
        decision_class=ObservationLevel.REALIZATION,
        required_object=ObservationLevel.REQUIRED_OBJECT[ObservationLevel.REALIZATION],
        description=(
            "The decision depends on realization identity, schedule, topology, ownership, "
            "embedding, transition, placement, provenance, or artifact, or names required "
            "retained identities; signature geometry alone cannot answer it."
        ),
        predicate=_is_realization_sensitive,
    ),
    MappingRule(
        rule_id="R-EXACT-02",
        spec_citation="26.4 row 3",
        decision_class=ObservationLevel.EXACT_REGION,
        required_object=ObservationLevel.REQUIRED_OBJECT[ObservationLevel.EXACT_REGION],
        description=(
            "The decision is exact-signature sensitive or nonmonotone: exact joint "
            "attainability of a point, a nonmonotone objective, or a price family that "
            "admits a negative weight.  Only exact R answers it."
        ),
        predicate=_needs_exact_region,
    ),
    MappingRule(
        rule_id="R-UNKNOWN-03",
        spec_citation="26.4 final row; 26.6",
        decision_class=ObservationLevel.EXACT_REGION,
        required_object=ObservationLevel.REQUIRED_OBJECT[ObservationLevel.EXACT_REGION],
        description=(
            "Unknown or mixed objective semantics: the compiler preserves exact R rather "
            "than guess a quotient it cannot justify."
        ),
        predicate=_is_unknown_semantics,
    ),
    MappingRule(
        rule_id="R-ROBUST-04",
        spec_citation="26.3; 26.4 row 6",
        decision_class=ObservationLevel.MONOTONE,
        required_object=ObservationLevel.REQUIRED_OBJECT[ObservationLevel.MONOTONE],
        description=(
            "Coupled robust aggregate over a weight or scenario family.  The inner family "
            "is monotone, so Gamma is sufficient, but the aggregate is a supremum of "
            "linear forms and is NOT an additive price: it MUST NOT be reduced to K."
        ),
        predicate=_is_robust_aggregate,
    ),
    MappingRule(
        rule_id="R-LEDGER-05",
        spec_citation="26.4 row 7; 29.3",
        decision_class=ObservationLevel.FINITE_LEDGER,
        required_object=ObservationLevel.REQUIRED_OBJECT[ObservationLevel.FINITE_LEDGER],
        description=(
            "A finite named set of technology and objective cases: an argmin-hitting "
            "retained set with witnesses is sufficient while the ledger stays closed."
        ),
        predicate=_is_finite_ledger,
    ),
    MappingRule(
        rule_id="R-APPROX-06",
        spec_citation="26.4 row 8; 20.5",
        decision_class=ObservationLevel.APPROXIMATE,
        required_object=ObservationLevel.REQUIRED_OBJECT[ObservationLevel.APPROXIMATE],
        description=(
            "The query explicitly accepts a bounded-regret approximation with a declared "
            "positive tolerance, so a certified approximation carrying an explicit regret "
            "bound is the minimum sufficient object."
        ),
        predicate=_accepts_bounded_regret,
    ),
    MappingRule(
        rule_id="R-MONO-07",
        spec_citation="26.4 row 4; 19.3, 19.4",
        decision_class=ObservationLevel.MONOTONE,
        required_object=ObservationLevel.REQUIRED_OBJECT[ObservationLevel.MONOTONE],
        description=(
            "Continuous coordinatewise monotone but non-additive resource decision "
            "(max, weighted max, bottleneck, Chebyshev).  Such an objective is not "
            "determined by the support values of nonnegative additive prices, so K is "
            "refused and Gamma is required."
        ),
        predicate=_is_monotone_nonadditive,
    ),
    MappingRule(
        rule_id="R-ADD-08",
        spec_citation="26.4 row 5; 19.4",
        decision_class=ObservationLevel.ADDITIVE_PRICE,
        required_object=ObservationLevel.REQUIRED_OBJECT[ObservationLevel.ADDITIVE_PRICE],
        description=(
            "Each objective in a nonnegative additive-price family evaluated separately. "
            "A fixed price vector, a range of prices, and a finite set of prices are all "
            "additive: every one of them sees exactly K."
        ),
        predicate=_is_additive_price,
    ),
)


def mapping_table_digest() -> str:
    """Content hash of the mapping table, pinned alongside its version."""
    return content_hash(
        {
            "mapping_table_version": MAPPING_TABLE_VERSION,
            "rules": [rule.to_canonical() for rule in MAPPING_TABLE],
        }
    )


#: Retention policies that are sufficient for each required object (29.3).
RETENTION_SUFFICIENCY: Dict[str, Tuple[str, ...]] = {
    "REALIZATION_REGISTRY_AND_FIBERS": (RetentionPolicy.RETAIN_ALL, RetentionPolicy.FIBER_PRESERVING),
    "R": (
        RetentionPolicy.RETAIN_ALL,
        RetentionPolicy.FIBER_PRESERVING,
        RetentionPolicy.RETAIN_ALL_SIGNATURES,
    ),
    "GAMMA": (
        RetentionPolicy.RETAIN_ALL,
        RetentionPolicy.FIBER_PRESERVING,
        RetentionPolicy.RETAIN_ALL_SIGNATURES,
        RetentionPolicy.UNIVERSAL_MONOTONE,
    ),
    "K": (
        RetentionPolicy.RETAIN_ALL,
        RetentionPolicy.FIBER_PRESERVING,
        RetentionPolicy.RETAIN_ALL_SIGNATURES,
        RetentionPolicy.UNIVERSAL_MONOTONE,
        RetentionPolicy.ADDITIVE_PRICE_VISIBLE,
    ),
    "ARGMIN_HITTING_SET": tuple(sorted(RetentionPolicy.ALL - {RetentionPolicy.BOUNDED_REGRET})),
    "BOUNDED_REGRET_REPRESENTATION": tuple(sorted(RetentionPolicy.ALL)),
}

DEFAULT_RETENTION: Dict[str, str] = {
    "REALIZATION_REGISTRY_AND_FIBERS": RetentionPolicy.FIBER_PRESERVING,
    "R": RetentionPolicy.RETAIN_ALL_SIGNATURES,
    "GAMMA": RetentionPolicy.UNIVERSAL_MONOTONE,
    "K": RetentionPolicy.ADDITIVE_PRICE_VISIBLE,
    "ARGMIN_HITTING_SET": RetentionPolicy.ARGMIN_HITTING,
    "BOUNDED_REGRET_REPRESENTATION": RetentionPolicy.BOUNDED_REGRET,
}

#: Why each strictly weaker geometric object is unsafe for a given rule.
_REFUSAL_REASON: Dict[str, str] = {
    "K": (
        "K retains only the convex hull plus the nonnegative orthant, so it preserves "
        "exactly the support values of nonnegative additive price vectors; any Pareto "
        "point interior to the hull may be discarded"
    ),
    "GAMMA": (
        "Gamma retains only the Pareto-minimal antichain of the upper set, so dominated "
        "signatures and exact joint attainability of non-frontier points are lost"
    ),
    "R": (
        "R retains exact signatures but not realization identity, so fibers, schedule, "
        "topology, ownership, placement, and transition data are lost"
    ),
    "REALIZATION_REGISTRY_AND_FIBERS": (
        "the realization registry is the richest retained object and cannot be refused"
    ),
}


def _refusals(query: dict, rule: MappingRule) -> List[str]:
    """Actual refused user requests (spec 26.6), not explanatory alternatives.

    Section 26.5 also requires the derivation to disclose every rejected
    lower-information alternative.  Those are recorded by :func:`_notes` even
    when the user did not ask for one.  Keeping them distinct matters to
    machine callers: a normal ``max`` query derives Gamma and records why K is
    insufficient, but it has not *been refused*.  Only an unsafe requested
    override (or an insufficient retention policy below) is a refusal.
    """
    required = rule.required_object
    refusals: List[str] = []
    required_rank = INFORMATION_ORDER[required]
    requested = query.get("requested_object")
    if requested and INFORMATION_ORDER[requested] < required_rank:
        refusals.append(
            f"REFUSED {requested}: rule {rule.rule_id} (spec {rule.spec_citation}) requires "
            f"{required}; {_REFUSAL_REASON[requested]}."
        )
        refusals.append(
            f"REFUSED REQUESTED OBJECT {requested}: spec 26.6 -- a user override MUST NOT "
            f"force an unsafe lower-information certificate; rule {rule.rule_id} requires "
            f"{required}."
        )
    return refusals


def _retention_policy(query: dict, rule: MappingRule, refusals: List[str]) -> str:
    """Choose a retention policy sufficient for the required object (29.3)."""
    required = rule.required_object
    declared = (query.get("retention") or {}).get("policy")
    if not declared:
        return DEFAULT_RETENTION[required]
    if declared in RetentionPolicy.DECLARED_UNSUPPORTED:
        refusals.append(
            f"REFUSED RETENTION POLICY {declared!r}: specification 29.3 names the policy, "
            "but this profile has no registered constructive or verification semantics for "
            f"it; using {DEFAULT_RETENTION[required]}."
        )
        return DEFAULT_RETENTION[required]
    if declared not in RetentionPolicy.ALL:
        refusals.append(
            f"REFUSED RETENTION POLICY {declared!r}: not a specification 29.3 retention "
            f"policy; using {DEFAULT_RETENTION[required]}."
        )
        return DEFAULT_RETENTION[required]
    if declared in RETENTION_SUFFICIENCY[required]:
        return declared
    refusals.append(
        f"REFUSED RETENTION POLICY {declared!r}: spec 26.6, 29.3 -- it is not sufficient "
        f"for required object {required} under rule {rule.rule_id}; overridden to "
        f"{DEFAULT_RETENTION[required]}."
    )
    return DEFAULT_RETENTION[required]


def _notes(query: dict, rule: MappingRule) -> List[str]:
    """Specification 26.5 derivation-record content carried as typed notes.

    The foundation ``DerivationRecord`` carries free-form notes; the fields
    section 26.5 requires beyond the typed columns are recorded here as
    ``key=value`` strings so they remain canonical and verifier readable.
    """
    family = query["objective_family"]
    interpreted = [f"type={family.get('type')}", f"quantification={query['quantification']}"]
    if "weights_are_ranges" in family:
        interpreted.append(
            "price_domain=" + ("RANGE_OR_SET" if family["weights_are_ranges"] else "FIXED_VECTOR")
        )
    if family.get("cases"):
        interpreted.append(f"ledger_cases={len(family['cases'])}")
    notes = [
        "interpreted_semantics=" + ";".join(interpreted),
        f"uncertainty_interpretation={query['uncertainty']['mode']}",
        "completeness_requirement=" + _completeness_requirement(rule.required_object),
        f"compiler_version={COMPILER_VERSION}",
        f"mapping_table_digest={mapping_table_digest()}",
        f"verification_program={VIR_PROGRAM}",
    ]
    rejected = [
        candidate
        for candidate in GEOMETRIC_CHAIN
        if INFORMATION_ORDER[candidate] < INFORMATION_ORDER[rule.required_object]
    ]
    for candidate in rejected:
        notes.append(
            f"rejected_lower_information_alternative={candidate};"
            f"required={rule.required_object};reason={_REFUSAL_REASON[candidate]}"
        )
    if rule.rule_id == "R-LEDGER-05":
        notes.append(
            "ledger_closure=an argmin-hitting set is sufficient only while the declared "
            "ledger of technology and objective cases stays closed; adding a case reopens "
            "the decision (spec 26.4, 30)"
        )
    if rule.rule_id == "R-ROBUST-04":
        notes.append(
            "robust_coupling=min over realizations of the supremum over the weight family "
            "is a coupled aggregate; spec 26.3 forbids reducing it to K automatically"
        )
    if rule.rule_id == "R-ADD-08" and query["objective_family"].get("weights_are_ranges"):
        notes.append(
            "price_range=a range or set of nonnegative additive prices is still additive; "
            "every member sees exactly K, so the range does not raise the requirement"
        )
    if rule.rule_id == "R-APPROX-06":
        notes.append(
            "approximation_limit=spec 20.5 -- an approximation may support bounded-regret "
            "certification, possible-winner sets, or refusal, never an exact-geometry claim"
        )
    return notes


def _completeness_requirement(required_object: str) -> str:
    if required_object == "REALIZATION_REGISTRY_AND_FIBERS":
        return "COMPLETE_REGISTRY_WITH_FIBERS"
    if required_object == "R":
        return "COMPLETE_SIGNATURE_SET"
    if required_object == "GAMMA":
        return "COMPLETE_FRONTIER"
    if required_object == "K":
        return "COMPLETE_EXTREME_VERTEX_SET"
    if required_object == "ARGMIN_HITTING_SET":
        return "CLOSED_DECLARED_LEDGER"
    return "DECLARED_REGRET_BOUND"


def compile_query(query: dict) -> Tuple[DecisionScope, DerivationRecord]:
    """Compile a decision query to its minimum sufficient retained object.

    Specification 26.4 (normative decision-observation mapping), 26.5
    (derivation record), and 26.6 (soundness behavior).  The returned
    :class:`DecisionScope` is what the certifier evaluates against; the
    returned :class:`DerivationRecord` cites the mapping rule that produced it
    and records every rejected lower-information alternative.

    The compiler never downgrades on request: a ``requested_object`` weaker
    than the required object becomes a refusal, per 26.6.
    """
    canonical = parse_query(query)

    rule: Optional[MappingRule] = None
    for candidate in MAPPING_TABLE:
        if candidate.predicate(canonical):
            rule = candidate
            break
    if rule is None:  # pragma: no cover - the table is total by construction
        raise QueryError(
            "no mapping rule matched; spec 26.6 requires refusing reduction rather than "
            "guessing a quotient"
        )

    refusals = _refusals(canonical, rule)
    retention_policy = _retention_policy(canonical, rule, refusals)

    objective_family = dict(canonical["objective_family"])
    objective_family["quantification"] = canonical["quantification"]
    if canonical["price_domain"]:
        objective_family["price_domain"] = canonical["price_domain"]
    if canonical["bounded_regret"]:
        objective_family["bounded_regret"] = canonical["bounded_regret"]
    if canonical["required_retained_identities"]:
        objective_family["required_retained_identities"] = canonical[
            "required_retained_identities"
        ]
    if canonical["realization_sensitivity"]:
        objective_family["realization_sensitivity"] = canonical["realization_sensitivity"]

    scope = DecisionScope(
        scope_id=canonical["decision_id"],
        observation_level=rule.decision_class,
        objective_family=objective_family,
        technology_domain=canonical["technology_domain"],
        tie_tolerance=Exact(canonical["ties"]["policy_tolerance"]),
        retain_all_ties=canonical["ties"]["retain_all"],
        retention_policy=retention_policy,
        uncertainty_mode=canonical["uncertainty"]["mode"],
        validity=canonical["validity"],
    )
    derivation = DerivationRecord(
        query_hash=content_hash(canonical),
        mapping_table_version=MAPPING_TABLE_VERSION,
        decision_class=rule.decision_class,
        required_object=rule.required_object,
        rule_cited=f"{rule.rule_id} (spec {rule.spec_citation}): {rule.description}",
        refusals=tuple(refusals),
        notes=tuple(_notes(canonical, rule)),
    )
    return scope, derivation


def bind_schema(scope: DecisionScope, schema: Any) -> DecisionScope:
    """Return ``scope`` with its coordinate order bound to ``schema``.

    A query names weights by coordinate identifier; a :class:`Signature` is
    positional.  Binding records the declared coordinate order (spec 19.1:
    coordinate order is part of canonicalization) so objective evaluation can
    never silently transpose two coordinates.
    """
    identifiers = tuple(schema.identifiers)
    family = dict(scope.objective_family)
    existing = family.get("coordinate_order")
    if existing is not None and tuple(existing) != identifiers:
        raise QueryError(
            "declared coordinate order does not match the bundle schema "
            f"({tuple(existing)} vs {identifiers})"
        )
    weights = family.get("weights")
    if weights:
        unknown = set(weights) - set(identifiers)
        if unknown:
            raise QueryError(f"objective weights name coordinates absent from the schema: {sorted(unknown)}")
    family["coordinate_order"] = list(identifiers)
    if family.get("cases"):
        bound_cases = []
        for case in family["cases"]:
            entry = dict(case)
            case_weights = entry.get("weights")
            if case_weights:
                unknown = set(case_weights) - set(identifiers)
                if unknown:
                    raise QueryError(
                        f"ledger case {entry.get('case_id')!r} names unknown coordinates: {sorted(unknown)}"
                    )
            entry["coordinate_order"] = list(identifiers)
            bound_cases.append(entry)
        family["cases"] = bound_cases
    return DecisionScope(
        scope_id=scope.scope_id,
        observation_level=scope.observation_level,
        objective_family=family,
        technology_domain=scope.technology_domain,
        tie_tolerance=scope.tie_tolerance,
        retain_all_ties=scope.retain_all_ties,
        retention_policy=scope.retention_policy,
        uncertainty_mode=scope.uncertainty_mode,
        validity=scope.validity,
    )


def ledger_case_scopes(scope: DecisionScope) -> Tuple[DecisionScope, ...]:
    """Explode a finite-ledger scope into one scope per declared case (26.4).

    Each case is an ordinary objective family; the argmin-hitting retention
    set is the union of the argmin sets of these per-case scopes.
    """
    cases = scope.objective_family.get("cases")
    if not cases:
        return (scope,)
    scopes = []
    for case in cases:
        family = dict(case)
        family.setdefault("quantification", Quantification.EACH_OBJECTIVE)
        if scope.objective_family.get("coordinate_order") and not family.get("coordinate_order"):
            family["coordinate_order"] = list(scope.objective_family["coordinate_order"])
        scopes.append(
            DecisionScope(
                scope_id=f"{scope.scope_id}::{case.get('case_id')}",
                observation_level=scope.observation_level,
                objective_family=family,
                technology_domain=scope.technology_domain,
                tie_tolerance=scope.tie_tolerance,
                retain_all_ties=scope.retain_all_ties,
                retention_policy=scope.retention_policy,
                uncertainty_mode=scope.uncertainty_mode,
                validity=scope.validity,
            )
        )
    return tuple(scopes)

# v1.3 composite closure: this product path is phase-bound to ETQ integration.
