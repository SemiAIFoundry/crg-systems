"""crg-certify: decision-query compilation, safe commitment, certified pruning.

Reference implementation of the CRG Operational Systems Master Specification
v0.2.0, sections 21, 22, 26, 27, and 29.  This is the module that decides, so
every path here is exact-rational or exact-interval and every refusal is
recorded rather than resolved.

The v1.3 ETQ lifecycle consumes these certificates without extending this
package's decision authority.
"""
from .query import (
    COMPILER_VERSION,
    MAPPING_TABLE,
    MAPPING_TABLE_VERSION,
    MappingRule,
    Quantification,
    QueryError,
    RetentionPolicy,
    bind_schema,
    compile_query,
    ledger_case_scopes,
    mapping_table_digest,
    parse_query,
)
from .certify import (
    ENGINE_VERSION,
    CertifyError,
    Comparison,
    Feasibility,
    GeometryUnavailable,
    ObjectiveError,
    certified_pruning,
    certify,
    compare_candidates,
    evaluate_objective,
    render_claim,
    retention_set,
    set_default_geometry,
)
from .regret import (
    REGRET_OBJECTIVE_FAMILY,
    RegretError,
    RegretObjective,
    build_regret_witness,
    lost_points,
    phi_value,
    verify_regret_witness,
    verify_regret_witness_detail,
)
from .commitment import (
    SAFE_COMMITMENT_PROFILE,
    SAFE_COMMITMENT_SCHEMA_VERSION,
    ConditionStatus,
    FutureDecision,
    FutureDecisionFamily,
    PolicyStatus,
    PruningAssessment,
    PruningCondition,
    RegretBoundFact,
    RegretEvidence,
    RetentionEvaluation,
    RetentionPolicyDeclaration,
    SafeCommitmentArtifact,
    assess_pruning,
    compare_retention_policies,
)
from .comparison import (
    COMPARISON_AUTHORITY,
    COMPARISON_CLAIM_BOUNDARY,
    COMPARISON_PROFILE,
    COMPARISON_SCHEMA_VERSION,
    ComparisonDesignError,
    ComparativeWorkflowEvaluation,
    build_comparative_workflow_evaluation,
)
from .phase_binding import PhaseBoundCertification, certify_with_certified_phase

__version__ = "1.3.0"
SPEC_VERSION = "0.2.0"

__all__ = [
    "COMPILER_VERSION",
    "ENGINE_VERSION",
    "MAPPING_TABLE",
    "MAPPING_TABLE_VERSION",
    "MappingRule",
    "Quantification",
    "QueryError",
    "RetentionPolicy",
    "CertifyError",
    "Comparison",
    "Feasibility",
    "GeometryUnavailable",
    "ObjectiveError",
    "REGRET_OBJECTIVE_FAMILY",
    "RegretError",
    "RegretObjective",
    "bind_schema",
    "build_regret_witness",
    "certified_pruning",
    "certify",
    "compare_candidates",
    "compile_query",
    "evaluate_objective",
    "ledger_case_scopes",
    "lost_points",
    "mapping_table_digest",
    "parse_query",
    "phi_value",
    "render_claim",
    "retention_set",
    "set_default_geometry",
    "verify_regret_witness",
    "verify_regret_witness_detail",
    "SAFE_COMMITMENT_PROFILE",
    "SAFE_COMMITMENT_SCHEMA_VERSION",
    "ConditionStatus",
    "FutureDecision",
    "FutureDecisionFamily",
    "PolicyStatus",
    "PruningAssessment",
    "PruningCondition",
    "RegretBoundFact",
    "RegretEvidence",
    "RetentionEvaluation",
    "RetentionPolicyDeclaration",
    "SafeCommitmentArtifact",
    "assess_pruning",
    "compare_retention_policies",
    "COMPARISON_AUTHORITY",
    "COMPARISON_CLAIM_BOUNDARY",
    "COMPARISON_PROFILE",
    "COMPARISON_SCHEMA_VERSION",
    "ComparisonDesignError",
    "ComparativeWorkflowEvaluation",
    "build_comparative_workflow_evaluation",
    "PhaseBoundCertification",
    "certify_with_certified_phase",
]
