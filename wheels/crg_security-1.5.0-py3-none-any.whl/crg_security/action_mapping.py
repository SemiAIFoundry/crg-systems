"""Non-authorizing host action mapping profiles (Advancement A1.1).

The profile composes existing CRG assessment records, independent verifier
profiles, and host-policy permissions.  Resolving a mapping states what must
be assessed; it never evaluates policy or authorizes execution.
"""

from __future__ import annotations

import json
from typing import Any, Mapping, Sequence

from crg_model.canonical import canonical_json, content_hash
from crg_model.schema import SchemaError, schema_for, validate_or_raise

from .roles import PERMISSIONS, ROLES

__all__ = [
    "ACTION_MAPPING_SCHEMA_VERSION",
    "ActionMappingError",
    "build_action_mapping_profile",
    "resolve_action_requirement",
    "validate_action_mapping_profile",
]

ACTION_MAPPING_SCHEMA_VERSION = "1.0.0"


class ActionMappingError(ValueError):
    """An action mapping is malformed, unsupported, or authority-bearing."""


def _document(value: Any, field: str) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise ActionMappingError(f"{field} must be a canonical object")
    try:
        return json.loads(canonical_json(dict(value)))
    except (TypeError, ValueError) as error:
        raise ActionMappingError(f"{field} is not canonical CRG content: {error}") from error


def _sorted_unique(values: Any, field: str, *, nonempty: bool = False) -> list[str]:
    if not isinstance(values, list) or (nonempty and not values):
        raise ActionMappingError(f"{field} must be a{' non-empty' if nonempty else ''} list")
    if not all(isinstance(value, str) and value for value in values):
        raise ActionMappingError(f"{field} contains an invalid identifier")
    if values != sorted(set(values)):
        raise ActionMappingError(f"{field} must be sorted and unique")
    return values


def _validate_semantics(record: Mapping[str, Any]) -> None:
    if record.get("authority") != "NON_AUTHORIZING" or record.get("execution_authorized") is not False:
        raise ActionMappingError("an action mapping profile cannot grant execution authority")
    mappings = record.get("mappings")
    if not isinstance(mappings, list) or not mappings:
        raise ActionMappingError("an action mapping profile requires at least one mapping")
    action_classes = [mapping.get("action_class") for mapping in mappings if isinstance(mapping, Mapping)]
    if len(action_classes) != len(mappings) or action_classes != sorted(set(action_classes)):
        raise ActionMappingError("action mappings must be sorted and unique by action_class")
    for mapping in mappings:
        subject = mapping["subject"]
        actor_kinds = _sorted_unique(subject["allowed_actor_kinds"], "allowed_actor_kinds", nonempty=True)
        roles = _sorted_unique(subject["required_roles"], "required_roles")
        if any(role not in ROLES for role in roles):
            raise ActionMappingError("action mapping names an unknown existing host role")
        if not actor_kinds:
            raise ActionMappingError("action mapping has no supported actor kind")
        assessment = mapping["assessment"]
        _sorted_unique(assessment["required_statuses"], "required_statuses", nonempty=True)
        _sorted_unique(assessment["required_evidence"], "required_evidence", nonempty=True)
        try:
            schema_for(assessment["record_type"])
        except SchemaError as error:
            raise ActionMappingError("action mapping names an unregistered assessment record") from error
        if mapping["host_policy"]["permission"] not in PERMISSIONS:
            raise ActionMappingError("action mapping names an unknown existing host permission")
    expected_hash = content_hash({key: value for key, value in record.items() if key != "profile_hash"})
    if record.get("profile_hash") != expected_hash:
        raise ActionMappingError("action mapping profile hash differs from canonical content")


def validate_action_mapping_profile(value: Any) -> dict[str, Any]:
    """Validate and detach one complete ActionMappingProfile."""

    record = _document(value, "action mapping profile")
    try:
        validate_or_raise(record, schema_for("ActionMappingProfile"))
    except Exception as error:
        raise ActionMappingError(f"action mapping profile schema validation failed: {error}") from error
    _validate_semantics(record)
    return record


def build_action_mapping_profile(
    *,
    profile_id: str,
    profile_version: str,
    mappings: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    """Build a byte-stable profile over existing assessment and policy identities."""

    detached = [_document(mapping, "action mapping") for mapping in mappings]
    detached.sort(key=lambda mapping: mapping.get("action_class", ""))
    record = {
        "record_type": "ActionMappingProfile",
        "schema_version": ACTION_MAPPING_SCHEMA_VERSION,
        "profile_id": profile_id,
        "profile_version": profile_version,
        "authority": "NON_AUTHORIZING",
        "execution_authorized": False,
        "mappings": detached,
        "unknown_action_result": "REFUSED_UNKNOWN_ACTION",
        "unsupported_action_result": "REFUSED_UNSUPPORTED_ACTION_CONTEXT",
    }
    record["profile_hash"] = content_hash(record)
    return validate_action_mapping_profile(record)


def resolve_action_requirement(
    profile: Mapping[str, Any],
    *,
    action_class: str,
    actor_kind: str,
    case_id: str | None = None,
    branch_id: str | None = None,
    causal_parent_id: str | None = None,
) -> dict[str, Any]:
    """Resolve required assessment inputs without making a host decision."""

    record = validate_action_mapping_profile(profile)
    mapping = next(
        (item for item in record["mappings"] if item["action_class"] == action_class),
        None,
    )
    if mapping is None:
        return {
            "action_class": action_class,
            "authority": "NON_AUTHORIZING",
            "execution_authorized": False,
            "profile_hash": record["profile_hash"],
            "status": record["unknown_action_result"],
        }
    target = mapping["target"]
    supported = (
        actor_kind in mapping["subject"]["allowed_actor_kinds"]
        and (not target["case_id_required"] or bool(case_id))
        and (not target["branch_id_required"] or bool(branch_id))
        and (not target["causal_parent_required"] or bool(causal_parent_id))
    )
    if not supported:
        return {
            "action_class": action_class,
            "authority": "NON_AUTHORIZING",
            "execution_authorized": False,
            "profile_hash": record["profile_hash"],
            "status": record["unsupported_action_result"],
        }
    return {
        "action_class": action_class,
        "assessment": mapping["assessment"],
        "authority": "NON_AUTHORIZING",
        "execution_authorized": False,
        "host_policy": mapping["host_policy"],
        "mapping_hash": content_hash(mapping),
        "profile_hash": record["profile_hash"],
        "scope": mapping["scope"],
        "status": "ASSESSMENT_REQUIRED",
        "subject": mapping["subject"],
        "target": {
            "case_id": case_id,
            "branch_id": branch_id,
            "causal_parent_id": causal_parent_id,
        },
    }
