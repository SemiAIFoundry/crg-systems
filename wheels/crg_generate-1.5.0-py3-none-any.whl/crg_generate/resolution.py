"""A1.5 deterministic domain-package resolution and four-root context.

The resolver consumes the identities already produced by the domain-pack and
canonical-package layers.  It does not discover, fetch, install, import, or
execute anything.  Registry/mirror/trust state is captured in the resolution
root while the semantic root contains only semantic composition identities,
so an advisory or mirror update cannot silently rewrite semantic identity.
"""
from __future__ import annotations

import copy
import re
from typing import Any, Mapping, Sequence

from crg_model.canonical import content_hash
from crg_model.schema import schema_for, validate_or_raise

__all__ = [
    "PACKAGE_RESOLUTION_REFUSALS",
    "PackageResolutionError",
    "build_assessment_context_roots",
    "resolve_package_profile",
    "validate_assessment_context_roots",
    "validate_resolved_profile_lock",
]

PACKAGE_RESOLUTION_REFUSALS = frozenset({
    "INVALID_DECLARATION", "PACKAGE_COLLISION", "NAMESPACE_COLLISION",
    "NAMESPACE_PUBLISHER_UNAUTHORIZED", "OVERRIDE_UNAUTHORIZED",
    "UNAVAILABLE_ARTIFACT", "STALE_TRUST_STATE", "SIGNATURE_UNVERIFIED",
    "ADVISORY_BLOCKED", "PACKAGE_REVOKED", "DEPENDENCY_CYCLE",
    "DIAMOND_CONSTRAINT_CONFLICT", "PACKAGE_CONFLICT",
    "INCOMPATIBLE_CAPABILITY", "UNKNOWN_FEATURE", "UNSUPPORTED_VERSION_CONSTRAINT",
})

_HASH = re.compile(r"^sha256:[0-9a-f]{64}$")
_ID = re.compile(r"^[a-z0-9]+(?:[._-][a-z0-9]+)*$")
_VERSION = re.compile(r"^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$")
_CANDIDATE_FIELDS = {
    "package_id", "namespace", "publisher", "version", "package_form",
    "manifest_hash", "domain_manifest_hash", "archive_digest", "dependencies",
    "optional_features", "platform_variants", "provides_capabilities",
    "requires_capabilities", "conflicts", "registry_origin", "mirror_state",
    "trust_state", "availability",
}
_DEPENDENCY_FIELDS = {"package_id", "constraint"}
_TRUST_FIELDS = {
    "snapshot_hash", "status", "signature_status", "advisory_status",
    "revocation_status",
}
_MIRROR_FIELDS = {"mirror_id", "snapshot_hash", "status"}


class PackageResolutionError(ValueError):
    """A deterministic resolver refusal carrying a closed reason code."""

    def __init__(self, code: str, detail: str) -> None:
        if code not in PACKAGE_RESOLUTION_REFUSALS:
            raise ValueError(f"unknown package-resolution refusal {code!r}")
        self.code = code
        self.detail = detail
        super().__init__(f"{code}: {detail}")


def _refuse(code: str, detail: str) -> None:
    raise PackageResolutionError(code, detail)


def _object(value: Any, fields: set[str], label: str) -> dict[str, Any]:
    if not isinstance(value, Mapping) or set(value) != fields:
        _refuse("INVALID_DECLARATION", f"{label} fields differ")
    return copy.deepcopy(dict(value))


def _text(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value:
        _refuse("INVALID_DECLARATION", f"{label} must be a non-empty string")
    return value


def _identifier(value: Any, label: str) -> str:
    text = _text(value, label)
    if _ID.fullmatch(text) is None:
        _refuse("INVALID_DECLARATION", f"{label} is not a portable identifier")
    return text


def _hash(value: Any, label: str) -> str:
    if not isinstance(value, str) or _HASH.fullmatch(value) is None:
        _refuse("INVALID_DECLARATION", f"{label} is not an algorithm-tagged SHA-256 hash")
    return value


def _version(value: Any, label: str = "version") -> tuple[int, int, int]:
    if not isinstance(value, str):
        _refuse("INVALID_DECLARATION", f"{label} must be semantic version text")
    match = _VERSION.fullmatch(value)
    if match is None:
        _refuse("INVALID_DECLARATION", f"{label} must use exact major.minor.patch")
    return tuple(int(part) for part in match.groups())


def _sorted_strings(value: Any, label: str) -> list[str]:
    if not isinstance(value, (list, tuple)):
        _refuse("INVALID_DECLARATION", f"{label} must be an array")
    result = [_identifier(item, label) for item in value]
    if result != sorted(set(result), key=lambda item: item.encode("utf-8")):
        _refuse("INVALID_DECLARATION", f"{label} must be UTF-8 sorted and unique")
    return result


def _dependency(value: Any, label: str) -> dict[str, str]:
    item = _object(value, _DEPENDENCY_FIELDS, label)
    item["package_id"] = _identifier(item["package_id"], f"{label}.package_id")
    item["constraint"] = _text(item["constraint"], f"{label}.constraint")
    _constraint_parts(item["constraint"])
    return item


def _constraint_parts(value: str) -> tuple[tuple[str, tuple[int, int, int]], ...]:
    if value == "*":
        return ()
    parts = []
    for raw in value.split(","):
        part = raw.strip()
        match = re.fullmatch(r"(==|>=|<=|>|<)?(.+)", part)
        if match is None:
            _refuse("UNSUPPORTED_VERSION_CONSTRAINT", f"unsupported constraint {value!r}")
        operator = match.group(1) or "=="
        version_text = match.group(2)
        try:
            parsed = _version(version_text, "constraint version")
        except PackageResolutionError:
            _refuse("UNSUPPORTED_VERSION_CONSTRAINT", f"unsupported constraint {value!r}")
        parts.append((operator, parsed))
    return tuple(parts)


def _matches(version: str, constraint: str) -> bool:
    current = _version(version)
    for operator, expected in _constraint_parts(constraint):
        if operator == "==" and current != expected:
            return False
        if operator == ">=" and current < expected:
            return False
        if operator == "<=" and current > expected:
            return False
        if operator == ">" and current <= expected:
            return False
        if operator == "<" and current >= expected:
            return False
    return True


def _candidate(value: Any) -> dict[str, Any]:
    item = _object(value, _CANDIDATE_FIELDS, "package candidate")
    item["package_id"] = _identifier(item["package_id"], "package_id")
    item["namespace"] = _identifier(item["namespace"], "namespace")
    item["publisher"] = _text(item["publisher"], "publisher")
    _version(item["version"])
    if item["package_id"] != item["namespace"] and not item["package_id"].startswith(item["namespace"] + "."):
        _refuse("NAMESPACE_COLLISION", f"{item['package_id']} is outside {item['namespace']}")
    if item["package_form"] not in {"DECLARATIVE", "EXECUTABLE", "AGGREGATE", "PROFILE", "DATA_RESOURCE"}:
        _refuse("INVALID_DECLARATION", "package form is unsupported")
    for field in ("manifest_hash", "domain_manifest_hash", "archive_digest"):
        _hash(item[field], field)
    if not isinstance(item["dependencies"], list):
        _refuse("INVALID_DECLARATION", "dependencies must be an array")
    item["dependencies"] = [_dependency(row, "dependency") for row in item["dependencies"]]
    item["dependencies"].sort(key=lambda row: (row["package_id"].encode("utf-8"), row["constraint"]))
    if len({row["package_id"] for row in item["dependencies"]}) != len(item["dependencies"]):
        _refuse("INVALID_DECLARATION", "dependencies repeat a package")
    if not isinstance(item["optional_features"], Mapping):
        _refuse("INVALID_DECLARATION", "optional_features must be an object")
    features = {}
    for raw_name, raw_dependencies in item["optional_features"].items():
        name = _identifier(raw_name, "feature")
        if not isinstance(raw_dependencies, list):
            _refuse("INVALID_DECLARATION", f"feature {name} dependencies must be an array")
        rows = [_dependency(row, f"feature {name} dependency") for row in raw_dependencies]
        rows.sort(key=lambda row: (row["package_id"].encode("utf-8"), row["constraint"]))
        features[name] = rows
    item["optional_features"] = {key: features[key] for key in sorted(features, key=lambda key: key.encode("utf-8"))}
    if not isinstance(item["platform_variants"], Mapping):
        _refuse("INVALID_DECLARATION", "platform_variants must be an object")
    variants = {}
    for raw_platform, digest in item["platform_variants"].items():
        platform = _identifier(raw_platform, "platform")
        variants[platform] = _hash(digest, f"platform variant {platform}")
    item["platform_variants"] = {key: variants[key] for key in sorted(variants)}
    for field in ("provides_capabilities", "requires_capabilities", "conflicts"):
        item[field] = _sorted_strings(item[field], field)
    item["registry_origin"] = _text(item["registry_origin"], "registry_origin")
    mirror = _object(item["mirror_state"], _MIRROR_FIELDS, "mirror_state")
    mirror["mirror_id"] = _text(mirror["mirror_id"], "mirror_id")
    _hash(mirror["snapshot_hash"], "mirror snapshot")
    if mirror["status"] not in {"CURRENT", "STALE", "PRIMARY"}:
        _refuse("INVALID_DECLARATION", "mirror status is unknown")
    item["mirror_state"] = mirror
    trust = _object(item["trust_state"], _TRUST_FIELDS, "trust_state")
    _hash(trust["snapshot_hash"], "trust snapshot")
    if trust["status"] not in {"CURRENT", "STALE"}:
        _refuse("INVALID_DECLARATION", "trust status is unknown")
    if trust["signature_status"] not in {"VERIFIED", "UNVERIFIED"}:
        _refuse("INVALID_DECLARATION", "signature status is unknown")
    if trust["advisory_status"] not in {"CLEAR", "ACKNOWLEDGED", "BLOCKED"}:
        _refuse("INVALID_DECLARATION", "advisory status is unknown")
    if trust["revocation_status"] not in {"ACTIVE", "REVOKED", "UNKNOWN"}:
        _refuse("INVALID_DECLARATION", "revocation status is unknown")
    item["trust_state"] = trust
    if item["availability"] not in {"AVAILABLE", "UNAVAILABLE"}:
        _refuse("INVALID_DECLARATION", "availability is unknown")
    return item


def _candidate_gate(item: Mapping[str, Any], namespace_authorities: Mapping[str, list[str]]) -> None:
    if item["publisher"] not in namespace_authorities.get(item["namespace"], []):
        _refuse("NAMESPACE_PUBLISHER_UNAUTHORIZED", f"publisher {item['publisher']} does not control {item['namespace']}")
    if item["availability"] != "AVAILABLE":
        _refuse("UNAVAILABLE_ARTIFACT", f"{item['package_id']}@{item['version']} is unavailable")
    trust = item["trust_state"]
    if trust["status"] != "CURRENT":
        _refuse("STALE_TRUST_STATE", f"{item['package_id']} trust snapshot is stale")
    if trust["signature_status"] != "VERIFIED":
        _refuse("SIGNATURE_UNVERIFIED", f"{item['package_id']} signature is not verified")
    if trust["advisory_status"] == "BLOCKED":
        _refuse("ADVISORY_BLOCKED", f"{item['package_id']} has a blocking advisory")
    if trust["revocation_status"] != "ACTIVE":
        _refuse("PACKAGE_REVOKED", f"{item['package_id']} is revoked or has unknown revocation state")


def resolve_package_profile(
    *,
    root_requests: Sequence[Mapping[str, Any]],
    candidates: Sequence[Mapping[str, Any]],
    selected_features: Mapping[str, Sequence[str]],
    platform: str,
    namespace_authorities: Mapping[str, Sequence[str]],
    overrides: Sequence[Mapping[str, Any]] = (),
    override_authorities: Mapping[str, str] | None = None,
    host_capabilities: Sequence[str] = (),
    resolver_version: str = "1.0.0",
    composition_abi: str = "1.0.0",
) -> dict[str, Any]:
    """Resolve exact package candidates without fetching or executing them."""

    platform = _identifier(platform, "platform")
    _version(resolver_version, "resolver_version")
    _version(composition_abi, "composition_abi")
    authorities = {}
    for namespace, publishers in namespace_authorities.items():
        name = _identifier(namespace, "namespace authority")
        values = sorted({_text(value, "authorized publisher") for value in publishers})
        if not values:
            _refuse("INVALID_DECLARATION", f"namespace {name} has no publisher authority")
        authorities[name] = values
    authorities = {key: authorities[key] for key in sorted(authorities)}

    pool: dict[str, list[dict[str, Any]]] = {}
    seen_versions = set()
    for raw in candidates:
        item = _candidate(raw)
        identity = (item["package_id"], item["version"])
        if identity in seen_versions:
            _refuse("PACKAGE_COLLISION", f"candidate {identity[0]}@{identity[1]} occurs more than once")
        seen_versions.add(identity)
        pool.setdefault(item["package_id"], []).append(item)
    for values in pool.values():
        values.sort(key=lambda item: _version(item["version"]), reverse=True)

    requests = [_dependency(value, "root request") for value in root_requests]
    requests.sort(key=lambda row: row["package_id"].encode("utf-8"))
    if not requests or len({row["package_id"] for row in requests}) != len(requests):
        _refuse("INVALID_DECLARATION", "root requests must be non-empty and unique")

    features = {}
    for raw_package, raw_features in selected_features.items():
        package_id = _identifier(raw_package, "selected-feature package")
        features[package_id] = _sorted_strings(raw_features, f"features for {package_id}")
    features = {key: features[key] for key in sorted(features)}

    authority_map = dict(override_authorities or {})
    override_rows = []
    override_by_package = {}
    for raw in overrides:
        row = _object(raw, {"package_id", "version", "authority_id", "authority_hash", "reason"}, "override")
        row["package_id"] = _identifier(row["package_id"], "override package")
        _version(row["version"], "override version")
        row["authority_id"] = _identifier(row["authority_id"], "override authority")
        _hash(row["authority_hash"], "override authority hash")
        row["reason"] = _text(row["reason"], "override reason")
        if authority_map.get(row["authority_id"]) != row["authority_hash"]:
            _refuse("OVERRIDE_UNAUTHORIZED", f"override for {row['package_id']} lacks exact authority")
        if row["package_id"] in override_by_package:
            _refuse("INVALID_DECLARATION", f"multiple overrides target {row['package_id']}")
        override_by_package[row["package_id"]] = row
        override_rows.append(row)
    override_rows.sort(key=lambda row: row["package_id"].encode("utf-8"))

    selected: dict[str, dict[str, Any]] = {}
    constraints: dict[str, list[str]] = {}
    edges: list[dict[str, Any]] = []
    stack: list[str] = []

    def visit(requirement: Mapping[str, str], parent: str | None, kind: str, feature: str | None) -> None:
        package_id = requirement["package_id"]
        constraint = requirement["constraint"]
        constraints.setdefault(package_id, []).append(constraint)
        if package_id in stack:
            chain = " -> ".join(stack + [package_id])
            _refuse("DEPENDENCY_CYCLE", chain)
        if parent is not None:
            edges.append({
                "from": parent, "to": package_id, "constraint": constraint,
                "kind": kind, "feature": feature,
            })
        existing = selected.get(package_id)
        if existing is not None:
            if not all(_matches(existing["version"], value) for value in constraints[package_id]):
                _refuse("DIAMOND_CONSTRAINT_CONFLICT", f"{package_id} constraints {sorted(constraints[package_id])} disagree")
            return
        available = pool.get(package_id, [])
        override = override_by_package.get(package_id)
        if override is not None:
            available = [item for item in available if item["version"] == override["version"]]
        compatible = [
            item for item in available
            if all(_matches(item["version"], value) for value in constraints[package_id])
        ]
        if not compatible:
            code = "DIAMOND_CONSTRAINT_CONFLICT" if len(constraints[package_id]) > 1 else "UNAVAILABLE_ARTIFACT"
            _refuse(code, f"no candidate for {package_id} satisfies {sorted(constraints[package_id])}")
        item = compatible[0]
        _candidate_gate(item, authorities)
        selected[package_id] = item
        stack.append(package_id)
        selected_names = features.get(package_id, [])
        unknown = sorted(set(selected_names) - set(item["optional_features"]))
        if unknown:
            _refuse("UNKNOWN_FEATURE", f"{package_id} does not declare features {unknown}")
        for dependency in item["dependencies"]:
            visit(dependency, package_id, "REQUIRED", None)
        for name in selected_names:
            for dependency in item["optional_features"][name]:
                visit(dependency, package_id, "OPTIONAL_FEATURE", name)
        stack.pop()

    for request in requests:
        visit(request, None, "ROOT", None)
    unused_overrides = sorted(set(override_by_package) - set(selected))
    if unused_overrides:
        _refuse("INVALID_DECLARATION", f"overrides target unselected packages {unused_overrides}")
    unused_features = sorted(set(features) - set(selected))
    if unused_features:
        _refuse("UNKNOWN_FEATURE", f"features target unselected packages {unused_features}")

    for package_id, item in selected.items():
        active_conflicts = sorted(set(item["conflicts"]) & set(selected))
        if active_conflicts:
            _refuse("PACKAGE_CONFLICT", f"{package_id} conflicts with {active_conflicts}")
    provided = set(host_capabilities)
    for item in selected.values():
        provided.update(item["provides_capabilities"])
    for package_id, item in selected.items():
        missing = sorted(set(item["requires_capabilities"]) - provided)
        if missing:
            _refuse("INCOMPATIBLE_CAPABILITY", f"{package_id} requires unavailable capabilities {missing}")

    edges.sort(key=lambda row: (
        row["from"].encode("utf-8"), row["to"].encode("utf-8"),
        row["kind"], row["feature"] or "", row["constraint"],
    ))
    conflict_graph = []
    package_rows = []
    semantic_rows = []
    for package_id in sorted(selected, key=lambda value: value.encode("utf-8")):
        item = selected[package_id]
        variants = item["platform_variants"]
        if variants and platform not in variants:
            _refuse("UNAVAILABLE_ARTIFACT", f"{package_id} has no {platform} variant")
        archive_digest = variants.get(platform, item["archive_digest"])
        row = {
            "package_id": package_id,
            "namespace": item["namespace"],
            "publisher": item["publisher"],
            "version": item["version"],
            "package_form": item["package_form"],
            "manifest_hash": item["manifest_hash"],
            "domain_manifest_hash": item["domain_manifest_hash"],
            "archive_digest": archive_digest,
            "selected_features": features.get(package_id, []),
            "provides_capabilities": item["provides_capabilities"],
            "requires_capabilities": item["requires_capabilities"],
            "registry_origin": item["registry_origin"],
            "mirror_state": item["mirror_state"],
            "trust_state": item["trust_state"],
        }
        package_rows.append(row)
        semantic_rows.append({
            "package_id": package_id,
            "version": item["version"],
            "package_form": item["package_form"],
            "manifest_hash": item["manifest_hash"],
            "domain_manifest_hash": item["domain_manifest_hash"],
            "selected_features": features.get(package_id, []),
        })
        for target in item["conflicts"]:
            conflict_graph.append({"from": package_id, "to": target, "active": target in selected})
    conflict_graph.sort(key=lambda row: (row["from"].encode("utf-8"), row["to"].encode("utf-8")))
    namespace_rows = [
        {"namespace": namespace, "publishers": publishers}
        for namespace, publishers in authorities.items()
    ]
    semantic_material = {
        "composition_abi": composition_abi,
        "root_requests": requests,
        "selected_features": features,
        "packages": semantic_rows,
        "dependency_graph": edges,
    }
    record = {
        "record_type": "ResolvedProfileLock",
        "schema_version": "1.0.0",
        "resolver": {"id": "crg-generate.package-resolver", "version": resolver_version, "composition_abi": composition_abi},
        "root_requests": requests,
        "selected_features": features,
        "platform": platform,
        "packages": package_rows,
        "dependency_graph": edges,
        "conflict_graph": conflict_graph,
        "namespace_authority": namespace_rows,
        "overrides": override_rows,
        "host_capabilities": _sorted_strings(
            sorted(set(host_capabilities), key=lambda value: str(value).encode("utf-8")),
            "host_capabilities",
        ),
        "semantic_composition_root": content_hash(semantic_material),
        "resolution_admission_root": "",
        "authority": "RESOLUTION_RECORD_ONLY",
        "execution_authorized": False,
    }
    record["resolution_admission_root"] = content_hash({
        key: value for key, value in record.items()
        if key not in {"semantic_composition_root", "resolution_admission_root", "lock_hash"}
    })
    record["lock_hash"] = content_hash(record)
    return validate_resolved_profile_lock(record)


def validate_resolved_profile_lock(value: Any) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        _refuse("INVALID_DECLARATION", "resolved profile lock must be an object")
    record = copy.deepcopy(dict(value))
    try:
        validate_or_raise(record, schema_for("ResolvedProfileLock"))
    except Exception as error:
        _refuse("INVALID_DECLARATION", f"resolved profile lock schema failed: {error}")
    if record["lock_hash"] != content_hash({key: value for key, value in record.items() if key != "lock_hash"}):
        _refuse("INVALID_DECLARATION", "resolved profile lock hash differs")
    packages = record["packages"]
    if [row["package_id"] for row in packages] != sorted({row["package_id"] for row in packages}, key=lambda value: value.encode("utf-8")):
        _refuse("INVALID_DECLARATION", "resolved packages are not sorted and unique")
    semantic_rows = [{
        "package_id": row["package_id"], "version": row["version"],
        "package_form": row["package_form"], "manifest_hash": row["manifest_hash"],
        "domain_manifest_hash": row["domain_manifest_hash"],
        "selected_features": row["selected_features"],
    } for row in packages]
    semantic_material = {
        "composition_abi": record["resolver"]["composition_abi"],
        "root_requests": record["root_requests"],
        "selected_features": record["selected_features"],
        "packages": semantic_rows,
        "dependency_graph": record["dependency_graph"],
    }
    if record["semantic_composition_root"] != content_hash(semantic_material):
        _refuse("INVALID_DECLARATION", "semantic composition root differs")
    expected_resolution = content_hash({
        key: item for key, item in record.items()
        if key not in {"semantic_composition_root", "resolution_admission_root", "lock_hash"}
    })
    if record["resolution_admission_root"] != expected_resolution:
        _refuse("INVALID_DECLARATION", "resolution/admission root differs")
    return record


def build_assessment_context_roots(
    *,
    resolved_profile_lock: Mapping[str, Any],
    action_mapping_profile_hash: str,
    host_policy_snapshot_hash: str,
    execution_profile_hash: str,
    deployment_profile_hash: str,
) -> dict[str, Any]:
    lock = validate_resolved_profile_lock(resolved_profile_lock)
    inputs = {
        "resolved_profile_lock_hash": lock["lock_hash"],
        "action_mapping_profile_hash": _hash(action_mapping_profile_hash, "action mapping profile hash"),
        "host_policy_snapshot_hash": _hash(host_policy_snapshot_hash, "host policy snapshot hash"),
        "execution_profile_hash": _hash(execution_profile_hash, "execution profile hash"),
        "deployment_profile_hash": _hash(deployment_profile_hash, "deployment profile hash"),
    }
    record = {
        "record_type": "AssessmentContextRoots",
        "schema_version": "1.0.0",
        "profile": "crg-assessment-context/four-root@1",
        "inputs": inputs,
        "semantic_composition_root": lock["semantic_composition_root"],
        "host_policy_action_mapping_root": content_hash({
            "action_mapping_profile_hash": inputs["action_mapping_profile_hash"],
            "host_policy_snapshot_hash": inputs["host_policy_snapshot_hash"],
        }),
        "execution_deployment_root": content_hash({
            "execution_profile_hash": inputs["execution_profile_hash"],
            "deployment_profile_hash": inputs["deployment_profile_hash"],
        }),
        "resolution_admission_root": lock["resolution_admission_root"],
        "authority": "ASSESSMENT_CONTEXT_ONLY",
        "execution_authorized": False,
    }
    record["context_hash"] = content_hash(record)
    return validate_assessment_context_roots(record)


def validate_assessment_context_roots(value: Any) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        _refuse("INVALID_DECLARATION", "assessment context roots must be an object")
    record = copy.deepcopy(dict(value))
    try:
        validate_or_raise(record, schema_for("AssessmentContextRoots"))
    except Exception as error:
        _refuse("INVALID_DECLARATION", f"assessment context roots schema failed: {error}")
    if record["context_hash"] != content_hash({key: item for key, item in record.items() if key != "context_hash"}):
        _refuse("INVALID_DECLARATION", "assessment context hash differs")
    if record["host_policy_action_mapping_root"] != content_hash({
        "action_mapping_profile_hash": record["inputs"]["action_mapping_profile_hash"],
        "host_policy_snapshot_hash": record["inputs"]["host_policy_snapshot_hash"],
    }):
        _refuse("INVALID_DECLARATION", "host-policy/action-mapping root differs")
    if record["execution_deployment_root"] != content_hash({
        "execution_profile_hash": record["inputs"]["execution_profile_hash"],
        "deployment_profile_hash": record["inputs"]["deployment_profile_hash"],
    }):
        _refuse("INVALID_DECLARATION", "execution/deployment root differs")
    return record
