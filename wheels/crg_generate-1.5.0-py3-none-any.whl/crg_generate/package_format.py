"""A1.4 canonical domain-package format built on ``DomainPackManifest``.

The unsigned manifest lives inside a deterministic USTAR archive.  The
archive digest and detached signature/transparency state live outside it in a
distribution envelope, which prevents a manifest/archive/signature hash cycle.
"""
from __future__ import annotations

import hashlib
import io
import json
import posixpath
import tarfile
import unicodedata
from dataclasses import dataclass
from typing import Any, Mapping, Optional, Sequence, Tuple

from crg_model.canonical import canonical_bytes, content_hash
from crg_model.schema import schema_for, validate_or_raise

from .packs import DomainPackManifest, PackError

__all__ = [
    "CANONICAL_PACKAGE_CONTROL_FILE",
    "CANONICAL_PACKAGE_MEDIA_TYPE",
    "CanonicalPackage",
    "PackageFormatError",
    "build_canonical_package",
    "build_package_distribution_envelope",
    "verify_canonical_package",
]

CANONICAL_PACKAGE_CONTROL_FILE = "CRG-PACKAGE.json"
CANONICAL_PACKAGE_MEDIA_TYPE = "application/vnd.crg.package.v1.tar"
_FORMS = frozenset({"DECLARATIVE", "EXECUTABLE", "AGGREGATE", "PROFILE", "DATA_RESOURCE"})
_MODES = frozenset({0o644, 0o755})


class PackageFormatError(ValueError):
    """A package path, manifest, archive, or envelope is not canonical."""


def _sha256(data: bytes) -> str:
    return "sha256:" + hashlib.sha256(data).hexdigest()


def _path(value: Any) -> str:
    if not isinstance(value, str) or not value or "\\" in value or "\x00" in value:
        raise PackageFormatError("package paths must be non-empty portable POSIX paths")
    if value.startswith("/") or value.endswith("/") or posixpath.normpath(value) != value:
        raise PackageFormatError(f"package path is not normalized: {value!r}")
    if unicodedata.normalize("NFC", value) != value:
        raise PackageFormatError(f"package path is not Unicode NFC: {value!r}")
    if any(part in {"", ".", ".."} for part in value.split("/")):
        raise PackageFormatError(f"package path traverses or aliases a component: {value!r}")
    if value == CANONICAL_PACKAGE_CONTROL_FILE:
        raise PackageFormatError(f"payload may not replace {CANONICAL_PACKAGE_CONTROL_FILE}")
    return value


def _payloads(value: Mapping[str, Any]) -> tuple[list[dict[str, Any]], dict[str, bytes]]:
    if not isinstance(value, Mapping) or not value:
        raise PackageFormatError("canonical package payload must be a non-empty path mapping")
    rows = []
    payloads: dict[str, bytes] = {}
    for raw_path, raw in value.items():
        path = _path(raw_path)
        if path in payloads:
            raise PackageFormatError(f"duplicate package path {path!r}")
        mode = 0o644
        data = raw
        if isinstance(raw, tuple):
            if len(raw) != 2:
                raise PackageFormatError("a payload tuple must be (bytes, mode)")
            data, mode = raw
        if not isinstance(data, (bytes, bytearray)):
            raise PackageFormatError(f"package payload {path!r} is not bytes")
        if mode not in _MODES:
            raise PackageFormatError(f"package payload {path!r} has unsupported mode {mode:o}")
        payload = bytes(data)
        payloads[path] = payload
        rows.append({
            "path": path,
            "mode": f"{mode:04o}",
            "bytes": len(payload),
            "sha256": _sha256(payload),
        })
    rows.sort(key=lambda row: row["path"].encode("utf-8"))
    if len({row["path"] for row in rows}) != len(rows):
        raise PackageFormatError("canonical package repeats a payload path")
    return rows, payloads


def _unsigned_manifest(
    domain_manifest: DomainPackManifest,
    package_form: str,
    inventory: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    if package_form not in _FORMS:
        raise PackageFormatError(f"unsupported package form {package_form!r}")
    missing = domain_manifest.missing_fields()
    if missing:
        raise PackError(f"domain pack manifest is incomplete: {list(missing)}")
    manifest = {
        "record_type": "CanonicalPackageManifest",
        "schema_version": "1.0.0",
        "format_profile": "crg-canonical-package/ustar@1",
        "package_form": package_form,
        "domain_manifest": domain_manifest.to_canonical(),
        "domain_manifest_hash": domain_manifest.manifest_hash(),
        "control_files": [CANONICAL_PACKAGE_CONTROL_FILE],
        "excluded_from_archive": ["DETACHED-SIGNATURE.json", "TRANSPARENCY.json"],
        "path_policy": {
            "normalization": "POSIX_RELATIVE_NFC_CALLER_SUPPLIED",
            "allowed_modes": ["0644", "0755"],
            "timestamp": 0,
            "symlinks": "PROHIBITED",
            "extra_files": "REFUSED",
        },
        "payload_inventory": [dict(row) for row in inventory],
        "payload_root": content_hash(list(inventory)),
    }
    manifest["manifest_hash"] = content_hash(manifest)
    validate_or_raise(manifest, schema_for("CanonicalPackageManifest"))
    return manifest


def _archive(manifest: Mapping[str, Any], payloads: Mapping[str, bytes]) -> bytes:
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode="w", format=tarfile.USTAR_FORMAT) as archive:
        manifest_bytes = canonical_bytes(manifest)
        control = tarfile.TarInfo(CANONICAL_PACKAGE_CONTROL_FILE)
        control.size = len(manifest_bytes)
        control.mode = 0o644
        control.uid = control.gid = 0
        control.uname = control.gname = "root"
        control.mtime = 0
        archive.addfile(control, io.BytesIO(manifest_bytes))
        rows = {row["path"]: row for row in manifest["payload_inventory"]}
        for path in sorted(payloads, key=lambda value: value.encode("utf-8")):
            payload = payloads[path]
            info = tarfile.TarInfo(path)
            info.size = len(payload)
            info.mode = int(rows[path]["mode"], 8)
            info.uid = info.gid = 0
            info.uname = info.gname = "root"
            info.mtime = 0
            archive.addfile(info, io.BytesIO(payload))
    return buffer.getvalue()


def build_package_distribution_envelope(
    *,
    manifest_hash: str,
    archive_bytes: bytes,
    locator: str,
    retrieved_at: str,
    signature: Optional[Mapping[str, Any]] = None,
    transparency: Optional[Mapping[str, Any]] = None,
    revocation_status: str = "ACTIVE",
    revocation_record_hash: Optional[str] = None,
) -> dict[str, Any]:
    if not isinstance(locator, str) or not locator:
        raise PackageFormatError("historical retrieval locator must be a non-empty string")
    if not isinstance(retrieved_at, str) or not retrieved_at:
        raise PackageFormatError("historical retrieval time must be a non-empty string")
    archive_digest = _sha256(archive_bytes)
    signed_content_hash = content_hash({
        "manifest_hash": manifest_hash,
        "archive_digest": archive_digest,
        "media_type": CANONICAL_PACKAGE_MEDIA_TYPE,
    })
    signature_value = dict(signature) if signature is not None else None
    if signature_value is not None and signature_value.get("signed_content_hash") != signed_content_hash:
        raise PackageFormatError("detached signature covers a different package identity")
    transparency_value = dict(transparency) if transparency is not None else None
    if (
        transparency_value is not None
        and transparency_value.get("signed_content_hash") != signed_content_hash
    ):
        raise PackageFormatError("transparency entry covers a different package identity")
    if revocation_status not in {"ACTIVE", "REVOKED", "UNAVAILABLE"}:
        raise PackageFormatError("package revocation status is unknown")
    if (revocation_status == "REVOKED") != (revocation_record_hash is not None):
        raise PackageFormatError("revocation record must be present exactly for REVOKED status")
    envelope = {
        "record_type": "PackageDistributionEnvelope",
        "schema_version": "1.0.0",
        "manifest_hash": manifest_hash,
        "archive": {
            "media_type": CANONICAL_PACKAGE_MEDIA_TYPE,
            "bytes": len(archive_bytes),
            "sha256": archive_digest,
        },
        "signed_content_hash": signed_content_hash,
        "detached_signature": signature_value,
        "transparency": transparency_value,
        "retrieval": {
            "locator": locator,
            "retrieved_at": retrieved_at,
            "archive_digest": archive_digest,
        },
        "revocation": {
            "status": revocation_status,
            "record_hash": revocation_record_hash,
        },
    }
    envelope["envelope_hash"] = content_hash(envelope)
    validate_or_raise(envelope, schema_for("PackageDistributionEnvelope"))
    return envelope


@dataclass(frozen=True)
class CanonicalPackage:
    manifest: Mapping[str, Any]
    archive_bytes: bytes
    envelope: Mapping[str, Any]


def build_canonical_package(
    *,
    domain_manifest: DomainPackManifest,
    package_form: str,
    payloads: Mapping[str, Any],
    locator: str,
    retrieved_at: str,
) -> CanonicalPackage:
    inventory, normalized = _payloads(payloads)
    manifest = _unsigned_manifest(domain_manifest, package_form, inventory)
    archive_bytes = _archive(manifest, normalized)
    envelope = build_package_distribution_envelope(
        manifest_hash=manifest["manifest_hash"],
        archive_bytes=archive_bytes,
        locator=locator,
        retrieved_at=retrieved_at,
    )
    result = CanonicalPackage(manifest=manifest, archive_bytes=archive_bytes, envelope=envelope)
    verify_canonical_package(result.archive_bytes, result.envelope)
    return result


def _decode_json(data: bytes, label: str) -> Mapping[str, Any]:
    def pairs(items: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in items:
            if key in result:
                raise PackageFormatError(f"{label} repeats JSON key {key!r}")
            result[key] = value
        return result
    try:
        value = json.loads(
            data.decode("utf-8"),
            object_pairs_hook=pairs,
            parse_float=lambda token: (_ for _ in ()).throw(
                PackageFormatError(f"{label} contains float {token}")
            ),
            parse_constant=lambda token: (_ for _ in ()).throw(
                PackageFormatError(f"{label} contains non-finite value {token}")
            ),
        )
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise PackageFormatError(f"{label} is not exact UTF-8 JSON: {error}") from error
    if not isinstance(value, Mapping):
        raise PackageFormatError(f"{label} must be a JSON object")
    return value


def verify_canonical_package(archive_bytes: bytes, envelope: Mapping[str, Any]) -> dict[str, Any]:
    """Reconstruct manifest, inventory, archive, and external envelope identities."""
    if not isinstance(archive_bytes, bytes):
        raise PackageFormatError("package archive must be bytes")
    envelope_record = dict(envelope)
    validate_or_raise(envelope_record, schema_for("PackageDistributionEnvelope"))
    if envelope_record["envelope_hash"] != content_hash({k: v for k, v in envelope_record.items() if k != "envelope_hash"}):
        raise PackageFormatError("distribution envelope hash differs")
    digest = _sha256(archive_bytes)
    if envelope_record["archive"] != {
        "media_type": CANONICAL_PACKAGE_MEDIA_TYPE,
        "bytes": len(archive_bytes),
        "sha256": digest,
    } or envelope_record["retrieval"]["archive_digest"] != digest:
        raise PackageFormatError("archive identity differs from the distribution envelope")
    signed_content_hash = content_hash({
        "manifest_hash": envelope_record["manifest_hash"],
        "archive_digest": digest,
        "media_type": CANONICAL_PACKAGE_MEDIA_TYPE,
    })
    if envelope_record["signed_content_hash"] != signed_content_hash:
        raise PackageFormatError("signed content identity differs from archive and manifest")
    signature = envelope_record["detached_signature"]
    if signature is not None and signature["signed_content_hash"] != signed_content_hash:
        raise PackageFormatError("detached signature covers a different package identity")
    transparency = envelope_record["transparency"]
    if transparency is not None and transparency["signed_content_hash"] != signed_content_hash:
        raise PackageFormatError("transparency entry covers a different package identity")
    revoked = envelope_record["revocation"]["status"] == "REVOKED"
    if revoked != (envelope_record["revocation"]["record_hash"] is not None):
        raise PackageFormatError("revocation record must be present exactly for REVOKED status")
    try:
        archive = tarfile.open(fileobj=io.BytesIO(archive_bytes), mode="r:")
    except tarfile.TarError as error:
        raise PackageFormatError(f"package archive is not readable USTAR: {error}") from error
    with archive:
        members = archive.getmembers()
        if not members or members[0].name != CANONICAL_PACKAGE_CONTROL_FILE:
            raise PackageFormatError("canonical package control file must be the first archive member")
        names = [member.name for member in members]
        if len(names) != len(set(names)):
            raise PackageFormatError("package archive repeats a member")
        for member in members:
            if member.name != CANONICAL_PACKAGE_CONTROL_FILE:
                _path(member.name)
            if not member.isfile() or member.issym() or member.islnk():
                raise PackageFormatError(f"package member {member.name!r} is not a regular file")
            if (
                member.mode not in _MODES
                or member.uid != 0
                or member.gid != 0
                or member.uname != "root"
                or member.gname != "root"
                or member.mtime != 0
                or member.linkname
                or member.devmajor != 0
                or member.devminor != 0
            ):
                raise PackageFormatError(f"package member {member.name!r} metadata is not canonical")
        if members[0].mode != 0o644:
            raise PackageFormatError("canonical package control file mode must be 0644")
        control = archive.extractfile(members[0])
        if control is None:
            raise PackageFormatError("canonical package control file has no bytes")
        control_bytes = control.read()
        manifest = dict(_decode_json(control_bytes, "package manifest"))
        if canonical_bytes(manifest) != control_bytes:
            raise PackageFormatError("package manifest bytes are not canonical")
        validate_or_raise(manifest, schema_for("CanonicalPackageManifest"))
        if manifest["manifest_hash"] != content_hash({k: v for k, v in manifest.items() if k != "manifest_hash"}):
            raise PackageFormatError("package manifest hash differs")
        if manifest["control_files"] != [CANONICAL_PACKAGE_CONTROL_FILE]:
            raise PackageFormatError("package control-file inventory differs")
        if manifest["excluded_from_archive"] != [
            "DETACHED-SIGNATURE.json", "TRANSPARENCY.json"
        ]:
            raise PackageFormatError("package archive exclusion policy differs")
        if manifest["path_policy"] != {
            "normalization": "POSIX_RELATIVE_NFC_CALLER_SUPPLIED",
            "allowed_modes": ["0644", "0755"],
            "timestamp": 0,
            "symlinks": "PROHIBITED",
            "extra_files": "REFUSED",
        }:
            raise PackageFormatError("package path and archive policy differs")
        domain = manifest["domain_manifest"]
        domain_object = DomainPackManifest(
            identity=domain["identity"],
            version=domain["version"],
            publisher=domain["publisher"],
            supported_spec_versions=tuple(domain["supported_spec_versions"]),
            permissions=tuple(domain["permissions"]),
            input_schemas=tuple(domain["input_schemas"]),
            output_schemas=tuple(domain["output_schemas"]),
            determinism_status=domain["determinism_status"],
            external_dependencies=tuple(domain["external_dependencies"]),
            resource_requirements=domain["resource_requirements"],
            failure_modes=tuple(domain["failure_modes"]),
            license=domain["license"],
            provenance=domain["provenance"],
            security_classification=domain["security_classification"],
            quantity_registry_additions=tuple(domain["quantity_registry_additions"]),
            proof_implications=tuple(domain["proof_implications"]),
            conformance_tests=tuple(domain["conformance_tests"]),
        )
        if domain_object.missing_fields() or domain_object.to_canonical() != domain:
            raise PackageFormatError("embedded domain manifest is incomplete or noncanonical")
        if manifest["domain_manifest_hash"] != content_hash(manifest["domain_manifest"]):
            raise PackageFormatError("domain manifest hash differs")
        if envelope_record["manifest_hash"] != manifest["manifest_hash"]:
            raise PackageFormatError("distribution envelope names a different manifest")
        declared_rows = manifest["payload_inventory"]
        if declared_rows != sorted(declared_rows, key=lambda row: row["path"].encode("utf-8")):
            raise PackageFormatError("payload inventory is not in UTF-8 path order")
        if len({row["path"] for row in declared_rows}) != len(declared_rows):
            raise PackageFormatError("payload inventory repeats a path")
        for row in declared_rows:
            _path(row["path"])
        rows = []
        for member in members[1:]:
            handle = archive.extractfile(member)
            if handle is None:
                raise PackageFormatError(f"package member {member.name!r} has no bytes")
            data = handle.read()
            rows.append({
                "path": member.name,
                "mode": f"{member.mode:04o}",
                "bytes": len(data),
                "sha256": _sha256(data),
            })
        rows.sort(key=lambda row: row["path"].encode("utf-8"))
        if rows != manifest["payload_inventory"] or content_hash(rows) != manifest["payload_root"]:
            raise PackageFormatError("archive payload differs from the canonical inventory")
        if names != [CANONICAL_PACKAGE_CONTROL_FILE] + [row["path"] for row in rows]:
            raise PackageFormatError("archive members are not in canonical order or contain extras")
        payload_map = {}
        for member in members[1:]:
            handle = archive.extractfile(member)
            assert handle is not None
            payload_map[member.name] = handle.read()
        rebuilt = _archive(manifest, payload_map)
        if rebuilt != archive_bytes:
            raise PackageFormatError("archive bytes are not the canonical USTAR encoding")
    return {
        "authority": "PACKAGE_FORMAT_VERIFICATION_ONLY",
        "execution_authorized": False,
        "manifest_hash": manifest["manifest_hash"],
        "archive_digest": digest,
        "payload_root": manifest["payload_root"],
        "payload_count": len(rows),
        "result": "VERIFIED_CANONICAL_PACKAGE",
    }
