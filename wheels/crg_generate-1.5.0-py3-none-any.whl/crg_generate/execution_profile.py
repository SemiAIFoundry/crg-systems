"""A1.6 execution-profile contract over the existing sandbox/OCI runners.

This module does not add a third execution path.  It makes the existing
``SandboxPolicy`` and ``InvocationRecord`` boundaries portable: a contract
binds wire formats, authority, budgets and runtime identities, and a receipt
binds one existing sandbox invocation and its hash-chained audit log.
"""
from __future__ import annotations

import copy
import re
from typing import Any, Mapping, Sequence

from crg_model.canonical import content_hash
from crg_model.schema import schema_for, validate_or_raise

from .sandbox import (
    FailureCategory,
    IsolationProfile,
    PROTOCOL_VERSION,
    SandboxLog,
    SandboxPolicy,
    SandboxResult,
)

__all__ = [
    "ExecutionProfileError",
    "build_execution_profile_contract",
    "build_execution_receipt",
    "validate_execution_profile_contract",
    "validate_execution_receipt",
]

_HASH = re.compile(r"^sha256:[0-9a-f]{64}$")
_AMBIENT_TIME_RANDOM_MODULES = frozenset({"time", "datetime", "random", "secrets", "uuid"})
_DATA_CLASSIFICATIONS = frozenset({"PUBLIC", "INTERNAL", "CONFIDENTIAL", "RESTRICTED"})


class ExecutionProfileError(ValueError):
    """An A1.6 contract or receipt exceeds the existing runner boundary."""


def _hash(value: Any, label: str) -> str:
    if not isinstance(value, str) or _HASH.fullmatch(value) is None:
        raise ExecutionProfileError(f"{label} must be an algorithm-tagged SHA-256 hash")
    return value


def _text(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value:
        raise ExecutionProfileError(f"{label} must be a non-empty string")
    return value


def _identity(value: Any, label: str) -> dict[str, str]:
    if not isinstance(value, Mapping) or set(value) != {"id", "hash"}:
        raise ExecutionProfileError(f"{label} identity fields differ")
    return {"id": _text(value["id"], f"{label}.id"), "hash": _hash(value["hash"], f"{label}.hash")}


def _capabilities(value: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    rows = []
    for raw in value:
        if not isinstance(raw, Mapping) or set(raw) != {
            "handle_id", "capability", "access", "scope_hash", "data_classification"
        }:
            raise ExecutionProfileError("capability handle fields differ")
        row = dict(raw)
        for field in ("handle_id", "capability", "access"):
            row[field] = _text(row[field], field)
        row["scope_hash"] = _hash(row["scope_hash"], "capability scope")
        if row["data_classification"] not in _DATA_CLASSIFICATIONS:
            raise ExecutionProfileError("capability data classification is unsupported")
        rows.append(row)
    rows.sort(key=lambda row: row["handle_id"].encode("utf-8"))
    if len({row["handle_id"] for row in rows}) != len(rows):
        raise ExecutionProfileError("capability handles repeat an identity")
    return rows


def build_execution_profile_contract(
    *,
    profile_id: str,
    profile_version: str,
    package_lock_hash: str,
    policy: SandboxPolicy,
    request_schema_hash: str,
    reply_schema_hash: str,
    data_classification: str,
    runner_identity: Mapping[str, Any],
    kernel_identity: Mapping[str, Any],
    platform_identity: Mapping[str, Any],
    capability_handles: Sequence[Mapping[str, Any]] = (),
    max_request_bytes: int = 8 * 1024 * 1024,
    max_reply_bytes: int = 8 * 1024 * 1024,
    max_output_bytes: int = 1024 * 1024,
    support_level: str | None = None,
) -> dict[str, Any]:
    """Bind one existing sandbox policy as a portable execution profile."""

    violations = policy.violations()
    if violations:
        raise ExecutionProfileError(f"sandbox policy is not enforceable: {violations[0].detail}")
    if set(policy.module_allow_list) & _AMBIENT_TIME_RANDOM_MODULES:
        raise ExecutionProfileError("execution profiles must remove ambient time and randomness modules")
    if data_classification not in _DATA_CLASSIFICATIONS:
        raise ExecutionProfileError("execution profile data classification is unsupported")
    for name, value in (
        ("max_request_bytes", max_request_bytes),
        ("max_reply_bytes", max_reply_bytes),
        ("max_output_bytes", max_output_bytes),
    ):
        if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
            raise ExecutionProfileError(f"{name} must be a positive integer")
    handles = _capabilities(capability_handles)
    effective = policy.effective_isolation_profile
    derived_support = "SUPPORTED" if effective == IsolationProfile.OCI_KERNEL else "EXPERIMENTAL"
    if support_level is not None and support_level != derived_support:
        raise ExecutionProfileError("support level cannot elevate or demote the selected isolation profile")
    if derived_support == "SUPPORTED" and (policy.granted_permissions or handles):
        raise ExecutionProfileError(
            "the supported v1 profile is pure computation; capability-bearing execution remains experimental"
        )
    if derived_support == "SUPPORTED" and not policy.determinism_replay:
        raise ExecutionProfileError("supported execution requires deterministic replay")
    runtime_image = policy.oci.image if policy.oci is not None else "NONE"
    limitations = [] if derived_support == "SUPPORTED" else [
        "PROCESS_REFERENCE_IS_SAME_UID_AND_NOT_A_PRODUCTION_SECURITY_BOUNDARY",
        "CAPABILITY_BEARING_EXECUTION_IS_EXPERIMENTAL",
    ]
    ambient = {
        "network": "DENIED" if not policy.network_granted else "DECLARED_CAPABILITY_ONLY",
        "filesystem": (
            "DENIED" if not (policy.readable_paths or policy.writable_paths)
            else "DECLARED_CAPABILITY_ONLY"
        ),
        "secrets": "DENIED" if not policy.declared_secrets else "DECLARED_CAPABILITY_ONLY",
        "environment": "DECLARED_MINIMAL_ONLY",
        "time": "DENIED",
        "randomness": "DENIED",
    }
    record = {
        "record_type": "ExecutionProfileContract",
        "schema_version": "1.0.0",
        "profile_id": _text(profile_id, "profile_id"),
        "profile_version": _text(profile_version, "profile_version"),
        "package_lock_hash": _hash(package_lock_hash, "package lock hash"),
        "wire": {
            "protocol": PROTOCOL_VERSION,
            "request_encoding": "CANONICAL_JSON_STDIN",
            "reply_encoding": "CANONICAL_JSON_DEDICATED_CHANNEL",
            "request_schema_hash": _hash(request_schema_hash, "request schema hash"),
            "reply_schema_hash": _hash(reply_schema_hash, "reply schema hash"),
            "max_request_bytes": max_request_bytes,
            "max_reply_bytes": max_reply_bytes,
            "max_output_bytes": max_output_bytes,
        },
        "capability_handles": handles,
        "ambient_authority": ambient,
        "permissions": list(policy.granted_permissions),
        "data_classification": data_classification,
        "budgets": {
            "resource_quota": policy.quota.to_canonical(),
            "filesystem_read_bytes": 0 if not policy.filesystem_read_granted else policy.quota.file_size_bytes,
            "filesystem_write_bytes": 0 if not policy.filesystem_write_granted else policy.quota.file_size_bytes,
            "network_requests": 0 if not policy.network_granted else 1,
            "network_bytes": 0 if not policy.network_granted else max_output_bytes,
            "output_bytes": max_output_bytes,
        },
        "termination": {
            "timeout_action": "KILL_PROCESS_GROUP",
            "cancellation": "REFUSE_BEFORE_START_OR_KILL_PROCESS_GROUP",
            "partial_output": "REFUSED",
        },
        "runtime": {
            "isolation_profile": effective,
            "support_level": derived_support,
            "policy_hash": policy.policy_hash(),
            "runner": _identity(runner_identity, "runner"),
            "kernel": _identity(kernel_identity, "kernel"),
            "platform": _identity(platform_identity, "platform"),
            "image_identity": runtime_image,
            "kernel_enforced": effective == IsolationProfile.OCI_KERNEL,
        },
        "determinism": {
            "replay_required": policy.determinism_replay,
            "time_source": "NONE",
            "randomness_source": "NONE",
        },
        "audit": {
            "invocation_record": "crg-generate.InvocationRecord/v1",
            "hash_chain": "crg-sandbox-log/1",
            "side_effect_receipt": "ExecutionReceipt/v1",
        },
        "limitations": limitations,
        "authority": "EXECUTION_CONTRACT_ONLY",
        "execution_authorized": False,
    }
    record["contract_hash"] = content_hash(record)
    return validate_execution_profile_contract(record)


def validate_execution_profile_contract(value: Any) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise ExecutionProfileError("execution profile contract must be an object")
    record = copy.deepcopy(dict(value))
    try:
        validate_or_raise(record, schema_for("ExecutionProfileContract"))
    except Exception as error:
        raise ExecutionProfileError(f"execution profile schema failed: {error}") from error
    if record["contract_hash"] != content_hash({key: item for key, item in record.items() if key != "contract_hash"}):
        raise ExecutionProfileError("execution profile contract hash differs")
    runtime = record["runtime"]
    supported = runtime["support_level"] == "SUPPORTED"
    if supported != (runtime["isolation_profile"] == "OCI_KERNEL" and runtime["kernel_enforced"] is True):
        raise ExecutionProfileError("support claim differs from the selected isolation boundary")
    if supported and (record["permissions"] or record["capability_handles"] or record["limitations"]):
        raise ExecutionProfileError("supported v1 profile exceeds pure-computation authority")
    if supported and record["determinism"]["replay_required"] is not True:
        raise ExecutionProfileError("supported profile omits deterministic replay")
    if record["ambient_authority"]["time"] != "DENIED" or record["ambient_authority"]["randomness"] != "DENIED":
        raise ExecutionProfileError("ambient time or randomness was admitted")
    return record


def build_execution_receipt(
    *,
    contract: Mapping[str, Any],
    result: SandboxResult,
    audit_log: SandboxLog,
) -> dict[str, Any]:
    profile = validate_execution_profile_contract(contract)
    record = result.record
    if record.policy_hash != profile["runtime"]["policy_hash"]:
        raise ExecutionProfileError("invocation used a different sandbox policy")
    if not audit_log.records or audit_log.records[-1].record_hash() != record.record_hash():
        raise ExecutionProfileError("audit log does not end with the invocation record")
    if profile["runtime"]["support_level"] == "SUPPORTED" and record.granted_permissions:
        raise ExecutionProfileError("supported pure execution receipt carries permissions")
    receipt = {
        "record_type": "ExecutionReceipt",
        "schema_version": "1.0.0",
        "execution_profile_hash": profile["contract_hash"],
        "request_hash": _hash(record.input_hash, "invocation request hash"),
        "reply_hash": record.output_hash or None,
        "outcome": {
            "status": "SUCCEEDED" if result.ok else "FAILED",
            "failure_category": record.failure_category,
            "timed_out": record.timed_out,
            "terminating_signal": record.terminating_signal or None,
        },
        "side_effects": [],
        "side_effect_disposition": "NONE_PERMITTED",
        "invocation_record_hash": record.record_hash(),
        "environment_hash": record.environment_hash,
        "audit_chain_hash": audit_log.chain_hash(),
        "authority": "EXECUTION_EVIDENCE_ONLY",
        "action_authorized": False,
    }
    receipt["receipt_hash"] = content_hash(receipt)
    return validate_execution_receipt(receipt)


def validate_execution_receipt(value: Any) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise ExecutionProfileError("execution receipt must be an object")
    record = copy.deepcopy(dict(value))
    try:
        validate_or_raise(record, schema_for("ExecutionReceipt"))
    except Exception as error:
        raise ExecutionProfileError(f"execution receipt schema failed: {error}") from error
    if record["receipt_hash"] != content_hash({key: item for key, item in record.items() if key != "receipt_hash"}):
        raise ExecutionProfileError("execution receipt hash differs")
    if record["side_effects"] or record["side_effect_disposition"] != "NONE_PERMITTED":
        raise ExecutionProfileError("pure execution receipt claims side effects")
    if record["outcome"]["status"] == "SUCCEEDED" and record["outcome"]["failure_category"] != FailureCategory.OK:
        raise ExecutionProfileError("successful receipt carries a failure category")
    if record["outcome"]["status"] == "FAILED" and record["outcome"]["failure_category"] == FailureCategory.OK:
        raise ExecutionProfileError("failed receipt carries an OK category")
    return record
