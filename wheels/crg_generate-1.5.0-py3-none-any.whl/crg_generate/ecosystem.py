"""A8 registry, lifecycle, private-package, and conformance composition.

This layer reuses canonical package and resolution identities.  It records
catalog state around them; it neither fetches package bytes nor promotes a
publisher's self-report to conformance authority.
"""
from __future__ import annotations

import copy
import re
from typing import Any, Mapping, Sequence

from crg_model.canonical import content_hash

__all__ = [
    "PackageEcosystemError",
    "build_catalog_checkpoint",
    "build_conformance_registry",
    "catalog_public_view",
    "evaluate_catalog_package",
    "validate_catalog_checkpoint",
    "validate_conformance_registry",
]

_HASH = re.compile(r"^sha256:[0-9a-f]{64}$")
_STATES = {"ACTIVE", "YANKED", "QUARANTINED", "REVOKED", "DEPRECATED", "ARCHIVED"}
_PACKAGE_FIELDS = {
    "package_id", "version", "namespace", "publisher", "manifest_hash",
    "archive_digest", "archive_locator", "state", "state_record_hash",
    "successor_package_id", "visibility", "entitlement_id", "opaque_payload_hash",
}
_RESULT_FIELDS = {
    "result_id", "package_id", "version", "publisher", "host_id", "verifier_id",
    "environment_id", "result_hash", "status", "passed", "evaluated_at",
}


class PackageEcosystemError(ValueError):
    def __init__(self, code: str, detail: str) -> None:
        super().__init__(f"{code}: {detail}")
        self.code = code
        self.detail = detail


def _fail(code: str, detail: str) -> None:
    raise PackageEcosystemError(code, detail)


def _text(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value:
        _fail("INVALID_RECORD", f"{label} must be non-empty text")
    return value


def _hash(value: Any, label: str) -> str:
    if not isinstance(value, str) or _HASH.fullmatch(value) is None:
        _fail("INVALID_RECORD", f"{label} is not a SHA-256 identity")
    return value


def _exact(value: Any, fields: set[str], label: str) -> dict[str, Any]:
    if not isinstance(value, Mapping) or set(value) != fields:
        _fail("INVALID_RECORD", f"{label} fields differ")
    return copy.deepcopy(dict(value))


def _package(value: Any, authorities: Mapping[str, Sequence[str]]) -> dict[str, Any]:
    item = _exact(value, _PACKAGE_FIELDS, "catalog package")
    for field in ("package_id", "version", "namespace", "publisher", "archive_locator"):
        _text(item[field], field)
    for field in ("manifest_hash", "archive_digest", "state_record_hash", "opaque_payload_hash"):
        _hash(item[field], field)
    if item["state"] not in _STATES:
        _fail("INVALID_RECORD", "package lifecycle state is unknown")
    if item["publisher"] not in authorities.get(item["namespace"], ()):
        _fail("NAMESPACE_PUBLISHER_UNAUTHORIZED", "publisher does not control namespace")
    if item["package_id"] != item["namespace"] and not item["package_id"].startswith(item["namespace"] + "."):
        _fail("NAMESPACE_COLLISION", "package is outside its namespace")
    if item["visibility"] not in {"PUBLIC", "PARTNER_PRIVATE"}:
        _fail("INVALID_RECORD", "package visibility is unknown")
    if (item["visibility"] == "PARTNER_PRIVATE") != isinstance(item["entitlement_id"], str):
        _fail("INVALID_RECORD", "private visibility and entitlement must appear together")
    if item["visibility"] == "PUBLIC" and item["entitlement_id"] is not None:
        _fail("INVALID_RECORD", "public package carries a private entitlement")
    if item["successor_package_id"] is not None:
        _text(item["successor_package_id"], "successor_package_id")
    if item["state"] == "DEPRECATED" and item["successor_package_id"] is None:
        _fail("INVALID_RECORD", "deprecated package must name a successor")
    return item


def build_catalog_checkpoint(
    *,
    catalog_id: str,
    sequence: int,
    previous_checkpoint_hash: str | None,
    mirror_id: str,
    created_at: str,
    namespace_authorities: Mapping[str, Sequence[str]],
    packages: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    if isinstance(sequence, bool) or not isinstance(sequence, int) or sequence < 1:
        _fail("INVALID_RECORD", "catalog sequence must be positive")
    if (sequence == 1) != (previous_checkpoint_hash is None):
        _fail("CATALOG_CHAIN_BROKEN", "only the first checkpoint may omit its predecessor")
    if previous_checkpoint_hash is not None:
        _hash(previous_checkpoint_hash, "previous_checkpoint_hash")
    authorities = {
        _text(namespace, "namespace"): sorted({_text(publisher, "publisher") for publisher in publishers})
        for namespace, publishers in namespace_authorities.items()
    }
    if any(not values for values in authorities.values()):
        _fail("INVALID_RECORD", "each namespace requires a publisher")
    rows = [_package(value, authorities) for value in packages]
    rows.sort(key=lambda row: (row["package_id"].encode("utf-8"), row["version"]))
    if len({(row["package_id"], row["version"]) for row in rows}) != len(rows):
        _fail("PACKAGE_COLLISION", "catalog repeats a package version")
    record = {
        "record_type": "PackageCatalogCheckpoint",
        "schema_version": "1.0.0",
        "catalog_id": _text(catalog_id, "catalog_id"),
        "sequence": sequence,
        "previous_checkpoint_hash": previous_checkpoint_hash,
        "mirror_id": _text(mirror_id, "mirror_id"),
        "created_at": _text(created_at, "created_at"),
        "namespace_authorities": {key: authorities[key] for key in sorted(authorities)},
        "packages": rows,
        "package_index_root": content_hash(rows),
        "authority": "CATALOG_STATE_ONLY",
        "execution_authorized": False,
    }
    record["checkpoint_hash"] = content_hash(record)
    return validate_catalog_checkpoint(record)


def validate_catalog_checkpoint(value: Any) -> dict[str, Any]:
    fields = {
        "record_type", "schema_version", "catalog_id", "sequence",
        "previous_checkpoint_hash", "mirror_id", "created_at",
        "namespace_authorities", "packages", "package_index_root", "authority",
        "execution_authorized", "checkpoint_hash",
    }
    item = _exact(value, fields, "catalog checkpoint")
    if item["record_type"] != "PackageCatalogCheckpoint" or item["schema_version"] != "1.0.0":
        _fail("INVALID_RECORD", "catalog type/version differs")
    # Reconstruct directly to avoid recursion through the public constructor.
    authorities = item["namespace_authorities"]
    if not isinstance(authorities, Mapping) or list(authorities) != sorted(authorities):
        _fail("INVALID_RECORD", "namespace authorities are not canonical")
    rows = [_package(value, authorities) for value in item["packages"]] if isinstance(item["packages"], list) else _fail("INVALID_RECORD", "packages must be an array")
    rows.sort(key=lambda row: (row["package_id"].encode("utf-8"), row["version"]))
    if item["packages"] != rows or item["package_index_root"] != content_hash(rows):
        _fail("INVALID_RECORD", "catalog package index differs")
    if item["authority"] != "CATALOG_STATE_ONLY" or item["execution_authorized"] is not False:
        _fail("INVALID_RECORD", "catalog authority differs")
    if item["checkpoint_hash"] != content_hash({k: v for k, v in item.items() if k != "checkpoint_hash"}):
        _fail("INVALID_RECORD", "catalog checkpoint identity differs")
    if isinstance(item["sequence"], bool) or not isinstance(item["sequence"], int) or item["sequence"] < 1:
        _fail("INVALID_RECORD", "catalog sequence differs")
    if (item["sequence"] == 1) != (item["previous_checkpoint_hash"] is None):
        _fail("CATALOG_CHAIN_BROKEN", "catalog predecessor relation differs")
    return item


def evaluate_catalog_package(
    checkpoint: Mapping[str, Any], *, package_id: str, version: str,
    purpose: str, entitlements: Sequence[str] = (), minimum_sequence: int = 1,
) -> dict[str, Any]:
    item = validate_catalog_checkpoint(checkpoint)
    if item["sequence"] < minimum_sequence:
        _fail("CATALOG_ROLLBACK", "catalog sequence is older than the admitted floor")
    selected = next((row for row in item["packages"] if row["package_id"] == package_id and row["version"] == version), None)
    if selected is None:
        _fail("PACKAGE_NOT_FOUND", "package version is not in the checkpoint")
    if selected["visibility"] == "PARTNER_PRIVATE" and selected["entitlement_id"] not in set(entitlements):
        _fail("ENTITLEMENT_REQUIRED", "private package entitlement is absent")
    if purpose == "NEW_RESOLUTION" and selected["state"] != "ACTIVE":
        _fail("PACKAGE_NOT_SELECTABLE", f"{selected['state']} package cannot enter a new lock")
    if purpose == "HISTORICAL_RETRIEVAL":
        disposition = "HISTORICAL_BYTES_AVAILABLE_NOT_CURRENTLY_SELECTABLE"
    elif purpose == "NEW_RESOLUTION":
        disposition = "SELECTABLE"
    else:
        _fail("INVALID_RECORD", "package evaluation purpose is unknown")
    return {
        "record_type": "PackageCatalogDecision", "schema_version": "1.0.0",
        "checkpoint_hash": item["checkpoint_hash"], "package_id": package_id,
        "version": version, "purpose": purpose, "state": selected["state"],
        "archive_locator": selected["archive_locator"], "disposition": disposition,
        "authority": "CATALOG_DECISION_ONLY", "execution_authorized": False,
    }


def catalog_public_view(checkpoint: Mapping[str, Any]) -> dict[str, Any]:
    item = validate_catalog_checkpoint(checkpoint)
    rows = []
    for package in item["packages"]:
        if package["visibility"] == "PARTNER_PRIVATE":
            rows.append({
                "package_id": "REDACTED_PARTNER_PRIVATE",
                "version": "REDACTED", "state": package["state"],
                "visibility": "PARTNER_PRIVATE", "payload_disclosed": False,
            })
        else:
            rows.append({
                "package_id": package["package_id"], "version": package["version"],
                "state": package["state"], "visibility": "PUBLIC",
                "payload_disclosed": False,
            })
    return {"checkpoint_hash": item["checkpoint_hash"], "packages": rows}


def build_conformance_registry(results: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    rows = []
    for value in results:
        row = _exact(value, _RESULT_FIELDS, "conformance result")
        for field in ("result_id", "package_id", "version", "publisher", "host_id", "verifier_id", "environment_id", "evaluated_at"):
            _text(row[field], field)
        _hash(row["result_hash"], "result_hash")
        if row["status"] not in {"CURRENT", "EXPIRED", "REVOKED", "HISTORICAL"} or not isinstance(row["passed"], bool):
            _fail("INVALID_RECORD", "conformance result status differs")
        if row["publisher"] == row["verifier_id"]:
            _fail("SELF_CERTIFICATION_REFUSED", "publisher cannot be its own conformance verifier")
        rows.append(row)
    rows.sort(key=lambda row: row["result_id"].encode("utf-8"))
    if len({row["result_id"] for row in rows}) != len(rows):
        _fail("INVALID_RECORD", "conformance result IDs repeat")
    record = {
        "record_type": "PackageConformanceRegistry", "schema_version": "1.0.0",
        "results": rows,
        "current_passes": [row["result_id"] for row in rows if row["status"] == "CURRENT" and row["passed"]],
        "authority": "CONFORMANCE_INDEX_ONLY", "execution_authorized": False,
    }
    record["registry_hash"] = content_hash(record)
    return validate_conformance_registry(record)


def validate_conformance_registry(value: Any) -> dict[str, Any]:
    item = _exact(value, {"record_type", "schema_version", "results", "current_passes", "authority", "execution_authorized", "registry_hash"}, "conformance registry")
    if item["record_type"] != "PackageConformanceRegistry" or item["schema_version"] != "1.0.0":
        _fail("INVALID_RECORD", "conformance registry type/version differs")
    expected_current = [row["result_id"] for row in item["results"] if row.get("status") == "CURRENT" and row.get("passed") is True]
    if item["current_passes"] != expected_current:
        _fail("INVALID_RECORD", "current conformance index differs")
    if item["authority"] != "CONFORMANCE_INDEX_ONLY" or item["execution_authorized"] is not False:
        _fail("INVALID_RECORD", "conformance authority differs")
    if item["registry_hash"] != content_hash({k: v for k, v in item.items() if k != "registry_hash"}):
        _fail("INVALID_RECORD", "conformance registry identity differs")
    # Revalidate result fields and self-certification without recursive construction.
    for row in item["results"]:
        checked = _exact(row, _RESULT_FIELDS, "conformance result")
        if checked["publisher"] == checked["verifier_id"]:
            _fail("SELF_CERTIFICATION_REFUSED", "publisher cannot be its own verifier")
        _hash(checked["result_hash"], "result_hash")
    return item
