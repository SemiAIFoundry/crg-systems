"""crg-security: specification 44, plus the parts of 14.5, 17, and 45 it rests on.

Reference implementation of the CRG Operational Systems Master Specification
v0.2.0 section 44 (security and privacy), with 14.5 (signatures), 17.2--17.5
(tombstones, cryptographic erasure, legal hold), 45 (clock and time
discipline), and 9 (trust zones) applied throughout.

The package is a set of refusals wearing an API.  Six of them define it.

**Nothing reads the machine clock.**  Every expiry, freshness, and validity
decision takes a :class:`~crg_security.clock.Clock` and reports which clock it
was, at which declared trust level (45.3, 45.5).  ``datetime.now`` does not
appear in this package outside :class:`~crg_security.clock.SystemClock`, whose
whole job is to be the one place that does.

**Real cryptography is an optional profile that never degrades quietly.**  The
kernel is standard-library-only by design (9.2).  ``cryptography`` is an
optional dependency; when it is absent, :data:`profile.PRODUCTION_CRYPTO_AVAILABLE`
is ``False``, every Ed25519 and AES-GCM operation *raises*, and
:func:`profile.disclosure` says so in a sentence a release note can quote.
There is no path by which an artifact labelled ``Ed25519`` was produced by
something else (14.5).

**Deny by default, and the rule that denied is part of the answer.**
:class:`~crg_security.policy.PolicyEngine` returns PERMIT, DENY, or
NOT_APPLICABLE together with the rule identifier; falling off the end of the
rule list is DENY attributed to
:data:`~crg_security.policy.DEFAULT_DENY_RULE_ID`.  Deny overrides permit, so
adding a rule can never widen access without that widening being the visible
subject of the diff (44.2, 6.6, 44.6).

**Tenant isolation is structural, not checked.**  A
:class:`~crg_security.tenancy.TenantScopedStore` closes over one partition and
holds no reference to the multi-tenant store.  Cross-tenant access is not
blocked; it has no expression.  Handles are
``content_hash({tenant_id, content})``, so an address leaked from one tenant is
not an address in another (44.5, 44.6).

**Erasure destroys a key and keeps the tombstone.**  17.4's cryptographic
erasure leaves the ciphertext, the plaintext content hash, the object type,
and every dependency edge in place while making the content permanently
unreadable, downgrades dependent certificates to ``UNVERIFIABLE_REDACTED``
(17.3) in the same call, and refuses to happen at all without an audit log to
record it in (17.2, 17.4, 17.5).

**The audit chain reports where it broke, not whether.**
:class:`~crg_security.audit.HashChainedAuditLog` is tamper-*evident* and says
so rather than claiming immutability it cannot provide; :meth:`verify` names
the first broken sequence number, because "the log is broken at entry 41" is
an investigation and "the log is broken" is only an alarm (44.7).

What is real and what is an interface with a mock is stated in
``LIMITATIONS.md`` and in :data:`identity.FEDERATED_ADAPTER_DISCLOSURE`.  The
short version: local accounts, API keys, production OIDC JWT validation, RBAC,
ABAC, object-level permissions,
case isolation, tenancy, envelope encryption, cryptographic erasure, the
hash-chained audit log, and Ed25519 signing are real. OIDC resource-server
validation uses HTTPS discovery, an explicit issuer/audience/algorithm policy,
and rotating JWKS. The browser authorization-code flow and SAML XML provider
remain unimplemented; the named mock providers remain test fixtures.

The v1.3 ETQ operation catalog also separates read-only phase/comparison/challenge
inspection from mutations that persist certified evidence or challenge records.
"""
from .audit import (
    AUDIT_EXPORT_FORMAT_VERSION,
    DEFAULT_AUDIT_EXPORT_LIMIT,
    GENESIS_HASH,
    MAX_AUDIT_EXPORT_LIMIT,
    AuditEntry,
    AuditExportVerification,
    ChainVerification,
    HashChainedAuditLog,
    compute_audit_export_hash,
    scrub_secrets,
    verify_audit_export,
    verify_chain,
)
from .clock import (
    AirGappedClock,
    Clock,
    ClockTrustLevel,
    FixedClock,
    SystemClock,
    TimeJudgment,
    TimeStatus,
    evaluate_validity,
    iso,
    parse_iso,
)
from .encryption import (
    AES_GCM_PROFILE,
    ENCRYPTION_PROFILE,
    STDLIB_TEST_PROFILE,
    EncryptedObject,
    EncryptedObjectStore,
    EncryptionProfile,
    EnvelopeEncryptor,
    PersistentObjectEnvelopeCodec,
    ErasureStatus,
    ErasureTombstone,
    KeyDestructionRecord,
    KeyVault,
    TenantKey,
    WrappedDataKey,
    get_encryption_profile,
    register_encryption_profile,
    supported_encryption_profiles,
)
from .errors import (
    AuditIntegrityError,
    AuthenticationError,
    AuthorizationError,
    ConfigurationError,
    CredentialExpiredError,
    KeyDestroyedError,
    LegalHoldError,
    ProfileUnavailableError,
    ReplayError,
    SecurityError,
    TenantIsolationError,
    UnsupportedProfileError,
)
from .gate import (
    NO_AUTHENTICATION_CONFIGURED,
    SecurityConfiguration,
    ServerSecurityGate,
    unconfigured_disclosure,
)
from .identity import (
    FEDERATED_ADAPTER_DISCLOSURE,
    AccountStatus,
    ApiKey,
    FederatedIdentityProvider,
    IdentityBroker,
    IssuedApiKey,
    JsonWebKeySet,
    LocalAccount,
    LocalAccountDirectory,
    MockOidcProvider,
    MockSamlProvider,
    PasswordHash,
    PasswordPolicy,
    Principal,
    ReplayGuard,
    ServiceIdentity,
    ServiceIdentityDirectory,
    SubjectKind,
    TokenClaims,
    hash_password,
    verify_password,
)
from .policy import (
    DEFAULT_DENY_RULE_ID,
    AccessRequest,
    Condition,
    Decision,
    Effect,
    ObjectPermissionTable,
    PolicyEngine,
    PolicySet,
    Resource,
    Rule,
    Subject,
    subject_from_principal,
)
from .oidc import OidcHttpClient, OidcProvider
from .profile import (
    CRYPTOGRAPHY_VERSION,
    DEGRADATION_NOTICE,
    PRODUCTION_CRYPTO_AVAILABLE,
    SECURITY_PROFILE,
    disclosure,
    require_production_crypto,
    warn_once_if_degraded,
)
from .roles import (
    OPERATION_PERMISSIONS,
    PERMISSIONS,
    ROLE_PERMISSIONS,
    ROLES,
    SEPARATION_OF_DUTIES,
    operation_permission,
    permissions_for,
    role_catalog,
    role_permits,
    separation_violation,
    unknown_roles,
)
from .signing import (
    ED25519_PROFILE,
    HMAC_TEST_PROFILE,
    SIGNATURE_PROFILE,
    KeyRing,
    Signature,
    SignatureProfile,
    SigningKey,
    VerificationKey,
    VerificationResult,
    generate_keypair,
    get_profile,
    register_profile,
    sign,
    sign_release_manifest,
    sign_bundle_manifest,
    supported_profiles,
    verify,
    verify_release_manifest,
    verify_bundle_manifest,
    bundle_signature_descriptor,
)
from .tenancy import (
    SEPARATION_LAYERS,
    MultiTenantStore,
    TenantContext,
    TenantRecord,
    TenantScopedStore,
    require_context,
)

__version__ = "1.3.0"
SPEC_VERSION = "0.2.0"

__all__ = [
    "__version__",
    "SPEC_VERSION",
    # clock (45)
    "Clock", "SystemClock", "FixedClock", "AirGappedClock", "ClockTrustLevel",
    "TimeStatus", "TimeJudgment", "evaluate_validity", "iso", "parse_iso",
    # profile (14.5, 44.4)
    "PRODUCTION_CRYPTO_AVAILABLE", "CRYPTOGRAPHY_VERSION", "SECURITY_PROFILE",
    "DEGRADATION_NOTICE", "disclosure", "require_production_crypto",
    "warn_once_if_degraded",
    # errors (6.6)
    "SecurityError", "ConfigurationError", "ProfileUnavailableError",
    "UnsupportedProfileError", "AuthenticationError", "CredentialExpiredError",
    "ReplayError", "AuthorizationError", "TenantIsolationError",
    "KeyDestroyedError", "LegalHoldError", "AuditIntegrityError",
    # roles (44.3)
    "ROLES", "PERMISSIONS", "ROLE_PERMISSIONS", "OPERATION_PERMISSIONS",
    "SEPARATION_OF_DUTIES", "permissions_for", "role_permits",
    "operation_permission", "separation_violation", "unknown_roles",
    "role_catalog",
    # signing (14.5)
    "SIGNATURE_PROFILE", "ED25519_PROFILE", "HMAC_TEST_PROFILE",
    "SignatureProfile", "SigningKey", "VerificationKey", "KeyRing",
    "Signature", "VerificationResult", "generate_keypair", "get_profile",
    "register_profile", "supported_profiles", "sign", "verify",
    "sign_release_manifest", "verify_release_manifest", "bundle_signature_descriptor",
    "sign_bundle_manifest", "verify_bundle_manifest",
    # audit (44.7)
    "HashChainedAuditLog", "AuditEntry", "ChainVerification", "verify_chain",
    "scrub_secrets", "GENESIS_HASH",
    # identity (44.2)
    "Principal", "SubjectKind", "AccountStatus", "PasswordPolicy",
    "PasswordHash", "hash_password", "verify_password", "LocalAccount",
    "LocalAccountDirectory", "ServiceIdentity", "ApiKey", "IssuedApiKey",
    "ServiceIdentityDirectory", "ReplayGuard", "JsonWebKeySet", "TokenClaims",
    "FederatedIdentityProvider", "MockOidcProvider", "MockSamlProvider",
    "OidcHttpClient", "OidcProvider",
    "IdentityBroker", "FEDERATED_ADAPTER_DISCLOSURE",
    # policy (44.2, 44.3)
    "Effect", "DEFAULT_DENY_RULE_ID", "Subject", "Resource", "AccessRequest",
    "Decision", "Condition", "Rule", "PolicySet", "ObjectPermissionTable",
    "PolicyEngine", "subject_from_principal",
    # tenancy (44.5)
    "TenantContext", "TenantRecord", "TenantScopedStore", "MultiTenantStore",
    "require_context", "SEPARATION_LAYERS",
    # encryption and erasure (44.4, 17.4)
    "AES_GCM_PROFILE", "STDLIB_TEST_PROFILE", "ENCRYPTION_PROFILE",
    "EncryptionProfile", "get_encryption_profile", "register_encryption_profile",
    "supported_encryption_profiles", "TenantKey", "KeyVault",
    "KeyDestructionRecord", "WrappedDataKey", "EncryptedObject",
    "ErasureTombstone", "ErasureStatus", "EnvelopeEncryptor",
    "PersistentObjectEnvelopeCodec",
    "EncryptedObjectStore",
    # integration (38.2, 44.2)
    "ServerSecurityGate", "SecurityConfiguration", "NO_AUTHENTICATION_CONFIGURED",
    "unconfigured_disclosure",
]
