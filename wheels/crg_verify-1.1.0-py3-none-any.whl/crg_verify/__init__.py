"""crg-verify: the independent CRG certificate verifier.

Reference implementation of master specification sections 24 (CRG-VIR) and
25 (independent certificate verifier), operating inside the verification
zone of section 9.1.

Independence is the product here, not a nicety.  This package imports the
Python standard library and no CRG kernel -- no ``crg_model``, no
``crg_geometry``, no ``crg_certify``, no ``crg_change``, no ``crg_io``.
V0--V3 load no third-party distribution.  V4 dynamically loads the optional
Ed25519 provider and fails closed when it is unavailable.  Canonicalization, hashing, exact rational
arithmetic, interval comparison, dominance, minima over generator sets, the
claim-scope table of 21.4, the decision-observation mapping of 26.4, and the
regret construction of 27.3 are each re-implemented here from the
specification text.

That is deliberate.  Specification 9.3 says the verifier MUST NOT assume the
originating solver, plugin, server, or organization is correct merely
because it issued a certificate-shaped artifact.  A verifier that called the
kernel's comparison code would inherit exactly the errors it exists to
catch; a verifier that reused the kernel's canonicalizer could never expose
a canonicalization disagreement (25.5).  So this package re-derives, and
where its re-derivation disagrees with the certificate, the certificate is
the thing that is wrong.
"""
from .arith import (
    ArithError,
    dominates,
    interval,
    minimum,
    positive_part_sup,
    rational,
    strictly_below,
    weakly_dominates,
)
from .canonical import (
    CanonicalError,
    canonical_bytes,
    canonical_json,
    content_hash,
    hash_without,
    is_hash,
)
from .certificate import (
    Level,
    Status,
    TimeStatus,
    VerificationResult,
    derive_claim_scope,
    evaluate_objective,
    required_object_for,
    verify_certificate,
)
from .bundle import verify_bundle
from .audit import AuditExportResult, audit_export_hash, verify_audit_export
from .federation import verify_federation
from .report import render_report
from .extensions import ExtensionCheckerError, ProofCheckerDeclaration, ProofCheckerRegistry
from .vir import BASELINE_OPERATIONS, VIR_VERSION, emit_vir, verify_vir
from .vir_ast import AST_VERSION, VirProgramError, evaluate_program
from .commitment import verify_safe_commitment
from .comparison import verify_comparative_workflow_evaluation
from .intake import (
    verify_registry_intake_confirmation,
    verify_registry_intake_preview,
    verify_registry_mapping_profile,
    verify_registry_source_snapshot,
)
from .source_adapter import (
    verify_source_adapter_conformance_report,
    verify_source_adapter_definition,
    verify_source_adapter_output,
)
from .pack_authoring import verify_pack_authoring_report

__version__ = "1.1.0"
SPEC_VERSION = "0.2.0"

__all__ = [
    "ArithError",
    "AuditExportResult",
    "AST_VERSION",
    "BASELINE_OPERATIONS",
    "CanonicalError",
    "ExtensionCheckerError",
    "Level",
    "ProofCheckerDeclaration",
    "ProofCheckerRegistry",
    "SPEC_VERSION",
    "Status",
    "TimeStatus",
    "VIR_VERSION",
    "VirProgramError",
    "VerificationResult",
    "canonical_bytes",
    "canonical_json",
    "content_hash",
    "audit_export_hash",
    "derive_claim_scope",
    "dominates",
    "emit_vir",
    "evaluate_program",
    "evaluate_objective",
    "hash_without",
    "interval",
    "is_hash",
    "minimum",
    "positive_part_sup",
    "rational",
    "render_report",
    "required_object_for",
    "strictly_below",
    "verify_bundle",
    "verify_audit_export",
    "verify_federation",
    "verify_certificate",
    "verify_safe_commitment",
    "verify_comparative_workflow_evaluation",
    "verify_registry_intake_confirmation",
    "verify_registry_intake_preview",
    "verify_registry_mapping_profile",
    "verify_registry_source_snapshot",
    "verify_source_adapter_conformance_report",
    "verify_source_adapter_definition",
    "verify_source_adapter_output",
    "verify_pack_authoring_report",
    "verify_vir",
    "weakly_dominates",
]
