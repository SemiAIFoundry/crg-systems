"""crg-change: reprice, re-embed, reopen, or revalidate (OID-CRG-003).

Reference implementation of master specification section 30, built on the
typed dependency graph of section 18.  The module executes the minimum
valid recomputation after a change: it classifies the change, propagates
it along typed edges only as far as the edges reach, preserves every
certificate outside the affected subgraph, orchestrates recomputation
through a caller-supplied callback, and emits a delta certificate.
"""
from .classify import (
    CLASS_ACTION,
    Classification,
    ObjectKind,
    PropertyClass,
    classify_change,
    classify_property,
    explain_change,
    minimum_action,
)
from .diff import (
    ChangeKind,
    canonical_form,
    diff_objects,
    object_relative,
    property_closure,
)
from .plan import (
    build_impact_plan,
    certificate_dependencies,
    mark_stale,
    object_kind_of,
    object_kinds_of,
)
from .apply import apply_change, case_root, case_view
from .certified_delta import (
    CERTIFIED_DELTA_SCHEMA_VERSION,
    CertifiedDeltaRecord,
    DeltaCategory,
    DeltaVerificationError,
    FieldDelta,
    TraversedEdge,
    build_certified_delta,
    require_verified_delta,
    verify_certified_delta,
)
from .challenge import (
    CHALLENGE_AUTHORITY,
    CHALLENGE_CLAIM_BOUNDARY,
    DECISION_CHALLENGE_PROFILE,
    DECISION_CHALLENGE_SCHEMA_VERSION,
    DECISION_CHALLENGE_VERIFICATION_PROGRAM,
    ChallengeDesignError,
    ChallengeStatus,
    DecisionChallengeRecord,
    build_decision_challenge,
    build_decision_challenge_refusal,
    registered_challenge_mutations,
    registered_challenge_previews,
)
from .phase_binding import PhaseBoundCertifiedChange, build_phase_bound_certified_delta
from .comparative import (
    COMPARATIVE_CHANGE_AUTHORITY,
    COMPARATIVE_CHANGE_CLAIM_BOUNDARY,
    COMPARATIVE_CHANGE_FIRST_RELEASE,
    COMPARATIVE_CHANGE_PROFILE,
    COMPARATIVE_CHANGE_SCHEMA_VERSION,
    ComparativeChangeError,
    ComparativeChangeEvidence,
    build_comparative_change_evidence,
)

__all__ = [
    "CLASS_ACTION",
    "Classification",
    "ObjectKind",
    "PropertyClass",
    "classify_change",
    "classify_property",
    "explain_change",
    "minimum_action",
    "ChangeKind",
    "canonical_form",
    "diff_objects",
    "object_relative",
    "property_closure",
    "build_impact_plan",
    "certificate_dependencies",
    "mark_stale",
    "object_kind_of",
    "object_kinds_of",
    "apply_change",
    "case_root",
    "case_view",
    "DeltaCategory",
    "CERTIFIED_DELTA_SCHEMA_VERSION",
    "DeltaVerificationError",
    "FieldDelta",
    "TraversedEdge",
    "CertifiedDeltaRecord",
    "build_certified_delta",
    "verify_certified_delta",
    "require_verified_delta",
    "CHALLENGE_AUTHORITY",
    "CHALLENGE_CLAIM_BOUNDARY",
    "DECISION_CHALLENGE_PROFILE",
    "DECISION_CHALLENGE_SCHEMA_VERSION",
    "DECISION_CHALLENGE_VERIFICATION_PROGRAM",
    "ChallengeDesignError",
    "ChallengeStatus",
    "DecisionChallengeRecord",
    "build_decision_challenge",
    "build_decision_challenge_refusal",
    "registered_challenge_mutations",
    "registered_challenge_previews",
    "PhaseBoundCertifiedChange",
    "build_phase_bound_certified_delta",
    "COMPARATIVE_CHANGE_AUTHORITY",
    "COMPARATIVE_CHANGE_CLAIM_BOUNDARY",
    "COMPARATIVE_CHANGE_FIRST_RELEASE",
    "COMPARATIVE_CHANGE_PROFILE",
    "COMPARATIVE_CHANGE_SCHEMA_VERSION",
    "ComparativeChangeError",
    "ComparativeChangeEvidence",
    "build_comparative_change_evidence",
]

__version__ = "1.2.0"
SPEC_VERSION = "0.2.0"
