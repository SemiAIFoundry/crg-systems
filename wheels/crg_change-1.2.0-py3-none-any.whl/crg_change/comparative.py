"""Portable comparative evidence for one independently verified CRG change.

This additive v1.2 record does not change ``CertifiedDeltaRecord`` semantics.
It binds that record, the exact inputs needed by the independent verifier,
and the verifier's result, then exposes only the minimum action and exact
artifact identities that were preserved, invalidated, or recomputed.

The counts are identity counts.  They are not elapsed time, labor, money,
avoided work, savings, ROI, or a comparison against an unexecuted workflow.
"""
from __future__ import annotations

import copy
from dataclasses import dataclass
from typing import Any, Mapping, Sequence

from crg_model.canonical import content_hash

__all__ = [
    "COMPARATIVE_CHANGE_AUTHORITY",
    "COMPARATIVE_CHANGE_CLAIM_BOUNDARY",
    "COMPARATIVE_CHANGE_FIRST_RELEASE",
    "COMPARATIVE_CHANGE_PROFILE",
    "COMPARATIVE_CHANGE_SCHEMA_VERSION",
    "ComparativeChangeError",
    "ComparativeChangeEvidence",
    "build_comparative_change_evidence",
]


COMPARATIVE_CHANGE_SCHEMA_VERSION = "1.2.0"
COMPARATIVE_CHANGE_PROFILE = "crg-comparative-change/certified-delta@1"
COMPARATIVE_CHANGE_FIRST_RELEASE = "v1.2/CERTIFIED_PHASE_AND_TYPED_CHANGE"
COMPARATIVE_CHANGE_AUTHORITY = "NON_AUTHORIZING"
COMPARATIVE_CHANGE_CLAIM_BOUNDARY = (
    "Scoped certified-change facts only. Artifact identity counts do not measure "
    "time, effort, cost, avoided work, business savings, ROI, superiority, or an "
    "unexecuted counterfactual, and this record cannot authorize case state."
)

_REQUIRED_INPUTS = frozenset(
    {"prior_case", "current_case", "dependency_edges", "replacements"}
)
_OPTIONAL_INPUTS = frozenset(
    {
        "prior_phase",
        "current_phase",
        "prior_phase_source_r",
        "current_phase_source_r",
    }
)
_FORBIDDEN_FACT_KEYS = frozenset(
    {
        "roi",
        "return_on_investment",
        "savings",
        "superiority",
        "generalization",
        "avoided_work",
        "avoided_recomputation",
        "avoided_effort",
        "cost_reduction",
        "time_reduction",
        "winner_method",
        "method_ranking",
    }
)


class ComparativeChangeError(ValueError):
    """The proposed comparative change evidence is incomplete or stronger than supported."""


def _identity(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value.strip() or value != value.strip():
        raise ComparativeChangeError(f"{field} must be a normalized non-empty string")
    return value


def _object(value: Any, field: str) -> dict:
    if not isinstance(value, Mapping):
        raise ComparativeChangeError(f"{field} must be an object")
    result = copy.deepcopy(dict(value))
    # Canonical hashing is also the binary-float and unsupported-type guard.
    try:
        content_hash(result)
    except Exception as error:
        raise ComparativeChangeError(f"{field} is not portable canonical JSON: {error}") from error
    return result


def _identities(value: Any, field: str) -> list[str]:
    if not isinstance(value, list):
        raise ComparativeChangeError(f"{field} must be a list")
    result = [_identity(item, field) for item in value]
    if len(result) != len(set(result)):
        raise ComparativeChangeError(f"{field} contains duplicate identities")
    if result != sorted(result):
        raise ComparativeChangeError(f"{field} must be in canonical identity order")
    return result


def _exact_count(value: int) -> dict:
    return {"exact": str(value)}


def _sealed(value: Mapping[str, Any], key: str) -> dict:
    result = copy.deepcopy(dict(value))
    result.pop(key, None)
    result[key] = content_hash(result)
    return result


def _forbidden_paths(value: Any, path: str) -> list[str]:
    failures: list[str] = []
    if isinstance(value, Mapping):
        for key, item in value.items():
            normalized = str(key).strip().lower().replace("-", "_")
            if normalized in _FORBIDDEN_FACT_KEYS:
                failures.append(f"{path}.{key}")
            failures.extend(_forbidden_paths(item, f"{path}.{key}"))
    elif isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            failures.extend(_forbidden_paths(item, f"{path}[{index}]"))
    return failures


def _verification_result(value: Any, artifact_hash: str, minimum_action: str) -> dict:
    result = _object(value, "independent_verification")
    required = {"ok", "status", "checks", "violations", "warnings", "report"}
    if set(result) != required:
        raise ComparativeChangeError(
            "independent_verification must be one complete VerificationResult document"
        )
    if result.get("ok") is not True or result.get("status") != "VERIFIED":
        raise ComparativeChangeError(
            "the bound CertifiedDeltaRecord must have an independently VERIFIED result"
        )
    if result.get("violations") != []:
        raise ComparativeChangeError("an accepted independent result cannot contain violations")
    report = result.get("report")
    if not isinstance(report, Mapping):
        raise ComparativeChangeError("independent_verification.report must be an object")
    if report.get("artifact_root") != artifact_hash:
        raise ComparativeChangeError(
            "independent_verification does not bind the supplied CertifiedDeltaRecord"
        )
    if report.get("minimum_action") != minimum_action:
        raise ComparativeChangeError(
            "independent_verification minimum action differs from the supplied delta"
        )
    return result


def _scope(
    delta: Mapping[str, Any],
    inputs: Mapping[str, Any],
    decision_scope: Any,
    evidence_scope: Any,
) -> dict:
    prior = inputs["prior_case"]
    current = inputs["current_case"]
    if not isinstance(prior, Mapping) or not isinstance(current, Mapping):
        raise ComparativeChangeError("prior_case and current_case must be objects")
    decision = _object(decision_scope, "decision_scope")
    prior_case_id = prior.get("case_id")
    current_case_id = current.get("case_id")
    if prior_case_id is None and current_case_id is None:
        case_id = _identity(decision.get("case_id"), "decision_scope.case_id")
    elif prior_case_id is None or current_case_id is None:
        raise ComparativeChangeError(
            "prior_case and current_case must either both carry case_id or both omit it"
        )
    else:
        case_id = _identity(prior_case_id, "prior_case.case_id")
        if _identity(current_case_id, "current_case.case_id") != case_id:
            raise ComparativeChangeError(
                "comparative change evidence cannot cross case identities"
            )
    declared_case_id = decision.get("case_id")
    if declared_case_id is not None and (
        _identity(declared_case_id, "decision_scope.case_id") != case_id
    ):
        raise ComparativeChangeError(
            "decision_scope.case_id differs from the replayed case identity"
        )
    event = delta.get("change_event")
    if not isinstance(event, Mapping):
        raise ComparativeChangeError("CertifiedDeltaRecord.delta.change_event must be an object")
    scope = {
        "case_id": case_id,
        "event_id": _identity(event.get("event_id"), "change_event.event_id"),
        "prior_case_root": _identity(delta.get("prior_root"), "delta.prior_root"),
        "current_case_root": _identity(delta.get("current_root"), "delta.current_root"),
        "decision_scope": decision,
        "evidence_scope": _object(evidence_scope, "evidence_scope"),
        "change_scope": {
            "changed_object": _identity(
                event.get("changed_object"), "change_event.changed_object"
            ),
            "changed_properties": _identities(
                event.get("changed_properties"), "change_event.changed_properties"
            ),
            "declared_reason": _identity(
                event.get("declared_reason"), "change_event.declared_reason"
            ),
        },
    }
    return _sealed(scope, "scope_hash")


def _work_facts(delta: Mapping[str, Any], minimum_action: str) -> tuple[dict, dict]:
    preserved = _identities(delta.get("preserved"), "delta.preserved")
    invalidated = _identities(delta.get("invalidated"), "delta.invalidated")
    recomputed = _identities(delta.get("recomputed"), "delta.recomputed")
    overlap = sorted(set(preserved) & set(invalidated))
    if overlap:
        raise ComparativeChangeError(
            f"preserved and invalidated prior work overlap: {overlap}"
        )
    prior_members = sorted(set(preserved) | set(invalidated))
    denominator = _sealed(
        {
            "prior_artifact_work": {
                "members": prior_members,
                "count": _exact_count(len(prior_members)),
                "unit": "artifact identities",
            },
            "replacement_output_work": {
                "members": recomputed,
                "count": _exact_count(len(recomputed)),
                "unit": "artifact identities",
            },
        },
        "denominator_hash",
    )
    facts = {
        "facts_profile": "crg-certified-change-work/identity-counts@1",
        "minimum_action": minimum_action,
        "preserved_work": {
            "members": preserved,
            "count": _exact_count(len(preserved)),
            "unit": "artifact identities",
        },
        "invalidated_work": {
            "members": invalidated,
            "count": _exact_count(len(invalidated)),
            "unit": "artifact identities",
        },
        "recomputed_work": {
            "members": recomputed,
            "count": _exact_count(len(recomputed)),
            "unit": "artifact identities",
        },
        "prior_work_partition_complete": True,
        "interpretation": (
            "Exact artifact identities under the certified typed dependency closure; "
            "no effort, elapsed-time, cost, or counterfactual quantity is derived."
        ),
    }
    forbidden = _forbidden_paths(facts, "system_derived_facts")
    if forbidden:
        raise ComparativeChangeError(f"prohibited strengthened fact field(s): {forbidden}")
    return denominator, facts


@dataclass(frozen=True)
class ComparativeChangeEvidence:
    """Immutable convenience wrapper for a portable v1.2 comparison record."""

    record: Mapping[str, Any]

    def to_canonical(self) -> dict:
        return copy.deepcopy(dict(self.record))


def build_comparative_change_evidence(
    comparison_id: str,
    *,
    certified_delta: Mapping[str, Any],
    verification_inputs: Mapping[str, Any],
    independent_verification: Mapping[str, Any],
    decision_scope: Mapping[str, Any],
    evidence_scope: Mapping[str, Any],
    limitations: Sequence[str],
) -> ComparativeChangeEvidence:
    """Bind and summarize one independently verified ``CertifiedDeltaRecord``.

    The independent result is supplied across the trust-zone boundary.  The
    independent ``crg_verify`` implementation replays it again when this
    comparative artifact is verified.
    """

    identifier = _identity(comparison_id, "comparison_id")
    artifact = _object(certified_delta, "certified_delta")
    if (
        artifact.get("record_type") != "CertifiedDeltaRecord"
        or artifact.get("schema_version") != COMPARATIVE_CHANGE_SCHEMA_VERSION
        or artifact.get("verification_status") != "INDEPENDENTLY_VERIFIED"
    ):
        raise ComparativeChangeError(
            "certified_delta must be an independently verified v1.2.0 CertifiedDeltaRecord"
        )
    delta = artifact.get("delta")
    if not isinstance(delta, Mapping):
        raise ComparativeChangeError("certified_delta.delta must be an object")
    minimum_claim = artifact.get("minimum_recomputation_claim")
    if not isinstance(minimum_claim, Mapping):
        raise ComparativeChangeError("certified_delta has no minimum-recomputation claim")
    minimum_action = _identity(minimum_claim.get("action"), "minimum action")

    inputs = _object(verification_inputs, "verification_inputs")
    missing = sorted(_REQUIRED_INPUTS - set(inputs))
    unknown = sorted(set(inputs) - _REQUIRED_INPUTS - _OPTIONAL_INPUTS)
    if missing or unknown:
        raise ComparativeChangeError(
            f"verification_inputs are not closed: missing={missing}, unknown={unknown}"
        )
    artifact_hash = content_hash(artifact)
    independent = _verification_result(
        independent_verification, artifact_hash, minimum_action
    )
    binding = _sealed(
        {
            "certified_delta": artifact,
            "verification_inputs": inputs,
            "independent_verification": independent,
            "certified_delta_hash": artifact_hash,
            "verification_inputs_hash": content_hash(inputs),
            "independent_verification_hash": content_hash(independent),
        },
        "binding_hash",
    )
    scope = _scope(delta, inputs, decision_scope, evidence_scope)
    denominator, facts = _work_facts(delta, minimum_action)
    if not isinstance(limitations, (list, tuple)):
        raise ComparativeChangeError("limitations must be a list")
    limitation_records = sorted(_identity(item, "limitation") for item in limitations)
    if not limitation_records or len(limitation_records) != len(set(limitation_records)):
        raise ComparativeChangeError("limitations must be non-empty and unique")

    record = {
        "record_type": "ComparativeChangeEvidence",
        "schema_version": COMPARATIVE_CHANGE_SCHEMA_VERSION,
        "profile": COMPARATIVE_CHANGE_PROFILE,
        "first_release_attribution": COMPARATIVE_CHANGE_FIRST_RELEASE,
        "comparison_id": identifier,
        "authority": COMPARATIVE_CHANGE_AUTHORITY,
        "authorizing": False,
        "semantic_effect": "NONE",
        "evidence_class": "SYSTEM_DERIVED_CERTIFIED_CHANGE_FACTS",
        "claim_boundary": COMPARATIVE_CHANGE_CLAIM_BOUNDARY,
        "scope": scope,
        "certified_delta_binding": binding,
        "work_denominator": denominator,
        "system_derived_facts": facts,
        "conclusion": "NO_METHOD_RANKING_OR_ECONOMIC_CONCLUSION",
        "limitations": limitation_records,
    }
    return ComparativeChangeEvidence(_sealed(record, "record_hash"))
