"""Independent verification of portable domain-pack authoring reports.

The authoring report is a claim about one exact JSON byte sequence.  This
module re-parses those bytes and reconstructs the declaration-only pack using
only the verifier's independent canonicalizer and the Python standard library.
It does not import ``crg-generate``, ``crg-model``, a pack, or extension code.

The result is deliberately non-authorizing.  A matching report establishes
only that the fixed authoring profile produced the stated validation outcome;
it does not execute extensions, replay conformance tests, verify signatures,
grant permissions, or establish that a pack is safe to run.
"""
from __future__ import annotations

import hashlib
import json
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple, Union

from .canonical import CanonicalError, canonical_bytes, content_hash, is_hash
from .certificate import Status, VerificationResult

__all__ = ["verify_pack_authoring_report"]


REPORT_VERSION = "1.0.0"
VALIDATION_PROFILE = "CRG_DOMAIN_PACK_JSON_AUTHORING_STRICT_V1"
SPEC_VERSION = "0.2.0"
AUTHORITY = "AUTHORING_VALIDATION_ONLY"
CLAIM_BOUNDARY = (
    "validates declaration-only JSON shape and pack semantics; does not execute "
    "extensions, replay conformance tests, verify package signatures, or grant "
    "permissions"
)

_REPORT_FIELDS = frozenset(
    {
        "record_type",
        "report_version",
        "validation_profile",
        "spec_version",
        "authority",
        "claim_boundary",
        "source_hash",
        "source_size_bytes",
        "disposition",
        "manifest_identity",
        "manifest_version",
        "manifest_hash",
        "pack_hash",
        "schema_violations",
        "semantic_violations",
        "declarations",
        "diagnostics",
    }
)
_DECLARATION_FIELDS = frozenset(
    {
        "permissions",
        "in_process_permissions",
        "isolation_required_permissions",
        "unknown_permissions",
        "determinism_status",
        "proof_checkers",
    }
)
_DIAGNOSTIC_FIELDS = frozenset({"code", "category", "status", "path", "message"})

_MANIFEST_REQUIRED_FIELDS: Tuple[str, ...] = (
    "identity",
    "version",
    "publisher",
    "supported_spec_versions",
    "permissions",
    "input_schemas",
    "output_schemas",
    "determinism_status",
    "external_dependencies",
    "resource_requirements",
    "failure_modes",
    "license",
    "provenance",
    "security_classification",
    "quantity_registry_additions",
    "proof_implications",
    "conformance_tests",
)
_MANIFEST_FATAL_FIELDS = frozenset(
    {
        "identity",
        "version",
        "supported_spec_versions",
        "determinism_status",
        "conformance_tests",
    }
)
_STRING_FIELDS = frozenset(
    {
        "identity",
        "version",
        "publisher",
        "determinism_status",
        "license",
        "security_classification",
    }
)
_MAPPING_FIELDS = frozenset({"resource_requirements", "provenance"})
_LIST_STRING_FIELDS = (
    frozenset(_MANIFEST_REQUIRED_FIELDS) - _STRING_FIELDS - _MAPPING_FIELDS
)

_CONTENT_MAPPING_FIELDS = frozenset(
    {"terminology", "quantities", "contracts", "accounting_rules"}
)
_CONTENT_LIST_FIELDS = frozenset(
    {
        "transformations",
        "obligation_coordinates",
        "technology_coordinates",
        "evaluators",
        "qualification_methods",
        "ui_extensions",
        "example_cases",
        "conformance_fixtures",
    }
)
_CONTENT_FIELDS = _CONTENT_MAPPING_FIELDS | _CONTENT_LIST_FIELDS | {"proof_checkers"}
_PROOF_CHECKER_FIELDS = frozenset(
    {
        "checker_id",
        "proof_format",
        "semantic_scope",
        "version",
        "implementation_identity",
        "sandbox_requirements",
        "conformance_suite",
        "trust_profile",
    }
)

_IN_PROCESS_PERMISSIONS = frozenset(
    {
        "READ_SOURCE",
        "READ_CONTEXT",
        "GENERATE_REALIZATIONS",
        "EVALUATE_LEGALITY",
        "EXTRACT_OBLIGATIONS",
        "REGISTER_QUANTITIES",
        "PROVIDE_BOUNDS",
        "RENDER_CERTIFICATE",
    }
)
_ISOLATION_PERMISSIONS = frozenset(
    {"FILESYSTEM_READ", "FILESYSTEM_WRITE", "NETWORK", "SUBPROCESS", "SECRETS"}
)
_ALL_PERMISSIONS = _IN_PROCESS_PERMISSIONS | _ISOLATION_PERMISSIONS
_DETERMINISM_STATUSES = frozenset(
    {"DETERMINISTIC", "SEEDED_DETERMINISTIC", "NONDETERMINISTIC"}
)
_SECURITY_CLASSIFICATIONS = frozenset(
    {"TRUSTED_FIRST_PARTY", "REVIEWED_THIRD_PARTY", "UNTRUSTED"}
)
_CORE_RESERVED_NAMES = frozenset(
    {
        "EXHAUSTIVE_DECLARED_UNIVERSE",
        "GENERATOR_CLOSED",
        "EXPLICIT_IMPORTED_FAMILY",
        "BOUNDED_UNENUMERATED_FAMILY",
        "TRUNCATED_BY_DECLARED_RULE",
        "KNOWN_INCOMPLETE",
        "UNKNOWN",
        "FULL_DECLARED_UNIVERSE",
        "GENERATOR_CLOSED_FAMILY",
        "BOUNDED_REMAINDER_GLOBAL",
        "RELATIVE_EXPLICIT_FAMILY",
        "PARTIAL_FAMILY",
        "LEGAL",
        "ILLEGAL",
        "INFEASIBLE",
        "UNGENERATED",
        "UNEVALUATED",
        "UNSUPPORTED",
        "claim_scope",
        "completeness_basis",
        "decision_certificate",
        "pruning_certificate",
        "regret_witness",
        "evidence_class",
    }
)


class _DecodeError(ValueError):
    pass


class _Unsupported(_DecodeError):
    pass


class _DuplicateKey(_DecodeError):
    pass


class _InexactJsonNumber(_DecodeError):
    pass


def _keys(value: Mapping[str, Any], required: Iterable[str], where: str) -> None:
    expected = set(required)
    missing = expected - set(value)
    unknown = set(value) - expected
    if missing:
        raise _DecodeError(f"{where} is missing fields {sorted(missing)}")
    if unknown:
        raise _DecodeError(f"{where} has unsupported fields {sorted(unknown)}")


def _array(value: Any, where: str) -> Sequence[Any]:
    if not isinstance(value, (list, tuple)):
        raise _DecodeError(f"{where} must be an array")
    return value


def _string_array(value: Any, where: str) -> List[str]:
    items = _array(value, where)
    if not all(isinstance(item, str) for item in items):
        raise _DecodeError(f"{where} must contain only strings")
    return list(items)


def _strict_object(pairs: Sequence[Tuple[str, Any]]) -> Dict[str, Any]:
    result: Dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise _DuplicateKey(f"duplicate JSON object member {key!r}")
        result[key] = value
    return result


def _reject_float(token: str) -> Any:
    raise _InexactJsonNumber(
        f"JSON number {token!r} is not an exact portable CRG value; use an integer "
        "or an exact decimal/rational string"
    )


def _reject_constant(token: str) -> Any:
    raise _InexactJsonNumber(f"non-finite JSON constant {token!r} is not admissible")


def _is_string_list(value: Any) -> bool:
    return isinstance(value, list) and all(isinstance(item, str) for item in value)


def _diagnostic(
    code: str, category: str, accepted: bool, message: str, path: str = "$"
) -> Dict[str, str]:
    return {
        "code": code,
        "category": category,
        "status": "ACCEPTED" if accepted else "REFUSED",
        "path": path,
        "message": message,
    }


def _schema_violations(document: Any) -> List[str]:
    violations: List[str] = []
    if not isinstance(document, Mapping):
        return [f"$: expected a JSON object, got {type(document).__name__}"]

    allowed = set(_MANIFEST_REQUIRED_FIELDS) | {"contents", "extensions"}
    for name in sorted(set(document) - allowed):
        violations.append(f"$.{name}: unknown manifest field; refused fail-closed")

    for name in _MANIFEST_REQUIRED_FIELDS:
        if name not in document:
            violations.append(f"$.{name}: required manifest field is absent")
            continue
        value = document[name]
        if name in _STRING_FIELDS and not isinstance(value, str):
            violations.append(f"$.{name}: expected string, got {type(value).__name__}")
        elif name in _LIST_STRING_FIELDS and not _is_string_list(value):
            violations.append(f"$.{name}: expected an array of strings")
        elif name in _MAPPING_FIELDS and not isinstance(value, Mapping):
            violations.append(f"$.{name}: expected object, got {type(value).__name__}")

    contents = document.get("contents", {})
    if not isinstance(contents, Mapping):
        violations.append("$.contents: expected object")
    else:
        for name in sorted(set(contents) - _CONTENT_FIELDS):
            violations.append(f"$.contents.{name}: unknown pack content; refused fail-closed")
        for name in sorted(_CONTENT_MAPPING_FIELDS & set(contents)):
            if not isinstance(contents[name], Mapping):
                violations.append(f"$.contents.{name}: expected object")
        for name in sorted(_CONTENT_LIST_FIELDS & set(contents)):
            if not _is_string_list(contents[name]):
                violations.append(f"$.contents.{name}: expected an array of strings")

        checkers = contents.get("proof_checkers", [])
        if not isinstance(checkers, list):
            violations.append("$.contents.proof_checkers: expected an array of objects")
        else:
            for index, checker in enumerate(checkers):
                path = f"$.contents.proof_checkers[{index}]"
                if not isinstance(checker, Mapping):
                    violations.append(f"{path}: expected object")
                    continue
                missing = sorted(_PROOF_CHECKER_FIELDS - set(checker))
                unknown = sorted(set(checker) - _PROOF_CHECKER_FIELDS)
                if missing:
                    violations.append(f"{path}: missing declaration fields {missing}")
                if unknown:
                    violations.append(
                        f"{path}: unknown declaration fields {unknown}; refused fail-closed"
                    )
                for field in (
                    "checker_id",
                    "proof_format",
                    "semantic_scope",
                    "version",
                    "implementation_identity",
                    "trust_profile",
                ):
                    if field in checker and not isinstance(checker[field], str):
                        violations.append(f"{path}.{field}: expected string")
                if (
                    isinstance(checker.get("implementation_identity"), str)
                    and not is_hash(checker["implementation_identity"])
                ):
                    violations.append(
                        f"{path}.implementation_identity: expected a content-addressed "
                        "sha256:<64 lowercase hexadecimal digits> identity"
                    )
                if "sandbox_requirements" in checker and not isinstance(
                    checker["sandbox_requirements"], Mapping
                ):
                    violations.append(f"{path}.sandbox_requirements: expected object")
                if "conformance_suite" in checker and not _is_string_list(
                    checker["conformance_suite"]
                ):
                    violations.append(f"{path}.conformance_suite: expected array of strings")

    extensions = document.get("extensions", {})
    if not isinstance(extensions, Mapping):
        violations.append("$.extensions: expected object")
    elif extensions:
        violations.append(
            "$.extensions: portable JSON authoring accepts declaration-only manifests; "
            "live generators, predicates, and typed bindings must be supplied separately "
            "by an execution host"
        )
    return sorted(set(violations))


def _manifest_canonical(document: Mapping[str, Any]) -> Dict[str, Any]:
    result: Dict[str, Any] = {}
    for name in _MANIFEST_REQUIRED_FIELDS:
        value = document[name]
        if name in _LIST_STRING_FIELDS:
            result[name] = sorted(value) if name == "permissions" else list(value)
        elif name in _MAPPING_FIELDS:
            result[name] = dict(value)
        else:
            result[name] = value
    return result


def _pack_canonical(document: Mapping[str, Any]) -> Dict[str, Any]:
    contents = document.get("contents", {})
    return {
        "manifest": _manifest_canonical(document),
        "generators": [],
        "legality_predicates": [],
        "typed_extensions": [],
        "terminology": dict(contents.get("terminology", {})),
        "quantities": dict(contents.get("quantities", {})),
        "contracts": dict(contents.get("contracts", {})),
        "transformations": list(contents.get("transformations", [])),
        "obligation_coordinates": list(contents.get("obligation_coordinates", [])),
        "accounting_rules": dict(contents.get("accounting_rules", {})),
        "technology_coordinates": list(contents.get("technology_coordinates", [])),
        "evaluators": list(contents.get("evaluators", [])),
        "qualification_methods": list(contents.get("qualification_methods", [])),
        "proof_checkers": [dict(checker) for checker in contents.get("proof_checkers", [])],
        "ui_extensions": list(contents.get("ui_extensions", [])),
        "example_cases": list(contents.get("example_cases", [])),
        "conformance_fixtures": list(contents.get("conformance_fixtures", [])),
    }


def _isolation_refusal(token: str) -> str:
    return (
        f"manifest declares permission {token!r}, which requires the process, "
        "filesystem, and network isolation of specification 36.3. This SDK loads packs "
        "in its own interpreter and cannot confine it, so the permission is refused "
        "rather than granted unenforced"
    )


def _semantic_violations(document: Mapping[str, Any], spec_version: str) -> List[str]:
    violations: List[str] = []

    for name in _MANIFEST_REQUIRED_FIELDS:
        value = document[name]
        if not value:
            if name in _MANIFEST_FATAL_FIELDS:
                violations.append(
                    f"manifest omits {name!r}, which specification 36.2 makes a MUST; a "
                    "pack without it cannot be identified, pinned, checked for compatibility, "
                    "or relied on for a certificate"
                )
            else:
                violations.append(
                    f"manifest omits {name!r} (spec 36.2 requires every listed field)"
                )

    declared = set(document["permissions"])
    for token in sorted(declared - _ALL_PERMISSIONS):
        violations.append(
            f"manifest declares unknown permission {token!r}; the declared vocabulary is "
            f"{sorted(_ALL_PERMISSIONS)} (spec 36.2)"
        )
    for token in sorted(declared & _ISOLATION_PERMISSIONS):
        violations.append(_isolation_refusal(token))
    if document["quantity_registry_additions"] and "REGISTER_QUANTITIES" not in declared:
        violations.append(
            "the pack exercises 'REGISTER_QUANTITIES' but does not declare it; every "
            "capability a pack uses MUST appear in its declared permission list "
            "(spec 36.2, 36.3)"
        )

    supported = document["supported_spec_versions"]
    if supported and spec_version not in supported:
        violations.append(
            f"the pack supports specification version(s) {sorted(supported)} but this core "
            f"implements {spec_version}; a pack that has not been checked against the "
            "specification in force MUST NOT be loaded (spec 15.6, 36.2)"
        )

    determinism = document["determinism_status"]
    if determinism and determinism not in _DETERMINISM_STATUSES:
        violations.append(
            f"manifest declares determinism status {determinism!r}; expected one of "
            f"{sorted(_DETERMINISM_STATUSES)} (spec 6.5, 36.2)"
        )

    contents = document.get("contents", {})
    defined_names = (
        set(document["quantity_registry_additions"])
        | set(document["proof_implications"])
        | set(contents.get("terminology", {}))
        | set(contents.get("obligation_coordinates", []))
    )
    for name in sorted(defined_names):
        if name in _CORE_RESERVED_NAMES:
            violations.append(
                f"the pack defines {name!r}, which is core certificate vocabulary; a domain "
                "pack MUST NOT override core certificate semantics (spec 36.4)"
            )

    seen_checkers = set()
    for index, checker in enumerate(contents.get("proof_checkers", [])):
        missing = sorted(_PROOF_CHECKER_FIELDS - set(checker))
        unknown = sorted(set(checker) - _PROOF_CHECKER_FIELDS)
        if missing or unknown:
            violations.append(
                f"proof checker {index} declaration fields mismatch: missing={missing}, "
                f"unknown={unknown} (spec 24.6, 36.4)"
            )
            continue
        checker_id = str(checker.get("checker_id", ""))
        if not checker_id:
            violations.append(f"proof checker {index} has no checker_id (spec 24.6)")
        elif checker_id in seen_checkers:
            violations.append(f"proof checker {checker_id!r} is declared more than once")
        seen_checkers.add(checker_id)
        for name in (
            "proof_format",
            "semantic_scope",
            "version",
            "implementation_identity",
            "trust_profile",
        ):
            if not str(checker.get(name, "")).strip():
                violations.append(
                    f"proof checker {checker_id or index!r} omits {name} (spec 24.6)"
                )
        sandbox = checker.get("sandbox_requirements")
        if not isinstance(sandbox, Mapping) or not str(sandbox.get("execution_mode", "")):
            violations.append(
                f"proof checker {checker_id or index!r} lacks sandbox execution_mode "
                "(spec 24.6)"
            )
        suite = checker.get("conformance_suite")
        if isinstance(suite, str) or not isinstance(suite, (list, tuple)) or not suite:
            violations.append(
                f"proof checker {checker_id or index!r} lacks a conformance suite "
                "(spec 24.6)"
            )

    classification = document["security_classification"]
    if classification and classification not in _SECURITY_CLASSIFICATIONS:
        violations.append(
            f"manifest declares security classification {classification!r}; expected one of "
            f"{sorted(_SECURITY_CLASSIFICATIONS)} (spec 36.2)"
        )
    if classification == "UNTRUSTED" and document["external_dependencies"]:
        violations.append(
            "an UNTRUSTED pack declares external dependencies; specification 36.3 requires "
            "signed-package verification and a reproducible environment manifest before "
            "such a pack may run, and this loader can verify neither"
        )
    return sorted(set(violations))


def _source_bytes(source: Union[bytes, bytearray, str]) -> bytes:
    if isinstance(source, str):
        return source.encode("utf-8")
    if isinstance(source, (bytes, bytearray)):
        return bytes(source)
    raise _DecodeError("pack manifest JSON source must be bytes or str")


def _expected_report(source: Union[bytes, bytearray, str], spec_version: str) -> Dict[str, Any]:
    source_bytes = _source_bytes(source)
    source_hash = "sha256:" + hashlib.sha256(source_bytes).hexdigest()
    diagnostics: List[Dict[str, str]] = []
    schema: List[str] = []
    semantic: List[str] = []
    document: Mapping[str, Any] = {}
    parsed: Any = None

    try:
        text = source_bytes.decode("utf-8")
        if text.startswith("\ufeff"):
            raise UnicodeError("a UTF-8 BOM is not part of the portable JSON profile")
        diagnostics.append(_diagnostic("SOURCE_UTF8", "SOURCE", True, "source is strict UTF-8"))
    except UnicodeError as error:
        schema.append(f"$: source is not strict UTF-8: {error}")
        diagnostics.append(_diagnostic("SOURCE_UTF8", "SOURCE", False, schema[-1]))
        text = ""

    if not schema:
        try:
            parsed = json.loads(
                text,
                object_pairs_hook=_strict_object,
                parse_float=_reject_float,
                parse_constant=_reject_constant,
            )
            diagnostics.append(_diagnostic("JSON_PARSE", "SCHEMA", True, "source is strict JSON"))
            if isinstance(parsed, Mapping):
                document = parsed
        except (ValueError, RecursionError) as error:
            schema.append(f"$: JSON refused: {error}")
            diagnostics.append(_diagnostic("JSON_PARSE", "SCHEMA", False, schema[-1]))
    else:
        diagnostics.append(
            _diagnostic("JSON_PARSE", "SCHEMA", False, "JSON parsing blocked by source refusal")
        )

    if not schema:
        schema.extend(_schema_violations(parsed))
        diagnostics.append(
            _diagnostic(
                "MANIFEST_SCHEMA",
                "SCHEMA",
                not schema,
                "manifest fields and portable value types are admitted"
                if not schema
                else f"manifest schema refused with {len(schema)} violation(s)",
            )
        )
    else:
        diagnostics.append(
            _diagnostic(
                "MANIFEST_SCHEMA",
                "SCHEMA",
                False,
                "manifest schema evaluation blocked by prior refusal",
            )
        )

    manifest_hash = ""
    pack_hash = ""
    if not schema:
        try:
            canonical_bytes(document)
            diagnostics.append(
                _diagnostic("CANONICALIZABLE", "SCHEMA", True, "manifest is canonically hashable")
            )
        except (CanonicalError, TypeError, UnicodeEncodeError) as error:
            schema.append(f"$: manifest is not canonically hashable: {error}")
            diagnostics.append(_diagnostic("CANONICALIZABLE", "SCHEMA", False, schema[-1]))
    else:
        diagnostics.append(
            _diagnostic(
                "CANONICALIZABLE",
                "SCHEMA",
                False,
                "canonicalization blocked by schema refusal",
            )
        )

    if not schema:
        try:
            manifest_hash = content_hash(_manifest_canonical(document))
            pack_hash = content_hash(_pack_canonical(document))
            diagnostics.append(
                _diagnostic("PACK_LOAD", "SEMANTIC", True, "manifest loaded fail-closed")
            )
        except (CanonicalError, TypeError, ValueError, UnicodeEncodeError) as error:
            schema.append(f"$: loader refused manifest: {error}")
            diagnostics.append(_diagnostic("PACK_LOAD", "SEMANTIC", False, schema[-1]))
    else:
        diagnostics.append(
            _diagnostic("PACK_LOAD", "SEMANTIC", False, "pack loading blocked by schema refusal")
        )

    if not schema and manifest_hash and pack_hash:
        semantic.extend(_semantic_violations(document, spec_version))
        diagnostics.append(
            _diagnostic(
                "PACK_SEMANTICS",
                "SEMANTIC",
                not semantic,
                "pack semantic declarations are admissible"
                if not semantic
                else f"pack semantics refused with {len(semantic)} violation(s)",
            )
        )
    else:
        diagnostics.append(
            _diagnostic(
                "PACK_SEMANTICS",
                "SEMANTIC",
                False,
                "semantic validation blocked because the pack did not load",
            )
        )

    raw_permissions = document.get("permissions", []) if document else []
    declared = sorted(raw_permissions) if _is_string_list(raw_permissions) else []
    in_process = sorted(set(declared) & _IN_PROCESS_PERMISSIONS)
    isolated = sorted(set(declared) & _ISOLATION_PERMISSIONS)
    unknown = sorted(set(declared) - _ALL_PERMISSIONS)
    contents = document.get("contents", {}) if document else {}
    raw_checkers = contents.get("proof_checkers", []) if isinstance(contents, Mapping) else []
    checker_declarations: List[Dict[str, Any]] = []
    if isinstance(raw_checkers, list) and all(isinstance(item, Mapping) for item in raw_checkers):
        checker_declarations = [
            dict(checker)
            for checker in sorted(
                raw_checkers,
                key=lambda item: (
                    str(item.get("checker_id", "")),
                    str(item.get("version", "")),
                ),
            )
        ]

    disposition = (
        "ACCEPTED"
        if not schema and not semantic and bool(manifest_hash) and bool(pack_hash)
        else "REFUSED"
    )
    return {
        "record_type": "CRGPackAuthoringReport",
        "report_version": REPORT_VERSION,
        "validation_profile": VALIDATION_PROFILE,
        "spec_version": spec_version,
        "authority": AUTHORITY,
        "claim_boundary": CLAIM_BOUNDARY,
        "source_hash": source_hash,
        "source_size_bytes": len(source_bytes),
        "disposition": disposition,
        "manifest_identity": (
            str(document.get("identity", ""))
            if isinstance(document.get("identity", ""), str)
            else ""
        ),
        "manifest_version": (
            str(document.get("version", ""))
            if isinstance(document.get("version", ""), str)
            else ""
        ),
        "manifest_hash": manifest_hash,
        "pack_hash": pack_hash,
        "schema_violations": sorted(set(schema)),
        "semantic_violations": sorted(set(semantic)),
        "declarations": {
            "permissions": declared,
            "in_process_permissions": in_process,
            "isolation_required_permissions": isolated,
            "unknown_permissions": unknown,
            "determinism_status": (
                str(document.get("determinism_status", ""))
                if isinstance(document.get("determinism_status", ""), str)
                else ""
            ),
            "proof_checkers": checker_declarations,
        },
        "diagnostics": diagnostics,
    }


def _decode_report(report: Mapping[str, Any]) -> Dict[str, Any]:
    if not isinstance(report, dict):
        raise _DecodeError("pack authoring report must be a JSON object")
    _keys(report, _REPORT_FIELDS, "pack authoring report")
    if report.get("record_type") != "CRGPackAuthoringReport":
        raise _Unsupported("unsupported pack authoring record_type")
    if report.get("report_version") != REPORT_VERSION:
        raise _Unsupported("unsupported pack authoring report_version")
    if report.get("validation_profile") != VALIDATION_PROFILE:
        raise _Unsupported("unsupported pack authoring validation_profile")
    if report.get("spec_version") != SPEC_VERSION:
        raise _Unsupported(
            f"unsupported pack authoring spec_version {report.get('spec_version')!r}"
        )
    if report.get("authority") != AUTHORITY or report.get("claim_boundary") != CLAIM_BOUNDARY:
        raise _DecodeError("pack authoring report attempts to strengthen its authority")
    if not is_hash(report.get("source_hash")):
        raise _DecodeError("pack authoring source_hash is not a SHA-256 content hash")
    size = report.get("source_size_bytes")
    if isinstance(size, bool) or not isinstance(size, int) or size < 0:
        raise _DecodeError("pack authoring source_size_bytes must be a non-negative integer")
    if report.get("disposition") not in {"ACCEPTED", "REFUSED"}:
        raise _DecodeError("pack authoring disposition is unsupported")
    for name in ("manifest_identity", "manifest_version"):
        if not isinstance(report.get(name), str):
            raise _DecodeError(f"pack authoring {name} must be a string")
    for name in ("manifest_hash", "pack_hash"):
        value = report.get(name)
        if value != "" and not is_hash(value):
            raise _DecodeError(f"pack authoring {name} is not empty or a SHA-256 hash")
    for name in ("schema_violations", "semantic_violations"):
        _string_array(report.get(name), f"pack authoring {name}")

    declarations = report.get("declarations")
    if not isinstance(declarations, dict):
        raise _DecodeError("pack authoring declarations must be an object")
    _keys(declarations, _DECLARATION_FIELDS, "pack authoring declarations")
    for name in (
        "permissions",
        "in_process_permissions",
        "isolation_required_permissions",
        "unknown_permissions",
    ):
        _string_array(declarations.get(name), f"pack authoring declarations.{name}")
    if not isinstance(declarations.get("determinism_status"), str):
        raise _DecodeError("pack authoring declarations.determinism_status must be a string")
    checkers = _array(declarations.get("proof_checkers"), "pack authoring proof_checkers")
    if not all(isinstance(checker, dict) for checker in checkers):
        raise _DecodeError("pack authoring proof_checkers must contain only objects")
    if report["disposition"] == "ACCEPTED":
        for index, checker in enumerate(checkers):
            _keys(checker, _PROOF_CHECKER_FIELDS, f"proof checker {index}")
            for name in (
                "checker_id",
                "proof_format",
                "semantic_scope",
                "version",
                "implementation_identity",
                "trust_profile",
            ):
                if not isinstance(checker.get(name), str):
                    raise _DecodeError(f"proof checker {index}.{name} must be a string")
            if not is_hash(checker.get("implementation_identity")):
                raise _DecodeError(
                    f"proof checker {index}.implementation_identity is not a SHA-256 hash"
                )
            if not isinstance(checker.get("sandbox_requirements"), dict):
                raise _DecodeError(f"proof checker {index}.sandbox_requirements must be an object")
            _string_array(
                checker.get("conformance_suite"), f"proof checker {index}.conformance_suite"
            )

    diagnostics = _array(report.get("diagnostics"), "pack authoring diagnostics")
    if not diagnostics:
        raise _DecodeError("pack authoring diagnostics must not be empty")
    for index, diagnostic in enumerate(diagnostics):
        if not isinstance(diagnostic, dict):
            raise _DecodeError(f"pack authoring diagnostic {index} must be an object")
        _keys(diagnostic, _DIAGNOSTIC_FIELDS, f"pack authoring diagnostic {index}")
        if not all(isinstance(diagnostic.get(name), str) for name in _DIAGNOSTIC_FIELDS):
            raise _DecodeError(f"pack authoring diagnostic {index} fields must be strings")
        if diagnostic.get("status") not in {"ACCEPTED", "REFUSED"}:
            raise _DecodeError(f"pack authoring diagnostic {index} status is unsupported")

    try:
        canonical_bytes(report)
    except (CanonicalError, TypeError, UnicodeEncodeError) as error:
        raise _DecodeError(f"pack authoring report is not canonically hashable: {error}") from error
    return dict(report)


def verify_pack_authoring_report(
    report: Mapping[str, Any],
    manifest_source: Union[bytes, bytearray, str],
    *,
    spec_version: str = SPEC_VERSION,
) -> VerificationResult:
    """Verify a report against the exact portable manifest source.

    ``spec_version`` is explicit because compatibility is one of the report's
    semantic claims.  This verifier supports the specification version bound
    to the current authoring profile; another target is unsupported rather
    than silently interpreted under different rules.
    """

    result = VerificationResult(ok=False)
    try:
        if spec_version != SPEC_VERSION:
            raise _Unsupported(
                f"authoring profile {VALIDATION_PROFILE} is bound to specification "
                f"{SPEC_VERSION}, not {spec_version!r}"
            )
        decoded = _decode_report(report)
        expected = _expected_report(manifest_source, spec_version)
    except _Unsupported as error:
        result.record("supported_profile", False, str(error))
        result.status = Status.UNSUPPORTED_PROFILE
        result.report.update(
            {"record_type": "CRGPackAuthoringReport", "authorization_effect": "NONE"}
        )
        return result.finish()
    except (
        _DecodeError,
        CanonicalError,
        TypeError,
        ValueError,
        UnicodeDecodeError,
        UnicodeEncodeError,
        json.JSONDecodeError,
    ) as error:
        result.record("pack_authoring_report", False, str(error))
        result.status = Status.FAILED
        result.report.update(
            {"record_type": "CRGPackAuthoringReport", "authorization_effect": "NONE"}
        )
        return result.finish()

    result.record(
        "spec_version_binding",
        decoded["spec_version"] == expected["spec_version"] == spec_version,
        "the report binds the exact specification version used for semantic validation",
    )
    result.record(
        "exact_source_binding",
        decoded["source_hash"] == expected["source_hash"]
        and decoded["source_size_bytes"] == expected["source_size_bytes"],
        "source SHA-256 and byte length match the caller-supplied manifest bytes",
    )
    result.record(
        "manifest_identity_binding",
        decoded["manifest_identity"] == expected["manifest_identity"]
        and decoded["manifest_version"] == expected["manifest_version"],
        "manifest identity and version were independently reconstructed",
    )
    result.record(
        "schema_outcome",
        decoded["schema_violations"] == expected["schema_violations"],
        "strict UTF-8/JSON, field, type, duplicate-member, and exact-number checks agree",
    )
    result.record(
        "semantic_outcome",
        decoded["semantic_violations"] == expected["semantic_violations"],
        "permission, isolation, compatibility, determinism, checker, and override checks agree",
    )
    result.record(
        "declaration_reconstruction",
        decoded["declarations"] == expected["declarations"],
        "permission classes, determinism, and proof-checker declarations were reconstructed",
    )
    result.record(
        "manifest_hash_binding",
        decoded["manifest_hash"] == expected["manifest_hash"],
        "normalized declaration manifest hash matches independent canonicalization",
    )
    result.record(
        "pack_hash_binding",
        decoded["pack_hash"] == expected["pack_hash"],
        "declaration-only pack hash matches independent canonicalization",
    )
    result.record(
        "disposition",
        decoded["disposition"] == expected["disposition"],
        "accepted/refused disposition follows the independently reconstructed outcomes",
    )
    result.record(
        "diagnostics",
        decoded["diagnostics"] == expected["diagnostics"],
        "the complete ordered diagnostic trace was independently reconstructed",
    )
    result.record(
        "non_authorizing_boundary",
        decoded["authority"] == AUTHORITY and decoded["claim_boundary"] == CLAIM_BOUNDARY,
        "verification grants no execution, signature, conformance, permission, or decision authority",
    )

    result.status = Status.INTEGRITY_ONLY if not result.violations else Status.FAILED
    result.report.update(
        {
            "record_type": "CRGPackAuthoringReport",
            "verification_profile": VALIDATION_PROFILE,
            "spec_version": spec_version,
            "authoring_disposition": expected["disposition"],
            "manifest_admitted": expected["disposition"] == "ACCEPTED",
            "report_hash": content_hash(decoded),
            "expected_report_hash": content_hash(expected),
            "manifest_hash": expected["manifest_hash"],
            "pack_hash": expected["pack_hash"],
            "authorization_effect": "NONE",
            "execution_authorized": False,
            "permissions_granted": [],
            "extensions_executed": False,
            "conformance_replayed": False,
            "signature_verified": False,
        }
    )
    return result.finish()

# v1.3 composite closure: this product path is phase-bound to ETQ integration.
