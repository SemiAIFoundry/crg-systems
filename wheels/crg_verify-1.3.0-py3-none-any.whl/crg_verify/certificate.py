"""Independent decision-certificate verification.

Normative basis: 5.3 (evidence classes), 6.6 (fail closed), 9.1-9.3 (trust
zones, proof-carrying engineering), 21.4-21.6 (claim scope), 22.2-22.7
(decision values, strict winner, ties), 23.2-23.4 (solver trust), 25 (the
independent verifier), 26.4 (decision-observation mapping), 27.3-27.4
(regret witnesses), 45 (clock discipline).

Everything here is a re-derivation.  Every value the certificate asserts is
recomputed from the retained registry, every classification is re-derived
from the normative tables, and where the two disagree the certificate
loses.  9.3 is explicit that the verifier MUST NOT assume the issuer is
correct merely because it issued a certificate-shaped artifact, so nothing
below reads a stated conclusion and calls that a check.
"""
from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass, field
from fractions import Fraction
from typing import Any, Dict, List, Optional, Sequence, Tuple

from .arith import (
    ZERO, ArithError, Interval, fmt, iadd, imul, interval, minimum,
    positive_part_sup, rational, strictly_below, within_tolerance,
)
from .canonical import content_hash, hash_without, is_hash

__all__ = [
    "VerificationResult", "Status", "TimeStatus", "Level", "verify_certificate",
    "required_object_for", "derive_claim_scope", "evaluate_objective", "VERIFIER_ID",
]

VERIFIER_ID = "crg-verify"
VERIFIER_VERSION = "1.3.0"
SPEC_VERSION = "0.2.0"
# Proof-checker pins identify the stable verification protocol implemented by
# both independent checkers, not the distribution/package release.
CHECKER_PROFILE_VERSION = SPEC_VERSION


class Status:
    """Final verification statuses (spec 25.4)."""

    VERIFIED = "VERIFIED"
    VERIFIED_RELATIVE = "VERIFIED_RELATIVE"
    VERIFIED_WITH_BOUNDED_REMAINDER = "VERIFIED_WITH_BOUNDED_REMAINDER"
    INTEGRITY_ONLY = "INTEGRITY_ONLY"
    REPLAY_BOUND = "REPLAY_BOUND"
    PARTIALLY_VERIFIED = "PARTIALLY_VERIFIED"
    FAILED = "FAILED"
    EXPIRED = "EXPIRED"
    REVOKED = "REVOKED"
    TIME_INDETERMINATE = "TIME_INDETERMINATE"
    UNVERIFIABLE_REDACTED = "UNVERIFIABLE_REDACTED"
    UNSUPPORTED_PROFILE = "UNSUPPORTED_PROFILE"


class TimeStatus:
    """Time statuses (spec 45.4)."""

    CURRENT = "CURRENT"
    NOT_YET_VALID = "NOT_YET_VALID"
    STALE = "STALE"
    EXPIRED = "EXPIRED"
    TIME_INDETERMINATE = "TIME_INDETERMINATE"
    CLOCK_POLICY_VIOLATION = "CLOCK_POLICY_VIOLATION"


class Level:
    """Verification levels (spec 25.2)."""

    V0, V1, V2, V3, V4 = "V0", "V1", "V2", "V3", "V4"
    ORDER = (V0, V1, V2, V3, V4)


@dataclass
class VerificationResult:
    """The verifier's answer.  ``ok`` is false whenever anything failed."""

    ok: bool
    checks: List[Tuple[str, bool, str]] = field(default_factory=list)
    violations: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    status: str = Status.FAILED
    report: Dict[str, Any] = field(default_factory=dict)

    def record(self, name: str, passed: bool, detail: str) -> bool:
        self.checks.append((name, bool(passed), detail))
        if not passed:
            self.violations.append(f"{name}: {detail}")
        return bool(passed)

    def note(self, name: str, detail: str) -> None:
        """A check that holds vacuously; recorded so the report stays total."""
        self.checks.append((name, True, detail))

    def warn(self, message: str) -> None:
        self.warnings.append(message)

    def unsupported(self, name: str, detail: str) -> None:
        """A check that could not be attempted.  Never silently a pass."""
        # ``passed`` is intentionally false.  Unsupported is distinct from a
        # disproved claim (and therefore is not added to ``violations``), but
        # it is also distinct from a check that was attempted and held.  A
        # verifier must never acquire a successful status or level by simply
        # omitting the evidence needed to run a required check.
        self.checks.append((name, False, f"UNSUPPORTED: {detail}"))
        self.report.setdefault("unsupported_checks", []).append(f"{name}: {detail}")
        self.warn(f"{name} could not be attempted: {detail}")

    def finish(self) -> "VerificationResult":
        unsupported = list(self.report.get("unsupported_checks") or [])
        self.ok = not self.violations and not unsupported
        # ``verify_bundle`` finishes after each cumulative level so it can
        # distinguish the achieved level.  These lists therefore must be
        # refreshed, not frozen by the first call at V0.
        unsupported_names = {
            item.split(":", 1)[0] for item in unsupported if isinstance(item, str)
        }
        self.report["checks_passed"] = [n for n, p, _ in self.checks if p]
        self.report["checks_failed"] = [
            n for n, p, _ in self.checks if not p and n not in unsupported_names
        ]
        self.report["checks_unsupported"] = [
            n for n, p, _ in self.checks if not p and n in unsupported_names
        ]
        return self

    def to_json(self) -> dict:
        return {
            "ok": self.ok,
            "status": self.status,
            "checks": [{"check": n, "passed": p, "detail": d} for n, p, d in self.checks],
            "violations": list(self.violations),
            "warnings": list(self.warnings),
            "report": self.report,
        }


# ---------------------------------------------------------------------------
# independent copies of the normative tables
# ---------------------------------------------------------------------------
#: 21.4, re-derived from 21.2.  BOUNDED_UNENUMERATED_FAMILY reaches a global
#: claim only when a remainder bound is present and declared to close the
#: decision (21.6); otherwise the family is partial.
_SCOPE_FROM_BASIS = {
    "EXHAUSTIVE_DECLARED_UNIVERSE": "FULL_DECLARED_UNIVERSE",
    "GENERATOR_CLOSED": "GENERATOR_CLOSED_FAMILY",
    "EXPLICIT_IMPORTED_FAMILY": "RELATIVE_EXPLICIT_FAMILY",
    "TRUNCATED_BY_DECLARED_RULE": "PARTIAL_FAMILY",
    "KNOWN_INCOMPLETE": "PARTIAL_FAMILY",
    "UNKNOWN": "PARTIAL_FAMILY",
}
_NO_WINNER_SCOPES = frozenset({"PARTIAL_FAMILY"})  # 21.5

#: Outcomes asserting a certified winner (29.6, 22.3-22.4).
_WINNER_LIKE = frozenset({"CERTIFIED_WINNER", "CERTIFIED_WINNER_SET", "CERTIFIED_POLICY_TIE"})
_STRICT_WINNER = frozenset({"CERTIFIED_WINNER", "CERTIFIED_WINNER_SET"})

#: 22.2 / 23.2: profiles that may authorize a strict claim.
_CERTIFYING_ARITHMETIC = frozenset({"EXACT_RATIONAL", "INTERVAL_ENCLOSED"})
_CERTIFYING_SOLVER = frozenset({"PROOF_CHECKED", "EXACT_RECOMPUTED"})
_REPLAY_ARITHMETIC = _CERTIFYING_ARITHMETIC | frozenset({"FLOAT_REPLAY_BOUND"})
_QUANTITY_REGISTRY_VERSION = "sha256:810b33ce38f3bf69be66fb153601782a4d73b125db1534ef810f82a088102bb1"
_NORMATIVE_RULE_TABLE_VERSION = "sha256:d1b2c0226357d194f7fefbb7f2060ab96d9f7dc9f7cd19e2ac635cef55de81f5"

#: Objective-family vocabulary, 26.3-26.4.
_ADDITIVE = frozenset("weighted_sum linear additive additive_price dot price_vector".split())
_MAX_EVALUABLE = frozenset(
    "max weighted_max bottleneck min_max minmax makespan chebyshev weighted_chebyshev".split()
)
_MONOTONE_NONADDITIVE = _MAX_EVALUABLE | frozenset(
    "monotone monotone_family lexicographic quantile leximin p_norm".split()
)
_NONMONOTONE = frozenset(
    "nonmonotone ratio difference target_distance balance variance spread".split()
)
_ATTAINABILITY = frozenset(
    "attainability exact_point exact_signature signature_attainability "
    "feasibility_of_point equality_target".split()
)
_REALIZATION = frozenset(
    "realization_attribute declared_value schedule topology ownership placement "
    "layout transition_cost embedding artifact".split()
)
_LEDGER = frozenset("finite_ledger case_ledger ledger".split())
_KNOWN = _ADDITIVE | _MONOTONE_NONADDITIVE | _NONMONOTONE | _ATTAINABILITY | _REALIZATION | _LEDGER

#: The information ladder (19.2-19.4): a larger rank strictly determines a
#: smaller one, and never the reverse.  That is what "sufficient" means.
_RANK = {"REALIZATION_REGISTRY_AND_FIBERS": 4, "R": 3, "GAMMA": 2, "K": 1}
_EXACT_MATCH_OBJECTS = frozenset({"ARGMIN_HITTING_SET", "BOUNDED_REGRET_REPRESENTATION"})


def derive_claim_scope(completeness: dict) -> str:
    """Re-derive the claim scope from the completeness basis (21.4, 21.6)."""
    basis = str(completeness.get("basis_type", "UNKNOWN"))
    if basis == "BOUNDED_UNENUMERATED_FAMILY":
        bound = completeness.get("remainder_bound")
        closes = bool(bound) and "CLOSES" in str(bound).upper()
        return "BOUNDED_REMAINDER_GLOBAL" if closes else "PARTIAL_FAMILY"
    return _SCOPE_FROM_BASIS.get(basis, "PARTIAL_FAMILY")


def _lower_weight(value: Any) -> Any:
    """The lower endpoint of a declared weight, whatever shape it arrived in.

    A weight may be a scalar (``"3"``, ``3``), a two-element range
    (``["1", "2"]``), or a mapping (``{"lo": "1", "hi": "2"}``).  An earlier
    revision indexed ``value[0]`` unconditionally, which silently took the
    first *character* of a numeral string and raised ``KeyError`` on a
    mapping.  Sign is decided by the lower endpoint, so that is what this
    returns; anything unrecognised raises and the caller fails closed.
    """
    if isinstance(value, (list, tuple)):
        if not value:
            raise ArithError("a weight range must declare an endpoint")
        return value[0]
    if isinstance(value, dict):
        for key in ("lo", "low", "min", "lower"):
            if key in value:
                return value[key]
        raise ArithError(f"weight mapping declares no lower endpoint: {sorted(value)}")
    return value


def _nonnegative_weights(objective: dict) -> bool:
    weights = objective.get("weights") or {}
    if not weights:
        return True  # an unweighted additive family is the all-ones price
    try:
        return all(rational(_lower_weight(v)) >= ZERO for v in weights.values())
    except (ArithError, TypeError, IndexError, KeyError, ValueError):
        # An unreadable weight is not a nonnegative one (spec 6.6).
        return False


def required_object_for(objective: dict) -> Tuple[str, str]:
    """Re-derive the minimum required retained object (26.4).

    Rows are evaluated strongest-requirement-first, so a query that is both
    realization sensitive and additive still requires the realization
    registry.  Returns ``(required_object, cited_rule)``.
    """
    kind = str(objective.get("type", "unknown")).strip().lower()
    quant = str(objective.get("quantification", "EACH_OBJECTIVE")).upper()
    regret = objective.get("bounded_regret") or {}
    if (kind in _REALIZATION or objective.get("realization_sensitivity")
            or objective.get("required_retained_identities")):
        return "REALIZATION_REGISTRY_AND_FIBERS", "26.4 rows 1-2; 19.6"
    if kind in _ATTAINABILITY or kind in _NONMONOTONE or objective.get("monotone") is False:
        return "R", "26.4 row 3"
    if kind in _ADDITIVE and not _nonnegative_weights(objective):
        return "R", "26.4 row 3 (a negative price is not monotone)"
    if kind not in _KNOWN:
        return "R", "26.4 final row; 26.6 (unknown semantics preserve R)"
    if quant == "ROBUST_AGGREGATE":
        return "GAMMA", "26.3; 26.4 row 6 (a coupled robust aggregate is not an additive price)"
    if kind in _LEDGER and objective.get("cases"):
        return "ARGMIN_HITTING_SET", "26.4 row 7"
    if regret.get("accept_approximation") and regret.get("tolerance") is not None:
        return "BOUNDED_REGRET_REPRESENTATION", "26.4 row 8; 20.5"
    if kind in _MONOTONE_NONADDITIVE:
        return "GAMMA", "26.4 row 4 (monotone non-additive; K is refused)"
    if kind in _ADDITIVE and quant == "EACH_OBJECTIVE":
        return "K", "26.4 row 5; 19.4"
    return "R", "26.4 final row; 26.6"


# ---------------------------------------------------------------------------
# independent objective evaluation (22.2, 26.3)
# ---------------------------------------------------------------------------
class Unevaluable(ValueError):
    """The objective cannot be recomputed from a signature alone."""


def _weight_box(objective: dict, order: Sequence[str]) -> List[Interval]:
    weights = objective.get("weights") or {}
    return [
        interval(weights[name]) if name in weights else (Fraction(1), Fraction(1))
        for name in order
    ]


def evaluate_objective(
    signature: Sequence[Fraction], objective: dict, order: Sequence[str]
) -> Interval:
    """Exact enclosure of the objective family at ``signature`` (22.2, 26.3).

    Only families genuinely determined by a signature are evaluated.
    Anything else raises, and the caller fails closed rather than adopting
    the issuer's number (6.6).
    """
    kind = str(objective.get("type", "unknown")).strip().lower()
    quant = str(objective.get("quantification", "EACH_OBJECTIVE")).upper()
    if len(signature) != len(order):
        raise Unevaluable(f"signature of length {len(signature)} against order {len(order)}")
    box = _weight_box(objective, order)
    if kind in _ADDITIVE:
        if quant == "ROBUST_AGGREGATE":
            # sup_{w in W} w . x: the upper weight on nonnegative coordinates,
            # the lower weight on negative ones.  Exact, not an enclosure.
            total = ZERO
            for (lo, hi), value in zip(box, signature):
                total += (hi * value) if value >= ZERO else (lo * value)
            return (total, total)
        out: Interval = (ZERO, ZERO)
        for weight, value in zip(box, signature):
            out = iadd(out, imul(weight, (value, value)))
        return out
    if kind in _MAX_EVALUABLE:
        terms = [imul(w, (v, v)) for w, v in zip(box, signature)]
        return (max(t[0] for t in terms), max(t[1] for t in terms))
    raise Unevaluable(
        f"objective family {kind!r} is not determined by a signature; the verifier "
        "refuses to adopt the issuer's value for it (spec 6.6)"
    )


def _paired_margin(
    p: Sequence[Fraction], q: Sequence[Fraction], objective: dict, order: Sequence[str]
) -> Interval:
    """Enclosure of ``{w . (q - p) : w in W}`` for an additive family.

    Sharper than differencing two independent enclosures, because the same
    weight vector is used on both sides.  This is the second sound route to
    a strict win; a verifier without it would reject correct certificates.
    """
    out: Interval = (ZERO, ZERO)
    for weight, (pi, qi) in zip(_weight_box(objective, order), zip(p, q)):
        out = iadd(out, imul(weight, (qi - pi, qi - pi)))
    return out


def _paired_route_available(objective: dict, values: Dict[str, Any]) -> bool:
    return (
        str(objective.get("type", "")).strip().lower() in _ADDITIVE
        and str(objective.get("quantification", "EACH_OBJECTIVE")).upper() == "EACH_OBJECTIVE"
        and bool(objective.get("weights"))
        and not any(isinstance(v, dict) and "evidence_interval" in v for v in values.values())
    )


# ---------------------------------------------------------------------------
# time (spec 45)
# ---------------------------------------------------------------------------
def _parse_time(value: Any) -> Optional[_dt.datetime]:
    if not value or not isinstance(value, str):
        return None
    try:
        parsed = _dt.datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    except ValueError:
        return None
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=_dt.timezone.utc)


def _time_judgment(cert: dict, clock: Optional[str], clock_source: str) -> Tuple[str, dict]:
    """Report issuer time, verifier time, and the resulting status (45.3-45.5)."""
    validity = cert.get("validity") or {}
    issued = cert.get("issued_at") or validity.get("issued_at") or cert.get("created_at")
    not_before = cert.get("not_before") or validity.get("not_before")
    expiry = cert.get("expiry") or validity.get("expires_at") or validity.get("expiry")
    judgment = {
        "issuer_asserted_issue_time": issued,
        "issuer_asserted_not_before": not_before,
        "issuer_asserted_expiry": expiry,
        "verifier_evaluation_time": clock,
        "verifier_clock_source": clock_source,
    }
    now, start, end = _parse_time(clock), _parse_time(not_before), _parse_time(expiry)
    if now is None:
        # 45.5: an indeterminate time claim MUST NOT be reported as current.
        status = TimeStatus.TIME_INDETERMINATE
    elif expiry and end is None:
        status = TimeStatus.CLOCK_POLICY_VIOLATION
    elif start is not None and now < start:
        status = TimeStatus.NOT_YET_VALID
    elif end is not None and now > end:
        status = TimeStatus.EXPIRED
    elif end is None:
        status = TimeStatus.TIME_INDETERMINATE
    else:
        status = TimeStatus.CURRENT
    judgment["time_status"] = status
    return status, judgment


# ---------------------------------------------------------------------------
# registry decoding
# ---------------------------------------------------------------------------
def _coordinate_order(registry: dict, cert: dict) -> List[str]:
    coordinates = (registry.get("schema") or {}).get("coordinates") or []
    if not coordinates:
        # A portable verifier projection may carry the canonical registry as
        # a content-addressed object while exposing only ``realizations`` at
        # the top level.  Recover its schema only after independently proving
        # that the object bytes match one of the declared registry roots.
        objects = registry.get("objects") or {}
        for root_key in ("retained_registry_hash", "complete_registry_hash"):
            root = registry.get(root_key)
            candidate = objects.get(root) if isinstance(objects, dict) else None
            if (
                isinstance(root, str)
                and is_hash(root)
                and isinstance(candidate, dict)
                and content_hash(candidate) == root
            ):
                coordinates = (candidate.get("schema") or {}).get("coordinates") or []
                if coordinates:
                    break
    if coordinates:
        return [str(c["identifier"]) for c in coordinates]
    family = (cert.get("scope") or {}).get("objective_family") or {}
    return [str(c) for c in (family.get("coordinate_order") or [])]


def _feasibility(entry: dict, domain: dict) -> Tuple[str, str]:
    """Re-derive feasibility (22.7); never inherited from the certificate."""
    if str(entry.get("legality", "LEGAL")) != "LEGAL":
        return "INFEASIBLE", f"legality={entry.get('legality')}"
    attributes = entry.get("attributes") or {}
    declared = attributes.get("feasible", attributes.get("feasibility"))
    if declared is False or (isinstance(declared, str) and declared.upper() == "INFEASIBLE"):
        return "INFEASIBLE", str(attributes.get("infeasible_reason", "declared infeasible"))
    if isinstance(declared, str) and declared.upper() == "UNKNOWN":
        return "UNKNOWN", "feasibility declared UNKNOWN"
    for key, bounds in (domain or {}).items():
        if key not in attributes or not isinstance(bounds, (list, tuple)) or len(bounds) != 2:
            continue
        try:
            value, lo, hi = rational(attributes[key]), rational(bounds[0]), rational(bounds[1])
        except ArithError:
            continue
        if value < lo or value > hi:
            return "INFEASIBLE", f"attribute {key}={fmt(value)} outside declared domain"
    return "FEASIBLE", ""


# ---------------------------------------------------------------------------
# the verifier
# ---------------------------------------------------------------------------
def verify_certificate(
    cert: dict,
    *,
    registry: Optional[dict] = None,
    clock: Optional[str] = None,
    clock_source: str = "none-supplied",
) -> VerificationResult:
    """Independently verify a decision certificate (spec 25).

    ``registry`` carries the retained signatures, coordinate schema, and any
    referenced objects; a CRG-VIR document supplies its own, which is what
    makes ``verify_vir`` total.  ``clock`` is the *verifier's* evaluation
    time (45.3): the issuer's clock is reported, never trusted, and never
    substituted when no verifier clock was supplied.
    """
    result = VerificationResult(ok=False)
    registry = dict(registry or {})
    if not isinstance(cert, dict):
        result.record("structure", False, "certificate is not a JSON object")
        result.status = Status.FAILED
        return result.finish()

    result.report.update({
        "verifier_identity": VERIFIER_ID, "verifier_version": VERIFIER_VERSION,
        "spec_version": SPEC_VERSION, "bundle_identity": cert.get("certificate_id"),
        "level_attempted": Level.V3,
    })
    outcome = str(cert.get("outcome", ""))
    stated_scope = str(cert.get("claim_scope", ""))
    derivation = cert.get("derivation") or {}
    objective = dict((cert.get("scope") or {}).get("objective_family") or {})
    values = cert.get("objective_values") or {}
    selected = [str(s) for s in (cert.get("selected") or [])]
    ties = [str(s) for s in (cert.get("ties") or [])]

    # -- 1: content hash (V0) -------------------------------------------
    stated = cert.get("certificate_hash") or (cert.get("hashes") or {}).get("certificate_hash")
    if stated is None:
        result.unsupported("content_hash", "no certificate hash is stated")
    else:
        recomputed = hash_without(
            cert, "certificate_hash", "hashes", "signatures", "validity", "verification")
        result.record("content_hash", is_hash(str(stated)) and recomputed == stated,
                      f"stated {stated}, recomputed {recomputed}")

    # -- 1b: semantics-bearing version closure (§15.2) -----------------
    pins = cert.get("semantic_pins")
    pin_errors: List[str] = []
    if not isinstance(pins, dict):
        pin_errors.append("semantic_pins is absent or not an object")
    else:
        schema_versions = pins.get("schema_versions")
        if not isinstance(schema_versions, dict) or schema_versions.get("crg-core") != SPEC_VERSION:
            pin_errors.append(f"schema_versions must pin crg-core={SPEC_VERSION}")
        if pins.get("quantity_registry_version") != _QUANTITY_REGISTRY_VERSION:
            pin_errors.append("quantity_registry_version is absent or unsupported")
        if pins.get("normative_rule_table_version") != _NORMATIVE_RULE_TABLE_VERSION:
            pin_errors.append("normative_rule_table_version is absent or unsupported")
        if pins.get("crg_vir_version") != SPEC_VERSION:
            pin_errors.append(f"crg_vir_version must be {SPEC_VERSION}")
        domain_versions = pins.get("domain_pack_versions")
        if not isinstance(domain_versions, dict) or any(
            not isinstance(k, str) or not k or not isinstance(v, str) or not v
            for k, v in (domain_versions.items() if isinstance(domain_versions, dict) else ())
        ):
            pin_errors.append("domain_pack_versions must be a string-to-string mapping")
        checkers = pins.get("proof_checker_versions")
        if not isinstance(checkers, dict) or checkers.get("crg-verify") != CHECKER_PROFILE_VERSION \
                or checkers.get("crg-verify-js") != CHECKER_PROFILE_VERSION:
            pin_errors.append(
                f"proof_checker_versions must pin both independent "
                f"{CHECKER_PROFILE_VERSION} checker profiles"
            )
    result.record(
        "semantic_version_pins", not pin_errors,
        "; ".join(pin_errors) if pin_errors else
        "schema, quantity registry, normative rules, CRG-VIR, applicable domain packs, "
        "and proof checkers are pinned (§15.2)",
    )

    # -- 2: claim scope re-derived from the completeness basis ------------
    scope = derive_claim_scope(cert.get("completeness") or {})
    result.record(
        "claim_scope_consistent", scope == stated_scope,
        f"basis {(cert.get('completeness') or {}).get('basis_type')!r} yields {scope}; "
        f"certificate states {stated_scope!r} (spec 21.4)")

    # -- 3: the claim is permitted by the claim scope (21.5) --------------
    # The *re-derived* scope gates the claim; the stated one has no standing.
    if scope in _NO_WINNER_SCOPES and outcome in _WINNER_LIKE:
        detail, permitted = (
            f"PARTIAL_FAMILY MUST NOT support a globally phrased winner; this certificate "
            f"asserts {outcome} over an incomplete family (spec 21.5)"), False
    elif scope in _NO_WINNER_SCOPES and selected and outcome != "HEURISTIC_ONLY":
        detail, permitted = (
            f"PARTIAL_FAMILY names selected realizations {selected} under outcome {outcome}; "
            "only a heuristic incumbent or a blocked outcome is permitted"), False
    elif scope == "RELATIVE_EXPLICIT_FAMILY" and bool(cert.get("global_claim")):
        detail, permitted = (
            "RELATIVE_EXPLICIT_FAMILY supports a relative winner only; this certificate is "
            "phrased globally (spec 21.5)"), False
    else:
        detail, permitted = f"{scope} may carry outcome {outcome}", True
    result.record("claim_permitted_by_scope", permitted, detail)

    # -- 4: required object sufficient for the decision class -------------
    declared = str(derivation.get("required_object", ""))
    needed, rule = required_object_for(objective)
    sufficient = (declared == needed
                  if declared in _EXACT_MATCH_OBJECTS or needed in _EXACT_MATCH_OBJECTS
                  else _RANK.get(declared, -1) >= _RANK.get(needed, 99))
    kind = str(objective.get("type", "")).strip().lower()
    result.record(
        "required_object_sufficient", sufficient,
        f"objective {objective.get('type')!r}/"
        f"{objective.get('quantification', 'EACH_OBJECTIVE')} requires {needed} ({rule}); "
        f"derivation declares {declared!r} for class "
        f"{str(derivation.get('decision_class', ''))!r}")
    # 26.3 names one reduction as unsound outright, so it is named here too
    # rather than left implicit in the ranking.
    k_abuse = declared == "K" and (
        kind in _MONOTONE_NONADDITIVE
        or str(objective.get("quantification", "")).upper() == "ROBUST_AGGREGATE")
    result.record(
        "k_not_used_for_nonadditive_objective", not k_abuse,
        f"objective family {kind!r} is monotone but not an additive price, so it is not "
        f"determined by the support values of nonnegative prices and K is insufficient "
        f"(spec 26.3, 26.4 row 4)" if k_abuse
        else f"K claim check: declared object {declared!r} against family {kind!r}")

    # -- 5: recompute the decision from the retained registry -------------
    _verify_decision(result, cert, registry, _coordinate_order(registry, cert),
                     objective, values, outcome, selected, ties)
    # -- 6, 7 -------------------------------------------------------------
    _verify_regret(result, cert, registry)
    _verify_dependencies(result, cert, registry)

    # -- 8: validity window against the verifier's clock ------------------
    time_status, judgment = _time_judgment(cert, clock, clock_source)
    result.report["time_judgment"] = judgment
    if time_status in (TimeStatus.EXPIRED, TimeStatus.NOT_YET_VALID,
                       TimeStatus.CLOCK_POLICY_VIOLATION):
        result.record("validity_window", False,
                      f"time status {time_status}: issuer asserted expiry "
                      f"{judgment['issuer_asserted_expiry']!r}, verifier clock "
                      f"{judgment['verifier_evaluation_time']!r} from {clock_source}")
    elif time_status == TimeStatus.TIME_INDETERMINATE:
        result.note("validity_window", f"TIME_INDETERMINATE (clock source: {clock_source})")
        result.warn("no verifier clock or no declared expiry: the time claim is "
                    "indeterminate and MUST NOT be reported as current (spec 45.5)")
    else:
        result.record("validity_window", True,
                      f"CURRENT at {judgment['verifier_evaluation_time']} "
                      f"(clock source: {clock_source})")

    # -- 9, 10 -------------------------------------------------------------
    _verify_evidence(
        result,
        cert,
        registry,
        registry.get("entries") or registry.get("retained_entries")
        or registry.get("realizations") or [],
        values,
        outcome,
    )
    _verify_arithmetic(result, cert, values, outcome)

    result.finish()
    result.status = _final_status(result, scope, outcome, time_status)
    # ``ok`` is part of the public library contract, not merely an internal
    # count of recorded violations.  A wholly withheld dependency closure is
    # deliberately represented by an unsupported check rather than a false
    # arithmetic assertion, but it still cannot be a successful verification.
    # Keep status and ok fail-closed together (spec 6.6, 25.3-25.4).
    if result.status == Status.UNVERIFIABLE_REDACTED:
        result.ok = False
    result.report.update({
        "final_status": result.status,
        "claim_judgment": {
            "outcome": outcome, "stated_claim_scope": stated_scope,
            "rederived_claim_scope": scope, "selected": selected, "ties": ties,
        },
        "level_achieved": (Level.V2 if result.status == Status.REPLAY_BOUND else Level.V3)
        if result.ok else (
            "NONE" if any(not p for n, p, _ in result.checks if n == "content_hash")
            else Level.V0),
    })
    return result


def _final_status(result: VerificationResult, scope: str, outcome: str, time_status: str) -> str:
    if time_status == TimeStatus.EXPIRED:
        return Status.EXPIRED
    if result.violations:
        return Status.FAILED
    if result.report.get("content_withheld"):
        # 25.3 provides a status for exactly this case; using VERIFIED would
        # let an artifact gain a clean bill of health by carrying less.
        return Status.UNVERIFIABLE_REDACTED
    unsupported = list(result.report.get("unsupported_checks") or [])
    if unsupported:
        # A missing content hash prevents even V0 integrity.  Other
        # unavailable required checks may leave a truthful partial result,
        # but can never produce VERIFIED or a successful ``ok`` flag.
        if any(str(item).startswith("content_hash:") for item in unsupported):
            return Status.FAILED
        return Status.PARTIALLY_VERIFIED
    if time_status == TimeStatus.TIME_INDETERMINATE:
        return Status.TIME_INDETERMINATE
    if result.report.get("replay_bound"):
        return Status.REPLAY_BOUND
    if scope == "RELATIVE_EXPLICIT_FAMILY":
        return Status.VERIFIED_RELATIVE
    if scope == "BOUNDED_REMAINDER_GLOBAL":
        return Status.VERIFIED_WITH_BOUNDED_REMAINDER
    if scope in _NO_WINNER_SCOPES and outcome not in _WINNER_LIKE:
        return Status.PARTIALLY_VERIFIED
    return Status.VERIFIED


# ---------------------------------------------------------------------------
# check 5: the winner really wins (22.3-22.5, 22.7)
# ---------------------------------------------------------------------------
def _verify_decision(
    result: VerificationResult, cert: dict, registry: dict, order: Sequence[str],
    objective: dict, values: Dict[str, Any], outcome: str,
    selected: Sequence[str], ties: Sequence[str],
) -> None:
    entries = (registry.get("entries") or registry.get("retained_entries")
               or registry.get("realizations") or [])
    if not entries:
        result.unsupported("winner_recomputation",
                           "no retained registry was supplied; the decision cannot be re-derived")
        return
    if not order:
        result.record("winner_recomputation", False, "no coordinate schema is available")
        return

    domain = (cert.get("scope") or {}).get("technology_domain") or {}
    recomputed: Dict[str, Interval] = {}
    signatures: Dict[str, List[Fraction]] = {}
    feasible: List[str] = []
    infeasible: Dict[str, str] = {}
    unevaluable: List[str] = []
    for entry in entries:
        rid = str(entry.get("realization_id"))
        try:
            signatures[rid] = [rational(v) for v in entry.get("signature", [])]
        except ArithError as error:
            result.record("winner_recomputation", False, f"{rid}: {error}")
            return
        status, reason = _feasibility(entry, domain)
        (infeasible.__setitem__(rid, reason) if status == "INFEASIBLE"
         else feasible.append(rid) if status == "FEASIBLE" else None)
        try:
            recomputed[rid] = evaluate_objective(signatures[rid], objective, order)
        except (Unevaluable, ArithError):
            unevaluable.append(rid)

    # 5a: the recomputed values must agree with the values the issuer recorded.
    mismatches: List[str] = []
    for rid, iv in recomputed.items():
        stated = values.get(rid)
        if stated is None:
            mismatches.append(f"{rid}: no recorded objective value")
            continue
        try:
            if interval(stated) != iv:
                mismatches.append(f"{rid}: recorded {interval(stated)} vs recomputed "
                                  f"[{fmt(iv[0])}, {fmt(iv[1])}]")
        except ArithError as error:
            mismatches.append(f"{rid}: {error}")
    if unevaluable:
        result.unsupported("objective_values_recomputed",
                           f"objective family {objective.get('type')!r} is not "
                           f"signature-determined for {sorted(unevaluable)}")
    else:
        result.record("objective_values_recomputed", not mismatches,
                      "; ".join(mismatches) if mismatches
                      else f"{len(recomputed)} objective values recomputed exactly and matched")

    # 5b: the feasibility partition must be independently re-derivable (22.7).
    stated_infeasible = set((cert.get("infeasible") or {}).keys())
    result.record("feasibility_partition", stated_infeasible == set(infeasible),
                  f"certificate declares {sorted(stated_infeasible)} infeasible; "
                  f"independently re-derived {sorted(infeasible)} (spec 22.7)")

    if outcome not in _WINNER_LIKE:
        result.note("winner_beats_every_competitor",
                    f"outcome {outcome} asserts no winner; nothing to re-derive")
        return

    winners = list(selected) or list(ties)
    for reason, bad in (
        (f"outcome {outcome} names no realization", not winners),
        (f"declared winners {[w for w in winners if w not in recomputed]} are absent from the "
         "retained registry", any(w not in recomputed for w in winners)),
        (f"declared winners {[w for w in winners if w in infeasible]} are independently "
         "infeasible (spec 22.7)", any(w in infeasible for w in winners)),
    ):
        if bad:
            result.record("winner_beats_every_competitor", False, reason)
            return
    try:
        tau = rational((cert.get("scope") or {}).get("tie_tolerance", 0))
    except ArithError:
        tau = ZERO
    if tau < ZERO:
        result.record("winner_beats_every_competitor", False, "policy tolerance is negative")
        return

    paired = _paired_route_available(objective, values)
    failures: List[str] = []
    routes: List[str] = []
    competitors = [r for r in feasible if r not in winners]
    for q in competitors:
        for w in winners:
            if strictly_below(recomputed[w], recomputed[q], tau):
                routes.append(f"{w} beats {q} by interval (U_p + tau < L_q)")
                break
            if paired:
                margin = _paired_margin(signatures[w], signatures[q], objective, order)
                if margin[0] > tau:
                    routes.append(f"{w} beats {q} by paired margin inf {fmt(margin[0])} > tau")
                    break
        else:
            failures.append(
                f"{q} is not beaten: recomputed [{fmt(recomputed[q][0])}, "
                f"{fmt(recomputed[q][1])}] against winner "
                + ", ".join(f"{w}=[{fmt(recomputed[w][0])}, {fmt(recomputed[w][1])}]"
                            for w in winners) + f" at tau={fmt(tau)}")
    if outcome == "CERTIFIED_WINNER" and len(winners) > 1:
        failures.append(f"CERTIFIED_WINNER names {len(winners)} realizations")
    if outcome == "CERTIFIED_POLICY_TIE":  # 22.4: members mutually indifferent
        failures.extend(
            f"tie members {a} and {b} are not within the declared tolerance {fmt(tau)} (22.4)"
            for a in winners for b in winners
            if a < b and not within_tolerance(recomputed[a], recomputed[b], tau))
    result.record(
        "winner_beats_every_competitor", not failures,
        "; ".join(failures) if failures
        else (f"{len(competitors)} competitors independently beaten: " + "; ".join(routes)
              if routes else "no competitors remain in the retained registry"))


# ---------------------------------------------------------------------------
# check 6: regret witness (27.3-27.4)
# ---------------------------------------------------------------------------
def _phi(point: Sequence[Fraction], anchor: Sequence[Fraction], eps: Fraction) -> Fraction:
    """Phi(x) = ||(x - a)^+||_inf + eps * sum(x), the 27.3 construction."""
    return positive_part_sup(point, anchor) + eps * sum(point, ZERO)


def _verify_regret(result: VerificationResult, cert: dict, registry: dict) -> None:
    witness = cert.get("regret_witness")
    if not witness:
        result.note("regret_witness", "no regret witness is present")
        return
    full_raw, retained_raw = registry.get("full_generators"), registry.get("retained_generators")
    if full_raw is None or retained_raw is None:
        result.record("regret_witness", False,
                      "a regret witness is asserted but the full and retained generator sets "
                      "were not supplied, so its infima cannot be recomputed (27.4, 6.6)")
        return
    try:
        full = [[rational(v) for v in point] for point in full_raw]
        retained = [[rational(v) for v in point] for point in retained_raw]
        anchor = [rational(v) for v in witness.get("lost_point", [])]
        eps = rational(witness.get("epsilon", 0))
        stated_gap = rational(witness.get("gap", 0))
        stated_full = rational(witness.get("full_infimum", 0))
        stated_retained = rational(witness.get("retained_infimum", 0))
    except (ArithError, TypeError) as error:
        result.record("regret_witness", False, f"witness is not exactly decodable: {error}")
        return
    if not retained:
        result.record("regret_witness", False, "the retained family is empty")
        return
    if eps <= ZERO:
        result.record("regret_witness", False, f"epsilon {fmt(eps)} is not positive (27.3)")
        return

    failures: List[str] = []
    if not any(point == anchor for point in full):  # 27.4.1
        failures.append("the lost point is not a member of the full basis (27.4.1)")
    separation = minimum(positive_part_sup(x, anchor) for x in retained)  # 27.4.2
    if separation is None or separation <= ZERO:
        failures.append("the lost point still lies in the retained upper region: some retained "
                        f"point weakly dominates it (separation {fmt(separation or ZERO)})")
    if str(witness.get("objective_family", "")) != "CONTINUOUS_STRICTLY_INCREASING_COERCIVE":
        failures.append(f"objective family {witness.get('objective_family')!r} is not the named "
                        "continuous, coordinatewise strictly increasing, coercive family (27.4.3)")
    # 27.4.4-5: recompute BOTH infima exactly, then check strict positivity.
    inf_full = minimum(_phi(x, anchor, eps) for x in full)
    inf_retained = minimum(_phi(x, anchor, eps) for x in retained)
    if inf_full is None or inf_retained is None:
        failures.append("an infimum is undefined over an empty family")
    else:
        gap = inf_retained - inf_full
        if gap <= ZERO:
            failures.append(f"recomputed regret gap {fmt(gap)} is not positive (27.3)")
        if gap != stated_gap:
            failures.append(f"stated gap {fmt(stated_gap)} does not equal the recomputed "
                            f"gap {fmt(gap)}")
        if inf_full != stated_full:
            failures.append(f"stated full-family infimum {fmt(stated_full)} vs recomputed "
                            f"{fmt(inf_full)}")
        if inf_retained != stated_retained:
            failures.append(f"stated retained infimum {fmt(stated_retained)} vs recomputed "
                            f"{fmt(inf_retained)}")
    kind = ("GLOBAL" if str((cert.get("completeness") or {}).get("basis_type", "")) in
            ("EXHAUSTIVE_DECLARED_UNIVERSE", "GENERATOR_CLOSED") else "RELATIVE")
    result.report["regret_witness_scope"] = kind  # 27.4.7
    result.record("regret_witness", not failures, "; ".join(failures) if failures
                  else f"both infima recomputed exactly; gap {fmt(stated_gap)} > 0; "
                       f"witness is {kind}")


# ---------------------------------------------------------------------------
# check 7: referenced dependencies (18.2, 14.4)
# ---------------------------------------------------------------------------
def _verify_dependencies(result: VerificationResult, cert: dict, registry: dict) -> None:
    """A certificate references typed object identities and content hashes.

    Identities are checked for presence in the retained registry; content
    hashes are recomputed from the carried object, because a hash the
    artifact merely repeats to itself is not evidence of anything.
    """
    declared = list(cert.get("dependencies") or []) + list(cert.get("evidence_roots") or [])
    declared += [cert[k] for k in ("complete_registry_hash", "retained_registry_hash")
                 if cert.get(k)]
    if not declared:
        result.note("dependency_hashes", "no dependencies are referenced")
        return
    objects = registry.get("objects") or {}
    # The complete/retained registry roots name the registry document itself,
    # not an entry in its optional ``objects`` side table.  A direct
    # certificate verification therefore has the referenced bytes in hand
    # whenever the supplied registry hashes to that root.  Treating that case
    # as withheld would turn a complete self-contained verification into the
    # redaction status intended for genuinely absent dependency content.
    carried_roots = {content_hash(registry)} if registry else set()
    known = {str(e.get("realization_id"))
             for e in (registry.get("entries") or registry.get("retained_entries")
                       or registry.get("realizations") or [])}
    known |= set((cert.get("objective_values") or {}).keys())

    missing: List[str] = []
    mismatched: List[str] = []
    unresolved: List[str] = []
    hashes = ids = 0
    for reference in declared:
        if isinstance(reference, dict):
            ref_hash, ref_id = reference.get("hash"), reference.get("id")
        else:
            tagged = is_hash(str(reference))
            ref_hash, ref_id = (reference, None) if tagged else (None, reference)
        if ref_hash is not None:
            if not is_hash(str(ref_hash)):
                missing.append(f"{ref_id or ref_hash}: not a tagged content hash (14.4)")
            elif ref_hash in carried_roots:
                hashes += 1
            elif ref_hash not in objects:
                unresolved.append(str(ref_hash))
            else:
                hashes += 1
                recomputed = content_hash(objects[ref_hash])
                if recomputed != ref_hash:
                    mismatched.append(f"{ref_hash} recomputes to {recomputed}")
        elif ref_id is not None:
            ids += 1
            if known and str(ref_id) not in known:
                missing.append(f"object {ref_id!r} is absent from the retained registry")
    if unresolved and not objects:
        # Spec 17.3, 25.3, 49.2: content withheld from the artifact means the
        # dependency chain could not be walked.  That is NOT a pass -- it
        # downgrades the final status to UNVERIFIABLE_REDACTED, because a
        # verifier that reports VERIFIED here would be certifying the absence
        # of evidence rather than the presence of it.
        result.unsupported("dependency_hashes",
                           f"{len(unresolved)} referenced objects are not carried in this "
                           "artifact, so their content could not be recomputed")
        result.report["missing_objects"] = sorted(unresolved + missing)
        result.report["content_withheld"] = True
        return
    missing.extend(unresolved)
    result.report["missing_objects"] = sorted(missing)
    result.record("dependency_hashes", not missing and not mismatched,
                  "; ".join(mismatched + [f"missing {m}" for m in missing])
                  if (missing or mismatched)
                  else f"{hashes} content hashes recomputed and matched; {ids} object "
                       f"identities resolved in the retained registry")


# ---------------------------------------------------------------------------
# checks 9 and 10 (5.3, 22.6, 23.4)
# ---------------------------------------------------------------------------
def _verify_evidence(
    result: VerificationResult, cert: dict, registry: dict,
    entries: Sequence[dict], values: Dict[str, Any], outcome: str,
) -> None:
    heuristic = [f"realization {e.get('realization_id')}" for e in entries
                 if str(e.get("evidence_class", "")).upper() == "HEURISTIC"]
    if str(cert.get("evidence_class", "")).upper() == "HEURISTIC":
        heuristic.append("certificate envelope")
    if str((cert.get("regret_witness") or {}).get("evidence_class", "")).upper() == "HEURISTIC":
        heuristic.append("regret witness")
    heuristic += [f"objective value {name}" for name, value in (values or {}).items()
                  if isinstance(value, dict)
                  and str(value.get("solver_trust_profile", "")).upper() == "HEURISTIC"]
    heuristic += [str(name) for name in registry.get("heuristic_inputs") or []]

    certified = outcome in _WINNER_LIKE or outcome == "CERTIFIED_RETENTION"
    result.record(
        "heuristic_never_authorizes", not (certified and heuristic),
        f"outcome {outcome} is a certified outcome but rests on HEURISTIC-classed input: "
        f"{sorted(set(heuristic))}; a heuristic may propose or rank but MUST NOT authorize a "
        "certified result (spec 5.3, 23.6)" if (certified and heuristic)
        else "no HEURISTIC-classed input authorizes this outcome" if not heuristic
        else f"HEURISTIC inputs present but outcome {outcome} is not a certified claim")


def _replay_binding_errors(binding: Any) -> List[str]:
    if not isinstance(binding, dict):
        return ["certificate has no replay_binding object"]
    errors: List[str] = []
    for key in ("solver_identity", "solver_version", "platform_profile"):
        if not isinstance(binding.get(key), str) or not binding.get(key).strip():
            errors.append(f"{key} must be a non-empty string")
    if not isinstance(binding.get("parameters"), dict):
        errors.append("parameters must be an object")
    seed = binding.get("seed")
    if isinstance(seed, bool) or not isinstance(seed, (str, int)):
        errors.append("seed must be a string or integer")
    threads = binding.get("thread_count")
    if isinstance(threads, bool) or not isinstance(threads, int) or threads < 1:
        errors.append("thread_count must be a positive integer")
    tolerances = binding.get("numeric_tolerances")
    if not isinstance(tolerances, dict) or not tolerances:
        errors.append("numeric_tolerances must be a non-empty object")
    if binding.get("replay_status") != "REPLAYED_MATCHED":
        errors.append("replay_status must be REPLAYED_MATCHED")
    if binding.get("mathematical_optimality_independently_proved") is not False:
        errors.append("mathematical_optimality_independently_proved must be false")
    return errors


def _verify_arithmetic(
    result: VerificationResult, cert: dict, values: Dict[str, Any], outcome: str,
) -> None:
    if outcome not in _STRICT_WINNER:
        result.note("certifying_arithmetic_profile",
                    f"outcome {outcome} is not a strict-winner claim")
        return
    if not values:
        result.record("certifying_arithmetic_profile", False,
                      "a strict-winner claim carries no decision-value records (22.2)")
        return
    bad: List[str] = []
    replay_values: List[str] = []
    for name, value in values.items():
        if not isinstance(value, dict):
            bad.append(f"{name}: not a decision-value record")
            continue
        profile = str(value.get("arithmetic_profile", "UNDECLARED"))
        solver = str(value.get("solver_trust_profile", "UNDECLARED"))
        if solver == "DETERMINISTIC_REPLAY":
            replay_values.append(str(name))
            if profile not in _REPLAY_ARITHMETIC:
                bad.append(f"{name}: replay arithmetic profile {profile}")
        elif solver not in _CERTIFYING_SOLVER:
            bad.append(f"{name}: solver trust profile {solver}; 23.4 requires "
                       "PROOF_CHECKED or EXACT_RECOMPUTED")
        elif profile not in _CERTIFYING_ARITHMETIC:
            bad.append(f"{name}: arithmetic profile {profile}")
    binding = cert.get("replay_binding")
    replay_errors = _replay_binding_errors(binding) if replay_values else (
        ["replay_binding is present but no objective value declares DETERMINISTIC_REPLAY"]
        if binding is not None else []
    )
    result.record(
        "replay_binding", not replay_errors,
        "; ".join(replay_errors) if replay_errors else (
            f"§23.5 replay disclosures complete for {sorted(replay_values)}; replay matched "
            "and mathematical optimality is explicitly unproved"
            if replay_values else "no replay-bound objective value is asserted"
        ),
    )
    if replay_values and not replay_errors:
        result.report["replay_bound"] = True
    result.record("certifying_arithmetic_profile", not bad, "; ".join(bad) if bad
                  else ("decision values satisfy the weaker, prominently disclosed §23.5 "
                        "replay-bound operational profile" if replay_values
                        else "every decision value has certifying arithmetic and solver trust "
                             "profiles (22.6, 23.4)"))

# v1.3 composite closure: this product path is phase-bound to ETQ integration.
