"""Independent verification for CRG v1.3 ETQ lifecycle records.

The verifier consumes decoded portable JSON and independently reconstructs
the guided ETQ loop, result ingestion, dependency closure, replacement, and
qualification disposition.  It imports no producer package.
"""
from __future__ import annotations

from typing import Any, Dict, Iterable, List, Mapping, Sequence, Set, Tuple

from .arith import ArithError
from .canonical import CanonicalError, content_hash, is_hash
from .certificate import Status, VerificationResult

__all__ = [
    "verify_etq_decision_loop",
    "verify_result_ingestion_record",
    "verify_selective_revalidation_record",
    "verify_replacement_record",
    "verify_qualification_disposition",
]

SCHEMA_VERSION = "1.0.0"
ETQ_PROFILE = "crg.etq-decision-loop"

_EVIDENCE_CLASSES = frozenset(
    {"EXACT", "CONSTRUCTIVE", "BOUNDED", "MEASURED", "MODELED", "IMPORTED", "DECLARED", "HEURISTIC"}
)
_AUTHORIZING_EVIDENCE = _EVIDENCE_CLASSES - {"HEURISTIC"}
_EVIDENCE_STATUS = {"DRAFT": 0, "PROVISIONAL": 1, "QUALIFIED": 2, "CERTIFIED": 3}
_STOPPING = frozenset(
    {
        "UNIQUE_GUARANTEED_WINNER", "CAPABILITY_ESTABLISHED", "CAPABILITY_RULED_OUT",
        "REGRET_BELOW_THRESHOLD", "UNCERTAINTY_BELOW_THRESHOLD", "BURDEN_LIMIT_REACHED",
        "NO_INFORMATIVE_EXPERIMENT_REMAINS", "MANUAL_ADJUDICATION_REQUIRED",
    }
)
_RESOLVING_STOPS = frozenset(
    {
        "UNIQUE_GUARANTEED_WINNER", "CAPABILITY_ESTABLISHED", "CAPABILITY_RULED_OUT",
        "REGRET_BELOW_THRESHOLD", "UNCERTAINTY_BELOW_THRESHOLD",
    }
)

_LOOP_STEPS = (
    "EVIDENCE_AUTHORED",
    "APPLICABILITY_EVALUATED",
    "UNCERTAINTY_PRESERVED",
    "CONFLICT_AND_VALIDITY_PRESERVED",
    "TECHNOLOGY_CONTRACT_ASSEMBLED",
    "DECISION_CONSEQUENCES_PROPAGATED",
    "DECISION_CHANGING_UNKNOWN_IDENTIFIED",
    "QUALIFICATION_TARGET_INVERTED",
    "EXPERIMENTS_RANKED",
    "REQUEST_AND_STOPPING_RULE_ISSUED",
    "RESULT_INGESTED_AS_EVIDENCE",
    "SELECTIVE_REVALIDATION_AND_REPLACEMENT",
)
_LOOP_OUTPUTS = {
    _LOOP_STEPS[0]: frozenset({"EvidenceRecord"}),
    _LOOP_STEPS[1]: frozenset({"ApplicabilityAssessment"}),
    _LOOP_STEPS[2]: frozenset({"UncertaintyComponentRecord"}),
    _LOOP_STEPS[3]: frozenset({"EvidenceDisposition"}),
    _LOOP_STEPS[4]: frozenset({"TechnologyContract"}),
    _LOOP_STEPS[5]: frozenset({"DecisionConsequence"}),
    _LOOP_STEPS[6]: frozenset({"DecisionChangingUnknown"}),
    _LOOP_STEPS[7]: frozenset({"QualificationTarget"}),
    _LOOP_STEPS[8]: frozenset({"ExperimentRanking"}),
    _LOOP_STEPS[9]: frozenset({"EvaluatorRequest", "ExperimentRequest"}),
    _LOOP_STEPS[10]: frozenset({"EvidenceRecord"}),
    _LOOP_STEPS[11]: frozenset({"SelectiveRevalidationRecord", "ReplacementRecord"}),
}

_ACTION_SEVERITY = {
    "NO_OPERATION": 0,
    "REVALIDATE_ONLY": 1,
    "RECOMPUTE_VALUE": 2,
    "REPRICE": 3,
    "RE_EMBED": 4,
    "RE_EVALUATE": 5,
    "REOPEN": 6,
    "BLOCK": 7,
}
_EDGE = {
    "DERIVES_VALUE_FROM": ("RECOMPUTE_VALUE", True),
    "DEPENDS_ON_VALIDITY_OF": ("REVALIDATE_ONLY", True),
    "DEPENDS_ON_MEMBERSHIP_OF": ("REOPEN", True),
    "DEPENDS_ON_SCOPE_OF": ("REOPEN", True),
    "DEPENDS_ON_PRICE_OF": ("REPRICE", True),
    "DEPENDS_ON_EMBEDDING_OF": ("RE_EMBED", True),
    "DEPENDS_ON_CAPABILITY_OF": ("REOPEN", True),
    "DEPENDS_ON_RULE_VERSION": ("REVALIDATE_ONLY", True),
    "DEPENDS_ON_GENERATOR_VERSION": ("REOPEN", True),
    "DEPENDS_ON_TOOL_IDENTITY": ("RE_EVALUATE", True),
    "DEPENDS_ON_SIGNATURE": ("BLOCK", True),
    "DEPENDS_ON_CONTEXT_FINGERPRINT": ("REVALIDATE_ONLY", True),
    "DEPENDS_ON_CLOCK": ("BLOCK", True),
    "DEPENDS_ON_ACCESS": ("BLOCK", True),
    "DERIVED_FROM_VERSION": ("NO_OPERATION", False),
    "PROVES": ("BLOCK", True),
    "WITNESSES": ("RECOMPUTE_VALUE", True),
}
_VALIDITY_RULE = {
    "NO_OPERATION": "PRESERVE_TARGET",
    "REVALIDATE_ONLY": "REVALIDATE_TARGET",
    "BLOCK": "BLOCK_TARGET",
}

class _DecodeError(ValueError):
    pass


class _UnsupportedProfileError(_DecodeError):
    pass


def _object(value: Any, where: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise _DecodeError(f"{where} must be an object")
    return value


def _array(value: Any, where: str) -> Sequence[Any]:
    if not isinstance(value, (list, tuple)):
        raise _DecodeError(f"{where} must be an array")
    return value


def _string(value: Any, where: str, *, empty: bool = False) -> str:
    if not isinstance(value, str) or (not empty and not value):
        raise _DecodeError(f"{where} must be a {'string' if empty else 'non-empty string'}")
    return value


def _boolean(value: Any, where: str) -> bool:
    if not isinstance(value, bool):
        raise _DecodeError(f"{where} must be a boolean")
    return value


def _integer(value: Any, where: str, *, minimum: Optional[int] = None) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise _DecodeError(f"{where} must be an integer")
    if minimum is not None and value < minimum:
        raise _DecodeError(f"{where} must be at least {minimum}")
    return value


def _keys(value: Mapping[str, Any], required: Iterable[str], optional: Iterable[str], where: str) -> None:
    required_set, allowed = set(required), set(required) | set(optional)
    missing, unknown = required_set - set(value), set(value) - allowed
    if missing:
        raise _DecodeError(f"{where} is missing fields {sorted(missing)}")
    if unknown:
        raise _DecodeError(f"{where} has unsupported fields {sorted(unknown)}")


def _hash(value: Any, where: str) -> str:
    if not is_hash(value):
        raise _DecodeError(f"{where} must be an algorithm-tagged SHA-256 hash")
    return value


def _strings(value: Any, where: str, *, sorted_unique: bool = False, nonempty: bool = False) -> Tuple[str, ...]:
    result = tuple(_string(item, f"{where}[]") for item in _array(value, where))
    if nonempty and not result:
        raise _DecodeError(f"{where} must not be empty")
    if len(set(result)) != len(result):
        raise _DecodeError(f"{where} contains duplicates")
    if sorted_unique and result != tuple(sorted(result)):
        raise _DecodeError(f"{where} is not canonically sorted")
    return result


def _hashes(value: Any, where: str, *, sorted_unique: bool = False) -> Tuple[str, ...]:
    result = tuple(_hash(item, f"{where}[]") for item in _array(value, where))
    if len(set(result)) != len(result):
        raise _DecodeError(f"{where} contains duplicate hashes")
    if sorted_unique and result != tuple(sorted(result)):
        raise _DecodeError(f"{where} is not canonically sorted")
    return result


def _preflight(value: Any, where: str) -> str:
    try:
        return content_hash(value)
    except (CanonicalError, TypeError, ValueError) as error:
        raise _DecodeError(f"{where} is not canonically hashable: {error}") from error



def _profile(record: Mapping[str, Any], record_type: str, profile: str) -> None:
    if record.get("schema_version") != SCHEMA_VERSION:
        raise _UnsupportedProfileError(
            f"unsupported {record_type} schema version {record.get('schema_version')!r}"
        )
    if record.get("profile") != profile:
        raise _UnsupportedProfileError(
            f"unregistered {record_type} profile {record.get('profile')!r}"
        )
    if record.get("record_type") != record_type:
        raise _DecodeError(
            f"expected record_type {record_type!r}, found {record.get('record_type')!r}"
        )


def _run(
    record: Mapping[str, Any],
    record_type: str,
    profile: str,
    checker: Any,
) -> VerificationResult:
    result = VerificationResult(ok=False, status=Status.FAILED)
    if not isinstance(record, Mapping):
        result.record("lifecycle_wire", False, f"{record_type} must be a JSON object")
        return result.finish()
    try:
        _profile(record, record_type, profile)
        root = _preflight(record, record_type)
        checks, report = checker()
    except _UnsupportedProfileError as error:
        result.status = Status.UNSUPPORTED_PROFILE
        result.record("lifecycle_profile", False, str(error))
        return result.finish()
    except (_DecodeError, ArithError, CanonicalError, KeyError, TypeError, ValueError, ZeroDivisionError) as error:
        result.record("lifecycle_decode", False, str(error))
        return result.finish()
    result.record("lifecycle_profile", True, f"{profile} schema {SCHEMA_VERSION}")
    for name, passed, detail in checks:
        result.record(name, passed, detail)
    result.report.update({"record_type": record_type, "artifact_root": root, **report})
    if not result.violations:
        result.status = Status.VERIFIED
    return result.finish()



# ---------------------------------------------------------------------------
# Workstream D: guided ETQ loop, ingestion, revalidation, and disposition
# ---------------------------------------------------------------------------
def verify_etq_decision_loop(record: Mapping[str, Any]) -> VerificationResult:
    """Verify the exact twelve-step order and immutable artifact chain."""

    def check() -> Tuple[List[Tuple[str, bool, str]], Dict[str, Any]]:
        _keys(
            record,
            ("record_type", "profile", "schema_version", "loop_id", "target_decision_id",
             "predicate_id", "target_context_hash", "declared_stopping_conditions", "steps",
             "complete", "refused", "next_step"),
            (),
            "ETQ decision loop",
        )
        for field in ("loop_id", "target_decision_id", "predicate_id"):
            _string(record.get(field), f"ETQ decision loop.{field}")
        _hash(record.get("target_context_hash"), "ETQ decision loop.target_context_hash")
        stopping = _strings(record.get("declared_stopping_conditions"), "declared stopping conditions", nonempty=True)
        unknown_stops = sorted(set(stopping) - _STOPPING)
        if unknown_stops:
            raise _DecodeError(f"unknown stopping conditions {unknown_stops}")

        steps = _array(record.get("steps"), "ETQ decision loop.steps")
        if len(steps) > len(_LOOP_STEPS):
            raise _DecodeError("ETQ decision loop contains more than twelve steps")
        seen_ids: Set[str] = set()
        seen_hashes: Set[str] = set()
        prior_outputs: Set[str] = set()
        refused_at: Optional[int] = None
        for offset, raw in enumerate(steps):
            index = offset + 1
            step = _object(raw, f"ETQ decision loop.steps[{offset}]")
            _keys(
                step,
                ("step_index", "step", "input_hashes", "outputs", "authority", "verification_basis"),
                ("refusal",),
                f"ETQ decision loop.steps[{offset}]",
            )
            if _integer(step.get("step_index"), f"step {index}.step_index") != index:
                raise _DecodeError(f"step {index} carries a forged step_index")
            name = _string(step.get("step"), f"step {index}.step")
            if name != _LOOP_STEPS[offset]:
                raise _DecodeError(f"ETQ loop skipped or reordered step {index}: found {name!r}")
            inputs = _hashes(step.get("input_hashes"), f"step {index}.input_hashes")
            authority = _string(step.get("authority"), f"step {index}.authority")
            basis = _strings(step.get("verification_basis"), f"step {index}.verification_basis", nonempty=True)
            del authority, basis
            refusal_raw = step.get("refusal")
            if refusal_raw is not None:
                refusal = _object(refusal_raw, f"step {index}.refusal")
                _keys(refusal, ("code", "detail"), (), f"step {index}.refusal")
                _string(refusal.get("code"), f"step {index}.refusal.code")
                _string(refusal.get("detail"), f"step {index}.refusal.detail")
                refused_at = index
            outputs = _array(step.get("outputs"), f"step {index}.outputs")
            if refusal_raw is not None and outputs:
                raise _DecodeError(f"refused step {index} also claims outputs")
            if refusal_raw is None and not outputs:
                raise _DecodeError(f"step {index} neither produced an artifact nor refused")
            if index == 1 and inputs:
                raise _DecodeError("the evidence-authoring step consumes undeclared prior output")
            if index > 1 and refusal_raw is None:
                if not inputs or not set(inputs).issubset(seen_hashes):
                    raise _DecodeError(f"step {index} consumes an unknown prior artifact")
                if not prior_outputs.intersection(inputs):
                    raise _DecodeError(f"step {index} does not consume the immediately preceding step")

            current_outputs: Set[str] = set()
            types: Set[str] = set()
            for item_index, raw_output in enumerate(outputs):
                output = _object(raw_output, f"step {index}.outputs[{item_index}]")
                _keys(
                    output,
                    ("artifact_id", "artifact_type", "content_hash", "parent_hashes", "status", "evidence_class"),
                    (),
                    f"step {index}.outputs[{item_index}]",
                )
                artifact_id = _string(output.get("artifact_id"), f"step {index} artifact_id")
                artifact_type = _string(output.get("artifact_type"), f"step {index} artifact_type")
                artifact_hash = _hash(output.get("content_hash"), f"step {index} content_hash")
                parents = _hashes(output.get("parent_hashes"), f"step {index} parent_hashes")
                _string(output.get("status"), f"step {index} status")
                evidence_class = _string(output.get("evidence_class"), f"step {index} evidence_class")
                if evidence_class not in _EVIDENCE_CLASSES:
                    raise _DecodeError(f"step {index} has unknown evidence class {evidence_class!r}")
                if artifact_type not in _LOOP_OUTPUTS[name]:
                    raise _DecodeError(f"step {index} produced unregistered type {artifact_type!r}")
                if artifact_hash in parents:
                    raise _DecodeError(f"step {index} artifact is its own parent")
                if set(parents) - seen_hashes:
                    raise _DecodeError(f"step {index} artifact cites an unknown parent")
                if artifact_id in seen_ids or artifact_hash in seen_hashes or artifact_hash in current_outputs:
                    raise _DecodeError(f"step {index} reuses an earlier artifact identity or content")
                seen_ids.add(artifact_id)
                seen_hashes.add(artifact_hash)
                current_outputs.add(artifact_hash)
                types.add(artifact_type)
            if index == 12 and refusal_raw is None and "SelectiveRevalidationRecord" not in types:
                raise _DecodeError("the final step lacks a SelectiveRevalidationRecord")
            prior_outputs = current_outputs
            if refused_at is not None and index != len(steps):
                raise _DecodeError("the ETQ loop continues after a fail-closed refusal")

        complete = len(steps) == len(_LOOP_STEPS) and refused_at is None
        refused = bool(steps and refused_at == len(steps))
        next_step = None if complete or refused else _LOOP_STEPS[len(steps)]
        derived = (
            record.get("complete") is complete
            and record.get("refused") is refused
            and record.get("next_step") == next_step
        )
        return [
            ("etq_step_chain", True, f"{len(steps)} ordered lifecycle steps independently checked"),
            ("etq_derived_state", derived, "complete, refused, and next_step rederived from the immutable prefix"),
        ], {"step_count": len(steps), "complete": complete, "refused": refused}

    return _run(record, "ETQDecisionLoop", ETQ_PROFILE, check)


def verify_result_ingestion_record(
    record: Mapping[str, Any],
    result_record: Mapping[str, Any],
    new_evidence: Mapping[str, Any],
    prior_evidence: Sequence[Mapping[str, Any]] = (),
) -> VerificationResult:
    """Rebuild result, evidence, provenance, and preserved-history bindings."""

    def check() -> Tuple[List[Tuple[str, bool, str]], Dict[str, Any]]:
        _keys(
            record,
            ("record_type", "profile", "schema_version", "ingestion_id", "plan_id", "experiment_id",
             "result_hash", "new_evidence_id", "new_evidence_hash", "evidence_class",
             "evidence_status", "prior_evidence_ids", "prior_evidence_hashes", "preserved_prior_records"),
            (),
            "result ingestion",
        )
        for field in ("ingestion_id", "plan_id", "experiment_id", "new_evidence_id"):
            _string(record.get(field), f"result ingestion.{field}")
        result_doc = _object(result_record, "returned result")
        evidence_doc = _object(new_evidence, "new evidence")
        result_root = _preflight(result_doc, "returned result")
        evidence_root = _preflight(evidence_doc, "new evidence")
        if result_doc.get("status") != "COMPLETED" or result_doc.get("observed") is None:
            raise _DecodeError("only a COMPLETED result with an observation may become evidence")
        if result_doc.get("context") is None:
            raise _DecodeError("returned result has no source context")
        if record.get("experiment_id") != result_doc.get("experiment_id"):
            raise _DecodeError("ingestion experiment_id differs from the returned result")
        if evidence_doc.get("record_type") != "etq.evidence_record":
            raise _DecodeError("new evidence has an unsupported record_type")
        method = _object(evidence_doc.get("M_method"), "new evidence.M_method")
        provenance = _object(evidence_doc.get("P_provenance"), "new evidence.P_provenance")
        chain = _hashes(provenance.get("chain"), "new evidence provenance chain")
        evidence_class = _string(method.get("evidence_class"), "new evidence evidence_class")
        evidence_status = _string(evidence_doc.get("evidence_status"), "new evidence evidence_status")
        if evidence_class not in _EVIDENCE_CLASSES or evidence_status not in _EVIDENCE_STATUS:
            raise _DecodeError("new evidence has an unknown class or status")
        if result_root not in chain:
            raise _DecodeError("new evidence provenance does not commit to the exact returned result")
        prior_docs = tuple(_object(item, "prior evidence") for item in prior_evidence)
        prior_ids = tuple(_string(item.get("evidence_id"), "prior evidence.evidence_id") for item in prior_docs)
        prior_roots = tuple(_preflight(item, "prior evidence") for item in prior_docs)
        if len(set(prior_ids)) != len(prior_ids) or len(set(prior_roots)) != len(prior_roots):
            raise _DecodeError("prior evidence lineage repeats a record")
        new_id = _string(evidence_doc.get("evidence_id"), "new evidence.evidence_id")
        if new_id in prior_ids or evidence_root in prior_roots:
            raise _DecodeError("result ingestion reuses prior evidence identity or bytes")
        bindings = (
            record.get("result_hash") == result_root
            and record.get("new_evidence_id") == new_id
            and record.get("new_evidence_hash") == evidence_root
            and record.get("evidence_class") == evidence_class
            and record.get("evidence_status") == evidence_status
            and tuple(record.get("prior_evidence_ids", ())) == prior_ids
            and tuple(record.get("prior_evidence_hashes", ())) == prior_roots
            and record.get("preserved_prior_records") is True
        )
        return [
            ("result_evidence_binding", bindings, "result, provenance, evidence maturity, and exact bytes independently bound"),
            ("prior_evidence_preserved", record.get("preserved_prior_records") is True, f"{len(prior_docs)} prior immutable records preserved"),
        ], {"result_root": result_root, "new_evidence_root": evidence_root, "prior_count": len(prior_docs)}

    return _run(record, "ResultIngestionRecord", ETQ_PROFILE, check)


def _dependency_edges(raw_edges: Sequence[Mapping[str, Any]]) -> List[dict]:
    result: List[dict] = []
    identifiers: Set[str] = set()
    signatures: Set[Tuple[Any, ...]] = set()
    for index, raw in enumerate(_array(raw_edges, "dependency edges")):
        edge = _object(raw, f"dependency edges[{index}]")
        _keys(
            edge,
            ("edge_id", "source", "target", "edge_type", "minimum_action", "transitive",
             "validity_propagation_rule", "edge_version", "source_property", "scope", "invalidation_predicate"),
            (),
            f"dependency edges[{index}]",
        )
        edge_id = _string(edge.get("edge_id"), f"dependency edges[{index}].edge_id")
        if edge_id != edge_id.strip():
            raise _DecodeError(f"dependency edge id {edge_id!r} is not normalized")
        if edge_id in identifiers:
            raise _DecodeError(f"duplicate dependency edge id {edge_id!r}")
        identifiers.add(edge_id)
        edge_type = _string(edge.get("edge_type"), f"dependency edges[{index}].edge_type")
        if edge_type not in _EDGE:
            raise _DecodeError(f"unknown dependency edge type {edge_type!r}")
        action, transitive = _EDGE[edge_type]
        if edge.get("minimum_action") != action or edge.get("transitive") is not transitive:
            raise _DecodeError(f"edge {edge_id!r} forges registered typed semantics")
        expected_rule = _VALIDITY_RULE.get(action, "MARK_TARGET_STALE")
        if edge.get("validity_propagation_rule") != expected_rule or edge.get("edge_version") != "1":
            raise _DecodeError(f"edge {edge_id!r} has an unsupported validity rule or version")
        source = _string(edge.get("source"), f"edge {edge_id}.source")
        target = _string(edge.get("target"), f"edge {edge_id}.target")
        if source != source.strip() or target != target.strip():
            raise _DecodeError(f"edge {edge_id!r} has a non-normalized endpoint identity")
        source_property = _string(edge.get("source_property"), f"edge {edge_id}.source_property")
        scope = _string(edge.get("scope"), f"edge {edge_id}.scope")
        predicate = _string(edge.get("invalidation_predicate"), f"edge {edge_id}.invalidation_predicate")
        signature = (source, target, edge_type, source_property, scope, predicate)
        if signature in signatures:
            raise _DecodeError(f"dependency graph repeats edge {signature!r}")
        signatures.add(signature)
        result.append(dict(edge))

    edge_order = [edge["edge_id"] for edge in result]
    if edge_order != sorted(edge_order):
        raise _DecodeError("dependency edge identities are not in canonical order")

    nodes = {edge["source"] for edge in result} | {edge["target"] for edge in result}
    indegree = {node: 0 for node in nodes}
    outgoing: Dict[str, List[str]] = {node: [] for node in nodes}
    for edge in result:
        indegree[edge["target"]] += 1
        outgoing[edge["source"]].append(edge["target"])
    queue = sorted(node for node, degree in indegree.items() if degree == 0)
    visited = 0
    while queue:
        node = queue.pop(0)
        visited += 1
        for target in sorted(outgoing[node]):
            indegree[target] -= 1
            if indegree[target] == 0:
                queue.append(target)
                queue.sort()
    if visited != len(nodes):
        raise _DecodeError("dependency graph contains a cycle")
    return result


def _revalidation_expected(
    record: Mapping[str, Any],
    dependency_edges: Sequence[Mapping[str, Any]],
    artifact_universe: Sequence[str],
) -> Tuple[List[dict], List[str], List[str], str]:
    edges = _dependency_edges(dependency_edges)
    universe = _strings(
        artifact_universe,
        "artifact universe",
        sorted_unique=True,
        nonempty=True,
    )
    if any(item != item.strip() for item in universe):
        raise _DecodeError("artifact universe contains a non-normalized identity")
    changed_source = _string(record.get("changed_source"), "selective revalidation.changed_source")
    changed = _strings(record.get("changed_properties"), "changed_properties", sorted_unique=True, nonempty=True)
    if changed_source not in universe:
        raise _DecodeError("changed source is absent from the complete artifact universe")
    nodes = {edge["source"] for edge in edges} | {edge["target"] for edge in edges}
    outside = sorted(nodes - set(universe))
    if outside:
        raise _DecodeError(f"dependency graph names artifacts outside the complete universe: {outside}")
    if changed_source not in nodes:
        raise _DecodeError("changed source is absent from the typed dependency graph")
    outgoing: Dict[str, List[dict]] = {}
    for edge in edges:
        outgoing.setdefault(edge["source"], []).append(edge)
    impact: Dict[str, str] = {}
    frontier: List[Tuple[str, Optional[Set[str]]]] = [(changed_source, set(changed))]
    seen: Set[str] = set()
    while frontier:
        node, properties = frontier.pop()
        for edge in outgoing.get(node, ()):
            if edge["edge_id"] in seen:
                continue
            source_property = edge["source_property"]
            if properties is not None and source_property != "*" and source_property not in properties:
                continue
            seen.add(edge["edge_id"])
            action = edge["minimum_action"]
            prior = impact.get(edge["target"], "NO_OPERATION")
            if _ACTION_SEVERITY[action] > _ACTION_SEVERITY[prior]:
                impact[edge["target"]] = action
            else:
                impact.setdefault(edge["target"], prior)
            if edge["transitive"] and action != "NO_OPERATION":
                frontier.append((edge["target"], None))
    affected = [
        {"artifact_id": identifier, "minimum_action": action}
        for identifier, action in sorted(impact.items())
    ]
    preserved = sorted(set(universe) - set(impact) - {changed_source})
    replacement = sorted(impact)
    graph_hash = content_hash([edge for edge in sorted(edges, key=lambda item: item["edge_id"])])
    return affected, preserved, replacement, graph_hash


def verify_selective_revalidation_record(
    record: Mapping[str, Any],
    dependency_edges: Sequence[Mapping[str, Any]],
    artifact_universe: Sequence[str],
) -> VerificationResult:
    """Replay a complete typed dependency closure and preservation claim."""

    def check() -> Tuple[List[Tuple[str, bool, str]], Dict[str, Any]]:
        _keys(
            record,
            ("record_type", "profile", "schema_version", "record_id", "changed_source",
             "changed_properties", "dependency_graph_hash", "dependency_completeness_basis",
             "affected", "preserved", "replacement_required", "state"),
            (),
            "selective revalidation",
        )
        _string(record.get("record_id"), "selective revalidation.record_id")
        _string(record.get("dependency_completeness_basis"), "dependency completeness basis")
        if record.get("state") not in {"PENDING_REVALIDATION", "REVALIDATION_COMPLETE"}:
            raise _DecodeError(f"unknown revalidation state {record.get('state')!r}")
        affected, preserved, replacement, graph_hash = _revalidation_expected(
            record, dependency_edges, artifact_universe
        )
        exact = (
            record.get("dependency_graph_hash") == graph_hash
            and record.get("affected") == affected
            and record.get("preserved") == preserved
            and record.get("replacement_required") == replacement
        )
        return [
            ("typed_dependency_closure", exact, "complete typed closure, minimum actions, and graph root independently reconstructed"),
            ("preservation_partition", not (set(preserved) & {item["artifact_id"] for item in affected}), "affected and preserved artifact sets are disjoint"),
        ], {"dependency_graph_hash": graph_hash, "affected_count": len(affected), "preserved_count": len(preserved)}

    return _run(record, "SelectiveRevalidationRecord", ETQ_PROFILE, check)


def verify_replacement_record(
    record: Mapping[str, Any],
    revalidation_record: Mapping[str, Any],
    prior_artifact: Mapping[str, Any],
    replacement_artifact: Mapping[str, Any],
    dependency_edges: Sequence[Mapping[str, Any]],
    artifact_universe: Sequence[str],
) -> VerificationResult:
    """Verify replacement lineage and prohibit replacing a preserved object."""

    def check() -> Tuple[List[Tuple[str, bool, str]], Dict[str, Any]]:
        _keys(
            record,
            ("record_type", "profile", "schema_version", "replacement_id", "revalidation_record_hash",
             "prior_artifact_id", "replacement_artifact_id", "prior_artifact_hash",
             "replacement_artifact_hash", "action_completed", "verification_basis"),
            (),
            "replacement record",
        )
        for field in ("replacement_id", "prior_artifact_id", "replacement_artifact_id"):
            _string(record.get(field), f"replacement record.{field}")
        _strings(record.get("verification_basis"), "replacement verification_basis", nonempty=True)
        revalidation = _object(revalidation_record, "revalidation record")
        revalidation_result = verify_selective_revalidation_record(
            revalidation, dependency_edges, artifact_universe
        )
        if not revalidation_result.ok:
            raise _DecodeError("the referenced selective-revalidation record does not independently verify")
        affected = {
            _string(item.get("artifact_id"), "affected.artifact_id"): _string(item.get("minimum_action"), "affected.minimum_action")
            for item in (_object(raw, "affected item") for raw in _array(revalidation.get("affected"), "affected"))
        }
        prior_id = record.get("prior_artifact_id")
        if prior_id in set(revalidation.get("preserved", ())):
            raise _DecodeError("a preserved artifact cannot be replaced")
        if prior_id not in affected or prior_id not in set(revalidation.get("replacement_required", ())):
            raise _DecodeError("replacement target was not affected and replacement-required")
        prior_root = _preflight(prior_artifact, "prior artifact")
        replacement_root = _preflight(replacement_artifact, "replacement artifact")
        if record.get("prior_artifact_id") == record.get("replacement_artifact_id") or prior_root == replacement_root:
            raise _DecodeError("replacement must have a new identity and new immutable bytes")
        exact = (
            record.get("revalidation_record_hash") == content_hash(revalidation)
            and record.get("prior_artifact_hash") == prior_root
            and record.get("replacement_artifact_hash") == replacement_root
            and record.get("action_completed") == affected[prior_id]
        )
        return [
            ("replacement_binding", exact, "revalidation, prior bytes, replacement bytes, and minimum action independently bound"),
            ("preserved_object_guard", prior_id not in set(revalidation.get("preserved", ())), "replacement target is not in the preserved partition"),
        ], {"prior_artifact_root": prior_root, "replacement_artifact_root": replacement_root}

    return _run(record, "ReplacementRecord", ETQ_PROFILE, check)


def _validate_ingestion_summary(record: Mapping[str, Any]) -> Tuple[str, str, str]:
    _profile(record, "ResultIngestionRecord", ETQ_PROFILE)
    _keys(
        record,
        ("record_type", "profile", "schema_version", "ingestion_id", "plan_id", "experiment_id",
         "result_hash", "new_evidence_id", "new_evidence_hash", "evidence_class",
         "evidence_status", "prior_evidence_ids", "prior_evidence_hashes", "preserved_prior_records"),
        (),
        "qualification result ingestion",
    )
    for field in ("ingestion_id", "plan_id", "experiment_id"):
        _string(record.get(field), f"ingestion.{field}")
    _hash(record.get("result_hash"), "ingestion.result_hash")
    evidence_id = _string(record.get("new_evidence_id"), "ingestion.new_evidence_id")
    evidence_hash = _hash(record.get("new_evidence_hash"), "ingestion.new_evidence_hash")
    evidence_class = _string(record.get("evidence_class"), "ingestion.evidence_class")
    evidence_status = _string(record.get("evidence_status"), "ingestion.evidence_status")
    if evidence_class not in _EVIDENCE_CLASSES or evidence_status not in _EVIDENCE_STATUS:
        raise _DecodeError("ingestion carries an unknown evidence class or maturity")
    prior_ids = _strings(record.get("prior_evidence_ids"), "ingestion.prior_evidence_ids")
    prior_hashes = _hashes(record.get("prior_evidence_hashes"), "ingestion.prior_evidence_hashes")
    if len(prior_ids) != len(prior_hashes):
        raise _DecodeError("ingestion prior evidence identities and hashes are not one-to-one")
    if evidence_id in prior_ids or evidence_hash in prior_hashes:
        raise _DecodeError("ingestion reuses a prior evidence identity or hash")
    if record.get("preserved_prior_records") is not True:
        raise _DecodeError("ingestion does not preserve prior evidence records")
    return evidence_id, evidence_hash, evidence_class


def verify_qualification_disposition(
    record: Mapping[str, Any],
    qualification_result: Mapping[str, Any],
    ingestions: Sequence[Mapping[str, Any]],
    required_evidence_ids: Sequence[str],
    verification_basis: Sequence[str],
    *,
    minimum_evidence_status: str = "QUALIFIED",
) -> VerificationResult:
    """Re-derive direct campaign disposition and its evidence floor."""

    def check() -> Tuple[List[Tuple[str, bool, str]], Dict[str, Any]]:
        _keys(
            record,
            ("record_type", "profile", "schema_version", "plan_id", "state", "stopping_condition",
             "outcome", "evidence_hashes", "verification_basis", "unmet_requirements"),
            (),
            "qualification disposition",
        )
        result_doc = _object(qualification_result, "qualification result")
        _preflight(result_doc, "qualification result")
        plan_id = _string(result_doc.get("plan_id"), "qualification result.plan_id")
        stopped = _boolean(result_doc.get("stopped"), "qualification result.stopped")
        reason = _string(result_doc.get("stopping_reason"), "qualification result.stopping_reason")
        detail = _string(result_doc.get("stopping_detail"), "qualification result.stopping_detail", empty=True)
        if minimum_evidence_status not in _EVIDENCE_STATUS:
            raise _UnsupportedProfileError(f"unknown minimum evidence status {minimum_evidence_status!r}")
        _preflight(list(verification_basis), "qualification verification basis")
        basis = tuple(_string(item, "verification_basis[]") for item in verification_basis if item)
        if len(set(basis)) != len(basis):
            raise _DecodeError("verification basis contains duplicates")
        required = set(_string(item, "required_evidence_ids[]") for item in required_evidence_ids)
        summaries = []
        for raw in ingestions:
            ingestion = _object(raw, "result ingestion")
            _preflight(ingestion, "result ingestion")
            evidence_id, evidence_hash, evidence_class = _validate_ingestion_summary(ingestion)
            summaries.append((evidence_id, evidence_hash, evidence_class, ingestion["evidence_status"]))
        ids = [item[0] for item in summaries]
        if len(set(ids)) != len(ids):
            raise _DecodeError("qualification ingestions repeat an evidence identity")
        evidence_hashes = [item[1] for item in summaries]
        unmet: List[str] = []
        if not stopped:
            state = "IN_PROGRESS"
            outcome = "the declared stopping rule has not fired"
        elif reason not in _RESOLVING_STOPS:
            if reason not in _STOPPING:
                raise _DecodeError(f"unknown stopping reason {reason!r}")
            state = "STOPPED_UNRESOLVED"
            outcome = detail
        else:
            missing = sorted(required - set(ids))
            if missing:
                unmet.append("missing required evidence: " + ", ".join(missing))
            weak = sorted(item[0] for item in summaries if _EVIDENCE_STATUS[item[3]] < _EVIDENCE_STATUS[minimum_evidence_status])
            if weak:
                unmet.append(f"evidence below {minimum_evidence_status}: " + ", ".join(weak))
            nonauthorizing = sorted(item[0] for item in summaries if item[2] not in _AUTHORIZING_EVIDENCE)
            if nonauthorizing:
                unmet.append("non-authorizing evidence class: " + ", ".join(nonauthorizing))
            if not basis:
                unmet.append("missing verification basis")
            if unmet:
                state = "EVIDENCE_REQUIREMENTS_UNSATISFIED"
                outcome = "the stopping condition fired but qualification evidence is incomplete"
            else:
                state = "QUALIFICATION_COMPLETE"
                outcome = detail
        expected = {
            "plan_id": plan_id,
            "state": state,
            "stopping_condition": reason,
            "outcome": outcome,
            "evidence_hashes": evidence_hashes,
            "verification_basis": list(basis),
            "unmet_requirements": unmet,
        }
        actual = {key: record.get(key) for key in expected}
        return [
            ("qualification_derivation", actual == expected, "stop class, evidence maturity/class, required identities, and verification basis independently rederived"),
            ("qualification_no_synthetic_score", not ({"score", "confidence", "readiness", "health"} & set(record)), "disposition contains direct states only"),
        ], {"derived_state": state, "evidence_count": len(summaries)}

    return _run(record, "QualificationDisposition", ETQ_PROFILE, check)
