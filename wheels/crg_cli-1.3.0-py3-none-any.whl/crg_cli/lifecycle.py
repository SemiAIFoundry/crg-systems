"""Integrated CRG v1.3 evidence-to-qualification lifecycle boundary.

The producer, CLI, server, SDK, and Studio share exactly six ETQ operations and
five portable record types. Every record is independently replayed before it
can be appended to case state. Successor decision-governance, validity,
comparison, conversion, migration, and recovery surfaces are outside this
release boundary.
"""
from __future__ import annotations

import copy
from typing import Any, Dict, Mapping, MutableMapping, Sequence, Tuple

import crg_verify
from crg_model.canonical import canonical_json, content_hash
from crg_model.edges import DependencyEdge
from crg_model.numeric import Exact, Interval
from etq_evidence import (
    AccessPolicy,
    ContextDescriptor,
    EvidenceRecord,
    MethodDescriptor,
    Provenance,
    UncertaintyBudget,
    ValidityWindow,
    VerificationClock,
)
from etq_qualify import (
    BurdenDimension,
    BurdenVector,
    ETQDecisionLoop,
    ETQStepRecord,
    ExperimentResult,
    LoopArtifactRef,
    QualificationResult,
    QualificationState,
    ReplacementRecord,
    ResultIngestionRecord,
    SelectiveRevalidationRecord,
    TargetEvaluation,
    ingest_result_as_evidence,
    issue_replacement,
    plan_selective_revalidation,
    qualification_disposition,
)

from .store import CaseError, record_history

__all__ = [
    "LIFECYCLE_OPERATIONS",
    "ETQ_LIFECYCLE_OPERATIONS",
    "LIFECYCLE_RECORD_TYPES",
    "ETQ_LIFECYCLE_RECORD_TYPES",
    "LIFECYCLE_INPUT_CONTRACTS",
    "LIFECYCLE_VERIFIER_CONTRACTS",
    "LifecycleVerificationError",
    "build_verified_lifecycle_record",
    "verify_lifecycle_record",
    "persist_lifecycle_record",
    "inspect_lifecycle_record",
    "portable_lifecycle_objects",
    "render_lifecycle_report",
]

ETQ_LIFECYCLE_OPERATIONS = (
    "CREATE_ETQ_LOOP",
    "APPEND_ETQ_STEP",
    "INGEST_RESULT",
    "PLAN_REVALIDATION",
    "ISSUE_REPLACEMENT",
    "QUALIFICATION_DISPOSITION",
)
LIFECYCLE_OPERATIONS = ETQ_LIFECYCLE_OPERATIONS

LIFECYCLE_INPUT_CONTRACTS = {
    "CREATE_ETQ_LOOP": ((
        "loop_id", "target_decision_id", "predicate_id", "target_context",
        "declared_stopping_conditions",
    ), ()),
    "APPEND_ETQ_STEP": (("loop_id", "authority", "verification_basis"), (
        "artifacts", "refusal",
    )),
    "INGEST_RESULT": ((
        "result", "ingestion_id", "plan_id", "evidence_id", "method", "provenance",
        "validity", "access",
    ), ("evidence_status", "prior_evidence")),
    "PLAN_REVALIDATION": ((
        "record_id", "changed_source", "changed_properties", "dependency_edges",
        "artifact_universe", "dependency_completeness_basis",
    ), ()),
    "ISSUE_REPLACEMENT": ((
        "revalidation_record_id", "replacement_id", "prior_artifact_id",
        "replacement_artifact_id", "prior_artifact", "replacement_artifact",
        "verification_basis",
    ), ()),
    "QUALIFICATION_DISPOSITION": ((
        "qualification_result", "ingestions", "required_evidence_ids", "verification_basis",
    ), ("minimum_evidence_status",)),
}

ETQ_LIFECYCLE_RECORD_TYPES = (
    "ETQDecisionLoop",
    "ResultIngestionRecord",
    "SelectiveRevalidationRecord",
    "ReplacementRecord",
    "QualificationDisposition",
)
LIFECYCLE_RECORD_TYPES = ETQ_LIFECYCLE_RECORD_TYPES

_IDENTITY_FIELDS = {
    "ETQDecisionLoop": "loop_id",
    "ResultIngestionRecord": "ingestion_id",
    "SelectiveRevalidationRecord": "record_id",
    "ReplacementRecord": "replacement_id",
}
_CONTENT_IDENTIFIED_RECORDS = frozenset({"QualificationDisposition"})
_DIRECT_STATE_FIELDS = {
    "ETQDecisionLoop": ("complete", "refused", "next_step"),
    "SelectiveRevalidationRecord": ("state",),
    "QualificationDisposition": ("state", "stopping_condition"),
}
_RECORD_WORKSTREAM = {
    record_type: "v1.3/ETQ_LIFECYCLE"
    for record_type in ETQ_LIFECYCLE_RECORD_TYPES
}
_VERIFIER_INPUT_FIELDS = {
    "verify_etq_decision_loop": frozenset(),
    "verify_result_ingestion_record": frozenset({
        "result_record", "new_evidence", "prior_evidence",
    }),
    "verify_selective_revalidation_record": frozenset({
        "dependency_edges", "artifact_universe",
    }),
    "verify_replacement_record": frozenset({
        "revalidation_record", "prior_artifact", "replacement_artifact",
        "dependency_edges", "artifact_universe",
    }),
    "verify_qualification_disposition": frozenset({
        "qualification_result", "ingestions", "required_evidence_ids",
        "verification_basis", "minimum_evidence_status",
    }),
}
_RECORD_VERIFIER_OPERATIONS = {
    "ETQDecisionLoop": "verify_etq_decision_loop",
    "ResultIngestionRecord": "verify_result_ingestion_record",
    "SelectiveRevalidationRecord": "verify_selective_revalidation_record",
    "ReplacementRecord": "verify_replacement_record",
    "QualificationDisposition": "verify_qualification_disposition",
}
LIFECYCLE_VERIFIER_CONTRACTS = {
    record_type: (
        operation,
        _RECORD_WORKSTREAM[record_type],
        tuple(sorted(_VERIFIER_INPUT_FIELDS[operation])),
    )
    for record_type, operation in _RECORD_VERIFIER_OPERATIONS.items()
}


class LifecycleVerificationError(CaseError):
    """The independent lifecycle implementation rejected producer output."""


def _object(value: Any, where: str) -> Dict[str, Any]:
    if not isinstance(value, Mapping):
        raise CaseError(f"{where} must be a JSON object")
    return copy.deepcopy(dict(value))


def _closed(
    value: Any,
    where: str,
    required: Sequence[str],
    optional: Sequence[str] = (),
) -> Dict[str, Any]:
    result = _object(value, where)
    missing = sorted(set(required) - set(result))
    unknown = sorted(set(result) - set(required) - set(optional))
    if missing:
        raise CaseError(f"{where} is missing required field(s): {', '.join(missing)}")
    if unknown:
        raise CaseError(
            f"{where} contains unsupported field(s): {', '.join(unknown)}; "
            "derived states, hashes, authority effects, scores, and mutations are not accepted"
        )
    return result


def _sequence(value: Any, where: str) -> Tuple[Any, ...]:
    if not isinstance(value, (list, tuple)):
        raise CaseError(f"{where} must be a JSON array")
    return tuple(copy.deepcopy(item) for item in value)


def _strings(value: Any, where: str) -> Tuple[str, ...]:
    values = _sequence(value, where)
    if any(not isinstance(item, str) or not item for item in values):
        raise CaseError(f"{where} must contain non-empty strings")
    return tuple(values)


def _exact(value: Any, where: str) -> Exact:
    item = _closed(value, where, ("exact",))
    raw = item["exact"]
    if not isinstance(raw, str):
        raise CaseError(f"{where}.exact must be a rational string; floats are forbidden")
    try:
        result = Exact(raw)
    except (TypeError, ValueError, ZeroDivisionError) as error:
        raise CaseError(f"{where} is not an exact rational: {error}") from error
    if result.to_canonical() != item:
        raise CaseError(f"{where} is not in canonical exact-rational form")
    return result


def _optional_exact(value: Any, where: str) -> Exact | None:
    return None if value is None else _exact(value, where)


def _interval(value: Any, where: str) -> Interval:
    item = _closed(value, where, ("lo", "hi"))
    result = Interval(_exact(item["lo"], f"{where}.lo"), _exact(item["hi"], f"{where}.hi"))
    if result.to_canonical() != item:
        raise CaseError(f"{where} is not a canonical exact interval")
    return result


def _canonical_instance(value: Any, instance: Any, where: str) -> Any:
    expected = instance.to_canonical()
    if canonical_json(expected) != canonical_json(value):
        raise CaseError(
            f"{where} is not the canonical form of the registered producer object"
        )
    return instance


def _context(value: Any, where: str) -> ContextDescriptor:
    item = _closed(value, where, ("context_id", "context_type", "fields"))
    return _canonical_instance(
        item,
        ContextDescriptor(item["context_id"], item["context_type"], item["fields"]),
        where,
    )


def _method(value: Any, where: str) -> MethodDescriptor:
    item = _closed(
        value,
        where,
        ("method_id", "method_class", "evidence_class"),
        ("instrument", "version", "parameters"),
    )
    return _canonical_instance(
        item,
        MethodDescriptor(
            item["method_id"],
            item["method_class"],
            item["evidence_class"],
            item.get("instrument"),
            item.get("version"),
            tuple(sorted((item.get("parameters") or {}).items())),
        ),
        where,
    )


def _provenance(value: Any, where: str, *, derived_result_hash: str | None = None) -> Provenance:
    item = _closed(
        value,
        where,
        ("source_id", "issuer", "integrity", "chain"),
        ("provenance_status", "issued_at", "signature", "notes"),
    )
    chain = item["chain"]
    if chain == ["DERIVE_FROM_RETURNED_RESULT"]:
        if derived_result_hash is None:
            raise CaseError(f"{where} cannot derive a result hash in this operation")
        chain = [derived_result_hash]
        item["chain"] = chain
        # ``provenance_status`` is derived by the producer and therefore may
        # be omitted (or replaced) in the authoring shorthand.
        item["provenance_status"] = "VALID"
    instance = Provenance(
        source_id=item["source_id"],
        issuer=item["issuer"],
        issued_at=item.get("issued_at"),
        chain=tuple(chain),
        integrity=item["integrity"],
        signature=item.get("signature"),
        notes=tuple(item.get("notes") or ()),
    )
    expected = instance.to_canonical()
    if canonical_json(expected) != canonical_json(item):
        raise CaseError(f"{where} is not canonical after deriving the returned-result binding")
    return instance


def _access(value: Any, where: str) -> AccessPolicy:
    item = _closed(
        value,
        where,
        (
            "classification",
            "permitted_roles",
            "permitted_subjects",
            "redaction_required",
            "export_permitted",
        ),
    )
    return _canonical_instance(
        item,
        AccessPolicy(
            item["classification"],
            tuple(item["permitted_roles"]),
            tuple(item["permitted_subjects"]),
            item["redaction_required"],
            item["export_permitted"],
        ),
        where,
    )


def _validity(value: Any, where: str) -> ValidityWindow:
    item = _closed(
        value,
        where,
        ("issuer_clock_source",),
        ("issued_at", "not_before", "expires_at", "max_age_seconds", "revalidation_triggers"),
    )
    return _canonical_instance(
        item,
        ValidityWindow(
            issued_at=item.get("issued_at"),
            not_before=item.get("not_before"),
            expires_at=item.get("expires_at"),
            max_age_seconds=item.get("max_age_seconds"),
            revalidation_triggers=tuple(item.get("revalidation_triggers") or ()),
            issuer_clock_source=item["issuer_clock_source"],
        ),
        where,
    )


def _clock(value: Any, where: str) -> VerificationClock:
    item = _closed(
        value,
        where,
        ("verifier_evaluation_time", "verifier_clock_source", "verifier_clock_trust_level"),
    )
    return _canonical_instance(
        item,
        VerificationClock(
            item["verifier_evaluation_time"],
            item["verifier_clock_source"],
            item["verifier_clock_trust_level"],
        ),
        where,
    )


def _uncertainty(value: Any, where: str) -> UncertaintyBudget:
    item = _closed(
        value,
        where,
        ("measurement", "sampling", "calibration", "transfer", "model", "component_order"),
        ("basis",),
    )
    if item["component_order"] != ["measurement", "sampling", "calibration", "transfer", "model"]:
        raise CaseError(f"{where}.component_order is not the registered five-component order")
    return _canonical_instance(
        item,
        UncertaintyBudget(
            measurement=_interval(item["measurement"], f"{where}.measurement"),
            sampling=_interval(item["sampling"], f"{where}.sampling"),
            calibration=_interval(item["calibration"], f"{where}.calibration"),
            transfer=_interval(item["transfer"], f"{where}.transfer"),
            model=_interval(item["model"], f"{where}.model"),
            basis=item.get("basis", ""),
        ),
        where,
    )


def _burden(value: Any, where: str) -> BurdenVector:
    item = _closed(value, where, ("declared_dimensions", "values"), ("basis",))
    values = _object(item["values"], f"{where}.values")
    declared = item["declared_dimensions"]
    if not isinstance(declared, list) or not all(isinstance(name, str) for name in declared):
        raise CaseError(f"{where}.declared_dimensions must be an array of strings")
    if len(set(declared)) != len(declared):
        raise CaseError(f"{where}.declared_dimensions repeats a burden dimension")
    unknown = set(declared) - set(BurdenDimension.ORDER)
    if unknown:
        raise CaseError(f"{where}.declared_dimensions contains unknown dimensions {sorted(unknown)}")
    governed = [name for name in BurdenDimension.ORDER if name in set(declared)]
    if declared != governed:
        raise CaseError(
            f"{where}.declared_dimensions is not in the governed burden-dimension order"
        )
    if set(values) != set(declared):
        raise CaseError(f"{where} declared dimensions and values do not name the same dimensions")
    instance = BurdenVector(
        [
            (name, _exact(values[name], f"{where}.values.{name}"))
            for name in declared
        ],
        basis=item.get("basis", ""),
    )
    return _canonical_instance(item, instance, where)


def _experiment_result(value: Any, where: str) -> ExperimentResult:
    item = _closed(
        value,
        where,
        ("experiment_id", "measurand", "unit", "status", "correlation_assumption", "uncertainty"),
        (
            "observed",
            "context",
            "observed_ambiguity",
            "ambiguity_metric",
            "burden_incurred",
            "regret_upper_bound",
            "possible_winners",
            "guaranteed_winner",
            "manual_adjudication_required",
            "manual_adjudication_reason",
            "notes",
        ),
    )
    instance = ExperimentResult(
        experiment_id=item["experiment_id"],
        measurand=item["measurand"],
        unit=item["unit"],
        observed=_interval(item["observed"], f"{where}.observed") if "observed" in item else None,
        uncertainty=_uncertainty(item["uncertainty"], f"{where}.uncertainty"),
        correlation_assumption=item["correlation_assumption"],
        context=_context(item["context"], f"{where}.context") if "context" in item else None,
        observed_ambiguity=_optional_exact(item.get("observed_ambiguity"), f"{where}.observed_ambiguity"),
        ambiguity_metric=item.get("ambiguity_metric"),
        status=item["status"],
        burden_incurred=_burden(item["burden_incurred"], f"{where}.burden_incurred") if "burden_incurred" in item else None,
        regret_upper_bound=_optional_exact(item.get("regret_upper_bound"), f"{where}.regret_upper_bound"),
        possible_winners=tuple(item["possible_winners"]) if "possible_winners" in item else None,
        guaranteed_winner=item.get("guaranteed_winner"),
        manual_adjudication_required=item.get("manual_adjudication_required", False),
        manual_adjudication_reason=item.get("manual_adjudication_reason", ""),
        notes=tuple(item.get("notes") or ()),
    )
    return _canonical_instance(item, instance, where)


def _state(value: Any, where: str) -> QualificationState:
    item = _closed(
        value,
        where,
        (
            "plan_id", "step", "coordinate_bounds", "predicate_state", "ambiguity_metric",
            "ambiguity", "ambiguity_derivable", "cumulative_burden", "completed_experiments",
            "remaining_experiments", "informative_remaining", "manual_adjudication_required",
        ),
        ("regret_upper_bound", "possible_winners", "guaranteed_winner", "manual_adjudication_reason", "notes"),
    )
    bounds = _object(item["coordinate_bounds"], f"{where}.coordinate_bounds")
    instance = QualificationState(
        plan_id=item["plan_id"],
        coordinate_bounds=tuple(
            (name, _interval(bound, f"{where}.coordinate_bounds.{name}"))
            for name, bound in bounds.items()
        ),
        predicate_state=item["predicate_state"],
        ambiguity_metric=item["ambiguity_metric"],
        ambiguity=_exact(item["ambiguity"], f"{where}.ambiguity"),
        cumulative_burden=_burden(item["cumulative_burden"], f"{where}.cumulative_burden"),
        completed_experiments=tuple(item["completed_experiments"]),
        remaining_experiments=tuple(item["remaining_experiments"]),
        informative_remaining=tuple(item["informative_remaining"]),
        ambiguity_derivable=item["ambiguity_derivable"],
        regret_upper_bound=_optional_exact(item.get("regret_upper_bound"), f"{where}.regret_upper_bound"),
        possible_winners=tuple(item.get("possible_winners") or ()),
        guaranteed_winner=item.get("guaranteed_winner"),
        manual_adjudication_required=item["manual_adjudication_required"],
        manual_adjudication_reason=item.get("manual_adjudication_reason", ""),
        step=item["step"],
        notes=tuple(item.get("notes") or ()),
    )
    return _canonical_instance(item, instance, where)


def _target_evaluation(value: Any, where: str) -> TargetEvaluation:
    item = _closed(
        value,
        where,
        ("target_id", "predicate_id", "coordinate_id", "measurand_status", "coordinate_status"),
        ("measurand", "observed", "carried_coordinate_bound", "detail"),
    )
    instance = TargetEvaluation(
        target_id=item["target_id"],
        predicate_id=item["predicate_id"],
        coordinate_id=item["coordinate_id"],
        measurand=item.get("measurand"),
        measurand_status=item["measurand_status"],
        coordinate_status=item["coordinate_status"],
        observed=_interval(item["observed"], f"{where}.observed") if "observed" in item else None,
        carried_coordinate_bound=_interval(item["carried_coordinate_bound"], f"{where}.carried_coordinate_bound") if "carried_coordinate_bound" in item else None,
        detail=item.get("detail", ""),
    )
    return _canonical_instance(item, instance, where)


def _qualification_result(value: Any, where: str) -> QualificationResult:
    item = _closed(
        value,
        where,
        (
            "plan_id", "experiment_id", "result_status", "predicate_state_before",
            "predicate_state_after", "ambiguity_before", "ambiguity_after", "residual_ambiguity",
            "residual_metric", "burden_incurred", "cumulative_burden", "target_evaluations",
            "stopped", "stopping_reason", "stopping_detail", "prior_state", "state",
            "warnings", "verification_basis",
        ),
    )
    instance = QualificationResult(
        plan_id=item["plan_id"],
        experiment_id=item["experiment_id"],
        result_status=item["result_status"],
        prior_state=_state(item["prior_state"], f"{where}.prior_state"),
        state=_state(item["state"], f"{where}.state"),
        target_evaluations=tuple(
            _target_evaluation(raw, f"{where}.target_evaluations[{index}]")
            for index, raw in enumerate(_sequence(item["target_evaluations"], f"{where}.target_evaluations"))
        ),
        predicate_state_before=item["predicate_state_before"],
        predicate_state_after=item["predicate_state_after"],
        ambiguity_before=_exact(item["ambiguity_before"], f"{where}.ambiguity_before"),
        ambiguity_after=_exact(item["ambiguity_after"], f"{where}.ambiguity_after"),
        burden_incurred=_burden(item["burden_incurred"], f"{where}.burden_incurred"),
        cumulative_burden=_burden(item["cumulative_burden"], f"{where}.cumulative_burden"),
        stopped=item["stopped"],
        stopping_reason=item["stopping_reason"],
        stopping_detail=item["stopping_detail"],
        residual_ambiguity=_exact(item["residual_ambiguity"], f"{where}.residual_ambiguity"),
        residual_metric=item["residual_metric"],
        warnings=tuple(item["warnings"]),
        verification_basis=tuple(item["verification_basis"]),
    )
    return _canonical_instance(item, instance, where)


def _evidence(value: Any, where: str) -> EvidenceRecord:
    item = _closed(
        value,
        where,
        (
            "record_type", "spec_section", "evidence_id", "quantity", "unit", "Y_value",
            "U_uncertainty", "C_source_context", "M_method", "P_provenance", "V_validity",
            "A_access", "evidence_status", "status",
        ),
        ("supersedes", "superseded_by", "scenarios", "notes"),
    )
    if item["record_type"] != "etq.evidence_record" or item["spec_section"] != "33.2":
        raise CaseError(f"{where} is not a registered ETQ evidence record")
    instance = EvidenceRecord(
        evidence_id=item["evidence_id"],
        quantity=item["quantity"],
        unit=item["unit"],
        value=_interval(item["Y_value"], f"{where}.Y_value"),
        uncertainty=_uncertainty(item["U_uncertainty"], f"{where}.U_uncertainty"),
        source_context=_context(item["C_source_context"], f"{where}.C_source_context"),
        method=_method(item["M_method"], f"{where}.M_method"),
        provenance=_provenance(item["P_provenance"], f"{where}.P_provenance"),
        validity=_validity(item["V_validity"], f"{where}.V_validity"),
        access=_access(item["A_access"], f"{where}.A_access"),
        evidence_status=item["evidence_status"],
        status=item["status"],
        supersedes=tuple(item.get("supersedes") or ()),
        superseded_by=item.get("superseded_by"),
        scenarios=tuple(
            _interval(raw, f"{where}.scenarios[{index}]")
            for index, raw in enumerate(item.get("scenarios") or ())
        ),
        notes=tuple(item.get("notes") or ()),
    )
    return _canonical_instance(item, instance, where)


def _dependency_edge(value: Any, where: str) -> DependencyEdge:
    item = _closed(
        value,
        where,
        (
            "edge_id", "source", "target", "edge_type", "minimum_action", "transitive",
            "validity_propagation_rule", "edge_version", "source_property", "scope",
            "invalidation_predicate",
        ),
    )
    instance = DependencyEdge(
        item["edge_id"],
        item["source"],
        item["target"],
        item["edge_type"],
        None if item["source_property"] == "*" else item["source_property"],
        None if item["scope"] == "GLOBAL" else item["scope"],
        None if item["invalidation_predicate"] == "EDGE_TYPE_TRIGGER:" + item["edge_type"] else item["invalidation_predicate"],
        item["edge_version"],
    )
    return _canonical_instance(item, instance, where)


def _loop(value: Any, where: str) -> ETQDecisionLoop:
    item = _object(value, where)
    steps = []
    for index, raw in enumerate(item.get("steps") or ()):
        step = _object(raw, f"{where}.steps[{index}]")
        outputs = tuple(
            LoopArtifactRef(
                output["artifact_id"], output["artifact_type"], output["content_hash"],
                tuple(output["parent_hashes"]), output["status"], output["evidence_class"],
            )
            for output in step.get("outputs") or ()
        )
        refusal = step.get("refusal") or {}
        steps.append(
            ETQStepRecord(
                step["step"], outputs, tuple(step["input_hashes"]), step["authority"],
                tuple(step["verification_basis"]), refusal.get("code"), refusal.get("detail", ""),
            )
        )
    instance = ETQDecisionLoop(
        item.get("loop_id", ""), item.get("target_decision_id", ""), item.get("predicate_id", ""),
        item.get("target_context_hash", ""), tuple(item.get("declared_stopping_conditions") or ()),
        tuple(steps), item.get("schema_version", ""),
    )
    return _canonical_instance(item, instance, where)


def _revalidation(value: Any, where: str) -> SelectiveRevalidationRecord:
    item = _object(value, where)
    instance = SelectiveRevalidationRecord(
        item.get("record_id", ""), item.get("changed_source", ""),
        tuple(item.get("changed_properties") or ()), item.get("dependency_graph_hash", ""),
        item.get("dependency_completeness_basis", ""),
        tuple((raw["artifact_id"], raw["minimum_action"]) for raw in item.get("affected") or ()),
        tuple(item.get("preserved") or ()), tuple(item.get("replacement_required") or ()),
        item.get("state", ""),
    )
    return _canonical_instance(item, instance, where)


def _ingestion(value: Any, where: str) -> ResultIngestionRecord:
    item = _object(value, where)
    instance = ResultIngestionRecord(
        item.get("ingestion_id", ""), item.get("plan_id", ""), item.get("experiment_id", ""),
        item.get("result_hash", ""), item.get("new_evidence_id", ""),
        item.get("new_evidence_hash", ""), item.get("evidence_class", ""),
        item.get("evidence_status", ""), tuple(item.get("prior_evidence_ids") or ()),
        tuple(item.get("prior_evidence_hashes") or ()), item.get("preserved_prior_records", False),
    )
    return _canonical_instance(item, instance, where)



def _verification_inputs(operation: str, record: Mapping[str, Any], **inputs: Any) -> dict:
    return {
        "verification_profile": "crg-lifecycle/independent-replay@1",
        "first_release_attribution": _RECORD_WORKSTREAM[record["record_type"]],
        "verifier_operation": operation,
        "record_type": record["record_type"],
        "record_hash": content_hash(record),
        "inputs": copy.deepcopy(inputs),
    }


def verify_lifecycle_record(record: Any, verification_inputs: Any):
    """Dispatch one exact portable v1.3 ETQ record to the independent verifier."""

    document = _object(record, "lifecycle record")
    envelope = _closed(
        verification_inputs,
        "lifecycle verification inputs",
        (
            "verification_profile", "first_release_attribution", "verifier_operation",
            "record_type", "record_hash", "inputs",
        ),
    )
    if envelope["verification_profile"] != "crg-lifecycle/independent-replay@1":
        raise CaseError("unsupported lifecycle verification profile")
    if envelope["record_type"] != document.get("record_type"):
        raise CaseError("lifecycle verification record_type does not match the record")
    if envelope["first_release_attribution"] != _RECORD_WORKSTREAM.get(document.get("record_type")):
        raise CaseError("lifecycle verification inputs carry incorrect first-release attribution")
    if envelope["record_hash"] != content_hash(document):
        raise CaseError("lifecycle verification inputs are bound to different record bytes")
    inputs = _object(envelope["inputs"], "lifecycle verifier inputs.inputs")
    operation = envelope["verifier_operation"]
    expected_fields = _VERIFIER_INPUT_FIELDS.get(operation)
    if expected_fields is None:
        raise CaseError(f"unsupported lifecycle verifier operation {operation!r}")
    if set(inputs) != expected_fields:
        raise CaseError(
            f"{operation} requires exact replay fields {sorted(expected_fields)}; "
            f"found {sorted(inputs)}"
        )
    dispatch = {
        "verify_etq_decision_loop": lambda: crg_verify.verify_etq_decision_loop(document),
        "verify_result_ingestion_record": lambda: crg_verify.verify_result_ingestion_record(
            document, inputs["result_record"], inputs["new_evidence"],
            inputs.get("prior_evidence", ()),
        ),
        "verify_selective_revalidation_record": lambda: (
            crg_verify.verify_selective_revalidation_record(
                document, inputs["dependency_edges"], inputs["artifact_universe"],
            )
        ),
        "verify_replacement_record": lambda: crg_verify.verify_replacement_record(
            document, inputs["revalidation_record"], inputs["prior_artifact"],
            inputs["replacement_artifact"], inputs["dependency_edges"],
            inputs["artifact_universe"],
        ),
        "verify_qualification_disposition": lambda: (
            crg_verify.verify_qualification_disposition(
                document, inputs["qualification_result"], inputs["ingestions"],
                inputs["required_evidence_ids"], inputs["verification_basis"],
                minimum_evidence_status=inputs["minimum_evidence_status"],
            )
        ),
    }
    result = dispatch[operation]()
    if not result.ok:
        detail = "; ".join(result.violations) or result.status
        raise LifecycleVerificationError(
            f"independent lifecycle replay failed; no record may be published: {detail}"
        )
    return result


def _stored_record(case: Mapping[str, Any], record_type: str, identity: str) -> dict:
    records = case.get("lifecycle_records") or {}
    by_type = records.get(record_type) if isinstance(records, Mapping) else None
    raw = by_type.get(identity) if isinstance(by_type, Mapping) else None
    if not isinstance(raw, Mapping):
        raise CaseError(f"no lifecycle {record_type} {identity!r} exists in this case")
    return copy.deepcopy(dict(raw))


def _stored_inputs(case: Mapping[str, Any], record_type: str, identity: str) -> dict:
    inventory = case.get("lifecycle_verification_inputs") or {}
    by_type = inventory.get(record_type) if isinstance(inventory, Mapping) else None
    raw = by_type.get(identity) if isinstance(by_type, Mapping) else None
    if not isinstance(raw, Mapping):
        raise CaseError(
            f"lifecycle {record_type} {identity!r} has no retained independent-verifier inputs"
        )
    return copy.deepcopy(dict(raw))


def _build_etq_lifecycle(
    operation: str, raw: Any, case: Mapping[str, Any]
) -> Tuple[dict, dict, Tuple[Tuple[str, dict], ...]]:
    """Build one v1.3 ETQ-lifecycle record and its independent-replay inputs."""

    if operation not in ETQ_LIFECYCLE_OPERATIONS:
        raise CaseError(f"unsupported v1.3 ETQ lifecycle operation {operation!r}")

    if operation == "CREATE_ETQ_LOOP":
        value = _closed(
            raw, operation,
            ("loop_id", "target_decision_id", "predicate_id", "target_context", "declared_stopping_conditions"),
        )
        loop = ETQDecisionLoop(
            value["loop_id"], value["target_decision_id"], value["predicate_id"],
            content_hash(value["target_context"]), tuple(value["declared_stopping_conditions"]),
        )
        record = loop.to_canonical()
        inputs = _verification_inputs("verify_etq_decision_loop", record)
        return record, inputs, ()

    if operation == "APPEND_ETQ_STEP":
        value = _closed(
            raw, operation, ("loop_id", "authority", "verification_basis"),
            ("artifacts", "refusal"),
        )
        prior_doc = _stored_record(case, "ETQDecisionLoop", value["loop_id"])
        loop = _loop(prior_doc, "stored ETQDecisionLoop")
        artifacts = []
        prior_outputs = tuple(
            output.content_hash for output in (loop.steps[-1].outputs if loop.steps else ())
        )
        for index, raw_artifact in enumerate(value.get("artifacts") or ()):
            artifact = _closed(
                raw_artifact, f"{operation}.artifacts[{index}]",
                ("artifact_id", "artifact_type", "content"), ("status", "evidence_class"),
            )
            artifacts.append(
                LoopArtifactRef(
                    artifact["artifact_id"], artifact["artifact_type"], content_hash(artifact["content"]),
                    prior_outputs, artifact.get("status", "ACTIVE"), artifact.get("evidence_class", "DECLARED"),
                )
            )
        refusal = value.get("refusal")
        refusal_value = _closed(refusal, f"{operation}.refusal", ("code", "detail")) if refusal is not None else {}
        step = ETQStepRecord(
            loop.next_step or "", tuple(artifacts), prior_outputs, value["authority"],
            tuple(value["verification_basis"]), refusal_value.get("code"), refusal_value.get("detail", ""),
        )
        record = loop.append(step).to_canonical()
        inputs = _verification_inputs("verify_etq_decision_loop", record)
        return record, inputs, ()

    if operation == "INGEST_RESULT":
        value = _closed(
            raw, operation,
            ("result", "ingestion_id", "plan_id", "evidence_id", "method", "provenance", "validity", "access"),
            ("evidence_status", "prior_evidence"),
        )
        result = _experiment_result(value["result"], f"{operation}.result")
        result_doc = result.to_canonical()
        prior = tuple(
            _evidence(item, f"{operation}.prior_evidence[{index}]")
            for index, item in enumerate(value.get("prior_evidence") or ())
        )
        new_evidence, ingestion = ingest_result_as_evidence(
            result,
            ingestion_id=value["ingestion_id"], plan_id=value["plan_id"], evidence_id=value["evidence_id"],
            method=_method(value["method"], f"{operation}.method"),
            provenance=_provenance(
                value["provenance"], f"{operation}.provenance",
                derived_result_hash=content_hash(result_doc),
            ),
            validity=_validity(value["validity"], f"{operation}.validity"),
            access=_access(value["access"], f"{operation}.access"),
            evidence_status=value.get("evidence_status", "PROVISIONAL"), prior_evidence=prior,
        )
        record, evidence_doc = ingestion.to_canonical(), new_evidence.to_canonical()
        inputs = _verification_inputs(
            "verify_result_ingestion_record", record,
            result_record=result_doc, new_evidence=evidence_doc,
            prior_evidence=[item.to_canonical() for item in prior],
        )
        return record, inputs, ((f"evidence:{new_evidence.evidence_id}", evidence_doc),)

    if operation == "PLAN_REVALIDATION":
        value = _closed(
            raw, operation,
            ("record_id", "changed_source", "changed_properties", "dependency_edges", "artifact_universe", "dependency_completeness_basis"),
        )
        edges = tuple(
            _dependency_edge(item, f"{operation}.dependency_edges[{index}]")
            for index, item in enumerate(value["dependency_edges"])
        )
        plan = plan_selective_revalidation(
            record_id=value["record_id"], changed_source=value["changed_source"],
            changed_properties=value["changed_properties"], dependency_edges=edges,
            artifact_universe=value["artifact_universe"],
            dependency_completeness_basis=value["dependency_completeness_basis"],
        )
        record = plan.to_canonical()
        inputs = _verification_inputs(
            "verify_selective_revalidation_record", record,
            dependency_edges=[edge.to_canonical() for edge in edges],
            artifact_universe=list(value["artifact_universe"]),
        )
        return record, inputs, ()

    if operation == "ISSUE_REPLACEMENT":
        value = _closed(
            raw, operation,
            ("revalidation_record_id", "replacement_id", "prior_artifact_id", "replacement_artifact_id", "prior_artifact", "replacement_artifact", "verification_basis"),
        )
        revalidation_doc = _stored_record(
            case, "SelectiveRevalidationRecord", value["revalidation_record_id"]
        )
        revalidation_inputs = _stored_inputs(
            case, "SelectiveRevalidationRecord", value["revalidation_record_id"]
        )["inputs"]
        plan = _revalidation(revalidation_doc, f"{operation}.revalidation_record")
        replacement = issue_replacement(
            plan,
            replacement_id=value["replacement_id"], prior_artifact_id=value["prior_artifact_id"],
            replacement_artifact_id=value["replacement_artifact_id"],
            prior_artifact_hash=content_hash(value["prior_artifact"]),
            replacement_artifact_hash=content_hash(value["replacement_artifact"]),
            verification_basis=value["verification_basis"],
        )
        record = replacement.to_canonical()
        inputs = _verification_inputs(
            "verify_replacement_record", record,
            revalidation_record=revalidation_doc, prior_artifact=value["prior_artifact"],
            replacement_artifact=value["replacement_artifact"],
            dependency_edges=revalidation_inputs["dependency_edges"],
            artifact_universe=revalidation_inputs["artifact_universe"],
        )
        return record, inputs, ()

    if operation == "QUALIFICATION_DISPOSITION":
        value = _closed(
            raw, operation,
            ("qualification_result", "ingestions", "required_evidence_ids", "verification_basis"),
            ("minimum_evidence_status",),
        )
        result = _qualification_result(value["qualification_result"], f"{operation}.qualification_result")
        ingestions = tuple(
            _ingestion(item, f"{operation}.ingestions[{index}]")
            for index, item in enumerate(value["ingestions"])
        )
        minimum = value.get("minimum_evidence_status", "QUALIFIED")
        disposition = qualification_disposition(
            result, ingestions=ingestions, required_evidence_ids=value["required_evidence_ids"],
            verification_basis=value["verification_basis"], minimum_evidence_status=minimum,
        )
        record = disposition.to_canonical()
        inputs = _verification_inputs(
            "verify_qualification_disposition", record,
            qualification_result=result.to_canonical(),
            ingestions=[item.to_canonical() for item in ingestions],
            required_evidence_ids=list(value["required_evidence_ids"]),
            verification_basis=list(value["verification_basis"]), minimum_evidence_status=minimum,
        )
        return record, inputs, ()

    raise CaseError(f"unsupported v1.3 ETQ lifecycle operation {operation!r}")



def _build(
    operation: str,
    raw: Any,
    case: Mapping[str, Any],
) -> Tuple[dict, dict, Tuple[Tuple[str, dict], ...]]:
    """Dispatch only to the v1.3 ETQ producer family."""

    if operation in ETQ_LIFECYCLE_OPERATIONS:
        return _build_etq_lifecycle(operation, raw, case)
    raise CaseError(f"unsupported v1.3 ETQ lifecycle operation {operation!r}")


def build_verified_lifecycle_record(
    request: Any, case: Mapping[str, Any] | None = None, *,
    authority_snapshot: Any = None,
    producer_crypto_judgment: Any = None,
    validity_source: Any = None,
) -> Tuple[dict, dict, Any, Tuple[Tuple[str, dict], ...]]:
    """Produce and independently replay one lifecycle record."""

    value = _closed(request, "lifecycle request", ("operation", "inputs"))
    operation = value["operation"]
    if operation not in LIFECYCLE_OPERATIONS:
        raise CaseError(
            f"unknown lifecycle operation {operation!r}; expected one of {list(LIFECYCLE_OPERATIONS)}"
        )
    try:
        if any(item is not None for item in (
            authority_snapshot, producer_crypto_judgment, validity_source,
        )):
            raise CaseError("v1.3 ETQ lifecycle accepts no successor trust inputs")
        record, inputs, companions = _build(operation, value["inputs"], case or {})
        verification = verify_lifecycle_record(record, inputs)
    except LifecycleVerificationError:
        raise
    except (KeyError, TypeError, ValueError) as error:
        raise CaseError(f"{operation} request is invalid: {error}") from error
    return record, inputs, verification, companions


def _identity(record: Mapping[str, Any]) -> Tuple[str, str]:
    record_type = str(record.get("record_type") or "")
    if record_type in _CONTENT_IDENTIFIED_RECORDS:
        return record_type, content_hash(record)
    field = _IDENTITY_FIELDS.get(record_type)
    if field is None:
        raise CaseError(f"unsupported lifecycle record_type {record_type!r}")
    identity = str(record.get(field) or "").strip()
    if not identity:
        raise CaseError(f"lifecycle {record_type} has no {field}")
    return record_type, identity


def persist_lifecycle_record(
    case: MutableMapping[str, Any],
    record: Mapping[str, Any],
    verification_inputs: Mapping[str, Any],
    companions: Sequence[Tuple[str, Mapping[str, Any]]] = (),
) -> Tuple[str, str]:
    """Persist a verified immutable version and its exact replay inputs."""

    verification = verify_lifecycle_record(record, verification_inputs)
    record_type, identity = _identity(record)
    canonical = copy.deepcopy(dict(record))
    existing = ((case.get("lifecycle_records") or {}).get(record_type) or {}).get(identity)
    if existing is not None and content_hash(existing) != content_hash(canonical):
        if record_type != "ETQDecisionLoop":
            raise CaseError(
                f"lifecycle {record_type} {identity!r} already names different content; "
                "use a new immutable identity"
            )
        prior_steps = existing.get("steps") if isinstance(existing, Mapping) else None
        next_steps = canonical.get("steps")
        if not isinstance(prior_steps, list) or not isinstance(next_steps, list) or next_steps[: len(prior_steps)] != prior_steps or len(next_steps) != len(prior_steps) + 1:
            raise CaseError("an ETQ loop update must be exactly one immutable-prefix append")
    # Preflight every companion before changing any case dictionary.  Snapshot
    # identity conflicts therefore fail atomically rather than leaving a
    # published record whose portable companions were only partly written.
    prepared_companions: Dict[str, dict] = {}
    existing_companions = case.get("lifecycle_companion_objects") or {}
    if not isinstance(existing_companions, Mapping):
        raise CaseError("lifecycle_companion_objects must be an object")
    for object_id, document in companions:
        name = str(object_id).strip()
        if not name:
            raise CaseError("lifecycle companion identity must be a non-empty string")
        canonical_companion = _object(document, f"lifecycle companion {name!r}")
        prior = prepared_companions.get(name)
        if prior is None:
            prior = existing_companions.get(name)
        if prior is not None and content_hash(prior) != content_hash(canonical_companion):
            raise CaseError(f"lifecycle companion {name!r} already names different bytes")
        prepared_companions[name] = canonical_companion
    root = content_hash(canonical)
    case.setdefault("lifecycle_record_versions", {}).setdefault(record_type, {})[root] = canonical
    case.setdefault("lifecycle_verification_input_versions", {}).setdefault(record_type, {})[root] = copy.deepcopy(dict(verification_inputs))
    case.setdefault("lifecycle_records", {}).setdefault(record_type, {})[identity] = canonical
    case.setdefault("lifecycle_verification_inputs", {}).setdefault(record_type, {})[identity] = copy.deepcopy(dict(verification_inputs))
    if prepared_companions:
        objects = case.setdefault("lifecycle_companion_objects", {})
        for object_id, document in prepared_companions.items():
            objects[object_id] = copy.deepcopy(document)
    record_history(
        case,
        "lifecycle publish",
        {
            "record_type": record_type,
            "record_id": identity,
            "record_hash": root,
            "independently_verified": True,
            "verifier_status": verification.status,
            "mutation_effect": "APPEND_ONLY_RECORD",
        },
    )
    return record_type, identity


def inspect_lifecycle_record(case: Mapping[str, Any], record_type: str, identity: str) -> dict:
    record = _stored_record(case, record_type, identity)
    inputs = _stored_inputs(case, record_type, identity)
    verification = verify_lifecycle_record(record, inputs)
    return {
        "record": record,
        "verification_inputs": inputs,
        "verification": verification.to_json(),
        "direct_state": {
            key: copy.deepcopy(record[key])
            for key in _DIRECT_STATE_FIELDS.get(record_type, ())
            if key in record
        },
        "report": render_lifecycle_report(record, verification),
    }



def portable_lifecycle_objects(case: Mapping[str, Any]) -> Dict[str, Any]:
    """Return verified current/versioned v1.3 ETQ records and companions."""

    objects: Dict[str, Any] = {}
    versions = case.get("lifecycle_record_versions") or {}
    input_versions = case.get("lifecycle_verification_input_versions") or {}
    if isinstance(versions, Mapping):
        for record_type, by_hash in sorted(versions.items()):
            if record_type not in ETQ_LIFECYCLE_RECORD_TYPES or not isinstance(by_hash, Mapping):
                continue
            for root, record in sorted(by_hash.items()):
                if not isinstance(record, Mapping):
                    continue
                inputs = (
                    (input_versions.get(record_type) or {}).get(root)
                    if isinstance(input_versions, Mapping) else None
                )
                if not isinstance(inputs, Mapping):
                    raise CaseError(
                        f"lifecycle version {record_type} {root} lacks verifier inputs"
                    )
                verify_lifecycle_record(record, inputs)
                token = root.split(":", 1)[-1]
                objects[f"lifecycle:{record_type}:{token}"] = copy.deepcopy(dict(record))
                objects[f"lifecycle-verification-inputs:{record_type}:{token}"] = (
                    copy.deepcopy(dict(inputs))
                )
    companions = case.get("lifecycle_companion_objects") or {}
    if isinstance(companions, Mapping):
        for object_id, document in sorted(companions.items()):
            if isinstance(document, Mapping):
                objects[f"lifecycle-companion:{object_id}"] = copy.deepcopy(dict(document))
    return objects


def render_lifecycle_report(record: Mapping[str, Any], verification: Any = None) -> str:
    record_type, identity = _identity(record)
    lines = [
        "CRG v1.3 ETQ LIFECYCLE RECORD",
        "=" * 29,
        "",
        f"Record type: {record_type}",
        f"Identity: {identity}",
        f"Record hash: {content_hash(record)}",
        f"Profile: {record.get('profile', 'not stated')}@{record.get('schema_version', 'not stated')}",
        f"First release: {_RECORD_WORKSTREAM[record_type]}",
        "Mutation effect: APPEND_ONLY_RECORD",
        "Commercial inference: NONE — no ROI, savings, or superiority is inferred.",
    ]
    direct = _DIRECT_STATE_FIELDS.get(record_type, ())
    if direct:
        lines.extend(["", "DIRECT STATES"])
        for field in direct:
            if field in record:
                lines.append(f"- {field}: {record[field]}")
    if record.get("claim_boundary"):
        lines.extend(["", "CLAIM BOUNDARY", str(record["claim_boundary"])])
    else:
        lines.extend(
            [
                "",
                "Claim boundary: this record states only its registered lifecycle facts; it does not imply ROI, confidence, readiness, or undeclared decision effect.",
            ]
        )
    if verification is not None:
        lines.extend(["", "INDEPENDENT VERIFICATION", f"Status: {verification.status}"])
        for name, passed, detail in verification.checks:
            lines.append(f"- {name}: {'PASS' if passed else 'FAIL'} — {detail}")
    return "\n".join(lines) + "\n"
