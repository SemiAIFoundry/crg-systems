"""Product-boundary helpers for portable comparative workflow evidence.

CRG-ENH-03 compares observed workflows over one declared, finite workload.
It does not authorize a decision, rank a method, or infer economic value.
This module keeps the CLI and server on one closed authoring contract and,
critically, runs the independent verifier before a record can be returned or
published into a successor case.
"""
from __future__ import annotations

import copy
from typing import Any, Dict, Mapping, Tuple

import crg_certify
import crg_verify
from crg_model.canonical import content_hash

from .store import CaseError, record_history

__all__ = [
    "COMPARISON_REQUEST_FIELDS",
    "COMPARISON_REQUIRED_FIELDS",
    "ComparativeVerificationError",
    "build_verified_comparative_evaluation",
    "comparative_verification_inputs",
    "persist_comparative_evaluation",
    "portable_comparison_objects",
    "render_comparative_evaluation_report",
]


COMPARISON_REQUEST_FIELDS = frozenset(
    {
        "evaluation_id",
        "inputs",
        "realization_family_input_id",
        "decision_family_input_id",
        "technology_scope",
        "evidence_scope",
        "change_scope",
        "scenario_scope",
        "held_out_treatment",
        "workload",
        "oracle",
        "methods",
        "limitations",
        "local_observations",
        "declared_counterfactuals",
    }
)
COMPARISON_REQUIRED_FIELDS = frozenset(
    COMPARISON_REQUEST_FIELDS - {"local_observations", "declared_counterfactuals"}
)


class ComparativeVerificationError(CaseError):
    """The independent implementation disagreed with a produced record."""


def _closed_request(request: Any) -> Dict[str, Any]:
    if not isinstance(request, Mapping):
        raise CaseError("comparative workflow request must be a JSON object")
    unsupported = sorted(set(request) - COMPARISON_REQUEST_FIELDS)
    if unsupported:
        raise CaseError(
            "comparative workflow request contains unsupported field(s): "
            + ", ".join(unsupported)
            + "; callers cannot supply derived facts, authority, conclusions, or hashes"
        )
    missing = sorted(COMPARISON_REQUIRED_FIELDS - set(request))
    if missing:
        raise CaseError(
            "comparative workflow request is missing required field(s): "
            + ", ".join(missing)
        )
    return copy.deepcopy(dict(request))


def build_verified_comparative_evaluation(request: Any) -> Tuple[dict, Any]:
    """Build and independently reconstruct one non-authorizing evaluation."""

    value = _closed_request(request)
    inputs = value.get("inputs")
    if not isinstance(inputs, Mapping) or not inputs:
        raise CaseError("comparative workflow inputs must be a non-empty JSON object")
    bindings = {str(name): content_hash(document) for name, document in inputs.items()}
    # Product surfaces may ask the system to derive portable content bindings
    # from the very input documents being embedded. This is safer and easier
    # to author than copying digests between fields; the canonical producer
    # still receives the same explicit mapping and binds it into the record.
    oracle = value.get("oracle")
    if isinstance(oracle, Mapping) and oracle.get("input_bindings") == (
        "DERIVE_FROM_EMBEDDED_INPUTS"
    ):
        value["oracle"] = {**dict(oracle), "input_bindings": dict(bindings)}
    methods = value.get("methods")
    if isinstance(methods, list):
        value["methods"] = [
            {
                **dict(method),
                "input_bindings": dict(bindings),
            }
            if isinstance(method, Mapping)
            and method.get("input_bindings") == "DERIVE_FROM_EMBEDDED_INPUTS"
            else method
            for method in methods
        ]
    evaluation_id = value.pop("evaluation_id")
    artifact = crg_certify.build_comparative_workflow_evaluation(
        evaluation_id,
        **value,
    ).to_canonical()
    verification = crg_verify.verify_comparative_workflow_evaluation(artifact)
    if not verification.ok:
        detail = "; ".join(verification.violations) or verification.status
        raise ComparativeVerificationError(
            "independent comparative-workflow reconstruction failed; no record was "
            f"published: {detail}"
        )
    return artifact, verification


def comparative_verification_inputs(record: Mapping[str, Any]) -> dict:
    """The exact self-contained input consumed by the independent verifier.

    Unlike a certified delta, the comparison profile embeds every raw trace,
    input document, binding, budget, denominator, and oracle answer in the
    record.  The verifier therefore needs exactly one input: that record.  We
    still store this explicit envelope so an export consumer does not need to
    infer the verifier call signature from a product-specific case layout.
    """

    return {
        "verification_profile": "crg-comparative-workflow/finite-exact@1",
        "verifier_operation": "verify_comparative_workflow_evaluation",
        "evaluation_id": str(record.get("evaluation_id") or ""),
        "record_hash": str(record.get("record_hash") or content_hash(record)),
        "record": copy.deepcopy(dict(record)),
    }


def persist_comparative_evaluation(case: Dict[str, Any], record: Mapping[str, Any]) -> dict:
    """Attach a verified record and its exact verifier input to a successor case."""

    if record.get("record_type") != "ComparativeWorkflowEvaluation":
        raise CaseError("only a ComparativeWorkflowEvaluation may be persisted here")
    evaluation_id = str(record.get("evaluation_id") or "").strip()
    if not evaluation_id:
        raise CaseError("comparative evaluation has no evaluation_id")
    existing = (case.get("comparative_evaluations") or {}).get(evaluation_id)
    if existing is not None and content_hash(existing) != content_hash(record):
        raise CaseError(
            f"comparative evaluation {evaluation_id!r} already names different content; "
            "use a new evaluation identity"
        )
    canonical = copy.deepcopy(dict(record))
    inputs = comparative_verification_inputs(canonical)
    case.setdefault("comparative_evaluations", {})[evaluation_id] = canonical
    case.setdefault("comparative_evaluation_verification_inputs", {})[
        evaluation_id
    ] = inputs
    record_history(
        case,
        "comparison generate",
        {
            "evaluation_id": evaluation_id,
            "record_hash": canonical["record_hash"],
            "authority": "NON_AUTHORIZING",
            "semantic_effect": "NONE",
            "independently_verified": True,
        },
    )
    return inputs


def portable_comparison_objects(case: Mapping[str, Any]) -> Dict[str, Any]:
    """Return the comparison inventory objects a portable bundle must carry."""

    objects: Dict[str, Any] = {}
    records = case.get("comparative_evaluations") or {}
    stored_inputs = case.get("comparative_evaluation_verification_inputs") or {}
    if not isinstance(records, Mapping) or not isinstance(stored_inputs, Mapping):
        return objects
    for evaluation_id, raw in sorted(records.items(), key=lambda item: str(item[0])):
        if not isinstance(raw, Mapping):
            continue
        identity = str(evaluation_id)
        record = copy.deepcopy(dict(raw))
        objects[f"comparative-evaluation:{identity}"] = record
        inputs = stored_inputs.get(evaluation_id)
        if not isinstance(inputs, Mapping):
            inputs = comparative_verification_inputs(record)
        objects[f"comparative-verification-inputs:{identity}"] = copy.deepcopy(dict(inputs))
    return objects


def _exact_text(value: Any) -> str:
    if isinstance(value, Mapping) and set(value) == {"exact"}:
        return str(value["exact"])
    return str(value)


def render_comparative_evaluation_report(
    record: Mapping[str, Any], verification: Any = None
) -> str:
    """Render a deterministic, claim-bounded public comparison report.

    Methods are listed by identity and never ordered by any result.  No
    between-method delta is calculated here; all numbers are the facts already
    bound to each method's own declared trace and registered denominators.
    """

    lines = [
        "CRG COMPARATIVE WORKFLOW EVALUATION",
        "=" * 35,
        "",
        f"Evaluation: {record.get('evaluation_id', 'not stated')}",
        f"Record hash: {record.get('record_hash', 'not stated')}",
        "Authority: NON_AUTHORIZING",
        "Semantic effect: NONE",
        f"Design comparability: {(record.get('comparability') or {}).get('status', 'UNKNOWN')}",
        "Conclusion: NO_METHOD_RANKING_OR_AUTHORIZING_CONCLUSION",
        "",
        "CLAIM BOUNDARY",
        str(record.get("claim_boundary") or "not stated"),
        "",
        "SCOPE AND DENOMINATORS",
        f"Scope hash: {(record.get('scope') or {}).get('scope_hash', 'not stated')}",
    ]
    reasons = (record.get("comparability") or {}).get("reasons") or []
    lines.append(
        "Design comparability reasons: " + (", ".join(str(item) for item in reasons) or "none")
    )
    results = {
        str(item.get("method_id")): item
        for item in record.get("results") or []
        if isinstance(item, Mapping)
    }
    first_result = next(iter(results.values()), {})
    for name, denominator in (first_result.get("denominators") or {}).items():
        if not isinstance(denominator, Mapping):
            continue
        lines.append(
            f"- {name}: {_exact_text(denominator.get('value'))} "
            f"{denominator.get('unit', '')}; "
            f"{len(denominator.get('members') or [])} explicitly listed members"
        )
    for method in record.get("methods") or []:
        if not isinstance(method, Mapping):
            continue
        method_id = str(method.get("method_id") or "not stated")
        result = results.get(method_id) or {}
        facts = result.get("system_derived_facts") or {}
        lines.extend(
            [
                "",
                f"METHOD: {method_id}",
                f"Name: {method.get('name', 'not stated')}",
                f"Version: {method.get('version', 'not stated')}",
                f"Workflow: {method.get('workflow', 'not stated')}",
                f"Method hash: {method.get('method_hash', 'not stated')}",
                f"Retention burden: {_exact_text((facts.get('retention_burden') or {}).get('retained_memberships'))} / "
                f"{_exact_text((facts.get('retention_burden') or {}).get('fraction'))}",
                f"Oracle misses: {_exact_text((facts.get('oracle_misses') or {}).get('count'))} / "
                f"{_exact_text((facts.get('oracle_misses') or {}).get('fraction'))}",
                f"Regret total / maximum / mean: "
                f"{_exact_text((facts.get('regret') or {}).get('total'))} / "
                f"{_exact_text((facts.get('regret') or {}).get('maximum'))} / "
                f"{_exact_text((facts.get('regret') or {}).get('mean'))}",
                f"Affected / preserved / invalidated work: "
                f"{_exact_text((facts.get('affected_work') or {}).get('count'))} / "
                f"{_exact_text((facts.get('preserved_work') or {}).get('count'))} / "
                f"{_exact_text((facts.get('invalidated_work') or {}).get('count'))}",
                f"Verified attempts: {_exact_text((facts.get('verification') or {}).get('verified_count'))} / "
                f"{_exact_text((facts.get('verification') or {}).get('fraction'))}",
            ]
        )
    lines.extend(["", "LIMITATIONS"])
    lines.extend(f"- {item}" for item in record.get("limitations") or ["not stated"])
    lines.extend(
        [
            "",
            "EVIDENCE LABELS",
            f"Local observations: {len(record.get('local_observations') or [])} "
            "(operator-declared; not system-derived)",
            f"Declared counterfactuals: {len(record.get('declared_counterfactuals') or [])} "
            "(user-declared; not system-derived)",
        ]
    )
    for observation in record.get("local_observations") or []:
        lines.append(
            "- LOCAL OBSERVATION "
            f"{observation.get('observation_id', 'not stated')}: method="
            f"{observation.get('method_id', 'not stated')}; metric="
            f"{observation.get('metric', 'not stated')}; value="
            f"{_exact_text(observation.get('value'))} {observation.get('unit', '')}; "
            f"observer={observation.get('observer', 'not stated')}"
        )
    for assertion in record.get("declared_counterfactuals") or []:
        lines.append(
            "- DECLARED COUNTERFACTUAL "
            f"{assertion.get('assertion_id', 'not stated')}: "
            f"{assertion.get('statement', 'not stated')} "
            f"(provenance: {assertion.get('provenance', 'not stated')})"
        )
    lines.extend(
        [
            "",
            "INDEPENDENT VERIFICATION",
            str(getattr(verification, "status", "not run in this rendering")),
        ]
    )
    return "\n".join(lines) + "\n"
