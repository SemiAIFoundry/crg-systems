"""Closed product boundary for portable Decision Challenge records.

Decision Challenge is an explicitly non-authorizing orchestration over the
phase and certified-delta evidence already held by a case.  This module gives
the CLI, server, SDKs, and Studio one authoring contract without accepting a
caller-supplied baseline, outcome, winner, minimum action, authority, or
verification status.  Those facts are reconstructed from stored portable
evidence and independently replayed before a record may be returned.
"""
from __future__ import annotations

import copy
import json
import os
import tempfile
from typing import Any, Dict, Mapping, Tuple

import crg_verify
from crg_change import (
    ChallengeStatus,
    build_decision_challenge,
    build_decision_challenge_refusal,
    registered_challenge_mutations,
    registered_challenge_previews,
)
from crg_model.canonical import canonical_json, content_hash

from .store import CaseError, case_dir

__all__ = [
    "CHALLENGE_REQUEST_FIELDS",
    "CHALLENGE_OPERATION_FIELDS",
    "DecisionChallengeVerificationError",
    "build_verified_decision_challenge",
    "persist_decision_challenge",
    "list_decision_challenges",
    "read_decision_challenge",
    "portable_decision_challenge_objects",
    "render_decision_challenge_report",
]


CHALLENGE_REQUEST_FIELDS = frozenset(
    {"challenge_id", "evidence_id", "operations", "promotion_request", "refusal"}
)
CHALLENGE_OPERATION_FIELDS = frozenset(
    {"operation_id", "mutation_type", "preview_operation", "target_path", "input"}
)
_PROMOTION_FIELDS = frozenset(
    {"request_id", "governed_operation", "requested_by", "reason"}
)
_REFUSAL_FIELDS = frozenset(
    {"status", "reason_code", "detail", "attempted_input"}
)


class DecisionChallengeVerificationError(CaseError):
    """The independent challenge verifier disagreed with the producer."""


def _identity(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value.strip() or value != value.strip():
        raise CaseError(f"{field} must be a normalized non-empty string")
    return value


def _closed_object(value: Any, fields: frozenset[str], name: str) -> Dict[str, Any]:
    if not isinstance(value, Mapping):
        raise CaseError(f"{name} must be a JSON object")
    unknown = sorted(set(value) - fields)
    missing = sorted(fields - set(value))
    if unknown:
        raise CaseError(f"{name} contains unsupported field(s): {', '.join(unknown)}")
    if missing:
        raise CaseError(f"{name} is missing required field(s): {', '.join(missing)}")
    return copy.deepcopy(dict(value))


def _closed_request(request: Any) -> Dict[str, Any]:
    if not isinstance(request, Mapping):
        raise CaseError("Decision Challenge request must be a JSON object")
    unknown = sorted(set(request) - CHALLENGE_REQUEST_FIELDS)
    if unknown:
        raise CaseError(
            "Decision Challenge request contains unsupported field(s): "
            + ", ".join(unknown)
            + "; callers cannot supply baselines, results, ranks, scores, authority, "
            "verification status, or mutation effects"
        )
    value = copy.deepcopy(dict(request))
    _identity(value.get("challenge_id"), "challenge_id")
    if "refusal" in value:
        if set(value) != {"challenge_id", "refusal"}:
            raise CaseError(
                "a typed Decision Challenge refusal requires exactly challenge_id and refusal"
            )
        refusal = _closed_object(value["refusal"], _REFUSAL_FIELDS, "refusal")
        _identity(refusal.get("detail"), "refusal.detail")
        value["refusal"] = refusal
        return value

    required = {"challenge_id", "evidence_id", "operations"}
    missing = sorted(required - set(value))
    if missing:
        raise CaseError(
            "Decision Challenge request is missing required field(s): " + ", ".join(missing)
        )
    _identity(value.get("evidence_id"), "evidence_id")
    operations = value.get("operations")
    if not isinstance(operations, list) or not operations:
        raise CaseError("operations must be a non-empty array of registered inputs")
    registry = registered_challenge_mutations()
    previews = set(registered_challenge_previews())
    normalized = []
    for index, raw in enumerate(operations):
        operation = _closed_object(
            raw, CHALLENGE_OPERATION_FIELDS, f"operations[{index}]"
        )
        mutation_type = _identity(
            operation.get("mutation_type"), f"operations[{index}].mutation_type"
        )
        if mutation_type not in registry:
            raise CaseError(f"unregistered Decision Challenge mutation {mutation_type!r}")
        preview = _identity(
            operation.get("preview_operation"),
            f"operations[{index}].preview_operation",
        )
        if preview not in previews:
            raise CaseError(f"unregistered Decision Challenge preview {preview!r}")
        if not isinstance(operation.get("input"), Mapping):
            raise CaseError(f"operations[{index}].input must be a JSON object")
        normalized.append(
            {
                **operation,
                "input_profile": registry[mutation_type]["input_profile"],
            }
        )
    value["operations"] = normalized
    if "promotion_request" in value:
        value["promotion_request"] = _closed_object(
            value["promotion_request"], _PROMOTION_FIELDS, "promotion_request"
        )
    return value


def _stored_delta(case: Mapping[str, Any], evidence_id: str) -> Tuple[dict, dict]:
    records = case.get("certified_deltas") or {}
    inputs = case.get("certified_delta_inputs") or {}
    if not isinstance(records, Mapping) or evidence_id not in records:
        raise CaseError(
            f"no CertifiedDeltaRecord {evidence_id!r} is stored on this case"
        )
    record = records[evidence_id]
    verifier_inputs = inputs.get(evidence_id) if isinstance(inputs, Mapping) else None
    if not isinstance(record, Mapping) or not isinstance(verifier_inputs, Mapping):
        raise CaseError(
            f"CertifiedDeltaRecord {evidence_id!r} lacks its exact portable replay inputs"
        )
    if record.get("evidence_id") != evidence_id:
        raise CaseError(
            f"CertifiedDeltaRecord {evidence_id!r} is stored under a mismatched identity"
        )
    required = {
        "prior_case", "current_case", "dependency_edges", "replacements",
        "prior_phase", "current_phase", "prior_phase_source_r",
        "current_phase_source_r",
    }
    missing = sorted(required - set(verifier_inputs))
    if missing:
        raise CaseError(
            f"CertifiedDeltaRecord {evidence_id!r} replay inputs omit {missing}"
        )
    return copy.deepcopy(dict(record)), copy.deepcopy(dict(verifier_inputs))


def _evidence(case: Mapping[str, Any], evidence_id: str) -> Tuple[dict, dict, dict]:
    delta, inputs = _stored_delta(case, evidence_id)
    phase = inputs.get("current_phase")
    source = inputs.get("current_phase_source_r")
    if not isinstance(phase, Mapping) or not isinstance(source, Mapping):
        raise CaseError(
            "Decision Challenge requires the stored delta's registered current-phase "
            "artifact and portable source R"
        )
    phase_verification = crg_verify.verify_phase_analysis_record(phase, source)
    if not phase_verification.ok:
        raise DecisionChallengeVerificationError(
            "stored phase evidence failed independent replay; no Decision Challenge "
            f"was published: {'; '.join(phase_verification.violations)}"
        )
    delta_verification = crg_verify.verify_certified_delta_record(
        delta,
        inputs["prior_case"],
        inputs["current_case"],
        inputs["dependency_edges"],
        replacements=inputs["replacements"],
        prior_phase=inputs["prior_phase"],
        current_phase=inputs["current_phase"],
        prior_phase_source_r=inputs["prior_phase_source_r"],
        current_phase_source_r=inputs["current_phase_source_r"],
    )
    if not delta_verification.ok:
        raise DecisionChallengeVerificationError(
            "stored certified-delta evidence failed independent replay; no Decision "
            f"Challenge was published: {'; '.join(delta_verification.violations)}"
        )
    phase_evidence = {
        "artifact": phase,
        "source_r": source,
        "verification_result": phase_verification.to_json(),
    }
    delta_evidence = {
        "artifact": delta,
        "current_case": inputs["current_case"],
        "dependency_edges": inputs["dependency_edges"],
        "replacements": inputs["replacements"],
        "prior_phase": inputs["prior_phase"],
        "current_phase": inputs["current_phase"],
        "prior_phase_source_r": inputs["prior_phase_source_r"],
        "current_phase_source_r": inputs["current_phase_source_r"],
        "verification_result": delta_verification.to_json(),
    }
    return inputs["prior_case"], phase_evidence, delta_evidence


def build_verified_decision_challenge(
    request: Any, case: Mapping[str, Any]
) -> Tuple[dict, Any]:
    """Produce and independently replay one non-authorizing challenge record."""

    value = _closed_request(request)
    challenge_id = value["challenge_id"]
    if "refusal" in value:
        refusal = value["refusal"]
        artifact = build_decision_challenge_refusal(
            challenge_id,
            baseline_case=case,
            status=refusal["status"],
            reason_code=refusal["reason_code"],
            detail=refusal["detail"],
            attempted_input=refusal["attempted_input"],
        ).to_canonical()
    else:
        baseline, phase_evidence, delta_evidence = _evidence(
            case, value["evidence_id"]
        )
        artifact = build_decision_challenge(
            challenge_id,
            baseline_case=baseline,
            operations=value["operations"],
            phase_evidence=phase_evidence,
            delta_evidence=delta_evidence,
            promotion_request=value.get("promotion_request"),
        ).to_canonical()
    verification = crg_verify.verify_decision_challenge_record(artifact)
    if not verification.ok:
        detail = "; ".join(verification.violations) or verification.status
        raise DecisionChallengeVerificationError(
            "independent Decision Challenge replay failed; no record was published: "
            + detail
        )
    return artifact, verification


def _ledger_paths(root: str, case_id: str) -> Tuple[str, str]:
    directory = os.path.join(case_dir(root, case_id), "decision-challenges")
    return directory, os.path.join(directory, "index.json")


def _atomic_write(path: str, document: Mapping[str, Any]) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(
        prefix=".crg-decision-challenge-", suffix=".tmp", dir=os.path.dirname(path)
    )
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(canonical_json(document) + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
        directory = os.open(
            os.path.dirname(path), os.O_RDONLY | getattr(os, "O_DIRECTORY", 0)
        )
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def _ledger(root: str, case_id: str) -> Dict[str, Any]:
    _directory, index_path = _ledger_paths(root, case_id)
    if not os.path.exists(index_path):
        return {
            "record_type": "DecisionChallengeLedger",
            "schema_version": "1.0.0",
            "case_id": case_id,
            "entries": {},
            "authority": "NON_AUTHORIZING",
            "semantic_effect": "NONE",
            "active_case_state": "UNCHANGED",
        }
    try:
        with open(index_path, encoding="utf-8") as handle:
            value = json.load(handle)
    except (OSError, ValueError) as error:
        raise CaseError(f"Decision Challenge ledger cannot be read: {error}") from error
    if (
        not isinstance(value, dict)
        or value.get("record_type") != "DecisionChallengeLedger"
        or value.get("case_id") != case_id
        or not isinstance(value.get("entries"), dict)
    ):
        raise CaseError("Decision Challenge ledger has an invalid closed envelope")
    return value


def persist_decision_challenge(
    root: str, case_id: str, record: Mapping[str, Any]
) -> str:
    """Persist to an auxiliary ledger without writing or versioning ``case.json``."""

    if record.get("record_type") != "DecisionChallengeRecord":
        raise CaseError("only a DecisionChallengeRecord may be persisted here")
    verification = crg_verify.verify_decision_challenge_record(record)
    if not verification.ok:
        detail = "; ".join(verification.violations) or verification.status
        raise DecisionChallengeVerificationError(
            "refusing to persist a Decision Challenge that failed independent replay: "
            + detail
        )
    challenge_id = _identity(record.get("challenge_id"), "challenge.challenge_id")
    canonical = copy.deepcopy(dict(record))
    digest = content_hash(canonical)
    directory, index_path = _ledger_paths(root, case_id)
    ledger = _ledger(root, case_id)
    existing = ledger["entries"].get(challenge_id)
    if existing is not None and existing.get("content_hash") != digest:
        raise CaseError(
            f"Decision Challenge {challenge_id!r} already names different content; "
            "use a new challenge identity"
        )
    object_path = os.path.join(
        directory, "objects", "sha256", digest.split(":", 1)[1][:2],
        digest.split(":", 1)[1] + ".json",
    )
    if not os.path.exists(object_path):
        _atomic_write(object_path, canonical)
    ledger["entries"][challenge_id] = {
        "content_hash": digest,
        "record_hash": canonical["record_hash"],
        "result_status": (canonical.get("result") or {}).get("status"),
        "object_path": os.path.relpath(object_path, directory),
        "authority": "NON_AUTHORIZING",
        "semantic_effect": "NONE",
        "active_case_mutated": False,
    }
    _atomic_write(index_path, ledger)
    return digest


def read_decision_challenge(root: str, case_id: str, challenge_id: str) -> dict:
    ledger = _ledger(root, case_id)
    entry = ledger["entries"].get(challenge_id)
    if not isinstance(entry, Mapping):
        raise CaseError(f"no Decision Challenge {challenge_id!r} in this case ledger")
    directory, _index_path = _ledger_paths(root, case_id)
    base = os.path.abspath(directory)
    path = os.path.abspath(os.path.join(base, str(entry.get("object_path") or "")))
    if os.path.commonpath((base, path)) != base:
        raise CaseError("Decision Challenge ledger contains an unsafe object path")
    try:
        with open(path, encoding="utf-8") as handle:
            record = json.load(handle)
    except (OSError, ValueError) as error:
        raise CaseError(f"Decision Challenge object cannot be read: {error}") from error
    if not isinstance(record, dict) or content_hash(record) != entry.get("content_hash"):
        raise CaseError("Decision Challenge object disagrees with its content-addressed ledger")
    if (
        record.get("record_type") != "DecisionChallengeRecord"
        or record.get("challenge_id") != challenge_id
        or record.get("record_hash") != entry.get("record_hash")
    ):
        raise CaseError("Decision Challenge object disagrees with its ledger identity")
    return record


def list_decision_challenges(root: str, case_id: str) -> Dict[str, Any]:
    ledger = _ledger(root, case_id)
    return {
        challenge_id: read_decision_challenge(root, case_id, challenge_id)
        for challenge_id in sorted(ledger["entries"])
    }


def portable_decision_challenge_objects(records: Mapping[str, Any]) -> Dict[str, Any]:
    """Return auxiliary challenge records for an explicitly assembled bundle."""

    result: Dict[str, Any] = {}
    if not isinstance(records, Mapping):
        return result
    for challenge_id, raw in sorted(records.items(), key=lambda item: str(item[0])):
        if isinstance(raw, Mapping):
            result[f"decision-challenge:{challenge_id}"] = copy.deepcopy(dict(raw))
    return result


def render_decision_challenge_report(
    record: Mapping[str, Any], verification: Any = None
) -> str:
    """Render a deterministic report with no score, ranking, or authority claim."""

    result = record.get("result") or {}
    no_mutation = record.get("no_mutation_guarantee") or {}
    verification_status = result.get("verification_status") or {}

    def _items(value: Any, empty: str = "none") -> str:
        if not isinstance(value, (list, tuple)) or not value:
            return empty
        return ", ".join(str(item) for item in value)

    lines = [
        "CRG DECISION CHALLENGE",
        "=" * 22,
        "",
        f"Challenge: {record.get('challenge_id', 'not stated')}",
        f"Record hash: {record.get('record_hash', 'not stated')}",
        f"Status: {result.get('status', 'UNKNOWN')}",
        "Authority: NON_AUTHORIZING",
        "Authorizing: false",
        "Semantic effect: NONE",
        "Score or ranking: NOT PRODUCED",
        f"Independent replay: {getattr(verification, 'status', 'not run')}",
        "",
        "CLAIM BOUNDARY",
        str(record.get("claim_boundary") or "not stated"),
        "",
        "FROZEN BASELINE AND MUTATION GUARANTEE",
        f"Baseline case root: {(record.get('baseline') or {}).get('case_root', 'not stated')}",
        f"Active case mutated: {str(no_mutation.get('active_case_mutated', False)).lower()}",
        f"Active case superseded: {str(no_mutation.get('active_case_superseded', False)).lower()}",
        f"Promotion executed: {str(no_mutation.get('promotion_executed', False)).lower()}",
        "Mutation performed: "
        f"{str(no_mutation.get('mutation_performed', False)).lower()}",
    ]
    refusal = record.get("refusal")
    if isinstance(refusal, Mapping):
        lines.extend(
            [
                "",
                "TYPED REFUSAL",
                f"Reason: {refusal.get('reason_code', 'not stated')}",
                f"Detail: {refusal.get('detail', 'not stated')}",
                "Disposition: NO PREVIEW, NO MUTATION; reopen or refuse.",
            ]
        )
    else:
        phase = result.get("phase") or {}
        change = result.get("change") or {}
        minimum = result.get("proposed_minimum_action") or {}
        regret = result.get("regret") or {}
        completeness = result.get("family_completeness") or {}
        lines.extend(["", "REGISTERED INPUTS"])
        for operation in record.get("operations") or []:
            lines.append(
                f"- {operation.get('sequence')}: {operation.get('mutation_type')} "
                f"at {operation.get('target_path')} via "
                f"{operation.get('preview_operation')} (mutation performed: false)"
            )
        lines.extend(
            [
                "",
                "INDEPENDENTLY RECONSTRUCTED PREVIEW",
                "Winner identity set (not ranked): "
                + _items(result.get("winner_ids"), "none stated"),
                "Challenge verification state: "
                + str(verification_status.get("challenge") or "not stated"),
                "Phase verification state: "
                + str(verification_status.get("phase") or "not stated"),
                "Delta verification state: "
                + str(verification_status.get("delta") or "not stated"),
                f"Phase state: {phase.get('state', 'not stated')}",
                "Nearest boundary identities: "
                + _items(phase.get("nearest_boundary_ids"), "none"),
                "Preserved claims: " + _items(change.get("preserved_ids")),
                "Invalidated claims: " + _items(change.get("invalidated_ids")),
                "Replacement roots: "
                + (
                    ", ".join(
                        f"{key}={value}"
                        for key, value in sorted(
                            (change.get("replacement_roots") or {}).items()
                        )
                    )
                    or "none"
                ),
                f"Proposed minimum action: {minimum.get('action', 'not stated')}",
                f"Basis: {minimum.get('basis', 'not stated')}",
                "Proposed action authority: NON_AUTHORIZING",
                f"Regret status: {regret.get('status', 'not stated')}",
                "Regret witnesses: " + _items(regret.get("witnesses")),
                "Claim scope: " + canonical_json(result.get("claim_scope")),
                "Completeness basis: "
                + str(completeness.get("basis_type") or "not stated"),
                "Declared universe: "
                + canonical_json(completeness.get("declared_universe")),
            ]
        )
    promotion = record.get("promotion_request")
    if isinstance(promotion, Mapping):
        lines.extend(
            [
                "",
                "SEPARATE GOVERNED PROMOTION PROPOSAL",
                f"Operation: {promotion.get('governed_operation', 'not stated')}",
                f"Status: {promotion.get('status', 'not stated')}",
                f"Execution: {promotion.get('execution_status', 'not stated')}",
                "This proposal did not execute or authorize the governed operation.",
            ]
        )
    return "\n".join(lines) + "\n"
