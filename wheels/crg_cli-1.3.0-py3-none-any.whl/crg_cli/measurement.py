"""Standalone CLI boundary for local operational measurement (CRG-ENH-04).

The measurement kernel ships with ``crg-server`` because the server owns the
durable local-session API.  This module imports it lazily: normal CRG CLI
operations retain their existing dependency graph, while an installed CRG
Systems product exposes the same local-only recorder through ``crg
measurement``.  No command reads or writes a CRG case.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import tempfile
from typing import Any, Callable, Dict


class OperationalMeasurementCliError(Exception):
    """A typed refusal from the optional local measurement surface."""


def _core():
    try:
        from crg_server import operational_measurement as measurement
    except ImportError as error:  # pragma: no cover - umbrella product installs both
        raise OperationalMeasurementCliError(
            "operational measurement requires the crg-server component of the "
            "integrated CRG Systems installation"
        ) from error
    return measurement


def _call(operation: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
    measurement = _core()
    try:
        return operation(*args, **kwargs)
    except measurement.MeasurementError as error:
        raise OperationalMeasurementCliError(str(error)) from error


def _recorder(args: Any):
    measurement = _core()
    # argparse requires the flag, but keep this guard at the execution
    # boundary so an embedding cannot bypass explicit opt-in with a hand-made
    # Namespace.  Refuse before constructing the filesystem store.
    if getattr(args, "measurement_enabled", False) is not True:
        raise OperationalMeasurementCliError(
            "operational measurement is off by default; pass --enable-local-measurement"
        )
    try:
        profile = measurement.OperationalMeasurementProfile(enabled=True)
        permission = measurement.OperationalMeasurementPermission(
            subject_label=args.subject_label,
            grants=tuple(args.measurement_grants or ()),
        )
        store = measurement.LocalOperationalMeasurementStore(args.measurement_store)
        return measurement.OperationalMeasurementRecorder(
            profile=profile,
            store=store,
            permission=permission,
        )
    except measurement.MeasurementError as error:
        raise OperationalMeasurementCliError(str(error)) from error


def _canonical(value: Any) -> bytes:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    ).encode("utf-8")


def _write_json(path: str, value: Any) -> None:
    destination = Path(path).expanduser().resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{destination.name}.", suffix=".tmp", dir=str(destination.parent)
    )
    try:
        os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(_canonical(value) + b"\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary_name, destination)
    finally:
        if os.path.exists(temporary_name):
            os.unlink(temporary_name)


def _session_text(verb: str, session: Dict[str, Any]) -> str:
    return "\n".join([
        f"operational measurement {verb}",
        f"  session         : {session['session_id']}",
        f"  state           : {session['status']}",
        f"  active time ns  : {session['active_time_ns']}",
        f"  compute time ns : {session['compute_time_ns']}",
        f"  wait time ns    : {session['wait_time_ns']}",
        f"  content hash    : {session['content_hash']}",
        "  authority       : none (not CRG evidence; cannot mutate a case)",
        "  economic claims : no ROI, savings, or superiority inferred",
    ])


def cmd_profile(args: Any, out: Any) -> int:
    recorder = _recorder(args)
    payload = {
        "profile": recorder.profile.to_record(),
        "permission": recorder.permission.to_record(),
        "store": {
            "domain": recorder.store.domain,
            "local_only": recorder.store.local_only,
            "root": str(recorder.store.root),
        },
    }
    out.result(
        payload,
        "\n".join([
            "local operational measurement is explicitly enabled",
            f"  store domain      : {payload['store']['domain']}",
            f"  permission domain : {payload['permission']['domain']}",
            f"  grants            : {', '.join(payload['permission']['grants'])}",
            "  phone home        : false",
            "  case/evidence authority: none",
        ]),
    )
    return 0


def cmd_list(args: Any, out: Any) -> int:
    recorder = _recorder(args)
    sessions = _call(recorder.list_sessions)
    payload = {
        "sessions": sessions,
        "count": len(sessions),
        "store_domain": recorder.store.domain,
        "local_only": True,
        "authorizing": False,
        "evidence_eligible": False,
    }
    lines = [f"local operational measurement sessions: {len(sessions)}"]
    lines.extend(
        f"  {item['session_id']} [{item['status']}] {item['content_hash']}"
        for item in sessions
    )
    out.result(payload, "\n".join(lines))
    return 0


def cmd_start(args: Any, out: Any) -> int:
    recorder = _recorder(args)
    session = _call(
        recorder.start_session,
        session_id=args.session_id,
        purpose_code=args.purpose_code,
        scope_code=args.scope_code,
    )
    out.result(session, _session_text("session started", session))
    return 0


def cmd_show(args: Any, out: Any) -> int:
    recorder = _recorder(args)
    session = _call(recorder.get_session, args.session_id)
    out.result(session, _session_text("session", session))
    return 0


def cmd_interval(args: Any, out: Any) -> int:
    recorder = _recorder(args)
    operation = {
        "active-start": recorder.begin_active,
        "active-end": recorder.end_active,
        "compute-start": recorder.begin_compute,
        "compute-end": recorder.end_compute,
        "wait-start": recorder.begin_wait,
        "wait-end": recorder.end_wait,
    }[args.measurement_command]
    session = _call(operation, args.session_id)
    out.result(session, _session_text(args.measurement_command, session))
    return 0


def cmd_observe(args: Any, out: Any) -> int:
    recorder = _recorder(args)
    session = _call(
        recorder.record_observation,
        args.session_id,
        metric_code=args.metric_code,
        numerator=args.numerator,
        denominator=args.denominator,
        unit_code=args.unit_code,
        measurement_class=args.measurement_class,
    )
    out.result(session, _session_text("observation recorded", session))
    return 0


def cmd_counterfactual(args: Any, out: Any) -> int:
    recorder = _recorder(args)
    session = _call(
        recorder.record_counterfactual,
        args.session_id,
        metric_code=args.metric_code,
        numerator=args.numerator,
        denominator=args.denominator,
        unit_code=args.unit_code,
        basis_code=args.basis_code,
    )
    out.result(session, _session_text("declared counterfactual recorded", session))
    return 0


def cmd_end(args: Any, out: Any) -> int:
    recorder = _recorder(args)
    session = _call(recorder.end_session, args.session_id)
    out.result(session, _session_text("session ended", session))
    return 0


def cmd_export(args: Any, out: Any) -> int:
    recorder = _recorder(args)
    document = _call(
        recorder.export_session,
        args.session_id,
        destination=args.output,
    )
    verified = _call(_core().verify_operational_measurement_export, document)
    out.result(
        {
            "output": str(Path(args.output).expanduser().resolve()),
            "independently_verified": True,
            "content_hash": verified["content_hash"],
            "session_content_hash": verified["session"]["content_hash"],
            "export": verified,
        },
        "\n".join([
            f"exported verified local measurement to {args.output}",
            f"  export hash  : {verified['content_hash']}",
            f"  session hash : {verified['session']['content_hash']}",
            "  verification : passed before destination write",
            "  transmission : false",
        ]),
    )
    return 0


def cmd_verify(args: Any, out: Any) -> int:
    try:
        document = Path(args.path).read_bytes()
    except OSError as error:
        raise OperationalMeasurementCliError(str(error)) from error
    verified = _call(_core().verify_operational_measurement_export, document)
    payload = {
        "ok": True,
        "status": "VERIFIED",
        "independent": True,
        "content_hash": verified["content_hash"],
        "session_content_hash": verified["session"]["content_hash"],
        "authorizing": False,
        "evidence_eligible": False,
    }
    out.result(
        payload,
        "\n".join([
            "operational measurement export VERIFIED",
            f"  export hash  : {payload['content_hash']}",
            f"  session hash : {payload['session_content_hash']}",
            "  authority    : none (operational record only)",
        ]),
    )
    return 0


def cmd_retention_preview(args: Any, out: Any) -> int:
    recorder = _recorder(args)
    preview = _call(
        recorder.preview_retention,
        as_of=args.as_of,
        maximum_age_seconds=args.maximum_age_seconds,
    )
    if args.output:
        _write_json(args.output, preview)
    out.result(
        preview,
        "\n".join([
            "local measurement retention preview (nothing deleted)",
            f"  candidates        : {preview['candidate_count']}",
            f"  active excluded   : {preview['excluded_active_count']}",
            f"  confirmation hash : {preview['content_hash']}",
        ]),
    )
    return 0


def cmd_retention_enforce(args: Any, out: Any) -> int:
    recorder = _recorder(args)
    try:
        preview = json.loads(Path(args.preview).read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        raise OperationalMeasurementCliError(
            f"cannot read retention preview: {error}"
        ) from error
    receipt = _call(
        recorder.enforce_retention,
        preview,
        confirmation_hash=args.confirmation_hash,
    )
    if args.output:
        _write_json(args.output, receipt)
    out.result(
        receipt,
        "\n".join([
            "confirmed local measurement retention enforced",
            f"  deleted      : {receipt['deleted_count']}",
            f"  preview hash : {receipt['preview_content_hash']}",
            "  case mutation: false",
        ]),
    )
    return 0


def cmd_delete(args: Any, out: Any) -> int:
    recorder = _recorder(args)
    receipt = _call(
        recorder.delete_session,
        args.session_id,
        expected_content_hash=args.expected_content_hash,
    )
    if args.output:
        _write_json(args.output, receipt)
    out.result(
        receipt,
        "\n".join([
            f"deleted local measurement session {args.session_id}",
            f"  deleted hash : {receipt['deleted'][0]['deleted_content_hash']}",
            "  case mutation: false",
        ]),
    )
    return 0


__all__ = [
    "OperationalMeasurementCliError",
    "cmd_counterfactual",
    "cmd_delete",
    "cmd_end",
    "cmd_export",
    "cmd_interval",
    "cmd_list",
    "cmd_observe",
    "cmd_profile",
    "cmd_retention_enforce",
    "cmd_retention_preview",
    "cmd_show",
    "cmd_start",
    "cmd_verify",
]
