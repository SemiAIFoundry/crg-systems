"""Closed v1.3 product boundary for comparative qualification evidence.

Public callers name stored certified-delta, selective-revalidation, and bounded
operational-measurement identities. The boundary independently replays the
stored engineering records, preserves local observations as non-evidentiary,
keeps user-declared counterfactuals unsupported, and publishes no authorizing
or economic conclusion.
"""
from __future__ import annotations

import copy
from typing import Any, Callable, Dict, Mapping, MutableMapping, Sequence, Tuple

import crg_change
import crg_verify
from crg_model.canonical import content_hash
from crg_verify.lifecycle import verify_selective_revalidation_record

from .store import CaseError, record_history

__all__ = [
    "CHANGE_COMPARISON_REQUEST_FIELDS",
    "CHANGE_COMPARISON_REQUIRED_FIELDS",
    "JourneyComparisonVerificationError",
    "build_verified_comparative_change",
    "persist_comparative_change",
    "inspect_comparative_change",
    "verify_comparative_change",
    "resolve_qualification_operational_sources",
    "portable_journey_comparison_objects",
    "render_comparative_change_report",
]

CHANGE_COMPARISON_REQUEST_FIELDS = frozenset(
    {
        "comparison_id",
        "certified_delta_id",
        "decision_scope",
        "evidence_scope",
        "limitations",
        "qualification_extension",
    }
)
CHANGE_COMPARISON_REQUIRED_FIELDS = CHANGE_COMPARISON_REQUEST_FIELDS - {
    "qualification_extension"
}

_DELTA_REQUIRED_INPUTS = frozenset(
    {"prior_case", "current_case", "dependency_edges", "replacements"}
)
_DELTA_OPTIONAL_INPUTS = frozenset(
    {
        "prior_phase",
        "current_phase",
        "prior_phase_source_r",
        "current_phase_source_r",
    }
)
_QUALIFICATION_REQUEST_FIELDS = frozenset(
    {
        "selective_revalidation_id",
        "local_observation_refs",
        "declared_counterfactual_refs",
    }
)
_OPERATIONAL_REF_FIELDS = frozenset({"session_id", "event_hash"})
_MAX_OPERATIONAL_REFS = 32


def _verify_stored_revalidation(
    record: Mapping[str, Any], verification_inputs: Mapping[str, Any]
):
    """Replay the exact v1.3 selective-revalidation envelope without producer code."""

    envelope = _object(
        verification_inputs, "SelectiveRevalidationRecord verification inputs"
    )
    expected = {
        "verification_profile",
        "first_release_attribution",
        "verifier_operation",
        "record_type",
        "record_hash",
        "inputs",
    }
    if set(envelope) != expected:
        raise CaseError(
            "SelectiveRevalidationRecord verification inputs have a non-closed field set"
        )
    if (
        envelope["verification_profile"] != "crg-lifecycle/independent-replay@1"
        or envelope["first_release_attribution"] != "v1.3/ETQ_LIFECYCLE"
        or envelope["verifier_operation"]
        != "verify_selective_revalidation_record"
        or envelope["record_type"] != "SelectiveRevalidationRecord"
        or envelope["record_hash"] != content_hash(record)
    ):
        raise JourneyComparisonVerificationError(
            "stored SelectiveRevalidationRecord has an invalid replay-envelope binding"
        )
    replay = _closed(
        envelope["inputs"],
        "SelectiveRevalidationRecord replay inputs",
        ("dependency_edges", "artifact_universe"),
    )
    result = verify_selective_revalidation_record(
        record, replay["dependency_edges"], replay["artifact_universe"]
    )
    if not result.ok:
        detail = "; ".join(result.violations) or result.status
        raise JourneyComparisonVerificationError(
            "stored SelectiveRevalidationRecord failed independent lifecycle replay; "
            f"no qualification comparison may be published: {detail}"
        )
    return result


class JourneyComparisonVerificationError(CaseError):
    """A producer or a stored source disagreed with independent replay."""


def _object(value: Any, where: str) -> dict:
    if not isinstance(value, Mapping):
        raise CaseError(f"{where} must be a JSON object")
    return copy.deepcopy(dict(value))


def _closed(
    value: Any,
    where: str,
    required: Sequence[str],
    optional: Sequence[str] = (),
) -> dict:
    result = _object(value, where)
    missing = sorted(set(required) - set(result))
    unsupported = sorted(set(result) - set(required) - set(optional))
    if missing:
        raise CaseError(f"{where} is missing required field(s): {', '.join(missing)}")
    if unsupported:
        raise CaseError(
            f"{where} contains unsupported field(s): {', '.join(unsupported)}; "
            "callers cannot supply records, verifier results, hashes, derived facts, "
            "authority, conclusions, scores, or mutations"
        )
    return result


def _identity(value: Any, where: str) -> str:
    if not isinstance(value, str) or not value.strip() or value != value.strip():
        raise CaseError(f"{where} must be a normalized non-empty string")
    return value


def _stored(
    case: Mapping[str, Any], inventory: str, identity: str, record_type: str
) -> dict:
    values = case.get(inventory) or {}
    raw = values.get(identity) if isinstance(values, Mapping) else None
    if not isinstance(raw, Mapping):
        raise CaseError(f"no stored {record_type} {identity!r} exists in this case")
    record = copy.deepcopy(dict(raw))
    if record.get("record_type") != record_type:
        raise CaseError(
            f"stored {inventory}.{identity} carries {record.get('record_type')!r}; "
            f"expected {record_type!r}"
        )
    return record


def _stored_delta(case: Mapping[str, Any], evidence_id: str) -> Tuple[dict, dict]:
    record = _stored(case, "certified_deltas", evidence_id, "CertifiedDeltaRecord")
    if record.get("evidence_id") != evidence_id:
        raise CaseError(
            f"stored CertifiedDeltaRecord {evidence_id!r} has a mismatched evidence_id"
        )
    inventory = case.get("certified_delta_inputs") or {}
    raw_inputs = inventory.get(evidence_id) if isinstance(inventory, Mapping) else None
    inputs = _object(raw_inputs, f"CertifiedDeltaRecord {evidence_id!r} replay inputs")
    missing = sorted(_DELTA_REQUIRED_INPUTS - set(inputs))
    unsupported = sorted(set(inputs) - _DELTA_REQUIRED_INPUTS - _DELTA_OPTIONAL_INPUTS)
    if missing or unsupported:
        raise CaseError(
            f"CertifiedDeltaRecord {evidence_id!r} has non-closed replay inputs: "
            f"missing={missing}, unsupported={unsupported}"
        )
    return record, inputs


def _qualification_request(value: Any) -> dict:
    request = _closed(
        value,
        "qualification comparison extension request",
        _QUALIFICATION_REQUEST_FIELDS,
    )
    request["selective_revalidation_id"] = _identity(
        request["selective_revalidation_id"], "selective_revalidation_id"
    )
    seen = set()
    for field in ("local_observation_refs", "declared_counterfactual_refs"):
        raw_refs = request.get(field)
        if not isinstance(raw_refs, list):
            raise CaseError(f"qualification_extension.{field} must be a list")
        if len(raw_refs) > _MAX_OPERATIONAL_REFS:
            raise CaseError(
                f"qualification_extension.{field} exceeds the bounded {_MAX_OPERATIONAL_REFS}-reference profile"
            )
        refs = []
        for index, raw in enumerate(raw_refs):
            item = _closed(
                raw,
                f"qualification_extension.{field}[{index}]",
                _OPERATIONAL_REF_FIELDS,
            )
            reference = {
                "session_id": _identity(
                    item["session_id"],
                    f"qualification_extension.{field}[{index}].session_id",
                ),
                "event_hash": _identity(
                    item["event_hash"],
                    f"qualification_extension.{field}[{index}].event_hash",
                ),
            }
            identity = (reference["session_id"], reference["event_hash"])
            if identity in seen:
                raise CaseError(
                    "qualification extension repeats an operational measurement identity"
                )
            seen.add(identity)
            refs.append(reference)
        refs.sort(key=lambda item: (item["session_id"], item["event_hash"]))
        request[field] = refs
    return request


def _stored_revalidation(
    case: Mapping[str, Any], record_id: str
) -> Tuple[dict, dict, Any]:
    records = case.get("lifecycle_records") or {}
    by_type = records.get("SelectiveRevalidationRecord") if isinstance(records, Mapping) else None
    raw_record = by_type.get(record_id) if isinstance(by_type, Mapping) else None
    inputs_inventory = case.get("lifecycle_verification_inputs") or {}
    by_type_inputs = (
        inputs_inventory.get("SelectiveRevalidationRecord")
        if isinstance(inputs_inventory, Mapping)
        else None
    )
    raw_inputs = (
        by_type_inputs.get(record_id) if isinstance(by_type_inputs, Mapping) else None
    )
    record = _object(raw_record, f"SelectiveRevalidationRecord {record_id!r}")
    inputs = _object(raw_inputs, f"SelectiveRevalidationRecord {record_id!r} inputs")
    if (
        record.get("record_type") != "SelectiveRevalidationRecord"
        or record.get("record_id") != record_id
    ):
        raise CaseError(
            f"stored SelectiveRevalidationRecord {record_id!r} has a mismatched identity"
        )
    verification = _verify_stored_revalidation(record, inputs)
    if not verification.ok:
        detail = "; ".join(verification.violations) or verification.status
        raise JourneyComparisonVerificationError(
            "stored SelectiveRevalidationRecord failed independent lifecycle replay; "
            f"no qualification comparison may be published: {detail}"
        )
    return record, inputs, verification


def resolve_qualification_operational_sources(
    request: Any,
    session_loader: Callable[[str], Mapping[str, Any]],
) -> dict:
    """Resolve identity-only measurement references from the separate local store.

    Only the selected bounded METRIC events cross into the portable comparison.
    The complete session stays in the dedicated operational-measurement domain.
    """

    value = _object(request, "comparative change request")
    raw_extension = value.get("qualification_extension")
    if raw_extension is None:
        return {"local_observations": [], "declared_counterfactuals": []}
    extension = _qualification_request(raw_extension)
    sessions: Dict[str, dict] = {}
    result = {"local_observations": [], "declared_counterfactuals": []}
    sections = (
        ("local_observation_refs", "local_observations", "LOCAL_OBSERVATION"),
        (
            "declared_counterfactual_refs",
            "declared_counterfactuals",
            "USER_DECLARED_COUNTERFACTUAL",
        ),
    )
    for request_field, output_field, expected_class in sections:
        for reference in extension[request_field]:
            session_id = reference["session_id"]
            if session_id not in sessions:
                session = _object(
                    session_loader(session_id),
                    f"operational measurement session {session_id!r}",
                )
                if session.get("session_id") != session_id:
                    raise CaseError(
                        f"operational measurement session {session_id!r} has a mismatched identity"
                    )
                session_hash = session.get("content_hash")
                unsigned = copy.deepcopy(session)
                unsigned.pop("content_hash", None)
                if session_hash != content_hash(unsigned):
                    raise JourneyComparisonVerificationError(
                        f"operational measurement session {session_id!r} failed its content binding"
                    )
                sessions[session_id] = session
            session = sessions[session_id]
            event_hash = reference["event_hash"]
            matches = [
                event
                for event in session.get("events") or []
                if isinstance(event, Mapping) and event.get("content_hash") == event_hash
            ]
            if len(matches) != 1:
                raise CaseError(
                    f"operational measurement session {session_id!r} has no unique event {event_hash!r}"
                )
            event = copy.deepcopy(dict(matches[0]))
            metric = event.get("metric") if isinstance(event.get("metric"), Mapping) else {}
            if event.get("event_type") != "METRIC" or metric.get(
                "measurement_class"
            ) != expected_class:
                raise CaseError(
                    f"operational event {event_hash!r} is not a stored {expected_class} METRIC"
                )
            result[output_field].append({
                "session_content_hash": session["content_hash"],
                "event": event,
            })
    return result


def _verify_delta(record: Mapping[str, Any], inputs: Mapping[str, Any]):
    result = crg_verify.verify_certified_delta_record(
        record,
        inputs["prior_case"],
        inputs["current_case"],
        inputs["dependency_edges"],
        replacements=inputs["replacements"],
        prior_phase=inputs.get("prior_phase"),
        current_phase=inputs.get("current_phase"),
        prior_phase_source_r=inputs.get("prior_phase_source_r"),
        current_phase_source_r=inputs.get("current_phase_source_r"),
    )
    if not result.ok:
        detail = "; ".join(result.violations) or result.status
        raise JourneyComparisonVerificationError(
            "stored CertifiedDeltaRecord failed independent replay; no comparative "
            f"record may be published: {detail}"
        )
    return result


def verify_comparative_change(record: Any):
    document = _object(record, "ComparativeChangeEvidence")
    result = crg_verify.verify_comparative_change_evidence(document)
    if not result.ok:
        detail = "; ".join(result.violations) or result.status
        raise JourneyComparisonVerificationError(
            "ComparativeChangeEvidence failed independent reconstruction; no record "
            f"may be previewed, persisted, reported, or exported: {detail}"
        )
    return result


def build_verified_comparative_change(
    request: Any,
    case: Mapping[str, Any],
    *,
    operational_measurement_sources: Mapping[str, Any] | None = None,
) -> Tuple[dict, Any]:
    """Resolve stored v1.2 facts and the optional stored-identity v1.3 extension."""

    value = _closed(
        request,
        "comparative change request",
        CHANGE_COMPARISON_REQUIRED_FIELDS,
        CHANGE_COMPARISON_REQUEST_FIELDS - CHANGE_COMPARISON_REQUIRED_FIELDS,
    )
    comparison_id = _identity(value["comparison_id"], "comparison_id")
    delta_id = _identity(value["certified_delta_id"], "certified_delta_id")
    delta, inputs = _stored_delta(case, delta_id)
    delta_verification = _verify_delta(delta, inputs)
    extension_args: dict = {}
    raw_extension = value.get("qualification_extension")
    if raw_extension is not None:
        extension = _qualification_request(raw_extension)
        revalidation, revalidation_inputs, revalidation_verification = (
            _stored_revalidation(case, extension["selective_revalidation_id"])
        )
        sources = _object(
            operational_measurement_sources or {
                "local_observations": [],
                "declared_counterfactuals": [],
            },
            "resolved operational measurement sources",
        )
        if set(sources) != {"local_observations", "declared_counterfactuals"}:
            raise CaseError(
                "resolved operational measurement sources must remain separated by classification"
            )
        expected_refs = {
            "local_observations": extension["local_observation_refs"],
            "declared_counterfactuals": extension["declared_counterfactual_refs"],
        }
        for field, requested in expected_refs.items():
            if not isinstance(sources.get(field), list) or len(sources[field]) != len(requested):
                raise CaseError(
                    f"resolved {field} do not match the identity-only qualification request"
                )
            expected_identities = sorted(
                (item["session_id"], item["event_hash"]) for item in requested
            )
            actual_identities = sorted(
                (
                    str((item.get("event") or {}).get("session_id")),
                    str((item.get("event") or {}).get("content_hash")),
                )
                for item in sources[field]
                if isinstance(item, Mapping) and isinstance(item.get("event"), Mapping)
            )
            if actual_identities != expected_identities:
                raise CaseError(
                    f"resolved {field} identities differ from the closed request"
                )
        extension_args = {
            "selective_revalidation": revalidation,
            "selective_revalidation_verification_inputs": revalidation_inputs,
            "selective_revalidation_independent_verification": (
                revalidation_verification.to_json()
            ),
            "local_operational_observations": sources["local_observations"],
            "declared_counterfactuals": sources["declared_counterfactuals"],
        }
    elif operational_measurement_sources:
        raise CaseError(
            "operational measurement sources were supplied without a qualification extension"
        )
    try:
        record = crg_change.build_comparative_change_evidence(
            comparison_id,
            certified_delta=delta,
            verification_inputs=inputs,
            independent_verification=delta_verification.to_json(),
            decision_scope=value["decision_scope"],
            evidence_scope=value["evidence_scope"],
            limitations=value["limitations"],
            **extension_args,
        ).to_canonical()
    except (KeyError, TypeError, ValueError) as error:
        raise CaseError(f"comparative change request is invalid: {error}") from error
    verification = verify_comparative_change(record)
    return record, verification


def persist_comparative_change(
    case: MutableMapping[str, Any], record: Mapping[str, Any]
) -> str:
    """Persist one immutable independently verified non-authorizing record."""

    verification = verify_comparative_change(record)
    comparison_id = _identity(record.get("comparison_id"), "comparison_id")
    existing = (case.get("comparative_change_evidence") or {}).get(comparison_id)
    if existing is not None and content_hash(existing) != content_hash(record):
        raise CaseError(
            f"comparative change {comparison_id!r} already names different content; "
            "use a new immutable comparison identity"
        )
    canonical = copy.deepcopy(dict(record))
    case.setdefault("comparative_change_evidence", {})[comparison_id] = canonical
    record_history(
        case,
        "comparative change generate",
        {
            "comparison_id": comparison_id,
            "record_hash": canonical["record_hash"],
            "authority": "NON_AUTHORIZING",
            "authorizing": False,
            "semantic_effect": "NONE",
            "independently_verified": True,
            "verifier_status": verification.status,
        },
    )
    return comparison_id


def inspect_comparative_change(case: Mapping[str, Any], comparison_id: str) -> dict:
    identity = _identity(comparison_id, "comparison_id")
    record = _stored(
        case, "comparative_change_evidence", identity, "ComparativeChangeEvidence"
    )
    if record.get("comparison_id") != identity:
        raise CaseError(f"stored comparative change {identity!r} has mismatched identity")
    verification = verify_comparative_change(record)
    return {
        "comparative_change": record,
        "verification": verification.to_json(),
        "report": render_comparative_change_report(record, verification),
        "authority": "NON_AUTHORIZING",
        "authorizing": False,
        "semantic_effect": "NONE",
    }

def portable_journey_comparison_objects(
    case: Mapping[str, Any]
) -> Dict[str, Any]:
    """Return independently replayed comparative-change records only."""

    objects: Dict[str, Any] = {}
    changes = case.get("comparative_change_evidence") or {}
    if isinstance(changes, Mapping):
        for comparison_id, raw in sorted(changes.items(), key=lambda item: str(item[0])):
            if not isinstance(raw, Mapping):
                raise CaseError(
                    f"comparative change {comparison_id!r} is not a JSON object"
                )
            record = copy.deepcopy(dict(raw))
            if record.get("comparison_id") != comparison_id:
                raise CaseError(
                    f"comparative change {comparison_id!r} has mismatched stored identity"
                )
            verify_comparative_change(record)
            objects[f"comparative-change:{comparison_id}"] = record
    return objects


def _count(value: Any) -> str:
    if isinstance(value, Mapping) and set(value) == {"exact"}:
        return str(value["exact"])
    return "not stated"


def render_comparative_change_report(
    record: Mapping[str, Any], verification: Any = None
) -> str:
    """Render direct certified-change facts without economic interpretation."""

    facts = record.get("system_derived_facts") or {}
    lines = [
        "CRG COMPARATIVE CHANGE EVIDENCE",
        "=" * 31,
        "",
        f"Comparison: {record.get('comparison_id', 'not stated')}",
        f"Record hash: {record.get('record_hash', 'not stated')}",
        "Authority: NON_AUTHORIZING",
        "Authorizing: false",
        "Semantic effect: NONE",
        f"Minimum action: {facts.get('minimum_action', 'not stated')}",
        "",
        "DIRECT CERTIFIED WORK IDENTITIES",
    ]
    for label, key in (
        ("Preserved", "preserved_work"),
        ("Invalidated", "invalidated_work"),
        ("Recomputed", "recomputed_work"),
    ):
        item = facts.get(key) or {}
        members = ", ".join(str(value) for value in item.get("members") or ()) or "none"
        lines.append(f"- {label}: {_count(item.get('count'))} artifact identities — {members}")
    extension = record.get("qualification_extension")
    if isinstance(extension, Mapping):
        qualification_facts = extension.get("system_derived_revalidation_facts") or {}
        lines.extend([
            "",
            "SYSTEM-DERIVED SELECTIVE-REVALIDATION FACTS",
            "Classification: SYSTEM_DERIVED_INDEPENDENTLY_RECONSTRUCTED",
            f"Changed source: {qualification_facts.get('changed_source', 'not stated')}",
            f"Affected: {_count(qualification_facts.get('affected_count'))}",
            f"Preserved: {_count(qualification_facts.get('preserved_count'))}",
            f"Replacement required: {_count(qualification_facts.get('replacement_required_count'))}",
            f"State: {qualification_facts.get('state', 'not stated')}",
            "",
            "LOCAL OPERATIONAL OBSERVATIONS — NON-EVIDENTIARY",
            f"Status: {extension.get('local_observation_status', 'not stated')}",
        ])
        for reference in extension.get("local_operational_observations") or []:
            metric = (reference.get("event") or {}).get("metric") or {}
            exact = metric.get("exact_value") or {}
            lines.append(
                f"- {metric.get('metric_code', 'not stated')}: "
                f"{exact.get('numerator', '?')}/{exact.get('denominator', '?')} "
                f"{metric.get('unit_code', 'not stated')} "
                f"[{reference.get('event_content_hash', 'not stated')}]"
            )
        lines.extend([
            "",
            "USER-DECLARED COUNTERFACTUALS — UNSUPPORTED",
            f"Status: {extension.get('counterfactual_status', 'not stated')}",
        ])
        for reference in extension.get("declared_counterfactuals") or []:
            metric = (reference.get("event") or {}).get("metric") or {}
            exact = metric.get("exact_value") or {}
            lines.append(
                f"- {metric.get('metric_code', 'not stated')}: "
                f"{exact.get('numerator', '?')}/{exact.get('denominator', '?')} "
                f"{metric.get('unit_code', 'not stated')} "
                f"(USER_DECLARED_UNVERIFIED; {reference.get('event_content_hash', 'not stated')})"
            )
    lines.extend(
        [
            "",
            "CLAIM BOUNDARY",
            str(record.get("claim_boundary") or "not stated"),
            "No elapsed-time, effort, cost, avoided-work, savings, ROI, ranking, or "
            "unexecuted counterfactual is inferred.",
        ]
    )
    if verification is not None:
        lines.extend(["", "INDEPENDENT VERIFICATION", f"Status: {verification.status}"])
    limitations = record.get("limitations") or []
    if limitations:
        lines.extend(["", "LIMITATIONS"])
        lines.extend(f"- {item}" for item in limitations)
    return "\n".join(lines) + "\n"
