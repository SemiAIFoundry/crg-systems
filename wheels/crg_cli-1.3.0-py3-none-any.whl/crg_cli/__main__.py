"""``python -m crg_cli`` entry point."""
from .main import main

if __name__ == "__main__":
    raise SystemExit(main())
