"""CLI output modes and exit codes.

Normative basis: 40 (CLI specification) and 6.6 (fail closed).

Specification 40 requires human-readable output, canonical JSON, JSON
Lines, a quiet exit-code mode, and a machine-streaming mode.  The exit code
is the part that matters most: 6.6 says a failed or unresolved check MUST
NOT produce affirmative certification, and at a process boundary the only
thing a caller reliably reads is the exit status.  So a violation is
always a nonzero exit, in every output mode, including quiet.
"""
from __future__ import annotations

import sys
from typing import Any, Dict, Optional

from crg_model.canonical import canonical_json

__all__ = ["Emitter", "OK", "VIOLATION", "USAGE", "HUMAN", "JSON", "STREAM", "QUIET"]

OK = 0
VIOLATION = 1
USAGE = 2

HUMAN = "human"
JSON = "json"
STREAM = "stream"
QUIET = "quiet"


class Emitter:
    """Writes command output in the mode the caller selected."""

    def __init__(self, mode: str = HUMAN, stream=None) -> None:
        self.mode = mode
        self.stream = stream or sys.stdout

    # -- progress -------------------------------------------------------
    def step(self, name: str, **fields: Any) -> None:
        """One step of a multi-stage command (machine-streaming mode)."""
        if self.mode == STREAM:
            self._line({"event": name, **fields})
        elif self.mode == HUMAN:
            detail = " ".join(f"{k}={v}" for k, v in fields.items())
            print(f"  -> {name}{(' ' + detail) if detail else ''}", file=self.stream)

    def note(self, text: str) -> None:
        if self.mode == HUMAN:
            print(text, file=self.stream)
        elif self.mode == STREAM:
            self._line({"event": "note", "text": text})

    def warn(self, text: str) -> None:
        if self.mode == HUMAN:
            print(f"warning: {text}", file=sys.stderr)
        elif self.mode == STREAM:
            self._line({"event": "warning", "text": text})

    def error(self, text: str) -> None:
        if self.mode == STREAM:
            self._line({"event": "error", "text": text})
        elif self.mode != QUIET:
            print(f"error: {text}", file=sys.stderr)

    # -- final result ---------------------------------------------------
    def result(self, payload: Dict[str, Any], human: Optional[str] = None) -> None:
        if self.mode == QUIET:
            return
        if self.mode == JSON:
            print(canonical_json(payload), file=self.stream)
        elif self.mode == STREAM:
            self._line({"event": "result", **payload})
        else:
            print(human if human is not None else canonical_json(payload), file=self.stream)

    def _line(self, payload: Dict[str, Any]) -> None:
        print(canonical_json(payload), file=self.stream, flush=True)
