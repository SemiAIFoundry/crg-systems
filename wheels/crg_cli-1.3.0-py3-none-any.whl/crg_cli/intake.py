"""Shared case-level helpers for the preview-first registry intake surface.

``crg_io.intake`` owns every import semantic.  This module contributes only
the product boundary around it: strict decoding of its canonical mapping and
provenance records, a stable preview response, and additive case persistence
for the exact records that a user reviewed and confirmed.  It deliberately
does not infer mappings, convert units, strengthen completeness, or authorize
a decision.
"""
from __future__ import annotations

from typing import Any, Dict, Mapping

import crg_io
from crg_model.canonical import canonical_json, content_hash, is_hash
from crg_model.schema import validate


__all__ = [
    "mapping_profile_from_document",
    "source_provenance_from_document",
    "registry_intake_preview_payload",
    "persist_registry_intake",
    "portable_intake_objects",
]


_LEDGER_MAPS = (
    ("mapping_profiles", "intake-profile"),
    ("source_snapshots", "intake-source"),
    ("previews", "intake-preview"),
    ("confirmations", "intake-confirmation"),
    ("materialized_registries", "intake-registry"),
    ("import_reports", "intake-report"),
)
_LEDGER_POINTERS = {
    "latest_profile_hash": "mapping_profiles",
    "latest_source_snapshot_hash": "source_snapshots",
    "latest_preview_hash": "previews",
    "latest_confirmation_hash": "confirmations",
}


def _content_addressed_records(
    ledger: Mapping[str, Any], name: str
) -> Dict[str, Mapping[str, Any]]:
    if name not in ledger:
        raise ValueError(f"registry intake ledger is missing {name}")
    raw = ledger[name]
    if not isinstance(raw, Mapping):
        raise ValueError(f"registry intake ledger {name} must be an object")
    records: Dict[str, Mapping[str, Any]] = {}
    for digest, record in raw.items():
        if not is_hash(digest):
            raise ValueError(f"registry intake ledger {name} has invalid hash key {digest!r}")
        if not isinstance(record, Mapping):
            raise ValueError(f"registry intake ledger {name}[{digest!r}] is not an object")
        actual = content_hash(record)
        if actual != digest:
            raise ValueError(
                f"registry intake ledger {name}[{digest!r}] hashes to {actual}"
            )
        records[str(digest)] = dict(record)
    return records


def _validate_intake_ledger(ledger: Mapping[str, Any]) -> Dict[str, Dict[str, Mapping[str, Any]]]:
    """Fail closed before appending to or exporting an intake history."""
    if not isinstance(ledger, Mapping):
        raise ValueError("registry intake ledger must be an object")
    violations = validate(dict(ledger), "RegistryIntakeLedger")
    if violations:
        raise ValueError("invalid registry intake ledger: " + "; ".join(violations))

    profile = ledger.get("historical_output_binding_profile")
    if profile != "CONTENT_ADDRESSED_COMPANIONS_V1":
        raise ValueError(
            "registry intake ledger requires content-addressed historical companions"
        )
    maps = {
        name: _content_addressed_records(ledger, name)
        for name, _prefix in _LEDGER_MAPS
    }
    for pointer, name in _LEDGER_POINTERS.items():
        digest = ledger.get(pointer)
        if digest not in maps[name]:
            raise ValueError(f"registry intake ledger {pointer} is dangling: {digest!r}")

    source = maps["source_snapshots"][str(ledger["latest_source_snapshot_hash"])]
    if ledger.get("latest_producer_source_snapshot_hash") != source.get(
        "producer_snapshot_hash"
    ):
        raise ValueError(
            "latest_producer_source_snapshot_hash does not match the selected typed source"
        )
    latest_confirmation = maps["confirmations"][str(ledger["latest_confirmation_hash"])]
    if (
        latest_confirmation.get("profile_hash") != ledger.get("latest_profile_hash")
        or latest_confirmation.get("source_snapshot_record_hash")
        != ledger.get("latest_source_snapshot_hash")
        or latest_confirmation.get("actual_preview_hash")
        != ledger.get("latest_preview_hash")
        or latest_confirmation.get("expected_preview_hash")
        != ledger.get("latest_preview_hash")
        or latest_confirmation.get("source_snapshot_hash")
        != ledger.get("latest_producer_source_snapshot_hash")
    ):
        raise ValueError(
            "registry intake ledger latest pointers do not describe one confirmation head"
        )

    for confirmation_hash, confirmation in maps["confirmations"].items():
        bindings = (
            ("profile_hash", "mapping_profiles"),
            ("source_snapshot_record_hash", "source_snapshots"),
            ("actual_preview_hash", "previews"),
        )
        for field, name in bindings:
            if confirmation.get(field) not in maps[name]:
                raise ValueError(
                    f"intake confirmation {confirmation_hash} has unresolved {field}"
                )
        typed_source = maps["source_snapshots"][
            str(confirmation["source_snapshot_record_hash"])
        ]
        if confirmation.get("source_snapshot_hash") != typed_source.get(
            "producer_snapshot_hash"
        ):
            raise ValueError(
                f"intake confirmation {confirmation_hash} source snapshot binding disagrees"
            )
        registry_hash = confirmation.get("bundle_hash")
        report_hash = confirmation.get("import_report_hash")
        if registry_hash not in maps["materialized_registries"]:
            raise ValueError(
                f"intake confirmation {confirmation_hash} has no historical registry"
            )
        if report_hash not in maps["import_reports"]:
            raise ValueError(
                f"intake confirmation {confirmation_hash} has no historical import report"
            )
        registry = maps["materialized_registries"][str(registry_hash)]
        report = maps["import_reports"][str(report_hash)]
        if (
            report.get("canonical_output_hash") != registry_hash
            or report.get("bundle_id") != registry.get("bundle_id")
            or report.get("source_fingerprint")
            != registry.get("source_fingerprint")
        ):
            raise ValueError(
                f"intake confirmation {confirmation_hash} output companions disagree"
            )
    return maps


def _insert_content_addressed(
    records: Dict[str, Mapping[str, Any]],
    digest: str,
    record: Mapping[str, Any],
    label: str,
) -> None:
    if not is_hash(digest) or content_hash(record) != digest:
        raise ValueError(f"refusing mis-keyed hash-bound {label} {digest!r}")
    existing = records.get(digest)
    if existing is not None and canonical_json(existing) != canonical_json(record):
        raise ValueError(f"refusing to overwrite hash-bound {label} {digest}")
    records[digest] = dict(record)


def mapping_profile_from_document(document: Mapping[str, Any]) -> Any:
    """Decode the producer's closed canonical mapping-profile vocabulary."""
    if not isinstance(document, Mapping):
        raise crg_io.IntakeProfileError("mapping_profile MUST be an object")
    return crg_io.RegistryMappingProfile.from_canonical(dict(document))


def source_provenance_from_document(document: Mapping[str, Any]) -> Any:
    """Decode provenance without permitting unnoticed caller extensions."""
    if not isinstance(document, Mapping):
        raise crg_io.IntakeProfileError("provenance MUST be an object")
    allowed = {"source_id", "source_name", "origin", "producer", "source_version"}
    required = {"source_id", "source_name", "origin"}
    unknown = set(document) - allowed
    missing = required - set(document)
    if unknown:
        raise crg_io.IntakeProfileError(
            "provenance contains unsupported field(s): "
            + ", ".join(sorted(map(str, unknown)))
        )
    if missing:
        raise crg_io.IntakeProfileError(
            "provenance is missing required field(s): "
            + ", ".join(sorted(missing))
        )
    return crg_io.SourceProvenance(
        source_id=document["source_id"],
        source_name=document["source_name"],
        origin=document["origin"],
        producer=document.get("producer"),
        source_version=document.get("source_version"),
    )


def registry_intake_preview_payload(preview: Any) -> Dict[str, Any]:
    """Return the complete non-mutating public preview response."""
    canonical = preview.to_canonical()
    preview_hash = preview.preview_hash()
    return {
        "record_type": "RegistryIntakePreviewResponse",
        "schema_version": "1.0.0",
        "authority": "NON_AUTHORIZING",
        "mutation_performed": False,
        "preview_hash": preview_hash,
        "profile_hash": canonical["profile_hash"],
        "source_snapshot_hash": canonical["source_snapshot_hash"],
        "accepted_count": len(canonical["accepted"]),
        "rejected_count": len(canonical["rejected"]),
        "ready_to_materialize": canonical["ready_to_materialize"],
        "preview": canonical,
        "canonical_preview_json": canonical_json(canonical),
        "confirmation": {
            "required_operation": "confirmRegistryIntake",
            "expected_preview_hash": preview_hash,
            "repreview_required": True,
            "rejected_rows_require_explicit_acknowledgement": bool(canonical["rejected"]),
        },
    }


def persist_registry_intake(
    case: Dict[str, Any],
    *,
    bundle: Any,
    report: Any,
    preview: Any,
    accept_partial: bool,
) -> Dict[str, Any]:
    """Attach one hash-bound intake result to a successor case document.

    The source bytes are intentionally not copied into the case.  Their exact
    fingerprint, byte length, declared provenance, mapping, typed row
    disposition, and the whole reviewed preview are retained.  Replacing the
    active registry never overwrites prior intake records; each is addressed
    by its canonical hash.
    """
    preview_record = preview.to_canonical()
    preview_hash = preview.preview_hash()
    profile_record = preview.profile.to_canonical()
    profile_hash = preview.profile.profile_hash()
    snapshot_payload = preview.source_snapshot.to_canonical()
    snapshot_hash = preview.source_snapshot.snapshot_hash()
    snapshot_record = {
        "record_type": "RegistrySourceSnapshot",
        "schema_version": "1.0.0",
        "authority": "NON_AUTHORIZING_INTAKE",
        "producer_snapshot_hash": snapshot_hash,
        **snapshot_payload,
    }
    snapshot_record_hash = content_hash(snapshot_record)
    bundle_record = bundle.to_canonical()
    report_record = report.to_canonical()
    # A server-side materialization uses an ephemeral path.  The declared
    # source name is the stable, portable identity; the exact source bytes are
    # bound separately by source_fingerprint/source_snapshot_hash.
    report_record["source_path"] = preview.source_snapshot.provenance.source_name
    registry_hash = content_hash(bundle_record)
    report_hash = content_hash(report_record)
    if bundle.bundle_hash() != registry_hash:
        raise ValueError(
            "materialized registry canonical hash disagrees with the producer bundle hash"
        )

    confirmation = {
        "record_type": "RegistryIntakeConfirmation",
        "schema_version": "1.0.0",
        "authority": "NON_AUTHORIZING_INTAKE",
        "mutation_performed": True,
        "expected_preview_hash": preview_hash,
        "actual_preview_hash": preview_hash,
        "profile_hash": profile_hash,
        "source_snapshot_hash": snapshot_hash,
        "source_snapshot_record_hash": snapshot_record_hash,
        "source_fingerprint": preview.source_snapshot.content_hash,
        "bundle_id": bundle.bundle_id,
        "bundle_hash": registry_hash,
        "import_report_hash": report_hash,
        "accepted_rows": len(preview.accepted),
        "rejected_rows": len(preview.rejected),
        "partial_import_acknowledged": bool(accept_partial),
        "completeness_basis": preview.completeness_basis.to_canonical(),
        "claim_scope": preview_record["claim_scope"],
    }
    confirmation_hash = content_hash(confirmation)

    prior_ledger = case.get("registry_intake")
    if prior_ledger is None:
        maps = {name: {} for name, _prefix in _LEDGER_MAPS}
    else:
        if not isinstance(prior_ledger, Mapping):
            raise ValueError("registry intake ledger must be an object")
        maps = _validate_intake_ledger(prior_ledger)

    for name, digest, record, label in (
        ("mapping_profiles", profile_hash, profile_record, "mapping profile"),
        ("source_snapshots", snapshot_record_hash, snapshot_record, "source snapshot"),
        ("previews", preview_hash, preview_record, "intake preview"),
        ("confirmations", confirmation_hash, confirmation, "intake confirmation"),
        (
            "materialized_registries",
            registry_hash,
            bundle_record,
            "materialized registry",
        ),
        ("import_reports", report_hash, report_record, "import report"),
    ):
        _insert_content_addressed(maps[name], digest, record, label)

    next_ledger = {
        "record_type": "RegistryIntakeLedger",
        "schema_version": "1.0.0",
        "authority": "NON_AUTHORIZING_INTAKE",
        "historical_output_binding_profile": "CONTENT_ADDRESSED_COMPANIONS_V1",
        "mapping_profiles": maps["mapping_profiles"],
        "source_snapshots": maps["source_snapshots"],
        "previews": maps["previews"],
        "confirmations": maps["confirmations"],
        "materialized_registries": maps["materialized_registries"],
        "import_reports": maps["import_reports"],
        "latest_profile_hash": profile_hash,
        "latest_source_snapshot_hash": snapshot_record_hash,
        "latest_producer_source_snapshot_hash": snapshot_hash,
        "latest_preview_hash": preview_hash,
        "latest_confirmation_hash": confirmation_hash,
    }
    _validate_intake_ledger(next_ledger)
    case["registry_intake"] = next_ledger
    case["registry"] = bundle_record
    case["import_report"] = report_record
    return {
        "confirmation": confirmation,
        "confirmation_hash": confirmation_hash,
        "preview": preview_record,
        "preview_hash": preview_hash,
        "mapping_profile": profile_record,
        "profile_hash": profile_hash,
        "source_snapshot": snapshot_record,
        "source_snapshot_hash": snapshot_hash,
        "source_snapshot_record_hash": snapshot_record_hash,
        "import_report": report_record,
        "import_report_hash": report_hash,
        "registry_hash": registry_hash,
    }


def portable_intake_objects(case: Mapping[str, Any]) -> Dict[str, Mapping[str, Any]]:
    """Flatten persisted intake provenance into portable bundle inventory."""
    ledger = case.get("registry_intake")
    if ledger is None:
        return {}
    if not isinstance(ledger, Mapping):
        raise ValueError("registry intake ledger must be an object")
    maps = _validate_intake_ledger(ledger)
    objects: Dict[str, Mapping[str, Any]] = {}
    for prefix, name in (
        ("intake-profile", "mapping_profiles"),
        ("intake-source", "source_snapshots"),
        ("intake-preview", "previews"),
        ("intake-confirmation", "confirmations"),
        ("intake-registry", "materialized_registries"),
        ("intake-report", "import_reports"),
    ):
        records = maps[name]
        for digest, record in sorted(records.items()):
            objects[f"{prefix}:{digest}"] = dict(record)
    return objects
