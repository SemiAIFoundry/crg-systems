/**
 * Independent decision-certificate verification, in the second language.
 *
 * Normative basis: 5.3 (evidence classes), 6.6 (fail closed), 9.1-9.3 (trust
 * zones, proof-carrying engineering), 21.4-21.6 (claim scope), 22.2-22.7
 * (decision values, strict winner, ties), 23.2-23.4 (solver trust), 25 (the
 * independent verifier), 26.4 (decision-observation mapping), 27.3-27.4
 * (regret witnesses), 45 (clock discipline).
 *
 * Everything here is a re-derivation.  Every value the certificate asserts is
 * recomputed from the retained registry, every classification is re-derived
 * from the normative tables, and where the two disagree the certificate
 * loses (9.3).
 *
 * The check NAMES are the Python verifier's check names, deliberately and
 * exactly.  25.5 wants two implementations whose reports can be compared
 * line by line; a second verifier that renamed the checks would be
 * incomparable, and an incomparable second opinion is not a second opinion.
 */
import {
  ZERO,
  ArithError,
  Rational,
  fmt,
  iadd,
  imul,
  interval,
  intervalEqual,
  minimum,
  positivePartSup,
  rational,
  strictlyBelow,
  sum as rationalSum,
  withinTolerance,
} from "./rational.mjs";
import { CanonicalError, contentHash, get, has, hashWithout, isHash, isObject } from "./canonical.mjs";
import { Level, Status, TimeStatus, VerificationResult } from "./result.mjs";

export const VERIFIER_ID = "crg-verify-js";
export const VERIFIER_VERSION = "1.4.0";
// VIR pins bind the stable checker protocol, independently of package releases.
export const CHECKER_PROFILE_VERSION = "0.2.0";
export const SPEC_VERSION = "0.2.0";

// ---------------------------------------------------------------------------
// Python-compatible coercions
// ---------------------------------------------------------------------------
// The Python verifier reaches its verdicts through `str(...)`, `bool(...)`,
// and `or`.  Those three are not JavaScript's.  `str(None)` is "None" and
// `[] or x` is x, where `String(null)` is "null" and `[] || x` is `[]`.  A
// port that used the JavaScript spellings would agree on the happy path and
// diverge exactly where a field is absent or empty -- which is where a
// tampered document lives.  So the three are written out.

/** Python `str(value)` for the values a decoded JSON document can hold. */
export function pyStr(value) {
  if (value === null || value === undefined) return "None";
  if (value === true) return "True";
  if (value === false) return "False";
  if (typeof value === "bigint") return value.toString(10);
  if (typeof value === "string") return value;
  if (Array.isArray(value)) return `[${value.map(pyRepr).join(", ")}]`;
  if (isObject(value)) {
    return `{${Object.keys(value).map((k) => `${pyRepr(k)}: ${pyRepr(value[k])}`).join(", ")}}`;
  }
  return String(value);
}

/** Python `repr(value)`, used only to build report detail text. */
export function pyRepr(value) {
  if (typeof value === "string") return `'${value.replace(/\\/g, "\\\\").replace(/'/g, "\\'")}'`;
  return pyStr(value);
}

/** Python truthiness: empty string, empty list, empty dict, 0, None, False. */
export function truthy(value) {
  if (value === null || value === undefined || value === false) return false;
  if (value === true) return true;
  if (typeof value === "string") return value.length > 0;
  if (typeof value === "bigint") return value !== 0n;
  if (typeof value === "number") return value !== 0;
  if (Array.isArray(value)) return value.length > 0;
  if (isObject(value)) return Object.keys(value).length > 0;
  return true;
}

/** Python `a or b or ...`: the first truthy operand, else the last. */
export function pyOr(...values) {
  for (const value of values) if (truthy(value)) return value;
  return values[values.length - 1];
}

function pySorted(values) {
  return [...values].sort((a, b) => (a < b ? -1 : a > b ? 1 : 0));
}

function asObject(value) {
  return isObject(value) ? value : Object.create(null);
}

function asArray(value) {
  return Array.isArray(value) ? value : [];
}

// ---------------------------------------------------------------------------
// independent copies of the normative tables
// ---------------------------------------------------------------------------
// 21.4, re-derived from 21.2.  BOUNDED_UNENUMERATED_FAMILY reaches a global
// claim only when a remainder bound is present and declared to close the
// decision (21.6); otherwise the family is partial.
const SCOPE_FROM_BASIS = new Map([
  ["EXHAUSTIVE_DECLARED_UNIVERSE", "FULL_DECLARED_UNIVERSE"],
  ["GENERATOR_CLOSED", "GENERATOR_CLOSED_FAMILY"],
  ["EXPLICIT_IMPORTED_FAMILY", "RELATIVE_EXPLICIT_FAMILY"],
  ["TRUNCATED_BY_DECLARED_RULE", "PARTIAL_FAMILY"],
  ["KNOWN_INCOMPLETE", "PARTIAL_FAMILY"],
  ["UNKNOWN", "PARTIAL_FAMILY"],
]);
const NO_WINNER_SCOPES = new Set(["PARTIAL_FAMILY"]); // 21.5

/** Outcomes asserting a certified winner (29.6, 22.3-22.4). */
const WINNER_LIKE = new Set(["CERTIFIED_WINNER", "CERTIFIED_WINNER_SET", "CERTIFIED_POLICY_TIE"]);
const STRICT_WINNER = new Set(["CERTIFIED_WINNER", "CERTIFIED_WINNER_SET"]);

/** 22.2 / 23.2: profiles that may authorize a strict claim. */
const CERTIFYING_ARITHMETIC = new Set(["EXACT_RATIONAL", "INTERVAL_ENCLOSED"]);
const CERTIFYING_SOLVER = new Set(["PROOF_CHECKED", "EXACT_RECOMPUTED"]);
const REPLAY_ARITHMETIC = new Set(["EXACT_RATIONAL", "INTERVAL_ENCLOSED", "FLOAT_REPLAY_BOUND"]);
const QUANTITY_REGISTRY_VERSION = "sha256:810b33ce38f3bf69be66fb153601782a4d73b125db1534ef810f82a088102bb1";
const NORMATIVE_RULE_TABLE_VERSION = "sha256:d1b2c0226357d194f7fefbb7f2060ab96d9f7dc9f7cd19e2ac635cef55de81f5";

const words = (text) => new Set(text.split(/\s+/).filter(Boolean));

/** Objective-family vocabulary, 26.3-26.4. */
const ADDITIVE = words("weighted_sum linear additive additive_price dot price_vector");
const MAX_EVALUABLE = words(
  "max weighted_max bottleneck min_max minmax makespan chebyshev weighted_chebyshev",
);
const MONOTONE_NONADDITIVE = new Set([
  ...MAX_EVALUABLE,
  ...words("monotone monotone_family lexicographic quantile leximin p_norm"),
]);
const NONMONOTONE = words("nonmonotone ratio difference target_distance balance variance spread");
const ATTAINABILITY = words(
  "attainability exact_point exact_signature signature_attainability " +
    "feasibility_of_point equality_target",
);
const REALIZATION = words(
  "realization_attribute declared_value schedule topology ownership placement " +
    "layout transition_cost embedding artifact",
);
const LEDGER = words("finite_ledger case_ledger ledger");
const KNOWN = new Set([
  ...ADDITIVE, ...MONOTONE_NONADDITIVE, ...NONMONOTONE, ...ATTAINABILITY, ...REALIZATION, ...LEDGER,
]);

/**
 * The information ladder (19.2-19.4): a larger rank strictly determines a
 * smaller one, and never the reverse.  That is what "sufficient" means.
 */
const RANK = new Map([
  ["REALIZATION_REGISTRY_AND_FIBERS", 4],
  ["R", 3],
  ["GAMMA", 2],
  ["K", 1],
]);
const EXACT_MATCH_OBJECTS = new Set(["ARGMIN_HITTING_SET", "BOUNDED_REGRET_REPRESENTATION"]);

/** Re-derive the claim scope from the completeness basis (21.4, 21.6). */
export function deriveClaimScope(completeness) {
  const record = asObject(completeness);
  const basis = pyStr(has(record, "basis_type") ? record.basis_type : "UNKNOWN");
  if (basis === "BOUNDED_UNENUMERATED_FAMILY") {
    const bound = get(record, "remainder_bound");
    const closes = truthy(bound) && pyStr(bound).toUpperCase().includes("CLOSES");
    return closes ? "BOUNDED_REMAINDER_GLOBAL" : "PARTIAL_FAMILY";
  }
  return SCOPE_FROM_BASIS.get(basis) ?? "PARTIAL_FAMILY";
}

function nonnegativeWeights(objective) {
  const weights = pyOr(get(objective, "weights"), Object.create(null));
  if (!truthy(weights)) return true; // an unweighted additive family is the all-ones price
  try {
    for (const key of Object.keys(weights)) {
      const pair = weights[key];
      // Python indexes `pair[0]`: the first element of a range, or the first
      // character of a numeral.  Reproduced, because the two implementations
      // have to reach the same 26.4 row on the same input.
      const first = typeof pair === "string" ? pair[0] : Array.isArray(pair) ? pair[0] : undefined;
      if (first === undefined) return false;
      if (rational(first).lt(ZERO)) return false;
    }
    return true;
  } catch {
    return false;
  }
}

/**
 * Re-derive the minimum required retained object (26.4).
 *
 * Rows are evaluated strongest-requirement-first, so a query that is both
 * realization sensitive and additive still requires the realization
 * registry.  Returns `[requiredObject, citedRule]`.
 */
export function requiredObjectFor(objective) {
  const record = asObject(objective);
  const kind = pyStr(has(record, "type") ? record.type : "unknown").trim().toLowerCase();
  const quant = pyStr(
    has(record, "quantification") ? record.quantification : "EACH_OBJECTIVE",
  ).toUpperCase();
  const regret = asObject(pyOr(get(record, "bounded_regret"), Object.create(null)));
  if (
    REALIZATION.has(kind) ||
    truthy(get(record, "realization_sensitivity")) ||
    truthy(get(record, "required_retained_identities"))
  ) {
    return ["REALIZATION_REGISTRY_AND_FIBERS", "26.4 rows 1-2; 19.6"];
  }
  if (ATTAINABILITY.has(kind) || NONMONOTONE.has(kind) || get(record, "monotone") === false) {
    return ["R", "26.4 row 3"];
  }
  if (ADDITIVE.has(kind) && !nonnegativeWeights(record)) {
    return ["R", "26.4 row 3 (a negative price is not monotone)"];
  }
  if (!KNOWN.has(kind)) return ["R", "26.4 final row; 26.6 (unknown semantics preserve R)"];
  if (quant === "ROBUST_AGGREGATE") {
    return ["GAMMA", "26.3; 26.4 row 6 (a coupled robust aggregate is not an additive price)"];
  }
  if (LEDGER.has(kind) && truthy(get(record, "cases"))) return ["ARGMIN_HITTING_SET", "26.4 row 7"];
  if (truthy(get(regret, "accept_approximation")) && get(regret, "tolerance") !== undefined
      && get(regret, "tolerance") !== null) {
    return ["BOUNDED_REGRET_REPRESENTATION", "26.4 row 8; 20.5"];
  }
  if (MONOTONE_NONADDITIVE.has(kind)) {
    return ["GAMMA", "26.4 row 4 (monotone non-additive; K is refused)"];
  }
  if (ADDITIVE.has(kind) && quant === "EACH_OBJECTIVE") return ["K", "26.4 row 5; 19.4"];
  return ["R", "26.4 final row; 26.6"];
}

// ---------------------------------------------------------------------------
// independent objective evaluation (22.2, 26.3)
// ---------------------------------------------------------------------------
/** The objective cannot be recomputed from a signature alone. */
export class Unevaluable extends Error {
  constructor(message) {
    super(message);
    this.name = "Unevaluable";
  }
}

const UNIT_INTERVAL = [new Rational(1n), new Rational(1n)];

function weightBox(objective, order) {
  const weights = asObject(pyOr(get(objective, "weights"), Object.create(null)));
  return order.map((name) => (has(weights, name) ? interval(weights[name]) : UNIT_INTERVAL));
}

/**
 * Exact enclosure of the objective family at `signature` (22.2, 26.3).
 *
 * Only families genuinely determined by a signature are evaluated.  Anything
 * else raises, and the caller fails closed rather than adopting the issuer's
 * number (6.6).
 */
export function evaluateObjective(signature, objective, order) {
  const record = asObject(objective);
  const kind = pyStr(has(record, "type") ? record.type : "unknown").trim().toLowerCase();
  const quant = pyStr(
    has(record, "quantification") ? record.quantification : "EACH_OBJECTIVE",
  ).toUpperCase();
  if (signature.length !== order.length) {
    throw new Unevaluable(
      `signature of length ${signature.length} against order ${order.length}`,
    );
  }
  const box = weightBox(record, order);
  if (ADDITIVE.has(kind)) {
    if (quant === "ROBUST_AGGREGATE") {
      // sup_{w in W} w . x: the upper weight on nonnegative coordinates, the
      // lower weight on negative ones.  Exact, not an enclosure.
      let total = ZERO;
      for (let i = 0; i < box.length; i += 1) {
        const [lo, hi] = box[i];
        const value = signature[i];
        total = total.add(value.gte(ZERO) ? hi.mul(value) : lo.mul(value));
      }
      return [total, total];
    }
    let out = [ZERO, ZERO];
    for (let i = 0; i < box.length && i < signature.length; i += 1) {
      out = iadd(out, imul(box[i], [signature[i], signature[i]]));
    }
    return out;
  }
  if (MAX_EVALUABLE.has(kind)) {
    const terms = [];
    for (let i = 0; i < box.length && i < signature.length; i += 1) {
      terms.push(imul(box[i], [signature[i], signature[i]]));
    }
    if (terms.length === 0) {
      throw new Unevaluable("a max-family objective over zero coordinates has no value");
    }
    let lo = terms[0][0];
    let hi = terms[0][1];
    for (const term of terms) {
      if (term[0].gt(lo)) lo = term[0];
      if (term[1].gt(hi)) hi = term[1];
    }
    return [lo, hi];
  }
  throw new Unevaluable(
    `objective family ${pyRepr(kind)} is not determined by a signature; the verifier ` +
      "refuses to adopt the issuer's value for it (spec 6.6)",
  );
}

/**
 * Enclosure of `{w . (q - p) : w in W}` for an additive family.
 *
 * Sharper than differencing two independent enclosures, because the same
 * weight vector is used on both sides.  This is the second sound route to a
 * strict win; a verifier without it would reject correct certificates.
 */
function pairedMargin(p, q, objective, order) {
  const box = weightBox(objective, order);
  let out = [ZERO, ZERO];
  for (let i = 0; i < box.length && i < p.length && i < q.length; i += 1) {
    const delta = q[i].sub(p[i]);
    out = iadd(out, imul(box[i], [delta, delta]));
  }
  return out;
}

function pairedRouteAvailable(objective, values) {
  const record = asObject(objective);
  const kind = pyStr(pyOr(get(record, "type"), "")).trim().toLowerCase();
  const quant = pyStr(
    has(record, "quantification") ? record.quantification : "EACH_OBJECTIVE",
  ).toUpperCase();
  if (!ADDITIVE.has(kind) || quant !== "EACH_OBJECTIVE") return false;
  if (!truthy(get(record, "weights"))) return false;
  for (const key of Object.keys(asObject(values))) {
    if (isObject(values[key]) && has(values[key], "evidence_interval")) return false;
  }
  return true;
}

// ---------------------------------------------------------------------------
// time (spec 45)
// ---------------------------------------------------------------------------
const ISO_DATE = /^(\d{4})-(\d{2})-(\d{2})$/;
const ISO_STAMP =
  /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::(\d{2})(?:[.,](\d{1,6}))?)?(?:([+-])(\d{2}):?(\d{2})(?::?\d{2})?)?$/;

/**
 * Parse an issuer or verifier timestamp to epoch microseconds, or null.
 *
 * A naive timestamp is read as UTC, matching the Python side's
 * `replace(tzinfo=utc)`.  Nothing here consults the host clock: 45.3 makes
 * the verifier's evaluation time an input, never something the verifier
 * helps itself to.
 */
export function parseTime(value) {
  if (typeof value !== "string" || value === "") return null;
  const text = value.trim().split("Z").join("+00:00");
  const dateOnly = ISO_DATE.exec(text);
  if (dateOnly) {
    const [, y, m, d] = dateOnly;
    return BigInt(Date.UTC(Number(y), Number(m) - 1, Number(d))) * 1000n;
  }
  const match = ISO_STAMP.exec(text);
  if (!match) return null;
  const [, y, mo, d, h, mi, s = "0", frac = "", sign, oh, om] = match;
  const month = Number(mo);
  const day = Number(d);
  if (month < 1 || month > 12 || day < 1 || day > 31) return null;
  if (Number(h) > 23 || Number(mi) > 59 || Number(s) > 59) return null;
  const utcMs = Date.UTC(Number(y), month - 1, day, Number(h), Number(mi), Number(s));
  if (!Number.isFinite(utcMs)) return null;
  let micros = BigInt(utcMs) * 1000n + BigInt((frac + "000000").slice(0, 6));
  if (sign) {
    const offset = (BigInt(oh) * 60n + BigInt(om)) * 60n * 1000000n;
    micros += sign === "+" ? -offset : offset;
  }
  return micros;
}

/** Report issuer time, verifier time, and the resulting status (45.3-45.5). */
function timeJudgment(cert, clock, clockSource) {
  const validity = asObject(pyOr(get(cert, "validity"), Object.create(null)));
  const issued = pyOr(get(cert, "issued_at"), get(validity, "issued_at"), get(cert, "created_at"));
  const notBefore = pyOr(get(cert, "not_before"), get(validity, "not_before"));
  const expiry = pyOr(get(cert, "expiry"), get(validity, "expires_at"), get(validity, "expiry"));
  const judgment = {
    issuer_asserted_issue_time: issued ?? null,
    issuer_asserted_not_before: notBefore ?? null,
    issuer_asserted_expiry: expiry ?? null,
    verifier_evaluation_time: clock ?? null,
    verifier_clock_source: clockSource,
  };
  const now = parseTime(clock);
  const start = parseTime(notBefore);
  const end = parseTime(expiry);
  let status;
  if (now === null) {
    // 45.5: an indeterminate time claim MUST NOT be reported as current.
    status = TimeStatus.TIME_INDETERMINATE;
  } else if (truthy(expiry) && end === null) {
    status = TimeStatus.CLOCK_POLICY_VIOLATION;
  } else if (start !== null && now < start) {
    status = TimeStatus.NOT_YET_VALID;
  } else if (end !== null && now > end) {
    status = TimeStatus.EXPIRED;
  } else if (end === null) {
    status = TimeStatus.TIME_INDETERMINATE;
  } else {
    status = TimeStatus.CURRENT;
  }
  judgment.time_status = status;
  return [status, judgment];
}

// ---------------------------------------------------------------------------
// registry decoding
// ---------------------------------------------------------------------------
function coordinateOrder(registry, cert) {
  const schema = asObject(pyOr(get(registry, "schema"), Object.create(null)));
  let coordinates = asArray(pyOr(get(schema, "coordinates"), []));
  if (coordinates.length === 0) {
    // Portable verifier projections may expose canonical `realizations`
    // while carrying the full registry in the content-addressed object map.
    // Never borrow that object's schema until its bytes rederive a declared
    // retained/complete registry root.
    const objects = asObject(pyOr(get(registry, "objects"), Object.create(null)));
    for (const rootKey of ["retained_registry_hash", "complete_registry_hash"]) {
      const root = get(registry, rootKey);
      const candidate = typeof root === "string" ? get(objects, root) : undefined;
      if (typeof root === "string" && isHash(root) && isObject(candidate)
          && contentHash(candidate) === root) {
        const candidateSchema = asObject(pyOr(get(candidate, "schema"), Object.create(null)));
        coordinates = asArray(pyOr(get(candidateSchema, "coordinates"), []));
        if (coordinates.length > 0) break;
      }
    }
  }
  if (coordinates.length > 0) return coordinates.map((c) => pyStr(get(c, "identifier")));
  const scope = asObject(pyOr(get(cert, "scope"), Object.create(null)));
  const family = asObject(pyOr(get(scope, "objective_family"), Object.create(null)));
  return asArray(pyOr(get(family, "coordinate_order"), [])).map(pyStr);
}

/** Re-derive feasibility (22.7); never inherited from the certificate. */
function feasibility(entry, domain) {
  if (pyStr(has(entry, "legality") ? entry.legality : "LEGAL") !== "LEGAL") {
    return ["INFEASIBLE", `legality=${pyStr(get(entry, "legality"))}`];
  }
  const attributes = asObject(pyOr(get(entry, "attributes"), Object.create(null)));
  const declared = has(attributes, "feasible") ? attributes.feasible : get(attributes, "feasibility");
  if (declared === false || (typeof declared === "string" && declared.toUpperCase() === "INFEASIBLE")) {
    return ["INFEASIBLE", pyStr(has(attributes, "infeasible_reason")
      ? attributes.infeasible_reason : "declared infeasible")];
  }
  if (typeof declared === "string" && declared.toUpperCase() === "UNKNOWN") {
    return ["UNKNOWN", "feasibility declared UNKNOWN"];
  }
  for (const key of Object.keys(asObject(domain))) {
    const bounds = domain[key];
    if (!has(attributes, key) || !Array.isArray(bounds) || bounds.length !== 2) continue;
    try {
      const value = rational(attributes[key]);
      const lo = rational(bounds[0]);
      const hi = rational(bounds[1]);
      if (value.lt(lo) || value.gt(hi)) {
        return ["INFEASIBLE", `attribute ${key}=${fmt(value)} outside declared domain`];
      }
    } catch (error) {
      if (error instanceof ArithError) continue;
      throw error;
    }
  }
  return ["FEASIBLE", ""];
}

// ---------------------------------------------------------------------------
// the verifier
// ---------------------------------------------------------------------------
/**
 * Independently verify a decision certificate (spec 25).
 *
 * `registry` carries the retained signatures, coordinate schema, and any
 * referenced objects; a CRG-VIR document supplies its own, which is what
 * makes `verifyVir` total.  `clock` is the *verifier's* evaluation time
 * (45.3): the issuer's clock is reported, never trusted, and never
 * substituted when no verifier clock was supplied.
 */
export function verifyCertificate(cert, { registry = null, clock = null, clockSource = "none-supplied" } = {}) {
  const result = new VerificationResult();
  const reg = asObject(registry);
  if (!isObject(cert)) {
    result.record("structure", false, "certificate is not a JSON object");
    result.status = Status.FAILED;
    return result.finish();
  }

  Object.assign(result.report, {
    verifier_identity: VERIFIER_ID,
    verifier_version: VERIFIER_VERSION,
    spec_version: SPEC_VERSION,
    bundle_identity: get(cert, "certificate_id") ?? null,
    level_attempted: Level.V3,
  });
  const outcome = pyStr(has(cert, "outcome") ? cert.outcome : "");
  const statedScope = pyStr(has(cert, "claim_scope") ? cert.claim_scope : "");
  const derivation = asObject(pyOr(get(cert, "derivation"), Object.create(null)));
  const scopeBlock = asObject(pyOr(get(cert, "scope"), Object.create(null)));
  const objective = asObject(pyOr(get(scopeBlock, "objective_family"), Object.create(null)));
  const values = asObject(pyOr(get(cert, "objective_values"), Object.create(null)));
  const selected = asArray(pyOr(get(cert, "selected"), [])).map(pyStr);
  const ties = asArray(pyOr(get(cert, "ties"), [])).map(pyStr);

  // -- 1: content hash (V0) -------------------------------------------
  const statedHash = pyOr(
    get(cert, "certificate_hash"),
    get(asObject(pyOr(get(cert, "hashes"), Object.create(null))), "certificate_hash"),
  );
  if (statedHash === null || statedHash === undefined) {
    result.unsupported("content_hash", "no certificate hash is stated");
  } else {
    let recomputed = null;
    let detail;
    try {
      recomputed = hashWithout(cert, "certificate_hash", "hashes", "signatures", "validity", "verification");
      detail = `stated ${statedHash}, recomputed ${recomputed}`;
    } catch (error) {
      if (!(error instanceof CanonicalError)) throw error;
      detail = `stated ${statedHash}, not canonically encodable: ${error.message}`;
    }
    result.record("content_hash", isHash(pyStr(statedHash)) && recomputed === statedHash, detail);
  }

  // -- 1b: semantics-bearing version closure (§15.2) -----------------
  const pins = get(cert, "semantic_pins");
  const pinErrors = [];
  if (!isObject(pins)) {
    pinErrors.push("semantic_pins is absent or not an object");
  } else {
    const schemas = get(pins, "schema_versions");
    if (!isObject(schemas) || get(schemas, "crg-core") !== SPEC_VERSION) {
      pinErrors.push(`schema_versions must pin crg-core=${SPEC_VERSION}`);
    }
    if (get(pins, "quantity_registry_version") !== QUANTITY_REGISTRY_VERSION) {
      pinErrors.push("quantity_registry_version is absent or unsupported");
    }
    if (get(pins, "normative_rule_table_version") !== NORMATIVE_RULE_TABLE_VERSION) {
      pinErrors.push("normative_rule_table_version is absent or unsupported");
    }
    if (get(pins, "crg_vir_version") !== SPEC_VERSION) {
      pinErrors.push(`crg_vir_version must be ${SPEC_VERSION}`);
    }
    const domains = get(pins, "domain_pack_versions");
    if (!isObject(domains) || Object.entries(domains).some(([k, v]) =>
      k.length === 0 || typeof v !== "string" || v.length === 0)) {
      pinErrors.push("domain_pack_versions must be a string-to-string mapping");
    }
    const checkers = get(pins, "proof_checker_versions");
    if (!isObject(checkers) || get(checkers, "crg-verify") !== CHECKER_PROFILE_VERSION ||
        get(checkers, "crg-verify-js") !== CHECKER_PROFILE_VERSION) {
      pinErrors.push(`proof_checker_versions must pin both independent ${CHECKER_PROFILE_VERSION} checker profiles`);
    }
  }
  result.record(
    "semantic_version_pins",
    pinErrors.length === 0,
    pinErrors.length > 0 ? pinErrors.join("; ") :
      "schema, quantity registry, normative rules, CRG-VIR, applicable domain packs, " +
      "and proof checkers are pinned (§15.2)",
  );

  // -- 2: claim scope re-derived from the completeness basis ------------
  const completeness = asObject(pyOr(get(cert, "completeness"), Object.create(null)));
  const scope = deriveClaimScope(completeness);
  result.record(
    "claim_scope_consistent",
    scope === statedScope,
    `basis ${pyRepr(get(completeness, "basis_type") ?? null)} yields ${scope}; ` +
      `certificate states ${pyRepr(statedScope)} (spec 21.4)`,
  );

  // -- 3: the claim is permitted by the claim scope (21.5) --------------
  // The *re-derived* scope gates the claim; the stated one has no standing.
  let detail;
  let permitted;
  if (NO_WINNER_SCOPES.has(scope) && WINNER_LIKE.has(outcome)) {
    permitted = false;
    detail =
      "PARTIAL_FAMILY MUST NOT support a globally phrased winner; this certificate " +
      `asserts ${outcome} over an incomplete family (spec 21.5)`;
  } else if (NO_WINNER_SCOPES.has(scope) && selected.length > 0 && outcome !== "HEURISTIC_ONLY") {
    permitted = false;
    detail =
      `PARTIAL_FAMILY names selected realizations ${pyStr(selected)} under outcome ${outcome}; ` +
      "only a heuristic incumbent or a blocked outcome is permitted";
  } else if (scope === "RELATIVE_EXPLICIT_FAMILY" && truthy(get(cert, "global_claim"))) {
    permitted = false;
    detail =
      "RELATIVE_EXPLICIT_FAMILY supports a relative winner only; this certificate is " +
      "phrased globally (spec 21.5)";
  } else {
    permitted = true;
    detail = `${scope} may carry outcome ${outcome}`;
  }
  result.record("claim_permitted_by_scope", permitted, detail);

  // -- 4: required object sufficient for the decision class -------------
  const declaredObject = pyStr(has(derivation, "required_object") ? derivation.required_object : "");
  const [needed, rule] = requiredObjectFor(objective);
  const sufficient =
    EXACT_MATCH_OBJECTS.has(declaredObject) || EXACT_MATCH_OBJECTS.has(needed)
      ? declaredObject === needed
      : (RANK.get(declaredObject) ?? -1) >= (RANK.get(needed) ?? 99);
  const kind = pyStr(pyOr(get(objective, "type"), "")).trim().toLowerCase();
  result.record(
    "required_object_sufficient",
    sufficient,
    `objective ${pyRepr(get(objective, "type") ?? null)}/` +
      `${pyStr(has(objective, "quantification") ? objective.quantification : "EACH_OBJECTIVE")} ` +
      `requires ${needed} (${rule}); derivation declares ${pyRepr(declaredObject)} for class ` +
      `${pyRepr(pyStr(has(derivation, "decision_class") ? derivation.decision_class : ""))}`,
  );
  // 26.3 names one reduction as unsound outright, so it is named here too
  // rather than left implicit in the ranking.
  const kAbuse =
    declaredObject === "K" &&
    (MONOTONE_NONADDITIVE.has(kind) ||
      pyStr(has(objective, "quantification") ? objective.quantification : "").toUpperCase() ===
        "ROBUST_AGGREGATE");
  result.record(
    "k_not_used_for_nonadditive_objective",
    !kAbuse,
    kAbuse
      ? `objective family ${pyRepr(kind)} is monotone but not an additive price, so it is not ` +
        "determined by the support values of nonnegative prices and K is insufficient " +
        "(spec 26.3, 26.4 row 4)"
      : `K claim check: declared object ${pyRepr(declaredObject)} against family ${pyRepr(kind)}`,
  );

  // -- 5: recompute the decision from the retained registry -------------
  verifyDecision(result, cert, reg, coordinateOrder(reg, cert), objective, values, outcome, selected, ties);
  // -- 6, 7 -------------------------------------------------------------
  verifyRegret(result, cert, reg);
  verifyDependencies(result, cert, reg);

  // -- 8: validity window against the verifier's clock ------------------
  const [timeStatus, judgment] = timeJudgment(cert, clock, clockSource);
  result.report.time_judgment = judgment;
  if (
    timeStatus === TimeStatus.EXPIRED ||
    timeStatus === TimeStatus.NOT_YET_VALID ||
    timeStatus === TimeStatus.CLOCK_POLICY_VIOLATION
  ) {
    result.record(
      "validity_window",
      false,
      `time status ${timeStatus}: issuer asserted expiry ` +
        `${pyRepr(judgment.issuer_asserted_expiry)}, verifier clock ` +
        `${pyRepr(judgment.verifier_evaluation_time)} from ${clockSource}`,
    );
  } else if (timeStatus === TimeStatus.TIME_INDETERMINATE) {
    result.note("validity_window", `TIME_INDETERMINATE (clock source: ${clockSource})`);
    result.warn(
      "no verifier clock or no declared expiry: the time claim is " +
        "indeterminate and MUST NOT be reported as current (spec 45.5)",
    );
  } else {
    result.record(
      "validity_window",
      true,
      `CURRENT at ${judgment.verifier_evaluation_time} (clock source: ${clockSource})`,
    );
  }

  // -- 9, 10 -------------------------------------------------------------
  verifyEvidence(
    result,
    cert,
    reg,
    asArray(pyOr(get(reg, "entries"), get(reg, "retained_entries"), get(reg, "realizations"), [])),
    values,
    outcome,
  );
  verifyArithmetic(result, cert, values, outcome);

  result.finish();
  result.status = finalStatus(result, scope, outcome, timeStatus);
  // Unsupported dependency closure is not a successful verification merely
  // because it creates no false arithmetic assertion.  The public `ok` flag
  // and the status must fail closed together (spec 6.6, 25.3-25.4).
  if (result.status === Status.UNVERIFIABLE_REDACTED) result.ok = false;
  Object.assign(result.report, {
    final_status: result.status,
    claim_judgment: {
      outcome,
      stated_claim_scope: statedScope,
      rederived_claim_scope: scope,
      selected,
      ties,
    },
    level_achieved: result.ok
      ? (result.status === Status.REPLAY_BOUND ? Level.V2 : Level.V3)
      : result.checks.some((c) => c.name === "content_hash" && !c.passed)
        ? "NONE"
        : Level.V0,
  });
  return result;
}

function finalStatus(result, scope, outcome, timeStatus) {
  if (timeStatus === TimeStatus.EXPIRED) return Status.EXPIRED;
  if (result.violations.length > 0) return Status.FAILED;
  if (result.report.content_withheld) {
    // 25.3 provides a status for exactly this case; using VERIFIED would let
    // an artifact gain a clean bill of health by carrying less.
    return Status.UNVERIFIABLE_REDACTED;
  }
  const unsupported = Array.isArray(result.report.unsupported_checks)
    ? result.report.unsupported_checks
    : [];
  if (unsupported.length > 0) {
    if (unsupported.some((item) => pyStr(item).startsWith("content_hash:"))) {
      return Status.FAILED;
    }
    return Status.PARTIALLY_VERIFIED;
  }
  if (timeStatus === TimeStatus.TIME_INDETERMINATE) return Status.TIME_INDETERMINATE;
  if (result.report.replay_bound) return Status.REPLAY_BOUND;
  if (scope === "RELATIVE_EXPLICIT_FAMILY") return Status.VERIFIED_RELATIVE;
  if (scope === "BOUNDED_REMAINDER_GLOBAL") return Status.VERIFIED_WITH_BOUNDED_REMAINDER;
  if (NO_WINNER_SCOPES.has(scope) && !WINNER_LIKE.has(outcome)) return Status.PARTIALLY_VERIFIED;
  return Status.VERIFIED;
}

// ---------------------------------------------------------------------------
// check 5: the winner really wins (22.3-22.5, 22.7)
// ---------------------------------------------------------------------------
function verifyDecision(result, cert, registry, order, objective, values, outcome, selected, ties) {
  const entries = asArray(
    pyOr(get(registry, "entries"), get(registry, "retained_entries"), get(registry, "realizations"), []),
  );
  if (entries.length === 0) {
    result.unsupported(
      "winner_recomputation",
      "no retained registry was supplied; the decision cannot be re-derived",
    );
    return;
  }
  if (order.length === 0) {
    result.record("winner_recomputation", false, "no coordinate schema is available");
    return;
  }

  const scopeBlock = asObject(pyOr(get(cert, "scope"), Object.create(null)));
  const domain = asObject(pyOr(get(scopeBlock, "technology_domain"), Object.create(null)));
  const recomputed = new Map();
  const signatures = new Map();
  const feasible = [];
  const infeasible = new Map();
  const unevaluable = [];
  for (const entry of entries) {
    const rid = pyStr(get(entry, "realization_id"));
    try {
      signatures.set(rid, asArray(pyOr(get(entry, "signature"), [])).map(rational));
    } catch (error) {
      if (!(error instanceof ArithError)) throw error;
      result.record("winner_recomputation", false, `${rid}: ${error.message}`);
      return;
    }
    const [status, reason] = feasibility(entry, domain);
    if (status === "INFEASIBLE") infeasible.set(rid, reason);
    else if (status === "FEASIBLE") feasible.push(rid);
    try {
      recomputed.set(rid, evaluateObjective(signatures.get(rid), objective, order));
    } catch (error) {
      if (!(error instanceof Unevaluable) && !(error instanceof ArithError)) throw error;
      unevaluable.push(rid);
    }
  }

  // 5a: the recomputed values must agree with the values the issuer recorded.
  const mismatches = [];
  for (const [rid, iv] of recomputed) {
    const stated = get(values, rid);
    if (stated === undefined || stated === null) {
      mismatches.push(`${rid}: no recorded objective value`);
      continue;
    }
    try {
      const decoded = interval(stated);
      if (!intervalEqual(decoded, iv)) {
        mismatches.push(
          `${rid}: recorded [${fmt(decoded[0])}, ${fmt(decoded[1])}] vs recomputed ` +
            `[${fmt(iv[0])}, ${fmt(iv[1])}]`,
        );
      }
    } catch (error) {
      if (!(error instanceof ArithError)) throw error;
      mismatches.push(`${rid}: ${error.message}`);
    }
  }
  if (unevaluable.length > 0) {
    result.unsupported(
      "objective_values_recomputed",
      `objective family ${pyRepr(get(objective, "type") ?? null)} is not ` +
        `signature-determined for ${pyStr(pySorted(unevaluable))}`,
    );
  } else {
    result.record(
      "objective_values_recomputed",
      mismatches.length === 0,
      mismatches.length > 0
        ? mismatches.join("; ")
        : `${recomputed.size} objective values recomputed exactly and matched`,
    );
  }

  // 5b: the feasibility partition must be independently re-derivable (22.7).
  const statedInfeasible = Object.keys(asObject(pyOr(get(cert, "infeasible"), Object.create(null))));
  const sameSize = statedInfeasible.length === infeasible.size;
  const samePartition = sameSize && statedInfeasible.every((rid) => infeasible.has(rid));
  result.record(
    "feasibility_partition",
    samePartition,
    `certificate declares ${pyStr(pySorted(statedInfeasible))} infeasible; ` +
      `independently re-derived ${pyStr(pySorted([...infeasible.keys()]))} (spec 22.7)`,
  );

  if (!WINNER_LIKE.has(outcome)) {
    result.note(
      "winner_beats_every_competitor",
      `outcome ${outcome} asserts no winner; nothing to re-derive`,
    );
    return;
  }

  const winners = selected.length > 0 ? [...selected] : [...ties];
  const absent = winners.filter((w) => !recomputed.has(w));
  const infeasibleWinners = winners.filter((w) => infeasible.has(w));
  for (const [reason, bad] of [
    [`outcome ${outcome} names no realization`, winners.length === 0],
    [
      `declared winners ${pyStr(absent)} are absent from the retained registry`,
      absent.length > 0,
    ],
    [
      `declared winners ${pyStr(infeasibleWinners)} are independently infeasible (spec 22.7)`,
      infeasibleWinners.length > 0,
    ],
  ]) {
    if (bad) {
      result.record("winner_beats_every_competitor", false, reason);
      return;
    }
  }
  let tau;
  try {
    tau = rational(has(scopeBlock, "tie_tolerance") ? scopeBlock.tie_tolerance : 0n);
  } catch (error) {
    if (!(error instanceof ArithError)) throw error;
    tau = ZERO;
  }
  if (tau.lt(ZERO)) {
    result.record("winner_beats_every_competitor", false, "policy tolerance is negative");
    return;
  }

  const paired = pairedRouteAvailable(objective, values);
  const failures = [];
  const routes = [];
  const competitors = feasible.filter((r) => !winners.includes(r));
  for (const q of competitors) {
    let beaten = false;
    for (const w of winners) {
      if (strictlyBelow(recomputed.get(w), recomputed.get(q), tau)) {
        routes.push(`${w} beats ${q} by interval (U_p + tau < L_q)`);
        beaten = true;
        break;
      }
      if (paired) {
        const margin = pairedMargin(signatures.get(w), signatures.get(q), objective, order);
        if (margin[0].gt(tau)) {
          routes.push(`${w} beats ${q} by paired margin inf ${fmt(margin[0])} > tau`);
          beaten = true;
          break;
        }
      }
    }
    if (!beaten) {
      failures.push(
        `${q} is not beaten: recomputed [${fmt(recomputed.get(q)[0])}, ` +
          `${fmt(recomputed.get(q)[1])}] against winner ` +
          winners
            .map((w) => `${w}=[${fmt(recomputed.get(w)[0])}, ${fmt(recomputed.get(w)[1])}]`)
            .join(", ") +
          ` at tau=${fmt(tau)}`,
      );
    }
  }
  if (outcome === "CERTIFIED_WINNER" && winners.length > 1) {
    failures.push(`CERTIFIED_WINNER names ${winners.length} realizations`);
  }
  if (outcome === "CERTIFIED_POLICY_TIE") {
    // 22.4: members mutually indifferent
    for (const a of winners) {
      for (const b of winners) {
        if (a < b && !withinTolerance(recomputed.get(a), recomputed.get(b), tau)) {
          failures.push(
            `tie members ${a} and ${b} are not within the declared tolerance ${fmt(tau)} (22.4)`,
          );
        }
      }
    }
  }
  result.record(
    "winner_beats_every_competitor",
    failures.length === 0,
    failures.length > 0
      ? failures.join("; ")
      : routes.length > 0
        ? `${competitors.length} competitors independently beaten: ${routes.join("; ")}`
        : "no competitors remain in the retained registry",
  );
}

// ---------------------------------------------------------------------------
// check 6: regret witness (27.3-27.4)
// ---------------------------------------------------------------------------
/** Phi(x) = ||(x - a)^+||_inf + eps * sum(x), the 27.3 construction. */
function phi(point, anchor, eps) {
  return positivePartSup(point, anchor).add(eps.mul(rationalSum(point)));
}

function verifyRegret(result, cert, registry) {
  const witness = get(cert, "regret_witness");
  if (!truthy(witness)) {
    result.note("regret_witness", "no regret witness is present");
    return;
  }
  const fullRaw = get(registry, "full_generators");
  const retainedRaw = get(registry, "retained_generators");
  if (fullRaw === null || fullRaw === undefined || retainedRaw === null || retainedRaw === undefined) {
    result.record(
      "regret_witness",
      false,
      "a regret witness is asserted but the full and retained generator sets " +
        "were not supplied, so its infima cannot be recomputed (27.4, 6.6)",
    );
    return;
  }
  let full;
  let retained;
  let anchor;
  let eps;
  let statedGap;
  let statedFull;
  let statedRetained;
  try {
    full = asArray(fullRaw).map((point) => asArray(point).map(rational));
    retained = asArray(retainedRaw).map((point) => asArray(point).map(rational));
    anchor = asArray(pyOr(get(witness, "lost_point"), [])).map(rational);
    eps = rational(has(witness, "epsilon") ? witness.epsilon : 0n);
    statedGap = rational(has(witness, "gap") ? witness.gap : 0n);
    statedFull = rational(has(witness, "full_infimum") ? witness.full_infimum : 0n);
    statedRetained = rational(has(witness, "retained_infimum") ? witness.retained_infimum : 0n);
  } catch (error) {
    if (!(error instanceof ArithError)) throw error;
    result.record("regret_witness", false, `witness is not exactly decodable: ${error.message}`);
    return;
  }
  if (retained.length === 0) {
    result.record("regret_witness", false, "the retained family is empty");
    return;
  }
  if (eps.lte(ZERO)) {
    result.record("regret_witness", false, `epsilon ${fmt(eps)} is not positive (27.3)`);
    return;
  }

  const failures = [];
  const sameVector = (a, b) => a.length === b.length && a.every((x, i) => x.eq(b[i]));
  if (!full.some((point) => sameVector(point, anchor))) {
    // 27.4.1
    failures.push("the lost point is not a member of the full basis (27.4.1)");
  }
  let separation = null;
  try {
    separation = minimum(retained.map((x) => positivePartSup(x, anchor)));
  } catch (error) {
    if (!(error instanceof ArithError)) throw error;
    separation = null;
  }
  if (separation === null || separation.lte(ZERO)) {
    // 27.4.2
    failures.push(
      "the lost point still lies in the retained upper region: some retained " +
        `point weakly dominates it (separation ${fmt(separation ?? ZERO)})`,
    );
  }
  if (pyStr(has(witness, "objective_family") ? witness.objective_family : "") !==
      "CONTINUOUS_STRICTLY_INCREASING_COERCIVE") {
    failures.push(
      `objective family ${pyRepr(get(witness, "objective_family") ?? null)} is not the named ` +
        "continuous, coordinatewise strictly increasing, coercive family (27.4.3)",
    );
  }
  // 27.4.4-5: recompute BOTH infima exactly, then check strict positivity.
  let infFull = null;
  let infRetained = null;
  try {
    infFull = minimum(full.map((x) => phi(x, anchor, eps)));
    infRetained = minimum(retained.map((x) => phi(x, anchor, eps)));
  } catch (error) {
    if (!(error instanceof ArithError)) throw error;
    infFull = null;
    infRetained = null;
  }
  if (infFull === null || infRetained === null) {
    failures.push("an infimum is undefined over an empty family");
  } else {
    const gap = infRetained.sub(infFull);
    if (gap.lte(ZERO)) failures.push(`recomputed regret gap ${fmt(gap)} is not positive (27.3)`);
    if (!gap.eq(statedGap)) {
      failures.push(
        `stated gap ${fmt(statedGap)} does not equal the recomputed gap ${fmt(gap)}`,
      );
    }
    if (!infFull.eq(statedFull)) {
      failures.push(
        `stated full-family infimum ${fmt(statedFull)} vs recomputed ${fmt(infFull)}`,
      );
    }
    if (!infRetained.eq(statedRetained)) {
      failures.push(
        `stated retained infimum ${fmt(statedRetained)} vs recomputed ${fmt(infRetained)}`,
      );
    }
  }
  const completeness = asObject(pyOr(get(cert, "completeness"), Object.create(null)));
  const basis = pyStr(has(completeness, "basis_type") ? completeness.basis_type : "");
  const kindOfWitness =
    basis === "EXHAUSTIVE_DECLARED_UNIVERSE" || basis === "GENERATOR_CLOSED" ? "GLOBAL" : "RELATIVE";
  result.report.regret_witness_scope = kindOfWitness; // 27.4.7
  result.record(
    "regret_witness",
    failures.length === 0,
    failures.length > 0
      ? failures.join("; ")
      : `both infima recomputed exactly; gap ${fmt(statedGap)} > 0; witness is ${kindOfWitness}`,
  );
}

// ---------------------------------------------------------------------------
// check 7: referenced dependencies (18.2, 14.4)
// ---------------------------------------------------------------------------
/**
 * A certificate references typed object identities and content hashes.
 *
 * Identities are checked for presence in the retained registry; content
 * hashes are recomputed from the carried object, because a hash the artifact
 * merely repeats to itself is not evidence of anything.
 */
function verifyDependencies(result, cert, registry) {
  const declared = [
    ...asArray(pyOr(get(cert, "dependencies"), [])),
    ...asArray(pyOr(get(cert, "evidence_roots"), [])),
  ];
  for (const key of ["complete_registry_hash", "retained_registry_hash"]) {
    if (truthy(get(cert, key))) declared.push(cert[key]);
  }
  if (declared.length === 0) {
    result.note("dependency_hashes", "no dependencies are referenced");
    return;
  }
  const objects = asObject(pyOr(get(registry, "objects"), Object.create(null)));
  // Registry-root hashes bind the registry document itself, not a member of
  // its optional objects side table.  The supplied registry is therefore
  // carried content and may be recomputed directly.
  const carriedRoots = new Set(truthy(registry) ? [contentHash(registry)] : []);
  const known = new Set(
    asArray(
      pyOr(get(registry, "entries"), get(registry, "retained_entries"), get(registry, "realizations"), []),
    ).map((e) =>
      pyStr(get(e, "realization_id")),
    ),
  );
  for (const rid of Object.keys(asObject(pyOr(get(cert, "objective_values"), Object.create(null))))) {
    known.add(rid);
  }

  const missing = [];
  const mismatched = [];
  const unresolved = [];
  let hashes = 0;
  let ids = 0;
  for (const reference of declared) {
    let refHash;
    let refId;
    if (isObject(reference)) {
      refHash = get(reference, "hash") ?? null;
      refId = get(reference, "id") ?? null;
    } else if (isHash(pyStr(reference))) {
      refHash = reference;
      refId = null;
    } else {
      refHash = null;
      refId = reference;
    }
    if (refHash !== null && refHash !== undefined) {
      if (!isHash(pyStr(refHash))) {
        missing.push(`${refId ?? refHash}: not a tagged content hash (14.4)`);
      } else if (carriedRoots.has(pyStr(refHash))) {
        hashes += 1;
      } else if (!has(objects, refHash)) {
        unresolved.push(pyStr(refHash));
      } else {
        hashes += 1;
        const recomputed = contentHash(objects[refHash]);
        if (recomputed !== refHash) mismatched.push(`${refHash} recomputes to ${recomputed}`);
      }
    } else if (refId !== null && refId !== undefined) {
      ids += 1;
      if (known.size > 0 && !known.has(pyStr(refId))) {
        missing.push(`object ${pyRepr(refId)} is absent from the retained registry`);
      }
    }
  }
  if (unresolved.length > 0 && !truthy(objects)) {
    // Spec 17.3, 25.3, 49.2: content withheld from the artifact means the
    // dependency chain could not be walked.  That is NOT a pass -- it
    // downgrades the final status to UNVERIFIABLE_REDACTED, because a
    // verifier that reported VERIFIED here would be certifying the absence
    // of evidence rather than the presence of it.
    result.unsupported(
      "dependency_hashes",
      `${unresolved.length} referenced objects are not carried in this ` +
        "artifact, so their content could not be recomputed",
    );
    result.report.missing_objects = pySorted([...unresolved, ...missing]);
    result.report.content_withheld = true;
    return;
  }
  missing.push(...unresolved);
  result.report.missing_objects = pySorted(missing);
  result.record(
    "dependency_hashes",
    missing.length === 0 && mismatched.length === 0,
    missing.length > 0 || mismatched.length > 0
      ? [...mismatched, ...missing.map((m) => `missing ${m}`)].join("; ")
      : `${hashes} content hashes recomputed and matched; ${ids} object ` +
        "identities resolved in the retained registry",
  );
}

// ---------------------------------------------------------------------------
// checks 9 and 10 (5.3, 22.6, 23.4)
// ---------------------------------------------------------------------------
function verifyEvidence(result, cert, registry, entries, values, outcome) {
  const heuristic = entries
    .filter((e) => pyStr(pyOr(get(e, "evidence_class"), "")).toUpperCase() === "HEURISTIC")
    .map((e) => `realization ${pyStr(get(e, "realization_id"))}`);
  if (pyStr(pyOr(get(cert, "evidence_class"), "")).toUpperCase() === "HEURISTIC") {
    heuristic.push("certificate envelope");
  }
  const witness = asObject(pyOr(get(cert, "regret_witness"), Object.create(null)));
  if (pyStr(pyOr(get(witness, "evidence_class"), "")).toUpperCase() === "HEURISTIC") {
    heuristic.push("regret witness");
  }
  for (const name of Object.keys(asObject(values))) {
    const value = values[name];
    if (isObject(value) && pyStr(pyOr(get(value, "solver_trust_profile"), "")).toUpperCase() === "HEURISTIC") {
      heuristic.push(`objective value ${name}`);
    }
  }
  for (const name of asArray(pyOr(get(registry, "heuristic_inputs"), []))) {
    heuristic.push(pyStr(name));
  }

  const certified = WINNER_LIKE.has(outcome) || outcome === "CERTIFIED_RETENTION";
  const blocked = certified && heuristic.length > 0;
  result.record(
    "heuristic_never_authorizes",
    !blocked,
    blocked
      ? `outcome ${outcome} is a certified outcome but rests on HEURISTIC-classed input: ` +
        `${pyStr(pySorted([...new Set(heuristic)]))}; a heuristic may propose or rank but MUST NOT ` +
        "authorize a certified result (spec 5.3, 23.6)"
      : heuristic.length === 0
        ? "no HEURISTIC-classed input authorizes this outcome"
        : `HEURISTIC inputs present but outcome ${outcome} is not a certified claim`,
  );
}

function replayBindingErrors(binding) {
  if (!isObject(binding)) return ["certificate has no replay_binding object"];
  const errors = [];
  for (const key of ["solver_identity", "solver_version", "platform_profile"]) {
    if (typeof binding[key] !== "string" || binding[key].trim().length === 0) {
      errors.push(`${key} must be a non-empty string`);
    }
  }
  if (!isObject(binding.parameters)) errors.push("parameters must be an object");
  if (!((typeof binding.seed === "string") || typeof binding.seed === "bigint" ||
        (Number.isInteger(binding.seed) && typeof binding.seed !== "boolean"))) {
    errors.push("seed must be a string or integer");
  }
  if (!((typeof binding.thread_count === "bigint" && binding.thread_count >= 1n) ||
        (Number.isInteger(binding.thread_count) && binding.thread_count >= 1))) {
    errors.push("thread_count must be a positive integer");
  }
  if (!isObject(binding.numeric_tolerances) || Object.keys(binding.numeric_tolerances).length === 0) {
    errors.push("numeric_tolerances must be a non-empty object");
  }
  if (binding.replay_status !== "REPLAYED_MATCHED") {
    errors.push("replay_status must be REPLAYED_MATCHED");
  }
  if (binding.mathematical_optimality_independently_proved !== false) {
    errors.push("mathematical_optimality_independently_proved must be false");
  }
  return errors;
}

function verifyArithmetic(result, cert, values, outcome) {
  if (!STRICT_WINNER.has(outcome)) {
    result.note("certifying_arithmetic_profile", `outcome ${outcome} is not a strict-winner claim`);
    return;
  }
  if (!truthy(values)) {
    result.record(
      "certifying_arithmetic_profile",
      false,
      "a strict-winner claim carries no decision-value records (22.2)",
    );
    return;
  }
  const bad = [];
  const replayValues = [];
  for (const name of Object.keys(asObject(values))) {
    const value = values[name];
    if (!isObject(value)) {
      bad.push(`${name}: not a decision-value record`);
      continue;
    }
    const profile = pyStr(has(value, "arithmetic_profile") ? value.arithmetic_profile : "UNDECLARED");
    const solver = pyStr(has(value, "solver_trust_profile") ? value.solver_trust_profile : "UNDECLARED");
    if (solver === "DETERMINISTIC_REPLAY") {
      replayValues.push(name);
      if (!REPLAY_ARITHMETIC.has(profile)) bad.push(`${name}: replay arithmetic profile ${profile}`);
    } else if (!CERTIFYING_SOLVER.has(solver)) {
      bad.push(
        `${name}: solver trust profile ${solver}; 23.4 requires ` +
          "PROOF_CHECKED or EXACT_RECOMPUTED",
      );
    } else if (!CERTIFYING_ARITHMETIC.has(profile)) {
      bad.push(`${name}: arithmetic profile ${profile}`);
    }
  }
  const binding = get(cert, "replay_binding");
  const replayErrors = replayValues.length > 0
    ? replayBindingErrors(binding)
    : binding !== undefined
      ? ["replay_binding is present but no objective value declares DETERMINISTIC_REPLAY"]
      : [];
  result.record(
    "replay_binding",
    replayErrors.length === 0,
    replayErrors.length > 0
      ? replayErrors.join("; ")
      : replayValues.length > 0
        ? `§23.5 replay disclosures complete for ${pyStr(pySorted(replayValues))}; replay matched ` +
          "and mathematical optimality is explicitly unproved"
        : "no replay-bound objective value is asserted",
  );
  if (replayValues.length > 0 && replayErrors.length === 0) result.report.replay_bound = true;
  result.record(
    "certifying_arithmetic_profile",
    bad.length === 0,
    bad.length > 0 ? bad.join("; ") : replayValues.length > 0
      ? "decision values satisfy the weaker, prominently disclosed §23.5 replay-bound operational profile"
      : "every decision value has certifying arithmetic and solver trust profiles (22.6, 23.4)",
  );
}
