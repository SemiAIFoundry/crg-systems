"""Conformance profiles, profile runs, and the conformance report (spec 48).

Specification 48.1 fixes thirteen profiles and the capability each requires.
Specification 48.2 fixes what official conformance costs, and -- the sentence
this module exists to honour -- states that *an implementation may truthfully
describe compatibility without claiming official conformance*.

Those are two different claims and this module keeps them two.  A report is
therefore never a boolean.  It carries a :class:`ConformanceStatus`, the
profile-by-profile record that supports it, the 48.2 checklist item by item,
and -- when official conformance is not available -- the exact sentence the
implementer *is* entitled to publish instead.

The suite reports what it observed.  It does not round a near miss up.  A
profile with one failing mandatory case is not conformant, and a report over an
implementation that cannot name itself is not an official conformance report
however many cases passed.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

__all__ = [
    "SUITE_VERSION",
    "SPEC_VERSION",
    "Profile",
    "CaseResult",
    "ProfileResult",
    "ConformanceStatus",
    "ConformanceReport",
    "run_profile",
    "run_all",
    "conformance_report",
]

#: Version of this conformance suite.  A conformance claim is meaningless
#: without it: "passes the suite" is a claim about a *published* suite at a
#: stated version (spec 48.2).
SUITE_VERSION = "1.4.0"

#: Version of the CRG Operational Systems Master Specification this suite
#: implements.  Distinct from :data:`SUITE_VERSION`: the suite may be revised
#: without the specification changing, and vice versa.
SPEC_VERSION = "0.2.0"


class Profile:
    """The conformance profiles of specification 48.1."""

    CRG_DATA = "CRG-DATA"
    CRG_GEOMETRY = "CRG-GEOMETRY"
    CRG_QUERY = "CRG-QUERY"
    CRG_GENERATE = "CRG-GENERATE"
    CRG_CERTIFY = "CRG-CERTIFY"
    CRG_VERIFY = "CRG-VERIFY"
    CRG_CHANGE = "CRG-CHANGE"
    CRG_CONVERT = "CRG-CONVERT"
    CRG_FEEDBACK = "CRG-FEEDBACK"
    ETQ_EVIDENCE = "ETQ-EVIDENCE"
    ETQ_QUALIFY = "ETQ-QUALIFY"
    ETQ_FEDERATE = "ETQ-FEDERATE"
    CRG_FULL = "CRG-FULL"

    #: The twelve profiles ``CRG-FULL`` is the conjunction of (48.1, last row:
    #: "All mandatory profiles under one compatible version").
    MANDATORY: Tuple[str, ...] = (
        CRG_DATA, CRG_GEOMETRY, CRG_QUERY, CRG_GENERATE, CRG_CERTIFY, CRG_VERIFY,
        CRG_CHANGE, CRG_CONVERT, CRG_FEEDBACK, ETQ_EVIDENCE, ETQ_QUALIFY, ETQ_FEDERATE,
    )

    ALL: Tuple[str, ...] = MANDATORY + (CRG_FULL,)

    #: Specification 48.1, column two, verbatim.
    REQUIRED_CAPABILITY: Mapping[str, str] = {
        CRG_DATA: "Canonical records, quantities, units, hashing, versions, "
                  "and bundle validation",
        CRG_GEOMETRY: "Canonical R, Gamma, K, fibers, and geometry envelopes",
        CRG_QUERY: "Decision language, derivation records, and soundness rules",
        CRG_GENERATE: "Generator interface, legality, rejection states, and "
                      "completeness effects",
        CRG_CERTIFY: "Safe commitment, numeric semantics, pruning, retention, "
                     "regret, and certificates",
        CRG_VERIFY: "CRG-VIR, proof checking, verification levels, and reports",
        CRG_CHANGE: "Typed dependency edges, reprice, re-embed, reopen, and "
                    "delta certificates",
        CRG_CONVERT: "Minimum-movement conversion and verification",
        CRG_FEEDBACK: "Evaluator protocol, witness registration, and transition records",
        ETQ_EVIDENCE: "Evidence, applicability, uncertainty, conflict, and "
                      "technology contracts",
        ETQ_QUALIFY: "Inverse qualification, experiment ranking, and stopping",
        ETQ_FEDERATE: "Capability envelopes, signatures, release policy, revocation, "
                      "and private evaluation",
        CRG_FULL: "All mandatory profiles under one compatible version",
    }

    @staticmethod
    def known(profile: str) -> bool:
        return profile in Profile.ALL


class ConformanceStatus:
    """What an implementation is entitled to say (spec 48.2)."""

    #: Every mandatory case passed in every declared profile, and every
    #: mechanically checkable 48.2 requirement is met.
    OFFICIALLY_CONFORMANT = "OFFICIALLY_CONFORMANT"

    #: Some declared profile has a failing mandatory case, or a 48.2 requirement
    #: is unmet.  The implementation may still truthfully describe compatibility
    #: with the profiles that did pass -- and only with those.
    COMPATIBLE_NOT_CONFORMANT = "COMPATIBLE_NOT_CONFORMANT"

    #: No declared profile passed.  Nothing may be claimed.
    NOT_CONFORMANT = "NOT_CONFORMANT"


# ---------------------------------------------------------------------------
# results
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class CaseResult:
    """One executed conformance case.

    ``spec_section`` is not decoration.  Specification 48.2 requires a
    published conformance report, and a report that says "6 failures" without
    saying which clause each failure is a failure of cannot be acted on, so
    every case carries its citation and every failure line reproduces it.
    """

    case_id: str
    kind: str                     # "INVARIANT" (49.2) or "GOLDEN" (49.3)
    profile: str
    spec_section: str
    passed: bool
    detail: str
    title: str = ""
    rationale: str = ""
    #: A non-mandatory case is a disclosed observation, not a conformance gate.
    #: It is reported in full, with its citation, and does not block the claim.
    mandatory: bool = True
    #: True when the implementation declined the operation the case needs.
    unsupported: bool = False

    @property
    def blocking(self) -> bool:
        """Whether this result prevents a conformance claim for its profile."""
        return self.mandatory and not self.passed

    def line(self) -> str:
        mark = "pass" if self.passed else ("SKIP" if self.unsupported else "FAIL")
        tag = "" if self.mandatory else " [advisory]"
        return f"  {mark:4s} {self.case_id:<44s} spec {self.spec_section}{tag}"


@dataclass(frozen=True)
class ProfileResult:
    """The outcome of one profile (spec 48.1)."""

    profile: str
    passed: int
    failed: int
    cases: List[CaseResult]
    ok: bool
    #: Cases that failed but were declared advisory, counted separately so the
    #: headline numbers stay honest in both directions.
    advisory_failed: int = 0
    #: True when the implementation did not declare this profile at all, which
    #: 48.2 requires it to disclose and which is not a failure.
    declared: bool = True
    spec_version: str = SPEC_VERSION
    suite_version: str = SUITE_VERSION

    @property
    def required_capability(self) -> str:
        return Profile.REQUIRED_CAPABILITY.get(self.profile, "")

    @property
    def failures(self) -> List[CaseResult]:
        return [c for c in self.cases if c.blocking]

    @property
    def advisories(self) -> List[CaseResult]:
        return [c for c in self.cases if not c.mandatory and not c.passed]


@dataclass(frozen=True)
class ConformanceReport:
    """A whole-suite result over one implementation (spec 48.2)."""

    implementation: str
    implementation_version: str
    implementation_spec_version: str
    suite_version: str
    spec_version: str
    profiles: List[ProfileResult]
    declared_profiles: Tuple[str, ...]
    undeclared_profiles: Tuple[str, ...]
    governance_policy: Optional[str]
    requirements: Mapping[str, bool] = field(default_factory=dict)
    status: str = ConformanceStatus.NOT_CONFORMANT

    @property
    def ok(self) -> bool:
        """True only when every declared profile passed every mandatory case."""
        return all(p.ok for p in self.profiles if p.declared)

    # CRG-FULL re-presents the cases of the twelve mandatory profiles, so it is
    # excluded from the whole-report counts: a case is counted once, under the
    # profile that owns it, plus CRG-FULL's own conjunction case.
    @property
    def _counted(self) -> List[ProfileResult]:
        return [p for p in self.profiles if p.profile != Profile.CRG_FULL]

    @property
    def passed(self) -> int:
        full = self.profile(Profile.CRG_FULL)
        own = sum(1 for c in (full.cases if full else [])
                  if c.profile == Profile.CRG_FULL and c.passed)
        return sum(p.passed for p in self._counted) + own

    @property
    def failed(self) -> int:
        full = self.profile(Profile.CRG_FULL)
        own = sum(1 for c in (full.cases if full else [])
                  if c.profile == Profile.CRG_FULL and c.blocking)
        return sum(p.failed for p in self._counted) + own

    @property
    def failures(self) -> List[CaseResult]:
        out: List[CaseResult] = []
        for profile in self._counted:
            out.extend(profile.failures)
        full = self.profile(Profile.CRG_FULL)
        if full is not None:
            out.extend(c for c in full.failures if c.profile == Profile.CRG_FULL)
        return out

    @property
    def conformant_profiles(self) -> Tuple[str, ...]:
        return tuple(p.profile for p in self.profiles if p.declared and p.ok)

    def profile(self, name: str) -> Optional[ProfileResult]:
        for result in self.profiles:
            if result.profile == name:
                return result
        return None

    def compatibility_statement(self) -> str:
        """The sentence this implementation is entitled to publish (spec 48.2)."""
        if self.status == ConformanceStatus.OFFICIALLY_CONFORMANT:
            return (
                f"{self.implementation} {self.implementation_version} is conformant with "
                f"CRG Operational Systems Master Specification v{self.spec_version} "
                f"profiles {', '.join(self.conformant_profiles)} under conformance suite "
                f"v{self.suite_version}."
            )
        conformant = self.conformant_profiles
        if not conformant:
            return (
                f"{self.implementation} {self.implementation_version} passed no profile of "
                f"CRG Operational Systems Master Specification v{self.spec_version} in "
                f"full and may make no compatibility or conformance claim."
            )
        return (
            f"{self.implementation} {self.implementation_version} is COMPATIBLE with CRG "
            f"Operational Systems Master Specification v{self.spec_version} profiles "
            f"{', '.join(conformant)} under conformance suite v{self.suite_version}. "
            "It is NOT officially conformant and MUST NOT be described as conformant."
        )


# ---------------------------------------------------------------------------
# running
# ---------------------------------------------------------------------------
def _default_implementation() -> Any:
    # Imported lazily: the suite's decision logic must be usable against a
    # foreign implementation without the reference modules being importable at
    # all (spec 48.3).
    from .reference import reference_implementation

    return reference_implementation()


def _cases_for(profile: str, implementation: Any) -> List[CaseResult]:
    from . import golden as _golden
    from . import invariants as _invariants

    results = list(_invariants.run_invariants(implementation, profile=profile))
    results.extend(_golden.run_vectors(implementation, profile=profile))
    return results


def run_profile(profile: str, *, implementation: Any = None) -> ProfileResult:
    """Run every case a specification 48.1 profile requires.

    ``CRG-FULL`` is not a profile with cases of its own: 48.1 defines it as
    *all mandatory profiles under one compatible version*, so it runs the twelve
    and is ``ok`` only when every one of them is.  "Under one compatible
    version" is checked too: the twelve must have been run against one
    implementation object reporting one version.
    """
    if not Profile.known(profile):
        raise ValueError(f"unknown conformance profile {profile!r} (spec 48.1)")
    implementation = implementation or _default_implementation()

    if profile == Profile.CRG_FULL:
        parts = [run_profile(p, implementation=implementation) for p in Profile.MANDATORY]
        return _full_profile(parts, implementation)

    supported = getattr(implementation, "supported_profiles", frozenset(Profile.MANDATORY))
    if profile not in supported:
        # Not a failure.  48.2 requires unsupported optional profiles to be
        # disclosed, and this is the disclosure.
        return ProfileResult(profile=profile, passed=0, failed=0, cases=[], ok=False,
                             declared=False)

    cases = _cases_for(profile, implementation)
    return ProfileResult(
        profile=profile,
        passed=sum(1 for c in cases if c.passed),
        failed=sum(1 for c in cases if c.blocking),
        cases=cases,
        ok=not any(c.blocking for c in cases),
        advisory_failed=sum(1 for c in cases if not c.mandatory and not c.passed),
    )


def _full_profile(parts: Sequence[ProfileResult], implementation: Any) -> ProfileResult:
    """Assemble ``CRG-FULL`` from already-run mandatory profiles (spec 48.1).

    ``CRG-FULL`` has no cases of its own.  48.1 defines it as *all mandatory
    profiles under one compatible version*, so it is the conjunction of the
    twelve plus one case asserting the conjunction held -- and the twelve are
    passed in already run, so a suite run never executes a profile twice.
    Running twice would be wrong as well as slow: the replay case of 49.3
    deliberately consumes a nonce, and a second run would meet its own leavings.
    """
    cases: List[CaseResult] = []
    for part in parts:
        cases.extend(part.cases)
    missing = [p.profile for p in parts if not p.declared]
    incomplete = [p.profile for p in parts if p.declared and not p.ok]
    detail_parts = []
    if missing:
        detail_parts.append("profiles not declared: " + ", ".join(missing))
    if incomplete:
        detail_parts.append("profiles with failing mandatory cases: "
                            + ", ".join(incomplete))
    full_ok = not missing and not incomplete
    cases.append(CaseResult(
        case_id="CRG-FULL/all-mandatory-profiles",
        kind="PROFILE", profile=Profile.CRG_FULL, spec_section="48.1",
        passed=full_ok,
        title="CRG-FULL requires every mandatory profile under one version",
        detail=(f"all {len(Profile.MANDATORY)} mandatory profiles pass under "
                f"{getattr(implementation, 'name', 'implementation')} "
                f"{getattr(implementation, 'version', '?')}"
                if full_ok else "; ".join(detail_parts)),
        rationale="48.1 defines CRG-FULL as the conjunction; a partial pass is not it.",
    ))
    return ProfileResult(
        profile=Profile.CRG_FULL,
        passed=sum(1 for c in cases if c.passed),
        failed=sum(1 for c in cases if c.blocking),
        cases=cases,
        ok=full_ok and not any(c.blocking for c in cases),
        advisory_failed=sum(1 for c in cases if not c.mandatory and not c.passed),
        declared=all(p.declared for p in parts),
    )


def _requirement_checklist(implementation: Any,
                           profiles: Sequence[ProfileResult]) -> Dict[str, bool]:
    """The five requirements of specification 48.2, as far as they are checkable."""
    name = getattr(implementation, "name", "") or ""
    version = getattr(implementation, "version", "") or ""
    declared = getattr(implementation, "supported_profiles", None)
    return {
        # "passing the published suite"
        "passes_the_published_suite":
            all(p.ok for p in profiles if p.declared and p.profile != Profile.CRG_FULL)
            and any(p.declared for p in profiles),
        # Rendering is not publication. The implementation must identify
        # release evidence outside this in-process result.
        "conformance_report_rendered":
            bool(getattr(implementation, "conformance_report_published", False)),
        # "disclosing unsupported optional profiles"
        "unsupported_profiles_disclosed": declared is not None,
        # "identifying implementation and version"
        "implementation_identified": bool(name.strip()) and bool(version.strip()),
        # A policy name is not evidence that the policy was met.
        "governance_policy_declared":
            bool(getattr(implementation, "governance_policy_met", False)),
    }


def run_all(*, implementation: Any = None) -> ConformanceReport:
    """Run every profile of specification 48.1 against one implementation."""
    implementation = implementation or _default_implementation()
    # The twelve mandatory profiles are run once; CRG-FULL is assembled from
    # them rather than re-run (see :func:`_full_profile`).
    profiles = [run_profile(p, implementation=implementation) for p in Profile.MANDATORY]
    profiles.append(_full_profile(profiles, implementation))
    requirements = _requirement_checklist(implementation, profiles)

    declared = tuple(p.profile for p in profiles if p.declared)
    undeclared = tuple(p.profile for p in profiles if not p.declared)
    if all(requirements.values()) and declared:
        status = ConformanceStatus.OFFICIALLY_CONFORMANT
    elif any(p.declared and p.ok for p in profiles):
        status = ConformanceStatus.COMPATIBLE_NOT_CONFORMANT
    else:
        status = ConformanceStatus.NOT_CONFORMANT

    return ConformanceReport(
        implementation=getattr(implementation, "name", "unnamed-implementation"),
        implementation_version=getattr(implementation, "version", "0.0.0"),
        implementation_spec_version=getattr(implementation, "spec_version", "unstated"),
        suite_version=SUITE_VERSION,
        spec_version=SPEC_VERSION,
        profiles=profiles,
        declared_profiles=declared,
        undeclared_profiles=undeclared,
        governance_policy=getattr(implementation, "governance_policy", None),
        requirements=requirements,
        status=status,
    )


# ---------------------------------------------------------------------------
# rendering
# ---------------------------------------------------------------------------
_RULE = "=" * 78
_THIN = "-" * 78

_REQUIREMENT_TEXT = {
    "passes_the_published_suite": "passing the published suite",
    "conformance_report_rendered": "publishing a conformance report",
    "unsupported_profiles_disclosed": "disclosing unsupported optional profiles",
    "implementation_identified": "identifying implementation and version",
    "governance_policy_declared": "meeting the applicable governance policy",
}


def conformance_report(report: ConformanceReport) -> str:
    """Render a human-readable conformance report (spec 48.2).

    The order is fixed and the omissions are deliberate.  Identification and
    versions come first, because a conformance claim that does not say *what*
    and *which version* is not a claim.  The status sentence comes before the
    counts, because a reader who stops after two lines must not be able to stop
    on a favourable number.  Every failure is listed with its specification
    citation; none is summarized away.
    """
    lines: List[str] = []
    add = lines.append

    add(_RULE)
    add("CRG SYSTEMS CONFORMANCE REPORT")
    add(_RULE)
    add(f"Implementation      : {report.implementation} {report.implementation_version}")
    add(f"Targets spec version: {report.implementation_spec_version}")
    add(f"Suite version       : crg-conformance {report.suite_version}")
    add(f"Specification       : CRG Operational Systems Master Specification "
        f"v{report.spec_version}")
    add(f"Governance policy   : {report.governance_policy or '(none declared)'}")
    add("")
    add(f"STATUS: {report.status}")
    add(report.compatibility_statement())
    add("")
    add(f"Cases: {report.passed} passed, {report.failed} failed "
        f"(mandatory), across {len(report.declared_profiles)} declared profile(s).")
    add("")

    add(_THIN)
    add("PROFILES (spec 48.1)")
    add(_THIN)
    for profile in report.profiles:
        if not profile.declared:
            add(f"{profile.profile:<14s} NOT DECLARED -- disclosed as unsupported "
                "(spec 48.2)")
            continue
        verdict = "CONFORMANT" if profile.ok else "NOT CONFORMANT"
        advisory = (f", {profile.advisory_failed} advisory"
                    if profile.advisory_failed else "")
        add(f"{profile.profile:<14s} {verdict:<15s} "
            f"{profile.passed} passed, {profile.failed} failed{advisory}")
        add(f"{'':<14s} requires: {profile.required_capability}")
    add("")

    add(_THIN)
    add("REQUIREMENTS FOR OFFICIAL CONFORMANCE (spec 48.2)")
    add(_THIN)
    for key, text in _REQUIREMENT_TEXT.items():
        met = report.requirements.get(key, False)
        add(f"  [{'x' if met else ' '}] {text}")
    if not report.requirements.get("governance_policy_declared", False):
        add("      note: the suite cannot verify a governance policy.  It records "
            "whether one")
        add("      was declared and never infers compliance from silence.")
    add("")

    failures = report.failures
    add(_THIN)
    add(f"FAILURES ({len(failures)})")
    add(_THIN)
    if not failures:
        add("  none.")
    for case in failures:
        add(f"  {case.profile} / {case.case_id}")
        add(f"    spec {case.spec_section} -- {case.kind.lower()} case")
        if case.title:
            add(f"    {case.title}")
        add(f"    observed: {case.detail}")
        if case.rationale:
            add(f"    why it matters: {case.rationale}")
    add("")

    advisories = [c for p in report._counted for c in p.advisories]
    if advisories:
        add(_THIN)
        add(f"ADVISORY OBSERVATIONS ({len(advisories)}) -- disclosed, not blocking")
        add(_THIN)
        for case in advisories:
            add(f"  {case.profile} / {case.case_id}  (spec {case.spec_section})")
            add(f"    {case.detail}")
        add("")

    add(_THIN)
    add("CASE DETAIL")
    add(_THIN)
    for profile in report.profiles:
        if not profile.declared or not profile.cases:
            continue
        # CRG-FULL re-presents cases already listed under their owning profile;
        # only its own conjunction case is new.
        cases = [c for c in profile.cases
                 if profile.profile != Profile.CRG_FULL or c.profile == Profile.CRG_FULL]
        if not cases:
            continue
        add(f"{profile.profile} (spec 48.1)")
        for case in cases:
            add(case.line())
    add(_RULE)
    return "\n".join(lines)
