"""The reference adapter: the CRG Systems modules behind the 48.3 boundary.

This module is the *default* implementation the suite tests, and nothing more.
It contains no conformance logic: it translates plain JSON requests into calls
on ``crg_model``, ``crg_geometry``, ``crg_generate``, ``crg_certify``,
``crg_verify``, ``crg_change``, ``crg_convert``, ``crg_io``, ``crg_feedback``,
``crg_server``, ``etq_evidence``, ``etq_qualify`` and ``etq_federation``, and
translates the answers back.  The judgements live in
:mod:`crg_conformance.invariants` and in ``golden/*.json``, so replacing this
module with a shim over a foreign implementation changes what is tested and
nothing about how it is judged (spec 48.3).

Every exact rational leaves this module as a canonical ``"p/q"`` string.
Binary floating point is never constructed, compared, or emitted (spec 14.2).
"""
from __future__ import annotations

import copy
import json
import os
import re
import tempfile
import zipfile
from dataclasses import replace as _dc_replace
from fractions import Fraction
from typing import Any, Dict, List, Mapping, Optional, Sequence

from crg_model.canonical import content_hash
from crg_model.completeness import ClaimScope, CompletenessBasis, CompletenessBasisType
from crg_model.edges import DependencyEdge, DependencyGraph, EdgeType
from crg_model.envelope import Envelope, EvidenceClass, ObjectStatus
from crg_model.numeric import Exact, Interval
from crg_model.records import (
    CertificatePins,
    ChangeEvent,
    Coordinate,
    CoordinateSchema,
    DecisionCertificate,
    DecisionScope,
    DecisionOutcome,
    DerivationRecord,
    Direction,
    ObservationLevel,
    RealizationBundle,
    RealizationRecord,
    Signature,
)

import crg_geometry
from crg_geometry import (
    build_K,
    build_R,
    build_gamma,
    certified_envelope,
    default_price_samples,
    region_included,
    support_error_bound,
    verify_geometry,
)

import crg_generate as _gen

from crg_certify import (
    QueryError,
    build_regret_witness,
    certified_pruning,
    certify,
    compile_query,
    parse_query,
    render_claim,
    retention_set,
    set_default_geometry,
    verify_regret_witness_detail,
)

from crg_verify import verify_bundle as _verify_bundle_file
from crg_verify import verify_certificate as _verify_certificate

from crg_io import read_bundle, verify_bundle_integrity, write_bundle
from crg_io.bundle import OBJECT_PREFIX

from crg_change import (
    build_impact_plan,
    certificate_dependencies,
    classify_property,
    explain_change,
    mark_stale,
    minimum_action,
)

from crg_convert import (
    Layout,
    SecondaryObjective,
    cell_overlaps,
    convert,
    is_nested,
    nested_closed_form,
    optimize_secondary,
    solve_max_assignment,
)

from crg_server.branch import MergeDecisionKind, MergeRule, merge_policy
from crg_server.errors import UsageError
from crg_server.jobs import JobContext
from crg_server.operations import op_migrate as _server_op_migrate

from etq_evidence import (
    AccessPolicy,
    ApplicabilityRule,
    ClockTrust,
    ConflictRefusal,
    ContextDescriptor,
    ContextPattern,
    CoordinateRequest,
    CorrelationAssumption,
    DifferenceKind,
    EvidenceRecord,
    EvidenceStatus,
    ExclusionKind,
    HardExclusion,
    MethodDescriptor,
    PermittedDifference,
    Provenance,
    QuantityType,
    ReasonCode,
    Requester,
    Transformation,
    TransformationKind,
    TransferModelKind,
    TransferUncertaintyModel,
    UncertaintyBudget,
    ValidityWindow,
    VerificationClock,
    apply_rule,
    assemble_technology_contract,
    classify_evidence_set,
    evaluate_time,
    fuse,
    select_rule,
)

from etq_qualify import (
    AcceptableAmbiguity,
    AmbiguityMetric,
    BurdenLimits,
    BurdenVector,
    BurdenWeights,
    DecisionPredicate,
    ExperimentDefinition,
    InformationEffect,
    NOT_STOPPED,
    PhaseRegion,
    PredicateState,
    QualificationObjective,
    RankingBasis,
    RankingTier,
    ResultModel,
    ResultModelKind,
    StoppingCondition,
    StoppingRule,
    invert,
    rank_experiments,
    region_ambiguity,
    stopping_reached,
)

from etq_federation import (
    Authorization,
    BoundedResult,
    CapabilityQuery,
    ClockAssertion,
    KeyRing,
    NonceLedger,
    ReleaseKind,
    ReleasePolicy,
    RevocationRegistry,
    SigningKey,
    VerifierExpectations,
    evaluate_private,
    issue_envelope,
    revoke,
)

from crg_feedback import (
    AUTHORIZE_TRANSITION,
    TRANSITION_PLAN_REQUIRED_ITEMS,
    Approver,
    AuditSpec,
    Capability,
    Configuration,
    DwellRequirement,
    EvaluatorRefusal,
    EvaluatorRequest,
    EvaluatorResponse,
    ExpectedBenefit,
    Hysteresis,
    IncompletePlan,
    Margin,
    MaturityLevel,
    PhaseGuard,
    Postcondition,
    ProtocolError,
    QuiescencePlan,
    RefusalReason,
    ResponseKind,
    RollbackPlan,
    TelemetryFreshness,
    TelemetrySample,
    TransitionClock,
    TransitionCost,
    TransitionPlan,
    TransitionRefused,
    TransitionRequirements,
    apply_feasibility,
    authorize,
    execute,
    plan_transition,
    promote_evidence_class,
    signoff_status,
    submit,
)

from .adapter import BaseImplementation
from .profiles import Profile

set_default_geometry(crg_geometry)

__all__ = ["ReferenceImplementation", "reference_implementation"]

REFERENCE_NAME = "crg-systems-reference"
REFERENCE_VERSION = "1.4.0"
SPEC_VERSION = "0.2.0"


# ===========================================================================
# shared helpers
# ===========================================================================
def _frac(value: Any) -> str:
    """Render an exact rational as a canonical ``"p/q"`` string (spec 14.2)."""
    if value is None:
        return None
    raw = value.value if hasattr(value, "value") else value
    fraction = Fraction(raw)
    return f"{fraction.numerator}/{fraction.denominator}"


def _sig_strings(signature: Signature) -> List[str]:
    return [str(v.value) for v in signature.values]


def _iv_string(interval: Any) -> Optional[str]:
    if interval is None:
        return None
    return f"[{interval.lo}, {interval.hi}]"


_DECISION_SCHEMA = CoordinateSchema(
    coordinates=(
        Coordinate(identifier="latency", quantity="time", unit="ns",
                   direction=Direction.MINIMIZE),
        Coordinate(identifier="energy", quantity="energy", unit="pJ",
                   direction=Direction.MINIMIZE),
    ),
    technology_context="conformance",
)


def _geometry_schema(dimension: int) -> CoordinateSchema:
    names = ("cost", "energy", "area", "mass", "time", "risk")
    return CoordinateSchema(
        coordinates=tuple(
            Coordinate(identifier=names[i], quantity=names[i], unit="unit",
                       direction=Direction.MINIMIZE)
            for i in range(dimension)
        ),
        technology_context="conformance",
    )


_BASIS_ARGS = {
    CompletenessBasisType.EXHAUSTIVE_DECLARED_UNIVERSE: {
        "declared_universe": "the declared conformance universe"},
    CompletenessBasisType.GENERATOR_CLOSED: {
        "declared_universe": "the closure of the declared generator set",
        "source_or_generator_hash": "sha256:" + "0" * 64},
    CompletenessBasisType.EXPLICIT_IMPORTED_FAMILY: {
        "declared_universe": "explicitly imported vendor candidates"},
    CompletenessBasisType.KNOWN_INCOMPLETE: {
        "declared_universe": "a partial sweep",
        "known_omissions": ("two vendors did not respond",)},
}


def _basis(request: Mapping[str, Any]) -> CompletenessBasis:
    """Build the completeness basis a certify request declares (spec 21.3)."""
    name = request.get("basis", CompletenessBasisType.EXHAUSTIVE_DECLARED_UNIVERSE)
    if name == CompletenessBasisType.BOUNDED_UNENUMERATED_FAMILY:
        return CompletenessBasis(
            basis_type=name,
            declared_universe="a bounded but unenumerated family",
            remainder_bound=request.get(
                "remainder_bound", "every unenumerated member costs at least 100"),
            closure_proof=request.get("closure_proof"),
        )
    if name == CompletenessBasisType.TRUNCATED_BY_DECLARED_RULE:
        return CompletenessBasis(
            basis_type=name,
            declared_universe="a declared but truncated closure",
            truncation_rule=request.get("truncation_rule", "MAX_DEPTH=1 (caller-declared)"),
        )
    return CompletenessBasis(basis_type=name, **_BASIS_ARGS[name])


def _decision_bundle(request: Mapping[str, Any]) -> RealizationBundle:
    """Build a decision bundle from a JSON candidate map."""
    candidates = request["candidates"]
    evidence = request.get("evidence_intervals") or {}
    infeasible = request.get("infeasible") or {}
    unknown = set(request.get("feasibility_unknown") or ())
    scopes = request.get("bound_scopes") or {}
    classes = request.get("evidence_classes") or {}
    realizations = []
    for identifier in sorted(candidates):
        attributes: Dict[str, Any] = {}
        if identifier in evidence:
            attributes["objective_evidence"] = list(evidence[identifier])
        if identifier in infeasible:
            attributes["feasible"] = False
            attributes["infeasible_reason"] = infeasible[identifier]
        if identifier in unknown:
            attributes["feasible"] = "UNKNOWN"
        if identifier in scopes:
            attributes["scope"] = scopes[identifier]
        realizations.append(
            RealizationRecord(
                realization_id=identifier,
                signature=Signature([Exact(v) for v in candidates[identifier]]),
                attributes=attributes,
                evidence_class=classes.get(identifier, EvidenceClass.EXACT),
            )
        )
    return RealizationBundle(
        bundle_id=request.get("bundle_id", "bundle-conformance"),
        schema=_DECISION_SCHEMA,
        realizations=realizations,
        completeness=_basis(request),
    )


def _query(request: Mapping[str, Any]) -> dict:
    """Build a decision query from a JSON request."""
    family = request.get("objective_family")
    if family is None:
        weights = request.get("objective") or {"latency": "1", "energy": "1"}
        family = {"type": "weighted_sum", "weights": dict(weights)}
    query = {
        "id": request.get("scope_id", "conformance-decision"),
        "objective_family": family,
        "quantification": request.get("quantification", "EACH_OBJECTIVE"),
        "ties": {
            "policy_tolerance": request.get("tolerance", "0"),
            "retain_all": True,
        },
    }
    if request.get("requested_object"):
        query["requested_object"] = request["requested_object"]
    if request.get("partial_family_policy"):
        query["objective_family"]["partial_family_policy"] = request["partial_family_policy"]
    return query


# ===========================================================================
# CRG-DATA
# ===========================================================================
def op_canonical_hash(request: Mapping[str, Any]) -> dict:
    """Spec 6.5, 14.3: identity is derived from canonical content."""
    payload = request["payload"]
    return {
        "hash": content_hash(payload),
        # A second hash over the same content presented in a different key
        # order must agree, or identity is not content-derived.
        "reordered_hash": content_hash(dict(reversed(list(payload.items()))))
        if isinstance(payload, dict) else content_hash(payload),
    }


def op_quantity_add(request: Mapping[str, Any]) -> dict:
    """Spec 13.1-13.4: no obligation arithmetic without declared units.

    ``crg_model`` carries a unit as a declared field on ``Coordinate``,
    ``DecisionValue`` and ``crg_generate.Obligation``, and its exact arithmetic
    is unit-free by construction, so the unit agreement is checked here, at the
    boundary where the two quantities meet.
    """
    a, b = request["a"], request["b"]
    for label, operand in (("a", a), ("b", b)):
        unit = operand.get("unit")
        if unit is None or (isinstance(unit, str) and not unit.strip()):
            return {
                "ok": False, "value": None, "unit": None,
                "refusal": (
                    f"operand {label} carries no declared unit; obligation arithmetic "
                    "on an unitless quantity is refused (spec 13.1)"
                ),
            }
    if a["unit"] != b["unit"]:
        return {
            "ok": False, "value": None, "unit": None,
            "refusal": (
                f"unit mismatch: {a['unit']!r} + {b['unit']!r}; addition is defined "
                "only within one declared unit (spec 13.2)"
            ),
        }
    total = Exact(a["value"]) + Exact(b["value"])
    return {"ok": True, "value": _frac(total), "unit": a["unit"], "refusal": None}


def _canonical_rotation(cycle: Sequence[str]) -> List[str]:
    """Normalize a reported cycle so the suite does not depend on hash order."""
    if len(cycle) < 2 or cycle[0] != cycle[-1]:
        return list(cycle)
    body = list(cycle[:-1])
    start = body.index(min(body))
    rotated = body[start:] + body[:start]
    return rotated + [rotated[0]]


def op_dependency_graph(request: Mapping[str, Any]) -> dict:
    """Spec 18.1-18.3: the typed dependency graph is acyclic."""
    graph = DependencyGraph()
    refusal = None
    cycle: List[str] = []
    accepted = 0
    for index, spec in enumerate(request.get("edges", ())):
        edge = DependencyEdge(
            edge_id=spec.get("edge_id", f"e{index}"),
            source=spec["source"],
            target=spec["target"],
            edge_type=getattr(EdgeType, spec.get("edge_type", "DERIVES_VALUE_FROM")),
        )
        try:
            graph.add_edge(edge)
        except ValueError as error:
            refusal = f"{type(error).__name__}: {error}"
            reported = str(error).split(":", 1)[1].strip().split(" -> ")
            cycle = _canonical_rotation(reported)
            break
        accepted += 1
    return {
        "ok": refusal is None,
        "cycle": cycle,
        "refusal": refusal,
        # The rejected edge is rolled back, so a refused cycle leaves no cycle
        # behind: an implementation that reported the cycle and kept the edge
        # would still hold a cyclic graph.
        "retained_edges": accepted,
        "residual_cycle": graph.find_cycle(),
        "nodes": sorted(graph.nodes),
    }


_BUNDLE_SCHEMA = {
    "coordinates": [
        {"identifier": "latency", "quantity": "time", "unit": "ns", "direction": "MINIMIZE"},
        {"identifier": "energy", "quantity": "energy", "unit": "pJ", "direction": "MINIMIZE"},
    ]
}
_BUNDLE_POINTS = {"p1": (1, 2), "p2": (2, 3), "p3": (4, 1)}


def _exact_json(value: Any) -> dict:
    return {"exact": str(value)}


def _interval_json(lo: Any, hi: Any = None) -> dict:
    return {"lo": _exact_json(lo), "hi": _exact_json(hi if hi is not None else lo)}


def _registry_bundle_document() -> dict:
    return {
        "bundle_id": "bundle-conf",
        "schema": _BUNDLE_SCHEMA,
        "realizations": [
            {"realization_id": rid, "signature": [_exact_json(v) for v in point],
             "legality": "LEGAL", "evidence_class": "IMPORTED"}
            for rid, point in sorted(_BUNDLE_POINTS.items())
        ],
        "completeness": {"basis_type": "EXHAUSTIVE_DECLARED_UNIVERSE",
                         "declared_universe": "the three declared packages"},
    }


def _decision_value_document(total: int) -> dict:
    return {
        "coordinate": "objective", "unit": "score",
        "numerical_interval": _interval_json(total),
        "combined_interval": _interval_json(total),
        "arithmetic_profile": "EXACT_RATIONAL",
        "solver_trust_profile": "EXACT_RECOMPUTED",
        "policy_tolerance": _exact_json(0),
    }


def _certificate_document() -> dict:
    body = _registry_bundle_document()
    bundle_hash = content_hash(body)
    document = {
        "certificate_id": "cert-conf-1",
        "outcome": "CERTIFIED_WINNER",
        "scope": {
            "scope_id": "package-choice", "observation_level": "ADDITIVE_PRICE",
            "objective_family": {
                "type": "weighted_sum",
                "weights": {"latency": ["1", "1"], "energy": ["1", "1"]},
                "weights_are_ranges": False, "quantification": "EACH_OBJECTIVE",
                "coordinate_order": ["latency", "energy"],
            },
            "technology_domain": {}, "tie_tolerance": _exact_json(0),
            "retain_all_ties": True, "retention_policy": "universal-monotone",
            "uncertainty_mode": "exact",
        },
        "derivation": {
            "query_hash": content_hash({"decision_id": "package-choice"}),
            "mapping_table_version": "1", "decision_class": "ADDITIVE_PRICE",
            "required_object": "K", "rule_cited": "R-ADD-08 (spec 26.4 row 5; 19.4)",
        },
        "claim_scope": "FULL_DECLARED_UNIVERSE",
        "completeness": body["completeness"],
        "complete_registry_hash": bundle_hash,
        "retained_registry_hash": bundle_hash,
        "semantic_pins": {
            "schema_versions": {"crg-core": "0.2.0"},
            "quantity_registry_version": "sha256:810b33ce38f3bf69be66fb153601782a4d73b125db1534ef810f82a088102bb1",
            "normative_rule_table_version": "sha256:d1b2c0226357d194f7fefbb7f2060ab96d9f7dc9f7cd19e2ac635cef55de81f5",
            "crg_vir_version": "0.2.0", "domain_pack_versions": {},
            "proof_checker_versions": {"crg-verify": "0.2.0", "crg-verify-js": "0.2.0"},
        },
        "selected": ["p1"], "ties": [], "runner_up": "p2",
        "objective_values": {
            "p1": _decision_value_document(3),
            "p2": _decision_value_document(5),
            "p3": _decision_value_document(5),
        },
        "geometry_preserved": True,
        "engine_versions": {"certify": "crg-certify@0.2.0"},
        "evidence_roots": [bundle_hash],
        "expiry": "2035-01-01T00:00:00Z", "issued_at": "2026-01-01T00:00:00Z",
    }
    document["certificate_hash"] = content_hash(document)
    return document


def _certificate_registry() -> dict:
    body = _registry_bundle_document()
    return {
        "schema": _BUNDLE_SCHEMA,
        "entries": [
            {"realization_id": rid, "signature": [_exact_json(v) for v in point],
             "legality": "LEGAL", "evidence_class": "IMPORTED"}
            for rid, point in sorted(_BUNDLE_POINTS.items())
        ],
        "objects": {content_hash(body): body},
    }


def op_bundle_verify(request: Mapping[str, Any]) -> dict:
    """Spec 39, 25.6: a bundle is content addressed and independently checkable."""
    clock = request.get("clock_at", "2026-08-24T00:00:00Z")
    with tempfile.TemporaryDirectory(prefix="crg-conformance-") as workspace:
        path = os.path.join(workspace, "conformance.crg")
        manifest_hash = write_bundle(
            path,
            case={"case_id": "case-conf-1", "crg_spec_version": SPEC_VERSION,
                  "quantity_registry_version": "0.2.0", "rule_table_version": "1"},
            objects={"bundle-conf": _registry_bundle_document(),
                     "cert-conf-1": _certificate_document()},
        )
        clean_violations = verify_bundle_integrity(path)
        # This golden case carries a decision certificate but no CRG-VIR proof
        # program, so section 25.2 permits V2, not V3.
        clean = _verify_bundle_file(
            path, level="V2", clock=clock, clock_source="conformance-clock"
        )
        read_ok = True
        try:
            read_bundle(path)
        except Exception as error:
            read_ok = f"{type(error).__name__}: {error}"

        if not request.get("corrupt", True):
            return {
                "manifest_hash": manifest_hash,
                "clean_ok": not clean_violations and clean.ok,
                "clean_status": clean.status,
                "read_ok": read_ok,
                "corrupt_ok": None, "corrupt_status": None, "corrupt_reason": None,
            }

        with zipfile.ZipFile(path, "r") as archive:
            members = {name: archive.read(name) for name in archive.namelist()}
            comment = archive.comment
        target = next(name for name in sorted(members)
                      if name.startswith(OBJECT_PREFIX) and b"LEGAL" in members[name])
        # One byte, and the member stays syntactically valid JSON: nothing but
        # the content hash can catch this.
        members[target] = members[target].replace(b"LEGAL", b"LEGAk", 1)
        corrupt_path = os.path.join(workspace, "corrupt.crg")
        with zipfile.ZipFile(corrupt_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            for name in sorted(members):
                archive.writestr(name, members[name])
            archive.comment = comment

        corrupt_violations = verify_bundle_integrity(corrupt_path)
        corrupt = _verify_bundle_file(
            corrupt_path, level="V2", clock=clock, clock_source="conformance-clock"
        )
        corrupt_read = "accepted"
        try:
            read_bundle(corrupt_path)
        except Exception as error:
            corrupt_read = f"{type(error).__name__}"
        return {
            "manifest_hash": manifest_hash,
            "clean_ok": not clean_violations and clean.ok,
            "clean_status": clean.status,
            "read_ok": read_ok,
            "corrupted_member": target,
            "corrupt_ok": not corrupt_violations and corrupt.ok,
            "corrupt_status": corrupt.status,
            "corrupt_reason": "; ".join(corrupt_violations) or "no integrity violation found",
            "corrupt_read": corrupt_read,
        }


# ===========================================================================
# CRG-GEOMETRY
# ===========================================================================
def _geometry_bundle(points: Mapping[str, Sequence[str]],
                     legality: Optional[Mapping[str, str]] = None) -> RealizationBundle:
    dimension = len(next(iter(points.values())))
    return RealizationBundle(
        bundle_id="bundle-geometry",
        schema=_geometry_schema(dimension),
        realizations=[
            RealizationRecord(
                realization_id=rid,
                signature=Signature([Exact(v) for v in values]),
                legality=(legality or {}).get(rid, "LEGAL"),
            )
            for rid, values in points.items()
        ],
        completeness=CompletenessBasis(
            basis_type=CompletenessBasisType.EXHAUSTIVE_DECLARED_UNIVERSE,
            declared_universe="the declared conformance universe"),
    )


def op_build_geometry(request: Mapping[str, Any]) -> dict:
    """Spec 19.2-19.6: R keeps fibers, Gamma reduces, K hulls; none of them merge."""
    points = request["points"]
    bundle = _geometry_bundle(points, request.get("legality"))
    r = build_R(bundle)
    gamma = build_gamma(r)
    k = build_K(r)
    return {
        "fibers": [
            {"signature": _sig_strings(fiber.signature),
             "realization_ids": list(fiber.realization_ids)}
            for fiber in r.fibers
        ],
        "fiber_count": len(r.fibers),
        "realization_count": sum(len(f.realization_ids) for f in r.fibers),
        "frontier": [_sig_strings(s) for s in gamma.frontier],
        "vertices": [_sig_strings(v) for v in k.vertices],
        "dominated_available": bool(gamma.dominated_available),
        "verify_errors": list(verify_geometry(r, gamma, k)),
        "root_hash": r.root_hash(),
    }


def op_support_claim(request: Mapping[str, Any]) -> dict:
    """Spec 19.5, 20.1-20.3: a finite price sample bounds, it does not prove."""
    inner = build_gamma(build_R(_geometry_bundle(request["inner"])))
    outer = build_gamma(build_R(_geometry_bundle(request["outer"])))
    declared = request.get("price_samples")
    samples = (default_price_samples(inner.schema.dimension) if declared is None
               else [[Exact(c) for c in vector] for vector in declared])
    try:
        envelope = certified_envelope(inner, outer, samples)
    except ValueError as error:
        return {"exact": False, "bound": None, "samples_proved": False,
                "claim_limit": None,
                "reason": f"certified_envelope refused: {error}"}
    semantics = envelope.error_semantics
    epsilon = support_error_bound(inner, outer, samples)
    forward = region_included(inner, outer)
    backward = region_included(outer, inner)
    exact = bool(semantics.get("exact_region_inclusion")) and forward and backward
    return {
        # The only exact statement available is mutual region inclusion, which
        # is decided by exact dominance and an exact rational LP.  The epsilon
        # is a maximum over a declared finite sample set and can never upgrade
        # to an exactness claim, whatever evidence class the caller declares.
        "exact": exact,
        "bound": _frac(epsilon),
        "samples_proved": False,
        "claim_limit": semantics["claim_limit"],
        "price_domain": semantics["support_value_error"]["price_domain"],
        "sample_count": semantics["support_value_error"]["sample_count"],
        "inclusion_forward": forward,
        "inclusion_backward": backward,
        "reason": (
            "mutual exact region inclusion holds, so the two upper sets are provably equal"
            if exact else
            f"epsilon is a maximum over {len(samples)} declared price vectors; "
            f"claim_limit={semantics['claim_limit']}"
        ),
    }


# ===========================================================================
# CRG-QUERY
# ===========================================================================
def op_compile_query(request: Mapping[str, Any]) -> dict:
    """Spec 26.4, 26.6: the required object is derived, and never lowered on request."""
    try:
        query = parse_query(_query(request))
        scope, derivation = compile_query(query)
    except QueryError as error:
        return {"ok": False, "observation_level": None, "required_object": None,
                "rule_cited": None, "refusal": f"QueryError: {error}"}
    refusals = list(derivation.refusals)
    return {
        "ok": True,
        "observation_level": scope.observation_level,
        "required_object": derivation.required_object,
        "rule_cited": derivation.rule_cited,
        "retention_policy": scope.retention_policy,
        "quantification": str(query.get("quantification", "EACH_OBJECTIVE")),
        "refusal": "; ".join(refusals) if refusals else None,
        "query_hash": derivation.query_hash,
    }


# ===========================================================================
# CRG-GENERATE
# ===========================================================================
_GEN_SCHEMA = CoordinateSchema(coordinates=(
    Coordinate(identifier="primary", quantity="primary", unit="1",
               direction=Direction.MINIMIZE),
    Coordinate(identifier="secondary", quantity="secondary", unit="1",
               direction=Direction.MINIMIZE),
))

_PLACEMENT_MODEL = {
    "tasks": {"t1": {"work": "2"}, "t2": {"work": "3"}},
    "nodes": {"n1": {"rate": "1", "price": "2"}, "n2": {"rate": "2", "price": "5"}},
    "coordinates": {"time": "primary", "cost": "secondary"},
}


def _placement_context() -> Any:
    return _gen.GenerationContext(
        schema=_GEN_SCHEMA, capabilities={},
        parameters={"placement_model": _PLACEMENT_MODEL},
        declared_universe="every placement of the declared tasks onto the declared nodes")


def _finite_context() -> Any:
    return _gen.GenerationContext(
        schema=_GEN_SCHEMA, capabilities={}, parameters={},
        declared_universe="the closure of the declared finite transformation rules")


def _finite_source() -> Any:
    seed = _gen.seed_record(
        source_id="finite-source",
        signature=Signature([Exact("100"), Exact("100")]),
        attributes={"policy": "store", "granularity": "fused", "replicas": 0},
        evidence_class=EvidenceClass.CONSTRUCTIVE)
    return _gen.GenerationSource(
        source_id="finite-source", source_type="EXPLICIT_RECORDS", seeds=(seed,),
        computation_contract={"contract_id": "cc-1", "version": "1"},
        resource_contract={"contract_id": "rc-1", "version": "1"})


def op_generate_family(request: Mapping[str, Any]) -> dict:
    """Spec 21.2-21.6, 28.3-28.6: the basis is derived from what generation did."""
    kind = request.get("generator", "placement")
    if kind == "placement":
        context = _placement_context()
        source = _gen.GenerationSource(
            source_id="placement-source", source_type="PLACEMENT",
            seeds=(_gen.placement_seed({"t1": "n1", "t2": "n1"}, context),),
            computation_contract={"contract_id": "cc-p", "version": "1"})
        kwargs: Dict[str, Any] = {}
        if request.get("determinism"):
            kwargs["determinism_status"] = request["determinism"]
        generators = [_gen.placement_generator(**kwargs)]
    else:
        context = _finite_context()
        source = _finite_source()
        kwargs = {"primary": "primary", "secondary": "secondary"}
        if request.get("determinism"):
            kwargs["determinism_status"] = request["determinism"]
        generators = [_gen.finite_transformation_generator(**kwargs)]

    build: Dict[str, Any] = {"schema": _GEN_SCHEMA, "context": context,
                             "generators": generators}
    if request.get("max_depth") is not None:
        build["max_depth"] = request["max_depth"]
    if request.get("max_size") is not None:
        build["max_size"] = request["max_size"]

    bundle, report = _gen.build_registry(source, **build)
    # Determinism is *measured*, never taken on the declaration: the registry is
    # rebuilt and the two canonical bundle hashes are compared.
    again, _ = _gen.build_registry(source, **build)

    declared = request.get("determinism", _gen.DeterminismStatus.DETERMINISTIC)
    may_close = declared in _gen.DeterminismStatus.MAY_CLOSE_A_FAMILY
    return {
        "basis": bundle.completeness.basis_type,
        "claim_scope": report.claim_scope,
        "realization_ids": [r.realization_id for r in bundle.realizations],
        "statuses": {r.realization_id: r.legality for r in bundle.realizations},
        "ungenerated_regions": [u.to_canonical() for u in report.ungenerated],
        "ungenerated_count": len(report.ungenerated),
        "infeasible_count": report.legality_of(_gen.LegalityStatus.INFEASIBLE),
        "deterministic": bundle.bundle_hash() == again.bundle_hash(),
        "declared_determinism": declared,
        "may_close_a_family": may_close,
        "refused_closure": (bundle.completeness.basis_type
                            != CompletenessBasisType.GENERATOR_CLOSED and not may_close),
        "reached_fixpoint": bool(report.closure_report.reached_fixpoint),
        "truncated": bool(report.closure_report.truncated),
        "known_omissions": list(bundle.completeness.known_omissions),
        "warnings": list(report.warnings),
    }


# ===========================================================================
# CRG-CERTIFY
# ===========================================================================
def op_certify_decision(request: Mapping[str, Any]) -> dict:
    """Spec 22.3-22.7, 29: a decision, or a named refusal to make one."""
    bundle = _decision_bundle(request)
    scope, derivation = compile_query(_query(request))
    retained = request.get("retained")
    certificate = certify(bundle, scope, derivation, geometry=crg_geometry,
                          retained=retained)
    all_ids = sorted(r.realization_id for r in bundle.realizations)
    kept = sorted(retained) if retained is not None else all_ids
    return {
        "outcome": certificate.outcome,
        "winners": list(certificate.selected),
        "winner_count": len(certificate.selected),
        "ties": list(certificate.ties),
        "runner_up": certificate.runner_up,
        "margin": (certificate.margin.to_canonical()
                   if certificate.margin is not None else None),
        "pruned": [i for i in all_ids if i not in set(kept)],
        "retained": kept,
        "claim_scope": certificate.claim_scope,
        "global_claim": certificate.claim_scope in ClaimScope.STRONG,
        "infeasible": dict(certificate.infeasible),
        "geometry_preserved": bool(certificate.geometry_preserved),
        "reopen_conditions": list(certificate.reopen_conditions),
        "claim": render_claim(certificate),
    }


def op_prune(request: Mapping[str, Any]) -> dict:
    """Spec 29.2: ten conditions, and condition 3 is the decision scope."""
    bundle = _decision_bundle(request)
    scope, _ = compile_query(_query(request))
    candidates = list(request.get("prune_candidates")
                      or sorted(request["candidates"]))
    certificates = certified_pruning(bundle, scope, candidates, geometry=crg_geometry)
    pruned = sorted(c.pruned_id for c in certificates)
    all_ids = sorted(request["candidates"])
    mismatches = []
    for identifier in candidates:
        declared = (request.get("bound_scopes") or {}).get(identifier)
        if declared is not None and str(declared) != scope.scope_id:
            mismatches.append(
                f"{identifier}: bound was issued under decision scope {declared!r}, "
                f"query scope is {scope.scope_id!r} (spec 29.2 condition 3)")
    refusal = None
    if mismatches:
        refusal = "REFUSED PRUNING (scope mismatch): " + "; ".join(mismatches)
    elif not certificates and candidates:
        refusal = ("REFUSED PRUNING: no candidate discharged all ten conditions of "
                   "spec 29.2")
    return {
        "pruned": pruned,
        "retained": [i for i in all_ids if i not in set(pruned)],
        "refusal": refusal,
        "scope_id": scope.scope_id,
        "certificate_count": len(certificates),
    }


def op_retention(request: Mapping[str, Any]) -> dict:
    """Spec 22.2, 27.3-27.4: retention is safe only against declared scopes."""
    bundle = _decision_bundle(request)
    initial_scope, initial_derivation = compile_query(
        _query({"scope_id": "initial-additive-price",
                "objective": request.get("initial_objective", {"latency": "1",
                                                               "energy": "3"})}))
    later_query = {"id": "later-bottleneck",
                   "objective_family": request.get("later_objective_family",
                                                   {"type": "max"})}
    later_scope, later_derivation = compile_query(later_query)

    kept_initial = list(retention_set(bundle, [initial_scope], None))
    kept_union = list(retention_set(bundle, [initial_scope, later_scope], None))
    all_ids = sorted(r.realization_id for r in bundle.realizations)

    full = certify(bundle, later_scope, later_derivation, geometry=crg_geometry)
    truncated = certify(bundle, later_scope, later_derivation, geometry=crg_geometry,
                        retained=tuple(kept_initial))
    winner = full.selected[0] if full.selected else ""
    witness = truncated.regret_witness
    return {
        "initial_retained": kept_initial,
        "pruned_out": [i for i in all_ids if i not in set(kept_initial)],
        "winner_under_later_objective": winner,
        "retained_covers_it": winner in kept_initial,
        "union_retained": kept_union,
        "union_covers_it": winner in kept_union,
        "initial_required_object": initial_derivation.required_object,
        "later_required_object": later_derivation.required_object,
        "full_family_outcome": full.outcome,
        "truncated_outcome": truncated.outcome,
        "truncated_geometry_preserved": bool(truncated.geometry_preserved),
        "truncated_winners": list(truncated.selected),
        "regret_witness": witness.to_canonical() if witness is not None else None,
    }


def op_regret_witness(request: Mapping[str, Any]) -> dict:
    """Spec 27.3-27.4: the witness is re-derived by the checker, not read."""
    full = tuple(Signature([Exact(c) for c in point]) for point in request["full_frontier"])
    retained = tuple(Signature([Exact(c) for c in point])
                     for point in request["retained_frontier"])
    witness = build_regret_witness(full, retained, _DECISION_SCHEMA)
    if witness is None:
        return {"phi": None, "verified": False, "exists": False,
                "detail": "no witness exists: the retention lost no point of the upper set"}
    tamper = request.get("tamper")
    if tamper:
        witness = _dc_replace(witness, **{
            key: (Signature([Exact(c) for c in value]) if key == "lost_point"
                  else Exact(value))
            for key, value in tamper.items()})
    ok, failures = verify_regret_witness_detail(witness, full, retained)
    return {
        "phi": witness.objective_family,
        "verified": bool(ok),
        "exists": True,
        "detail": ("; ".join(failures) if failures else
                   f"recomputed: epsilon={witness.epsilon}, gap={witness.gap} > 0"),
        "lost_point": [str(v.value) for v in witness.lost_point.values],
        "construction": witness.construction,
        "gap": _frac(witness.gap),
    }


# ===========================================================================
# CRG-VERIFY
# ===========================================================================
def op_verify_certificate(request: Mapping[str, Any]) -> dict:
    """Spec 24, 25.2-25.5: the verifier re-derives; it does not trust the issuer."""
    if request.get("heuristic_solver_trust"):
        # A certificate issued over exact input, then presented with a decision
        # value whose solver trust profile is HEURISTIC.  Specification 5.3 and
        # 23.6: a heuristic may propose or rank, but MUST NOT authorize.
        bundle = _decision_bundle({"candidates": {"fast": ["1", "1"],
                                                  "slow": ["5", "5"]}})
        scope, derivation = compile_query(_query({"scope_id": "heuristic-verify"}))
        issued = certify(bundle, scope, derivation, geometry=crg_geometry)
        document = json.loads(json.dumps(issued.to_canonical()))
        document["certificate_hash"] = issued.certificate_hash()
        registry = {
            "coordinate_order": ["latency", "energy"],
            "signatures": {r.realization_id: [v.to_canonical() for v in r.signature.values]
                           for r in bundle.realizations},
            "heuristic_inputs": [],
        }
        for value in document["objective_values"].values():
            value["solver_trust_profile"] = "HEURISTIC"
        result = _verify_certificate(document, registry=registry)
        named = {name: (passed, detail) for name, passed, detail in result.checks}
        heuristic_pass, heuristic_detail = named.get(
            "heuristic_never_authorizes", (None, "check absent"))
        return {
            "status": result.status,
            "ok": bool(result.ok),
            "reasons": list(result.violations),
            "warnings": list(result.warnings),
            "unsupported_checks": list(result.report.get("unsupported_checks") or []),
            "outcome": document["outcome"],
            "heuristic_never_authorizes": heuristic_pass,
            "heuristic_detail": heuristic_detail,
        }

    document = _certificate_document()
    registry = copy.deepcopy(_certificate_registry())
    objects = dict(registry["objects"])
    for reference in request.get("withhold", ()):
        # Withholding by *position* -- the first pinned dependency -- keeps the
        # vector free of a content hash that would change if the fixture did.
        # A decoy replaces it so the objects store stays non-empty: this is the
        # partial redaction of 25.4, not an artifact that carries no objects.
        if reference == "first" and objects:
            key = sorted(objects)[0]
            body = objects.pop(key)
            decoy = copy.deepcopy(body)
            decoy["bundle_id"] = "bundle-decoy"
            objects[content_hash(decoy)] = decoy
    if request.get("withhold_all"):
        objects = {}
    for reference in request.get("stale_dependencies", ()):
        if reference == "first" and objects:
            key = sorted(objects)[0]
            body = copy.deepcopy(objects[key])
            body["bundle_id"] = str(body.get("bundle_id", "")) + "-v2"
            objects[key] = body
    registry["objects"] = objects
    result = _verify_certificate(
        document, registry=registry,
        clock=request.get("clock_at", "2026-08-24T00:00:00Z"),
        clock_source="conformance-clock")
    return {
        "status": result.status,
        "ok": bool(result.ok),
        "reasons": list(result.violations),
        "warnings": list(result.warnings),
        "unsupported_checks": list(result.report.get("unsupported_checks") or []),
        "missing_objects": list(result.report.get("missing_objects") or []),
        "affirmative": bool(result.ok) and not result.report.get("unsupported_checks"),
    }


# ===========================================================================
# CRG-CHANGE
# ===========================================================================
class _GraphNode:
    """An object carrying an envelope, so ``mark_stale`` can reach its status."""

    def __init__(self, object_id: str, kind: str) -> None:
        self.object_kind = kind
        self.envelope = Envelope(object_id=object_id, object_type=kind)

    def to_canonical(self) -> dict:
        return {"object_kind": self.object_kind}


_CHANGE_OBJECTS = {
    "price-a": "PRICE_MODEL", "embed-a": "EMBEDDING_MODEL", "cap-a": "CAPABILITY_MODEL",
    "gamma-a": "GEOMETRY", "decision-a": "DECISION", "cert-a": "CERTIFICATE",
    "price-b": "PRICE_MODEL", "embed-b": "EMBEDDING_MODEL", "cap-b": "CAPABILITY_MODEL",
    "gamma-b": "GEOMETRY", "decision-b": "DECISION", "cert-b": "CERTIFICATE",
    "registry": "CANDIDATE_REGISTRY",
}

_CHANGE_EDGES = (
    {"edge_id": "e-price-a", "source": "price-a", "target": "gamma-a",
     "edge_type": "DEPENDS_ON_PRICE_OF", "source_property": "price.package_gbps"},
    {"edge_id": "e-embed-a", "source": "embed-a", "target": "gamma-a",
     "edge_type": "DEPENDS_ON_EMBEDDING_OF", "source_property": "embedding.placement"},
    {"edge_id": "e-cap-a", "source": "cap-a", "target": "gamma-a",
     "edge_type": "DEPENDS_ON_CAPABILITY_OF", "source_property": "capability.primitives"},
    {"edge_id": "e-reg-a", "source": "registry", "target": "gamma-a",
     "edge_type": "DEPENDS_ON_MEMBERSHIP_OF", "source_property": "members"},
    {"edge_id": "e-dec-a", "source": "gamma-a", "target": "decision-a",
     "edge_type": "DERIVES_VALUE_FROM"},
    {"edge_id": "e-cert-a", "source": "decision-a", "target": "cert-a",
     "edge_type": "DERIVES_VALUE_FROM"},
    {"edge_id": "e-price-b", "source": "price-b", "target": "gamma-b",
     "edge_type": "DEPENDS_ON_PRICE_OF", "source_property": "price.package_gbps"},
    {"edge_id": "e-embed-b", "source": "embed-b", "target": "gamma-b",
     "edge_type": "DEPENDS_ON_EMBEDDING_OF", "source_property": "embedding.placement"},
    {"edge_id": "e-cap-b", "source": "cap-b", "target": "gamma-b",
     "edge_type": "DEPENDS_ON_CAPABILITY_OF", "source_property": "capability.primitives"},
    {"edge_id": "e-dec-b", "source": "gamma-b", "target": "decision-b",
     "edge_type": "DERIVES_VALUE_FROM"},
    {"edge_id": "e-cert-b", "source": "decision-b", "target": "cert-b",
     "edge_type": "DERIVES_VALUE_FROM"},
)

_CHANGE_CERTIFICATES = {
    "cert-a": ("price-a", "embed-a", "cap-a", "registry", "gamma-a", "decision-a"),
    "cert-b": ("price-b", "embed-b", "cap-b", "gamma-b", "decision-b"),
}


def _fixture_certificate(certificate_id: str, dependencies: Sequence[str]) -> DecisionCertificate:
    return DecisionCertificate(
        certificate_id=certificate_id,
        outcome=DecisionOutcome.CERTIFIED_WINNER,
        scope=DecisionScope(scope_id=f"scope-{certificate_id}",
                            observation_level=ObservationLevel.ADDITIVE_PRICE,
                            objective_family={"family": "LINEAR_NONNEGATIVE"}),
        derivation=DerivationRecord(
            query_hash=content_hash({"query": certificate_id}),
            mapping_table_version=SPEC_VERSION, decision_class="ADDITIVE_PRICE",
            required_object="K", rule_cited="26.4"),
        claim_scope=ClaimScope.RELATIVE_EXPLICIT_FAMILY,
        completeness=CompletenessBasis(
            basis_type=CompletenessBasisType.EXPLICIT_IMPORTED_FAMILY,
            declared_universe="imported family"),
        complete_registry_hash=content_hash({"registry": certificate_id}),
        retained_registry_hash=content_hash({"retained": certificate_id}),
        semantic_pins=CertificatePins(
            schema_versions={"crg-core": "0.2.0"},
            quantity_registry_version="sha256:810b33ce38f3bf69be66fb153601782a4d73b125db1534ef810f82a088102bb1",
            normative_rule_table_version="sha256:d1b2c0226357d194f7fefbb7f2060ab96d9f7dc9f7cd19e2ac635cef55de81f5",
            crg_vir_version="0.2.0", domain_pack_versions={},
            proof_checker_versions={"crg-verify": "0.2.0", "crg-verify-js": "0.2.0"},
        ),
        selected=(), dependencies=tuple(dependencies))


def op_classify_change(request: Mapping[str, Any]) -> dict:
    """Spec 30.2-30.4: the minimum valid recomputation, and nothing more."""
    objects = {oid: _GraphNode(oid, kind) for oid, kind in _CHANGE_OBJECTS.items()}
    graph = DependencyGraph()
    for spec in _CHANGE_EDGES:
        graph.add_edge(DependencyEdge(
            edge_id=spec["edge_id"], source=spec["source"], target=spec["target"],
            edge_type=getattr(EdgeType, spec["edge_type"]),
            source_property=spec.get("source_property")))
    certificates = {cid: _fixture_certificate(cid, deps)
                    for cid, deps in _CHANGE_CERTIFICATES.items()}

    changed = request["changed_object"]
    event = ChangeEvent(
        event_id=f"evt-{changed}", changed_object=changed,
        previous_version="1", current_version="2",
        declared_reason=request.get("declared_reason", "conformance change"),
        changed_properties=tuple(request.get("changed_properties", ())))

    classification = explain_change(event, object_kinds=_CHANGE_OBJECTS)
    plan = build_impact_plan(event, graph, all_objects=objects, certificates=certificates)
    marked = mark_stale(objects, plan)
    action = minimum_action([plan.classification] + list(plan.affected.values()))
    certificate_ids = set(certificates)
    under_test = request.get("certificate_under_test")
    return {
        "classification": classification.action,
        "action": action,
        "reason": classification.reason,
        "stale": sorted(marked),
        "preserved": sorted(c for c in plan.preserved if c in certificate_ids),
        "invalidated": sorted(plan.invalidated),
        "affected": dict(plan.affected),
        "property_classes": {p: classify_property(p)
                             for p in request.get("changed_properties", ())},
        "certificate_status_before": ObjectStatus.ACTIVE,
        "certificate_status_after": (objects[under_test].envelope.status
                                     if under_test else None),
        "certificate_dependencies": (sorted(certificate_dependencies(
            under_test, certificates[under_test])) if under_test in certificates else []),
    }


def op_migrate(request: Mapping[str, Any]) -> dict:
    """Spec 15.3-15.5: a certificate is inherited only across a proved equivalence."""
    case = {
        "case_id": "case-migrate-1",
        "schema_version": request.get("from_schema_version", "0.1.0"),
        "status": "CERTIFIED",
        "certificates": {"cert-a": {"certificate_id": "cert-a"},
                         "cert-b": {"certificate_id": "cert-b"}},
    }
    payload: Dict[str, Any] = {
        "target_schema_version": request.get("target_schema_version", "0.2.0")}
    if request.get("migration_class") is not None:
        payload["migration_class"] = request["migration_class"]
    if request.get("authority") is not None:
        payload["authority"] = request["authority"]

    context = JobContext(
        job_id="job-migrate", case_id=str(case["case_id"]), store=None,
        inputs={"request": payload, "case": case}, resource_limits={},
        actor="crg-conformance", correlation_id="corr-migrate")
    try:
        result = _server_op_migrate(context)
    except UsageError as error:
        return {"ok": False, "classification": request.get("migration_class"),
                "inherited": False, "revalidation_required": True,
                "reason": f"{type(error).__name__}: {error}",
                "active_certificates": [], "superseded_certificates": [],
                "case_status": None}

    outputs = result.outputs
    migrated = dict(result.case or {})
    inherited = bool(outputs["certificates_carried"])
    return {
        "ok": True,
        "classification": outputs["migration_class"],
        "inherited": inherited,
        "revalidation_required": bool(outputs["revalidation_required"]),
        "active_certificates": sorted(migrated.get("certificates") or {}),
        "superseded_certificates": sorted(migrated.get("superseded_certificates") or {}),
        "case_status": migrated.get("status"),
        "reason": (
            "spec 15.5: only a recorded SEMANTICALLY_EQUIVALENT classification licenses "
            "carrying prior certificates across a schema migration"
            if inherited else
            f"spec 15.5: migration class {outputs['migration_class']} does not certify "
            "semantic equivalence, so no certificate is inherited"),
    }


_MERGE_BASE = {
    "case_id": "case-merge", "title": "north site", "owner": "ops-1",
    "registry": {"members": ["a", "b"]},
}


def op_merge_branches(request: Mapping[str, Any]) -> dict:
    """Spec 16.3-16.4: CRG SHALL NOT automatically merge semantic objects."""
    base = dict(_MERGE_BASE)
    source = dict(base)
    source.update(request.get("source", {}))
    target = dict(base)
    target.update(request.get("target", {}))
    rules = tuple(
        MergeRule(rule_id=r["rule_id"], fields=tuple(r["fields"]),
                  strategy=r.get("strategy", "PREFER_SOURCE"),
                  registered_by=r.get("registered_by", "conformance"))
        for r in request.get("rules", ()))
    decision = merge_policy(source, target, base_case=base, registered_rules=rules)
    return {
        "ok": bool(decision.automatic),
        "decision": decision.decision,
        "auto_merged": bool(decision.automatic
                            and decision.decision == MergeDecisionKind.AUTOMATIC_METADATA),
        "conflicts": (list(decision.semantic_conflicts)
                      + list(decision.overlapping_fields)
                      + list(decision.unregistered_fields)),
        "semantic_conflicts": list(decision.semantic_conflicts),
        "reason": decision.rationale,
        "required_actions": list(decision.required_actions),
    }


# ===========================================================================
# CRG-CONVERT
# ===========================================================================
def _layout(spec: Mapping[str, Any]) -> Layout:
    label = spec.get("label", "")
    if "measures" in spec:
        return Layout(measures=spec["measures"], label=label or "measures")
    if "divisions" in spec:
        return Layout(tuple(spec["divisions"]), label=label or "grid")
    return Layout.aligned(int(spec["K"]), int(spec["C"]),
                          label=label or f"K{spec['K']}-C{spec['C']}")


def op_convert_layout(request: Mapping[str, Any]) -> dict:
    """Spec 31.2: the exact maximum-weight assignment, never the closed form off-hypothesis."""
    source = _layout(request["source"])
    target = _layout(request["target"])
    record = convert(source, target)
    evidence = record.solver_evidence
    c, c_prime = source.partitions, target.partitions
    try:
        closed_form = _frac(nested_closed_form(c, c_prime))
        closed_form_refusal = None
    except ValueError as error:
        closed_form = None
        closed_form_refusal = f"{type(error).__name__}: {error}"
    return {
        "retained": _frac(record.retained_fraction),
        "moved": _frac(record.moved_fraction),
        "nested": bool(evidence.nested),
        "closed_form_applies": bool(evidence.nested
                                    and evidence.closed_form_value is not None),
        "closed_form_value": closed_form,
        "closed_form_refusal": closed_form_refusal,
        "is_nested_pair": is_nested(c, c_prime),
        "identity": bool(record.identity),
        "solver_method": evidence.method,
        "partitions": [c, c_prime],
        "invariants_hold": bool(record.invariants_hold),
        "notes": list(evidence.notes),
    }


def op_secondary_objective(request: Mapping[str, Any]) -> dict:
    """Spec 31.3: a secondary objective is optimized inside the primary optimum."""
    source = _layout(request["source"])
    target = _layout(request["target"])
    weights = cell_overlaps(source, target)
    primary = solve_max_assignment(weights).value
    try:
        objective = SecondaryObjective(
            kind=request["kind"],
            cost=tuple(tuple(Exact(v) for v in row) for row in request["cost"]),
            permit_movement_trade=bool(request.get("permit_movement_trade", False)),
            authorization=request.get("authorization"))
    except ValueError as error:
        return {"ok": False, "primary_retained": _frac(primary),
                "achieved_retention": None, "secondary_value": None,
                "trade_refused": False, "primary_respected": True,
                "reason": f"REFUSED at construction -- {type(error).__name__}: {error}"}
    outcome = optimize_secondary(weights, objective)
    report = outcome.report
    return {
        "ok": bool(report.primary_respected),
        "primary_retained": _frac(primary),
        "achieved_retention": _frac(outcome.retention),
        "retention_equals_optimum": outcome.retention == primary,
        "secondary_value": _frac(outcome.secondary_value),
        "trade_refused": bool(report.trade_refused),
        "trade_permitted": bool(report.trade_permitted),
        "retention_preserved": bool(report.retention_preserved),
        "primary_respected": bool(report.primary_respected),
        "authorization": report.authorization,
        "refused_gain": _frac(report.refused_gain) if report.refused_gain is not None else None,
        "reason": (report.refusal_reason if report.trade_refused else
                   "secondary minimized inside the retention-optimal subgraph"),
    }


# ===========================================================================
# CRG-FEEDBACK
# ===========================================================================
NOW_TICKS = 1_000_000
WALL_CLOCK = "2026-03-01T12:00:00Z"
_FEEDBACK_REALIZATION = "rz-cache-4way"


def _transition_clock(ticks: int = NOW_TICKS, wall: Optional[str] = WALL_CLOCK) -> Any:
    return TransitionClock.declared(
        ticks, "controller-monotonic",
        wall_clock=(VerificationClock.declared(wall, "controller-wall",
                                               ClockTrust.SYNCHRONIZED)
                    if wall is not None else None))


def _telemetry(*, at_ticks: int = NOW_TICKS - 50, dwell_ticks: int = 8_000) -> Any:
    sample = TelemetrySample(
        source_id="sensor-array-1", observed_ticks=at_ticks,
        signals={"thermal_margin_c": Exact("17/2"), "load_factor": Exact("4/5"),
                 "throughput_ops": Exact(1200)},
        phases={"pipeline_phase": "STEADY"},
        dwell_ticks={"load-above-threshold": dwell_ticks})
    return sample.signed_by("sensor-array-1")


def _requirements(**overrides: Any) -> Any:
    fields: Dict[str, Any] = dict(
        phase_guard=PhaseGuard(guard_id="pg-steady", signal="pipeline_phase",
                               permitted_values=("STEADY", "DRAINING")),
        margin=Margin(quantity="thermal_margin_c", required=Exact(5), unit="C"),
        hysteresis=Hysteresis(quantity="load_factor", enter_threshold=Exact("3/4"),
                              exit_threshold=Exact("3/5")),
        dwell=DwellRequirement(condition_id="load-above-threshold", minimum_ticks=5_000),
        expected_benefit=ExpectedBenefit(quantity="throughput_ops", value=Exact(180),
                                         basis="compact queueing model"),
        total_cost=TransitionCost.of({"drain": "40", "convert": "125", "warmup": "35"}),
        quiescence=QuiescencePlan(mode="DRAIN_AND_HOLD", drain_ticks=2_000,
                                  verification_signal="inflight_ops"),
        postconditions=(
            Postcondition(condition_id="pc-throughput", signal="throughput_ops",
                          comparator=">=", threshold=Exact(1300)),
            Postcondition(condition_id="pc-thermal", signal="thermal_margin_c",
                          comparator=">=", threshold=Exact(4)),
        ),
        rollback=RollbackPlan(rollback_id="rb-1", checkpoint_id="unbound",
                              steps=("halt", "restore-checkpoint", "resume"),
                              bounded_ticks=9_000, verification_signal="active_config"),
        audit=AuditSpec(audit_id="audit-1", sink="crg://audit/oid5",
                        retained_fields=("plan_id", "level", "approver", "postconditions")),
        telemetry_freshness=TelemetryFreshness(max_age_ticks=250),
    )
    fields.update(overrides)
    return TransitionRequirements(**fields)


def _source_config() -> Any:
    return Configuration(config_id="cfg-4way", label="four-way partition", phase="STEADY",
                         parameters={"partitions": Exact(4), "voltage_mv": Exact(800)},
                         layout_label="four", partition_count=4)


def _target_config(**overrides: Any) -> Any:
    fields: Dict[str, Any] = dict(
        config_id="cfg-6way", label="six-way partition", phase="STEADY",
        parameters={"partitions": Exact(6), "voltage_mv": Exact(850)},
        layout_label="six", partition_count=6, entry_requirements=_requirements())
    fields.update(overrides)
    return Configuration(**fields)


def _approver() -> Any:
    return Approver(
        identity="a.operator", role="site reliability engineer",
        capability=Capability(
            capability_id="cap-1", holder="a.operator",
            permitted_levels=(MaturityLevel.L1_SUPERVISED,),
            permitted_actions=(AUTHORIZE_TRANSITION,),
            validity=ValidityWindow(issued_at="2026-01-01T00:00:00Z",
                                    expires_at="2027-01-01T00:00:00Z")))


class _FakeExecutor:
    """A domain executor with scriptable postcondition telemetry."""

    def __init__(self, plan: Any, *, throughput: str = "1450",
                 fail_restore: bool = False) -> None:
        self._plan = plan
        self._active = plan.source_config.config_id
        self._throughput = throughput
        self._fail_restore = fail_restore

    def context_fingerprint(self) -> str:
        return self._plan.context_fingerprint

    def quiesce(self, quiescence: Any) -> bool:
        return True

    def capture_checkpoint(self, checkpoint: Any) -> str:
        return f"token::{checkpoint.checkpoint_id}::{self._active}"

    def convert_state(self, conversion: Any) -> bool:
        return True

    def apply_configuration(self, config: Any) -> str:
        self._active = config.config_id
        return self._active

    def observe(self) -> Any:
        return TelemetrySample(
            source_id="sensor-array-1", observed_ticks=NOW_TICKS + 10,
            signals={"throughput_ops": Exact(self._throughput),
                     "thermal_margin_c": Exact("15/2")}).signed_by("sensor-array-1")

    def restore(self, checkpoint: Any, token: str) -> str:
        if self._fail_restore:
            return "cfg-undetermined"
        self._active = checkpoint.configuration_id
        return self._active


def op_runtime_transition(request: Mapping[str, Any]) -> dict:
    """Spec 32.4-32.5: fourteen plan items, valid guards, and a verified rollback."""
    telemetry = _telemetry(
        at_ticks=NOW_TICKS - int(request.get("telemetry_age_ticks", 50)),
        dwell_ticks=int(request.get("dwell_ticks", 8_000)))
    clock = _transition_clock(int(request.get("clock_ticks", NOW_TICKS)))
    drop = tuple(request.get("drop_items", ()))

    try:
        plan = plan_transition(_source_config(), _target_config(), envelope=None,
                               telemetry=telemetry, clock=clock)
    except TransitionRefused as error:
        return {"status": "REFUSED", "refusal_reason": error.reason,
                "rolled_back": False, "guards_valid": False, "rollback_present": True,
                "plan_built": False, "exception": f"{type(error).__name__}: {error}",
                "missing": []}

    if drop:
        kwargs = {name: getattr(plan, name) for name in TRANSITION_PLAN_REQUIRED_ITEMS}
        kwargs.update({"plan_id": "plan-under-test", "source_config": plan.source_config,
                       "target_config": plan.target_config, "clock": plan.clock,
                       "context_fingerprint": plan.context_fingerprint})
        for name in drop:
            kwargs[name] = None
        try:
            TransitionPlan(**kwargs)
        except IncompletePlan as error:
            return {
                "status": "INCOMPLETE_PLAN",
                "refusal_reason": (RefusalReason.MISSING_ROLLBACK if "rollback" in drop
                                   else "MISSING_PLAN_ITEMS"),
                "rolled_back": False, "guards_valid": not plan.gates.refusals,
                "rollback_present": "rollback" not in drop, "plan_built": True,
                "exception": f"{type(error).__name__}: {error}",
                "missing": sorted(error.missing),
            }
        return {"status": "ACCEPTED_INCOMPLETE_PLAN", "refusal_reason": None,
                "rolled_back": False, "guards_valid": not plan.gates.refusals,
                "rollback_present": "rollback" not in drop, "plan_built": True,
                "exception": None, "missing": list(drop)}

    guards_valid = not plan.gates.refusals
    authorization = authorize(plan, level=request.get("level", MaturityLevel.L1_SUPERVISED),
                              approver=_approver() if request.get("approver", True) else None)
    if not authorization.authorized:
        return {"status": "NOT_AUTHORIZED",
                "refusal_reason": list(authorization.reasons)[0],
                "rolled_back": False, "guards_valid": guards_valid,
                "rollback_present": plan.rollback is not None, "plan_built": True,
                "missing": []}

    executor = _FakeExecutor(plan, throughput=request.get("observed_throughput", "1450"),
                             fail_restore=bool(request.get("fail_restore")))
    try:
        record = execute(plan, executor=executor,
                         clock=_transition_clock(int(request.get("execute_clock_ticks",
                                                                 NOW_TICKS))))
    except TransitionRefused as error:
        return {"status": "REFUSED", "refusal_reason": error.reason, "rolled_back": False,
                "guards_valid": guards_valid, "rollback_present": plan.rollback is not None,
                "plan_built": True, "exception": f"{type(error).__name__}: {error}",
                "missing": []}
    return {
        "status": record.status,
        "refusal_reason": list(record.reasons)[0] if record.reasons else None,
        "rolled_back": bool(record.rolled_back),
        "guards_valid": guards_valid,
        "rollback_present": plan.rollback is not None,
        "plan_built": True,
        "returned_to_source": bool(record.returned_to_source),
        "rollback_verified": bool(record.returned_to_source and record.rolled_back),
        "failed_postconditions": [p.condition_id for p in record.failed_postconditions],
        "final_config_id": record.final_config_id,
        "audit_events": [e.event for e in record.audit],
        "missing": [],
    }


_WALL_CLOCK_CALL = re.compile(
    r"datetime\.now|time\.time|time\.monotonic|utcnow|perf_counter|monotonic_ns")


def _wall_clock_offenders() -> Dict[str, List[str]]:
    """Grep the runtime-control sources for a wall-clock or process-clock call."""
    import crg_feedback
    root = os.path.dirname(os.path.abspath(crg_feedback.__file__))
    offenders: Dict[str, List[str]] = {}
    for name in sorted(os.listdir(root)):
        if not name.endswith(".py"):
            continue
        with open(os.path.join(root, name), encoding="utf-8") as handle:
            hits = [line.strip() for line in handle
                    if _WALL_CLOCK_CALL.search(line) and not line.lstrip().startswith("#")]
        if hits:
            offenders[name] = hits
    return offenders


def op_monotonic_dwell(request: Mapping[str, Any]) -> dict:
    """Spec 32.5, 45.6: dwell is counted in monotonic ticks, never wall time."""
    minimum = int(request.get("minimum_ticks", 5_000))
    observed = int(request.get("dwell_ticks", 8_000))
    requirement = DwellRequirement(condition_id="load-above-threshold",
                                   minimum_ticks=minimum)
    clock = _transition_clock(int(request.get("clock_ticks", NOW_TICKS)),
                              wall=request.get("wall_clock", WALL_CLOCK))
    telemetry = _telemetry(dwell_ticks=observed)
    refusal = requirement.evaluate(telemetry)

    gate_reasons: List[str] = []
    try:
        plan = plan_transition(
            _source_config(),
            _target_config(entry_requirements=_requirements(dwell=requirement)),
            envelope=None, telemetry=telemetry, clock=clock)
        gate_reasons = [r.reason for r in plan.gates.refusals]
    except (TransitionRefused, IncompletePlan) as error:
        gate_reasons = [f"{type(error).__name__}: {error}"]

    return {
        "dwell_satisfied": refusal is None,
        "source": "MONOTONIC_TICKS",
        "reason": (refusal.detail if refusal is not None else
                   f"condition held for {observed} ticks; {minimum} are required"),
        "monotonic_ticks": clock.monotonic_ticks,
        "wall_clock_asserted": (clock.wall_clock.evaluation_time
                                if clock.wall_clock is not None else None),
        "observed_dwell_ticks": observed,
        "minimum_ticks": minimum,
        "gate_refusals": gate_reasons,
        "refusal_reason": None if refusal is None else refusal.reason,
        "wall_clock_calls": _wall_clock_offenders(),
    }


def _feedback_bundle() -> RealizationBundle:
    return RealizationBundle(
        bundle_id="bundle-oid5",
        schema=_DECISION_SCHEMA,
        realizations=[
            RealizationRecord(realization_id=_FEEDBACK_REALIZATION,
                              signature=Signature((Exact(11), Exact("7/2"))),
                              legality="UNEVALUATED", evidence_class=EvidenceClass.IMPORTED),
            RealizationRecord(realization_id="rz-cache-8way",
                              signature=Signature((Exact(9), Exact("9/2"))),
                              legality="UNEVALUATED", evidence_class=EvidenceClass.IMPORTED)],
        completeness=CompletenessBasis(
            basis_type=CompletenessBasisType.EXPLICIT_IMPORTED_FAMILY,
            declared_universe="imported cache micro-architectures"))


def _evaluator_request() -> Any:
    return EvaluatorRequest(
        realization_id=_FEEDBACK_REALIZATION, embedding_candidate="embed-a",
        technology_contract="tc-node7", requested_evidence_level=EvidenceClass.MEASURED,
        tool_config={"solver": "thermal-fd", "grid": "128"},
        objective="minimize latency",
        constraints=("peak_temperature<=95C", "area<=4mm2"),
        requested_outputs=("latency", "energy"), timeout_ticks=30_000,
        resource_policy={"cores": 8, "memory_gb": 32},
        confidentiality_policy="no-raw-geometry-export", request_id="req-1")


def _evaluator_response(kind: str, **overrides: Any) -> Any:
    fields: Dict[str, Any] = dict(kind=kind, request_id="req-1",
                                  realization_id=_FEEDBACK_REALIZATION,
                                  evaluator_identity="lab-evaluator")
    if kind == ResponseKind.PHYSICAL_INFEASIBILITY:
        fields["violated_constraints"] = ("peak_temperature<=95C",)
        fields.setdefault("evidence_class", EvidenceClass.MEASURED)
    if kind in (ResponseKind.TOOL_FAILURE, ResponseKind.CONVERGENCE_FAILURE):
        fields["detail"] = "solver aborted at iteration 4100"
    if kind in (ResponseKind.MODELED_RESULT, ResponseKind.MEASURED_RESULT):
        fields.setdefault("values", {"latency": Exact("21/2")})
    fields.update(overrides)
    return EvaluatorResponse(**fields)


def op_evaluator_result(request: Mapping[str, Any]) -> dict:
    """Spec 32.1: a tool failure is not infeasibility; a model is not signoff."""
    if request.get("crashing_evaluator"):
        def crashing(_request: Any) -> Any:
            raise RuntimeError(request.get("fault", "segmentation fault in mesh generator"))
        response = submit(_evaluator_request(), crashing)
    else:
        response = _evaluator_response(request.get("kind", ResponseKind.MEASURED_RESULT))

    registry = _feedback_bundle()
    update = apply_feasibility(response, registry)
    signoff = signoff_status(response)

    promotion: Optional[dict] = None
    target = request.get("promote_to")
    if target:
        try:
            promoted = promote_evidence_class(response, target)
            promotion = {"promoted": True, "evidence_class": promoted.evidence_class,
                         "signoff": signoff_status(promoted)}
        except EvaluatorRefusal as error:
            promotion = {"promoted": False,
                         "exception": f"{type(error).__name__}: {error}"}

    constructor_refusal = None
    if request.get("declare_measured_on_modeled"):
        try:
            _evaluator_response(ResponseKind.MODELED_RESULT,
                                evidence_class=EvidenceClass.MEASURED)
        except ProtocolError as error:
            constructor_refusal = f"{type(error).__name__}: {error}"

    return {
        "kind": response.kind,
        "feasibility": update.effect,
        "evidence_class": response.evidence_class,
        "signoff": signoff,
        "marks_infeasible": bool(update.marks_infeasible),
        "leaves_unevaluated": bool(update.leaves_unevaluated),
        "recorded_legality": update.recorded_legality,
        "legality_after": registry.realizations[0].legality,
        "establishes_infeasibility": bool(response.establishes_infeasibility),
        "is_physical_signoff": bool(response.is_physical_signoff),
        "promotion": promotion,
        "constructor_refusal": constructor_refusal,
        "reason": update.basis,
    }


# ===========================================================================
# ETQ-EVIDENCE
# ===========================================================================
_ETQ_QUANTITY = "etq.tool_throughput"
_ETQ_UNIT = "wafer/h"
_ETQ_COORDINATE = "throughput"

_STEWARD = Requester(subject_id="alice", roles=("Evidence Steward",), authority="fab-a")
_OUTSIDER = Requester(subject_id="mallory", roles=("Viewer",))
_SIGNER = Requester(subject_id="bob", roles=("Certificate Signer",))


def _evidence_clock(iso: Optional[str]) -> Any:
    if iso is None:
        return VerificationClock.absent()
    return VerificationClock.declared(iso, "conformance-fixed-clock",
                                      ClockTrust.LOCAL_DECLARED)


def _chain(*labels: str) -> tuple:
    return tuple(content_hash({"link": label}) for label in labels)


def _context(cid: str, line: str, tool: str = "T1") -> Any:
    return ContextDescriptor(cid, "process_cell",
                             {"process_node": "n5", "tool": tool, "line": line})


def _evidence(evidence_id: str = "ev-1", lo: Any = 100, hi: Any = 100,
              expires_at: str = "2026-12-31T00:00:00Z", access: Any = None,
              line: str = "A", uncertainty: Any = None,
              object_status: str = ObjectStatus.ACTIVE) -> EvidenceRecord:
    return EvidenceRecord(
        evidence_id=evidence_id, quantity=_ETQ_QUANTITY, unit=_ETQ_UNIT,
        value=Interval(lo, hi),
        uncertainty=uncertainty if uncertainty is not None else UncertaintyBudget(
            measurement=Interval(-1, 1), sampling=Interval(-2, 2),
            calibration=Interval(0, 1), model=Interval(-3, 0),
            basis="conformance fixture budget"),
        source_context=_context(f"ctx-source-{line}", line),
        method=MethodDescriptor(method_id="M-metrology-1",
                                method_class="PHYSICAL_MEASUREMENT",
                                evidence_class=EvidenceClass.MEASURED,
                                instrument="metrology-bench-3", version="2.1"),
        provenance=Provenance.verified(source_id="fab-a/lot-run-2026-01", issuer="fab-a",
                                       chain=_chain("lot", evidence_id),
                                       issued_at="2026-01-01T00:00:00Z"),
        validity=ValidityWindow(issued_at="2026-01-01T00:00:00Z", expires_at=expires_at,
                                revalidation_triggers=("tool_recalibration",)),
        access=access if access is not None else AccessPolicy.public(),
        evidence_status=EvidenceStatus.QUALIFIED, status=object_status)


def _applicability_rule(rule_id: str = "R-line-transfer",
                        expiration: str = "2026-12-31T00:00:00Z") -> ApplicabilityRule:
    return ApplicabilityRule(
        rule_id=rule_id,
        input_quantity=QuantityType(_ETQ_QUANTITY, _ETQ_UNIT, dimension="count/time"),
        output_quantity=QuantityType(_ETQ_QUANTITY, _ETQ_UNIT, dimension="count/time"),
        source_context_pattern=ContextPattern("process_cell",
                                              {"process_node": "*", "tool": "*"},
                                              "qualified process cells"),
        target_context_pattern=ContextPattern("process_cell",
                                              {"process_node": "*", "tool": "*"},
                                              "qualified process cells"),
        exact_match_fields=("process_node",),
        permitted_differences=(PermittedDifference(
            field="line", kind=DifferenceKind.ANY_VALUE,
            added_transfer_uncertainty=Interval(-2, 2),
            basis="QS-2025-11 measured line-to-line spread"),),
        hard_exclusions=(HardExclusion(
            exclusion_id="X-unqualified-tool", field="tool",
            kind=ExclusionKind.TARGET_FIELD_IN, values=("T9",),
            reason="tool T9 has no qualification basis"),),
        transformation=Transformation(kind=TransformationKind.AFFINE_DERATE,
                                      scale=Exact("9/10"), offset=Exact(0),
                                      basis="10% derating for line-side handling loss"),
        transfer_uncertainty_model=TransferUncertaintyModel(
            model_id="TU-line-transfer", kind=TransferModelKind.PER_DIFFERENCE_SUM,
            correlation_assumption=CorrelationAssumption.UNKNOWN,
            basis="qualification study QS-2025-11"),
        minimum_evidence_status=EvidenceStatus.QUALIFIED,
        correlation_assumption=CorrelationAssumption.UNKNOWN,
        validation_basis="qualification study QS-2025-11, approved 2026-01-15",
        authority="fab-a/qualification-board", expiration=expiration,
        revalidation_triggers=("tool_recalibration",), unit_conversions=(),
        coordinate_id=_ETQ_COORDINATE)


def op_evidence_applicability(request: Mapping[str, Any]) -> dict:
    """Spec 33.3, 45.3: an absent rule is UNSUPPORTED, never an assumed default."""
    clock = _evidence_clock(request.get("clock_at", "2026-06-01T00:00:00Z"))
    record = _evidence(expires_at=request.get("evidence_expires_at",
                                              "2026-12-31T00:00:00Z"),
                       line=request.get("source_line", "A"))
    rules = () if request.get("no_rules") else (
        _applicability_rule(expiration=request.get("rule_expiration",
                                                   "2026-12-31T00:00:00Z")),)
    target = _context("ctx-target-B", request.get("target_line", "B"),
                      tool=request.get("target_tool", "T1"))
    applied, results = select_rule(record, rules, target, clock=clock,
                                   requester=_STEWARD)
    chosen = applied if applied is not None else results[0]
    if chosen.rule_time_judgment is not None and chosen.rule_time_judgment.blocks:
        time_status = chosen.rule_time_judgment.time_status
    elif chosen.time_judgment is not None:
        time_status = chosen.time_judgment.time_status
    else:
        time_status = evaluate_time(record.validity, clock).time_status
    return {
        "status": chosen.status,
        "reason_code": (chosen.reason_code
                        if chosen.reason_code != ReasonCode.APPLICABLE else None),
        "value": _iv_string(chosen.transformed_value),
        "affirmative": chosen.transformed_value is not None and bool(chosen.applicable),
        "time_status": time_status,
        "detail": chosen.detail,
    }


def op_evidence_conflict(request: Mapping[str, Any]) -> dict:
    """Spec 33.5: conflict is surfaced, never silently averaged away."""
    clock = _evidence_clock(request.get("clock_at", "2026-06-01T00:00:00Z"))
    records = [
        _evidence(evidence_id=member["id"], lo=member["lo"], hi=member["hi"],
                  uncertainty=UncertaintyBudget(
                      measurement=Interval(*member.get("measurement", (0, 0)))))
        for member in request["members"]
    ]
    relation = classify_evidence_set(records, clock=clock, requester=_STEWARD)
    result = {"relation": relation.relation, "fused": None, "refusal": None}
    try:
        result["fused"] = _iv_string(fuse(relation))
    except ConflictRefusal as error:
        result["refusal"] = f"{type(error).__name__}: {error}"
    return result


def op_redacted_evidence(request: Mapping[str, Any]) -> dict:
    """Spec 33.2, 44.2, 6.6: withheld required content yields no valid status."""
    clock = _evidence_clock(request.get("clock_at", "2026-06-01T00:00:00Z"))
    policy = AccessPolicy(
        classification=request.get("classification", "restricted"),
        permitted_roles=tuple(request.get("permitted_roles", ("Certificate Signer",))),
        redaction_required=bool(request.get("redaction_required", True)),
        export_permitted=bool(request.get("export_permitted", False)))
    record = _evidence(access=policy,
                       object_status=request.get("object_status", ObjectStatus.ACTIVE))
    who = request.get("requester")
    requester = (None if who is None
                 else _OUTSIDER if who == "outsider" else _SIGNER)
    target = _context("ctx-target-B", "B")
    result = apply_rule(record, _applicability_rule(), target, clock=clock,
                        requester=requester)
    contract, report = assemble_technology_contract(
        [record], [_applicability_rule()], target, clock=clock, requester=requester,
        coordinates=(CoordinateRequest(coordinate_id=_ETQ_COORDINATE,
                                       quantity=_ETQ_QUANTITY, unit=_ETQ_UNIT,
                                       required=True),),
        contract_id="tc-redaction")
    return {
        "status": result.status,
        "reason": result.reason_code,
        "affirmative": bool(result.applicable and result.transformed_value is not None
                            and contract.has(_ETQ_COORDINATE)),
        "rejection_reasons": list(report.reasons()),
        "verification_status": contract.verification_status,
        "detail": result.detail,
    }


# ===========================================================================
# ETQ-QUALIFY
# ===========================================================================
_QUALIFY_CLOCK = VerificationClock.declared("2026-06-01T00:00:00Z",
                                            "conformance-fixed-clock",
                                            ClockTrust.LOCAL_DECLARED)
_YIELD_QUANTITY, _YIELD_UNIT = "etq.yield_loss", "percent"
_AMBIGUITY_METRIC = AmbiguityMetric.GUARANTEED_VERSUS_POSSIBLE_GAP
_BURDEN_WEIGHTS = BurdenWeights({"time": Exact(1), "cost": Exact("1/100")},
                                basis="1 per tool-hour, 1 per 100 currency units")


def _qualify_pattern() -> ContextPattern:
    return ContextPattern("process_cell", {"process_node": "*", "tool": "*"},
                          "qualified process cells")


def _throughput_rule() -> ApplicabilityRule:
    return _applicability_rule(rule_id="R-throughput")


def _yield_rule() -> ApplicabilityRule:
    return ApplicabilityRule(
        rule_id="R-yield",
        input_quantity=QuantityType(_YIELD_QUANTITY, _YIELD_UNIT,
                                    dimension="dimensionless"),
        output_quantity=QuantityType(_YIELD_QUANTITY, _YIELD_UNIT,
                                     dimension="dimensionless"),
        source_context_pattern=_qualify_pattern(),
        target_context_pattern=_qualify_pattern(),
        exact_match_fields=("process_node",), permitted_differences=(),
        hard_exclusions=(),
        transformation=Transformation.identity(basis="same tooling, no derating"),
        transfer_uncertainty_model=TransferUncertaintyModel(
            model_id="TU-none", kind=TransferModelKind.NONE_DECLARED,
            correlation_assumption=CorrelationAssumption.INDEPENDENT,
            basis="identity map, no transfer term"),
        minimum_evidence_status=EvidenceStatus.QUALIFIED,
        correlation_assumption=CorrelationAssumption.INDEPENDENT,
        validation_basis="QS-2025-12", authority="fab-a/qualification-board",
        expiration="2026-12-31T00:00:00Z",
        revalidation_triggers=("process_node_change",), coordinate_id="yield_loss")


def _predicate(threshold: str = "100") -> DecisionPredicate:
    return DecisionPredicate("P1", {"throughput": Exact(1), "yield_loss": Exact(-2)},
                             threshold=Exact(threshold),
                             basis="line B must clear the declared net wafer/h")


def _information(before: str = "26", expected: str = "4",
                 worst: str = "10") -> InformationEffect:
    return InformationEffect(_AMBIGUITY_METRIC, before, expected, worst,
                             basis="pre-registered from QS-2025-11 replicates")


def _experiment(identifier: str, *, measurand: str = _ETQ_QUANTITY,
                unit: str = _ETQ_UNIT, time: str = "2", cost: str = "100",
                information: Any = None,
                targets: Sequence[str] = ("throughput",)) -> ExperimentDefinition:
    return ExperimentDefinition(
        experiment_id=identifier, measurand=measurand, unit=unit,
        method=MethodDescriptor(method_id=f"M-{identifier}",
                                method_class="PHYSICAL_MEASUREMENT",
                                evidence_class=EvidenceClass.MEASURED,
                                instrument="metrology-bench-3", version="2.1"),
        result_model=ResultModel(kind=ResultModelKind.INTERVAL, expected_width=Exact(2),
                                 basis="interval enclosure over replicates"),
        burden=BurdenVector.of(time=time, cost=cost, basis=f"quoted for {identifier}"),
        context=_context("ctx-source-A", "A"),
        expected_information_effect=information or _information(),
        targets=tuple(targets), authority="fab-a/qualification-board")


def _experiment_catalogue() -> Dict[str, ExperimentDefinition]:
    fast = _experiment("E-throughput-fast", time="2", cost="100",
                       information=_information("26", "4", "10"))
    slow = _experiment("E-throughput-slow", time="20", cost="1000",
                       information=_information("26", "2", "6"))
    yielded = _experiment("E-yield", measurand=_YIELD_QUANTITY, unit=_YIELD_UNIT,
                          time="5", cost="200",
                          information=_information("26", "12", "18"),
                          targets=("yield_loss",))
    null = _experiment("E-null", time="0", cost="0",
                       information=InformationEffect.none(
                           _AMBIGUITY_METRIC, "26",
                           basis="a screen that cannot move the bound"))
    free = _dc_replace(fast, experiment_id="E-free",
                       burden=BurdenVector.of(time="0", cost="0",
                                              basis="reanalysis of existing data"))
    return {e.experiment_id: e for e in (fast, slow, yielded, null, free)}


def _qualification_objective(*, stops: Any = None, prior_bounds: Any = None,
                             threshold: str = "100",
                             acceptable: str = "0") -> QualificationObjective:
    return QualificationObjective(
        objective_id="OBJ-line-B",
        desired_state="line B qualified for the 100 wafer/h architecture state",
        region=PhaseRegion("REG-line-B", (_predicate(threshold),),
                           basis="single-predicate phase region"),
        acceptable_ambiguity=AcceptableAmbiguity(_AMBIGUITY_METRIC, acceptable,
                                                 basis="board tolerance"),
        stopping_rules=stops or (
            StoppingRule(StoppingCondition.UNIQUE_GUARANTEED_WINNER, basis="board rule"),
            StoppingRule(StoppingCondition.CAPABILITY_ESTABLISHED, basis="board rule"),
        ),
        authority="fab-a/qualification-board", burden_limits=BurdenLimits.none(),
        burden_weights=_BURDEN_WEIGHTS,
        prior_bounds=prior_bounds or (("throughput", Interval(110, 130)),
                                      ("yield_loss", Interval(3, 6))),
        prior_bounds_basis="incumbent line A contract carried across as a declared prior")


def _winner_sets(candidates: Mapping[str, Sequence[str]]) -> tuple:
    """Exact interval-order winner analysis (spec 22.5): never a midpoint winner."""
    intervals = {k: Interval(Exact(str(v[0])), Exact(str(v[1])))
                 for k, v in candidates.items()}
    if not intervals:
        return (), None
    best_lo = max(iv.lo for iv in intervals.values())
    possible = tuple(sorted(k for k, iv in intervals.items() if iv.hi >= best_lo))
    guaranteed = None
    for key, enclosure in intervals.items():
        if all(enclosure.lo >= other.hi
               for other_key, other in intervals.items() if other_key != key):
            guaranteed = key
    return possible, guaranteed


def op_qualify(request: Mapping[str, Any]) -> dict:
    """Spec 34.4-34.5: an unresolved set stays a set until a declared rule stops it."""
    stops = tuple(
        StoppingRule(s["condition"], threshold=s.get("threshold"),
                     metric=s.get("metric"), basis=s.get("basis", "conformance request"))
        for s in request.get("stopping_rules", ())) or None
    objective = _qualification_objective(stops=stops,
                                         threshold=request.get("threshold", "100"))
    plan = invert(objective, None, (_throughput_rule(), _yield_rule()),
                  candidate_experiments=tuple(_experiment_catalogue().values())[:4],
                  burden_weights=_BURDEN_WEIGHTS, clock=_QUALIFY_CLOCK)
    possible, guaranteed = _winner_sets(request.get("candidates", {}))
    state = _dc_replace(plan.initial_state, possible_winners=possible,
                        guaranteed_winner=guaranteed,
                        **dict(request.get("state_overrides", {})))
    stopped, reason = stopping_reached(plan, state)
    return {
        "ambiguity": str(state.ambiguity),
        "possible_winners": list(state.possible_winners),
        "possible_winner_count": len(state.possible_winners),
        "guaranteed_winners": ([state.guaranteed_winner]
                               if state.unique_guaranteed_winner else []),
        "stopped": bool(stopped),
        "stop_reason": None if reason == NOT_STOPPED else reason,
        "predicate_state": state.predicate_state,
        "ambiguity_metric": state.ambiguity_metric,
    }


def op_phase_boundary(request: Mapping[str, Any]) -> dict:
    """Spec 34.2, 34.5: an enclosure straddling a boundary is not pushed to a side."""
    bounds = {c: Interval(Exact(str(lo)), Exact(str(hi)))
              for c, (lo, hi) in request["bounds"].items()}
    region = PhaseRegion(
        request.get("region_id", "REG-line-B"),
        tuple(_predicate(str(t)) for t in request.get("thresholds", ["100"])),
        basis="declared phase region")
    regions = []
    crosses = False
    for predicate in region.predicates:
        enclosure = predicate.evaluate(bounds)
        straddles = enclosure is not None and enclosure.lo < Exact(0) <= enclosure.hi
        crosses = crosses or straddles
        regions.append({
            "predicate_id": predicate.predicate_id,
            "g_enclosure": _iv_string(enclosure),
            "state": predicate.state(bounds),
            "crosses_boundary": bool(straddles),
        })
    uncertainty = region_ambiguity(region, bounds,
                                   AmbiguityMetric.PHASE_BOUNDARY_UNCERTAINTY)
    region_state = region.state(bounds)
    return {
        "crosses": bool(crosses),
        "regions": regions,
        "resolved": region_state in PredicateState.RESOLVED,
        "region_state": region_state,
        "phase_boundary_uncertainty": None if uncertainty is None else str(uncertainty),
        "reason": (
            f"region {region.region_id} is {region_state}; the enclosure of g straddles "
            "g = 0, so no side is chosen (spec 49.2: no conversion of ambiguity into a "
            "midpoint winner)"
            if crosses else
            f"region {region.region_id} is {region_state}; the enclosure lies wholly on "
            "one side of g = 0"),
    }


def op_rank_experiments(request: Mapping[str, Any]) -> dict:
    """Spec 34.4: cheapness never buys rank that information did not earn."""
    catalogue = _experiment_catalogue()
    chosen = tuple(catalogue[i] for i in request.get(
        "experiments", ["E-throughput-fast", "E-throughput-slow", "E-yield", "E-null"]))
    ranked = rank_experiments(chosen, None, burden_weights=_BURDEN_WEIGHTS,
                              basis=request.get("basis", RankingBasis.EXPECTED))
    names = dict(RankingTier.NAME)
    return {
        "ranking": [{
            "id": r.experiment_id,
            "tier": names.get(r.tier, str(r.tier)),
            "tier_value": r.tier,
            "score": None if r.score is None else _frac(r.score),
            "reduction": _frac(r.ambiguity_reduction),
            "burden": None if r.burden_scalar is None else _frac(r.burden_scalar),
            "informative": bool(r.informative),
            "excluded_reason": r.excluded_reason,
        } for r in ranked],
        "order": [r.experiment_id for r in ranked],
        "reason": ("spec 34.4 tiers before it scores: an experiment whose declared "
                   "reduction is not strictly positive sits below every informative one "
                   "whatever its burden"),
    }


# ===========================================================================
# ETQ-FEDERATE
# ===========================================================================
_FED_KEY = SigningKey.from_secret("key-fab-a-2026",
                                  b"0123456789abcdef0123456789abcdef", "fab-a")
_FED_OTHER_KEY = SigningKey.from_secret("key-fab-z-2026",
                                        b"fedcba9876543210fedcba9876543210", "fab-z")
_FED_RING = KeyRing((_FED_KEY,))
_FED_PARTNER = Requester(subject_id="partner-bob", roles=("Federation Partner",),
                         authority="fab-b")
_FED_EVIDENCE = (content_hash({"evidence": "ev-1"}), content_hash({"evidence": "ev-2"}))

#: Ledgers and revocation registries are keyed by a caller-supplied name so a
#: golden vector can present the *same* nonce to the *same* verifier twice.
_LEDGERS: Dict[str, NonceLedger] = {}
_REGISTRIES: Dict[str, RevocationRegistry] = {}


def reset_federation_state() -> None:
    """Clear the nonce ledgers and revocation registries between suite runs."""
    _LEDGERS.clear()
    _REGISTRIES.clear()


def _federation_rule(version: str = "1") -> ApplicabilityRule:
    pattern = ContextPattern("process_cell", {"process_node": "*"},
                             "qualified process cells")
    return ApplicabilityRule(
        rule_id="R-line-transfer",
        input_quantity=QuantityType(_ETQ_QUANTITY, _ETQ_UNIT, dimension="count/time"),
        output_quantity=QuantityType(_ETQ_QUANTITY, _ETQ_UNIT, dimension="count/time"),
        source_context_pattern=pattern, target_context_pattern=pattern,
        exact_match_fields=("process_node",), permitted_differences=(),
        hard_exclusions=(),
        transformation=Transformation.identity(basis="identical tooling"),
        transfer_uncertainty_model=TransferUncertaintyModel(
            model_id="TU-none", kind=TransferModelKind.NONE_DECLARED,
            correlation_assumption=CorrelationAssumption.INDEPENDENT,
            basis="no transfer term declared"),
        minimum_evidence_status=EvidenceStatus.QUALIFIED,
        correlation_assumption=CorrelationAssumption.INDEPENDENT,
        validation_basis="qualification study QS-2025-11",
        authority="fab-a/qualification-board", expiration="2026-12-31T00:00:00Z",
        revalidation_triggers=("tool_recalibration",), coordinate_id=_ETQ_COORDINATE,
        rule_version=version)


def _capability_envelope(nonce: str, expires_at: str) -> Any:
    return issue_envelope(
        BoundedResult(coordinate_id=_ETQ_COORDINATE, quantity=_ETQ_QUANTITY,
                      unit=_ETQ_UNIT, bound=Interval(120, 130), direction="MAXIMIZE",
                      uncertainty=UncertaintyBudget(measurement=Interval(-1, 1),
                                                    basis="bench repeatability"),
                      correlation_assumption=CorrelationAssumption.INDEPENDENT,
                      uncertainty_statement="five components carried separately (33.4)",
                      bound_derivation="intersection of two supporting evidence records"),
        _context("ctx-target-B", "B"), _federation_rule(), _FED_EVIDENCE,
        issuer="fab-a", key=_FED_KEY,
        validity=ValidityWindow(issued_at="2026-01-01T00:00:00Z", expires_at=expires_at,
                                revalidation_triggers=("tool_recalibration",)),
        nonce=nonce,
        authorization=Authorization(authority="fab-a/federation-board",
                                    access=AccessPolicy.public(),
                                    permitted_roles=("Federation Partner",),
                                    basis="federation agreement FA-2026-03"),
        release_policy=ReleasePolicy(
            policy_id="release-fab-a",
            authorized_kinds=(ReleaseKind.BOOLEAN, ReleaseKind.QUANTIZED_MARGIN,
                              ReleaseKind.BOUNDED_INTERVAL),
            quantization_step=Exact(5), basis="FA-2026-03 annex B"),
        clock_assertion=ClockAssertion(asserted_at="2026-01-01T00:00:00Z",
                                       clock_source="fab-a-ntp",
                                       trust_level=ClockTrust.SYNCHRONIZED),
        envelope_id=f"env-{nonce}")


def op_verify_envelope(request: Mapping[str, Any]) -> dict:
    """Spec 35.2-35.4: fail closed, release the minimum, and never return False."""
    nonce = request.get("nonce", "nonce-0001")
    envelope = _capability_envelope(nonce, request.get("expires_at",
                                                       "2026-12-31T00:00:00Z"))
    clock = (_evidence_clock(request["clock_at"]) if request.get("clock_at")
             else _evidence_clock("2026-06-01T00:00:00Z"))
    keys = KeyRing((_FED_OTHER_KEY,)) if request.get("wrong_key") else _FED_RING

    seen = None
    if request.get("ledger") is not None:
        # A replay case must present one nonce to one verifier twice, so the
        # ledger is named and outlives the call.  ``reset_ledger`` lets the
        # first step of such a vector start from a clean ledger, which keeps
        # the vector idempotent across repeated suite runs.
        if request.get("reset_ledger"):
            _LEDGERS.pop(request["ledger"], None)
        seen = _LEDGERS.setdefault(request["ledger"], NonceLedger())

    registry = None
    if request.get("registry") is not None:
        if request.get("reset_registry"):
            _REGISTRIES.pop(request["registry"], None)
        registry = _REGISTRIES.setdefault(
            request["registry"], RevocationRegistry(registry_id="fab-a-crl",
                                                    authority="fab-a"))
        if request.get("revoke_this"):
            revoke(envelope.envelope_id, registry)

    # One pass only: evaluate_private runs verify_envelope internally and
    # exposes it, so verifying separately would consume the nonce twice.
    result = evaluate_private(
        envelope,
        CapabilityQuery("q-1", _ETQ_COORDINATE, ">=", request.get("threshold", "100"),
                        basis="can line B clear the threshold"),
        clock=clock, seen_nonces=seen, keys=keys, revocations=registry,
        expectations=VerifierExpectations(
            target_context_fingerprint=_context("ctx-target-B", "B").fingerprint(),
            authorized_rules=(("R-line-transfer", "1"),),
            trusted_issuers=("fab-a",), requester=_FED_PARTNER))
    outcome = result.verification
    reasons = list(outcome.reasons())
    return {
        "outcome": "ACCEPTED" if outcome.accepted else "DENIED",
        "reason_code": outcome.primary_reason if reasons else None,
        "all_reasons": reasons,
        "replay_checked": bool(outcome.replay_checked),
        "release_kind": result.release_kind,
        "released": bool(result.released),
        "affirmative": bool(result.affirmative),
        # A denied evaluation must return no Boolean at all: False would be
        # indistinguishable from a refutation (spec 35.4).
        "boolean_is_none": result.boolean is None,
        "boolean_is_false": result.boolean is False,
        "release_basis": result.release_basis,
    }


# ===========================================================================
# the implementation object
# ===========================================================================
class ReferenceImplementation(BaseImplementation):
    """The bundled reference adapter over the CRG Systems modules.

    It declares every profile of specification 48.1 and asserts the open-commons
    governance policy of specification 52.1.  Whether it *is* conformant is not
    a property of this class; it is whatever :func:`crg_conformance.run_all`
    reports after running the suite against it.
    """

    name = REFERENCE_NAME
    version = REFERENCE_VERSION
    spec_version = SPEC_VERSION
    supported_profiles = frozenset(Profile.MANDATORY)
    governance_policy = "crg-open-commons-governance (spec 52.1)"
    conformance_report_published = False
    governance_policy_met = False

    op_canonical_hash = staticmethod(op_canonical_hash)
    op_quantity_add = staticmethod(op_quantity_add)
    op_dependency_graph = staticmethod(op_dependency_graph)
    op_bundle_verify = staticmethod(op_bundle_verify)
    op_build_geometry = staticmethod(op_build_geometry)
    op_support_claim = staticmethod(op_support_claim)
    op_compile_query = staticmethod(op_compile_query)
    op_generate_family = staticmethod(op_generate_family)
    op_certify_decision = staticmethod(op_certify_decision)
    op_prune = staticmethod(op_prune)
    op_retention = staticmethod(op_retention)
    op_regret_witness = staticmethod(op_regret_witness)
    op_verify_certificate = staticmethod(op_verify_certificate)
    op_classify_change = staticmethod(op_classify_change)
    op_migrate = staticmethod(op_migrate)
    op_merge_branches = staticmethod(op_merge_branches)
    op_convert_layout = staticmethod(op_convert_layout)
    op_secondary_objective = staticmethod(op_secondary_objective)
    op_evaluator_result = staticmethod(op_evaluator_result)
    op_runtime_transition = staticmethod(op_runtime_transition)
    op_monotonic_dwell = staticmethod(op_monotonic_dwell)
    op_evidence_applicability = staticmethod(op_evidence_applicability)
    op_evidence_conflict = staticmethod(op_evidence_conflict)
    op_redacted_evidence = staticmethod(op_redacted_evidence)
    op_qualify = staticmethod(op_qualify)
    op_phase_boundary = staticmethod(op_phase_boundary)
    op_rank_experiments = staticmethod(op_rank_experiments)
    op_verify_envelope = staticmethod(op_verify_envelope)


def reference_implementation() -> ReferenceImplementation:
    """A fresh reference adapter with clean federation replay state."""
    reset_federation_state()
    return ReferenceImplementation()
