"""crg-io: registry import, portable ``.crg`` bundles, canonical reports.

Reference implementation of sections 37 (Registry Import Profile), 39
(portable ``.crg`` interchange artifact), and 50 (canonical human-readable
certificate report) of the CRG Operational Systems Master Specification
v0.2.0.

These three surfaces are the boundary of the system: what comes in, what
goes out, and what a human reads.  Each therefore carries one non-negotiable
property.

* **In** -- every imported numeric becomes an exact rational or the row is
  refused with a reason; an imported family is ``EXPLICIT_IMPORTED_FAMILY``
  and nothing stronger (spec 21.2, 37).
* **Out** -- a bundle is content addressed and independently checkable with
  ``sha256`` alone, and it may not depend on an unversioned URL (spec 39).
* **Read** -- the claim scope and completeness basis precede any winner, in a
  fixed order that every conforming renderer preserves (spec 50).

The exact import kernel is standard-library-only; the distribution pins
PyArrow solely as the Apache Parquet format provider. ``crg_model`` is the
sole internal dependency.
"""
from .import_profile import (
    IMPORTER_ID,
    IMPORTER_VERSION,
    JSON_IMPORTER_ID,
    MAPPING_FORMATS,
    MAPPING_IMPORTER_ID,
    ExactParseError,
    ImportProfileError,
    ImportReport,
    RejectedRow,
    default_completeness,
    file_fingerprint,
    import_json,
    import_mapping_export,
    import_tabular,
    infer_schema,
    parse_exact,
    parse_exact_value,
)
from .formats import (
    COMPILER_GRAPH_FORMATS,
    COMPILER_GRAPH_IMPORTER_ID,
    PARQUET_IMPORTER_ID,
    SPREADSHEET_IMPORTER_ID,
    available_importers,
    import_compiler_graph,
    import_parquet,
    import_registered,
    import_registry,
    import_spreadsheet,
    register_domain_importer,
)
from .bundle import (
    BUNDLE_FORMAT_VERSION,
    CREATION_TOOL,
    CREATION_TOOL_VERSION,
    BundleError,
    BundleIntegrityError,
    FileArtifact,
    manifest_hash_of,
    read_bundle,
    verify_bundle_integrity,
    write_bundle,
)
from .report import (
    OUTCOME_PHRASE,
    RENDERER_ID,
    RENDERER_VERSION,
    SCOPE_PHRASE,
    claim_sentence,
    render_certificate,
    render_delta,
)

__all__ = [
    # spec 37
    "IMPORTER_ID",
    "IMPORTER_VERSION",
    "JSON_IMPORTER_ID",
    "MAPPING_IMPORTER_ID",
    "MAPPING_FORMATS",
    "ExactParseError",
    "ImportProfileError",
    "ImportReport",
    "RejectedRow",
    "default_completeness",
    "file_fingerprint",
    "import_json",
    "import_mapping_export",
    "import_tabular",
    "infer_schema",
    "parse_exact",
    "parse_exact_value",
    "SPREADSHEET_IMPORTER_ID",
    "PARQUET_IMPORTER_ID",
    "COMPILER_GRAPH_IMPORTER_ID",
    "COMPILER_GRAPH_FORMATS",
    "import_spreadsheet",
    "import_parquet",
    "import_compiler_graph",
    "register_domain_importer",
    "available_importers",
    "import_registered",
    "import_registry",
    # spec 39
    "BUNDLE_FORMAT_VERSION",
    "CREATION_TOOL",
    "CREATION_TOOL_VERSION",
    "BundleError",
    "BundleIntegrityError",
    "FileArtifact",
    "manifest_hash_of",
    "read_bundle",
    "verify_bundle_integrity",
    "write_bundle",
    # spec 50
    "OUTCOME_PHRASE",
    "RENDERER_ID",
    "RENDERER_VERSION",
    "SCOPE_PHRASE",
    "claim_sentence",
    "render_certificate",
    "render_delta",
]

__version__ = "1.0.1"
SPEC_VERSION = "0.2.0"
