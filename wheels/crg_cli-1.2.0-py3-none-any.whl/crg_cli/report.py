"""The canonical human-readable certificate report (spec 50).

50.3 permits implementations to vary typography, language, and format; it
forbids hiding or reordering the claim scope, completeness basis,
uncertainty, or verification status.  So the section list below is fixed
and every section is emitted, even when it is empty -- "not stated" is a
finding, and omitting the line would hide it.

This renderer lives in the CLI rather than in ``crg-verify`` because 50.2
binds conforming *renderers*.  A renderer is presentation, and the
verification zone of 9.1 is deliberately kept to checking.
"""
from __future__ import annotations

import json
from typing import Any, Dict, List, Mapping, Optional

__all__ = [
    "render_certificate_report",
    "render_phase_analysis_report",
    "render_certified_delta_report",
    "CERTIFICATE_SECTIONS",
]

#: Specification 50.2, mandatory order.
CERTIFICATE_SECTIONS = (
    "Claim",
    "Claim scope",
    "Completeness basis",
    "Decision semantics",
    "Required retained object",
    "Selected, tied, or possible-winner realizations",
    "Runner-up and margin",
    "Numerical enclosure",
    "Evidence uncertainty",
    "Policy tolerance",
    "Geometry basis",
    "Retained and pruned alternatives",
    "Regret witness",
    "Evidence classes and lineage",
    "Solver trust profile",
    "Verification level",
    "Dependencies",
    "Validity and clock judgment",
    "Reopen conditions",
    "Signatures",
    "Limitations",
)


def _text(value: Any) -> str:
    return "not stated" if value in (None, (), [], {}) else str(value)


def _canonical_text(value: Any) -> str:
    if value in (None, (), [], {}):
        return "not stated"
    if isinstance(value, (Mapping, list, tuple)):
        return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return str(value)


def render_certificate_report(cert: Dict[str, Any], verification: Optional[Any] = None) -> str:
    """Render a decision certificate in the mandatory order of 50.2."""
    scope = cert.get("scope") or {}
    objective = scope.get("objective_family") or {}
    derivation = cert.get("derivation") or {}
    completeness = cert.get("completeness") or {}
    witness = cert.get("regret_witness")
    values = cert.get("objective_values") or {}
    verified = verification.report if verification is not None else {}

    body: Dict[str, Any] = {
        "Claim": f"{cert.get('outcome')} for decision scope {scope.get('scope_id')!r}",
        "Claim scope": cert.get("claim_scope"),
        "Completeness basis": f"{completeness.get('basis_type')} over "
                              f"{completeness.get('declared_universe')!r}",
        "Decision semantics": f"objective family {objective.get('type')!r}, quantification "
                              f"{objective.get('quantification', 'EACH_OBJECTIVE')}, "
                              f"uncertainty {scope.get('uncertainty_mode')}",
        "Required retained object": f"{derivation.get('required_object')} via "
                                    f"{derivation.get('rule_cited')}",
        "Selected, tied, or possible-winner realizations":
            f"selected={list(cert.get('selected') or [])}, ties={list(cert.get('ties') or [])}",
        "Runner-up and margin": f"runner-up={cert.get('runner_up')}, "
                                f"margin={cert.get('margin')}",
        "Numerical enclosure": {k: v.get("numerical_interval")
                                for k, v in values.items() if isinstance(v, dict)},
        "Evidence uncertainty": {k: v.get("evidence_interval") for k, v in values.items()
                                 if isinstance(v, dict) and v.get("evidence_interval")}
                                or "no evidence interval declared",
        "Policy tolerance": scope.get("tie_tolerance"),
        "Geometry basis": f"complete registry {cert.get('complete_registry_hash')}, retained "
                          f"{cert.get('retained_registry_hash')}, geometry preserved="
                          f"{cert.get('geometry_preserved')}",
        "Retained and pruned alternatives":
            f"{len(values)} retained; pruning certificates: "
            f"{len(cert.get('pruning_certificates') or [])}",
        "Regret witness": (f"gap {witness.get('gap')} in family "
                           f"{witness.get('objective_family')}") if witness else "none",
        "Evidence classes and lineage": cert.get("evidence_roots"),
        "Solver trust profile": sorted({str(v.get("solver_trust_profile"))
                                        for v in values.values() if isinstance(v, dict)})
                                or "not stated",
        "Verification level": verified.get("level_achieved") or "not verified in this run",
        "Dependencies": cert.get("dependencies"),
        "Validity and clock judgment": verified.get("time_judgment")
                                       or f"expiry {cert.get('expiry')} "
                                          "(issuer asserted; unverified)",
        "Reopen conditions": cert.get("reopen_conditions"),
        "Signatures": cert.get("signatures") or "unsigned",
        "Limitations": cert.get("limitations") or list(derivation.get("refusals") or [])
                       or "none recorded",
    }

    lines: List[str] = ["CRG DECISION CERTIFICATE REPORT", "=" * 31, ""]
    for index, section in enumerate(CERTIFICATE_SECTIONS, start=1):
        lines += [f"{index}. {section}", f"   {_text(body.get(section))}", ""]
    if verification is not None:
        lines.append(f"VERIFICATION STATUS: {verification.status}")
    return "\n".join(lines)


def render_phase_analysis_report(
    record: Mapping[str, Any], verification: Optional[Any] = None
) -> str:
    """Render all decision-relevant fields of a certified phase analysis."""

    profile = record.get("profile") or {}
    stability = record.get("stability") or {}
    boundaries = record.get("boundaries") or []
    regions = record.get("regions") or []
    ties = record.get("ties") or []
    degeneracies = record.get("degeneracies") or []
    lines = [
        "CRG CERTIFIED PHASE ANALYSIS REPORT",
        "=" * 35,
        "",
        f"Analysis identity: {record.get('analysis_id', 'not stated')}",
        f"Schema version: {record.get('schema_version', 'not stated')}",
        f"Registered profile: {profile.get('profile_id', 'not stated')} / {profile.get('profile_version', 'not stated')}",
        f"Claim scope: {record.get('claim_scope', 'not stated')}",
        f"Source R root: {record.get('source_r_root', 'not stated')}",
        f"Coordinate schema: {record.get('coordinate_schema_hash', 'not stated')}",
        f"Family completeness: {_canonical_text(record.get('family_completeness'))}",
        f"Parameter domain: {_canonical_text(profile.get('parameter_domain'))}",
        f"Policy tolerance: {_canonical_text(profile.get('policy_tolerance'))}",
        f"Arithmetic / solver trust: {record.get('arithmetic_profile', 'not stated')} / {record.get('solver_trust_profile', 'not stated')}",
        "",
        f"Policies ({len(record.get('policies') or [])})",
    ]
    for policy in record.get("policies") or []:
        lines.append(
            f"  - {policy.get('policy_id')}: coordinates={_canonical_text(policy.get('coordinate_values'))}; "
            f"affine={_canonical_text(policy.get('affine_value'))}"
        )
    lines.append(f"Regions ({len(regions)})")
    for region in regions:
        lines.append(
            f"  - {region.get('region_id')}: interval={_canonical_text(region.get('parameter_interval'))}; "
            f"winners={_canonical_text(region.get('winner_ids'))}"
        )
    lines.append(f"Certified boundaries ({len(boundaries)})")
    for boundary in boundaries:
        lines.append(
            f"  - {boundary.get('boundary_id')}: parameter={_canonical_text(boundary.get('parameter'))}; "
            f"left={_canonical_text(boundary.get('left_winner_ids'))}; "
            f"at={_canonical_text(boundary.get('boundary_winner_ids'))}; "
            f"right={_canonical_text(boundary.get('right_winner_ids'))}; "
            f"sidedness={boundary.get('sidedness')}"
        )
    lines.extend(
        [
            f"Ties ({len(ties)}): {_canonical_text(ties)}",
            f"Degeneracies ({len(degeneracies)}): {_canonical_text(degeneracies)}",
            f"Stability: {_canonical_text(stability)}",
            f"Limitations: {_canonical_text(record.get('claim_limitations'))}",
        ]
    )
    if verification is not None:
        lines.append(f"Independent verification: {verification.status}")
        if verification.violations:
            lines.append(f"Verification violations: {_canonical_text(verification.violations)}")
    return "\n".join(lines)


def render_certified_delta_report(
    record: Mapping[str, Any], verification: Optional[Any] = None
) -> str:
    """Render the complete certified-change and minimum-action evidence."""

    delta = record.get("delta") or {}
    event = delta.get("change_event") or {}
    minimum = record.get("minimum_recomputation_claim") or {}
    fields = record.get("changed_fields") or []
    edges = record.get("traversed_edges") or []
    lines = [
        "CRG CERTIFIED DELTA REPORT",
        "=" * 26,
        "",
        f"Evidence identity: {record.get('evidence_id', 'not stated')}",
        f"Schema version: {record.get('schema_version', 'not stated')}",
        f"Delta identity / root: {delta.get('delta_id', 'not stated')} / {record.get('delta_root', 'not stated')}",
        f"Classification: {delta.get('classification', 'not stated')}",
        f"Prior / current roots: {delta.get('prior_root', 'not stated')} / {delta.get('current_root', 'not stated')}",
        f"Change event: {_canonical_text(event)}",
        f"Minimum action: {minimum.get('action', 'not stated')}",
        f"Minimum-action basis: {minimum.get('basis', 'not stated')}",
        f"Phase evidence: {_canonical_text(record.get('phase_evidence'))}",
        f"Completeness changes: {_canonical_text(record.get('completeness_changes'))}",
        "",
        f"Changed fields ({len(fields)})",
    ]
    for field in fields:
        lines.append(
            f"  - {field.get('path')}: {field.get('change')} [{field.get('category')}]; "
            f"prior={_canonical_text(field.get('prior'))}; current={_canonical_text(field.get('current'))}"
        )
    lines.append(f"Traversed dependency edges ({len(edges)})")
    for edge in edges:
        lines.append(
            f"  - {edge.get('edge_id')}: {edge.get('source')} -> {edge.get('target')} "
            f"[{edge.get('edge_type')}], minimum={edge.get('minimum_action')}"
        )
    lines.extend(
        [
            f"Categorized changes: {_canonical_text(record.get('category_changes'))}",
            f"Preserved: {_canonical_text(delta.get('preserved'))}",
            f"Affected: {_canonical_text(delta.get('affected_paths'))}",
            f"Invalidated: {_canonical_text(delta.get('invalidated'))}",
            f"Recomputed: {_canonical_text(delta.get('recomputed'))}",
            f"Replacement roots: {_canonical_text(record.get('replacement_roots'))}",
            f"Producer verification status: {record.get('verification_status', 'not stated')}",
            f"Fail-closed policy: {_canonical_text(record.get('fail_closed_policy'))}",
        ]
    )
    if verification is not None:
        lines.append(f"Independent verification: {verification.status}")
        if verification.violations:
            lines.append(f"Verification violations: {_canonical_text(verification.violations)}")
    return "\n".join(lines)
