"""Closed v1.2 product boundary for non-authorizing change comparisons.

Public callers name one immutable stored ``CertifiedDeltaRecord``. They never
resubmit its inputs, verification result, derived counts, hashes, conclusions,
or authority fields. This module independently replays the stored delta,
builds the portable comparison, and independently verifies that result before
it can be previewed, persisted, reported, or exported.
"""
from __future__ import annotations

import copy
from typing import Any, Dict, Mapping, MutableMapping, Sequence, Tuple

import crg_change
import crg_verify
from crg_model.canonical import content_hash

from .store import CaseError, record_history

__all__ = [
    "CHANGE_COMPARISON_REQUEST_FIELDS",
    "CHANGE_COMPARISON_REQUIRED_FIELDS",
    "JourneyComparisonVerificationError",
    "build_verified_comparative_change",
    "persist_comparative_change",
    "inspect_comparative_change",
    "verify_comparative_change",
    "portable_journey_comparison_objects",
    "render_comparative_change_report",
]


CHANGE_COMPARISON_REQUEST_FIELDS = frozenset(
    {
        "comparison_id",
        "certified_delta_id",
        "decision_scope",
        "evidence_scope",
        "limitations",
    }
)
CHANGE_COMPARISON_REQUIRED_FIELDS = CHANGE_COMPARISON_REQUEST_FIELDS

_DELTA_REQUIRED_INPUTS = frozenset(
    {"prior_case", "current_case", "dependency_edges", "replacements"}
)
_DELTA_OPTIONAL_INPUTS = frozenset(
    {
        "prior_phase",
        "current_phase",
        "prior_phase_source_r",
        "current_phase_source_r",
    }
)


class JourneyComparisonVerificationError(CaseError):
    """A producer or stored source disagreed with independent replay."""


def _object(value: Any, where: str) -> dict:
    if not isinstance(value, Mapping):
        raise CaseError(f"{where} must be a JSON object")
    return copy.deepcopy(dict(value))


def _closed(value: Any, where: str, required: Sequence[str]) -> dict:
    result = _object(value, where)
    missing = sorted(set(required) - set(result))
    unsupported = sorted(set(result) - set(required))
    if missing:
        raise CaseError(f"{where} is missing required field(s): {', '.join(missing)}")
    if unsupported:
        raise CaseError(
            f"{where} contains unsupported field(s): {', '.join(unsupported)}; "
            "callers cannot supply records, verifier results, hashes, derived facts, "
            "authority, conclusions, scores, or mutations"
        )
    return result


def _identity(value: Any, where: str) -> str:
    if not isinstance(value, str) or not value.strip() or value != value.strip():
        raise CaseError(f"{where} must be a normalized non-empty string")
    return value


def _stored(
    case: Mapping[str, Any], inventory: str, identity: str, record_type: str
) -> dict:
    values = case.get(inventory) or {}
    raw = values.get(identity) if isinstance(values, Mapping) else None
    if not isinstance(raw, Mapping):
        raise CaseError(f"no stored {record_type} {identity!r} exists in this case")
    record = copy.deepcopy(dict(raw))
    if record.get("record_type") != record_type:
        raise CaseError(
            f"stored {inventory}.{identity} carries {record.get('record_type')!r}; "
            f"expected {record_type!r}"
        )
    return record


def _stored_delta(case: Mapping[str, Any], evidence_id: str) -> Tuple[dict, dict]:
    record = _stored(case, "certified_deltas", evidence_id, "CertifiedDeltaRecord")
    if record.get("evidence_id") != evidence_id:
        raise CaseError(
            f"stored CertifiedDeltaRecord {evidence_id!r} has a mismatched evidence_id"
        )
    inventory = case.get("certified_delta_inputs") or {}
    raw_inputs = inventory.get(evidence_id) if isinstance(inventory, Mapping) else None
    inputs = _object(raw_inputs, f"CertifiedDeltaRecord {evidence_id!r} replay inputs")
    missing = sorted(_DELTA_REQUIRED_INPUTS - set(inputs))
    unsupported = sorted(set(inputs) - _DELTA_REQUIRED_INPUTS - _DELTA_OPTIONAL_INPUTS)
    if missing or unsupported:
        raise CaseError(
            f"CertifiedDeltaRecord {evidence_id!r} has non-closed replay inputs: "
            f"missing={missing}, unsupported={unsupported}"
        )
    return record, inputs


def _verify_delta(record: Mapping[str, Any], inputs: Mapping[str, Any]):
    result = crg_verify.verify_certified_delta_record(
        record,
        inputs["prior_case"],
        inputs["current_case"],
        inputs["dependency_edges"],
        replacements=inputs["replacements"],
        prior_phase=inputs.get("prior_phase"),
        current_phase=inputs.get("current_phase"),
        prior_phase_source_r=inputs.get("prior_phase_source_r"),
        current_phase_source_r=inputs.get("current_phase_source_r"),
    )
    if not result.ok:
        detail = "; ".join(result.violations) or result.status
        raise JourneyComparisonVerificationError(
            "stored CertifiedDeltaRecord failed independent replay; no comparative "
            f"record may be published: {detail}"
        )
    return result


def verify_comparative_change(record: Any):
    document = _object(record, "ComparativeChangeEvidence")
    result = crg_verify.verify_comparative_change_evidence(document)
    if not result.ok:
        detail = "; ".join(result.violations) or result.status
        raise JourneyComparisonVerificationError(
            "ComparativeChangeEvidence failed independent reconstruction; no record "
            f"may be previewed, persisted, reported, or exported: {detail}"
        )
    return result


def build_verified_comparative_change(
    request: Any, case: Mapping[str, Any]
) -> Tuple[dict, Any]:
    """Resolve one stored delta and build independently verified v1.2 evidence."""

    value = _closed(
        request,
        "comparative change request",
        CHANGE_COMPARISON_REQUIRED_FIELDS,
    )
    comparison_id = _identity(value["comparison_id"], "comparison_id")
    delta_id = _identity(value["certified_delta_id"], "certified_delta_id")
    delta, inputs = _stored_delta(case, delta_id)
    delta_verification = _verify_delta(delta, inputs)
    try:
        record = crg_change.build_comparative_change_evidence(
            comparison_id,
            certified_delta=delta,
            verification_inputs=inputs,
            independent_verification=delta_verification.to_json(),
            decision_scope=value["decision_scope"],
            evidence_scope=value["evidence_scope"],
            limitations=value["limitations"],
        ).to_canonical()
    except (KeyError, TypeError, ValueError) as error:
        raise CaseError(f"comparative change request is invalid: {error}") from error
    verification = verify_comparative_change(record)
    return record, verification


def persist_comparative_change(
    case: MutableMapping[str, Any], record: Mapping[str, Any]
) -> str:
    """Persist one immutable independently verified non-authorizing record."""

    verification = verify_comparative_change(record)
    comparison_id = _identity(record.get("comparison_id"), "comparison_id")
    existing = (case.get("comparative_change_evidence") or {}).get(comparison_id)
    if existing is not None and content_hash(existing) != content_hash(record):
        raise CaseError(
            f"comparative change {comparison_id!r} already names different content; "
            "use a new immutable comparison identity"
        )
    canonical = copy.deepcopy(dict(record))
    case.setdefault("comparative_change_evidence", {})[comparison_id] = canonical
    record_history(
        case,
        "comparative change generate",
        {
            "comparison_id": comparison_id,
            "record_hash": canonical["record_hash"],
            "authority": "NON_AUTHORIZING",
            "authorizing": False,
            "semantic_effect": "NONE",
            "independently_verified": True,
            "verifier_status": verification.status,
        },
    )
    return comparison_id


def inspect_comparative_change(case: Mapping[str, Any], comparison_id: str) -> dict:
    identity = _identity(comparison_id, "comparison_id")
    record = _stored(
        case, "comparative_change_evidence", identity, "ComparativeChangeEvidence"
    )
    if record.get("comparison_id") != identity:
        raise CaseError(f"stored comparative change {identity!r} has mismatched identity")
    verification = verify_comparative_change(record)
    return {
        "comparative_change": record,
        "verification": verification.to_json(),
        "report": render_comparative_change_report(record, verification),
        "authority": "NON_AUTHORIZING",
        "authorizing": False,
        "semantic_effect": "NONE",
    }


def portable_journey_comparison_objects(case: Mapping[str, Any]) -> Dict[str, Any]:
    """Return independently replayed v1.2 comparative-change records."""

    objects: Dict[str, Any] = {}
    changes = case.get("comparative_change_evidence") or {}
    if not isinstance(changes, Mapping):
        return objects
    for comparison_id, raw in sorted(changes.items(), key=lambda item: str(item[0])):
        if not isinstance(raw, Mapping):
            raise CaseError(f"comparative change {comparison_id!r} is not a JSON object")
        record = copy.deepcopy(dict(raw))
        if record.get("comparison_id") != comparison_id:
            raise CaseError(
                f"comparative change {comparison_id!r} has mismatched stored identity"
            )
        verify_comparative_change(record)
        objects[f"comparative-change:{comparison_id}"] = record
    return objects


def _count(value: Any) -> str:
    if isinstance(value, Mapping) and set(value) == {"exact"}:
        return str(value["exact"])
    return "not stated"


def render_comparative_change_report(
    record: Mapping[str, Any], verification: Any = None
) -> str:
    """Render direct certified-change facts without economic interpretation."""

    facts = record.get("system_derived_facts") or {}
    lines = [
        "CRG COMPARATIVE CHANGE EVIDENCE",
        "=" * 31,
        "",
        f"Comparison: {record.get('comparison_id', 'not stated')}",
        f"Record hash: {record.get('record_hash', 'not stated')}",
        "Authority: NON_AUTHORIZING",
        "Authorizing: false",
        "Semantic effect: NONE",
        f"Minimum action: {facts.get('minimum_action', 'not stated')}",
        "",
        "DIRECT CERTIFIED WORK IDENTITIES",
    ]
    for label, key in (
        ("Preserved", "preserved_work"),
        ("Invalidated", "invalidated_work"),
        ("Recomputed", "recomputed_work"),
    ):
        item = facts.get(key) or {}
        members = ", ".join(str(value) for value in item.get("members") or ()) or "none"
        lines.append(
            f"- {label}: {_count(item.get('count'))} artifact identities — {members}"
        )
    lines.extend(
        [
            "",
            "CLAIM BOUNDARY",
            str(record.get("claim_boundary") or "not stated"),
            "No elapsed-time, effort, cost, avoided-work, savings, ROI, ranking, or "
            "unexecuted counterfactual is inferred.",
        ]
    )
    if verification is not None:
        lines.extend(["", "INDEPENDENT VERIFICATION", f"Status: {verification.status}"])
    limitations = record.get("limitations") or []
    if limitations:
        lines.extend(["", "LIMITATIONS"])
        lines.extend(f"- {item}" for item in limitations)
    return "\n".join(lines) + "\n"
