"""The client SDK generator: OpenAPI in, two dependency-free clients out.

Normative basis: 38.2 (the reference server SHALL provide *generated* client
SDKs), 38.3 (principal endpoints), 38.4 (idempotency keys), 38.5 (events),
6.6 (fail closed), 6.12 (anti-lock-in), 47.1 (determinism).

38.2 asks for *generated* client SDKs, and the word is doing work.  A
hand-written client is a second description of the surface, and a second
description drifts: it grows a method for an endpoint that was renamed, keeps
calling one that was removed, and quietly omits the ``Idempotency-Key``
header on the three mutations whose author had not read 38.4 yet.  The
generator here reads exactly one input --
:func:`crg_server.openapi.openapi_document`, which is itself generated from
the router's endpoint table -- so there is a single chain from the table the
server dispatches on to the method an integrator calls, and no link in it is
maintained by hand.

That chain is only worth anything if it is *checked*, so two properties are
asserted by the test suite rather than asserted by this docstring:

* **coverage in both directions.**  Every documented operation appears in
  both clients, and every method in both clients is a documented operation.
  The second direction is the interesting one: a generator that emitted a
  convenience method for an endpoint the server does not have would be
  reintroducing the drift the generator exists to remove.
* **byte-for-byte determinism (47.1).**  Regenerating produces identical
  bytes.  Paths are walked in sorted order, methods within a path in sorted
  order, and nothing in the emitted header is a timestamp, a hostname, or a
  version of the interpreter that happened to run it.  A generated artifact
  that differs between two runs cannot be reviewed in a diff, and an artifact
  nobody can review in a diff is an artifact nobody reviews.

Both clients are dependency-free by construction -- Python uses
:mod:`urllib.request`, JavaScript uses ``fetch`` and nothing else -- for the
same reason the server is: 45.5 contemplates air-gapped deployments and 48.3
contemplates independent reimplementations, and neither is served by a client
that first needs a package index.

What the emitted clients carry beyond a naive request wrapper, because the
specification makes each of them load-bearing:

* ``Idempotency-Key`` is generated exactly when OpenAPI declares it (38.4).
  The isolated CRG-ENH-04 local-measurement transitions deliberately rely on
  state/hash confirmation and never copy replay bodies into the case-store
  idempotency plane;
* ``X-CRG-Actor`` and ``X-CRG-Correlation-Id`` are sent on every request
  (44.7, 38.5), so an event a subscriber receives can be traced back to the
  call that caused it;
* refusals are raised as *typed* errors carrying the server's category,
  status, and remedy, and a blocked outcome gets its own class, so a client
  that catches "an error" cannot silently treat a 422 refusal as a transport
  hiccup and retry it (6.6);
* long-running operations get a polling helper shaped around 38.3's ``202``
  contract, and the event stream gets an SSE reader shaped around 38.2's
  resumption contract.  Both exist so that the *asynchronous* parts of the
  surface are as easy to use correctly as the synchronous parts, which is
  the only way they will be.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

__all__ = [
    "GENERATOR",
    "SDK_FILES",
    "Operation",
    "load_operations",
    "render_javascript_client",
    "render_javascript_manifest",
    "render_python_client",
    "generate_sdk",
    "write_sdk",
    "main",
]

#: Named in every emitted header, so a reader of a generated file knows what
#: to re-run rather than what to edit.
GENERATOR = "crg_server.sdkgen"

#: The emitted tree, relative to the repository root.
SDK_FILES = ("sdk/python/crg_client.py", "sdk/js/crg-client.mjs", "sdk/js/package.json")

_DO_NOT_EDIT = "DO NOT EDIT BY HAND."


# ---------------------------------------------------------------------------
# reading the description
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class Operation:
    """One documented operation, in the shape a code emitter needs it.

    Everything here is read out of the OpenAPI document.  Nothing is read out
    of :data:`crg_server.app.ENDPOINTS`, even though that would be easier:
    the point of generating from the description is that the description is
    what an *independent* implementation would also generate from (48.3), and
    a generator that peeked at the server's internals would not prove that.
    """

    operation_id: str
    method: str
    path: str
    summary: str
    spec: str
    path_parameters: Tuple[str, ...] = ()
    query_parameters: Tuple[str, ...] = ()
    header_parameters: Tuple[str, ...] = ()
    request_fields: Tuple[str, ...] = ()
    body_operation_values: Tuple[str, ...] = ()
    has_body: bool = False
    idempotent: bool = False
    long_running: bool = False
    streaming: bool = False
    binary: bool = False
    success_status: int = 200
    failure_statuses: Tuple[int, ...] = ()


def _success_status(responses: Mapping[str, Any]) -> int:
    codes = sorted(int(code) for code in responses if str(code).isdigit())
    for code in codes:
        if 200 <= code < 300:
            return code
    return 200


def _produces(responses: Mapping[str, Any], success: int) -> str:
    content = (responses.get(str(success)) or {}).get("content") or {}
    for media in sorted(content):
        return str(media)
    return "application/json"


def load_operations(document: Mapping[str, Any]) -> Tuple[Operation, ...]:
    """Every operation in ``document``, in a stable order (47.1).

    Sorted by path and then by method, not by the order the document happens
    to list them in: a generator whose output order depends on a dictionary's
    insertion order produces a different file every time somebody reorders
    the endpoint table for readability.
    """
    operations: List[Operation] = []
    paths = document.get("paths") or {}
    for path in sorted(paths):
        entry = paths[path] or {}
        for method in sorted(entry):
            operation = entry[method] or {}
            parameters = operation.get("parameters") or []
            responses = operation.get("responses") or {}
            success = _success_status(responses)
            produces = _produces(responses, success)
            body = operation.get("requestBody") or {}
            schema = (
                ((body.get("content") or {}).get("application/json") or {}).get("schema")
                or {}
            )
            operations.append(
                Operation(
                    operation_id=str(operation.get("operationId") or ""),
                    method=str(method).upper(),
                    path=str(path),
                    summary=str(operation.get("summary") or ""),
                    spec=str(operation.get("x-crg-spec-reference") or ""),
                    path_parameters=tuple(
                        str(p["name"]) for p in parameters if p.get("in") == "path"
                    ),
                    query_parameters=tuple(
                        str(p["name"]) for p in parameters if p.get("in") == "query"
                    ),
                    header_parameters=tuple(
                        str(p["name"])
                        for p in parameters
                        if p.get("in") == "header"
                        and str(p["name"])
                        not in {"X-CRG-Actor", "X-CRG-Correlation-Id", "Idempotency-Key"}
                    ),
                    request_fields=tuple(sorted(schema.get("properties") or {})),
                    body_operation_values=tuple(
                        str(value)
                        for value in (
                            (((schema.get("properties") or {}).get("operation") or {}).get("enum"))
                            or ()
                        )
                    ),
                    has_body=bool(body),
                    idempotent=any(
                        p.get("in") == "header" and p.get("name") == "Idempotency-Key"
                        for p in parameters
                    ),
                    long_running=bool(operation.get("x-crg-long-running")),
                    streaming=bool(operation.get("x-crg-streaming")),
                    binary=produces not in {"application/json", "text/event-stream"},
                    success_status=success,
                    failure_statuses=tuple(
                        sorted(
                            int(code)
                            for code in responses
                            if str(code).isdigit() and int(code) >= 400
                        )
                    ),
                )
            )
    return tuple(operations)


# ---------------------------------------------------------------------------
# naming
# ---------------------------------------------------------------------------
def _python_name(wire: str) -> str:
    """A wire parameter name as a Python identifier."""
    return wire.replace("-", "_").replace(".", "_").lower()


def _js_name(wire: str) -> str:
    """A wire parameter name as a JavaScript identifier (camelCase)."""
    parts = wire.replace("-", "_").replace(".", "_").lower().split("_")
    return parts[0] + "".join(part.capitalize() for part in parts[1:])


def _header_block(document: Mapping[str, Any], comment: str, count: int) -> List[str]:
    info = document.get("info") or {}
    return [
        f"{comment} GENERATED FILE.  {_DO_NOT_EDIT}",
        f"{comment}",
        f"{comment} Generator      : {GENERATOR}",
        f"{comment} OpenAPI        : {document.get('openapi')}",
        f"{comment} API version    : {info.get('version')}",
        f"{comment} Specification  : CRG Operational Systems Master Specification "
        f"v{document.get('x-crg-spec-version')}, section 38",
        f"{comment} Operations     : {count}",
        f"{comment}",
        f"{comment} Regenerate with:  python3 -m {GENERATOR}",
        f"{comment} Edits made here are lost on the next run and, worse, make the",
        f"{comment} client disagree with the server it was generated from (6.12).",
    ]


# ---------------------------------------------------------------------------
# the Python client
# ---------------------------------------------------------------------------
_PYTHON_PREAMBLE = '''
from __future__ import annotations

import base64
import json
import re
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Callable, Dict, Iterable, Iterator, List, Mapping, Optional, Tuple

__all__ = [
    "CrgError",
    "CrgApiError",
    "CrgBlocked",
    "CrgConflict",
    "CrgForbidden",
    "CrgNotFound",
    "CrgRedacted",
    "CrgUnauthorized",
    "SseEvent",
    "CrgClient",
    "parse_sse",
    "urllib_transport",
    "urllib_stream_transport",
    "OPERATIONS",
]


class CrgError(Exception):
    """Anything this client refuses to do, or could not do."""


class CrgApiError(CrgError):
    """A refusal the server described (6.6, 38.3).

    The server's ``category``, ``status``, and ``remedy`` are kept as fields
    rather than flattened into the message, because the remedy is frequently
    the only text that says which rule refused.
    """

    def __init__(self, status, body, operation=""):
        error = ((body or {}).get("error") if isinstance(body, Mapping) else None) or {}
        message = error.get("message") or "request refused with status %s" % status
        super().__init__(message)
        self.status = int(status)
        self.category = error.get("category", "unknown")
        self.remedy = error.get("remedy", "")
        self.detail = error.get("detail")
        self.body = body
        self.operation = operation


class CrgUnauthorized(CrgApiError):
    """401: no actor identity was presented (44.2)."""


class CrgForbidden(CrgApiError):
    """403: the actor holds no role authorizing this operation (44.3)."""


class CrgNotFound(CrgApiError):
    """404: no object of that identity exists here."""


class CrgConflict(CrgApiError):
    """409: stale version, idempotency-key reuse, legal hold, or a job with no result."""


class CrgRedacted(CrgApiError):
    """410: the content was removed and a tombstone remains (17.2)."""


class CrgBlocked(CrgApiError):
    """422: a scope mismatch or a blocked outcome.

    Its own class on purpose.  6.6 forbids reporting a refusal behind a 2xx,
    and the corresponding client-side rule is that a refusal must not be
    caught by the same ``except`` clause that retries a timeout.
    """


_ERROR_CLASSES = {
    401: CrgUnauthorized,
    403: CrgForbidden,
    404: CrgNotFound,
    409: CrgConflict,
    410: CrgRedacted,
    422: CrgBlocked,
}


def _raise_for(status, body, operation):
    raise _ERROR_CLASSES.get(int(status), CrgApiError)(status, body, operation)


class SseEvent(object):
    """One record of a Server-Sent Events stream (38.2, 38.5)."""

    __slots__ = ("id", "event", "data", "raw")

    def __init__(self, identifier, name, data, raw):
        self.id = identifier
        self.event = name
        self.data = data
        self.raw = raw

    def __repr__(self):
        return "SseEvent(id=%r, event=%r)" % (self.id, self.event)


def parse_sse(chunks):
    """Turn framed SSE bytes into :class:`SseEvent` values.

    Records are separated by a blank line and a record may arrive split
    across chunk boundaries, so the buffer is carried between chunks.  A
    record whose first character is a colon is a comment -- the keepalive --
    and is skipped rather than surfaced, because a subscriber counting
    events must not count heartbeats.
    """
    buffer = ""
    for chunk in chunks:
        if isinstance(chunk, bytes):
            chunk = chunk.decode("utf-8")
        buffer += chunk
        while "\\n\\n" in buffer:
            record, buffer = buffer.split("\\n\\n", 1)
            parsed = _parse_sse_record(record)
            if parsed is not None:
                yield parsed
    if buffer.strip():
        parsed = _parse_sse_record(buffer)
        if parsed is not None:
            yield parsed


def _parse_sse_record(record):
    identifier = None
    name = "message"
    data_lines = []
    saw_data = False
    for line in record.split("\\n"):
        if not line or line.startswith(":"):
            continue
        field, _, value = line.partition(":")
        if value.startswith(" "):
            value = value[1:]
        if field == "id":
            identifier = value
        elif field == "event":
            name = value
        elif field == "data":
            data_lines.append(value)
            saw_data = True
    if not saw_data:
        return None
    text = "\\n".join(data_lines)
    try:
        data = json.loads(text)
    except ValueError:
        data = text
    return SseEvent(identifier, name, data, record)


def urllib_transport(method, url, headers, body, timeout=30.0):
    """The default transport: ``(status, headers, bytes)`` over urllib."""
    request = urllib.request.Request(url, data=body, headers=dict(headers), method=method)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return int(response.status), dict(response.headers), response.read()
    except urllib.error.HTTPError as error:
        return int(error.code), dict(error.headers or {}), error.read() or b""


def urllib_stream_transport(method, url, headers, timeout=None):
    """The default streaming transport: an iterator of byte chunks (38.2).

    ``timeout=None`` on purpose.  An event stream is *supposed* to be quiet
    between events; a read timeout would turn a working subscription into a
    reconnect loop, which is exactly the failure mode the keepalive comment
    and ``Last-Event-ID`` exist to make unnecessary.
    """
    request = urllib.request.Request(url, headers=dict(headers), method=method)
    response = urllib.request.urlopen(request, timeout=timeout)
    try:
        while True:
            chunk = response.read1(4096) if hasattr(response, "read1") else response.read(4096)
            if not chunk:
                return
            yield chunk
    finally:
        response.close()


class CrgClient(object):
    """A generated client for the CRG headless integration surface (38).

    ``transport`` and ``stream_transport`` are injectable: the default pair
    speaks HTTP, and a caller may substitute anything with the same shape --
    an in-process callable that hands the request straight to
    ``Application.dispatch``, for instance, which is how this client is
    tested without a socket.
    """

    def __init__(
        self,
        base_url="http://127.0.0.1:8000",
        actor="",
        correlation_id=None,
        authorization=None,
        transport=None,
        stream_transport=None,
        timeout=30.0,
    ):
        self.base_url = str(base_url).rstrip("/")
        self.actor = str(actor or "")
        self.correlation_id = correlation_id
        self.authorization = str(authorization or "")
        self.timeout = timeout
        self._transport = transport or (
            lambda method, url, headers, body: urllib_transport(
                method, url, headers, body, timeout
            )
        )
        self._stream_transport = stream_transport

    def set_bearer_token(self, token):
        """Authenticate subsequent calls with an OAuth/OIDC bearer token."""
        value = str(token or "").strip()
        if not value:
            raise CrgError("a bearer token must be nonempty")
        self.authorization = "Bearer " + value
        return self

    def set_api_key(self, key_id, secret):
        """Authenticate subsequent calls with a CRG service identity."""
        identifier = str(key_id or "").strip()
        material = str(secret or "")
        if not identifier or not material:
            raise CrgError("an API key requires both key_id and secret")
        self.authorization = "ApiKey " + identifier + "." + material
        return self

    def set_basic_auth(self, username, password):
        """Authenticate subsequent calls with a TLS-protected local account."""
        user = str(username or "")
        password = str(password or "")
        if not user or ":" in user or not password:
            raise CrgError("basic authentication requires a nonempty colon-free username and password")
        raw = (user + ":" + password).encode("utf-8")
        self.authorization = "Basic " + base64.b64encode(raw).decode("ascii")
        return self

    def clear_authentication(self):
        """Remove the configured credential from subsequent calls."""
        self.authorization = ""
        return self

    # -- request plumbing --------------------------------------------------
    def _expand(self, template, params):
        def replace(match):
            name = match.group(1)
            value = params.get(name)
            if value is None or value == "":
                raise CrgError(
                    "the path parameter %r is required by %s" % (name, template)
                )
            return urllib.parse.quote(str(value), safe="")

        return re.sub(r"\\{([^}]+)\\}", replace, template)

    @staticmethod
    def _query(values):
        return {k: str(v) for k, v in sorted(values.items()) if v is not None}

    def _headers(self, actor, correlation_id, idempotency_key=None, extra=None):
        headers = {"Accept": "application/json"}
        if self.authorization:
            headers["Authorization"] = self.authorization
        chosen_actor = self.actor if actor is None else actor
        if chosen_actor:
            headers["X-CRG-Actor"] = str(chosen_actor)
        chosen_correlation = (
            self.correlation_id if correlation_id is None else correlation_id
        )
        if chosen_correlation:
            headers["X-CRG-Correlation-Id"] = str(chosen_correlation)
        if idempotency_key:
            headers["Idempotency-Key"] = str(idempotency_key)
        for key, value in sorted((extra or {}).items()):
            if value is not None:
                headers[key] = str(value)
        return headers

    def _url(self, path, query):
        url = self.base_url + path
        if query:
            url += "?" + urllib.parse.urlencode(query)
        return url

    def _request(
        self,
        method,
        path,
        query=None,
        body=None,
        idempotency_key=None,
        actor=None,
        correlation_id=None,
        raw=False,
        operation="",
    ):
        headers = self._headers(actor, correlation_id, idempotency_key)
        payload = None
        if body is not None:
            payload = json.dumps(body, sort_keys=True, separators=(",", ":")).encode("utf-8")
            headers["Content-Type"] = "application/json"
        status, response_headers, data = self._transport(
            method, self._url(path, query or {}), headers, payload
        )
        if raw:
            if status >= 400:
                _raise_for(status, _maybe_json(data), operation)
            return data
        decoded = _maybe_json(data)
        if status >= 400:
            _raise_for(status, decoded, operation)
        return decoded

    def _stream(
        self, path, query=None, last_event_id=None, actor=None, correlation_id=None
    ):
        """Open a Server-Sent Events subscription and yield parsed records."""
        extra = {"Accept": "text/event-stream"}
        if last_event_id is not None:
            extra["Last-Event-ID"] = str(last_event_id)
        headers = self._headers(actor, correlation_id, None, extra)
        url = self._url(path, query or {})
        if self._stream_transport is not None:
            chunks = self._stream_transport("GET", url, headers)
        else:
            status, _headers, data = self._transport("GET", url, headers, None)
            if status >= 400:
                _raise_for(status, _maybe_json(data), "stream")
            chunks = [data]
        for record in parse_sse(chunks):
            yield record

    # -- the asynchronous contract of 38.3 ---------------------------------
    def wait_for_job(self, job_id, attempts=1000, on_wait=None):
        """Poll ``GET /jobs/{job_id}/result`` until the job stops running.

        Raises :class:`CrgBlocked` for a blocked outcome and
        :class:`CrgConflict` for a failed or cancelled job, because that is
        what the server returns and flattening either into ``None`` would
        reintroduce the ambiguity 6.6 removed.
        """
        for _ in range(int(attempts)):
            result = self.getJobResult(job_id)
            if str(result.get("status")) not in ("QUEUED", "RUNNING"):
                return result
            if on_wait is not None:
                on_wait()
        raise CrgError("job %s did not reach a terminal status in %s polls" % (job_id, attempts))

    @staticmethod
    def encode_bundle(data):
        """Base64 a ``.crg`` archive for the bundle endpoints of 39."""
        return base64.b64encode(bytes(data)).decode("ascii")

    # -- the generated method per operationId of the document --------------
'''

_PYTHON_EPILOGUE = '''
def _maybe_json(data):
    if not data:
        return None
    if isinstance(data, bytes):
        try:
            data = data.decode("utf-8")
        except UnicodeDecodeError:
            return None
    try:
        return json.loads(data)
    except ValueError:
        return data
'''


def _python_signature(operation: Operation) -> str:
    parts = ["self"]
    parts.extend(_python_name(name) for name in operation.path_parameters)
    keyword: List[str] = []
    for name in operation.query_parameters:
        keyword.append(f"{_python_name(name)}=None")
    for name in operation.header_parameters:
        keyword.append(f"{_python_name(name)}=None")
    if operation.has_body:
        keyword.append("body=None")
    if operation.idempotent:
        keyword.append("idempotency_key=None")
    keyword.append("actor=None")
    keyword.append("correlation_id=None")
    if keyword:
        parts.append("*")
        parts.extend(keyword)
    return ", ".join(parts)


def _python_docstring(operation: Operation) -> List[str]:
    lines = [
        f'        """{operation.method} {operation.path} -- {operation.summary}.',
        "",
        f"        Specification {operation.spec}.",
    ]
    if operation.long_running:
        lines.append(
            "        Long-running: answers 202 with a job identifier, never a result"
        )
        lines.append("        (38.3).  Follow with ``wait_for_job``.")
    if operation.streaming:
        lines.append(
            "        Streaming: returns an iterator of :class:`SseEvent` (38.2)."
        )
    if operation.binary:
        lines.append("        Returns raw bytes rather than a decoded object.")
    if operation.request_fields:
        lines.append(
            "        Body fields: " + ", ".join(operation.request_fields) + "."
        )
    if operation.body_operation_values:
        lines.append(
            "        Closed body operation values: "
            + ", ".join(operation.body_operation_values)
            + "."
        )
    if operation.failure_statuses:
        lines.append(
            "        Refuses with: "
            + ", ".join(str(s) for s in operation.failure_statuses)
            + " (6.6)."
        )
    lines.append('        """')
    return lines


def _python_method(operation: Operation) -> List[str]:
    lines = [f"    def {operation.operation_id}({_python_signature(operation)}):"]
    lines.extend(_python_docstring(operation))
    path_map = (
        "{"
        + ", ".join(
            f'"{name}": {_python_name(name)}' for name in operation.path_parameters
        )
        + "}"
    )
    query_map = (
        "{"
        + ", ".join(
            f'"{name}": {_python_name(name)}' for name in operation.query_parameters
        )
        + "}"
    )
    expand = f'self._expand("{operation.path}", {path_map})'
    if operation.streaming:
        header = operation.header_parameters[0] if operation.header_parameters else None
        resume = _python_name(header) if header else "None"
        lines.extend(
            [
                "        return self._stream(",
                f"            {expand},",
                f"            query=self._query({query_map}),",
                f"            last_event_id={resume},",
                "            actor=actor,",
                "            correlation_id=correlation_id,",
                "        )",
            ]
        )
        return lines
    lines.extend(
        [
            "        return self._request(",
            f'            "{operation.method}",',
            f"            {expand},",
            f"            query=self._query({query_map}),",
            f"            body={'body' if operation.has_body else 'None'},",
            f"            idempotency_key={'idempotency_key' if operation.idempotent else 'None'},",
            "            actor=actor,",
            "            correlation_id=correlation_id,",
            f"            raw={operation.binary},",
            f'            operation="{operation.operation_id}",',
            "        )",
        ]
    )
    return lines


def render_python_client(
    document: Mapping[str, Any], operations: Sequence[Operation]
) -> str:
    """Emit ``sdk/python/crg_client.py`` (38.2)."""
    lines: List[str] = ['"""']
    lines.append(
        "A generated Python client for the CRG headless integration surface "
        "(specification 38)."
    )
    lines.append("")
    lines.extend(line.lstrip() for line in _header_block(document, "", len(operations)))
    lines.append("")
    lines.append(
        "Standard library only.  One method per operationId, path templating from"
    )
    lines.append(
        "the OpenAPI path templates, documented query parameters as keyword"
    )
    lines.append(
        "arguments, declared Idempotency-Key support (38.4), X-CRG-Actor and"
    )
    lines.append(
        "X-CRG-Correlation-Id on every request (44.7, 38.5), typed refusals (6.6),"
    )
    lines.append("a job-polling helper (38.3), and a Server-Sent Events reader (38.2).")
    lines.append('"""')
    lines.append(_PYTHON_PREAMBLE.strip("\n"))
    for operation in operations:
        lines.append("")
        lines.extend(_python_method(operation))
    lines.append("")
    lines.append("")
    lines.append(_PYTHON_EPILOGUE.strip("\n"))
    lines.append("")
    lines.append("")
    lines.append("#: Every operation this client was generated from, as data.")
    lines.append("OPERATIONS = {")
    for operation in operations:
        lines.append(
            f'    "{operation.operation_id}": '
            f'{{"method": "{operation.method}", "path": "{operation.path}", '
            f'"spec": "{operation.spec}", "long_running": {operation.long_running}, '
            f'"streaming": {operation.streaming}, "idempotent": {operation.idempotent}}},'
        )
    lines.append("}")
    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------------------
# the JavaScript client
# ---------------------------------------------------------------------------
_JS_PREAMBLE = '''
/** Anything this client refuses to do, or could not do. */
export class CrgError extends Error {
  constructor(message) {
    super(message);
    this.name = "CrgError";
  }
}

/**
 * A refusal the server described (6.6, 38.3).
 *
 * `category`, `status`, and `remedy` are kept as fields rather than flattened
 * into the message: the remedy is frequently the only text that says which
 * rule refused, and a client that discards it leaves its user guessing.
 */
export class CrgApiError extends CrgError {
  constructor(status, body, operation) {
    const error = (body && body.error) || {};
    super(error.message || `request refused with status ${status}`);
    this.name = "CrgApiError";
    this.status = status;
    this.category = error.category || "unknown";
    this.remedy = error.remedy || "";
    this.detail = error.detail || null;
    this.body = body;
    this.operation = operation;
  }
}

/** 401: no actor identity was presented (44.2). */
export class CrgUnauthorized extends CrgApiError {}
/** 403: the actor holds no role authorizing this operation (44.3). */
export class CrgForbidden extends CrgApiError {}
/** 404: no object of that identity exists here. */
export class CrgNotFound extends CrgApiError {}
/** 409: stale version, key reuse, legal hold, or a job with no result. */
export class CrgConflict extends CrgApiError {}
/** 410: the content was removed and a tombstone remains (17.2). */
export class CrgRedacted extends CrgApiError {}
/** 422: a scope mismatch or a blocked outcome, which is never a 2xx (6.6). */
export class CrgBlocked extends CrgApiError {}

const ERROR_CLASSES = {
  401: CrgUnauthorized,
  403: CrgForbidden,
  404: CrgNotFound,
  409: CrgConflict,
  410: CrgRedacted,
  422: CrgBlocked,
};

function refusalFor(status, body, operation) {
  const Cls = ERROR_CLASSES[status] || CrgApiError;
  return new Cls(status, body, operation);
}

/** Fill an OpenAPI path template.  A missing parameter is a programming error. */
export function expandPath(template, params = {}) {
  return template.replace(/\\{([^}]+)\\}/g, (_match, name) => {
    const value = params[name];
    if (value === undefined || value === null || value === "") {
      throw new CrgError(`the path parameter "${name}" is required by ${template}`);
    }
    return encodeURIComponent(String(value));
  });
}

/**
 * Parse one Server-Sent Events record (38.2).
 *
 * A record whose first character is a colon is a comment -- the keepalive --
 * and yields `null`, because a subscriber counting events must not count
 * heartbeats.
 */
export function parseSseRecord(record) {
  let id = null;
  let event = "message";
  const dataLines = [];
  let sawData = false;
  for (const line of record.split("\\n")) {
    if (!line || line.startsWith(":")) continue;
    const index = line.indexOf(":");
    const field = index === -1 ? line : line.slice(0, index);
    let value = index === -1 ? "" : line.slice(index + 1);
    if (value.startsWith(" ")) value = value.slice(1);
    if (field === "id") id = value;
    else if (field === "event") event = value;
    else if (field === "data") {
      dataLines.push(value);
      sawData = true;
    }
  }
  if (!sawData) return null;
  const text = dataLines.join("\\n");
  let data;
  try {
    data = JSON.parse(text);
  } catch (_error) {
    data = text;
  }
  return { id, event, data, raw: record };
}

/** A generated client for the CRG headless integration surface (spec 38). */
export class CrgClient {
  constructor(baseUrl = "http://127.0.0.1:8000", options = {}) {
    this.baseUrl = String(baseUrl).replace(/\\/+$/, "");
    this.actor = options.actor || "";
    this.correlationId = options.correlationId || null;
    this.authorization = options.authorization || "";
    // Injectable so a test, a proxy, or a runtime without a global `fetch`
    // can supply its own; the default is the platform one and nothing else.
    this.fetchImpl = options.fetch || (typeof fetch === "function" ? fetch.bind(globalThis) : null);
  }

  setBearerToken(token) {
    const value = String(token || "").trim();
    if (!value) throw new CrgError("a bearer token must be nonempty");
    this.authorization = `Bearer ${value}`;
    return this;
  }

  setApiKey(keyId, secret) {
    const identifier = String(keyId || "").trim();
    const material = String(secret || "");
    if (!identifier || !material) throw new CrgError("an API key requires keyId and secret");
    this.authorization = `ApiKey ${identifier}.${material}`;
    return this;
  }

  setBasicAuth(username, password) {
    const user = String(username || "");
    const material = String(password || "");
    if (!user || user.includes(":") || !material) {
      throw new CrgError("basic authentication requires a nonempty colon-free username and password");
    }
    const raw = `${user}:${material}`;
    let encoded;
    if (typeof btoa === "function") {
      const bytes = new TextEncoder().encode(raw);
      let binary = "";
      for (const byte of bytes) binary += String.fromCharCode(byte);
      encoded = btoa(binary);
    } else if (typeof Buffer !== "undefined") {
      encoded = Buffer.from(raw, "utf8").toString("base64");
    } else {
      throw new CrgError("this runtime has no base64 encoder for basic authentication");
    }
    this.authorization = `Basic ${encoded}`;
    return this;
  }

  clearAuthentication() {
    this.authorization = "";
    return this;
  }

  _headers(options = {}, extra = {}) {
    const headers = { Accept: "application/json" };
    const authorization =
      options.authorization === undefined ? this.authorization : options.authorization;
    if (authorization) headers.Authorization = String(authorization);
    const actor = options.actor === undefined ? this.actor : options.actor;
    if (actor) headers["X-CRG-Actor"] = String(actor);
    const correlationId =
      options.correlationId === undefined ? this.correlationId : options.correlationId;
    if (correlationId) headers["X-CRG-Correlation-Id"] = String(correlationId);
    if (options.idempotencyKey) headers["Idempotency-Key"] = String(options.idempotencyKey);
    for (const [key, value] of Object.entries(extra)) {
      if (value !== undefined && value !== null) headers[key] = String(value);
    }
    return headers;
  }

  _url(path, query = {}) {
    const search = new URLSearchParams();
    for (const key of Object.keys(query).sort()) {
      const value = query[key];
      if (value !== undefined && value !== null) search.append(key, String(value));
    }
    const suffix = search.toString();
    return this.baseUrl + path + (suffix ? `?${suffix}` : "");
  }

  async _request(method, path, spec = {}) {
    if (!this.fetchImpl) {
      throw new CrgError("no fetch implementation is available; pass options.fetch");
    }
    const headers = this._headers(spec.options || {});
    let body;
    if (spec.body !== undefined && spec.body !== null) {
      body = JSON.stringify(spec.body);
      headers["Content-Type"] = "application/json";
    }
    const response = await this.fetchImpl(this._url(path, spec.query || {}), {
      method,
      headers,
      body,
    });
    if (spec.binary) {
      if (!response.ok) throw refusalFor(response.status, await safeJson(response), spec.operation);
      return await response.arrayBuffer();
    }
    const payload = await safeJson(response);
    if (!response.ok) throw refusalFor(response.status, payload, spec.operation);
    return payload;
  }

  /**
   * Open a Server-Sent Events subscription and yield parsed records (38.2).
   *
   * `lastEventId` is the resumption contract: the server replays exactly
   * what was missed, with no gap and no duplicate.
   */
  async *_stream(path, spec = {}) {
    if (!this.fetchImpl) {
      throw new CrgError("no fetch implementation is available; pass options.fetch");
    }
    const extra = { Accept: "text/event-stream" };
    if (spec.lastEventId !== undefined && spec.lastEventId !== null) {
      extra["Last-Event-ID"] = String(spec.lastEventId);
    }
    const response = await this.fetchImpl(this._url(path, spec.query || {}), {
      method: "GET",
      headers: this._headers(spec.options || {}, extra),
    });
    if (!response.ok) {
      throw refusalFor(response.status, await safeJson(response), spec.operation);
    }
    const decoder = new TextDecoder("utf-8");
    let buffer = "";
    for await (const chunk of iterateBody(response)) {
      buffer += typeof chunk === "string" ? chunk : decoder.decode(chunk, { stream: true });
      let split = buffer.indexOf("\\n\\n");
      while (split !== -1) {
        const record = buffer.slice(0, split);
        buffer = buffer.slice(split + 2);
        const parsed = parseSseRecord(record);
        if (parsed) yield parsed;
        split = buffer.indexOf("\\n\\n");
      }
    }
    if (buffer.trim()) {
      const parsed = parseSseRecord(buffer);
      if (parsed) yield parsed;
    }
  }

  /**
   * Poll `GET /jobs/{job_id}/result` until the job stops running (38.3).
   *
   * A blocked outcome throws `CrgBlocked` and a failed job throws
   * `CrgConflict`, because that is what the server returns; collapsing
   * either into `null` would reintroduce the ambiguity 6.6 removed.
   */
  async waitForJob(jobId, options = {}) {
    const attempts = options.attempts || 1000;
    for (let index = 0; index < attempts; index += 1) {
      const result = await this.getJobResult(jobId, options);
      if (result.status !== "QUEUED" && result.status !== "RUNNING") return result;
      if (options.onWait) await options.onWait();
    }
    throw new CrgError(`job ${jobId} did not reach a terminal status in ${attempts} polls`);
  }

  // -- the generated method per operationId of the document ------------
'''

_JS_EPILOGUE = '''
}

async function safeJson(response) {
  const text = await response.text();
  if (!text) return null;
  try {
    return JSON.parse(text);
  } catch (_error) {
    return text;
  }
}

async function* iterateBody(response) {
  if (response.body && typeof response.body.getReader === "function") {
    const reader = response.body.getReader();
    for (;;) {
      const { done, value } = await reader.read();
      if (done) return;
      yield value;
    }
  } else {
    yield await response.text();
  }
}
'''


def _js_signature(operation: Operation) -> str:
    positional = [_js_name(name) for name in operation.path_parameters]
    positional.append("options = {}")
    return ", ".join(positional)


def _js_method(operation: Operation) -> List[str]:
    path_entries = ", ".join(
        f'"{name}": {_js_name(name)}' for name in operation.path_parameters
    )
    query_entries = ", ".join(
        f'"{name}": options.{_js_name(name)}' for name in operation.query_parameters
    )
    lines = [
        "  /**",
        f"   * {operation.method} {operation.path} -- {operation.summary}.",
        "   *",
        f"   * Specification {operation.spec}.",
    ]
    if operation.long_running:
        lines.append(
            "   * Long-running: resolves to a job identifier, never a result (38.3)."
        )
    if operation.streaming:
        lines.append("   * Streaming: an async iterator of SSE records (38.2).")
    if operation.binary:
        lines.append("   * Resolves to an ArrayBuffer rather than a decoded object.")
    if operation.request_fields:
        lines.append("   * Body fields: " + ", ".join(operation.request_fields) + ".")
    if operation.body_operation_values:
        lines.append(
            "   * Closed body operation values: "
            + ", ".join(operation.body_operation_values)
            + "."
        )
    if operation.failure_statuses:
        lines.append(
            "   * Refuses with: "
            + ", ".join(str(s) for s in operation.failure_statuses)
            + " (6.6)."
        )
    lines.append("   */")
    marker = "async *" if operation.streaming else "async "
    lines.append(f"  {marker}{operation.operation_id}({_js_signature(operation)}) {{")
    if not operation.idempotent and operation.path.startswith("/operational-measurement"):
        lines.append("    if (options.idempotencyKey) {")
        lines.append(
            f'      throw new CrgError("{operation.operation_id} does not declare an '
            'Idempotency-Key header in OpenAPI");'
        )
        lines.append("    }")
    lines.append(
        f'    const path = expandPath("{operation.path}", {{{path_entries}}});'
    )
    lines.append(f"    const query = {{{query_entries}}};")
    if operation.streaming:
        header = operation.header_parameters[0] if operation.header_parameters else None
        resume = f"options.{_js_name(header)}" if header else "undefined"
        lines.append("    yield* this._stream(path, {")
        lines.append("      query,")
        lines.append(f"      lastEventId: {resume},")
        lines.append("      options,")
        lines.append(f'      operation: "{operation.operation_id}",')
        lines.append("    });")
    else:
        lines.append(f'    return this._request("{operation.method}", path, {{')
        lines.append("      query,")
        if operation.has_body:
            lines.append("      body: options.body,")
        lines.append("      options,")
        lines.append(f"      binary: {'true' if operation.binary else 'false'},")
        lines.append(f'      operation: "{operation.operation_id}",')
        lines.append("    });")
    lines.append("  }")
    return lines


def render_javascript_client(
    document: Mapping[str, Any], operations: Sequence[Operation]
) -> str:
    """Emit ``sdk/js/crg-client.mjs`` (38.2)."""
    lines: List[str] = ["/**"]
    lines.append(
        " * A generated JavaScript client for the CRG headless integration surface."
    )
    lines.append(" *")
    for line in _header_block(document, "", len(operations)):
        lines.append((" * " + line).rstrip())
    lines.append(" *")
    lines.append(
        " * An ES module with zero npm dependencies, in the style of `verifier-js/`:"
    )
    lines.append(
        " * `fetch` and the platform's own `URLSearchParams` and `TextDecoder`, and"
    )
    lines.append(
        " * nothing else.  45.5 contemplates air-gapped deployments and 48.3"
    )
    lines.append(
        " * contemplates independent reimplementations; neither is served by a client"
    )
    lines.append(" * that first needs a package index.")
    lines.append(" */")
    lines.append(_JS_PREAMBLE.strip("\n"))
    for operation in operations:
        lines.append("")
        lines.extend(_js_method(operation))
    lines.append(_JS_EPILOGUE.strip("\n"))
    lines.append("")
    lines.append("/** Every operation this client was generated from, as data. */")
    lines.append("export const OPERATIONS = {")
    for operation in operations:
        lines.append(
            f'  {operation.operation_id}: {{ method: "{operation.method}", '
            f'path: "{operation.path}", spec: "{operation.spec}", '
            f"longRunning: {str(operation.long_running).lower()}, "
            f"streaming: {str(operation.streaming).lower()}, "
            f"idempotent: {str(operation.idempotent).lower()} }},"
        )
    lines.append("};")
    return "\n".join(lines) + "\n"


def render_javascript_manifest(document: Mapping[str, Any], count: int) -> str:
    """Emit ``sdk/js/package.json``: a module declaration and no dependencies."""
    info = document.get("info") or {}
    manifest = {
        "name": "@semiaifoundry/crg-client",
        "version": str(info.get("version") or "0.0.0"),
        "description": (
            "Generated CRG Systems client (spec 38.2). "
            f"{count} operations. {_DO_NOT_EDIT} Regenerate with python3 -m {GENERATOR}."
        ),
        "type": "module",
        "private": True,
        "main": "./crg-client.mjs",
        "exports": {".": "./crg-client.mjs"},
        "engines": {"node": ">=18"},
        "dependencies": {},
        "devDependencies": {},
        "license": "LicenseRef-CRG-Research-Noncommercial-1.0",
    }
    return json.dumps(manifest, indent=2, sort_keys=False) + "\n"


# ---------------------------------------------------------------------------
# generation
# ---------------------------------------------------------------------------
def generate_sdk(document: Optional[Mapping[str, Any]] = None) -> Dict[str, str]:
    """Every generated file, as ``relative path -> text``.

    Pure: given the same document it returns the same strings, which is what
    makes the byte-identity assertion in the test suite meaningful (47.1).
    """
    if document is None:
        from .openapi import openapi_document

        document = openapi_document()
    operations = load_operations(document)
    return {
        "sdk/python/crg_client.py": render_python_client(document, operations),
        "sdk/js/crg-client.mjs": render_javascript_client(document, operations),
        "sdk/js/package.json": render_javascript_manifest(document, len(operations)),
    }


def write_sdk(
    root: Any, document: Optional[Mapping[str, Any]] = None
) -> Dict[str, str]:
    """Write the generated tree under ``root``; returns the written paths."""
    base = Path(root)
    written: Dict[str, str] = {}
    for relative, text in sorted(generate_sdk(document).items()):
        target = base / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text, encoding="utf-8")
        written[relative] = str(target)
    return written


def main(argv: Optional[Sequence[str]] = None) -> int:
    """``python3 -m crg_server.sdkgen [root]``."""
    arguments = list(argv if argv is not None else [])
    root = arguments[0] if arguments else os.getcwd()
    written = write_sdk(root)
    for relative in sorted(written):
        print(written[relative])
    return 0


if __name__ == "__main__":  # pragma: no cover - a command, not a library path
    import sys

    raise SystemExit(main(sys.argv[1:]))
