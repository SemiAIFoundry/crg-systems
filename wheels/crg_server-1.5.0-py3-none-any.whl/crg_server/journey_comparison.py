"""REST/job boundary for non-authorizing change and journey comparisons."""
from __future__ import annotations

import copy
from typing import Any, Mapping

from crg_cli.journey_comparison import (
    JourneyComparisonVerificationError,
    build_verified_comparative_change,
    build_verified_cumulative_comparison,
    inspect_comparative_change,
    inspect_cumulative_comparison,
    persist_comparative_change,
    persist_cumulative_comparison,
    render_comparative_change_report,
    render_cumulative_comparison_report,
    resolve_qualification_operational_sources,
    verify_comparative_change,
    verify_cumulative_comparison,
)

from .errors import BlockedOutcome, NotFoundError, UsageError
from .jobs import JobContext, JobResult

__all__ = [
    "op_preview_comparative_change",
    "op_generate_comparative_change",
    "op_preview_cumulative_comparison",
    "op_generate_cumulative_comparison",
    "inspect_change",
    "inspect_cumulative",
    "verify_change_request",
    "verify_cumulative_request",
    "resolve_qualification_operational_sources",
]


def _blocked(error: JourneyComparisonVerificationError) -> BlockedOutcome:
    return BlockedOutcome(
        "independent comparison replay disagreed with the stored or produced evidence",
        outcome="BLOCKED_VERIFIER_DISAGREEMENT",
        detail={"message": str(error)},
        remedy=(
            "publish nothing; recover the exact stored artifacts and their verifier "
            "inputs, then rerun the independent verification boundary"
        ),
    )


def _run_change(context: JobContext, *, persist: bool) -> JobResult:
    case = copy.deepcopy(context.inputs["case"])
    request = context.inputs.get("request") or {}
    try:
        record, verification = build_verified_comparative_change(
            request,
            case,
            operational_measurement_sources=context.inputs.get(
                "operational_measurement_sources"
            ),
        )
        if persist:
            persist_comparative_change(case, record)
    except JourneyComparisonVerificationError as error:
        raise _blocked(error) from error
    comparison_id = record["comparison_id"]
    report = render_comparative_change_report(record, verification)
    context.log(
        f"comparative change {comparison_id} independently replayed; "
        f"authority=NON_AUTHORIZING semantic_effect=NONE persist={persist}"
    )
    outputs = {
        "preview": not persist,
        "comparison_id": comparison_id,
        "record_hash": record["record_hash"],
        "authority": "NON_AUTHORIZING",
        "authorizing": False,
        "semantic_effect": "NONE",
        "decision_state_mutation_performed": False,
        "successor_case_recorded": persist,
        "comparative_change": record,
        "verification": verification.to_json(),
        "report": report,
    }
    proof = {
        "proof_type": "COMPARATIVE_CHANGE_INDEPENDENT_RECONSTRUCTION",
        "profile": record["profile"],
        "record_hash": record["record_hash"],
        "verifier": "crg-verify",
        "status": verification.status,
        "authority": "NON_AUTHORIZING",
        "authorizing": False,
        "semantic_effect": "NONE",
        "decision_state_mutation_performed": False,
        "successor_case_recorded": persist,
    }
    if not persist:
        return JobResult(outputs=outputs, proof_artifacts=[proof])
    return JobResult(
        outputs=outputs,
        objects=[(f"comparative-change:{comparison_id}", record)],
        case=case,
        proof_artifacts=[proof],
    )


def op_preview_comparative_change(context: JobContext) -> JobResult:
    return _run_change(context, persist=False)


def op_generate_comparative_change(context: JobContext) -> JobResult:
    return _run_change(context, persist=True)


def _run_cumulative(context: JobContext, *, persist: bool) -> JobResult:
    case = copy.deepcopy(context.inputs["case"])
    request = context.inputs.get("request") or {}
    try:
        record, verification = build_verified_cumulative_comparison(request, case)
        if persist:
            persist_cumulative_comparison(case, record)
    except JourneyComparisonVerificationError as error:
        raise _blocked(error) from error
    journey_id = record["journey_id"]
    report = render_cumulative_comparison_report(record, verification)
    context.log(
        f"cumulative lifecycle comparison {journey_id} independently replayed; "
        f"authority=NON_AUTHORIZING semantic_effect=NONE persist={persist}"
    )
    outputs = {
        "preview": not persist,
        "journey_id": journey_id,
        "record_hash": record["record_hash"],
        "authority": "NON_AUTHORIZING",
        "authorizing": False,
        "semantic_effect": "NONE",
        "decision_state_mutation_performed": False,
        "successor_case_recorded": persist,
        "cumulative_comparison": record,
        "verification": verification.to_json(),
        "report": report,
    }
    proof = {
        "proof_type": "CUMULATIVE_LIFECYCLE_COMPARISON_INDEPENDENT_RECONSTRUCTION",
        "profile": record["profile"],
        "record_hash": record["record_hash"],
        "verifier": "crg-verify",
        "status": verification.status,
        "nested_artifacts_replayed": len(
            (verification.report or {}).get("nested_results") or []
        ),
        "authority": "NON_AUTHORIZING",
        "authorizing": False,
        "semantic_effect": "NONE",
        "decision_state_mutation_performed": False,
        "successor_case_recorded": persist,
    }
    if not persist:
        return JobResult(outputs=outputs, proof_artifacts=[proof])
    return JobResult(
        outputs=outputs,
        objects=[(f"cumulative-lifecycle-comparison:{journey_id}", record)],
        case=case,
        proof_artifacts=[proof],
    )


def op_preview_cumulative_comparison(context: JobContext) -> JobResult:
    return _run_cumulative(context, persist=False)


def op_generate_cumulative_comparison(context: JobContext) -> JobResult:
    return _run_cumulative(context, persist=True)


def _closed_record_request(request: Any, record_type: str) -> Mapping[str, Any]:
    if not isinstance(request, Mapping) or set(request) != {"record"}:
        raise UsageError(
            f"{record_type} verification requires exactly {{'record': <{record_type}>}}",
            remedy="pass the canonical portable record without authoring or derived fields",
        )
    record = request.get("record")
    if not isinstance(record, Mapping):
        raise UsageError(f"{record_type} verification record must be a JSON object")
    return record


def _verified_change_payload(record: Mapping[str, Any]) -> dict:
    try:
        verification = verify_comparative_change(record)
    except JourneyComparisonVerificationError as error:
        raise _blocked(error) from error
    document = copy.deepcopy(dict(record))
    return {
        "comparative_change": document,
        "verification": verification.to_json(),
        "report": render_comparative_change_report(document, verification),
        "authority": "NON_AUTHORIZING",
        "authorizing": False,
        "semantic_effect": "NONE",
        "decision_state_mutation_performed": False,
        "successor_case_recorded": False,
    }


def _verified_cumulative_payload(record: Mapping[str, Any]) -> dict:
    try:
        verification = verify_cumulative_comparison(record)
    except JourneyComparisonVerificationError as error:
        raise _blocked(error) from error
    document = copy.deepcopy(dict(record))
    return {
        "cumulative_comparison": document,
        "verification": verification.to_json(),
        "report": render_cumulative_comparison_report(document, verification),
        "authority": "NON_AUTHORIZING",
        "authorizing": False,
        "semantic_effect": "NONE",
        "decision_state_mutation_performed": False,
        "successor_case_recorded": False,
    }


def inspect_change(case: Mapping[str, Any], comparison_id: str) -> dict:
    records = case.get("comparative_change_evidence") or {}
    if not isinstance(records, Mapping) or comparison_id not in records:
        raise NotFoundError(
            f"comparative change {comparison_id!r} does not exist in this case",
            remedy="generate the comparison first or use a stored comparison identity",
        )
    try:
        return inspect_comparative_change(case, comparison_id)
    except JourneyComparisonVerificationError as error:
        raise _blocked(error) from error


def inspect_cumulative(case: Mapping[str, Any], journey_id: str) -> dict:
    records = case.get("cumulative_lifecycle_comparisons") or {}
    if not isinstance(records, Mapping) or journey_id not in records:
        raise NotFoundError(
            f"cumulative lifecycle comparison {journey_id!r} does not exist in this case",
            remedy="generate the comparison first or use a stored journey identity",
        )
    try:
        return inspect_cumulative_comparison(case, journey_id)
    except JourneyComparisonVerificationError as error:
        raise _blocked(error) from error


def verify_change_request(request: Any) -> dict:
    return _verified_change_payload(
        _closed_record_request(request, "ComparativeChangeEvidence")
    )


def verify_cumulative_request(request: Any) -> dict:
    return _verified_cumulative_payload(
        _closed_record_request(request, "CumulativeLifecycleComparison")
    )
