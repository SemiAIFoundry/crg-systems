"""A6 bounded multi-agent coordination over established CRG primitives.

This module does not introduce another event log, branch model, permission
system, or merge engine.  It composes ``AgentEventLedger``, ``CaseStore``
optimistic versions, the existing role/permission vocabulary, and explicit
reconciliation records.  Proposals never mutate a case directly.
"""
from __future__ import annotations

import copy
import importlib
from dataclasses import dataclass, replace
from typing import Any, Dict, Mapping, Sequence, Tuple

from crg_model.canonical import content_hash
from .errors import ConflictError, ForbiddenError, UsageError
from .events import AgentEventLedger, validate_agent_event_record

__all__ = [
    "AgentOperationBudget",
    "AgentOperationGrant",
    "MultiAgentCoordinator",
    "build_agent_proposal",
    "validate_agent_proposal",
    "validate_agent_grant",
]

_HASH_PREFIX = "sha256:"


def _text(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value:
        raise UsageError(f"{label} must be a non-empty string")
    return value


def _integer(value: Any, label: str, *, minimum: int = 0) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise UsageError(f"{label} must be an integer >= {minimum}")
    return value


def _hash(value: Any, label: str) -> str:
    text = _text(value, label)
    if not text.startswith(_HASH_PREFIX) or len(text) != 71:
        raise UsageError(f"{label} must be an algorithm-tagged SHA-256 identity")
    return text


@dataclass(frozen=True)
class AgentOperationBudget:
    max_proposals: int
    max_cost_units: int
    max_elapsed_ticks: int

    def __post_init__(self) -> None:
        for name in ("max_proposals", "max_cost_units", "max_elapsed_ticks"):
            _integer(getattr(self, name), name, minimum=1)

    def to_canonical(self) -> Dict[str, int]:
        return {
            "max_proposals": self.max_proposals,
            "max_cost_units": self.max_cost_units,
            "max_elapsed_ticks": self.max_elapsed_ticks,
        }


@dataclass(frozen=True)
class AgentOperationGrant:
    grant_id: str
    agent_id: str
    organization: str
    tenant_id: str
    roles: Tuple[str, ...]
    case_ids: Tuple[str, ...]
    branch_ids: Tuple[str, ...]
    permitted_actions: Tuple[str, ...]
    budget: AgentOperationBudget
    revoked: bool = False

    def __post_init__(self) -> None:
        # crg-security is an established optional server profile. Import it
        # only when a deployment actually constructs a governed agent grant,
        # preserving the server's existing dependency boundary.
        try:
            security = importlib.import_module("crg_security")
            PERMISSIONS = security.PERMISSIONS
            permissions_for = security.permissions_for
        except ImportError as error:
            raise UsageError(
                "bounded agent grants require the installed crg-security profile"
            ) from error
        for name in ("grant_id", "agent_id", "organization", "tenant_id"):
            _text(getattr(self, name), name)
        roles = tuple(sorted(set(map(str, self.roles))))
        actions = tuple(sorted(set(map(str, self.permitted_actions))))
        if not roles or not self.case_ids or not self.branch_ids or not actions:
            raise UsageError("agent grant scope, roles, and permitted actions must be non-empty")
        unknown = sorted(set(actions) - set(PERMISSIONS))
        if unknown:
            raise UsageError(f"agent grant names unknown permissions {unknown}")
        role_permissions = permissions_for(roles)
        if not set(actions).issubset(role_permissions):
            raise ForbiddenError(
                "agent grant exceeds its existing CRG roles",
                detail={"requested": list(actions), "role_permissions": sorted(role_permissions)},
            )
        object.__setattr__(self, "roles", roles)
        object.__setattr__(self, "case_ids", tuple(sorted(set(map(str, self.case_ids)))))
        object.__setattr__(self, "branch_ids", tuple(sorted(set(map(str, self.branch_ids)))))
        object.__setattr__(self, "permitted_actions", actions)

    def to_canonical(self) -> Dict[str, Any]:
        record = {
            "record_type": "AgentOperationGrant",
            "schema_version": "1.0.0",
            "grant_id": self.grant_id,
            "agent_id": self.agent_id,
            "organization": self.organization,
            "tenant_id": self.tenant_id,
            "roles": list(self.roles),
            "case_ids": list(self.case_ids),
            "branch_ids": list(self.branch_ids),
            "permitted_actions": list(self.permitted_actions),
            "budget": self.budget.to_canonical(),
            "revoked": self.revoked,
            "authority": "DEPLOYMENT_SCOPED_AGENT_GRANT",
            "execution_authorized": False,
        }
        record["grant_hash"] = content_hash(record)
        return record


_GRANT_FIELDS = {
    "record_type", "schema_version", "grant_id", "agent_id", "organization",
    "tenant_id", "roles", "case_ids", "branch_ids", "permitted_actions",
    "budget", "revoked", "authority", "execution_authorized", "grant_hash",
}


def validate_agent_grant(value: Any) -> AgentOperationGrant:
    """Decode a portable grant without accepting caller-selected authority."""

    if not isinstance(value, Mapping) or set(value) != _GRANT_FIELDS:
        raise UsageError("agent grant fields differ")
    record = dict(value)
    if record["record_type"] != "AgentOperationGrant" or record["schema_version"] != "1.0.0":
        raise UsageError("agent grant type/version differs")
    if record["authority"] != "DEPLOYMENT_SCOPED_AGENT_GRANT" or record["execution_authorized"] is not False:
        raise UsageError("agent grant authority differs")
    budget = record["budget"]
    if not isinstance(budget, Mapping) or set(budget) != {
        "max_proposals", "max_cost_units", "max_elapsed_ticks",
    }:
        raise UsageError("agent grant budget fields differ")
    grant = AgentOperationGrant(
        grant_id=record["grant_id"], agent_id=record["agent_id"],
        organization=record["organization"], tenant_id=record["tenant_id"],
        roles=tuple(record["roles"]), case_ids=tuple(record["case_ids"]),
        branch_ids=tuple(record["branch_ids"]),
        permitted_actions=tuple(record["permitted_actions"]),
        budget=AgentOperationBudget(
            budget["max_proposals"], budget["max_cost_units"], budget["max_elapsed_ticks"]
        ),
        revoked=record["revoked"],
    )
    if grant.to_canonical() != record:
        raise UsageError("agent grant canonical identity differs")
    return grant


_PROPOSAL_FIELDS = {
    "record_type", "schema_version", "proposal_id", "grant_hash", "agent_id",
    "organization", "tenant_id", "case_id", "branch_id", "action",
    "expected_parent_version", "causal_parent_ids", "event_hash", "payload_hash",
    "cost_units", "elapsed_ticks", "authority", "execution_authorized",
    "proposal_hash",
}


def validate_agent_proposal(value: Any) -> Dict[str, Any]:
    if not isinstance(value, Mapping) or set(value) != _PROPOSAL_FIELDS:
        raise UsageError("agent proposal fields differ")
    record = copy.deepcopy(dict(value))
    if record["record_type"] != "AgentProposalRecord" or record["schema_version"] != "1.0.0":
        raise UsageError("agent proposal type/version differs")
    for field in ("proposal_id", "agent_id", "organization", "tenant_id", "case_id", "branch_id", "action"):
        _text(record[field], field)
    for field in ("grant_hash", "event_hash", "payload_hash", "proposal_hash"):
        _hash(record[field], field)
    _integer(record["expected_parent_version"], "expected_parent_version", minimum=1)
    _integer(record["cost_units"], "cost_units", minimum=0)
    _integer(record["elapsed_ticks"], "elapsed_ticks", minimum=0)
    parents = record["causal_parent_ids"]
    if not isinstance(parents, list) or parents != sorted(set(parents)):
        raise UsageError("proposal causal parents must be sorted and unique")
    if record["authority"] != "PROPOSAL_ONLY" or record["execution_authorized"] is not False:
        raise UsageError("agent proposal exceeds its non-authorizing boundary")
    expected = content_hash({key: item for key, item in record.items() if key != "proposal_hash"})
    if record["proposal_hash"] != expected:
        raise UsageError("agent proposal hash differs")
    return record


def build_agent_proposal(
    *,
    proposal_id: str,
    grant: AgentOperationGrant,
    case_id: str,
    branch_id: str,
    action: str,
    expected_parent_version: int,
    causal_parent_ids: Sequence[str],
    event_hash: str,
    payload_hash: str,
    cost_units: int,
    elapsed_ticks: int,
) -> Dict[str, Any]:
    grant_record = grant.to_canonical()
    record = {
        "record_type": "AgentProposalRecord",
        "schema_version": "1.0.0",
        "proposal_id": _text(proposal_id, "proposal_id"),
        "grant_hash": grant_record["grant_hash"],
        "agent_id": grant.agent_id,
        "organization": grant.organization,
        "tenant_id": grant.tenant_id,
        "case_id": _text(case_id, "case_id"),
        "branch_id": _text(branch_id, "branch_id"),
        "action": _text(action, "action"),
        "expected_parent_version": _integer(expected_parent_version, "expected_parent_version", minimum=1),
        "causal_parent_ids": sorted(set(map(str, causal_parent_ids))),
        "event_hash": _hash(event_hash, "event_hash"),
        "payload_hash": _hash(payload_hash, "payload_hash"),
        "cost_units": _integer(cost_units, "cost_units"),
        "elapsed_ticks": _integer(elapsed_ticks, "elapsed_ticks"),
        "authority": "PROPOSAL_ONLY",
        "execution_authorized": False,
    }
    record["proposal_hash"] = content_hash(record)
    return validate_agent_proposal(record)


class MultiAgentCoordinator:
    """Evaluate bounded proposals; never apply them or pick a conflict winner."""

    def __init__(self, store: Any, *, ledger: AgentEventLedger | None = None) -> None:
        self.store = store
        self.ledger = ledger or AgentEventLedger(store=store, stream_id="multi-agent")
        self._grants: Dict[str, AgentOperationGrant] = {}
        self._usage: Dict[str, Dict[str, int]] = {}
        self._proposals: Dict[str, Dict[str, Any]] = {}
        self._conflicts: Dict[str, Dict[str, Any]] = {}

    def register_grant(self, grant: AgentOperationGrant) -> Dict[str, Any]:
        if grant.agent_id in self._grants:
            raise ConflictError(f"agent {grant.agent_id!r} already has a grant")
        self._grants[grant.agent_id] = grant
        self._usage[grant.agent_id] = {"proposals": 0, "cost_units": 0, "elapsed_ticks": 0}
        record = grant.to_canonical()
        self.store.put_object(record, object_type="AgentOperationGrant", created_by="deployment")
        return record

    def revoke_grant(self, agent_id: str) -> Dict[str, Any]:
        """Revoke future proposal admission without rewriting prior evidence."""

        grant = self._grants.get(agent_id)
        if grant is None:
            raise UsageError(f"unknown agent {agent_id!r}")
        revoked = replace(grant, revoked=True)
        self._grants[agent_id] = revoked
        record = revoked.to_canonical()
        self.store.put_object(record, object_type="AgentOperationGrant", created_by="deployment")
        return record

    def submit(self, proposal: Mapping[str, Any], event: Mapping[str, Any]) -> Dict[str, Any]:
        record = validate_agent_proposal(proposal)
        carrier = validate_agent_event_record(event)
        grant = self._grants.get(record["agent_id"])
        if grant is None or grant.revoked:
            raise ForbiddenError("agent grant is absent or revoked")
        if record["grant_hash"] != grant.to_canonical()["grant_hash"]:
            raise ForbiddenError("proposal names a different agent grant")
        if record["organization"] != grant.organization or record["tenant_id"] != grant.tenant_id:
            raise ForbiddenError("proposal organization or tenant differs from deployment grant")
        if record["case_id"] not in grant.case_ids or record["branch_id"] not in grant.branch_ids:
            raise ForbiddenError("proposal is outside its case or branch scope")
        if record["action"] not in grant.permitted_actions:
            raise ForbiddenError("proposal action is outside its permission grant")
        if carrier["actor"]["actor_id"] != grant.agent_id or carrier["actor"]["actor_kind"] != "AGENT":
            raise ForbiddenError("agent event actor does not own the proposal")
        if carrier["proposal_id"] != record["proposal_id"] or carrier["event_hash"] != record["event_hash"]:
            raise UsageError("proposal and AgentEvent identities differ")
        if carrier["case_id"] != record["case_id"] or carrier["branch_id"] != record["branch_id"]:
            raise UsageError("proposal and AgentEvent scopes differ")
        if carrier["payload_hash"] != record["payload_hash"]:
            raise UsageError("proposal and AgentEvent payload hashes differ")
        if carrier["causal_parent_ids"] != record["causal_parent_ids"]:
            raise UsageError("proposal and AgentEvent causal parents differ")
        head = self.store.head_version(record["case_id"])
        if head != record["expected_parent_version"]:
            return self._result("STALE_PARENT", record, current_parent_version=head)
        usage = self._usage[grant.agent_id]
        next_usage = {
            "proposals": usage["proposals"] + 1,
            "cost_units": usage["cost_units"] + record["cost_units"],
            "elapsed_ticks": usage["elapsed_ticks"] + record["elapsed_ticks"],
        }
        if (
            next_usage["proposals"] > grant.budget.max_proposals
            or next_usage["cost_units"] > grant.budget.max_cost_units
            or next_usage["elapsed_ticks"] > grant.budget.max_elapsed_ticks
        ):
            return self._result("BUDGET_EXHAUSTED", record, usage=next_usage)
        event_result = self.ledger.ingest(carrier)
        if not event_result["accepted"]:
            return self._result(event_result["status"], record, event_result=event_result)
        usage.update(next_usage)
        self._proposals[record["proposal_id"]] = record
        self.store.put_object(record, object_type="AgentProposalRecord", created_by=grant.agent_id)

        concurrent = [
            other for other in self._proposals.values()
            if other["proposal_id"] != record["proposal_id"]
            and other["case_id"] == record["case_id"]
            and other["branch_id"] == record["branch_id"]
            and other["expected_parent_version"] == record["expected_parent_version"]
            and other["payload_hash"] != record["payload_hash"]
        ]
        if concurrent:
            ids = sorted([record["proposal_id"], *(item["proposal_id"] for item in concurrent)])
            conflict = {
                "record_type": "AgentConflictRecord",
                "schema_version": "1.0.0",
                "conflict_id": "conflict-" + content_hash(ids).removeprefix("sha256:"),
                "case_id": record["case_id"],
                "branch_id": record["branch_id"],
                "expected_parent_version": record["expected_parent_version"],
                "proposal_ids": ids,
                "resolution_status": "RECONCILIATION_REQUIRED",
                "arrival_order_authoritative": False,
                "last_writer_wins": False,
                "authority": "CONFLICT_EVIDENCE_ONLY",
                "execution_authorized": False,
            }
            conflict["conflict_hash"] = content_hash(conflict)
            self._conflicts[conflict["conflict_id"]] = conflict
            self.store.put_object(conflict, object_type="AgentConflictRecord", created_by="multi-agent")
            return self._result("CONFLICT_RECORDED", record, conflict=conflict, usage=next_usage)
        return self._result("ACCEPTED_FOR_REVIEW", record, usage=next_usage)

    def reconcile(
        self,
        conflict_id: str,
        *,
        selected_proposal_id: str | None,
        resolved_by: str,
        resolution_authority: str,
        rationale: str,
    ) -> Dict[str, Any]:
        conflict = self._conflicts.get(conflict_id)
        if conflict is None:
            raise UsageError(f"unknown conflict {conflict_id!r}")
        if resolution_authority not in {"HUMAN", "ADMITTED_POLICY"}:
            raise ForbiddenError("conflict resolution requires a human or admitted policy")
        if selected_proposal_id is not None and selected_proposal_id not in conflict["proposal_ids"]:
            raise UsageError("reconciliation selected a proposal outside the conflict")
        record = {
            "record_type": "AgentReconciliationRecord",
            "schema_version": "1.0.0",
            "reconciliation_id": "reconciliation-" + conflict_id.removeprefix("conflict-"),
            "conflict_hash": conflict["conflict_hash"],
            "proposal_ids": list(conflict["proposal_ids"]),
            "selected_proposal_id": selected_proposal_id,
            "resolved_by": _text(resolved_by, "resolved_by"),
            "resolution_authority": resolution_authority,
            "rationale": _text(rationale, "rationale"),
            "arrival_order_authoritative": False,
            "last_writer_wins": False,
            "mutation_applied": False,
            "authority": "RECONCILIATION_DECISION_ONLY",
            "execution_authorized": False,
        }
        record["reconciliation_hash"] = content_hash(record)
        self.store.put_object(record, object_type="AgentReconciliationRecord", created_by=resolved_by)
        return record

    @staticmethod
    def _result(status: str, proposal: Mapping[str, Any], **detail: Any) -> Dict[str, Any]:
        return {
            "status": status,
            "proposal_id": proposal["proposal_id"],
            "proposal_hash": proposal["proposal_hash"],
            "accepted": status in {"ACCEPTED_FOR_REVIEW", "CONFLICT_RECORDED"},
            "mutation_applied": False,
            "authority": "COORDINATION_RESULT_ONLY",
            "execution_authorized": False,
            **detail,
        }
