"""Public API boundary for preview-first bring-your-own-registry intake.

The kernel producer lives in :mod:`crg_io.intake`.  This adapter accepts only
inline UTF-8 content (or its exact base64 bytes), creates no preview state,
and requires confirmation to replay the producer against the same mapping and
source before a successor case is written.
"""
from __future__ import annotations

import base64
import binascii
import os
import tempfile
from typing import Any, Dict, Mapping, Tuple

import crg_io
from crg_cli.intake import (
    mapping_profile_from_document,
    persist_registry_intake,
    registry_intake_preview_payload,
    source_provenance_from_document,
)
from crg_model.lifecycle import (
    PREPARATION_STATES,
    CaseState,
    case_state,
    is_legal_transition,
    set_case_state,
)

from .errors import PayloadTooLargeError, UsageError
from .jobs import JobContext, JobResult
from .store import record_history


__all__ = ["MAX_INLINE_INTAKE_BYTES", "preview_request", "op_confirm"]


# The default durable job profile caps its complete replay payload at 8 MiB.
# Keep the source below half of that budget so base64 expansion, the mapping,
# provenance, and a normal case record still fit the confirmation job. Larger
# sources use the local CLI or a separately reviewed deployment boundary.
MAX_INLINE_INTAKE_BYTES = 4 * 1024 * 1024
_COMMON_FIELDS = {"mapping_profile", "provenance", "source_text", "source_base64"}
_CONFIRM_FIELDS = _COMMON_FIELDS | {"expected_preview_hash", "accept_partial"}


def _strict_request(request: Mapping[str, Any], *, confirm: bool) -> None:
    if not isinstance(request, Mapping):
        raise UsageError("registry intake request MUST be a JSON object")
    allowed = _CONFIRM_FIELDS if confirm else _COMMON_FIELDS
    unknown = set(request) - allowed
    if unknown:
        raise UsageError(
            "registry intake request contains unsupported field(s): "
            + ", ".join(sorted(map(str, unknown))),
            remedy="use the exact request fields published by /openapi.json",
        )
    missing = {"mapping_profile", "provenance"} - set(request)
    if missing:
        raise UsageError(
            "registry intake request is missing required field(s): "
            + ", ".join(sorted(missing))
        )
    supplied = [name for name in ("source_text", "source_base64") if name in request]
    if len(supplied) != 1:
        raise UsageError(
            "registry intake requires exactly one of source_text or source_base64",
            remedy="supply UTF-8 source text directly, or base64 for byte-exact transport",
        )
    if confirm and "expected_preview_hash" not in request:
        raise UsageError(
            "registry intake confirmation requires expected_preview_hash",
            remedy="copy preview_hash from the non-mutating preview response",
        )


def _source_bytes(request: Mapping[str, Any]) -> bytes:
    if "source_text" in request:
        value = request["source_text"]
        if not isinstance(value, str):
            raise UsageError("source_text MUST be a UTF-8 text string")
        data = value.encode("utf-8")
    else:
        value = request["source_base64"]
        if not isinstance(value, str):
            raise UsageError("source_base64 MUST be a base64 string")
        if len(value) > ((MAX_INLINE_INTAKE_BYTES + 2) // 3) * 4 + 4:
            raise PayloadTooLargeError(
                "base64 registry source exceeds the inline intake limit",
                remedy=f"supply no more than {MAX_INLINE_INTAKE_BYTES} decoded bytes",
            )
        try:
            data = base64.b64decode(value, validate=True)
        except (binascii.Error, ValueError) as error:
            raise UsageError(f"source_base64 is not strict base64: {error}") from None
    if len(data) > MAX_INLINE_INTAKE_BYTES:
        raise PayloadTooLargeError(
            f"registry source is {len(data)} bytes; limit is {MAX_INLINE_INTAKE_BYTES}",
            remedy="split the registry or use a reviewed deployment with a larger explicit limit",
        )
    return data


def _decoded(request: Mapping[str, Any], *, confirm: bool) -> Tuple[Any, Any, bytes]:
    _strict_request(request, confirm=confirm)
    try:
        profile = mapping_profile_from_document(request["mapping_profile"])
        provenance = source_provenance_from_document(request["provenance"])
    except (crg_io.IntakeProfileError, TypeError, ValueError) as error:
        raise UsageError(str(error)) from None
    return profile, provenance, _source_bytes(request)


def _with_source(data: bytes, source_format: str, operation: Any) -> Any:
    suffix = ".csv" if source_format == crg_io.CSV_SOURCE else ".json"
    descriptor, path = tempfile.mkstemp(prefix="crg-registry-intake-", suffix=suffix)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        return operation(path)
    finally:
        if os.path.exists(path):
            os.unlink(path)


def preview_request(request: Mapping[str, Any]) -> Dict[str, Any]:
    """Compute a canonical preview without writing case or server state."""
    profile, provenance, data = _decoded(request, confirm=False)
    try:
        preview = _with_source(
            data,
            profile.source_format,
            lambda path: crg_io.preview_registry_intake(
                path, profile=profile, provenance=provenance
            ),
        )
    except (crg_io.IntakeProfileError, crg_io.IntakeSourceError, ValueError) as error:
        raise UsageError(str(error)) from None
    return registry_intake_preview_payload(preview)


def _advance_preparation(case: Dict[str, Any], target: str, reason: str) -> None:
    current = case_state(case)
    if current not in PREPARATION_STATES or not is_legal_transition(current, target):
        return
    set_case_state(case, target, reason=reason, actor="crg-server")


def op_confirm(context: JobContext) -> JobResult:
    """Re-preview, hash-check, materialize, and persist a successor case."""
    request = dict(context.inputs.get("request") or {})
    case = dict(context.inputs["case"])
    dependent_state = [
        name for name in (
            "geometry", "scope", "derivation", "certificates", "safe_commitments",
            "phase_analyses", "certified_deltas", "deltas",
        )
        if case.get(name)
    ]
    if dependent_state:
        raise UsageError(
            "registry intake confirmation cannot replace a family that already has "
            "decision-dependent state: " + ", ".join(dependent_state),
            remedy=(
                "use the governed change/reopen workflow for an established case, or confirm "
                "this intake into a fresh or preparation-only case"
            ),
        )
    profile, provenance, data = _decoded(request, confirm=True)
    accept_partial = request.get("accept_partial", False)
    if not isinstance(accept_partial, bool):
        raise UsageError("accept_partial MUST be a boolean")
    expected = request.get("expected_preview_hash")
    try:
        bundle, report, preview = _with_source(
            data,
            profile.source_format,
            lambda path: crg_io.materialize_registry_intake(
                path,
                profile=profile,
                provenance=provenance,
                expected_preview_hash=expected,
                accept_partial=accept_partial,
            ),
        )
    except (
        crg_io.IntakeProfileError,
        crg_io.IntakeSourceError,
        crg_io.IntakeMaterializationError,
        ValueError,
    ) as error:
        raise UsageError(str(error)) from None

    persisted = persist_registry_intake(
        case,
        bundle=bundle,
        report=report,
        preview=preview,
        accept_partial=accept_partial,
    )
    _advance_preparation(
        case,
        CaseState.VALIDATED,
        f"preview-bound registry intake validated {len(preview.accepted)} rows",
    )
    _advance_preparation(
        case,
        CaseState.IMPORTED_OR_GENERATED,
        f"registry intake confirmed from {provenance.source_name}",
    )
    record_history(
        case,
        "registry intake confirm",
        {
            "preview_hash": persisted["preview_hash"],
            "confirmation_hash": persisted["confirmation_hash"],
            "source_snapshot_hash": persisted["source_snapshot_hash"],
            "source_snapshot_record_hash": persisted["source_snapshot_record_hash"],
            "accepted": len(preview.accepted),
            "rejected": len(preview.rejected),
            "partial_import_acknowledged": accept_partial,
        },
    )
    context.log(
        f"confirmed preview {persisted['preview_hash']}; "
        f"accepted {len(preview.accepted)}, rejected {len(preview.rejected)}"
    )
    objects = [
        (bundle.bundle_id, bundle.to_canonical()),
        (f"intake-profile:{persisted['profile_hash']}", persisted["mapping_profile"]),
        (
            f"intake-source:{persisted['source_snapshot_record_hash']}",
            persisted["source_snapshot"],
        ),
        (f"intake-preview:{persisted['preview_hash']}", persisted["preview"]),
        (
            f"intake-confirmation:{persisted['confirmation_hash']}",
            persisted["confirmation"],
        ),
    ]
    return JobResult(
        outputs={
            "record_type": "RegistryIntakeConfirmationResponse",
            "schema_version": "1.0.0",
            "authority": "NON_AUTHORIZING_INTAKE",
            "mutation_performed": True,
            **persisted,
        },
        objects=objects,
        case=case,
        events=[{
            "event": "registry.imported",
            "detail": {
                "intake_mode": "PREVIEW_BOUND_CONFIRMATION",
                "preview_hash": persisted["preview_hash"],
                "confirmation_hash": persisted["confirmation_hash"],
                "accepted": len(preview.accepted),
                "rejected": len(preview.rejected),
                "partial_import_acknowledged": accept_partial,
            },
        }],
    )
