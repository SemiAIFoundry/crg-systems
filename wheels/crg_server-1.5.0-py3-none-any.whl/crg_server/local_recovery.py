"""Versioned local-profile recovery drill over a real :class:`CaseStore`.

The drill performs the public administrative path: scan and back up a
populated source, independently inspect the verified archive, restore it into
an absent or empty target, and independently inspect the restored store.  The
returned evidence is explicitly limited to that observed local logical
operation; it is not a provider DR, PITR, failover, availability, RPO, or RTO
claim.
"""
from __future__ import annotations

import base64
import json
import os
import tempfile
import zipfile
from pathlib import Path
from typing import Any, Dict, Mapping, Tuple

from crg_feedback.local_recovery import (
    LocalRecoveryTypedInventory,
    create_local_recovery_inventory,
    create_local_recovery_lifecycle_snapshot,
    record_local_admin_recovery,
)
from crg_verify.local_recovery import verify_local_admin_recovery_evidence

from .admin import _extract_verified, create_backup, restore_backup
from .bundleio import import_bundle_bytes
from .store import CaseStore

__all__ = [
    "extract_local_store_inventory",
    "inspect_local_backup_inventory",
    "seed_local_recovery_store_from_bundle",
    "execute_local_recovery_drill",
]


def _case_entries(store: CaseStore) -> list[Dict[str, Any]]:
    rows = store._connection.execute(
        "SELECT case_id, case_version, content_hash, branch_id, parent_version, "
        "status, created_at, derived_from FROM cases "
        "ORDER BY case_id ASC, case_version ASC"
    ).fetchall()
    entries = []
    for row in rows:
        digest = str(row["content_hash"])
        derived_from = row["derived_from"]
        entries.append({
            "case_id": str(row["case_id"]),
            "case_version": int(row["case_version"]),
            "content_hash": digest,
            "branch_id": str(row["branch_id"] or "main"),
            "parent_version": (
                int(row["parent_version"])
                if row["parent_version"] is not None else None
            ),
            "status": str(row["status"]),
            "created_at": str(row["created_at"]),
            "derived_from": (
                json.loads(str(derived_from)) if derived_from is not None else None
            ),
            "object_status": store.object_status(digest),
            "payload": store.get_object(digest),
        })
    return entries


def _dependency_entries(store: CaseStore) -> list[Dict[str, Any]]:
    rows = store._connection.execute(
        "SELECT edge_id, case_id, source, target, edge_type, scope, "
        "minimum_action, recorded_at FROM edges "
        "ORDER BY COALESCE(case_id, ''), edge_id"
    ).fetchall()
    return [{
        "edge_id": str(row["edge_id"]),
        "case_id": str(row["case_id"]) if row["case_id"] is not None else None,
        "source": str(row["source"]),
        "target": str(row["target"]),
        "edge_type": str(row["edge_type"]),
        "scope": str(row["scope"] or ""),
        "minimum_action": str(row["minimum_action"] or ""),
        "recorded_at": str(row["recorded_at"]),
    } for row in rows]


def _certificate_entries(store: CaseStore) -> Dict[str, list[Dict[str, Any]]]:
    rows = store._connection.execute(
        "SELECT case_id, certificate_id, content_hash, job_id, outcome, "
        "affirmative, registered_at FROM certificates "
        "ORDER BY case_id ASC, certificate_id ASC"
    ).fetchall()
    partitions: Dict[str, list[Dict[str, Any]]] = {
        "active": [], "superseded": [], "other": [],
    }
    for row in rows:
        digest = str(row["content_hash"])
        status = store.object_status(digest)
        partition = (
            "active" if status == "ACTIVE"
            else "superseded" if status == "SUPERSEDED"
            else "other"
        )
        partitions[partition].append({
            "case_id": str(row["case_id"]),
            "certificate_id": str(row["certificate_id"]),
            "content_hash": digest,
            "job_id": str(row["job_id"]),
            "outcome": str(row["outcome"] or ""),
            "affirmative": bool(row["affirmative"]),
            "registered_at": str(row["registered_at"]),
            "status": status,
            "payload": store.get_object(digest),
        })
    return partitions


def _object_entries(store: CaseStore) -> list[Dict[str, Any]]:
    rows = store._connection.execute(
        "SELECT content_hash, object_type, byte_length, present FROM objects "
        "ORDER BY content_hash ASC"
    ).fetchall()
    entries = []
    for row in rows:
        digest = str(row["content_hash"])
        present = bool(row["present"])
        entries.append({
            "object_id": digest,
            "object_type": str(row["object_type"]),
            "status": store.object_status(digest),
            "present": present,
            "byte_length": int(row["byte_length"]),
            "content_hash": digest,
            "payload": store.get_object(digest) if present else None,
            "tombstone": None if present else store.tombstone(digest).to_canonical(),
        })
    return entries


def _inventory_from_store(
    store: CaseStore, inventory_id: str, inventory_role: str
) -> LocalRecoveryTypedInventory:
    integrity = store.scan_integrity()
    if not integrity.get("ok"):
        raise ValueError(
            f"refusing recovery inventory extraction from an inconsistent store: {integrity}"
        )
    return create_local_recovery_inventory(
        inventory_id,
        inventory_role,
        cases=_case_entries(store),
        dependency_edges=_dependency_entries(store),
        audit_records=store.audit_records(),
        certificates=_certificate_entries(store),
        objects=_object_entries(store),
    )


def extract_local_store_inventory(
    root: str,
    inventory_id: str,
    inventory_role: str,
    *,
    object_codec: Any = None,
    require_encryption: bool = False,
) -> LocalRecoveryTypedInventory:
    """Independently open and inventory one durable local store."""
    store = CaseStore(
        root, object_codec=object_codec, require_encryption=require_encryption
    )
    try:
        return _inventory_from_store(store, inventory_id, inventory_role)
    finally:
        store.close()


def inspect_local_backup_inventory(
    archive: str,
    inventory_id: str,
    *,
    object_codec: Any = None,
    require_encryption: bool = False,
) -> Tuple[LocalRecoveryTypedInventory, Dict[str, Any]]:
    """Verify/extract an archive and inventory its SQLite/object bytes anew."""
    source = Path(archive).expanduser().resolve()
    if not source.is_file():
        raise ValueError(f"no backup archive at {str(source)!r}")
    with tempfile.TemporaryDirectory(prefix="crg-backup-inspect-") as temporary:
        root = _extract_verified(source, Path(temporary))
        manifest = json.loads(
            (root / "backup-manifest.json").read_text(encoding="utf-8")
        )
        inventory = extract_local_store_inventory(
            str(root), inventory_id, "BACKUP_ARCHIVE",
            object_codec=object_codec, require_encryption=require_encryption,
        )
    return inventory, manifest


class _ImportedCertificateJob:
    status = "SUCCEEDED"

    def __init__(self, job_id: str) -> None:
        self.job_id = job_id


def seed_local_recovery_store_from_bundle(
    root: str,
    bundle: str,
    *,
    object_codec: Any = None,
    require_encryption: bool = False,
) -> Dict[str, Any]:
    """Verify/import a public ``.crg`` bundle into a new recovery source.

    The import is staged beside the destination and renamed into place only
    after its cases, typed edges, certificate registrations, and audit facts
    have passed a full integrity scan.  This gives the flagship a public
    product path for populating the real ``CaseStore`` used by ``crg-admin``;
    callers with an existing populated store do not use this helper.
    """
    target = Path(root).expanduser().resolve()
    source = Path(bundle).expanduser().resolve()
    if not source.is_file():
        raise ValueError(f"no portable bundle at {str(source)!r}")
    if target.exists() and (not target.is_dir() or any(target.iterdir())):
        raise ValueError("bundle recovery source destination must be absent or empty")
    target.parent.mkdir(parents=True, exist_ok=True)
    data = source.read_bytes()
    with tempfile.TemporaryDirectory(
        prefix=".crg-recovery-source-", dir=str(target.parent)
    ) as temporary:
        staged = Path(temporary) / "store"
        store = CaseStore(
            str(staged), object_codec=object_codec,
            require_encryption=require_encryption,
        )
        try:
            imported = import_bundle_bytes(
                store,
                {"bundle_base64": base64.b64encode(data).decode("ascii")},
                created_by="crg-admin:verified-bundle-import",
            )
            case_id = str(imported["case_id"])
            case = store.get_case(case_id)
            replay_inputs = (
                (case.get("lifecycle_verification_inputs") or {}).get(
                    "LifecycleReplayRecord"
                ) or {}
            )
            replay_dependencies = 0
            for envelope in replay_inputs.values():
                carried = envelope.get("inputs") if isinstance(envelope, Mapping) else None
                if not isinstance(carried, Mapping):
                    continue
                payloads = [carried.get("source_checkpoint")]
                payloads.extend(carried.get("records") or ())
                payloads.extend(carried.get("verification_inputs") or ())
                for payload in payloads:
                    if payload is None:
                        continue
                    store.put_object(
                        payload,
                        object_type="LifecycleReplayDependency",
                        created_by="crg-admin:verified-bundle-import",
                    )
                    replay_dependencies += 1
            active = dict(case.get("certificates") or {})
            superseded = dict(case.get("superseded_certificates") or {})
            for status, values in (("ACTIVE", active), ("SUPERSEDED", superseded)):
                for certificate_id, certificate in sorted(values.items()):
                    digest = store.register_certificate(
                        case_id,
                        certificate,
                        job=_ImportedCertificateJob(
                            f"verified-bundle-import:{certificate_id}"
                        ),
                    )
                    if status == "SUPERSEDED":
                        store.set_object_status(
                            digest,
                            "SUPERSEDED",
                            reason="portable bundle carries certificate as superseded provenance",
                        )

            edges = []
            with zipfile.ZipFile(source) as archive:
                manifest = json.loads(archive.read("manifest.json").decode("utf-8"))
                for entry in manifest.get("object_inventory") or ():
                    if not str(entry.get("object_id") or "").startswith(
                        "dependency-edge:"
                    ):
                        continue
                    path = str(entry.get("path") or "")
                    if path:
                        edges.append(json.loads(archive.read(path).decode("utf-8")))
            if edges:
                store.record_edges(edges, case_id=case_id)
            store.append_audit({
                "event": "recovery_source.bundle_imported",
                "case_id": case_id,
                "bundle_manifest_hash": imported["manifest_hash"],
                "source_profile": "PUBLIC_PORTABLE_CRG_BUNDLE",
            })
            store.append_audit({
                "event": "recovery_source.inventory_registered",
                "case_id": case_id,
                "active_certificate_count": len(active),
                "superseded_certificate_count": len(superseded),
                "dependency_edge_count": len(edges),
                "replay_dependency_count": replay_dependencies,
            })
            integrity = store.scan_integrity()
            if not integrity.get("ok"):
                raise ValueError(
                    f"verified bundle recovery source failed store integrity: {integrity}"
                )
        finally:
            store.close()
        if target.exists():
            target.rmdir()
        os.replace(staged, target)
    return {
        **imported,
        "active_certificates_registered": len(active),
        "superseded_certificates_registered": len(superseded),
        "dependency_edges_registered": len(edges),
        "replay_dependencies_materialized": replay_dependencies,
        "integrity_scan": integrity,
    }


def execute_local_recovery_drill(
    root: str,
    archive: str,
    destination: str,
    *,
    recovery_id: str,
    authority: str,
    source_bundle: str | None = None,
    object_codec: Any = None,
    require_encryption: bool = False,
) -> Dict[str, Any]:
    """Run and independently verify one actual local backup/restore drill."""
    source_root = Path(root).expanduser().resolve()
    archive_target = Path(archive).expanduser().resolve()
    target = Path(destination).expanduser().resolve()
    if len({source_root, archive_target, target}) != 3:
        raise ValueError("recovery source, archive, and restore destination must be distinct")
    if source_root in archive_target.parents or source_root in target.parents:
        raise ValueError(
            "backup archive and restore destination must be outside the source store"
        )
    if archive_target.exists():
        raise ValueError(f"backup output {str(archive_target)!r} already exists")
    destination_was_empty = (
        not target.exists()
        or (target.is_dir() and not any(target.iterdir()))
    )
    if not destination_was_empty:
        raise ValueError("restore destination must be absent or genuinely empty")
    source_import = None
    if source_bundle is not None:
        source_import = seed_local_recovery_store_from_bundle(
            root,
            source_bundle,
            object_codec=object_codec,
            require_encryption=require_encryption,
        )

    source_inventory = extract_local_store_inventory(
        root, f"{recovery_id}:source", "SOURCE",
        object_codec=object_codec, require_encryption=require_encryption,
    )
    backup_report = create_backup(
        root, archive, object_codec=object_codec,
        require_encryption=require_encryption,
    )
    backup_inventory, backup_manifest = inspect_local_backup_inventory(
        archive, f"{recovery_id}:archive",
        object_codec=object_codec, require_encryption=require_encryption,
    )
    restore_report = restore_backup(
        archive, destination, object_codec=object_codec,
        require_encryption=require_encryption,
    )
    restored_inventory = extract_local_store_inventory(
        destination, f"{recovery_id}:restored", "RESTORED_EMPTY_TARGET",
        object_codec=object_codec, require_encryption=require_encryption,
    )
    evidence = record_local_admin_recovery(
        recovery_id,
        source_inventory,
        backup_inventory,
        restored_inventory,
        archive_sha256=str(backup_report["archive_sha256"]),
        backup_manifest=backup_manifest,
        destination_was_empty=destination_was_empty,
        authority=authority,
    )
    evidence_document = evidence.to_canonical()
    archive_bytes = Path(archive).expanduser().resolve().read_bytes()
    verification = verify_local_admin_recovery_evidence(
        evidence_document,
        source_inventory.to_canonical(),
        backup_inventory.to_canonical(),
        restored_inventory.to_canonical(),
        backup_manifest,
        archive_bytes,
    )
    if not verification.ok:
        raise ValueError(
            "independent local recovery verification failed: "
            + "; ".join(verification.violations)
        )

    source_snapshot = create_local_recovery_lifecycle_snapshot(
        f"{recovery_id}:source", source_inventory
    )
    backup_snapshot = create_local_recovery_lifecycle_snapshot(
        f"{recovery_id}:archive", backup_inventory
    )
    restored_snapshot = create_local_recovery_lifecycle_snapshot(
        f"{recovery_id}:restored", restored_inventory
    )
    if len({
        source_snapshot.inventory_root,
        backup_snapshot.inventory_root,
        restored_snapshot.inventory_root,
    }) != 1:
        raise ValueError(
            "local recovery lifecycle projections differ after typed-root equality"
        )
    result = {
        "ok": True,
        "record_type": "LocalAdminRecoveryDrillResult",
        "profile": "crg.local-admin-recovery-drill@1",
        "recovery_evidence": evidence_document,
        "source_inventory": source_inventory.to_canonical(),
        "backup_inventory": backup_inventory.to_canonical(),
        "restored_inventory": restored_inventory.to_canonical(),
        "source_snapshot": source_snapshot.to_canonical(),
        "backup_snapshot": backup_snapshot.to_canonical(),
        "restored_snapshot": restored_snapshot.to_canonical(),
        "backup_manifest": backup_manifest,
        "backup_operation": backup_report,
        "restore_operation": restore_report,
        "verification": verification.to_json(),
    }
    if source_import is not None:
        result["source_import"] = source_import
    return result
