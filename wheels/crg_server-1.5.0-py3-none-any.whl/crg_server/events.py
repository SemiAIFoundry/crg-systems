"""The declared event vocabulary, its carrier, and a webhook-shaped payload.

Normative basis: 38.5 (events), 38.2 (webhooks and event streaming), 44.7
(every authorization-sensitive operation produces an immutable audit event).

Specification 38.5 does two things at once.  It fixes a *vocabulary* -- a
closed list of event names -- and it fixes a *carrier*: every event MUST
carry case ID, branch ID, object hashes, timestamp, actor, correlation ID,
and schema version.  Both are enforced structurally here.  An event name
outside the vocabulary raises rather than being emitted as a novel string,
because a subscriber filtering on ``decision.certified`` cannot be expected
to also guess ``decision.certified.v2``; and an event missing a required
carrier field raises, because a correlation ID that is sometimes absent is a
correlation ID no operator can build a trace on.

The bus is in-process and synchronous.  38.2 asks the reference server for
Server-Sent Events, WebSocket, or equivalent plus webhooks; those are
transports over this vocabulary, not separate semantics.  What this module
provides is the semantics plus :func:`webhook_payload`, which *builds* the
delivery a webhook would carry -- signature included -- without opening a
socket.  A test can then assert the exact bytes an integrator would receive,
which is the property that actually matters, and no test needs a network.
"""
from __future__ import annotations

import hashlib
import hmac
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Mapping, Optional, Sequence, Tuple

from crg_model.canonical import canonical_json, content_hash
from crg_model.envelope import new_object_id, utc_now
from crg_model.schema import schema_for, validate_or_raise

from .errors import UsageError

__all__ = [
    "EVENT_VOCABULARY",
    "REQUIRED_EVENT_FIELDS",
    "WEBHOOK_SIGNATURE_PROFILE",
    "Event",
    "EventBus",
    "AGENT_EVENT_PROTOCOL_VERSIONS",
    "AGENT_EVENT_TRANSPORT_PROFILES",
    "AGENT_EVENT_RESULTS",
    "AgentEvent",
    "AgentEventLedger",
    "negotiate_agent_event_protocol",
    "validate_agent_event_record",
    "webhook_payload",
]

#: Specification 38.5.  Closed by construction: :meth:`EventBus.emit` refuses
#: any name not in this tuple.
EVENT_VOCABULARY: Tuple[str, ...] = (
    "case.created",
    "case.validated",
    "case.branched",
    "case.merged",
    "case.migrated",
    "case.redacted",
    "registry.imported",
    "realization.generated",
    "realization.rejected",
    "design-space.pruned",
    "design-space.batch-pruned",
    "geometry.updated",
    "query.compiled",
    "commitment.previewed",
    "commitment.compared",
    "assessment.completed",
    "phase.previewed",
    "phase.analyzed",
    "decision.certified",
    "decision.blocked",
    "certificate.verified",
    "certificate.stale",
    "change.classified",
    "change.previewed",
    "case.reopened",
    "evidence.registered",
    "evidence.expired",
    "technology_contract.updated",
    "qualification.planned",
    "experiment.completed",
    "conversion.planned",
    "transition.executed",
    "transition.rolled_back",
    "capability.revoked",
)

#: Specification 38.5, "Every event MUST carry".
REQUIRED_EVENT_FIELDS: Tuple[str, ...] = (
    "case_id",
    "branch_id",
    "object_hashes",
    "timestamp",
    "actor",
    "correlation_id",
    "schema_version",
)

#: The webhook delivery signature profile.  Symmetric, and labelled as such:
#: a shared secret authenticates the *sender to a receiver that holds the same
#: secret* and proves nothing to a third party (compare 14.5, which requires
#: Ed25519 over canonical manifests for portable artifacts).
WEBHOOK_SIGNATURE_PROFILE = "HMAC-SHA256-SHARED-SECRET"

SCHEMA_VERSION = "0.2.0"

#: A1.3 is additive to the 38.5 carrier above.  Transport mappings share one
#: canonical envelope; none of them originates separate semantics.
AGENT_EVENT_PROTOCOL_VERSIONS: Tuple[str, ...] = ("1.0.0",)
AGENT_EVENT_TRANSPORT_PROFILES: Tuple[str, ...] = (
    "BATCH_FILE", "QUEUE", "LOCAL_PROCESS", "HTTP", "GRPC",
)
AGENT_EVENT_RESULTS: Tuple[str, ...] = (
    "ACCEPTED", "GAP_DETECTED", "FORK_DETECTED", "OMISSION_DETECTED",
    "DUPLICATE", "LATE_ARRIVAL", "STALE_PARENT", "ACKNOWLEDGED",
    "RETRY_SCHEDULED", "BACKPRESSURE", "OVERLOADED",
)


def negotiate_agent_event_protocol(offered_versions: Sequence[str]) -> Dict[str, Any]:
    """Select the highest common ABI version, or return an exact refusal."""

    offered = tuple(str(value) for value in offered_versions)
    selected = next(
        (version for version in reversed(AGENT_EVENT_PROTOCOL_VERSIONS) if version in offered),
        None,
    )
    return {
        "authority": "PROTOCOL_NEGOTIATION_ONLY",
        "execution_authorized": False,
        "offered_versions": list(offered),
        "selected_version": selected,
        "status": "NEGOTIATED" if selected else "UNSUPPORTED_PROTOCOL_VERSION",
        "supported_versions": list(AGENT_EVENT_PROTOCOL_VERSIONS),
    }


def _agent_text(value: Any, label: str, *, nullable: bool = False) -> Optional[str]:
    if nullable and value is None:
        return None
    if not isinstance(value, str) or not value:
        raise UsageError(f"agent event {label} must be a non-empty string")
    return value


def _agent_result(status: str, event: Mapping[str, Any], **extra: Any) -> Dict[str, Any]:
    if status not in AGENT_EVENT_RESULTS:
        raise UsageError(f"unknown agent event result {status!r}")
    return {
        "accepted": status in {"ACCEPTED", "ACKNOWLEDGED", "RETRY_SCHEDULED"},
        "authority": "EVENT_INGESTION_ONLY",
        "event_hash": event.get("event_hash"),
        "event_id": event.get("event_id"),
        "execution_authorized": False,
        "retryable": status in {"GAP_DETECTED", "OMISSION_DETECTED", "BACKPRESSURE", "RETRY_SCHEDULED"},
        "status": status,
        **extra,
    }


def validate_agent_event_record(value: Mapping[str, Any]) -> Dict[str, Any]:
    """Validate one A1.3 envelope and its transaction/delivery invariants."""

    if not isinstance(value, Mapping):
        raise UsageError("agent event must be an object")
    record = dict(value)
    try:
        validate_or_raise(record, schema_for("AgentEvent"))
    except Exception as error:
        raise UsageError(f"agent event schema validation failed: {error}") from error
    expected = content_hash({key: item for key, item in record.items() if key != "event_hash"})
    if record["event_hash"] != expected:
        raise UsageError("agent event hash differs from canonical content")
    if record["sequence"] < 1:
        raise UsageError("agent event sequence must be positive")
    parents = record["causal_parent_ids"]
    if parents != sorted(set(parents)):
        raise UsageError("agent event causal parents must be sorted and unique")
    relation = record["ordering_relation"]
    if (relation == "ROOT") != (parents == []):
        raise UsageError("ROOT ordering must have no parents and non-root ordering must name parents")
    if record["case_id"] is None and record["branch_id"] is not None:
        raise UsageError("agent event cannot name a branch without a case")
    delivery = record["delivery"]
    if delivery["attempt"] < 1 or delivery["max_attempts"] < 1 or delivery["attempt"] > delivery["max_attempts"]:
        raise UsageError("agent event delivery attempt is outside its declared retry bound")
    if (delivery["attempt"] == 1) != (delivery["retry_of_event_id"] is None):
        raise UsageError("only a delivery attempt after the first may name retry_of_event_id")
    transaction = record["transaction"]
    phase = transaction["phase"]
    if (phase == "ASSESS") != (transaction["prior_phase_event_id"] is None):
        raise UsageError("ASSESS starts a transaction; COMMIT and ACKNOWLEDGE bind a prior phase")
    allowed_types = {
        "ASSESS": {"assessment.requested", "assessment.completed"},
        "COMMIT": {"commitment.proposed", "commitment.dispositioned", "action.recorded"},
        "ACKNOWLEDGE": {"acknowledgement.recorded"},
    }
    if record["event_type"] not in allowed_types[phase]:
        raise UsageError("agent event type is outside its transaction phase")
    if phase == "COMMIT" and record["proposal_id"] is None:
        raise UsageError("a COMMIT phase event must bind a proposal")
    if record["event_type"] == "action.recorded" and record["action_id"] is None:
        raise UsageError("an action.recorded event must bind an action identity")
    if phase == "ACKNOWLEDGE":
        if not delivery["ack_required"] or delivery["acknowledged_event_id"] is None:
            raise UsageError("ACKNOWLEDGE must bind the acknowledged event")
    elif delivery["acknowledged_event_id"] is not None:
        raise UsageError("only ACKNOWLEDGE may bind acknowledged_event_id")
    return record


@dataclass(frozen=True)
class AgentEvent:
    """Canonical A1.3 envelope layered on the existing server event authority."""

    event_id: str
    event_type: str
    actor_id: str
    actor_kind: str
    case_id: Optional[str]
    branch_id: Optional[str]
    proposal_id: Optional[str]
    action_id: Optional[str]
    causal_parent_ids: Tuple[str, ...]
    ordering_relation: str
    sequence: int
    idempotency_key: str
    deduplication_key: str
    correlation_id: str
    occurred_at: str
    delivery_id: str
    attempt: int
    max_attempts: int
    ack_required: bool
    acknowledged_event_id: Optional[str]
    retry_of_event_id: Optional[str]
    transport_profile: str
    transaction_id: str
    transaction_phase: str
    request_hash: str
    prior_phase_event_id: Optional[str]
    payload_hash: str

    def __post_init__(self) -> None:
        object.__setattr__(self, "causal_parent_ids", tuple(sorted(self.causal_parent_ids)))
        validate_agent_event_record(self.to_canonical())

    def to_canonical(self) -> Dict[str, Any]:
        record: Dict[str, Any] = {
            "record_type": "AgentEvent",
            "schema_version": "1.0.0",
            "protocol_version": "1.0.0",
            "minimum_reader_version": "1.0.0",
            "event_id": self.event_id,
            "event_type": self.event_type,
            "actor": {"actor_id": self.actor_id, "actor_kind": self.actor_kind},
            "case_id": self.case_id,
            "branch_id": self.branch_id,
            "proposal_id": self.proposal_id,
            "action_id": self.action_id,
            "causal_parent_ids": list(self.causal_parent_ids),
            "ordering_relation": self.ordering_relation,
            "sequence": int(self.sequence),
            "idempotency_key": self.idempotency_key,
            "deduplication_key": self.deduplication_key,
            "correlation_id": self.correlation_id,
            "occurred_at": self.occurred_at,
            "delivery": {
                "delivery_id": self.delivery_id,
                "attempt": int(self.attempt),
                "max_attempts": int(self.max_attempts),
                "ack_required": self.ack_required,
                "acknowledged_event_id": self.acknowledged_event_id,
                "retry_of_event_id": self.retry_of_event_id,
            },
            "transport": {
                "profile": self.transport_profile,
                "mapping_version": "1.0.0",
            },
            "transaction": {
                "transaction_id": self.transaction_id,
                "phase": self.transaction_phase,
                "request_hash": self.request_hash,
                "prior_phase_event_id": self.prior_phase_event_id,
            },
            "payload_hash": self.payload_hash,
            "authority": "EVENT_CARRIER_ONLY",
            "execution_authorized": False,
        }
        record["event_hash"] = content_hash(record)
        return record

    def event_hash(self) -> str:
        return self.to_canonical()["event_hash"]


class AgentEventLedger:
    """Deterministic causal/delivery evaluator with optional audit persistence.

    ``store`` is the existing :class:`CaseStore` audit authority.  Supplying it
    makes accepted events restart-safe without adding a database or log: the
    ledger replays its own typed audit rows and verifies that each recorded
    result is reproduced before accepting new input.
    """

    def __init__(
        self,
        *,
        max_unacknowledged: int = 64,
        max_buffered: int = 128,
        store: Any = None,
        stream_id: str = "default",
    ) -> None:
        if max_unacknowledged < 1 or max_buffered < max_unacknowledged:
            raise ValueError("agent event buffer limits are invalid")
        if not stream_id:
            raise ValueError("agent event stream_id must be non-empty")
        self.max_unacknowledged = int(max_unacknowledged)
        self.max_buffered = int(max_buffered)
        self.store = store
        self.stream_id = str(stream_id)
        self._events: Dict[str, Dict[str, Any]] = {}
        self._results: Dict[str, Dict[str, Any]] = {}
        self._dedup: Dict[str, str] = {}
        self._children: Dict[str, str] = {}
        self._transaction_heads: Dict[str, str] = {}
        self._unacknowledged: Dict[str, str] = {}
        self._last_sequence = 0
        if self.store is not None:
            self._restore()

    @property
    def expected_sequence(self) -> int:
        return self._last_sequence + 1

    def ingest(self, value: Any) -> Dict[str, Any]:
        record = value.to_canonical() if isinstance(value, AgentEvent) else validate_agent_event_record(value)
        result = self._ingest(record)
        if self.store is not None:
            self.store.append_audit({
                "event": "agent_event.ingested",
                "record_type": "AgentEventIngestionRecord",
                "schema_version": "1.0.0",
                "stream_id": self.stream_id,
                "agent_event": record,
                "result": result,
                "recorded_at": utc_now(),
            })
        return result

    def _ingest(self, record: Dict[str, Any]) -> Dict[str, Any]:
        if record["event_id"] in self._events or record["deduplication_key"] in self._dedup:
            return _agent_result("DUPLICATE", record, expected_sequence=self.expected_sequence)
        if record["sequence"] > self.expected_sequence:
            return _agent_result("GAP_DETECTED", record, expected_sequence=self.expected_sequence)
        if record["sequence"] < self.expected_sequence:
            return _agent_result("LATE_ARRIVAL", record, expected_sequence=self.expected_sequence)
        missing = [parent for parent in record["causal_parent_ids"] if parent not in self._events]
        if missing:
            return _agent_result("OMISSION_DETECTED", record, missing_parent_ids=missing, expected_sequence=self.expected_sequence)
        for parent in record["causal_parent_ids"]:
            if parent in self._children and record["ordering_relation"] != "CONCURRENT":
                return _agent_result("FORK_DETECTED", record, fork_parent_id=parent, expected_sequence=self.expected_sequence)
        transaction_id = record["transaction"]["transaction_id"]
        head = self._transaction_heads.get(transaction_id)
        if head is not None and record["ordering_relation"] == "CAUSALLY_AFTER" and head not in record["causal_parent_ids"]:
            return _agent_result("STALE_PARENT", record, current_parent_id=head, expected_sequence=self.expected_sequence)
        acknowledged = None
        if record["event_type"] == "acknowledgement.recorded":
            acknowledged = record["delivery"]["acknowledged_event_id"]
            if acknowledged not in self._unacknowledged:
                return _agent_result(
                    "OMISSION_DETECTED", record,
                    missing_acknowledged_event_id=acknowledged,
                    expected_sequence=self.expected_sequence,
                )
        else:
            if len(self._unacknowledged) >= self.max_buffered:
                return _agent_result("OVERLOADED", record, expected_sequence=self.expected_sequence)
            if len(self._unacknowledged) >= self.max_unacknowledged:
                return _agent_result("BACKPRESSURE", record, expected_sequence=self.expected_sequence)
        self._events[record["event_id"]] = record
        self._dedup[record["deduplication_key"]] = record["event_id"]
        for parent in record["causal_parent_ids"]:
            if record["ordering_relation"] != "CONCURRENT":
                self._children[parent] = record["event_id"]
        self._transaction_heads[transaction_id] = record["event_id"]
        self._last_sequence = record["sequence"]
        if record["delivery"]["ack_required"] and record["event_type"] != "acknowledgement.recorded":
            self._unacknowledged[record["event_id"]] = record["delivery"]["delivery_id"]
        if record["event_type"] == "acknowledgement.recorded":
            self._unacknowledged.pop(acknowledged)
            result = _agent_result("ACKNOWLEDGED", record, expected_sequence=self.expected_sequence)
        elif record["delivery"]["attempt"] > 1:
            result = _agent_result("RETRY_SCHEDULED", record, expected_sequence=self.expected_sequence)
        else:
            result = _agent_result("ACCEPTED", record, expected_sequence=self.expected_sequence)
        self._results[record["event_id"]] = result
        return result

    def _restore(self) -> None:
        if not hasattr(self.store, "audit_log"):
            raise ValueError("persistent AgentEventLedger requires a CaseStore-compatible audit log")
        for row in self.store.audit_log():
            if (
                row.get("record_type") != "AgentEventIngestionRecord"
                or row.get("stream_id") != self.stream_id
            ):
                continue
            stored_result = row.get("result")
            if not isinstance(stored_result, Mapping) or stored_result.get("accepted") is not True:
                continue
            record = validate_agent_event_record(row.get("agent_event"))
            replayed = self._ingest(record)
            if replayed != stored_result:
                raise UsageError(
                    "persisted Agent Event result does not replay",
                    remedy="restore the CaseStore audit chain from a verified backup",
                )

    def transaction_receipt(self, transaction_id: str) -> Dict[str, Any]:
        """Return a portable causal receipt over one accepted transaction."""
        selected = [
            record for record in self._events.values()
            if record["transaction"]["transaction_id"] == transaction_id
        ]
        if not selected:
            raise UsageError(f"no Agent Event transaction {transaction_id!r}")
        selected.sort(key=lambda record: (record["sequence"], record["event_id"]))
        rows = [
            {
                "event_id": record["event_id"],
                "event_hash": record["event_hash"],
                "event_type": record["event_type"],
                "phase": record["transaction"]["phase"],
                "sequence": record["sequence"],
                "causal_parent_ids": list(record["causal_parent_ids"]),
                "request_hash": record["transaction"]["request_hash"],
                "payload_hash": record["payload_hash"],
                "ingestion_status": self._results[record["event_id"]]["status"],
            }
            for record in selected
        ]
        acknowledged = sorted({
            record["delivery"]["acknowledged_event_id"]
            for record in selected
            if record["event_type"] == "acknowledgement.recorded"
        })
        required_acknowledgements = {
            record["event_id"]
            for record in selected
            if record["event_type"] != "acknowledgement.recorded"
            and record["delivery"]["ack_required"]
        }
        unacknowledged = sorted(required_acknowledgements - set(acknowledged))
        receipt: Dict[str, Any] = {
            "record_type": "AgentTransactionReceipt",
            "schema_version": "1.0.0",
            "profile": "crg-agent-transaction/assess-commit-ack@1",
            "transaction_id": str(transaction_id),
            "events": rows,
            "sequence_start": rows[0]["sequence"],
            "sequence_end": rows[-1]["sequence"],
            "acknowledged_event_ids": acknowledged,
            "unacknowledged_event_ids": unacknowledged,
            "status": "ACKNOWLEDGED" if not unacknowledged else "OPEN",
            "authority": "TRANSACTION_EVIDENCE_ONLY",
            "execution_authorized": False,
        }
        receipt["receipt_hash"] = content_hash(receipt)
        return receipt


@dataclass(frozen=True)
class Event:
    """One emitted event with the full 38.5 carrier.

    ``object_hashes`` is a tuple of content hashes the event refers to.  It is
    part of the carrier and not an optional annotation: an event that says a
    decision was certified without naming the certificate it certified cannot
    be correlated with the object store afterwards.
    """

    event: str
    case_id: Optional[str]
    branch_id: Optional[str]
    object_hashes: Tuple[str, ...]
    timestamp: str
    actor: str
    correlation_id: str
    schema_version: str = SCHEMA_VERSION
    detail: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.event not in EVENT_VOCABULARY:
            raise UsageError(
                f"unknown event name {self.event!r}",
                remedy=(
                    "38.5 fixes a closed event vocabulary; emit one of "
                    f"{list(EVENT_VOCABULARY)} or extend the specification"
                ),
            )
        if not self.actor:
            raise UsageError(
                "an event must name its actor (38.5)",
                remedy="supply an actor identity on the originating request",
            )
        if not self.correlation_id:
            raise UsageError(
                "an event must carry a correlation ID (38.5)",
                remedy="supply a correlation ID on the originating request",
            )
        if not self.timestamp:
            raise UsageError("an event must carry a timestamp (38.5)")
        object.__setattr__(self, "object_hashes", tuple(str(h) for h in self.object_hashes))

    def to_canonical(self) -> Dict[str, Any]:
        record: Dict[str, Any] = {
            "event": self.event,
            "case_id": self.case_id,
            "branch_id": self.branch_id,
            "object_hashes": list(self.object_hashes),
            "timestamp": self.timestamp,
            "actor": self.actor,
            "correlation_id": self.correlation_id,
            "schema_version": self.schema_version,
        }
        if self.detail:
            record["detail"] = dict(self.detail)
        return record

    def event_hash(self) -> str:
        return content_hash(self.to_canonical())


class EventBus:
    """In-process publication of the 38.5 vocabulary.

    Subscribers are plain callables.  A subscriber that raises does not stop
    the emission: an integration listener is outside the trusted computing
    base of 9.2, and a broken listener must not be able to prevent an audit
    record from being written.  Its failure is recorded on the bus instead.
    """

    def __init__(self, store: Any = None) -> None:
        self._subscribers: List[Callable[[Event], None]] = []
        self._history: List[Event] = []
        self._store = store
        self.subscriber_failures: List[Tuple[str, str]] = []

    # -- subscription ------------------------------------------------------
    def subscribe(self, callback: Callable[[Event], None]) -> Callable[[], None]:
        """Register ``callback``; returns a zero-argument unsubscribe."""
        self._subscribers.append(callback)

        def _unsubscribe() -> None:
            if callback in self._subscribers:
                self._subscribers.remove(callback)

        return _unsubscribe

    # -- emission ----------------------------------------------------------
    def emit(
        self,
        event: str,
        *,
        actor: str,
        correlation_id: str,
        case_id: Optional[str] = None,
        branch_id: Optional[str] = None,
        object_hashes: Sequence[str] = (),
        detail: Optional[Mapping[str, Any]] = None,
        timestamp: Optional[str] = None,
    ) -> Event:
        record = Event(
            event=event,
            case_id=case_id,
            branch_id=branch_id,
            object_hashes=tuple(object_hashes),
            timestamp=timestamp or utc_now(),
            actor=actor,
            correlation_id=correlation_id,
            detail=dict(detail or {}),
        )
        self._history.append(record)
        # 44.7: the audit record is written before subscribers run, so a
        # subscriber that raises cannot cost the deployment its audit trail.
        if self._store is not None:
            self._store.append_audit(record.to_canonical())
        for callback in list(self._subscribers):
            try:
                callback(record)
            except Exception as error:  # noqa: BLE001 - listeners are untrusted
                self.subscriber_failures.append((record.event, f"{type(error).__name__}: {error}"))
        return record

    # -- inspection --------------------------------------------------------
    @property
    def history(self) -> Tuple[Event, ...]:
        return tuple(self._history)

    def names(self) -> Tuple[str, ...]:
        return tuple(e.event for e in self._history)

    def since(self, index: int) -> Tuple[Event, ...]:
        return tuple(self._history[index:])


def webhook_payload(
    event: Event,
    *,
    endpoint: str,
    secret: Optional[bytes] = None,
    delivery_id: Optional[str] = None,
) -> Dict[str, Any]:
    """Build the delivery a webhook subscriber would receive (spec 38.2).

    Nothing is sent.  The return value is the complete delivery -- headers,
    canonical body bytes, and signature -- so that an integrator can be tested
    against the exact payload without a network, and so that a deployment can
    hand the result to whatever transport it actually uses.

    The signature is computed over the canonical JSON of the body (14.3), not
    over whatever byte string a serializer happened to produce, so a receiver
    that re-canonicalizes reaches the same digest.
    """
    body = {
        "delivery_id": delivery_id or new_object_id("delivery"),
        "endpoint": endpoint,
        "event": event.to_canonical(),
    }
    payload = canonical_json(body).encode("utf-8")
    headers = {
        "Content-Type": "application/json",
        "CRG-Event": event.event,
        "CRG-Correlation-Id": event.correlation_id,
        "CRG-Delivery-Id": str(body["delivery_id"]),
        "CRG-Schema-Version": event.schema_version,
    }
    if secret is None:
        headers["CRG-Signature-Profile"] = "UNSIGNED"
        signature = None
    else:
        headers["CRG-Signature-Profile"] = WEBHOOK_SIGNATURE_PROFILE
        signature = hmac.new(secret, payload, hashlib.sha256).hexdigest()
        headers["CRG-Signature"] = f"sha256={signature}"
    return {
        "endpoint": endpoint,
        "method": "POST",
        "headers": headers,
        "body": body,
        "body_bytes": payload,
        "signature": signature,
        "signature_profile": headers["CRG-Signature-Profile"],
    }
