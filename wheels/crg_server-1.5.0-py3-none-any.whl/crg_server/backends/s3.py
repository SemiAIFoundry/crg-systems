"""An S3-compatible content-addressed object store for the 42.3 profile.

Normative basis: 42.3 (enterprise profile: "S3-compatible object storage",
high availability, backup and recovery, customer-managed encryption, legal
hold, air-gapped deployment), 42.1 (content-addressed object store for
canonical records and artifacts), 14.4 (hashing), 17.2--17.5 (redaction,
tombstones, legal hold), 6.6 (fail closed), 44.4 (encryption at rest), 44.5
(multi-tenancy).

**Read this paragraph before you deploy anything that imports this module.**
The adapter's object contract has been exercised over HTTP against a
checksum-verified single-node MinIO release through pinned boto3/botocore.
This establishes a bounded compatibility baseline, not qualification of an
arbitrary S3-compatible service, distributed topology, or operating
environment.  The following conditions remain deployment-specific:

* **Consistency taxonomy.**  Amazon S3 has offered strong read-after-write
  for new objects since December 2020, but "S3-compatible" covers stores that
  do not, and listings remain the weakest operation on all of them.  The
  monitoring in :meth:`S3ObjectStore.get_content` is a *process-local*
  approximation (see below) and has not met real replica lag or a distributed
  object-store cluster.
* **Error taxonomy.**  ``ClientError`` codes are matched against the
  documented strings.  A real deployment will meet codes not in the table --
  ``RequestTimeout``, ``SlowDown`` variants, ``503 Service Unavailable``
  without a code, non-AWS implementations' own codes -- and the fallback is
  :class:`~crg_server.backends.base.BackendUnavailableError`, which is safe
  but coarse.
* **Conditional writes.**  ``If-None-Match: *`` on ``PutObject`` is what makes
  the write-once claim enforceable at the store rather than in this process.
  Amazon added it in November 2024; older and third-party implementations
  ignore the header, in which case a put silently overwrites and the
  write-once property degrades to "guaranteed by content addressing alone".
  The live MinIO gate accepts and enforces this condition; that does not
  establish the behavior of older third-party stores.
* **IAM and permissions.**  Nothing here has met a bucket policy, an SCP, a
  KMS key policy, a VPC endpoint policy, or an ``AccessDenied``.
* **Large objects and multipart.**  The multipart path below is written from
  the API documentation.  Part sizing, the 5 MiB minimum part size, abort
  cleanup on failure, and ``CompleteMultipartUpload``'s eventual-consistency
  and retry behaviour are unexercised against a server.
* **Network partition.**  Retries, backoff, idempotency of a put that timed
  out after the bytes landed, and half-open connections are the client's
  responsibility here (a supplied ``boto3`` client has its own retry config)
  and none of it has run.
* **Server-side encryption.**  44.4's customer-managed keys are passed
  through as ``SSEKMSKeyId``/``ServerSideEncryption`` if configured and are
  otherwise absent.  No key has been created, rotated, or denied.

**Why boto3 is not imported.**  The client is supplied by the caller.  9.2
keeps the kernel standard-library-only, the 42.2 local profile must not
acquire a cloud SDK dependency because an enterprise adapter exists, and
42.3's air-gapped deployment may be talking to something that is not AWS at
all.  A deployment passes ``client=boto3.client("s3", ...)``, or passes
``client=None`` and gets :class:`DriverNotInstalledError` naming the package
at *construction* time rather than an ``ImportError`` at import time.

**Why the key is fanned out by hash prefix.**  Keys are
``<prefix>/content/ab/cd/<64 hex>``.  An object store partitions its index by
key prefix, and request rate is provisioned per partition; a layout whose
keys share a long common prefix -- a date, a monotonic counter, a tenant name
-- concentrates every request on one partition and gets throttled at a rate
far below the bucket's headline capacity.  A SHA-256 hex digest is uniformly
distributed, so taking two bytes of it as directory levels spreads writes
over 65,536 prefixes with no coordination and no hot spot, forever, including
for a bulk import that writes a million objects in an hour.  Amazon's index
now auto-partitions, so on AWS specifically this is belt and braces; on the
S3-compatible stores 42.3 also has to work with, it is still the difference
between a working import and a throttled one.

**Why there is a metadata sidecar.**  Content is write-once; the envelope
around it is not (42.1 puts presence, lifecycle status, and legal hold
outside the content, and 17.1/17.5 change all three).  S3 user metadata is
fixed at upload and can only be changed by a ``CopyObject`` onto the same key
with ``MetadataDirective=REPLACE`` -- which is a rewrite of an object this
system has just promised is immutable.  So each object gets a second, small,
mutable key under ``<prefix>/meta/`` holding the envelope.  It costs one
extra request per put and one per metadata read, it survives the deletion of
the content (which is exactly what 17.2 needs -- a tombstone must have
something to hang identity on), and it keeps the content key strictly
write-once.  In a deployment with S3 Object Lock available, the legal hold in
the sidecar SHOULD be mirrored to a real ``PutObjectLegalHold`` so the hold is
enforced by the store and not merely by this process; that mirroring is not
implemented here and its absence is the single largest gap between this
adapter and a 42.3 legal-hold claim.
"""
from __future__ import annotations

import importlib.util
import json
from typing import Any, Dict, List, Mapping, Optional

from crg_model.envelope import ObjectStatus, utc_now

from ..errors import (
    ConflictError,
    IntegrityError,
    NotFoundError,
    RedactedError,
    ServerError,
    UsageError,
)
from .base import (
    BackendConfigurationError,
    BackendUnavailableError,
    ConsistencyModel,
    DriverNotInstalledError,
    EventualConsistencyError,
    ObjectRecord,
    split_digest,
    verify_digest,
)

__all__ = [
    "S3ObjectStore",
    "S3_CONSISTENCY",
    "DEFAULT_MULTIPART_THRESHOLD",
    "DEFAULT_PART_SIZE",
    "NOT_FOUND_CODES",
    "PRECONDITION_CODES",
    "RETRYABLE_CODES",
    "boto3_client",
    "content_key",
    "metadata_key",
]

#: S3's own minimum part size for every part but the last is 5 MiB; the
#: threshold is set higher so a single-part put is used for everything a CRG
#: canonical record realistically is.  Exact integers, never floats.
DEFAULT_PART_SIZE = 8 * 1024 * 1024
DEFAULT_MULTIPART_THRESHOLD = 8 * 1024 * 1024

#: Codes that mean "the key is not there".  ``404`` appears because
#: ``head_object`` reports a miss with a bare status code and no code string.
NOT_FOUND_CODES = frozenset({"NoSuchKey", "NoSuchObject", "NotFound", "404"})

#: Codes that mean a conditional write was refused because the key existed.
PRECONDITION_CODES = frozenset({"PreconditionFailed", "412", "ObjectAlreadyExists"})

#: Codes that mean "try again"; every one of them leaves the operation's
#: outcome unknown, which is why they all become BackendUnavailableError (6.6)
#: rather than being retried silently inside this adapter.
RETRYABLE_CODES = frozenset(
    {
        "SlowDown",
        "Throttling",
        "ThrottlingException",
        "RequestLimitExceeded",
        "TooManyRequests",
        "InternalError",
        "ServiceUnavailable",
        "RequestTimeout",
        "500",
        "502",
        "503",
        "504",
    }
)

S3_CONSISTENCY = ConsistencyModel(
    name="s3-compatible",
    read_after_write="MONITORED",
    list_after_write="EVENTUAL",
    multi_statement_atomicity="NONE",
    cross_store_atomicity="NONE",
    notes=(
        "Content addressing removes the failure mode that makes eventual consistency "
        "dangerous: a stale read cannot return the WRONG version of an object, because "
        "there is only ever one version at an address.  What remains is a read that "
        "misses an object that was written, and a read that returns bytes which are not "
        "the object.  The second is detected absolutely, on every read, by hashing.  The "
        "first is detected only for objects THIS PROCESS wrote, by remembering their "
        "addresses -- a bound that is lost on restart and does not extend to another "
        "worker's writes. The normal path is exercised against single-node MinIO; "
        "replica lag and distributed failure behavior remain unobserved."
    ),
)


def content_key(prefix: str, digest: str) -> str:
    """``<prefix>/content/ab/cd/<hex>``.  See the module docstring on fan-out."""
    _, hexdigest = split_digest(digest)
    return f"{prefix}content/{hexdigest[0:2]}/{hexdigest[2:4]}/{hexdigest}"


def metadata_key(prefix: str, digest: str) -> str:
    """``<prefix>/meta/ab/cd/<hex>.json``.  The mutable envelope (42.1)."""
    _, hexdigest = split_digest(digest)
    return f"{prefix}meta/{hexdigest[0:2]}/{hexdigest[2:4]}/{hexdigest}.json"


def boto3_client(**kwargs: Any) -> Any:
    """Build a boto3 S3 client, or refuse by name.

    Called only when a deployment did not supply its own client.  The import
    happens *here*, so ``import crg_server.backends.s3`` succeeds on a machine
    with no boto3 -- which matters because the local profile (42.2) requires
    no external services and must not acquire a cloud SDK because an
    enterprise adapter exists.
    """
    if importlib.util.find_spec("boto3") is None:
        raise DriverNotInstalledError(
            "boto3 is not installed; crg-server imports no cloud SDK by design",
            remedy=(
                "install it -- \"pip install 'boto3>=1.34'\" -- or pass "
                "client=<any object with put_object/get_object/head_object/"
                "delete_object/list_objects_v2> so crg-server never has to know "
                "which SDK you use (42.3 also has to work air-gapped, against a "
                "store that is not AWS)"
            ),
            detail={"searched": ["boto3"],
                    "note": "the local 42.2 profile needs no SDK at all"},
        )
    module = importlib.import_module("boto3")
    return module.client("s3", **kwargs)  # type: ignore[attr-defined]


def _error_code(error: BaseException) -> str:
    """The S3 error code carried by a ``ClientError``-shaped exception.

    Duck-typed rather than ``isinstance(error, ClientError)``, because
    ``botocore`` is not imported here and because 42.3's air-gapped
    deployments may be using a client that is not botocore at all.  Anything
    without the shape returns ``""`` and is classified as a transport failure,
    which is the conservative reading.
    """
    response = getattr(error, "response", None)
    if isinstance(response, Mapping):
        detail = response.get("Error")
        if isinstance(detail, Mapping):
            code = detail.get("Code")
            if code is not None:
                return str(code)
        metadata = response.get("ResponseMetadata")
        if isinstance(metadata, Mapping) and metadata.get("HTTPStatusCode") is not None:
            return str(metadata["HTTPStatusCode"])
    return ""


class S3ObjectStore:
    """:class:`~crg_server.backends.base.ObjectStoreBackend` over S3.

    Interface-complete and exercised against single-node MinIO. See the module
    docstring for the production-service properties that does not establish.

    ``client`` must provide ``put_object``, ``get_object``, ``head_object``,
    ``delete_object`` and ``list_objects_v2``, plus the four multipart calls
    if objects above :attr:`multipart_threshold` are expected.  That is a
    boto3 client, and it is also anything else with the same five names --
    which is how MinIO, Ceph, or another compatible client can drive it.
    """

    def __init__(
        self,
        *,
        bucket: str,
        client: Optional[Any] = None,
        prefix: str = "crg/",
        multipart_threshold: int = DEFAULT_MULTIPART_THRESHOLD,
        part_size: int = DEFAULT_PART_SIZE,
        server_side_encryption: str = "",
        kms_key_id: str = "",
        conditional_writes: bool = True,
        client_kwargs: Optional[Mapping[str, Any]] = None,
    ) -> None:
        if not bucket:
            raise BackendConfigurationError(
                "an S3 object store needs a bucket name",
                remedy="pass bucket='my-crg-bucket'",
            )
        if int(part_size) < 5 * 1024 * 1024:
            raise BackendConfigurationError(
                f"part_size {part_size} is below S3's 5 MiB minimum for non-final parts",
                remedy="use at least 5242880, or lower multipart_threshold instead",
            )
        self.bucket = bucket
        self.prefix = prefix if prefix.endswith("/") or prefix == "" else prefix + "/"
        self.multipart_threshold = int(multipart_threshold)
        self.part_size = int(part_size)
        self.server_side_encryption = server_side_encryption
        self.kms_key_id = kms_key_id
        self.conditional_writes = bool(conditional_writes)
        self._client = client if client is not None else boto3_client(**(client_kwargs or {}))
        #: Addresses this process has successfully written.  A read that
        #: misses one of these is an eventual-consistency violation rather
        #: than an absence, and is raised as such -- see
        #: :data:`S3_CONSISTENCY` for what this does and does not cover.
        self._written: set = set()
        #: Multipart uploads whose abort also failed, for the operator who has
        #: to reap them.  Never silently discarded; see :meth:`_multipart_put`.
        self.abort_failures: List[Dict[str, Any]] = []
        self._closed = False

    # -- request plumbing --------------------------------------------------
    def _call(self, operation: str, /, **kwargs: Any) -> Any:
        """Invoke one client operation, converting failures at one place.

        Everything that is not a recognised "the key is not there" or "the
        conditional write was refused" becomes
        :class:`BackendUnavailableError`.  That includes throttling, 5xx,
        ``AccessDenied``, and a bare socket error, and the reason they are
        merged is 6.6: all of them leave the operation's outcome unknown, and
        an unknown outcome is reported rather than guessed at.  A caller that
        needs to distinguish them reads ``detail['s3_code']``.
        """
        method = getattr(self._client, operation, None)
        if method is None:
            raise BackendConfigurationError(
                f"the supplied S3 client has no {operation!r} operation",
                remedy=(
                    "supply a boto3 s3 client, or an object providing put_object, "
                    "get_object, head_object, delete_object and list_objects_v2"
                ),
                detail={"operation": operation,
                        "client_type": type(self._client).__name__},
            )
        try:
            return method(**kwargs)
        except ServerError:
            raise
        except Exception as error:  # noqa: BLE001 - classified immediately below
            code = _error_code(error)
            if code in NOT_FOUND_CODES:
                raise _KeyAbsent(kwargs.get("Key", "")) from error
            if code in PRECONDITION_CODES:
                raise _PreconditionFailed(kwargs.get("Key", "")) from error
            raise BackendUnavailableError(
                f"S3 {operation} failed"
                + (f" ({code})" if code else f": {type(error).__name__}: {error}"),
                remedy=(
                    "the outcome is unknown; re-read before concluding anything.  "
                    "Retrying is safe: every write here is content-addressed and "
                    "therefore idempotent (6.6)"
                ),
                detail={
                    "operation": operation,
                    "bucket": self.bucket,
                    "key": str(kwargs.get("Key", "")),
                    "s3_code": code,
                    "exception": type(error).__name__,
                    "retryable": code in RETRYABLE_CODES,
                },
            ) from error

    def _encryption_kwargs(self) -> Dict[str, Any]:
        """44.4 server-side encryption headers, when the deployment set them.

        Absent by default rather than defaulted to ``AES256``: a bucket with a
        default encryption policy already encrypts, and sending a weaker
        header than the bucket policy demands is how a put gets a 403 that
        looks like a permissions bug.
        """
        kwargs: Dict[str, Any] = {}
        if self.server_side_encryption:
            kwargs["ServerSideEncryption"] = self.server_side_encryption
        if self.kms_key_id:
            kwargs["SSEKMSKeyId"] = self.kms_key_id
        return kwargs

    # -- envelope sidecar --------------------------------------------------
    def _read_envelope(self, digest: str) -> Optional[Dict[str, Any]]:
        try:
            response = self._call(
                "get_object", Bucket=self.bucket, Key=metadata_key(self.prefix, digest)
            )
        except _KeyAbsent:
            return None
        payload = _read_body(response)
        try:
            value = json.loads(payload.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise IntegrityError(
                f"the metadata sidecar for {digest} is not readable JSON",
                remedy="restore the sidecar from a verified bundle; the content may be intact",
                detail={"key": metadata_key(self.prefix, digest), "error": str(error)},
            ) from error
        if not isinstance(value, dict):
            raise IntegrityError(
                f"the metadata sidecar for {digest} is not an object",
                remedy="restore the sidecar from a verified bundle",
                detail={"key": metadata_key(self.prefix, digest)},
            )
        return value

    def _write_envelope(self, digest: str, envelope: Mapping[str, Any]) -> None:
        payload = json.dumps(dict(envelope), sort_keys=True, separators=(",", ":")).encode(
            "utf-8"
        )
        self._call(
            "put_object",
            Bucket=self.bucket,
            Key=metadata_key(self.prefix, digest),
            Body=payload,
            ContentType="application/json",
            **self._encryption_kwargs(),
        )

    def _envelope_or_new(self, digest: str) -> Dict[str, Any]:
        envelope = self._read_envelope(digest)
        if envelope is not None:
            return envelope
        return {
            "content_hash": digest,
            "object_type": "OpaqueRecord",
            "byte_length": 0,
            "created_at": utc_now(),
            "created_by": "crg-server",
            "present": False,
            "legal_hold": False,
            "status": ObjectStatus.ACTIVE,
            "status_reason": "",
        }

    # -- interface: content ------------------------------------------------
    def put_content(
        self,
        digest: str,
        payload: bytes,
        *,
        object_type: str = "OpaqueRecord",
        created_by: str = "crg-server",
        legal_hold: bool = False,
    ) -> bool:
        """Conditional, write-once put.  Returns whether bytes were transferred.

        ``If-None-Match: *`` makes the write-once property the *store's* rule
        rather than this process's, so two workers racing on the same address
        cannot both write.  A refused condition is not an error here: the
        address is the hash, so whoever won wrote the same bytes, and the
        correct answer is "already present, nothing transferred".

        Ordering: content first, envelope second.  An interruption between
        them leaves bytes with no envelope, which
        :meth:`content_metadata` reports as absent and the next identical put
        repairs.  The other order would leave an envelope claiming a byte
        length for content that is not there.
        """
        split_digest(digest)
        verify_digest(digest, payload, where="s3 put_content (caller-declared address)")
        existing = self._read_envelope(digest)
        if existing is not None and existing.get("status") == ObjectStatus.REDACTED:
            raise RedactedError(
                f"object {digest} was redacted under authority and cannot be re-stored (17.2)",
                remedy="17.2: removal is an authorized act; reinstatement requires the same",
                detail={"content_hash": digest,
                        "removal_reason": str(existing.get("status_reason") or "")},
            )

        already_present = existing is not None and bool(existing.get("present"))
        key = content_key(self.prefix, digest)
        wrote = True
        try:
            if len(payload) > self.multipart_threshold:
                self._multipart_put(key, payload)
            else:
                conditional: Dict[str, Any] = (
                    {"IfNoneMatch": "*"} if self.conditional_writes else {}
                )
                self._call(
                    "put_object",
                    Bucket=self.bucket,
                    Key=key,
                    Body=payload,
                    ContentType="application/json",
                    **conditional,
                    **self._encryption_kwargs(),
                )
        except _PreconditionFailed:
            # Somebody else already wrote this address.  Content addressing
            # guarantees they wrote these bytes.
            wrote = False

        self._written.add(digest)
        envelope = self._envelope_or_new(digest)
        envelope.update(
            {
                "content_hash": digest,
                "object_type": object_type or envelope.get("object_type") or "OpaqueRecord",
                "byte_length": len(payload),
                "created_by": envelope.get("created_by") or created_by,
                "present": True,
                "legal_hold": bool(envelope.get("legal_hold")) or bool(legal_hold),
                "status": envelope.get("status") or ObjectStatus.ACTIVE,
            }
        )
        envelope.setdefault("created_at", utc_now())
        envelope.setdefault("status_reason", "")
        self._write_envelope(digest, envelope)
        return wrote and not already_present

    def _multipart_put(self, key: str, payload: bytes) -> None:
        """Upload in parts.  Aborts the upload if any part fails.

        The abort matters operationally: an incomplete multipart upload is
        invisible to ``ListObjects`` and is billed until a lifecycle rule
        reaps it, so a deployment that leaks them pays for storage it cannot
        see.  Untested against a server, like everything else in this file.
        """
        created = self._call(
            "create_multipart_upload",
            Bucket=self.bucket,
            Key=key,
            ContentType="application/json",
            **self._encryption_kwargs(),
        )
        upload_id = str(created["UploadId"])
        parts: List[Dict[str, Any]] = []
        try:
            number = 1
            for offset in range(0, len(payload), self.part_size):
                chunk = payload[offset: offset + self.part_size]
                result = self._call(
                    "upload_part",
                    Bucket=self.bucket,
                    Key=key,
                    UploadId=upload_id,
                    PartNumber=number,
                    Body=chunk,
                )
                parts.append({"ETag": result.get("ETag", ""), "PartNumber": number})
                number += 1
            self._call(
                "complete_multipart_upload",
                Bucket=self.bucket,
                Key=key,
                UploadId=upload_id,
                MultipartUpload={"Parts": parts},
            )
        except BaseException:
            try:
                self._call(
                    "abort_multipart_upload",
                    Bucket=self.bucket,
                    Key=key,
                    UploadId=upload_id,
                )
            except (BackendUnavailableError, _KeyAbsent, BackendConfigurationError) as failure:
                # The original failure is the one worth reporting; a failed
                # abort leaves a billable orphan, not a correctness problem.
                # It is recorded rather than swallowed so an operator can find
                # the uploads a lifecycle rule will have to reap.
                self.abort_failures.append(
                    {"key": key, "upload_id": upload_id, "error": str(failure)}
                )
            raise

    def get_content(self, digest: str) -> bytes:
        """Fetch and verify.  **Never trust the store.**

        Three distinct failures, kept distinct because collapsing them would
        make an operator debug the wrong thing:

        * bytes that do not hash to the key -- :class:`IntegrityError`, a hard
          failure and never a warning.  A returned object whose bytes are not
          the object is either corruption or tampering, and both must stop the
          read.
        * a key this process wrote that is now missing --
          :class:`EventualConsistencyError`, retryable.
        * a key that was removed under authority -- :class:`RedactedError`
          with the envelope, because 17.1 keeps absent and removed apart.
        """
        split_digest(digest)
        try:
            response = self._call(
                "get_object", Bucket=self.bucket, Key=content_key(self.prefix, digest)
            )
        except _KeyAbsent as absent:
            raise self._absence_error(digest) from absent
        payload = _read_body(response)
        declared = response.get("ContentLength")
        if declared is not None and int(declared) != len(payload):
            raise IntegrityError(
                f"S3 declared {declared} bytes for {digest} and delivered {len(payload)}",
                remedy="retry; if it persists, quarantine the object and restore it",
                detail={"declared": int(declared), "received": len(payload)},
            )
        verify_digest(digest, payload, where="s3 get_content (object store)")
        return payload

    def _absence_error(self, digest: str) -> ServerError:
        envelope = self._read_envelope(digest)
        if envelope is not None and envelope.get("status") == ObjectStatus.REDACTED:
            return RedactedError(
                f"object {digest} has been redacted (17.2)",
                remedy="the tombstone preserves identity, hash, type, and dependency edges",
                detail={"content_hash": digest,
                        "removal_reason": str(envelope.get("status_reason") or "")},
            )
        if digest in self._written:
            return EventualConsistencyError(
                f"object {digest} was written by this process and the store reports it absent",
                remedy=(
                    "retry: the object is durable and the read is stale.  This is not "
                    "'never stored' and must not be reported as such (17.1)"
                ),
                detail={"content_hash": digest, "bucket": self.bucket,
                        "key": content_key(self.prefix, digest)},
            )
        return NotFoundError(
            f"no object {digest} in bucket {self.bucket}",
            remedy="store it first; objects are addressed by the hash of their content",
            detail={"content_hash": digest},
        )

    def has_content(self, digest: str) -> bool:
        """Whether the bytes are readable.  ``False`` for a redacted digest.

        ``head_object`` rather than ``get_object``: this answers a presence
        question and there is no reason to move the bytes.  A miss on a digest
        this process wrote still raises
        :class:`EventualConsistencyError` -- returning ``False`` would let a
        caller conclude "not stored" about an object that is stored, which is
        exactly the mistake 6.6 exists to prevent.
        """
        split_digest(digest)
        try:
            self._call(
                "head_object", Bucket=self.bucket, Key=content_key(self.prefix, digest)
            )
        except _KeyAbsent:
            if digest in self._written:
                envelope = self._read_envelope(digest)
                if envelope is not None and envelope.get("status") == ObjectStatus.REDACTED:
                    return False
                raise EventualConsistencyError(
                    f"object {digest} was written by this process and the store reports it absent",
                    remedy="retry: the object is durable and the read is stale",
                    detail={"content_hash": digest, "bucket": self.bucket},
                ) from None
            return False
        return True

    def delete_content(self, digest: str) -> bool:
        """Remove the bytes, keep the envelope (17.2).  Refuses under hold (17.5).

        The envelope survives with ``present: false`` so that the tombstone
        has identity, type, and byte length to preserve, and so that a later
        read can say *removed under authority* rather than *never existed*.
        """
        split_digest(digest)
        envelope = self._read_envelope(digest)
        if envelope is None:
            return False
        if bool(envelope.get("legal_hold")):
            raise ConflictError(
                f"object {digest} is under legal hold and MUST NOT be deleted or "
                "cryptographically erased until the hold is released (17.5)",
                remedy="release the hold under authorized policy, then redact",
                detail={"content_hash": digest, "bucket": self.bucket},
            )
        if not envelope.get("present"):
            return False
        try:
            self._call(
                "delete_object", Bucket=self.bucket, Key=content_key(self.prefix, digest)
            )
        except _KeyAbsent:
            # S3 deletes are idempotent and report success for absent keys;
            # a store that reports a miss instead is still a successful
            # deletion from this method's point of view.
            pass
        envelope["present"] = False
        self._write_envelope(digest, envelope)
        self._written.discard(digest)
        return True

    def content_metadata(self, digest: str) -> ObjectRecord:
        envelope = self._read_envelope(digest)
        if envelope is None:
            raise NotFoundError(
                f"no object {digest} in bucket {self.bucket}",
                detail={"content_hash": digest},
            )
        return ObjectRecord(
            content_hash=str(envelope.get("content_hash") or digest),
            object_type=str(envelope.get("object_type") or "OpaqueRecord"),
            byte_length=int(envelope.get("byte_length") or 0),
            created_at=str(envelope.get("created_at") or ""),
            created_by=str(envelope.get("created_by") or ""),
            present=bool(envelope.get("present")),
            legal_hold=bool(envelope.get("legal_hold")),
            status=str(envelope.get("status") or ObjectStatus.ACTIVE),
            status_reason=str(envelope.get("status_reason") or ""),
        )

    def content_status(self, digest: str) -> str:
        envelope = self._read_envelope(digest)
        if envelope is None:
            return ObjectStatus.ACTIVE
        return str(envelope.get("status") or ObjectStatus.ACTIVE)

    def set_content_status(self, digest: str, status: str, *, reason: str = "") -> None:
        if status not in ObjectStatus.ALL:
            raise UsageError(
                f"unknown object status {status!r} (spec 12)",
                remedy=f"use one of {sorted(ObjectStatus.ALL)}",
            )
        envelope = self._envelope_or_new(digest)
        envelope["status"] = status
        envelope["status_reason"] = reason
        self._write_envelope(digest, envelope)

    def legal_hold(self, digest: str) -> bool:
        envelope = self._read_envelope(digest)
        return bool(envelope.get("legal_hold")) if envelope else False

    def set_legal_hold(self, digest: str, held: bool, *, authority: str = "") -> None:
        """Place or release a hold (17.5).

        Recorded in the sidecar, which means it is enforced by *this adapter*
        and not by the bucket.  A 42.3 deployment that means it should also
        set S3 Object Lock's own legal hold on the content key; see the module
        docstring.  A hold may be placed before the object arrives -- an
        organisation under a preservation order should not have to lose a race
        with an uploader.
        """
        envelope = self._envelope_or_new(digest)
        envelope["legal_hold"] = bool(held)
        envelope["legal_hold_authority"] = authority
        envelope["legal_hold_changed_at"] = utc_now()
        self._write_envelope(digest, envelope)

    def list_digests(self, *, limit: Optional[int] = None) -> List[str]:
        """Enumerate content keys.  Eventually consistent; never load-bearing.

        Paginates properly, because a listing that silently stopped at the
        first 1000 keys would make an export (6.2) quietly incomplete -- and a
        quietly incomplete export is worse than a failed one.
        """
        digests: List[str] = []
        token: Optional[str] = None
        content_prefix = f"{self.prefix}content/"
        while True:
            kwargs: Dict[str, Any] = {"Bucket": self.bucket, "Prefix": content_prefix}
            if token:
                kwargs["ContinuationToken"] = token
            response = self._call("list_objects_v2", **kwargs)
            for entry in response.get("Contents") or ():
                key = str(entry.get("Key") or "")
                hexdigest = key.rsplit("/", 1)[-1]
                if len(hexdigest) == 64:
                    digests.append("sha256:" + hexdigest)
            if not response.get("IsTruncated"):
                break
            token = response.get("NextContinuationToken")
            if not token:
                break
        digests.sort()
        return digests if limit is None else digests[: int(limit)]

    def consistency(self) -> ConsistencyModel:
        return S3_CONSISTENCY

    def close(self) -> None:
        self._closed = True
        self._written.clear()


def _read_body(response: Mapping[str, Any]) -> bytes:
    """Drain an S3 ``Body``, accepting either a stream or raw bytes."""
    body = response.get("Body")
    if isinstance(body, (bytes, bytearray)):
        return bytes(body)
    read = getattr(body, "read", None)
    if callable(read):
        return bytes(read())
    raise BackendUnavailableError(
        "the S3 client returned a response with no readable Body",
        remedy="the client is not S3-shaped; supply a boto3 client or an equivalent",
        detail={"body_type": type(body).__name__},
    )


class _S3Signal(Exception):
    """Internal control flow between :meth:`S3ObjectStore._call` and its callers.

    Not a :class:`~crg_server.errors.ServerError`: these never escape this
    module.  Every one of them is caught and converted into an interface-level
    outcome, because "the key was not there" is an answer to some questions
    (``has_content``) and a failure for others (``get_content``), and only the
    caller knows which.
    """

    def __init__(self, key: str) -> None:
        super().__init__(key)
        self.key = key


class _KeyAbsent(_S3Signal):
    """404 from the store."""


class _PreconditionFailed(_S3Signal):
    """412: a conditional write lost the race.  Not an error here."""
