"""A PostgreSQL metadata store for the 42.3 enterprise profile.

Normative basis: 42.3 (enterprise profile: "PostgreSQL or equivalent",
distributed workers, high availability, organization-level identity, policy
and audit export, backup and recovery, legal hold, air-gapped deployment),
42.1 (relational metadata, graph indexes for dependency traversal, an
append-only audit log), 16.1 (optimistic locking), 15.3 (migration MUST NOT
silently rewrite historical objects), 17.2 (tombstones), 18.5 (dependency
traversal), 38.4 (idempotency), 44.5 (multi-tenancy), 44.7 (audit).

**Read this paragraph before you deploy anything that imports this module.**
The adapter's metadata contract has been exercised against PostgreSQL 16
through the pinned Psycopg driver.  This establishes a bounded compatibility
baseline, not qualification of another server version, topology, workload, or
operating environment.  Specifically, the following classes of defect remain
outside that evidence:

* **Version breadth.** PostgreSQL 16 establishes the emitted SQL and common
  coercions on one service version; a maintained server-version matrix is
  still required before a broad compatibility claim.
* **Isolation and concurrency.**  Case locks, per-job session claims, and
  ``FOR UPDATE`` below are the intended answer under concurrent writers and
  workers.  Concurrent-writer and distributed-worker behavior requires
  deployment-specific testing.  Serialization anomalies, lock ordering,
  deadlock detection, and advisory-lock scope across pooled connections are
  not established by the compatibility baseline.
* **Operational reality.**  Connection pooling, statement timeouts,
  ``search_path`` and schema-per-tenant behaviour (44.5), permissions,
  ``VACUUM`` and index bloat, replication lag on a read replica, and failover
  are outside anything exercised here.
* **Size.**  No statement here has been run against a table with more than a
  few dozen rows.  The indexes are argued for, not measured.

Those operational gaps remain material even though the SQL compatibility gate
is now real; a single-node contract pass is not HA or production evidence.

**Why ``connect()`` is injected.**  Nothing in this module imports
``psycopg`` or ``psycopg2`` at module scope, so ``import
crg_server.backends.postgres`` succeeds on a machine that has neither -- which
matters because the local profile (42.2) requires no external services and
must not be broken by the existence of an enterprise adapter it never uses.
A deployment either supplies its own zero-argument ``connect()`` callable
returning a DBAPI 2.0 connection, or supplies a DSN and lets
:func:`psycopg_connect_factory` look for a driver, which raises
:class:`~crg_server.backends.base.DriverNotInstalledError` -- naming the
package and the version -- *at construction time*.

**Why every driver exception becomes ``BackendUnavailableError``.**  DBAPI
2.0 puts its exception hierarchy on the driver module, and this module has no
driver module.  So :meth:`PostgresMetadataStore._execute` re-raises this
package's own typed failures unchanged and converts everything else.  That
loses the distinction between, say, a serialization failure and a dropped
connection -- but both leave the statement's outcome *unknown*, and 6.6 says
an unknown outcome is reported rather than guessed at.  A deployment that
wants a finer taxonomy passes ``driver_errors=`` and can then classify.
"""
from __future__ import annotations

import json
import hashlib
import importlib.util
import threading
from contextlib import contextmanager
from typing import Any, Callable, Iterator, List, Optional, Sequence, Tuple, Union

from crg_model.envelope import utc_now

from ..errors import ConflictError, NotFoundError, ServerError, UsageError
from .base import (
    AuditRecord,
    BackendConfigurationError,
    BackendUnavailableError,
    CaseVersionRecord,
    CertificateRecord,
    ConsistencyModel,
    DriverNotInstalledError,
    EdgeRecord,
    IdempotencyRecord,
    JobRecord,
    TombstoneRecord,
)

__all__ = [
    "POSTGRES_DDL",
    "POSTGRES_SCHEMA_VERSION",
    "POSTGRES_CONSISTENCY",
    "ADVISORY_LOCK_NAMESPACE",
    "PostgresMetadataStore",
    "psycopg_connect_factory",
    "postgres_ddl",
    "advisory_lock_key",
]

#: A fixed namespace for ``pg_advisory_xact_lock(int4, int4)`` so CRG's locks
#: cannot collide with another application's in the same database.  42.3
#: allows the CRG schema to share a cluster with a tenant's other data.
ADVISORY_LOCK_NAMESPACE = 0x43524701  # "CRG" + version nibble
POSTGRES_SCHEMA_VERSION = 1


# ---------------------------------------------------------------------------
# Schema.  Emitted as one readable constant because a DBA has to review it
# before a migration window, and a schema assembled at runtime from fragments
# is a schema nobody reviews.
# ---------------------------------------------------------------------------
POSTGRES_DDL = """\
-- CRG Systems enterprise metadata schema (spec 42.1, 42.3).
-- Content lives in the object store; every hash column below is a reference
-- into it and never a copy of it.  Idempotent: safe to run on every start.

CREATE TABLE IF NOT EXISTS crg_schema_migrations (
    version              BIGINT  NOT NULL,
    applied_at           TEXT    NOT NULL,
    implementation_hash  TEXT    NOT NULL,
    PRIMARY KEY (version)
);

CREATE TABLE IF NOT EXISTS crg_cases (
    case_id         TEXT    NOT NULL,
    case_version    BIGINT  NOT NULL,
    content_hash    TEXT    NOT NULL,
    branch_id       TEXT    NOT NULL DEFAULT 'main',
    derived_from    TEXT,
    parent_version  BIGINT,
    status          TEXT    NOT NULL DEFAULT 'DRAFT',
    created_at      TEXT    NOT NULL,
    created_by      TEXT    NOT NULL DEFAULT 'crg-server',
    PRIMARY KEY (case_id, case_version)
);

-- 16.1 reads the head version before appending the next one.  The primary
-- key already orders (case_id, case_version); this index makes the DESC LIMIT
-- 1 head read an index-only backwards scan rather than a sort.
CREATE INDEX IF NOT EXISTS crg_cases_head_idx
    ON crg_cases (case_id, case_version DESC);
-- 11.2 keeps a superseded version addressable by its content hash.
CREATE INDEX IF NOT EXISTS crg_cases_hash_idx
    ON crg_cases (case_id, content_hash);

CREATE TABLE IF NOT EXISTS crg_edges (
    edge_id         TEXT    NOT NULL,
    case_id         TEXT,
    source          TEXT    NOT NULL,
    target          TEXT    NOT NULL,
    edge_type       TEXT    NOT NULL,
    scope           TEXT    NOT NULL DEFAULT '',
    minimum_action  TEXT    NOT NULL DEFAULT '',
    recorded_at     TEXT    NOT NULL,
    PRIMARY KEY (edge_id)
);

-- 42.1 asks for graph indexes for dependency traversal, and 18.5 traverses in
-- BOTH directions.  Forward ("what does this depend on") and reverse ("what
-- depends on this") are different index scans; the reverse direction is the
-- one impact analysis needs and the one a single (source) index turns into a
-- sequential scan of the whole edge table on every change classification.
CREATE INDEX IF NOT EXISTS crg_edges_source_idx ON crg_edges (source, edge_id);
CREATE INDEX IF NOT EXISTS crg_edges_target_idx ON crg_edges (target, edge_id);
CREATE INDEX IF NOT EXISTS crg_edges_case_idx   ON crg_edges (case_id, edge_id);

CREATE TABLE IF NOT EXISTS crg_certificates (
    case_id         TEXT    NOT NULL,
    certificate_id  TEXT    NOT NULL,
    content_hash    TEXT    NOT NULL,
    job_id          TEXT    NOT NULL DEFAULT '',
    outcome         TEXT    NOT NULL DEFAULT '',
    affirmative     BOOLEAN NOT NULL DEFAULT TRUE,
    registered_at   TEXT    NOT NULL,
    PRIMARY KEY (case_id, certificate_id)
);

-- 42.4: withdrawing the registrations of a job that failed to commit must not
-- scan every certificate in the deployment.
CREATE INDEX IF NOT EXISTS crg_certificates_job_idx ON crg_certificates (job_id);
CREATE INDEX IF NOT EXISTS crg_certificates_hash_idx ON crg_certificates (content_hash);

CREATE TABLE IF NOT EXISTS crg_idempotency (
    key             TEXT    NOT NULL,
    request_hash    TEXT    NOT NULL,
    response_json   TEXT    NOT NULL,
    status          BIGINT  NOT NULL,
    created_at      TEXT    NOT NULL,
    PRIMARY KEY (key)
);

CREATE TABLE IF NOT EXISTS crg_jobs (
    job_id          TEXT    NOT NULL,
    record_json     TEXT    NOT NULL,
    payload_json    TEXT    NOT NULL DEFAULT '',
    updated_at      TEXT    NOT NULL,
    PRIMARY KEY (job_id)
);

-- 44.7: append-only.  There is no UPDATE and no DELETE against this table
-- anywhere in this module, and seq is assigned by the database so two events
-- in the same millisecond still have an order and a clock that steps
-- backwards cannot reorder the log.  This is tamper-EVIDENCE, not
-- immutability: anyone with direct database privileges can still edit a
-- table, and 42.3's "policy and audit export" is how a deployment gets the
-- log somewhere the application cannot reach.
CREATE TABLE IF NOT EXISTS crg_audit (
    seq             BIGSERIAL PRIMARY KEY,
    recorded_at     TEXT    NOT NULL,
    event_json      TEXT    NOT NULL
);

CREATE INDEX IF NOT EXISTS crg_audit_time_idx ON crg_audit (recorded_at, seq);

-- 17.2.  The tombstone outlives the content, so this table is never cleaned
-- up by a retention job that removes the object it describes.
CREATE TABLE IF NOT EXISTS crg_tombstones (
    content_hash            TEXT    NOT NULL,
    object_id               TEXT    NOT NULL,
    object_type             TEXT    NOT NULL,
    reason                  TEXT    NOT NULL,
    authority               TEXT    NOT NULL,
    removed_at              TEXT    NOT NULL,
    legal_hold              BOOLEAN NOT NULL DEFAULT FALSE,
    permitted_disclosure    TEXT    NOT NULL DEFAULT '',
    dependency_edges_json   TEXT    NOT NULL DEFAULT '[]',
    PRIMARY KEY (content_hash)
);
"""


def postgres_ddl() -> str:
    """Return the schema.  Deterministic: the same text on every call.

    A schema that varied between calls -- by iterating a dict, by embedding a
    timestamp, by ordering indexes by hash seed -- could not be diffed between
    releases, and 15.3's migration discipline starts with being able to see
    what changed.
    """
    return POSTGRES_DDL


def postgres_ddl_statements() -> Tuple[str, ...]:
    """The DDL split into individual statements, comments stripped.

    A DBAPI ``execute`` takes one statement.  Splitting here rather than in
    the driver keeps :data:`POSTGRES_DDL` a document a human reads.
    """
    # Strip whole comment lines *before* splitting.  Several explanatory
    # comments contain semicolons; splitting the raw document first turns the
    # text after such a semicolon into an apparent SQL statement.
    uncommented = "\n".join(
        line for line in POSTGRES_DDL.splitlines()
        if line.strip() and not line.strip().startswith("--")
    )
    statements: List[str] = []
    for chunk in uncommented.split(";"):
        lines = [line for line in chunk.splitlines() if line.strip()]
        statement = "\n".join(lines).strip()
        if statement:
            statements.append(statement)
    return tuple(statements)


POSTGRES_CONSISTENCY = ConsistencyModel(
    name="postgresql",
    read_after_write="STRICT",
    list_after_write="STRICT",
    multi_statement_atomicity="TRANSACTIONAL",
    cross_store_atomicity="NONE",
    notes=(
        "READ COMMITTED with an advisory transaction lock around the 16.1 "
        "read-head-then-append sequence.  STRICT read-after-write assumes reads go "
        "to the primary; a deployment that routes reads to a streaming replica has "
        "MONITORED at best and this adapter has no way to detect the difference -- "
        "point it at the primary.  None of this has been observed against a real "
        "server (see the module docstring)."
    ),
)


# ---------------------------------------------------------------------------
# Driver discovery
# ---------------------------------------------------------------------------
def psycopg_connect_factory(dsn: str) -> Callable[[], Any]:
    """Return a zero-argument ``connect()`` for ``dsn``, or refuse by name.

    Called only when a deployment gave a DSN instead of its own callable.  The
    driver search happens *now*, so the failure is a
    :class:`DriverNotInstalledError` at construction with an install line
    attached -- not an ``ImportError`` at module import that would take down a
    local-profile server which never wanted PostgreSQL.

    ``psycopg`` (v3) is preferred over ``psycopg2``; both are accepted because
    an existing deployment may already have pinned the older one.
    """
    if not dsn:
        raise BackendConfigurationError(
            "a PostgreSQL DSN or a connect() callable is required",
            remedy=(
                "pass dsn='postgresql://...' or connect=<callable returning a "
                "DBAPI connection>"
            ),
        )
    for module_name, install in (
        ("psycopg", "pip install 'psycopg[binary]>=3.1'"),
        ("psycopg2", "pip install 'psycopg2-binary>=2.9'"),
    ):
        if importlib.util.find_spec(module_name) is not None:
            def connect(_module_name: str = module_name, _dsn: str = dsn) -> Any:
                module = importlib.import_module(_module_name)
                return module.connect(_dsn)  # type: ignore[attr-defined]

            return connect
    raise DriverNotInstalledError(
        "no PostgreSQL driver is installed; crg-server imports none by design",
        remedy=(
            "install one -- \"pip install 'psycopg[binary]>=3.1'\" (preferred) or "
            "\"pip install 'psycopg2-binary>=2.9'\" -- or pass your own connect() "
            "callable so crg-server never has to know which driver you use"
        ),
        detail={"searched": ["psycopg", "psycopg2"],
                "note": "the local 42.2 profile needs no driver at all"},
    )


def advisory_lock_key(case_id: str) -> int:
    """A stable 31-bit key for ``pg_advisory_xact_lock(namespace, key)``.

    Derived in Python from SHA-256 rather than from PostgreSQL's ``hashtext``
    so that the key does not depend on a server-side function whose algorithm
    is explicitly not guaranteed stable across major versions -- a lock that
    silently changed identity during an upgrade would stop excluding anything
    while looking like it still did.

    Collisions are possible and harmless: two case IDs sharing a key serialize
    against each other unnecessarily.  Losing a lock would not be harmless,
    which is why the trade is in this direction.
    """
    digest = hashlib.sha256(case_id.encode("utf-8")).digest()
    return int.from_bytes(digest[:4], "big") & 0x7FFFFFFF


# ---------------------------------------------------------------------------
# The adapter
# ---------------------------------------------------------------------------
class PostgresMetadataStore:
    """:class:`~crg_server.backends.base.MetadataBackend` over PostgreSQL.

    Interface-complete and exercised against PostgreSQL 16. See the module
    docstring for the operational properties that one live contract does not
    establish.

    Every value crosses the boundary as a bound parameter in the ``%s``
    paramstyle.  There is no ``%``-formatting, no f-string, and no ``+`` of a
    caller-supplied value into a statement anywhere in this class; the only
    interpolation is of table names that are literals in this file.  That is
    not a style preference: a store that concatenated a ``case_id`` into a
    ``WHERE`` clause would let a case identifier rewrite the audit log.
    """

    def __init__(
        self,
        *,
        connect: Optional[Callable[[], Any]] = None,
        dsn: str = "",
        driver_errors: Sequence[type] = (),
        autocommit_ddl: bool = True,
    ) -> None:
        if connect is None:
            connect = psycopg_connect_factory(dsn)  # raises DriverNotInstalledError now
        if not callable(connect):
            raise BackendConfigurationError(
                "connect must be a zero-argument callable returning a DBAPI connection",
                remedy="pass connect=lambda: psycopg.connect(dsn)",
            )
        self._connect = connect
        self._driver_errors: Tuple[type, ...] = tuple(driver_errors)
        self._autocommit_ddl = bool(autocommit_ddl)
        self._lock = threading.RLock()
        self._depth = 0
        self._connection: Optional[Any] = None
        self._closed = False

    # -- connection handling ----------------------------------------------
    def _conn(self) -> Any:
        """One connection, opened lazily and reused.

        A pool belongs above this class, not inside it: 42.3's distributed
        workers each hold their own store and a pool per worker per process is
        the deployment's decision, not the adapter's.  What this class must
        not do is open a connection per statement, which would make the
        advisory lock in :meth:`transaction` meaningless -- an advisory
        *transaction* lock is scoped to the connection that took it.
        """
        if self._closed:
            raise BackendUnavailableError(
                "this PostgreSQL metadata store has been closed",
                remedy="construct a new store; a closed store is not reopened silently",
            )
        if self._connection is None:
            try:
                self._connection = self._connect()
            except Exception as error:  # noqa: BLE001 - classified below
                raise self._unavailable("connect", error) from error
        return self._connection

    def _unavailable(self, what: str, error: BaseException) -> BackendUnavailableError:
        return BackendUnavailableError(
            f"PostgreSQL {what} failed: {type(error).__name__}: {error}",
            remedy=(
                "the outcome of this statement is unknown; re-read before concluding "
                "anything, and retry -- every write in this store is idempotent (6.6)"
            ),
            detail={"driver_exception": type(error).__name__, "operation": what},
        )

    def _execute(self, sql: str, parameters: Sequence[Any] = ()) -> List[Tuple[Any, ...]]:
        """Run one statement, return rows (empty for non-SELECT).

        Rows are materialized under the adapter's lock before returning, for
        the same reason :class:`crg_server.store._SerializedConnection` does
        it: a cursor handed back and fetched later can interleave with another
        thread's write between the execute and the fetch.
        """
        with self._lock:
            connection = self._conn()
            try:
                cursor = connection.cursor()
            except Exception as error:  # noqa: BLE001
                raise self._unavailable("cursor", error) from error
            try:
                cursor.execute(sql, tuple(parameters))
                rows = list(cursor.fetchall()) if cursor.description is not None else []
            except ServerError:
                raise
            except self._driver_errors as error:  # type: ignore[misc]
                raise self._unavailable("execute", error) from error
            except Exception as error:  # noqa: BLE001 - see the module docstring
                raise self._unavailable("execute", error) from error
            finally:
                close = getattr(cursor, "close", None)
                if callable(close):
                    close()
            return rows

    def _commit(self) -> None:
        with self._lock:
            try:
                self._conn().commit()
            except ServerError:
                raise
            except Exception as error:  # noqa: BLE001
                raise self._unavailable("commit", error) from error

    def _rollback(self) -> None:
        with self._lock:
            connection = self._connection
            if connection is None:
                return
            try:
                connection.rollback()
            except Exception as error:  # noqa: BLE001
                # A rollback that itself fails leaves the session in an
                # unknown state, so the connection is discarded rather than
                # reused.  6.6: do not carry an unknown state forward.
                self._connection = None
                raise self._unavailable("rollback", error) from error

    # -- interface: lifecycle ---------------------------------------------
    def initialize(self) -> None:
        """Apply and verify the versioned schema, refusing unknown drift."""
        with self._lock:
            for statement in postgres_ddl_statements():
                self._execute(statement)
            rows = self._execute(
                "SELECT version, implementation_hash FROM crg_schema_migrations "
                "ORDER BY version DESC LIMIT 1"
            )
            implementation_hash = "sha256:" + hashlib.sha256(
                POSTGRES_DDL.encode("utf-8")
            ).hexdigest()
            if not rows:
                self._execute(
                    "INSERT INTO crg_schema_migrations "
                    "(version, applied_at, implementation_hash) VALUES (%s, %s, %s) "
                    "ON CONFLICT (version) DO NOTHING",
                    (POSTGRES_SCHEMA_VERSION, utc_now(), implementation_hash),
                )
            else:
                version, recorded_hash = int(rows[0][0]), str(rows[0][1])
                if version != POSTGRES_SCHEMA_VERSION:
                    relation = "newer" if version > POSTGRES_SCHEMA_VERSION else "older"
                    raise BackendConfigurationError(
                        f"PostgreSQL schema version {version} is {relation} than supported "
                        f"version {POSTGRES_SCHEMA_VERSION}",
                        remedy="run a reviewed versioned database migration; startup never "
                               "guesses or silently downgrades schema state (15.3-15.6)",
                    )
                if recorded_hash != implementation_hash:
                    raise BackendConfigurationError(
                        "PostgreSQL schema implementation hash differs at the same version",
                        remedy="bump the schema version and ship a reviewed migration; do not "
                               "edit versioned DDL in place",
                    )
            if self._autocommit_ddl:
                self._commit()

    def schema_version(self) -> int:
        rows = self._execute(
            "SELECT version, implementation_hash FROM crg_schema_migrations "
            "ORDER BY version DESC LIMIT 1"
        )
        return int(rows[0][0]) if rows else 0

    @contextmanager
    def transaction(self) -> Iterator[None]:
        """A real transaction: ``COMMIT`` on clean exit, ``ROLLBACK`` on any exception.

        Re-entrant.  A nested ``with`` joins the outer unit rather than
        opening a second one, because PostgreSQL has no nested transactions
        (only savepoints) and silently mapping a nested ``with`` to a
        savepoint would make an inner failure look recoverable when the outer
        unit is already doomed.
        """
        with self._lock:
            outermost = self._depth == 0
            self._depth += 1
            try:
                yield
            except BaseException:
                self._depth -= 1
                if outermost:
                    self._rollback()
                raise
            else:
                self._depth -= 1
                if outermost:
                    self._commit()

    def lock_dependency_graph(self, case_id: str) -> None:
        """Hold a transaction-scoped advisory lock for one persisted DAG."""
        if self._depth == 0:
            raise BackendConfigurationError(
                "dependency graph locks require an active metadata transaction",
                remedy="use `with metadata.transaction():` before validation and writes",
            )
        self._advisory_lock(f"dependency-graph:{case_id}")

    def close(self) -> None:
        with self._lock:
            self._closed = True
            connection = self._connection
            self._connection = None
            if connection is None:
                return
            try:
                connection.close()
            except Exception as error:  # noqa: BLE001
                raise self._unavailable("close", error) from error

    def acquire_worker_lock(self, worker_id: str) -> bool:
        """Hold the legacy deployment-wide external-worker lease on this session.

        Session advisory locks are released by PostgreSQL if the process or
        connection dies, so crash recovery cannot leave a permanent lease.
        Retained for compatibility and administrative exclusivity. Runtime
        workers use :meth:`acquire_job_lock` so distinct jobs can be sharded.
        """
        rows = self._execute(
            "SELECT pg_try_advisory_lock(%s, %s)",
            (ADVISORY_LOCK_NAMESPACE, advisory_lock_key("crg-external-worker")),
        )
        return bool(rows and rows[0][0])

    def release_worker_lock(self, worker_id: str) -> bool:
        rows = self._execute(
            "SELECT pg_advisory_unlock(%s, %s)",
            (ADVISORY_LOCK_NAMESPACE, advisory_lock_key("crg-external-worker")),
        )
        return bool(rows and rows[0][0])

    def acquire_job_lock(self, job_id: str, worker_id: str = "") -> bool:
        """Try to claim one job on this PostgreSQL session.

        The lock is deliberately per job rather than deployment-wide.  Two
        workers can therefore execute different jobs concurrently, while a
        second worker observing the same queued (or crash-interrupted RUNNING)
        record fails to acquire that job.  PostgreSQL releases the claim if
        the worker process or connection dies, which makes recovery possible
        without a stale lease reaper or a wall-clock timeout that could expire
        during a legitimate long exact computation.

        ``worker_id`` is accepted for the common application-store protocol;
        ownership is the database session, not a caller-asserted string.
        """
        rows = self._execute(
            "SELECT pg_try_advisory_lock(%s, %s)",
            (ADVISORY_LOCK_NAMESPACE, advisory_lock_key(f"crg-job:{job_id}")),
        )
        return bool(rows and rows[0][0])

    def release_job_lock(self, job_id: str, worker_id: str = "") -> bool:
        """Release a per-job claim held by this PostgreSQL session."""
        rows = self._execute(
            "SELECT pg_advisory_unlock(%s, %s)",
            (ADVISORY_LOCK_NAMESPACE, advisory_lock_key(f"crg-job:{job_id}")),
        )
        return bool(rows and rows[0][0])

    def consistency(self) -> ConsistencyModel:
        return POSTGRES_CONSISTENCY

    # -- interface: cases (11.2, 16.1) ------------------------------------
    def put_case_version(self, record: CaseVersionRecord) -> None:
        """Append one version, holding the case's advisory lock.

        ``ON CONFLICT DO NOTHING`` plus a ``RETURNING`` probe rather than
        catching a unique-violation: catching would require knowing the
        driver's exception class, which this module deliberately does not
        import, and would leave the transaction aborted in PostgreSQL's
        "current transaction is aborted" state even though the caller intends
        to recover.
        """
        with self.transaction():
            self._advisory_lock(record.case_id)
            rows = self._execute(
                "INSERT INTO crg_cases (case_id, case_version, content_hash, branch_id, "
                "derived_from, parent_version, status, created_at, created_by) "
                "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s) "
                "ON CONFLICT (case_id, case_version) DO NOTHING "
                "RETURNING case_version",
                (
                    record.case_id,
                    int(record.case_version),
                    record.content_hash,
                    record.branch_id or "main",
                    record.derived_from or None,
                    record.parent_version,
                    record.status or "DRAFT",
                    record.created_at or utc_now(),
                    record.created_by or "crg-server",
                ),
            )
            if not rows:
                raise ConflictError(
                    f"case {record.case_id!r} already has a version "
                    f"{record.case_version}; history is append-only (15.3)",
                    remedy="re-read the head version, re-apply the change, and retry (16.1)",
                    detail={"case_id": record.case_id,
                            "case_version": int(record.case_version)},
                )

    def _advisory_lock(self, case_id: str) -> None:
        """Serialize writers for one case for the rest of this transaction.

        This is what the local profile gets for free from a single serialized
        connection (42.2) and what a 42.3 deployment with distributed workers
        does not.  ``pg_advisory_xact_lock`` releases at commit or rollback
        with no unlock call to leak, which is the property that matters when
        the thing between the lock and the commit is a solver.
        """
        self._execute(
            "SELECT pg_advisory_xact_lock(%s, %s)",
            (ADVISORY_LOCK_NAMESPACE, advisory_lock_key(case_id)),
        )

    def head_version(self, case_id: str) -> int:
        """Highest ordinal, ``0`` if unknown.

        ``ORDER BY ... DESC LIMIT 1 FOR UPDATE`` rather than ``MAX()``:
        PostgreSQL rejects ``FOR UPDATE`` alongside an aggregate, and the row
        lock is the point -- inside :meth:`put_case_version`'s transaction it
        stops a second writer from reading the same head and appending the
        same next ordinal.  Outside a transaction the lock is taken and
        released immediately, which costs a little and is correct.
        """
        rows = self._execute(
            "SELECT case_version FROM crg_cases WHERE case_id = %s "
            "ORDER BY case_version DESC LIMIT 1 FOR UPDATE",
            (case_id,),
        )
        if not rows:
            return 0
        return int(rows[0][0])

    def case_version(
        self, case_id: str, version: Union[int, str, None] = None
    ) -> CaseVersionRecord:
        columns = (
            "case_id, case_version, content_hash, branch_id, derived_from, "
            "parent_version, status, created_at, created_by"
        )
        if version is None:
            rows = self._execute(
                f"SELECT {columns} FROM crg_cases WHERE case_id = %s "
                "ORDER BY case_version DESC LIMIT 1",
                (case_id,),
            )
        elif isinstance(version, str) and version.startswith("sha256:"):
            rows = self._execute(
                f"SELECT {columns} FROM crg_cases WHERE case_id = %s AND content_hash = %s",
                (case_id, version),
            )
        else:
            try:
                ordinal = int(version)
            except (TypeError, ValueError):
                raise UsageError(
                    f"version {version!r} is neither an ordinal nor a sha256 content hash"
                ) from None
            rows = self._execute(
                f"SELECT {columns} FROM crg_cases WHERE case_id = %s AND case_version = %s",
                (case_id, ordinal),
            )
        if not rows:
            raise NotFoundError(
                f"no case {case_id!r}" + ("" if version is None else f" at version {version!r}"),
                remedy="POST /cases to create one, or GET /cases/{case_id} for the head",
            )
        return _case_record(rows[0])

    def list_case_versions(self, case_id: str) -> List[CaseVersionRecord]:
        rows = self._execute(
            "SELECT case_id, case_version, content_hash, branch_id, derived_from, "
            "parent_version, status, created_at, created_by FROM crg_cases "
            "WHERE case_id = %s ORDER BY case_version ASC",
            (case_id,),
        )
        return [_case_record(row) for row in rows]

    def list_case_ids(self) -> List[str]:
        rows = self._execute("SELECT DISTINCT case_id FROM crg_cases ORDER BY case_id ASC")
        return [str(row[0]) for row in rows]

    # -- interface: typed dependency graph (18) ---------------------------
    def record_edge(self, record: EdgeRecord) -> None:
        self._execute(
            "INSERT INTO crg_edges (edge_id, case_id, source, target, edge_type, scope, "
            "minimum_action, recorded_at) VALUES (%s, %s, %s, %s, %s, %s, %s, %s) "
            "ON CONFLICT (edge_id) DO UPDATE SET case_id = EXCLUDED.case_id, "
            "source = EXCLUDED.source, target = EXCLUDED.target, "
            "edge_type = EXCLUDED.edge_type, scope = EXCLUDED.scope, "
            "minimum_action = EXCLUDED.minimum_action, recorded_at = EXCLUDED.recorded_at",
            (
                record.edge_id,
                record.case_id or None,
                record.source,
                record.target,
                record.edge_type,
                record.scope or "",
                record.minimum_action or "",
                record.recorded_at or utc_now(),
            ),
        )
        if self._depth == 0:
            self._commit()

    def edges_from(self, source: str) -> List[EdgeRecord]:
        return self._edges("source = %s", (source,))

    def edges_to(self, target: str) -> List[EdgeRecord]:
        return self._edges("target = %s", (target,))

    def edges_for_case(self, case_id: str) -> List[EdgeRecord]:
        return self._edges("case_id = %s", (case_id,))

    def _edges(self, predicate: str, parameters: Sequence[Any]) -> List[EdgeRecord]:
        # ``predicate`` is a literal from the three call sites above and never
        # caller-supplied; the values are still bound parameters.
        rows = self._execute(
            "SELECT edge_id, case_id, source, target, edge_type, scope, minimum_action, "
            f"recorded_at FROM crg_edges WHERE {predicate} ORDER BY edge_id ASC",
            parameters,
        )
        return [_edge_record(row) for row in rows]

    # -- interface: certificates (42.4) -----------------------------------
    def register_certificate(self, record: CertificateRecord) -> None:
        self._execute(
            "INSERT INTO crg_certificates (case_id, certificate_id, content_hash, job_id, "
            "outcome, affirmative, registered_at) VALUES (%s, %s, %s, %s, %s, %s, %s) "
            "ON CONFLICT (case_id, certificate_id) DO UPDATE SET "
            "content_hash = EXCLUDED.content_hash, job_id = EXCLUDED.job_id, "
            "outcome = EXCLUDED.outcome, affirmative = EXCLUDED.affirmative, "
            "registered_at = EXCLUDED.registered_at",
            (
                record.case_id,
                record.certificate_id,
                record.content_hash,
                record.job_id or "",
                record.outcome or "",
                bool(record.affirmative),
                record.registered_at or utc_now(),
            ),
        )
        if self._depth == 0:
            self._commit()

    def certificate(self, case_id: str, certificate_id: str) -> CertificateRecord:
        rows = self._execute(
            "SELECT case_id, certificate_id, content_hash, job_id, outcome, affirmative, "
            "registered_at FROM crg_certificates WHERE case_id = %s AND certificate_id = %s",
            (case_id, certificate_id),
        )
        if not rows:
            raise NotFoundError(f"no certificate {certificate_id!r} in case {case_id!r}")
        return _certificate_record(rows[0])

    def list_certificates(self, case_id: str) -> List[CertificateRecord]:
        rows = self._execute(
            "SELECT case_id, certificate_id, content_hash, job_id, outcome, affirmative, "
            "registered_at FROM crg_certificates WHERE case_id = %s ORDER BY certificate_id ASC",
            (case_id,),
        )
        return [_certificate_record(row) for row in rows]

    def unregister_certificates(self, job_id: str) -> int:
        rows = self._execute(
            "DELETE FROM crg_certificates WHERE job_id = %s RETURNING certificate_id",
            (job_id,),
        )
        if self._depth == 0:
            self._commit()
        return len(rows)

    # -- interface: idempotency (38.4) ------------------------------------
    def idempotency_lookup(self, key: str) -> Optional[IdempotencyRecord]:
        rows = self._execute(
            "SELECT key, request_hash, response_json, status, created_at "
            "FROM crg_idempotency WHERE key = %s",
            (key,),
        )
        if not rows:
            return None
        row = rows[0]
        return IdempotencyRecord(
            key=str(row[0]),
            request_hash=str(row[1]),
            response_json=str(row[2]),
            status=int(row[3]),
            created_at=str(row[4]),
        )

    def idempotency_record(self, record: IdempotencyRecord) -> None:
        self._execute(
            "INSERT INTO crg_idempotency (key, request_hash, response_json, status, created_at) "
            "VALUES (%s, %s, %s, %s, %s) ON CONFLICT (key) DO UPDATE SET "
            "request_hash = EXCLUDED.request_hash, response_json = EXCLUDED.response_json, "
            "status = EXCLUDED.status, created_at = EXCLUDED.created_at",
            (
                record.key,
                record.request_hash,
                record.response_json,
                int(record.status),
                record.created_at or utc_now(),
            ),
        )
        if self._depth == 0:
            self._commit()

    def list_idempotency(self) -> List[IdempotencyRecord]:
        rows = self._execute(
            "SELECT key, request_hash, response_json, status, created_at "
            "FROM crg_idempotency ORDER BY key ASC"
        )
        return [
            IdempotencyRecord(
                key=str(row[0]), request_hash=str(row[1]), response_json=str(row[2]),
                status=int(row[3]), created_at=str(row[4]),
            )
            for row in rows
        ]

    # -- interface: jobs (42.4) -------------------------------------------
    def save_job(self, record: JobRecord) -> None:
        self._execute(
            "INSERT INTO crg_jobs (job_id, record_json, payload_json, updated_at) "
            "VALUES (%s, %s, %s, %s) ON CONFLICT (job_id) DO UPDATE SET "
            "record_json = EXCLUDED.record_json, payload_json = EXCLUDED.payload_json, "
            "updated_at = EXCLUDED.updated_at",
            (
                record.job_id,
                record.record_json,
                record.payload_json or "",
                record.updated_at or utc_now(),
            ),
        )
        if self._depth == 0:
            self._commit()

    def compare_and_set_job(
        self,
        record: JobRecord,
        *,
        expected_statuses: Sequence[str],
        expected_phase: str,
    ) -> bool:
        """Serialize cancellation against the worker's publication claim."""
        with self.transaction():
            rows = self._execute(
                "SELECT job_id, record_json, payload_json, updated_at FROM crg_jobs "
                "WHERE job_id = %s FOR UPDATE",
                (record.job_id,),
            )
            if not rows:
                return False
            current = json.loads(str(rows[0][1]))
            status = str(current.get("status"))
            phase = current.get("execution_phase")
            if phase is None:
                phase = (
                    "QUEUED" if status == "QUEUED"
                    else "EXECUTING" if status == "RUNNING"
                    else "TERMINAL"
                )
            if (
                status not in {str(value) for value in expected_statuses}
                or str(phase) != str(expected_phase)
            ):
                return False
            self.save_job(record)
        return True

    def load_job(self, job_id: str) -> Optional[JobRecord]:
        rows = self._execute(
            "SELECT job_id, record_json, payload_json, updated_at FROM crg_jobs "
            "WHERE job_id = %s",
            (job_id,),
        )
        if not rows:
            return None
        row = rows[0]
        return JobRecord(
            job_id=str(row[0]),
            record_json=str(row[1]),
            updated_at=str(row[3]),
            payload_json=str(row[2] or ""),
        )

    def list_jobs(self) -> List[JobRecord]:
        rows = self._execute(
            "SELECT job_id, record_json, payload_json, updated_at FROM crg_jobs "
            "ORDER BY job_id ASC"
        )
        return [
            JobRecord(
                job_id=str(row[0]),
                record_json=str(row[1]),
                updated_at=str(row[3]),
                payload_json=str(row[2] or ""),
            )
            for row in rows
        ]

    # -- interface: audit (44.7) ------------------------------------------
    def append_audit(self, recorded_at: str, event_json: str) -> int:
        """Insert and return the sequence PostgreSQL assigned.

        ``RETURNING seq`` rather than ``currval`` or a second ``SELECT``: the
        sequence must be the one *this* insert got, and a second statement
        could observe another writer's.
        """
        rows = self._execute(
            "INSERT INTO crg_audit (recorded_at, event_json) VALUES (%s, %s) RETURNING seq",
            (recorded_at or utc_now(), event_json),
        )
        if self._depth == 0:
            self._commit()
        if not rows:
            raise BackendUnavailableError(
                "audit insert returned no sequence number",
                remedy=(
                    "the event may or may not have been recorded; 44.7 requires an "
                    "immutable audit event for this operation, so the operation must "
                    "not be reported as complete (6.6)"
                ),
            )
        return int(rows[0][0])

    def read_audit(
        self, *, after_seq: int = 0, limit: Optional[int] = None
    ) -> List[AuditRecord]:
        rows = self._execute(
            "SELECT seq, recorded_at, event_json FROM crg_audit WHERE seq > %s "
            "ORDER BY seq ASC",
            (int(after_seq),),
        )
        records = [
            AuditRecord(seq=int(row[0]), recorded_at=str(row[1]), event_json=str(row[2]))
            for row in rows
        ]
        return records if limit is None else records[: int(limit)]

    # -- interface: tombstones (17.2) -------------------------------------
    def put_tombstone(self, record: TombstoneRecord) -> None:
        self._execute(
            "INSERT INTO crg_tombstones (content_hash, object_id, object_type, reason, "
            "authority, removed_at, legal_hold, permitted_disclosure, dependency_edges_json) "
            "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s) "
            "ON CONFLICT (content_hash) DO NOTHING",
            (
                record.content_hash,
                record.object_id,
                record.object_type,
                record.reason,
                record.authority,
                record.removed_at or utc_now(),
                bool(record.legal_hold),
                record.permitted_disclosure,
                record.dependency_edges_json or "[]",
            ),
        )
        if self._depth == 0:
            self._commit()

    def get_tombstone(self, digest: str) -> Optional[TombstoneRecord]:
        rows = self._execute(
            "SELECT content_hash, object_id, object_type, reason, authority, removed_at, "
            "legal_hold, permitted_disclosure, dependency_edges_json FROM crg_tombstones "
            "WHERE content_hash = %s",
            (digest,),
        )
        return _tombstone_record(rows[0]) if rows else None

    def list_tombstones(self) -> List[TombstoneRecord]:
        rows = self._execute(
            "SELECT content_hash, object_id, object_type, reason, authority, removed_at, "
            "legal_hold, permitted_disclosure, dependency_edges_json FROM crg_tombstones "
            "ORDER BY content_hash ASC"
        )
        return [_tombstone_record(row) for row in rows]


# ---------------------------------------------------------------------------
# Row adapters.  Positional, because the SELECT lists above are explicit and
# a driver that returns tuples must work as well as one that returns dicts.
# ---------------------------------------------------------------------------
def _case_record(row: Sequence[Any]) -> CaseVersionRecord:
    return CaseVersionRecord(
        case_id=str(row[0]),
        case_version=int(row[1]),
        content_hash=str(row[2]),
        branch_id=str(row[3] or "main"),
        derived_from=str(row[4] or ""),
        parent_version=int(row[5]) if row[5] is not None else None,
        status=str(row[6] or "DRAFT"),
        created_at=str(row[7] or ""),
        created_by=str(row[8] or "crg-server"),
    )


def _edge_record(row: Sequence[Any]) -> EdgeRecord:
    return EdgeRecord(
        edge_id=str(row[0]),
        case_id=str(row[1] or ""),
        source=str(row[2]),
        target=str(row[3]),
        edge_type=str(row[4]),
        scope=str(row[5] or ""),
        minimum_action=str(row[6] or ""),
        recorded_at=str(row[7] or ""),
    )


def _certificate_record(row: Sequence[Any]) -> CertificateRecord:
    return CertificateRecord(
        case_id=str(row[0]),
        certificate_id=str(row[1]),
        content_hash=str(row[2]),
        job_id=str(row[3] or ""),
        outcome=str(row[4] or ""),
        affirmative=bool(row[5]),
        registered_at=str(row[6] or ""),
    )


def _tombstone_record(row: Sequence[Any]) -> TombstoneRecord:
    return TombstoneRecord(
        content_hash=str(row[0]),
        object_id=str(row[1]),
        object_type=str(row[2]),
        reason=str(row[3]),
        authority=str(row[4]),
        removed_at=str(row[5]),
        legal_hold=bool(row[6]),
        permitted_disclosure=str(row[7] or ""),
        dependency_edges_json=str(row[8] or "[]"),
    )
