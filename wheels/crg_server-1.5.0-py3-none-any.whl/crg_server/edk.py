"""Embedded Developer Kit over the existing CRG application boundary.

The EDK is deliberately an adapter, not a second application.  The in-process
profile calls :class:`crg_server.app.Application`; the sidecar profile calls
the routes generated from that same application's endpoint table.  Both
therefore use the existing producers, CaseStore, JobQueue, event vocabulary,
OpenAPI description, and refusal behavior.
"""
from __future__ import annotations

import base64
import hashlib
import importlib
import json
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Optional, Protocol, Sequence, Tuple

from crg_model.canonical import canonical_json, content_hash
from crg_verify import verify_source_adapter_output

from .app import Application, ROLE_REQUIREMENTS, Request, build_request
from .jobs import DEFAULT_RESOURCE_LIMITS

__all__ = [
    "EDK_PROFILE",
    "EDK_RECEIPT_PROFILE",
    "EDKError",
    "EDKTransportResponse",
    "InProcessTransport",
    "ApplicationWireTransport",
    "SidecarTransport",
    "EmbeddedDeveloperKit",
]

EDK_PROFILE = "crg-edk-preview/v1"
EDK_RECEIPT_PROFILE = "crg-edk-operation-receipt/v1"
_SUPPORTED_TRANSPORT_PROFILES = frozenset({
    "IN_PROCESS", "SIDECAR_WIRE_CODEC", "SIDECAR_HTTP",
})

_HIGH_LEVEL_OPERATIONS = (
    "importRegistry",
    "generateFamily",
    "getDesignSpaceCapabilities",
    "verifyDesignSpace",
    "buildGeometry",
    "compileQuery",
    "pruneDesignSpace",
    "pruneDesignSpaceBatch",
    "registerEvidence",
    "requestAssessment",
    "publishLifecycleRecord",
    "verifyLifecycleRecord",
    "executeTransition",
    "revokeCapability",
    "previewCommitment",
    "compareCommitment",
    "classifyChange",
    "previewChange",
    "ingestAgentEvent",
    "getAgentTransactionReceipt",
    "registerAgentGrant",
    "revokeAgentGrant",
    "submitAgentProposal",
    "reconcileAgentConflict",
    "verifyBundle",
    "exportBundle",
)


class EDKError(RuntimeError):
    """A typed application, transport, timeout, or protocol refusal."""

    def __init__(
        self,
        message: str,
        *,
        status: int = 0,
        category: str = "EDK_ERROR",
        remedy: str = "",
        detail: Any = None,
    ) -> None:
        super().__init__(message)
        self.status = int(status)
        self.category = str(category)
        self.remedy = str(remedy)
        self.detail = detail


@dataclass(frozen=True)
class EDKTransportResponse:
    status: int
    body: Any
    headers: Mapping[str, str]
    content_type: str = "application/json"


class EDKTransport(Protocol):
    profile: str

    def invoke(
        self,
        *,
        method: str,
        path: str,
        query: Mapping[str, str],
        body: Optional[Mapping[str, Any]],
        actor: str,
        correlation_id: str,
        idempotency_key: Optional[str],
        timeout: float,
    ) -> EDKTransportResponse: ...


class InProcessTransport:
    """Direct use of the already-established application façade."""

    profile = "IN_PROCESS"

    def __init__(self, application: Application) -> None:
        self.application = application

    def invoke(
        self,
        *,
        method: str,
        path: str,
        query: Mapping[str, str],
        body: Optional[Mapping[str, Any]],
        actor: str,
        correlation_id: str,
        idempotency_key: Optional[str],
        timeout: float,
    ) -> EDKTransportResponse:
        del timeout
        response = self.application.dispatch(Request(
            method=method,
            path=path,
            query=dict(query),
            body=None if body is None else dict(body),
            actor=actor,
            correlation_id=correlation_id,
            idempotency_key=idempotency_key,
        ))
        payload = response.raw if response.raw is not None else response.body
        return EDKTransportResponse(
            response.status, payload, dict(response.headers), response.content_type
        )

    def drive_job(self, job_id: str) -> None:
        """Run acknowledged local work through the existing embedded worker."""
        record = self.application.queue.get(job_id)
        if record.status == "QUEUED":
            self.application.queue.run(job_id)


class ApplicationWireTransport(InProcessTransport):
    """Exercise the sidecar JSON wire codec without opening a test socket.

    The production sidecar is still :class:`SidecarTransport`.  This adapter
    exists for deterministic offline conformance: it serializes a request to
    the exact bytes accepted by :func:`build_request`, dispatches the same
    application, then decodes the exact response payload a sidecar writes.
    """

    profile = "SIDECAR_WIRE_CODEC"

    def invoke(
        self,
        *,
        method: str,
        path: str,
        query: Mapping[str, str],
        body: Optional[Mapping[str, Any]],
        actor: str,
        correlation_id: str,
        idempotency_key: Optional[str],
        timeout: float,
    ) -> EDKTransportResponse:
        del timeout
        target = path
        if query:
            target += "?" + urllib.parse.urlencode(sorted(query.items()))
        raw = b"" if body is None else canonical_json(dict(body)).encode("utf-8")
        headers = {
            "Content-Type": "application/json",
            "X-CRG-Actor": actor,
            "X-CRG-Correlation-Id": correlation_id,
        }
        if idempotency_key is not None:
            headers["Idempotency-Key"] = idempotency_key
        request = build_request(method, target, raw, headers)
        response = self.application.dispatch(request)
        payload = response.payload()
        if "json" in response.content_type:
            decoded: Any = json.loads(payload.decode("utf-8")) if payload else None
        else:
            decoded = payload
        return EDKTransportResponse(
            response.status, decoded, dict(response.headers), response.content_type
        )


class SidecarTransport:
    """Dependency-free JSON/HTTP adapter for the existing ``crg-server``."""

    profile = "SIDECAR_HTTP"

    def __init__(self, base_url: str) -> None:
        parsed = urllib.parse.urlsplit(str(base_url))
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise ValueError("sidecar base_url must be an absolute http(s) URL")
        self.base_url = str(base_url).rstrip("/")

    def invoke(
        self,
        *,
        method: str,
        path: str,
        query: Mapping[str, str],
        body: Optional[Mapping[str, Any]],
        actor: str,
        correlation_id: str,
        idempotency_key: Optional[str],
        timeout: float,
    ) -> EDKTransportResponse:
        target = self.base_url + path
        if query:
            target += "?" + urllib.parse.urlencode(sorted(query.items()))
        raw = None if body is None else canonical_json(dict(body)).encode("utf-8")
        headers = {
            "Accept": "application/json, application/zip",
            "X-CRG-Actor": actor,
            "X-CRG-Correlation-Id": correlation_id,
        }
        if raw is not None:
            headers["Content-Type"] = "application/json"
        if idempotency_key is not None:
            headers["Idempotency-Key"] = idempotency_key
        request = urllib.request.Request(
            target, data=raw, headers=headers, method=method
        )
        try:
            response = urllib.request.urlopen(request, timeout=float(timeout))
            status = int(response.status)
            response_headers = dict(response.headers.items())
            response_raw = response.read()
        except urllib.error.HTTPError as error:
            status = int(error.code)
            response_headers = dict(error.headers.items()) if error.headers else {}
            response_raw = error.read()
        except (urllib.error.URLError, TimeoutError, OSError) as error:
            raise EDKError(
                f"sidecar unavailable: {error}",
                category="SIDECAR_UNAVAILABLE",
                remedy="start or restore the configured crg-server sidecar",
            ) from error
        content_type = str(response_headers.get("Content-Type") or "application/json")
        if "json" in content_type and response_raw:
            try:
                response_body: Any = json.loads(response_raw.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError) as error:
                raise EDKError(
                    f"sidecar returned malformed JSON: {error}",
                    status=status,
                    category="MALFORMED_SIDECAR_RESPONSE",
                ) from error
        elif "json" in content_type:
            response_body = None
        else:
            response_body = response_raw
        return EDKTransportResponse(status, response_body, response_headers, content_type)


class EmbeddedDeveloperKit:
    """Versioned high-level methods over the generated application surface."""

    def __init__(
        self,
        transport: EDKTransport,
        *,
        actor: str,
        timeout_seconds: float = 30.0,
        poll_interval_seconds: float = 0.05,
    ) -> None:
        if not actor:
            raise ValueError("the EDK requires an attributable actor identity")
        if getattr(transport, "profile", None) not in _SUPPORTED_TRANSPORT_PROFILES:
            raise ValueError(
                "unsupported EDK transport profile; expected IN_PROCESS, "
                "SIDECAR_WIRE_CODEC, or SIDECAR_HTTP"
            )
        if timeout_seconds <= 0 or poll_interval_seconds <= 0:
            raise ValueError("EDK timeout and poll interval must be positive")
        self.transport = transport
        self.actor = str(actor)
        self.timeout_seconds = float(timeout_seconds)
        self.poll_interval_seconds = float(poll_interval_seconds)
        self._receipts: list[Dict[str, Any]] = []

    @property
    def receipts(self) -> Tuple[Dict[str, Any], ...]:
        return tuple(dict(receipt) for receipt in self._receipts)

    @property
    def last_receipt(self) -> Optional[Dict[str, Any]]:
        return dict(self._receipts[-1]) if self._receipts else None

    def disclosure(self) -> Dict[str, Any]:
        return {
            "profile": EDK_PROFILE,
            "transport_profile": self.transport.profile,
            "application_boundary": "crg_server.Application",
            "new_semantic_producers": False,
            "new_persistence_format": False,
            "authority": "APPLICATION_ADAPTER_ONLY",
            "execution_authorized": False,
        }

    def security_boundary(self) -> Dict[str, Any]:
        """Describe the existing application security boundary used by the EDK.

        This is a disclosure over the established server, security, job, and
        audit machinery.  It neither creates an EDK-specific identity system
        nor treats caller-authored organization or tenant values as authority.
        """
        OPERATION_PERMISSIONS = importlib.import_module(
            "crg_security"
        ).OPERATION_PERMISSIONS

        application = getattr(self.transport, "application", None)
        if application is not None:
            deployment = application.security_disclosure()
            held_roles = sorted(application.roles.get(self.actor, ()))
        else:
            deployment = {
                "authentication_configured": "DISCLOSED_BY_SIDECAR_RESPONSE",
                "tenant_separation": "ENFORCED_BY_SIDECAR_DEPLOYMENT",
            }
            held_roles = []
        permissions = {
            operation_id: {
                "permission": OPERATION_PERMISSIONS.get(operation_id),
                "required_roles": list(ROLE_REQUIREMENTS.get(operation_id, ())),
            }
            for operation_id in _HIGH_LEVEL_OPERATIONS
        }
        return {
            "profile": EDK_PROFILE,
            "transport_profile": self.transport.profile,
            "identities": {
                "caller": {
                    "actor": self.actor,
                    "authentication": "DELEGATED_TO_APPLICATION_SECURITY_GATE",
                    "held_static_roles": held_roles,
                },
                "organization": "DEPLOYMENT_OWNED_NOT_EDK_REQUEST_DATA",
                "tenant": "DEPLOYMENT_OWNED_NOT_EDK_REQUEST_DATA",
                "agent": "BOUND_BY_AGENT_EVENT_ACTOR_ID_AND_ACTOR_KIND",
                "tool": "BOUND_BY_SOURCE_ADAPTER_DEFINITION",
                "package": "BOUND_BY_RESOLVED_PROFILE_LOCK_AND_PACKAGE_IDENTITY",
            },
            "permissions": permissions,
            "secret_custody": {
                "values_in_operation_receipts": False,
                "values_in_durable_job_inputs": False,
                "references_owned_by": "DEPLOYMENT_OR_TRANSPORT",
            },
            "resource_limits": dict(DEFAULT_RESOURCE_LIMITS),
            "audit_and_correlation": {
                "request_hash": "EDKOperationReceipt.request_hash",
                "correlation_id": "EDKOperationReceipt.correlation_id",
                "application_audit": "CaseStore audit log and EventBus",
            },
            "network": {
                "default": "LOCAL_OFFLINE",
                "used": self.transport.profile == "SIDECAR_HTTP",
                "sidecar_only": True,
            },
            "deployment_security": deployment,
            "threats": [
                {"threat": "UNTRUSTED_INPUT", "control": "typed Application request decoding"},
                {"threat": "IDENTITY_SPOOFING", "control": "deployment security gate"},
                {"threat": "REPLAY", "control": "request hash and idempotency key"},
                {"threat": "STALE_EVENT", "control": "AgentEvent causal and sequence ledger"},
                {"threat": "SECRET_LEAKAGE", "control": "redacted durable inputs and hash-only receipts"},
                {"threat": "TOOL_OR_PACKAGE_ELEVATION", "control": "non-authorizing adapter and package identities"},
                {"threat": "SIDECAR_UNAVAILABLE", "control": "typed refusal without local fallback"},
            ],
            "authority": "APPLICATION_SECURITY_DISCLOSURE_ONLY",
            "execution_authorized": False,
        }

    @staticmethod
    def _path_identifier(value: str) -> str:
        text = str(value)
        if not text:
            raise ValueError("path identifiers must be non-empty")
        return urllib.parse.quote(text, safe="")

    @staticmethod
    def _payload_hash(value: Any) -> str:
        if isinstance(value, bytes):
            return "sha256:" + hashlib.sha256(value).hexdigest()
        return content_hash(value)

    def _invoke(
        self,
        operation_id: str,
        method: str,
        path: str,
        *,
        body: Optional[Mapping[str, Any]] = None,
        query: Optional[Mapping[str, Any]] = None,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> EDKTransportResponse:
        query_record = {
            str(key): str(value) for key, value in sorted((query or {}).items())
            if value is not None
        }
        request_record = {
            "method": str(method).upper(),
            "path": str(path),
            "query": query_record,
            "body": None if body is None else dict(body),
        }
        request_hash = content_hash(request_record)
        correlation_id = "edk-" + request_hash.removeprefix("sha256:")[:24]
        replay_key = idempotency_key
        if replay_key is None and method.upper() in {"POST", "PUT", "PATCH", "DELETE"}:
            replay_key = "edk-" + request_hash.removeprefix("sha256:")
        response = self.transport.invoke(
            method=method.upper(), path=path, query=query_record, body=body,
            actor=self.actor, correlation_id=correlation_id,
            idempotency_key=replay_key,
            timeout=self.timeout_seconds if timeout is None else float(timeout),
        )
        response_hash = self._payload_hash(response.body)
        receipt: Dict[str, Any] = {
            "record_type": "EDKOperationReceipt",
            "schema_version": "1.0.0",
            "profile": EDK_RECEIPT_PROFILE,
            "edk_profile": EDK_PROFILE,
            "transport_profile": self.transport.profile,
            "operation_id": operation_id,
            "method": method.upper(),
            "path": path,
            "request_hash": request_hash,
            "correlation_id": correlation_id,
            "idempotency_key": replay_key,
            "response_status": response.status,
            "response_content_type": response.content_type,
            "response_hash": response_hash,
            "authority": "TRANSPORT_RECEIPT_ONLY",
            "execution_authorized": False,
        }
        receipt["receipt_hash"] = content_hash(receipt)
        self._receipts.append(receipt)
        if not 200 <= response.status < 300:
            error = response.body.get("error", {}) if isinstance(response.body, Mapping) else {}
            raise EDKError(
                str(error.get("message") or f"{operation_id} returned {response.status}"),
                status=response.status,
                category=str(error.get("category") or "APPLICATION_REFUSAL"),
                remedy=str(error.get("remedy") or "inspect the typed response detail"),
                detail=error.get("detail"),
            )
        return response

    def invoke(
        self,
        operation_id: str,
        method: str,
        path: str,
        *,
        body: Optional[Mapping[str, Any]] = None,
        query: Optional[Mapping[str, Any]] = None,
        idempotency_key: Optional[str] = None,
    ) -> Any:
        return self._invoke(
            operation_id, method, path, body=body, query=query,
            idempotency_key=idempotency_key,
        ).body

    def wait_for_job(self, job_id: str, *, timeout_seconds: Optional[float] = None) -> Any:
        deadline = time.monotonic() + (
            self.timeout_seconds if timeout_seconds is None else float(timeout_seconds)
        )
        driver = getattr(self.transport, "drive_job", None)
        if callable(driver):
            driver(job_id)
        path = f"/jobs/{self._path_identifier(job_id)}/result"
        while True:
            response = self._invoke("getJobResult", "GET", path)
            if response.status != 202:
                return response.body
            if time.monotonic() >= deadline:
                raise EDKError(
                    f"job {job_id} did not complete before the EDK timeout",
                    status=408,
                    category="JOB_TIMEOUT",
                    remedy="poll the durable job later or cancel it through the existing API",
                    detail={"job_id": job_id},
                )
            time.sleep(self.poll_interval_seconds)

    def _long_running(
        self,
        operation_id: str,
        path: str,
        body: Mapping[str, Any],
        *,
        wait: bool,
        idempotency_key: Optional[str],
    ) -> Any:
        accepted = self._invoke(
            operation_id, "POST", path, body=body, idempotency_key=idempotency_key
        ).body
        if not wait:
            return accepted
        if not isinstance(accepted, Mapping) or not accepted.get("job_id"):
            raise EDKError(
                f"{operation_id} did not return a job identifier",
                category="MALFORMED_APPLICATION_RESPONSE",
            )
        return self.wait_for_job(str(accepted["job_id"]))

    # A2.2 lifecycle conveniences.
    def create_case(self, request: Mapping[str, Any]) -> Any:
        return self.invoke("createCase", "POST", "/cases", body=request)

    def get_case(self, case_id: str) -> Any:
        return self.invoke(
            "getCase", "GET", f"/cases/{self._path_identifier(case_id)}"
        )

    def create_branch(self, case_id: str, request: Mapping[str, Any]) -> Any:
        return self.invoke(
            "createBranch", "POST",
            f"/cases/{self._path_identifier(case_id)}/branches", body=request,
        )

    def publish_lifecycle_record(
        self,
        case_id: str,
        request: Mapping[str, Any],
        *,
        wait: bool = True,
        idempotency_key: Optional[str] = None,
    ) -> Any:
        """Use the established deployment-owned lifecycle authority path.

        The EDK does not accept a trust context, policy, organization, or
        clock override here.  Those remain inputs of the configured
        :class:`crg_server.Application`, exactly as they are for the REST and
        generated-client surfaces.
        """
        return self._long_running(
            "publishLifecycleRecord",
            f"/cases/{self._path_identifier(case_id)}/lifecycle/records",
            request,
            wait=wait,
            idempotency_key=idempotency_key,
        )

    def verify_lifecycle_record(self, request: Mapping[str, Any]) -> Any:
        return self.invoke(
            "verifyLifecycleRecord", "POST", "/lifecycle/records/verify",
            body=request,
        )

    def execute_transition(
        self,
        plan_id: str,
        request: Mapping[str, Any],
        *,
        idempotency_key: Optional[str] = None,
    ) -> Any:
        """Execute only through the deployment's existing transition adapter.

        The returned mapping is the stored ``TransitionRecord`` action,
        postcondition, rollback, or non-execution evidence.  The EDK cannot
        install an executor and cannot turn a semantic assessment into host
        permission.
        """
        return self.invoke(
            "executeTransition", "POST",
            f"/transitions/{self._path_identifier(plan_id)}/execute",
            body=request,
            idempotency_key=idempotency_key,
        )

    def revoke_capability(
        self,
        subject_id: str,
        request: Mapping[str, Any],
        *,
        idempotency_key: Optional[str] = None,
    ) -> Any:
        return self.invoke(
            "revokeCapability", "POST",
            f"/capability-envelopes/{self._path_identifier(subject_id)}/revoke",
            body=request,
            idempotency_key=idempotency_key,
        )

    # A2.4 high-level agent methods: aliases over existing operations.
    def register_candidate(
        self, case_id: str, request: Mapping[str, Any], *, wait: bool = True,
        idempotency_key: Optional[str] = None,
    ) -> Any:
        return self._long_running(
            "importRegistry", f"/cases/{self._path_identifier(case_id)}/import",
            request, wait=wait, idempotency_key=idempotency_key,
        )

    @staticmethod
    def _evidence_request(evidence: Mapping[str, Any]) -> Dict[str, Any]:
        """Translate the canonical EvidenceRecord into the existing typed API input."""
        if evidence.get("record_type") != "etq.evidence_record":
            return dict(evidence)
        uncertainty = dict(evidence.get("U_uncertainty") or {})
        uncertainty.pop("component_order", None)
        provenance = dict(evidence.get("P_provenance") or {})
        provenance.pop("provenance_status", None)
        source_context = dict(evidence.get("C_source_context") or {})
        context_fields = source_context.get("fields")
        if isinstance(context_fields, Mapping):
            source_context["fields"] = sorted(context_fields.items())
        method = dict(evidence.get("M_method") or {})
        method_parameters = method.get("parameters")
        if isinstance(method_parameters, Mapping):
            method["parameters"] = sorted(method_parameters.items())
        request = {
            "evidence_id": evidence.get("evidence_id"),
            "quantity": evidence.get("quantity"),
            "unit": evidence.get("unit"),
            "value": evidence.get("Y_value"),
            "uncertainty": uncertainty,
            "source_context": source_context,
            "method": method,
            "provenance": provenance,
            "validity": evidence.get("V_validity"),
            "access": evidence.get("A_access"),
            "evidence_status": evidence.get("evidence_status"),
            "status": evidence.get("status"),
        }
        for name in ("supersedes", "superseded_by", "scenarios", "notes"):
            if name in evidence:
                request[name] = evidence[name]
        return request

    def attach_evidence(self, evidence: Mapping[str, Any], *, clock: Any = None) -> Any:
        body: Dict[str, Any] = {"evidence": self._evidence_request(evidence)}
        if clock is not None:
            body["clock"] = clock
        return self.invoke("registerEvidence", "POST", "/evidence", body=body)

    def verify_open_tool_output(
        self,
        *,
        definition: Mapping[str, Any],
        output: Mapping[str, Any],
        original_source: bytes,
        normalized_source: bytes,
    ) -> Dict[str, Any]:
        """Independently verify one caller-supplied, bounded open-tool export."""
        result = verify_source_adapter_output(
            output,
            definition,
            original_source=original_source,
            normalized_source=normalized_source,
        )
        if not result.ok:
            raise EDKError(
                "open-tool source-adapter output failed independent verification",
                status=422,
                category="SOURCE_ADAPTER_VERIFICATION_FAILED",
                remedy="supply the exact definition, original bytes, normalized bytes, and output",
                detail=result.to_json(),
            )
        return {
            "source_adapter_output": dict(output),
            "source_adapter_output_hash": content_hash(dict(output)),
            "definition_hash": content_hash(dict(definition)),
            "original_source_hash": "sha256:" + hashlib.sha256(original_source).hexdigest(),
            "normalized_source_hash": "sha256:" + hashlib.sha256(normalized_source).hexdigest(),
            "verification": result.to_json(),
            "evidence_class": "IMPORTED",
            "completeness_basis": output.get("completeness_basis"),
            "authorization_effect": "NONE",
            "commitment_authorized": False,
            "source_truth_established": False,
            "originating_server_contacted": False,
        }

    def attach_source_adapter_evidence(
        self,
        *,
        definition: Mapping[str, Any],
        output: Mapping[str, Any],
        original_source: bytes,
        normalized_source: bytes,
        evidence: Mapping[str, Any],
        clock: Any = None,
    ) -> Dict[str, Any]:
        """Verify a source-adapter output, then use the existing evidence API.

        The evidence provenance must bind the exact adapter output.  This
        keeps the open-tool contribution typed and portable while preserving
        the established evidence permission and non-authorizing boundary.
        """
        observation = self.verify_open_tool_output(
            definition=definition,
            output=output,
            original_source=original_source,
            normalized_source=normalized_source,
        )
        method = evidence.get("M_method")
        provenance = evidence.get("P_provenance")
        if not isinstance(method, Mapping) or method.get("evidence_class") != "IMPORTED":
            raise EDKError(
                "source-adapter evidence must remain IMPORTED",
                status=422,
                category="SOURCE_ADAPTER_AUTHORITY_ELEVATION_REFUSED",
            )
        chain = provenance.get("chain") if isinstance(provenance, Mapping) else None
        if not isinstance(chain, Sequence) or isinstance(chain, (str, bytes)) or (
            observation["source_adapter_output_hash"] not in chain
        ):
            raise EDKError(
                "evidence provenance does not bind the verified source-adapter output",
                status=422,
                category="SOURCE_ADAPTER_EVIDENCE_BINDING_MISSING",
            )
        registered = self.attach_evidence(evidence, clock=clock)
        return {
            "source_adapter": observation,
            "evidence_registration": registered,
            "authorization_effect": "NONE",
            "commitment_authorized": False,
        }

    def request_assessment(
        self,
        case_id: str,
        *,
        assessment_id: str,
        commitment_event: Mapping[str, Any],
        semantic_inputs: Sequence[Mapping[str, Any]],
        context_roots: Mapping[str, Any],
        validity: Mapping[str, Any],
        disagreement: Mapping[str, Any],
        limitations: Sequence[str] = (),
    ) -> Any:
        return self.invoke(
            "requestAssessment", "POST",
            f"/cases/{self._path_identifier(case_id)}/assessments",
            body={
                "assessment_id": assessment_id,
                "commitment_event": dict(commitment_event),
                "semantic_inputs": [dict(item) for item in semantic_inputs],
                "context_roots": dict(context_roots),
                "validity": dict(validity),
                "disagreement": dict(disagreement),
                "limitations": list(limitations),
            },
        )

    def generate_family(
        self, case_id: str, request: Mapping[str, Any], *, wait: bool = True,
        idempotency_key: Optional[str] = None,
    ) -> Any:
        """Run any registered reference-pack request through the canonical job path."""
        return self._long_running(
            "generateFamily", f"/cases/{self._path_identifier(case_id)}/generate",
            request, wait=wait, idempotency_key=idempotency_key,
        )

    def build_geometry(
        self, case_id: str, request: Mapping[str, Any] | None = None, *,
        wait: bool = True, idempotency_key: Optional[str] = None,
    ) -> Any:
        """Construct exact R/Gamma/K through the existing application producer."""
        return self._long_running(
            "buildGeometry", f"/cases/{self._path_identifier(case_id)}/geometry",
            dict(request or {}), wait=wait, idempotency_key=idempotency_key,
        )

    def compile_query(self, case_id: str, query: Mapping[str, Any]) -> Any:
        """Compile a decision query to its minimum sufficient CRG object."""
        return self.invoke(
            "compileQuery", "POST",
            f"/cases/{self._path_identifier(case_id)}/queries/compile",
            body={"query": dict(query)},
        )

    def prune_design_space(
        self, request: Mapping[str, Any], *, wait: bool = True,
        idempotency_key: Optional[str] = None,
    ) -> Any:
        """Return a verified, non-mutating reduced compiler design space."""
        return self._long_running(
            "pruneDesignSpace", "/design-spaces/prune", request,
            wait=wait, idempotency_key=idempotency_key,
        )

    def design_space_capabilities(self) -> Any:
        """Discover the exact closed agent design-space profile and limits."""
        return self.invoke(
            "getDesignSpaceCapabilities", "GET", "/design-spaces/capabilities"
        )

    def verify_design_space_remote(self, result: Mapping[str, Any]) -> Any:
        """Verify a portable result through the server's independent boundary."""
        return self.invoke(
            "verifyDesignSpace", "POST", "/design-spaces/verify",
            body={"result": dict(result)},
        )

    def prune_design_spaces(
        self, requests: Sequence[Mapping[str, Any]], *, wait: bool = True,
        idempotency_key: Optional[str] = None,
    ) -> Any:
        """Evaluate a bounded all-or-nothing batch through one durable job."""
        return self._long_running(
            "pruneDesignSpaceBatch", "/design-spaces/prune-batch",
            {"requests": [dict(item) for item in requests]},
            wait=wait, idempotency_key=idempotency_key,
        )

    @staticmethod
    def verify_design_space(result: Mapping[str, Any]) -> Dict[str, Any]:
        """Run the code-separated portable verifier without contacting a server."""
        from crg_verify import verify_agent_design_space

        return verify_agent_design_space(result).to_json()

    def propose_reduction(
        self, case_id: str, request: Mapping[str, Any], *, wait: bool = True,
        idempotency_key: Optional[str] = None,
    ) -> Any:
        return self._long_running(
            "previewCommitment",
            f"/cases/{self._path_identifier(case_id)}/commitments/preview",
            request, wait=wait, idempotency_key=idempotency_key,
        )

    def request_commit(
        self, case_id: str, request: Mapping[str, Any], *, wait: bool = True,
        idempotency_key: Optional[str] = None,
    ) -> Any:
        return self._long_running(
            "compareCommitment",
            f"/cases/{self._path_identifier(case_id)}/commitments",
            request, wait=wait, idempotency_key=idempotency_key,
        )

    def apply_change(
        self, case_id: str, request: Mapping[str, Any], *, wait: bool = True,
        idempotency_key: Optional[str] = None,
    ) -> Any:
        return self._long_running(
            "classifyChange", f"/cases/{self._path_identifier(case_id)}/changes",
            request, wait=wait, idempotency_key=idempotency_key,
        )

    def query_reopen(
        self, case_id: str, request: Mapping[str, Any], *, wait: bool = True,
        idempotency_key: Optional[str] = None,
    ) -> Any:
        return self._long_running(
            "previewChange",
            f"/cases/{self._path_identifier(case_id)}/changes/preview",
            request, wait=wait, idempotency_key=idempotency_key,
        )

    def acknowledge_result(self, event: Mapping[str, Any]) -> Any:
        if event.get("event_type") != "acknowledgement.recorded":
            raise ValueError("acknowledge_result requires an acknowledgement.recorded AgentEvent")
        return self.invoke(
            "ingestAgentEvent", "POST", "/agent-events", body={"event": dict(event)}
        )

    def ingest_agent_event(self, event: Mapping[str, Any]) -> Any:
        return self.invoke(
            "ingestAgentEvent", "POST", "/agent-events", body={"event": dict(event)}
        )

    def transaction_receipt(self, transaction_id: str) -> Any:
        return self.invoke(
            "getAgentTransactionReceipt", "GET",
            f"/agent-transactions/{self._path_identifier(transaction_id)}",
        )

    def register_agent_grant(self, grant: Mapping[str, Any]) -> Any:
        return self.invoke(
            "registerAgentGrant", "POST", "/agent-grants", body={"grant": dict(grant)}
        )

    def revoke_agent_grant(self, agent_id: str) -> Any:
        return self.invoke(
            "revokeAgentGrant", "POST",
            f"/agent-grants/{self._path_identifier(agent_id)}/revoke",
        )

    def submit_agent_proposal(
        self, proposal: Mapping[str, Any], event: Mapping[str, Any]
    ) -> Any:
        return self.invoke(
            "submitAgentProposal", "POST", "/agent-proposals",
            body={"proposal": dict(proposal), "event": dict(event)},
        )

    def reconcile_agent_conflict(
        self,
        conflict_id: str,
        *,
        selected_proposal_id: str | None,
        resolution_authority: str,
        rationale: str,
    ) -> Any:
        return self.invoke(
            "reconcileAgentConflict", "POST",
            f"/agent-conflicts/{self._path_identifier(conflict_id)}/reconcile",
            body={
                "selected_proposal_id": selected_proposal_id,
                "resolution_authority": resolution_authority,
                "rationale": rationale,
            },
        )

    def verify_portable_artifact(
        self, artifact: bytes | Mapping[str, Any], *, level: str = "V3",
        clock: Any = None, clock_source: str = "none-supplied",
    ) -> Any:
        body = dict(artifact) if isinstance(artifact, Mapping) else {
            "bundle_base64": base64.b64encode(artifact).decode("ascii")
        }
        body.update({"level": level, "clock_source": clock_source})
        if clock is not None:
            body["clock"] = clock
        return self.invoke("verifyBundle", "POST", "/bundles/verify", body=body)

    def export_portable_artifact(
        self, case_id: str, *, version: Optional[str] = None, authority: str = ""
    ) -> bytes:
        response = self._invoke(
            "exportBundle", "GET",
            f"/bundles/{self._path_identifier(case_id)}/export",
            query={"version": version, "authority": authority},
        )
        if not isinstance(response.body, bytes):
            raise EDKError(
                "portable export did not return bytes",
                category="MALFORMED_APPLICATION_RESPONSE",
            )
        return response.body
