"""Asynchronous job semantics: what a job records, and what a failure denies.

Normative basis: 42.4 (job semantics), 38.3 (long-running actions MUST return
a job identifier), 42.2 (a local worker process), 23.2 (solver trust
profiles), 47.1 (reproducibility).

Specification 42.4 enumerates thirteen things every job MUST record, and
:class:`JobRecord` has one field per item -- canonical inputs, engine
versions, resource limits, start and completion, status, logs, outputs,
failure category, retry history, cancellation, determinism status, solver
trust profile, and proof artifacts.  They are recorded because a certificate
is only as reproducible as the run that produced it (47.1): "it worked when I
ran it" is not an engine version, and "it failed" is not a failure category.

The load-bearing sentence is the last one: *a failed job MUST NOT produce a
valid certificate unless a separately valid partial-result pathway exists.*
That is enforced in two places that cannot be bypassed by ordering:

1. a job body returns a :class:`JobResult`; nothing it computed is committed
   to the store until the body has returned normally *and* the resource
   limits have been checked; and
2. :meth:`crg_server.store.CaseStore.register_certificate` refuses any job
   whose status is not ``SUCCEEDED``, so even a caller holding the store
   directly cannot register a certificate on behalf of a failed run.

The partial-result pathway 42.4 permits is expressed, not assumed: a job body
may set :attr:`JobResult.partial_pathway` to name the separately valid
pathway, and only then may a failed job commit outputs -- which are recorded
as ``PARTIAL`` and never as certificates.

The queue can be a local worker (42.2) or the persisted half of an external
worker process (42.3). ``autorun`` starts a background worker; otherwise a
worker calls :meth:`refresh` and :meth:`drain`. The external profile can run
pure bodies in a child process whose process group is killed at the recorded
wall limit, so a timed-out computation cannot later commit. Queued records and
replay payloads are recovered from the store on restart, while a submission-only
server sets ``recover_interrupted=False`` so it never steals a running job.
"""
from __future__ import annotations

import multiprocessing
import os
import signal
import time
import threading
import traceback
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Mapping, Optional, Sequence, Tuple

from crg_model.canonical import canonical_json, content_hash
from crg_model.envelope import new_object_id, utc_now
from crg_model.numeric import SolverTrustProfile

from .errors import ConflictError, NotFoundError, ServiceUnavailableError, UsageError

__all__ = [
    "JobStatus",
    "FailureCategory",
    "DeterminismStatus",
    "DEFAULT_RESOURCE_LIMITS",
    "ENGINE_VERSIONS",
    "JobContext",
    "JobResult",
    "JobRecord",
    "JobQueue",
]


class JobStatus:
    """Specification 42.4."""

    QUEUED = "QUEUED"
    RUNNING = "RUNNING"
    SUCCEEDED = "SUCCEEDED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"

    TERMINAL = frozenset({SUCCEEDED, FAILED, CANCELLED})


class FailureCategory:
    """Why a job failed, kept distinct because the remedies are distinct.

    ``INPUT_INVALID`` is the caller's; ``ENGINE_ERROR`` is ours;
    ``RESOURCE_LIMIT`` is the deployment's; ``DEPENDENCY_UNAVAILABLE`` is a
    redaction or a missing object; ``UNSUPPORTED_PROFILE`` is an honest
    refusal to pretend a profile is implemented (48.2); ``BLOCKED`` is a
    decision that refused, which is a result and not a fault.  Collapsing
    these into one "error" would leave an operator retrying a request that can
    never succeed, or escalating one that only needed a larger limit.
    """

    INPUT_INVALID = "INPUT_INVALID"
    ENGINE_ERROR = "ENGINE_ERROR"
    RESOURCE_LIMIT = "RESOURCE_LIMIT"
    DEPENDENCY_UNAVAILABLE = "DEPENDENCY_UNAVAILABLE"
    UNSUPPORTED_PROFILE = "UNSUPPORTED_PROFILE"
    CANCELLED = "CANCELLED"

    ALL = frozenset(
        {
            INPUT_INVALID,
            ENGINE_ERROR,
            RESOURCE_LIMIT,
            DEPENDENCY_UNAVAILABLE,
            UNSUPPORTED_PROFILE,
            CANCELLED,
        }
    )


class DeterminismStatus:
    """Specification 42.4, with 23.2 and 47.1 behind it."""

    DETERMINISTIC = "DETERMINISTIC"
    REPLAY_BOUND = "REPLAY_BOUND"
    NONDETERMINISTIC = "NONDETERMINISTIC"
    UNDECLARED = "UNDECLARED"


#: 42.4 requires resource limits to be recorded.  They are recorded *and*
#: checked; an unenforced limit is documentation.
DEFAULT_RESOURCE_LIMITS: Dict[str, Any] = {
    "max_wall_seconds": 60,
    "max_output_objects": 1024,
    "max_input_bytes": 8 * 1024 * 1024,
}

#: 42.4 requires engine versions.  These are the versions that actually ran,
#: read from the packages themselves rather than restated here, so a bumped
#: module cannot leave a stale claim in a job record.
def _module_version(name: str) -> str:
    try:
        module = __import__(name)
    except ImportError:  # pragma: no cover - module set is fixed in this repo
        return "absent"
    return str(getattr(module, "__version__", "unknown"))


ENGINE_VERSIONS: Dict[str, str] = {
    name: _module_version(name)
    for name in (
        "crg_model",
        "crg_generate",
        "crg_geometry",
        "crg_certify",
        "crg_change",
        "crg_convert",
        "crg_io",
        "crg_verify",
        "etq_evidence",
        "etq_qualify",
        "etq_federation",
        "crg_feedback",
    )
}


class IsolatedExecutionError(RuntimeError):
    """A child process exited without returning a valid job result."""

    def __init__(self, message: str, *, child_type: str = "") -> None:
        super().__init__(message)
        self.child_type = str(child_type)


class IsolatedTimeoutError(IsolatedExecutionError):
    """The hard wall-clock boundary terminated the job process group."""


class IsolatedCancellationError(IsolatedExecutionError):
    """An accepted cancellation terminated the isolated job process group."""


@dataclass
class JobContext:
    """What a job body is handed.

    ``log`` is the job's own log (42.4); writing to it is the only side effect
    a body should have besides returning a :class:`JobResult`.
    """

    job_id: str
    case_id: Optional[str]
    store: Any
    inputs: Mapping[str, Any]
    resource_limits: Mapping[str, Any]
    actor: str
    correlation_id: str
    logs: List[str] = field(default_factory=list)

    def log(self, message: str) -> None:
        self.logs.append(f"{utc_now()} {message}")


@dataclass
class JobResult:
    """What a job body returns.

    ``objects`` and ``certificates`` are *proposals*.  The queue commits them
    only after the run has been judged successful, which is what makes 42.4's
    prohibition structural rather than conventional.
    """

    outputs: Dict[str, Any] = field(default_factory=dict)
    objects: List[Tuple[str, Any]] = field(default_factory=list)
    certificates: List[Mapping[str, Any]] = field(default_factory=list)
    dependencies: List[Any] = field(default_factory=list)
    events: List[Dict[str, Any]] = field(default_factory=list)
    case: Optional[Mapping[str, Any]] = None
    affirmative: bool = True
    blocked_outcome: Optional[str] = None
    proof_artifacts: List[Dict[str, Any]] = field(default_factory=list)
    determinism_status: str = DeterminismStatus.DETERMINISTIC
    solver_trust_profile: str = SolverTrustProfile.EXACT_RECOMPUTED
    #: 42.4's escape hatch, spelled out.  A failed job may commit outputs only
    #: when a separately valid partial-result pathway is named here, and even
    #: then never a certificate.
    partial_pathway: Optional[str] = None


def _isolated_body_entry(
    sender: Any,
    body: Callable[[JobContext], JobResult],
    context_fields: Mapping[str, Any],
) -> None:
    """Execute one pure job body in a new process group and report once."""
    try:
        if hasattr(os, "setsid"):
            os.setsid()
        context = JobContext(store=None, **dict(context_fields))
        result = body(context)
        sender.send(("ok", result, list(context.logs)))
    except BaseException as error:  # noqa: BLE001 - the parent classifies it
        sender.send((
            "error",
            type(error).__name__,
            str(error),
            traceback.format_exc(limit=8),
            list(context.logs),
        ))
    finally:
        sender.close()


def _terminate_process_group(process: Any) -> None:
    """Kill a timed-out job and any subprocesses it created."""
    if process.pid and hasattr(os, "killpg"):
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except (ProcessLookupError, PermissionError, OSError):
            process.kill()
    else:  # pragma: no cover - non-POSIX fallback is rejected at construction
        process.kill()
    process.join(timeout=5)


@dataclass
class JobRecord:
    """One job with every item specification 42.4 requires."""

    job_id: str
    kind: str
    case_id: Optional[str]
    branch_id: Optional[str]
    canonical_inputs: Dict[str, Any]
    input_hash: str
    engine_versions: Dict[str, str]
    resource_limits: Dict[str, Any]
    actor: str
    correlation_id: str
    status: str = JobStatus.QUEUED
    submitted_at: str = field(default_factory=utc_now)
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    logs: List[str] = field(default_factory=list)
    outputs: Dict[str, Any] = field(default_factory=dict)
    failure_category: Optional[str] = None
    failure_detail: Optional[str] = None
    retry_history: List[Dict[str, Any]] = field(default_factory=list)
    cancellation: Optional[Dict[str, Any]] = None
    determinism_status: str = DeterminismStatus.DETERMINISTIC
    solver_trust_profile: str = SolverTrustProfile.EXACT_RECOMPUTED
    proof_artifacts: List[Dict[str, Any]] = field(default_factory=list)
    affirmative: bool = True
    blocked_outcome: Optional[str] = None
    object_hashes: List[str] = field(default_factory=list)
    certificate_ids: List[str] = field(default_factory=list)
    wall_seconds: Optional[str] = None
    partial_pathway: Optional[str] = None
    # Internal publication phase.  The public status remains one of 42.4's
    # five states; this field makes the RUNNING -> publish boundary explicit
    # so cancellation and commit can be ordered atomically across processes.
    execution_phase: Optional[str] = None

    def __post_init__(self) -> None:
        if self.execution_phase is None:
            if self.status == JobStatus.QUEUED:
                self.execution_phase = "QUEUED"
            elif self.status == JobStatus.RUNNING:
                self.execution_phase = "EXECUTING"
            else:
                self.execution_phase = "TERMINAL"

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "job_id": self.job_id,
            "kind": self.kind,
            "case_id": self.case_id,
            "branch_id": self.branch_id,
            "canonical_inputs": self.canonical_inputs,
            "input_hash": self.input_hash,
            "engine_versions": dict(self.engine_versions),
            "resource_limits": dict(self.resource_limits),
            "actor": self.actor,
            "correlation_id": self.correlation_id,
            "status": self.status,
            "submitted_at": self.submitted_at,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "logs": list(self.logs),
            "outputs": dict(self.outputs),
            "failure_category": self.failure_category,
            "failure_detail": self.failure_detail,
            "retry_history": list(self.retry_history),
            "cancellation": self.cancellation,
            "determinism_status": self.determinism_status,
            "solver_trust_profile": self.solver_trust_profile,
            "proof_artifacts": list(self.proof_artifacts),
            "affirmative": self.affirmative,
            "blocked_outcome": self.blocked_outcome,
            "object_hashes": list(self.object_hashes),
            "certificate_ids": list(self.certificate_ids),
            "wall_seconds": self.wall_seconds,
            "partial_pathway": self.partial_pathway,
            "execution_phase": self.execution_phase,
        }

    @property
    def succeeded(self) -> bool:
        return self.status == JobStatus.SUCCEEDED


class JobQueue:
    """A local worker over a persisted job table (spec 42.2, 42.4)."""

    def __init__(
        self,
        store: Any,
        *,
        autorun: bool = False,
        resource_limits: Optional[Mapping[str, Any]] = None,
        events: Any = None,
        recover_interrupted: bool = True,
        isolate_bodies: bool = False,
        in_process_kinds: Sequence[str] = (),
    ) -> None:
        self.store = store
        self.autorun = autorun
        self.resource_limits = dict(resource_limits or DEFAULT_RESOURCE_LIMITS)
        self.events = events
        self.isolate_bodies = bool(isolate_bodies)
        self.in_process_kinds = frozenset(str(kind) for kind in in_process_kinds)
        if self.isolate_bodies and "fork" not in multiprocessing.get_all_start_methods():
            raise UsageError(
                "isolated job execution requires the POSIX fork start method",
                remedy="run crg-worker on the supported Linux/macOS deployment profile",
            )
        self._records: Dict[str, JobRecord] = {}
        self._bodies: Dict[str, Callable[[JobContext], JobResult]] = {}
        self._live_bodies: Dict[str, Callable[[JobContext], JobResult]] = {}
        self._payloads: Dict[str, Dict[str, Any]] = {}
        self._pending: List[str] = []
        self._lock = threading.RLock()
        self._condition = threading.Condition(self._lock)
        self._worker: Optional[threading.Thread] = None
        self._stopping = False
        # Shutdown is a state transition, not merely a thread join.  Once a
        # deployment begins draining it must refuse every new submission and
        # retry while completing work that it already acknowledged (Gate 5,
        # Gate 8).  This flag never re-opens within a queue instance: a fresh
        # process/queue is the explicit recovery boundary.
        self._accepting = True
        self._draining = False
        #: Number of job bodies actually executed.  An idempotent replay must
        #: not move this; the tests read it rather than inferring from timing.
        self.executions = 0
        self._restore(recover_interrupted=recover_interrupted)

    def _restore(self, *, recover_interrupted: bool) -> None:
        """Recover persisted records; interrupted work becomes queued for replay."""
        if self.store is None or not hasattr(self.store, "list_jobs"):
            return
        for document in self.store.list_jobs():
            record = JobRecord(**document)
            if recover_interrupted and record.status == JobStatus.RUNNING:
                record.retry_history.append({
                    "attempt": len(record.retry_history) + 1,
                    "previous_status": JobStatus.RUNNING,
                    "failure_category": FailureCategory.DEPENDENCY_UNAVAILABLE,
                    "failure_detail": "worker process stopped before completion",
                    "at": utc_now(),
                    "actor": "crg-worker-recovery",
                })
                record.status = JobStatus.QUEUED
                record.execution_phase = "QUEUED"
                record.started_at = None
                record.completed_at = None
                self._persist(record)
            self._records[record.job_id] = record
            payload = self.store.load_job_payload(record.job_id)
            if payload is not None:
                self._payloads[record.job_id] = payload
            if record.status == JobStatus.QUEUED:
                self._pending.append(record.job_id)

    def refresh(self) -> int:
        """Load jobs submitted or completed by another process.

        A poll never treats ``RUNNING`` as interrupted; only the external
        worker that successfully acquired the deployment lease may do that at
        construction. This distinction prevents a submission-only server from
        re-queuing work that a healthy worker is executing.
        """
        if self.store is None or not hasattr(self.store, "list_jobs"):
            return 0
        changed = 0
        documents = self.store.list_jobs()
        with self._condition:
            for document in documents:
                incoming = JobRecord(**document)
                existing = self._records.get(incoming.job_id)
                if existing is not None and existing.to_canonical() == incoming.to_canonical():
                    continue
                self._records[incoming.job_id] = incoming
                payload = self.store.load_job_payload(incoming.job_id)
                if payload is not None:
                    self._payloads[incoming.job_id] = payload
                if incoming.status == JobStatus.QUEUED and incoming.job_id not in self._pending:
                    self._pending.append(incoming.job_id)
                elif incoming.status != JobStatus.QUEUED and incoming.job_id in self._pending:
                    self._pending.remove(incoming.job_id)
                changed += 1
            if changed:
                self._condition.notify_all()
        return changed

    def register(self, kind: str, body: Callable[[JobContext], JobResult]) -> None:
        """Register the replayable body for a persisted job kind."""
        if not kind or not callable(body):
            raise UsageError("a job body registration needs a kind and callable")
        with self._lock:
            self._bodies[str(kind)] = body

    def start_worker(self) -> None:
        """Start the background local worker exactly once."""
        with self._condition:
            if self._worker is not None and self._worker.is_alive():
                self._condition.notify_all()
                return
            self._stopping = False
            self._worker = threading.Thread(
                target=self._worker_loop,
                name="crg-local-worker",
                daemon=True,
            )
            self._worker.start()
            self._condition.notify_all()

    def stop_worker(self, *, timeout: float = 5.0) -> None:
        """Stop the worker without waiting for accepted queued work.

        This remains the forced/legacy primitive.  Production entry points use
        :meth:`graceful_shutdown`, which first closes admission and waits for
        acknowledged work to reach a terminal state.
        """
        with self._condition:
            self._stopping = True
            self._condition.notify_all()
            worker = self._worker
        if worker is not None and worker is not threading.current_thread():
            worker.join(timeout=max(0.0, timeout))

    @property
    def worker_alive(self) -> bool:
        with self._lock:
            return self._worker is not None and self._worker.is_alive()

    @property
    def accepting(self) -> bool:
        """Whether this process may acknowledge a new job."""
        with self._lock:
            return bool(self._accepting)

    @property
    def draining(self) -> bool:
        """Whether admission is closed for graceful shutdown."""
        with self._lock:
            return bool(self._draining)

    def begin_drain(self) -> Dict[str, Any]:
        """Close admission atomically and expose the current drain state.

        Existing queued/running work is untouched.  A background worker keeps
        consuming the queue; once the last accepted job finishes it exits
        instead of waiting for work that can no longer arrive.
        """
        with self._condition:
            self._accepting = False
            self._draining = True
            self._condition.notify_all()
            return self._drain_snapshot_unlocked()

    def _drain_snapshot_unlocked(self) -> Dict[str, Any]:
        running = sorted(
            record.job_id for record in self._records.values()
            if record.status == JobStatus.RUNNING
        )
        return {
            "accepting": bool(self._accepting),
            "draining": bool(self._draining),
            "pending_jobs": tuple(self._pending),
            "running_jobs": tuple(running),
            "worker_alive": bool(self._worker and self._worker.is_alive()),
        }

    def drain_snapshot(self) -> Dict[str, Any]:
        """Return a bounded, content-free operational drain snapshot."""
        self.refresh()
        with self._lock:
            return self._drain_snapshot_unlocked()

    def graceful_shutdown(
        self,
        *,
        timeout: float = 30.0,
        finish_pending: bool = True,
    ) -> Dict[str, Any]:
        """Close admission and wait boundedly for acknowledged work.

        ``finish_pending`` is true for an embedded worker: every job this
        process acknowledged is completed before exit when the grace budget
        permits.  A submission-only external API sets it false because the
        durable queue belongs to independent workers; it waits only for a
        locally running body (normally none) and leaves queued records intact.

        The returned record is truthful even on timeout.  No running thread is
        claimed stopped merely because the grace budget expired.
        """
        budget = float(timeout)
        if budget < 0:
            raise UsageError("graceful shutdown timeout must be non-negative")
        self.begin_drain()
        deadline = time.monotonic() + budget
        drained = False
        with self._condition:
            while True:
                running = any(
                    record.status == JobStatus.RUNNING
                    for record in self._records.values()
                )
                pending = bool(self._pending) if finish_pending else False
                if not running and not pending:
                    drained = True
                    break
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    break
                # Store-backed state may be completed by another process and
                # not signal this condition; bounded polling keeps that seam
                # observable without a busy loop.
                self._condition.wait(timeout=min(remaining, 0.05))
                if str(getattr(self, "execution_mode", "")) == "external":
                    self.refresh()
            self._stopping = True
            self._condition.notify_all()
            worker = self._worker
        remaining = max(0.0, deadline - time.monotonic())
        if worker is not None and worker is not threading.current_thread():
            worker.join(timeout=remaining)
        with self._lock:
            snapshot = self._drain_snapshot_unlocked()
            snapshot.update({
                "drained": bool(drained),
                "finish_pending": bool(finish_pending),
                "timeout_seconds": budget,
            })
            return snapshot

    def _worker_loop(self) -> None:
        while True:
            with self._condition:
                while not self._pending and not self._stopping:
                    if self._draining:
                        return
                    self._condition.wait()
                if self._stopping:
                    return
                job_id = self._pending[0]
            try:
                self.run(job_id)
            except Exception as error:  # noqa: BLE001 - contain worker infrastructure faults
                # ``run`` categorizes body failures itself.  This boundary is
                # for infrastructure failures that occur before that guarded
                # body region (for example a persistence/CAS fault).  One bad
                # transition must not kill the sole local worker and strand
                # every subsequently acknowledged job in QUEUED.
                try:
                    record = self.get(job_id)
                    if record.status not in JobStatus.TERMINAL:
                        self._fail(
                            record,
                            _category_for(error),
                            f"{type(error).__name__}: {error}",
                            trace=traceback.format_exc(limit=6),
                        )
                except Exception:  # noqa: BLE001 - persistence may still be unavailable
                    with self._condition:
                        if job_id not in self._pending:
                            self._pending.append(job_id)
                        self._condition.notify_all()
                    # Bound retries during a persistent local-store failure.
                    time.sleep(0.05)

    # -- submission ---------------------------------------------------------
    def submit(
        self,
        kind: str,
        body: Callable[[JobContext], JobResult],
        *,
        canonical_inputs: Mapping[str, Any],
        actor: str,
        correlation_id: str,
        case_id: Optional[str] = None,
        branch_id: Optional[str] = None,
        resource_limits: Optional[Mapping[str, Any]] = None,
        determinism_status: str = DeterminismStatus.DETERMINISTIC,
        solver_trust_profile: str = SolverTrustProfile.EXACT_RECOMPUTED,
        _payload: Optional[Mapping[str, Any]] = None,
    ) -> JobRecord:
        """Enqueue a job and return its record (spec 38.3).

        The identifier exists before any work does, which is the whole point:
        an endpoint can answer immediately with something the caller can poll,
        and a client never has to hold a connection open across a computation
        whose duration is a property of the case rather than of the API.

        ``canonical_inputs`` is what 42.4 records; ``_payload`` is what the
        body actually receives.  They differ in exactly one respect: the
        record has had signing material removed (44.4) and carries the case by
        reference rather than by value, so a job record is safe to export.
        """
        if not kind:
            raise UsageError("a job must declare its kind (42.4)")
        inputs = dict(canonical_inputs)
        record = JobRecord(
            job_id=new_object_id("job"),
            kind=kind,
            case_id=case_id,
            branch_id=branch_id,
            canonical_inputs=inputs,
            input_hash=content_hash(inputs),
            engine_versions=dict(ENGINE_VERSIONS),
            resource_limits=dict(resource_limits or self.resource_limits),
            actor=actor,
            correlation_id=correlation_id,
            determinism_status=determinism_status,
            solver_trust_profile=solver_trust_profile,
        )
        payload = dict(_payload) if _payload is not None else inputs
        input_limit = record.resource_limits.get("max_input_bytes")
        input_bytes = len(canonical_json(payload).encode("utf-8"))
        if input_limit is not None and input_bytes > int(input_limit):
            raise UsageError(
                f"job replay payload is {input_bytes} bytes; limit is {input_limit}",
                remedy="reduce the request or select an explicitly reviewed larger worker profile",
            )
        with self._condition:
            if not self._accepting:
                raise ServiceUnavailableError(
                    "the job queue is draining and cannot accept new work",
                    remedy=(
                        "retry against a READY instance after the deployment completes "
                        "its graceful restart"
                    ),
                )
            self._records[record.job_id] = record
            self._bodies[kind] = body
            self._live_bodies[record.job_id] = body
            self._payloads[record.job_id] = payload
            self._pending.append(record.job_id)
            self._persist(record)
            if self.store is not None and hasattr(self.store, "save_job_payload"):
                self.store.save_job_payload(record.job_id, payload)
            self._condition.notify_all()
        if self.autorun:
            self.start_worker()
        return record

    # -- inspection ---------------------------------------------------------
    def get(self, job_id: str) -> JobRecord:
        if self.store is not None and hasattr(self.store, "load_job"):
            document = self.store.load_job(job_id)
            if document is not None:
                with self._lock:
                    incoming = JobRecord(**document)
                    current = self._records.get(job_id)
                    if current is None or current.to_canonical() != incoming.to_canonical():
                        self._records[job_id] = incoming
        with self._lock:
            record = self._records.get(job_id)
        if record is None:
            raise NotFoundError(
                f"no job {job_id!r}",
                remedy="job identifiers are returned by the POST that created the work",
            )
        return record

    def list(self, *, case_id: Optional[str] = None) -> List[JobRecord]:
        self.refresh()
        with self._lock:
            records = sorted(self._records.values(), key=lambda r: (r.submitted_at, r.job_id))
        if case_id is not None:
            records = [r for r in records if r.case_id == case_id]
        return records

    @property
    def pending(self) -> Tuple[str, ...]:
        with self._lock:
            return tuple(self._pending)

    def recoverable(self) -> Tuple[str, ...]:
        """Jobs an external claimant may attempt to acquire.

        ``RUNNING`` is included because a session-scoped claim, not the JSON
        status alone, distinguishes healthy execution from a worker whose
        process died.  A claimant must acquire the store's per-job lock before
        calling :meth:`run` with ``recover_running=True``.
        """
        self.refresh()
        with self._lock:
            return tuple(
                record.job_id
                for record in sorted(
                    self._records.values(), key=lambda r: (r.submitted_at, r.job_id)
                )
                if record.status in {JobStatus.QUEUED, JobStatus.RUNNING}
            )

    # -- execution ----------------------------------------------------------
    def drain(self) -> List[JobRecord]:
        """Run every queued job, oldest first.  The local worker (42.2)."""
        finished: List[JobRecord] = []
        while self.pending:
            finished.append(self.run(self.pending[0]))
        return finished

    def run(self, job_id: str, *, recover_running: bool = False) -> JobRecord:
        with self._lock:
            record = self.get(job_id)
            if record.status == JobStatus.RUNNING:
                if not recover_running:
                    return record
                if record.execution_phase == "COMMITTING":
                    # The prior process may have written an object or even a
                    # certificate before dying.  Replaying blindly could
                    # duplicate a successor or bless an uncertain commit.
                    # Withdraw any certificate registrations and terminate
                    # the record for explicit operator reconciliation.
                    if self.store is not None and hasattr(
                        self.store, "unregister_certificates"
                    ):
                        self.store.unregister_certificates(job_id)
                    candidate = JobRecord(**record.to_canonical())
                    candidate.status = JobStatus.FAILED
                    candidate.execution_phase = "TERMINAL"
                    candidate.failure_category = FailureCategory.ENGINE_ERROR
                    candidate.failure_detail = (
                        "worker stopped during publication; certificate registrations were "
                        "withdrawn and any content-addressed orphan must be reconciled"
                    )
                    candidate.completed_at = utc_now()
                    candidate.affirmative = False
                    candidate.outputs = {}
                    candidate.object_hashes = []
                    candidate.certificate_ids = []
                    if self._compare_and_set(
                        candidate,
                        expected_statuses=(JobStatus.RUNNING,),
                        expected_phase="COMMITTING",
                    ):
                        return candidate
                    return self.get(job_id)
                candidate = JobRecord(**record.to_canonical())
                candidate.retry_history.append({
                    "attempt": len(record.retry_history) + 1,
                    "previous_status": JobStatus.RUNNING,
                    "failure_category": FailureCategory.DEPENDENCY_UNAVAILABLE,
                    "failure_detail": "prior worker session ended before completion",
                    "at": utc_now(),
                    "actor": "crg-worker-session-recovery",
                })
                candidate.status = JobStatus.QUEUED
                candidate.execution_phase = "QUEUED"
                candidate.started_at = None
                candidate.completed_at = None
                if not self._compare_and_set(
                    candidate,
                    expected_statuses=(JobStatus.RUNNING,),
                    expected_phase="EXECUTING",
                ):
                    return self.get(job_id)
                record = candidate
            if job_id in self._pending:
                self._pending.remove(job_id)
            if record.status == JobStatus.CANCELLED:
                return record
            if record.status in JobStatus.TERMINAL:
                return record
            body = self._live_bodies.get(job_id) or self._bodies.get(record.kind)
        if body is None:
            return self._fail(record, FailureCategory.ENGINE_ERROR, "no job body registered")

        candidate = JobRecord(**record.to_canonical())
        candidate.status = JobStatus.RUNNING
        candidate.execution_phase = "EXECUTING"
        candidate.started_at = utc_now()
        if not self._compare_and_set(
            candidate,
            expected_statuses=(JobStatus.QUEUED,),
            expected_phase="QUEUED",
        ):
            # A cancellation or another worker won the durable transition.
            # Never execute from a stale in-memory QUEUED record.
            return self.get(job_id)
        record = candidate
        context = JobContext(
            job_id=job_id,
            case_id=record.case_id,
            store=self.store,
            inputs=self._payloads.get(job_id, record.canonical_inputs),
            resource_limits=record.resource_limits,
            actor=record.actor,
            correlation_id=record.correlation_id,
        )
        started = time.monotonic()
        self.executions += 1
        try:
            if self.isolate_bodies and record.kind not in self.in_process_kinds:
                result = self._run_isolated(body, context)
            else:
                result = body(context)
        except IsolatedCancellationError:
            record.logs.extend(context.logs)
            current = self.get(job_id)
            if current.status == JobStatus.CANCELLED:
                return current
            return self._fail(
                record,
                FailureCategory.ENGINE_ERROR,
                "isolated execution was terminated without a durable cancellation",
            )
        except IsolatedTimeoutError as error:
            record.logs.extend(context.logs)
            return self._fail(record, FailureCategory.RESOURCE_LIMIT, str(error))
        except Exception as error:  # noqa: BLE001 - every failure is categorized
            record.logs.extend(context.logs)
            return self._fail(
                record,
                _category_for(error),
                f"{type(error).__name__}: {error}",
                trace=traceback.format_exc(limit=6),
            )
        elapsed = time.monotonic() - started
        record.logs.extend(context.logs)
        record.wall_seconds = f"{elapsed:.6f}"

        if not isinstance(result, JobResult):  # pragma: no cover - internal contract
            return self._fail(
                record, FailureCategory.ENGINE_ERROR, "job body did not return a JobResult"
            )

        limit = record.resource_limits.get("max_wall_seconds")
        if limit is not None and elapsed > float(limit):
            return self._fail(
                record,
                FailureCategory.RESOURCE_LIMIT,
                f"wall time {elapsed:.3f}s exceeded the declared limit of {limit}s",
            )
        object_limit = record.resource_limits.get("max_output_objects")
        if object_limit is not None and len(result.objects) > int(object_limit):
            return self._fail(
                record,
                FailureCategory.RESOURCE_LIMIT,
                f"{len(result.objects)} output objects exceeded the declared limit "
                f"of {object_limit}",
            )

        # Atomically close the cancellation window before publishing any
        # object, successor case, dependency edge, event, or certificate.
        # A cancellation that wins first leaves a terminal CANCELLED record;
        # a cancellation after this claim receives 409 because publication is
        # already committed to proceeding.
        candidate = JobRecord(**record.to_canonical())
        candidate.execution_phase = "COMMITTING"
        if not self._compare_and_set(
            candidate,
            expected_statuses=(JobStatus.RUNNING,),
            expected_phase="EXECUTING",
        ):
            return self.get(job_id)
        record = candidate

        # -- commit, and only now ------------------------------------------
        #
        # Order matters and is not incidental.  Objects and the successor case
        # version are written first; certificates are registered last, so a
        # conflict on the case version (16.1 optimistic locking) fails the job
        # *before* any certificate becomes visible.  If a commit step raises
        # after the status was set, the certificate registrations this job
        # made are withdrawn, which keeps 42.4's prohibition true even under a
        # partial commit.
        record.status = JobStatus.SUCCEEDED
        record.determinism_status = result.determinism_status
        record.solver_trust_profile = result.solver_trust_profile
        record.proof_artifacts = list(result.proof_artifacts)
        record.affirmative = bool(result.affirmative)
        record.blocked_outcome = result.blocked_outcome
        record.outputs = dict(result.outputs)
        payload = self._payloads.get(job_id, {})
        try:
            for object_id, obj in result.objects:
                digest = self.store.put_object(obj, created_by=record.actor)
                record.object_hashes.append(digest)
                record.outputs.setdefault("object_hashes", {})[object_id] = digest
            if result.case is not None:
                case_hash = self.store.put_case(
                    result.case,
                    expected_parent_version=payload.get("expected_parent_version"),
                    created_by=record.actor,
                )
                record.outputs["case_hash"] = case_hash
                record.outputs["case_version"] = self.store.head_version(
                    str(result.case["case_id"])
                )
            if result.dependencies:
                self.store.record_edges(result.dependencies, case_id=record.case_id)
            for certificate in result.certificates:
                self.store.register_certificate(str(record.case_id), certificate, job=record)
                record.certificate_ids.append(str(certificate.get("certificate_id")))
        except Exception as error:  # noqa: BLE001 - a failed commit is a failed job
            self.store.unregister_certificates(job_id)
            return self._fail(
                record, _category_for(error), f"commit failed: {type(error).__name__}: {error}"
            )
        record.completed_at = utc_now()
        record.execution_phase = "TERMINAL"
        self._persist(record)
        self._emit_events(record, result)
        return record

    def _run_isolated(
        self, body: Callable[[JobContext], JobResult], context: JobContext
    ) -> JobResult:
        """Run a pure computation behind an enforced process boundary.

        The child receives no store handle, so it cannot commit partial state.
        Only the parent commits the returned :class:`JobResult`, after all
        limits pass.  A timeout kills the child's process group and therefore
        cannot later race a successful commit.
        """
        maximum = float(context.resource_limits.get("max_wall_seconds", 60))
        if maximum <= 0:
            raise IsolatedTimeoutError(
                f"hard wall time limit {maximum}s is not positive; job was not started"
            )
        fork = multiprocessing.get_context("fork")
        receiver, sender = fork.Pipe(duplex=False)
        fields = {
            "job_id": context.job_id,
            "case_id": context.case_id,
            "inputs": dict(context.inputs),
            "resource_limits": dict(context.resource_limits),
            "actor": context.actor,
            "correlation_id": context.correlation_id,
        }
        process = fork.Process(
            target=_isolated_body_entry,
            args=(sender, body, fields),
            name=f"crg-job-{context.job_id}",
        )
        process.start()
        sender.close()
        deadline = time.monotonic() + maximum
        message: Optional[Tuple[Any, ...]] = None
        while message is None:
            if self._durably_cancelled(context.job_id):
                _terminate_process_group(process)
                receiver.close()
                raise IsolatedCancellationError(
                    "the accepted cancellation terminated the job process group"
                )
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                _terminate_process_group(process)
                receiver.close()
                raise IsolatedTimeoutError(
                    f"hard wall time limit of {maximum:g}s exceeded; "
                    "the job process group was terminated"
                )
            if receiver.poll(min(remaining, 0.05)):
                try:
                    message = receiver.recv()
                except EOFError as error:
                    process.join(timeout=1)
                    raise IsolatedExecutionError(
                        f"job child exited {process.exitcode} without a result"
                    ) from error
            elif not process.is_alive():
                process.join(timeout=1)
                raise IsolatedExecutionError(
                    f"job child exited {process.exitcode} without a result"
                )
        receiver.close()
        process.join(timeout=1)
        if process.is_alive():  # message arrived, but a child finalizer is stuck
            _terminate_process_group(process)
            raise IsolatedExecutionError("job child returned but did not exit cleanly")
        if message[0] != "ok":
            _, name, detail, child_trace, logs = message
            context.logs.extend(str(line) for line in logs)
            raise IsolatedExecutionError(
                f"{name}: {detail}\n{child_trace}", child_type=str(name)
            )
        _, result, logs = message
        context.logs.extend(str(line) for line in logs)
        if not isinstance(result, JobResult):
            raise IsolatedExecutionError("job child did not return a JobResult")
        return result

    def _emit_events(self, record: JobRecord, result: JobResult) -> None:
        """Publish the job's declared events (spec 38.5).

        Emitted after the commit, never before: an event that named a
        certificate hash a subscriber could not then fetch would be worse than
        no event at all.
        """
        if self.events is None:
            return
        for event in result.events:
            self.events.emit(
                str(event["event"]),
                actor=record.actor,
                correlation_id=record.correlation_id,
                case_id=record.case_id,
                branch_id=record.branch_id,
                object_hashes=tuple(event.get("object_hashes") or record.object_hashes),
                detail={**dict(event.get("detail") or {}), "job_id": record.job_id},
            )

    def cancel(self, job_id: str, *, reason: str, actor: str) -> JobRecord:
        """Cancel queued work or safely interrupt an isolated running job.

        A cancelled job produces nothing.  It is not a failure of the engine
        and it is not a success, so it carries its own terminal status and its
        own cancellation record naming who cancelled it and why.
        """
        with self._condition:
            record = self.get(job_id)
            if record.status in JobStatus.TERMINAL:
                raise ConflictError(
                    f"job {job_id} is already {record.status}",
                    remedy="a terminal job cannot be cancelled; submit a new one",
                )
            isolated_here = self.isolate_bodies and record.kind not in self.in_process_kinds
            isolated_externally = (
                str(getattr(self, "execution_mode", "")) == "external"
                and record.kind not in self.in_process_kinds
            )
            if record.status == JobStatus.RUNNING and not (
                isolated_here or isolated_externally
            ):
                raise ConflictError(
                    f"job {job_id} is already running",
                    remedy="this job body is not isolated and cannot be interrupted safely; "
                           "use the isolated worker profile",
                )
            if record.status == JobStatus.RUNNING and record.execution_phase != "EXECUTING":
                raise ConflictError(
                    f"job {job_id} has already entered its publication phase",
                    remedy="publication cannot be cancelled atomically; let the job finish and "
                           "supersede or redact its result under policy",
                )
            candidate = JobRecord(**record.to_canonical())
            if job_id in self._pending:
                self._pending.remove(job_id)
            candidate.status = JobStatus.CANCELLED
            previous_phase = str(record.execution_phase)
            candidate.execution_phase = "TERMINAL"
            candidate.failure_category = FailureCategory.CANCELLED
            candidate.cancellation = {"reason": reason, "actor": actor, "at": utc_now()}
            candidate.completed_at = utc_now()
            candidate.affirmative = False
            if not self._compare_and_set(
                candidate,
                expected_statuses=(JobStatus.QUEUED, JobStatus.RUNNING),
                expected_phase=previous_phase,
            ):
                current = self.get(job_id)
                if current.status in JobStatus.TERMINAL:
                    raise ConflictError(
                        f"job {job_id} is already {current.status}",
                        remedy="a terminal job cannot be cancelled; submit a new one",
                    )
                raise ConflictError(
                    f"job {job_id} has already entered its publication phase",
                    remedy="publication cannot be cancelled atomically; let the job finish",
                )
            record = candidate
        return record

    def retry(self, job_id: str, *, actor: str) -> JobRecord:
        """Re-queue a terminal job, preserving its retry history (spec 42.4)."""
        with self._condition:
            if not self._accepting:
                raise ServiceUnavailableError(
                    "the job queue is draining and cannot retry work",
                    remedy="retry against a READY instance after graceful restart",
                )
            record = self.get(job_id)
            if record.status not in JobStatus.TERMINAL:
                raise ConflictError(
                    f"job {job_id} is {record.status}; only a terminal job may be retried"
                )
            record.retry_history.append(
                {
                    "attempt": len(record.retry_history) + 1,
                    "previous_status": record.status,
                    "failure_category": record.failure_category,
                    "failure_detail": record.failure_detail,
                    "at": utc_now(),
                    "actor": actor,
                }
            )
            record.status = JobStatus.QUEUED
            record.execution_phase = "QUEUED"
            record.failure_category = None
            record.failure_detail = None
            record.cancellation = None
            record.started_at = None
            record.completed_at = None
            record.affirmative = True
            record.blocked_outcome = None
            self._pending.append(job_id)
            self._persist(record)
            self._condition.notify_all()
        if self.autorun:
            self.start_worker()
        return record

    # -- internals ----------------------------------------------------------
    def _fail(
        self,
        record: JobRecord,
        category: str,
        detail: str,
        *,
        trace: str = "",
    ) -> JobRecord:
        # An accepted cancellation is authoritative.  An isolated child may
        # report an exception at the same instant the request path cancels it;
        # that race must never resurrect the record as FAILED.
        try:
            current = self.get(record.job_id)
        except NotFoundError:
            current = record
        if current.status == JobStatus.CANCELLED:
            return current
        record.status = JobStatus.FAILED
        record.execution_phase = "TERMINAL"
        record.failure_category = category
        record.failure_detail = detail
        record.completed_at = utc_now()
        record.affirmative = False
        # Nothing is committed.  ``outputs`` stays empty and no certificate is
        # registered, which is 42.4's prohibition observed at the only moment
        # it could be violated.
        record.outputs = {}
        record.object_hashes = []
        record.certificate_ids = []
        if trace:
            record.logs.append(trace.strip())
        self._persist(record)
        return record

    def _persist(self, record: JobRecord) -> None:
        with self._condition:
            if self.store is not None:
                self.store.save_job(record.job_id, record.to_canonical())
            self._records[record.job_id] = record
            self._condition.notify_all()

    def _compare_and_set(
        self,
        record: JobRecord,
        *,
        expected_statuses: Sequence[str],
        expected_phase: str,
    ) -> bool:
        """Atomically replace a persisted job only from the named state."""
        with self._condition:
            if self.store is not None and hasattr(self.store, "compare_and_set_job"):
                changed = bool(self.store.compare_and_set_job(
                    record.job_id,
                    record.to_canonical(),
                    expected_statuses=tuple(expected_statuses),
                    expected_phase=str(expected_phase),
                ))
            else:
                current = self._records.get(record.job_id)
                changed = bool(
                    current is not None
                    and current.status in set(expected_statuses)
                    and current.execution_phase == expected_phase
                )
                if changed and self.store is not None:
                    self.store.save_job(record.job_id, record.to_canonical())
            if changed:
                self._records[record.job_id] = record
                self._condition.notify_all()
            return changed

    def _durably_cancelled(self, job_id: str) -> bool:
        """Read the authoritative record while an isolated child is running."""
        if self.store is not None and hasattr(self.store, "load_job"):
            document = self.store.load_job(job_id)
            return bool(document and document.get("status") == JobStatus.CANCELLED)
        with self._lock:
            record = self._records.get(job_id)
            return bool(record and record.status == JobStatus.CANCELLED)


def _category_for(error: BaseException) -> str:
    """Map an engine exception onto a 42.4 failure category.

    A ``ValueError`` from a kernel module is almost always a rejected input,
    and calling it an engine error would send an operator hunting a bug that
    is not there.  A missing or redacted dependency is separated for the same
    reason: the remedy is to supply the object, not to retry.
    """
    from .errors import (
        BlockedOutcome as _Blocked,
        NotFoundError as _NotFound,
        RedactedError as _Redacted,
        ServerError,
    )

    name = (
        error.child_type
        if isinstance(error, IsolatedExecutionError) and error.child_type
        else type(error).__name__
    )
    if isinstance(error, (_NotFound, _Redacted)):
        return FailureCategory.DEPENDENCY_UNAVAILABLE
    if (
        isinstance(error, _Blocked)
        and error.outcome == "BLOCKED_VERIFIER_DISAGREEMENT"
    ) or name == "BlockedOutcome":
        # Producer/verifier disagreement is our fault, never malformed caller
        # input.  No proposal is published, and operations must investigate
        # the two trust paths before retrying the same request.
        return FailureCategory.ENGINE_ERROR
    if name == "UnsupportedPhaseProfileError":
        return FailureCategory.UNSUPPORTED_PROFILE
    if isinstance(error, ServerError):
        return FailureCategory.INPUT_INVALID
    if name in {"CaseError", "ValueError", "KeyError", "TypeError"} or isinstance(
        error, (ValueError, KeyError, TypeError)
    ):
        return FailureCategory.INPUT_INVALID
    return FailureCategory.ENGINE_ERROR
