"""Local, privacy-preserving operational measurement for CRG workflows.

This module is intentionally outside the CRG case/evidence persistence path.
Its records describe product-operation timing and explicitly declared numeric
observations only.  They cannot become case evidence, mutate a case, or
authorize any CRG state transition.

Capture is disabled unless an ``OperationalMeasurementProfile`` is created
with ``enabled=True``.  The only persistent implementation writes to a
dedicated local directory using content-hashed records and atomic replace;
this module contains no transmission facility or remote storage adapter.

Privacy is enforced structurally rather than by asking callers to remember to
redact arbitrary dictionaries.  There is no free-form payload or metadata
field.  Purpose, scope, metric, unit, and counterfactual-basis values are
bounded codes; actor and session labels must carry the explicit ``psn-``
pseudonym prefix; measured values are exact integers or rational numbers.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import tempfile
import time
from typing import Any, Callable, Dict, Iterable, List, Mapping, Optional, Protocol, Sequence, Tuple


PROFILE_ID = "crg-operational-measurement/local-private@1"
SCHEMA_VERSION = "1.0.0"
EXPORT_FORMAT = "crg-operational-measurement-export@1"
STORE_FORMAT = "crg-operational-measurement-local-store@1"
PERMISSION_DOMAIN = "crg-operational-measurement"
STORE_DOMAIN = "crg-operational-measurement-local"
AUTHORIZATION_EFFECT = "NONE"

PROFILE_SCHEMA_ID = (
    "https://crg.systems/schemas/operational-measurement/1.0.0/"
    "operational-measurement-profile.schema.json"
)
PERMISSION_SCHEMA_ID = (
    "https://crg.systems/schemas/operational-measurement/1.0.0/"
    "operational-measurement-permission.schema.json"
)
EVENT_SCHEMA_ID = (
    "https://crg.systems/schemas/operational-measurement/1.0.0/"
    "operational-measurement-event.schema.json"
)
SESSION_SCHEMA_ID = (
    "https://crg.systems/schemas/operational-measurement/1.0.0/"
    "operational-measurement-session.schema.json"
)
RETENTION_PREVIEW_SCHEMA_ID = (
    "https://crg.systems/schemas/operational-measurement/1.0.0/"
    "operational-measurement-retention-preview.schema.json"
)
DELETION_SCHEMA_ID = (
    "https://crg.systems/schemas/operational-measurement/1.0.0/"
    "operational-measurement-deletion-receipt.schema.json"
)
EXPORT_SCHEMA_ID = (
    "https://crg.systems/schemas/operational-measurement/1.0.0/"
    "operational-measurement-export.schema.json"
)

PROFILE_RECORD_TYPE = "OperationalMeasurementProfile"
PERMISSION_RECORD_TYPE = "OperationalMeasurementPermission"
EVENT_RECORD_TYPE = "OperationalMeasurementEvent"
SESSION_RECORD_TYPE = "OperationalMeasurementSessionRecord"
RETENTION_PREVIEW_RECORD_TYPE = "OperationalMeasurementRetentionPreview"
DELETION_RECORD_TYPE = "OperationalMeasurementDeletionReceipt"
EXPORT_RECORD_TYPE = "OperationalMeasurementExport"

_SCHEMA_IDS = {
    PROFILE_RECORD_TYPE: PROFILE_SCHEMA_ID,
    PERMISSION_RECORD_TYPE: PERMISSION_SCHEMA_ID,
    EVENT_RECORD_TYPE: EVENT_SCHEMA_ID,
    SESSION_RECORD_TYPE: SESSION_SCHEMA_ID,
    RETENTION_PREVIEW_RECORD_TYPE: RETENTION_PREVIEW_SCHEMA_ID,
    DELETION_RECORD_TYPE: DELETION_SCHEMA_ID,
    EXPORT_RECORD_TYPE: EXPORT_SCHEMA_ID,
}

_CODE = re.compile(r"^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$")
_PSEUDONYM = re.compile(r"^psn-[a-z0-9]+(?:-[a-z0-9]+)*$")
_MAX_CODE_LENGTH = 64

DEFAULT_PURPOSE_CODES = (
    "local-product-evaluation",
    "reference-path-evaluation",
    "reliability-evaluation",
    "workflow-timing",
)
DEFAULT_SCOPE_CODES = (
    "declared-operation-set",
    "reference-journey",
    "single-session",
)


class MeasurementError(Exception):
    """Base class for operational-measurement refusal states."""


class MeasurementDisabledError(MeasurementError):
    """Raised before any store access when opt-in capture is disabled."""


class MeasurementPermissionError(MeasurementError):
    """Raised when the separate measurement permission is absent or invalid."""


class MeasurementValidationError(MeasurementError):
    """Raised when a record or caller input is outside the strict profile."""


class MeasurementIntegrityError(MeasurementError):
    """Raised when content hashes, hash chains, or summaries do not verify."""


class MeasurementNotFoundError(MeasurementError):
    """Raised when a measurement session is not present in its local store."""


class MeasurementStateError(MeasurementError):
    """Raised for an invalid capture-session state transition."""


class MeasurementGrant:
    CAPTURE = "CAPTURE"
    READ = "READ"
    EXPORT = "EXPORT"
    DELETE = "DELETE"
    RETENTION = "RETENTION"
    ALL = frozenset({CAPTURE, READ, EXPORT, DELETE, RETENTION})


class MeasurementClass:
    SYSTEM_DERIVED = "SYSTEM_DERIVED"
    LOCAL_OBSERVATION = "LOCAL_OBSERVATION"
    USER_DECLARED_COUNTERFACTUAL = "USER_DECLARED_COUNTERFACTUAL"
    ALL = frozenset({
        SYSTEM_DERIVED,
        LOCAL_OBSERVATION,
        USER_DECLARED_COUNTERFACTUAL,
    })


class EventType:
    SESSION_START = "SESSION_START"
    ACTIVE_START = "ACTIVE_START"
    ACTIVE_END = "ACTIVE_END"
    COMPUTE_START = "COMPUTE_START"
    COMPUTE_END = "COMPUTE_END"
    WAIT_START = "WAIT_START"
    WAIT_END = "WAIT_END"
    METRIC = "METRIC"
    SESSION_END = "SESSION_END"
    ALL = frozenset({
        SESSION_START,
        ACTIVE_START,
        ACTIVE_END,
        COMPUTE_START,
        COMPUTE_END,
        WAIT_START,
        WAIT_END,
        METRIC,
        SESSION_END,
    })


_INTERVAL_EVENTS = {
    "active": (EventType.ACTIVE_START, EventType.ACTIVE_END),
    "compute": (EventType.COMPUTE_START, EventType.COMPUTE_END),
    "wait": (EventType.WAIT_START, EventType.WAIT_END),
}


def _reject_constant(value: str) -> None:
    raise MeasurementValidationError(f"non-finite JSON number {value!r} is forbidden")


def _pairs(pairs: Sequence[Tuple[str, Any]]) -> Dict[str, Any]:
    result: Dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise MeasurementValidationError(f"duplicate JSON key {key!r}")
        result[key] = value
    return result


def _loads(document: str) -> Any:
    try:
        return json.loads(
            document,
            object_pairs_hook=_pairs,
            parse_constant=_reject_constant,
        )
    except MeasurementValidationError:
        raise
    except (TypeError, ValueError, json.JSONDecodeError) as error:
        raise MeasurementValidationError("measurement JSON is malformed") from error


def _canonical_bytes(value: Any) -> bytes:
    try:
        return json.dumps(
            value,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
            allow_nan=False,
        ).encode("utf-8")
    except (TypeError, ValueError) as error:
        raise MeasurementValidationError(
            "measurement records must contain canonical JSON values"
        ) from error


def _digest(value: Any) -> str:
    return "sha256:" + hashlib.sha256(_canonical_bytes(value)).hexdigest()


def _seal(value: Mapping[str, Any]) -> Dict[str, Any]:
    if "content_hash" in value:
        raise MeasurementValidationError("content_hash is computed, not caller supplied")
    result = dict(value)
    result["content_hash"] = _digest(result)
    return result


def _verify_seal(value: Mapping[str, Any], *, label: str) -> Dict[str, Any]:
    if not isinstance(value, Mapping):
        raise MeasurementValidationError(f"{label} must be a JSON object")
    supplied = value.get("content_hash")
    if not isinstance(supplied, str) or not supplied.startswith("sha256:"):
        raise MeasurementIntegrityError(f"{label} has no valid content_hash")
    unsigned = dict(value)
    del unsigned["content_hash"]
    expected = _digest(unsigned)
    if supplied != expected:
        raise MeasurementIntegrityError(f"{label} content hash mismatch")
    return dict(value)


def _header(record_type: str) -> Dict[str, Any]:
    return {
        "record_type": record_type,
        "schema_id": _SCHEMA_IDS[record_type],
        "schema_version": SCHEMA_VERSION,
        "profile_id": PROFILE_ID,
    }


def _validate_header(value: Mapping[str, Any], record_type: str) -> None:
    expected = _header(record_type)
    for key, required in expected.items():
        if value.get(key) != required:
            raise MeasurementValidationError(
                f"{record_type} {key} must be {required!r}"
            )


def _code(value: str, label: str) -> str:
    text = str(value or "")
    if len(text) > _MAX_CODE_LENGTH or not _CODE.fullmatch(text):
        raise MeasurementValidationError(
            f"{label} must be a lower-case, hyphen-delimited code of at most "
            f"{_MAX_CODE_LENGTH} characters"
        )
    return text


def _pseudonym(value: str, label: str) -> str:
    text = str(value or "")
    if len(text) > _MAX_CODE_LENGTH or not _PSEUDONYM.fullmatch(text):
        raise MeasurementValidationError(
            f"{label} must be an explicit safe pseudonymous label beginning 'psn-'"
        )
    return text


def _codes(values: Iterable[str], label: str) -> Tuple[str, ...]:
    normalized = tuple(sorted({_code(value, label) for value in values}))
    if not normalized:
        raise MeasurementValidationError(f"{label} must not be empty")
    return normalized


def _instant(value: Any, label: str) -> datetime:
    if isinstance(value, datetime):
        parsed = value
    else:
        text = str(value or "")
        try:
            parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
        except ValueError as error:
            raise MeasurementValidationError(
                f"{label} must be an ISO-8601 timestamp with an explicit timezone"
            ) from error
    if parsed.tzinfo is None:
        raise MeasurementValidationError(f"{label} must include an explicit timezone")
    return parsed.astimezone(timezone.utc)


def _timestamp(value: Any, label: str) -> str:
    parsed = _instant(value, label)
    return parsed.isoformat(timespec="microseconds").replace("+00:00", "Z")


def _exact_int(value: Any, label: str, *, nonnegative: bool = False) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise MeasurementValidationError(f"{label} must be an exact integer")
    if nonnegative and value < 0:
        raise MeasurementValidationError(f"{label} must be non-negative")
    return value


def _record_header_and_hash(value: Mapping[str, Any], record_type: str) -> Dict[str, Any]:
    verified = _verify_seal(value, label=record_type)
    _validate_header(verified, record_type)
    return verified


@dataclass(frozen=True)
class OperationalMeasurementProfile:
    """Explicit opt-in profile for the isolated local measurement plane."""

    enabled: bool = False
    retention_seconds: Optional[int] = None
    allowed_purpose_codes: Tuple[str, ...] = DEFAULT_PURPOSE_CODES
    allowed_scope_codes: Tuple[str, ...] = DEFAULT_SCOPE_CODES
    local_only: bool = True
    phone_home: bool = False
    store_domain: str = STORE_DOMAIN
    permission_domain: str = PERMISSION_DOMAIN
    authorization_effect: str = AUTHORIZATION_EFFECT

    def __post_init__(self) -> None:
        if type(self.enabled) is not bool:
            raise MeasurementValidationError("enabled must be a boolean")
        if self.local_only is not True or self.phone_home is not False:
            raise MeasurementValidationError(
                "the supported measurement profile is local-only with phone_home=false"
            )
        if self.store_domain != STORE_DOMAIN:
            raise MeasurementValidationError("measurement store domain is fixed and separate")
        if self.permission_domain != PERMISSION_DOMAIN:
            raise MeasurementValidationError(
                "measurement permission domain is fixed and separate"
            )
        if self.authorization_effect != AUTHORIZATION_EFFECT:
            raise MeasurementValidationError("measurement authorization_effect must be NONE")
        if self.retention_seconds is not None:
            _exact_int(self.retention_seconds, "retention_seconds", nonnegative=True)
        object.__setattr__(
            self,
            "allowed_purpose_codes",
            _codes(self.allowed_purpose_codes, "purpose code"),
        )
        object.__setattr__(
            self,
            "allowed_scope_codes",
            _codes(self.allowed_scope_codes, "scope code"),
        )

    def to_record(self) -> Dict[str, Any]:
        return _seal({
            **_header(PROFILE_RECORD_TYPE),
            "enabled": self.enabled,
            "local_only": True,
            "phone_home": False,
            "store_domain": STORE_DOMAIN,
            "permission_domain": PERMISSION_DOMAIN,
            "authorization_effect": AUTHORIZATION_EFFECT,
            "evidence_eligible": False,
            "retention_seconds": self.retention_seconds,
            "allowed_purpose_codes": list(self.allowed_purpose_codes),
            "allowed_scope_codes": list(self.allowed_scope_codes),
        })


@dataclass(frozen=True)
class OperationalMeasurementPermission:
    """Capability in the measurement-only permission domain.

    ``subject_label`` is deliberately a pseudonym, not a person/account
    identity.  Application identity mapping, if desired, stays outside this
    record and outside exported measurements.
    """

    subject_label: str
    grants: Tuple[str, ...] = field(default_factory=tuple)
    domain: str = PERMISSION_DOMAIN

    def __post_init__(self) -> None:
        object.__setattr__(self, "subject_label", _pseudonym(
            self.subject_label, "permission subject_label"
        ))
        normalized = tuple(sorted(set(str(grant) for grant in self.grants)))
        unknown = set(normalized) - set(MeasurementGrant.ALL)
        if unknown:
            raise MeasurementValidationError(
                f"unknown measurement grants: {sorted(unknown)}"
            )
        if not normalized:
            raise MeasurementValidationError("at least one measurement grant is required")
        if self.domain != PERMISSION_DOMAIN:
            raise MeasurementValidationError(
                "permissions from another domain cannot authorize measurement operations"
            )
        object.__setattr__(self, "grants", normalized)

    def to_record(self) -> Dict[str, Any]:
        return _seal({
            **_header(PERMISSION_RECORD_TYPE),
            "domain": PERMISSION_DOMAIN,
            "subject_label": self.subject_label,
            "grants": list(self.grants),
            "case_authority": False,
            "evidence_authority": False,
        })


class OperationalMeasurementStore(Protocol):
    """Minimal local-only store interface, separate from the CRG case store."""

    domain: str
    local_only: bool

    def put_session(self, session: Mapping[str, Any]) -> None: ...
    def get_session(self, session_id: str) -> Dict[str, Any]: ...
    def list_session_ids(self) -> List[str]: ...
    def delete_session(self, session_id: str) -> None: ...


class MemoryOperationalMeasurementStore:
    """Process-local implementation useful for embedded and ephemeral use."""

    domain = STORE_DOMAIN
    local_only = True

    def __init__(self) -> None:
        self._documents: Dict[str, bytes] = {}

    def put_session(self, session: Mapping[str, Any]) -> None:
        verified = _verify_session(session)
        self._documents[str(verified["session_id"])] = _canonical_bytes(verified)

    def get_session(self, session_id: str) -> Dict[str, Any]:
        key = _pseudonym(session_id, "session_id")
        try:
            raw = self._documents[key].decode("utf-8")
        except KeyError as error:
            raise MeasurementNotFoundError(f"measurement session {key!r} not found") from error
        except UnicodeDecodeError as error:
            raise MeasurementIntegrityError("stored measurement is not UTF-8 JSON") from error
        value = _loads(raw)
        return _verify_session(value)

    def list_session_ids(self) -> List[str]:
        return sorted(self._documents)

    def delete_session(self, session_id: str) -> None:
        key = _pseudonym(session_id, "session_id")
        if key not in self._documents:
            raise MeasurementNotFoundError(f"measurement session {key!r} not found")
        del self._documents[key]


def _atomic_write(path: Path, payload: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=str(path.parent)
    )
    temporary = Path(temporary_name)
    try:
        os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
        try:
            directory = os.open(path.parent, os.O_RDONLY)
        except OSError:
            return
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        if temporary.exists():
            temporary.unlink()


class LocalOperationalMeasurementStore:
    """Crash-safe local filesystem store dedicated to measurement records."""

    domain = STORE_DOMAIN
    local_only = True
    _MARKER = ".crg-operational-measurement-store.json"

    def __init__(self, root: str | os.PathLike[str]) -> None:
        self.root = Path(root).expanduser().resolve()
        if self.root.exists() and not self.root.is_dir():
            raise MeasurementValidationError("measurement store root must be a directory")
        self.root.mkdir(parents=True, exist_ok=True, mode=0o700)
        self._sessions = self.root / "sessions"
        self._sessions.mkdir(exist_ok=True, mode=0o700)
        marker = self.root / self._MARKER
        expected = _canonical_bytes({"format": STORE_FORMAT, "domain": STORE_DOMAIN}) + b"\n"
        if marker.exists():
            try:
                actual = marker.read_bytes()
            except OSError as error:
                raise MeasurementIntegrityError("cannot read measurement store marker") from error
            if actual != expected:
                raise MeasurementIntegrityError(
                    "local path belongs to an unknown or incompatible storage domain"
                )
        else:
            unrelated = [item.name for item in self.root.iterdir() if item != self._sessions]
            unrelated.extend(
                f"sessions/{item.name}" for item in self._sessions.iterdir()
            )
            if unrelated:
                raise MeasurementValidationError(
                    "refusing to initialize measurement storage in a non-empty unmarked directory"
                )
            _atomic_write(marker, expected)

    def _path(self, session_id: str) -> Path:
        return self._sessions / f"{_pseudonym(session_id, 'session_id')}.json"

    def put_session(self, session: Mapping[str, Any]) -> None:
        verified = _verify_session(session)
        _atomic_write(
            self._path(str(verified["session_id"])),
            _canonical_bytes(verified) + b"\n",
        )

    def get_session(self, session_id: str) -> Dict[str, Any]:
        path = self._path(session_id)
        try:
            raw = path.read_text(encoding="utf-8")
        except FileNotFoundError as error:
            raise MeasurementNotFoundError(
                f"measurement session {session_id!r} not found"
            ) from error
        except UnicodeDecodeError as error:
            raise MeasurementIntegrityError("stored measurement is not UTF-8 JSON") from error
        return _verify_session(_loads(raw))

    def list_session_ids(self) -> List[str]:
        result: List[str] = []
        for path in sorted(self._sessions.glob("*.json")):
            name = path.name[:-5]
            _pseudonym(name, "stored session_id")
            result.append(name)
        return result

    def delete_session(self, session_id: str) -> None:
        path = self._path(session_id)
        try:
            path.unlink()
        except FileNotFoundError as error:
            raise MeasurementNotFoundError(
                f"measurement session {session_id!r} not found"
            ) from error
        try:
            directory = os.open(self._sessions, os.O_RDONLY)
        except OSError:
            return
        try:
            os.fsync(directory)
        finally:
            os.close(directory)


def _verify_profile_record(value: Mapping[str, Any]) -> Dict[str, Any]:
    profile = _record_header_and_hash(value, PROFILE_RECORD_TYPE)
    expected_keys = {
        "record_type", "schema_id", "schema_version", "profile_id", "content_hash",
        "enabled", "local_only", "phone_home", "store_domain", "permission_domain",
        "authorization_effect", "evidence_eligible", "retention_seconds",
        "allowed_purpose_codes", "allowed_scope_codes",
    }
    if set(profile) != expected_keys:
        raise MeasurementValidationError("measurement profile has unknown or missing fields")
    rebuilt = OperationalMeasurementProfile(
        enabled=profile.get("enabled"),
        retention_seconds=profile.get("retention_seconds"),
        allowed_purpose_codes=tuple(profile.get("allowed_purpose_codes") or ()),
        allowed_scope_codes=tuple(profile.get("allowed_scope_codes") or ()),
        local_only=profile.get("local_only"),
        phone_home=profile.get("phone_home"),
        store_domain=str(profile.get("store_domain") or ""),
        permission_domain=str(profile.get("permission_domain") or ""),
        authorization_effect=str(profile.get("authorization_effect") or ""),
    ).to_record()
    if profile.get("evidence_eligible") is not False or rebuilt != profile:
        raise MeasurementValidationError("measurement profile invariants are invalid")
    return profile


def _metric_payload(
    *,
    metric_code: str,
    numerator: int,
    denominator: int,
    unit_code: str,
    measurement_class: str,
    basis_code: Optional[str] = None,
) -> Dict[str, Any]:
    if measurement_class not in MeasurementClass.ALL:
        raise MeasurementValidationError(
            f"unknown measurement_class {measurement_class!r}"
        )
    numerator = _exact_int(numerator, "metric numerator")
    denominator = _exact_int(denominator, "metric denominator")
    if denominator <= 0:
        raise MeasurementValidationError("metric denominator must be positive")
    result: Dict[str, Any] = {
        "measurement_class": measurement_class,
        "metric_code": _code(metric_code, "metric_code"),
        "exact_value": {"numerator": numerator, "denominator": denominator},
        "unit_code": _code(unit_code, "unit_code"),
        "authorizing": False,
        "evidence_eligible": False,
        "claim_boundary": "operational-measurement-only",
    }
    if measurement_class == MeasurementClass.USER_DECLARED_COUNTERFACTUAL:
        result.update({
            "basis_code": _code(str(basis_code or ""), "counterfactual basis_code"),
            "counterfactual_status": "USER_DECLARED_UNVERIFIED",
            "roi_inferred": False,
            "savings_inferred": False,
            "superiority_inferred": False,
        })
    elif basis_code is not None:
        raise MeasurementValidationError(
            "basis_code is reserved for user-declared counterfactuals"
        )
    return result


def _event(
    *,
    session_id: str,
    sequence: int,
    event_type: str,
    observed_at: str,
    monotonic_ns: int,
    previous_event_hash: str,
    metric: Optional[Mapping[str, Any]] = None,
) -> Dict[str, Any]:
    if event_type not in EventType.ALL:
        raise MeasurementValidationError(f"unknown event_type {event_type!r}")
    body: Dict[str, Any] = {
        **_header(EVENT_RECORD_TYPE),
        "session_id": _pseudonym(session_id, "session_id"),
        "sequence": _exact_int(sequence, "event sequence", nonnegative=True),
        "event_type": event_type,
        "observed_at": _timestamp(observed_at, "event observed_at"),
        "monotonic_ns": _exact_int(monotonic_ns, "event monotonic_ns", nonnegative=True),
        "previous_event_hash": str(previous_event_hash),
        "authorizing": False,
        "evidence_eligible": False,
    }
    if event_type == EventType.METRIC:
        if not isinstance(metric, Mapping):
            raise MeasurementValidationError("METRIC event requires a structured metric")
        body["metric"] = dict(metric)
    elif metric is not None:
        raise MeasurementValidationError("only METRIC events may carry a metric")
    return _seal(body)


def _event_durations(events: Sequence[Mapping[str, Any]]) -> Dict[str, int]:
    opened: Dict[str, Optional[int]] = {key: None for key in _INTERVAL_EVENTS}
    totals: Dict[str, int] = {key: 0 for key in _INTERVAL_EVENTS}
    for event in events:
        event_type = event["event_type"]
        tick = _exact_int(event["monotonic_ns"], "event monotonic_ns", nonnegative=True)
        for kind, (start_type, end_type) in _INTERVAL_EVENTS.items():
            if event_type == start_type:
                if opened[kind] is not None:
                    raise MeasurementStateError(f"{kind} interval is already open")
                opened[kind] = tick
            elif event_type == end_type:
                start = opened[kind]
                if start is None:
                    raise MeasurementStateError(f"{kind} interval has no matching start")
                if tick < start:
                    raise MeasurementIntegrityError("monotonic clock moved backwards")
                totals[kind] += tick - start
                opened[kind] = None
    totals["open_active"] = int(opened["active"] is not None)
    totals["open_compute"] = int(opened["compute"] is not None)
    totals["open_wait"] = int(opened["wait"] is not None)
    return totals


def _verify_metric(metric: Mapping[str, Any]) -> None:
    expected_keys = {
        "measurement_class", "metric_code", "exact_value", "unit_code",
        "authorizing", "evidence_eligible", "claim_boundary",
    }
    classification = metric.get("measurement_class")
    if classification == MeasurementClass.USER_DECLARED_COUNTERFACTUAL:
        expected_keys.update({
            "basis_code", "counterfactual_status", "roi_inferred",
            "savings_inferred", "superiority_inferred",
        })
    if set(metric) != expected_keys:
        raise MeasurementValidationError(
            "metric has unknown, missing, or privacy-unsafe fields"
        )
    exact = metric.get("exact_value")
    if not isinstance(exact, Mapping) or set(exact) != {"numerator", "denominator"}:
        raise MeasurementValidationError("metric exact_value must be a rational pair")
    rebuilt = _metric_payload(
        metric_code=str(metric.get("metric_code") or ""),
        numerator=exact.get("numerator"),
        denominator=exact.get("denominator"),
        unit_code=str(metric.get("unit_code") or ""),
        measurement_class=str(classification or ""),
        basis_code=(str(metric.get("basis_code") or "")
                    if classification == MeasurementClass.USER_DECLARED_COUNTERFACTUAL
                    else None),
    )
    if dict(metric) != rebuilt:
        raise MeasurementValidationError("metric claim boundary or classification is invalid")


def _verify_event(
    event: Mapping[str, Any], *, session_id: str, sequence: int, previous_hash: str
) -> Dict[str, Any]:
    verified = _record_header_and_hash(event, EVENT_RECORD_TYPE)
    common = {
        "record_type", "schema_id", "schema_version", "profile_id", "content_hash",
        "session_id", "sequence", "event_type", "observed_at", "monotonic_ns",
        "previous_event_hash", "authorizing", "evidence_eligible",
    }
    event_type = verified.get("event_type")
    expected_keys = common | ({"metric"} if event_type == EventType.METRIC else set())
    if set(verified) != expected_keys:
        raise MeasurementValidationError("event has unknown or missing fields")
    if verified.get("session_id") != session_id:
        raise MeasurementIntegrityError("event session_id mismatch")
    if verified.get("sequence") != sequence:
        raise MeasurementIntegrityError("event sequence is not contiguous")
    if verified.get("previous_event_hash") != previous_hash:
        raise MeasurementIntegrityError("event hash chain mismatch")
    if event_type not in EventType.ALL:
        raise MeasurementValidationError("event type is unsupported")
    _timestamp(verified.get("observed_at"), "event observed_at")
    _exact_int(verified.get("monotonic_ns"), "event monotonic_ns", nonnegative=True)
    if verified.get("authorizing") is not False or verified.get("evidence_eligible") is not False:
        raise MeasurementValidationError("measurement events are non-authorizing and non-evidence")
    if event_type == EventType.METRIC:
        metric = verified.get("metric")
        if not isinstance(metric, Mapping):
            raise MeasurementValidationError("metric event has no metric object")
        _verify_metric(metric)
    return verified


def _verify_session(value: Mapping[str, Any]) -> Dict[str, Any]:
    session = _record_header_and_hash(value, SESSION_RECORD_TYPE)
    expected_keys = {
        "record_type", "schema_id", "schema_version", "profile_id", "content_hash",
        "profile_content_hash", "session_id", "actor_label", "purpose_code",
        "scope_code", "status", "started_at", "ended_at", "events",
        "active_time_ns", "compute_time_ns", "wait_time_ns", "local_only",
        "transmission", "store_domain", "permission_domain", "authorizing",
        "evidence_eligible", "case_mutation", "roi_inferred", "savings_inferred",
        "superiority_inferred",
    }
    if set(session) != expected_keys:
        raise MeasurementValidationError("session has unknown or missing fields")
    session_id = _pseudonym(str(session.get("session_id") or ""), "session_id")
    _pseudonym(str(session.get("actor_label") or ""), "actor_label")
    _code(str(session.get("purpose_code") or ""), "purpose_code")
    _code(str(session.get("scope_code") or ""), "scope_code")
    profile_hash = str(session.get("profile_content_hash") or "")
    if not profile_hash.startswith("sha256:"):
        raise MeasurementValidationError("profile_content_hash is required")
    invariants = {
        "local_only": True,
        "transmission": False,
        "store_domain": STORE_DOMAIN,
        "permission_domain": PERMISSION_DOMAIN,
        "authorizing": False,
        "evidence_eligible": False,
        "case_mutation": False,
        "roi_inferred": False,
        "savings_inferred": False,
        "superiority_inferred": False,
    }
    for key, expected in invariants.items():
        if session.get(key) != expected:
            raise MeasurementValidationError(f"measurement session invariant {key} violated")
    events = session.get("events")
    if not isinstance(events, list) or not events:
        raise MeasurementValidationError("measurement session requires explicit events")
    previous = ""
    verified_events: List[Dict[str, Any]] = []
    previous_tick: Optional[int] = None
    for sequence, event in enumerate(events):
        if not isinstance(event, Mapping):
            raise MeasurementValidationError("session event must be an object")
        verified = _verify_event(
            event, session_id=session_id, sequence=sequence, previous_hash=previous
        )
        tick = int(verified["monotonic_ns"])
        if previous_tick is not None and tick < previous_tick:
            raise MeasurementIntegrityError("event monotonic clock moved backwards")
        previous_tick = tick
        previous = str(verified["content_hash"])
        verified_events.append(verified)
    if verified_events[0]["event_type"] != EventType.SESSION_START:
        raise MeasurementIntegrityError("first event must be SESSION_START")
    if any(
        event["event_type"] == EventType.SESSION_START
        for event in verified_events[1:]
    ):
        raise MeasurementIntegrityError("SESSION_START must occur exactly once")
    durations = _event_durations(verified_events)
    status = session.get("status")
    if status == "ACTIVE":
        if any(event["event_type"] == EventType.SESSION_END for event in verified_events):
            raise MeasurementIntegrityError("active session cannot contain SESSION_END")
        if session.get("ended_at") is not None:
            raise MeasurementIntegrityError("active session cannot have ended_at")
    elif status == "CLOSED":
        if verified_events[-1]["event_type"] != EventType.SESSION_END:
            raise MeasurementIntegrityError("closed session must end with SESSION_END")
        if sum(e["event_type"] == EventType.SESSION_END for e in verified_events) != 1:
            raise MeasurementIntegrityError("SESSION_END must occur exactly once")
        if session.get("ended_at") != verified_events[-1]["observed_at"]:
            raise MeasurementIntegrityError("ended_at does not bind the SESSION_END event")
        if any(durations[f"open_{kind}"] for kind in _INTERVAL_EVENTS):
            raise MeasurementIntegrityError("closed session has an open timing interval")
    else:
        raise MeasurementValidationError("session status must be ACTIVE or CLOSED")
    if session.get("started_at") != verified_events[0]["observed_at"]:
        raise MeasurementIntegrityError("started_at does not bind the SESSION_START event")
    for kind in _INTERVAL_EVENTS:
        if session.get(f"{kind}_time_ns") != durations[kind]:
            raise MeasurementIntegrityError(f"{kind} time summary does not match events")
    return session


class OperationalMeasurementRecorder:
    """Governed capture/export/retention façade over a measurement-only store."""

    def __init__(
        self,
        *,
        profile: Optional[OperationalMeasurementProfile] = None,
        store: Optional[OperationalMeasurementStore] = None,
        permission: Optional[OperationalMeasurementPermission] = None,
        wall_clock: Optional[Callable[[], Any]] = None,
        monotonic_clock_ns: Optional[Callable[[], int]] = None,
    ) -> None:
        self.profile = profile or OperationalMeasurementProfile()
        self.store = store or MemoryOperationalMeasurementStore()
        self.permission = permission
        self._wall_clock = wall_clock or (lambda: datetime.now(timezone.utc))
        self._monotonic_clock_ns = monotonic_clock_ns or time.monotonic_ns
        if (
            getattr(self.store, "domain", None) != STORE_DOMAIN
            or getattr(self.store, "local_only", None) is not True
        ):
            raise MeasurementValidationError(
                "operational measurement requires its dedicated local storage domain"
            )

    def _require(self, grant: str) -> None:
        if not self.profile.enabled:
            raise MeasurementDisabledError(
                "operational measurement is off by default; explicit opt-in is required"
            )
        permission = self.permission
        if permission is None or permission.domain != PERMISSION_DOMAIN:
            raise MeasurementPermissionError(
                "a permission from the operational-measurement domain is required"
            )
        if grant not in permission.grants:
            raise MeasurementPermissionError(f"measurement grant {grant} is required")

    def _now(self) -> str:
        return _timestamp(self._wall_clock(), "measurement clock")

    def _tick(self) -> int:
        return _exact_int(
            self._monotonic_clock_ns(), "measurement monotonic clock", nonnegative=True
        )

    def _profile_hash(self) -> str:
        return str(self.profile.to_record()["content_hash"])

    def _read(self, session_id: str, grant: str) -> Dict[str, Any]:
        self._require(grant)
        session = self.store.get_session(session_id)
        if session["profile_content_hash"] != self._profile_hash():
            raise MeasurementIntegrityError(
                "session was captured under a different measurement profile"
            )
        return session

    def start_session(
        self, *, session_id: str, purpose_code: str, scope_code: str
    ) -> Dict[str, Any]:
        self._require(MeasurementGrant.CAPTURE)
        session_id = _pseudonym(session_id, "session_id")
        purpose_code = _code(purpose_code, "purpose_code")
        scope_code = _code(scope_code, "scope_code")
        if purpose_code not in self.profile.allowed_purpose_codes:
            raise MeasurementValidationError("purpose_code is not allowed by the profile")
        if scope_code not in self.profile.allowed_scope_codes:
            raise MeasurementValidationError("scope_code is not allowed by the profile")
        try:
            self.store.get_session(session_id)
        except MeasurementNotFoundError:
            pass
        else:
            raise MeasurementStateError(f"measurement session {session_id!r} already exists")
        now = self._now()
        tick = self._tick()
        event = _event(
            session_id=session_id,
            sequence=0,
            event_type=EventType.SESSION_START,
            observed_at=now,
            monotonic_ns=tick,
            previous_event_hash="",
        )
        permission = self.permission
        if permission is None:  # ``_require`` already refused; narrows the type.
            raise MeasurementPermissionError("measurement permission is required")
        session = _seal({
            **_header(SESSION_RECORD_TYPE),
            "profile_content_hash": self._profile_hash(),
            "session_id": session_id,
            "actor_label": permission.subject_label,
            "purpose_code": purpose_code,
            "scope_code": scope_code,
            "status": "ACTIVE",
            "started_at": now,
            "ended_at": None,
            "events": [event],
            "active_time_ns": 0,
            "compute_time_ns": 0,
            "wait_time_ns": 0,
            "local_only": True,
            "transmission": False,
            "store_domain": STORE_DOMAIN,
            "permission_domain": PERMISSION_DOMAIN,
            "authorizing": False,
            "evidence_eligible": False,
            "case_mutation": False,
            "roi_inferred": False,
            "savings_inferred": False,
            "superiority_inferred": False,
        })
        self.store.put_session(session)
        return dict(session)

    def _append(
        self,
        session_id: str,
        event_type: str,
        *,
        metric: Optional[Mapping[str, Any]] = None,
        close: bool = False,
    ) -> Dict[str, Any]:
        session = self._read(session_id, MeasurementGrant.CAPTURE)
        if session["status"] != "ACTIVE":
            raise MeasurementStateError("measurement session is already closed")
        now = self._now()
        tick = self._tick()
        events = list(session["events"])
        event = _event(
            session_id=str(session["session_id"]),
            sequence=len(events),
            event_type=event_type,
            observed_at=now,
            monotonic_ns=tick,
            previous_event_hash=str(events[-1]["content_hash"]),
            metric=metric,
        )
        proposed_events = events + [event]
        durations = _event_durations(proposed_events)
        if close and any(durations[f"open_{kind}"] for kind in _INTERVAL_EVENTS):
            raise MeasurementStateError(
                "all active, compute, and wait intervals must end before the session ends"
            )
        unsigned = dict(session)
        del unsigned["content_hash"]
        unsigned.update({
            "events": proposed_events,
            "active_time_ns": durations["active"],
            "compute_time_ns": durations["compute"],
            "wait_time_ns": durations["wait"],
        })
        if close:
            unsigned["status"] = "CLOSED"
            unsigned["ended_at"] = now
        updated = _seal(unsigned)
        self.store.put_session(updated)
        return dict(updated)

    def begin_active(self, session_id: str) -> Dict[str, Any]:
        return self._append(session_id, EventType.ACTIVE_START)

    def end_active(self, session_id: str) -> Dict[str, Any]:
        return self._append(session_id, EventType.ACTIVE_END)

    def begin_compute(self, session_id: str) -> Dict[str, Any]:
        return self._append(session_id, EventType.COMPUTE_START)

    def end_compute(self, session_id: str) -> Dict[str, Any]:
        return self._append(session_id, EventType.COMPUTE_END)

    def begin_wait(self, session_id: str) -> Dict[str, Any]:
        return self._append(session_id, EventType.WAIT_START)

    def end_wait(self, session_id: str) -> Dict[str, Any]:
        return self._append(session_id, EventType.WAIT_END)

    def record_observation(
        self,
        session_id: str,
        *,
        metric_code: str,
        numerator: int,
        denominator: int = 1,
        unit_code: str = "count",
        measurement_class: str = MeasurementClass.LOCAL_OBSERVATION,
    ) -> Dict[str, Any]:
        if measurement_class not in {
            MeasurementClass.SYSTEM_DERIVED,
            MeasurementClass.LOCAL_OBSERVATION,
        }:
            raise MeasurementValidationError(
                "observations must be SYSTEM_DERIVED or LOCAL_OBSERVATION"
            )
        metric = _metric_payload(
            metric_code=metric_code,
            numerator=numerator,
            denominator=denominator,
            unit_code=unit_code,
            measurement_class=measurement_class,
        )
        return self._append(session_id, EventType.METRIC, metric=metric)

    def record_counterfactual(
        self,
        session_id: str,
        *,
        metric_code: str,
        numerator: int,
        denominator: int = 1,
        unit_code: str = "count",
        basis_code: str,
    ) -> Dict[str, Any]:
        metric = _metric_payload(
            metric_code=metric_code,
            numerator=numerator,
            denominator=denominator,
            unit_code=unit_code,
            measurement_class=MeasurementClass.USER_DECLARED_COUNTERFACTUAL,
            basis_code=basis_code,
        )
        return self._append(session_id, EventType.METRIC, metric=metric)

    def end_session(self, session_id: str) -> Dict[str, Any]:
        return self._append(session_id, EventType.SESSION_END, close=True)

    def get_session(self, session_id: str) -> Dict[str, Any]:
        return dict(self._read(session_id, MeasurementGrant.READ))

    def list_sessions(self) -> List[Dict[str, Any]]:
        """Return privacy-bounded summaries from the dedicated local store.

        Listing is deliberately part of the measurement permission domain.
        It neither consults nor joins against the case store, and it exposes
        no event payload beyond the already-pseudonymous session identity and
        the sealed timing summary.
        """
        self._require(MeasurementGrant.READ)
        summaries: List[Dict[str, Any]] = []
        for session_id in self.store.list_session_ids():
            session = self.store.get_session(session_id)
            if session["profile_content_hash"] != self._profile_hash():
                raise MeasurementIntegrityError(
                    "session list encountered a record from another measurement profile"
                )
            summaries.append({
                "session_id": session["session_id"],
                "status": session["status"],
                "purpose_code": session["purpose_code"],
                "scope_code": session["scope_code"],
                "started_at": session["started_at"],
                "ended_at": session["ended_at"],
                "active_time_ns": session["active_time_ns"],
                "compute_time_ns": session["compute_time_ns"],
                "wait_time_ns": session["wait_time_ns"],
                "content_hash": session["content_hash"],
            })
        return summaries

    def export_session(
        self, session_id: str, *, destination: Optional[str | os.PathLike[str]] = None
    ) -> str:
        session = self._read(session_id, MeasurementGrant.EXPORT)
        export = _seal({
            **_header(EXPORT_RECORD_TYPE),
            "format": EXPORT_FORMAT,
            "exported_at": self._now(),
            "local_only": True,
            "transmission": False,
            "authorizing": False,
            "evidence_eligible": False,
            "profile": self.profile.to_record(),
            "session": session,
        })
        document = _canonical_bytes(export).decode("utf-8") + "\n"
        # Cross the stateless verifier boundary before returning bytes or
        # touching a destination.  A producer regression must therefore fail
        # before a caller can mistake an unverified file for a portable
        # measurement export.
        verify_operational_measurement_export(document)
        if destination is not None:
            _atomic_write(Path(destination).expanduser().resolve(), document.encode("utf-8"))
        return document

    def preview_retention(
        self,
        *,
        as_of: Optional[Any] = None,
        maximum_age_seconds: Optional[int] = None,
    ) -> Dict[str, Any]:
        self._require(MeasurementGrant.RETENTION)
        age_limit = (
            self.profile.retention_seconds
            if maximum_age_seconds is None
            else maximum_age_seconds
        )
        if age_limit is None:
            raise MeasurementValidationError(
                "retention requires an explicit maximum_age_seconds or profile policy"
            )
        age_limit = _exact_int(age_limit, "maximum_age_seconds", nonnegative=True)
        observed = _timestamp(as_of if as_of is not None else self._wall_clock(), "retention as_of")
        observed_dt = _instant(observed, "retention as_of")
        candidates: List[Dict[str, Any]] = []
        excluded_active = 0
        for session_id in self.store.list_session_ids():
            session = self.store.get_session(session_id)
            if session["profile_content_hash"] != self._profile_hash():
                raise MeasurementIntegrityError(
                    "retention encountered a session from another measurement profile"
                )
            if session["status"] != "CLOSED":
                excluded_active += 1
                continue
            ended_at = str(session["ended_at"])
            delta = observed_dt - _instant(ended_at, "session ended_at")
            age_microseconds = (
                (delta.days * 86400 + delta.seconds) * 1_000_000
                + delta.microseconds
            )
            if age_microseconds < 0:
                raise MeasurementIntegrityError(
                    "retention as_of predates a stored session end time"
                )
            age = age_microseconds // 1_000_000
            if age >= age_limit:
                candidates.append({
                    "session_id": session_id,
                    "session_content_hash": session["content_hash"],
                    "ended_at": ended_at,
                    "age_seconds": age,
                })
        return _seal({
            **_header(RETENTION_PREVIEW_RECORD_TYPE),
            "profile_content_hash": self._profile_hash(),
            "as_of": observed,
            "maximum_age_seconds": age_limit,
            "candidate_count": len(candidates),
            "excluded_active_count": excluded_active,
            "candidates": candidates,
            "action": "DELETE_LOCAL_MEASUREMENT",
            "preview_only": True,
            "authorizing": False,
            "case_mutation": False,
        })

    def enforce_retention(
        self, preview: Mapping[str, Any], *, confirmation_hash: str
    ) -> Dict[str, Any]:
        self._require(MeasurementGrant.RETENTION)
        verified = _record_header_and_hash(preview, RETENTION_PREVIEW_RECORD_TYPE)
        if confirmation_hash != verified["content_hash"]:
            raise MeasurementIntegrityError("retention confirmation hash does not match preview")
        if verified.get("profile_content_hash") != self._profile_hash():
            raise MeasurementIntegrityError("retention preview belongs to another profile")
        expected_keys = {
            "record_type", "schema_id", "schema_version", "profile_id", "content_hash",
            "profile_content_hash", "as_of", "maximum_age_seconds", "candidate_count",
            "excluded_active_count", "candidates", "action", "preview_only",
            "authorizing", "case_mutation",
        }
        if set(verified) != expected_keys:
            raise MeasurementValidationError("retention preview has unknown or missing fields")
        if (
            verified.get("action") != "DELETE_LOCAL_MEASUREMENT"
            or verified.get("preview_only") is not True
            or verified.get("authorizing") is not False
            or verified.get("case_mutation") is not False
        ):
            raise MeasurementValidationError("retention preview invariants are invalid")
        candidates = verified.get("candidates")
        if not isinstance(candidates, list) or verified.get("candidate_count") != len(candidates):
            raise MeasurementValidationError("retention candidate count mismatch")
        # Verify the complete preview again before the first deletion.  This
        # makes enforcement fail closed on tamper, replacement, or clock-policy
        # drift rather than partially applying a stale plan.
        recomputed = self.preview_retention(
            as_of=verified.get("as_of"),
            maximum_age_seconds=verified.get("maximum_age_seconds"),
        )
        if recomputed["content_hash"] != verified["content_hash"]:
            raise MeasurementIntegrityError("retention preview is stale")
        deleted: List[Dict[str, str]] = []
        for candidate in candidates:
            if not isinstance(candidate, Mapping) or set(candidate) != {
                "session_id", "session_content_hash", "ended_at", "age_seconds"
            }:
                raise MeasurementValidationError("retention candidate is malformed")
            session_id = _pseudonym(str(candidate["session_id"]), "retention session_id")
            self.store.delete_session(session_id)
            deleted.append({
                "session_id": session_id,
                "deleted_content_hash": str(candidate["session_content_hash"]),
            })
        return _seal({
            **_header(DELETION_RECORD_TYPE),
            "operation": "RETENTION_ENFORCEMENT",
            "deleted_at": self._now(),
            "preview_content_hash": verified["content_hash"],
            "deleted": deleted,
            "deleted_count": len(deleted),
            "local_only": True,
            "transmission": False,
            "authorizing": False,
            "case_mutation": False,
        })

    def delete_session(
        self, session_id: str, *, expected_content_hash: str
    ) -> Dict[str, Any]:
        session = self._read(session_id, MeasurementGrant.DELETE)
        if expected_content_hash != session["content_hash"]:
            raise MeasurementIntegrityError("expected session content hash does not match")
        self.store.delete_session(session_id)
        return _seal({
            **_header(DELETION_RECORD_TYPE),
            "operation": "EXPLICIT_DELETION",
            "deleted_at": self._now(),
            "preview_content_hash": "",
            "deleted": [{
                "session_id": session_id,
                "deleted_content_hash": session["content_hash"],
            }],
            "deleted_count": 1,
            "local_only": True,
            "transmission": False,
            "authorizing": False,
            "case_mutation": False,
        })


def verify_operational_measurement_export(document: str | bytes) -> Dict[str, Any]:
    """Verify and return a portable export without trusting its producer."""
    if isinstance(document, bytes):
        try:
            text = document.decode("utf-8")
        except UnicodeDecodeError as error:
            raise MeasurementValidationError("measurement export is not UTF-8") from error
    else:
        text = str(document)
    value = _loads(text)
    export = _record_header_and_hash(value, EXPORT_RECORD_TYPE)
    expected_keys = {
        "record_type", "schema_id", "schema_version", "profile_id", "content_hash",
        "format", "exported_at", "local_only", "transmission", "authorizing",
        "evidence_eligible", "profile", "session",
    }
    if set(export) != expected_keys:
        raise MeasurementValidationError("measurement export has unknown or missing fields")
    if export.get("format") != EXPORT_FORMAT:
        raise MeasurementValidationError("measurement export format is unsupported")
    _timestamp(export.get("exported_at"), "exported_at")
    if (
        export.get("local_only") is not True
        or export.get("transmission") is not False
        or export.get("authorizing") is not False
        or export.get("evidence_eligible") is not False
    ):
        raise MeasurementValidationError("measurement export boundary is invalid")
    session = export.get("session")
    if not isinstance(session, Mapping):
        raise MeasurementValidationError("measurement export session is missing")
    profile = export.get("profile")
    if not isinstance(profile, Mapping):
        raise MeasurementValidationError("measurement export profile is missing")
    verified_profile = _verify_profile_record(profile)
    if session.get("profile_content_hash") != verified_profile.get("content_hash"):
        raise MeasurementIntegrityError("exported session does not bind the exported profile")
    _verify_session(session)
    return export


__all__ = [
    "AUTHORIZATION_EFFECT",
    "EXPORT_FORMAT",
    "PERMISSION_DOMAIN",
    "PROFILE_ID",
    "SCHEMA_VERSION",
    "STORE_DOMAIN",
    "MeasurementClass",
    "MeasurementDisabledError",
    "MeasurementError",
    "MeasurementGrant",
    "MeasurementIntegrityError",
    "MeasurementNotFoundError",
    "MeasurementPermissionError",
    "MeasurementStateError",
    "MeasurementValidationError",
    "MemoryOperationalMeasurementStore",
    "LocalOperationalMeasurementStore",
    "OperationalMeasurementPermission",
    "OperationalMeasurementProfile",
    "OperationalMeasurementRecorder",
    "OperationalMeasurementStore",
    "verify_operational_measurement_export",
]
