"""API/job boundary for CRG-ENH-03 comparative workflow evidence.

The producer and independent verifier are deliberately separate packages.
This surface publishes a successor case only after both agree and never
converts a workflow observation into decision authority, ranking, economic
value, or a causal claim.
"""
from __future__ import annotations

from typing import Any, Mapping

import crg_verify
from crg_cli.comparison import (
    ComparativeVerificationError,
    build_verified_comparative_evaluation,
    comparative_verification_inputs,
    persist_comparative_evaluation,
    render_comparative_evaluation_report,
)

from .errors import BlockedOutcome, NotFoundError, UsageError
from .jobs import JobContext, JobResult

__all__ = [
    "op_preview",
    "op_generate",
    "inspect_evaluation",
    "verify_request",
]


def _run(context: JobContext, *, persist: bool) -> JobResult:
    request = context.inputs.get("request") or {}
    case = dict(context.inputs["case"])
    try:
        record, verification = build_verified_comparative_evaluation(request)
    except ComparativeVerificationError as error:
        raise BlockedOutcome(
            "independent comparative-workflow reconstruction disagreed with the producer",
            outcome="BLOCKED_VERIFIER_DISAGREEMENT",
            detail={"message": str(error)},
            remedy="publish nothing; repair and independently test the producer/verifier boundary",
        ) from error
    inputs = comparative_verification_inputs(record)
    report = render_comparative_evaluation_report(record, verification)
    evaluation_id = record["evaluation_id"]
    context.log(
        f"comparative evaluation {evaluation_id} independently reconstructed; "
        f"authority=NON_AUTHORIZING persist={persist}"
    )
    outputs = {
        "preview": not persist,
        "evaluation_id": evaluation_id,
        "record_hash": record["record_hash"],
        "authority": "NON_AUTHORIZING",
        "authorizing": False,
        "semantic_effect": "NONE",
        "evaluation": record,
        "verification_inputs": inputs,
        "verification": verification.to_json(),
        "report": report,
    }
    proof = {
        "proof_type": "COMPARATIVE_WORKFLOW_INDEPENDENT_RECONSTRUCTION",
        "profile": record["profile"],
        "record_hash": record["record_hash"],
        "verifier": "crg-verify",
        "status": verification.status,
        "authority": "NON_AUTHORIZING",
        "semantic_effect": "NONE",
    }
    if not persist:
        return JobResult(outputs=outputs, proof_artifacts=[proof])
    persist_comparative_evaluation(case, record)
    return JobResult(
        outputs=outputs,
        objects=[
            (f"comparative-evaluation:{evaluation_id}", record),
            (f"comparative-verification-inputs:{evaluation_id}", inputs),
        ],
        case=case,
        proof_artifacts=[proof],
    )


def op_preview(context: JobContext) -> JobResult:
    return _run(context, persist=False)


def op_generate(context: JobContext) -> JobResult:
    return _run(context, persist=True)


def _verified_payload(record: Mapping[str, Any]) -> dict:
    verification = crg_verify.verify_comparative_workflow_evaluation(record)
    if not verification.ok:
        raise BlockedOutcome(
            "independent comparative-workflow reconstruction failed",
            outcome="BLOCKED_VERIFICATION_FAILED",
            detail={
                "status": verification.status,
                "violations": list(verification.violations),
            },
            remedy=(
                "do not publish, compare, or rely on this record; recover the exact "
                "canonical producer output and verification input"
            ),
        )
    return {
        "evaluation": dict(record),
        "verification_inputs": comparative_verification_inputs(record),
        "verification": verification.to_json(),
        "report": render_comparative_evaluation_report(record, verification),
        "authority": "NON_AUTHORIZING",
        "authorizing": False,
        "semantic_effect": "NONE",
    }


def inspect_evaluation(case: Mapping[str, Any], evaluation_id: str) -> dict:
    records = case.get("comparative_evaluations") or {}
    if not isinstance(records, Mapping) or evaluation_id not in records:
        raise NotFoundError(
            f"no comparative workflow evaluation {evaluation_id!r} in this case",
            remedy="generate the evaluation or choose an identity listed on the case",
        )
    record = records[evaluation_id]
    if not isinstance(record, Mapping):
        raise UsageError("stored comparative workflow evaluation is not a JSON object")
    payload = _verified_payload(record)
    stored = (case.get("comparative_evaluation_verification_inputs") or {}).get(
        evaluation_id
    )
    if isinstance(stored, Mapping):
        payload["verification_inputs"] = dict(stored)
    return payload


def verify_request(request: Any) -> dict:
    if not isinstance(request, Mapping) or set(request) != {"record"}:
        raise UsageError(
            "comparative verification requires exactly {'record': <ComparativeWorkflowEvaluation>}",
            remedy="pass the canonical portable record without authoring fields or conclusions",
        )
    record = request.get("record")
    if not isinstance(record, Mapping):
        raise UsageError("comparative verification record must be a JSON object")
    return _verified_payload(record)
