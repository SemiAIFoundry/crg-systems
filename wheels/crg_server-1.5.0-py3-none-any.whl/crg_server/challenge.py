"""REST/job boundary for non-authorizing Decision Challenge records."""
from __future__ import annotations

from typing import Any, Mapping

import crg_verify
from crg_cli.challenge import (
    DecisionChallengeVerificationError,
    build_verified_decision_challenge,
    render_decision_challenge_report,
)
from crg_model.canonical import content_hash

from .errors import BlockedOutcome, NotFoundError, UsageError
from .jobs import JobContext, JobResult, JobStatus

__all__ = [
    "op_preview", "op_record", "challenge_inventory",
    "ensure_challenge_available", "inspect_challenge", "verify_request",
]


def _run(context: JobContext, *, persist: bool) -> JobResult:
    request = context.inputs.get("request") or {}
    case = dict(context.inputs["case"])
    try:
        record, verification = build_verified_decision_challenge(request, case)
    except DecisionChallengeVerificationError as error:
        raise BlockedOutcome(
            "independent Decision Challenge replay disagreed with the producer",
            outcome="BLOCKED_VERIFIER_DISAGREEMENT",
            detail={"message": str(error)},
            remedy=(
                "publish nothing; recover the authentic phase and certified-delta "
                "evidence before retrying the non-authorizing preview"
            ),
        ) from error
    challenge_id = record["challenge_id"]
    report = render_decision_challenge_report(record, verification)
    context.log(
        f"Decision Challenge {challenge_id} independently replayed; "
        f"authority=NON_AUTHORIZING mutation=false persist={persist}"
    )
    outputs = {
        "preview": not persist,
        "challenge_id": challenge_id,
        "record_hash": record["record_hash"],
        "authority": "NON_AUTHORIZING",
        "authorizing": False,
        "semantic_effect": "NONE",
        "mutation_performed": False,
        "active_case_head_unchanged": True,
        "challenge": record,
        "verification": verification.to_json(),
        "report": report,
    }
    proof = {
        "proof_type": "DECISION_CHALLENGE_INDEPENDENT_REPLAY",
        "profile": record["profile"],
        "record_hash": record["record_hash"],
        "verifier": "crg-verify",
        "status": verification.status,
        "authority": "NON_AUTHORIZING",
        "authorizing": False,
        "semantic_effect": "NONE",
        "mutation_effect": "NONE",
    }
    if not persist:
        return JobResult(outputs=outputs, proof_artifacts=[proof])
    return JobResult(
        outputs=outputs,
        objects=[(f"decision-challenge:{challenge_id}", record)],
        proof_artifacts=[proof],
    )


def op_preview(context: JobContext) -> JobResult:
    return _run(context, persist=False)


def op_record(context: JobContext) -> JobResult:
    return _run(context, persist=True)


def _verified_payload(record: Mapping[str, Any]) -> dict:
    verification = crg_verify.verify_decision_challenge_record(record)
    if not verification.ok:
        raise BlockedOutcome(
            "independent Decision Challenge replay failed",
            outcome="BLOCKED_VERIFICATION_FAILED",
            detail={
                "status": verification.status,
                "violations": list(verification.violations),
            },
            remedy=(
                "do not rely on this preview; recover the exact canonical record with "
                "its embedded portable phase and certified-delta evidence"
            ),
        )
    value = dict(record)
    return {
        "challenge": value,
        "verification": verification.to_json(),
        "report": render_decision_challenge_report(value, verification),
        "authority": "NON_AUTHORIZING",
        "authorizing": False,
        "semantic_effect": "NONE",
        "mutation_performed": False,
    }


def _recorded_jobs(queue: Any, case_id: str):
    return [
        job for job in queue.list(case_id=case_id)
        if job.kind == "recordDecisionChallenge" and job.status == JobStatus.SUCCEEDED
    ]


def challenge_inventory(queue: Any, case_id: str) -> dict:
    """Read the auxiliary content-addressed ledger represented by durable jobs."""

    records = {}
    hashes = {}
    for job in _recorded_jobs(queue, case_id):
        submitted = job.outputs.get("challenge")
        challenge_id = str(
            submitted.get("challenge_id") if isinstance(submitted, Mapping) else ""
        )
        if not challenge_id:
            continue
        digest = (job.outputs.get("object_hashes") or {}).get(
            f"decision-challenge:{challenge_id}"
        )
        if not isinstance(digest, str) or not digest.startswith("sha256:"):
            raise UsageError(
                f"auxiliary Decision Challenge {challenge_id!r} has no content address"
            )
        store = getattr(queue, "store", None)
        if store is None or not hasattr(store, "get_object"):
            raise UsageError("Decision Challenge ledger has no content-addressed store")
        record = store.get_object(digest)
        if (
            not isinstance(record, Mapping)
            or record.get("record_type") != "DecisionChallengeRecord"
            or record.get("challenge_id") != challenge_id
            or content_hash(record) != digest
        ):
            raise UsageError(
                f"auxiliary Decision Challenge {challenge_id!r} disagrees with its content address"
            )
        if isinstance(submitted, Mapping) and content_hash(submitted) != digest:
            raise UsageError(
                f"auxiliary Decision Challenge {challenge_id!r} disagrees with its durable index"
            )
        previous = records.get(challenge_id)
        if previous is not None and previous != record:
            raise UsageError(
                f"auxiliary Decision Challenge ledger has conflicting identity {challenge_id!r}"
            )
        records[challenge_id] = dict(record)
        hashes[challenge_id] = digest
    return {
        "record_type": "DecisionChallengeLedgerView",
        "case_id": case_id,
        "active_case_head_unchanged": True,
        "authority": "NON_AUTHORIZING",
        "semantic_effect": "NONE",
        "count": len(records),
        "entries": [
            {
                "challenge_id": challenge_id,
                "record_hash": records[challenge_id].get("record_hash"),
                "content_hash": hashes.get(challenge_id),
                "result_status": (records[challenge_id].get("result") or {}).get("status"),
            }
            for challenge_id in sorted(records)
        ],
        "records": records,
    }


def ensure_challenge_available(queue: Any, case_id: str, challenge_id: str) -> None:
    """Reserve one auxiliary identity across queued, running, and stored records."""

    for job in queue.list(case_id=case_id):
        if job.kind != "recordDecisionChallenge" or job.status in {
            JobStatus.FAILED, JobStatus.CANCELLED
        }:
            continue
        request = (job.canonical_inputs or {}).get("request") or {}
        recorded = (job.outputs or {}).get("challenge") or {}
        existing_id = request.get("challenge_id") or recorded.get("challenge_id")
        if existing_id == challenge_id:
            raise UsageError(
                f"Decision Challenge {challenge_id!r} is already reserved or recorded",
                remedy="reuse the original idempotency key or choose a new challenge identity",
            )


def inspect_challenge(queue: Any, case_id: str, challenge_id: str) -> dict:
    records = challenge_inventory(queue, case_id)["records"]
    if challenge_id not in records:
        raise NotFoundError(
            f"no Decision Challenge {challenge_id!r} is stored on this case",
            remedy="record the challenge or choose an identity listed on the case",
        )
    record = records[challenge_id]
    if not isinstance(record, Mapping):
        raise UsageError("stored Decision Challenge is not a JSON object")
    return _verified_payload(record)


def verify_request(request: Any) -> dict:
    if not isinstance(request, Mapping) or set(request) != {"record"}:
        raise UsageError(
            "Decision Challenge verification requires exactly "
            "{'record': <DecisionChallengeRecord>}",
            remedy=(
                "pass the canonical portable record; it already embeds the exact "
                "independent phase and certified-delta replay inputs"
            ),
        )
    record = request.get("record")
    if not isinstance(record, Mapping):
        raise UsageError("Decision Challenge verification record must be a JSON object")
    return _verified_payload(record)
