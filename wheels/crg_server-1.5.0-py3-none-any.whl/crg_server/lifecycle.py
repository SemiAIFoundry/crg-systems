"""Server/job boundary for v1.3 ETQ and v1.4 decision/resilience lifecycle."""
from __future__ import annotations

import copy
from typing import Any, Dict, Mapping

from crg_model.canonical import content_hash

from crg_cli.lifecycle import (
    LifecycleVerificationError,
    RESILIENCE_LIFECYCLE_RECORD_TYPES,
    build_verified_lifecycle_record,
    inspect_lifecycle_record,
    persist_lifecycle_record,
    render_lifecycle_report,
    verify_lifecycle_record,
)

from .errors import BlockedOutcome, NotFoundError, UsageError
from .jobs import JobContext, JobResult

__all__ = [
    "op_publish", "continued_validity_case_evidence", "continued_validity_source",
    "inspect_record", "verify_request",
]


def op_publish(context: JobContext) -> JobResult:
    """Produce, replay, and append one typed lifecycle record."""

    request = context.inputs.get("request") or {}
    case = dict(context.inputs["case"])
    operation = str(request.get("operation") or "")
    authority = context.inputs.get("lifecycle_authority_snapshot")
    producer_crypto_judgment = None
    validity_source = None
    if operation == "RECORD_SIGNATURE_VERIFICATION":
        from crg_security import verify_lifecycle_signature

        raw = request.get("inputs") or {}
        producer_crypto_judgment = verify_lifecycle_signature(
            raw.get("signed_content"), raw.get("signature_content"), authority
        )
    if operation == "BUILD_CONTINUED_VALIDITY":
        validity_source = context.inputs.get("lifecycle_validity_source")
        if validity_source is None:  # additive recovery for pre-closure queued jobs
            validity_source = continued_validity_source(
                context.store, case, request.get("inputs") or {}, authority
            )
    try:
        record, verifier_inputs, verification, companions = (
            build_verified_lifecycle_record(
                request,
                case,
                authority_snapshot=authority,
                producer_crypto_judgment=producer_crypto_judgment,
                validity_source=validity_source,
            )
        )
    except LifecycleVerificationError as error:
        raise BlockedOutcome(
            "independent lifecycle replay disagreed with the producer",
            outcome="BLOCKED_VERIFIER_DISAGREEMENT",
            detail={"message": str(error)},
            remedy="publish nothing; repair and independently test the producer/verifier boundary",
        ) from error
    record_type, record_id = persist_lifecycle_record(
        case, record, verifier_inputs, companions
    )
    direct_state = inspect_lifecycle_record(case, record_type, record_id)["direct_state"]
    report = render_lifecycle_report(record, verification)
    context.log(
        f"lifecycle {record_type} {record_id} independently replayed; "
        f"generation={verifier_inputs['first_release_attribution']}"
    )
    proof = {
        "proof_type": "LIFECYCLE_INDEPENDENT_REPLAY",
        "record_type": record_type,
        "record_hash": verifier_inputs["record_hash"],
        "verifier": "crg-verify",
        "status": verification.status,
        "first_release_attribution": verifier_inputs["first_release_attribution"],
        "direct_state": direct_state,
        "synthetic_score": False,
        "commercial_inference": False,
    }
    if isinstance(authority, Mapping):
        proof.update({
            "authority_scope": "DEPLOYMENT_OWNED",
            "trust_context_root": authority["trust_context_root"],
            "policy_roots": dict(authority["policy_roots"]),
            "clock_root": authority["clock_root"],
            "authenticated_subject": authority["principal"]["subject_id"],
            "authenticated_organization": authority["principal"]["organization"],
            "authenticated_roles": list(authority["principal"]["roles"]),
        })
    if record_type in RESILIENCE_LIFECYCLE_RECORD_TYPES:
        proof.update({
            "claim_boundary": record["claim_boundary"],
            "provider_disaster_recovery_claim": False,
            "service_level_claim": False,
        })
    objects = [
        (f"lifecycle:{record_type}:{record_id}", record),
        (f"lifecycle-verification-inputs:{record_type}:{record_id}", verifier_inputs),
    ]
    objects.extend(companions)
    return JobResult(
        outputs={
            "record_type": record_type,
            "record_id": record_id,
            "record": record,
            "verification_inputs": verifier_inputs,
            "verification": verification.to_json(),
            "direct_state": direct_state,
            "report": report,
        },
        objects=objects,
        case=case,
        proof_artifacts=[proof],
    )


def _object_status(store: Any, digest: str) -> str:
    if store is None or not digest:
        return "UNKNOWN"
    try:
        if hasattr(store, "has_object") and not store.has_object(digest):
            return "MISSING"
        return str(store.object_status(digest))
    except Exception:
        return "UNKNOWN"


def continued_validity_case_evidence(case: Mapping[str, Any]) -> Dict[str, Any]:
    """Return the bounded canonical case evidence consumed by validity checks.

    Lifecycle verification inputs can themselves contain earlier case
    evidence.  Capturing the entire mutable persistence document would create
    recursively growing snapshots.  This versioned projection carries every
    case field used by the registered branch/change/supersession checkers plus
    the active and superseded certificate inventories, without weakening any
    checker or trusting a caller summary.
    """

    return {
        "profile": "crg.continued-validity-case-evidence",
        "schema_version": "1.0.0",
        "case_id": str(case.get("case_id") or ""),
        "case_version": int(case.get("case_version") or 0),
        "status": str(case.get("status") or ""),
        "branch_id": str(case.get("branch_id") or ""),
        "parent_case_refs": copy.deepcopy(list(case.get("parent_case_refs") or ())),
        "merge_decisions": copy.deepcopy(list(case.get("merge_decisions") or ())),
        "deltas": copy.deepcopy(list(case.get("deltas") or ())),
        "history": copy.deepcopy(list(case.get("history") or ())),
        "active_certificate_ids": sorted(
            str(identity) for identity in (case.get("certificates") or {})
        ),
        "superseded_certificate_ids": sorted(
            str(identity) for identity in (case.get("superseded_certificates") or {})
        ),
    }


def _artifact_status(
    store: Any, case: Mapping[str, Any], artifact_root: str
) -> str:
    for document in (case.get("certificates") or {}).values():
        if isinstance(document, Mapping) and content_hash(document) == artifact_root:
            return "ACTIVE"
    for document in (case.get("superseded_certificates") or {}).values():
        if isinstance(document, Mapping) and content_hash(document) == artifact_root:
            return "SUPERSEDED"
    return _object_status(store, artifact_root)


def _dependency_status(store: Any, case: Mapping[str, Any], identity: str) -> str:
    registry_ids = {
        str(item.get("realization_id"))
        for item in ((case.get("registry") or {}).get("realizations") or ())
        if isinstance(item, Mapping) and item.get("realization_id")
    }
    if identity in registry_ids:
        return "ACTIVE"
    return _object_status(store, identity)


def continued_validity_source(
    store: Any,
    case: Mapping[str, Any],
    request_inputs: Mapping[str, Any],
    authority: Any,
) -> Dict[str, Any]:
    """Assemble validity evidence from canonical store state, never request declarations."""

    if not isinstance(authority, Mapping):
        raise UsageError("BUILD_CONTINUED_VALIDITY requires deployment lifecycle authority")
    artifact = request_inputs.get("artifact")
    if not isinstance(artifact, Mapping):
        raise UsageError("BUILD_CONTINUED_VALIDITY artifact must be a canonical object")
    artifact = dict(artifact)
    artifact_root = content_hash(artifact)
    evidence_roots = artifact.get("evidence_roots")
    if not isinstance(evidence_roots, (list, tuple)):
        evidence_roots = ()
    dependency_roots = artifact.get("dependencies")
    if not isinstance(dependency_roots, (list, tuple)):
        dependency_roots = ()
    case_id = str(case.get("case_id") or request_inputs.get("case_id") or "")
    edges = list(store.edges_for(case_id)) if store is not None and hasattr(store, "edges_for") else []
    audit = list(store.audit_log(case_id=case_id)) if store is not None and hasattr(store, "audit_log") else []
    lifecycle = case.get("lifecycle_records") or {}
    lifecycle_inputs = case.get("lifecycle_verification_inputs") or {}
    candidates = []
    for identity, record in (lifecycle.get("LifecycleAuthorization") or {}).items():
        if isinstance(record, Mapping) and record.get("artifact_hash") == artifact_root:
            envelope = (lifecycle_inputs.get("LifecycleAuthorization") or {}).get(identity)
            if isinstance(envelope, Mapping):
                candidates.append((content_hash(record), dict(record), dict(envelope)))
    candidates.sort(key=lambda item: item[0])
    if candidates:
        _root, authorization_record, authorization_inputs = candidates[-1]
    else:
        authorization_record = authorization_inputs = None
    migrations = [
        dict(record)
        for _identity, record in sorted(
            (lifecycle.get("MigrationReverificationRecord") or {}).items()
        )
        if isinstance(record, Mapping)
    ]
    case_evidence = continued_validity_case_evidence(case)
    return {
        "profile": "crg.continued-validity-source",
        "schema_version": "1.0.0",
        "case": case_evidence,
        "case_root": content_hash(case_evidence),
        "artifact": artifact,
        "artifact_root": artifact_root,
        "artifact_status": _artifact_status(store, case, artifact_root),
        "evidence_statuses": {
            str(root): _object_status(store, str(root)) for root in evidence_roots
        },
        "dependency_edges": edges,
        "dependency_statuses": {
            str(root): _dependency_status(store, case, str(root))
            for root in dependency_roots
        },
        "audit_events": audit,
        "audit_root": content_hash(audit),
        "authorization_record": authorization_record,
        "authorization_inputs": authorization_inputs,
        "migration_records": migrations,
        "authority_snapshot": dict(authority),
    }


def inspect_record(case: Mapping[str, Any], record_type: str, record_id: str) -> dict:
    try:
        return inspect_lifecycle_record(case, record_type, record_id)
    except Exception as error:
        if "no lifecycle" in str(error):
            raise NotFoundError(
                f"no lifecycle {record_type} {record_id!r} in this case",
                remedy="publish the dependency-ordered record or choose an identity listed on the case",
            ) from error
        raise


def verify_request(request: Any, *, trusted_context_root: str | None = None) -> dict:
    if not isinstance(request, Mapping) or set(request) != {"record", "verification_inputs"}:
        raise UsageError(
            "lifecycle verification requires exactly {'record', 'verification_inputs'}",
            remedy="pass the canonical record and the exact portable independent-replay envelope",
        )
    if not isinstance(request.get("record"), Mapping):
        raise UsageError("lifecycle verification record must be a JSON object")
    if not isinstance(request.get("verification_inputs"), Mapping):
        raise UsageError("lifecycle verification inputs must be a JSON object")
    envelope = request["verification_inputs"]
    operation = str(envelope.get("verifier_operation") or "")
    if operation.endswith("_v2"):
        inputs = envelope.get("inputs") or {}
        authority = inputs.get("authority_snapshot") if isinstance(inputs, Mapping) else None
        carried_root = authority.get("trust_context_root") if isinstance(authority, Mapping) else None
        if trusted_context_root is None or carried_root != trusted_context_root:
            raise UsageError(
                "authority replay requires this deployment's configured lifecycle trust root"
            )
    try:
        verification = verify_lifecycle_record(
            request["record"], request["verification_inputs"]
        )
    except LifecycleVerificationError as error:
        raise BlockedOutcome(
            "independent lifecycle replay failed",
            outcome="BLOCKED_VERIFICATION_FAILED",
            detail={"message": str(error)},
            remedy="do not rely on this record; recover the exact canonical producer output and replay inputs",
        ) from error
    record = dict(request["record"])
    return {
        "record": record,
        "verification_inputs": dict(request["verification_inputs"]),
        "verification": verification.to_json(),
        "report": render_lifecycle_report(record, verification),
    }
