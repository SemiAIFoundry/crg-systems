"""crg-server: the headless integration surface.

Reference implementation of sections 38 (integration specification) and 42
(persistence and execution architecture) of the CRG Operational Systems
Master Specification v0.2.0, with 15 (schema evolution), 16 (branching,
concurrency, merge), 17 (deletion, retention, redaction, tombstones), and 44
(security and privacy) applied throughout.

This package adds no semantics.  Every decision it surfaces was made by
``crg_generate``, ``crg_geometry``, ``crg_certify``, ``crg_change``,
``crg_convert``, ``etq_evidence``, ``etq_qualify``, or ``etq_federation``;
what this package contributes is the *boundary* -- and a boundary is made of
refusals.  Five of them define the module.

**Nothing outside can mutate a canonical object (10.1).**  ``CaseStore``
exposes ``put_object``, ``get_object``, and ``put_successor``, and no writer
that takes a hash and new bytes.  Objects are addressed by the hash of their
content, so "edit this certificate" is not a request that can be phrased.  A
change produces a successor with the predecessor in ``parent_hashes``; status
and presence are metadata and move separately, which is exactly the split
42.1 draws between a relational metadata store and a content-addressed object
store.

**A failed job produces no certificate (42.4).**  Job bodies *propose*
objects and certificates; the queue commits them only after the body returned
normally and the declared resource limits held.  ``register_certificate``
independently refuses any job whose status is not ``SUCCEEDED``, and a commit
that fails partway withdraws the registrations it made.  There is no ordering
of calls that leaves a failed run holding a live claim.

**A long-running action returns an identifier, not a result (38.3).**  Every
such endpoint answers ``202`` with a job id.  The reference deployment runs a
local worker (42.2) that may well finish first; the response is still the
identifier, because that is the contract an integrator writes against.

**A refusal leaves as a refusal (6.6).**  ``GET /jobs/{id}/result`` is the
only door a computed decision leaves by, and it answers ``422`` for a blocked
outcome and ``409`` for a failed or cancelled job.  Usage errors are ``400``,
missing identity ``401``, insufficient role ``403``, stale parent version or
legal hold ``409``, redacted content ``410`` with the tombstone attached, and
scope mismatch ``422``.  No status in that table lets a caller receive ``200``
together with a decision that did not carry.

**Redaction downgrades rather than hides (17.2, 17.3).**  ``redact`` removes
content, keeps identity, hash, type, and every typed dependency edge as a
``TombstoneRecord``, and walks the reachable dependents *at the moment of
removal* to set each affected certificate to ``UNVERIFIABLE_REDACTED`` --
unless it carries a separately sufficient proof artifact that is still
present.  A later verification pass would be too late, because the caller
might never run one.

**38.2's five delivery surfaces, and the one that is not here.**  REST with
OpenAPI 3.1 (``openapi``), asynchronous job APIs (``jobs``), webhooks
(``webhooks``: subscriptions, an exact exponential-with-jitter retry
schedule, a hashed delivery log, and a dead-letter state), and generated
client SDKs (``sdkgen``, which emits ``sdk/python`` and ``sdk/js`` from the
OpenAPI document rather than by hand) are all present.  For event streaming
38.2 permits "Server-Sent Events, WebSocket, **or equivalent**", and this
package implements **SSE only** (``streaming``).  The reason is resumption:
``Last-Event-ID`` is part of the SSE protocol and this bus can answer it
exactly, because its history is an ordinal cursor -- so a subscriber that
lost its connection receives what it missed with no gap and no duplicate.  A
dropped WebSocket leaves that gap to an application-level protocol somebody
would have to invent.  The gRPC profile 38.2 makes a MAY is not supplied.

Standard library only: ``http.server``, ``sqlite3``, ``zipfile``, ``json``,
``hmac``.  Specification 43 recommends FastAPI and PostgreSQL and says in the
same section that the specification boundary shall remain language-neutral;
what 38.2 requires is REST with OpenAPI 3.1, asynchronous job APIs, event
streaming, and webhooks, and those are properties of the surface rather than
of a framework.  Nothing here needs acquiring before an air-gapped deployment
(45.5) or an independent reimplementation (48.3) can run it.
"""
from .errors import (
    BlockedOutcome,
    ConflictError,
    IntegrityError,
    PayloadTooLargeError,
    ForbiddenError,
    MethodNotAllowedError,
    NotFoundError,
    RedactedError,
    ScopeMismatchError,
    ServiceUnavailableError,
    ServerError,
    UnauthorizedError,
    UnsupportedMediaTypeError,
    UsageError,
    error_body,
    from_security_error,
)
from .events import (
    AGENT_EVENT_PROTOCOL_VERSIONS,
    AGENT_EVENT_RESULTS,
    AGENT_EVENT_TRANSPORT_PROFILES,
    EVENT_VOCABULARY,
    REQUIRED_EVENT_FIELDS,
    WEBHOOK_SIGNATURE_PROFILE,
    AgentEvent,
    AgentEventLedger,
    Event,
    EventBus,
    negotiate_agent_event_protocol,
    validate_agent_event_record,
    webhook_payload,
)
from .streaming import (
    DEFAULT_HEARTBEAT_SECONDS,
    DEFAULT_RETRY_MS,
    SSE_CONTENT_TYPE,
    SSE_HEADERS,
    SSE_KEEPALIVE,
    EventFilter,
    EventStream,
    build_event_stream,
    parse_event_names,
    parse_last_event_id,
    sse_comment,
    sse_frame,
)
from .webhooks import (
    DEFAULT_MAX_ATTEMPTS,
    JITTER_RATIO,
    DeliveryAttempt,
    DeliveryOutcome,
    PendingDelivery,
    TransportResponse,
    WebhookDispatcher,
    WebhookSubscription,
    WebhookTransportError,
    backoff_delay,
    urllib_transport,
    verify_webhook_signature,
)
from .durable_webhooks import DurableWebhookPump, load_webhook_subscriptions
from .enterprise_backup import create_enterprise_backup, restore_enterprise_backup
from .telemetry import (
    OtlpTelemetry,
    SpanContext,
    TelemetryConfigurationError,
    parse_otlp_headers,
    parse_traceparent,
)
from .sdkgen import Operation, generate_sdk, load_operations, write_sdk
from .store import CaseStore, Tombstone
from .federation_state import (
    FederationStateError,
    FederationVerifierState,
    PersistentNonceLedger,
    ReplayDetectedError,
    load_federation_verifier_state,
)
from .retention import (
    RETENTION_CONTROL_TYPES,
    RetentionAction,
    RetentionDecision,
    RetentionEngine,
    RetentionPolicy,
    retention_engine_for_store,
)
from .jobs import (
    DEFAULT_RESOURCE_LIMITS,
    ENGINE_VERSIONS,
    DeterminismStatus,
    FailureCategory,
    JobContext,
    JobQueue,
    JobRecord,
    JobResult,
    JobStatus,
)
from .branch import (
    BRANCH_RECORD_REQUIRED,
    NONSEMANTIC_METADATA,
    SEMANTIC_OBJECTS,
    BranchRecord,
    MergeDecision,
    MergeDecisionKind,
    MergeRule,
    create_branch,
    merge_policy,
)
from .multi_agent import (
    AgentOperationBudget,
    AgentOperationGrant,
    MultiAgentCoordinator,
    build_agent_proposal,
    validate_agent_grant,
    validate_agent_proposal,
)
from .typed import decode, decode_exact, decode_interval, encode
from .bundleio import export_bundle, import_bundle_bytes, verify_bundle_bytes
from .openapi import OPENAPI_VERSION, endpoint_paths, openapi_document
from .app import (
    ENDPOINTS,
    NO_AUTHENTICATION_CONFIGURED,
    ROLE_REQUIREMENTS,
    Application,
    Endpoint,
    Request,
    Response,
    build_request,
    make_app,
    make_handler,
    make_server,
    serve,
)
from .edk import (
    EDK_PROFILE,
    EDK_RECEIPT_PROFILE,
    EDKError,
    EDKTransportResponse,
    ApplicationWireTransport,
    EmbeddedDeveloperKit,
    InProcessTransport,
    SidecarTransport,
)

__version__ = "1.5.0"
SPEC_VERSION = "0.2.0"

__all__ = [
    # errors (6.6, 38.3)
    "BlockedOutcome",
    "ConflictError",
    "IntegrityError",
    "ForbiddenError",
    "MethodNotAllowedError",
    "NotFoundError",
    "RedactedError",
    "ScopeMismatchError",
    "ServiceUnavailableError",
    "ServerError",
    "UnauthorizedError",
    "UnsupportedMediaTypeError",
    "UsageError",
    "error_body",
    "from_security_error",
    # events (38.5)
    "AGENT_EVENT_PROTOCOL_VERSIONS",
    "AGENT_EVENT_RESULTS",
    "AGENT_EVENT_TRANSPORT_PROFILES",
    "EVENT_VOCABULARY",
    "REQUIRED_EVENT_FIELDS",
    "WEBHOOK_SIGNATURE_PROFILE",
    "AgentEvent",
    "AgentEventLedger",
    "Event",
    "EventBus",
    "negotiate_agent_event_protocol",
    "validate_agent_event_record",
    "webhook_payload",
    # event streaming over Server-Sent Events (38.2)
    "DEFAULT_HEARTBEAT_SECONDS",
    "DEFAULT_RETRY_MS",
    "SSE_CONTENT_TYPE",
    "SSE_HEADERS",
    "SSE_KEEPALIVE",
    "EventFilter",
    "EventStream",
    "build_event_stream",
    "parse_event_names",
    "parse_last_event_id",
    "sse_comment",
    "sse_frame",
    # webhook delivery (38.2)
    "DEFAULT_MAX_ATTEMPTS",
    "JITTER_RATIO",
    "DeliveryAttempt",
    "DeliveryOutcome",
    "PendingDelivery",
    "TransportResponse",
    "WebhookDispatcher",
    "WebhookSubscription",
    "WebhookTransportError",
    "backoff_delay",
    "urllib_transport",
    "verify_webhook_signature",
    "DurableWebhookPump",
    "load_webhook_subscriptions",
    "create_enterprise_backup",
    "restore_enterprise_backup",
    "OtlpTelemetry",
    "SpanContext",
    "TelemetryConfigurationError",
    "parse_otlp_headers",
    "parse_traceparent",
    # generated client SDKs (38.2)
    "Operation",
    "generate_sdk",
    "load_operations",
    "write_sdk",
    # persistence (42.1, 17)
    "CaseStore",
    "Tombstone",
    "FederationStateError",
    "ReplayDetectedError",
    "PersistentNonceLedger",
    "FederationVerifierState",
    "load_federation_verifier_state",
    "RETENTION_CONTROL_TYPES",
    "RetentionAction",
    "RetentionDecision",
    "RetentionEngine",
    "RetentionPolicy",
    "retention_engine_for_store",
    # jobs (42.4)
    "DEFAULT_RESOURCE_LIMITS",
    "ENGINE_VERSIONS",
    "DeterminismStatus",
    "FailureCategory",
    "JobContext",
    "JobQueue",
    "JobRecord",
    "JobResult",
    "JobStatus",
    # branching and merge (16)
    "BRANCH_RECORD_REQUIRED",
    "NONSEMANTIC_METADATA",
    "SEMANTIC_OBJECTS",
    "BranchRecord",
    "MergeDecision",
    "MergeDecisionKind",
    "MergeRule",
    "create_branch",
    "merge_policy",
    # bounded multi-agent coordination (A6)
    "AgentOperationBudget",
    "AgentOperationGrant",
    "MultiAgentCoordinator",
    "build_agent_proposal",
    "validate_agent_grant",
    "validate_agent_proposal",
    # typed requests (10.1, 14.2)
    "decode",
    "decode_exact",
    "decode_interval",
    "encode",
    # portable bundles (39)
    "export_bundle",
    "import_bundle_bytes",
    "verify_bundle_bytes",
    # description (38.2)
    "OPENAPI_VERSION",
    "endpoint_paths",
    "openapi_document",
    # surface (38.3)
    "ENDPOINTS",
    "NO_AUTHENTICATION_CONFIGURED",
    "ROLE_REQUIREMENTS",
    "Application",
    "Endpoint",
    "Request",
    "Response",
    "build_request",
    "make_app",
    "make_handler",
    "make_server",
    "serve",
    "SPEC_VERSION",
    # Embedded Developer Kit (Advancement 2)
    "EDK_PROFILE",
    "EDK_RECEIPT_PROFILE",
    "EDKError",
    "EDKTransportResponse",
    "ApplicationWireTransport",
    "EmbeddedDeveloperKit",
    "InProcessTransport",
    "SidecarTransport",
]
