"""Offline integrity, backup, and restore commands for the local profile."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import sqlite3
import tarfile
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

from crg_model.canonical import canonical_json
from crg_model.envelope import utc_now

from .store import CaseStore
from .federation_state import load_federation_verifier_state
from .deployment import load_at_rest_codec
from .backends import (
    ApplicationStore,
    BackendError,
    backend_config_from_env,
    select_backend,
)
from .enterprise_backup import create_enterprise_backup, restore_enterprise_backup
from .errors import UsageError


def _digest(path: Path) -> str:
    hasher = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            hasher.update(chunk)
    return "sha256:" + hasher.hexdigest()


def create_backup(
    root: str, output: str, *, object_codec: Any = None,
    require_encryption: bool = False,
) -> Dict[str, Any]:
    target = Path(output).expanduser().resolve()
    if target.exists():
        raise ValueError(f"backup output {str(target)!r} already exists")
    target.parent.mkdir(parents=True, exist_ok=True)
    store = CaseStore(
        root, object_codec=object_codec, require_encryption=require_encryption
    )
    try:
        integrity = store.scan_integrity()
        if not integrity["ok"]:
            raise ValueError("refusing to back up a store that fails its integrity scan")
        with tempfile.TemporaryDirectory(prefix="crg-backup-") as temporary:
            stage = Path(temporary) / "store"
            stage.mkdir()
            with store._write_lock:
                snapshot = sqlite3.connect(str(stage / "metadata.sqlite3"))
                try:
                    store._connection._connection.backup(snapshot)
                finally:
                    snapshot.close()
                federation_source = Path(store.root) / "federation" / "state.sqlite3"
                if federation_source.is_file():
                    federation_target = stage / "federation" / "state.sqlite3"
                    federation_target.parent.mkdir(parents=True, exist_ok=True)
                    source_connection = sqlite3.connect(str(federation_source))
                    target_connection = sqlite3.connect(str(federation_target))
                    try:
                        source_connection.backup(target_connection)
                    finally:
                        target_connection.close()
                        source_connection.close()
                for source in Path(store.root).rglob("*"):
                    if not source.is_file() or source == Path(store.database_path):
                        continue
                    relative = source.relative_to(store.root)
                    if relative.as_posix() in {
                        "federation/state.sqlite3", "federation/state.sqlite3-wal",
                        "federation/state.sqlite3-shm",
                    }:
                        continue
                    destination = stage / relative
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(source, destination)
            files = []
            for path in sorted(stage.rglob("*")):
                if path.is_file():
                    files.append({
                        "path": path.relative_to(stage).as_posix(),
                        "length": path.stat().st_size,
                        "sha256": _digest(path),
                    })
            manifest = {
                "format": "crg-local-backup-v1",
                "created_at": utc_now(),
                "database_schema_version": store.database_schema_version(),
                "files": files,
                "integrity_scan": integrity,
            }
            (stage / "backup-manifest.json").write_text(
                canonical_json(manifest) + "\n", encoding="utf-8"
            )
            with tarfile.open(target, "x:gz") as archive:
                archive.add(stage, arcname="store", recursive=True)
        return {**manifest, "output": str(target), "archive_sha256": _digest(target)}
    finally:
        store.close()


def _extract_verified(archive_path: Path, stage: Path) -> Path:
    with tarfile.open(archive_path, "r:gz") as archive:
        names = set()
        for member in archive.getmembers():
            if member.name in names:
                raise ValueError(f"backup contains duplicate member {member.name!r}")
            names.add(member.name)
            if member.name != "store" and not member.name.startswith("store/"):
                raise ValueError(f"backup contains member outside store/: {member.name!r}")
            if member.issym() or member.islnk() or not (member.isfile() or member.isdir()):
                raise ValueError(f"backup contains unsupported member {member.name!r}")
            destination = (stage / member.name).resolve()
            if stage.resolve() not in destination.parents and destination != stage.resolve():
                raise ValueError(f"backup member escapes extraction root: {member.name!r}")
            if member.isdir():
                destination.mkdir(parents=True, exist_ok=True)
                continue
            destination.parent.mkdir(parents=True, exist_ok=True)
            source = archive.extractfile(member)
            if source is None:
                raise ValueError(f"cannot read backup member {member.name!r}")
            with source, destination.open("xb") as output:
                shutil.copyfileobj(source, output)
    root = stage / "store"
    manifest_path = root / "backup-manifest.json"
    if not manifest_path.is_file():
        raise ValueError("backup has no backup-manifest.json")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if not isinstance(manifest, dict):
        raise ValueError("backup manifest must be a JSON object")
    if manifest.get("format") != "crg-local-backup-v1":
        raise ValueError("backup format is unsupported")
    entries = manifest.get("files")
    if not isinstance(entries, list):
        raise ValueError("backup manifest files must be an array")
    declared = set()
    for entry in entries:
        if not isinstance(entry, dict) or set(entry) != {"path", "length", "sha256"}:
            raise ValueError("backup manifest file entries use an unsupported shape")
        relative = Path(str(entry["path"]))
        if (
            relative.is_absolute()
            or ".." in relative.parts
            or relative.as_posix() in {"", ".", "backup-manifest.json"}
        ):
            raise ValueError(f"backup manifest contains unsafe member {entry['path']!r}")
        normalized = relative.as_posix()
        if normalized in declared:
            raise ValueError(f"backup manifest repeats member {normalized!r}")
        declared.add(normalized)
        path = root / relative
        if not path.is_file() or path.stat().st_size != int(entry["length"]):
            raise ValueError(f"backup member length mismatch: {entry['path']}")
        if _digest(path) != entry["sha256"]:
            raise ValueError(f"backup member hash mismatch: {entry['path']}")
    actual = {
        path.relative_to(root).as_posix()
        for path in root.rglob("*")
        if path.is_file() and path != manifest_path
    }
    if declared != actual:
        missing = sorted(declared - actual)
        undeclared = sorted(actual - declared)
        raise ValueError(
            f"backup member inventory mismatch; missing={missing}, undeclared={undeclared}"
        )
    return root


def restore_backup(
    archive: str, destination: str, *, object_codec: Any = None,
    require_encryption: bool = False,
) -> Dict[str, Any]:
    source = Path(archive).expanduser().resolve()
    target = Path(destination).expanduser().resolve()
    if not source.is_file():
        raise ValueError(f"no backup archive at {str(source)!r}")
    if target.exists() and any(target.iterdir()):
        raise ValueError("restore destination must be absent or empty")
    target.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="crg-restore-") as temporary:
        restored = _extract_verified(source, Path(temporary))
        if target.exists():
            target.rmdir()
        shutil.copytree(restored, target, ignore=shutil.ignore_patterns("backup-manifest.json"))
    store = CaseStore(
        str(target), object_codec=object_codec, require_encryption=require_encryption
    )
    try:
        integrity = store.scan_integrity()
        if not integrity["ok"]:
            raise ValueError("restored store failed its post-restore integrity scan")
        federation_integrity = None
        federation_path = target / "federation" / "state.sqlite3"
        if federation_path.is_file():
            connection = sqlite3.connect(str(federation_path))
            try:
                messages = [str(row[0]) for row in connection.execute("PRAGMA integrity_check")]
            finally:
                connection.close()
            federation_integrity = {"ok": messages == ["ok"], "messages": messages}
            if not federation_integrity["ok"]:
                raise ValueError("restored federation state failed its integrity scan")
        result = {"restored_to": str(target), "integrity_scan": integrity}
        if federation_integrity is not None:
            result["federation_integrity_scan"] = federation_integrity
        return result
    finally:
        store.close()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="crg-admin")
    commands = parser.add_subparsers(dest="command", required=True)
    scan = commands.add_parser("integrity")
    scan.add_argument("--root", default=".crg-server")
    scan.add_argument("--security-config")
    backup = commands.add_parser("backup")
    backup.add_argument("--root", default=".crg-server")
    backup.add_argument("--output", required=True)
    backup.add_argument("--security-config")
    restore = commands.add_parser("restore")
    restore.add_argument("--archive", required=True)
    restore.add_argument("--destination", required=True)
    restore.add_argument("--security-config")
    recovery = commands.add_parser(
        "recovery-drill",
        help="back up a populated local store, restore to an empty target, and bind typed roots",
    )
    recovery.add_argument("--root", default=".crg-server")
    recovery.add_argument(
        "--source-bundle",
        help="verify/import a public .crg bundle into an absent or empty source store",
    )
    recovery.add_argument("--archive", required=True)
    recovery.add_argument("--destination", required=True)
    recovery.add_argument("--recovery-id", required=True)
    recovery.add_argument("--authority", required=True)
    recovery.add_argument("--report-output")
    recovery.add_argument("--security-config")
    enterprise_backup = commands.add_parser(
        "enterprise-backup", help="logical backup of CRG_POSTGRES_DSN + S3 state"
    )
    enterprise_backup.add_argument("--output", required=True)
    enterprise_restore = commands.add_parser(
        "enterprise-restore", help="restore a logical backup into empty enterprise state"
    )
    enterprise_restore.add_argument("--archive", required=True)
    enterprise_restore.add_argument(
        "--acknowledge-empty-target", action="store_true",
        help="confirm the configured PostgreSQL/S3 target is intended to be empty",
    )
    federation_status = commands.add_parser(
        "federation-status", help="inspect durable V4 replay/revocation state"
    )
    federation_status.add_argument("--root", default=".crg-server")
    federation_status.add_argument("--security-config", required=True)
    federation_revoke = commands.add_parser(
        "federation-revoke", help="revoke a V4 envelope/evidence/key subject"
    )
    federation_revoke.add_argument("--root", default=".crg-server")
    federation_revoke.add_argument("--security-config", required=True)
    federation_revoke.add_argument("--subject", required=True)
    federation_revoke.add_argument("--reason", required=True)
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if args.command == "integrity":
            codec = load_at_rest_codec(args.security_config) if args.security_config else None
            store = CaseStore(
                args.root, object_codec=codec,
                require_encryption=bool(args.security_config),
            )
            try:
                report = store.scan_integrity()
            finally:
                store.close()
        elif args.command == "backup":
            codec = load_at_rest_codec(args.security_config) if args.security_config else None
            report = create_backup(
                args.root, args.output, object_codec=codec,
                require_encryption=bool(args.security_config),
            )
        elif args.command == "restore":
            codec = load_at_rest_codec(args.security_config) if args.security_config else None
            report = restore_backup(
                args.archive, args.destination, object_codec=codec,
                require_encryption=bool(args.security_config),
            )
        elif args.command == "recovery-drill":
            codec = load_at_rest_codec(args.security_config) if args.security_config else None
            report_path = None
            if args.report_output:
                report_path = Path(args.report_output).expanduser().resolve()
                if report_path.exists():
                    raise ValueError(
                        f"recovery report output {str(report_path)!r} already exists"
                    )
            # Delayed import avoids a module cycle: the drill composes the
            # public backup and restore functions defined above.
            from .local_recovery import execute_local_recovery_drill
            report = execute_local_recovery_drill(
                args.root,
                args.archive,
                args.destination,
                recovery_id=args.recovery_id,
                authority=args.authority,
                source_bundle=args.source_bundle,
                object_codec=codec,
                require_encryption=bool(args.security_config),
            )
            if report_path is not None:
                report_path.parent.mkdir(parents=True, exist_ok=True)
                report_path.write_text(
                    canonical_json(report) + "\n", encoding="utf-8"
                )
        elif args.command in {"enterprise-backup", "enterprise-restore"}:
            config = backend_config_from_env()
            tenant_id = str(config.get("tenant_id") or "")
            if not tenant_id:
                raise ValueError("CRG_STORE_TENANT is required for enterprise recovery")
            enterprise = ApplicationStore(
                select_backend(config), root_label="crg-admin", tenant_id=tenant_id
            )
            try:
                if args.command == "enterprise-backup":
                    report = create_enterprise_backup(enterprise, args.output)
                else:
                    if not args.acknowledge_empty_target:
                        raise ValueError(
                            "enterprise restore requires --acknowledge-empty-target"
                        )
                    report = restore_enterprise_backup(
                        args.archive, enterprise, expected_tenant=tenant_id
                    )
            finally:
                enterprise.close()
        else:
            state = load_federation_verifier_state(
                args.security_config, store_root=args.root
            )
            if state is None:
                raise ValueError("deployment configuration has no federation verifier policy")
            try:
                if args.command == "federation-revoke":
                    state.revoke(args.subject, reason=args.reason)
                report = {"ok": True, "federation": state.disclosure()}
            finally:
                state.close()
    except (OSError, ValueError, tarfile.TarError, BackendError, UsageError) as error:
        print(canonical_json({"ok": False, "error": str(error)}))
        return 1
    print(canonical_json(report))
    return 0 if report.get("ok", report.get("integrity_scan", {}).get("ok", True)) else 1


if __name__ == "__main__":
    raise SystemExit(main())
