"""``crg-serve`` -- run the authenticated reference deployment.

The shipped executable is fail-closed. It will not bind a socket unless an
identity policy is configured, and it will not expose cleartext transport
except when an operator explicitly chooses the loopback-only development
profile. Embedders may still construct an unconfigured ``Application`` for
tests; that is not the behavior of this network entry point.
"""
from __future__ import annotations

import argparse
import ipaddress
import json
import os
import signal
import ssl
import sys
import threading
from datetime import datetime, timezone
from typing import List, Optional

from .app import DEFAULT_MAX_REQUEST_BYTES, make_server
from .deployment import (
    DeploymentConfigurationError,
    load_federation_verifier_state,
    load_at_rest_codec,
    load_security_gate,
)
from .jobs import JobQueue
from .operational_measurement import (
    LocalOperationalMeasurementStore,
    MeasurementError,
    OperationalMeasurementPermission,
    OperationalMeasurementProfile,
)
from .telemetry import OtlpTelemetry, TelemetryConfigurationError, parse_otlp_headers
from .store import CaseStore
from .backends import (
    ApplicationStore,
    BackendConfigurationError,
    BackendError,
    backend_config_from_env,
    select_backend,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="crg-serve",
        description="Run the secured CRG Systems integration surface (spec 38, 44).",
    )
    parser.add_argument("--root", default=".crg-server",
                        help="local store/control-plane root (security audit and federation state)")
    parser.add_argument(
        "--storage-backend",
        choices=("local", "environment"),
        default="local",
        help=(
            "local uses SQLite/filesystem at --root; environment requires the explicit "
            "CRG_STORE_* PostgreSQL/S3 backend configuration"
        ),
    )
    parser.add_argument("--host", default="127.0.0.1", help="bind address")
    parser.add_argument("--port", type=int, default=8731, help="bind port")
    parser.add_argument(
        "--security-config",
        help="JSON identity/policy config; secret values come from named environment variables",
    )
    parser.add_argument("--tls-cert", help="PEM certificate chain for direct TLS")
    parser.add_argument("--tls-key", help="PEM private key for direct TLS")
    parser.add_argument(
        "--tls-client-ca",
        help="optional CA bundle; when set, valid client certificates are mandatory",
    )
    parser.add_argument(
        "--allow-loopback-http",
        action="store_true",
        help="explicitly allow authenticated cleartext HTTP on loopback only",
    )
    parser.add_argument(
        "--insecure-development",
        action="store_true",
        help="loopback-only escape hatch: no authentication and unverified X-CRG-Actor",
    )
    parser.add_argument("--actor", help="default actor in --insecure-development only")
    parser.add_argument(
        "--max-request-mib",
        type=int,
        default=DEFAULT_MAX_REQUEST_BYTES // (1024 * 1024),
        help="hard HTTP request-body limit in MiB",
    )
    parser.add_argument(
        "--job-execution", choices=("embedded", "external"), default="embedded",
        help="embedded starts the local worker thread; external only persists jobs for crg-worker",
    )
    parser.add_argument(
        "--worker-heartbeat-max-age-seconds", type=float, default=120.0,
        help="external readiness threshold; must exceed the worker heartbeat interval",
    )
    parser.add_argument(
        "--shutdown-grace-seconds", type=float, default=75.0,
        help=(
            "bounded graceful-drain budget; admission closes immediately and embedded "
            "accepted jobs finish within this interval"
        ),
    )
    parser.add_argument(
        "--otlp-traces-endpoint",
        default=os.environ.get("OTEL_EXPORTER_OTLP_TRACES_ENDPOINT", ""),
        help="optional OTLP/HTTP JSON /v1/traces endpoint (HTTPS or loopback HTTP)",
    )
    parser.add_argument(
        "--telemetry-service-name", default=os.environ.get("OTEL_SERVICE_NAME", "crg-server"),
        help="OpenTelemetry service.name resource attribute",
    )
    parser.add_argument(
        "--otlp-ca", default=os.environ.get("OTEL_EXPORTER_OTLP_CERTIFICATE", ""),
        help="optional PEM CA bundle for a private HTTPS collector",
    )
    parser.add_argument(
        "--enable-local-measurement",
        action="store_true",
        help=(
            "explicitly enable the separate local-only CRG-ENH-04 measurement plane; "
            "off by default"
        ),
    )
    parser.add_argument(
        "--operational-measurement-store",
        help="dedicated local measurement path (default: ROOT/operational-measurement)",
    )
    parser.add_argument(
        "--operational-measurement-permissions",
        help=(
            "JSON actor-to-capability map; each entry requires subject_label, grants, "
            "and domain=crg-operational-measurement"
        ),
    )
    parser.add_argument(
        "--lifecycle-trust-context",
        help=(
            "deployment-owned JSON lifecycle trust context containing only public "
            "keys, registered subjects, versioned policies, and clock policy"
        ),
    )
    parser.add_argument(
        "--lifecycle-clock-source",
        help="deployment clock source registered by --lifecycle-trust-context",
    )
    parser.add_argument(
        "--lifecycle-clock-trust-level",
        choices=("SYNCHRONIZED", "ATTESTED"),
        help="deployment clock trust assertion registered by the lifecycle clock policy",
    )
    return parser


def _is_loopback(host: str) -> bool:
    if host.lower() == "localhost":
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


def _configuration_error(message: str) -> int:
    print(f"crg-serve: configuration refused: {message}", file=sys.stderr)
    return 2


def main(argv: Optional[List[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    loopback = _is_loopback(args.host)
    tls_requested = bool(args.tls_cert or args.tls_key)
    if bool(args.tls_cert) != bool(args.tls_key):
        return _configuration_error("--tls-cert and --tls-key are required together")
    if args.tls_client_ca and not tls_requested:
        return _configuration_error("--tls-client-ca requires direct TLS")
    if args.max_request_mib <= 0:
        return _configuration_error("--max-request-mib must be positive")
    if args.worker_heartbeat_max_age_seconds <= 0:
        return _configuration_error("--worker-heartbeat-max-age-seconds must be positive")
    if args.shutdown_grace_seconds < 0 or args.shutdown_grace_seconds > 3600:
        return _configuration_error("--shutdown-grace-seconds must be from 0 through 3600")
    if not args.enable_local_measurement and (
        args.operational_measurement_store
        or args.operational_measurement_permissions
    ):
        return _configuration_error(
            "operational measurement options require --enable-local-measurement"
        )
    lifecycle_options = (
        args.lifecycle_trust_context,
        args.lifecycle_clock_source,
        args.lifecycle_clock_trust_level,
    )
    if any(lifecycle_options) and not all(lifecycle_options):
        return _configuration_error(
            "--lifecycle-trust-context, --lifecycle-clock-source, and "
            "--lifecycle-clock-trust-level are required together"
        )
    if args.insecure_development and args.lifecycle_trust_context:
        return _configuration_error(
            "authority-bearing lifecycle operations require authenticated deployment mode"
        )

    lifecycle_trust_context = None
    lifecycle_clock = None
    if args.lifecycle_trust_context:
        try:
            from crg_security import validate_lifecycle_trust_context

            with open(args.lifecycle_trust_context, encoding="utf-8") as handle:
                lifecycle_trust_context = validate_lifecycle_trust_context(
                    json.load(handle)
                )
            clock_policy = lifecycle_trust_context["clock_policy"]
            if args.lifecycle_clock_source not in clock_policy["allowed_sources"]:
                raise ValueError(
                    f"clock source {args.lifecycle_clock_source!r} is not registered"
                )
            trust_order = {
                "NONE_SUPPLIED": 0,
                "LOCAL_DECLARED": 1,
                "SYNCHRONIZED": 2,
                "ATTESTED": 3,
            }
            minimum = clock_policy["minimum_trust"]
            if trust_order[args.lifecycle_clock_trust_level] < trust_order.get(minimum, 99):
                raise ValueError(
                    f"clock trust {args.lifecycle_clock_trust_level!r} is below {minimum!r}"
                )

            def lifecycle_clock():
                return {
                    "verifier_evaluation_time": datetime.now(timezone.utc)
                    .isoformat(timespec="seconds")
                    .replace("+00:00", "Z"),
                    "verifier_clock_source": args.lifecycle_clock_source,
                    "verifier_clock_trust_level": args.lifecycle_clock_trust_level,
                }
        except (OSError, ValueError) as error:
            return _configuration_error(f"lifecycle authority: {error}")

    operational_measurement_profile = None
    operational_measurement_store = None
    operational_measurement_permissions = None
    if args.enable_local_measurement:
        if not args.operational_measurement_permissions:
            return _configuration_error(
                "--enable-local-measurement requires an explicit "
                "--operational-measurement-permissions file"
            )
        try:
            with open(
                args.operational_measurement_permissions, encoding="utf-8"
            ) as handle:
                operational_measurement_permissions = json.load(handle)
            if (
                not isinstance(operational_measurement_permissions, dict)
                or not operational_measurement_permissions
            ):
                raise ValueError("measurement permission map must be a non-empty JSON object")
            validated_permissions = {}
            for actor, permission in operational_measurement_permissions.items():
                if not str(actor).strip() or not isinstance(permission, dict):
                    raise ValueError(
                        "measurement permission entries require a non-empty actor and object"
                    )
                if set(permission) != {"subject_label", "grants", "domain"}:
                    raise ValueError(
                        "measurement permission entries require exactly subject_label, "
                        "grants, and domain"
                    )
                validated_permissions[str(actor)] = OperationalMeasurementPermission(
                    subject_label=permission["subject_label"],
                    grants=tuple(permission["grants"]),
                    domain=permission["domain"],
                )
            operational_measurement_permissions = validated_permissions
            operational_measurement_profile = OperationalMeasurementProfile(enabled=True)
            measurement_root = (
                args.operational_measurement_store
                or os.path.join(args.root, "operational-measurement")
            )
            operational_measurement_store = LocalOperationalMeasurementStore(measurement_root)
        except (OSError, ValueError, MeasurementError) as error:
            return _configuration_error(f"operational measurement: {error}")

    federation_state = None
    if args.insecure_development:
        if not loopback:
            return _configuration_error(
                "--insecure-development may bind only 127.0.0.0/8, ::1, or localhost"
            )
        if args.security_config:
            return _configuration_error(
                "--insecure-development and --security-config are mutually exclusive"
            )
        security = None
        default_actor = args.actor or "local-development"
    else:
        if args.actor:
            return _configuration_error("--actor is accepted only with --insecure-development")
        if not args.security_config:
            return _configuration_error(
                "--security-config is required (or explicitly select --insecure-development)"
            )
        try:
            security = load_security_gate(args.security_config, store_root=args.root)
            federation_state = load_federation_verifier_state(
                args.security_config, store_root=args.root
            )
        except (DeploymentConfigurationError, ValueError) as error:
            return _configuration_error(str(error))
        default_actor = None

    if not tls_requested:
        if args.insecure_development:
            pass
        elif not (loopback and args.allow_loopback_http):
            if federation_state is not None:
                federation_state.close()
            return _configuration_error(
                "TLS is mandatory; provide --tls-cert/--tls-key, or explicitly use "
                "--allow-loopback-http on a loopback address"
            )

    telemetry = None
    try:
        if args.storage_backend == "local":
            codec = (
                None if args.insecure_development
                else load_at_rest_codec(args.security_config)
            )
            store = CaseStore(
                args.root,
                object_codec=codec,
                require_encryption=not args.insecure_development,
            )
            if not args.insecure_development:
                integrity = store.scan_integrity()
                if not integrity["ok"]:
                    raise ValueError(
                        "encrypted local store failed startup integrity/decryption scan: "
                        f"{integrity['failures'][:3]}"
                    )
            if security is not None:
                store.tenant_id = str(security.configuration.audit_log.tenant_id)
            storage_description = f"local SQLite/filesystem at {store.root}"
        else:
            storage_config = backend_config_from_env()
            storage_tenant = str(storage_config.get("tenant_id") or "")
            if not storage_tenant:
                raise BackendConfigurationError(
                    "CRG_STORE_TENANT is required for environment-selected storage",
                    remedy="bind this process to exactly one authenticated tenant (44.5)",
                )
            if security is not None:
                security_tenant = str(security.configuration.audit_log.tenant_id)
                if storage_tenant != security_tenant:
                    raise BackendConfigurationError(
                        f"storage tenant {storage_tenant!r} does not match security "
                        f"tenant {security_tenant!r}",
                        remedy="CRG_STORE_TENANT and security-config tenant_id must agree",
                    )
            backend = select_backend(storage_config)
            consistency = backend.consistency().to_canonical()
            store = ApplicationStore(
                backend,
                root_label=f"environment:{consistency['name']}",
                tenant_id=storage_tenant,
            )
            storage_description = (
                f"configured backend {consistency['name']} "
                f"(read-after-write={consistency['read_after_write']}, "
                f"cross-store-atomicity={consistency['cross_store_atomicity']})"
            )
    except (BackendError, ValueError) as error:
        if federation_state is not None:
            federation_state.close()
        return _configuration_error(str(error))
    try:
        try:
            telemetry = OtlpTelemetry(
                args.otlp_traces_endpoint,
                service_name=args.telemetry_service_name,
                ca_file=args.otlp_ca,
                headers=parse_otlp_headers(os.environ.get("OTEL_EXPORTER_OTLP_HEADERS", "")),
            )
        except TelemetryConfigurationError as error:
            return _configuration_error(str(error))
        embedded_jobs = args.job_execution == "embedded"
        queue = JobQueue(
            store,
            autorun=embedded_jobs,
            recover_interrupted=embedded_jobs,
            # The external submission process must know which operation the
            # isolated worker deliberately executes in-process, otherwise it
            # could promise cancellation that the worker cannot enforce.
            in_process_kinds=("importBundle",),
        )
        queue.execution_mode = args.job_execution
        queue.worker_heartbeat_max_age_seconds = args.worker_heartbeat_max_age_seconds
        server = make_server(
            args.host,
            args.port,
            store,
            queue,
            default_actor=default_actor,
            security=security,
            federation_verifier_context=federation_state,
            lifecycle_trust_context=lifecycle_trust_context,
            lifecycle_clock=lifecycle_clock,
            telemetry=telemetry,
            operational_measurement_profile=operational_measurement_profile,
            operational_measurement_store=operational_measurement_store,
            operational_measurement_permissions=operational_measurement_permissions,
            max_request_bytes=args.max_request_mib * 1024 * 1024,
        )
        scheme = "http"
        if tls_requested:
            context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            context.minimum_version = ssl.TLSVersion.TLSv1_2
            context.load_cert_chain(args.tls_cert, args.tls_key)
            if args.tls_client_ca:
                context.load_verify_locations(cafile=args.tls_client_ca)
                context.verify_mode = ssl.CERT_REQUIRED
            server.socket = context.wrap_socket(server.socket, server_side=True)
            scheme = "https"

        print(f"crg-server listening on {scheme}://{args.host}:{args.port}")
        print(f"  storage       : {storage_description}")
        print(f"  control root  : {args.root}")
        print(f"  description   : {scheme}://{args.host}:{args.port}/openapi.json")
        print(f"  authentication: {'disabled (development)' if security is None else 'required'}")
        print(
            "  federation V4: "
            + ("durable replay/revocation state" if federation_state is not None else "disabled")
        )
        print(
            "  lifecycle authority: "
            + (
                f"context {lifecycle_trust_context['context_id']} "
                f"version {lifecycle_trust_context['context_version']}"
                if lifecycle_trust_context is not None
                else "disabled (authority-bearing lifecycle operations refuse)"
            )
        )
        print(f"  request limit : {args.max_request_mib} MiB")
        print(f"  job execution : {args.job_execution}")
        print(f"  shutdown grace: {args.shutdown_grace_seconds:g} seconds")
        print(
            "  OTLP tracing   : "
            + (args.otlp_traces_endpoint or "disabled (trace context still propagated)")
        )
        print(
            "  local measurement: "
            + (
                f"enabled at {operational_measurement_store.root} (phone-home false)"
                if operational_measurement_store is not None
                else "disabled (default)"
            )
        )
        if scheme == "http":
            print(
                "  DISCLOSURE    : cleartext transport is restricted to this explicit "
                "loopback development profile; it is not a production deployment.",
                file=sys.stderr,
            )
        app = server.crg_application  # type: ignore[attr-defined]
        shutdown_started = threading.Event()

        def request_shutdown(_signum: int, _frame: object) -> None:
            if shutdown_started.is_set():
                return
            shutdown_started.set()
            app.begin_drain()
            # ``shutdown`` must run outside the serve_forever thread.  Closing
            # admission happens synchronously first, so a concurrent request
            # cannot be acknowledged after SIGTERM committed this instance to
            # removal.
            threading.Thread(
                target=server.shutdown,
                name="crg-http-shutdown",
                daemon=True,
            ).start()

        previous_sigterm = signal.getsignal(signal.SIGTERM)
        signal.signal(signal.SIGTERM, request_shutdown)
        drain_result = None
        try:
            server.serve_forever()
        except KeyboardInterrupt:  # pragma: no cover - interactive
            app.begin_drain()
        finally:
            signal.signal(signal.SIGTERM, previous_sigterm)
            app.begin_drain()
            server.server_close()
            drain_result = queue.graceful_shutdown(
                timeout=args.shutdown_grace_seconds,
                finish_pending=embedded_jobs,
            )
            if not drain_result["drained"]:
                print(
                    "crg-server: graceful drain timed out; acknowledged work remains "
                    f"pending={len(drain_result['pending_jobs'])} "
                    f"running={len(drain_result['running_jobs'])}",
                    file=sys.stderr,
                )
    finally:
        if telemetry is not None:
            telemetry.close()
        if federation_state is not None:
            federation_state.close()
        store.close()
    return 1 if drain_result is not None and not drain_result["drained"] else 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
