"""Candidate experiments and the ranking of specification 34.4.

Normative basis: master specification 34.2 (candidate measurands and
candidate experiments) and 34.4 (ranking by

    expected or worst-case reduction in decision ambiguity
    -----------------------------------------------------
                 declared experiment burden

).

Two properties of that ratio are enforced here rather than left to the
caller.

**A zero-information experiment never outranks an informative one.**  The
ratio is a ratio, so an uninformative experiment with a near-zero burden
would otherwise float to the top on arithmetic alone.  Ranking is therefore
*tiered* before it is scored: informative experiments occupy strictly
higher tiers than uninformative ones, and the score only orders within a
tier.  Cheapness cannot buy rank that information did not earn.

**The denominator is guarded.**  A zero declared burden does not divide.
Such an experiment is placed in its own tier above the finite-burden tier
and carries ``score=None``, which is the honest statement that its ratio is
not a rational number rather than a very large one.

Ordering is total and deterministic: tier, then score, then reduction, then
smaller burden, then experiment identity.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from fractions import Fraction
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

from crg_model.canonical import content_hash
from crg_model.envelope import EvidenceClass
from crg_model.numeric import Exact, Interval
from etq_evidence import ContextDescriptor, CorrelationAssumption, MethodDescriptor, UncertaintyBudget

from .ambiguity import AmbiguityError, AmbiguityMetric, InformationEffect, RankingBasis
from .burden import BurdenError, BurdenVector, BurdenWeights

__all__ = [
    "ExperimentError",
    "ResultModelKind",
    "ResultModel",
    "ExperimentDefinition",
    "RankingTier",
    "RankedExperiment",
    "rank_experiments",
]


class ExperimentError(ValueError):
    """Raised when an experiment declaration or ranking request is malformed."""


class ResultModelKind:
    """How the experiment's result will be expressed (14.2 numeric forms)."""

    INTERVAL = "INTERVAL"
    POINT_WITH_UNCERTAINTY = "POINT_WITH_UNCERTAINTY"
    SCENARIO_SET = "SCENARIO_SET"
    BOOLEAN_SCREEN = "BOOLEAN_SCREEN"

    ORDER: Tuple[str, ...] = (INTERVAL, POINT_WITH_UNCERTAINTY, SCENARIO_SET, BOOLEAN_SCREEN)
    ALL = frozenset(ORDER)

    @classmethod
    def check(cls, kind: str) -> str:
        if kind not in cls.ALL:
            raise ExperimentError(
                f"unknown result model {kind!r}; expected one of {', '.join(cls.ORDER)}"
            )
        return kind


@dataclass(frozen=True)
class ResultModel:
    """The declared form and uncertainty of the result an experiment will yield.

    ``expected_width`` is the enclosure width the method is expected to
    deliver; it is what makes a *pre-registered* claim about information
    gain auditable after the fact.
    """

    kind: str
    expected_width: Optional[Exact] = None
    uncertainty: UncertaintyBudget = field(default_factory=UncertaintyBudget)
    correlation_assumption: str = CorrelationAssumption.UNKNOWN
    basis: str = ""

    def __post_init__(self) -> None:
        ResultModelKind.check(self.kind)
        if self.expected_width is not None:
            width = Exact(self.expected_width)
            if width < Exact(0):
                raise ExperimentError("expected_width must be non-negative")
            object.__setattr__(self, "expected_width", width)
        if self.correlation_assumption not in CorrelationAssumption.ALL:
            raise ExperimentError(
                f"unknown correlation assumption {self.correlation_assumption!r} (spec 33.4)"
            )

    def to_canonical(self) -> dict:
        record: dict = {
            "kind": self.kind,
            "correlation_assumption": self.correlation_assumption,
            "uncertainty": self.uncertainty.to_canonical(),
        }
        if self.expected_width is not None:
            record["expected_width"] = self.expected_width.to_canonical()
        if self.basis:
            record["basis"] = self.basis
        return record


@dataclass(frozen=True)
class ExperimentDefinition:
    """A candidate experiment (34.2), complete enough to be ranked (34.4).

    ``measurand`` is the quantity actually measured in ``context`` -- a
    *source*-context quantity, not a technology coordinate.  ``targets``
    names the technology coordinates the measurement can constrain once the
    applicability transformation of 33.3 is applied to it.
    """

    experiment_id: str
    measurand: str
    unit: str
    method: MethodDescriptor
    result_model: ResultModel
    burden: BurdenVector
    context: ContextDescriptor
    expected_information_effect: InformationEffect
    targets: Tuple[str, ...] = ()
    prerequisites: Tuple[str, ...] = ()
    authority: str = ""
    notes: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not str(self.experiment_id).strip():
            raise ExperimentError("an experiment requires an identity")
        if not str(self.measurand).strip():
            raise ExperimentError(
                f"experiment {self.experiment_id!r} names no measurand; 34.2 requires "
                "candidate measurands"
            )
        if not isinstance(self.burden, BurdenVector):
            raise ExperimentError("burden must be a BurdenVector (spec 34.4)")
        if not isinstance(self.expected_information_effect, InformationEffect):
            raise ExperimentError(
                "expected_information_effect must be an InformationEffect (spec 34.4, 34.6)"
            )
        object.__setattr__(self, "targets", tuple(str(t) for t in (self.targets or ())))
        object.__setattr__(
            self, "prerequisites", tuple(str(t) for t in (self.prerequisites or ()))
        )
        object.__setattr__(self, "notes", tuple(str(n) for n in (self.notes or ())))
        if self.expected_information_effect.experiment_id is None:
            object.__setattr__(
                self,
                "expected_information_effect",
                self.expected_information_effect.with_experiment(self.experiment_id),
            )

    @property
    def metric(self) -> str:
        return self.expected_information_effect.metric

    @property
    def evidence_class(self) -> str:
        return self.method.evidence_class

    @property
    def may_authorize(self) -> bool:
        """A heuristic method may rank or propose but never authorize (5.3)."""
        return EvidenceClass.may_authorize(self.method.evidence_class)

    def constrains(self, coordinate_id: str) -> bool:
        return coordinate_id in self.targets

    def to_canonical(self) -> dict:
        record: dict = {
            "experiment_id": self.experiment_id,
            "measurand": self.measurand,
            "unit": self.unit,
            "method": self.method.to_canonical(),
            "result_model": self.result_model.to_canonical(),
            "burden": self.burden.to_canonical(),
            "context": self.context.to_canonical(),
            "expected_information_effect": self.expected_information_effect.to_canonical(),
            "targets": list(self.targets),
        }
        if self.prerequisites:
            record["prerequisites"] = list(self.prerequisites)
        if self.authority:
            record["authority"] = self.authority
        if self.notes:
            record["notes"] = list(self.notes)
        return record

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())


class RankingTier:
    """Ranking tiers, highest first.  Tier dominates score (see module docstring)."""

    #: Positive information and no declared burden: the ratio is undefined,
    #: not enormous, so it is tiered rather than scored.
    INFORMATIVE_ZERO_BURDEN = 2
    #: Positive information and a positive declared burden: the ratio of 34.4.
    INFORMATIVE = 1
    #: Zero or negative information.  Never above an informative experiment,
    #: whatever its burden.
    UNINFORMATIVE = 0

    NAME: Dict[int, str] = {
        INFORMATIVE_ZERO_BURDEN: "INFORMATIVE_ZERO_BURDEN",
        INFORMATIVE: "INFORMATIVE",
        UNINFORMATIVE: "UNINFORMATIVE",
    }


@dataclass(frozen=True)
class RankedExperiment:
    """One experiment's place in the 34.4 ranking, with the ratio shown."""

    rank: int
    experiment: ExperimentDefinition
    information_effect: InformationEffect
    ranking_basis: str
    ambiguity_metric: str
    ambiguity_reduction: Exact
    burden_scalar: Optional[Exact]
    score: Optional[Exact]
    tier: int
    informative: bool
    excluded_reason: Optional[str] = None
    basis: str = ""

    @property
    def experiment_id(self) -> str:
        return self.experiment.experiment_id

    @property
    def tier_name(self) -> str:
        return RankingTier.NAME[self.tier]

    @property
    def burden(self) -> BurdenVector:
        return self.experiment.burden

    def to_canonical(self) -> dict:
        record: dict = {
            "rank": self.rank,
            "experiment_id": self.experiment_id,
            "tier": self.tier,
            "tier_name": self.tier_name,
            "informative": self.informative,
            "ranking_basis": self.ranking_basis,
            "ambiguity_metric": self.ambiguity_metric,
            "ambiguity_reduction": self.ambiguity_reduction.to_canonical(),
            "information_effect": self.information_effect.to_canonical(),
            "burden": self.experiment.burden.to_canonical(),
        }
        if self.burden_scalar is not None:
            record["burden_scalar"] = self.burden_scalar.to_canonical()
        if self.score is not None:
            record["score"] = self.score.to_canonical()
        if self.excluded_reason:
            record["excluded_reason"] = self.excluded_reason
        if self.basis:
            record["basis"] = self.basis
        return record

    def render(self) -> str:
        score = "n/a (zero declared burden)" if self.score is None else str(self.score)
        return (
            f"{self.rank:>2}. {self.experiment_id:<24} {self.tier_name:<24} "
            f"reduction={self.ambiguity_reduction} burden={self.burden_scalar} score={score}"
        )


AmbiguityFn = Callable[[ExperimentDefinition], InformationEffect]


def rank_experiments(
    experiments: Sequence[ExperimentDefinition],
    ambiguity_fn: Optional[AmbiguityFn] = None,
    *,
    burden_weights: BurdenWeights,
    basis: str = RankingBasis.EXPECTED,
) -> List[RankedExperiment]:
    """Rank candidate experiments by the ratio of specification 34.4.

    ``ambiguity_fn`` maps an experiment to the :class:`InformationEffect` it
    is credited with.  Passing ``None`` uses each experiment's own declared
    ``expected_information_effect``, which is the pre-registered claim.

    All effects must share one ambiguity metric; mixing metrics raises,
    because 34.4's numerator is a reduction *in a stated metric* and two
    metrics do not share a scale.

    The returned list is ordered best-first and every candidate appears in
    it, including uninformative ones -- a plan needs to record what it
    declined as much as what it selected.
    """
    RankingBasis.check(basis)
    if burden_weights is None:
        raise ExperimentError(
            "ranking requires declared burden weights; specification 34.4 divides "
            "by a declared burden"
        )
    candidates = tuple(experiments or ())
    ids = [e.experiment_id for e in candidates]
    if len(set(ids)) != len(ids):
        raise ExperimentError("duplicate experiment identity in the candidate set")

    resolve: AmbiguityFn = ambiguity_fn or (lambda e: e.expected_information_effect)

    scored: List[RankedExperiment] = []
    metric: Optional[str] = None
    for experiment in candidates:
        effect = resolve(experiment)
        if not isinstance(effect, InformationEffect):
            raise ExperimentError(
                f"ambiguity_fn returned {type(effect)!r} for {experiment.experiment_id!r}; "
                "an InformationEffect is required (spec 34.4)"
            )
        if metric is None:
            metric = effect.metric
        elif effect.metric != metric:
            raise AmbiguityError(
                "candidate experiments declare reductions on different ambiguity "
                f"metrics ({metric} versus {effect.metric}); 34.4 ranks within one "
                "stated metric"
            )

        reduction = effect.reduction(basis)
        informative = reduction > Exact(0)

        burden_scalar: Optional[Exact]
        excluded: Optional[str] = None
        try:
            burden_scalar = burden_weights.scalarize(experiment.burden)
        except BurdenError as exc:
            burden_scalar = None
            excluded = f"BURDEN_NOT_DECLARED: {exc}"

        score: Optional[Exact] = None
        if excluded is not None:
            # An unquotable denominator cannot be ranked on the 34.4 ratio.
            # It is tiered below every rankable experiment, informative or not.
            tier = RankingTier.UNINFORMATIVE
            informative = False
        elif not informative:
            tier = RankingTier.UNINFORMATIVE
            excluded = (
                "ZERO_OR_NEGATIVE_INFORMATION: the declared reduction on "
                f"{effect.metric} is {reduction}; specification 34.4's numerator is "
                "not positive, so no burden makes this experiment worth running"
            )
        elif burden_scalar is not None and burden_scalar > Exact(0):
            tier = RankingTier.INFORMATIVE
            score = reduction / burden_scalar
        else:
            tier = RankingTier.INFORMATIVE_ZERO_BURDEN
            excluded = (
                "ZERO_DECLARED_BURDEN: the 34.4 ratio has no value; ranked above "
                "finite-burden experiments by tier rather than by an invented score"
            )

        scored.append(
            RankedExperiment(
                rank=0,
                experiment=experiment,
                information_effect=effect,
                ranking_basis=basis,
                ambiguity_metric=effect.metric,
                ambiguity_reduction=reduction,
                burden_scalar=burden_scalar,
                score=score,
                tier=tier,
                informative=informative,
                excluded_reason=excluded,
                basis=(
                    "specification 34.4: (expected or worst-case reduction in decision "
                    "ambiguity) / (declared experiment burden)"
                ),
            )
        )

    def sort_key(item: RankedExperiment):
        score = item.score.value if item.score is not None else Fraction(0)
        burden = item.burden_scalar.value if item.burden_scalar is not None else Fraction(0)
        return (
            -item.tier,
            -score,
            -item.ambiguity_reduction.value,
            burden,
            item.experiment_id,
        )

    ordered = sorted(scored, key=sort_key)
    return [
        RankedExperiment(
            rank=index + 1,
            experiment=item.experiment,
            information_effect=item.information_effect,
            ranking_basis=item.ranking_basis,
            ambiguity_metric=item.ambiguity_metric,
            ambiguity_reduction=item.ambiguity_reduction,
            burden_scalar=item.burden_scalar,
            score=item.score,
            tier=item.tier,
            informative=item.informative,
            excluded_reason=item.excluded_reason,
            basis=item.basis,
        )
        for index, item in enumerate(ordered)
    ]
