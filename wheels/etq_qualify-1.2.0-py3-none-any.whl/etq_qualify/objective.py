"""The qualification objective: what is to be decided, and when to stop.

Normative basis: master specification 34.2 (inputs to inverse
qualification) and 34.5 (stopping rules).

A decision predicate is written in the normative form of 34.3,

    g(theta) = sum_i c_i * theta_i - threshold >= 0,

with exact rational coefficients.  A *phase region* is the conjunction of
one or more such predicates, which is how 34.2's "phase region or decision
predicate" is represented here: one object covers both inputs, and a
single predicate is the one-element case.

The governing refusal of this module is 34.5: **a qualification plan MUST
state a stopping condition.**  :class:`QualificationObjective` raises when
its ``stopping_rules`` are empty, so an objective with no declared stop
cannot be constructed, let alone inverted into a plan.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, Mapping, Optional, Sequence, Tuple

from crg_model.canonical import content_hash
from crg_model.numeric import Exact, Interval

from .ambiguity import AmbiguityMetric, PredicateState, RankingBasis
from .burden import BurdenLimits, BurdenVector, BurdenWeights

__all__ = [
    "QualificationError",
    "DecisionPredicate",
    "PhaseRegion",
    "AcceptableAmbiguity",
    "StoppingCondition",
    "StoppingRule",
    "QualificationObjective",
]


class QualificationError(ValueError):
    """Raised when a qualification input violates specification 34."""


@dataclass(frozen=True)
class DecisionPredicate:
    """``g(theta) >= 0`` in the normative form of specification 34.3.

    ``coefficients`` are the exact rational ``c_i`` on each technology
    coordinate ``theta_i``; ``threshold`` is subtracted.  A coordinate with
    a zero coefficient does not appear: it cannot influence the sign of
    ``g`` and therefore is not part of the sufficient coordinate set.
    """

    predicate_id: str
    coefficients: Tuple[Tuple[str, Exact], ...]
    threshold: Exact = Exact(0)
    basis: str = ""

    def __init__(
        self,
        predicate_id: str,
        coefficients: Any,
        threshold: Any = 0,
        basis: str = "",
    ) -> None:
        if isinstance(coefficients, Mapping):
            pairs: Iterable[Tuple[Any, Any]] = coefficients.items()
        else:
            pairs = tuple(coefficients or ())
        seen: Dict[str, Exact] = {}
        for item in pairs:
            try:
                name, value = item
            except (TypeError, ValueError) as exc:
                raise QualificationError(
                    "predicate coefficients must be (coordinate_id, coefficient) pairs"
                ) from exc
            name = str(name)
            if name in seen:
                raise QualificationError(f"coordinate {name!r} carries two coefficients")
            seen[name] = Exact(value)
        kept = tuple((name, seen[name]) for name in sorted(seen) if seen[name] != Exact(0))
        if not kept:
            raise QualificationError(
                f"predicate {predicate_id!r} has no coordinate with a non-zero "
                "coefficient; there is nothing to qualify (spec 34.3)"
            )
        object.__setattr__(self, "predicate_id", str(predicate_id))
        object.__setattr__(self, "coefficients", kept)
        object.__setattr__(self, "threshold", Exact(threshold))
        object.__setattr__(self, "basis", str(basis))

    @property
    def coordinates(self) -> Tuple[str, ...]:
        """The coordinate set sufficient to establish the predicate (34.3.i)."""
        return tuple(name for name, _ in self.coefficients)

    def coefficient(self, coordinate_id: str) -> Exact:
        for name, value in self.coefficients:
            if name == coordinate_id:
                return value
        return Exact(0)

    def worst_case_point(self, bounds: Mapping[str, Interval]) -> Optional[Dict[str, Exact]]:
        """The vertex of the box minimizing ``g``; ``None`` if a bound is absent.

        ``g`` is affine, so its minimum over an interval box sits at the
        vertex that takes each coordinate's lower end where its coefficient
        is positive and its upper end where the coefficient is negative.
        """
        point: Dict[str, Exact] = {}
        for name, c in self.coefficients:
            enclosure = bounds.get(name)
            if enclosure is None:
                return None
            point[name] = enclosure.lo if c > Exact(0) else enclosure.hi
        return point

    def evaluate(self, bounds: Mapping[str, Interval]) -> Optional[Interval]:
        """Exact interval enclosure of ``g`` over the coordinate box.

        Returns ``None`` when any coordinate the predicate depends on has no
        bound: an absent coordinate constrains nothing, and inventing an
        enclosure for it would be the "assumed default" forbidden by 33.3.
        """
        total = Interval(0, 0)
        for name, c in self.coefficients:
            enclosure = bounds.get(name)
            if enclosure is None:
                return None
            total = total + enclosure.scale(c)
        return total - Interval(self.threshold, self.threshold)

    def state(self, bounds: Mapping[str, Interval]) -> str:
        value = self.evaluate(bounds)
        if value is None:
            return PredicateState.UNDETERMINED
        if value.lo >= Exact(0):
            return PredicateState.GUARANTEED_SATISFIED
        if value.hi < Exact(0):
            return PredicateState.GUARANTEED_VIOLATED
        return PredicateState.AMBIGUOUS

    def render(self) -> str:
        terms = " + ".join(f"({c})*{name}" for name, c in self.coefficients)
        return f"g_{self.predicate_id}(theta) = {terms} - ({self.threshold}) >= 0"

    def to_canonical(self) -> dict:
        record: dict = {
            "predicate_id": self.predicate_id,
            "form": "sum(c_i * theta_i) - threshold >= 0",
            "coefficients": {name: c.to_canonical() for name, c in self.coefficients},
            "threshold": self.threshold.to_canonical(),
            "coordinates": list(self.coordinates),
        }
        if self.basis:
            record["basis"] = self.basis
        return record

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())


@dataclass(frozen=True)
class PhaseRegion:
    """A conjunction of decision predicates (34.2: "phase region or predicate").

    The region holds exactly when every member predicate holds.  A single
    predicate is the degenerate one-element region, so callers never have to
    choose between the two inputs 34.2 offers.
    """

    region_id: str
    predicates: Tuple[DecisionPredicate, ...]
    basis: str = ""

    def __init__(
        self,
        region_id: str,
        predicates: Sequence[DecisionPredicate],
        basis: str = "",
    ) -> None:
        members = tuple(predicates or ())
        if not members:
            raise QualificationError(
                f"phase region {region_id!r} declares no predicate; 34.2 requires a "
                "phase region or decision predicate"
            )
        ids = [p.predicate_id for p in members]
        if len(set(ids)) != len(ids):
            raise QualificationError("phase region contains duplicate predicate identities")
        object.__setattr__(self, "region_id", str(region_id))
        object.__setattr__(self, "predicates", members)
        object.__setattr__(self, "basis", str(basis))

    @classmethod
    def single(cls, predicate: DecisionPredicate) -> "PhaseRegion":
        return cls(f"region-{predicate.predicate_id}", (predicate,), basis=predicate.basis)

    @property
    def coordinates(self) -> Tuple[str, ...]:
        """Union of the sufficient coordinate sets, in canonical order (34.3.i)."""
        seen: list = []
        for predicate in self.predicates:
            for name in predicate.coordinates:
                if name not in seen:
                    seen.append(name)
        return tuple(sorted(seen))

    def predicate(self, predicate_id: str) -> DecisionPredicate:
        for candidate in self.predicates:
            if candidate.predicate_id == predicate_id:
                return candidate
        raise KeyError(predicate_id)

    def states(self, bounds: Mapping[str, Interval]) -> Tuple[str, ...]:
        return tuple(p.state(bounds) for p in self.predicates)

    def state(self, bounds: Mapping[str, Interval]) -> str:
        """Conjunction: one violation decides the region; one gap suspends it."""
        states = self.states(bounds)
        if PredicateState.GUARANTEED_VIOLATED in states:
            return PredicateState.GUARANTEED_VIOLATED
        if PredicateState.UNDETERMINED in states:
            return PredicateState.UNDETERMINED
        if PredicateState.AMBIGUOUS in states:
            return PredicateState.AMBIGUOUS
        return PredicateState.GUARANTEED_SATISFIED

    def to_canonical(self) -> dict:
        record: dict = {
            "region_id": self.region_id,
            "semantics": "conjunction of g_j(theta) >= 0",
            "predicates": [p.to_canonical() for p in self.predicates],
            "coordinates": list(self.coordinates),
        }
        if self.basis:
            record["basis"] = self.basis
        return record

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())


@dataclass(frozen=True)
class AcceptableAmbiguity:
    """Declared acceptable ambiguity (34.2), stated on one named metric (34.4)."""

    metric: str
    threshold: Exact
    basis: str = ""

    def __init__(self, metric: str, threshold: Any, basis: str = "") -> None:
        object.__setattr__(self, "metric", AmbiguityMetric.check(str(metric)))
        value = Exact(threshold)
        if value < Exact(0):
            raise QualificationError("acceptable ambiguity threshold must be non-negative")
        object.__setattr__(self, "threshold", value)
        object.__setattr__(self, "basis", str(basis))

    def satisfied_by(self, ambiguity: Exact) -> bool:
        return ambiguity <= self.threshold

    def to_canonical(self) -> dict:
        record: dict = {"metric": self.metric, "threshold": self.threshold.to_canonical()}
        if self.basis:
            record["basis"] = self.basis
        return record


class StoppingCondition:
    """Specification 34.5.  All eight conditions the specification names."""

    UNIQUE_GUARANTEED_WINNER = "UNIQUE_GUARANTEED_WINNER"
    CAPABILITY_ESTABLISHED = "CAPABILITY_ESTABLISHED"
    CAPABILITY_RULED_OUT = "CAPABILITY_RULED_OUT"
    REGRET_BELOW_THRESHOLD = "REGRET_BELOW_THRESHOLD"
    UNCERTAINTY_BELOW_THRESHOLD = "UNCERTAINTY_BELOW_THRESHOLD"
    BURDEN_LIMIT_REACHED = "BURDEN_LIMIT_REACHED"
    NO_INFORMATIVE_EXPERIMENT_REMAINS = "NO_INFORMATIVE_EXPERIMENT_REMAINS"
    MANUAL_ADJUDICATION_REQUIRED = "MANUAL_ADJUDICATION_REQUIRED"

    ORDER: Tuple[str, ...] = (
        UNIQUE_GUARANTEED_WINNER,
        CAPABILITY_ESTABLISHED,
        CAPABILITY_RULED_OUT,
        REGRET_BELOW_THRESHOLD,
        UNCERTAINTY_BELOW_THRESHOLD,
        BURDEN_LIMIT_REACHED,
        NO_INFORMATIVE_EXPERIMENT_REMAINS,
        MANUAL_ADJUDICATION_REQUIRED,
    )
    ALL = frozenset(ORDER)

    #: Conditions that are meaningless without a declared numeric threshold.
    THRESHOLD_REQUIRED = frozenset({REGRET_BELOW_THRESHOLD, UNCERTAINTY_BELOW_THRESHOLD})

    @classmethod
    def check(cls, condition: str) -> str:
        if condition not in cls.ALL:
            raise QualificationError(
                f"unknown stopping condition {condition!r}; specification 34.5 names "
                f"{', '.join(cls.ORDER)}"
            )
        return condition


#: The reason string returned by ``stopping_reached`` when no declared rule fires.
NOT_STOPPED = "CONTINUE"


@dataclass(frozen=True)
class StoppingRule:
    """One declared stopping condition (34.5), with its threshold where required."""

    condition: str
    threshold: Optional[Exact] = None
    metric: Optional[str] = None
    basis: str = ""

    def __init__(
        self,
        condition: str,
        threshold: Any = None,
        metric: Optional[str] = None,
        basis: str = "",
    ) -> None:
        condition = StoppingCondition.check(str(condition))
        value = None if threshold is None else Exact(threshold)
        if condition in StoppingCondition.THRESHOLD_REQUIRED and value is None:
            raise QualificationError(
                f"stopping condition {condition} requires a declared threshold; "
                "an undeclared threshold cannot be reached (spec 34.5)"
            )
        if value is not None and value < Exact(0):
            raise QualificationError("a stopping threshold must be non-negative")
        if metric is not None:
            AmbiguityMetric.check(str(metric))
        object.__setattr__(self, "condition", condition)
        object.__setattr__(self, "threshold", value)
        object.__setattr__(self, "metric", None if metric is None else str(metric))
        object.__setattr__(self, "basis", str(basis))

    def to_canonical(self) -> dict:
        record: dict = {"condition": self.condition}
        if self.threshold is not None:
            record["threshold"] = self.threshold.to_canonical()
        if self.metric is not None:
            record["metric"] = self.metric
        if self.basis:
            record["basis"] = self.basis
        return record


@dataclass(frozen=True)
class QualificationObjective:
    """The inputs of specification 34.2, in one object.

    ``desired_state`` is the desired realization or architecture state;
    ``region`` is the phase region or decision predicate; the remaining
    fields carry acceptable ambiguity, burden constraints, the stopping
    rule, and the authority under which the qualification is run.

    Construction raises when ``stopping_rules`` is empty (34.5) or when no
    authority is declared (34.2): both are refusals, not defaults.
    """

    objective_id: str
    desired_state: str
    region: PhaseRegion
    acceptable_ambiguity: AcceptableAmbiguity
    stopping_rules: Tuple[StoppingRule, ...]
    authority: str
    burden_limits: BurdenLimits = field(default_factory=BurdenLimits.none)
    burden_weights: Optional[BurdenWeights] = None
    ranking_basis: str = RankingBasis.EXPECTED
    prior_bounds: Tuple[Tuple[str, Interval], ...] = ()
    prior_bounds_basis: str = ""
    notes: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not isinstance(self.region, PhaseRegion):
            raise QualificationError("region must be a PhaseRegion (spec 34.2)")
        rules = tuple(self.stopping_rules or ())
        if not rules:
            raise QualificationError(
                "a qualification objective declares no stopping rule; specification "
                "34.5 requires a qualification plan to state a stopping condition, "
                "so an objective without one cannot be inverted into a valid plan"
            )
        conditions = [rule.condition for rule in rules]
        if len(set(conditions)) != len(conditions):
            raise QualificationError("a stopping condition is declared twice")
        object.__setattr__(self, "stopping_rules", rules)
        if not str(self.authority).strip():
            raise QualificationError(
                "no authority declared; specification 34.2 lists authority among the "
                "required inputs to inverse qualification"
            )
        RankingBasis.check(self.ranking_basis)
        object.__setattr__(
            self,
            "prior_bounds",
            tuple((str(name), value) for name, value in (self.prior_bounds or ())),
        )
        object.__setattr__(self, "notes", tuple(str(n) for n in (self.notes or ())))

    @property
    def coordinates(self) -> Tuple[str, ...]:
        return self.region.coordinates

    @property
    def declared_conditions(self) -> Tuple[str, ...]:
        return tuple(rule.condition for rule in self.stopping_rules)

    def stopping_rule(self, condition: str) -> Optional[StoppingRule]:
        for rule in self.stopping_rules:
            if rule.condition == condition:
                return rule
        return None

    def prior_bound(self, coordinate_id: str) -> Optional[Interval]:
        for name, value in self.prior_bounds:
            if name == coordinate_id:
                return value
        return None

    def effective_burden_weights(self) -> Optional[BurdenWeights]:
        return self.burden_weights

    def to_canonical(self) -> dict:
        record: dict = {
            "objective_id": self.objective_id,
            "desired_state": self.desired_state,
            "region": self.region.to_canonical(),
            "acceptable_ambiguity": self.acceptable_ambiguity.to_canonical(),
            "stopping_rules": [rule.to_canonical() for rule in self.stopping_rules],
            "authority": self.authority,
            "burden_limits": self.burden_limits.to_canonical(),
            "ranking_basis": self.ranking_basis,
        }
        if self.burden_weights is not None:
            record["burden_weights"] = self.burden_weights.to_canonical()
        if self.prior_bounds:
            record["prior_bounds"] = {
                name: value.to_canonical() for name, value in self.prior_bounds
            }
            record["prior_bounds_basis"] = self.prior_bounds_basis
        if self.notes:
            record["notes"] = list(self.notes)
        return record

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())
