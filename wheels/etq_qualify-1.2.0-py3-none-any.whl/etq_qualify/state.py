"""Qualification state: what is currently known, spent, and left to run.

Normative basis: master specification 34.4 (ambiguity metrics), 34.5
(stopping rules evaluate against a state), and 34.6 (residual ambiguity as
a required output).

The state is immutable.  Every ingestion produces a new state and keeps the
prior one, so a qualification campaign is an auditable chain rather than a
mutated object.  Coordinate bounds are exact intervals; ambiguity is an
exact rational on one declared metric.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Mapping, Optional, Sequence, Tuple

from crg_model.canonical import content_hash
from crg_model.numeric import Exact, Interval

from .ambiguity import (
    AmbiguityMetric,
    BOUNDS_DERIVABLE_METRICS,
    PredicateState,
    feasibility_ambiguity,
    guaranteed_versus_possible_gap,
    interval_width,
    phase_boundary_uncertainty,
)
from .burden import BurdenVector
from .objective import PhaseRegion

__all__ = ["QualificationState", "region_ambiguity"]


def region_ambiguity(
    region: PhaseRegion, bounds: Mapping[str, Interval], metric: str
) -> Optional[Exact]:
    """Evaluate an ambiguity metric of 34.4 from exact coordinate bounds.

    Returns ``None`` when the metric cannot be derived from bounds alone --
    possible-winner-set size, entropy, and regret upper bound all need the
    CRG decision machinery or a declared observation.  ``None`` is a
    refusal to invent a number, not a zero.
    """
    AmbiguityMetric.check(metric)
    if metric not in BOUNDS_DERIVABLE_METRICS:
        return None

    if metric == AmbiguityMetric.FEASIBILITY_AMBIGUITY:
        return feasibility_ambiguity(region.states(bounds))

    per_predicate = {
        AmbiguityMetric.INTERVAL_WIDTH: interval_width,
        AmbiguityMetric.GUARANTEED_VERSUS_POSSIBLE_GAP: guaranteed_versus_possible_gap,
        AmbiguityMetric.PHASE_BOUNDARY_UNCERTAINTY: phase_boundary_uncertainty,
    }[metric]

    total = Exact(0)
    for predicate in region.predicates:
        value = predicate.evaluate(bounds)
        if value is None:
            return None
        contribution = per_predicate(value)
        if contribution is None:  # pragma: no cover - guarded above
            return None
        total = total + contribution
    return total


@dataclass(frozen=True)
class QualificationState:
    """A snapshot of the campaign against which 34.5 stopping rules are tested."""

    plan_id: str
    coordinate_bounds: Tuple[Tuple[str, Interval], ...]
    predicate_state: str
    ambiguity_metric: str
    ambiguity: Exact
    cumulative_burden: BurdenVector = field(default_factory=BurdenVector)
    completed_experiments: Tuple[str, ...] = ()
    remaining_experiments: Tuple[str, ...] = ()
    informative_remaining: Tuple[str, ...] = ()
    ambiguity_derivable: bool = True
    regret_upper_bound: Optional[Exact] = None
    possible_winners: Tuple[str, ...] = ()
    guaranteed_winner: Optional[str] = None
    manual_adjudication_required: bool = False
    manual_adjudication_reason: str = ""
    step: int = 0
    notes: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        AmbiguityMetric.check(self.ambiguity_metric)
        if self.predicate_state not in PredicateState.ALL:
            raise ValueError(f"unknown predicate state {self.predicate_state!r}")
        object.__setattr__(
            self,
            "coordinate_bounds",
            tuple(sorted(((str(k), v) for k, v in self.coordinate_bounds), key=lambda p: p[0])),
        )
        object.__setattr__(self, "ambiguity", Exact(self.ambiguity))
        object.__setattr__(
            self, "completed_experiments", tuple(str(e) for e in self.completed_experiments)
        )
        object.__setattr__(
            self, "remaining_experiments", tuple(str(e) for e in self.remaining_experiments)
        )
        object.__setattr__(
            self, "informative_remaining", tuple(str(e) for e in self.informative_remaining)
        )
        object.__setattr__(self, "possible_winners", tuple(str(w) for w in self.possible_winners))
        object.__setattr__(self, "notes", tuple(str(n) for n in self.notes))
        if self.regret_upper_bound is not None:
            object.__setattr__(self, "regret_upper_bound", Exact(self.regret_upper_bound))

    def bounds_map(self) -> Dict[str, Interval]:
        return {name: value for name, value in self.coordinate_bounds}

    def bound(self, coordinate_id: str) -> Optional[Interval]:
        return self.bounds_map().get(coordinate_id)

    @property
    def resolved(self) -> bool:
        return self.predicate_state in PredicateState.RESOLVED

    @property
    def unique_guaranteed_winner(self) -> bool:
        """A single realization is guaranteed to win (34.5)."""
        if self.guaranteed_winner is None:
            return False
        if not self.possible_winners:
            return True
        return set(self.possible_winners) == {self.guaranteed_winner}

    def to_canonical(self) -> dict:
        record: dict = {
            "plan_id": self.plan_id,
            "step": self.step,
            "coordinate_bounds": {
                name: value.to_canonical() for name, value in self.coordinate_bounds
            },
            "predicate_state": self.predicate_state,
            "ambiguity_metric": self.ambiguity_metric,
            "ambiguity": self.ambiguity.to_canonical(),
            "ambiguity_derivable": self.ambiguity_derivable,
            "cumulative_burden": self.cumulative_burden.to_canonical(),
            "completed_experiments": list(self.completed_experiments),
            "remaining_experiments": list(self.remaining_experiments),
            "informative_remaining": list(self.informative_remaining),
            "manual_adjudication_required": self.manual_adjudication_required,
        }
        if self.regret_upper_bound is not None:
            record["regret_upper_bound"] = self.regret_upper_bound.to_canonical()
        if self.possible_winners:
            record["possible_winners"] = list(self.possible_winners)
        if self.guaranteed_winner is not None:
            record["guaranteed_winner"] = self.guaranteed_winner
        if self.manual_adjudication_reason:
            record["manual_adjudication_reason"] = self.manual_adjudication_reason
        if self.notes:
            record["notes"] = list(self.notes)
        return record

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())
