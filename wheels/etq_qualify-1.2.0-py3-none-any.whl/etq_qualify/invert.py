"""Qualification inversion: from a decision predicate back to experiments.

Normative basis: master specification 34.3 (qualification inversion) and
34.6 (the qualification plan output), with 34.4 (ranking) and 34.5
(stopping rules) applied at the end of the chain.

Specification 34.3 is a *direction*, not a list of deliverables.  Given
``g(theta) >= 0`` the engine determines, in order:

    1. the coordinate set sufficient to establish the predicate;
    2. the source-context evidence capable of constraining that set;
    3. the applicability transformations mapping evidence to theta;
    4. measurable targets and tolerances;
    5. experiments capable of resolving remaining ambiguity; and
    6. the expected effect on the CRG decision.

:func:`invert` walks exactly that chain and records it in
:attr:`QualificationPlan.inversion_trace`.  The trace is not decoration:
:class:`QualificationPlan` validates that step *n* consumes only identities
that steps ``1..n-1`` produced, so a plan assembled by solving forward and
relabelling the answer cannot be constructed.  The arithmetic is backward
too -- a measurable target is obtained by *solving* ``g >= 0`` for one
coordinate while every other coordinate sits at its worst case, and then
pulling that coordinate bound back through the inverse of the applicability
transformation into the units of the thing an instrument can actually
measure.

The plan carries the eleven items of 34.6 and refuses to exist without a
stopping rule (34.5).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Mapping, Optional, Sequence, Tuple

from crg_model.canonical import content_hash
from crg_model.numeric import Exact, Interval
from etq_evidence import (
    ApplicabilityRule,
    TechnologyContract,
    TransformationKind,
    VerificationClock,
)

from .ambiguity import (
    AmbiguityMetric,
    InformationEffect,
    PredicateState,
    RankingBasis,
)
from .burden import BurdenLimits, BurdenVector, BurdenWeights
from .experiment import (
    ExperimentDefinition,
    RankedExperiment,
    RankingTier,
    rank_experiments,
)
from .objective import (
    DecisionPredicate,
    NOT_STOPPED,
    QualificationError,
    QualificationObjective,
    StoppingCondition,
    StoppingRule,
)
from .state import QualificationState, region_ambiguity

__all__ = [
    "InversionStep",
    "InversionRecord",
    "CoordinateNeed",
    "EvidenceNeed",
    "TransformationPath",
    "TargetStatus",
    "MeasurableTarget",
    "QualificationPlan",
    "PLAN_REQUIRED_ITEMS",
    "invert",
]


class InversionStep:
    """The six steps of specification 34.3, in their normative order."""

    COORDINATE_SET = "COORDINATE_SET"
    SOURCE_EVIDENCE = "SOURCE_EVIDENCE"
    APPLICABILITY_TRANSFORMATIONS = "APPLICABILITY_TRANSFORMATIONS"
    MEASURABLE_TARGETS = "MEASURABLE_TARGETS"
    RESOLVING_EXPERIMENTS = "RESOLVING_EXPERIMENTS"
    DECISION_EFFECT = "DECISION_EFFECT"

    ORDER: Tuple[str, ...] = (
        COORDINATE_SET,
        SOURCE_EVIDENCE,
        APPLICABILITY_TRANSFORMATIONS,
        MEASURABLE_TARGETS,
        RESOLVING_EXPERIMENTS,
        DECISION_EFFECT,
    )
    ALL = frozenset(ORDER)

    CITATION: Dict[str, str] = {
        COORDINATE_SET: "34.3(1) the coordinate set sufficient to establish the predicate",
        SOURCE_EVIDENCE: "34.3(2) source-context evidence capable of constraining that set",
        APPLICABILITY_TRANSFORMATIONS: "34.3(3) applicability transformations mapping evidence to theta",
        MEASURABLE_TARGETS: "34.3(4) measurable targets and tolerances",
        RESOLVING_EXPERIMENTS: "34.3(5) experiments capable of resolving remaining ambiguity",
        DECISION_EFFECT: "34.3(6) the expected effect on the CRG decision",
    }


@dataclass(frozen=True)
class InversionRecord:
    """One step of the 34.3 chain, with what it consumed and what it produced."""

    step: str
    index: int
    spec_citation: str
    derived_from: Optional[str]
    inputs: Tuple[str, ...]
    outputs: Tuple[str, ...]
    detail: str = ""

    def __post_init__(self) -> None:
        if self.step not in InversionStep.ALL:
            raise QualificationError(f"unknown inversion step {self.step!r}")
        object.__setattr__(self, "inputs", tuple(str(i) for i in self.inputs))
        object.__setattr__(self, "outputs", tuple(str(o) for o in self.outputs))

    def to_canonical(self) -> dict:
        record: dict = {
            "step": self.step,
            "index": self.index,
            "spec_citation": self.spec_citation,
            "inputs": list(self.inputs),
            "outputs": list(self.outputs),
        }
        if self.derived_from is not None:
            record["derived_from"] = self.derived_from
        if self.detail:
            record["detail"] = self.detail
        return record


@dataclass(frozen=True)
class CoordinateNeed:
    """34.3(1): one member of the sufficient coordinate set."""

    coordinate_id: str
    coefficients: Tuple[Tuple[str, Exact], ...]
    bound: Optional[Interval]
    bound_source: str
    sensitivity: Optional[Exact]
    resolved: bool
    basis: str = ""

    #: Where the current enclosure came from.
    FROM_CONTRACT = "TECHNOLOGY_CONTRACT"
    FROM_PRIOR = "DECLARED_PRIOR"
    UNBOUNDED = "UNBOUNDED"

    @property
    def bounded(self) -> bool:
        return self.bound is not None

    def to_canonical(self) -> dict:
        record: dict = {
            "coordinate_id": self.coordinate_id,
            "coefficients": {p: c.to_canonical() for p, c in self.coefficients},
            "bound_source": self.bound_source,
            "resolved": self.resolved,
        }
        if self.bound is not None:
            record["bound"] = self.bound.to_canonical()
        if self.sensitivity is not None:
            record["sensitivity"] = self.sensitivity.to_canonical()
        if self.basis:
            record["basis"] = self.basis
        return record


@dataclass(frozen=True)
class EvidenceNeed:
    """34.3(2): the source-context evidence able to constrain one coordinate."""

    coordinate_id: str
    evidence_ids: Tuple[str, ...] = ()
    evidence_hashes: Tuple[str, ...] = ()
    source_context_fingerprints: Tuple[str, ...] = ()
    candidate_source_contexts: Tuple[str, ...] = ()
    rule_ids: Tuple[str, ...] = ()
    bounded_by_existing_evidence: bool = False
    further_evidence_required: bool = True
    basis: str = ""

    @property
    def token(self) -> str:
        """Identity this need contributes to the inversion trace."""
        return f"evidence-need:{self.coordinate_id}"

    def to_canonical(self) -> dict:
        record: dict = {
            "coordinate_id": self.coordinate_id,
            "evidence_ids": list(self.evidence_ids),
            "evidence_hashes": list(self.evidence_hashes),
            "source_context_fingerprints": list(self.source_context_fingerprints),
            "candidate_source_contexts": list(self.candidate_source_contexts),
            "rule_ids": list(self.rule_ids),
            "bounded_by_existing_evidence": self.bounded_by_existing_evidence,
            "further_evidence_required": self.further_evidence_required,
        }
        if self.basis:
            record["basis"] = self.basis
        return record


@dataclass(frozen=True)
class TransformationPath:
    """34.3(3): the applicability transformation carrying evidence to ``theta``.

    ``invertible`` records whether the target derivation of 34.3(4) can pull
    a coordinate bound back through this map.  A scenario-set transformation
    is not a function of one variable and is therefore not inverted; the
    plan says so instead of picking a scenario.
    """

    coordinate_id: str
    rule_id: str
    rule_version: str
    rule_hash: str
    transformation_kind: str
    scale: Exact
    offset: Exact
    input_quantity: str
    input_unit: str
    output_quantity: str
    output_unit: str
    transfer_model_id: str
    transfer_model_kind: str
    #: Half-width the 33.3 transfer-uncertainty model adds on the coordinate
    #: side, evaluated at the coordinate's current enclosure.  It becomes the
    #: tolerance of the measurable target once divided by ``|scale|``.
    transfer_tolerance: Exact
    correlation_assumption: str
    minimum_evidence_status: str
    authority: str
    invertible: bool
    not_invertible_reason: str = ""
    basis: str = ""

    def to_canonical(self) -> dict:
        record: dict = {
            "coordinate_id": self.coordinate_id,
            "rule_id": self.rule_id,
            "rule_version": self.rule_version,
            "rule_hash": self.rule_hash,
            "transformation_kind": self.transformation_kind,
            "scale": self.scale.to_canonical(),
            "offset": self.offset.to_canonical(),
            "input_quantity": self.input_quantity,
            "input_unit": self.input_unit,
            "output_quantity": self.output_quantity,
            "output_unit": self.output_unit,
            "transfer_model_id": self.transfer_model_id,
            "transfer_model_kind": self.transfer_model_kind,
            "transfer_tolerance": self.transfer_tolerance.to_canonical(),
            "correlation_assumption": self.correlation_assumption,
            "minimum_evidence_status": self.minimum_evidence_status,
            "authority": self.authority,
            "invertible": self.invertible,
        }
        if self.not_invertible_reason:
            record["not_invertible_reason"] = self.not_invertible_reason
        if self.basis:
            record["basis"] = self.basis
        return record


class TargetStatus:
    """Whether the current enclosure already meets a derived target."""

    MET = "MET"
    VIOLATED = "VIOLATED"
    AMBIGUOUS = "AMBIGUOUS"
    #: The target could not be derived -- an unbounded companion coordinate or
    #: a non-invertible transformation.  Not a failure of the target, a
    #: refusal to state one.
    UNDERIVABLE = "UNDERIVABLE"

    ALL = frozenset({MET, VIOLATED, AMBIGUOUS, UNDERIVABLE})


@dataclass(frozen=True)
class MeasurableTarget:
    """34.3(4): a target and tolerance stated on something measurable.

    ``coordinate_threshold`` is what ``g >= 0`` demands of the coordinate
    while all other coordinates sit at their worst case.
    ``measurand_threshold`` is that demand pulled back through the inverse
    applicability transformation and widened by the transfer tolerance, so
    it is a number an instrument in the *source* context can be compared
    against.
    """

    target_id: str
    predicate_id: str
    coordinate_id: str
    coordinate_relation: str
    coordinate_threshold: Optional[Exact]
    measurand: Optional[str]
    measurand_unit: Optional[str]
    measurand_relation: Optional[str]
    measurand_threshold_before_tolerance: Optional[Exact]
    transfer_tolerance: Optional[Exact]
    measurand_threshold: Optional[Exact]
    rule_id: Optional[str]
    transformation_kind: Optional[str]
    holding_others_at: Tuple[Tuple[str, Exact], ...]
    status: str
    derivation: Tuple[str, ...]
    detail: str = ""

    def __post_init__(self) -> None:
        if self.status not in TargetStatus.ALL:
            raise QualificationError(f"unknown target status {self.status!r}")

    @property
    def derivable(self) -> bool:
        return self.status != TargetStatus.UNDERIVABLE

    def coordinate_satisfied_by(self, enclosure: Interval) -> str:
        """Judge an enclosure against the coordinate-side target."""
        if self.coordinate_threshold is None:
            return TargetStatus.UNDERIVABLE
        if self.coordinate_relation == ">=":
            if enclosure.lo >= self.coordinate_threshold:
                return TargetStatus.MET
            if enclosure.hi < self.coordinate_threshold:
                return TargetStatus.VIOLATED
            return TargetStatus.AMBIGUOUS
        if enclosure.hi <= self.coordinate_threshold:
            return TargetStatus.MET
        if enclosure.lo > self.coordinate_threshold:
            return TargetStatus.VIOLATED
        return TargetStatus.AMBIGUOUS

    def measurand_satisfied_by(self, enclosure: Interval) -> str:
        """Judge a raw source-context observation against the pulled-back target."""
        if self.measurand_threshold is None or self.measurand_relation is None:
            return TargetStatus.UNDERIVABLE
        if self.measurand_relation == ">=":
            if enclosure.lo >= self.measurand_threshold:
                return TargetStatus.MET
            if enclosure.hi < self.measurand_threshold:
                return TargetStatus.VIOLATED
            return TargetStatus.AMBIGUOUS
        if enclosure.hi <= self.measurand_threshold:
            return TargetStatus.MET
        if enclosure.lo > self.measurand_threshold:
            return TargetStatus.VIOLATED
        return TargetStatus.AMBIGUOUS

    def to_canonical(self) -> dict:
        record: dict = {
            "target_id": self.target_id,
            "predicate_id": self.predicate_id,
            "coordinate_id": self.coordinate_id,
            "coordinate_relation": self.coordinate_relation,
            "status": self.status,
            "derivation": list(self.derivation),
            "holding_others_at": {
                name: value.to_canonical() for name, value in self.holding_others_at
            },
        }
        for key, value in (
            ("coordinate_threshold", self.coordinate_threshold),
            ("measurand_threshold_before_tolerance", self.measurand_threshold_before_tolerance),
            ("transfer_tolerance", self.transfer_tolerance),
            ("measurand_threshold", self.measurand_threshold),
        ):
            if value is not None:
                record[key] = value.to_canonical()
        for key, value in (
            ("measurand", self.measurand),
            ("measurand_unit", self.measurand_unit),
            ("measurand_relation", self.measurand_relation),
            ("rule_id", self.rule_id),
            ("transformation_kind", self.transformation_kind),
        ):
            if value is not None:
                record[key] = value
        if self.detail:
            record["detail"] = self.detail
        return record


#: The eleven items specification 34.6 requires of a qualification plan.
PLAN_REQUIRED_ITEMS: Tuple[str, ...] = (
    "target decision",
    "threshold derivation",
    "measurable target",
    "selected experiments",
    "sequence or adaptive policy",
    "expected information effect",
    "burden",
    "dependencies",
    "stopping rule",
    "residual ambiguity",
    "verification basis",
)


@dataclass(frozen=True)
class QualificationPlan:
    """The output of specification 34.6.

    Construction enforces two refusals.  A plan with no stopping rule is
    invalid (34.5) and raises.  An inversion trace that is not a backward
    chain -- steps out of order, or a step consuming an identity no earlier
    step produced -- raises, because a forward solve wearing inverse labels
    is the failure mode 34.3 exists to prevent.
    """

    plan_id: str
    objective: QualificationObjective
    target_decision: str
    threshold_derivation: Tuple[str, ...]
    coordinate_needs: Tuple[CoordinateNeed, ...]
    evidence_needs: Tuple[EvidenceNeed, ...]
    transformation_paths: Tuple[TransformationPath, ...]
    measurable_targets: Tuple[MeasurableTarget, ...]
    considered_experiments: Tuple[RankedExperiment, ...]
    selected_experiments: Tuple[RankedExperiment, ...]
    sequence: Tuple[str, ...]
    adaptive_policy: str
    expected_information_effect: Tuple[InformationEffect, ...]
    burden: BurdenVector
    dependencies: Tuple[str, ...]
    stopping_rules: Tuple[StoppingRule, ...]
    residual_ambiguity: Exact
    residual_metric: str
    initial_state: QualificationState
    verification_basis: Tuple[str, ...]
    inversion_trace: Tuple[InversionRecord, ...]
    burden_weights: BurdenWeights
    ranking_basis: str = RankingBasis.EXPECTED
    warnings: Tuple[str, ...] = ()
    notes: Tuple[str, ...] = ()
    schema_version: str = "0.2.0"

    def __post_init__(self) -> None:
        if not self.stopping_rules:
            raise QualificationError(
                "qualification plan declares no stopping rule; specification 34.5 "
                "requires a plan to state a stopping condition, and a plan that "
                "cannot stop cannot be executed"
            )
        self._validate_trace()
        object.__setattr__(self, "residual_ambiguity", Exact(self.residual_ambiguity))
        AmbiguityMetric.check(self.residual_metric)
        RankingBasis.check(self.ranking_basis)
        object.__setattr__(self, "warnings", tuple(str(w) for w in self.warnings))
        object.__setattr__(self, "notes", tuple(str(n) for n in self.notes))

    def _validate_trace(self) -> None:
        trace = tuple(self.inversion_trace)
        steps = tuple(record.step for record in trace)
        if steps != InversionStep.ORDER:
            raise QualificationError(
                "inversion trace is not the backward chain of specification 34.3; "
                f"expected {InversionStep.ORDER} but found {steps}"
            )
        produced: set = set()
        for index, record in enumerate(trace):
            if record.index != index + 1:
                raise QualificationError(
                    f"inversion step {record.step} carries index {record.index}, "
                    f"expected {index + 1}"
                )
            expected_parent = None if index == 0 else InversionStep.ORDER[index - 1]
            if record.derived_from != expected_parent:
                raise QualificationError(
                    f"inversion step {record.step} declares derived_from="
                    f"{record.derived_from!r}, expected {expected_parent!r}; 34.3 is "
                    "an ordered backward chain"
                )
            if index > 0:
                if not record.inputs:
                    raise QualificationError(
                        f"inversion step {record.step} consumes nothing; it cannot "
                        "have been derived from the preceding step"
                    )
                orphans = [i for i in record.inputs if i not in produced]
                if orphans:
                    raise QualificationError(
                        f"inversion step {record.step} consumes identities no earlier "
                        f"step produced: {', '.join(sorted(orphans))}; the chain would "
                        "not be an inversion"
                    )
            if not record.outputs:
                raise QualificationError(
                    f"inversion step {record.step} produces nothing to hand to the "
                    "next step of 34.3"
                )
            produced.update(record.outputs)

    # -- accessors ----------------------------------------------------
    @property
    def region(self):
        return self.objective.region

    @property
    def ambiguity_metric(self) -> str:
        return self.objective.acceptable_ambiguity.metric

    @property
    def burden_limits(self) -> BurdenLimits:
        return self.objective.burden_limits

    def target(self, target_id: str) -> MeasurableTarget:
        for item in self.measurable_targets:
            if item.target_id == target_id:
                return item
        raise KeyError(target_id)

    def targets_for_measurand(self, measurand: str) -> Tuple[MeasurableTarget, ...]:
        return tuple(t for t in self.measurable_targets if t.measurand == measurand)

    def targets_for_coordinate(self, coordinate_id: str) -> Tuple[MeasurableTarget, ...]:
        return tuple(t for t in self.measurable_targets if t.coordinate_id == coordinate_id)

    def transformation_for(self, coordinate_id: str) -> Optional[TransformationPath]:
        for path in self.transformation_paths:
            if path.coordinate_id == coordinate_id:
                return path
        return None

    def experiment(self, experiment_id: str) -> Optional[ExperimentDefinition]:
        for ranked in self.considered_experiments:
            if ranked.experiment_id == experiment_id:
                return ranked.experiment
        return None

    def ranked(self, experiment_id: str) -> Optional[RankedExperiment]:
        for item in self.considered_experiments:
            if item.experiment_id == experiment_id:
                return item
        return None

    def stopping_rule(self, condition: str) -> Optional[StoppingRule]:
        for rule in self.stopping_rules:
            if rule.condition == condition:
                return rule
        return None

    @property
    def declared_conditions(self) -> Tuple[str, ...]:
        return tuple(rule.condition for rule in self.stopping_rules)

    def check_required_items(self) -> Dict[str, str]:
        """Presence audit against the eleven items of specification 34.6."""
        present = {
            "target decision": bool(self.target_decision),
            "threshold derivation": bool(self.threshold_derivation),
            "measurable target": bool(self.measurable_targets),
            "selected experiments": True,  # an empty selection is a stated result
            "sequence or adaptive policy": bool(self.sequence) or bool(self.adaptive_policy),
            "expected information effect": True,
            "burden": True,
            "dependencies": bool(self.dependencies),
            "stopping rule": bool(self.stopping_rules),
            "residual ambiguity": True,
            "verification basis": bool(self.verification_basis),
        }
        return {item: ("PRESENT" if present[item] else "ABSENT") for item in PLAN_REQUIRED_ITEMS}

    def to_canonical(self) -> dict:
        return {
            "schema_version": self.schema_version,
            "plan_id": self.plan_id,
            "target_decision": self.target_decision,
            "objective": self.objective.to_canonical(),
            "threshold_derivation": list(self.threshold_derivation),
            "coordinate_needs": [n.to_canonical() for n in self.coordinate_needs],
            "evidence_needs": [n.to_canonical() for n in self.evidence_needs],
            "transformation_paths": [p.to_canonical() for p in self.transformation_paths],
            "measurable_targets": [t.to_canonical() for t in self.measurable_targets],
            "considered_experiments": [r.to_canonical() for r in self.considered_experiments],
            "selected_experiments": [r.to_canonical() for r in self.selected_experiments],
            "sequence": list(self.sequence),
            "adaptive_policy": self.adaptive_policy,
            "expected_information_effect": [
                e.to_canonical() for e in self.expected_information_effect
            ],
            "burden": self.burden.to_canonical(),
            "burden_weights": self.burden_weights.to_canonical(),
            "ranking_basis": self.ranking_basis,
            "dependencies": list(self.dependencies),
            "stopping_rules": [r.to_canonical() for r in self.stopping_rules],
            "residual_ambiguity": self.residual_ambiguity.to_canonical(),
            "residual_metric": self.residual_metric,
            "initial_state": self.initial_state.to_canonical(),
            "verification_basis": list(self.verification_basis),
            "inversion_trace": [r.to_canonical() for r in self.inversion_trace],
            "required_items": self.check_required_items(),
            "warnings": list(self.warnings),
            "notes": list(self.notes),
        }

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())

    def render(self, width: int = 88) -> str:  # pragma: no cover - display only
        lines = [
            "=" * width,
            f"QUALIFICATION PLAN {self.plan_id}",
            "=" * width,
            f"target decision : {self.target_decision}",
            f"authority       : {self.objective.authority}",
            "",
            "threshold derivation (34.3(4)):",
        ]
        lines += [f"  {line}" for line in self.threshold_derivation]
        lines += ["", "selected experiments (34.4):"]
        lines += [f"  {r.render()}" for r in self.selected_experiments] or ["  (none)"]
        lines += [
            "",
            f"sequence        : {' -> '.join(self.sequence) or '(none)'}",
            f"burden          : {self.burden.render()}",
            f"residual        : {self.residual_ambiguity} ({self.residual_metric})",
            f"stopping rules  : {', '.join(self.declared_conditions)}",
        ]
        if self.warnings:
            lines += ["", "warnings:"] + [f"  ! {w}" for w in self.warnings]
        return "\n".join(lines)


# ==========================================================================
# the inversion itself (34.3)
# ==========================================================================

def _abs(value: Exact) -> Exact:
    return value if value >= Exact(0) else -value


def _deviation_magnitude(interval: Interval) -> Exact:
    lo, hi = _abs(interval.lo), _abs(interval.hi)
    return hi if hi >= lo else lo


_DEFAULT_WEIGHTS = BurdenWeights(
    {"time": Exact(1), "cost": Exact(1)},
    basis="default: unit weight on declared time and cost (spec 34.4)",
)


def invert(
    objective: QualificationObjective,
    contract: Optional[TechnologyContract],
    rules: Sequence[ApplicabilityRule],
    *,
    candidate_experiments: Sequence[ExperimentDefinition] = (),
    ambiguity_fn: Optional[Callable[[ExperimentDefinition], InformationEffect]] = None,
    burden_weights: Optional[BurdenWeights] = None,
    plan_id: Optional[str] = None,
    clock: Optional[VerificationClock] = None,
) -> QualificationPlan:
    """Invert a decision predicate into a qualification plan (34.3, 34.6).

    ``contract`` supplies the current bounded coordinates and their evidence
    lineage; it may be ``None``, in which case only the objective's declared
    prior bounds constrain anything.  ``rules`` are the applicability rules
    of 33.3 whose transformations are inverted in step three.

    The walk is strictly backward.  Nothing in this function evaluates the
    CRG decision forward and then names the pieces; step *n* is computed
    from the output of step ``n-1`` and the trace records that dependence.
    """
    if not isinstance(objective, QualificationObjective):
        raise QualificationError("objective must be a QualificationObjective (spec 34.2)")
    if contract is not None and not isinstance(contract, TechnologyContract):
        raise QualificationError("contract must be a TechnologyContract or None (spec 33.6)")

    region = objective.region
    metric = objective.acceptable_ambiguity.metric
    basis = objective.ranking_basis
    weights = burden_weights or objective.effective_burden_weights() or _DEFAULT_WEIGHTS
    plan_id = plan_id or f"plan-{objective.objective_id}"
    warnings: List[str] = []
    trace: List[InversionRecord] = []

    rule_list = tuple(rules or ())

    # ------------------------------------------------------------------
    # 34.3(1) the coordinate set sufficient to establish the predicate
    # ------------------------------------------------------------------
    bounds: Dict[str, Interval] = {}
    bound_source: Dict[str, str] = {}
    for coordinate_id in region.coordinates:
        enclosure: Optional[Interval] = None
        source = CoordinateNeed.UNBOUNDED
        if contract is not None and contract.has(coordinate_id):
            enclosure = contract.coordinate(coordinate_id).bound
            source = CoordinateNeed.FROM_CONTRACT
        else:
            prior = objective.prior_bound(coordinate_id)
            if prior is not None:
                enclosure = prior
                source = CoordinateNeed.FROM_PRIOR
        if enclosure is not None:
            bounds[coordinate_id] = enclosure
        bound_source[coordinate_id] = source

    coordinate_needs: List[CoordinateNeed] = []
    for coordinate_id in region.coordinates:
        coefficients = tuple(
            (p.predicate_id, p.coefficient(coordinate_id))
            for p in region.predicates
            if p.coefficient(coordinate_id) != Exact(0)
        )
        enclosure = bounds.get(coordinate_id)
        sensitivity: Optional[Exact] = None
        if enclosure is not None:
            sensitivity = Exact(0)
            for _, c in coefficients:
                sensitivity = sensitivity + (_abs(c) * enclosure.width)
        resolved = enclosure is not None and sensitivity == Exact(0)
        coordinate_needs.append(
            CoordinateNeed(
                coordinate_id=coordinate_id,
                coefficients=coefficients,
                bound=enclosure,
                bound_source=bound_source[coordinate_id],
                sensitivity=sensitivity,
                resolved=resolved,
                basis=(
                    "34.3(1): a coordinate with a non-zero coefficient can change the "
                    "sign of g and is therefore part of the sufficient set"
                ),
            )
        )
        if enclosure is None:
            warnings.append(
                f"coordinate {coordinate_id!r} has no bounded coordinate and no declared "
                "prior; the predicate is UNDETERMINED until evidence constrains it "
                "(spec 33.3 -- an absent coordinate is not a default)"
            )

    trace.append(
        InversionRecord(
            step=InversionStep.COORDINATE_SET,
            index=1,
            spec_citation=InversionStep.CITATION[InversionStep.COORDINATE_SET],
            derived_from=None,
            inputs=tuple(p.predicate_id for p in region.predicates),
            outputs=tuple(need.coordinate_id for need in coordinate_needs),
            detail=(
                f"region {region.region_id} is a conjunction of "
                f"{len(region.predicates)} predicate(s) over "
                f"{len(coordinate_needs)} coordinate(s)"
            ),
        )
    )

    # ------------------------------------------------------------------
    # 34.3(2) source-context evidence capable of constraining that set
    # ------------------------------------------------------------------
    rules_by_coordinate: Dict[str, List[ApplicabilityRule]] = {}
    for rule in rule_list:
        rules_by_coordinate.setdefault(rule.target_coordinate, []).append(rule)
    for coordinate_id in rules_by_coordinate:
        rules_by_coordinate[coordinate_id].sort(key=lambda r: r.rule_id)

    evidence_needs: List[EvidenceNeed] = []
    for need in coordinate_needs:
        coordinate_id = need.coordinate_id
        evidence_ids: Tuple[str, ...] = ()
        evidence_hashes: Tuple[str, ...] = ()
        fingerprints: Tuple[str, ...] = ()
        if contract is not None and contract.has(coordinate_id):
            bounded = contract.coordinate(coordinate_id)
            evidence_ids = bounded.evidence_ids
            evidence_hashes = bounded.evidence_hashes
            fingerprints = bounded.source_context_fingerprints
        applicable = rules_by_coordinate.get(coordinate_id, [])
        evidence_needs.append(
            EvidenceNeed(
                coordinate_id=coordinate_id,
                evidence_ids=evidence_ids,
                evidence_hashes=evidence_hashes,
                source_context_fingerprints=fingerprints,
                candidate_source_contexts=tuple(
                    sorted({r.source_context_pattern.context_type for r in applicable})
                ),
                rule_ids=tuple(r.rule_id for r in applicable),
                bounded_by_existing_evidence=need.bounded,
                further_evidence_required=not need.resolved,
                basis=(
                    "34.3(2): evidence able to constrain this coordinate is the union of "
                    "the lineage already in the technology contract and the source "
                    "contexts the declared applicability rules accept"
                ),
            )
        )
        if not applicable:
            warnings.append(
                f"no applicability rule targets coordinate {coordinate_id!r}; no source "
                "evidence can be carried into it and the coordinate is UNSUPPORTED "
                "(spec 33.3)"
            )

    trace.append(
        InversionRecord(
            step=InversionStep.SOURCE_EVIDENCE,
            index=2,
            spec_citation=InversionStep.CITATION[InversionStep.SOURCE_EVIDENCE],
            derived_from=InversionStep.COORDINATE_SET,
            inputs=tuple(need.coordinate_id for need in coordinate_needs),
            outputs=tuple(need.token for need in evidence_needs),
            detail=(
                "for each coordinate of step 1, the evidence already carried into it "
                "and the source contexts able to supply more"
            ),
        )
    )

    # ------------------------------------------------------------------
    # 34.3(3) applicability transformations mapping evidence to theta
    # ------------------------------------------------------------------
    paths: List[TransformationPath] = []
    for need in evidence_needs:
        for rule in rules_by_coordinate.get(need.coordinate_id, []):
            transformation = rule.transformation
            invertible = True
            reason = ""
            if transformation.kind == TransformationKind.SCENARIO_SET:
                invertible = False
                reason = (
                    "a scenario-set transformation is a family of maps, not one "
                    "invertible map; a single measurable target would have to pick a "
                    "scenario, which the rule does not authorize (spec 33.3)"
                )
            elif transformation.scale == Exact(0):
                invertible = False
                reason = "the transformation scale is zero; the map discards the measurand"
            # The transfer tolerance is evaluated by the rule's own declared
            # model (33.3) at the coordinate's current enclosure; nothing is
            # re-derived here.
            tolerance_interval = rule.transfer_uncertainty_model.transfer_interval(
                bounds.get(need.coordinate_id) or Interval(0, 0),
                rule.permitted_differences,
            )
            paths.append(
                TransformationPath(
                    coordinate_id=need.coordinate_id,
                    rule_id=rule.rule_id,
                    rule_version=rule.rule_version,
                    rule_hash=rule.fingerprint(),
                    transformation_kind=transformation.kind,
                    scale=transformation.scale,
                    offset=transformation.offset,
                    input_quantity=rule.input_quantity.quantity_id,
                    input_unit=rule.input_quantity.unit,
                    output_quantity=rule.output_quantity.quantity_id,
                    output_unit=rule.output_quantity.unit,
                    transfer_model_id=rule.transfer_uncertainty_model.model_id,
                    transfer_model_kind=rule.transfer_uncertainty_model.kind,
                    transfer_tolerance=_deviation_magnitude(tolerance_interval),
                    correlation_assumption=rule.correlation_assumption,
                    minimum_evidence_status=rule.minimum_evidence_status,
                    authority=rule.authority,
                    invertible=invertible,
                    not_invertible_reason=reason,
                    basis=(
                        "34.3(3): theta = scale * measurand + offset, so the target "
                        "derivation of 34.3(4) inverts this map"
                    ),
                )
            )

    trace.append(
        InversionRecord(
            step=InversionStep.APPLICABILITY_TRANSFORMATIONS,
            index=3,
            spec_citation=InversionStep.CITATION[InversionStep.APPLICABILITY_TRANSFORMATIONS],
            derived_from=InversionStep.SOURCE_EVIDENCE,
            inputs=tuple(need.token for need in evidence_needs),
            outputs=tuple(f"{p.rule_id}@{p.rule_version}" for p in paths)
            or ("no-applicability-transformation",),
            detail=(
                "the declared 33.3 transformation and transfer-uncertainty model for "
                "each evidence route found in step 2"
            ),
        )
    )

    # ------------------------------------------------------------------
    # 34.3(4) measurable targets and tolerances
    # ------------------------------------------------------------------
    targets: List[MeasurableTarget] = []
    derivation_lines: List[str] = []
    for predicate in region.predicates:
        derivation_lines.append(predicate.render())
        enclosure = predicate.evaluate(bounds)
        if enclosure is None:
            derivation_lines.append(
                f"  g_{predicate.predicate_id} has no enclosure: a coordinate it depends "
                "on is unbounded"
            )
        else:
            derivation_lines.append(
                f"  over the declared box, g_{predicate.predicate_id} in "
                f"[{enclosure.lo}, {enclosure.hi}] -> {predicate.state(bounds)}"
            )
        for coordinate_id in predicate.coordinates:
            targets.append(
                _derive_target(
                    predicate=predicate,
                    coordinate_id=coordinate_id,
                    bounds=bounds,
                    path=_first_invertible(paths, coordinate_id),
                    derivation_lines=derivation_lines,
                )
            )

    trace.append(
        InversionRecord(
            step=InversionStep.MEASURABLE_TARGETS,
            index=4,
            spec_citation=InversionStep.CITATION[InversionStep.MEASURABLE_TARGETS],
            derived_from=InversionStep.APPLICABILITY_TRANSFORMATIONS,
            inputs=tuple(f"{p.rule_id}@{p.rule_version}" for p in paths)
            or ("no-applicability-transformation",),
            outputs=tuple(t.target_id for t in targets),
            detail=(
                "g >= 0 solved for one coordinate with the others at their worst case, "
                "then pulled back through the inverse transformation of step 3 and "
                "widened by the declared transfer tolerance"
            ),
        )
    )

    # ------------------------------------------------------------------
    # 34.3(5) experiments capable of resolving remaining ambiguity
    # ------------------------------------------------------------------
    wanted_measurands = {t.measurand for t in targets if t.measurand}
    wanted_coordinates = {t.coordinate_id for t in targets if t.status != TargetStatus.MET}
    relevant: List[ExperimentDefinition] = []
    for experiment in candidate_experiments or ():
        if experiment.measurand in wanted_measurands or (
            set(experiment.targets) & wanted_coordinates
        ):
            relevant.append(experiment)
        else:
            warnings.append(
                f"candidate experiment {experiment.experiment_id!r} measures "
                f"{experiment.measurand!r}, which no derived target names and whose "
                "declared targets touch no unresolved coordinate; it cannot resolve "
                "remaining ambiguity (spec 34.3(5))"
            )

    considered = rank_experiments(
        relevant, ambiguity_fn, burden_weights=weights, basis=basis
    )
    selected = tuple(r for r in considered if r.tier != RankingTier.UNINFORMATIVE)
    for ranked in considered:
        if ranked.tier == RankingTier.UNINFORMATIVE:
            warnings.append(
                f"experiment {ranked.experiment_id!r} excluded: {ranked.excluded_reason}"
            )
        if not ranked.experiment.may_authorize:
            warnings.append(
                f"experiment {ranked.experiment_id!r} declares evidence class "
                f"{ranked.experiment.evidence_class}; a heuristic may rank or propose "
                "but may never authorize (spec 5.3)"
            )

    sequence, sequence_warnings = _order_sequence(selected)
    warnings.extend(sequence_warnings)

    trace.append(
        InversionRecord(
            step=InversionStep.RESOLVING_EXPERIMENTS,
            index=5,
            spec_citation=InversionStep.CITATION[InversionStep.RESOLVING_EXPERIMENTS],
            derived_from=InversionStep.MEASURABLE_TARGETS,
            inputs=tuple(t.target_id for t in targets),
            outputs=tuple(r.experiment_id for r in selected) or ("no-informative-experiment",),
            detail=(
                f"{len(considered)} candidate(s) able to address a derived target, ranked "
                "by the 34.4 ratio; uninformative candidates are tiered below every "
                "informative one regardless of burden"
            ),
        )
    )

    # ------------------------------------------------------------------
    # 34.3(6) the expected effect on the CRG decision
    # ------------------------------------------------------------------
    current_ambiguity = region_ambiguity(region, bounds, metric)
    ambiguity_derivable = current_ambiguity is not None
    if current_ambiguity is None:
        declared = [r.information_effect.ambiguity_before for r in considered]
        current_ambiguity = declared[0] if declared else Exact(0)
        warnings.append(
            f"ambiguity metric {metric} is not derivable from coordinate bounds; the "
            "prior ambiguity is taken from the candidates' declared "
            "ambiguity_before rather than computed (spec 34.4)"
        )

    residual = current_ambiguity
    for ranked in selected:
        posterior = ranked.information_effect.posterior(basis)
        if posterior < residual:
            residual = posterior

    predicate_state = region.state(bounds)
    acceptable = objective.acceptable_ambiguity
    projected = (
        "AMBIGUITY_WITHIN_ACCEPTABLE"
        if acceptable.satisfied_by(residual)
        else "AMBIGUITY_ABOVE_ACCEPTABLE"
    )
    effect_detail = (
        f"region {region.region_id} is currently {predicate_state}; running the selected "
        f"sequence is expected to leave {metric} at {residual} against an acceptable "
        f"{acceptable.threshold} -> {projected}.  Reductions are not compounded: the "
        "projection is the best single posterior among the selected experiments, which "
        "is the conservative reading when correlation between experiments is undeclared."
    )

    trace.append(
        InversionRecord(
            step=InversionStep.DECISION_EFFECT,
            index=6,
            spec_citation=InversionStep.CITATION[InversionStep.DECISION_EFFECT],
            derived_from=InversionStep.RESOLVING_EXPERIMENTS,
            inputs=tuple(r.experiment_id for r in selected) or ("no-informative-experiment",),
            outputs=(f"decision-effect:{region.region_id}",),
            detail=effect_detail,
        )
    )

    # ------------------------------------------------------------------
    # 34.5 stopping rules and 34.6 assembly
    # ------------------------------------------------------------------
    stopping_rules = list(objective.stopping_rules)
    if objective.burden_limits.declared and not any(
        r.condition == StoppingCondition.BURDEN_LIMIT_REACHED for r in stopping_rules
    ):
        stopping_rules.append(
            StoppingRule(
                StoppingCondition.BURDEN_LIMIT_REACHED,
                basis=(
                    "added by inversion: burden limits were declared under 34.2 without "
                    "a matching 34.5 stop, and a declared limit that cannot halt the "
                    "plan is not a limit"
                ),
            )
        )
        warnings.append(
            "burden limits were declared without a BURDEN_LIMIT_REACHED stopping rule; "
            "one was added so the declared limit can halt the plan (spec 34.2, 34.5)"
        )
    if not stopping_rules:  # pragma: no cover - objective already refuses this
        raise QualificationError("plan has no stopping rule (spec 34.5)")

    total_burden = BurdenVector()
    for ranked in selected:
        total_burden = total_burden + ranked.experiment.burden
    breached = objective.burden_limits.exceeded_by(total_burden)
    if breached:
        warnings.append(
            "the selected sequence already exceeds the declared burden limit on "
            f"{', '.join(breached)}; BURDEN_LIMIT_REACHED will fire before the sequence "
            "completes (spec 34.5)"
        )

    dependencies: List[str] = []
    if contract is not None:
        dependencies.append(f"contract:{contract.contract_id}")
        dependencies.append(f"contract-hash:{contract.fingerprint()}")
    for need in evidence_needs:
        dependencies.extend(f"evidence:{e}" for e in need.evidence_ids)
        dependencies.extend(f"evidence-hash:{h}" for h in need.evidence_hashes)
    for path in paths:
        dependencies.append(f"rule:{path.rule_id}@{path.rule_version}")
        dependencies.append(f"rule-hash:{path.rule_hash}")
    dependencies.append(f"objective-hash:{objective.fingerprint()}")
    for ranked in selected:
        dependencies.append(f"experiment-hash:{ranked.experiment.fingerprint()}")
    dependencies = sorted(dict.fromkeys(dependencies))

    verification_basis = [
        "spec 34.3: inversion walked backward from the decision predicate; the "
        "inversion_trace records each step's inputs as identities the previous step "
        "produced",
        "spec 34.4: experiments ranked by ambiguity reduction over declared burden, "
        f"on basis {basis} and metric {metric}",
        "spec 34.5: every stopping condition on this plan is declared and testable",
        "spec 14.2: every magnitude in this plan is an exact rational; no float is used",
        f"objective fingerprint {objective.fingerprint()}",
    ]
    if contract is not None:
        verification_basis.append(
            f"technology contract {contract.contract_id} "
            f"({contract.verification_status}) fingerprint {contract.fingerprint()}"
        )
        verification_basis.append(
            f"contract time status {contract.time_judgment.time_status} against clock "
            f"{contract.time_judgment.verifier_clock_source}"
        )
    if clock is not None:
        verification_basis.append(
            f"inversion evaluated against supplied clock {clock.source} "
            f"({clock.trust_level}) at {clock.evaluation_time}"
        )

    initial_state = QualificationState(
        plan_id=plan_id,
        coordinate_bounds=tuple(bounds.items()),
        predicate_state=predicate_state,
        ambiguity_metric=metric,
        ambiguity=current_ambiguity,
        cumulative_burden=BurdenVector(),
        completed_experiments=(),
        remaining_experiments=sequence,
        informative_remaining=tuple(
            r.experiment_id for r in selected if r.tier != RankingTier.UNINFORMATIVE
        ),
        ambiguity_derivable=ambiguity_derivable,
        step=0,
        notes=("initial state produced by inverse qualification (spec 34.3)",),
    )

    return QualificationPlan(
        plan_id=plan_id,
        objective=objective,
        target_decision=(
            f"{objective.desired_state} -- region {region.region_id} "
            f"({', '.join(p.predicate_id for p in region.predicates)}) under authority "
            f"{objective.authority}"
        ),
        threshold_derivation=tuple(derivation_lines),
        coordinate_needs=tuple(coordinate_needs),
        evidence_needs=tuple(evidence_needs),
        transformation_paths=tuple(paths),
        measurable_targets=tuple(targets),
        considered_experiments=tuple(considered),
        selected_experiments=selected,
        sequence=sequence,
        adaptive_policy=(
            "sequential, re-ranked after each ingestion: run the head of the sequence, "
            "ingest its result, re-test the declared stopping rules in declaration "
            "order, and stop on the first that fires (spec 34.5, 34.6)"
        ),
        expected_information_effect=tuple(r.information_effect for r in selected),
        burden=total_burden,
        dependencies=tuple(dependencies),
        stopping_rules=tuple(stopping_rules),
        residual_ambiguity=residual,
        residual_metric=metric,
        initial_state=initial_state,
        verification_basis=tuple(verification_basis),
        inversion_trace=tuple(trace),
        burden_weights=weights,
        ranking_basis=basis,
        warnings=tuple(dict.fromkeys(warnings)),
        notes=(effect_detail,),
    )


def _first_invertible(
    paths: Sequence[TransformationPath], coordinate_id: str
) -> Optional[TransformationPath]:
    fallback: Optional[TransformationPath] = None
    for path in paths:
        if path.coordinate_id != coordinate_id:
            continue
        if path.invertible:
            return path
        if fallback is None:
            fallback = path
    return fallback


def _derive_target(
    *,
    predicate: DecisionPredicate,
    coordinate_id: str,
    bounds: Mapping[str, Interval],
    path: Optional[TransformationPath],
    derivation_lines: List[str],
) -> MeasurableTarget:
    """Solve ``g >= 0`` for one coordinate, then pull the result back (34.3(4))."""
    target_id = f"target:{predicate.predicate_id}:{coordinate_id}"
    c_k = predicate.coefficient(coordinate_id)
    relation = ">=" if c_k > Exact(0) else "<="

    others = [name for name in predicate.coordinates if name != coordinate_id]
    missing = [name for name in others if name not in bounds]
    if missing:
        detail = (
            f"cannot solve for {coordinate_id}: companion coordinate(s) "
            f"{', '.join(sorted(missing))} have no enclosure, so their worst case is "
            "unknown (spec 33.3 -- an absent coordinate is not a default)"
        )
        derivation_lines.append(f"  {target_id}: UNDERIVABLE -- {detail}")
        return MeasurableTarget(
            target_id=target_id,
            predicate_id=predicate.predicate_id,
            coordinate_id=coordinate_id,
            coordinate_relation=relation,
            coordinate_threshold=None,
            measurand=path.input_quantity if path else None,
            measurand_unit=path.input_unit if path else None,
            measurand_relation=None,
            measurand_threshold_before_tolerance=None,
            transfer_tolerance=None,
            measurand_threshold=None,
            rule_id=path.rule_id if path else None,
            transformation_kind=path.transformation_kind if path else None,
            holding_others_at=(),
            status=TargetStatus.UNDERIVABLE,
            derivation=(detail,),
            detail=detail,
        )

    # Worst case of every other term: g is affine, so the minimising vertex
    # takes the lower end where the coefficient is positive and the upper end
    # where it is negative.
    rest = Exact(0)
    held: List[Tuple[str, Exact]] = []
    for name in others:
        c = predicate.coefficient(name)
        enclosure = bounds[name]
        worst = enclosure.lo if c > Exact(0) else enclosure.hi
        held.append((name, worst))
        rest = rest + (c * worst)

    required = (predicate.threshold - rest) / c_k
    lines = [
        f"{target_id}: solve {predicate.render()} for {coordinate_id}",
        "  hold companions at their worst case: "
        + (", ".join(f"{n}={v}" for n, v in held) or "(none)"),
        f"  ({c_k})*{coordinate_id} >= ({predicate.threshold}) - ({rest})",
        f"  => {coordinate_id} {relation} {required}",
    ]

    status = TargetStatus.UNDERIVABLE
    enclosure_k = bounds.get(coordinate_id)
    measurand = path.input_quantity if path else None
    measurand_unit = path.input_unit if path else None
    measurand_relation: Optional[str] = None
    raw_threshold: Optional[Exact] = None
    tolerance: Optional[Exact] = None
    measurand_threshold: Optional[Exact] = None
    detail = ""

    if path is None:
        detail = (
            f"no applicability rule maps any measurand to {coordinate_id}; the "
            "coordinate target stands but nothing measurable is bound to it (spec 33.3)"
        )
        lines.append(f"  {detail}")
    elif not path.invertible:
        detail = f"transformation not invertible: {path.not_invertible_reason}"
        lines.append(f"  {detail}")
    else:
        # theta = scale * x + offset  =>  x = (theta - offset) / scale.
        # A negative scale reverses the inequality.
        raw_threshold = (required - path.offset) / path.scale
        flipped = path.scale < Exact(0)
        measurand_relation = (
            relation if not flipped else (">=" if relation == "<=" else "<=")
        )
        tolerance = path.transfer_tolerance
        scaled_tolerance = tolerance / _abs(path.scale)
        measurand_threshold = (
            raw_threshold + scaled_tolerance
            if measurand_relation == ">="
            else raw_threshold - scaled_tolerance
        )
        lines.append(
            f"  pull back through {path.rule_id} ({path.transformation_kind}, "
            f"scale={path.scale}, offset={path.offset}): "
            f"{measurand} {measurand_relation} {raw_threshold} {measurand_unit}"
        )
        lines.append(
            f"  widen by transfer tolerance {tolerance} / |scale| = {scaled_tolerance} "
            f"(model {path.transfer_model_id}, {path.transfer_model_kind}): "
            f"{measurand} {measurand_relation} {measurand_threshold} {measurand_unit}"
        )

    if enclosure_k is None:
        status = TargetStatus.UNDERIVABLE if path is None else TargetStatus.AMBIGUOUS
        if enclosure_k is None and path is not None:
            lines.append(
                f"  {coordinate_id} is unbounded, so the target is not yet met or "
                "violated -- it is simply untested"
            )
    else:
        if relation == ">=":
            if enclosure_k.lo >= required:
                status = TargetStatus.MET
            elif enclosure_k.hi < required:
                status = TargetStatus.VIOLATED
            else:
                status = TargetStatus.AMBIGUOUS
        else:
            if enclosure_k.hi <= required:
                status = TargetStatus.MET
            elif enclosure_k.lo > required:
                status = TargetStatus.VIOLATED
            else:
                status = TargetStatus.AMBIGUOUS
        lines.append(
            f"  current enclosure [{enclosure_k.lo}, {enclosure_k.hi}] -> {status}"
        )

    derivation_lines.extend(f"  {line}" for line in lines)
    return MeasurableTarget(
        target_id=target_id,
        predicate_id=predicate.predicate_id,
        coordinate_id=coordinate_id,
        coordinate_relation=relation,
        coordinate_threshold=required,
        measurand=measurand,
        measurand_unit=measurand_unit,
        measurand_relation=measurand_relation,
        measurand_threshold_before_tolerance=raw_threshold,
        transfer_tolerance=tolerance,
        measurand_threshold=measurand_threshold,
        rule_id=path.rule_id if path else None,
        transformation_kind=path.transformation_kind if path else None,
        holding_others_at=tuple(held),
        status=status,
        derivation=tuple(lines),
        detail=detail,
    )


def _order_sequence(selected: Sequence[RankedExperiment]) -> Tuple[Tuple[str, ...], List[str]]:
    """Rank order, adjusted so declared prerequisites run first (34.6 sequence)."""
    warnings: List[str] = []
    chosen = {r.experiment_id for r in selected}
    ordered: List[str] = []
    placed: set = set()

    def place(ranked: RankedExperiment, stack: Tuple[str, ...]) -> None:
        experiment_id = ranked.experiment_id
        if experiment_id in placed:
            return
        if experiment_id in stack:
            warnings.append(
                "prerequisite cycle among experiments "
                f"{' -> '.join(stack + (experiment_id,))}; the cycle is broken at "
                f"{experiment_id!r} and the declared rank order is used"
            )
            return
        for prerequisite in ranked.experiment.prerequisites:
            if prerequisite not in chosen:
                warnings.append(
                    f"experiment {experiment_id!r} declares prerequisite "
                    f"{prerequisite!r}, which is not in the selected set; the "
                    "sequence cannot honour it"
                )
                continue
            for other in selected:
                if other.experiment_id == prerequisite:
                    place(other, stack + (experiment_id,))
        placed.add(experiment_id)
        ordered.append(experiment_id)

    for ranked in selected:
        place(ranked, ())
    return tuple(ordered), warnings
