"""Executing a qualification plan: ingesting results and testing the stop.

Normative basis: master specification 34.5 (stopping rules) and 34.6
(residual ambiguity as a plan output), with 33.3 (the applicability
transformation) used in the forward direction to carry an observation into
a technology coordinate.

Inversion decided *what to measure*; ingestion is the one place where the
map runs forward, and it runs the same declared transformation the target
was pulled back through -- widened by the same declared transfer tolerance,
so a result that exactly meets its measurable target exactly meets its
coordinate target.

Two behaviours are load-bearing.

**Stopping rules are declared and evaluated in declaration order.**  The
specification gives no priority among the eight conditions of 34.5, so this
implementation does not invent one: the objective's own ordering decides,
and :func:`stopping_reached` returns the first condition that fires.  An
undeclared condition never fires, however true it happens to be.

**An observation that contradicts the prior bound is not averaged.**
Disjoint enclosures raise manual adjudication (34.5) rather than being
merged, which is the same refusal 33.5 makes about contradictory evidence.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

from crg_model.canonical import content_hash
from crg_model.numeric import Exact, Interval
from etq_evidence import ContextDescriptor, CorrelationAssumption, UncertaintyBudget

from .ambiguity import AmbiguityMetric, PredicateState
from .burden import BurdenVector
from .experiment import RankingTier
from .invert import MeasurableTarget, QualificationPlan, TargetStatus
from .objective import NOT_STOPPED, QualificationError, StoppingCondition
from .state import QualificationState, region_ambiguity

__all__ = [
    "ResultStatus",
    "ExperimentResult",
    "TargetEvaluation",
    "QualificationResult",
    "ingest_result",
    "stopping_reached",
]


class ResultStatus:
    """How an experiment concluded."""

    COMPLETED = "COMPLETED"
    #: Ran, but produced nothing that constrains the measurand.
    INCONCLUSIVE = "INCONCLUSIVE"
    FAILED = "FAILED"
    ABORTED = "ABORTED"

    ALL = frozenset({COMPLETED, INCONCLUSIVE, FAILED, ABORTED})
    #: Statuses that may move a coordinate bound.  Burden is incurred by all
    #: four: a failed experiment still consumed the tool.
    CONSTRAINING = frozenset({COMPLETED})


@dataclass(frozen=True)
class ExperimentResult:
    """The outcome of one planned experiment, in source-context terms."""

    experiment_id: str
    measurand: str
    unit: str
    observed: Optional[Interval] = None
    uncertainty: UncertaintyBudget = field(default_factory=UncertaintyBudget)
    correlation_assumption: str = CorrelationAssumption.UNKNOWN
    context: Optional[ContextDescriptor] = None
    observed_ambiguity: Optional[Exact] = None
    ambiguity_metric: Optional[str] = None
    status: str = ResultStatus.COMPLETED
    burden_incurred: Optional[BurdenVector] = None
    regret_upper_bound: Optional[Exact] = None
    possible_winners: Optional[Tuple[str, ...]] = None
    guaranteed_winner: Optional[str] = None
    manual_adjudication_required: bool = False
    manual_adjudication_reason: str = ""
    notes: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if self.status not in ResultStatus.ALL:
            raise QualificationError(f"unknown result status {self.status!r}")
        if self.correlation_assumption not in CorrelationAssumption.ALL:
            raise QualificationError(
                f"unknown correlation assumption {self.correlation_assumption!r} (spec 33.4)"
            )
        if self.ambiguity_metric is not None:
            AmbiguityMetric.check(self.ambiguity_metric)
        if self.observed_ambiguity is not None:
            value = Exact(self.observed_ambiguity)
            if value < Exact(0):
                raise QualificationError("observed_ambiguity must be non-negative")
            object.__setattr__(self, "observed_ambiguity", value)
        if self.regret_upper_bound is not None:
            object.__setattr__(self, "regret_upper_bound", Exact(self.regret_upper_bound))
        if self.possible_winners is not None:
            object.__setattr__(
                self, "possible_winners", tuple(str(w) for w in self.possible_winners)
            )
        object.__setattr__(self, "notes", tuple(str(n) for n in self.notes))
        if self.status in ResultStatus.CONSTRAINING and self.observed is None:
            raise QualificationError(
                f"experiment {self.experiment_id!r} is COMPLETED but reports no observed "
                "enclosure; a completed measurement that constrains nothing is "
                "INCONCLUSIVE, not COMPLETED"
            )

    def to_canonical(self) -> dict:
        record: dict = {
            "experiment_id": self.experiment_id,
            "measurand": self.measurand,
            "unit": self.unit,
            "status": self.status,
            "correlation_assumption": self.correlation_assumption,
            "uncertainty": self.uncertainty.to_canonical(),
        }
        if self.observed is not None:
            record["observed"] = self.observed.to_canonical()
        if self.context is not None:
            record["context"] = self.context.to_canonical()
        if self.observed_ambiguity is not None:
            record["observed_ambiguity"] = self.observed_ambiguity.to_canonical()
        if self.ambiguity_metric is not None:
            record["ambiguity_metric"] = self.ambiguity_metric
        if self.burden_incurred is not None:
            record["burden_incurred"] = self.burden_incurred.to_canonical()
        if self.regret_upper_bound is not None:
            record["regret_upper_bound"] = self.regret_upper_bound.to_canonical()
        if self.possible_winners is not None:
            record["possible_winners"] = list(self.possible_winners)
        if self.guaranteed_winner is not None:
            record["guaranteed_winner"] = self.guaranteed_winner
        if self.manual_adjudication_required:
            record["manual_adjudication_required"] = True
            record["manual_adjudication_reason"] = self.manual_adjudication_reason
        if self.notes:
            record["notes"] = list(self.notes)
        return record


@dataclass(frozen=True)
class TargetEvaluation:
    """A measurable target of 34.3(4) judged against what was observed."""

    target_id: str
    predicate_id: str
    coordinate_id: str
    measurand: Optional[str]
    measurand_status: str
    coordinate_status: str
    observed: Optional[Interval]
    carried_coordinate_bound: Optional[Interval]
    detail: str = ""

    def to_canonical(self) -> dict:
        record: dict = {
            "target_id": self.target_id,
            "predicate_id": self.predicate_id,
            "coordinate_id": self.coordinate_id,
            "measurand_status": self.measurand_status,
            "coordinate_status": self.coordinate_status,
        }
        if self.measurand is not None:
            record["measurand"] = self.measurand
        if self.observed is not None:
            record["observed"] = self.observed.to_canonical()
        if self.carried_coordinate_bound is not None:
            record["carried_coordinate_bound"] = self.carried_coordinate_bound.to_canonical()
        if self.detail:
            record["detail"] = self.detail
        return record


@dataclass(frozen=True)
class QualificationResult:
    """What one ingestion did to the campaign, and whether it stops it."""

    plan_id: str
    experiment_id: str
    result_status: str
    prior_state: QualificationState
    state: QualificationState
    target_evaluations: Tuple[TargetEvaluation, ...]
    predicate_state_before: str
    predicate_state_after: str
    ambiguity_before: Exact
    ambiguity_after: Exact
    burden_incurred: BurdenVector
    cumulative_burden: BurdenVector
    stopped: bool
    stopping_reason: str
    stopping_detail: str
    residual_ambiguity: Exact
    residual_metric: str
    warnings: Tuple[str, ...] = ()
    verification_basis: Tuple[str, ...] = ()

    @property
    def resolved(self) -> bool:
        return self.predicate_state_after in PredicateState.RESOLVED

    def to_canonical(self) -> dict:
        return {
            "plan_id": self.plan_id,
            "experiment_id": self.experiment_id,
            "result_status": self.result_status,
            "predicate_state_before": self.predicate_state_before,
            "predicate_state_after": self.predicate_state_after,
            "ambiguity_before": self.ambiguity_before.to_canonical(),
            "ambiguity_after": self.ambiguity_after.to_canonical(),
            "residual_ambiguity": self.residual_ambiguity.to_canonical(),
            "residual_metric": self.residual_metric,
            "burden_incurred": self.burden_incurred.to_canonical(),
            "cumulative_burden": self.cumulative_burden.to_canonical(),
            "target_evaluations": [t.to_canonical() for t in self.target_evaluations],
            "stopped": self.stopped,
            "stopping_reason": self.stopping_reason,
            "stopping_detail": self.stopping_detail,
            "prior_state": self.prior_state.to_canonical(),
            "state": self.state.to_canonical(),
            "warnings": list(self.warnings),
            "verification_basis": list(self.verification_basis),
        }

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())


# ==========================================================================
# 34.5 stopping rules
# ==========================================================================

def stopping_reached(
    plan: QualificationPlan, state: QualificationState
) -> Tuple[bool, str]:
    """Test the plan's declared stopping rules against a state (34.5).

    Returns ``(True, condition)`` for the first declared condition that
    fires, in the order the objective declared them, or
    ``(False, "CONTINUE")``.  The specification states no priority among
    the eight conditions, so the declaration order is the authority; an
    undeclared condition never stops the plan however true it is.
    """
    stopped, reason, _ = _stopping_detail(plan, state)
    return stopped, reason


def _stopping_detail(
    plan: QualificationPlan, state: QualificationState
) -> Tuple[bool, str, str]:
    if not plan.stopping_rules:  # pragma: no cover - plan refuses this at construction
        raise QualificationError("plan has no stopping rule (spec 34.5)")

    for rule in plan.stopping_rules:
        condition = rule.condition

        if condition == StoppingCondition.UNIQUE_GUARANTEED_WINNER:
            if state.unique_guaranteed_winner:
                return (
                    True,
                    condition,
                    f"{state.guaranteed_winner!r} is the unique guaranteed winner",
                )

        elif condition == StoppingCondition.CAPABILITY_ESTABLISHED:
            if state.predicate_state == PredicateState.GUARANTEED_SATISFIED:
                return (
                    True,
                    condition,
                    f"every predicate of region {plan.region.region_id} is guaranteed "
                    "satisfied over the current enclosures",
                )

        elif condition == StoppingCondition.CAPABILITY_RULED_OUT:
            if state.predicate_state == PredicateState.GUARANTEED_VIOLATED:
                return (
                    True,
                    condition,
                    f"a predicate of region {plan.region.region_id} is guaranteed "
                    "violated over the current enclosures",
                )

        elif condition == StoppingCondition.REGRET_BELOW_THRESHOLD:
            bound = state.regret_upper_bound
            if bound is not None and rule.threshold is not None and bound <= rule.threshold:
                return (
                    True,
                    condition,
                    f"regret upper bound {bound} is at or below the declared "
                    f"{rule.threshold}",
                )

        elif condition == StoppingCondition.UNCERTAINTY_BELOW_THRESHOLD:
            if rule.metric is not None and rule.metric != state.ambiguity_metric:
                continue
            if not state.ambiguity_derivable:
                continue
            if rule.threshold is not None and state.ambiguity <= rule.threshold:
                return (
                    True,
                    condition,
                    f"{state.ambiguity_metric} is {state.ambiguity}, at or below the "
                    f"declared {rule.threshold}",
                )

        elif condition == StoppingCondition.BURDEN_LIMIT_REACHED:
            breached = plan.burden_limits.exceeded_by(state.cumulative_burden)
            if breached:
                return (
                    True,
                    condition,
                    "cumulative burden passed the declared limit on "
                    + ", ".join(breached),
                )

        elif condition == StoppingCondition.NO_INFORMATIVE_EXPERIMENT_REMAINS:
            if not state.informative_remaining:
                return (
                    True,
                    condition,
                    "no remaining experiment declares a positive ambiguity reduction",
                )

        elif condition == StoppingCondition.MANUAL_ADJUDICATION_REQUIRED:
            if state.manual_adjudication_required:
                return (
                    True,
                    condition,
                    state.manual_adjudication_reason or "manual adjudication was raised",
                )

    return (
        False,
        NOT_STOPPED,
        "no declared stopping condition fires against the current state (spec 34.5)",
    )


# ==========================================================================
# ingestion
# ==========================================================================

def ingest_result(
    plan: QualificationPlan,
    result: ExperimentResult,
    *,
    state: Optional[QualificationState] = None,
) -> QualificationResult:
    """Fold an experiment result into the campaign state and test the stop.

    ``state`` defaults to the plan's initial state; pass the previous
    result's :attr:`QualificationResult.state` to chain ingestions.  The
    returned object holds both the prior and the new state, so the campaign
    is an auditable chain of immutable snapshots.
    """
    if not isinstance(plan, QualificationPlan):
        raise QualificationError("plan must be a QualificationPlan (spec 34.6)")
    if not isinstance(result, ExperimentResult):
        raise QualificationError("result must be an ExperimentResult")

    prior = state or plan.initial_state
    warnings: List[str] = []
    bounds: Dict[str, Interval] = prior.bounds_map()

    ranked = plan.ranked(result.experiment_id)
    if ranked is None:
        warnings.append(
            f"UNPLANNED_EXPERIMENT: {result.experiment_id!r} is not among the "
            "experiments this plan considered; its result is ingested but the plan's "
            "declared information effect does not cover it (spec 34.6)"
        )
    elif result.experiment_id not in plan.sequence:
        warnings.append(
            f"OUT_OF_SEQUENCE: {result.experiment_id!r} was considered but not selected "
            f"({ranked.excluded_reason or 'not in the selected sequence'})"
        )
    elif ranked.experiment.measurand != result.measurand:
        warnings.append(
            f"MEASURAND_MISMATCH: {result.experiment_id!r} was planned to measure "
            f"{ranked.experiment.measurand!r} but the result reports "
            f"{result.measurand!r}"
        )
    elif ranked.experiment.unit != result.unit:
        warnings.append(
            f"UNIT_MISMATCH: {result.experiment_id!r} was planned in "
            f"{ranked.experiment.unit!r} but the result is in {result.unit!r}; the "
            "observation is not carried into a coordinate (spec 13.1)"
        )

    unit_mismatch = any(w.startswith("UNIT_MISMATCH") for w in warnings)
    manual = prior.manual_adjudication_required
    manual_reason = prior.manual_adjudication_reason

    # -- carry the observation forward through the same declared map --------
    evaluations: List[TargetEvaluation] = []
    constraining = (
        result.status in ResultStatus.CONSTRAINING
        and result.observed is not None
        and not unit_mismatch
    )
    matched = plan.targets_for_measurand(result.measurand)
    if constraining and not matched:
        warnings.append(
            f"NO_TARGET_FOR_MEASURAND: no derived target names measurand "
            f"{result.measurand!r}; the observation constrains no coordinate"
        )

    for target in matched:
        measurand_status = (
            target.measurand_satisfied_by(result.observed)
            if constraining and target.measurand_threshold is not None
            else TargetStatus.UNDERIVABLE
        )
        carried: Optional[Interval] = None
        detail = ""
        if constraining:
            path = plan.transformation_for(target.coordinate_id)
            if path is None or not path.invertible:
                detail = (
                    "no invertible applicability transformation carries this measurand "
                    "into the coordinate; the observation is recorded but not applied "
                    "(spec 33.3)"
                )
            else:
                carried = _carry_forward(result.observed, path)
                existing = bounds.get(target.coordinate_id)
                if existing is None:
                    bounds[target.coordinate_id] = carried
                    detail = "coordinate had no prior enclosure; the carried bound is adopted"
                elif not existing.overlaps(carried):
                    manual = True
                    manual_reason = (
                        f"observation for {target.coordinate_id!r} encloses "
                        f"[{carried.lo}, {carried.hi}], disjoint from the prior "
                        f"[{existing.lo}, {existing.hi}]; contradictory evidence is not "
                        "averaged away (spec 33.5) and requires adjudication (spec 34.5)"
                    )
                    warnings.append(f"CONTRADICTORY_OBSERVATION: {manual_reason}")
                    detail = "disjoint from the prior enclosure; prior bound retained"
                else:
                    tightened = Interval(
                        max(existing.lo, carried.lo, key=lambda e: e.value),
                        min(existing.hi, carried.hi, key=lambda e: e.value),
                    )
                    bounds[target.coordinate_id] = tightened
                    detail = (
                        f"intersected with the prior enclosure to "
                        f"[{tightened.lo}, {tightened.hi}]"
                    )
        coordinate_bound = bounds.get(target.coordinate_id)
        coordinate_status = (
            target.coordinate_satisfied_by(coordinate_bound)
            if coordinate_bound is not None
            else TargetStatus.UNDERIVABLE
        )
        evaluations.append(
            TargetEvaluation(
                target_id=target.target_id,
                predicate_id=target.predicate_id,
                coordinate_id=target.coordinate_id,
                measurand=target.measurand,
                measurand_status=measurand_status,
                coordinate_status=coordinate_status,
                observed=result.observed,
                carried_coordinate_bound=carried,
                detail=detail,
            )
        )

    if result.manual_adjudication_required:
        manual = True
        manual_reason = result.manual_adjudication_reason or (
            f"experiment {result.experiment_id!r} raised manual adjudication"
        )

    # -- burden: incurred whatever the outcome ------------------------------
    if result.burden_incurred is not None:
        incurred = result.burden_incurred
    elif ranked is not None:
        incurred = ranked.experiment.burden
    else:
        incurred = BurdenVector()
        warnings.append(
            "NO_BURDEN_DECLARED: the result quoted no burden and the experiment is "
            "unknown to the plan; nothing was added to the cumulative burden"
        )
    cumulative = prior.cumulative_burden + incurred

    # -- ambiguity ----------------------------------------------------------
    metric = plan.ambiguity_metric
    if result.ambiguity_metric is not None and result.ambiguity_metric != metric:
        warnings.append(
            f"AMBIGUITY_METRIC_MISMATCH: the result reports {result.ambiguity_metric} "
            f"but the plan is stated on {metric}; the reported value is ignored"
        )
        observed_ambiguity = None
    else:
        observed_ambiguity = result.observed_ambiguity

    derived = region_ambiguity(plan.region, bounds, metric)
    ambiguity_derivable = derived is not None
    if observed_ambiguity is not None:
        ambiguity = observed_ambiguity
    elif derived is not None:
        ambiguity = derived
    else:
        ambiguity = prior.ambiguity
        warnings.append(
            f"AMBIGUITY_NOT_RECOMPUTED: {metric} cannot be derived from coordinate "
            "bounds and the result declared none; the prior value is carried forward "
            "rather than a number being invented (spec 34.4)"
        )

    completed = tuple(dict.fromkeys(prior.completed_experiments + (result.experiment_id,)))
    remaining = tuple(e for e in prior.remaining_experiments if e not in completed)
    informative_remaining = tuple(
        e
        for e in remaining
        if (plan.ranked(e) is not None and plan.ranked(e).tier != RankingTier.UNINFORMATIVE)
    )

    predicate_state = plan.region.state(bounds)
    new_state = QualificationState(
        plan_id=plan.plan_id,
        coordinate_bounds=tuple(bounds.items()),
        predicate_state=predicate_state,
        ambiguity_metric=metric,
        ambiguity=ambiguity,
        cumulative_burden=cumulative,
        completed_experiments=completed,
        remaining_experiments=remaining,
        informative_remaining=informative_remaining,
        ambiguity_derivable=ambiguity_derivable or observed_ambiguity is not None,
        regret_upper_bound=(
            result.regret_upper_bound
            if result.regret_upper_bound is not None
            else prior.regret_upper_bound
        ),
        possible_winners=(
            result.possible_winners
            if result.possible_winners is not None
            else prior.possible_winners
        ),
        guaranteed_winner=(
            result.guaranteed_winner
            if result.guaranteed_winner is not None
            else prior.guaranteed_winner
        ),
        manual_adjudication_required=manual,
        manual_adjudication_reason=manual_reason,
        step=prior.step + 1,
        notes=prior.notes + (f"ingested {result.experiment_id} ({result.status})",),
    )

    stopped, reason, detail = _stopping_detail(plan, new_state)

    return QualificationResult(
        plan_id=plan.plan_id,
        experiment_id=result.experiment_id,
        result_status=result.status,
        prior_state=prior,
        state=new_state,
        target_evaluations=tuple(evaluations),
        predicate_state_before=prior.predicate_state,
        predicate_state_after=predicate_state,
        ambiguity_before=prior.ambiguity,
        ambiguity_after=ambiguity,
        burden_incurred=incurred,
        cumulative_burden=cumulative,
        stopped=stopped,
        stopping_reason=reason,
        stopping_detail=detail,
        residual_ambiguity=ambiguity,
        residual_metric=metric,
        warnings=tuple(dict.fromkeys(warnings)),
        verification_basis=(
            "spec 33.3: the observation was carried into the coordinate by the same "
            "declared transformation the target was pulled back through",
            "spec 33.5: disjoint enclosures are adjudicated, never averaged",
            "spec 34.5: the declared stopping rules were tested in declaration order",
            f"plan fingerprint {plan.fingerprint()}",
            f"result fingerprint {content_hash(result.to_canonical())}",
        ),
    )


def _carry_forward(observed: Interval, path) -> Interval:
    """``theta = scale * x + offset``, widened by the declared transfer tolerance.

    The same tolerance the measurable target was widened by is applied here,
    so an observation that exactly meets its measurable target exactly meets
    the coordinate target it was derived from.
    """
    carried = observed.scale(path.scale) + Interval(path.offset, path.offset)
    tolerance = path.transfer_tolerance
    if tolerance == Exact(0):
        return carried
    return Interval(carried.lo - tolerance, carried.hi + tolerance)
