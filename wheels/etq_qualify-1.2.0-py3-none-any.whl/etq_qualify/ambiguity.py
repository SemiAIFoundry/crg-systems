"""Decision-ambiguity metrics and the declared information effect of an experiment.

Normative basis: master specification 34.4 (ambiguity metrics and the
numerator of the ranking ratio), 34.5 (uncertainty and regret thresholds),
and 22 (numeric, uncertainty, tie, and ambiguity semantics).

The numerator of 34.4 is a *reduction* in decision ambiguity, and this
module keeps that quantity honest in three ways.

**Reduction is measured against a declared metric.**  An
:class:`InformationEffect` names which of the metrics of 34.4 it speaks
about; two effects measured on different metrics are not comparable and
:func:`compare_effects` refuses to order them.

**Worst case is never better than expectation.**  A declaration whose
worst-case posterior ambiguity is below its expected posterior ambiguity is
malformed and is rejected at construction.

**A non-positive reduction is not information.**  ``expected_reduction``
may be zero or negative; :meth:`InformationEffect.informative` says so, and
the ranking in :mod:`etq_qualify.experiment` uses that flag to tier
uninformative experiments below informative ones regardless of burden.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, Mapping, Optional, Sequence, Tuple

from crg_model.numeric import Exact, Interval

__all__ = [
    "AmbiguityError",
    "AmbiguityMetric",
    "RankingBasis",
    "PredicateState",
    "InformationEffect",
    "compare_effects",
    "interval_width",
    "guaranteed_versus_possible_gap",
    "phase_boundary_uncertainty",
    "feasibility_ambiguity",
    "BOUNDS_DERIVABLE_METRICS",
]


class AmbiguityError(ValueError):
    """Raised when an ambiguity declaration is malformed or incomparable."""


class AmbiguityMetric:
    """Specification 34.4.  The ambiguity metric MAY be any of these."""

    POSSIBLE_WINNER_SET_SIZE = "POSSIBLE_WINNER_SET_SIZE"
    GUARANTEED_VERSUS_POSSIBLE_GAP = "GUARANTEED_VERSUS_POSSIBLE_GAP"
    ENTROPY = "ENTROPY"
    PHASE_BOUNDARY_UNCERTAINTY = "PHASE_BOUNDARY_UNCERTAINTY"
    REGRET_UPPER_BOUND = "REGRET_UPPER_BOUND"
    INTERVAL_WIDTH = "INTERVAL_WIDTH"
    FEASIBILITY_AMBIGUITY = "FEASIBILITY_AMBIGUITY"

    ORDER: Tuple[str, ...] = (
        POSSIBLE_WINNER_SET_SIZE,
        GUARANTEED_VERSUS_POSSIBLE_GAP,
        ENTROPY,
        PHASE_BOUNDARY_UNCERTAINTY,
        REGRET_UPPER_BOUND,
        INTERVAL_WIDTH,
        FEASIBILITY_AMBIGUITY,
    )
    ALL = frozenset(ORDER)

    DESCRIPTION: Dict[str, str] = {
        POSSIBLE_WINNER_SET_SIZE: "count of realizations that could still win",
        GUARANTEED_VERSUS_POSSIBLE_GAP: "width of the undecided band around the predicate boundary",
        ENTROPY: "declared entropy of the decision distribution",
        PHASE_BOUNDARY_UNCERTAINTY: "distance from the current enclosure to the phase boundary",
        REGRET_UPPER_BOUND: "certified upper bound on regret from acting now",
        INTERVAL_WIDTH: "width of the decision-value enclosure",
        FEASIBILITY_AMBIGUITY: "count of predicates whose feasibility is undecided",
    }

    @classmethod
    def check(cls, metric: str) -> str:
        if metric not in cls.ALL:
            raise AmbiguityError(
                f"unknown ambiguity metric {metric!r}; specification 34.4 names "
                f"{', '.join(cls.ORDER)}"
            )
        return metric


#: Metrics this package can recompute from coordinate bounds alone.  The
#: others (winner-set size, entropy, regret bound) require the CRG decision
#: machinery or a declared observation; when they are in force and no
#: observed ambiguity is supplied, the prior value is carried forward and a
#: warning is raised rather than a number being invented.
BOUNDS_DERIVABLE_METRICS = frozenset(
    {
        AmbiguityMetric.GUARANTEED_VERSUS_POSSIBLE_GAP,
        AmbiguityMetric.PHASE_BOUNDARY_UNCERTAINTY,
        AmbiguityMetric.INTERVAL_WIDTH,
        AmbiguityMetric.FEASIBILITY_AMBIGUITY,
    }
)


class RankingBasis:
    """Which numerator 34.4 is evaluated with: ``expected`` *or* ``worst case``."""

    EXPECTED = "EXPECTED"
    WORST_CASE = "WORST_CASE"

    ALL = frozenset({EXPECTED, WORST_CASE})

    @classmethod
    def check(cls, basis: str) -> str:
        if basis not in cls.ALL:
            raise AmbiguityError(
                f"unknown ranking basis {basis!r}; specification 34.4 permits "
                "expected or worst-case ambiguity reduction"
            )
        return basis


class PredicateState:
    """Status of a decision predicate against the current enclosures (34.3)."""

    GUARANTEED_SATISFIED = "GUARANTEED_SATISFIED"
    GUARANTEED_VIOLATED = "GUARANTEED_VIOLATED"
    AMBIGUOUS = "AMBIGUOUS"
    #: At least one coordinate the predicate depends on has no bound at all.
    #: This is distinct from AMBIGUOUS: nothing constrains the answer, so no
    #: enclosure of ``g`` exists (33.3 -- an absent coordinate is not a default).
    UNDETERMINED = "UNDETERMINED"

    ALL = frozenset({GUARANTEED_SATISFIED, GUARANTEED_VIOLATED, AMBIGUOUS, UNDETERMINED})
    RESOLVED = frozenset({GUARANTEED_SATISFIED, GUARANTEED_VIOLATED})


def _abs(value: Exact) -> Exact:
    return value if value >= Exact(0) else -value


@dataclass(frozen=True)
class InformationEffect:
    """A declared expected/worst-case effect of an experiment on ambiguity (34.4).

    ``ambiguity_before`` and the two posteriors are stated on the *same*
    metric.  ``basis`` records how the declaration was arrived at; an
    undeclared basis is permitted but a plan that carries one is weaker
    evidence, which is why it is preserved verbatim in the plan output.
    """

    metric: str
    ambiguity_before: Exact
    expected_ambiguity_after: Exact
    worst_case_ambiguity_after: Exact
    basis: str = ""
    experiment_id: Optional[str] = None

    def __init__(
        self,
        metric: str,
        ambiguity_before: object,
        expected_ambiguity_after: object,
        worst_case_ambiguity_after: object,
        basis: str = "",
        experiment_id: Optional[str] = None,
    ) -> None:
        object.__setattr__(self, "metric", AmbiguityMetric.check(str(metric)))
        before = Exact(ambiguity_before)
        expected = Exact(expected_ambiguity_after)
        worst = Exact(worst_case_ambiguity_after)
        for label, value in (
            ("ambiguity_before", before),
            ("expected_ambiguity_after", expected),
            ("worst_case_ambiguity_after", worst),
        ):
            if value < Exact(0):
                raise AmbiguityError(f"{label} is negative; ambiguity is a magnitude")
        if worst < expected:
            raise AmbiguityError(
                "worst_case_ambiguity_after is below expected_ambiguity_after; a "
                "worst case that beats the expectation is a malformed declaration "
                "(spec 34.4)"
            )
        object.__setattr__(self, "ambiguity_before", before)
        object.__setattr__(self, "expected_ambiguity_after", expected)
        object.__setattr__(self, "worst_case_ambiguity_after", worst)
        object.__setattr__(self, "basis", str(basis))
        object.__setattr__(
            self, "experiment_id", None if experiment_id is None else str(experiment_id)
        )

    @classmethod
    def none(
        cls,
        metric: str,
        ambiguity_before: object,
        *,
        basis: str = "declared to resolve nothing",
        experiment_id: Optional[str] = None,
    ) -> "InformationEffect":
        """An explicitly zero-information declaration (34.4 numerator = 0)."""
        return cls(
            metric,
            ambiguity_before,
            ambiguity_before,
            ambiguity_before,
            basis=basis,
            experiment_id=experiment_id,
        )

    @property
    def expected_reduction(self) -> Exact:
        return self.ambiguity_before - self.expected_ambiguity_after

    @property
    def worst_case_reduction(self) -> Exact:
        return self.ambiguity_before - self.worst_case_ambiguity_after

    def reduction(self, basis: str = RankingBasis.EXPECTED) -> Exact:
        RankingBasis.check(basis)
        if basis == RankingBasis.WORST_CASE:
            return self.worst_case_reduction
        return self.expected_reduction

    def posterior(self, basis: str = RankingBasis.EXPECTED) -> Exact:
        RankingBasis.check(basis)
        if basis == RankingBasis.WORST_CASE:
            return self.worst_case_ambiguity_after
        return self.expected_ambiguity_after

    def informative(self, basis: str = RankingBasis.EXPECTED) -> bool:
        """True only for a strictly positive reduction on the chosen basis."""
        return self.reduction(basis) > Exact(0)

    def with_experiment(self, experiment_id: str) -> "InformationEffect":
        return InformationEffect(
            self.metric,
            self.ambiguity_before,
            self.expected_ambiguity_after,
            self.worst_case_ambiguity_after,
            basis=self.basis,
            experiment_id=experiment_id,
        )

    def to_canonical(self) -> dict:
        record: dict = {
            "metric": self.metric,
            "ambiguity_before": self.ambiguity_before.to_canonical(),
            "expected_ambiguity_after": self.expected_ambiguity_after.to_canonical(),
            "worst_case_ambiguity_after": self.worst_case_ambiguity_after.to_canonical(),
            "expected_reduction": self.expected_reduction.to_canonical(),
            "worst_case_reduction": self.worst_case_reduction.to_canonical(),
        }
        if self.experiment_id:
            record["experiment_id"] = self.experiment_id
        if self.basis:
            record["basis"] = self.basis
        return record


def compare_effects(
    left: InformationEffect, right: InformationEffect, *, basis: str = RankingBasis.EXPECTED
) -> int:
    """Order two effects on the same metric: ``-1``, ``0``, or ``1``.

    Raises when the metrics differ.  A gap measured in wafers per hour and a
    winner-set count are not two readings of one quantity.
    """
    if left.metric != right.metric:
        raise AmbiguityError(
            f"ambiguity reductions on different metrics are not comparable: "
            f"{left.metric} versus {right.metric} (spec 34.4)"
        )
    a, b = left.reduction(basis), right.reduction(basis)
    if a < b:
        return -1
    if a > b:
        return 1
    return 0


# ==========================================================================
# metric evaluation from exact enclosures
# ==========================================================================

def interval_width(value: Optional[Interval]) -> Optional[Exact]:
    """``INTERVAL_WIDTH``: the width of a decision-value enclosure (34.4)."""
    if value is None:
        return None
    return value.width


def guaranteed_versus_possible_gap(value: Optional[Interval]) -> Optional[Exact]:
    """``GUARANTEED_VERSUS_POSSIBLE_GAP`` for a predicate value ``g``.

    Zero when the sign of ``g`` is decided over the whole enclosure -- there
    is then no gap between what is guaranteed and what is merely possible.
    Otherwise the full width of the straddling enclosure.
    """
    if value is None:
        return None
    if value.lo >= Exact(0) or value.hi < Exact(0):
        return Exact(0)
    return value.width


def phase_boundary_uncertainty(value: Optional[Interval]) -> Optional[Exact]:
    """``PHASE_BOUNDARY_UNCERTAINTY``: how far the enclosure reaches past ``g = 0``.

    For a straddling enclosure this is the smaller of the two excursions:
    the amount by which one further unit of evidence on the near side would
    have to move to place the whole enclosure on one side of the boundary.
    """
    if value is None:
        return None
    if value.lo >= Exact(0) or value.hi < Exact(0):
        return Exact(0)
    below = -value.lo
    above = value.hi
    return below if below <= above else above


def feasibility_ambiguity(states: Sequence[str]) -> Exact:
    """``FEASIBILITY_AMBIGUITY``: how many predicates remain undecided (34.4)."""
    return Exact(sum(1 for s in states if s not in PredicateState.RESOLVED))
