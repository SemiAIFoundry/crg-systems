"""Declared experiment burden, its weighting, and its limits.

Normative basis: master specification 34.4 (the denominator of the
experiment-ranking ratio) and 34.2 (burden constraints as a declared input
to inverse qualification).

Burden is *declared*, never inferred.  The nine dimensions of 34.4 are
named constants and an undeclared dimension is not silently zero: a
:class:`BurdenVector` remembers which dimensions its author actually
declared, and :meth:`BurdenWeights.scalarize` refuses to weight a
dimension that was never declared.  Ranking on a cost the experiment
never quoted would be a fabricated denominator, and 34.4 divides by the
*declared* burden.

Every magnitude is an exact rational (14.2).  No float enters this module.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from fractions import Fraction
from typing import Any, Dict, Iterable, Mapping, Optional, Sequence, Tuple

from crg_model.numeric import Exact

__all__ = [
    "BurdenError",
    "BurdenDimension",
    "BurdenVector",
    "BurdenWeights",
    "BurdenLimits",
]


class BurdenError(ValueError):
    """Raised when a burden declaration is malformed or cannot be weighted."""


class BurdenDimension:
    """Specification 34.4.  Burden MAY include all nine of these."""

    TIME = "time"
    COST = "cost"
    SAMPLES = "samples"
    TOOL_OCCUPANCY = "tool_occupancy"
    MATERIAL = "material"
    SAFETY_RISK = "safety_risk"
    SCHEDULE_RISK = "schedule_risk"
    ORGANIZATIONAL_DISCLOSURE = "organizational_disclosure"
    COMPUTATIONAL_EXPENSE = "computational_expense"

    #: Canonical ordering; part of the canonical encoding of a burden vector.
    ORDER: Tuple[str, ...] = (
        TIME,
        COST,
        SAMPLES,
        TOOL_OCCUPANCY,
        MATERIAL,
        SAFETY_RISK,
        SCHEDULE_RISK,
        ORGANIZATIONAL_DISCLOSURE,
        COMPUTATIONAL_EXPENSE,
    )
    ALL = frozenset(ORDER)

    #: What the declaring party is expected to quote each dimension in.  The
    #: registry (13) governs real units; this is a disclosure aid, not a
    #: unit conversion table.
    SUGGESTED_UNIT: Dict[str, str] = {
        TIME: "h",
        COST: "currency",
        SAMPLES: "count",
        TOOL_OCCUPANCY: "tool-h",
        MATERIAL: "declared-material-unit",
        SAFETY_RISK: "declared-risk-index",
        SCHEDULE_RISK: "declared-risk-index",
        ORGANIZATIONAL_DISCLOSURE: "declared-disclosure-index",
        COMPUTATIONAL_EXPENSE: "core-h",
    }

    @classmethod
    def check(cls, name: str) -> str:
        if name not in cls.ALL:
            raise BurdenError(
                f"unknown burden dimension {name!r}; specification 34.4 names "
                f"{', '.join(cls.ORDER)}"
            )
        return name


def _exact(value: Any, what: str) -> Exact:
    try:
        return Exact(value)
    except (TypeError, ValueError) as exc:  # pragma: no cover - message path
        raise BurdenError(f"{what} must be an exact rational: {exc}") from exc


def _normalize(values: Any, what: str) -> Tuple[Tuple[str, Exact], ...]:
    if values is None:
        return ()
    if isinstance(values, Mapping):
        pairs: Iterable[Tuple[Any, Any]] = values.items()
    else:
        pairs = tuple(values)
    seen: Dict[str, Exact] = {}
    for item in pairs:
        try:
            name, magnitude = item
        except (TypeError, ValueError) as exc:
            raise BurdenError(f"{what} entries must be (dimension, magnitude) pairs") from exc
        name = BurdenDimension.check(str(name))
        if name in seen:
            raise BurdenError(f"burden dimension {name!r} declared twice")
        amount = _exact(magnitude, f"{what}[{name}]")
        if amount < Exact(0):
            raise BurdenError(f"{what}[{name}] is negative; burden is a non-negative magnitude")
        seen[name] = amount
    return tuple((name, seen[name]) for name in BurdenDimension.ORDER if name in seen)


@dataclass(frozen=True)
class BurdenVector:
    """A declared experiment burden over the nine dimensions of 34.4.

    An absent dimension means *not declared*, which is not the same claim as
    "declared to be zero".  :attr:`declared_dimensions` reports the
    difference and :meth:`BurdenWeights.scalarize` acts on it.
    """

    values: Tuple[Tuple[str, Exact], ...] = ()
    basis: str = ""

    def __init__(self, values: Any = None, basis: str = "") -> None:
        object.__setattr__(self, "values", _normalize(values, "burden"))
        object.__setattr__(self, "basis", str(basis))

    @classmethod
    def of(cls, *, basis: str = "", **dimensions: Any) -> "BurdenVector":
        """``BurdenVector.of(time="4", cost="1200")`` -- keyword construction."""
        return cls(dimensions, basis=basis)

    @property
    def declared_dimensions(self) -> Tuple[str, ...]:
        return tuple(name for name, _ in self.values)

    def get(self, dimension: str) -> Exact:
        """Magnitude of a dimension; ``Exact(0)`` when it was not declared."""
        BurdenDimension.check(dimension)
        for name, amount in self.values:
            if name == dimension:
                return amount
        return Exact(0)

    def declares(self, dimension: str) -> bool:
        return dimension in self.declared_dimensions

    @property
    def is_empty(self) -> bool:
        return not self.values

    @property
    def is_zero(self) -> bool:
        """True when every declared dimension is exactly zero."""
        return all(amount == Exact(0) for _, amount in self.values)

    def __add__(self, other: "BurdenVector") -> "BurdenVector":
        """Union of declarations; magnitudes add.  Used to accumulate spend."""
        if not isinstance(other, BurdenVector):  # pragma: no cover - guard
            return NotImplemented
        merged: Dict[str, Exact] = {name: amount for name, amount in self.values}
        for name, amount in other.values:
            merged[name] = merged.get(name, Exact(0)) + amount
        basis = "; ".join(b for b in (self.basis, other.basis) if b)
        return BurdenVector(merged, basis=basis)

    def to_canonical(self) -> dict:
        record: dict = {
            "declared_dimensions": list(self.declared_dimensions),
            "values": {name: amount.to_canonical() for name, amount in self.values},
        }
        if self.basis:
            record["basis"] = self.basis
        return record

    def render(self) -> str:
        if not self.values:
            return "(no burden declared)"
        return ", ".join(f"{name}={amount}" for name, amount in self.values)


@dataclass(frozen=True)
class BurdenWeights:
    """Non-negative weights turning a burden vector into a single denominator.

    At least one weight must be positive: a weight vector that is entirely
    zero would make every experiment infinitely attractive, which is the
    degenerate reading of 34.4 that this module refuses.
    """

    weights: Tuple[Tuple[str, Exact], ...] = ()
    basis: str = ""

    def __init__(self, weights: Any = None, basis: str = "") -> None:
        normalized = _normalize(weights, "burden weight")
        if not normalized:
            raise BurdenError(
                "burden weights are empty; specification 34.4 divides by a declared "
                "burden, so at least one dimension must be weighted"
            )
        if all(w == Exact(0) for _, w in normalized):
            raise BurdenError(
                "every burden weight is zero; the ranking denominator would vanish "
                "for every experiment (spec 34.4)"
            )
        object.__setattr__(self, "weights", normalized)
        object.__setattr__(self, "basis", str(basis))

    @classmethod
    def of(cls, *, basis: str = "", **dimensions: Any) -> "BurdenWeights":
        return cls(dimensions, basis=basis)

    @classmethod
    def uniform(cls, dimensions: Sequence[str], *, basis: str = "uniform weighting") -> "BurdenWeights":
        return cls({str(d): Exact(1) for d in dimensions}, basis=basis)

    @property
    def weighted_dimensions(self) -> Tuple[str, ...]:
        return tuple(name for name, w in self.weights if w > Exact(0))

    def weight(self, dimension: str) -> Exact:
        BurdenDimension.check(dimension)
        for name, w in self.weights:
            if name == dimension:
                return w
        return Exact(0)

    def undeclared_but_weighted(self, burden: BurdenVector) -> Tuple[str, ...]:
        return tuple(d for d in self.weighted_dimensions if not burden.declares(d))

    def scalarize(self, burden: BurdenVector) -> Exact:
        """Weighted sum of the declared burden (the denominator of 34.4).

        Raises when a positively weighted dimension was not declared.  The
        alternative -- treating the omission as zero -- would let an
        experiment improve its rank by declining to quote its cost.
        """
        missing = self.undeclared_but_weighted(burden)
        if missing:
            raise BurdenError(
                "cannot weight undeclared burden dimension(s) "
                f"{', '.join(missing)}; specification 34.4 divides by the *declared* "
                "burden, and an omitted dimension is not a zero dimension"
            )
        total = Exact(0)
        for name, w in self.weights:
            total = total + (w * burden.get(name))
        return total

    def to_canonical(self) -> dict:
        record: dict = {name: w.to_canonical() for name, w in self.weights}
        if self.basis:
            record["basis"] = self.basis
        return {"weights": record}


@dataclass(frozen=True)
class BurdenLimits:
    """Declared burden constraints (34.2) and the burden-limit stop (34.5).

    A limit on a dimension the plan never accumulates cannot be breached;
    a limit is breached the moment cumulative spend *exceeds* it.
    """

    caps: BurdenVector = field(default_factory=BurdenVector)
    basis: str = ""

    @classmethod
    def of(cls, *, basis: str = "", **dimensions: Any) -> "BurdenLimits":
        return cls(caps=BurdenVector(dimensions), basis=basis)

    @classmethod
    def none(cls) -> "BurdenLimits":
        return cls(caps=BurdenVector(), basis="no burden limit declared")

    @property
    def declared(self) -> bool:
        return bool(self.caps.declared_dimensions)

    def exceeded_by(self, cumulative: BurdenVector) -> Tuple[str, ...]:
        """Dimensions whose cap the cumulative burden has passed."""
        breached = []
        for name in self.caps.declared_dimensions:
            if cumulative.get(name) > self.caps.get(name):
                breached.append(name)
        return tuple(breached)

    def would_exceed(self, cumulative: BurdenVector, additional: BurdenVector) -> Tuple[str, ...]:
        return self.exceeded_by(cumulative + additional)

    def headroom(self, cumulative: BurdenVector) -> Tuple[Tuple[str, Exact], ...]:
        return tuple(
            (name, self.caps.get(name) - cumulative.get(name))
            for name in self.caps.declared_dimensions
        )

    def to_canonical(self) -> dict:
        record: dict = {"declared": self.declared, "caps": self.caps.to_canonical()}
        if self.basis:
            record["basis"] = self.basis
        return record
