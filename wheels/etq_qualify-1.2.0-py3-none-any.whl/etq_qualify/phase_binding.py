"""ETQ decision-consequence surface for certified CRG phase evidence."""
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Mapping, Sequence

from crg_model.canonical import canonical_json, content_hash
from crg_model.envelope import EvidenceClass
from crg_model.phase_binding import (
    CertifiedPhaseBinding,
    CertifiedPhaseBindingError,
    CertifiedPhaseConsumption,
    consume_certified_phase,
)

if TYPE_CHECKING:
    from .lifecycle import LoopArtifactRef

__all__ = ["PhaseBoundDecisionConsequence", "build_phase_bound_decision_consequence"]


def _payload(value: Any) -> dict:
    if hasattr(value, "to_canonical") and callable(value.to_canonical):
        value = value.to_canonical()
    if not isinstance(value, Mapping):
        raise CertifiedPhaseBindingError("ETQ decision consequence must be a canonical object")
    try:
        return json.loads(canonical_json(dict(value)))
    except (TypeError, ValueError) as error:
        raise CertifiedPhaseBindingError(
            f"ETQ decision consequence is not canonical CRG content: {error}"
        ) from error


@dataclass(frozen=True)
class PhaseBoundDecisionConsequence:
    """Decision consequence that records the shared certified-phase identity."""

    consequence_id: str
    target_decision_id: str
    consequence: dict
    phase_consumption: CertifiedPhaseConsumption

    def to_canonical(self) -> dict:
        return {
            "record_type": "DecisionConsequence",
            "schema_version": "1.2.0",
            "profile": "crg.etq.certified-phase-consequence",
            "consequence_id": self.consequence_id,
            "target_decision_id": self.target_decision_id,
            "consequence": self.consequence,
            "consequence_payload_root": content_hash(self.consequence),
            "phase_consumption": self.phase_consumption.to_canonical(),
            "claim_limitations": [
                "DECISION_CONSEQUENCE_IS_RELATIVE_TO_CARRIED_SOURCE_R",
                "NO_PHASE_BOUNDARY_CLAIM_FROM_UNVERIFIED_EVIDENCE",
            ],
        }

    def root_hash(self) -> str:
        return content_hash(self.to_canonical())

    def artifact_ref(
        self,
        *,
        parent_hashes: Sequence[str] = (),
        evidence_class: str = EvidenceClass.DECLARED,
    ) -> "LoopArtifactRef":
        """Return the optional v1.3 step-6 reference consumed by ``ETQDecisionLoop``.

        The certified decision consequence is a v1.2 phase consumer and must
        remain importable without the later twelve-step lifecycle module.  The
        v1.3 adapter is therefore resolved only when a caller explicitly asks
        for the lifecycle reference.
        """
        from .lifecycle import LoopArtifactRef

        return LoopArtifactRef(
            artifact_id=self.consequence_id,
            artifact_type="DecisionConsequence",
            content_hash=self.root_hash(),
            parent_hashes=tuple(parent_hashes),
            evidence_class=evidence_class,
        )


def build_phase_bound_decision_consequence(
    *,
    consequence_id: str,
    target_decision_id: str,
    consequence: Mapping[str, Any],
    certified_phase: CertifiedPhaseBinding,
    expected_phase_analysis_root: str,
    expected_source_r_root: str,
) -> PhaseBoundDecisionConsequence:
    """Bind ETQ step-6 decision consequences to independently verified phase evidence."""
    if not consequence_id or not target_decision_id:
        raise CertifiedPhaseBindingError(
            "phase-bound ETQ consequence requires consequence and target-decision identities"
        )
    if not isinstance(certified_phase, CertifiedPhaseBinding):
        raise CertifiedPhaseBindingError(
            "ETQ phase consequence requires a verified CertifiedPhaseBinding"
        )
    certified_phase.require_identity(expected_phase_analysis_root, expected_source_r_root)
    payload = _payload(consequence)
    consumption = consume_certified_phase(
        certified_phase,
        consumer="ETQ_DECISION_CONSEQUENCE",
        subject_root=content_hash(payload),
        expected_phase_analysis_root=expected_phase_analysis_root,
        expected_source_r_root=expected_source_r_root,
    )
    return PhaseBoundDecisionConsequence(
        consequence_id=consequence_id,
        target_decision_id=target_decision_id,
        consequence=payload,
        phase_consumption=consumption,
    )
