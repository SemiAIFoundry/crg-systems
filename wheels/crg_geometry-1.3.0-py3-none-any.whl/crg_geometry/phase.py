"""Certified phase analysis for registered CRG mathematical profiles.

Workstream C adds phase evidence without weakening the v1.0.1 geometry
contract.  A phase boundary is a change in the optimal policy set under a
*registered* parameterization; a crossing between inactive policies, an
active coordinate, and a bottleneck are not phase boundaries.

The first registered profile is ``TWO_COORDINATE_PRICE_SIMPLEX_V1``.  For a
two-coordinate minimization signature ``(x, y)`` it declares the exact
nonnegative price family

    w(theta) = (theta, 1 - theta),  0 <= theta <= 1,

and therefore the affine policy value

    value(theta) = y + (x - y) theta.

All crossings, winner sets, regions, ties, degeneracies, stability
conditions, and boundary distances are computed with rational arithmetic.
Unsupported profiles and dimensions fail closed.
"""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from crg_model.canonical import content_hash
from crg_model.numeric import Exact
from crg_model.records import RRecord

__all__ = [
    "PHASE_ANALYSIS_SCHEMA_VERSION",
    "PhaseProfile",
    "UnsupportedPhaseProfileError",
    "PhaseVerificationError",
    "PhasePolicy",
    "PhaseRegion",
    "PhaseBoundary",
    "PhaseTie",
    "PhaseDegeneracy",
    "PhaseStability",
    "PhaseAnalysisRecord",
    "build_phase_analysis",
    "phase_analysis_from_canonical",
    "verify_phase_analysis",
    "require_verified_phase_analysis",
]

PHASE_ANALYSIS_SCHEMA_VERSION = "1.2.0"


class PhaseProfile:
    """Registered mathematical profiles admitted to certificate-authorizing use."""

    TWO_COORDINATE_PRICE_SIMPLEX_V1 = "TWO_COORDINATE_PRICE_SIMPLEX_V1"
    REGISTERED = frozenset({TWO_COORDINATE_PRICE_SIMPLEX_V1})


class UnsupportedPhaseProfileError(ValueError):
    """The requested phase semantics are not registered or cannot be proved."""


class PhaseVerificationError(ValueError):
    """A phase-analysis artifact failed independent recomputation."""


def _exact(value: Fraction) -> Exact:
    return Exact(value)


def _stable_id(prefix: str, value: Any) -> str:
    digest = content_hash(value).split(":", 1)[1]
    return f"{prefix}-{digest[:20]}"


def _sorted_ids(values: Iterable[str]) -> Tuple[str, ...]:
    return tuple(sorted(set(str(value) for value in values)))


@dataclass(frozen=True)
class PhasePolicy:
    """One realization's exact affine value under the registered profile."""

    policy_id: str
    coordinate_values: Tuple[Exact, Exact]
    intercept: Exact
    slope: Exact

    def to_canonical(self) -> dict:
        return {
            "policy_id": self.policy_id,
            "coordinate_values": [value.to_canonical() for value in self.coordinate_values],
            "affine_value": {
                "intercept": self.intercept.to_canonical(),
                "slope": self.slope.to_canonical(),
            },
        }


@dataclass(frozen=True)
class PhaseRegion:
    """A maximal interval whose interior has one constant optimal policy set."""

    region_id: str
    lower: Exact
    upper: Exact
    lower_closed: bool
    upper_closed: bool
    winner_ids: Tuple[str, ...]

    def to_canonical(self) -> dict:
        return {
            "region_id": self.region_id,
            "parameter_interval": {
                "lower": self.lower.to_canonical(),
                "upper": self.upper.to_canonical(),
                "lower_closed": self.lower_closed,
                "upper_closed": self.upper_closed,
            },
            "winner_ids": list(self.winner_ids),
            "claim": "CERTIFIED_CONSTANT_OPTIMAL_POLICY_SET",
        }


@dataclass(frozen=True)
class PhaseBoundary:
    """A proved one- or two-sided change in the optimal policy set."""

    boundary_id: str
    parameter: Exact
    sidedness: str
    left_winner_ids: Tuple[str, ...]
    boundary_winner_ids: Tuple[str, ...]
    right_winner_ids: Tuple[str, ...]

    def to_canonical(self) -> dict:
        return {
            "boundary_id": self.boundary_id,
            "parameter": self.parameter.to_canonical(),
            "sidedness": self.sidedness,
            "left_winner_ids": list(self.left_winner_ids),
            "boundary_winner_ids": list(self.boundary_winner_ids),
            "right_winner_ids": list(self.right_winner_ids),
            "classification": "CERTIFIED_PHASE_BOUNDARY",
            "basis": "OPTIMAL_POLICY_SET_CHANGES",
        }


@dataclass(frozen=True)
class PhaseTie:
    """An exact optimal-policy tie at a point or over an interval."""

    tie_id: str
    kind: str
    decision_outcome: str
    lower: Exact
    upper: Exact
    lower_closed: bool
    upper_closed: bool
    policy_ids: Tuple[str, ...]

    def to_canonical(self) -> dict:
        return {
            "tie_id": self.tie_id,
            "kind": self.kind,
            "decision_outcome": self.decision_outcome,
            "parameter_interval": {
                "lower": self.lower.to_canonical(),
                "upper": self.upper.to_canonical(),
                "lower_closed": self.lower_closed,
                "upper_closed": self.upper_closed,
            },
            "policy_ids": list(self.policy_ids),
            "claim": (
                "EXACT_OPTIMAL_VALUE_EQUALITY"
                if self.decision_outcome == "CERTIFIED_WINNER_SET"
                else "WITHIN_DECLARED_POLICY_TOLERANCE"
            ),
        }


@dataclass(frozen=True)
class PhaseDegeneracy:
    """A declared non-generic condition retained by the phase artifact."""

    degeneracy_id: str
    kind: str
    policy_ids: Tuple[str, ...]
    parameter: Optional[Exact] = None

    def to_canonical(self) -> dict:
        record = {
            "degeneracy_id": self.degeneracy_id,
            "kind": self.kind,
            "policy_ids": list(self.policy_ids),
        }
        if self.parameter is not None:
            record["parameter"] = self.parameter.to_canonical()
        return record


@dataclass(frozen=True)
class PhaseStability:
    """Local stability and the exact distance to the nearest true boundary."""

    parameter: Exact
    state: str
    winner_ids: Tuple[str, ...]
    stable_lower: Exact
    stable_upper: Exact
    lower_closed: bool
    upper_closed: bool
    boundary_distance: Optional[Exact]
    nearest_boundary_ids: Tuple[str, ...]

    def to_canonical(self) -> dict:
        record = {
            "parameter": self.parameter.to_canonical(),
            "state": self.state,
            "winner_ids": list(self.winner_ids),
            "stability_interval": {
                "lower": self.stable_lower.to_canonical(),
                "upper": self.stable_upper.to_canonical(),
                "lower_closed": self.lower_closed,
                "upper_closed": self.upper_closed,
            },
            "boundary_distance_metric": "ABSOLUTE_SCALAR_PARAMETER",
            "nearest_boundary_ids": list(self.nearest_boundary_ids),
        }
        if self.boundary_distance is not None:
            record["boundary_distance"] = self.boundary_distance.to_canonical()
        else:
            record["boundary_distance"] = None
        return record


@dataclass(frozen=True)
class PhaseAnalysisRecord:
    """Portable exact evidence for one registered phase analysis."""

    analysis_id: str
    profile_id: str
    source_r_root: str
    coordinate_schema_hash: str
    family_completeness: Dict[str, Any]
    policy_tolerance: Exact
    policies: Tuple[PhasePolicy, ...]
    regions: Tuple[PhaseRegion, ...]
    boundaries: Tuple[PhaseBoundary, ...]
    ties: Tuple[PhaseTie, ...]
    degeneracies: Tuple[PhaseDegeneracy, ...]
    schema_version: str = PHASE_ANALYSIS_SCHEMA_VERSION
    stability: Optional[PhaseStability] = None

    def to_canonical(self) -> dict:
        record = {
            "record_type": "PhaseAnalysisRecord",
            "schema_version": self.schema_version,
            "analysis_id": self.analysis_id,
            "profile": {
                "profile_id": self.profile_id,
                "profile_version": "1",
                "objective": "MINIMIZE",
                "parameter": "theta",
                "parameter_domain": {
                    "lower": Exact(0).to_canonical(),
                    "upper": Exact(1).to_canonical(),
                    "lower_closed": True,
                    "upper_closed": True,
                },
                "weight_map": ["theta", "1-theta"],
                "policy_tolerance": self.policy_tolerance.to_canonical(),
            },
            "source_r_root": self.source_r_root,
            "coordinate_schema_hash": self.coordinate_schema_hash,
            "family_completeness": self.family_completeness,
            "claim_scope": "RELATIVE_TO_DECLARED_FAMILY",
            "arithmetic_profile": "EXACT_RATIONAL",
            "solver_trust_profile": "EXACT_RECOMPUTED",
            "policies": [policy.to_canonical() for policy in self.policies],
            "regions": [region.to_canonical() for region in self.regions],
            "boundaries": [boundary.to_canonical() for boundary in self.boundaries],
            "ties": [tie.to_canonical() for tie in self.ties],
            "degeneracies": [item.to_canonical() for item in self.degeneracies],
            "verification_program": "crg-geometry.phase.verify/v1",
            "claim_limitations": [
                "REGISTERED_PROFILE_ONLY",
                "NO_PHASE_CLAIM_FROM_ACTIVE_COORDINATES_OR_BOTTLENECKS",
                "NO_CLAIM_BEYOND_DECLARED_FAMILY_COMPLETENESS",
            ],
        }
        if self.stability is not None:
            record["stability"] = self.stability.to_canonical()
        return record

    def root_hash(self) -> str:
        return content_hash(self.to_canonical())


def _policies_from_r(r: RRecord) -> Tuple[PhasePolicy, ...]:
    if r.schema.dimension != 2:
        raise UnsupportedPhaseProfileError(
            "TWO_COORDINATE_PRICE_SIMPLEX_V1 requires exactly two coordinates; "
            f"the source R declares {r.schema.dimension}"
        )
    directions = tuple(coordinate.direction for coordinate in r.schema.coordinates)
    if directions != ("MINIMIZE", "MINIMIZE"):
        raise UnsupportedPhaseProfileError(
            "TWO_COORDINATE_PRICE_SIMPLEX_V1 requires two coordinates declared "
            "MINIMIZE; other orientations need a separately registered phase profile"
        )
    policies: List[PhasePolicy] = []
    seen: set[str] = set()
    for fiber in r.fibers:
        x, y = (component.value for component in fiber.signature.values)
        for policy_id in fiber.realization_ids:
            if policy_id in seen:
                raise ValueError(f"duplicate realization identifier {policy_id!r} in R")
            seen.add(policy_id)
            policies.append(
                PhasePolicy(
                    policy_id=policy_id,
                    coordinate_values=(_exact(x), _exact(y)),
                    intercept=_exact(y),
                    slope=_exact(x - y),
                )
            )
    if not policies:
        raise UnsupportedPhaseProfileError(
            "phase analysis requires at least one legal realization in the source R"
        )
    return tuple(sorted(policies, key=lambda item: item.policy_id))


def _score(policy: PhasePolicy, parameter: Fraction) -> Fraction:
    return policy.intercept.value + policy.slope.value * parameter


def _winners(
    policies: Sequence[PhasePolicy], parameter: Fraction, tolerance: Fraction
) -> Tuple[str, ...]:
    scores = {policy.policy_id: _score(policy, parameter) for policy in policies}
    best = min(scores.values())
    return tuple(
        sorted(
            policy_id
            for policy_id, value in scores.items()
            if value <= best + tolerance
        )
    )


def _crossings(
    policies: Sequence[PhasePolicy], tolerance: Fraction
) -> Tuple[Fraction, ...]:
    points = {Fraction(0), Fraction(1)}
    for index, left in enumerate(policies):
        for right in policies[index + 1 :]:
            denominator = left.slope.value - right.slope.value
            if denominator == 0:
                continue
            # A decision set can change at exact equality or when either
            # policy reaches the declared tolerance from the other.
            for offset in (-tolerance, Fraction(0), tolerance):
                parameter = (
                    right.intercept.value - left.intercept.value + offset
                ) / denominator
                if 0 <= parameter <= 1:
                    points.add(parameter)
    return tuple(sorted(points))


def _build_boundaries(
    policies: Sequence[PhasePolicy],
    crossings: Sequence[Fraction],
    tolerance: Fraction,
) -> Tuple[PhaseBoundary, ...]:
    out: List[PhaseBoundary] = []
    for index, parameter in enumerate(crossings):
        at = _winners(policies, parameter, tolerance)
        left = ()
        right = ()
        if index > 0:
            left = _winners(
                policies, (crossings[index - 1] + parameter) / 2, tolerance
            )
        if index + 1 < len(crossings):
            right = _winners(
                policies, (parameter + crossings[index + 1]) / 2, tolerance
            )

        changes = (left and left != at) or (right and right != at) or (
            left and right and left != right
        )
        if not changes:
            continue
        # An inactive crossing has identical winner sets at the point and on
        # both sides.  It is intentionally omitted.
        if parameter not in (0, 1) and left == right:
            continue
        sidedness = "TWO_SIDED" if left and right else "ONE_SIDED"
        payload = {
            "parameter": _exact(parameter),
            "left": left,
            "at": at,
            "right": right,
        }
        out.append(
            PhaseBoundary(
                boundary_id=_stable_id("phase-boundary", payload),
                parameter=_exact(parameter),
                sidedness=sidedness,
                left_winner_ids=left,
                boundary_winner_ids=at,
                right_winner_ids=right,
            )
        )
    return tuple(out)


def _build_regions(
    policies: Sequence[PhasePolicy],
    boundaries: Sequence[PhaseBoundary],
    tolerance: Fraction,
) -> Tuple[PhaseRegion, ...]:
    boundary_values = {item.parameter.value for item in boundaries}
    cuts = sorted({Fraction(0), Fraction(1)} | boundary_values)
    regions: List[PhaseRegion] = []
    for lower, upper in zip(cuts, cuts[1:]):
        if lower == upper:
            continue
        winners = _winners(policies, (lower + upper) / 2, tolerance)
        lower_closed = (
            lower not in boundary_values
            and _winners(policies, lower, tolerance) == winners
        )
        upper_closed = (
            upper not in boundary_values
            and _winners(policies, upper, tolerance) == winners
        )
        payload = {
            "lower": _exact(lower),
            "upper": _exact(upper),
            "lower_closed": lower_closed,
            "upper_closed": upper_closed,
            "winners": winners,
        }
        regions.append(
            PhaseRegion(
                region_id=_stable_id("phase-region", payload),
                lower=_exact(lower),
                upper=_exact(upper),
                lower_closed=lower_closed,
                upper_closed=upper_closed,
                winner_ids=winners,
            )
        )
    return tuple(regions)


def _build_ties(
    policies: Sequence[PhasePolicy],
    boundaries: Sequence[PhaseBoundary],
    regions: Sequence[PhaseRegion],
) -> Tuple[PhaseTie, ...]:
    policy_map = {policy.policy_id: policy for policy in policies}

    def point_outcome(policy_ids: Sequence[str], parameter: Fraction) -> str:
        values = {_score(policy_map[policy_id], parameter) for policy_id in policy_ids}
        return "CERTIFIED_WINNER_SET" if len(values) == 1 else "CERTIFIED_POLICY_TIE"

    def interval_outcome(policy_ids: Sequence[str]) -> str:
        coefficients = {
            (
                policy_map[policy_id].intercept.value,
                policy_map[policy_id].slope.value,
            )
            for policy_id in policy_ids
        }
        return "CERTIFIED_WINNER_SET" if len(coefficients) == 1 else "CERTIFIED_POLICY_TIE"

    ties: List[PhaseTie] = []
    for boundary in boundaries:
        if len(boundary.boundary_winner_ids) < 2:
            continue
        outcome = point_outcome(boundary.boundary_winner_ids, boundary.parameter.value)
        payload = {
            "kind": "POINT",
            "decision_outcome": outcome,
            "parameter": boundary.parameter,
            "policies": boundary.boundary_winner_ids,
        }
        ties.append(
            PhaseTie(
                tie_id=_stable_id("phase-tie", payload),
                kind="POINT",
                decision_outcome=outcome,
                lower=boundary.parameter,
                upper=boundary.parameter,
                lower_closed=True,
                upper_closed=True,
                policy_ids=boundary.boundary_winner_ids,
            )
        )
    for region in regions:
        if len(region.winner_ids) < 2:
            continue
        outcome = interval_outcome(region.winner_ids)
        payload = {
            "kind": "INTERVAL",
            "decision_outcome": outcome,
            "lower": region.lower,
            "upper": region.upper,
            "lower_closed": region.lower_closed,
            "upper_closed": region.upper_closed,
            "policies": region.winner_ids,
        }
        ties.append(
            PhaseTie(
                tie_id=_stable_id("phase-tie", payload),
                kind="INTERVAL",
                decision_outcome=outcome,
                lower=region.lower,
                upper=region.upper,
                lower_closed=region.lower_closed,
                upper_closed=region.upper_closed,
                policy_ids=region.winner_ids,
            )
        )
    return tuple(sorted(ties, key=lambda item: (item.lower.value, item.upper.value, item.tie_id)))


def _build_degeneracies(
    policies: Sequence[PhasePolicy], boundaries: Sequence[PhaseBoundary]
) -> Tuple[PhaseDegeneracy, ...]:
    out: List[PhaseDegeneracy] = []
    coefficient_groups: Dict[Tuple[Fraction, Fraction], List[str]] = {}
    for policy in policies:
        coefficient_groups.setdefault(
            (policy.intercept.value, policy.slope.value), []
        ).append(policy.policy_id)
    for coefficients, policy_ids in sorted(coefficient_groups.items()):
        if len(policy_ids) < 2:
            continue
        ids = _sorted_ids(policy_ids)
        payload = {"kind": "COINCIDENT_SCORE_FUNCTIONS", "policies": ids}
        out.append(
            PhaseDegeneracy(
                degeneracy_id=_stable_id("phase-degeneracy", payload),
                kind="COINCIDENT_SCORE_FUNCTIONS",
                policy_ids=ids,
            )
        )
    policy_map = {policy.policy_id: policy for policy in policies}
    for boundary in boundaries:
        scores = {
            policy_id: _score(policy_map[policy_id], boundary.parameter.value)
            for policy_id in boundary.boundary_winner_ids
        }
        best = min(scores.values())
        exact_optimal_ids = _sorted_ids(
            policy_id for policy_id, value in scores.items() if value == best
        )
        distinct = {
            (
                policy_map[policy_id].intercept.value,
                policy_map[policy_id].slope.value,
            )
            for policy_id in exact_optimal_ids
        }
        if len(distinct) < 3:
            continue
        payload = {
            "kind": "MULTIWAY_OPTIMAL_BOUNDARY",
            "parameter": boundary.parameter,
            "policies": exact_optimal_ids,
        }
        out.append(
            PhaseDegeneracy(
                degeneracy_id=_stable_id("phase-degeneracy", payload),
                kind="MULTIWAY_OPTIMAL_BOUNDARY",
                policy_ids=exact_optimal_ids,
                parameter=boundary.parameter,
            )
        )
    return tuple(sorted(out, key=lambda item: item.degeneracy_id))


def _build_stability(
    policies: Sequence[PhasePolicy],
    regions: Sequence[PhaseRegion],
    boundaries: Sequence[PhaseBoundary],
    parameter: Exact,
    tolerance: Fraction,
) -> PhaseStability:
    theta = parameter.value
    if not 0 <= theta <= 1:
        raise ValueError("phase stability parameter theta must lie in the closed interval [0, 1]")
    winners = _winners(policies, theta, tolerance)
    on_boundary = [item for item in boundaries if item.parameter.value == theta]
    if on_boundary:
        return PhaseStability(
            parameter=parameter,
            state="ON_CERTIFIED_PHASE_BOUNDARY",
            winner_ids=winners,
            stable_lower=parameter,
            stable_upper=parameter,
            lower_closed=True,
            upper_closed=True,
            boundary_distance=Exact(0),
            nearest_boundary_ids=_sorted_ids(item.boundary_id for item in on_boundary),
        )

    containing = None
    for region in regions:
        lower_ok = theta > region.lower.value or (theta == region.lower.value and region.lower_closed)
        upper_ok = theta < region.upper.value or (theta == region.upper.value and region.upper_closed)
        if lower_ok and upper_ok:
            containing = region
            break
    if containing is None:
        raise ValueError("parameter is not covered by a phase region or boundary")

    if boundaries:
        distances = {
            item.boundary_id: abs(theta - item.parameter.value) for item in boundaries
        }
        nearest = min(distances.values())
        nearest_ids = _sorted_ids(
            boundary_id for boundary_id, distance in distances.items() if distance == nearest
        )
        boundary_distance: Optional[Exact] = _exact(nearest)
        state = "STABLE_WITHIN_CERTIFIED_REGION"
    else:
        nearest_ids = ()
        boundary_distance = None
        state = "NO_PHASE_BOUNDARY_IN_DECLARED_DOMAIN"
    return PhaseStability(
        parameter=parameter,
        state=state,
        winner_ids=winners,
        stable_lower=containing.lower,
        stable_upper=containing.upper,
        lower_closed=containing.lower_closed,
        upper_closed=containing.upper_closed,
        boundary_distance=boundary_distance,
        nearest_boundary_ids=nearest_ids,
    )


def build_phase_analysis(
    r: RRecord,
    *,
    profile_id: str = PhaseProfile.TWO_COORDINATE_PRICE_SIMPLEX_V1,
    stability_parameter: Optional[Any] = None,
    policy_tolerance: Any = 0,
) -> PhaseAnalysisRecord:
    """Build exact phase evidence for a registered profile.

    The artifact's claim remains relative to the completeness basis carried
    by ``R``.  No global-family claim is inferred from a represented family.
    """
    if profile_id not in PhaseProfile.REGISTERED:
        raise UnsupportedPhaseProfileError(
            f"unregistered phase profile {profile_id!r}; supported profiles are "
            f"{sorted(PhaseProfile.REGISTERED)}"
        )
    tolerance = Exact(policy_tolerance)
    if tolerance < 0:
        raise ValueError("phase policy tolerance must be nonnegative (spec 22.3)")
    policies = _policies_from_r(r)
    crossings = _crossings(policies, tolerance.value)
    boundaries = _build_boundaries(policies, crossings, tolerance.value)
    regions = _build_regions(policies, boundaries, tolerance.value)
    ties = _build_ties(policies, boundaries, regions)
    degeneracies = _build_degeneracies(policies, boundaries)
    probe = Exact(stability_parameter) if stability_parameter is not None else None
    stability = (
        _build_stability(
            policies, regions, boundaries, probe, tolerance.value
        )
        if probe is not None
        else None
    )
    identity = {
        "schema_version": PHASE_ANALYSIS_SCHEMA_VERSION,
        "profile_id": profile_id,
        "source_r_root": r.root_hash(),
        "stability_parameter": probe,
        "policy_tolerance": tolerance,
    }
    return PhaseAnalysisRecord(
        analysis_id=_stable_id("phase-analysis", identity),
        profile_id=profile_id,
        source_r_root=r.root_hash(),
        coordinate_schema_hash=r.schema.schema_hash(),
        family_completeness=r.completeness.to_canonical(),
        policy_tolerance=tolerance,
        policies=policies,
        regions=regions,
        boundaries=boundaries,
        ties=ties,
        degeneracies=degeneracies,
        schema_version=PHASE_ANALYSIS_SCHEMA_VERSION,
        stability=stability,
    )


def phase_analysis_from_canonical(document: Mapping[str, Any]) -> PhaseAnalysisRecord:
    """Decode the exact v1.2 wire form and require a lossless round trip.

    This parser is intentionally version-specific.  Unknown versions or
    fields require an admitted migration; they are not silently ignored.
    Semantic acceptance still requires :func:`verify_phase_analysis` against
    the source ``R``.
    """
    if not isinstance(document, Mapping):
        raise ValueError("phase-analysis document must be an object")
    if document.get("record_type") != "PhaseAnalysisRecord":
        raise ValueError("phase-analysis record_type is missing or unsupported")
    schema_version = document.get("schema_version")
    if schema_version != PHASE_ANALYSIS_SCHEMA_VERSION:
        raise ValueError(
            f"unsupported phase-analysis schema version {schema_version!r}; "
            f"expected {PHASE_ANALYSIS_SCHEMA_VERSION!r}"
        )

    def mapping(value: Any, where: str) -> Mapping[str, Any]:
        if not isinstance(value, Mapping):
            raise ValueError(f"{where} must be an object")
        return value

    def sequence(value: Any, where: str) -> Sequence[Any]:
        if not isinstance(value, (list, tuple)):
            raise ValueError(f"{where} must be an array")
        return value

    def exact(value: Any, where: str) -> Exact:
        try:
            return Exact.from_canonical(dict(mapping(value, where)))
        except (KeyError, TypeError, ValueError) as error:
            raise ValueError(f"{where} is not an exact rational: {error}") from error

    profile = mapping(document.get("profile"), "profile")
    tolerance = exact(profile.get("policy_tolerance"), "profile.policy_tolerance")

    policies: List[PhasePolicy] = []
    for index, raw in enumerate(sequence(document.get("policies"), "policies")):
        item = mapping(raw, f"policies[{index}]")
        coordinates = sequence(
            item.get("coordinate_values"), f"policies[{index}].coordinate_values"
        )
        if len(coordinates) != 2:
            raise ValueError(f"policies[{index}] must carry exactly two coordinates")
        affine = mapping(item.get("affine_value"), f"policies[{index}].affine_value")
        policies.append(
            PhasePolicy(
                policy_id=str(item.get("policy_id", "")),
                coordinate_values=(
                    exact(coordinates[0], f"policies[{index}].coordinate_values[0]"),
                    exact(coordinates[1], f"policies[{index}].coordinate_values[1]"),
                ),
                intercept=exact(
                    affine.get("intercept"), f"policies[{index}].affine_value.intercept"
                ),
                slope=exact(affine.get("slope"), f"policies[{index}].affine_value.slope"),
            )
        )

    regions: List[PhaseRegion] = []
    for index, raw in enumerate(sequence(document.get("regions"), "regions")):
        item = mapping(raw, f"regions[{index}]")
        interval = mapping(
            item.get("parameter_interval"), f"regions[{index}].parameter_interval"
        )
        regions.append(
            PhaseRegion(
                region_id=str(item.get("region_id", "")),
                lower=exact(interval.get("lower"), f"regions[{index}].lower"),
                upper=exact(interval.get("upper"), f"regions[{index}].upper"),
                lower_closed=bool(interval.get("lower_closed")),
                upper_closed=bool(interval.get("upper_closed")),
                winner_ids=tuple(
                    str(value)
                    for value in sequence(item.get("winner_ids"), f"regions[{index}].winner_ids")
                ),
            )
        )

    boundaries: List[PhaseBoundary] = []
    for index, raw in enumerate(sequence(document.get("boundaries"), "boundaries")):
        item = mapping(raw, f"boundaries[{index}]")
        boundaries.append(
            PhaseBoundary(
                boundary_id=str(item.get("boundary_id", "")),
                parameter=exact(item.get("parameter"), f"boundaries[{index}].parameter"),
                sidedness=str(item.get("sidedness", "")),
                left_winner_ids=tuple(
                    str(value)
                    for value in sequence(
                        item.get("left_winner_ids"), f"boundaries[{index}].left_winner_ids"
                    )
                ),
                boundary_winner_ids=tuple(
                    str(value)
                    for value in sequence(
                        item.get("boundary_winner_ids"),
                        f"boundaries[{index}].boundary_winner_ids",
                    )
                ),
                right_winner_ids=tuple(
                    str(value)
                    for value in sequence(
                        item.get("right_winner_ids"), f"boundaries[{index}].right_winner_ids"
                    )
                ),
            )
        )

    ties: List[PhaseTie] = []
    for index, raw in enumerate(sequence(document.get("ties"), "ties")):
        item = mapping(raw, f"ties[{index}]")
        interval = mapping(
            item.get("parameter_interval"), f"ties[{index}].parameter_interval"
        )
        ties.append(
            PhaseTie(
                tie_id=str(item.get("tie_id", "")),
                kind=str(item.get("kind", "")),
                decision_outcome=str(item.get("decision_outcome", "")),
                lower=exact(interval.get("lower"), f"ties[{index}].lower"),
                upper=exact(interval.get("upper"), f"ties[{index}].upper"),
                lower_closed=bool(interval.get("lower_closed")),
                upper_closed=bool(interval.get("upper_closed")),
                policy_ids=tuple(
                    str(value)
                    for value in sequence(item.get("policy_ids"), f"ties[{index}].policy_ids")
                ),
            )
        )

    degeneracies: List[PhaseDegeneracy] = []
    for index, raw in enumerate(
        sequence(document.get("degeneracies"), "degeneracies")
    ):
        item = mapping(raw, f"degeneracies[{index}]")
        parameter = item.get("parameter")
        degeneracies.append(
            PhaseDegeneracy(
                degeneracy_id=str(item.get("degeneracy_id", "")),
                kind=str(item.get("kind", "")),
                policy_ids=tuple(
                    str(value)
                    for value in sequence(
                        item.get("policy_ids"), f"degeneracies[{index}].policy_ids"
                    )
                ),
                parameter=(
                    exact(parameter, f"degeneracies[{index}].parameter")
                    if parameter is not None
                    else None
                ),
            )
        )

    stability = None
    if "stability" in document:
        item = mapping(document.get("stability"), "stability")
        interval = mapping(item.get("stability_interval"), "stability.stability_interval")
        distance = item.get("boundary_distance")
        stability = PhaseStability(
            parameter=exact(item.get("parameter"), "stability.parameter"),
            state=str(item.get("state", "")),
            winner_ids=tuple(
                str(value)
                for value in sequence(item.get("winner_ids"), "stability.winner_ids")
            ),
            stable_lower=exact(interval.get("lower"), "stability.stability_interval.lower"),
            stable_upper=exact(interval.get("upper"), "stability.stability_interval.upper"),
            lower_closed=bool(interval.get("lower_closed")),
            upper_closed=bool(interval.get("upper_closed")),
            boundary_distance=(
                exact(distance, "stability.boundary_distance")
                if distance is not None
                else None
            ),
            nearest_boundary_ids=tuple(
                str(value)
                for value in sequence(
                    item.get("nearest_boundary_ids"), "stability.nearest_boundary_ids"
                )
            ),
        )

    completeness = mapping(document.get("family_completeness"), "family_completeness")
    decoded = PhaseAnalysisRecord(
        analysis_id=str(document.get("analysis_id", "")),
        profile_id=str(profile.get("profile_id", "")),
        source_r_root=str(document.get("source_r_root", "")),
        coordinate_schema_hash=str(document.get("coordinate_schema_hash", "")),
        family_completeness=dict(completeness),
        policy_tolerance=tolerance,
        policies=tuple(policies),
        regions=tuple(regions),
        boundaries=tuple(boundaries),
        ties=tuple(ties),
        degeneracies=tuple(degeneracies),
        schema_version=str(schema_version),
        stability=stability,
    )
    if decoded.to_canonical() != dict(document):
        raise ValueError(
            "phase-analysis document is not the canonical lossless v1.2 wire form"
        )
    return decoded


def verify_phase_analysis(record: PhaseAnalysisRecord, source_r: RRecord) -> List[str]:
    """Independently recompute the minimum facts needed to accept ``record``.

    This verifier does not call :func:`build_phase_analysis` or its phase
    partition helpers.  It derives crossings and lower-envelope winners
    directly from the source R, then checks every claimed region, boundary,
    tie, degeneracy, stability interval, and deterministic identity.
    """
    violations: List[str] = []
    if record.schema_version != PHASE_ANALYSIS_SCHEMA_VERSION:
        return [
            f"phase: unsupported schema version {record.schema_version!r}; "
            f"expected {PHASE_ANALYSIS_SCHEMA_VERSION!r}"
        ]
    if record.profile_id not in PhaseProfile.REGISTERED:
        return [f"phase: unregistered profile {record.profile_id!r}"]
    if source_r.schema.dimension != 2:
        return [
            "phase: TWO_COORDINATE_PRICE_SIMPLEX_V1 requires exactly two coordinates"
        ]
    if tuple(coordinate.direction for coordinate in source_r.schema.coordinates) != (
        "MINIMIZE",
        "MINIMIZE",
    ):
        return [
            "phase: TWO_COORDINATE_PRICE_SIMPLEX_V1 requires both source coordinates "
            "to be declared MINIMIZE"
        ]
    if record.source_r_root != source_r.root_hash():
        violations.append("phase: source R root does not match the supplied source")
    if record.coordinate_schema_hash != source_r.schema.schema_hash():
        violations.append("phase: coordinate schema hash does not match the source R")
    if record.family_completeness != source_r.completeness.to_canonical():
        violations.append("phase: family completeness differs from the source R")
    tolerance = record.policy_tolerance.value
    if tolerance < 0:
        violations.append("phase: policy tolerance is negative")

    # Independent policy derivation.
    expected_policy: Dict[str, Tuple[Fraction, Fraction, Fraction, Fraction]] = {}
    for fiber in source_r.fibers:
        if len(fiber.signature) != 2:
            violations.append("phase: source fiber has the wrong dimension")
            continue
        x, y = (value.value for value in fiber.signature.values)
        for policy_id in fiber.realization_ids:
            if policy_id in expected_policy:
                violations.append(f"phase: duplicate source policy identifier {policy_id!r}")
            expected_policy[policy_id] = (x, y, y, x - y)
    actual_ids = [policy.policy_id for policy in record.policies]
    if actual_ids != sorted(actual_ids) or len(actual_ids) != len(set(actual_ids)):
        violations.append("phase: policies are not unique and canonically sorted")
    if set(actual_ids) != set(expected_policy):
        violations.append("phase: policies do not preserve every source realization identity")
    for policy in record.policies:
        expected = expected_policy.get(policy.policy_id)
        actual = (
            policy.coordinate_values[0].value,
            policy.coordinate_values[1].value,
            policy.intercept.value,
            policy.slope.value,
        )
        if expected is not None and actual != expected:
            violations.append(
                f"phase: affine coefficients for policy {policy.policy_id!r} do not derive "
                "from its source signature"
            )

    coefficients = {
        policy.policy_id: (policy.intercept.value, policy.slope.value)
        for policy in record.policies
    }

    def value(policy_id: str, theta: Fraction) -> Fraction:
        intercept, slope = coefficients[policy_id]
        return intercept + slope * theta

    def winners(theta: Fraction) -> Tuple[str, ...]:
        values = {policy_id: value(policy_id, theta) for policy_id in coefficients}
        if not values:
            return ()
        minimum = min(values.values())
        return tuple(
            sorted(
                policy_id
                for policy_id, result in values.items()
                if result <= minimum + tolerance
            )
        )

    # Recompute every affine crossing independently from the serialized
    # coefficients, then retain only crossings that change the lower envelope.
    candidates = {Fraction(0), Fraction(1)}
    policy_ids = sorted(coefficients)
    for index, left_id in enumerate(policy_ids):
        left_intercept, left_slope = coefficients[left_id]
        for right_id in policy_ids[index + 1 :]:
            right_intercept, right_slope = coefficients[right_id]
            if left_slope == right_slope:
                continue
            for offset in (-tolerance, Fraction(0), tolerance):
                theta = (
                    right_intercept - left_intercept + offset
                ) / (left_slope - right_slope)
                if 0 <= theta <= 1:
                    candidates.add(theta)
    candidate_list = sorted(candidates)
    expected_boundaries: List[Tuple[Fraction, Tuple[str, ...], Tuple[str, ...], Tuple[str, ...]]] = []
    for index, theta in enumerate(candidate_list):
        at = winners(theta)
        left = winners((candidate_list[index - 1] + theta) / 2) if index else ()
        right = (
            winners((theta + candidate_list[index + 1]) / 2)
            if index + 1 < len(candidate_list)
            else ()
        )
        changes = (left and left != at) or (right and right != at) or (
            left and right and left != right
        )
        if changes and not (theta not in (0, 1) and left == right):
            expected_boundaries.append((theta, left, at, right))

    actual_boundary_values = [boundary.parameter.value for boundary in record.boundaries]
    expected_boundary_values = [item[0] for item in expected_boundaries]
    if actual_boundary_values != expected_boundary_values:
        violations.append("phase: certified boundary set differs from the exact lower envelope")
    for boundary, expected in zip(record.boundaries, expected_boundaries):
        theta, left, at, right = expected
        expected_id = _stable_id(
            "phase-boundary",
            {"parameter": _exact(theta), "left": left, "at": at, "right": right},
        )
        if boundary.boundary_id != expected_id:
            violations.append(f"phase: boundary at {theta} has a noncanonical identity")
        if (
            boundary.left_winner_ids,
            boundary.boundary_winner_ids,
            boundary.right_winner_ids,
        ) != (left, at, right):
            violations.append(f"phase: boundary at {theta} has incorrect winner sets")
        expected_sidedness = "TWO_SIDED" if left and right else "ONE_SIDED"
        if boundary.sidedness != expected_sidedness:
            violations.append(f"phase: boundary at {theta} has incorrect sidedness")

    cuts = sorted({Fraction(0), Fraction(1)} | set(expected_boundary_values))
    expected_regions = []
    boundary_set = set(expected_boundary_values)
    for lower, upper in zip(cuts, cuts[1:]):
        if lower == upper:
            continue
        region_winners = winners((lower + upper) / 2)
        lower_closed = lower not in boundary_set and winners(lower) == region_winners
        upper_closed = upper not in boundary_set and winners(upper) == region_winners
        expected_regions.append((lower, upper, lower_closed, upper_closed, region_winners))
    if len(record.regions) != len(expected_regions):
        violations.append("phase: region count does not match the independently derived partition")
    for region, expected in zip(record.regions, expected_regions):
        lower, upper, lower_closed, upper_closed, region_winners = expected
        payload = {
            "lower": _exact(lower),
            "upper": _exact(upper),
            "lower_closed": lower_closed,
            "upper_closed": upper_closed,
            "winners": region_winners,
        }
        if (
            region.lower.value,
            region.upper.value,
            region.lower_closed,
            region.upper_closed,
            region.winner_ids,
        ) != expected:
            violations.append(f"phase: region {region.region_id!r} is not an exact phase cell")
        if region.region_id != _stable_id("phase-region", payload):
            violations.append(f"phase: region on [{lower}, {upper}] has a noncanonical identity")

    def point_outcome(theta: Fraction, policy_ids: Sequence[str]) -> str:
        return (
            "CERTIFIED_WINNER_SET"
            if len({value(policy_id, theta) for policy_id in policy_ids}) == 1
            else "CERTIFIED_POLICY_TIE"
        )

    def interval_outcome(policy_ids: Sequence[str]) -> str:
        return (
            "CERTIFIED_WINNER_SET"
            if len({coefficients[policy_id] for policy_id in policy_ids}) == 1
            else "CERTIFIED_POLICY_TIE"
        )

    expected_point_ties = {
        (theta, at, point_outcome(theta, at))
        for theta, _left, at, _right in expected_boundaries
        if len(at) >= 2
    }
    expected_interval_ties = {
        (
            lower,
            upper,
            lower_closed,
            upper_closed,
            region_winners,
            interval_outcome(region_winners),
        )
        for lower, upper, lower_closed, upper_closed, region_winners in expected_regions
        if len(region_winners) >= 2
    }
    actual_point_ties = {
        (tie.lower.value, tie.policy_ids, tie.decision_outcome)
        for tie in record.ties
        if tie.kind == "POINT" and tie.lower == tie.upper and tie.lower_closed and tie.upper_closed
    }
    actual_interval_ties = {
        (
            tie.lower.value,
            tie.upper.value,
            tie.lower_closed,
            tie.upper_closed,
            tie.policy_ids,
            tie.decision_outcome,
        )
        for tie in record.ties
        if tie.kind == "INTERVAL" and tie.lower < tie.upper
    }
    if actual_point_ties != expected_point_ties:
        violations.append("phase: point policy ties are incomplete or unsupported")
    if actual_interval_ties != expected_interval_ties:
        violations.append("phase: interval policy ties are incomplete or unsupported")
    if len(record.ties) != len(actual_point_ties) + len(actual_interval_ties):
        violations.append("phase: malformed or duplicate policy tie records are present")
    for tie in record.ties:
        if tie.kind == "POINT":
            payload = {
                "kind": "POINT",
                "decision_outcome": tie.decision_outcome,
                "parameter": tie.lower,
                "policies": tie.policy_ids,
            }
        elif tie.kind == "INTERVAL":
            payload = {
                "kind": "INTERVAL",
                "decision_outcome": tie.decision_outcome,
                "lower": tie.lower,
                "upper": tie.upper,
                "lower_closed": tie.lower_closed,
                "upper_closed": tie.upper_closed,
                "policies": tie.policy_ids,
            }
        else:
            continue
        if tie.tie_id != _stable_id("phase-tie", payload):
            violations.append(f"phase: tie {tie.tie_id!r} has a noncanonical identity")

    expected_coincident = {
        tuple(sorted(group))
        for key in set(coefficients.values())
        for group in [[policy_id for policy_id, value_pair in coefficients.items() if value_pair == key]]
        if len(group) >= 2
    }
    actual_coincident = {
        item.policy_ids
        for item in record.degeneracies
        if item.kind == "COINCIDENT_SCORE_FUNCTIONS" and item.parameter is None
    }
    if actual_coincident != expected_coincident:
        violations.append("phase: coincident-policy degeneracies are incomplete or unsupported")
    expected_multiway = set()
    for theta, _left, at, _right in expected_boundaries:
        if not at:
            continue
        at_values = {policy_id: value(policy_id, theta) for policy_id in at}
        best = min(at_values.values())
        exact_ids = tuple(
            sorted(policy_id for policy_id, result in at_values.items() if result == best)
        )
        if len({coefficients[policy_id] for policy_id in exact_ids}) >= 3:
            expected_multiway.add((theta, exact_ids))
    actual_multiway = {
        (item.parameter.value, item.policy_ids)
        for item in record.degeneracies
        if item.kind == "MULTIWAY_OPTIMAL_BOUNDARY" and item.parameter is not None
    }
    if actual_multiway != expected_multiway:
        violations.append("phase: multiway-boundary degeneracies are incomplete or unsupported")
    if len(record.degeneracies) != len(actual_coincident) + len(actual_multiway):
        violations.append("phase: unknown or duplicate degeneracy records are present")
    for item in record.degeneracies:
        payload = {"kind": item.kind, "policies": item.policy_ids}
        if item.parameter is not None:
            payload["parameter"] = item.parameter
        if item.degeneracy_id != _stable_id("phase-degeneracy", payload):
            violations.append(
                f"phase: degeneracy {item.degeneracy_id!r} has a noncanonical identity"
            )

    if record.stability is not None:
        stability = record.stability
        theta = stability.parameter.value
        if not 0 <= theta <= 1:
            violations.append("phase: stability probe lies outside the registered domain")
        else:
            at_boundary = [
                boundary for boundary in record.boundaries if boundary.parameter.value == theta
            ]
            if at_boundary:
                expected_state = "ON_CERTIFIED_PHASE_BOUNDARY"
                expected_interval = (theta, theta, True, True)
                expected_distance: Optional[Fraction] = Fraction(0)
                nearest_ids = _sorted_ids(item.boundary_id for item in at_boundary)
            else:
                match = next(
                    (
                        region
                        for region in record.regions
                        if (theta > region.lower.value or (theta == region.lower.value and region.lower_closed))
                        and (theta < region.upper.value or (theta == region.upper.value and region.upper_closed))
                    ),
                    None,
                )
                if match is None:
                    violations.append("phase: stability probe is not covered by the phase partition")
                    expected_state = stability.state
                    expected_interval = (
                        stability.stable_lower.value,
                        stability.stable_upper.value,
                        stability.lower_closed,
                        stability.upper_closed,
                    )
                else:
                    expected_interval = (
                        match.lower.value,
                        match.upper.value,
                        match.lower_closed,
                        match.upper_closed,
                    )
                    expected_state = (
                        "STABLE_WITHIN_CERTIFIED_REGION"
                        if record.boundaries
                        else "NO_PHASE_BOUNDARY_IN_DECLARED_DOMAIN"
                    )
                if record.boundaries:
                    distances = {
                        item.boundary_id: abs(theta - item.parameter.value)
                        for item in record.boundaries
                    }
                    expected_distance = min(distances.values())
                    nearest_ids = _sorted_ids(
                        boundary_id
                        for boundary_id, distance in distances.items()
                        if distance == expected_distance
                    )
                else:
                    expected_distance = None
                    nearest_ids = ()
            actual_interval = (
                stability.stable_lower.value,
                stability.stable_upper.value,
                stability.lower_closed,
                stability.upper_closed,
            )
            actual_distance = (
                stability.boundary_distance.value
                if stability.boundary_distance is not None
                else None
            )
            if stability.state != expected_state:
                violations.append("phase: stability state is incorrect")
            if stability.winner_ids != winners(theta):
                violations.append("phase: stability winner set is incorrect")
            if actual_interval != expected_interval:
                violations.append("phase: stability interval is incorrect")
            if actual_distance != expected_distance or stability.nearest_boundary_ids != nearest_ids:
                violations.append("phase: nearest-boundary distance is incorrect")

    expected_analysis_id = _stable_id(
        "phase-analysis",
        {
            "schema_version": record.schema_version,
            "profile_id": record.profile_id,
            "source_r_root": source_r.root_hash(),
            "stability_parameter": record.stability.parameter if record.stability else None,
            "policy_tolerance": record.policy_tolerance,
        },
    )
    if record.analysis_id != expected_analysis_id:
        violations.append("phase: analysis identity is not canonical for its source and probe")
    try:
        record.root_hash()
    except Exception as error:
        violations.append(f"phase: artifact is not canonically hashable ({error})")
    return violations


def require_verified_phase_analysis(record: PhaseAnalysisRecord, source_r: RRecord) -> None:
    """Fail closed unless independent recomputation accepts the phase artifact."""
    violations = verify_phase_analysis(record, source_r)
    if violations:
        raise PhaseVerificationError("; ".join(violations))
