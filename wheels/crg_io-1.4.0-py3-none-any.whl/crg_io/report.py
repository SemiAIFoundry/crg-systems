"""Canonical human-readable certificate report.

Normative basis: master specification section 50 (canonical human-readable
certificate report), with section 21 (claim scope), section 22 (numeric,
uncertainty, tie, and ambiguity semantics), section 26 (decision-query
derivation), section 27 (regret witness), and section 29 (certificates).

Section 50.1 requires that an auditor can read a certificate without CRG
Studio, and that all conforming renderers preserve the same semantic order.
Section 50.2 fixes that order in twenty-one positions, and 50.3 allows an
implementation to vary typography but forbids hiding or reordering the claim
scope, the completeness basis, the uncertainty, or the verification status in
a manner that could mislead the reader.

This renderer is therefore:

* **scope first** -- the claim, its claim scope, and its completeness basis
  occupy the first three sections, before any winner is named, so a
  ``RELATIVE_EXPLICIT_FAMILY`` result can never be skimmed as a global one;
* **deterministic** -- no clock, no locale, no iteration over unordered sets;
  rendering the same certificate twice yields byte-identical text, which is
  what makes a rendered report diffable and archivable;
* **plain ASCII** -- no colour codes, no box drawing, no typography that a
  terminal, a printer, or a screen reader would disagree about.

Every objective value carries a bracketed evidence tag so the reader can see
at a glance which numbers are exact, which are enclosed, and which are merely
replay-bound (spec 5.3, 22.2, 23.2).

This module deliberately depends only on ``crg_model``: a report is a
rendering of a record, and a renderer that had to import the decision engine
could not be used to audit a certificate that engine produced.
"""
from __future__ import annotations

import textwrap
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence

from crg_model.completeness import ClaimScope
from crg_model.numeric import ArithmeticProfile, Exact, Interval
from crg_model.records import DecisionCertificate, DecisionOutcome, DeltaCertificate

__all__ = [
    "RENDERER_ID",
    "RENDERER_VERSION",
    "render_certificate",
    "render_delta",
    "claim_sentence",
    "OUTCOME_PHRASE",
    "SCOPE_PHRASE",
]

RENDERER_ID = "crg-io.report"
RENDERER_VERSION = "1.4.0"

LABEL_WIDTH = 26

# ---------------------------------------------------------------------------
# phrasing tables (spec 29.6 outcomes, 21.4 claim scopes)
# ---------------------------------------------------------------------------

#: Specification 29.5 (required outcomes).  The phrase never stands alone: 21.5
#: forbids shortening "certified winner relative to the explicitly imported
#: family" to "certified winner", so :func:`claim_sentence` always pairs it with
#: the claim scope.
OUTCOME_PHRASE: Dict[str, str] = {
    DecisionOutcome.CERTIFIED_WINNER: "Certified winner",
    DecisionOutcome.CERTIFIED_WINNER_SET: "Certified winner set",
    DecisionOutcome.CERTIFIED_POLICY_TIE: "Certified policy tie",
    DecisionOutcome.POSSIBLE_WINNER_SET: "Possible-winner set (unresolved under the "
    "declared enclosures)",
    DecisionOutcome.CERTIFIED_RETENTION: "Certified retention",
    DecisionOutcome.AMBIGUOUS: "Ambiguous; no winner is certified",
    DecisionOutcome.ALL_INFEASIBLE: "All candidates infeasible; no winner exists",
    DecisionOutcome.BLOCKED_SCOPE_MISMATCH: "BLOCKED: decision scope mismatch",
    DecisionOutcome.BLOCKED_INCOMPLETE_EVIDENCE: "BLOCKED: incomplete evidence",
    DecisionOutcome.BLOCKED_GEOMETRY_LOSS: "BLOCKED: geometry not preserved",
    DecisionOutcome.BLOCKED_COVERAGE: "BLOCKED: insufficient family coverage",
    DecisionOutcome.HEURISTIC_ONLY: "Heuristic incumbent only; NOT a certified winner",
    DecisionOutcome.STALE: "STALE: this certificate no longer matches its dependencies",
    DecisionOutcome.EXPIRED: "EXPIRED: this certificate is past its declared validity",
    DecisionOutcome.REVOKED: "REVOKED: this certificate has been withdrawn",
    DecisionOutcome.UNVERIFIABLE_REDACTED: (
        "UNVERIFIABLE: redaction prevents independent checking of this certificate"
    ),
}

#: Specification 21.4.
SCOPE_PHRASE: Dict[str, str] = {
    ClaimScope.FULL_DECLARED_UNIVERSE: "over the complete declared universe",
    ClaimScope.GENERATOR_CLOSED_FAMILY: "over the closure of the declared generator set",
    ClaimScope.BOUNDED_REMAINDER_GLOBAL: (
        "globally for this decision scope, because the unenumerated remainder is proved "
        "unable to change the result"
    ),
    ClaimScope.RELATIVE_EXPLICIT_FAMILY: (
        "ONLY relative to the explicitly represented candidates -- this is NOT a global claim"
    ),
    ClaimScope.PARTIAL_FAMILY: (
        "over an incomplete or unknown family -- no globally phrased winner is permitted"
    ),
}

#: Specification 21.5, rendered verbatim so the reader sees the limit, not a summary.
SCOPE_LIMIT: Dict[str, str] = {
    ClaimScope.FULL_DECLARED_UNIVERSE: (
        "Strong certified claims are permitted within the declared universe."
    ),
    ClaimScope.GENERATOR_CLOSED_FAMILY: (
        "Strong certified claims are permitted within the declared generator closure."
    ),
    ClaimScope.BOUNDED_REMAINDER_GLOBAL: (
        "Strong certified claims are permitted; the remainder bound is part of the evidence."
    ),
    ClaimScope.RELATIVE_EXPLICIT_FAMILY: (
        "A certified RELATIVE winner is permitted. Adding one further candidate may change "
        "this result, and no statement about candidates outside the represented family is "
        "made or implied."
    ),
    ClaimScope.PARTIAL_FAMILY: (
        "A globally phrased winner is FORBIDDEN. This result may be read only as a heuristic "
        "incumbent, a possible winner, or a decision blocked by incomplete coverage."
    ),
}

#: Bracketed evidence tag per value (spec 5.3, 22.2, 23.2).
_PROFILE_TAG: Dict[str, str] = {
    ArithmeticProfile.EXACT_RATIONAL: "EXACT",
    ArithmeticProfile.INTERVAL_ENCLOSED: "ENCLOSED",
    ArithmeticProfile.FLOAT_REPLAY_BOUND: "REPLAY-BOUND",
    ArithmeticProfile.UNBOUNDED_FLOAT: "UNCERTIFIED",
}

_CERTIFYING_OUTCOMES = frozenset(
    {
        DecisionOutcome.CERTIFIED_WINNER,
        DecisionOutcome.CERTIFIED_WINNER_SET,
        DecisionOutcome.CERTIFIED_POLICY_TIE,
        DecisionOutcome.CERTIFIED_RETENTION,
    }
)


# ---------------------------------------------------------------------------
# layout primitives -- shared with the import report
# ---------------------------------------------------------------------------


def _rule(char: str, width: int) -> str:
    return char * max(8, width)


def _wrap(text: str, width: int, indent: int = 0) -> List[str]:
    prefix = " " * indent
    body = " ".join(str(text).split())
    if not body:
        return [""]
    lines = textwrap.wrap(
        body,
        width=max(24, width),
        initial_indent=prefix,
        subsequent_indent=prefix + "  ",
        break_long_words=False,
        break_on_hyphens=False,
    )
    # A hash or a long identifier is never broken, which can leave a bullet
    # marker stranded on its own line; keep the marker with its content.
    while len(lines) > 1 and len(lines[0].strip()) <= 2:
        lines = [lines[0] + " " + lines[1].strip()] + lines[2:]
    return lines


def _kv(label: str, value: Any, width: int, indent: int = 2) -> List[str]:
    text = "(none)" if value is None or value == "" else str(value)
    head = f"{' ' * indent}{label:<{LABEL_WIDTH}}: "
    available = max(24, width - len(head))
    chunks = textwrap.wrap(
        " ".join(text.split()),
        width=available,
        break_long_words=False,
        break_on_hyphens=False,
    ) or [""]
    lines = [head + chunks[0]]
    pad = " " * len(head)
    lines.extend(pad + chunk for chunk in chunks[1:])
    return lines


def _section(number: int, title: str, width: int) -> List[str]:
    head = f"{number}. {title} "
    return [head + "-" * max(4, width - len(head))]


def _bullets(
    values: Iterable[Any], width: int, marker: str = "-", indent: int = 2
) -> List[str]:
    out: List[str] = []
    for value in values:
        out.extend(_wrap(f"{marker} {value}", width, indent=indent))
    return out or [" " * indent + "(none)"]


# ---------------------------------------------------------------------------
# value rendering (exact only -- spec 14.2)
# ---------------------------------------------------------------------------


def _exact_text(value: Any) -> str:
    """Render an exact scalar from either an object or its canonical form."""
    if value is None:
        return "(none)"
    if isinstance(value, Exact):
        return str(value)
    if isinstance(value, Mapping) and "exact" in value:
        return str(value["exact"])
    if isinstance(value, bool):
        return "yes" if value else "no"
    if isinstance(value, (int, str)):
        return str(value)
    to_canonical = getattr(value, "to_canonical", None)
    if callable(to_canonical):
        return _exact_text(to_canonical())
    return str(value)


def _interval_text(value: Any) -> str:
    """Render an interval as ``lo`` when degenerate and ``[lo, hi]`` otherwise."""
    if value is None:
        return "(none)"
    if isinstance(value, Interval):
        return _interval_text(value.to_canonical())
    if isinstance(value, Mapping) and "lo" in value and "hi" in value:
        lo, hi = _exact_text(value["lo"]), _exact_text(value["hi"])
        return lo if lo == hi else f"[{lo}, {hi}]"
    to_canonical = getattr(value, "to_canonical", None)
    if callable(to_canonical):
        return _interval_text(to_canonical())
    return _exact_text(value)


def _value_tag(record: Mapping[str, Any]) -> str:
    profile = str(record.get("arithmetic_profile", ArithmeticProfile.EXACT_RATIONAL))
    tag = _PROFILE_TAG.get(profile, profile)
    if record.get("evidence_interval") is not None:
        tag += "+EVIDENCE"
    return f"[{tag}]"


def _value_line(realization_id: str, record: Any, width: int, key: str) -> List[str]:
    """One objective value line, tagged with its evidence class."""
    if not isinstance(record, Mapping):
        return _kv(realization_id, _interval_text(record), width)
    unit = str(record.get("unit", "")) or "1"
    interval = _interval_text(record.get(key))
    if interval == "(none)":
        interval = _interval_text(record.get("combined_interval"))
    tag = _value_tag(record)
    return _kv(realization_id, f"{tag} {interval} {unit}", width)


# ---------------------------------------------------------------------------
# claim (spec 50.2 position 1)
# ---------------------------------------------------------------------------


def claim_sentence(certificate: DecisionCertificate) -> str:
    """Outcome and claim scope in one sentence, never apart (spec 21.5, 29.5)."""
    outcome = OUTCOME_PHRASE.get(certificate.outcome, certificate.outcome)
    scope = SCOPE_PHRASE.get(certificate.claim_scope, certificate.claim_scope)
    subject = ", ".join(certificate.selected) if certificate.selected else ""
    if subject:
        return f"{outcome}: {subject}, certified {scope}."
    return f"{outcome}, {scope}."


def _limitations(certificate: DecisionCertificate) -> List[str]:
    """Assemble position 21 from what the certificate itself records."""
    limits: List[str] = [SCOPE_LIMIT.get(certificate.claim_scope, certificate.claim_scope)]
    limits.append(
        "The completeness basis is "
        f"{certificate.completeness.basis_type}; the claim reaches no further than that basis."
    )
    if certificate.outcome not in _CERTIFYING_OUTCOMES:
        limits.append(
            f"Outcome {certificate.outcome} does not authorize a commitment; it records why "
            "the engine declined to certify one."
        )
    if not certificate.geometry_preserved:
        limits.append(
            "Geometry was NOT preserved by the retention: the retained registry no longer "
            "determines the object this decision class requires (spec 29.2 condition 7)."
        )
    for refusal in certificate.derivation.refusals:
        limits.append(f"Query refusal recorded at compile time: {refusal}")
    if certificate.infeasible:
        limits.append(
            f"{len(certificate.infeasible)} candidate(s) are infeasible and were excluded "
            "from comparison rather than ranked (spec 22.7)."
        )
    for omission in certificate.completeness.known_omissions:
        limits.append(f"Known omission: {omission}")
    return limits


# ---------------------------------------------------------------------------
# certificate report (spec 50.2)
# ---------------------------------------------------------------------------


def render_certificate(certificate: DecisionCertificate, *, width: int = 88) -> str:
    """Render ``certificate`` in the mandatory order of specification 50.2.

    The twenty-one positions of 50.2 appear as twenty-one numbered sections,
    in order, followed by an identity footer that repeats the hashes needed to
    re-verify the certificate.  The footer adds material; it does not reorder
    or replace any mandated position (spec 50.3).

    The output is pure ASCII and is a deterministic function of the
    certificate: no timestamps, no environment, no unordered iteration.
    """
    scope = certificate.scope
    derivation = certificate.derivation
    basis = certificate.completeness
    lines: List[str] = []

    lines.append(_rule("=", width))
    lines.append("CRG DECISION CERTIFICATE -- CANONICAL REPORT (spec 50)")
    lines.append(_rule("=", width))
    lines.extend(_kv("certificate id", certificate.certificate_id, width))
    lines.extend(_kv("outcome", certificate.outcome, width))
    lines.extend(_kv("claim scope", certificate.claim_scope, width))
    lines.extend(_kv("completeness basis", basis.basis_type, width))
    lines.append(_rule("=", width))
    lines.append("")

    # 1. Claim
    lines.extend(_section(1, "CLAIM", width))
    lines.extend(_wrap(claim_sentence(certificate), width, indent=2))
    lines.append("")

    # 2. Claim scope
    lines.extend(_section(2, "CLAIM SCOPE", width))
    lines.extend(_kv("claim scope", certificate.claim_scope, width))
    lines.extend(
        _wrap(SCOPE_PHRASE.get(certificate.claim_scope, certificate.claim_scope), width, indent=2)
    )
    lines.extend(_wrap(SCOPE_LIMIT.get(certificate.claim_scope, ""), width, indent=2))
    lines.append("")

    # 3. Completeness basis
    lines.extend(_section(3, "COMPLETENESS BASIS", width))
    lines.extend(_kv("basis type", basis.basis_type, width))
    lines.extend(_kv("declared universe", basis.declared_universe, width))
    lines.extend(_kv("source/generator hash", basis.source_or_generator_hash, width))
    lines.extend(_kv("generator versions", _join(basis.generator_versions), width))
    lines.extend(_kv("closure procedure", basis.closure_procedure, width))
    lines.extend(_kv("closure proof", basis.closure_proof, width))
    lines.extend(_kv("truncation rule", basis.truncation_rule, width))
    lines.extend(_kv("remainder bound", basis.remainder_bound, width))
    lines.extend(_kv("validity", basis.validity, width))
    lines.append("  known omissions:")
    lines.extend(_bullets(basis.known_omissions, width))
    lines.append("")

    # 4. Decision semantics
    lines.extend(_section(4, "DECISION SEMANTICS", width))
    lines.extend(_kv("decision scope id", scope.scope_id, width))
    lines.extend(_kv("observation level", scope.observation_level, width))
    lines.extend(_kv("objective family", _mapping_text(scope.objective_family), width))
    lines.extend(_kv("technology domain", _mapping_text(scope.technology_domain), width))
    lines.extend(_kv("retention policy", scope.retention_policy, width))
    lines.extend(_kv("retain all ties", "yes" if scope.retain_all_ties else "no", width))
    lines.extend(_kv("uncertainty mode", scope.uncertainty_mode, width))
    lines.append("  derivation record (query -> required object -> rule cited, spec 26):")
    lines.extend(_kv("query hash", derivation.query_hash, width, indent=4))
    lines.extend(_kv("mapping table version", derivation.mapping_table_version, width, indent=4))
    lines.extend(_kv("decision class", derivation.decision_class, width, indent=4))
    lines.extend(_kv("required object", derivation.required_object, width, indent=4))
    lines.extend(_kv("rule cited", derivation.rule_cited, width, indent=4))
    lines.append("    refusals:")
    lines.extend(_bullets(derivation.refusals, width, marker="!", indent=4))
    lines.append("    notes:")
    lines.extend(_bullets(derivation.notes, width, indent=4))
    lines.append("")

    # 5. Required retained object
    lines.extend(_section(5, "REQUIRED RETAINED OBJECT", width))
    lines.extend(_kv("required object", derivation.required_object, width))
    lines.extend(_kv("complete registry hash", certificate.complete_registry_hash, width))
    lines.extend(_kv("retained registry hash", certificate.retained_registry_hash, width))
    lines.append("")

    # 6. Selected, tied, or possible-winner realizations
    lines.extend(_section(6, "SELECTED, TIED, OR POSSIBLE-WINNER REALIZATIONS", width))
    lines.append("  selected:")
    lines.extend(_bullets(certificate.selected, width, marker="*"))
    lines.append("  ties (all retained under the declared tie policy, spec 22.4):")
    lines.extend(_bullets(certificate.ties, width, marker="="))
    lines.append("  infeasible (excluded from comparison, never ranked, spec 22.7):")
    lines.extend(
        _bullets(
            [f"{key}: {certificate.infeasible[key]}" for key in sorted(certificate.infeasible)],
            width,
            marker="x",
        )
    )
    lines.append("")

    # 7. Runner-up and margin
    lines.extend(_section(7, "RUNNER-UP AND MARGIN", width))
    lines.extend(_kv("runner-up", certificate.runner_up, width))
    lines.extend(_kv("margin", _interval_text(certificate.margin), width))
    lines.extend(
        _wrap(
            "The margin is the exact separation between the selected value and the runner-up "
            "value under the declared objective; a margin that straddles zero is not a "
            "strict separation (spec 22.3).",
            width,
            indent=2,
        )
    )
    lines.append("")

    # 8. Numerical enclosure
    lines.extend(_section(8, "NUMERICAL ENCLOSURE (objective values, spec 22.1(1))", width))
    lines.extend(_objective_block(certificate.objective_values, "numerical_interval", width))
    lines.append("")

    # 9. Evidence uncertainty
    lines.extend(_section(9, "EVIDENCE UNCERTAINTY (spec 22.1(2))", width))
    evidence_lines = _objective_block(
        certificate.objective_values, "evidence_interval", width, only_present=True
    )
    if evidence_lines:
        lines.extend(evidence_lines)
    else:
        lines.append("  (no evidence interval was declared on any objective value)")
    lines.append("  combined (conservative merge, recorded as a merge, spec 22.1):")
    lines.extend(_objective_block(certificate.objective_values, "combined_interval", width))
    lines.append("")

    # 10. Policy tolerance
    lines.extend(_section(10, "POLICY TOLERANCE (spec 22.1(3))", width))
    lines.extend(_kv("declared tie tolerance", _exact_text(scope.tie_tolerance), width))
    lines.extend(
        _wrap(
            "Policy tolerance is a decision rule, not an uncertainty: it is never merged into "
            "the enclosures above.",
            width,
            indent=2,
        )
    )
    lines.append("")

    # 11. Geometry basis
    lines.extend(_section(11, "GEOMETRY BASIS", width))
    lines.extend(
        _kv("geometry preserved", "yes" if certificate.geometry_preserved else "NO", width)
    )
    lines.extend(_kv("required object", derivation.required_object, width))
    lines.append("  active bottlenecks (coordinates attaining the decisive value):")
    lines.extend(_bullets(certificate.active_bottlenecks, width))
    lines.append("")

    # 12. Retained and pruned alternatives
    lines.extend(_section(12, "RETAINED AND PRUNED ALTERNATIVES", width))
    lines.append("  retained (evaluated candidates carried into this decision):")
    lines.extend(_bullets(sorted(certificate.dependencies), width, marker="+"))
    lines.append("  pruned (each with a pruning certificate, spec 29.3):")
    if certificate.pruning_certificates:
        for pruning in certificate.pruning_certificates:
            lines.extend(
                _wrap(
                    f"- {pruning.pruned_id}: lower bound "
                    f"{_interval_text(pruning.lower_bound)} is not below incumbent "
                    f"{pruning.incumbent_id} upper bound "
                    f"{_interval_text(pruning.incumbent_upper)}; scope {pruning.scope_id}; "
                    f"tie policy satisfied={_yesno(pruning.tie_policy_satisfied)}, "
                    f"geometry preserved={_yesno(pruning.geometry_preserved)}, "
                    f"dependencies valid={_yesno(pruning.dependencies_valid)}",
                    width,
                    indent=2,
                )
            )
    else:
        lines.append("  (none)")
    lines.append("")

    # 13. Regret witness
    lines.extend(_section(13, "REGRET WITNESS", width))
    witness = certificate.regret_witness
    if witness is None:
        lines.append("  (not applicable: no certified regret witness is attached)")
    else:
        lines.extend(_kv("lost point", _signature_text(witness.lost_point), width))
        lines.extend(_kv("objective family", witness.objective_family, width))
        lines.extend(_kv("construction", witness.construction, width))
        lines.extend(_kv("epsilon", _exact_text(witness.epsilon), width))
        lines.extend(_kv("retained infimum", _exact_text(witness.retained_infimum), width))
        lines.extend(_kv("full infimum", _exact_text(witness.full_infimum), width))
        lines.extend(_kv("gap", _exact_text(witness.gap), width))
        lines.extend(_kv("evidence class", witness.evidence_class, width))
        lines.extend(
            _wrap(
                "A positive gap is a constructive proof that the retention lost a decision "
                "that some admissible objective in this family would have made (spec 27).",
                width,
                indent=2,
            )
        )
    lines.append("")

    # 14. Evidence classes and lineage
    lines.extend(_section(14, "EVIDENCE CLASSES AND LINEAGE", width))
    lines.append("  evidence roots:")
    lines.extend(_bullets(certificate.evidence_roots, width))
    lines.append("  value tags in use (spec 5.3, 22.2):")
    for tag in sorted(_tags_used(certificate.objective_values)):
        lines.extend(_kv(tag, _TAG_MEANING.get(tag, "declared arithmetic profile"), width, 4))
    lines.append("")

    # 15. Solver trust profile
    lines.extend(_section(15, "SOLVER TRUST PROFILE (spec 23.2)", width))
    for profile in sorted(_profiles_used(certificate.objective_values)):
        lines.extend(_kv("solver trust", profile, width))
    if not _profiles_used(certificate.objective_values):
        lines.append("  (no objective value declared a solver trust profile)")
    lines.append("")

    # 16. Verification level
    lines.extend(_section(16, "VERIFICATION LEVEL", width))
    lines.extend(
        _kv(
            "achievable level",
            "INDEPENDENT_RECOMPUTATION"
            if _all_exact(certificate.objective_values)
            else "REPLAY_BOUND",
            width,
        )
    )
    lines.extend(
        _wrap(
            "Every value above is exact or interval-enclosed, so an independent verifier can "
            "recompute this decision from the referenced registries."
            if _all_exact(certificate.objective_values)
            else "At least one value is only replay-bound, so independent recomputation is "
            "limited to the recorded replay conditions (spec 23.5).",
            width,
            indent=2,
        )
    )
    lines.append("")

    # 17. Dependencies
    lines.extend(_section(17, "DEPENDENCIES", width))
    lines.extend(_bullets(sorted(certificate.dependencies), width))
    lines.append("")

    # 18. Validity and clock judgment
    lines.extend(_section(18, "VALIDITY AND CLOCK JUDGMENT (spec 45)", width))
    lines.extend(_kv("expiry", certificate.expiry, width))
    lines.extend(
        _wrap(
            "This report makes no clock judgment: expiry is compared against the verifier's "
            "own trusted time source at verification time, not at rendering time."
            if certificate.expiry
            else "No expiry was declared; validity is governed by the dependency and reopen "
            "conditions below.",
            width,
            indent=2,
        )
    )
    lines.append("")

    # 19. Reopen conditions
    lines.extend(_section(19, "REOPEN CONDITIONS", width))
    lines.extend(_bullets(certificate.reopen_conditions, width))
    lines.append("")

    # 20. Signatures
    lines.extend(_section(20, "SIGNATURES", width))
    lines.append("  (none attached to this certificate record)")
    lines.extend(
        _wrap(
            "Content hashes establish integrity, not authenticity. An unsigned certificate "
            "may be checked for self-consistency but attributes authorship to no one "
            "(spec 14.5).",
            width,
            indent=2,
        )
    )
    lines.append("")

    # 21. Limitations
    lines.extend(_section(21, "LIMITATIONS", width))
    lines.extend(_bullets(_limitations(certificate), width, marker="!"))
    lines.append("")

    lines.append(_rule("-", width))
    lines.append("IDENTITY, ENGINES, AND REGISTRY HASHES")
    lines.append(_rule("-", width))
    lines.extend(_kv("certificate hash", certificate.certificate_hash(), width))
    lines.extend(_kv("complete registry hash", certificate.complete_registry_hash, width))
    lines.extend(_kv("retained registry hash", certificate.retained_registry_hash, width))
    pins = certificate.semantic_pins.to_canonical()
    for label, key in (
        ("schema versions", "schema_versions"),
        ("quantity registry", "quantity_registry_version"),
        ("normative rule table", "normative_rule_table_version"),
        ("CRG-VIR", "crg_vir_version"),
        ("domain packs", "domain_pack_versions"),
        ("proof checkers", "proof_checker_versions"),
    ):
        value = pins[key]
        if isinstance(value, dict):
            value = ", ".join(f"{name}@{value[name]}" for name in sorted(value)) or "(none applicable)"
        lines.extend(_kv(label, value, width))
    for engine in sorted(certificate.engine_versions):
        lines.extend(_kv(engine, certificate.engine_versions[engine], width))
    lines.extend(_kv("renderer", f"{RENDERER_ID}@{RENDERER_VERSION}", width))
    lines.append(_rule("=", width))
    return "\n".join(lines) + "\n"


_TAG_MEANING: Dict[str, str] = {
    "[EXACT]": "derived exactly under the stated semantics; exact rational arithmetic",
    "[ENCLOSED]": "interval-enclosed; the true value lies within the printed interval",
    "[REPLAY-BOUND]": "valid only under the recorded replay conditions (spec 23.5)",
    "[UNCERTIFIED]": "unbounded floating point; MUST NOT authorize a certificate (spec 22.6)",
    "[EXACT+EVIDENCE]": "exact arithmetic carrying a separate declared evidence interval",
    "[ENCLOSED+EVIDENCE]": "interval-enclosed and carrying a declared evidence interval",
    "[REPLAY-BOUND+EVIDENCE]": "replay-bound and carrying a declared evidence interval",
    "[UNCERTIFIED+EVIDENCE]": "unbounded float carrying a declared evidence interval",
}


def _objective_block(
    values: Mapping[str, Any], key: str, width: int, only_present: bool = False
) -> List[str]:
    lines: List[str] = []
    for realization_id in sorted(values):
        record = values[realization_id]
        if only_present and (
            not isinstance(record, Mapping) or record.get(key) is None
        ):
            continue
        lines.extend(_value_line(realization_id, record, width, key))
    if not lines and not only_present:
        lines.append("  (no objective values were recorded)")
    return lines


def _tags_used(values: Mapping[str, Any]) -> List[str]:
    return sorted(
        {_value_tag(record) for record in values.values() if isinstance(record, Mapping)}
    )


def _profiles_used(values: Mapping[str, Any]) -> List[str]:
    return sorted(
        {
            str(record.get("solver_trust_profile"))
            for record in values.values()
            if isinstance(record, Mapping) and record.get("solver_trust_profile")
        }
    )


def _all_exact(values: Mapping[str, Any]) -> bool:
    for record in values.values():
        if not isinstance(record, Mapping):
            continue
        if record.get("arithmetic_profile") not in ArithmeticProfile.CERTIFYING:
            return False
    return True


def _signature_text(signature: Any) -> str:
    canonical = signature.to_canonical() if hasattr(signature, "to_canonical") else signature
    if isinstance(canonical, (list, tuple)):
        return "(" + ", ".join(_exact_text(v) for v in canonical) + ")"
    return _exact_text(canonical)


def _mapping_text(mapping: Optional[Mapping[str, Any]]) -> str:
    if not mapping:
        return "(none)"
    parts = []
    for key in sorted(mapping):
        parts.append(f"{key}={_scalar_text(mapping[key])}")
    return "; ".join(parts)


def _scalar_text(value: Any) -> str:
    if isinstance(value, Mapping):
        return "{" + _mapping_text(value) + "}"
    if isinstance(value, (list, tuple)):
        return "[" + ", ".join(_scalar_text(v) for v in value) + "]"
    return _exact_text(value)


def _join(values: Optional[Sequence[str]]) -> str:
    return ", ".join(values) if values else "(none)"


def _yesno(value: Any) -> str:
    return "yes" if value else "no"


# ---------------------------------------------------------------------------
# delta certificate report (spec 30.5, rendered under the 50 discipline)
# ---------------------------------------------------------------------------


def render_delta(delta: DeltaCertificate, *, width: int = 88) -> str:
    """Render a delta certificate deterministically (spec 30.5).

    The order mirrors section 50: what changed and how it was classified come
    before any statement about winners, so a reader cannot mistake a repriced
    result for an unchanged one.
    """
    event = delta.change_event
    lines: List[str] = []
    lines.append(_rule("=", width))
    lines.append("CRG DELTA CERTIFICATE -- CANONICAL REPORT (spec 30.5)")
    lines.append(_rule("=", width))
    lines.extend(_kv("delta id", delta.delta_id, width))
    lines.extend(_kv("classification", delta.classification, width))
    lines.append(_rule("=", width))
    lines.append("")

    lines.extend(_section(1, "CHANGE EVENT", width))
    lines.extend(_kv("event id", event.event_id, width))
    lines.extend(_kv("changed object", event.changed_object, width))
    lines.extend(_kv("previous version", event.previous_version, width))
    lines.extend(_kv("current version", event.current_version, width))
    lines.extend(_kv("declared reason", event.declared_reason, width))
    lines.extend(_kv("authority", event.authority, width))
    lines.extend(_kv("timestamp", event.timestamp, width))
    lines.append("  changed properties:")
    lines.extend(_bullets(sorted(event.changed_properties), width))
    lines.append("")

    lines.extend(_section(2, "CLASSIFICATION AND ROOTS", width))
    lines.extend(_kv("classification", delta.classification, width))
    lines.extend(_kv("prior root", delta.prior_root, width))
    lines.extend(_kv("current root", delta.current_root, width))
    lines.append("")

    lines.extend(_section(3, "AFFECTED, PRESERVED, INVALIDATED, RECOMPUTED", width))
    lines.append("  affected paths:")
    lines.extend(_bullets(sorted(delta.affected_paths), width))
    lines.append("  preserved (outside the affected subgraph, spec 30):")
    lines.extend(_bullets(sorted(delta.preserved), width, marker="+"))
    lines.append("  invalidated:")
    lines.extend(_bullets(sorted(delta.invalidated), width, marker="x"))
    lines.append("  recomputed:")
    lines.extend(_bullets(sorted(delta.recomputed), width, marker="*"))
    lines.append("")

    lines.extend(_section(4, "DECISION EFFECT", width))
    lines.append("  prior winners:")
    lines.extend(_bullets(sorted(delta.prior_winners), width))
    lines.append("  current winners:")
    lines.extend(_bullets(sorted(delta.current_winners), width))
    lines.extend(_kv("prior margin", _interval_text(delta.prior_margin), width))
    lines.extend(_kv("current margin", _interval_text(delta.current_margin), width))
    changed = sorted(delta.prior_winners) != sorted(delta.current_winners)
    lines.extend(
        _wrap(
            "THE DECIDED OUTCOME CHANGED." if changed else "The decided outcome is unchanged.",
            width,
            indent=2,
        )
    )
    lines.append("")

    lines.extend(_section(5, "RESIDUAL UNCERTAINTY, APPROVALS, AND REOPEN", width))
    lines.extend(_kv("residual uncertainty", delta.residual_uncertainty, width))
    lines.append("  approvals:")
    lines.extend(_bullets(sorted(delta.approvals), width))
    lines.extend(_kv("reopen reason", delta.reopen_reason, width))
    lines.append("")

    lines.append(_rule("-", width))
    lines.extend(_kv("delta hash", delta.delta_hash(), width))
    lines.extend(_kv("renderer", f"{RENDERER_ID}@{RENDERER_VERSION}", width))
    lines.append(_rule("=", width))
    return "\n".join(lines) + "\n"
