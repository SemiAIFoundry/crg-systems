"""Kernel operations behind the endpoints, as job bodies and pure functions.

Normative basis: 38.1 (import -> augment -> certify -> verify -> export),
38.3 (principal endpoints), 42.4 (job semantics), 18 (typed dependency
graph), 21 (claim scope), 29 (safe commitment), 30 (change), 31 (conversion),
33--35 (ETQ), 6.6 (fail closed).

Nothing here decides anything.  Every operation is a thin, typed adapter over
a module that already owns the semantics -- ``crg_generate``,
``crg_geometry``, ``crg_certify``, ``crg_change``, ``crg_convert``,
``etq_evidence``, ``etq_federation`` -- and the adapter's whole job is to turn
a JSON request into the kernel's own types and the kernel's own objects back
into canonical JSON.  Re-deriving a comparison, a claim scope, or a
completeness basis at this layer would produce a second opinion, and 6.9
forbids a second semantics.

Two properties are contributed by this layer rather than inherited.

**Typed dependency edges are emitted at the moment of production (18.2).**  A
certificate is registered together with the edges from the objects it
actually consumed, with the edge *types* 18.3 names.  Recovering those edges
later by inspecting a finished certificate would be guesswork, and 18.1 says
a generic untyped ``depends_on`` cannot authorize anything.

**Secrets never reach a job record (44.4).**  A request that carries signing
material is canonicalized for the job's ``canonical_inputs`` with the secret
replaced by its profile and key identifier, so the reproducibility record of
42.4 does not become a key disclosure.
"""
from __future__ import annotations

import copy
import json
import os
import tempfile
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

import crg_certify
import crg_generate
import crg_geometry
import crg_verify
from crg_model.case import validate_case_metadata
from crg_change import apply_change
from crg_model.canonical import canonical_json, content_hash
from crg_model.completeness import CompletenessBasisType
from crg_model.edges import DependencyEdge, DependencyGraph, EdgeType
from crg_model.envelope import EvidenceClass, utc_now
from crg_model.lifecycle import (
    PREPARATION_STATES,
    CaseState,
    LifecycleError,
    case_state,
    is_legal_transition,
    set_case_state,
)
from crg_model.migration import DEFAULT_MIGRATION_REGISTRY, MigrationError
from crg_model.numeric import Exact
from crg_model.records import ChangeEvent, DecisionOutcome, Signature

from .errors import BlockedOutcome, ConflictError, NotFoundError, ScopeMismatchError, UsageError
from .jobs import JobContext, JobResult
from .store import (
    CaseError,
    import_table,
    load_bundle,
    load_derivation,
    load_scope,
    record_history,
)
from .typed import decode, decode_exact, encode

__all__ = [
    "AFFIRMATIVE_OUTCOMES",
    "SECRET_KEYS",
    "redact_secrets",
    "case_dependency_graph",
    "dependency_view",
    "op_validate",
    "op_import",
    "op_generate",
    "op_geometry",
    "op_compile",
    "op_commitment_preview",
    "op_commitment_compare",
    "op_certify",
    "op_change",
    "op_recompute",
    "op_convert",
    "op_evaluate",
    "op_migrate",
    "op_evidence",
    "op_technology_contract",
    "op_capability_envelope",
    "op_private_evaluation",
    "op_qualification_plan",
    "op_evaluator_request",
    "vir_for",
]

#: Specification 29.5 read through 6.6: these outcomes and no others are an
#: affirmative certification.  Everything else is a refusal, and a refusal
#: leaves this process as a 4xx rather than as a 200 with a sad field in it.
AFFIRMATIVE_OUTCOMES = frozenset(
    {
        DecisionOutcome.CERTIFIED_WINNER,
        DecisionOutcome.CERTIFIED_WINNER_SET,
        DecisionOutcome.CERTIFIED_POLICY_TIE,
        DecisionOutcome.CERTIFIED_RETENTION,
    }
)

#: Keys whose values are signing or encryption material (spec 44.4).
SECRET_KEYS = frozenset({"secret", "private_key", "signing_secret", "password", "token"})

_REDACTED = "[redacted: 44.4 forbids secrets in logs and exports]"


def redact_secrets(value: Any) -> Any:
    """Copy ``value`` with signing material removed (spec 44.4).

    Applied to everything that becomes a job's ``canonical_inputs`` or an
    audit event.  42.4 wants the inputs recorded for reproducibility; 44.4
    says secrets MUST NOT appear in logs or exports without explicit
    authorization.  Both hold: the record keeps the key *identity* and
    *profile*, which is what a reproducer needs, and drops the bytes.
    """
    if isinstance(value, Mapping):
        return {
            str(k): (_REDACTED if str(k) in SECRET_KEYS else redact_secrets(v))
            for k, v in value.items()
        }
    if isinstance(value, (list, tuple)):
        return [redact_secrets(v) for v in value]
    return value


# ---------------------------------------------------------------------------
# case lifecycle (spec 11.2)
# ---------------------------------------------------------------------------
# Every status change below goes through one of these three helpers.  Before
# they existed each operation wrote ``case["status"] = ...`` directly, which
# meant the lifecycle of 11.2 was a diagram in the specification and nothing
# in the code.  ``crg_model.lifecycle`` owns the legal transitions; this layer
# only decides which transition an operation is asking for, and turns an
# illegal one into a 409 rather than a traceback.
def _advance(
    case: Dict[str, Any], target: str, *, reason: str, actor: str = "crg-server"
) -> str:
    """Move the case to ``target``, or refuse with 409 (spec 11.2, 6.6)."""
    try:
        return set_case_state(case, target, reason=reason, actor=actor)
    except LifecycleError as error:
        raise ConflictError(
            f"case {case.get('case_id')!r} cannot move from {error.current} to "
            f"{error.target}: {error}",
            remedy=(
                "11.2 declares the case lifecycle; run the step that reaches the required "
                "state first, or reopen the case if it has already certified"
            ),
            detail={"from_state": error.current, "to_state": error.target},
        ) from None


def _advance_preparation(
    case: Dict[str, Any], target: str, *, reason: str, actor: str = "crg-server"
) -> str:
    """Advance a preparation-phase status, leaving a settled case alone.

    Importing, generating, building geometry, compiling a query, and
    evaluating a family are all *preparation*: they add objects to a case that
    has not yet made a claim.  Two consequences follow, and both are the
    reason this helper is not simply :func:`_advance`.

    A case that has already certified is not dragged backwards by a geometry
    rebuild.  11.2 routes a certified case out of ``CERTIFIED`` through
    ``STALE`` and ``REOPENED``, driven by a declared change event, precisely so
    that the reason the claim stopped holding is on the record (30.5); a
    geometry build is not such a reason and must not silently act like one.

    And a case that has not yet reached the point a step names does not jump
    there.  Compiling a query against a case with no imported family leaves
    the case where it is: the query compiled, but the case is not
    ``EVALUATED``, and saying otherwise would be a claim about a family that
    does not exist.
    """
    current = case_state(case)
    if current not in PREPARATION_STATES:
        return current
    if not is_legal_transition(current, target):
        return current
    return _advance(case, target, reason=reason, actor=actor)


def _stale_then_reopen(
    case: Dict[str, Any], *, reason: str, actor: str = "crg-server"
) -> str:
    """Reopen a case by the declared route (spec 11.2).

    11.2 draws no arrow from ``CERTIFIED`` straight to ``REOPENED`` for a case
    whose claim has just been invalidated: it goes ``CERTIFIED -> STALE ->
    REOPENED``, and both legs are recorded.  An earlier revision jumped
    straight to ``REOPENED``, which lost the fact that the case was stale at
    all -- and "this claim stopped holding" is a different statement from
    "someone reopened this case".
    """
    current = case_state(case)
    if current in (CaseState.CERTIFIED, CaseState.COMMITTED):
        _advance(case, CaseState.STALE, reason=reason, actor=actor)
    if case_state(case) == CaseState.STALE:
        return _advance(case, CaseState.REOPENED, reason=reason, actor=actor)
    if is_legal_transition(case_state(case), CaseState.REOPENED):
        return _advance(case, CaseState.REOPENED, reason=reason, actor=actor)
    return case_state(case)


# ---------------------------------------------------------------------------
# shared case helpers -- the CLI's canonical forms, reused rather than restated
# ---------------------------------------------------------------------------
def _points(signatures: Sequence[Any]) -> List[List[dict]]:
    return [[v.to_canonical() for v in s.values] for s in signatures]


def _normalize_registry(case: Dict[str, Any]) -> None:
    """Store the registry in exactly the canonical form its hash covers (14.3).

    ``RealizationBundle.to_canonical`` omits empty optional members, so a
    registry kept in any other shape would hash differently from the bundle a
    certificate names, and an independent verifier would correctly report a
    missing dependency.
    """
    if case.get("registry"):
        case["registry"] = load_bundle(case).to_canonical()


def _registry_hash(case: Mapping[str, Any]) -> Optional[str]:
    registry = case.get("registry")
    return content_hash(registry) if registry else None


def _store_certificate(case: Dict[str, Any], certificate: Any) -> Dict[str, Any]:
    """Attach issuance time and the covering hash (spec 45.2, 14.4).

    The issuance time is an assertion of the issuer and part of the record, so
    it lives inside the hash preimage; a hash taken before the timestamp was
    attached would leave the timestamp unbound and freely editable.  The
    engine's own hash over the kernel canonical form is kept alongside so the
    two views stay traceable.  This mirrors ``crg_cli.main._store_certificate``
    exactly, because a certificate issued by the server and one issued by the
    CLI must be the same object.
    """
    canonical = certificate.to_canonical()
    canonical["engine_certificate_hash"] = certificate.certificate_hash()
    canonical["issued_at"] = utc_now()
    canonical["issuer_clock_source"] = "issuer-system-clock"
    if not canonical.get("expiry") and (case.get("scope") or {}).get("validity"):
        canonical["expiry"] = case["scope"]["validity"]
    canonical["certificate_hash"] = content_hash(canonical)
    case.setdefault("certificates", {})[certificate.certificate_id] = canonical
    return canonical


def _case_objects(case: Mapping[str, Any]) -> Dict[str, Any]:
    """Project a case into the typed objects a change propagates through (18).

    The price vector is a separate object from the decision scope.  That
    separation is what lets 30.2 distinguish a ``REPRICE`` from a ``REOPEN``:
    with the weights inside the scope, every tariff update would also read as
    a scope change and escalate.
    """
    scope = dict(case.get("scope") or {})
    family = dict(scope.pop("objective_family", None) or {})
    weights = family.pop("weights", None)
    family.pop("weights_are_ranges", None)
    scope["objective_family"] = family
    return {
        "candidate-registry": {
            "object_kind": "CANDIDATE_REGISTRY",
            "registry": case.get("registry"),
        },
        "price-model": {"object_kind": "PRICE_MODEL", "price": {"weights": weights}},
        "decision-scope": {"object_kind": "DECISION_SCOPE", "scope": scope},
    }


def _case_view(case: Mapping[str, Any]) -> Dict[str, Any]:
    return {
        "objects": _case_objects(case),
        "certificates": dict(case.get("certificates") or {}),
    }


def case_dependency_graph(certificate_ids: Sequence[str]) -> DependencyGraph:
    """The typed edges from a case's objects to its certificates (18.3)."""
    graph = DependencyGraph()
    for index, cert_id in enumerate(sorted(certificate_ids)):
        for source, edge_type in (
            ("price-model", EdgeType.DEPENDS_ON_PRICE_OF),
            ("candidate-registry", EdgeType.DEPENDS_ON_MEMBERSHIP_OF),
            ("decision-scope", EdgeType.DEPENDS_ON_SCOPE_OF),
        ):
            graph.add_edge(
                DependencyEdge(
                    edge_id=f"{source}->{cert_id}#{index}",
                    source=source,
                    target=cert_id,
                    edge_type=edge_type,
                )
            )
    return graph


def _certificate_edges(
    case: Mapping[str, Any], certificate_hash: str, certificate_id: str
) -> List[DependencyEdge]:
    """Content-hash edges from the objects a certificate consumed (18.2).

    ``DEPENDS_ON_MEMBERSHIP_OF`` because the claim is over a family and
    membership changes reopen it (18.3); ``DEPENDS_ON_ACCESS`` because the
    same registry is the *supporting content*, and 18.3's trigger for that
    edge is exactly "supporting content becomes unavailable or redacted", with
    minimum action "mark unverifiable or block".  Both are recorded because
    they fire on different events and 17.3 depends on the second one.
    """
    edges: List[DependencyEdge] = []
    registry_hash = _registry_hash(case)
    if registry_hash:
        for edge_type in (EdgeType.DEPENDS_ON_MEMBERSHIP_OF, EdgeType.DEPENDS_ON_ACCESS):
            edges.append(
                DependencyEdge(
                    edge_id=f"{registry_hash}->{certificate_hash}#{edge_type}",
                    source=registry_hash,
                    target=certificate_hash,
                    edge_type=edge_type,
                    scope=certificate_id,
                )
            )
    for name in ("R", "GAMMA", "K"):
        record = (case.get("geometry") or {}).get(name)
        if isinstance(record, Mapping) and record.get("root_hash"):
            edges.append(
                DependencyEdge(
                    edge_id=f"{record['root_hash']}->{certificate_hash}#geometry-{name}",
                    source=str(record["root_hash"]),
                    target=certificate_hash,
                    edge_type=EdgeType.DERIVES_VALUE_FROM,
                    scope=f"geometry.{name}",
                )
            )
    return edges


def dependency_view(store: Any, case: Mapping[str, Any]) -> Dict[str, Any]:
    """The typed dependency graph of a case (spec 18, endpoint 38.3)."""
    case_id = str(case.get("case_id") or "")
    logical = case_dependency_graph(sorted(case.get("certificates") or {}))
    edges = [
        edge.to_canonical()
        for node in sorted(logical.nodes)
        for edge in sorted(logical.edges_from(node), key=lambda e: e.edge_id)
    ]
    return {
        "case_id": case_id,
        "logical_edges": edges,
        "acyclicity_checked": logical.find_cycle() is None,
        "content_edges": store.edges_for(case_id),
        "registry_hash": _registry_hash(case),
        "geometry_roots": {
            name: (case.get("geometry") or {}).get(name, {}).get("root_hash")
            for name in ("R", "GAMMA", "K")
            if isinstance((case.get("geometry") or {}).get(name), Mapping)
        },
        "certificates": sorted(case.get("certificates") or {}),
        "superseded_certificates": sorted(case.get("superseded_certificates") or {}),
    }


def vir_for(case: Mapping[str, Any], certificate: Mapping[str, Any]) -> dict:
    """Emit the CRG-VIR program an independent verifier reads (spec 24.5)."""
    geometry = case.get("geometry") or {}
    return crg_verify.emit_vir(
        certificate,
        {"full": geometry.get("full_frontier"), "retained": geometry.get("retained_frontier")},
        case.get("registry"),
    )


# ---------------------------------------------------------------------------
# synchronous operations
# ---------------------------------------------------------------------------
def op_validate(case: Mapping[str, Any]) -> Dict[str, Any]:
    """Structural validation of a case (endpoint ``POST /cases/{id}/validate``).

    Cheap and total, so it is not a job: 38.3 requires an identifier for
    *long-running* actions, and forcing a poll for a check that is a schema
    walk would be ceremony without a property.
    """
    problems: List[str] = []
    if not case.get("registry"):
        problems.append("no registry imported")
    else:
        try:
            bundle = load_bundle(case)
            dimension = bundle.schema.dimension
            for realization in bundle.realizations:
                if len(realization.signature) != dimension:
                    problems.append(
                        f"{realization.realization_id}: {len(realization.signature)} "
                        f"coordinates against a schema of {dimension}"
                    )
        except (CaseError, ValueError) as error:
            problems.append(str(error))
    problems.extend(validate_case_metadata(case))
    return {
        "case_id": case.get("case_id"),
        "valid": not problems,
        "problems": problems,
        "realizations": len((case.get("registry") or {}).get("realizations") or []),
    }


def op_compile(case: Dict[str, Any], document: Any) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """Compile a decision query to its minimum sufficient object (spec 26).

    A compilation that produced refusals is not a compiled query: 26.6 makes
    the refusal the answer, and returning it under a success status would let
    a caller proceed to certify against a scope the compiler declined.
    """
    try:
        scope, derivation = crg_certify.compile_query(document)
    except crg_certify.QueryError as error:
        raise ScopeMismatchError(
            f"the decision query does not compile: {error}",
            remedy="26.2 lists the required query fields; supply the missing or conflicting one",
        ) from None
    case["scope"] = {**scope.to_canonical(), "validity": scope.validity}
    case["derivation"] = derivation.to_canonical()
    _advance_preparation(
        case, CaseState.EVALUATED, reason=f"decision query compiled to scope {scope.scope_id}"
    )
    record_history(case, "query compile", {"scope_id": scope.scope_id})
    payload = {
        "scope_id": scope.scope_id,
        "decision_class": derivation.decision_class,
        "required_object": derivation.required_object,
        "rule_cited": derivation.rule_cited,
        "refusals": list(derivation.refusals),
        "retention_policy": scope.retention_policy,
        "query_hash": derivation.query_hash,
        "mapping_table_version": derivation.mapping_table_version,
    }
    if derivation.refusals:
        raise ScopeMismatchError(
            "the soundness compiler refused this query",
            remedy="26.6: a refusal is the answer; narrow the claim or supply the missing object",
            detail=payload,
        )
    return case, payload


# ---------------------------------------------------------------------------
# job bodies
# ---------------------------------------------------------------------------
def op_import(context: JobContext) -> JobResult:
    """Import a candidate registry (spec 37, endpoint ``/cases/{id}/import``).

    21.2: an imported family is ``EXPLICIT_IMPORTED_FAMILY`` and nothing
    stronger, whatever the caller asserts about it.  A stronger basis has to
    be *derived* from a closure procedure (see :func:`op_generate`), so the
    request may name a weaker basis but may not promote itself.
    """
    request = dict(context.inputs.get("request") or {})
    case = dict(context.inputs["case"])
    rows = request.get("rows")
    source_path = request.get("source_path")
    basis = str(request.get("completeness_basis") or CompletenessBasisType.EXPLICIT_IMPORTED_FAMILY)
    # 21.2 read as a ceiling, not a menu.  An importer may declare a basis
    # that is no stronger than what importing a list actually establishes, so
    # it may say "these candidates" or something weaker still; it may not say
    # GENERATOR_CLOSED or EXHAUSTIVE_DECLARED_UNIVERSE, because those are
    # *derived* from a closure procedure (21.3, 28.3) and no assertion by the
    # caller can supply one.
    importable = {
        CompletenessBasisType.EXPLICIT_IMPORTED_FAMILY,
        CompletenessBasisType.BOUNDED_UNENUMERATED_FAMILY,
        CompletenessBasisType.KNOWN_INCOMPLETE,
        CompletenessBasisType.UNKNOWN,
    }
    if basis not in importable:
        raise UsageError(
            f"an import may not declare the basis {basis!r}",
            remedy=(
                "21.2--21.3: an imported family is EXPLICIT_IMPORTED_FAMILY or weaker; a "
                "generator-closed or exhaustive basis must be derived by generation, not "
                f"asserted by the importer.  Accepted here: {sorted(importable)}"
            ),
        )
    temporary: Optional[str] = None
    try:
        if source_path:
            path = str(source_path)
        elif rows is not None:
            handle, temporary = tempfile.mkstemp(suffix=".json")
            with os.fdopen(handle, "w", encoding="utf-8") as stream:
                json.dump({"realizations": rows, "schema": request.get("schema")}, stream)
            path = temporary
        else:
            raise UsageError(
                "an import must supply rows or a source_path",
                remedy="POST {'rows': [...]} or {'source_path': '...'}",
            )
        registry, report = import_table(
            path,
            request.get("mapping"),
            basis_type=basis,
            declared_universe=str(
                request.get("declared_universe") or "the explicitly imported candidates"
            ),
            bundle_id=str(request.get("bundle_id") or f"bundle-{case['case_id']}"),
        )
    finally:
        if temporary and os.path.exists(temporary):
            os.remove(temporary)

    case["registry"] = registry
    _normalize_registry(case)
    case["import_report"] = report
    # 11.2 names the node after import ``IMPORTED_OR_GENERATED``, and the
    # import profile of 37 validates every row before accepting it, so an
    # import walks both declared legs -- ``VALIDATED`` then
    # ``IMPORTED_OR_GENERATED`` -- and records each.  An earlier revision
    # stopped at ``VALIDATED``, which left an imported case permanently one
    # step short of the state 11.2 says an import reaches.
    _advance_preparation(
        case, CaseState.VALIDATED, reason=f"registry import validated {report['accepted']} rows"
    )
    _advance_preparation(
        case,
        CaseState.IMPORTED_OR_GENERATED,
        reason=f"registry imported from {report['source']}",
    )
    record_history(case, "import", {"source": report["source"], "accepted": report["accepted"]})
    context.log(f"imported {report['accepted']} realizations, rejected {report['rejected']}")

    events: List[Dict[str, Any]] = [
        {"event": "registry.imported", "detail": {"accepted": report["accepted"],
                                                  "rejected": report["rejected"]}}
    ]
    if report["rejected"]:
        # 6.11: no silent truncation.  Every refused row is announced.
        events.append(
            {"event": "realization.rejected",
             "detail": {"count": report["rejected"], "rejections": report["rejections"]}}
        )
    return JobResult(
        outputs={"import_report": report, "registry_hash": _registry_hash(case)},
        objects=[("registry", case["registry"])],
        case=case,
        events=events,
    )


def op_generate(context: JobContext) -> JobResult:
    """Generate a legal realization family (spec 28, 36.5).

    The completeness basis is *derived from what generation did* (21.3, 28.3
    step 10) and never taken from the request.  A generator profile the server
    does not implement fails the job with ``UNSUPPORTED_PROFILE`` rather than
    falling back to a nearby generator: 28.4 keeps ``UNGENERATED`` and
    ``INFEASIBLE`` apart, and a substituted generator would silently answer a
    different question.
    """
    request = dict(context.inputs.get("request") or {})
    case = dict(context.inputs["case"])
    profile = str(request.get("generator") or "")
    schema_spec = request.get("schema") or (case.get("registry") or {}).get("schema")
    if not schema_spec:
        raise UsageError(
            "generation needs a coordinate schema",
            remedy="supply 'schema', or import a registry first so the case carries one",
        )
    schema = _schema_from_json(schema_spec)
    parameters = dict(request.get("parameters") or {})
    context_object = crg_generate.GenerationContext(
        schema=schema,
        capabilities=dict(request.get("capabilities") or {}),
        parameters=parameters,
        declared_universe=str(
            request.get("declared_universe") or "the closure of the declared generator set"
        ),
    )

    if profile == "finite_transformation":
        coordinates = [c.identifier for c in schema.coordinates]
        if len(coordinates) < 2:
            raise UsageError(
                "the finite-transformation reference generator needs two coordinates",
                remedy="declare a primary and a secondary coordinate in the schema",
            )
        generator = crg_generate.finite_transformation_generator(
            primary=str(request.get("primary") or coordinates[0]),
            secondary=str(request.get("secondary") or coordinates[1]),
            replica_limit=int(request.get("replica_limit", 2)),
        )
        seeds = tuple(
            crg_generate.seed_record(
                source_id=str(request.get("source_id") or "server-source"),
                signature=Signature(
                    [decode_exact(v, where="seed.signature") for v in seed["signature"]]
                ),
                attributes=dict(seed.get("attributes") or {}),
                evidence_class=str(seed.get("evidence_class") or EvidenceClass.CONSTRUCTIVE),
            )
            for seed in (request.get("seeds") or ())
        )
    elif profile == "placement":
        generator = crg_generate.placement_generator()
        seeds = tuple(
            crg_generate.placement_seed(dict(seed), context_object)
            for seed in (request.get("seeds") or ())
        )
    else:
        raise UsageError(
            f"no generator profile {profile!r} is registered on this deployment",
            remedy=(
                "declare 'generator' as one of ['finite_transformation', 'placement']; "
                "28.4 forbids substituting a different generator for an absent one"
            ),
            detail={"failure_category": "UNSUPPORTED_PROFILE"},
        )
    if not seeds:
        raise UsageError("generation needs at least one seed record (28.3)")

    source = crg_generate.GenerationSource(
        source_id=str(request.get("source_id") or "server-source"),
        source_type=str(request.get("source_type") or "EXPLICIT_RECORDS"),
        seeds=seeds,
        computation_contract=dict(request.get("computation_contract") or {"contract_id": "cc",
                                                                          "version": "1"}),
        resource_contract=dict(request.get("resource_contract") or {}),
        declared_universe=context_object.declared_universe,
        declared_universe_size=request.get("declared_universe_size"),
        universe_key=request.get("universe_key"),
    )
    bundle, report = crg_generate.build_registry(
        source,
        generators=(generator,),
        schema=schema,
        context=context_object,
        max_depth=request.get("max_depth"),
        max_size=request.get("max_size"),
    )
    case["registry"] = bundle.to_canonical()
    case["generation_report"] = encode(report)
    # 28.3 steps 2-3 validate the computation and resource contracts before
    # any candidate is proposed, so generation, like import, passes through
    # VALIDATED on its way to IMPORTED_OR_GENERATED.
    _advance_preparation(case, CaseState.VALIDATED, reason=f"generation source validated ({profile})")
    _advance_preparation(
        case,
        CaseState.IMPORTED_OR_GENERATED,
        reason=f"generated {len(bundle.realizations)} realizations with {profile}",
    )
    record_history(
        case, "generate", {"generator": profile, "realizations": len(bundle.realizations)}
    )
    context.log(
        f"generated {len(bundle.realizations)} realizations; basis "
        f"{bundle.completeness.basis_type}"
    )
    events: List[Dict[str, Any]] = [
        {
            "event": "realization.generated",
            "detail": {
                "realizations": len(bundle.realizations),
                "completeness_basis": bundle.completeness.basis_type,
                "claim_scope": report.claim_scope,
            },
        }
    ]
    if getattr(report, "rejected", ()):  # 28.6, 6.11
        events.append(
            {"event": "realization.rejected", "detail": {"count": len(report.rejected)}}
        )
    return JobResult(
        outputs={
            "realizations": len(bundle.realizations),
            "completeness_basis": bundle.completeness.basis_type,
            "claim_scope": report.claim_scope,
            "registry_hash": _registry_hash(case),
        },
        objects=[("registry", case["registry"])],
        case=case,
        events=events,
    )


def _schema_from_json(payload: Mapping[str, Any]):
    from crg_model.records import Coordinate, CoordinateSchema, Direction

    return CoordinateSchema(
        coordinates=tuple(
            Coordinate(
                identifier=str(c["identifier"]),
                quantity=str(c.get("quantity", c["identifier"])),
                unit=str(c.get("unit", "1")),
                direction=str(c.get("direction", Direction.MINIMIZE)),
                accounting_scope=c.get("accounting_scope"),
            )
            for c in payload.get("coordinates", [])
        ),
        technology_context=payload.get("technology_context"),
    )


def _commitment_family(case: Mapping[str, Any], request: Mapping[str, Any]):
    """Compile server authoring input; never trust a supplied derivation."""
    raw_family = request.get("family")
    requested_id = str(request.get("family_id") or "").strip()
    if raw_family is None:
        scope = load_scope(dict(case))
        derivation = load_derivation(dict(case))
        family_id = requested_id or f"future-{scope.scope_id}"
        return crg_certify.FutureDecisionFamily(
            family_id,
            (crg_certify.FutureDecision(scope.scope_id, scope, derivation),),
            scenario_scope={"case_id": case["case_id"], "source": "compiled-case-scope"},
            authority="CRG registered decision-query mapping",
            validity=scope.validity,
        )
    if not isinstance(raw_family, Mapping):
        raise UsageError("family must be an object")
    raw_decisions = raw_family.get("decisions")
    if not isinstance(raw_decisions, list) or not raw_decisions:
        raise UsageError("family.decisions must be a non-empty array")
    decisions = []
    for index, item in enumerate(raw_decisions):
        if not isinstance(item, Mapping) or not isinstance(item.get("query"), Mapping):
            raise UsageError(
                f"family decision {index} must carry a query object; "
                "caller-supplied derivations are not accepted"
            )
        decision_id = str(item.get("decision_id") or item["query"].get("id") or "").strip()
        if not decision_id:
            raise UsageError(f"family decision {index} has no decision_id")
        document = dict(item["query"])
        document.setdefault("id", decision_id)
        scope, derivation = crg_certify.compile_query(document)
        if derivation.refusals:
            raise ScopeMismatchError(
                f"future decision {decision_id!r} was refused by the soundness compiler",
                remedy="narrow the claim or supply the registered minimum sufficient object",
                detail={"decision_id": decision_id, "refusals": list(derivation.refusals)},
            )
        decisions.append(crg_certify.FutureDecision(decision_id, scope, derivation))
    family_id = str(requested_id or raw_family.get("family_id") or "").strip()
    if not family_id:
        raise UsageError("family_id is required")
    return crg_certify.FutureDecisionFamily(
        family_id,
        tuple(decisions),
        scenario_scope=dict(raw_family.get("scenario_scope") or {}),
        authority=raw_family.get("authority"),
        validity=raw_family.get("validity"),
    )


def _commitment_policies(request: Mapping[str, Any], family_id: str):
    raw_policies = request.get("policies")
    if not isinstance(raw_policies, list) or not raw_policies:
        raise UsageError("policies must be a non-empty array")
    policies = []
    for index, item in enumerate(raw_policies):
        if not isinstance(item, Mapping):
            raise UsageError(f"policy {index} must be an object")
        declared_family = str(item.get("family_id") or family_id)
        if declared_family != family_id:
            raise UsageError(
                f"policy {item.get('policy_id', index)!r} names family "
                f"{declared_family!r}, not {family_id!r}"
            )
        policies.append(
            crg_certify.RetentionPolicyDeclaration(
                policy_id=str(item.get("policy_id") or ""),
                family_id=family_id,
                policy=str(item.get("policy") or ""),
                parameters=dict(item.get("parameters") or {}),
                protected_ids=tuple(item.get("protected_ids") or ()),
                protected_classes=dict(item.get("protected_classes") or {}),
            )
        )
    return tuple(policies)


def _op_safe_commitment(context: JobContext, *, persist: bool) -> JobResult:
    crg_certify.set_default_geometry(crg_geometry)
    request = dict(context.inputs.get("request") or {})
    case = dict(context.inputs["case"])
    bundle = load_bundle(case)
    family = _commitment_family(case, request)
    policies = _commitment_policies(request, family.family_id)
    artifact = crg_certify.compare_retention_policies(
        bundle,
        family,
        policies,
        geometry=crg_geometry,
        artifact_id=request.get("artifact_id"),
    ).to_canonical()
    verification = crg_verify.verify_safe_commitment(artifact)
    if not verification.ok:
        raise BlockedOutcome(
            "independent safe-commitment reconstruction failed",
            outcome="BLOCKED_VERIFIER_DISAGREEMENT",
            detail={"status": verification.status, "violations": verification.violations},
            remedy="do not persist or rely on the comparison; repair the producer/verifier disagreement",
        )
    statuses = {
        str(item["policy_id"]): str(item["status"])
        for item in artifact["evaluations"]
    }
    context.log(
        f"safe commitment {artifact['artifact_id']} independently reconstructed; "
        f"persist={persist}"
    )
    outputs = {
        "preview": not persist,
        "artifact": artifact,
        "artifact_id": artifact["artifact_id"],
        "artifact_hash": artifact["artifact_hash"],
        "family_id": family.family_id,
        "policy_statuses": statuses,
        "verification": verification.to_json(),
    }
    proof = {
        "proof_type": "SAFE_COMMITMENT_INDEPENDENT_RECONSTRUCTION",
        "profile": artifact["profile"],
        "artifact_hash": artifact["artifact_hash"],
        "verifier": "crg-verify",
        "status": verification.status,
    }
    if not persist:
        return JobResult(
            outputs=outputs,
            proof_artifacts=[proof],
            events=[{
                "event": "commitment.previewed",
                "detail": {"family_id": family.family_id, "policy_statuses": statuses},
            }],
        )
    case.setdefault("safe_commitments", {})[artifact["artifact_id"]] = artifact
    record_history(
        case,
        "commitment compare",
        {
            "artifact_id": artifact["artifact_id"],
            "artifact_hash": artifact["artifact_hash"],
            "family_id": family.family_id,
            "policy_statuses": statuses,
            "independently_verified": True,
        },
    )
    return JobResult(
        outputs=outputs,
        objects=[(artifact["artifact_id"], artifact)],
        case=case,
        proof_artifacts=[proof],
        events=[{
            "event": "commitment.compared",
            "object_hashes": [artifact["artifact_hash"]],
            "detail": {"family_id": family.family_id, "policy_statuses": statuses},
        }],
    )


def op_commitment_preview(context: JobContext) -> JobResult:
    return _op_safe_commitment(context, persist=False)


def op_commitment_compare(context: JobContext) -> JobResult:
    return _op_safe_commitment(context, persist=True)


def op_geometry(context: JobContext) -> JobResult:
    """Build canonical exact ``R``, ``Gamma``, and ``K`` (spec 19)."""
    request = dict(context.inputs.get("request") or {})
    case = dict(context.inputs["case"])
    requested = [str(o).strip().upper() for o in (request.get("objects") or ["R", "GAMMA", "K"])]
    unknown = sorted(set(requested) - {"R", "GAMMA", "K"})
    if unknown:
        raise UsageError(
            f"unknown geometry object(s) {unknown}",
            remedy="19 defines R, Gamma, and K; there is no fourth canonical object",
        )
    bundle = load_bundle(case)
    geometry = dict(case.get("geometry") or {})
    r_record = crg_geometry.build_R(bundle)
    if "R" in requested:
        geometry["R"] = {
            "root_hash": r_record.root_hash(),
            "signatures": len(r_record.fibers),
            "fibers": [
                {"signature": f.signature.to_canonical(),
                 "realization_ids": list(f.realization_ids)}
                for f in r_record.fibers
            ],
        }
    if "GAMMA" in requested:
        gamma = crg_geometry.build_gamma(r_record)
        geometry["GAMMA"] = {
            "root_hash": gamma.root_hash(),
            "frontier_size": len(gamma.frontier),
            "frontier": _points(gamma.frontier),
        }
        geometry["full_frontier"] = _points(gamma.frontier)
    if "K" in requested:
        k_record = crg_geometry.build_K(r_record)
        geometry["K"] = {
            "root_hash": k_record.root_hash(),
            "vertices": len(k_record.vertices),
            "vertex_points": _points(k_record.vertices),
        }
    case["geometry"] = geometry
    _advance_preparation(
        case,
        CaseState.IMPORTED_OR_GENERATED,
        reason=f"canonical geometry built: {', '.join(requested)}",
    )
    record_history(case, "geometry", {"objects": requested})
    context.log(f"built {requested}")
    roots = {k: v.get("root_hash") for k, v in geometry.items() if isinstance(v, Mapping)}
    return JobResult(
        outputs={"objects": roots},
        objects=[(f"geometry-{name}", geometry[name]) for name in requested if name in geometry],
        case=case,
        events=[{"event": "geometry.updated", "detail": {"objects": requested, "roots": roots}}],
    )


def op_certify(context: JobContext) -> JobResult:
    """Issue a decision certificate (spec 29).

    The certificate is produced whatever the outcome, because a refusal is a
    record and 29.5 names the refusals.  What the outcome controls is whether
    the job is *affirmative*: a blocked outcome sets ``affirmative=False`` and
    ``blocked_outcome``, and the boundary turns that into a 422 rather than a
    200 (6.6).  The certificate is still registered, because a blocked
    certificate is exactly the artifact an auditor needs.
    """
    crg_certify.set_default_geometry(crg_geometry)
    request = dict(context.inputs.get("request") or {})
    case = dict(context.inputs["case"])
    retained = request.get("retained")
    retained_ids = [str(r) for r in retained] if retained is not None else None

    bundle = load_bundle(case)
    scope = load_scope(case)
    derivation = load_derivation(case)
    certificate = crg_certify.certify(bundle, scope, derivation, retained=retained_ids)
    canonical = _store_certificate(case, certificate)

    if retained_ids is not None:
        r_full = crg_geometry.build_R(bundle)
        full_frontier = crg_geometry.build_gamma(r_full).frontier
        kept = [r for r in bundle.realizations if r.realization_id in set(retained_ids)]
        geometry = dict(case.get("geometry") or {})
        geometry["full_frontier"] = _points(full_frontier)
        if kept:
            geometry["retained_frontier"] = _points(
                crg_geometry.pareto_minimal([r.signature for r in kept])
            )
        case["geometry"] = geometry

    affirmative = certificate.outcome in AFFIRMATIVE_OUTCOMES
    # Hard advance, not a preparation step: this is the transition 11.2 exists
    # to guard.  A case that has not reached EVALUATED cannot become CERTIFIED,
    # and the refusal is a 409 rather than a silently mislabelled case.
    _advance(
        case,
        CaseState.CERTIFIED if affirmative else CaseState.BLOCKED,
        reason=f"{certificate.certificate_id}: {certificate.outcome}",
    )
    record_history(
        case,
        "certify",
        {"certificate_id": certificate.certificate_id, "outcome": certificate.outcome},
    )
    context.log(f"outcome {certificate.outcome}, claim scope {certificate.claim_scope}")

    certificate_hash = content_hash(canonical)
    program = vir_for(case, canonical)
    outputs = {
        "certificate_id": certificate.certificate_id,
        "certificate_hash": canonical["certificate_hash"],
        "outcome": certificate.outcome,
        "claim_scope": certificate.claim_scope,
        "selected": list(certificate.selected),
        "ties": list(certificate.ties),
        "runner_up": certificate.runner_up,
        "affirmative": affirmative,
        "claim": crg_certify.render_claim(certificate),
        "verification_program_id": program["program_id"],
    }
    return JobResult(
        outputs=outputs,
        objects=[
            ("registry", case["registry"]),
            (f"vir-{program['program_id']}", program),
        ],
        certificates=[canonical],
        dependencies=_certificate_edges(case, certificate_hash, certificate.certificate_id),
        case=case,
        affirmative=affirmative,
        blocked_outcome=None if affirmative else certificate.outcome,
        events=[
            {
                "event": "decision.certified" if affirmative else "decision.blocked",
                "object_hashes": [canonical["certificate_hash"]],
                "detail": {"outcome": certificate.outcome,
                           "claim_scope": certificate.claim_scope},
            }
        ],
        proof_artifacts=[
            {
                "artifact_type": "CRG_VIR_PROGRAM",
                "program_id": program["program_id"],
                "content_hash": content_hash(program),
                "sufficiency": "REQUIRES_REFERENCED_OBJECTS",
            }
        ],
    )


def op_change(context: JobContext) -> JobResult:
    """Classify a change and recompute the minimum valid amount (spec 30)."""
    request = dict(context.inputs.get("request") or {})
    case = dict(context.inputs["case"])
    if not case.get("certificates"):
        raise UsageError(
            "nothing to change: this case has no certificate yet",
            remedy="certify first; 30.1 is about what a change does to an existing claim",
        )
    prior = json.loads(canonical_json(case))
    prior_view = _case_view(prior)

    changed_object = "candidate-registry"
    changed_properties: List[str] = []
    for assignment in request.get("set") or ():
        target = str(assignment.get("realization") or "")
        coordinate = str(assignment.get("coordinate") or "")
        registry = case["registry"]
        identifiers = [c["identifier"] for c in registry["schema"]["coordinates"]]
        if coordinate not in identifiers:
            raise UsageError(f"unknown coordinate {coordinate!r}")
        index = identifiers.index(coordinate)
        for realization in registry["realizations"]:
            if realization["realization_id"] == target:
                realization["signature"][index] = decode_exact(
                    assignment.get("value"), where="set.value"
                ).to_canonical()
                break
        else:
            raise UsageError(f"unknown realization {target!r}")
        changed_properties.append(f"registry.candidates.{target}.{coordinate}")
    for assignment in request.get("weight") or ():
        changed_object = "price-model"
        coordinate = str(assignment.get("coordinate") or "")
        value = str(decode_exact(assignment.get("value"), where="weight.value"))
        family = dict((case.get("scope") or {}).get("objective_family") or {})
        weights = dict(family.get("weights") or {})
        weights[coordinate] = [value, value]
        family["weights"] = weights
        family["weights_are_ranges"] = any(w[0] != w[1] for w in weights.values())
        case["scope"] = {**(case.get("scope") or {}), "objective_family": family}
        changed_properties.append(f"price.weights.{coordinate}")
    if not changed_properties:
        raise UsageError(
            "declare what changed",
            remedy="supply 'set' or 'weight'; 30.2 classifies a declared change, not a diff guess",
        )
    _normalize_registry(case)

    event = ChangeEvent(
        event_id=str(request.get("event_id") or f"change-{len(case.get('history', []))}"),
        changed_object=changed_object,
        previous_version=str(prior.get("status")),
        current_version=str(case.get("status", "REOPENED")),
        declared_reason=str(request.get("reason") or "unstated"),
        changed_properties=tuple(changed_properties),
        timestamp=utc_now(),
        authority=str(request.get("authority") or "unattested"),
    )

    crg_certify.set_default_geometry(crg_geometry)
    bundle = load_bundle(case)
    scope = load_scope(case)
    derivation = load_derivation(case)

    def recompute(_case: Any, _plan: Any) -> List[dict]:
        certificate = crg_certify.certify(bundle, scope, derivation)
        return [_store_certificate(case, certificate)]

    delta = apply_change(
        prior_view,
        _case_view(case),
        event,
        case_dependency_graph(sorted(case.get("certificates") or {})),
        recompute_fn=recompute,
        approvals=tuple(request.get("approvals") or ()),
    )
    canonical = delta.to_canonical()
    canonical["delta_hash"] = delta.delta_hash()
    case.setdefault("deltas", {})[delta.delta_id] = canonical

    # 30.3 step 6 / 17.1: an invalidated certificate is superseded, not
    # deleted.  It leaves the active set but stays in the case.
    superseded = case.setdefault("superseded_certificates", {})
    for cert_id in delta.invalidated:
        if cert_id in case.get("certificates", {}):
            stale = dict(case["certificates"].pop(cert_id))
            stale["status"] = "SUPERSEDED"
            stale["superseded_by"] = delta.delta_id
            superseded[cert_id] = stale
    if delta.reopen_reason:
        _stale_then_reopen(case, reason=f"{delta.delta_id}: {delta.reopen_reason}")
    else:
        _advance(
            case,
            CaseState.CERTIFIED,
            reason=f"{delta.delta_id}: {delta.classification} carried the prior claim",
        )
    record_history(
        case, "change", {"delta_id": delta.delta_id, "classification": delta.classification}
    )
    context.log(f"classification {delta.classification}")

    events: List[Dict[str, Any]] = [
        {
            "event": "change.classified",
            "detail": {"classification": delta.classification,
                       "invalidated": list(delta.invalidated),
                       "recomputed": list(delta.recomputed)},
        }
    ]
    if delta.reopen_reason:
        events.append({"event": "case.reopened", "detail": {"reason": delta.reopen_reason}})
    for cert_id in delta.invalidated:
        events.append({"event": "certificate.stale", "detail": {"certificate_id": cert_id}})

    fresh = [
        cert for cert_id, cert in (case.get("certificates") or {}).items()
        if cert_id in set(delta.recomputed)
    ]
    dependencies: List[DependencyEdge] = []
    for certificate in fresh:
        dependencies.extend(
            _certificate_edges(case, content_hash(certificate),
                               str(certificate.get("certificate_id")))
        )
    return JobResult(
        outputs={
            "delta_id": delta.delta_id,
            "classification": delta.classification,
            "preserved": list(delta.preserved),
            "invalidated": list(delta.invalidated),
            "recomputed": list(delta.recomputed),
            "prior_winners": list(delta.prior_winners),
            "current_winners": list(delta.current_winners),
            "delta_hash": canonical["delta_hash"],
        },
        objects=[(delta.delta_id, canonical), ("registry", case["registry"])],
        certificates=fresh,
        dependencies=dependencies,
        case=case,
        events=events,
    )


def op_recompute(context: JobContext) -> JobResult:
    """Recompute the certificates of a case in place-free fashion (spec 30.3).

    "In place-free" is literal: recomputation issues *new* certificate
    objects.  The prior certificates are moved to the superseded set (17.1),
    never edited, so a reader who kept a hash can still resolve it.
    """
    case = dict(context.inputs["case"])
    if not case.get("scope"):
        raise UsageError("nothing to recompute: compile a decision query first")
    crg_certify.set_default_geometry(crg_geometry)
    bundle = load_bundle(case)
    scope = load_scope(case)
    derivation = load_derivation(case)

    superseded = case.setdefault("superseded_certificates", {})
    for cert_id, certificate in list((case.get("certificates") or {}).items()):
        stale = dict(certificate)
        stale["status"] = "SUPERSEDED"
        superseded[cert_id] = stale
    case["certificates"] = {}

    certificate = crg_certify.certify(bundle, scope, derivation)
    canonical = _store_certificate(case, certificate)
    affirmative = certificate.outcome in AFFIRMATIVE_OUTCOMES
    _advance(
        case,
        CaseState.CERTIFIED if affirmative else CaseState.BLOCKED,
        reason=f"recomputed {certificate.certificate_id}: {certificate.outcome}",
    )
    record_history(case, "recompute", {"certificate_id": certificate.certificate_id})
    context.log(f"recomputed {certificate.certificate_id}: {certificate.outcome}")
    return JobResult(
        outputs={
            "certificate_id": certificate.certificate_id,
            "outcome": certificate.outcome,
            "affirmative": affirmative,
            "superseded": sorted(superseded),
        },
        certificates=[canonical],
        dependencies=_certificate_edges(
            case, content_hash(canonical), certificate.certificate_id
        ),
        case=case,
        affirmative=affirmative,
        blocked_outcome=None if affirmative else certificate.outcome,
        events=[
            {
                "event": "decision.certified" if affirmative else "decision.blocked",
                "object_hashes": [canonical["certificate_hash"]],
                "detail": {"outcome": certificate.outcome},
            }
        ],
    )


def op_evaluate(context: JobContext) -> JobResult:
    """Evaluate the compiled objective over the family (spec 22.2).

    Produces decision values -- guaranteed and possible bounds -- and nothing
    else.  Evaluation is not certification: 22.3's strict-winner test is a
    separate gate and lives in ``crg_certify``.
    """
    case = dict(context.inputs["case"])
    bundle = load_bundle(case)
    # 19.1: the scope is bound to the coordinate order of the schema it will
    # be evaluated against, so a weight cannot be silently transposed onto the
    # wrong coordinate.  The kernel refuses an unbound scope; this is where
    # the binding belongs, because only here are both objects in hand.
    scope = crg_certify.bind_schema(load_scope(case), bundle.schema)
    values = []
    for realization in bundle.realizations:
        enclosure = crg_certify.evaluate_objective(realization.signature, scope)
        values.append(
            {
                "realization_id": realization.realization_id,
                # 22.2: the numerical enclosure is *all* this is.  Evidence
                # uncertainty and policy tolerance are separate components and
                # are not folded in here, so the field is named for what it is.
                "numerical_enclosure": encode(enclosure),
            }
        )
    case["decision_values"] = values
    _advance_preparation(
        case, CaseState.EVALUATED, reason=f"evaluated {len(values)} realizations"
    )
    record_history(case, "evaluate", {"evaluated": len(values)})
    context.log(f"evaluated {len(values)} realizations")
    return JobResult(
        outputs={"evaluated": len(values), "decision_values": values},
        objects=[("decision-values", values)],
        case=case,
        events=[{"event": "experiment.completed", "detail": {"evaluated": len(values)}}],
    )


def op_migrate(context: JobContext) -> JobResult:
    """Migrate a case to a target schema version (spec 15.3--15.5).

    Migration creates new objects and never rewrites historical ones, so this
    writes a successor case version and emits a ``MigrationRecord`` carrying
    the registered transform and independently checkable classification
    evidence.  The request's class is only an assertion: it cannot override
    the registry.  No prior certificate is carried across, including for the
    registered identity transform, because 15.5 permits re-verification but
    forbids inheritance merely because fields appear similar.
    """
    request = dict(context.inputs.get("request") or {})
    case = dict(context.inputs["case"])
    target = str(request.get("target_schema_version") or "")
    declared_class = request.get("migration_class")
    transform_id = str(request.get("transform_id") or "") or None
    if not target:
        raise UsageError("a migration must name its target schema version (15.1)")
    source_version = str(case.get("schema_version") or "0.2.0")
    try:
        execution = DEFAULT_MIGRATION_REGISTRY.execute(
            case,
            target,
            transform_id=transform_id,
            declared_class=(str(declared_class) if declared_class is not None else None),
        )
    except MigrationError as error:
        raise UsageError(
            str(error),
            remedy=(
                "select an installed transform whose source/target path and registered "
                "semantic class match the request; class labels are assertions, not "
                "classification evidence (15.3-15.6)"
            ),
        ) from None
    case = dict(execution.transformed)
    effective_class = execution.transform.migration_class
    verified_noop = (
        effective_class == "SEMANTICALLY_EQUIVALENT"
        and execution.source_object_hash == execution.transformed_object_hash
    )
    migration_profile = execution.transform.transform_id
    active = dict(case.get("certificates") or {})
    if verified_noop and active:
        case["pending_reverification"] = {
            cert_id: {**dict(certificate), "status": "RE_VERIFICATION_PENDING",
                      "original_schema_version": source_version}
            for cert_id, certificate in active.items()
        }
    carried = False
    if active:
        superseded = case.setdefault("superseded_certificates", {})
        for cert_id, certificate in active.items():
            stale = dict(certificate)
            stale["status"] = (
                "RE_VERIFICATION_PENDING" if verified_noop else "SUPERSEDED"
            )
            stale["superseded_by"] = "migration"
            superseded[cert_id] = stale
        case["certificates"] = {}
        _stale_then_reopen(
            case,
            reason=(
                f"migration to {target} classified {effective_class}; 15.5 refuses to carry "
                "the prior certificates across"
            ),
        )
    record_history(case, "migrate", {"migration_class": effective_class, "target": target})
    target_object_hash = content_hash(case)
    record = {
        "record_type": "MigrationRecord",
        "migration_id": (
            f"migration-{case.get('case_id')}-{target}-"
            f"{len(case.get('migration_records') or []) + 1}"
        ),
        "case_id": case.get("case_id"),
        "source_schema_version": source_version,
        "target_schema_version": target,
        "source_object_hash": execution.source_object_hash,
        "target_object_hash": target_object_hash,
        "declared_migration_class": (
            str(declared_class).upper() if declared_class is not None else ""
        ),
        "migration_class": effective_class,
        "migration_profile": migration_profile,
        **execution.evidence(),
        "migrated_at": utc_now(),
        "actor": context.actor,
        "actor_authentication": "SERVER_AUTHENTICATED_PRINCIPAL",
        "authority": str(request.get("authority") or "unattested"),
    }
    case.setdefault("migration_records", []).append(record)
    context.log(f"migrated {source_version} -> {target} as {effective_class}")
    return JobResult(
        outputs={
            "declared_migration_class": (
                str(declared_class).upper() if declared_class is not None else ""
            ),
            "migration_class": effective_class,
            "transform_id": execution.transform.transform_id,
            "transform_hash": execution.transform.transform_hash,
            "classification_proof_hash": execution.transform.classification_proof_hash,
            "classification_verified": True,
            "target_schema_version": target,
            "certificates_carried": carried,
            "revalidation_required": not carried,
        },
        objects=[("migration-record", record)],
        case=case,
        events=[{"event": "case.migrated", "detail": {"migration_class": effective_class}}],
    )


def op_convert(context: JobContext) -> JobResult:
    """Plan an ownership or layout conversion (spec 31)."""
    from crg_convert import Layout, convert

    request = dict(context.inputs.get("request") or {})
    case = dict(context.inputs["case"])
    source_spec = request.get("source")
    target_spec = request.get("target")
    if source_spec is None or target_spec is None:
        raise UsageError(
            "a conversion needs a source and a target layout",
            remedy="POST {'source': {...}, 'target': {...}} (31.2)",
        )

    def _layout(spec: Any, label: str) -> Any:
        if isinstance(spec, Mapping):
            divisions = spec.get("divisions")
            return Layout(
                divisions if divisions is not None else (),
                label=str(spec.get("label") or label),
                total_elements=spec.get("total_elements"),
                bytes_per_element=spec.get("bytes_per_element"),
            )
        return Layout(spec, label=label)

    record = convert(
        _layout(source_spec, "source"),
        _layout(target_spec, "target"),
        record_id=request.get("record_id"),
        consistency_epoch=request.get("consistency_epoch"),
    )
    canonical = encode(record)
    case.setdefault("conversions", {})[record.record_id] = canonical
    record_history(case, "convert", {"record_id": record.record_id})
    context.log(f"retained {record.retained_fraction}, moved {record.moved_fraction}")
    return JobResult(
        outputs={
            "record_id": record.record_id,
            "retained_fraction": str(record.retained_fraction),
            "moved_fraction": str(record.moved_fraction),
        },
        objects=[(record.record_id, canonical)],
        case=case,
        events=[
            {
                "event": "conversion.planned",
                "detail": {"retained_fraction": str(record.retained_fraction)},
            }
        ],
    )


# ---------------------------------------------------------------------------
# ETQ operations (spec 33, 34, 35)
# ---------------------------------------------------------------------------
def _clock(payload: Any):
    from etq_evidence import VerificationClock

    if payload is None:
        # 45.3, 45.4: with no clock, expiry is undecided.  The wall clock is
        # never read on a verifying path, so an absent clock is
        # TIME_INDETERMINATE and not "now".
        return VerificationClock.absent()
    return decode(VerificationClock, payload, where="clock")


def op_evidence(request: Mapping[str, Any]) -> Dict[str, Any]:
    """Register an evidence record (spec 33.2, endpoint ``POST /evidence``)."""
    from etq_evidence import EvidenceRecord

    payload = request.get("evidence")
    if payload is None:
        raise UsageError("POST /evidence requires an 'evidence' record (33.2)")
    record = decode(EvidenceRecord, payload, where="evidence")
    judgment = record.time_judgment(_clock(request.get("clock")))
    canonical = encode(record)
    return {
        "evidence_id": record.evidence_id,
        "evidence": canonical,
        "content_hash": content_hash(canonical),
        "time_judgment": encode(judgment),
        "time_status": judgment.time_status,
        "provenance_status": record.provenance_status(),
        "may_authorize": record.may_authorize,
    }


def op_technology_contract(context: JobContext) -> JobResult:
    """Assemble a technology contract (spec 33.6)."""
    from etq_evidence import (
        ApplicabilityRule,
        ContextDescriptor,
        CoordinateRequest,
        EvidenceRecord,
        Requester,
        assemble_technology_contract,
    )

    request = dict(context.inputs.get("request") or {})
    evidence = [
        decode(EvidenceRecord, e, where=f"evidence[{i}]")
        for i, e in enumerate(request.get("evidence") or ())
    ]
    rules = [
        decode(ApplicabilityRule, r, where=f"rules[{i}]")
        for i, r in enumerate(request.get("rules") or ())
    ]
    target = decode(ContextDescriptor, request.get("target_context") or {},
                    where="target_context")
    coordinates = [
        decode(CoordinateRequest, c, where=f"coordinates[{i}]")
        for i, c in enumerate(request.get("coordinates") or ())
    ] or None
    requester = (
        decode(Requester, request["requester"], where="requester")
        if request.get("requester") is not None
        else None
    )
    contract, report = assemble_technology_contract(
        evidence,
        rules,
        target,
        clock=_clock(request.get("clock")),
        requester=requester,
        coordinates=coordinates,
        contract_id=str(request.get("contract_id") or "technology-contract"),
    )
    canonical = encode(contract)
    context.log(
        f"{len(getattr(contract, 'coordinates', ()) or ())} bounded coordinates, "
        f"{len(getattr(report, 'rejections', ()) or ())} rejections"
    )
    return JobResult(
        outputs={
            "contract_id": contract.contract_id,
            "contract": canonical,
            "content_hash": content_hash(canonical),
            "report": encode(report),
            "verification_status": getattr(contract, "verification_status", None),
        },
        objects=[(contract.contract_id, canonical)],
        events=[
            {
                "event": "technology_contract.updated",
                "detail": {"contract_id": contract.contract_id},
            }
        ],
    )


def op_capability_envelope(request: Mapping[str, Any]) -> Dict[str, Any]:
    """Issue a capability envelope (spec 35.2).

    The signing key arrives in the request and leaves in nothing: the returned
    payload, the stored objects, and the audit event carry the key identity
    and profile only (44.4).
    """
    from etq_evidence import ContextDescriptor, ValidityWindow
    from etq_federation import (
        Authorization,
        BoundedResult,
        ClockAssertion,
        ReleasePolicy,
        RuleIdentity,
        SigningKey,
        VerificationProgram,
        issue_envelope,
    )

    bound = decode(BoundedResult, request.get("bounded_result") or {}, where="bounded_result")
    target = decode(ContextDescriptor, request.get("target_context") or {},
                    where="target_context")
    rule = decode(RuleIdentity, request.get("rule") or {}, where="rule")
    key = decode(SigningKey, request.get("key") or {}, where="key")
    validity = decode(ValidityWindow, request.get("validity") or {}, where="validity")
    nonce = str(request.get("nonce") or "")
    if not nonce:
        raise UsageError(
            "an envelope must carry a nonce (35.2)",
            remedy="a replayed envelope is a named threat in 44.6; supply a fresh nonce",
        )
    optional: Dict[str, Any] = {}
    if request.get("authorization") is not None:
        optional["authorization"] = decode(
            Authorization, request["authorization"], where="authorization"
        )
    if request.get("release_policy") is not None:
        optional["release_policy"] = decode(
            ReleasePolicy, request["release_policy"], where="release_policy"
        )
    if request.get("clock_assertion") is not None:
        optional["clock_assertion"] = decode(
            ClockAssertion, request["clock_assertion"], where="clock_assertion"
        )
    if request.get("verification_program") is not None:
        optional["verification_program"] = decode(
            VerificationProgram, request["verification_program"], where="verification_program"
        )
    envelope = issue_envelope(
        bound,
        target,
        rule,
        request.get("evidence_root"),
        issuer=str(request.get("issuer") or ""),
        key=key,
        validity=validity,
        nonce=nonce,
        envelope_id=request.get("envelope_id"),
        **optional,
    )
    canonical = encode(envelope)
    typed_form = _typed_form(envelope)
    return {
        "envelope_id": envelope.envelope_id,
        "envelope": canonical,
        "typed_envelope": typed_form,
        "content_hash": content_hash(canonical),
        "signature_profile": key.profile,
        "key_id": key.key_id,
    }


def op_private_evaluation(request: Mapping[str, Any]) -> Dict[str, Any]:
    """Evaluate a capability predicate confidentially (spec 35.3, 35.4).

    Fails closed and specifically.  A denied evaluation returns ``NO_RESULT``
    with every value field empty -- never ``False``, which a recipient could
    read as a refutation (35.4).
    """
    from etq_evidence import VerificationClock  # noqa: F401  (documents the clock discipline)
    from etq_federation import (
        CapabilityEnvelope,
        CapabilityQuery,
        KeyRing,
        NonceLedger,
        ReleasePolicy,
        SigningKey,
        VerifierExpectations,
        evaluate_private,
    )

    envelope_payload = request.get("typed_envelope") or request.get("envelope")
    if envelope_payload is None:
        raise UsageError(
            "a private evaluation needs the capability envelope it is about",
            remedy="POST the 'typed_envelope' returned by POST /capability-envelopes",
        )
    envelope = decode(CapabilityEnvelope, envelope_payload, where="envelope")
    predicate = decode(CapabilityQuery, request.get("predicate") or {}, where="predicate")
    keys = [
        decode(SigningKey, k, where=f"keys[{i}]")
        for i, k in enumerate(request.get("keys") or ())
    ]
    policy = (
        decode(ReleasePolicy, request["release_policy"], where="release_policy")
        if request.get("release_policy") is not None
        else None
    )
    expectations = (
        decode(VerifierExpectations, request["expectations"], where="expectations")
        if request.get("expectations") is not None
        else None
    )
    result = evaluate_private(
        envelope,
        predicate,
        release_policy=policy,
        clock=_clock(request.get("clock")),
        seen_nonces=NonceLedger(request.get("seen_nonces") or ()),
        requested_kind=request.get("requested_kind"),
        keys=KeyRing(keys) if keys else None,
        expectations=expectations,
    )
    canonical = encode(result)
    denials = [encode(d) for d in (getattr(result, "denials", ()) or ())]
    return {
        "result": canonical,
        "content_hash": content_hash(canonical),
        "state": getattr(result, "state", None),
        "release_kind": getattr(result, "release_kind", None),
        "released": bool(getattr(result, "released", False)),
        "denied": bool(denials),
        "denials": denials,
        # 35.4: the attestation scope travels with the result, so a consumer
        # holding only this object still cannot read more into it than the
        # specification permits.
        "attestation_scope": getattr(result, "attestation_scope", None),
        "attestation_does_not_prove": list(
            getattr(result, "attestation_does_not_prove", ()) or ()
        ),
    }


def op_qualification_plan(context: JobContext) -> JobResult:
    """Rank the experiments that would resolve a qualification (spec 34.4).

    Ranking is tiered before it is scored, and both come from
    ``etq_qualify.rank_experiments``: an experiment whose declared reduction
    is not strictly positive sits below every informative one whatever its
    burden, so cheapness cannot buy rank that information did not earn.
    """
    from etq_qualify import (
        BurdenWeights,
        ExperimentDefinition,
        rank_experiments,
    )

    request = dict(context.inputs.get("request") or {})
    experiments = [
        decode(ExperimentDefinition, e, where=f"experiments[{i}]")
        for i, e in enumerate(request.get("experiments") or ())
    ]
    if not experiments:
        raise UsageError("a qualification plan needs at least one declared experiment (34.2)")
    if request.get("burden_weights") is None:
        raise UsageError(
            "a qualification plan must declare its burden weights (34.4)",
            remedy=(
                "34.4: a dimension that was never declared cannot be weighted, so there is "
                "no default weighting; state the burden dimensions and their weights"
            ),
        )
    weights = decode(BurdenWeights, request["burden_weights"], where="burden_weights")
    ranked = rank_experiments(
        experiments,
        burden_weights=weights,
        basis=str(request.get("basis") or "EXPECTED"),
    )
    canonical = [encode(r) for r in ranked]
    context.log(f"ranked {len(canonical)} experiments")
    return JobResult(
        outputs={"ranked_experiments": canonical, "count": len(canonical)},
        objects=[("qualification-plan", canonical)],
        events=[{"event": "qualification.planned", "detail": {"experiments": len(canonical)}}],
    )


def op_evaluator_request(case: Mapping[str, Any], request: Mapping[str, Any]) -> Dict[str, Any]:
    """Record a physical-evaluator request (spec 32.1)."""
    from crg_feedback import EvaluatorRequest

    payload = request.get("evaluator_request")
    if payload is None:
        raise UsageError("this endpoint requires an 'evaluator_request' (32.1)")
    record = decode(EvaluatorRequest, payload, where="evaluator_request")
    canonical = encode(record)
    return {
        "request_id": getattr(record, "request_id", None),
        "evaluator_request": canonical,
        "content_hash": content_hash(canonical),
    }


def _typed_form(value: Any) -> Any:
    """A field-for-field projection that :func:`crg_server.typed.decode` reads.

    ``to_canonical`` is the *hashing* form and may rename or omit fields, so
    it does not round-trip; this does, which is what lets a caller hand an
    issued envelope straight back for a private evaluation without the server
    holding session state (10.1: typed requests, no server-side mutation).
    """
    import dataclasses

    from crg_model.numeric import Exact, Interval

    if isinstance(value, Exact):
        return str(value)
    if isinstance(value, Interval):
        return [str(value.lo), str(value.hi)]
    if dataclasses.is_dataclass(value) and not isinstance(value, type):
        return {
            f.name: _typed_form(getattr(value, f.name))
            for f in dataclasses.fields(value)
            if f.init
        }
    if isinstance(value, Mapping):
        return {str(k): _typed_form(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set, frozenset)):
        return [_typed_form(v) for v in value]
    if isinstance(value, bytes):
        return value.hex()
    return value
