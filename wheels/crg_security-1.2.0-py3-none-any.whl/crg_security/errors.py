"""The refusal vocabulary of the security package.

Normative basis: 6.6 (fail closed), 44.2, 44.3, 44.5, 44.6.

Every class here is a *refusal*.  There is deliberately no "warning" class:
specification 6.6 makes an unresolved security question a refusal rather than
a note attached to an affirmative answer, and a security package that could
return "probably fine" would be the first place that principle leaked.

The split matters at the integration boundary.  :class:`AuthenticationError`
maps to HTTP 401 -- *who are you* -- and :class:`AuthorizationError` maps to
403 -- *I know who you are and the answer is no*.  Collapsing them would let
a caller distinguishing the two learn nothing, but it would also let an
operator reading an audit log fail to distinguish a credential problem from a
policy problem, which are different incidents with different responses.
"""
from __future__ import annotations

from typing import Any, Dict, Mapping, Optional

__all__ = [
    "SecurityError",
    "ConfigurationError",
    "ProfileUnavailableError",
    "UnsupportedProfileError",
    "AuthenticationError",
    "CredentialExpiredError",
    "ReplayError",
    "AuthorizationError",
    "TenantIsolationError",
    "KeyDestroyedError",
    "LegalHoldError",
    "AuditIntegrityError",
]


class SecurityError(Exception):
    """Base of every refusal in this package.

    ``remedy`` is not decoration.  A refusal that does not say what would have
    to be true instead is an obstacle rather than a control, and the security
    surface is exactly where an operator is least able to guess.
    """

    #: The HTTP status an integration boundary should map this to (38.2).
    status: int = 403
    #: A stable machine-readable category, so a client can branch without
    #: parsing prose.
    category: str = "SECURITY"

    def __init__(
        self,
        message: str,
        *,
        remedy: str = "",
        detail: Optional[Mapping[str, Any]] = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.remedy = remedy
        self.detail: Dict[str, Any] = dict(detail or {})

    def to_canonical(self) -> Dict[str, Any]:
        record: Dict[str, Any] = {
            "error": type(self).__name__,
            "category": self.category,
            "status": self.status,
            "message": self.message,
        }
        if self.remedy:
            record["remedy"] = self.remedy
        if self.detail:
            record["detail"] = dict(self.detail)
        return record

    def __str__(self) -> str:  # pragma: no cover - trivial
        if self.remedy:
            return f"{self.message} -- {self.remedy}"
        return self.message


class ConfigurationError(SecurityError):
    """A deployment asked for something it did not configure."""

    status = 500
    category = "CONFIGURATION"


class ProfileUnavailableError(ConfigurationError):
    """A cryptographic profile was requested that this build cannot perform.

    Raised, never downgraded.  The whole point of the optional production
    profile (see :mod:`crg_security.profile`) is that a deployment which
    believes it is running Ed25519 finds out at the first signing attempt
    that it is not, rather than shipping HMAC-shaped artifacts labelled
    Ed25519.
    """

    category = "PROFILE_UNAVAILABLE"


class UnsupportedProfileError(SecurityError):
    """A verifier met a signature profile it does not implement (14.5).

    Distinct from :class:`ProfileUnavailableError`: that one is "I would if I
    could", this one is "I will not guess".  Both fail closed; only one is
    fixable by installing a dependency.
    """

    status = 422
    category = "UNSUPPORTED_PROFILE"


class AuthenticationError(SecurityError):
    """The caller's identity could not be established (44.2)."""

    status = 401
    category = "UNAUTHENTICATED"


class CredentialExpiredError(AuthenticationError):
    """A credential was well-formed and is no longer valid (45.4 ``EXPIRED``)."""

    category = "CREDENTIAL_EXPIRED"


class ReplayError(AuthenticationError):
    """A single-use credential or nonce was presented twice (35.4)."""

    category = "REPLAY"


class AuthorizationError(SecurityError):
    """The caller is known and the policy said no (44.3, 44.4)."""

    status = 403
    category = "FORBIDDEN"


class TenantIsolationError(SecurityError):
    """A tenant boundary was crossed, or an access was attempted without one.

    In this package this is close to unreachable through the supported API --
    tenant views are separate objects over separate stores (44.5) -- and that
    is the point.  It exists so that the *unsupported* paths, and any future
    caller that reaches under the abstraction, still fail closed rather than
    succeeding quietly.
    """

    status = 403
    category = "TENANT_ISOLATION"


class KeyDestroyedError(SecurityError):
    """The key that would decrypt this object was destroyed (17.4).

    This is a permanent, intended condition, not a fault.  It carries the
    destruction record so a caller can say *when, by whom, and under what
    authority* the content became unreadable -- 17.2's tombstone discipline
    applied to cryptographic erasure.
    """

    status = 410
    category = "CRYPTOGRAPHICALLY_ERASED"


class LegalHoldError(SecurityError):
    """Erasure was refused because the object is under legal hold (17.5)."""

    status = 409
    category = "LEGAL_HOLD"


class AuditIntegrityError(SecurityError):
    """The audit chain does not verify (44.7)."""

    status = 500
    category = "AUDIT_INTEGRITY"
