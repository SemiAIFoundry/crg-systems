"""The opt-in security gate an integration boundary plugs in (44.2, 44.7).

Normative basis: 44.2 (identity and authorization at the enterprise profile),
44.3 (minimum roles), 44.5 (separation at authentication and authorization),
44.7 (every authorization-sensitive operation produces an immutable audit
event), 38.2 (the integration boundary), 51 and 60 (published claim boundary),
6.6 (fail closed).

This module is the seam between :mod:`crg_security` and :mod:`crg_server`.
The application object accepts any gate with the three methods below, while
the shipped ``crg-serve`` network entry point deliberately imports this gate
and refuses to start without one.  An embedding can still supply its own gate
without coupling the router to a particular identity provider.

**Default off, and loudly.**  An :class:`Application` constructed without a
gate behaves exactly as it did before this package existed, and reports
:data:`NO_AUTHENTICATION_CONFIGURED` in
:meth:`crg_server.Application.security_disclosure` and in the
``X-CRG-Authentication`` response header on every request.  The alternative --
a default gate that permits everything -- would be indistinguishable at the
wire from a configured one, and 60 exists to prevent exactly that kind of
quiet.

**Authentication and authorization stay separate.**  :meth:`authenticate`
answers *who is this* (401 on failure) and :meth:`authorize` answers *may they*
(403).  Collapsing them would lose the distinction an operator needs to tell a
credential incident from a policy incident.

**Every decision is logged, including the permits.**  44.7 says every
authorization-sensitive operation, and a log containing only refusals cannot
answer "what did the compromised account actually do".
"""
from __future__ import annotations

import base64
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from .audit import HashChainedAuditLog
from .clock import Clock
from .errors import (
    AuthenticationError,
    ConfigurationError,
    TenantIsolationError,
)
from .identity import IdentityBroker, Principal
from .policy import (
    AccessRequest,
    Decision,
    Effect,
    PolicyEngine,
    Resource,
    subject_from_principal,
)
from .profile import SECURITY_PROFILE, disclosure as profile_disclosure
from .roles import operation_permission
from .tenancy import MultiTenantStore, TenantContext

__all__ = [
    "NO_AUTHENTICATION_CONFIGURED",
    "SecurityConfiguration",
    "ServerSecurityGate",
    "unconfigured_disclosure",
]

#: The exact sentence a deployment publishes when it has configured nothing.
#: Quoted verbatim by ``crg_server`` so that the server does not have to
#: import this package to be honest about not having it.
NO_AUTHENTICATION_CONFIGURED = (
    "NO AUTHENTICATION CONFIGURED.  This server is accepting the X-CRG-Actor "
    "header as an unverified assertion of identity and is enforcing no "
    "authentication, no tenant separation, and no attribute-based policy.  "
    "Specification 44.2 requires the enterprise profile to support local "
    "accounts, OIDC, SAML where required, and service identities; none of them "
    "is active.  Operation-level role checks apply only if a static role table "
    "was supplied.  Do not expose this deployment to an untrusted network."
)


def unconfigured_disclosure() -> Dict[str, Any]:
    """The machine-readable form of the sentence above (51, 60)."""
    return {
        "authentication_configured": False,
        "disclosure": NO_AUTHENTICATION_CONFIGURED,
        "spec": "44.2, 44.5, 44.7",
        "identity_sources": [],
        "tenant_separation": "none (single tenant, unenforced)",
        "authorization": "static role table only, if supplied",
        "audit": "server event log; not the hash-chained crg-security log",
    }


# ==========================================================================
# configuration
# ==========================================================================
@dataclass
class SecurityConfiguration:
    """Everything a gate needs, in one reviewable object.

    A dataclass rather than a pile of constructor keywords so that a
    deployment's security posture is a *value* it can canonicalize, diff, and
    put in a change record -- 44.6 lists unauthorized rule changes as a threat
    and an unreviewable configuration is where they hide.

    ``required`` is the single switch between "refuse anything anonymous" and
    "authenticate when credentials are present, and otherwise leave the
    request to whatever the boundary already did".  It defaults to ``True``,
    because a gate that was configured and then quietly let anonymous requests
    through would be worse than no gate: the operator would believe they had
    one.  ``required=False`` exists for a staged rollout -- turn the gate on,
    watch the audit log fill with what *would* have been refused, then flip it
    -- and it is disclosed in :meth:`to_canonical` so that a deployment cannot
    forget it left the switch down.

    ``anonymous_operations`` is the narrower escape: named operations that may
    proceed without credentials even when ``required`` is true.  Naming them
    one at a time is the point; a wildcard would be ``required=False`` wearing
    a disguise.
    """

    broker: IdentityBroker
    engine: PolicyEngine
    clock: Clock
    audit_log: HashChainedAuditLog
    #: Optional notary/custody key used only to sign audit checkpoints.  The
    #: private material is never serialized by :meth:`to_canonical`; the
    #: disclosure records only whether a signer is configured.
    audit_checkpoint_signing_key: Any = None
    store: Optional[MultiTenantStore] = None
    required: bool = True
    #: Header carrying the tenant a request is acting in.  The gate refuses a
    #: tenant that disagrees with the authenticated principal's own (44.5).
    tenant_header: str = "X-CRG-Tenant"
    authorization_header: str = "Authorization"
    #: Operations that may be reached without credentials.  Empty by default;
    #: a deployment that wants an unauthenticated health or description
    #: endpoint has to name it, which makes the exception reviewable.
    anonymous_operations: Tuple[str, ...] = ()
    default_case_scope: Tuple[str, ...] = ("*",)

    def __post_init__(self) -> None:
        for name, value in (
            ("broker", self.broker),
            ("engine", self.engine),
            ("clock", self.clock),
            ("audit_log", self.audit_log),
        ):
            if value is None:
                raise ConfigurationError(
                    f"a security configuration requires {name}",
                    remedy="a partially configured gate is the failure mode 60 forbids: "
                           "it looks configured and enforces less than it appears to",
                )
        self.anonymous_operations = tuple(str(o) for o in self.anonymous_operations)
        self.default_case_scope = tuple(str(c) for c in self.default_case_scope)

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "authentication_configured": True,
            "required": self.required,
            "identity": self.broker.disclosure(),
            "authorization": self.engine.to_canonical(),
            "anonymous_operations": list(self.anonymous_operations),
            "tenant_header": self.tenant_header,
            "multi_tenant_store": self.store is not None,
            "tenants": list(self.store.tenants) if self.store is not None else [],
            "clock_source": self.clock.source,
            "clock_trust_level": self.clock.trust_level,
            "audit_checkpoint_signing": (
                "configured" if self.audit_checkpoint_signing_key is not None
                else "not-configured"
            ),
            "security_profile": SECURITY_PROFILE,
        }


# ==========================================================================
# the gate
# ==========================================================================
class ServerSecurityGate:
    """Authenticate, authorize, audit -- the three calls a boundary needs.

    Duck-typed against :mod:`crg_server` deliberately: the server calls
    ``authenticate(request)``, ``authorize(...)``, and ``disclosure()``, and
    nothing else, so any object with those three methods is a gate.

    An *unconfigured* gate is a real object too --
    :meth:`ServerSecurityGate.unconfigured` -- and it permits everything while
    reporting :data:`NO_AUTHENTICATION_CONFIGURED`.  It exists so that a
    deployment can hold "a gate" uniformly, and it is not the default: the
    default is no gate at all, which is the same behaviour and one fewer
    object to mistake for a control.
    """

    def __init__(self, configuration: Optional[SecurityConfiguration] = None) -> None:
        self.configuration = configuration

    # -- construction -------------------------------------------------------
    @classmethod
    def unconfigured(cls) -> "ServerSecurityGate":
        return cls(None)

    @property
    def enabled(self) -> bool:
        return self.configuration is not None

    # -- authentication (44.2) ---------------------------------------------
    def authenticate(self, request: Any) -> Optional[Principal]:
        """Resolve credentials on ``request`` to a :class:`Principal`.

        Accepted schemes, chosen by the ``Authorization`` header's own label
        rather than by trying each in turn:

        * ``Bearer <token>`` -- a federated assertion, validated by the
          configured production OIDC provider or an explicit test adapter;
        * ``ApiKey <key_id>.<secret>`` -- a service identity (44.2);
        * ``Basic <base64(user:pass)>`` -- a local account.

        Basic is accepted because 44.2 requires local accounts and something
        has to carry them; 44.4 makes transport encryption mandatory, so the
        credential is only ever on the wire inside TLS, and this docstring is
        the place that says the server does not provide the TLS.
        """
        config = self.configuration
        if config is None:
            return None
        header = _header(request, config.authorization_header)
        if not header:
            # No credential is not, by itself, a refusal: whether anonymity is
            # acceptable depends on the *operation*, which authentication does
            # not know.  Returning ``None`` hands that judgment to
            # :meth:`authorize`, which does know, and which refuses with a 401
            # unless the operation was explicitly declared anonymous.  Raising
            # here instead would make ``anonymous_operations`` unreachable.
            return None
        scheme, _, value = header.partition(" ")
        scheme = scheme.strip().lower()
        value = value.strip()
        if not value:
            raise AuthenticationError(
                f"the {config.authorization_header} header carries a scheme and no credential"
            )
        if scheme == "bearer":
            principal = config.broker.authenticate(
                "federated", value, clock=config.clock
            )
        elif scheme in {"apikey", "api-key"}:
            principal = config.broker.authenticate("api-key", value, clock=config.clock)
        elif scheme == "basic":
            try:
                decoded = base64.b64decode(value + "=" * (-len(value) % 4)).decode("utf-8")
            except Exception as exc:  # noqa: BLE001 - any decode failure is a refusal
                raise AuthenticationError(
                    "the Basic credential is not base64-encoded UTF-8",
                    remedy="the credential is malformed; it is refused rather than repaired",
                ) from exc
            username, sep, password = decoded.partition(":")
            if not sep:
                raise AuthenticationError("a Basic credential must be 'username:password'")
            principal = config.broker.authenticate(
                "password", (username, password), clock=config.clock
            )
        else:
            raise AuthenticationError(
                f"authentication scheme {scheme!r} is not supported",
                remedy="supported schemes are Bearer, ApiKey, and Basic; an unknown "
                       "scheme is refused rather than tried against each mechanism",
            )

        asserted_tenant = _header(request, config.tenant_header)
        if asserted_tenant and asserted_tenant != principal.tenant_id:
            raise TenantIsolationError(
                f"the request asserts tenant {asserted_tenant!r} and the credential "
                f"authenticated into tenant {principal.tenant_id!r}",
                remedy="44.5 separates at authentication; the header cannot widen what "
                       "the credential established",
                detail={
                    "asserted_tenant": asserted_tenant,
                    "authenticated_tenant": principal.tenant_id,
                },
            )
        return principal

    # -- authorization (44.2, 44.3) ----------------------------------------
    def authorize(
        self,
        *,
        operation_id: str,
        principal: Optional[Principal],
        parameters: Optional[Mapping[str, str]] = None,
        request: Any = None,
        resource_id: str = "",
        resource_type: str = "",
        previously_exercised: Sequence[str] = (),
    ) -> Decision:
        """Decide, audit, and raise unless the answer is PERMIT (6.6)."""
        config = self.configuration
        if config is None:
            return Decision(
                effect=Effect.PERMIT,
                rule_id="urn:crg:policy:unconfigured",
                reason=NO_AUTHENTICATION_CONFIGURED,
                action=str(operation_id),
                policy_effect=Effect.NOT_APPLICABLE,
            )
        if principal is None:
            if str(operation_id) in config.anonymous_operations:
                return Decision(
                    effect=Effect.PERMIT,
                    rule_id="urn:crg:policy:anonymous-operation",
                    reason=f"{operation_id} is on this deployment's declared "
                           "anonymous-operation list",
                    action=str(operation_id),
                    policy_effect=Effect.NOT_APPLICABLE,
                )
            if not config.required:
                return Decision(
                    effect=Effect.PERMIT,
                    rule_id="urn:crg:policy:gate-not-required",
                    reason=(
                        "this gate is configured with required=False, so an anonymous "
                        "request is passed through to whatever the boundary already "
                        "enforced; this is a staged-rollout posture, not a control"
                    ),
                    action=str(operation_id),
                    policy_effect=Effect.NOT_APPLICABLE,
                )
            raise AuthenticationError(
                f"{operation_id} requires an authenticated identity",
                remedy="present credentials; 44.7 requires every authorization-sensitive "
                       "operation to be attributable",
            )

        params = dict(parameters or {})
        case_id = params.get("case_id")
        access = AccessRequest(
            subject=subject_from_principal(
                principal, case_scope=config.default_case_scope
            ),
            resource=Resource(
                resource_id=str(resource_id or case_id or params.get("job_id") or operation_id),
                resource_type=str(resource_type or ("CRGCase" if case_id else "Operation")),
                tenant_id=principal.tenant_id,
                case_id=case_id,
                attributes={"operation_id": str(operation_id)},
            ),
            action=str(operation_id),
            environment={
                "method": getattr(request, "method", ""),
                "path": getattr(request, "path", ""),
                "clock_source": config.clock.source,
                "clock_trust_level": config.clock.trust_level,
                "authentication_method": principal.authentication_method,
                "subject_kind": principal.kind,
            },
            previously_exercised=tuple(previously_exercised),
        )
        return config.engine.authorize(access)

    # -- tenancy ------------------------------------------------------------
    def context_for(
        self, principal: Principal, *, correlation_id: str = "", purpose: str = ""
    ) -> TenantContext:
        """The :class:`TenantContext` this principal may open (44.5)."""
        config = self.configuration
        if config is None:
            raise ConfigurationError(
                "an unconfigured gate has no tenancy",
                remedy=NO_AUTHENTICATION_CONFIGURED,
            )
        return TenantContext(
            tenant_id=principal.tenant_id,
            principal=principal,
            clock=config.clock,
            correlation_id=correlation_id,
            case_scope=tuple(
                principal.attributes.get("case_scope") or config.default_case_scope
            ),
            purpose=purpose,
        )

    def store_view(self, principal: Principal, *, correlation_id: str = "") -> Any:
        config = self.configuration
        if config is None or config.store is None:
            raise ConfigurationError(
                "no multi-tenant store is configured on this gate",
                remedy="construct SecurityConfiguration(store=MultiTenantStore(...))",
            )
        return config.store.view(
            self.context_for(principal, correlation_id=correlation_id)
        )

    # -- audit (44.7) -------------------------------------------------------
    def record(
        self,
        *,
        actor: str,
        action: str,
        resource: str,
        decision: str,
        outcome: str,
        tenant_id: str = "",
        correlation_id: str = "",
        rule_id: str = "",
        detail: Optional[Mapping[str, Any]] = None,
    ) -> Any:
        """Append an event to the hash-chained log, if one is configured."""
        config = self.configuration
        if config is None:
            return None
        return config.audit_log.append(
            actor=actor,
            action=action,
            resource=resource,
            decision=decision,
            outcome=outcome,
            correlation_id=correlation_id,
            rule_id=rule_id,
            tenant_id=tenant_id or config.audit_log.tenant_id,
            detail=dict(detail or {}),
        )

    def export_audit(
        self,
        *,
        principal: Principal,
        authority: str,
        after_sequence: int = -1,
        limit: int = 100,
        correlation_id: str = "",
    ) -> Dict[str, Any]:
        """Create a bounded tenant audit artifact after authorization.

        The server calls this only after :meth:`authorize` has permitted the
        ``exportAudit`` operation.  That permit is already one link in the
        chain.  A second completion link is appended here before the snapshot,
        so the exported evidence contains both who was allowed to ask and the
        fact that an artifact was actually produced.
        """
        config = self.configuration
        if config is None:
            raise ConfigurationError(
                "an unconfigured security gate has no governed audit chain",
                remedy="configure a tenant-bound HashChainedAuditLog before export",
            )
        if principal is None:
            raise AuthenticationError("audit export requires an authenticated principal")
        tenant_id = str(principal.tenant_id or "")
        log_tenant = str(config.audit_log.tenant_id or "")
        if not log_tenant:
            raise ConfigurationError(
                "the configured audit log is not bound to a tenant",
                remedy="44.5: bind one audit chain to exactly one tenant before export",
            )
        if tenant_id != log_tenant:
            raise TenantIsolationError(
                f"principal tenant {tenant_id!r} cannot export audit tenant {log_tenant!r}",
                remedy="route the request to the principal's tenant-bound audit service",
            )
        config.audit_log.require_intact()
        config.audit_log.append(
            actor=principal.subject_id,
            action="audit.export.generated",
            resource=f"audit:{tenant_id}",
            decision="PERMIT",
            outcome="COMPLETED",
            correlation_id=correlation_id,
            rule_id="urn:crg:audit:export-completion",
            tenant_id=tenant_id,
            detail={
                "authority": str(authority),
                "after_sequence": after_sequence,
                "limit": limit,
            },
        )
        return config.audit_log.export_page(
            requested_by=principal.subject_id,
            authority=authority,
            after_sequence=after_sequence,
            limit=limit,
            signing_key=config.audit_checkpoint_signing_key,
        )

    # -- disclosure (51, 60) ------------------------------------------------
    def disclosure(self) -> Dict[str, Any]:
        if self.configuration is None:
            record = unconfigured_disclosure()
            record["cryptographic_profile"] = profile_disclosure()
            return record
        record = self.configuration.to_canonical()
        record["cryptographic_profile"] = profile_disclosure()
        return record

    def unmapped_operations(self, operation_ids: Sequence[str]) -> Tuple[str, ...]:
        """Operations with no permission mapping -- each one fails closed (6.6).

        Offered so a deployment can *assert* the set is empty at start-up
        rather than discovering at 3am that a new endpoint denies everybody.
        The answer is the honest one either way: an unmapped operation is
        denied, not allowed.
        """
        return tuple(
            sorted(op for op in operation_ids if operation_permission(str(op)) is None)
        )


def _header(request: Any, name: str) -> str:
    """Case-insensitive header lookup over any mapping-ish request object."""
    headers = getattr(request, "headers", None) or {}
    if not isinstance(headers, Mapping):
        return ""
    wanted = str(name).lower()
    for key, value in headers.items():
        if str(key).lower() == wanted:
            return str(value).strip()
    return ""
