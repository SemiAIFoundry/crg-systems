"""Local accounts, service identities, and the federated-identity adapter.

Normative basis: 44.2 (local accounts, OIDC, SAML where required, service
identities, delegated signing authority), 44.4 (secrets MUST NOT appear in
logs or exports), 44.6 (replayed envelopes, context substitution), 44.7
(audit), 45.1--45.4 (every expiry is judged against a *declared* clock and
reported as one of the six statuses), 6.6 (fail closed), 14.5 (the signature
profile a token is verified under is a value, not an assumption).

Four decisions define this module.

**Nothing here reads the machine clock.**  Every function that could expire
something takes a :class:`~crg_security.clock.Clock` and routes the decision
through :func:`~crg_security.clock.evaluate_validity`, so the answer carries
the verifier's evaluation time, its clock source, and its declared trust level
(45.3).  An ``AuthenticationError`` that cannot say *which clock said so* is
not auditable, and 44.7 makes authentication auditable.

**A password verifier that returns ``True``/``False`` is not enough.**
:meth:`LocalAccountDirectory.authenticate` returns a :class:`Principal` or
raises, and the raise distinguishes *unknown account*, *wrong secret*,
*disabled*, *locked*, and *expired credential* in the audit record while
returning the same opaque refusal to the caller.  The distinction an
investigator needs and the distinction an attacker must not have are different
distinctions, and they are made in different places.

**The federated adapter has explicit production and mock implementations.**
:class:`FederatedIdentityProvider` is the seam an OIDC or SAML deployment
implements.  This module ships :class:`MockOidcProvider` and
:class:`MockSamlProvider`, which validate a **locally issued** assertion
against a **locally held** key set.  They exercise the interface, the clock
discipline, the replay guard, and the claim mapping.  They do not exercise a
real identity provider. :class:`crg_security.oidc.OidcProvider` implements the
production OIDC JWT resource-server path with TLS discovery and rotating JWKS.
There is still no ``state``/``nonce`` round trip with a browser and no SAML XML
canonicalization, and no metadata trust store.  ``LIMITATIONS.md`` states this
in the same words.

**Mock-assertion replay is refused by memory, not by hope.**  A token carries a ``jti``; a
:class:`ReplayGuard` remembers it until its own expiry passes on the supplied
clock.  44.6 lists replay as a threat, and a bearer credential with an expiry
but no single-use record is replayable for the whole of its lifetime.
"""
from __future__ import annotations

import base64
import binascii
import hashlib
import hmac
import json
import os
import secrets
from dataclasses import dataclass, field, replace
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from crg_model.canonical import canonical_bytes

from .clock import Clock, TimeStatus, evaluate_validity, iso, parse_iso
from .errors import (
    AuthenticationError,
    ConfigurationError,
    CredentialExpiredError,
    ReplayError,
)
from .roles import ROLES, permissions_for, unknown_roles
from .signing import (
    HMAC_TEST_PROFILE,
    KeyRing,
    SigningKey,
    VerificationKey,
    get_profile,
)

__all__ = [
    "SubjectKind",
    "AccountStatus",
    "Principal",
    "PasswordPolicy",
    "PasswordHash",
    "hash_password",
    "verify_password",
    "LocalAccount",
    "LocalAccountDirectory",
    "ServiceIdentity",
    "ApiKey",
    "IssuedApiKey",
    "ServiceIdentityDirectory",
    "ReplayGuard",
    "JsonWebKeySet",
    "TokenClaims",
    "FederatedIdentityProvider",
    "MockOidcProvider",
    "MockSamlProvider",
    "IdentityBroker",
    "FEDERATED_ADAPTER_DISCLOSURE",
    "b64u_encode",
    "b64u_decode",
]


# ==========================================================================
# vocabulary
# ==========================================================================
class SubjectKind:
    """What kind of thing is authenticated (44.2)."""

    #: A human, holding a password or a federated assertion.
    USER = "USER"
    #: A machine, holding an API key.  44.2 names service identities
    #: separately from local accounts because they expire, rotate, and are
    #: revoked on different schedules and by different people.
    SERVICE = "SERVICE"
    #: A human authenticated by an external IdP (OIDC/SAML).
    FEDERATED_USER = "FEDERATED_USER"

    ALL = (USER, SERVICE, FEDERATED_USER)


class AccountStatus:
    """Why an account may not authenticate right now."""

    ACTIVE = "ACTIVE"
    DISABLED = "DISABLED"
    LOCKED = "LOCKED"

    ALL = (ACTIVE, DISABLED, LOCKED)


#: Quoted verbatim wherever this package describes itself (51, 60).
FEDERATED_ADAPTER_DISCLOSURE = (
    "MockOidcProvider and MockSamlProvider are MOCK PROVIDERS. They validate a token or "
    "assertion this process issued itself, against a key set this process "
    "holds. They do not use the production OidcProvider. No authorization-code "
    "or browser redirect flow is performed and no "
    "SAML XML signature or canonicalization is processed, and no IdP metadata "
    "trust store exists.  The interface, the clock discipline (45.1-45.4), the "
    "replay guard, and the claim-to-role mapping are real and tested; the "
    "mock identity provider is not."
)


# ==========================================================================
# principals
# ==========================================================================
@dataclass(frozen=True)
class Principal:
    """An authenticated subject, with everything a policy decision needs.

    ``attributes`` is the subject half of 44.2's attribute-based access
    policies; :mod:`crg_security.policy` reads it and nothing else about the
    caller.  Keeping it a plain mapping rather than a fixed schema is
    deliberate -- a deployment's attributes are its own (clearance, business
    unit, geography, contract), and a fixed schema would push them into a
    free-text field that no policy could match on.

    ``authenticated_at`` and ``expires_at`` are ISO-8601 assertions of *this*
    process, and ``clock_source`` says which clock made them, because 45.3
    requires a time judgment to name its clock.
    """

    subject_id: str
    tenant_id: str
    kind: str = SubjectKind.USER
    display_name: str = ""
    roles: Tuple[str, ...] = ()
    attributes: Mapping[str, Any] = field(default_factory=dict)
    authentication_method: str = "unspecified"
    provider_id: str = ""
    session_id: str = ""
    authenticated_at: str = ""
    expires_at: Optional[str] = None
    clock_source: str = ""
    clock_trust_level: str = ""

    def __post_init__(self) -> None:
        if not str(self.subject_id).strip():
            raise ConfigurationError("a principal requires a subject identity (14.1)")
        if not str(self.tenant_id).strip():
            raise ConfigurationError(
                "a principal requires a tenant identity",
                remedy="44.5 makes authentication a tenant-separation layer; an "
                       "untenanted principal has no store it may legitimately reach",
            )
        if self.kind not in SubjectKind.ALL:
            raise ConfigurationError(f"unknown subject kind {self.kind!r}")
        object.__setattr__(self, "roles", tuple(sorted({str(r) for r in self.roles})))
        object.__setattr__(self, "attributes", dict(self.attributes))

    @property
    def permissions(self) -> frozenset:
        """The union of the permissions the held roles grant (44.3)."""
        return permissions_for(self.roles)

    @property
    def undeclared_roles(self) -> Tuple[str, ...]:
        """Roles held that are outside 44.3's thirteen."""
        return unknown_roles(self.roles)

    def with_attributes(self, **extra: Any) -> "Principal":
        merged = dict(self.attributes)
        merged.update(extra)
        return replace(self, attributes=merged)

    def to_canonical(self) -> Dict[str, Any]:
        """A logging-safe description.  No secret ever passes through here."""
        record: Dict[str, Any] = {
            "subject_id": self.subject_id,
            "tenant_id": self.tenant_id,
            "kind": self.kind,
            "roles": list(self.roles),
            "attributes": dict(self.attributes),
            "authentication_method": self.authentication_method,
            "authenticated_at": self.authenticated_at,
            "expires_at": self.expires_at,
        }
        if self.display_name:
            record["display_name"] = self.display_name
        if self.provider_id:
            record["provider_id"] = self.provider_id
        if self.session_id:
            record["session_id"] = self.session_id
        if self.clock_source:
            record["clock_source"] = self.clock_source
            record["clock_trust_level"] = self.clock_trust_level
        return record


# ==========================================================================
# passwords
# ==========================================================================
@dataclass(frozen=True)
class PasswordPolicy:
    """Work factor and shape.  Values, so a deployment can raise them.

    The scrypt parameters are the reason this is a dataclass rather than four
    module constants: a stored hash records the parameters it was produced
    under, so raising the work factor does not invalidate existing hashes and
    :func:`verify_password` keeps verifying them at their own cost.  A scheme
    that could not do that is a scheme whose work factor never rises.
    """

    #: CPU/memory cost.  Must be a power of two (``hashlib.scrypt``).
    n: int = 1 << 14
    #: Block size.
    r: int = 8
    #: Parallelism.
    p: int = 1
    #: Derived-key length in bytes.
    dklen: int = 32
    #: Salt length in bytes.  Per-hash, random, stored in the clear: a salt is
    #: not a secret, it is a defeat of precomputation.
    salt_bytes: int = 16
    minimum_length: int = 12

    def maxmem(self) -> int:
        # 128 * r * n is scrypt's working set; OpenSSL refuses without headroom.
        return 128 * self.r * self.n * 2 + (1 << 20)


DEFAULT_PASSWORD_POLICY = PasswordPolicy()


@dataclass(frozen=True)
class PasswordHash:
    """A stored verifier.  Never the password, and never the pepper.

    The *salt* is stored beside the hash; the *pepper* is not stored at all.
    They defeat different attacks and that is why both are here.  A salt is
    per-record and public, and it defeats a precomputed table shared across
    records.  A pepper is per-deployment and held outside the database -- in
    an environment variable, a KMS, an HSM -- and it means that a stolen
    database alone is not enough to mount an offline guessing attack at all.
    Storing the pepper next to the hash would make it a second salt, which is
    the mistake this docstring exists to prevent.
    """

    algorithm: str
    n: int
    r: int
    p: int
    dklen: int
    salt: bytes
    digest: bytes
    peppered: bool = True

    def __repr__(self) -> str:  # 44.4: not in logs, not in a dataclass repr
        return (
            f"PasswordHash(algorithm={self.algorithm!r}, n={self.n}, r={self.r}, "
            f"p={self.p}, salt=<{len(self.salt)} bytes>, digest=<redacted>)"
        )

    def to_canonical(self) -> Dict[str, Any]:
        """Serializable form.  The digest is included; the pepper is not.

        This is what a deployment writes to its account table.  It is *not*
        safe to publish -- see :func:`crg_security.audit.scrub_secrets`, which
        removes anything whose field name looks like this.
        """
        return {
            "algorithm": self.algorithm,
            "n": self.n,
            "r": self.r,
            "p": self.p,
            "dklen": self.dklen,
            "salt": base64.b64encode(self.salt).decode("ascii"),
            "digest": base64.b64encode(self.digest).decode("ascii"),
            "peppered": self.peppered,
        }

    @classmethod
    def from_canonical(cls, record: Mapping[str, Any]) -> "PasswordHash":
        return cls(
            algorithm=str(record["algorithm"]),
            n=int(record["n"]),
            r=int(record["r"]),
            p=int(record["p"]),
            dklen=int(record["dklen"]),
            salt=base64.b64decode(str(record["salt"])),
            digest=base64.b64decode(str(record["digest"])),
            peppered=bool(record.get("peppered", True)),
        )


def _pepper_bytes(pepper: Optional[bytes]) -> bytes:
    if pepper is None:
        return b""
    if isinstance(pepper, str):
        return pepper.encode("utf-8")
    return bytes(pepper)


def hash_password(
    password: str,
    *,
    pepper: Optional[bytes] = None,
    policy: PasswordPolicy = DEFAULT_PASSWORD_POLICY,
    salt: Optional[bytes] = None,
) -> PasswordHash:
    """Derive a stored verifier with ``hashlib.scrypt`` (44.2).

    scrypt rather than PBKDF2 because the attacker's advantage over the
    defender is hardware parallelism, and scrypt's cost is memory as well as
    CPU.  Standard library rather than argon2 because 9.2 asks the trusted
    computing base to be dependency-light and ``hashlib.scrypt`` is present in
    every CPython 3.6+ built against OpenSSL 1.1+.

    The pepper is mixed by HMAC *before* the KDF rather than concatenated with
    the password, so a pepper of any length contributes its full entropy and
    cannot be confused with the password bytes by a length-extension or a
    delimiter ambiguity.
    """
    if not isinstance(password, str) or len(password) < policy.minimum_length:
        raise ConfigurationError(
            f"a password must be at least {policy.minimum_length} characters",
            remedy="raise or lower PasswordPolicy.minimum_length on purpose, not by accident",
        )
    salt_value = salt if salt is not None else os.urandom(policy.salt_bytes)
    pepper_value = _pepper_bytes(pepper)
    material = password.encode("utf-8")
    if pepper_value:
        material = hmac.new(pepper_value, material, hashlib.sha256).digest()
    digest = hashlib.scrypt(
        material,
        salt=salt_value,
        n=policy.n,
        r=policy.r,
        p=policy.p,
        dklen=policy.dklen,
        maxmem=policy.maxmem(),
    )
    return PasswordHash(
        algorithm="scrypt",
        n=policy.n,
        r=policy.r,
        p=policy.p,
        dklen=policy.dklen,
        salt=salt_value,
        digest=digest,
        peppered=bool(pepper_value),
    )


def verify_password(
    password: str, stored: PasswordHash, *, pepper: Optional[bytes] = None
) -> bool:
    """Constant-time comparison against a stored verifier.

    Recomputes at the parameters *the stored hash records*, not at the current
    policy, so a work-factor increase does not lock out existing accounts.
    """
    if not isinstance(stored, PasswordHash):
        raise ConfigurationError("verify_password requires a PasswordHash")
    if stored.algorithm != "scrypt":
        raise ConfigurationError(f"unknown password algorithm {stored.algorithm!r}")
    pepper_value = _pepper_bytes(pepper)
    if stored.peppered and not pepper_value:
        # Refuse rather than silently fail every login: a deployment that lost
        # its pepper has an operational incident, not a wave of bad passwords.
        raise ConfigurationError(
            "this password hash was peppered and no pepper was supplied",
            remedy="restore the deployment pepper from its key store; without it these "
                   "hashes cannot be verified, which is the property the pepper buys",
        )
    material = password.encode("utf-8")
    if pepper_value:
        material = hmac.new(pepper_value, material, hashlib.sha256).digest()
    candidate = hashlib.scrypt(
        material,
        salt=stored.salt,
        n=stored.n,
        r=stored.r,
        p=stored.p,
        dklen=stored.dklen,
        maxmem=PasswordPolicy(n=stored.n, r=stored.r, p=stored.p).maxmem(),
    )
    return hmac.compare_digest(candidate, stored.digest)


# ==========================================================================
# local accounts (44.2)
# ==========================================================================
@dataclass
class LocalAccount:
    """One local account.  Mutable, because status and counters move."""

    account_id: str
    tenant_id: str
    username: str
    password_hash: PasswordHash
    roles: Tuple[str, ...] = ()
    attributes: Mapping[str, Any] = field(default_factory=dict)
    display_name: str = ""
    status: str = AccountStatus.ACTIVE
    created_at: str = ""
    credential_not_before: Optional[str] = None
    credential_not_after: Optional[str] = None
    failed_attempts: int = 0
    last_authenticated_at: Optional[str] = None

    def __repr__(self) -> str:  # 44.4
        return (
            f"LocalAccount(account_id={self.account_id!r}, tenant_id={self.tenant_id!r}, "
            f"username={self.username!r}, status={self.status!r}, "
            f"roles={list(self.roles)!r}, password_hash=<redacted>)"
        )

    def to_canonical(self) -> Dict[str, Any]:
        """Everything but the verifier.  Safe to log (44.4)."""
        return {
            "account_id": self.account_id,
            "tenant_id": self.tenant_id,
            "username": self.username,
            "display_name": self.display_name,
            "roles": list(self.roles),
            "attributes": dict(self.attributes),
            "status": self.status,
            "created_at": self.created_at,
            "credential_not_before": self.credential_not_before,
            "credential_not_after": self.credential_not_after,
            "failed_attempts": self.failed_attempts,
            "last_authenticated_at": self.last_authenticated_at,
        }


class LocalAccountDirectory:
    """A tenant-scoped set of local accounts (44.2, 44.5).

    Tenant-scoped at construction, not per call.  44.5 requires separation at
    authentication, and a directory that took a tenant argument on every
    lookup would be one forgotten argument away from a cross-tenant login.
    Here there is no argument to forget: the directory *is* the tenant's.

    ``pepper`` is held by the directory and never written into an account
    record.  If it is lost, every account in this directory becomes
    unverifiable -- which is the property it exists to provide, stated plainly
    so nobody is surprised by it.
    """

    def __init__(
        self,
        *,
        tenant_id: str,
        clock: Clock,
        pepper: Optional[bytes] = None,
        policy: PasswordPolicy = DEFAULT_PASSWORD_POLICY,
        max_failed_attempts: int = 5,
    ) -> None:
        if not str(tenant_id).strip():
            raise ConfigurationError(
                "an account directory is tenant-scoped and requires a tenant id (44.5)"
            )
        if clock is None:
            raise ConfigurationError(
                "an account directory requires a supplied clock",
                remedy="45.3: an expiry decision must be able to name the clock that made it",
            )
        self.tenant_id = str(tenant_id)
        self._clock = clock
        self._pepper = _pepper_bytes(pepper)
        self._policy = policy
        self._max_failed = int(max_failed_attempts)
        self._by_username: Dict[str, LocalAccount] = {}
        self._by_id: Dict[str, LocalAccount] = {}

    # -- registration -------------------------------------------------------
    def create_account(
        self,
        *,
        username: str,
        password: str,
        roles: Sequence[str] = (),
        attributes: Optional[Mapping[str, Any]] = None,
        display_name: str = "",
        account_id: str = "",
        credential_not_before: Optional[str] = None,
        credential_not_after: Optional[str] = None,
    ) -> LocalAccount:
        key = str(username).strip().lower()
        if not key:
            raise ConfigurationError("an account requires a username")
        if key in self._by_username:
            raise ConfigurationError(
                f"username {username!r} already exists in tenant {self.tenant_id!r}"
            )
        unknown = unknown_roles(roles)
        if unknown:
            raise ConfigurationError(
                f"account {username!r} was given roles outside 44.3: {list(unknown)}",
                remedy=f"44.3 declares exactly these thirteen: {list(ROLES)}",
            )
        account = LocalAccount(
            account_id=str(account_id or f"acct-{secrets.token_hex(8)}"),
            tenant_id=self.tenant_id,
            username=key,
            password_hash=hash_password(
                password, pepper=self._pepper or None, policy=self._policy
            ),
            roles=tuple(sorted({str(r) for r in roles})),
            attributes=dict(attributes or {}),
            display_name=str(display_name or username),
            created_at=iso(self._clock.now()),
            credential_not_before=credential_not_before,
            credential_not_after=credential_not_after,
        )
        self._by_username[key] = account
        self._by_id[account.account_id] = account
        return account

    def get(self, username: str) -> Optional[LocalAccount]:
        return self._by_username.get(str(username).strip().lower())

    def by_id(self, account_id: str) -> Optional[LocalAccount]:
        return self._by_id.get(str(account_id))

    def usernames(self) -> Tuple[str, ...]:
        return tuple(sorted(self._by_username))

    def set_status(self, username: str, status: str) -> LocalAccount:
        if status not in AccountStatus.ALL:
            raise ConfigurationError(f"unknown account status {status!r}")
        account = self._require(username)
        account.status = status
        if status == AccountStatus.ACTIVE:
            account.failed_attempts = 0
        return account

    def set_password(self, username: str, password: str) -> LocalAccount:
        account = self._require(username)
        account.password_hash = hash_password(
            password, pepper=self._pepper or None, policy=self._policy
        )
        return account

    def _require(self, username: str) -> LocalAccount:
        account = self.get(username)
        if account is None:
            raise ConfigurationError(
                f"no account {username!r} in tenant {self.tenant_id!r}"
            )
        return account

    # -- authentication -----------------------------------------------------
    def authenticate(
        self, username: str, password: str, *, clock: Optional[Clock] = None
    ) -> Principal:
        """Return a :class:`Principal` or raise.  Never returns ``False``.

        The refusal is deliberately uniform to the caller -- an unknown
        username and a wrong password produce the same message and the same
        status -- while the ``detail`` mapping carries the distinguishing
        reason for the audit record.  An attacker enumerating usernames learns
        nothing; an operator reading :mod:`crg_security.audit` learns
        everything.

        A dummy scrypt derivation runs on the unknown-account path so that the
        two cases also take comparable time.  It is not a constant-time
        guarantee -- Python is not the place to claim one -- and it is here
        because the alternative, returning immediately, is a *loud* oracle.
        """
        judge = clock or self._clock
        key = str(username).strip().lower()
        account = self._by_username.get(key)
        if account is None:
            hash_password(
                "0" * self._policy.minimum_length,
                pepper=self._pepper or None,
                policy=self._policy,
            )
            raise AuthenticationError(
                "authentication failed",
                remedy="check the username and password, or ask an administrator "
                       "whether the account exists in this tenant",
                detail={
                    "reason": "no such account in this tenant",
                    "tenant_id": self.tenant_id,
                    **judge.declaration(),
                },
            )
        if account.status != AccountStatus.ACTIVE:
            raise AuthenticationError(
                "authentication failed",
                remedy=f"the account is {account.status}; an administrator must restore it",
                detail={
                    "reason": f"account status is {account.status}",
                    "subject_id": account.account_id,
                    **judge.declaration(),
                },
            )

        judgment = evaluate_validity(
            judge,
            not_before=account.credential_not_before,
            not_after=account.credential_not_after,
        )
        if judgment.status == TimeStatus.EXPIRED:
            raise CredentialExpiredError(
                "this credential has expired",
                remedy="an administrator must reissue it; an expired credential is not "
                       "accepted with a warning (6.6)",
                detail={"subject_id": account.account_id, **judgment.to_canonical()},
            )
        if judgment.status != TimeStatus.CURRENT:
            raise AuthenticationError(
                f"this credential is not currently valid ({judgment.status})",
                remedy=judgment.reason or "45.4: only CURRENT supports an affirmative answer",
                detail={"subject_id": account.account_id, **judgment.to_canonical()},
            )

        if not verify_password(password, account.password_hash, pepper=self._pepper or None):
            account.failed_attempts += 1
            if account.failed_attempts >= self._max_failed:
                account.status = AccountStatus.LOCKED
            raise AuthenticationError(
                "authentication failed",
                remedy="check the username and password",
                detail={
                    "reason": "password verifier did not match",
                    "subject_id": account.account_id,
                    "failed_attempts": account.failed_attempts,
                    "locked": account.status == AccountStatus.LOCKED,
                    **judge.declaration(),
                },
            )

        account.failed_attempts = 0
        account.last_authenticated_at = iso(judge.now())
        return Principal(
            subject_id=account.account_id,
            tenant_id=account.tenant_id,
            kind=SubjectKind.USER,
            display_name=account.display_name,
            roles=account.roles,
            attributes=dict(account.attributes),
            authentication_method="local-password-scrypt",
            provider_id="local",
            session_id=f"sess-{secrets.token_hex(8)}",
            authenticated_at=iso(judge.now()),
            expires_at=account.credential_not_after,
            clock_source=judge.source,
            clock_trust_level=judge.trust_level,
        )


# ==========================================================================
# service identities and API keys (44.2)
# ==========================================================================
@dataclass(frozen=True)
class ServiceIdentity:
    """A non-human principal (44.2).

    ``delegated_signing_key_id`` is 44.2's *delegated signing authority* made
    explicit: a service does not hold "the" signing key, it holds a named
    delegation that can be listed, audited, and withdrawn without touching any
    other service.
    """

    service_id: str
    tenant_id: str
    display_name: str = ""
    roles: Tuple[str, ...] = ()
    attributes: Mapping[str, Any] = field(default_factory=dict)
    delegated_signing_key_id: str = ""

    def __post_init__(self) -> None:
        object.__setattr__(self, "roles", tuple(sorted({str(r) for r in self.roles})))
        object.__setattr__(self, "attributes", dict(self.attributes))

    def to_canonical(self) -> Dict[str, Any]:
        record: Dict[str, Any] = {
            "service_id": self.service_id,
            "tenant_id": self.tenant_id,
            "display_name": self.display_name,
            "roles": list(self.roles),
            "attributes": dict(self.attributes),
        }
        if self.delegated_signing_key_id:
            record["delegated_signing_key_id"] = self.delegated_signing_key_id
        return record


@dataclass
class ApiKey:
    """The *stored* half of an API key.  Never the secret.

    An API key is a high-entropy bearer secret, so the KDF question is
    different from a password's: there is no dictionary to attack, and a
    per-request scrypt derivation would be a denial-of-service surface a
    service identity hits on every call.  SHA-256 over the full 256-bit secret
    with a per-key salt is the right trade here, and the reason is written
    down so that nobody "fixes" it into scrypt without understanding what they
    are paying for -- or, worse, "fixes" the password path into SHA-256
    because this one is.
    """

    key_id: str
    service_id: str
    tenant_id: str
    salt: bytes
    digest: bytes
    issued_at: str
    not_after: Optional[str] = None
    revoked: bool = False
    revocation_reason: str = ""
    last_used_at: Optional[str] = None

    def __repr__(self) -> str:  # 44.4
        return (
            f"ApiKey(key_id={self.key_id!r}, service_id={self.service_id!r}, "
            f"revoked={self.revoked}, digest=<redacted>)"
        )

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "key_id": self.key_id,
            "service_id": self.service_id,
            "tenant_id": self.tenant_id,
            "issued_at": self.issued_at,
            "not_after": self.not_after,
            "revoked": self.revoked,
            "revocation_reason": self.revocation_reason,
            "last_used_at": self.last_used_at,
        }


@dataclass(frozen=True)
class IssuedApiKey:
    """What issuance returns: the record, and the secret, exactly once.

    Two fields rather than one because the secret must be handed to a caller
    and must not be stored.  Returning a tuple would have let a caller keep
    the whole object in a variable and log it; this shape makes the secret a
    named field that :func:`crg_security.audit.scrub_secrets` removes and that
    ``__repr__`` hides.
    """

    record: ApiKey
    secret: str

    def __repr__(self) -> str:  # 44.4
        return f"IssuedApiKey(record={self.record!r}, secret=<shown once, not stored>)"

    @property
    def presentation(self) -> str:
        """The value a client sends: ``<key_id>.<secret>``.

        The key id travels in the clear so the server can find *one* record to
        compare against, rather than comparing the presented secret against
        every stored digest -- which is both slow and, since the comparison
        would short-circuit differently per record, a timing oracle.
        """
        return f"{self.record.key_id}.{self.secret}"


class ServiceIdentityDirectory:
    """Tenant-scoped service identities and their API keys (44.2, 44.5)."""

    #: Bytes of entropy in an issued secret.  256 bits: an API key is not
    #: guessed offline from a stolen database, it is guessed online against a
    #: live endpoint, and 256 bits ends that conversation.
    SECRET_BYTES = 32

    def __init__(self, *, tenant_id: str, clock: Clock) -> None:
        if not str(tenant_id).strip():
            raise ConfigurationError(
                "a service directory is tenant-scoped and requires a tenant id (44.5)"
            )
        if clock is None:
            raise ConfigurationError("a service directory requires a supplied clock (45.3)")
        self.tenant_id = str(tenant_id)
        self._clock = clock
        self._services: Dict[str, ServiceIdentity] = {}
        self._keys: Dict[str, ApiKey] = {}

    def register_service(
        self,
        *,
        service_id: str,
        roles: Sequence[str] = (),
        display_name: str = "",
        attributes: Optional[Mapping[str, Any]] = None,
        delegated_signing_key_id: str = "",
    ) -> ServiceIdentity:
        unknown = unknown_roles(roles)
        if unknown:
            raise ConfigurationError(
                f"service {service_id!r} was given roles outside 44.3: {list(unknown)}"
            )
        service = ServiceIdentity(
            service_id=str(service_id),
            tenant_id=self.tenant_id,
            display_name=str(display_name or service_id),
            roles=tuple(roles),
            attributes=dict(attributes or {}),
            delegated_signing_key_id=str(delegated_signing_key_id),
        )
        self._services[service.service_id] = service
        return service

    def get_service(self, service_id: str) -> Optional[ServiceIdentity]:
        return self._services.get(str(service_id))

    def issue_api_key(
        self, service_id: str, *, not_after: Optional[str] = None, key_id: str = ""
    ) -> IssuedApiKey:
        service = self._services.get(str(service_id))
        if service is None:
            raise ConfigurationError(
                f"no service identity {service_id!r} in tenant {self.tenant_id!r}"
            )
        secret = secrets.token_urlsafe(self.SECRET_BYTES)
        salt = os.urandom(16)
        record = ApiKey(
            key_id=str(key_id or f"key-{secrets.token_hex(6)}"),
            service_id=service.service_id,
            tenant_id=self.tenant_id,
            salt=salt,
            digest=hashlib.sha256(salt + secret.encode("utf-8")).digest(),
            issued_at=iso(self._clock.now()),
            not_after=not_after,
        )
        self._keys[record.key_id] = record
        return IssuedApiKey(record=record, secret=secret)

    def revoke_api_key(self, key_id: str, *, reason: str = "") -> ApiKey:
        record = self._keys.get(str(key_id))
        if record is None:
            raise ConfigurationError(f"no API key {key_id!r} to revoke")
        record.revoked = True
        record.revocation_reason = reason or "unspecified"
        return record

    def api_keys(self) -> Tuple[ApiKey, ...]:
        return tuple(self._keys[k] for k in sorted(self._keys))

    def authenticate_api_key(
        self, presentation: str, *, clock: Optional[Clock] = None
    ) -> Principal:
        """Authenticate ``<key_id>.<secret>`` and return a service principal."""
        judge = clock or self._clock
        key_id, _, secret = str(presentation).partition(".")
        record = self._keys.get(key_id)
        if record is None or not secret:
            raise AuthenticationError(
                "API key authentication failed",
                remedy="present '<key_id>.<secret>' exactly as issued",
                detail={"reason": "unknown or malformed key id", **judge.declaration()},
            )
        if record.revoked:
            raise AuthenticationError(
                "API key authentication failed",
                remedy=f"this key was revoked ({record.revocation_reason}); issue a new one",
                detail={
                    "reason": "key revoked",
                    "key_id": record.key_id,
                    **judge.declaration(),
                },
            )
        judgment = evaluate_validity(judge, not_after=record.not_after)
        if judgment.status == TimeStatus.EXPIRED:
            raise CredentialExpiredError(
                "this API key has expired",
                remedy="issue a new key; 45.4 EXPIRED is a refusal, not a warning",
                detail={"key_id": record.key_id, **judgment.to_canonical()},
            )
        if judgment.status != TimeStatus.CURRENT:
            raise AuthenticationError(
                f"this API key is not currently valid ({judgment.status})",
                remedy=judgment.reason,
                detail={"key_id": record.key_id, **judgment.to_canonical()},
            )
        expected = hashlib.sha256(record.salt + secret.encode("utf-8")).digest()
        if not hmac.compare_digest(expected, record.digest):
            raise AuthenticationError(
                "API key authentication failed",
                remedy="present the secret exactly as issued",
                detail={
                    "reason": "secret did not match",
                    "key_id": record.key_id,
                    **judge.declaration(),
                },
            )
        service = self._services[record.service_id]
        record.last_used_at = iso(judge.now())
        attributes = dict(service.attributes)
        if service.delegated_signing_key_id:
            attributes["delegated_signing_key_id"] = service.delegated_signing_key_id
        return Principal(
            subject_id=service.service_id,
            tenant_id=service.tenant_id,
            kind=SubjectKind.SERVICE,
            display_name=service.display_name,
            roles=service.roles,
            attributes=attributes,
            authentication_method="api-key-sha256",
            provider_id="local-service-directory",
            session_id=record.key_id,
            authenticated_at=iso(judge.now()),
            expires_at=record.not_after,
            clock_source=judge.source,
            clock_trust_level=judge.trust_level,
        )


# ==========================================================================
# replay
# ==========================================================================
class ReplayGuard:
    """Single-use enforcement for token identifiers (44.6).

    An expiry alone does not stop replay: a stolen token with fifteen minutes
    left is a stolen token that works fifteen more times.  This remembers each
    ``jti`` until *that token's own* expiry passes on the supplied clock, at
    which point forgetting it is safe because the expiry check now refuses it
    anyway.  The window is bounded by the credential lifetime rather than by a
    fixed retention, which is why the memory does not grow without limit and
    why shortening a token's lifetime shortens the guard's memory with it.

    ``strict_requires_expiry`` (default true) refuses to register a token that
    declares no expiry at all: an eternal single-use token would have to be
    remembered forever, and a guard that quietly forgot it would be a guard
    that quietly permitted a replay.
    """

    def __init__(self, *, clock: Clock, strict_requires_expiry: bool = True) -> None:
        if clock is None:
            raise ConfigurationError("a replay guard requires a supplied clock (45.1)")
        self._clock = clock
        self._seen: Dict[str, Optional[Any]] = {}
        self._strict = bool(strict_requires_expiry)

    def __len__(self) -> int:
        self._sweep()
        return len(self._seen)

    def _sweep(self) -> None:
        now = self._clock.now()
        for jti in [k for k, exp in self._seen.items() if exp is not None and exp <= now]:
            del self._seen[jti]

    def register(self, jti: str, *, expires_at: Optional[str] = None) -> None:
        """Record first use, or raise :class:`ReplayError` on a second."""
        # Stripped, because a ``jti`` of ``" "`` is not an identifier: it is a
        # missing identifier that happens to be truthy, and admitting it would
        # let every token in a batch share one "unique" id.
        token_id = str(jti).strip()
        if not token_id:
            raise AuthenticationError(
                "this credential carries no jti and cannot be checked for replay",
                remedy="44.6 lists replayed envelopes as a threat; issue tokens with a "
                       "unique identifier",
            )
        self._sweep()
        if token_id in self._seen:
            raise ReplayError(
                f"credential {token_id!r} has already been presented",
                remedy="a single-use credential is single-use; obtain a fresh one",
                detail={"jti": token_id, **self._clock.declaration()},
            )
        expiry = parse_iso(expires_at) if expires_at else None
        if expiry is None and self._strict:
            raise AuthenticationError(
                f"credential {token_id!r} declares no parseable expiry",
                remedy="a single-use credential without an expiry would have to be "
                       "remembered forever; issue tokens with 'exp'",
                detail={"jti": token_id},
            )
        self._seen[token_id] = expiry

    def seen(self, jti: str) -> bool:
        self._sweep()
        return str(jti) in self._seen


# ==========================================================================
# tokens: base64url, JWKS-like key sets, and the adapter interface
# ==========================================================================
def b64u_encode(data: bytes) -> str:
    """Unpadded base64url (RFC 4648 section 5), as JOSE uses it."""
    return base64.urlsafe_b64encode(bytes(data)).rstrip(b"=").decode("ascii")


def b64u_decode(value: str) -> bytes:
    """Decode unpadded base64url, refusing rather than guessing on garbage."""
    text = str(value)
    padding = "=" * (-len(text) % 4)
    try:
        return base64.urlsafe_b64decode(text + padding)
    except (binascii.Error, ValueError) as exc:
        raise AuthenticationError(
            "a token segment is not valid base64url",
            remedy="the credential is malformed; it is refused rather than repaired",
            detail={"decode_error": str(exc)},
        ) from exc


#: JOSE ``alg`` names for the signature profiles this package implements.
#: The mapping is explicit and closed for the same reason
#: :func:`crg_security.signing.get_profile` is: an ``alg`` a verifier does not
#: implement must be refused, never approximated.  In particular ``none`` is
#: absent, which is the oldest JWT vulnerability there is.
_ALG_TO_PROFILE: Dict[str, str] = {
    "EdDSA": "Ed25519",
    "HS256": HMAC_TEST_PROFILE,
}
_PROFILE_TO_ALG: Dict[str, str] = {v: k for k, v in _ALG_TO_PROFILE.items()}


class JsonWebKeySet:
    """A JWKS-*like* key set: the verifier's closed world of token keys.

    "Like", not "is".  A real OIDC verifier fetches this document from the
    provider's ``jwks_uri`` over TLS, caches it, and rotates on ``kid`` miss.
    Here it wraps a :class:`~crg_security.signing.KeyRing` the process already
    holds.  The *shape* -- keys addressed by ``kid``, an unknown ``kid``
    refused, a revoked key refused even though the mathematics would pass --
    is the shape a real one must have, and it is what the tests exercise.

    :meth:`to_public_document` deliberately refuses to publish the material of
    a symmetric key: publishing it would let every reader forge every token
    the set verifies.  It publishes the opaque key reference instead, together
    with a warning naming the profile as test-only.
    """

    def __init__(self, keys: Iterable[VerificationKey] = (), *, issuer: str = "") -> None:
        self._ring = KeyRing(keys)
        self.issuer = str(issuer)

    @property
    def ring(self) -> KeyRing:
        return self._ring

    def add(self, key: VerificationKey) -> "JsonWebKeySet":
        self._ring.add(key)
        return self

    def revoke(self, kid: str, *, reason: str = "") -> None:
        self._ring.revoke(str(kid), reason=reason)

    def get(self, kid: str) -> VerificationKey:
        key = self._ring.get(str(kid))
        if key is None:
            raise AuthenticationError(
                f"no key {kid!r} in this issuer's key set",
                remedy="the token names a key this verifier does not hold; an unknown "
                       "kid is refused, never resolved by trying another key (6.6)",
                detail={"kid": str(kid), "known_kids": list(self._ring.key_ids)},
            )
        if key.revoked:
            raise AuthenticationError(
                f"key {kid!r} is revoked "
                f"({self._ring.revocation_reason(str(kid)) or 'no reason recorded'})",
                remedy="a revoked key does not authenticate a token regardless of the "
                       "mathematics (44.6)",
                detail={"kid": str(kid)},
            )
        return key

    def to_public_document(self) -> Dict[str, Any]:
        keys: List[Dict[str, Any]] = []
        for kid in self._ring.key_ids:
            key = self._ring.get(kid)
            assert key is not None  # key_ids came from the ring
            profile = get_profile(key.profile)
            entry: Dict[str, Any] = {
                "kid": kid,
                "alg": _PROFILE_TO_ALG.get(key.profile, key.profile),
                "use": "sig",
                "revoked": key.revoked,
            }
            if profile.asymmetric:
                entry["kty"] = "OKP"
                entry["crv"] = "Ed25519"
                entry["x"] = b64u_encode(key.material)
            else:
                entry["kty"] = "oct"
                entry["key_reference"] = key.public_reference
                entry["warning"] = (
                    "symmetric key material is deliberately NOT published: a holder of "
                    "it can forge every token this set verifies (14.5)"
                )
            keys.append(entry)
        return {"keys": keys, "issuer": self.issuer}


@dataclass(frozen=True)
class TokenClaims:
    """The claim set a federated assertion carries, after validation.

    Named for the OIDC ID-token claims because that is what a deployment will
    be mapping from, and carried as a frozen record rather than a raw dict so
    that "which claims did the provider actually assert" is answerable after
    the fact.
    """

    issuer: str
    subject: str
    audience: str
    issued_at: str
    expires_at: str
    not_before: Optional[str] = None
    jti: str = ""
    tenant_id: str = ""
    roles: Tuple[str, ...] = ()
    nonce: str = ""
    extra: Mapping[str, Any] = field(default_factory=dict)

    def to_canonical(self) -> Dict[str, Any]:
        record: Dict[str, Any] = {
            "iss": self.issuer,
            "sub": self.subject,
            "aud": self.audience,
            "iat": self.issued_at,
            "exp": self.expires_at,
            "jti": self.jti,
        }
        if self.not_before:
            record["nbf"] = self.not_before
        if self.tenant_id:
            record["tenant_id"] = self.tenant_id
        if self.roles:
            record["roles"] = list(self.roles)
        if self.nonce:
            record["nonce"] = self.nonce
        record.update({k: v for k, v in self.extra.items() if k not in record})
        return record


class FederatedIdentityProvider:
    """The adapter seam 44.2 asks for: OIDC, and SAML where required.

    A deployment implements :meth:`validate` against its real provider.  The
    contract is narrow on purpose -- credential in, :class:`Principal` out or
    raise -- because every wider contract observed in the wild ends up letting
    the adapter decide authorization as well, and 44.2 keeps identity and
    authorization as separate concerns for the same reason 401 and 403 are
    separate statuses.

    Implementations MUST:

    * judge every time-dependent claim against the ``clock`` argument, never
      an ambient one (45.1, 45.3);
    * refuse a token whose ``alg``/``kid`` they do not implement, rather than
      trying another key (6.6);
    * register the token's ``jti`` with a :class:`ReplayGuard` (44.6); and
    * return a principal whose ``tenant_id`` came from the assertion or from
      an explicit mapping, never a default (44.5).
    """

    #: Stable identifier of this provider in audit records.
    provider_id: str = ""
    #: ``"oidc"`` or ``"saml"``.  44.2 names both.
    protocol: str = ""
    #: Whether this adapter talks to a real IdP.  ``False`` for what ships.
    production: bool = False

    def validate(self, credential: Any, *, clock: Clock) -> Principal:
        raise NotImplementedError  # pragma: no cover - abstract

    def disclosure(self) -> Dict[str, Any]:
        record: Dict[str, Any] = {
            "provider_id": self.provider_id,
            "protocol": self.protocol,
            "production": self.production,
        }
        if not self.production:
            record["disclosure"] = FEDERATED_ADAPTER_DISCLOSURE
        return record


class _LocalAssertionIssuer:
    """Shared machinery for the two mock providers.

    Both mocks issue and validate an assertion signed under a
    :mod:`crg_security.signing` profile and resolved through a
    :class:`JsonWebKeySet`.  Factoring it here keeps the OIDC and SAML mocks
    honest about what they actually differ in -- serialization and claim
    names -- rather than letting one of them accidentally be stricter than the
    other.
    """

    def __init__(
        self,
        *,
        issuer: str,
        audience: str,
        key_set: JsonWebKeySet,
        signing_key: Optional[SigningKey] = None,
        replay_guard: Optional[ReplayGuard] = None,
        role_claim: str = "roles",
        tenant_claim: str = "tenant_id",
        tenant_map: Optional[Mapping[str, str]] = None,
        role_map: Optional[Mapping[str, Sequence[str]]] = None,
        default_tenant: str = "",
        max_clock_skew_seconds: float = 0.0,
    ) -> None:
        if not issuer or not audience:
            raise ConfigurationError(
                "a federated provider requires an issuer and an audience",
                remedy="44.6 lists context substitution as a threat; an assertion minted "
                       "for another audience must be refusable",
            )
        self.issuer = str(issuer)
        self.audience = str(audience)
        self.key_set = key_set
        self._signing_key = signing_key
        self.replay_guard = replay_guard
        self.role_claim = str(role_claim)
        self.tenant_claim = str(tenant_claim)
        self.tenant_map = dict(tenant_map or {})
        self.role_map = {str(k): tuple(v) for k, v in (role_map or {}).items()}
        self.default_tenant = str(default_tenant)
        self.max_clock_skew_seconds = float(max_clock_skew_seconds)

    # -- issuance (mock only) ----------------------------------------------
    @property
    def signing_key(self) -> SigningKey:
        if self._signing_key is None:
            raise ConfigurationError(
                "this provider holds no signing key and cannot issue assertions",
                remedy="a validating-only adapter is the production shape; issuance "
                       "exists so the mock can be tested end to end",
            )
        return self._signing_key

    def _sign_segments(self, signing_input: bytes) -> str:
        profile = get_profile(self.signing_key.profile)
        value = profile.sign_bytes(signing_input, self.signing_key)
        _, _, hexvalue = value.partition(":")
        return b64u_encode(bytes.fromhex(hexvalue))

    def _verify_segments(
        self, signing_input: bytes, signature_segment: str, key: VerificationKey
    ) -> bool:
        profile = get_profile(key.profile)
        raw = b64u_decode(signature_segment)
        return profile.verify_bytes(signing_input, f"{profile.algorithm}:{raw.hex()}", key)

    # -- claim checking -----------------------------------------------------
    def _check_claims(
        self, claims: Mapping[str, Any], *, clock: Clock, expected_nonce: str = ""
    ) -> TokenClaims:
        issuer = str(claims.get("iss") or "")
        if issuer != self.issuer:
            raise AuthenticationError(
                "the assertion was issued by a different issuer",
                remedy=f"this adapter accepts assertions from {self.issuer!r} only; "
                       "44.6 lists context substitution as a threat",
                detail={"asserted_issuer": issuer, "expected_issuer": self.issuer},
            )
        audience = claims.get("aud")
        audiences = (
            [str(a) for a in audience]
            if isinstance(audience, (list, tuple))
            else [str(audience or "")]
        )
        if self.audience not in audiences:
            raise AuthenticationError(
                "the assertion was minted for a different audience",
                remedy=f"this relying party is {self.audience!r}; an assertion issued for "
                       "another service is not a credential here (44.6)",
                detail={"asserted_audience": audiences, "expected_audience": self.audience},
            )
        subject = str(claims.get("sub") or "")
        if not subject:
            raise AuthenticationError(
                "the assertion carries no subject",
                remedy="an unattributable authentication cannot be audited (44.7)",
            )
        if expected_nonce and str(claims.get("nonce") or "") != expected_nonce:
            raise AuthenticationError(
                "the assertion's nonce does not match the one this relying party sent",
                remedy="44.6: a replayed or substituted assertion is refused",
                detail={"expected_nonce": expected_nonce},
            )

        issued_at = str(claims.get("iat") or "")
        expires_at = str(claims.get("exp") or "")
        not_before = claims.get("nbf")
        if not expires_at:
            raise AuthenticationError(
                "the assertion declares no expiry",
                remedy="45.4: a credential with no expiry cannot be judged CURRENT and "
                       "is not accepted as though it were",
            )
        judgment = evaluate_validity(
            clock,
            not_before=str(not_before) if not_before else None,
            not_after=expires_at,
            issued_at=issued_at or None,
            max_clock_skew_seconds=self.max_clock_skew_seconds,
        )
        if judgment.status == TimeStatus.EXPIRED:
            raise CredentialExpiredError(
                "this assertion has expired",
                remedy="obtain a fresh assertion from the identity provider",
                detail={"subject": subject, **judgment.to_canonical()},
            )
        if judgment.status != TimeStatus.CURRENT:
            raise AuthenticationError(
                f"this assertion is not currently valid ({judgment.status})",
                remedy=judgment.reason or "45.4: only CURRENT supports an affirmative answer",
                detail={"subject": subject, **judgment.to_canonical()},
            )

        jti = str(claims.get("jti") or "")
        if self.replay_guard is not None:
            self.replay_guard.register(jti, expires_at=expires_at)

        raw_roles = claims.get(self.role_claim) or ()
        if isinstance(raw_roles, str):
            raw_roles = [raw_roles]
        mapped: List[str] = []
        for claimed in raw_roles:
            mapped.extend(self.role_map.get(str(claimed), (str(claimed),)))

        asserted_tenant = str(claims.get(self.tenant_claim) or "")
        tenant = self.tenant_map.get(asserted_tenant, asserted_tenant) or self.default_tenant
        if not tenant:
            raise AuthenticationError(
                "the assertion carries no tenant and this adapter declares no default",
                remedy="44.5 requires separation at authentication; map the provider's "
                       "organization claim onto a tenant explicitly",
                detail={"tenant_claim": self.tenant_claim},
            )

        reserved = {"iss", "sub", "aud", "iat", "exp", "nbf", "jti", "nonce",
                    self.role_claim, self.tenant_claim}
        return TokenClaims(
            issuer=issuer,
            subject=subject,
            audience=self.audience,
            issued_at=issued_at,
            expires_at=expires_at,
            not_before=str(not_before) if not_before else None,
            jti=jti,
            tenant_id=tenant,
            roles=tuple(sorted(set(mapped))),
            nonce=str(claims.get("nonce") or ""),
            extra={k: v for k, v in claims.items() if k not in reserved},
        )


class MockOidcProvider(FederatedIdentityProvider, _LocalAssertionIssuer):
    """An OIDC adapter validating a **locally issued** ID token (44.2).

    The token is JOSE compact serialization -- ``b64u(header).b64u(payload).
    b64u(signature)`` with the signature computed over the ASCII bytes of the
    first two segments -- so the parsing, the ``alg``/``kid`` resolution, and
    the segment-tampering failure modes are the real ones.  What is *not* real
    is the provider: :meth:`issue` mints the token that :meth:`validate` then
    checks, using a key set this process holds.  See
    :data:`FEDERATED_ADAPTER_DISCLOSURE`.

    Refusals worth naming, because each is a documented JWT attack:

    * ``alg: none`` -- not in :data:`_ALG_TO_PROFILE`, so it is refused at
      resolution rather than reaching a signature check that would trivially
      pass;
    * ``alg`` disagreeing with the resolved key's profile -- refused, because
      "verify an EdDSA token with an HS256 key" is the algorithm-confusion
      attack;
    * unknown ``kid`` -- refused, never retried against another key;
    * a replayed ``jti`` -- refused by :class:`ReplayGuard`;
    * an assertion for another ``aud`` or from another ``iss`` -- refused as
      context substitution (44.6).
    """

    protocol = "oidc"
    production = False

    def __init__(self, *, provider_id: str = "mock-oidc", **kwargs: Any) -> None:
        _LocalAssertionIssuer.__init__(self, **kwargs)
        self.provider_id = str(provider_id)

    # -- mock issuance ------------------------------------------------------
    def issue(
        self,
        *,
        subject: str,
        clock: Clock,
        lifetime_seconds: float = 900.0,
        roles: Sequence[str] = (),
        tenant_id: str = "",
        nonce: str = "",
        not_before: Optional[str] = None,
        jti: str = "",
        audience: Optional[str] = None,
        extra_claims: Optional[Mapping[str, Any]] = None,
    ) -> str:
        """Mint an ID token.  Present only because the provider is a mock."""
        import datetime as _dt

        now = clock.now()
        claims: Dict[str, Any] = {
            "iss": self.issuer,
            "sub": str(subject),
            "aud": str(audience if audience is not None else self.audience),
            "iat": iso(now),
            "exp": iso(now + _dt.timedelta(seconds=float(lifetime_seconds))),
            "jti": str(jti or f"jti-{secrets.token_hex(8)}"),
        }
        if not_before:
            claims["nbf"] = not_before
        if nonce:
            claims["nonce"] = nonce
        if roles:
            claims[self.role_claim] = list(roles)
        if tenant_id:
            claims[self.tenant_claim] = str(tenant_id)
        if extra_claims:
            claims.update(dict(extra_claims))
        header = {
            "alg": _PROFILE_TO_ALG.get(self.signing_key.profile, self.signing_key.profile),
            "typ": "JWT",
            "kid": self.signing_key.key_id,
        }
        segments = (
            b64u_encode(canonical_bytes(header)),
            b64u_encode(canonical_bytes(claims)),
        )
        signing_input = ".".join(segments).encode("ascii")
        return ".".join(segments) + "." + self._sign_segments(signing_input)

    # -- validation ---------------------------------------------------------
    def validate(
        self, credential: Any, *, clock: Clock, expected_nonce: str = ""
    ) -> Principal:
        token = str(credential or "")
        parts = token.split(".")
        if len(parts) != 3 or not all(parts):
            raise AuthenticationError(
                "the bearer token is not a three-segment JOSE compact serialization",
                remedy="the credential is malformed; it is refused rather than repaired",
                detail={"segments": len(parts)},
            )
        header_segment, payload_segment, signature_segment = parts
        try:
            header = json.loads(b64u_decode(header_segment).decode("utf-8"))
            claims = json.loads(b64u_decode(payload_segment).decode("utf-8"))
        except (ValueError, UnicodeDecodeError) as exc:
            raise AuthenticationError(
                "a token segment is not JSON",
                remedy="the credential is malformed; it is refused rather than repaired",
                detail={"decode_error": str(exc)},
            ) from exc
        if not isinstance(header, Mapping) or not isinstance(claims, Mapping):
            raise AuthenticationError("token header and payload must be JSON objects")

        alg = str(header.get("alg") or "")
        profile_name = _ALG_TO_PROFILE.get(alg)
        if profile_name is None:
            raise AuthenticationError(
                f"token algorithm {alg!r} is not implemented by this verifier",
                remedy="an unimplemented alg is refused, never approximated; in "
                       f"particular 'none' is not accepted.  Supported: "
                       f"{sorted(_ALG_TO_PROFILE)}",
                detail={"alg": alg, "supported": sorted(_ALG_TO_PROFILE)},
            )
        key = self.key_set.get(str(header.get("kid") or ""))
        if key.profile != profile_name:
            raise AuthenticationError(
                f"token declares alg {alg!r} but key {key.key_id!r} is a "
                f"{key.profile!r} key",
                remedy="this is algorithm confusion; the verifier refuses rather than "
                       "reinterpreting the key material (14.5)",
                detail={"alg": alg, "key_profile": key.profile},
            )
        signing_input = f"{header_segment}.{payload_segment}".encode("ascii")
        if not self._verify_segments(signing_input, signature_segment, key):
            raise AuthenticationError(
                "the token signature does not verify",
                remedy="the token has been modified or was signed by another key",
                detail={"kid": key.key_id, "alg": alg},
            )

        validated = self._check_claims(claims, clock=clock, expected_nonce=expected_nonce)
        return Principal(
            subject_id=validated.subject,
            tenant_id=validated.tenant_id,
            kind=SubjectKind.FEDERATED_USER,
            display_name=str(validated.extra.get("name") or validated.subject),
            roles=validated.roles,
            attributes={
                k: v for k, v in validated.extra.items()
                if k not in {"name"} and not str(k).startswith("_")
            },
            authentication_method=f"oidc-id-token/{alg}",
            provider_id=self.provider_id,
            session_id=validated.jti,
            authenticated_at=iso(clock.now()),
            expires_at=validated.expires_at,
            clock_source=clock.source,
            clock_trust_level=clock.trust_level,
        )


class MockSamlProvider(FederatedIdentityProvider, _LocalAssertionIssuer):
    """A SAML adapter validating a **locally issued** assertion (44.2).

    44.2 says "SAML where required", and what is required of the *adapter* is
    that a SAML deployment can plug in without the surrounding policy code
    learning a second identity shape.  So this mock speaks the SAML vocabulary
    -- ``Issuer``, ``Subject/NameID``, ``Conditions/NotBefore``,
    ``NotOnOrAfter``, ``AudienceRestriction``, ``AttributeStatement``,
    ``ID`` -- over a canonical **JSON** encoding rather than XML.

    That substitution is the whole of what is faked, and it is the part a real
    integration would find hardest: XML signature verification with exclusive
    canonicalization, XSW (signature-wrapping) defences, and metadata trust
    are precisely the SAML-specific attack surface, and none of it is here.
    ``LIMITATIONS.md`` says so.  What *is* exercised is the claim mapping, the
    condition-window evaluation against a supplied clock, replay refusal on
    ``ID``, and audience restriction.
    """

    protocol = "saml"
    production = False

    def __init__(self, *, provider_id: str = "mock-saml", **kwargs: Any) -> None:
        kwargs.setdefault("role_claim", "Role")
        kwargs.setdefault("tenant_claim", "Organization")
        _LocalAssertionIssuer.__init__(self, **kwargs)
        self.provider_id = str(provider_id)

    def issue(
        self,
        *,
        subject: str,
        clock: Clock,
        lifetime_seconds: float = 300.0,
        attributes: Optional[Mapping[str, Any]] = None,
        assertion_id: str = "",
        audience: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Mint a signed assertion document.  Mock-only, like the OIDC twin."""
        import datetime as _dt

        now = clock.now()
        assertion: Dict[str, Any] = {
            "ID": str(assertion_id or f"_saml-{secrets.token_hex(8)}"),
            "Version": "2.0",
            "IssueInstant": iso(now),
            "Issuer": self.issuer,
            "Subject": {"NameID": str(subject), "Format": "urn:oasis:names:tc:SAML:2.0:nameid-format:persistent"},
            "Conditions": {
                "NotBefore": iso(now),
                "NotOnOrAfter": iso(now + _dt.timedelta(seconds=float(lifetime_seconds))),
                "AudienceRestriction": [str(audience if audience is not None else self.audience)],
            },
            "AttributeStatement": dict(attributes or {}),
        }
        signing_input = canonical_bytes(assertion)
        return {
            "Assertion": assertion,
            "Signature": {
                "kid": self.signing_key.key_id,
                "alg": _PROFILE_TO_ALG.get(
                    self.signing_key.profile, self.signing_key.profile
                ),
                "value": self._sign_segments(signing_input),
                "encoding": "crg-canonical-json (NOT XML DSig -- see LIMITATIONS.md)",
            },
        }

    def validate(self, credential: Any, *, clock: Clock) -> Principal:
        if not isinstance(credential, Mapping):
            raise AuthenticationError(
                "a SAML credential must be an assertion document",
                remedy="pass the mapping returned by MockSamlProvider.issue",
            )
        assertion = credential.get("Assertion")
        signature = credential.get("Signature")
        if not isinstance(assertion, Mapping) or not isinstance(signature, Mapping):
            raise AuthenticationError("the SAML document is missing Assertion or Signature")

        alg = str(signature.get("alg") or "")
        profile_name = _ALG_TO_PROFILE.get(alg)
        if profile_name is None:
            raise AuthenticationError(
                f"assertion algorithm {alg!r} is not implemented by this verifier",
                detail={"alg": alg, "supported": sorted(_ALG_TO_PROFILE)},
            )
        key = self.key_set.get(str(signature.get("kid") or ""))
        if key.profile != profile_name:
            raise AuthenticationError(
                f"assertion declares alg {alg!r} but key {key.key_id!r} is a "
                f"{key.profile!r} key",
                remedy="algorithm confusion is refused (14.5)",
            )
        if not self._verify_segments(
            canonical_bytes(assertion), str(signature.get("value") or ""), key
        ):
            raise AuthenticationError(
                "the assertion signature does not verify",
                remedy="the assertion has been modified or was signed by another key",
                detail={"kid": key.key_id},
            )

        conditions = assertion.get("Conditions") or {}
        if not isinstance(conditions, Mapping):
            raise AuthenticationError("the assertion's Conditions element is malformed")
        subject_element = assertion.get("Subject") or {}
        attributes = assertion.get("AttributeStatement") or {}
        if not isinstance(subject_element, Mapping) or not isinstance(attributes, Mapping):
            raise AuthenticationError("the assertion's Subject or AttributeStatement is malformed")

        claims: Dict[str, Any] = {
            "iss": assertion.get("Issuer"),
            "sub": subject_element.get("NameID"),
            "aud": conditions.get("AudienceRestriction"),
            "iat": assertion.get("IssueInstant"),
            "exp": conditions.get("NotOnOrAfter"),
            "nbf": conditions.get("NotBefore"),
            "jti": assertion.get("ID"),
        }
        claims.update({str(k): v for k, v in attributes.items()})
        validated = self._check_claims(claims, clock=clock)
        return Principal(
            subject_id=validated.subject,
            tenant_id=validated.tenant_id,
            kind=SubjectKind.FEDERATED_USER,
            display_name=str(validated.extra.get("DisplayName") or validated.subject),
            roles=validated.roles,
            attributes={
                k: v for k, v in validated.extra.items() if k != "DisplayName"
            },
            authentication_method=f"saml-assertion/{alg}",
            provider_id=self.provider_id,
            session_id=validated.jti,
            authenticated_at=iso(clock.now()),
            expires_at=validated.expires_at,
            clock_source=clock.source,
            clock_trust_level=clock.trust_level,
        )


# ==========================================================================
# broker
# ==========================================================================
class IdentityBroker:
    """One entry point over local accounts, service keys, and federation.

    A boundary needs a single ``authenticate(credential) -> Principal``, and
    the alternative -- letting each call site pick a directory -- is how a
    deployment ends up with an endpoint that checks API keys but not account
    status.  The broker dispatches on the credential's declared scheme and
    refuses an unknown one, rather than trying each in turn: trying each in
    turn is a credential-confusion oracle and it also makes the audit record
    ambiguous about which mechanism actually succeeded.
    """

    def __init__(
        self,
        *,
        clock: Clock,
        accounts: Optional[LocalAccountDirectory] = None,
        services: Optional[ServiceIdentityDirectory] = None,
        providers: Iterable[FederatedIdentityProvider] = (),
    ) -> None:
        if clock is None:
            raise ConfigurationError("an identity broker requires a supplied clock (45.3)")
        self._clock = clock
        self.accounts = accounts
        self.services = services
        self.providers: Dict[str, FederatedIdentityProvider] = {
            p.provider_id: p for p in providers
        }

    def add_provider(self, provider: FederatedIdentityProvider) -> "IdentityBroker":
        if not isinstance(provider, FederatedIdentityProvider):
            raise ConfigurationError(
                "only FederatedIdentityProvider implementations may be registered"
            )
        if not provider.provider_id:
            raise ConfigurationError("a federated provider requires a provider_id")
        self.providers[provider.provider_id] = provider
        return self

    def authenticate(
        self,
        scheme: str,
        credential: Any,
        *,
        clock: Optional[Clock] = None,
        provider_id: str = "",
        **kwargs: Any,
    ) -> Principal:
        """Dispatch on ``scheme``: ``password``, ``api-key``, or ``federated``."""
        judge = clock or self._clock
        mechanism = str(scheme).strip().lower()
        if mechanism == "password":
            if self.accounts is None:
                raise ConfigurationError(
                    "no local account directory is configured",
                    remedy="construct the broker with accounts=LocalAccountDirectory(...)",
                )
            username, secret = credential
            return self.accounts.authenticate(username, secret, clock=judge)
        if mechanism in {"api-key", "apikey", "bearer-api-key"}:
            if self.services is None:
                raise ConfigurationError(
                    "no service identity directory is configured",
                    remedy="construct the broker with services=ServiceIdentityDirectory(...)",
                )
            return self.services.authenticate_api_key(str(credential), clock=judge)
        if mechanism in {"federated", "oidc", "saml"}:
            provider = self._resolve_provider(mechanism, provider_id)
            return provider.validate(credential, clock=judge, **kwargs)
        raise AuthenticationError(
            f"unknown authentication scheme {scheme!r}",
            remedy="the broker dispatches on a declared scheme rather than trying each "
                   "mechanism in turn, which would be a credential-confusion oracle; "
                   f"known schemes: password, api-key, federated ({sorted(self.providers)})",
            detail={"scheme": str(scheme)},
        )

    def _resolve_provider(
        self, mechanism: str, provider_id: str
    ) -> FederatedIdentityProvider:
        if provider_id:
            provider = self.providers.get(str(provider_id))
            if provider is None:
                raise AuthenticationError(
                    f"no federated provider {provider_id!r} is configured",
                    detail={"known": sorted(self.providers)},
                )
            return provider
        candidates = [
            p for p in self.providers.values()
            if mechanism == "federated" or p.protocol == mechanism
        ]
        if len(candidates) != 1:
            raise ConfigurationError(
                f"{len(candidates)} providers match scheme {mechanism!r}; name one",
                remedy="pass provider_id=; guessing between identity providers would "
                       "make the audit record ambiguous about which one authenticated",
                detail={"known": sorted(self.providers)},
            )
        return candidates[0]

    def disclosure(self) -> Dict[str, Any]:
        """What this broker can actually do, for a release note (51, 60)."""
        return {
            "local_accounts": self.accounts is not None,
            "service_identities": self.services is not None,
            "federated_providers": [p.disclosure() for p in self.providers.values()],
            "password_hash": "scrypt (salted, and peppered when a pepper is configured)",
            "clock_source": self._clock.source,
            "clock_trust_level": self._clock.trust_level,
            "federated_adapter_disclosure": FEDERATED_ADAPTER_DISCLOSURE,
        }
