"""Tenant contexts and store views that make cross-tenant access impossible.

Normative basis: 44.5 (multi-tenant deployments MUST enforce separation at
authentication, authorization, database access, object storage, cache, logs,
jobs, search, metrics, and backups), 44.6 (cross-tenant exposure is a named
threat), 42.1 (content-addressed object storage), 14.4 (algorithm-tagged
hashes), 6.6, 17.2 (tombstones).

The load-bearing sentence of this module is that isolation is **structural,
not checked**.  The difference matters, and it is worth being precise about
what is claimed.

A *checked* design keeps one store and asks, on every read, whether the
caller's tenant matches the object's.  It fails the moment somebody adds a
read path and forgets the check -- and the forgotten check looks exactly like
correct code in review, because the absence of a line is invisible.

A *structural* design gives each tenant a store view that holds a reference to
**its own partition and to nothing else**.  :class:`TenantScopedStore` has no
attribute pointing at the multi-tenant store, no tenant argument on any
method, and no way to name another partition.  Reaching tenant B's data from
tenant A's view is not "blocked"; there is no expression for it.  A new read
method added to the view next year is confined by the same construction,
because the object it reads from is the only one it has.

Two independent properties, so that defeating one does not defeat the other:

* **Partition confinement.**  The view closes over one dict.  Cross-tenant
  reads have no path.
* **Handle divergence.**  An address in this store is not the bare content
  hash.  It is the 14.4 hash of ``{"tenant_id": ..., "content": ...}``, so
  identical content stored by two tenants has two different addresses.  An
  attacker who learns tenant B's handle by any out-of-band means -- a log, a
  bundle, a screenshot -- is holding a string that is not an address in
  tenant A's namespace at all.

The residual risk is stated rather than hidden: a caller with a reference to
the :class:`MultiTenantStore` itself can reach every partition, and so can
anything with filesystem access to the backing store.  That is a *deployment*
boundary, not a language one, and no amount of Python prevents it.  What this
module guarantees is that code holding only a :class:`TenantScopedStore`
cannot cross the line by accident or by omission.  Every method that could be
tempted to take a tenant argument does not have one, and
:class:`TenantIsolationError` guards the few places where a caller could still
present something from elsewhere.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Mapping, Optional, Tuple

from crg_model.canonical import canonical_json, content_hash

from .audit import HashChainedAuditLog
from .clock import Clock, iso
from .errors import ConfigurationError, TenantIsolationError
from .policy import (
    AccessRequest,
    PolicyEngine,
    Resource,
    Subject,
    subject_from_principal,
)

__all__ = [
    "TenantContext",
    "TenantRecord",
    "TenantScopedStore",
    "MultiTenantStore",
    "require_context",
    "SEPARATION_LAYERS",
]

#: 44.5, verbatim and in its order.  :meth:`MultiTenantStore.separation_report`
#: answers each one with what this implementation actually does, including the
#: ones it does not do, because a separation claim with a silent gap is worse
#: than an acknowledged gap.
SEPARATION_LAYERS: Tuple[str, ...] = (
    "authentication",
    "authorization",
    "database access",
    "object storage",
    "cache",
    "logs",
    "jobs",
    "search",
    "metrics",
    "backups",
)


# ==========================================================================
# the context
# ==========================================================================
@dataclass(frozen=True)
class TenantContext:
    """Who is acting, in which tenant, judged by which clock.

    Required for **any** store access.  Not "checked on" store access --
    required to obtain the store object at all: :meth:`MultiTenantStore.view`
    takes one and there is no other way to get a
    :class:`TenantScopedStore`.  A context is therefore not a parameter a
    caller can forget; it is the thing a caller must have in order to have
    anything.

    ``principal`` is the :class:`crg_security.identity.Principal` that
    authenticated, kept so that a store operation can be attributed in the
    audit log (44.7) without the store having to reach back into an identity
    service.
    """

    tenant_id: str
    principal: Any
    clock: Clock
    correlation_id: str = ""
    case_scope: Tuple[str, ...] = ("*",)
    purpose: str = ""

    def __post_init__(self) -> None:
        if not str(self.tenant_id).strip():
            raise TenantIsolationError(
                "a tenant context requires a tenant identity",
                remedy="44.5: an untenanted context has no store it may legitimately reach",
            )
        if self.principal is None:
            raise ConfigurationError(
                "a tenant context requires an authenticated principal",
                remedy="44.7 requires every store operation to be attributable",
            )
        if self.clock is None:
            raise ConfigurationError(
                "a tenant context requires a supplied clock (45.1, 45.3)"
            )
        principal_tenant = str(getattr(self.principal, "tenant_id", "") or "")
        if principal_tenant and principal_tenant != str(self.tenant_id):
            raise TenantIsolationError(
                f"principal {getattr(self.principal, 'subject_id', '?')!r} authenticated "
                f"into tenant {principal_tenant!r} and cannot open a context in tenant "
                f"{self.tenant_id!r}",
                remedy="44.5 separates at authentication; re-authenticate against the "
                       "other tenant's directory if that is really intended",
            )
        object.__setattr__(self, "case_scope", tuple(str(c) for c in self.case_scope))

    @property
    def actor(self) -> str:
        return str(getattr(self.principal, "subject_id", "") or "unattributed")

    @property
    def roles(self) -> Tuple[str, ...]:
        return tuple(getattr(self.principal, "roles", ()) or ())

    def subject(self) -> Subject:
        """The policy subject this context speaks for."""
        base = subject_from_principal(self.principal, case_scope=self.case_scope)
        if self.case_scope != ("*",):
            return Subject(
                subject_id=base.subject_id,
                tenant_id=base.tenant_id,
                roles=base.roles,
                attributes=base.attributes,
                case_scope=self.case_scope,
                kind=base.kind,
            )
        return base

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "tenant_id": self.tenant_id,
            "actor": self.actor,
            "roles": list(self.roles),
            "case_scope": list(self.case_scope),
            "correlation_id": self.correlation_id,
            "purpose": self.purpose,
            "clock_source": self.clock.source,
            "clock_trust_level": self.clock.trust_level,
        }


def require_context(context: Optional[TenantContext]) -> TenantContext:
    """Raise unless a tenant context is present.

    For the boundary code that receives one from outside.  Inside this module
    the requirement is structural; at the edge, where a context arrives as an
    argument that could be ``None``, it has to be a check, and this is the one
    place it is written so that it is not rewritten differently ten times.
    """
    if context is None:
        raise TenantIsolationError(
            "this operation requires a TenantContext and received none",
            remedy="44.5: obtain one from the authenticated principal; there is no "
                   "ambient or default tenant",
        )
    if not isinstance(context, TenantContext):
        raise TenantIsolationError(
            f"expected a TenantContext, received {type(context).__name__}",
            remedy="a duck-typed stand-in would bypass the construction-time checks that "
                   "make a context trustworthy",
        )
    return context


# ==========================================================================
# the partition
# ==========================================================================
@dataclass
class _Partition:
    """One tenant's entire world.  Never handed to another tenant's view.

    A plain container: objects, an index of case ids, a tombstone table, a
    cache, a job table, a search index, a metrics counter, and this tenant's
    own audit log.  The field list is 44.5's separation layers, because a
    partition missing one of them is a deployment that separates nine layers
    and shares the tenth.
    """

    tenant_id: str
    objects: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    tombstones: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    cases: Dict[str, List[str]] = field(default_factory=dict)
    cache: Dict[str, Any] = field(default_factory=dict)
    jobs: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    search: Dict[str, List[str]] = field(default_factory=dict)
    metrics: Dict[str, int] = field(default_factory=dict)
    audit: Optional[HashChainedAuditLog] = None


@dataclass(frozen=True)
class TenantRecord:
    """What a tenant view stores against a handle."""

    handle: str
    tenant_id: str
    object_type: str
    case_id: Optional[str]
    content_hash: str
    created_at: str
    created_by: str
    legal_hold: bool = False

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "handle": self.handle,
            "tenant_id": self.tenant_id,
            "object_type": self.object_type,
            "case_id": self.case_id,
            "content_hash": self.content_hash,
            "created_at": self.created_at,
            "created_by": self.created_by,
            "legal_hold": self.legal_hold,
        }


class TenantScopedStore:
    """A store view bound to exactly one tenant partition (44.5).

    Look at what this class does *not* have: a reference to the multi-tenant
    store, a ``tenant_id`` argument on any method, a way to enumerate other
    partitions, or a constructor a caller would normally invoke.  It is built
    by :meth:`MultiTenantStore.view` and closes over the single
    :class:`_Partition` it was given.

    That is the whole isolation mechanism, and it is worth saying why it is
    stronger than a check: a check must be *present* in every method, so its
    correctness is a property of every future method; a closure is a property
    of the object's construction, so future methods inherit it whether or not
    their author was thinking about tenancy.

    Reads and writes are additionally routed through an optional
    :class:`~crg_security.policy.PolicyEngine`, so 44.5's "separation at
    authorization" and this module's separation at storage are two independent
    layers rather than one layer named twice.
    """

    def __init__(
        self,
        partition: _Partition,
        context: TenantContext,
        *,
        engine: Optional[PolicyEngine] = None,
    ) -> None:
        # Deliberately private and deliberately the only two references held.
        self.__partition = partition
        self.__context = context
        self.__engine = engine
        if partition.tenant_id != context.tenant_id:  # pragma: no cover - constructor invariant
            raise TenantIsolationError(
                "refusing to bind a view to another tenant's partition",
                remedy="this is a construction error in MultiTenantStore.view",
            )

    # -- identity -----------------------------------------------------------
    @property
    def tenant_id(self) -> str:
        return self.__context.tenant_id

    @property
    def context(self) -> TenantContext:
        return self.__context

    def __repr__(self) -> str:
        return (
            f"TenantScopedStore(tenant_id={self.tenant_id!r}, "
            f"actor={self.__context.actor!r}, objects={len(self.__partition.objects)})"
        )

    # -- addressing ---------------------------------------------------------
    def handle_for(self, obj: Any) -> str:
        """The address ``obj`` would have **in this tenant** (14.4).

        Not the bare content hash.  Binding the tenant into the hashed
        structure means the same bytes have different addresses in different
        tenants, so a handle leaked from one tenant is not even syntactically
        an address in another.  The underlying content hash is retained in the
        record, so 14.4's content addressing and 17.2's "the hash survives
        removal" both still hold.
        """
        if hasattr(obj, "to_canonical"):
            obj = obj.to_canonical()
        return content_hash({"tenant_id": self.tenant_id, "content": obj})

    # -- writes -------------------------------------------------------------
    def put_object(
        self,
        obj: Any,
        *,
        object_type: str = "",
        case_id: Optional[str] = None,
        legal_hold: bool = False,
    ) -> str:
        """Store content in this tenant and return its tenant-scoped handle."""
        if hasattr(obj, "to_canonical"):
            obj = obj.to_canonical()
        self._authorize("case:create" if case_id else "case:update", "", case_id)
        handle = self.handle_for(obj)
        partition = self.__partition
        if handle in partition.tombstones:
            raise TenantIsolationError(
                f"handle {handle} is tombstoned in this tenant and cannot be re-stored",
                remedy="17.2: removal is an authorized act and re-submitting the bytes "
                       "does not undo it",
                detail={"tombstone": dict(partition.tombstones[handle])},
            )
        record = TenantRecord(
            handle=handle,
            tenant_id=self.tenant_id,
            object_type=str(object_type or _type_of(obj)),
            case_id=str(case_id) if case_id else None,
            content_hash=content_hash(obj),
            created_at=iso(self.__context.clock.now()),
            created_by=self.__context.actor,
            legal_hold=bool(legal_hold),
        )
        partition.objects[handle] = {
            "record": record,
            "content": obj,
        }
        if case_id:
            partition.cases.setdefault(str(case_id), [])
            if handle not in partition.cases[str(case_id)]:
                partition.cases[str(case_id)].append(handle)
        for token in _tokens(obj):
            partition.search.setdefault(token, [])
            if handle not in partition.search[token]:
                partition.search[token].append(handle)
        partition.metrics["objects_written"] = partition.metrics.get("objects_written", 0) + 1
        self._log("object.stored", handle, "PERMIT", "COMPLETED")
        return handle

    # -- reads --------------------------------------------------------------
    def get_object(self, handle: str) -> Any:
        """Read by handle.  A handle from another tenant is simply not here.

        The refusal is :class:`TenantIsolationError` rather than a not-found,
        and the distinction is deliberate: the caller learns that the address
        is not addressable *by them*, and the audit record distinguishes an
        attempted crossing from a stale reference.  What the caller does not
        learn is whether the handle exists somewhere else, because this view
        cannot see anywhere else and so has nothing to leak.
        """
        key = str(handle)
        partition = self.__partition
        entry = partition.objects.get(key)
        if entry is None:
            if key in partition.tombstones:
                raise TenantIsolationError(
                    f"object {key} was removed under authority in this tenant (17.2)",
                    remedy="the tombstone preserves identity, hash, type, and dependency "
                           "structure",
                    detail={"tombstone": dict(partition.tombstones[key])},
                )
            self._log("object.read", key, "DENY", "REFUSED")
            raise TenantIsolationError(
                f"no object {key} is addressable in tenant {self.tenant_id!r}",
                remedy="a handle is the hash of {tenant_id, content}; an address from "
                       "another tenant is not an address here, and this view holds no "
                       "reference to any other tenant's partition (44.5)",
                detail={"tenant_id": self.tenant_id, "handle": key},
            )
        record: TenantRecord = entry["record"]
        self._authorize("case:read", key, record.case_id)
        partition.metrics["objects_read"] = partition.metrics.get("objects_read", 0) + 1
        self._log("object.read", key, "PERMIT", "COMPLETED")
        return entry["content"]

    def metadata(self, handle: str) -> TenantRecord:
        entry = self.__partition.objects.get(str(handle))
        if entry is None:
            raise TenantIsolationError(
                f"no object {handle} is addressable in tenant {self.tenant_id!r}"
            )
        return entry["record"]

    def has_object(self, handle: str) -> bool:
        return str(handle) in self.__partition.objects

    def handles(self) -> Tuple[str, ...]:
        return tuple(sorted(self.__partition.objects))

    def case_handles(self, case_id: str) -> Tuple[str, ...]:
        if not self.__context_may_reach(case_id):
            raise TenantIsolationError(
                f"case {case_id!r} is outside this context's case scope "
                f"{list(self.__context.case_scope)} (44.2)",
            )
        return tuple(self.__partition.cases.get(str(case_id), ()))

    def cases(self) -> Tuple[str, ...]:
        return tuple(
            c for c in sorted(self.__partition.cases) if self.__context_may_reach(c)
        )

    # -- the other 44.5 layers ---------------------------------------------
    def cache_put(self, key: str, value: Any) -> None:
        self.__partition.cache[str(key)] = value

    def cache_get(self, key: str, default: Any = None) -> Any:
        return self.__partition.cache.get(str(key), default)

    def submit_job(self, job_id: str, record: Mapping[str, Any]) -> str:
        self.__partition.jobs[str(job_id)] = {
            **dict(record),
            "tenant_id": self.tenant_id,
            "submitted_by": self.__context.actor,
        }
        return str(job_id)

    def job(self, job_id: str) -> Optional[Dict[str, Any]]:
        return self.__partition.jobs.get(str(job_id))

    def jobs(self) -> Tuple[str, ...]:
        return tuple(sorted(self.__partition.jobs))

    def search(self, token: str) -> Tuple[str, ...]:
        return tuple(self.__partition.search.get(str(token).lower(), ()))

    def metrics(self) -> Dict[str, int]:
        return dict(self.__partition.metrics)

    @property
    def audit(self) -> HashChainedAuditLog:
        """This tenant's own audit log (44.5: logs are a separation layer)."""
        log = self.__partition.audit
        if log is None:  # pragma: no cover - MultiTenantStore always supplies one
            raise ConfigurationError("this partition has no audit log")
        return log

    # -- removal ------------------------------------------------------------
    def tombstone(
        self, handle: str, *, reason: str, authority: str, removal_status: str = "REDACTED"
    ) -> Dict[str, Any]:
        """Remove content, keep identity, hash, type, and structure (17.2).

        The content is dropped from the partition; the record stays as a
        tombstone carrying every field 17.2 permits.  This is the *content
        removal* half of the story; :mod:`crg_security.encryption` implements
        17.4's cryptographic erasure, which reaches the same visible state by
        destroying a key instead.
        """
        key = str(handle)
        entry = self.__partition.objects.get(key)
        if entry is None:
            raise TenantIsolationError(
                f"no object {key} is addressable in tenant {self.tenant_id!r}"
            )
        record: TenantRecord = entry["record"]
        if record.legal_hold:
            from .errors import LegalHoldError

            raise LegalHoldError(
                f"object {key} is under legal hold and MUST NOT be deleted or "
                "cryptographically erased until the hold is released (17.5)",
                remedy="release the hold under authorized policy, then remove",
                detail={"handle": key},
            )
        self._authorize("object:redact", key, record.case_id)
        tomb = {
            "record_type": "TombstoneRecord",
            "object_id": key,
            "content_hash": record.content_hash,
            "object_type": record.object_type,
            "removal_reason": str(reason),
            "removal_authority": str(authority),
            "removal_time": iso(self.__context.clock.now()),
            "legal_hold": False,
            "permitted_disclosure": "identity, hash, type, and dependency structure only",
            "status": str(removal_status),
            "tenant_id": self.tenant_id,
        }
        self.__partition.tombstones[key] = tomb
        del self.__partition.objects[key]
        self._log("object.removed", key, "PERMIT", "COMPLETED", detail={"reason": reason})
        return dict(tomb)

    def tombstones(self) -> Tuple[Dict[str, Any], ...]:
        return tuple(dict(t) for t in self.__partition.tombstones.values())

    def set_legal_hold(self, handle: str, held: bool, *, authority: str) -> TenantRecord:
        entry = self.__partition.objects.get(str(handle))
        if entry is None:
            raise TenantIsolationError(
                f"no object {handle} is addressable in tenant {self.tenant_id!r}"
            )
        self._authorize("object:legal_hold", str(handle), entry["record"].case_id)
        old: TenantRecord = entry["record"]
        entry["record"] = TenantRecord(
            handle=old.handle,
            tenant_id=old.tenant_id,
            object_type=old.object_type,
            case_id=old.case_id,
            content_hash=old.content_hash,
            created_at=old.created_at,
            created_by=old.created_by,
            legal_hold=bool(held),
        )
        self._log(
            "legal_hold.changed", str(handle), "PERMIT", "COMPLETED",
            detail={"held": bool(held), "authority": authority},
        )
        return entry["record"]

    # -- internals ----------------------------------------------------------
    def __context_may_reach(self, case_id: Optional[str]) -> bool:
        scope = self.__context.case_scope
        return not case_id or "*" in scope or str(case_id) in scope

    def _authorize(self, action: str, resource_id: str, case_id: Optional[str]) -> None:
        if self.__engine is None:
            # No engine configured: case scope is still enforced, because it
            # is a property of the *context* rather than of a policy document.
            if not self.__context_may_reach(case_id):
                raise TenantIsolationError(
                    f"case {case_id!r} is outside this context's case scope "
                    f"{list(self.__context.case_scope)} (44.2)"
                )
            return
        request = AccessRequest(
            subject=self.__context.subject(),
            resource=Resource(
                resource_id=resource_id or self.tenant_id,
                resource_type="StoredObject",
                tenant_id=self.tenant_id,
                case_id=case_id,
            ),
            action=action,
            environment={"clock_source": self.__context.clock.source},
        )
        self.__engine.authorize(request)

    def _log(
        self,
        action: str,
        resource: str,
        decision: str,
        outcome: str,
        *,
        detail: Optional[Mapping[str, Any]] = None,
    ) -> None:
        log = self.__partition.audit
        if log is None:  # pragma: no cover
            return
        log.append(
            actor=self.__context.actor,
            action=action,
            resource=resource,
            decision=decision,
            outcome=outcome,
            correlation_id=self.__context.correlation_id,
            tenant_id=self.tenant_id,
            detail=dict(detail or {}),
        )


def _type_of(obj: Any) -> str:
    if isinstance(obj, Mapping):
        for key in ("object_type", "record_type"):
            if obj.get(key):
                return str(obj[key])
    return "OpaqueRecord"


def _tokens(obj: Any) -> Tuple[str, ...]:
    """A trivial search index.  Present so that 44.5's *search* layer is real.

    A shared search index is one of the classic cross-tenant leaks -- the
    documents are separated and the index is not -- so the index lives inside
    the partition like everything else, and this function exists only to put
    something in it.
    """
    text = canonical_json(obj) if not isinstance(obj, str) else obj
    return tuple(sorted({w.strip('",:{}[]').lower() for w in text.split() if len(w) > 3}))


# ==========================================================================
# the multi-tenant store
# ==========================================================================
class MultiTenantStore:
    """Holds the partitions and hands out views.  The only crossing point.

    Deliberately the *only* object in this module that can see more than one
    tenant, and deliberately small, so that the code an auditor must read to
    convince themselves of 44.5 is this class and not the whole package.

    :meth:`view` is the sole constructor of :class:`TenantScopedStore`.  A
    tenant that has not been registered gets a refusal rather than an
    implicitly created partition: implicit creation would mean a typo in a
    tenant id silently opens an empty tenth tenant, and an operator debugging
    "my data disappeared" would be looking at an isolation success.
    """

    def __init__(self, *, clock: Clock, engine: Optional[PolicyEngine] = None) -> None:
        if clock is None:
            raise ConfigurationError("a multi-tenant store requires a supplied clock (45.1)")
        self._clock = clock
        self._engine = engine
        self._partitions: Dict[str, _Partition] = {}

    def register_tenant(self, tenant_id: str) -> str:
        name = str(tenant_id).strip()
        if not name:
            raise ConfigurationError("a tenant requires an identity")
        if name not in self._partitions:
            self._partitions[name] = _Partition(
                tenant_id=name,
                audit=HashChainedAuditLog(clock=self._clock, tenant_id=name),
            )
        return name

    @property
    def tenants(self) -> Tuple[str, ...]:
        return tuple(sorted(self._partitions))

    def view(
        self, context: Optional[TenantContext], *, engine: Optional[PolicyEngine] = None
    ) -> TenantScopedStore:
        """The only way to obtain a store view.  Requires a context (44.5)."""
        ctx = require_context(context)
        partition = self._partitions.get(ctx.tenant_id)
        if partition is None:
            raise TenantIsolationError(
                f"tenant {ctx.tenant_id!r} is not registered in this deployment",
                remedy="register the tenant explicitly; an unregistered tenant is not "
                       "created on demand, because a typo would otherwise open a new, "
                       "empty, silently-isolated tenant",
                detail={"known_tenants": list(self.tenants)},
            )
        return TenantScopedStore(partition, ctx, engine=engine or self._engine)

    def audit_log(self, tenant_id: str) -> HashChainedAuditLog:
        """Administrative access to one tenant's log.  Not reachable from a view."""
        partition = self._partitions.get(str(tenant_id))
        if partition is None or partition.audit is None:
            raise TenantIsolationError(f"tenant {tenant_id!r} is not registered")
        return partition.audit

    def separation_report(self) -> Dict[str, Any]:
        """What 44.5's ten layers actually get here, including the gaps.

        Published rather than asserted.  Four of the ten are provided by this
        module directly; the rest are named with what a deployment must still
        do, because a separation claim that quietly covers six layers and
        implies ten is the kind of claim 60 exists to forbid.
        """
        provided = {
            "authentication": (
                "PROVIDED -- LocalAccountDirectory and ServiceIdentityDirectory are "
                "constructed per tenant and a Principal carries its tenant_id; a "
                "TenantContext refuses a principal from another tenant"
            ),
            "authorization": (
                "PROVIDED -- PolicyEngine denies on tenant mismatch as a built-in rule "
                "that no declarative rule can outvote (deny-overrides)"
            ),
            "database access": (
                "PROVIDED IN THIS REFERENCE -- each tenant is a separate _Partition and "
                "a TenantScopedStore holds a reference to one; a production deployment "
                "on a shared RDBMS must additionally enforce row-level security or "
                "schema separation, which this in-memory reference does not model"
            ),
            "object storage": (
                "PROVIDED -- handles are content_hash({tenant_id, content}), so the same "
                "bytes have different addresses per tenant and a leaked handle is not an "
                "address elsewhere"
            ),
            "cache": "PROVIDED -- the cache is a field of the partition",
            "logs": (
                "PROVIDED -- each partition owns a HashChainedAuditLog constructed with "
                "its tenant_id, which refuses an entry for another tenant"
            ),
            "jobs": "PROVIDED -- the job table is a field of the partition",
            "search": (
                "PROVIDED -- the token index is a field of the partition; a shared index "
                "over separated documents is a classic cross-tenant leak and is avoided "
                "by construction rather than by filtering results"
            ),
            "metrics": "PROVIDED -- counters are per partition",
            "backups": (
                "NOT PROVIDED -- this reference has no backup mechanism at all, so it "
                "neither separates backups nor claims to; a deployment must ensure a "
                "restore cannot move objects between tenants"
            ),
        }
        return {
            "spec": "44.5",
            "layers": [{"layer": layer, "status": provided[layer]} for layer in SEPARATION_LAYERS],
            "isolation_mechanism": (
                "structural: a TenantScopedStore closes over one partition and holds no "
                "reference to the multi-tenant store, so a cross-tenant read has no code "
                "path rather than a failing check"
            ),
            "residual_risk": (
                "a caller holding the MultiTenantStore, or filesystem access to the "
                "backing store, reaches every tenant; that is a deployment boundary and "
                "no language-level construction removes it"
            ),
            "tenants_registered": len(self._partitions),
        }
