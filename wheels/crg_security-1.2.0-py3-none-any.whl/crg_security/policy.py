"""RBAC over 44.3's roles, ABAC over attributes, and a deny-by-default engine.

Normative basis: 44.2 (role-based access control, attribute-based access
policies, object-level permissions, case-level isolation, approval
separation), 44.3 (the thirteen roles), 44.5 (separation at authorization),
44.7 (every authorization-sensitive operation produces an audit event), 6.6
(fail closed), 6.7 (extensibility without core modification), 14.3 (a policy
document is canonical data).

Five properties, and the first two are the ones that make the rest safe.

**Deny by default, structurally.**  :meth:`PolicyEngine.decide` collects the
effects of every applicable rule and then asks one question: *did anything
permit this?*  A request that matched nothing is
:data:`Effect.NOT_APPLICABLE` from the policy set and ``DENY`` from the
engine, attributed to :data:`DEFAULT_DENY_RULE_ID`.  There is no branch in
which falling off the end of the rule list produces an affirmative answer,
and no configuration flag that changes it.  ``NOT_APPLICABLE`` is preserved
in the decision record (``policy_effect``) because "no rule spoke" and "a rule
said no" are different findings for whoever is tuning the policy, but they
are the same answer to the caller.

**Deny overrides.**  When rules disagree, the deny wins, and the decision
names the denying rule.  Any other combining algorithm makes a policy set
non-monotone: adding a rule could grant access, which means a reviewer cannot
read a diff and know what it does.

**The rule that fired is part of the answer.**  :class:`Decision` carries
``rule_id`` and ``reason`` in every case, including the default deny.  A
403 that cannot say which rule produced it is unappealable, and an audit log
of unappealable refusals is not an audit log.

**RBAC and ABAC are the same evaluation, not two systems.**  The role check
of 44.3 is expressed as a built-in rule alongside the declarative ones, so a
deployment reading a single ordered list sees the whole authorization story.
The alternative -- a role gate in front of a policy engine -- hides the
interaction, and the interaction is where the mistakes live.

**Isolation is checked before anything else can permit.**  Tenant mismatch
(44.5) and case scope (44.2's case-level isolation) are built-in *deny* rules
that no declarative rule can outvote, because deny overrides.  A deployment
cannot write a policy that grants cross-tenant read, which is the point:
:mod:`crg_security.tenancy` makes it structurally hard and this makes it
policy-impossible.
"""
from __future__ import annotations

import fnmatch
import json
import re
from dataclasses import dataclass, field
from typing import (
    Any,
    Callable,
    Dict,
    FrozenSet,
    Iterable,
    List,
    Mapping,
    Optional,
    Sequence,
    Tuple,
)

from crg_model.canonical import canonical_json

from .clock import Clock
from .errors import AuthorizationError, ConfigurationError, TenantIsolationError
from .roles import (
    OPERATION_PERMISSIONS,
    ROLES,
    operation_permission,
    permissions_for,
    separation_violation,
    unknown_roles,
)

__all__ = [
    "Effect",
    "DEFAULT_DENY_RULE_ID",
    "Subject",
    "Resource",
    "AccessRequest",
    "Decision",
    "Condition",
    "Rule",
    "PolicySet",
    "ObjectPermissionTable",
    "PolicyEngine",
    "OPERATORS",
    "subject_from_principal",
]


class Effect:
    """The three answers a policy evaluation can give (44.2)."""

    PERMIT = "PERMIT"
    DENY = "DENY"
    NOT_APPLICABLE = "NOT_APPLICABLE"

    ALL = (PERMIT, DENY, NOT_APPLICABLE)


#: The rule attributed when nothing permitted.  A real identifier rather than
#: an empty string, so that "denied by default" is greppable in an audit log
#: and distinguishable from "denied by a rule whose id was left blank".
DEFAULT_DENY_RULE_ID = "urn:crg:policy:default-deny"


# ==========================================================================
# the request tuple: (subject, resource, action, environment)
# ==========================================================================
@dataclass(frozen=True)
class Subject:
    """The subject half of an ABAC request (44.2).

    ``case_scope`` implements 44.2's *case-level isolation*.  ``("*",)`` means
    every case in the tenant; any other value is an explicit allow-list, and
    an empty tuple means no case at all.  It defaults to ``("*",)`` because a
    single-case deployment that had to enumerate its own case to read it would
    be a deployment that turns the feature off; the isolation is real when a
    deployment sets it, and :class:`PolicyEngine` enforces it either way.
    """

    subject_id: str
    tenant_id: str
    roles: Tuple[str, ...] = ()
    attributes: Mapping[str, Any] = field(default_factory=dict)
    case_scope: Tuple[str, ...] = ("*",)
    kind: str = "USER"

    def __post_init__(self) -> None:
        object.__setattr__(self, "roles", tuple(sorted({str(r) for r in self.roles})))
        object.__setattr__(self, "attributes", dict(self.attributes))
        object.__setattr__(self, "case_scope", tuple(str(c) for c in self.case_scope))
        if not str(self.subject_id).strip():
            raise ConfigurationError("an access request requires a subject identity")
        if not str(self.tenant_id).strip():
            raise ConfigurationError(
                "an access request requires a tenant (44.5 separates at authorization)"
            )

    @property
    def permissions(self) -> FrozenSet[str]:
        return permissions_for(self.roles)

    def may_reach_case(self, case_id: Optional[str]) -> bool:
        if not case_id:
            return True
        return "*" in self.case_scope or str(case_id) in self.case_scope

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "subject_id": self.subject_id,
            "tenant_id": self.tenant_id,
            "kind": self.kind,
            "roles": list(self.roles),
            "attributes": dict(self.attributes),
            "case_scope": list(self.case_scope),
        }


def subject_from_principal(principal: Any, *, case_scope: Sequence[str] = ("*",)) -> Subject:
    """Adapt a :class:`crg_security.identity.Principal` to a policy subject.

    A separate type rather than passing the principal straight in.  The
    principal is what *authentication* produced and carries session and clock
    provenance; the subject is what *authorization* consumes.  Keeping them
    distinct is what stops a policy rule from matching on, say, a session id,
    which would make the policy's behaviour depend on when the user logged in.
    """
    scope = tuple(principal.attributes.get("case_scope") or case_scope)
    return Subject(
        subject_id=principal.subject_id,
        tenant_id=principal.tenant_id,
        roles=tuple(principal.roles),
        attributes=dict(principal.attributes),
        case_scope=scope,
        kind=getattr(principal, "kind", "USER"),
    )


@dataclass(frozen=True)
class Resource:
    """The resource half of an ABAC request, plus what isolation needs.

    ``resource_id`` is whatever addresses the object in its store -- a case
    id, a content hash, an evidence id.  ``tenant_id`` and ``case_id`` are
    separate fields rather than attributes because the engine's built-in
    isolation rules must be able to find them without a deployment having
    named them correctly in a policy document.
    """

    resource_id: str
    resource_type: str = ""
    tenant_id: str = ""
    case_id: Optional[str] = None
    owner: str = ""
    attributes: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        object.__setattr__(self, "attributes", dict(self.attributes))

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "resource_id": self.resource_id,
            "resource_type": self.resource_type,
            "tenant_id": self.tenant_id,
            "case_id": self.case_id,
            "owner": self.owner,
            "attributes": dict(self.attributes),
        }


@dataclass(frozen=True)
class AccessRequest:
    """``(subject, resource, action, environment)`` -- 44.2's ABAC tuple.

    ``action`` is a permission name from :data:`crg_security.roles.PERMISSIONS`
    or an ``operation_id`` from the server's endpoint table; the engine
    resolves the second to the first through
    :func:`crg_security.roles.operation_permission` and refuses an operation
    nobody mapped, because a new endpoint that was forgotten must fail closed.

    ``previously_exercised`` is the permission history of *this subject on
    this object*, which is what 44.2's approval separation is actually a
    property of.  See :func:`crg_security.roles.separation_violation`.
    """

    subject: Subject
    resource: Resource
    action: str
    environment: Mapping[str, Any] = field(default_factory=dict)
    previously_exercised: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(self, "environment", dict(self.environment))
        object.__setattr__(
            self, "previously_exercised", tuple(str(p) for p in self.previously_exercised)
        )

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "subject": self.subject.to_canonical(),
            "resource": self.resource.to_canonical(),
            "action": self.action,
            "environment": dict(self.environment),
            "previously_exercised": list(self.previously_exercised),
        }


@dataclass(frozen=True)
class Decision:
    """A complete authorization answer: effect, rule, and why (44.2, 44.7).

    ``policy_effect`` preserves the raw three-valued result of the declarative
    policy set even when ``effect`` has collapsed ``NOT_APPLICABLE`` into
    ``DENY``.  ``evaluated`` lists every rule that matched, in order, so a
    reviewer can see that a permit existed and was outvoted rather than
    concluding no rule applied.
    """

    effect: str
    rule_id: str
    reason: str
    action: str = ""
    subject_id: str = ""
    resource_id: str = ""
    tenant_id: str = ""
    policy_effect: str = Effect.NOT_APPLICABLE
    obligations: Tuple[str, ...] = ()
    evaluated: Tuple[Tuple[str, str], ...] = ()

    def __bool__(self) -> bool:
        return self.effect == Effect.PERMIT

    @property
    def permitted(self) -> bool:
        return self.effect == Effect.PERMIT

    def to_canonical(self) -> Dict[str, Any]:
        record: Dict[str, Any] = {
            "effect": self.effect,
            "rule_id": self.rule_id,
            "reason": self.reason,
            "action": self.action,
            "subject_id": self.subject_id,
            "resource_id": self.resource_id,
            "tenant_id": self.tenant_id,
            "policy_effect": self.policy_effect,
            "evaluated_rules": [{"rule_id": r, "effect": e} for r, e in self.evaluated],
        }
        if self.obligations:
            record["obligations"] = list(self.obligations)
        return record

    def require_permit(self) -> "Decision":
        """Return self, or raise :class:`AuthorizationError` (6.6)."""
        if self.effect == Effect.PERMIT:
            return self
        error: Any = AuthorizationError
        if self.rule_id in {_TENANT_RULE_ID}:
            error = TenantIsolationError
        raise error(
            f"{self.action or 'this action'} is denied",
            remedy=self.reason,
            detail=self.to_canonical(),
        )


# ==========================================================================
# declarative conditions
# ==========================================================================
def _resolve(path: str, request: AccessRequest) -> Any:
    """Resolve a dotted attribute path against the request tuple.

    Four namespaces, matching 44.2's four inputs exactly: ``subject``,
    ``resource``, ``action``, ``environment``.  A path outside them is a
    configuration error at *load* time, not a silent ``None`` at decision
    time -- a policy that references a namespace that does not exist is a
    policy whose author believed something false, and the moment to say so is
    when it is written.
    """
    head, _, rest = str(path).partition(".")
    if head == "action":
        return request.action
    if head == "environment":
        return _dig(request.environment, rest)
    if head == "subject":
        base: Dict[str, Any] = {
            "id": request.subject.subject_id,
            "subject_id": request.subject.subject_id,
            "tenant_id": request.subject.tenant_id,
            "roles": list(request.subject.roles),
            "kind": request.subject.kind,
            "case_scope": list(request.subject.case_scope),
            "permissions": sorted(request.subject.permissions),
        }
        if rest in base:
            return base[rest]
        return _dig(request.subject.attributes, rest)
    if head == "resource":
        base = {
            "id": request.resource.resource_id,
            "resource_id": request.resource.resource_id,
            "type": request.resource.resource_type,
            "resource_type": request.resource.resource_type,
            "tenant_id": request.resource.tenant_id,
            "case_id": request.resource.case_id,
            "owner": request.resource.owner,
        }
        if rest in base:
            return base[rest]
        return _dig(request.resource.attributes, rest)
    raise ConfigurationError(
        f"policy path {path!r} names no known namespace",
        remedy="44.2's inputs are subject, resource, action, and environment",
    )


def _dig(mapping: Mapping[str, Any], path: str) -> Any:
    value: Any = mapping
    if not path:
        return value
    for part in path.split("."):
        if not isinstance(value, Mapping) or part not in value:
            return None
        value = value[part]
    return value


def _as_set(value: Any) -> set:
    if value is None:
        return set()
    if isinstance(value, (str, bytes)):
        return {value}
    if isinstance(value, Mapping):
        return set(value)
    if isinstance(value, Iterable):
        return set(value)
    return {value}


def _numeric(left: Any, right: Any, op: Callable[[Any, Any], bool]) -> bool:
    """Ordered comparison that refuses across incomparable types.

    ``None < 5`` raises in Python 3 and silently succeeded in Python 2; either
    way, an ordering comparison against a missing attribute is a policy bug.
    Here it is ``False`` -- the condition does not hold -- which combined with
    deny-by-default means a missing attribute never widens access.
    """
    try:
        return bool(op(left, right))
    except TypeError:
        return False


#: The operator vocabulary of a policy document.  Closed and small: every
#: operator is one a reviewer can evaluate in their head against a request.
#: Notably absent is any operator that executes code, because a policy
#: document is data (14.3) and a policy document that could run code would be
#: a plugin, with 44.6's "malicious or compromised plugins" attached to it.
OPERATORS: Dict[str, Callable[[Any, Any], bool]] = {
    "eq": lambda a, b: a == b,
    "ne": lambda a, b: a != b,
    "in": lambda a, b: a in _as_set(b),
    "not_in": lambda a, b: a not in _as_set(b),
    "contains": lambda a, b: b in _as_set(a),
    "not_contains": lambda a, b: b not in _as_set(a),
    "intersects": lambda a, b: bool(_as_set(a) & _as_set(b)),
    "subset_of": lambda a, b: _as_set(a) <= _as_set(b),
    "superset_of": lambda a, b: _as_set(a) >= _as_set(b),
    "exists": lambda a, b: (a is not None) == bool(b),
    "lt": lambda a, b: _numeric(a, b, lambda x, y: x < y),
    "le": lambda a, b: _numeric(a, b, lambda x, y: x <= y),
    "gt": lambda a, b: _numeric(a, b, lambda x, y: x > y),
    "ge": lambda a, b: _numeric(a, b, lambda x, y: x >= y),
    "glob": lambda a, b: fnmatch.fnmatchcase(str(a), str(b)),
    "matches": lambda a, b: re.fullmatch(str(b), str(a)) is not None,
}


@dataclass(frozen=True)
class Condition:
    """One ``attribute OP value`` test.

    ``value_path`` is the interesting field: it compares two *attributes*
    rather than an attribute and a literal, which is how relationship rules
    ("the owner may read it", "the approver's business unit must match the
    case's") are expressed without inventing a per-relationship rule type.
    Exactly one of ``value`` and ``value_path`` may be given.
    """

    attribute: str
    operator: str
    value: Any = None
    value_path: str = ""

    def __post_init__(self) -> None:
        if self.operator not in OPERATORS:
            raise ConfigurationError(
                f"unknown policy operator {self.operator!r}",
                remedy=f"the closed operator vocabulary is {sorted(OPERATORS)}",
            )
        if self.value_path and self.value is not None:
            raise ConfigurationError(
                "a condition takes either 'value' or 'value_path', not both",
                remedy="comparing an attribute to both a literal and another attribute "
                       "has no single meaning, so it is refused rather than guessed",
            )

    def holds(self, request: AccessRequest) -> bool:
        left = _resolve(self.attribute, request)
        right = _resolve(self.value_path, request) if self.value_path else self.value
        return bool(OPERATORS[self.operator](left, right))

    def to_canonical(self) -> Dict[str, Any]:
        record: Dict[str, Any] = {"attribute": self.attribute, "operator": self.operator}
        if self.value_path:
            record["value_path"] = self.value_path
        else:
            record["value"] = self.value
        return record

    @classmethod
    def from_canonical(cls, record: Mapping[str, Any]) -> "Condition":
        return cls(
            attribute=str(record["attribute"]),
            operator=str(record["operator"]),
            value=record.get("value"),
            value_path=str(record.get("value_path") or ""),
        )


@dataclass(frozen=True)
class Rule:
    """One declarative ABAC rule (44.2).

    A rule *applies* when its ``actions`` and ``resource_types`` targets match
    and every condition holds -- conjunction, deliberately.  Disjunction is
    expressible as two rules, and two rules are two lines in a review diff,
    whereas a nested boolean tree is a thing reviewers skim.

    ``obligations`` are strings a caller must honour on a permit (log this,
    watermark that).  They are carried on the decision rather than enforced
    here, and the docstring says so, because an obligation this module cannot
    enforce must not be described as enforced.
    """

    rule_id: str
    effect: str
    description: str = ""
    actions: Tuple[str, ...] = ("*",)
    resource_types: Tuple[str, ...] = ("*",)
    conditions: Tuple[Condition, ...] = ()
    obligations: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not str(self.rule_id).strip():
            raise ConfigurationError(
                "every rule requires an id",
                remedy="44.7 and 6.6: a decision must be able to name the rule that made it",
            )
        if self.effect not in (Effect.PERMIT, Effect.DENY):
            raise ConfigurationError(
                f"a rule's effect must be PERMIT or DENY, not {self.effect!r}",
                remedy="NOT_APPLICABLE is what a policy set returns when no rule matched; "
                       "it is not something a rule may assert",
            )
        object.__setattr__(self, "actions", tuple(str(a) for a in self.actions) or ("*",))
        object.__setattr__(
            self, "resource_types", tuple(str(t) for t in self.resource_types) or ("*",)
        )
        object.__setattr__(self, "conditions", tuple(self.conditions))
        object.__setattr__(self, "obligations", tuple(str(o) for o in self.obligations))

    def targets(self, request: AccessRequest) -> bool:
        if not any(
            a == "*" or fnmatch.fnmatchcase(request.action, a) for a in self.actions
        ):
            return False
        rtype = request.resource.resource_type
        return any(
            t == "*" or fnmatch.fnmatchcase(rtype, t) for t in self.resource_types
        )

    def applies(self, request: AccessRequest) -> bool:
        if not self.targets(request):
            return False
        return all(condition.holds(request) for condition in self.conditions)

    def to_canonical(self) -> Dict[str, Any]:
        record: Dict[str, Any] = {
            "rule_id": self.rule_id,
            "effect": self.effect,
            "actions": list(self.actions),
            "resource_types": list(self.resource_types),
            "conditions": [c.to_canonical() for c in self.conditions],
        }
        if self.description:
            record["description"] = self.description
        if self.obligations:
            record["obligations"] = list(self.obligations)
        return record

    @classmethod
    def from_canonical(cls, record: Mapping[str, Any]) -> "Rule":
        return cls(
            rule_id=str(record.get("rule_id") or record.get("id") or ""),
            effect=str(record.get("effect") or "").upper(),
            description=str(record.get("description") or ""),
            actions=tuple(record.get("actions") or ("*",)),
            resource_types=tuple(record.get("resource_types") or ("*",)),
            conditions=tuple(
                Condition.from_canonical(c) for c in (record.get("conditions") or ())
            ),
            obligations=tuple(record.get("obligations") or ()),
        )


class PolicySet:
    """An ordered, named set of rules with a deny-overrides combiner (44.2).

    Loadable from a dict or a JSON string, canonicalizable back (14.3), and
    diffable, because a policy that cannot be diffed cannot be reviewed and
    44.6 lists unauthorized rule changes as a threat.

    :meth:`evaluate` is the honest three-valued function 44.2 implies: it
    returns ``NOT_APPLICABLE`` when nothing matched, and it is
    :class:`PolicyEngine` -- the thing that actually gates an operation -- that
    turns silence into a refusal.  Splitting them this way means a deployment
    can *analyse* its policy set (does anything cover this action?) without
    that analysis being confused with an access decision.
    """

    def __init__(
        self,
        rules: Iterable[Rule] = (),
        *,
        policy_id: str = "default",
        version: str = "1",
        description: str = "",
    ) -> None:
        self.policy_id = str(policy_id)
        self.version = str(version)
        self.description = str(description)
        self._rules: List[Rule] = []
        seen: set = set()
        for rule in rules:
            if rule.rule_id in seen:
                raise ConfigurationError(
                    f"duplicate rule id {rule.rule_id!r} in policy {policy_id!r}",
                    remedy="a decision names one rule; two rules with one name make the "
                           "audit record ambiguous",
                )
            seen.add(rule.rule_id)
            self._rules.append(rule)

    def __len__(self) -> int:
        return len(self._rules)

    @property
    def rules(self) -> Tuple[Rule, ...]:
        return tuple(self._rules)

    def rule(self, rule_id: str) -> Optional[Rule]:
        for candidate in self._rules:
            if candidate.rule_id == rule_id:
                return candidate
        return None

    def evaluate(self, request: AccessRequest) -> Decision:
        """Three-valued, deny-overrides.  Never raises on a normal denial."""
        matched: List[Tuple[str, str]] = []
        first_permit: Optional[Rule] = None
        for rule in self._rules:
            if not rule.applies(request):
                continue
            matched.append((rule.rule_id, rule.effect))
            if rule.effect == Effect.DENY:
                return Decision(
                    effect=Effect.DENY,
                    rule_id=rule.rule_id,
                    reason=rule.description or f"rule {rule.rule_id} denies this action",
                    action=request.action,
                    subject_id=request.subject.subject_id,
                    resource_id=request.resource.resource_id,
                    tenant_id=request.subject.tenant_id,
                    policy_effect=Effect.DENY,
                    obligations=rule.obligations,
                    evaluated=tuple(matched),
                )
            if first_permit is None:
                first_permit = rule
        if first_permit is not None:
            return Decision(
                effect=Effect.PERMIT,
                rule_id=first_permit.rule_id,
                reason=first_permit.description
                or f"rule {first_permit.rule_id} permits this action",
                action=request.action,
                subject_id=request.subject.subject_id,
                resource_id=request.resource.resource_id,
                tenant_id=request.subject.tenant_id,
                policy_effect=Effect.PERMIT,
                obligations=first_permit.obligations,
                evaluated=tuple(matched),
            )
        return Decision(
            effect=Effect.NOT_APPLICABLE,
            rule_id="",
            reason=f"no rule in policy {self.policy_id!r} applies to this request",
            action=request.action,
            subject_id=request.subject.subject_id,
            resource_id=request.resource.resource_id,
            tenant_id=request.subject.tenant_id,
            policy_effect=Effect.NOT_APPLICABLE,
            evaluated=(),
        )

    # -- documents ----------------------------------------------------------
    def to_canonical(self) -> Dict[str, Any]:
        return {
            "policy_id": self.policy_id,
            "version": self.version,
            "description": self.description,
            "combining_algorithm": "deny-overrides",
            "default_effect": Effect.DENY,
            "rules": [rule.to_canonical() for rule in self._rules],
        }

    def to_json(self) -> str:
        return canonical_json(self.to_canonical())

    @classmethod
    def from_canonical(cls, document: Mapping[str, Any]) -> "PolicySet":
        algorithm = str(document.get("combining_algorithm") or "deny-overrides")
        if algorithm != "deny-overrides":
            raise ConfigurationError(
                f"combining algorithm {algorithm!r} is not implemented",
                remedy="only deny-overrides is supported; permit-overrides would make a "
                       "policy set non-monotone, so adding a rule could grant access",
            )
        default = str(document.get("default_effect") or Effect.DENY)
        if default != Effect.DENY:
            raise ConfigurationError(
                f"default_effect {default!r} is refused",
                remedy="44.2 with 6.6: deny by default is not configurable",
            )
        return cls(
            rules=[Rule.from_canonical(r) for r in (document.get("rules") or ())],
            policy_id=str(document.get("policy_id") or "default"),
            version=str(document.get("version") or "1"),
            description=str(document.get("description") or ""),
        )

    @classmethod
    def from_json(cls, text: str) -> "PolicySet":
        return cls.from_canonical(json.loads(text))


# ==========================================================================
# object-level permissions (44.2)
# ==========================================================================
class ObjectPermissionTable:
    """Per-object grants and denials, addressed by object id (44.2).

    Roles answer "what may this kind of person do"; this answers "what may
    this person do *to this thing*".  Both are needed and neither substitutes
    for the other: a role model fine-grained enough to express per-object
    access is a role model with one role per object.

    Denials are stored separately from grants and win, for the same reason the
    engine's combiner is deny-overrides: a revocation that could be outvoted
    by a grant is not a revocation.
    """

    def __init__(self) -> None:
        self._grants: Dict[Tuple[str, str], set] = {}
        self._denials: Dict[Tuple[str, str], set] = {}

    def grant(self, resource_id: str, subject_id: str, *permissions: str) -> None:
        self._grants.setdefault((str(resource_id), str(subject_id)), set()).update(
            str(p) for p in permissions
        )

    def deny(self, resource_id: str, subject_id: str, *permissions: str) -> None:
        self._denials.setdefault((str(resource_id), str(subject_id)), set()).update(
            str(p) for p in permissions
        )

    def revoke(self, resource_id: str, subject_id: str, *permissions: str) -> None:
        entry = self._grants.get((str(resource_id), str(subject_id)))
        if entry:
            entry.difference_update(str(p) for p in permissions)

    def granted(self, resource_id: str, subject_id: str) -> FrozenSet[str]:
        return frozenset(self._grants.get((str(resource_id), str(subject_id)), set()))

    def denied(self, resource_id: str, subject_id: str) -> FrozenSet[str]:
        return frozenset(self._denials.get((str(resource_id), str(subject_id)), set()))

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "grants": [
                {"resource_id": r, "subject_id": s, "permissions": sorted(p)}
                for (r, s), p in sorted(self._grants.items())
            ],
            "denials": [
                {"resource_id": r, "subject_id": s, "permissions": sorted(p)}
                for (r, s), p in sorted(self._denials.items())
            ],
        }


# ==========================================================================
# the engine
# ==========================================================================
_TENANT_RULE_ID = "urn:crg:policy:builtin:tenant-isolation"
_CASE_RULE_ID = "urn:crg:policy:builtin:case-isolation"
_ACL_DENY_RULE_ID = "urn:crg:policy:builtin:object-permission-denied"
_ACL_PERMIT_RULE_ID = "urn:crg:policy:builtin:object-permission-granted"
_RBAC_RULE_ID = "urn:crg:policy:builtin:rbac"
_SOD_RULE_ID = "urn:crg:policy:builtin:separation-of-duties"
_UNMAPPED_RULE_ID = "urn:crg:policy:builtin:unmapped-operation"
_UNDECLARED_ROLE_RULE_ID = "urn:crg:policy:builtin:undeclared-role"


class PolicyEngine:
    """RBAC + ABAC + object permissions + isolation, deny by default (44.2).

    Evaluation order, and why it is this order:

    1. **Unmapped action.**  An ``action`` that is neither a declared
       permission nor a mapped ``operation_id`` is denied.  6.6: an endpoint
       nobody remembered to map must not be open.
    2. **Undeclared roles.**  A subject holding a role outside 44.3's thirteen
       is denied outright rather than having the unknown role ignored.  A
       typo in a role assignment that silently degrades to fewer permissions
       is survivable; one that silently degrades to *no check* is not, and
       refusing makes the typo loud.
    3. **Tenant isolation (44.5).**  Subject tenant must equal resource
       tenant.  Built in, before any rule can permit, and deny-overrides means
       no declarative rule can outvote it.
    4. **Case isolation (44.2).**  The subject's ``case_scope`` must cover the
       resource's ``case_id``.
    5. **Object-level denial.**
    6. **Declarative policy set** (deny-overrides within itself).
    7. **Separation of duties (44.2).**  Checked *after* a permit would
       otherwise be granted, because it is about this subject's history on
       this object rather than about the subject's rights.
    8. **RBAC or an object-level grant.**  Either the subject's roles carry
       the permission, or it was granted on this specific object.
    9. **Default deny**, attributed to :data:`DEFAULT_DENY_RULE_ID`.

    Every step returns a :class:`Decision` naming its rule.  When an audit log
    is supplied, every decision is appended to it -- 44.7 says *every*
    authorization-sensitive operation, which includes the ones that were
    refused, and especially those.
    """

    def __init__(
        self,
        policy: Optional[PolicySet] = None,
        *,
        object_permissions: Optional[ObjectPermissionTable] = None,
        audit_log: Any = None,
        clock: Optional[Clock] = None,
        require_declarative_permit: bool = False,
    ) -> None:
        # ``is None`` rather than ``or``: an empty PolicySet is falsy under
        # ``__len__``, and a deployment that deliberately supplied one would
        # otherwise find it replaced by a different empty one with another id,
        # which makes the audit record name a policy nobody wrote.
        self.policy = policy if policy is not None else PolicySet(policy_id="empty")
        self.object_permissions = (
            object_permissions if object_permissions is not None else ObjectPermissionTable()
        )
        self.audit_log = audit_log
        self.clock = clock
        #: When true, RBAC alone does not suffice: the declarative policy set
        #: must also permit.  Off by default because a deployment that has
        #: written no ABAC rules would otherwise be denied everything; on, it
        #: is the stricter enterprise posture 44.2 contemplates.
        self.require_declarative_permit = bool(require_declarative_permit)

    # -- the decision -------------------------------------------------------
    def decide(self, request: AccessRequest) -> Decision:
        decision = self._decide(request)
        self._audit(request, decision)
        return decision

    def authorize(self, request: AccessRequest) -> Decision:
        """:meth:`decide`, then raise unless the answer is ``PERMIT`` (6.6)."""
        return self.decide(request).require_permit()

    def _decide(self, request: AccessRequest) -> Decision:
        subject, resource = request.subject, request.resource

        def answer(effect: str, rule_id: str, reason: str, **kw: Any) -> Decision:
            return Decision(
                effect=effect,
                rule_id=rule_id,
                reason=reason,
                action=request.action,
                subject_id=subject.subject_id,
                resource_id=resource.resource_id,
                tenant_id=subject.tenant_id,
                **kw,
            )

        # 1. resolve the action to a permission
        permission = self._permission_for(request.action)
        if permission is None:
            return answer(
                Effect.DENY,
                _UNMAPPED_RULE_ID,
                f"action {request.action!r} maps to no declared permission; an "
                "unmapped operation is refused rather than allowed (6.6)",
            )

        # 2. undeclared roles
        strays = unknown_roles(subject.roles)
        if strays:
            return answer(
                Effect.DENY,
                _UNDECLARED_ROLE_RULE_ID,
                f"subject holds roles outside 44.3: {list(strays)}; the thirteen "
                f"declared roles are {list(ROLES)}",
            )

        # 3. tenant isolation (44.5)
        if resource.tenant_id and resource.tenant_id != subject.tenant_id:
            return answer(
                Effect.DENY,
                _TENANT_RULE_ID,
                f"subject is in tenant {subject.tenant_id!r} and the resource is in "
                f"tenant {resource.tenant_id!r}; 44.5 requires separation at "
                "authorization and no declarative rule may override this",
            )

        # 4. case isolation (44.2)
        if not subject.may_reach_case(resource.case_id):
            return answer(
                Effect.DENY,
                _CASE_RULE_ID,
                f"case {resource.case_id!r} is outside this subject's case scope "
                f"{list(subject.case_scope)} (44.2, case-level isolation)",
            )

        # 5. object-level denial (44.2)
        if permission in self.object_permissions.denied(
            resource.resource_id, subject.subject_id
        ):
            return answer(
                Effect.DENY,
                _ACL_DENY_RULE_ID,
                f"permission {permission!r} is denied to this subject on object "
                f"{resource.resource_id!r} specifically",
            )

        # 6. the declarative policy set
        policy_decision = self.policy.evaluate(request)
        if policy_decision.effect == Effect.DENY:
            return Decision(
                effect=Effect.DENY,
                rule_id=policy_decision.rule_id,
                reason=policy_decision.reason,
                action=request.action,
                subject_id=subject.subject_id,
                resource_id=resource.resource_id,
                tenant_id=subject.tenant_id,
                policy_effect=Effect.DENY,
                obligations=policy_decision.obligations,
                evaluated=policy_decision.evaluated,
            )

        # 7. separation of duties (44.2), before any permit is issued
        violation = separation_violation(
            subject.roles, permission, previously_exercised=request.previously_exercised
        )
        if violation is not None:
            first, second, why = violation
            return answer(
                Effect.DENY,
                _SOD_RULE_ID,
                f"approval separation: {why} (this subject already exercised "
                f"{first!r} on {resource.resource_id!r} and now asks for {second!r})",
                policy_effect=policy_decision.policy_effect,
                evaluated=policy_decision.evaluated,
            )

        # 8. RBAC, or an object-level grant
        by_role = permission in subject.permissions
        by_acl = permission in self.object_permissions.granted(
            resource.resource_id, subject.subject_id
        )
        needs_policy = self.require_declarative_permit
        policy_permits = policy_decision.effect == Effect.PERMIT

        if needs_policy and not policy_permits:
            return answer(
                Effect.DENY,
                DEFAULT_DENY_RULE_ID,
                "this engine requires an explicit declarative permit and the policy "
                f"set returned {policy_decision.policy_effect}",
                policy_effect=policy_decision.policy_effect,
                evaluated=policy_decision.evaluated,
            )
        if by_role or by_acl or policy_permits:
            rule_id = (
                policy_decision.rule_id if policy_permits
                else (_RBAC_RULE_ID if by_role else _ACL_PERMIT_RULE_ID)
            )
            if policy_permits:
                reason = policy_decision.reason
            elif by_role:
                reason = (
                    f"roles {list(subject.roles)} carry permission {permission!r} (44.3)"
                )
            else:
                reason = (
                    f"permission {permission!r} was granted to this subject on object "
                    f"{resource.resource_id!r} specifically (44.2)"
                )
            return Decision(
                effect=Effect.PERMIT,
                rule_id=rule_id,
                reason=reason,
                action=request.action,
                subject_id=subject.subject_id,
                resource_id=resource.resource_id,
                tenant_id=subject.tenant_id,
                policy_effect=policy_decision.policy_effect,
                obligations=policy_decision.obligations,
                evaluated=policy_decision.evaluated,
            )

        # 9. deny by default
        return answer(
            Effect.DENY,
            DEFAULT_DENY_RULE_ID,
            f"nothing permits {permission!r} for this subject: roles "
            f"{list(subject.roles)} do not carry it, no object-level grant exists, "
            f"and the policy set returned {policy_decision.policy_effect}",
            policy_effect=policy_decision.policy_effect,
            evaluated=policy_decision.evaluated,
        )

    # -- helpers ------------------------------------------------------------
    @staticmethod
    def _permission_for(action: str) -> Optional[str]:
        """Resolve an action to a declared permission, or ``None``.

        Accepts a permission name directly (``case:read``) or an
        ``operation_id`` from the server's endpoint table (``getCase``).  An
        operation the table does not mention returns ``None``, which the
        caller turns into a denial -- see
        :func:`crg_security.roles.operation_permission`.
        """
        name = str(action)
        if ":" in name:
            from .roles import PERMISSIONS

            return name if name in PERMISSIONS else None
        return operation_permission(name)

    def _audit(self, request: AccessRequest, decision: Decision) -> None:
        if self.audit_log is None:
            return
        self.audit_log.append(
            actor=request.subject.subject_id,
            action=request.action,
            resource=request.resource.resource_id,
            decision=decision.effect,
            outcome="REFUSED" if decision.effect != Effect.PERMIT else "AUTHORIZED",
            rule_id=decision.rule_id,
            tenant_id=request.subject.tenant_id,
            detail={
                "reason": decision.reason,
                "resource_type": request.resource.resource_type,
                "case_id": request.resource.case_id,
                "policy_effect": decision.policy_effect,
                "roles": list(request.subject.roles),
            },
        )

    # -- description --------------------------------------------------------
    def to_canonical(self) -> Dict[str, Any]:
        return {
            "policy": self.policy.to_canonical(),
            "object_permissions": self.object_permissions.to_canonical(),
            "require_declarative_permit": self.require_declarative_permit,
            "builtin_rules": [
                {"rule_id": _UNMAPPED_RULE_ID, "effect": Effect.DENY,
                 "description": "an action mapping to no declared permission is refused (6.6)"},
                {"rule_id": _UNDECLARED_ROLE_RULE_ID, "effect": Effect.DENY,
                 "description": "a role outside 44.3's thirteen is refused, not ignored"},
                {"rule_id": _TENANT_RULE_ID, "effect": Effect.DENY,
                 "description": "cross-tenant access is refused at authorization (44.5)"},
                {"rule_id": _CASE_RULE_ID, "effect": Effect.DENY,
                 "description": "case-level isolation (44.2)"},
                {"rule_id": _ACL_DENY_RULE_ID, "effect": Effect.DENY,
                 "description": "object-level denial (44.2)"},
                {"rule_id": _SOD_RULE_ID, "effect": Effect.DENY,
                 "description": "approval separation (44.2)"},
                {"rule_id": _RBAC_RULE_ID, "effect": Effect.PERMIT,
                 "description": "the subject's 44.3 roles carry the permission"},
                {"rule_id": _ACL_PERMIT_RULE_ID, "effect": Effect.PERMIT,
                 "description": "object-level grant (44.2)"},
                {"rule_id": DEFAULT_DENY_RULE_ID, "effect": Effect.DENY,
                 "description": "nothing permitted this request (6.6)"},
            ],
            "mapped_operations": sorted(OPERATION_PERMISSIONS),
        }
