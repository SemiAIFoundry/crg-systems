"""Which cryptography this build can actually perform, and saying so out loud.

Normative basis: 14.5 (Ed25519 is the baseline portable signature profile),
44.4 (encryption), 9.2 (the trusted computing base should be dependency-light),
6.6 (fail closed), 51 (published claim boundary).

The CRG kernel packages are standard-library-only by design: 9.2 asks the
verification zone to be dependency-light, independently auditable, and
executable offline, and every dependency is one more thing an air-gapped
verifier must acquire and audit.  But 14.5 asks for Ed25519, which the
standard library cannot do.

This module resolves that tension the only honest way: the production profile
is *optional and detected*, never *assumed*.  Import ``crg_security`` on a
machine without :mod:`cryptography` and everything still imports and runs --
but :data:`PRODUCTION_CRYPTO_AVAILABLE` is ``False``, every asymmetric
operation raises :class:`~crg_security.errors.ProfileUnavailableError`, and
:func:`disclosure` says so in one sentence a release note can quote.

What this module refuses to do is the thing that would be convenient: fall
back to a symmetric MAC while keeping the label ``Ed25519``.  A verifier that
cannot tell a forgeable artifact from an unforgeable one by reading its
profile string has lost the only property the profile string exists to carry.
"""
from __future__ import annotations

import warnings
from typing import Any, Dict, Optional, Tuple

__all__ = [
    "PRODUCTION_CRYPTO_AVAILABLE",
    "CRYPTOGRAPHY_VERSION",
    "SECURITY_PROFILE",
    "PROFILE_PRODUCTION",
    "PROFILE_STDLIB",
    "DEGRADATION_NOTICE",
    "disclosure",
    "require_production_crypto",
    "warn_once_if_degraded",
]

#: The profile name when :mod:`cryptography` is importable.
PROFILE_PRODUCTION = "crg-security/production-crypto"
#: The profile name when it is not.
PROFILE_STDLIB = "crg-security/stdlib-only"


def _detect() -> Tuple[bool, Optional[str]]:
    try:
        import cryptography  # noqa: F401  (probe import)
        from cryptography.hazmat.primitives.asymmetric import ed25519  # noqa: F401
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM  # noqa: F401
    except Exception:  # noqa: BLE001 - any import failure means "not available"
        return False, None
    return True, str(getattr(cryptography, "__version__", "unknown"))


PRODUCTION_CRYPTO_AVAILABLE, CRYPTOGRAPHY_VERSION = _detect()

SECURITY_PROFILE = PROFILE_PRODUCTION if PRODUCTION_CRYPTO_AVAILABLE else PROFILE_STDLIB

DEGRADATION_NOTICE = (
    "crg-security is running in its standard-library-only profile: the "
    "'cryptography' package is not importable, so the specification 14.5 "
    "Ed25519 signature profile and the AES-256-GCM encryption profile are "
    "UNAVAILABLE.  Signing and verification under those profiles will raise "
    "rather than fall back.  Only the explicitly test-labelled symmetric "
    "profiles remain, and no production deployment may rely on them: a holder "
    "of a symmetric verification key can forge the artifacts it verifies.  "
    "Install crg-security[crypto] to enable the production profile."
)

_WARNED = False


def warn_once_if_degraded() -> bool:
    """Emit the degradation notice once per process; return whether degraded.

    Once, not every call: a warning printed on every signature is a warning an
    operator filters out, and a filtered warning is not a disclosure.
    """
    global _WARNED
    if PRODUCTION_CRYPTO_AVAILABLE:
        return False
    if not _WARNED:
        _WARNED = True
        warnings.warn(DEGRADATION_NOTICE, RuntimeWarning, stacklevel=2)
    return True


def require_production_crypto(operation: str) -> None:
    """Raise unless this build can perform production cryptography.

    Called at the top of every operation that would otherwise be tempted to
    approximate.  The error names the operation, because "cryptography is not
    installed" is a fact and "you cannot sign a release manifest because
    cryptography is not installed" is an instruction.
    """
    if PRODUCTION_CRYPTO_AVAILABLE:
        return
    from .errors import ProfileUnavailableError

    raise ProfileUnavailableError(
        f"{operation} requires the production cryptographic profile, which this "
        "build cannot perform",
        remedy=(
            "install the optional dependency ('pip install crg-security[crypto]', "
            "or 'pip install cryptography'); this operation will not be silently "
            "downgraded to a symmetric stand-in (14.5)"
        ),
        detail={"security_profile": SECURITY_PROFILE, "operation": operation},
    )


def disclosure() -> Dict[str, Any]:
    """The machine-readable statement of what this build can do (51, 60).

    Intended to be embedded in a release manifest, an ``/openapi`` extension,
    or a verification report.  A deployment that publishes this cannot later
    claim it did not know which profile it was running.
    """
    record: Dict[str, Any] = {
        "security_profile": SECURITY_PROFILE,
        "production_crypto_available": PRODUCTION_CRYPTO_AVAILABLE,
        "signature_profiles_supported": (
            ["Ed25519", "HMAC-SHA256-TEST"]
            if PRODUCTION_CRYPTO_AVAILABLE
            else ["HMAC-SHA256-TEST"]
        ),
        "encryption_profiles_supported": (
            ["AES-256-GCM", "SHA256-CTR-HMAC-TEST"]
            if PRODUCTION_CRYPTO_AVAILABLE
            else ["SHA256-CTR-HMAC-TEST"]
        ),
        "baseline_profile_required_by_spec": "Ed25519 (14.5)",
        "password_hash": "scrypt (standard library, salted and peppered)",
        "transport_encryption": (
            "NOT PROVIDED by this package; 44.4 makes transport encryption "
            "mandatory and this reference server must be deployed behind TLS"
        ),
        "hsm_or_kms_custody": (
            "NOT PROVIDED; 44.4 says signing keys SHOULD support HSM or external "
            "key management, and the KeyVault here is a software vault"
        ),
    }
    if CRYPTOGRAPHY_VERSION:
        record["cryptography_version"] = CRYPTOGRAPHY_VERSION
    if not PRODUCTION_CRYPTO_AVAILABLE:
        record["degradation_notice"] = DEGRADATION_NOTICE
    return record
