"""Supplied clocks, declared clock sources, and the 45.4 time statuses.

Normative basis: 45.1 (wall-clock and monotonic are distinct domains), 45.2
(signed time assertions), 45.3 (a verifier reports its own evaluation time and
clock source), 45.4 (the six statuses), 45.5 (an air-gapped verifier must
disclose its clock source and MUST NOT silently represent an indeterminate
claim as current), 45.6 (a wall-clock adjustment MUST NOT extend a freshness
window).

Nothing in :mod:`crg_security` calls :func:`datetime.datetime.now`.  Every
expiry decision takes a :class:`Clock`, and the clock declares its source.
Two reasons, and the second is the interesting one.

The obvious reason is testability: a session that expires in an hour is
untestable against the machine clock without sleeping for an hour.

The real reason is 45.3 and 45.5.  A verifier must *report* which clock it
judged by, and an air-gapped verifier's clock has a different trust level than
an NTP-disciplined one.  If expiry were computed from an ambient global
function, there would be no object to ask what the clock source was, and the
report 45.3 requires could not be produced truthfully.  Making the clock a
parameter makes the answer a value.

45.6 is enforced structurally rather than by convention: freshness windows are
computed from :meth:`Clock.monotonic`, which no wall-clock adjustment can move
backwards, and :class:`FixedClock` will refuse a monotonic value that goes
backwards even in a test.
"""
from __future__ import annotations

import datetime as _dt
import time
from dataclasses import dataclass
from typing import Any, Dict, Optional

__all__ = [
    "TimeStatus",
    "ClockTrustLevel",
    "Clock",
    "SystemClock",
    "FixedClock",
    "AirGappedClock",
    "iso",
    "parse_iso",
    "evaluate_validity",
    "TimeJudgment",
]


class TimeStatus:
    """Specification 45.4, verbatim and closed."""

    CURRENT = "CURRENT"
    NOT_YET_VALID = "NOT_YET_VALID"
    STALE = "STALE"
    EXPIRED = "EXPIRED"
    TIME_INDETERMINATE = "TIME_INDETERMINATE"
    CLOCK_POLICY_VIOLATION = "CLOCK_POLICY_VIOLATION"

    ALL = (
        CURRENT,
        NOT_YET_VALID,
        STALE,
        EXPIRED,
        TIME_INDETERMINATE,
        CLOCK_POLICY_VIOLATION,
    )

    #: The statuses that may support an affirmative answer.  Exactly one.
    AFFIRMATIVE = (CURRENT,)


class ClockTrustLevel:
    """How much a verifier is entitled to claim for its own clock (45.3, 45.5)."""

    #: Disciplined against an external time source the deployment trusts.
    SYNCHRONIZED = "SYNCHRONIZED"
    #: The host clock, undisciplined; good enough to order events, not to
    #: adjudicate a disputed expiry.
    LOCAL_UNVERIFIED = "LOCAL_UNVERIFIED"
    #: 45.5: an air-gapped verifier MAY use its own declared local clock and
    #: MUST disclose that it did.
    AIR_GAPPED_DECLARED = "AIR_GAPPED_DECLARED"
    #: No usable clock.  Everything time-dependent becomes
    #: ``TIME_INDETERMINATE``; 45.5 forbids calling it ``CURRENT``.
    NONE = "NONE"

    ALL = (SYNCHRONIZED, LOCAL_UNVERIFIED, AIR_GAPPED_DECLARED, NONE)


def iso(moment: _dt.datetime) -> str:
    """Canonical UTC ISO-8601 with a ``Z`` suffix (14.3)."""
    if moment.tzinfo is None:
        moment = moment.replace(tzinfo=_dt.timezone.utc)
    return (
        moment.astimezone(_dt.timezone.utc)
        .isoformat(timespec="seconds")
        .replace("+00:00", "Z")
    )


def parse_iso(value: str) -> Optional[_dt.datetime]:
    """Parse an ISO-8601 instant, returning ``None`` rather than raising.

    ``None`` is a real answer here: an unparseable issuer time assertion is
    ``TIME_INDETERMINATE`` (45.4), not an exception, because the verifier's
    job is to *report* a status rather than to abort.
    """
    if not isinstance(value, str) or not value.strip():
        return None
    text = value.strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        parsed = _dt.datetime.fromisoformat(text)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=_dt.timezone.utc)
    return parsed.astimezone(_dt.timezone.utc)


class Clock:
    """The two clock domains of 45.1, as one supplied object.

    Subclasses provide :meth:`now` (wall clock, for issuance, expiry,
    signatures, federation, audit) and :meth:`monotonic` (for freshness
    windows, dwell time, and timeouts).  ``trust_level`` and ``source`` are
    what 45.3 requires a verifier to report about itself.
    """

    trust_level: str = ClockTrustLevel.LOCAL_UNVERIFIED
    source: str = "unspecified"

    def now(self) -> _dt.datetime:  # pragma: no cover - abstract
        raise NotImplementedError

    def monotonic(self) -> float:  # pragma: no cover - abstract
        raise NotImplementedError

    # -- convenience --------------------------------------------------------
    def now_iso(self) -> str:
        return iso(self.now())

    def declaration(self) -> Dict[str, Any]:
        """The clock disclosure 45.3 and 45.5 require in a report."""
        return {
            "clock_source": self.source,
            "clock_trust_level": self.trust_level,
            "verifier_evaluation_time": self.now_iso(),
        }

    @property
    def usable_for_expiry(self) -> bool:
        return self.trust_level != ClockTrustLevel.NONE


class SystemClock(Clock):
    """The host clock.  Declares itself unverified unless told otherwise."""

    def __init__(
        self,
        *,
        trust_level: str = ClockTrustLevel.LOCAL_UNVERIFIED,
        source: str = "host-system-clock",
    ) -> None:
        if trust_level not in ClockTrustLevel.ALL:
            raise ValueError(f"unknown clock trust level {trust_level!r} (45.3)")
        self.trust_level = trust_level
        self.source = source

    def now(self) -> _dt.datetime:
        return _dt.datetime.now(_dt.timezone.utc)

    def monotonic(self) -> float:
        return time.monotonic()


class AirGappedClock(SystemClock):
    """45.5: a local clock that says, in every report, that it is local."""

    def __init__(self, *, source: str = "air-gapped-local-clock") -> None:
        super().__init__(trust_level=ClockTrustLevel.AIR_GAPPED_DECLARED, source=source)


class FixedClock(Clock):
    """A settable clock for tests and for deterministic replay (49.1).

    :meth:`advance` moves both domains together, which is the normal case.
    :meth:`set_wall_clock` moves *only* the wall clock, which is how 45.6 is
    tested: a backwards or forwards wall-clock adjustment must not change a
    freshness window computed from the monotonic domain.
    """

    def __init__(
        self,
        moment: Any = "2026-01-01T00:00:00Z",
        *,
        monotonic: float = 1000.0,
        trust_level: str = ClockTrustLevel.SYNCHRONIZED,
        source: str = "fixed-test-clock",
    ) -> None:
        parsed = parse_iso(moment) if isinstance(moment, str) else moment
        if parsed is None:
            raise ValueError(f"FixedClock could not parse {moment!r}")
        self._now: _dt.datetime = parsed
        self._monotonic = float(monotonic)
        self.trust_level = trust_level
        self.source = source

    def now(self) -> _dt.datetime:
        return self._now

    def monotonic(self) -> float:
        return self._monotonic

    def advance(self, seconds: float) -> "FixedClock":
        """Move both domains forward.  Refuses to move monotonic backwards."""
        if seconds < 0:
            raise ValueError(
                "a monotonic clock does not run backwards; use set_wall_clock to "
                "model a wall-clock adjustment (45.6)"
            )
        self._now = self._now + _dt.timedelta(seconds=seconds)
        self._monotonic += float(seconds)
        return self

    def set_wall_clock(self, moment: Any) -> "FixedClock":
        """Adjust the wall clock alone (45.6's adversarial case)."""
        parsed = parse_iso(moment) if isinstance(moment, str) else moment
        if parsed is None:
            raise ValueError(f"FixedClock could not parse {moment!r}")
        self._now = parsed
        return self


@dataclass(frozen=True)
class TimeJudgment:
    """A verifier's complete answer about time (45.3, 45.4)."""

    status: str
    issuer_asserted_time: Optional[str]
    signed_validity_interval: Optional[Dict[str, Optional[str]]]
    verifier_evaluation_time: str
    clock_source: str
    clock_trust_level: str
    reason: str = ""

    @property
    def is_current(self) -> bool:
        return self.status == TimeStatus.CURRENT

    def to_canonical(self) -> Dict[str, Any]:
        record: Dict[str, Any] = {
            "time_status": self.status,
            "issuer_asserted_time": self.issuer_asserted_time,
            "signed_validity_interval": self.signed_validity_interval,
            "verifier_evaluation_time": self.verifier_evaluation_time,
            "clock_source": self.clock_source,
            "clock_trust_level": self.clock_trust_level,
        }
        if self.reason:
            record["reason"] = self.reason
        return record


def evaluate_validity(
    clock: Clock,
    *,
    not_before: Optional[str] = None,
    not_after: Optional[str] = None,
    issued_at: Optional[str] = None,
    staleness_seconds: Optional[float] = None,
    max_clock_skew_seconds: float = 0.0,
) -> TimeJudgment:
    """Decide the 45.4 status of a validity interval against a supplied clock.

    The order of the checks is the order of the answers a reader wants:

    1. no usable clock, or an interval that cannot be parsed, is
       ``TIME_INDETERMINATE`` -- 45.5 forbids reporting it as ``CURRENT``;
    2. an inverted interval (``not_after`` before ``not_before``) is a
       ``CLOCK_POLICY_VIOLATION``, because the issuer asserted something that
       cannot be true rather than something that is merely no longer true;
    3. before the window is ``NOT_YET_VALID``;
    4. after the window is ``EXPIRED``;
    5. inside the window but older than a declared freshness bound is
       ``STALE`` -- 22-style "valid but too old to rely on";
    6. otherwise ``CURRENT``.

    ``max_clock_skew_seconds`` widens the window on both ends.  It defaults to
    zero: skew tolerance is a policy decision a deployment must make on
    purpose, and a default that silently accepted a minute of drift would be
    a default that silently accepted a minute of expired credential.
    """
    evaluation = clock.now()
    interval: Dict[str, Optional[str]] = {"not_before": not_before, "not_after": not_after}
    base = {
        "issuer_asserted_time": issued_at,
        "signed_validity_interval": interval if (not_before or not_after) else None,
        "verifier_evaluation_time": iso(evaluation),
        "clock_source": clock.source,
        "clock_trust_level": clock.trust_level,
    }

    if not clock.usable_for_expiry:
        return TimeJudgment(
            status=TimeStatus.TIME_INDETERMINATE,
            reason=(
                "the verifier declares no usable clock; 45.5 forbids representing an "
                "indeterminate time claim as current"
            ),
            **base,
        )

    start = parse_iso(not_before) if not_before else None
    end = parse_iso(not_after) if not_after else None
    if (not_before and start is None) or (not_after and end is None):
        return TimeJudgment(
            status=TimeStatus.TIME_INDETERMINATE,
            reason="the asserted validity interval could not be parsed as ISO-8601 (45.4)",
            **base,
        )
    if start is not None and end is not None and end < start:
        return TimeJudgment(
            status=TimeStatus.CLOCK_POLICY_VIOLATION,
            reason=(
                "the issuer asserted a validity interval that ends before it begins; "
                "this is a malformed assertion, not an expiry (45.4)"
            ),
            **base,
        )

    skew = _dt.timedelta(seconds=max(0.0, float(max_clock_skew_seconds)))
    if start is not None and evaluation < (start - skew):
        return TimeJudgment(
            status=TimeStatus.NOT_YET_VALID,
            reason=f"evaluation time precedes not_before={not_before}",
            **base,
        )
    if end is not None and evaluation > (end + skew):
        return TimeJudgment(
            status=TimeStatus.EXPIRED,
            reason=f"evaluation time follows not_after={not_after}",
            **base,
        )

    if staleness_seconds is not None and issued_at:
        issued = parse_iso(issued_at)
        if issued is None:
            return TimeJudgment(
                status=TimeStatus.TIME_INDETERMINATE,
                reason="issued_at could not be parsed, so freshness cannot be judged",
                **base,
            )
        age = (evaluation - issued).total_seconds()
        if age > float(staleness_seconds):
            return TimeJudgment(
                status=TimeStatus.STALE,
                reason=(
                    f"the assertion is {age:.0f}s old against a freshness bound of "
                    f"{float(staleness_seconds):.0f}s"
                ),
                **base,
            )

    return TimeJudgment(status=TimeStatus.CURRENT, reason="", **base)
