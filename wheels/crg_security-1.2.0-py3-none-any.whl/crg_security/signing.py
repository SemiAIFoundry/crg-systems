"""Signature profiles, a registry, and the 14.5 Ed25519 baseline.

Normative basis: 14.3 (canonicalization), 14.4 (algorithm-tagged hashes),
14.5 (Ed25519 baseline, enterprise profiles, and what a signature proves),
9.2 (dependency-light verification zone), 6.6 (fail closed), 61 (the release
artifact manifest, and ``release-manifest.sig``).

Three ideas, in the order they matter.

**A profile is a value, not an assumption.**  Every signature carries the name
of the profile that produced it, and a verifier resolves that name through
:data:`PROFILE_REGISTRY`.  A profile it does not implement is
:class:`~crg_security.errors.UnsupportedProfileError` -- refused, never
guessed at, never "well, the bytes are the right length".  This is the single
most load-bearing rule in the module: an implementation that accepts an
unknown profile by attempting its default algorithm has converted profile
agility into a downgrade oracle.

**Ed25519 is real when it is present and absent when it is not.**  The
profile object reports :attr:`SignatureProfile.available`, and an unavailable
profile raises on use.  There is no path by which an artifact stamped
``Ed25519`` was produced by anything else.

**A signature proves control of a key over content.**  14.5 says so and
:class:`VerificationResult` repeats it in the affirmative case, because the
place where that sentence stops being read is exactly the place where someone
concludes that a signed certificate is a correct certificate.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import secrets
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, Mapping, Optional, Sequence, Tuple, Union

from crg_model.canonical import canonical_bytes, canonical_json, content_hash

from .clock import Clock, iso
from .errors import (
    ConfigurationError,
    ProfileUnavailableError,
    SecurityError,
    UnsupportedProfileError,
)
from .profile import PRODUCTION_CRYPTO_AVAILABLE, require_production_crypto

__all__ = [
    "SIGNATURE_PROFILE",
    "ED25519_PROFILE",
    "HMAC_TEST_PROFILE",
    "SIGNATURE_PROVES",
    "SIGNATURE_DOES_NOT_PROVE",
    "SignatureProfile",
    "Ed25519Profile",
    "HmacTestProfile",
    "PROFILE_REGISTRY",
    "register_profile",
    "get_profile",
    "supported_profiles",
    "SigningKey",
    "VerificationKey",
    "KeyRing",
    "generate_keypair",
    "Signature",
    "VerificationResult",
    "sign",
    "verify",
    "sign_release_manifest",
    "verify_release_manifest",
    "RELEASE_MANIFEST_SIGNATURE_VERSION",
    "BUNDLE_MANIFEST_SIGNATURE_VERSION",
    "bundle_signature_descriptor",
    "sign_bundle_manifest",
    "verify_bundle_manifest",
]

#: 14.5: "The baseline portable profile SHOULD support Ed25519 signatures over
#: canonical manifests."  This is the name that appears in artifacts.
ED25519_PROFILE = "Ed25519"

#: The symmetric stand-in that :mod:`etq_federation` already ships.  Kept in
#: the registry so that existing artifacts remain *verifiable*, and labelled
#: as test-only so they remain *identifiable*.
HMAC_TEST_PROFILE = "HMAC-SHA256-TEST"

#: The profile this package prefers when it can.
SIGNATURE_PROFILE = ED25519_PROFILE if PRODUCTION_CRYPTO_AVAILABLE else HMAC_TEST_PROFILE

SIGNATURE_PROVES: Tuple[str, ...] = (
    "control of the named signing key over exactly the signed canonical content",
)

#: 14.5, second sentence, as data.
SIGNATURE_DOES_NOT_PROVE: Tuple[str, ...] = (
    "that the signed content is scientifically correct",
    "that the signed content is mathematically correct",
    "that the signed content is commercially correct",
    "that the signer was authorized by any particular organization",
    "that the issuer's asserted time is true (45.2)",
)


# ==========================================================================
# profiles
# ==========================================================================
class SignatureProfile:
    """One signature algorithm, its key shapes, and whether this build has it."""

    name: str = ""
    algorithm: str = ""
    #: Asymmetric profiles separate signing power from verifying power.  This
    #: flag is what a federation policy checks before deciding that a verified
    #: signature means anything to a third party (35.1).
    asymmetric: bool = False
    #: Whether a production deployment may rely on this profile.
    production: bool = False
    warning: str = ""

    @property
    def available(self) -> bool:  # pragma: no cover - overridden
        return True

    def generate(self, key_id: str, holder: str = "") -> Tuple["SigningKey", "VerificationKey"]:
        raise NotImplementedError  # pragma: no cover - abstract

    def sign_bytes(self, message: bytes, key: "SigningKey") -> str:
        raise NotImplementedError  # pragma: no cover - abstract

    def verify_bytes(self, message: bytes, value: str, key: "VerificationKey") -> bool:
        raise NotImplementedError  # pragma: no cover - abstract

    def public_reference(self, key: Union["SigningKey", "VerificationKey"]) -> str:
        raise NotImplementedError  # pragma: no cover - abstract

    def to_canonical(self) -> Dict[str, Any]:
        record: Dict[str, Any] = {
            "profile": self.name,
            "algorithm": self.algorithm,
            "asymmetric": self.asymmetric,
            "production": self.production,
            "available": self.available,
        }
        if self.warning:
            record["warning"] = self.warning
        return record


class Ed25519Profile(SignatureProfile):
    """14.5's baseline portable profile, via :mod:`cryptography`.

    Unavailable builds do not degrade.  :meth:`sign_bytes` raises
    :class:`~crg_security.errors.ProfileUnavailableError`, so the only way an
    artifact carries this profile name is that this code actually ran.
    """

    name = ED25519_PROFILE
    algorithm = "ed25519"
    asymmetric = True
    production = True

    @property
    def available(self) -> bool:
        return PRODUCTION_CRYPTO_AVAILABLE

    # -- key material -------------------------------------------------------
    def generate(self, key_id: str, holder: str = "") -> Tuple["SigningKey", "VerificationKey"]:
        require_production_crypto("Ed25519 key generation")
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric import ed25519

        private = ed25519.Ed25519PrivateKey.generate()
        raw_private = private.private_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PrivateFormat.Raw,
            encryption_algorithm=serialization.NoEncryption(),
        )
        raw_public = private.public_key().public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )
        signing = SigningKey(
            key_id=key_id, profile=self.name, material=raw_private, holder=holder
        )
        verification = VerificationKey(
            key_id=key_id, profile=self.name, material=raw_public, holder=holder
        )
        return signing, verification

    def sign_bytes(self, message: bytes, key: "SigningKey") -> str:
        require_production_crypto("Ed25519 signing")
        from cryptography.hazmat.primitives.asymmetric import ed25519

        private = ed25519.Ed25519PrivateKey.from_private_bytes(key.material)
        return f"{self.algorithm}:{private.sign(message).hex()}"

    def verify_bytes(self, message: bytes, value: str, key: "VerificationKey") -> bool:
        require_production_crypto("Ed25519 verification")
        from cryptography.exceptions import InvalidSignature
        from cryptography.hazmat.primitives.asymmetric import ed25519

        prefix, _, hexvalue = str(value).partition(":")
        if prefix != self.algorithm or not hexvalue:
            return False
        try:
            signature = bytes.fromhex(hexvalue)
        except ValueError:
            return False
        public = ed25519.Ed25519PublicKey.from_public_bytes(key.material)
        try:
            public.verify(signature, message)
        except InvalidSignature:
            return False
        return True

    def public_reference(self, key: Union["SigningKey", "VerificationKey"]) -> str:
        if isinstance(key, VerificationKey):
            return f"ed25519-pub:{key.material.hex()}"
        require_production_crypto("Ed25519 public-key derivation")
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric import ed25519

        private = ed25519.Ed25519PrivateKey.from_private_bytes(key.material)
        raw = private.public_key().public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )
        return f"ed25519-pub:{raw.hex()}"


class HmacTestProfile(SignatureProfile):
    """A keyed MAC.  Test-only, and says so in every artifact it touches.

    Retained for two reasons: :mod:`etq_federation` already produces artifacts
    under this name, and a verifier that cannot check them cannot tell a
    *test-signed* artifact from a *corrupt* one.  Retained with
    ``production = False`` and a warning attached to every verification result,
    because a verifier of a MAC can forge what it verifies.
    """

    name = HMAC_TEST_PROFILE
    algorithm = "hmac-sha256"
    asymmetric = False
    production = False
    warning = (
        "HMAC-SHA256-TEST is a symmetric MAC: the verifier holds the signing key and "
        "can forge any artifact it can verify.  It proves nothing to a third party "
        "and MUST NOT be accepted in a production federation (14.5)."
    )

    @property
    def available(self) -> bool:
        return True

    def generate(self, key_id: str, holder: str = "") -> Tuple["SigningKey", "VerificationKey"]:
        secret = secrets.token_bytes(32)
        signing = SigningKey(key_id=key_id, profile=self.name, material=secret, holder=holder)
        # Symmetric: the "verification" key is the same secret.  Returning it
        # as a distinct object does not make it a public key, and the profile
        # says so; it makes the *shape* uniform so calling code need not care.
        verification = VerificationKey(
            key_id=key_id, profile=self.name, material=secret, holder=holder
        )
        return signing, verification

    def sign_bytes(self, message: bytes, key: "SigningKey") -> str:
        return f"{self.algorithm}:{hmac.new(key.material, message, hashlib.sha256).hexdigest()}"

    def verify_bytes(self, message: bytes, value: str, key: "VerificationKey") -> bool:
        expected = f"{self.algorithm}:{hmac.new(key.material, message, hashlib.sha256).hexdigest()}"
        return hmac.compare_digest(expected, str(value))

    def public_reference(self, key: Union["SigningKey", "VerificationKey"]) -> str:
        digest = hashlib.sha256(b"crg-key-reference:" + key.material).hexdigest()
        return f"keyref-sha256:{digest[:32]}"


#: The verifier's closed world.  A profile name outside this mapping is
#: refused; :func:`register_profile` is how an enterprise profile (14.5 names
#: X.509, HSM-backed keys, Sigstore, COSE, JWS, or organizational PKI) is
#: added without modifying this module (6.7).
PROFILE_REGISTRY: Dict[str, SignatureProfile] = {
    ED25519_PROFILE: Ed25519Profile(),
    HMAC_TEST_PROFILE: HmacTestProfile(),
}


def register_profile(profile: SignatureProfile, *, replace: bool = False) -> None:
    """Add an enterprise signature profile (14.5, 6.7)."""
    if not isinstance(profile, SignatureProfile):
        raise ConfigurationError("only SignatureProfile instances may be registered")
    if not profile.name:
        raise ConfigurationError("a signature profile must have a name to be selectable")
    if profile.name in PROFILE_REGISTRY and not replace:
        raise ConfigurationError(
            f"signature profile {profile.name!r} is already registered",
            remedy="pass replace=True if you really mean to shadow it",
        )
    PROFILE_REGISTRY[profile.name] = profile


def get_profile(name: str) -> SignatureProfile:
    """Resolve a profile name, or refuse.

    This is the chokepoint 14.5 hangs on.  An unknown name is
    :class:`~crg_security.errors.UnsupportedProfileError` and never a fallback.
    """
    profile = PROFILE_REGISTRY.get(str(name))
    if profile is None:
        raise UnsupportedProfileError(
            f"signature profile {name!r} is not implemented by this verifier",
            remedy=(
                "a verifier MUST reject a profile it does not support rather than "
                "attempting another algorithm; supported profiles are "
                f"{sorted(PROFILE_REGISTRY)}"
            ),
            detail={"declared_profile": str(name), "supported": sorted(PROFILE_REGISTRY)},
        )
    return profile


def supported_profiles(*, production_only: bool = False) -> Tuple[str, ...]:
    return tuple(
        sorted(
            name
            for name, profile in PROFILE_REGISTRY.items()
            if profile.available and (profile.production or not production_only)
        )
    )


# ==========================================================================
# keys
# ==========================================================================
@dataclass(frozen=True)
class SigningKey:
    """Private key material plus the profile it belongs to.

    ``material`` never appears in :meth:`to_canonical`, and ``__repr__`` is
    overridden, because 44.4 forbids secrets in logs and a dataclass repr is
    the most common accidental log line in Python.
    """

    key_id: str
    profile: str
    material: bytes
    holder: str = ""

    def __post_init__(self) -> None:
        if not str(self.key_id).strip():
            raise SecurityError("a signing key requires an identity (14.1)")
        if self.profile not in PROFILE_REGISTRY:
            raise UnsupportedProfileError(f"unknown signature profile {self.profile!r}")
        if not isinstance(self.material, (bytes, bytearray)) or len(self.material) < 16:
            raise SecurityError(
                "signing key material must be at least 16 bytes",
                remedy="use crg_security.signing.generate_keypair",
            )
        object.__setattr__(self, "material", bytes(self.material))

    def __repr__(self) -> str:
        return f"SigningKey(key_id={self.key_id!r}, profile={self.profile!r}, material=<redacted>)"

    @property
    def public_reference(self) -> str:
        return get_profile(self.profile).public_reference(self)

    def to_canonical(self) -> Dict[str, Any]:
        record = {
            "key_id": self.key_id,
            "profile": self.profile,
            "public_reference": self.public_reference,
        }
        if self.holder:
            record["holder"] = self.holder
        return record


@dataclass(frozen=True)
class VerificationKey:
    """The half a verifier needs.  For an asymmetric profile it is public."""

    key_id: str
    profile: str
    material: bytes
    holder: str = ""
    revoked: bool = False

    def __post_init__(self) -> None:
        if not str(self.key_id).strip():
            raise SecurityError("a verification key requires an identity (14.1)")
        if self.profile not in PROFILE_REGISTRY:
            raise UnsupportedProfileError(f"unknown signature profile {self.profile!r}")
        object.__setattr__(self, "material", bytes(self.material))

    def __repr__(self) -> str:
        kind = "public" if get_profile(self.profile).asymmetric else "<redacted-secret>"
        return f"VerificationKey(key_id={self.key_id!r}, profile={self.profile!r}, {kind})"

    @property
    def public_reference(self) -> str:
        return get_profile(self.profile).public_reference(self)

    def to_canonical(self) -> Dict[str, Any]:
        record: Dict[str, Any] = {
            "key_id": self.key_id,
            "profile": self.profile,
            "public_reference": self.public_reference,
            "revoked": self.revoked,
        }
        if self.holder:
            record["holder"] = self.holder
        return record


class KeyRing:
    """A verifier's set of verification keys, addressed by key identity.

    Supports revocation, because 14.5's enterprise profiles are meaningless
    without it and 44.6 lists compromised signing keys as a threat.  A revoked
    key still *verifies* mathematically; :func:`verify` refuses it anyway, and
    says which of the two happened, because "the signature is valid but the
    key was revoked on this date" and "the signature is invalid" are different
    facts for an investigator.
    """

    def __init__(self, keys: Iterable[VerificationKey] = ()) -> None:
        self._keys: Dict[str, VerificationKey] = {}
        self._revocation_reasons: Dict[str, str] = {}
        for key in keys:
            self.add(key)

    def add(self, key: VerificationKey) -> "KeyRing":
        if not isinstance(key, VerificationKey):
            raise ConfigurationError("only VerificationKey objects may enter a key ring")
        self._keys[key.key_id] = key
        return self

    def revoke(self, key_id: str, *, reason: str = "") -> None:
        key = self._keys.get(key_id)
        if key is None:
            raise ConfigurationError(f"no key {key_id!r} to revoke")
        self._keys[key_id] = VerificationKey(
            key_id=key.key_id,
            profile=key.profile,
            material=key.material,
            holder=key.holder,
            revoked=True,
        )
        self._revocation_reasons[key_id] = reason or "unspecified"

    def get(self, key_id: str) -> Optional[VerificationKey]:
        return self._keys.get(key_id)

    def __contains__(self, key_id: object) -> bool:
        return key_id in self._keys

    def __len__(self) -> int:
        return len(self._keys)

    @property
    def key_ids(self) -> Tuple[str, ...]:
        return tuple(sorted(self._keys))

    def revocation_reason(self, key_id: str) -> str:
        return self._revocation_reasons.get(key_id, "")


def generate_keypair(
    key_id: str, *, profile: str = SIGNATURE_PROFILE, holder: str = ""
) -> Tuple[SigningKey, VerificationKey]:
    """Generate a key pair under ``profile`` (14.5)."""
    return get_profile(profile).generate(key_id, holder)


def _as_ring(keys: Any) -> KeyRing:
    if keys is None:
        return KeyRing()
    if isinstance(keys, KeyRing):
        return keys
    if isinstance(keys, VerificationKey):
        return KeyRing((keys,))
    if isinstance(keys, Mapping):
        return KeyRing(tuple(keys.values()))
    return KeyRing(tuple(keys))


# ==========================================================================
# signatures
# ==========================================================================
@dataclass(frozen=True)
class Signature:
    """A signature over canonical content (14.3, 14.5)."""

    profile: str
    algorithm: str
    key_id: str
    key_reference: str
    value: str
    payload_hash: str
    created_at: Optional[str] = None
    excluded_fields: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(
            self, "excluded_fields", tuple(sorted(str(f) for f in self.excluded_fields))
        )

    @property
    def is_production_profile(self) -> bool:
        profile = PROFILE_REGISTRY.get(self.profile)
        return bool(profile and profile.production)

    def to_canonical(self) -> Dict[str, Any]:
        record: Dict[str, Any] = {
            "profile": self.profile,
            "algorithm": self.algorithm,
            "key_id": self.key_id,
            "key_reference": self.key_reference,
            "value": self.value,
            "payload_hash": self.payload_hash,
            "excluded_fields": list(self.excluded_fields),
        }
        if self.created_at is not None:
            record["created_at"] = self.created_at
        return record

    @classmethod
    def from_canonical(cls, record: Mapping[str, Any]) -> "Signature":
        return cls(
            profile=str(record["profile"]),
            algorithm=str(record.get("algorithm") or ""),
            key_id=str(record["key_id"]),
            key_reference=str(record.get("key_reference") or ""),
            value=str(record["value"]),
            payload_hash=str(record.get("payload_hash") or ""),
            created_at=record.get("created_at"),
            excluded_fields=tuple(record.get("excluded_fields") or ()),
        )


@dataclass(frozen=True)
class VerificationResult:
    """``ok`` plus the reason, and what the answer does and does not mean."""

    ok: bool
    reason: str
    profile: str = ""
    key_id: str = ""
    production_profile: bool = False
    warnings: Tuple[str, ...] = ()
    proves: Tuple[str, ...] = field(default=SIGNATURE_PROVES)
    does_not_prove: Tuple[str, ...] = field(default=SIGNATURE_DOES_NOT_PROVE)

    def __bool__(self) -> bool:
        return self.ok

    def to_canonical(self) -> Dict[str, Any]:
        record: Dict[str, Any] = {
            "verified": self.ok,
            "reason": self.reason,
            "profile": self.profile,
            "key_id": self.key_id,
            "production_profile": self.production_profile,
            "proves": list(self.proves),
            "does_not_prove": list(self.does_not_prove),
        }
        if self.warnings:
            record["warnings"] = list(self.warnings)
        return record


def _payload_bytes(payload: Any, excluded_fields: Sequence[str]) -> bytes:
    """Canonicalize ``payload``, dropping the fields 14.3 says to exclude."""
    if hasattr(payload, "to_canonical"):
        payload = payload.to_canonical()
    if excluded_fields and isinstance(payload, Mapping):
        payload = {k: v for k, v in payload.items() if k not in set(excluded_fields)}
    return canonical_bytes(payload)


def sign(
    payload: Any,
    key: SigningKey,
    *,
    clock: Optional[Clock] = None,
    excluded_fields: Sequence[str] = (),
) -> Signature:
    """Sign the canonical encoding of ``payload`` under ``key``'s profile.

    ``clock`` is optional and, when omitted, the signature simply carries no
    ``created_at``.  It is *not* filled in from the machine clock: 45.2 makes
    an issuance time an assertion of the issuer, and an assertion nobody chose
    to make should be absent rather than invented.
    """
    if not isinstance(key, SigningKey):
        raise ConfigurationError("sign() requires a SigningKey")
    profile = get_profile(key.profile)
    if not profile.available:
        raise ProfileUnavailableError(
            f"signature profile {profile.name!r} is not available in this build",
            remedy="install crg-security[crypto]; this call will not be downgraded",
        )
    message = _payload_bytes(payload, excluded_fields)
    return Signature(
        profile=profile.name,
        algorithm=profile.algorithm,
        key_id=key.key_id,
        key_reference=profile.public_reference(key),
        value=profile.sign_bytes(message, key),
        payload_hash=content_hash(
            {k: v for k, v in payload.items() if k not in set(excluded_fields)}
            if (excluded_fields and isinstance(payload, Mapping))
            else (payload.to_canonical() if hasattr(payload, "to_canonical") else payload)
        ),
        created_at=iso(clock.now()) if clock is not None else None,
        excluded_fields=tuple(excluded_fields),
    )


def verify(
    payload: Any,
    signature: Optional[Union[Signature, Mapping[str, Any]]],
    public_key: Any,
    *,
    require_production_profile: bool = False,
) -> VerificationResult:
    """Verify ``signature`` over ``payload``, failing closed at every step.

    The checks, and why each is a *failure* rather than a shrug:

    * **absent signature** -- an unsigned artifact is unverified, and 6.6 makes
      unverified a refusal;
    * **no key supplied** -- an unchecked signature is not a passed signature;
    * **unknown profile** -- raises :class:`UnsupportedProfileError`; see
      :func:`get_profile`;
    * **unavailable profile** -- this build cannot check it, so it will not
      claim to have;
    * **profile/key mismatch** -- an Ed25519 signature checked against an HMAC
      key is a category error, and category errors in signature code are how
      cross-profile confusion attacks start;
    * **revoked key** -- 44.6 lists compromised signing keys; a revoked key
      fails with a distinct reason so the log distinguishes revocation from
      forgery;
    * **key-reference mismatch** -- the artifact names a different key than the
      ring entry with that id, which means the id was reused;
    * **bad signature** -- the ordinary case.

    ``require_production_profile=True`` additionally refuses the test MAC,
    which is what a federation policy should set (35.1).
    """
    if signature is None:
        return VerificationResult(
            ok=False,
            reason="no signature is present on the artifact (14.5, 35.2)",
        )
    if isinstance(signature, Mapping):
        signature = Signature.from_canonical(signature)

    profile = get_profile(signature.profile)  # raises on unknown, by design
    if not profile.available:
        return VerificationResult(
            ok=False,
            reason=(
                f"signature profile {profile.name!r} is declared but this build cannot "
                "perform it; an unverifiable signature is a failure, not a pass (6.6)"
            ),
            profile=profile.name,
            key_id=signature.key_id,
        )
    if require_production_profile and not profile.production:
        return VerificationResult(
            ok=False,
            reason=(
                f"profile {profile.name!r} is not a production profile and this verifier "
                "was configured to require one (14.5)"
            ),
            profile=profile.name,
            key_id=signature.key_id,
            warnings=(profile.warning,) if profile.warning else (),
        )

    ring = _as_ring(public_key)
    if len(ring) == 0:
        return VerificationResult(
            ok=False,
            reason=(
                "no verification key was supplied; an unchecked signature is a failure, "
                "not a pass (6.6)"
            ),
            profile=profile.name,
            key_id=signature.key_id,
        )
    key = ring.get(signature.key_id)
    if key is None:
        return VerificationResult(
            ok=False,
            reason=(
                f"no key {signature.key_id!r} in the verifier's key ring "
                f"(known: {', '.join(ring.key_ids) or 'none'})"
            ),
            profile=profile.name,
            key_id=signature.key_id,
        )
    if key.profile != signature.profile:
        return VerificationResult(
            ok=False,
            reason=(
                f"signature declares profile {signature.profile!r} but key "
                f"{key.key_id!r} is a {key.profile!r} key"
            ),
            profile=profile.name,
            key_id=signature.key_id,
        )
    if key.revoked:
        return VerificationResult(
            ok=False,
            reason=(
                f"key {key.key_id!r} is revoked "
                f"({ring.revocation_reason(key.key_id) or 'no reason recorded'}); "
                "a revoked key does not authenticate an artifact regardless of the "
                "mathematics (44.6)"
            ),
            profile=profile.name,
            key_id=signature.key_id,
        )
    if signature.key_reference and signature.key_reference != key.public_reference:
        return VerificationResult(
            ok=False,
            reason=(
                "the signature's key reference does not match the ring entry with that "
                "key id; the identifier has been reused for different material"
            ),
            profile=profile.name,
            key_id=signature.key_id,
        )

    message = _payload_bytes(payload, signature.excluded_fields)
    if not profile.verify_bytes(message, signature.value, key):
        return VerificationResult(
            ok=False,
            reason="signature does not verify over the canonical payload (14.3)",
            profile=profile.name,
            key_id=signature.key_id,
        )
    return VerificationResult(
        ok=True,
        reason=(
            f"signature verifies under {profile.name}; a valid signature proves control "
            "of the signing key over the signed content and nothing about scientific, "
            "mathematical, or commercial correctness (14.5)"
        ),
        profile=profile.name,
        key_id=signature.key_id,
        production_profile=profile.production,
        warnings=(profile.warning,) if profile.warning else (),
    )


# ==========================================================================
# release-manifest.sig (61)
# ==========================================================================
RELEASE_MANIFEST_SIGNATURE_VERSION = "1.0"
BUNDLE_MANIFEST_SIGNATURE_VERSION = "1.0"


def bundle_signature_descriptor(key: SigningKey) -> Dict[str, Any]:
    """Descriptor embedded in a §39 manifest before that manifest is signed."""
    profile = get_profile(key.profile)
    return {
        "signature_version": BUNDLE_MANIFEST_SIGNATURE_VERSION,
        "profile": key.profile,
        "algorithm": profile.algorithm,
        "key_id": key.key_id,
        "key_reference": profile.public_reference(key),
        "path": "signatures/manifest.sig",
        "signed_payload": "CRG-BUNDLE-MANIFEST-HASH-V1",
    }


def sign_bundle_manifest(
    manifest_bytes: bytes, manifest_hash: str, key: SigningKey, *, clock: Clock,
) -> Dict[str, Any]:
    """Sign an already-canonical §39 manifest without creating a hash cycle."""
    raw = bytes(manifest_bytes)
    actual = f"sha256:{hashlib.sha256(raw).hexdigest()}"
    if actual != manifest_hash:
        raise SecurityError("supplied bundle manifest hash does not match its raw bytes")
    manifest = json.loads(raw.decode("utf-8"))
    descriptor = bundle_signature_descriptor(key)
    if descriptor not in (manifest.get("signatures") or []):
        raise SecurityError("bundle manifest does not carry the signing-key descriptor")
    header = {
        "signature_version": BUNDLE_MANIFEST_SIGNATURE_VERSION,
        "artifact": "manifest.json",
        "manifest_hash": actual,
        "canonical_hash": content_hash(manifest),
        "signed_at": iso(clock.now()),
        "clock_source": clock.source,
        "clock_trust_level": clock.trust_level,
        "signer_key_id": key.key_id,
        "signature_profile": key.profile,
    }
    return {
        "signed": header,
        "signature": sign(header, key, clock=clock).to_canonical(),
        "proves": list(SIGNATURE_PROVES),
        "does_not_prove": list(SIGNATURE_DOES_NOT_PROVE),
    }


def verify_bundle_manifest(
    manifest_bytes: bytes, signature_document: Mapping[str, Any], keys: Any,
    *, require_production_profile: bool = True,
) -> VerificationResult:
    """Verify a §39 signature document and its manifest descriptor binding."""
    raw = bytes(manifest_bytes)
    try:
        manifest = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        return VerificationResult(ok=False, reason=f"manifest is not JSON: {error}")
    signed = signature_document.get("signed")
    if not isinstance(signed, Mapping):
        return VerificationResult(ok=False, reason="bundle signature has no signed header")
    actual = f"sha256:{hashlib.sha256(raw).hexdigest()}"
    if signed.get("manifest_hash") != actual or signed.get("canonical_hash") != content_hash(manifest):
        return VerificationResult(ok=False, reason="bundle manifest does not match signed hashes")
    descriptors = manifest.get("signatures") or []
    matching = [d for d in descriptors if isinstance(d, Mapping)
                and d.get("key_id") == signed.get("signer_key_id")
                and d.get("profile") == signed.get("signature_profile")
                and d.get("path") == "signatures/manifest.sig"]
    if not matching:
        return VerificationResult(
            ok=False, reason="signed key/profile is not declared by the bundle manifest"
        )
    return verify(
        signed, signature_document.get("signature"), keys,
        require_production_profile=require_production_profile,
    )


def sign_release_manifest(
    manifest_path: str,
    key: SigningKey,
    *,
    clock: Clock,
    signature_path: Optional[str] = None,
    write: bool = True,
) -> Dict[str, Any]:
    """Produce ``release-manifest.sig`` for an existing ``PUBLIC_RELEASE_MANIFEST.json``.

    Two commitments, deliberately, because they catch different attacks:

    ``manifest_hash`` is SHA-256 over the **raw file bytes**, so a byte the
    publisher did not intend -- reordered keys, changed whitespace, an
    appended field a lax parser ignores -- is detected.

    ``canonical_hash`` is 14.3/14.4 over the **parsed structure**, so a
    consumer who re-serializes the manifest (which every JSON toolchain does)
    can still check the signature without having preserved the original bytes.

    The signature covers a small header naming both.  Signing the header
    rather than the manifest means the profile, key, and time assertion are
    inside the signed region: an attacker cannot relabel a test-profile
    signature as Ed25519 without invalidating it.
    """
    with open(manifest_path, "rb") as handle:
        raw = handle.read()
    manifest = json.loads(raw.decode("utf-8"))

    signed_header: Dict[str, Any] = {
        "signature_version": RELEASE_MANIFEST_SIGNATURE_VERSION,
        "artifact": os.path.basename(manifest_path),
        "manifest_version": str(manifest.get("manifest_version") or ""),
        "release_version": str(manifest.get("release_version") or ""),
        "hash_algorithm": "sha256",
        "manifest_hash": f"sha256:{hashlib.sha256(raw).hexdigest()}",
        "canonical_hash": content_hash(manifest),
        "artifact_count": int(manifest.get("artifact_count") or len(manifest.get("artifacts") or ())),
        "signed_at": iso(clock.now()),
        "clock_source": clock.source,
        "clock_trust_level": clock.trust_level,
        "signer_key_id": key.key_id,
        "signature_profile": key.profile,
    }
    signature = sign(signed_header, key, clock=clock)
    document: Dict[str, Any] = {
        "signed": signed_header,
        "signature": signature.to_canonical(),
        "proves": list(SIGNATURE_PROVES),
        "does_not_prove": list(SIGNATURE_DOES_NOT_PROVE),
    }
    if write:
        target = signature_path or (os.path.splitext(manifest_path)[0] + ".sig")
        with open(target, "w", encoding="utf-8") as handle:
            handle.write(canonical_json(document) + "\n")
        document["written_to"] = target
    return document


def verify_release_manifest(
    manifest_path: str,
    signature_document: Union[str, Mapping[str, Any]],
    keys: Any,
    *,
    require_production_profile: bool = True,
) -> VerificationResult:
    """Check a ``release-manifest.sig`` against the manifest it names.

    Defaults to requiring a production profile: a release manifest signed with
    a symmetric test MAC tells a downloader nothing, and the default should be
    the one that does not mislead.
    """
    if isinstance(signature_document, str):
        with open(signature_document, encoding="utf-8") as handle:
            document = json.load(handle)
    else:
        document = dict(signature_document)

    signed = document.get("signed")
    if not isinstance(signed, Mapping):
        return VerificationResult(ok=False, reason="the signature document has no signed header")

    with open(manifest_path, "rb") as handle:
        raw = handle.read()
    actual_raw = f"sha256:{hashlib.sha256(raw).hexdigest()}"
    if actual_raw != str(signed.get("manifest_hash")):
        try:
            manifest = json.loads(raw.decode("utf-8"))
        except ValueError:
            manifest = None
        if manifest is None or content_hash(manifest) != str(signed.get("canonical_hash")):
            return VerificationResult(
                ok=False,
                reason=(
                    "the manifest on disk matches neither the signed raw-byte hash nor the "
                    "signed canonical hash; it has been modified since signing"
                ),
                profile=str(signed.get("signature_profile") or ""),
            )
        # Bytes differ, structure matches: report success only after the
        # signature itself checks out, and say which commitment carried it.
    result = verify(
        signed,
        document.get("signature"),
        keys,
        require_production_profile=require_production_profile,
    )
    if result.ok and actual_raw != str(signed.get("manifest_hash")):
        return VerificationResult(
            ok=True,
            reason=(
                result.reason
                + "; note the manifest's raw bytes differ from the signed bytes but its "
                "canonical form (14.3) matches, which is a re-serialization, not a change "
                "of content"
            ),
            profile=result.profile,
            key_id=result.key_id,
            production_profile=result.production_profile,
            warnings=result.warnings + ("manifest was re-serialized since signing",),
        )
    return result
