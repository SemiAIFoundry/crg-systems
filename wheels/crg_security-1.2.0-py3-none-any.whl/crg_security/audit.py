"""A hash-chained, tamper-evident audit log.

Normative basis: 44.7 ("Every authorization-sensitive operation MUST produce
an immutable audit event"), 6.4 (immutable provenance), 14.3 (canonical
encoding), 14.4 (algorithm-tagged hashes), 44.4 (secrets MUST NOT appear in
logs), 44.5 (logs are one of the layers tenant separation must reach), 45.1
(wall-clock time for audit).

"Immutable" is doing real work in 44.7, and an append-only *file* does not
provide it: a file is exactly as immutable as the filesystem permissions of
whoever is investigating the incident.  What can be provided in software is
*tamper evidence*: each entry commits to the hash of the entry before it, so
any edit, deletion, or reordering breaks the chain at a detectable index.

That is a strictly weaker property than immutability and this module says so
rather than implying otherwise.  An attacker with write access can still
rewrite the entire log from the tampered point forward and recompute every
subsequent hash.  Two things constrain that in practice, and both are
supported here rather than assumed:

* :meth:`HashChainedAuditLog.head_hash` can be published, notarized, or
  counter-signed periodically (see :meth:`checkpoint`), which pins every entry
  before the checkpoint; and
* a checkpoint may be signed under a key the log's host does not hold, which
  is the point at which rewriting becomes forgery rather than editing.

:meth:`verify` reports the *first* broken index rather than a boolean, because
"the log is broken" is an alarm and "the log is broken at entry 41, which
claims a redaction by an account that did not exist yet" is an investigation.
"""
from __future__ import annotations

import hashlib
import json
import os
import threading
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from crg_model.canonical import canonical_json

from .clock import Clock, iso
from .errors import AuditIntegrityError, ConfigurationError

__all__ = [
    "AUDIT_EXPORT_FORMAT_VERSION",
    "DEFAULT_AUDIT_EXPORT_LIMIT",
    "GENESIS_HASH",
    "MAX_AUDIT_EXPORT_LIMIT",
    "REDACTED_PLACEHOLDER",
    "SECRET_FIELD_NAMES",
    "AuditEntry",
    "AuditExportVerification",
    "ChainVerification",
    "HashChainedAuditLog",
    "compute_audit_export_hash",
    "scrub_secrets",
    "verify_audit_export",
    "verify_chain",
]

AUDIT_EXPORT_FORMAT_VERSION = "1.0.0"
DEFAULT_AUDIT_EXPORT_LIMIT = 100
MAX_AUDIT_EXPORT_LIMIT = 1000

#: The predecessor of the first entry.  A fixed, recognizable value, so that a
#: log whose first entry claims some other predecessor is detectably truncated
#: at the front -- the attack an "each entry links to the last" scheme misses
#: if the genesis link is left free.
GENESIS_HASH = "sha256:" + "0" * 64

REDACTED_PLACEHOLDER = "<redacted-by-audit-policy>"

#: 44.4: "Secrets MUST NOT appear in logs, exports, or plugin environments
#: without explicit authorization."  Matching is on substrings of the *key*,
#: lowercased, because the field a developer adds next month will be called
#: ``client_secret`` or ``api_token`` and not any name enumerated today.
SECRET_FIELD_NAMES: Tuple[str, ...] = (
    "password",
    "passphrase",
    "secret",
    "token",
    "api_key",
    "apikey",
    "private_key",
    "privatekey",
    "credential",
    "authorization",
    "cookie",
    "session_id",
    "pepper",
    "salt",
    "key_material",
    "wrapped_key",
    "plaintext",
)


def scrub_secrets(value: Any, *, authorized: bool = False) -> Any:
    """Recursively replace secret-looking fields (44.4).

    ``authorized=True`` is the "explicit authorization" 44.4 allows, and it is
    a parameter rather than a configuration flag so that the authorization is
    visible at the call site where somebody decided to exercise it.
    """
    if authorized:
        return value
    if isinstance(value, Mapping):
        scrubbed: Dict[str, Any] = {}
        for key, item in value.items():
            lowered = str(key).lower()
            if any(name in lowered for name in SECRET_FIELD_NAMES):
                scrubbed[str(key)] = REDACTED_PLACEHOLDER
            else:
                scrubbed[str(key)] = scrub_secrets(item)
        return scrubbed
    if isinstance(value, (list, tuple)):
        return [scrub_secrets(item) for item in value]
    return value


@dataclass(frozen=True)
class AuditEntry:
    """One link in the chain (44.7).

    ``decision`` and ``outcome`` are separate on purpose.  A policy decision of
    ``DENY`` with an outcome of ``REFUSED`` is a working control; a decision of
    ``PERMIT`` with an outcome of ``ERROR`` is an availability problem; and a
    decision of ``DENY`` with an outcome of ``COMPLETED`` is the incident you
    built the log to find.
    """

    sequence: int
    timestamp: str
    tenant_id: str
    actor: str
    action: str
    resource: str
    decision: str
    outcome: str
    correlation_id: str = ""
    rule_id: str = ""
    detail: Mapping[str, Any] = field(default_factory=dict)
    previous_hash: str = GENESIS_HASH
    entry_hash: str = ""

    def signed_body(self) -> Dict[str, Any]:
        """Everything the entry hash commits to (which is everything but itself)."""
        return {
            "sequence": self.sequence,
            "timestamp": self.timestamp,
            "tenant_id": self.tenant_id,
            "actor": self.actor,
            "action": self.action,
            "resource": self.resource,
            "decision": self.decision,
            "outcome": self.outcome,
            "correlation_id": self.correlation_id,
            "rule_id": self.rule_id,
            "detail": dict(self.detail),
            "previous_hash": self.previous_hash,
        }

    def compute_hash(self) -> str:
        return "sha256:" + hashlib.sha256(
            canonical_json(self.signed_body()).encode("utf-8")
        ).hexdigest()

    def to_canonical(self) -> Dict[str, Any]:
        record = self.signed_body()
        record["entry_hash"] = self.entry_hash
        return record

    @classmethod
    def from_canonical(cls, record: Mapping[str, Any]) -> "AuditEntry":
        return cls(
            sequence=int(record["sequence"]),
            timestamp=str(record["timestamp"]),
            tenant_id=str(record.get("tenant_id") or ""),
            actor=str(record.get("actor") or ""),
            action=str(record.get("action") or ""),
            resource=str(record.get("resource") or ""),
            decision=str(record.get("decision") or ""),
            outcome=str(record.get("outcome") or ""),
            correlation_id=str(record.get("correlation_id") or ""),
            rule_id=str(record.get("rule_id") or ""),
            detail=dict(record.get("detail") or {}),
            previous_hash=str(record.get("previous_hash") or GENESIS_HASH),
            entry_hash=str(record.get("entry_hash") or ""),
        )


@dataclass(frozen=True)
class ChainVerification:
    """The result of checking a chain end to end."""

    ok: bool
    entries_checked: int
    head_hash: str
    broken_at: Optional[int] = None
    reason: str = ""

    def __bool__(self) -> bool:
        return self.ok

    def to_canonical(self) -> Dict[str, Any]:
        record: Dict[str, Any] = {
            "chain_intact": self.ok,
            "entries_checked": self.entries_checked,
            "head_hash": self.head_hash,
        }
        if not self.ok:
            record["broken_at_sequence"] = self.broken_at
            record["reason"] = self.reason
        return record


@dataclass(frozen=True)
class AuditExportVerification:
    """Independent judgment over one :class:`AuditExportRecord` page.

    ``ok`` means the record is internally self-consistent: its artifact hash,
    page linkage, range metadata, and checkpoint all agree.  It deliberately
    does *not* mean the checkpoint is externally trusted.  That stronger
    statement is carried separately by ``trust_established`` and can only be
    true when a caller supplies either a verification key for the checkpoint
    signature or a checkpoint obtained through an independent channel.
    """

    ok: bool
    entries_checked: int
    artifact_hash: str
    page_head_hash: str
    checkpoint_signature_status: str
    trust_established: bool = False
    reasons: Tuple[str, ...] = ()

    def __bool__(self) -> bool:
        return self.ok

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "ok": self.ok,
            "entries_checked": self.entries_checked,
            "artifact_hash": self.artifact_hash,
            "page_head_hash": self.page_head_hash,
            "checkpoint_signature_status": self.checkpoint_signature_status,
            "trust_established": self.trust_established,
            "reasons": list(self.reasons),
        }


def compute_audit_export_hash(record: Mapping[str, Any]) -> str:
    """Hash an export while excluding its self-referential hash field."""
    projection = {str(key): value for key, value in record.items()
                  if str(key) != "artifact_hash"}
    return "sha256:" + hashlib.sha256(
        canonical_json(projection).encode("utf-8")
    ).hexdigest()


class HashChainedAuditLog:
    """Append-only, hash-chained, optionally tenant-scoped and file-backed.

    There is no ``update``, ``delete``, ``truncate``, or ``__setitem__`` on
    this class, and :meth:`entries` returns a tuple.  A caller that wants to
    tamper with the log must reach into ``_entries``, which is what the
    adversarial test does -- the goal of the test is not to prove tampering is
    impossible (it is not) but that it is *detected*.
    """

    def __init__(
        self,
        *,
        clock: Clock,
        tenant_id: str = "",
        path: Optional[str] = None,
        scrub: bool = True,
        _allow_broken: bool = False,
    ) -> None:
        if clock is None:
            raise ConfigurationError(
                "an audit log requires a supplied clock",
                remedy="45.1 makes audit a wall-clock domain and 45.3 requires the "
                       "clock source to be reportable; pass crg_security.clock.SystemClock()",
            )
        self._clock = clock
        self._tenant_id = str(tenant_id)
        self._entries: List[AuditEntry] = []
        self._path = path
        self._scrub = bool(scrub)
        self._lock = threading.RLock()
        if path:
            os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
            if os.path.exists(path):
                try:
                    with open(path, "r", encoding="utf-8") as handle:
                        for line_number, line in enumerate(handle, 1):
                            if not line.strip():
                                continue
                            payload = json.loads(line)
                            self._entries.append(AuditEntry(**payload))
                except (OSError, ValueError, TypeError, json.JSONDecodeError) as error:
                    raise AuditIntegrityError(
                        f"cannot load audit chain {path!r}: {error}",
                        remedy="restore the last verified audit checkpoint; do not append to an unreadable chain",
                        detail={"path": os.path.abspath(path),
                                "line": locals().get("line_number")},
                    ) from error
                result = verify_chain(self._entries)
                if not result.ok and not _allow_broken:
                    raise AuditIntegrityError(
                        f"the persisted audit chain is broken at sequence "
                        f"{result.broken_at}: {result.reason}",
                        remedy="restore from a verified checkpoint before accepting requests",
                        detail=result.to_canonical(),
                    )

    # -- properties ---------------------------------------------------------
    @property
    def tenant_id(self) -> str:
        return self._tenant_id

    @property
    def head_hash(self) -> str:
        return self._entries[-1].entry_hash if self._entries else GENESIS_HASH

    def __len__(self) -> int:
        return len(self._entries)

    def entries(self) -> Tuple[AuditEntry, ...]:
        with self._lock:
            return tuple(self._entries)

    def records(self) -> List[Dict[str, Any]]:
        with self._lock:
            return [entry.to_canonical() for entry in self._entries]

    # -- append -------------------------------------------------------------
    def append(
        self,
        *,
        actor: str,
        action: str,
        resource: str,
        decision: str,
        outcome: str,
        correlation_id: str = "",
        rule_id: str = "",
        detail: Optional[Mapping[str, Any]] = None,
        tenant_id: Optional[str] = None,
        authorized_secret_disclosure: bool = False,
    ) -> AuditEntry:
        """Append one event and return it, chained to the current head."""
        with self._lock:
            scoped = str(tenant_id if tenant_id is not None else self._tenant_id)
            if self._tenant_id and scoped != self._tenant_id:
                from .errors import TenantIsolationError

                raise TenantIsolationError(
                    f"audit log for tenant {self._tenant_id!r} refused an entry for "
                    f"tenant {scoped!r}",
                    remedy="44.5 makes logs a separation layer; use that tenant's own log",
                )
            entry = AuditEntry(
                sequence=len(self._entries),
                timestamp=iso(self._clock.now()),
                tenant_id=scoped,
                actor=str(actor),
                action=str(action),
                resource=str(resource),
                decision=str(decision),
                outcome=str(outcome),
                correlation_id=str(correlation_id),
                rule_id=str(rule_id),
                detail=scrub_secrets(
                    dict(detail or {}),
                    authorized=(self._scrub is False) or authorized_secret_disclosure,
                ),
                previous_hash=self.head_hash,
            )
            entry = AuditEntry(**{**entry.to_canonical(), "entry_hash": entry.compute_hash()})
            if self._path:
                with open(self._path, "a", encoding="utf-8") as handle:
                    handle.write(canonical_json(entry.to_canonical()) + "\n")
                    handle.flush()
                    os.fsync(handle.fileno())
            self._entries.append(entry)
            return entry

    # -- verification -------------------------------------------------------
    def verify(self) -> ChainVerification:
        with self._lock:
            return verify_chain(self._entries)

    def require_intact(self) -> None:
        """Raise unless the chain verifies (for a caller that wants fail-closed)."""
        result = self.verify()
        if not result.ok:
            raise AuditIntegrityError(
                f"the audit chain is broken at sequence {result.broken_at}: {result.reason}",
                remedy=(
                    "treat every entry from that sequence onward as untrustworthy and "
                    "compare against the last signed checkpoint (44.7)"
                ),
                detail=result.to_canonical(),
            )

    # -- checkpoints --------------------------------------------------------
    def checkpoint(self, *, signing_key: Any = None) -> Dict[str, Any]:
        """A statement of the head, optionally signed.

        A checkpoint countersigned under a key the log's host does not hold is
        what upgrades tamper *evidence* into something an attacker with local
        write access cannot repair, because rewriting history would then
        require forging a signature rather than recomputing hashes.
        """
        with self._lock:
            return self._checkpoint_unlocked(signing_key=signing_key)

    def _checkpoint_unlocked(self, *, signing_key: Any = None) -> Dict[str, Any]:
        record: Dict[str, Any] = {
            "checkpoint_type": "audit-chain-head",
            "tenant_id": self._tenant_id,
            "entry_count": len(self._entries),
            "head_hash": self.head_hash,
            "genesis_hash": GENESIS_HASH,
            "asserted_at": iso(self._clock.now()),
            "clock_source": self._clock.source,
            "clock_trust_level": self._clock.trust_level,
        }
        if signing_key is not None:
            from .signing import sign

            record["signature"] = sign(record, signing_key, clock=self._clock).to_canonical()
        return record

    def export_page(
        self,
        *,
        requested_by: str,
        authority: str,
        after_sequence: int = -1,
        limit: int = DEFAULT_AUDIT_EXPORT_LIMIT,
        signing_key: Any = None,
    ) -> Dict[str, Any]:
        """Emit one bounded, canonical, independently checkable audit page.

        The full chain is verified and the entries, page metadata, checkpoint,
        and optional signature are captured while holding the same lock.  A
        concurrent authorization may therefore appear either wholly before
        or wholly after this snapshot; it cannot split the snapshot.
        """
        actor = str(requested_by).strip()
        named_authority = str(authority).strip()
        if not actor:
            raise ValueError("an audit export requires an authenticated requester")
        if not named_authority:
            raise ValueError("an audit export requires a named records authority")
        if isinstance(after_sequence, bool) or not isinstance(after_sequence, int):
            raise ValueError("after_sequence must be an integer")
        if isinstance(limit, bool) or not isinstance(limit, int):
            raise ValueError("limit must be an integer")
        if after_sequence < -1:
            raise ValueError("after_sequence must be -1 or a non-negative sequence")
        if limit < 1 or limit > MAX_AUDIT_EXPORT_LIMIT:
            raise ValueError(
                f"limit must be between 1 and {MAX_AUDIT_EXPORT_LIMIT}"
            )

        with self._lock:
            full = verify_chain(self._entries)
            if not full.ok:
                raise AuditIntegrityError(
                    f"the audit chain is broken at sequence {full.broken_at}: {full.reason}",
                    remedy="restore the last independently trusted checkpoint before export",
                    detail=full.to_canonical(),
                )
            total = len(self._entries)
            if (total == 0 and after_sequence != -1) or after_sequence >= total:
                # Asking after the current tail is almost always a stale or
                # cross-log cursor.  Equality to the final sequence is the
                # sole valid empty page and is handled below.
                if not (total > 0 and after_sequence == total - 1):
                    raise ValueError(
                        f"after_sequence {after_sequence} is outside this {total}-entry chain"
                    )
            start = after_sequence + 1
            selected = tuple(self._entries[start:start + limit])
            predecessor = (
                GENESIS_HASH if start == 0 else self._entries[start - 1].entry_hash
            )
            next_after = selected[-1].sequence if selected else after_sequence
            has_more = next_after + 1 < total
            page_head = selected[-1].entry_hash if selected else predecessor
            checkpoint = self._checkpoint_unlocked(signing_key=signing_key)
            record: Dict[str, Any] = {
                "record_type": "AuditExportRecord",
                "format_version": AUDIT_EXPORT_FORMAT_VERSION,
                "tenant_id": self._tenant_id,
                "requested_by": actor,
                "authority": named_authority,
                "exported_at": checkpoint["asserted_at"],
                "clock_source": checkpoint["clock_source"],
                "clock_trust_level": checkpoint["clock_trust_level"],
                "range": {
                    "after_sequence": after_sequence,
                    "start_sequence": selected[0].sequence if selected else None,
                    "end_sequence": selected[-1].sequence if selected else None,
                    "entry_count": len(selected),
                    "next_after_sequence": next_after,
                    "has_more": has_more,
                },
                "total_entry_count": total,
                "genesis_hash": GENESIS_HASH,
                "predecessor_hash": predecessor,
                "page_head_hash": page_head,
                "chain_head_hash": full.head_hash,
                "chain_verification": full.to_canonical(),
                "checkpoint_status": (
                    "SIGNED" if "signature" in checkpoint else "UNSIGNED"
                ),
                "checkpoint": checkpoint,
                "entries": [entry.to_canonical() for entry in selected],
                "verification_scope": (
                    "The artifact hash and page links prove internal consistency. "
                    "Authenticating history against host rewrite requires a trusted "
                    "signed checkpoint or an independently published head hash."
                ),
            }
            record["artifact_hash"] = compute_audit_export_hash(record)
            return record

    # -- loading ------------------------------------------------------------
    @classmethod
    def load(
        cls, path: str, *, clock: Clock, tenant_id: str = ""
    ) -> Tuple["HashChainedAuditLog", ChainVerification]:
        """Read a JSONL log back and verify it in the same call.

        Returning the verification alongside the log is deliberate: there is no
        way to obtain a loaded log without also being handed the answer to
        "did this file survive intact", so a caller cannot forget to ask.
        """
        # A forensic loader must return the broken chain and its verdict. The
        # normal constructor remains fail-closed for a live deployment.
        log = cls(clock=clock, tenant_id=tenant_id, path=path, _allow_broken=True)
        entries: List[AuditEntry] = []
        if os.path.exists(path):
            with open(path, encoding="utf-8") as handle:
                for line in handle:
                    line = line.strip()
                    if line:
                        entries.append(AuditEntry.from_canonical(json.loads(line)))
        log._entries = entries
        return log, verify_chain(entries)


def verify_chain(entries: Sequence[AuditEntry]) -> ChainVerification:
    """Check sequence, linkage, and per-entry hash, reporting the first break."""
    previous = GENESIS_HASH
    for index, entry in enumerate(entries):
        if entry.sequence != index:
            return ChainVerification(
                ok=False,
                entries_checked=index,
                head_hash=previous,
                broken_at=entry.sequence,
                reason=(
                    f"entry at position {index} declares sequence {entry.sequence}; "
                    "an entry has been removed, reordered, or inserted"
                ),
            )
        if entry.previous_hash != previous:
            return ChainVerification(
                ok=False,
                entries_checked=index,
                head_hash=previous,
                broken_at=entry.sequence,
                reason=(
                    f"entry {entry.sequence} links to {entry.previous_hash} but the "
                    f"preceding entry hashes to {previous}"
                ),
            )
        recomputed = entry.compute_hash()
        if recomputed != entry.entry_hash:
            return ChainVerification(
                ok=False,
                entries_checked=index,
                head_hash=previous,
                broken_at=entry.sequence,
                reason=(
                    f"entry {entry.sequence} has been modified: it records "
                    f"{entry.entry_hash} but its content hashes to {recomputed}"
                ),
            )
        previous = entry.entry_hash
    return ChainVerification(ok=True, entries_checked=len(entries), head_hash=previous)


def verify_audit_export(
    record: Mapping[str, Any], *, expected_tenant_id: Optional[str] = None,
    verification_key: Any = None,
    trusted_checkpoint: Optional[Mapping[str, Any]] = None,
) -> AuditExportVerification:
    """Verify an exported page without access to the live audit log.

    A partial page is anchored by its declared predecessor and checkpoint. It
    proves the exported suffix is internally linked; only a supplied trusted
    checkpoint or verification key establishes that the live host did not
    rewrite the whole chain before export.
    """
    reasons: List[str] = []
    checked = 0
    page_head = str(record.get("page_head_hash") or "")
    declared_artifact_hash = str(record.get("artifact_hash") or "")
    recomputed_artifact_hash = compute_audit_export_hash(record)
    tenant = str(record.get("tenant_id") or "")
    if record.get("record_type") != "AuditExportRecord":
        reasons.append("record_type is not AuditExportRecord")
    if record.get("format_version") != AUDIT_EXPORT_FORMAT_VERSION:
        reasons.append("unsupported audit export format_version")
    if not tenant:
        reasons.append("tenant_id is empty")
    if expected_tenant_id is not None and tenant != str(expected_tenant_id):
        reasons.append(
            f"tenant_id {tenant!r} does not match expected {str(expected_tenant_id)!r}"
        )
    if declared_artifact_hash != recomputed_artifact_hash:
        reasons.append("artifact_hash does not match canonical export content")

    try:
        range_record = dict(record.get("range") or {})
        after = int(range_record["after_sequence"])
        count = int(range_record["entry_count"])
        next_after = int(range_record["next_after_sequence"])
        has_more = range_record["has_more"]
        if not isinstance(has_more, bool):
            raise TypeError("range.has_more is not a boolean")
        entries_raw = record.get("entries")
        if not isinstance(entries_raw, list):
            raise TypeError("entries is not an array")
        if count != len(entries_raw):
            reasons.append("range.entry_count does not equal the number of entries")
        previous = str(record.get("predecessor_hash") or "")
        if after == -1 and previous != GENESIS_HASH:
            reasons.append("the first page is not anchored to the fixed genesis hash")
        expected_sequence = after + 1
        entries: List[AuditEntry] = []
        for raw in entries_raw:
            if not isinstance(raw, Mapping):
                raise TypeError("an audit entry is not an object")
            entry = AuditEntry.from_canonical(raw)
            entries.append(entry)
            if entry.sequence != expected_sequence:
                reasons.append(
                    f"entry sequence {entry.sequence} does not follow {expected_sequence - 1}"
                )
                break
            if entry.tenant_id != tenant:
                reasons.append(
                    f"entry {entry.sequence} belongs to tenant {entry.tenant_id!r}"
                )
                break
            if entry.previous_hash != previous:
                reasons.append(f"entry {entry.sequence} has a broken predecessor link")
                break
            if entry.compute_hash() != entry.entry_hash:
                reasons.append(f"entry {entry.sequence} content does not match entry_hash")
                break
            checked += 1
            expected_sequence += 1
            previous = entry.entry_hash
        if previous != page_head:
            reasons.append("page_head_hash does not match the exported page")
        expected_start = entries[0].sequence if entries else None
        expected_end = entries[-1].sequence if entries else None
        if range_record.get("start_sequence") != expected_start:
            reasons.append("range.start_sequence does not match the entries")
        if range_record.get("end_sequence") != expected_end:
            reasons.append("range.end_sequence does not match the entries")
        expected_next = expected_end if entries else after
        if next_after != expected_next:
            reasons.append("range.next_after_sequence does not match the page tail")
    except (KeyError, TypeError, ValueError, OverflowError) as error:
        reasons.append(f"malformed range or entry: {error}")
        range_record = {}
        has_more = True

    checkpoint = record.get("checkpoint")
    signature_status = "NOT_PRESENT"
    trust_established = False
    if not isinstance(checkpoint, Mapping):
        reasons.append("checkpoint is missing or is not an object")
        checkpoint = {}
    else:
        if checkpoint.get("checkpoint_type") != "audit-chain-head":
            reasons.append("checkpoint_type is not audit-chain-head")
        if str(checkpoint.get("tenant_id") or "") != tenant:
            reasons.append("checkpoint tenant does not match the export tenant")
        if checkpoint.get("genesis_hash") != GENESIS_HASH:
            reasons.append("checkpoint genesis hash is not the fixed audit genesis")
        if checkpoint.get("head_hash") != record.get("chain_head_hash"):
            reasons.append("checkpoint head does not match chain_head_hash")
        if checkpoint.get("entry_count") != record.get("total_entry_count"):
            reasons.append("checkpoint entry count does not match total_entry_count")
        claimed = record.get("chain_verification")
        if not isinstance(claimed, Mapping) or claimed.get("chain_intact") is not True:
            reasons.append("the exporter did not assert a successful full-chain verification")
        elif (claimed.get("head_hash") != record.get("chain_head_hash")
              or claimed.get("entries_checked") != record.get("total_entry_count")):
            reasons.append("full-chain verification metadata disagrees with the checkpoint")
        if not has_more and page_head != str(record.get("chain_head_hash") or ""):
            reasons.append("a final page does not end at the declared chain head")

        signature = checkpoint.get("signature")
        if signature is not None:
            signature_status = "UNVERIFIED"
            if verification_key is not None:
                from .signing import verify

                payload = {k: v for k, v in checkpoint.items() if k != "signature"}
                verdict = verify(payload, signature, verification_key)
                signature_status = "VERIFIED" if verdict.ok else "FAILED"
                if verdict.ok:
                    trust_established = True
                else:
                    reasons.append(f"checkpoint signature failed: {verdict.reason}")

    if trusted_checkpoint is not None:
        trust_fields = ("checkpoint_type", "tenant_id", "entry_count", "head_hash",
                        "genesis_hash")
        if all(trusted_checkpoint.get(key) == checkpoint.get(key) for key in trust_fields):
            trust_established = True
            if signature_status in {"NOT_PRESENT", "UNVERIFIED"}:
                signature_status = "TRUSTED_CHECKPOINT_MATCH"
        else:
            reasons.append("the supplied trusted checkpoint does not match this export")

    return AuditExportVerification(
        ok=not reasons,
        entries_checked=checked,
        artifact_hash=recomputed_artifact_hash,
        page_head_hash=page_head,
        checkpoint_signature_status=signature_status,
        trust_established=trust_established,
        reasons=tuple(reasons),
    )
