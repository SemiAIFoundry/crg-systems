"""Envelope encryption and 17.4 cryptographic erasure.

Normative basis: 17.1 (``CRYPTOGRAPHICALLY_ERASED`` is a distinct state),
17.2 (a tombstone preserves identity, content hash, object type, dependency
edges, removal reason, authority, time, legal-hold status, and permitted
disclosure), 17.3 (a certificate whose necessary support is gone becomes
``UNVERIFIABLE_REDACTED`` and MUST NOT be reported valid), 17.4 ("Encrypted
objects MAY be rendered inaccessible through controlled destruction of
encryption keys.  Key destruction SHALL be auditable."), 17.5 (legal hold),
44.4 (encryption at rest, customer-managed keys, HSM/KMS, secrets not in
logs), 44.7 (audit), 14.4 (algorithm-tagged hashes), 6.6.

The shape is the standard one and each layer earns its place.

**Per-object data key, wrapped by a per-tenant key.**  Encrypting every object
directly under one tenant key means rotating that key rewrites every object,
and erasing one object is impossible without erasing all of them.  A data key
per object makes erasure *granular* -- destroy one wrapped key, one object
becomes unreadable -- and rotation *cheap*: rewrap the data keys, leave the
ciphertext alone.  It also makes the tenant key a customer-managed key in the
44.4 sense: a deployment that holds its own KEK holds the ability to erase
everything under it, and holds nothing that has to be shipped anywhere.

**Erasure destroys the key and keeps the tombstone.**  After
:meth:`EncryptedObjectStore.cryptographic_erase`, the ciphertext is still
there, the 14.4 content hash of the *plaintext* is still there, the object
type and every dependency edge are still there, and the content is
permanently unreadable.  That is exactly 17.2's list minus the bytes, which is
what 17.2 is for: a certificate that depended on this object can still say
what it depended on, and 17.3 can still be applied to it.

**Destruction requires a log.**  17.4 says key destruction SHALL be auditable,
so :meth:`KeyVault.destroy` takes an audit log and refuses without one.  A
flag that made the log optional would make the "SHALL" advisory.

**What "destroyed" honestly means here.**  Key material is held in a
``bytearray`` and overwritten in place before the reference is dropped, so the
vault does not keep it.  This is not a guarantee that no copy exists anywhere
in the process: CPython may have copied the buffer, the allocator does not
promise anything, and swap exists.  A deployment that needs erasure to be a
*physical* guarantee must hold the key in an HSM or external KMS and destroy
it there -- 44.4 says signing keys SHOULD support exactly that, and
:func:`crg_security.profile.disclosure` already reports that this vault is a
software vault.  What is guaranteed here is that no supported API can decrypt
the object afterwards, and that the attempt is a loud, auditable refusal
rather than a wrong answer.
"""
from __future__ import annotations

import hashlib
import hmac
import os
import secrets
from dataclasses import dataclass
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

from crg_model.canonical import canonical_bytes, content_hash

from .audit import HashChainedAuditLog
from .clock import Clock, iso
from .errors import (
    ConfigurationError,
    KeyDestroyedError,
    LegalHoldError,
    ProfileUnavailableError,
    SecurityError,
    UnsupportedProfileError,
)
from .profile import PRODUCTION_CRYPTO_AVAILABLE, require_production_crypto

__all__ = [
    "AES_GCM_PROFILE",
    "STDLIB_TEST_PROFILE",
    "ENCRYPTION_PROFILE",
    "EncryptionProfile",
    "AesGcmProfile",
    "StdlibCtrHmacTestProfile",
    "ENCRYPTION_PROFILE_REGISTRY",
    "get_encryption_profile",
    "register_encryption_profile",
    "supported_encryption_profiles",
    "TenantKey",
    "KeyDestructionRecord",
    "KeyVault",
    "WrappedDataKey",
    "EncryptedObject",
    "ErasureTombstone",
    "EnvelopeEncryptor",
    "PersistentObjectEnvelopeCodec",
    "EncryptedObjectStore",
    "ErasureStatus",
]

#: 44.4's data-at-rest profile when the optional dependency is present.
AES_GCM_PROFILE = "AES-256-GCM"
#: The standard-library stand-in.  Test-only, and it says so everywhere.
STDLIB_TEST_PROFILE = "SHA256-CTR-HMAC-TEST"


class ErasureStatus:
    """17.1's states that this module can put an object into."""

    ACTIVE = "ACTIVE"
    #: 17.1, verbatim.  The key is gone; identity, hash, and structure remain.
    CRYPTOGRAPHICALLY_ERASED = "CRYPTOGRAPHICALLY_ERASED"
    #: 17.1: the dependent certificate's fate under 17.3.
    UNVERIFIABLE_REDACTED = "UNVERIFIABLE_REDACTED"

    ALL = (ACTIVE, CRYPTOGRAPHICALLY_ERASED, UNVERIFIABLE_REDACTED)


# ==========================================================================
# profiles
# ==========================================================================
class EncryptionProfile:
    """One authenticated-encryption algorithm and whether this build has it.

    Mirrors :class:`crg_security.signing.SignatureProfile` on purpose: the
    same rule applies for the same reason.  A ciphertext carries the name of
    the profile that produced it, an unknown name is refused rather than
    guessed at, and a build that cannot perform a profile raises instead of
    substituting a weaker one.
    """

    name: str = ""
    algorithm: str = ""
    key_bytes: int = 32
    nonce_bytes: int = 12
    production: bool = False
    warning: str = ""

    @property
    def available(self) -> bool:  # pragma: no cover - overridden
        return True

    def generate_key(self) -> bytes:
        return secrets.token_bytes(self.key_bytes)

    def encrypt(self, key: bytes, plaintext: bytes, aad: bytes) -> Tuple[bytes, bytes]:
        raise NotImplementedError  # pragma: no cover - abstract

    def decrypt(self, key: bytes, nonce: bytes, ciphertext: bytes, aad: bytes) -> bytes:
        raise NotImplementedError  # pragma: no cover - abstract

    def to_canonical(self) -> Dict[str, Any]:
        record: Dict[str, Any] = {
            "profile": self.name,
            "algorithm": self.algorithm,
            "key_bits": self.key_bytes * 8,
            "production": self.production,
            "available": self.available,
        }
        if self.warning:
            record["warning"] = self.warning
        return record


class AesGcmProfile(EncryptionProfile):
    """AES-256-GCM via :mod:`cryptography` (44.4).

    Authenticated encryption with associated data, and the associated data is
    not decoration here: :class:`EnvelopeEncryptor` binds the tenant id, the
    object id, and the wrapping key id into the AAD, so a ciphertext moved to
    another tenant or relabelled with another object id fails to authenticate
    rather than decrypting into a plausible-looking object.  44.6 lists
    context substitution as a threat and this is where it is answered.
    """

    name = AES_GCM_PROFILE
    algorithm = "aes-256-gcm"
    key_bytes = 32
    nonce_bytes = 12
    production = True

    @property
    def available(self) -> bool:
        return PRODUCTION_CRYPTO_AVAILABLE

    def encrypt(self, key: bytes, plaintext: bytes, aad: bytes) -> Tuple[bytes, bytes]:
        require_production_crypto("AES-256-GCM encryption")
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM

        nonce = os.urandom(self.nonce_bytes)
        return nonce, AESGCM(bytes(key)).encrypt(nonce, plaintext, aad)

    def decrypt(self, key: bytes, nonce: bytes, ciphertext: bytes, aad: bytes) -> bytes:
        require_production_crypto("AES-256-GCM decryption")
        from cryptography.exceptions import InvalidTag
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM

        try:
            return AESGCM(bytes(key)).decrypt(bytes(nonce), bytes(ciphertext), aad)
        except InvalidTag as exc:
            raise SecurityError(
                "the ciphertext did not authenticate under this key and context",
                remedy="the object has been modified, or it was relabelled with another "
                       "object id or tenant id, which the AAD binds (44.6)",
            ) from exc


class StdlibCtrHmacTestProfile(EncryptionProfile):
    """SHA-256 counter-mode keystream with encrypt-then-MAC.  Test-only.

    Present so that the envelope machinery, the erasure semantics, and the
    tombstone discipline are testable in a standard-library-only build (9.2),
    and labelled ``production = False`` so that a deployment cannot mistake it
    for 44.4's data-at-rest profile.

    Construction, stated plainly so a reader can judge it: the keystream is
    ``SHA256(key || nonce || counter)`` concatenated, XORed with the
    plaintext; the tag is ``HMAC-SHA256(key_mac, nonce || ciphertext || aad)``
    where the encryption and MAC keys are separately derived from the data key
    by HKDF-like expansion.  Encrypt-then-MAC, distinct keys, and the AAD
    inside the tag.  It is not a reviewed cipher construction and this
    docstring does not pretend it is one; it is a stand-in with the right
    *shape*, and the profile name carries ``TEST`` into every artifact it
    touches.
    """

    name = STDLIB_TEST_PROFILE
    algorithm = "sha256-ctr-hmac"
    key_bytes = 32
    nonce_bytes = 16
    production = False
    warning = (
        "SHA256-CTR-HMAC-TEST is a standard-library stand-in, not a reviewed cipher "
        "construction, and MUST NOT be used for data at rest in a deployment that "
        "44.4 applies to.  Install crg-security[crypto] for AES-256-GCM."
    )

    @property
    def available(self) -> bool:
        return True

    @staticmethod
    def _subkeys(key: bytes) -> Tuple[bytes, bytes]:
        enc = hmac.new(bytes(key), b"crg-envelope-enc", hashlib.sha256).digest()
        mac = hmac.new(bytes(key), b"crg-envelope-mac", hashlib.sha256).digest()
        return enc, mac

    @classmethod
    def _keystream(cls, enc_key: bytes, nonce: bytes, length: int) -> bytes:
        blocks: List[bytes] = []
        counter = 0
        while sum(len(b) for b in blocks) < length:
            blocks.append(
                hashlib.sha256(enc_key + nonce + counter.to_bytes(8, "big")).digest()
            )
            counter += 1
        return b"".join(blocks)[:length]

    def encrypt(self, key: bytes, plaintext: bytes, aad: bytes) -> Tuple[bytes, bytes]:
        enc_key, mac_key = self._subkeys(key)
        nonce = os.urandom(self.nonce_bytes)
        stream = self._keystream(enc_key, nonce, len(plaintext))
        body = bytes(a ^ b for a, b in zip(plaintext, stream))
        tag = hmac.new(mac_key, nonce + body + aad, hashlib.sha256).digest()
        return nonce, body + tag

    def decrypt(self, key: bytes, nonce: bytes, ciphertext: bytes, aad: bytes) -> bytes:
        enc_key, mac_key = self._subkeys(key)
        raw = bytes(ciphertext)
        if len(raw) < 32:
            raise SecurityError("ciphertext is too short to carry an authentication tag")
        body, tag = raw[:-32], raw[-32:]
        expected = hmac.new(mac_key, bytes(nonce) + body + aad, hashlib.sha256).digest()
        if not hmac.compare_digest(expected, tag):
            raise SecurityError(
                "the ciphertext did not authenticate under this key and context",
                remedy="the object has been modified, or it was relabelled with another "
                       "object id or tenant id, which the AAD binds (44.6)",
            )
        stream = self._keystream(enc_key, bytes(nonce), len(body))
        return bytes(a ^ b for a, b in zip(body, stream))


ENCRYPTION_PROFILE_REGISTRY: Dict[str, EncryptionProfile] = {
    AES_GCM_PROFILE: AesGcmProfile(),
    STDLIB_TEST_PROFILE: StdlibCtrHmacTestProfile(),
}

#: The profile this package prefers when it can (44.4).
ENCRYPTION_PROFILE = (
    AES_GCM_PROFILE if PRODUCTION_CRYPTO_AVAILABLE else STDLIB_TEST_PROFILE
)


def register_encryption_profile(
    profile: EncryptionProfile, *, replace: bool = False
) -> None:
    """Add an enterprise profile without modifying this module (6.7)."""
    if not isinstance(profile, EncryptionProfile):
        raise ConfigurationError("only EncryptionProfile instances may be registered")
    if not profile.name:
        raise ConfigurationError("an encryption profile must have a name to be selectable")
    if profile.name in ENCRYPTION_PROFILE_REGISTRY and not replace:
        raise ConfigurationError(
            f"encryption profile {profile.name!r} is already registered",
            remedy="pass replace=True if you really mean to shadow it",
        )
    ENCRYPTION_PROFILE_REGISTRY[profile.name] = profile


def get_encryption_profile(name: str) -> EncryptionProfile:
    """Resolve a profile name, or refuse.  Never a fallback (6.6)."""
    profile = ENCRYPTION_PROFILE_REGISTRY.get(str(name))
    if profile is None:
        raise UnsupportedProfileError(
            f"encryption profile {name!r} is not implemented by this build",
            remedy="a decryptor MUST refuse a profile it does not implement rather than "
                   f"attempting another; supported: {sorted(ENCRYPTION_PROFILE_REGISTRY)}",
            detail={"declared_profile": str(name)},
        )
    return profile


def supported_encryption_profiles(*, production_only: bool = False) -> Tuple[str, ...]:
    return tuple(
        sorted(
            name
            for name, profile in ENCRYPTION_PROFILE_REGISTRY.items()
            if profile.available and (profile.production or not production_only)
        )
    )


# ==========================================================================
# keys
# ==========================================================================
@dataclass
class TenantKey:
    """A tenant's key-encryption key.  Material is mutable so it can be erased.

    ``material`` is a ``bytearray`` rather than ``bytes`` for one reason: a
    ``bytes`` object cannot be overwritten, so "destroying" one only drops a
    reference and leaves the value in memory for the garbage collector to
    reach whenever it likes.  The bytearray is zeroed in place.  See the
    module docstring for exactly how much that does and does not claim.
    """

    key_id: str
    tenant_id: str
    profile: str
    material: bytearray
    created_at: str
    purpose: str = "tenant-key-encryption-key"
    customer_managed: bool = False
    destroyed: bool = False

    def __repr__(self) -> str:  # 44.4: never in a log line
        state = "destroyed" if self.destroyed else f"<{len(self.material)} bytes, redacted>"
        return (
            f"TenantKey(key_id={self.key_id!r}, tenant_id={self.tenant_id!r}, "
            f"profile={self.profile!r}, material={state})"
        )

    @property
    def fingerprint(self) -> str:
        """A stable, non-reversing reference to the key.

        Computed once at creation and retained after destruction, so a
        destruction record can name *which* key was destroyed without holding
        anything that could reconstruct it.
        """
        return getattr(self, "_fingerprint", "")

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "key_id": self.key_id,
            "tenant_id": self.tenant_id,
            "profile": self.profile,
            "created_at": self.created_at,
            "purpose": self.purpose,
            "customer_managed": self.customer_managed,
            "destroyed": self.destroyed,
            "key_fingerprint": self.fingerprint,
        }


@dataclass(frozen=True)
class KeyDestructionRecord:
    """The auditable record 17.4 requires of a key destruction.

    Retained forever, by design.  The key is gone; this is the only remaining
    evidence that it ever existed, who destroyed it, when, and under what
    authority, and 17.2's tombstone discipline applied to keys is exactly
    this.
    """

    key_id: str
    tenant_id: str
    key_fingerprint: str
    profile: str
    reason: str
    authority: str
    destroyed_at: str
    clock_source: str
    clock_trust_level: str
    objects_affected: Tuple[str, ...] = ()
    audit_entry_hash: str = ""

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "record_type": "KeyDestructionRecord",
            "key_id": self.key_id,
            "tenant_id": self.tenant_id,
            "key_fingerprint": self.key_fingerprint,
            "profile": self.profile,
            "destruction_reason": self.reason,
            "destruction_authority": self.authority,
            "destroyed_at": self.destroyed_at,
            "clock_source": self.clock_source,
            "clock_trust_level": self.clock_trust_level,
            "objects_affected": list(self.objects_affected),
            "audit_entry_hash": self.audit_entry_hash,
            "spec": "17.4",
            "irreversible": True,
        }


class KeyVault:
    """A software key vault with auditable, irreversible destruction (17.4, 44.4).

    Software, and :func:`crg_security.profile.disclosure` already says so:
    44.4 asks that signing keys SHOULD support HSM or external key management,
    and this is the thing that would be replaced by one.  The interface is
    deliberately the interface a KMS would satisfy -- create, fetch by id,
    destroy by id, and a destruction record -- so replacing it is a
    substitution rather than a rewrite.

    Destroyed key ids are never reused and never resurrected.  :meth:`create`
    refuses a key id that has been destroyed, because a vault in which a new
    key can take a destroyed key's name is a vault in which an erasure can be
    silently undone by an operator who did not realise what they were doing.
    """

    def __init__(self, *, clock: Clock, profile: str = "") -> None:
        if clock is None:
            raise ConfigurationError("a key vault requires a supplied clock (45.1)")
        self._clock = clock
        self._profile_name = str(profile or ENCRYPTION_PROFILE)
        get_encryption_profile(self._profile_name)  # validate eagerly
        self._keys: Dict[str, TenantKey] = {}
        self._destroyed: Dict[str, KeyDestructionRecord] = {}

    @property
    def profile(self) -> str:
        return self._profile_name

    def __len__(self) -> int:
        return len(self._keys)

    @property
    def key_ids(self) -> Tuple[str, ...]:
        return tuple(sorted(self._keys))

    @property
    def destroyed_key_ids(self) -> Tuple[str, ...]:
        return tuple(sorted(self._destroyed))

    def create(
        self,
        *,
        tenant_id: str,
        key_id: str = "",
        profile: str = "",
        customer_managed: bool = False,
        material: Optional[bytes] = None,
    ) -> TenantKey:
        """Create (or import) a tenant key-encryption key.

        ``material`` exists for 44.4's *customer-managed keys*: a deployment
        that generates its KEK in its own HSM imports it here rather than
        letting this process choose it.  Importing sets
        ``customer_managed=True`` so the distinction survives into the
        published key record.
        """
        name = str(key_id or f"tk-{tenant_id}-{secrets.token_hex(4)}")
        if name in self._destroyed:
            raise KeyDestroyedError(
                f"key id {name!r} was destroyed and MUST NOT be reused",
                remedy="17.4: a destroyed key is permanent; choose a new key id",
                detail={"destruction_record": self._destroyed[name].to_canonical()},
            )
        if name in self._keys:
            raise ConfigurationError(f"key {name!r} already exists in this vault")
        profile_name = str(profile or self._profile_name)
        resolved = get_encryption_profile(profile_name)
        if not resolved.available:
            raise ProfileUnavailableError(
                f"encryption profile {profile_name!r} is not available in this build",
                remedy="install crg-security[crypto]; this call will not be downgraded",
            )
        raw = bytes(material) if material is not None else resolved.generate_key()
        if len(raw) != resolved.key_bytes:
            raise ConfigurationError(
                f"profile {profile_name!r} requires a {resolved.key_bytes}-byte key, "
                f"received {len(raw)}"
            )
        key = TenantKey(
            key_id=name,
            tenant_id=str(tenant_id),
            profile=profile_name,
            material=bytearray(raw),
            created_at=iso(self._clock.now()),
            customer_managed=bool(customer_managed or material is not None),
        )
        object.__setattr__(
            key,
            "_fingerprint",
            "sha256:" + hashlib.sha256(b"crg-key-fingerprint:" + raw).hexdigest()[:32],
        )
        self._keys[name] = key
        return key

    def get(self, key_id: str) -> TenantKey:
        """Fetch a live key, or explain that it was destroyed (17.4)."""
        name = str(key_id)
        record = self._destroyed.get(name)
        if record is not None:
            raise KeyDestroyedError(
                f"key {name!r} was destroyed on {record.destroyed_at} by "
                f"{record.authority!r} and cannot be recovered",
                remedy="17.4: this is a permanent, intended condition; the tombstone "
                       "remains and the content does not",
                detail={"destruction_record": record.to_canonical()},
            )
        key = self._keys.get(name)
        if key is None:
            raise ConfigurationError(
                f"no key {name!r} in this vault",
                remedy="a missing key and a destroyed key are different findings; this "
                       "one was never here",
            )
        return key

    def is_destroyed(self, key_id: str) -> bool:
        return str(key_id) in self._destroyed

    def destruction_record(self, key_id: str) -> Optional[KeyDestructionRecord]:
        return self._destroyed.get(str(key_id))

    def destroy(
        self,
        key_id: str,
        *,
        reason: str,
        authority: str,
        audit_log: HashChainedAuditLog,
        objects_affected: Sequence[str] = (),
        legal_hold: bool = False,
    ) -> KeyDestructionRecord:
        """Destroy a key irreversibly and record it (17.4, 17.5, 44.7).

        ``audit_log`` is a required argument, not an option.  17.4's second
        sentence is "Key destruction SHALL be auditable", and a destruction
        that could happen with the log absent would be auditable only by
        convention.  The audit entry is appended *before* the material is
        zeroed, so a crash between the two leaves a log claiming a destruction
        that did not finish -- which is the failure an investigator can
        recover from -- rather than a destruction with no record, which is the
        failure they cannot.
        """
        name = str(key_id)
        if audit_log is None:
            raise ConfigurationError(
                "key destruction requires an audit log",
                remedy="17.4: 'Key destruction SHALL be auditable'; this argument is "
                       "required so that the requirement is not a convention",
            )
        existing = self._destroyed.get(name)
        if existing is not None:
            return existing
        if legal_hold:
            raise LegalHoldError(
                f"key {name!r} protects an object under legal hold and MUST NOT be "
                "destroyed until the hold is released (17.5)",
                remedy="release the hold under authorized policy, then erase",
                detail={"key_id": name},
            )
        if not reason:
            raise ConfigurationError("key destruction requires a stated reason (17.2)")
        if not authority:
            raise ConfigurationError("key destruction requires a named authority (17.2)")
        key = self._keys.get(name)
        if key is None:
            raise ConfigurationError(f"no key {name!r} in this vault to destroy")

        destroyed_at = iso(self._clock.now())
        entry = audit_log.append(
            actor=str(authority),
            action="key.destroyed",
            resource=name,
            decision="PERMIT",
            outcome="COMPLETED",
            tenant_id=key.tenant_id,
            detail={
                "spec": "17.4",
                "key_fingerprint": key.fingerprint,
                "profile": key.profile,
                "reason": reason,
                "objects_affected": list(objects_affected),
                "irreversible": True,
                "clock_source": self._clock.source,
                "clock_trust_level": self._clock.trust_level,
            },
        )

        for index in range(len(key.material)):
            key.material[index] = 0
        key.material = bytearray()
        key.destroyed = True

        record = KeyDestructionRecord(
            key_id=name,
            tenant_id=key.tenant_id,
            key_fingerprint=key.fingerprint,
            profile=key.profile,
            reason=str(reason),
            authority=str(authority),
            destroyed_at=destroyed_at,
            clock_source=self._clock.source,
            clock_trust_level=self._clock.trust_level,
            objects_affected=tuple(str(o) for o in objects_affected),
            audit_entry_hash=entry.entry_hash,
        )
        self._destroyed[name] = record
        del self._keys[name]
        return record

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "profile": self._profile_name,
            "live_keys": [self._keys[k].to_canonical() for k in sorted(self._keys)],
            "destruction_records": [
                self._destroyed[k].to_canonical() for k in sorted(self._destroyed)
            ],
            "custody": (
                "software vault; 44.4 says signing keys SHOULD support HSM or external "
                "key management and this is the component such a deployment replaces"
            ),
        }


# ==========================================================================
# envelopes
# ==========================================================================
@dataclass(frozen=True)
class WrappedDataKey:
    """A per-object data key, encrypted under a tenant key (44.4).

    The plaintext data key exists only inside :meth:`EnvelopeEncryptor.encrypt`
    and :meth:`EnvelopeEncryptor.decrypt`.  It is never stored, never
    returned, and never logged, so the *only* route to the plaintext of an
    object is through the tenant key -- which is precisely the property that
    makes destroying the tenant key an erasure.
    """

    wrapping_key_id: str
    profile: str
    nonce: bytes
    ciphertext: bytes

    def __repr__(self) -> str:  # 44.4
        return (
            f"WrappedDataKey(wrapping_key_id={self.wrapping_key_id!r}, "
            f"profile={self.profile!r}, ciphertext=<{len(self.ciphertext)} bytes>)"
        )

    def to_canonical(self) -> Dict[str, Any]:
        import base64

        return {
            "wrapping_key_id": self.wrapping_key_id,
            "profile": self.profile,
            "nonce": base64.b64encode(bytes(self.nonce)).decode("ascii"),
            "wrapped_key": base64.b64encode(bytes(self.ciphertext)).decode("ascii"),
        }

    @classmethod
    def from_canonical(cls, value: Mapping[str, Any]) -> "WrappedDataKey":
        import base64

        if not isinstance(value, Mapping):
            raise ConfigurationError("wrapped data key must be a mapping")
        try:
            nonce = base64.b64decode(str(value["nonce"]), validate=True)
            ciphertext = base64.b64decode(str(value["wrapped_key"]), validate=True)
        except (KeyError, ValueError, TypeError) as error:
            raise ConfigurationError(f"wrapped data key is malformed: {error}") from error
        return cls(
            wrapping_key_id=str(value.get("wrapping_key_id", "")),
            profile=str(value.get("profile", "")), nonce=nonce, ciphertext=ciphertext,
        )


@dataclass(frozen=True)
class EncryptedObject:
    """Ciphertext plus everything 17.2 will need after the key is gone.

    ``content_hash`` is the 14.4 hash of the **plaintext**.  Keeping it is
    what makes cryptographic erasure compatible with content addressing: after
    erasure the object still knows its own identity, a dependency edge
    pointing at it still resolves to a real thing, and a certificate that
    committed to it can still be shown to have committed to *this* object.
    Keeping the plaintext hash of unreadable content is a deliberate,
    documented disclosure -- an adversary who can guess the plaintext can
    confirm the guess -- and it is the trade 17.2 asks for when it lists
    "content hash" among the fields a tombstone preserves.
    """

    object_id: str
    tenant_id: str
    object_type: str
    profile: str
    content_hash: str
    nonce: bytes
    ciphertext: bytes
    wrapped_key: WrappedDataKey
    created_at: str
    created_by: str = ""
    case_id: Optional[str] = None
    dependency_edges: Tuple[Dict[str, Any], ...] = ()
    legal_hold: bool = False
    status: str = ErasureStatus.ACTIVE

    def __repr__(self) -> str:  # 44.4
        return (
            f"EncryptedObject(object_id={self.object_id!r}, tenant_id={self.tenant_id!r}, "
            f"profile={self.profile!r}, status={self.status!r}, "
            f"ciphertext=<{len(self.ciphertext)} bytes>)"
        )

    def aad(self) -> bytes:
        """The associated data bound into the ciphertext (44.6).

        Tenant, object id, object type, and wrapping key id.  Moving a
        ciphertext to another tenant, relabelling it with another object id,
        or rewrapping it under a different key all break authentication, so a
        context substitution fails loudly instead of decrypting into something
        that looks like a legitimate object of the target context.
        """
        return canonical_bytes(
            {
                "tenant_id": self.tenant_id,
                "object_id": self.object_id,
                "object_type": self.object_type,
                "wrapping_key_id": self.wrapped_key.wrapping_key_id,
            }
        )

    def to_canonical(self) -> Dict[str, Any]:
        import base64

        return {
            "record_type": "EncryptedObject",
            "object_id": self.object_id,
            "tenant_id": self.tenant_id,
            "object_type": self.object_type,
            "encryption_profile": self.profile,
            "content_hash": self.content_hash,
            "nonce": base64.b64encode(bytes(self.nonce)).decode("ascii"),
            "ciphertext": base64.b64encode(bytes(self.ciphertext)).decode("ascii"),
            "wrapped_key": self.wrapped_key.to_canonical(),
            "created_at": self.created_at,
            "created_by": self.created_by,
            "case_id": self.case_id,
            "dependency_edges": [dict(e) for e in self.dependency_edges],
            "legal_hold": self.legal_hold,
            "status": self.status,
        }

    @classmethod
    def from_canonical(cls, value: Mapping[str, Any]) -> "EncryptedObject":
        import base64

        if not isinstance(value, Mapping) or value.get("record_type") != "EncryptedObject":
            raise ConfigurationError("encrypted object record is malformed")
        try:
            nonce = base64.b64decode(str(value["nonce"]), validate=True)
            ciphertext = base64.b64decode(str(value["ciphertext"]), validate=True)
            wrapped = WrappedDataKey.from_canonical(value["wrapped_key"])
        except (KeyError, ValueError, TypeError) as error:
            raise ConfigurationError(f"encrypted object record is malformed: {error}") from error
        return cls(
            object_id=str(value.get("object_id", "")),
            tenant_id=str(value.get("tenant_id", "")),
            object_type=str(value.get("object_type", "")),
            profile=str(value.get("encryption_profile", "")),
            content_hash=str(value.get("content_hash", "")),
            nonce=nonce, ciphertext=ciphertext, wrapped_key=wrapped,
            created_at=str(value.get("created_at", "")),
            created_by=str(value.get("created_by", "")),
            case_id=str(value["case_id"]) if value.get("case_id") else None,
            dependency_edges=tuple(dict(edge) for edge in value.get("dependency_edges", ())),
            legal_hold=bool(value.get("legal_hold", False)),
            status=str(value.get("status", ErasureStatus.ACTIVE)),
        )


@dataclass(frozen=True)
class ErasureTombstone:
    """17.2's tombstone for a cryptographically erased object (17.1, 17.4).

    Every field 17.2 permits, plus the key destruction record, because for a
    cryptographic erasure "removal authority" and "when" are properties of a
    key destruction rather than of a file deletion, and an investigator needs
    to be able to join the two.
    """

    object_id: str
    content_hash: str
    object_type: str
    tenant_id: str
    reason: str
    authority: str
    removed_at: str
    dependency_edges: Tuple[Dict[str, Any], ...] = ()
    legal_hold: bool = False
    permitted_disclosure: str = "identity, hash, type, and dependency structure only"
    status: str = ErasureStatus.CRYPTOGRAPHICALLY_ERASED
    destruction_record: Optional[KeyDestructionRecord] = None
    affected_objects: Tuple[str, ...] = ()

    def to_canonical(self) -> Dict[str, Any]:
        record: Dict[str, Any] = {
            "record_type": "TombstoneRecord",
            "object_id": self.object_id,
            "content_hash": self.content_hash,
            "object_type": self.object_type,
            "tenant_id": self.tenant_id,
            "removal_reason": self.reason,
            "removal_authority": self.authority,
            "removal_time": self.removed_at,
            "legal_hold": self.legal_hold,
            "permitted_disclosure": self.permitted_disclosure,
            "dependency_edges": [dict(e) for e in self.dependency_edges],
            "status": self.status,
            "affected_objects": list(self.affected_objects),
            "erasure_method": "cryptographic (17.4): the key was destroyed, not the bytes",
        }
        if self.destruction_record is not None:
            record["key_destruction"] = self.destruction_record.to_canonical()
        return record


class EnvelopeEncryptor:
    """Per-object data key wrapped by a tenant key (44.4).

    Two encryptions per object and one plaintext data key that never leaves a
    stack frame.  The wrapping key is looked up in the vault at every call
    rather than cached, so an erasure that happened between two calls takes
    effect on the second: a cached key would keep an erased object readable
    for the lifetime of the cache, which is exactly the bug that turns
    "cryptographically erased" into "cryptographically erased, mostly".
    """

    def __init__(self, vault: KeyVault, *, clock: Clock, profile: str = "") -> None:
        if vault is None:
            raise ConfigurationError("envelope encryption requires a key vault")
        if clock is None:
            raise ConfigurationError("envelope encryption requires a supplied clock (45.1)")
        self._vault = vault
        self._clock = clock
        self._profile_name = str(profile or vault.profile)
        get_encryption_profile(self._profile_name)

    @property
    def profile(self) -> str:
        return self._profile_name

    def encrypt(
        self,
        payload: Any,
        *,
        object_id: str,
        tenant_key_id: str,
        object_type: str = "",
        created_by: str = "",
        case_id: Optional[str] = None,
        dependency_edges: Sequence[Mapping[str, Any]] = (),
        legal_hold: bool = False,
    ) -> EncryptedObject:
        """Encrypt ``payload`` under a fresh data key wrapped by the tenant key."""
        if hasattr(payload, "to_canonical"):
            payload = payload.to_canonical()
        tenant_key = self._vault.get(tenant_key_id)
        profile = get_encryption_profile(self._profile_name)
        if not profile.available:
            raise ProfileUnavailableError(
                f"encryption profile {self._profile_name!r} is not available in this build",
                remedy="install crg-security[crypto]; encryption is not downgraded silently",
            )

        resolved_type = str(object_type or _type_of(payload))
        aad = canonical_bytes(
            {
                "tenant_id": tenant_key.tenant_id,
                "object_id": str(object_id),
                "object_type": resolved_type,
                "wrapping_key_id": tenant_key.key_id,
            }
        )
        data_key = profile.generate_key()
        try:
            nonce, ciphertext = profile.encrypt(data_key, canonical_bytes(payload), aad)
            wrap_nonce, wrapped = profile.encrypt(bytes(tenant_key.material), data_key, aad)
        finally:
            data_key = b"\x00" * len(data_key)

        return EncryptedObject(
            object_id=str(object_id),
            tenant_id=tenant_key.tenant_id,
            object_type=resolved_type,
            profile=self._profile_name,
            content_hash=content_hash(payload),
            nonce=nonce,
            ciphertext=ciphertext,
            wrapped_key=WrappedDataKey(
                wrapping_key_id=tenant_key.key_id,
                profile=self._profile_name,
                nonce=wrap_nonce,
                ciphertext=wrapped,
            ),
            created_at=iso(self._clock.now()),
            created_by=str(created_by),
            case_id=str(case_id) if case_id else None,
            dependency_edges=tuple(dict(e) for e in dependency_edges),
            legal_hold=bool(legal_hold),
        )

    def decrypt(self, encrypted: EncryptedObject) -> Any:
        """Unwrap the data key, decrypt, and verify the 14.4 content hash.

        The hash check at the end is not redundant with the AEAD tag.  The tag
        proves the ciphertext was produced under this key and context; the
        hash proves the *plaintext* is the object whose identity the record
        claims.  They fail on different attacks, and after an erasure the hash
        is the only one of the two that is still checkable at all.
        """
        import json as _json

        if encrypted.status != ErasureStatus.ACTIVE:
            raise KeyDestroyedError(
                f"object {encrypted.object_id!r} is {encrypted.status} and cannot be read",
                remedy="17.4: the key was destroyed; the tombstone remains",
                detail={"object_id": encrypted.object_id, "status": encrypted.status},
            )
        profile = get_encryption_profile(encrypted.profile)
        tenant_key = self._vault.get(encrypted.wrapped_key.wrapping_key_id)
        aad = encrypted.aad()
        data_key = profile.decrypt(
            bytes(tenant_key.material),
            encrypted.wrapped_key.nonce,
            encrypted.wrapped_key.ciphertext,
            aad,
        )
        try:
            plaintext = profile.decrypt(data_key, encrypted.nonce, encrypted.ciphertext, aad)
        finally:
            data_key = b"\x00" * len(data_key)
        payload = _json.loads(plaintext.decode("utf-8"))
        if content_hash(payload) != encrypted.content_hash:
            raise SecurityError(
                "the decrypted plaintext does not hash to the recorded content hash",
                remedy="the record's identity and its content disagree; treat the object "
                       "as tampered with (14.4)",
                detail={"object_id": encrypted.object_id},
            )
        return payload


class PersistentObjectEnvelopeCodec:
    """Duck-typed adapter for encrypted persistent content-addressed stores.

    The server package deliberately does not import :mod:`crg_security`; its
    local store accepts an object codec through this tiny protocol instead.
    This adapter is the production implementation of that protocol.  The
    address remains the hash of the canonical *plaintext*.  Randomized
    ciphertext is a storage representation and receives its own separately
    checked hash in the store metadata.

    A codec is bound to exactly one tenant key.  Consequently a process that
    starts with the wrong tenant or key cannot partially read a store and
    cannot silently fall back to plaintext.
    """

    format = "crg-envelope-v1"

    def __init__(self, encryptor: EnvelopeEncryptor, *, tenant_key_id: str) -> None:
        if encryptor is None:
            raise ConfigurationError("persistent encryption requires an envelope encryptor")
        if not str(tenant_key_id).strip():
            raise ConfigurationError("persistent encryption requires a tenant key id")
        self._encryptor = encryptor
        self.tenant_key_id = str(tenant_key_id)

    @property
    def storage_encoding(self) -> str:
        return f"{self.format}:{self._encryptor.profile}"

    @property
    def profile(self) -> str:
        return self._encryptor.profile

    def encode(
        self,
        payload: Any,
        *,
        object_id: str,
        object_type: str,
        created_by: str,
        case_id: Optional[str],
        dependency_edges: Sequence[Mapping[str, Any]],
        legal_hold: bool,
    ) -> Mapping[str, Any]:
        encrypted = self._encryptor.encrypt(
            payload,
            object_id=object_id,
            tenant_key_id=self.tenant_key_id,
            object_type=object_type,
            created_by=created_by,
            case_id=case_id,
            dependency_edges=dependency_edges,
            legal_hold=legal_hold,
        )
        if encrypted.content_hash != object_id:
            raise SecurityError(
                "persistent object address does not match encrypted plaintext identity"
            )
        return encrypted.to_canonical()

    def decode(
        self,
        record: Mapping[str, Any],
        *,
        expected_object_id: str,
        expected_object_type: str,
    ) -> Any:
        encrypted = EncryptedObject.from_canonical(record)
        if encrypted.object_id != str(expected_object_id):
            raise SecurityError("encrypted object id does not match its storage address")
        if encrypted.content_hash != str(expected_object_id):
            raise SecurityError("encrypted plaintext hash does not match its storage address")
        if encrypted.object_type != str(expected_object_type):
            raise SecurityError("encrypted object type does not match store metadata")
        if encrypted.wrapped_key.wrapping_key_id != self.tenant_key_id:
            raise SecurityError("encrypted object is wrapped by a different tenant key")
        return self._encryptor.decrypt(encrypted)


def _type_of(payload: Any) -> str:
    if isinstance(payload, Mapping):
        for key in ("object_type", "record_type"):
            if payload.get(key):
                return str(payload[key])
    return "OpaqueRecord"


# ==========================================================================
# the store
# ==========================================================================
class EncryptedObjectStore:
    """Encrypted objects, erasure, and the tombstones that outlive them.

    Tenant-scoped like everything else in :mod:`crg_security.tenancy`: the
    store is constructed for one tenant and has no method taking a tenant
    argument.

    :meth:`cryptographic_erase` is the whole point of the module.  After it:

    * the object's content is unreachable through any supported API, and the
      attempt raises :class:`~crg_security.errors.KeyDestroyedError` carrying
      the destruction record rather than returning empty or missing;
    * ``content_hash``, ``object_type``, ``object_id``, and every dependency
      edge survive in an :class:`ErasureTombstone` (17.2);
    * dependent certificates are walked and set to ``UNVERIFIABLE_REDACTED``
      (17.3), at the moment of erasure rather than at some later verification
      pass that a caller might never run; and
    * an ``object.cryptographically_erased`` event and a ``key.destroyed``
      event are in the hash-chained audit log (17.4, 44.7).
    """

    def __init__(
        self,
        *,
        tenant_id: str,
        vault: KeyVault,
        clock: Clock,
        audit_log: Optional[HashChainedAuditLog] = None,
        profile: str = "",
    ) -> None:
        if not str(tenant_id).strip():
            raise ConfigurationError("an encrypted object store is tenant-scoped (44.5)")
        self.tenant_id = str(tenant_id)
        self._vault = vault
        self._clock = clock
        # ``is None`` rather than ``or``: an empty audit log is falsy, and
        # ``audit_log or ...`` would silently discard the caller's log and
        # write the destruction record 17.4 requires into a private one.
        self._audit = (
            audit_log
            if audit_log is not None
            else HashChainedAuditLog(clock=clock, tenant_id=self.tenant_id)
        )
        self._encryptor = EnvelopeEncryptor(vault, clock=clock, profile=profile)
        self._objects: Dict[str, EncryptedObject] = {}
        self._tombstones: Dict[str, ErasureTombstone] = {}
        self._dependents: Dict[str, List[str]] = {}
        self._statuses: Dict[str, str] = {}
        #: Every typed edge any object declared, kept flat so that a
        #: tombstone can preserve the edges pointing *at* the erased object as
        #: well as the ones it declared itself.  17.2 says "dependency edges",
        #: not "outgoing dependency edges", and an evidence object that kept
        #: only its own outgoing edges would leave a certificate referring to
        #: a hash with no record of what that hash used to be to it.
        self._edges: List[Dict[str, Any]] = []

    # -- properties ---------------------------------------------------------
    @property
    def audit(self) -> HashChainedAuditLog:
        return self._audit

    @property
    def object_ids(self) -> Tuple[str, ...]:
        return tuple(sorted(self._objects))

    def __len__(self) -> int:
        return len(self._objects)

    # -- writes -------------------------------------------------------------
    def put(
        self,
        payload: Any,
        *,
        object_id: str,
        tenant_key_id: str,
        object_type: str = "",
        created_by: str = "",
        case_id: Optional[str] = None,
        dependency_edges: Sequence[Mapping[str, Any]] = (),
        legal_hold: bool = False,
    ) -> EncryptedObject:
        oid = str(object_id)
        if oid in self._tombstones:
            raise KeyDestroyedError(
                f"object {oid!r} was cryptographically erased and cannot be re-stored "
                "under the same identity",
                remedy="17.2: removal is an authorized act; re-submitting content does "
                       "not undo it",
                detail={"tombstone": self._tombstones[oid].to_canonical()},
            )
        encrypted = self._encryptor.encrypt(
            payload,
            object_id=oid,
            tenant_key_id=tenant_key_id,
            object_type=object_type,
            created_by=created_by,
            case_id=case_id,
            dependency_edges=dependency_edges,
            legal_hold=legal_hold,
        )
        self._objects[oid] = encrypted
        self._statuses[oid] = ErasureStatus.ACTIVE
        for edge in encrypted.dependency_edges:
            if dict(edge) not in self._edges:
                self._edges.append(dict(edge))
            target = str(edge.get("target") or "")
            if target:
                self._dependents.setdefault(target, [])
                if oid not in self._dependents[target]:
                    self._dependents[target].append(oid)
        self._audit.append(
            actor=str(created_by or "crg-security"),
            action="object.encrypted",
            resource=oid,
            decision="PERMIT",
            outcome="COMPLETED",
            tenant_id=self.tenant_id,
            detail={
                "encryption_profile": encrypted.profile,
                "wrapping_key_id": encrypted.wrapped_key.wrapping_key_id,
                "content_hash": encrypted.content_hash,
                "object_type": encrypted.object_type,
            },
        )
        return encrypted

    def set_legal_hold(self, object_id: str, held: bool, *, authority: str) -> EncryptedObject:
        encrypted = self._require(str(object_id))
        updated = EncryptedObject(
            **{**_fields(encrypted), "legal_hold": bool(held)}
        )
        self._objects[updated.object_id] = updated
        self._audit.append(
            actor=str(authority),
            action="legal_hold.changed",
            resource=updated.object_id,
            decision="PERMIT",
            outcome="COMPLETED",
            tenant_id=self.tenant_id,
            detail={"held": bool(held), "spec": "17.5"},
        )
        return updated

    # -- reads --------------------------------------------------------------
    def get(self, object_id: str) -> Any:
        """Decrypt, or explain the erasure.  Never returns partial content."""
        oid = str(object_id)
        tomb = self._tombstones.get(oid)
        if tomb is not None:
            raise KeyDestroyedError(
                f"object {oid!r} was cryptographically erased on {tomb.removed_at} "
                f"by {tomb.authority!r}; its content is permanently unreadable",
                remedy="17.4: the tombstone preserves identity, content hash, type, and "
                       "dependency structure, and that is the whole of what remains",
                detail={"tombstone": tomb.to_canonical()},
            )
        return self._encryptor.decrypt(self._require(oid))

    def ciphertext(self, object_id: str) -> EncryptedObject:
        """The encrypted record, erased or not.

        Available after erasure on purpose: 17.2's tombstone and the surviving
        ciphertext together are what let an auditor confirm that the bytes were
        *not* altered when the key was destroyed.
        """
        oid = str(object_id)
        if oid in self._objects:
            return self._objects[oid]
        raise ConfigurationError(f"no object {oid!r} in this store")

    def status(self, object_id: str) -> str:
        return self._statuses.get(str(object_id), ErasureStatus.ACTIVE)

    def tombstone(self, object_id: str) -> Optional[ErasureTombstone]:
        return self._tombstones.get(str(object_id))

    def tombstones(self) -> Tuple[ErasureTombstone, ...]:
        return tuple(self._tombstones[k] for k in sorted(self._tombstones))

    def _require(self, object_id: str) -> EncryptedObject:
        encrypted = self._objects.get(str(object_id))
        if encrypted is None:
            raise ConfigurationError(
                f"no object {object_id!r} in tenant {self.tenant_id!r}",
                remedy="a missing object and an erased object are different states (17.1)",
            )
        return encrypted

    def edges_touching(self, object_id: str) -> Tuple[Dict[str, Any], ...]:
        """Every typed edge with ``object_id`` at either end (17.2, 18.2).

        Both directions, because 17.2 asks a tombstone to preserve *dependency
        edges* and the interesting ones after an erasure are usually the
        incoming ones: they are what a surviving certificate used to depend on.
        """
        oid = str(object_id)
        return tuple(
            dict(e)
            for e in self._edges
            if str(e.get("source") or "") == oid or str(e.get("target") or "") == oid
        )

    # -- erasure (17.4) -----------------------------------------------------
    def cryptographic_erase(
        self,
        object_id: str,
        *,
        reason: str,
        authority: str,
        permitted_disclosure: str = "identity, hash, type, and dependency structure only",
    ) -> ErasureTombstone:
        """Destroy this object's data key; keep the tombstone (17.2, 17.4).

        The data key exists only in wrapped form, so destroying the wrapped
        blob destroys the only copy.  The wrapped bytes are overwritten in the
        record rather than merely dropped, and the record's status becomes
        17.1's ``CRYPTOGRAPHICALLY_ERASED``.

        A tenant-wide erasure is :meth:`erase_tenant_key`, which destroys the
        KEK and takes every object wrapped under it with it.  Both are here
        because they answer different questions: "forget this person's record"
        and "forget this customer".
        """
        oid = str(object_id)
        existing = self._tombstones.get(oid)
        if existing is not None:
            return existing
        encrypted = self._require(oid)
        if encrypted.legal_hold:
            raise LegalHoldError(
                f"object {oid!r} is under legal hold and MUST NOT be deleted or "
                "cryptographically erased until the hold is released (17.5)",
                remedy="release the hold under authorized policy, then erase",
                detail={"object_id": oid, "tenant_id": self.tenant_id},
            )
        if not reason:
            raise ConfigurationError("cryptographic erasure requires a stated reason (17.2)")
        if not authority:
            raise ConfigurationError("cryptographic erasure requires an authority (17.2)")

        removed_at = iso(self._clock.now())
        affected = self._downgrade_dependents(oid, reason=reason)

        entry = self._audit.append(
            actor=str(authority),
            action="object.cryptographically_erased",
            resource=oid,
            decision="PERMIT",
            outcome="COMPLETED",
            tenant_id=self.tenant_id,
            detail={
                "spec": "17.4",
                "content_hash": encrypted.content_hash,
                "object_type": encrypted.object_type,
                "reason": reason,
                "wrapping_key_id": encrypted.wrapped_key.wrapping_key_id,
                "affected_objects": affected,
                "irreversible": True,
                "clock_source": self._clock.source,
                "clock_trust_level": self._clock.trust_level,
            },
        )

        destroyed_wrapped = WrappedDataKey(
            wrapping_key_id=encrypted.wrapped_key.wrapping_key_id,
            profile=encrypted.wrapped_key.profile,
            nonce=b"",
            ciphertext=b"",
        )
        self._objects[oid] = EncryptedObject(
            **{
                **_fields(encrypted),
                "wrapped_key": destroyed_wrapped,
                "status": ErasureStatus.CRYPTOGRAPHICALLY_ERASED,
            }
        )
        self._statuses[oid] = ErasureStatus.CRYPTOGRAPHICALLY_ERASED

        record = KeyDestructionRecord(
            key_id=f"dek:{oid}",
            tenant_id=self.tenant_id,
            key_fingerprint="sha256:"
            + hashlib.sha256(b"crg-dek-fingerprint:" + encrypted.wrapped_key.ciphertext)
            .hexdigest()[:32],
            profile=encrypted.profile,
            reason=str(reason),
            authority=str(authority),
            destroyed_at=removed_at,
            clock_source=self._clock.source,
            clock_trust_level=self._clock.trust_level,
            objects_affected=(oid,),
            audit_entry_hash=entry.entry_hash,
        )
        tomb = ErasureTombstone(
            object_id=oid,
            content_hash=encrypted.content_hash,
            object_type=encrypted.object_type,
            tenant_id=self.tenant_id,
            reason=str(reason),
            authority=str(authority),
            removed_at=removed_at,
            dependency_edges=self.edges_touching(oid),
            legal_hold=False,
            permitted_disclosure=permitted_disclosure,
            destruction_record=record,
            affected_objects=tuple(affected),
        )
        self._tombstones[oid] = tomb
        return tomb

    def erase_tenant_key(
        self, tenant_key_id: str, *, reason: str, authority: str
    ) -> KeyDestructionRecord:
        """Destroy a tenant KEK: every object wrapped under it goes with it.

        This is 17.4 at customer granularity, and the reason it lives on the
        store rather than only on the vault is that the store knows which
        objects are affected, and 17.2 requires the tombstones to be written
        for each of them.  An object under legal hold blocks the whole
        destruction (17.5) rather than being skipped, because a KEK
        destruction that spared one object would not be a destruction.
        """
        key_id = str(tenant_key_id)
        wrapped_under = [
            oid for oid, obj in sorted(self._objects.items())
            if obj.wrapped_key.wrapping_key_id == key_id
            and obj.status == ErasureStatus.ACTIVE
        ]
        held = [oid for oid in wrapped_under if self._objects[oid].legal_hold]
        if held:
            raise LegalHoldError(
                f"tenant key {key_id!r} protects {len(held)} object(s) under legal hold "
                "and MUST NOT be destroyed until the holds are released (17.5)",
                remedy="release the holds under authorized policy, then erase",
                detail={"objects_under_hold": held},
            )
        record = self._vault.destroy(
            key_id,
            reason=reason,
            authority=authority,
            audit_log=self._audit,
            objects_affected=wrapped_under,
        )
        removed_at = record.destroyed_at
        for oid in wrapped_under:
            encrypted = self._objects[oid]
            affected = self._downgrade_dependents(oid, reason=reason)
            self._objects[oid] = EncryptedObject(
                **{**_fields(encrypted), "status": ErasureStatus.CRYPTOGRAPHICALLY_ERASED}
            )
            self._statuses[oid] = ErasureStatus.CRYPTOGRAPHICALLY_ERASED
            self._tombstones[oid] = ErasureTombstone(
                object_id=oid,
                content_hash=encrypted.content_hash,
                object_type=encrypted.object_type,
                tenant_id=self.tenant_id,
                reason=str(reason),
                authority=str(authority),
                removed_at=removed_at,
                dependency_edges=self.edges_touching(oid),
                permitted_disclosure=(
                    "identity, hash, type, and dependency structure only"
                ),
                destruction_record=record,
                affected_objects=tuple(affected),
            )
            self._audit.append(
                actor=str(authority),
                action="object.cryptographically_erased",
                resource=oid,
                decision="PERMIT",
                outcome="COMPLETED",
                tenant_id=self.tenant_id,
                detail={
                    "spec": "17.4",
                    "cause": "tenant key destruction",
                    "wrapping_key_id": key_id,
                    "content_hash": encrypted.content_hash,
                },
            )
        return record

    def _downgrade_dependents(self, object_id: str, *, reason: str) -> List[str]:
        """17.3, applied at the moment of erasure rather than later.

        Anything that declared a dependency edge onto the erased object loses
        its support, so its status becomes ``UNVERIFIABLE_REDACTED``.  17.3
        says such a certificate MUST NOT be silently reported as valid, and
        "silently" is doing the work: the downgrade happens here, in the same
        call, so there is no window in which a reader sees the old status.
        """
        affected: List[str] = []
        frontier = [str(object_id)]
        seen = {str(object_id)}
        while frontier:
            current = frontier.pop()
            for dependent in self._dependents.get(current, ()):
                if dependent in seen:
                    continue
                seen.add(dependent)
                self._statuses[dependent] = ErasureStatus.UNVERIFIABLE_REDACTED
                affected.append(dependent)
                frontier.append(dependent)
                self._audit.append(
                    actor="crg-security",
                    action="certificate.downgraded",
                    resource=dependent,
                    decision="PERMIT",
                    outcome="COMPLETED",
                    tenant_id=self.tenant_id,
                    detail={
                        "spec": "17.3",
                        "new_status": ErasureStatus.UNVERIFIABLE_REDACTED,
                        "cause": f"support {current} was cryptographically erased",
                        "reason": reason,
                    },
                )
        return sorted(affected)

    # -- description --------------------------------------------------------
    def to_canonical(self) -> Dict[str, Any]:
        return {
            "tenant_id": self.tenant_id,
            "encryption_profile": self._encryptor.profile,
            "objects": [
                self._objects[o].to_canonical() for o in sorted(self._objects)
            ],
            "tombstones": [t.to_canonical() for t in self.tombstones()],
            "statuses": dict(sorted(self._statuses.items())),
            "audit_head": self._audit.head_hash,
        }


def _fields(encrypted: EncryptedObject) -> Dict[str, Any]:
    """The constructor arguments of ``encrypted``, for a modified copy.

    ``dataclasses.replace`` would do, but writing it out keeps the fields
    visible at the two call sites that rebuild an object with a changed status
    -- and a silently-added field that those call sites forgot would be a
    field that erasure quietly dropped.
    """
    return {
        "object_id": encrypted.object_id,
        "tenant_id": encrypted.tenant_id,
        "object_type": encrypted.object_type,
        "profile": encrypted.profile,
        "content_hash": encrypted.content_hash,
        "nonce": encrypted.nonce,
        "ciphertext": encrypted.ciphertext,
        "wrapped_key": encrypted.wrapped_key,
        "created_at": encrypted.created_at,
        "created_by": encrypted.created_by,
        "case_id": encrypted.case_id,
        "dependency_edges": encrypted.dependency_edges,
        "legal_hold": encrypted.legal_hold,
        "status": encrypted.status,
    }
