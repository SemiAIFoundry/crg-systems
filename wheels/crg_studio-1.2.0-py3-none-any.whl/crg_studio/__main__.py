"""``crg-studio`` -- the secured certified phase/change interface."""
from __future__ import annotations

import argparse
import ipaddress
import json
import os
import signal
import ssl
import sys
import threading
from typing import List, Optional

from crg_server.app import DEFAULT_MAX_REQUEST_BYTES
from crg_server.deployment import (
    DeploymentConfigurationError,
    load_at_rest_codec,
    load_federation_verifier_state,
    load_security_gate,
)
from crg_server.jobs import JobQueue
from crg_server.operational_measurement import (
    LocalOperationalMeasurementStore,
    MeasurementError,
    OperationalMeasurementPermission,
    OperationalMeasurementProfile,
)
from crg_server.store import CaseStore

from .app import serve_studio, studio_index_url


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="crg-studio",
        description=(
            "Run the secured CRG API with certified phase/change Studio mounted "
            "(certified phase, change, and Decision Challenge; spec 38, 41, 44)."
        ),
    )
    parser.add_argument("--root", default=".crg-server")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8731)
    parser.add_argument("--security-config")
    parser.add_argument("--tls-cert")
    parser.add_argument("--tls-key")
    parser.add_argument("--tls-client-ca")
    parser.add_argument("--allow-loopback-http", action="store_true")
    parser.add_argument("--insecure-development", action="store_true")
    parser.add_argument("--actor")
    parser.add_argument(
        "--max-request-mib", type=int,
        default=DEFAULT_MAX_REQUEST_BYTES // (1024 * 1024),
    )
    parser.add_argument(
        "--shutdown-grace-seconds", type=float, default=75.0,
        help="bounded graceful-drain budget for accepted Studio/API jobs",
    )
    parser.add_argument(
        "--enable-local-measurement",
        action="store_true",
        help="explicitly enable local-only operational measurement; off by default",
    )
    parser.add_argument(
        "--operational-measurement-store",
        help="dedicated local measurement path (default: ROOT/operational-measurement)",
    )
    parser.add_argument(
        "--operational-measurement-permissions",
        help=(
            "JSON actor-to-capability map with explicit subject_label, grants, "
            "and crg-operational-measurement domain"
        ),
    )
    return parser


def _loopback(host: str) -> bool:
    if host.lower() == "localhost":
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


def _refuse(message: str) -> int:
    print(f"crg-studio: configuration refused: {message}", file=sys.stderr)
    return 2


def main(argv: Optional[List[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    loopback = _loopback(args.host)
    tls = bool(args.tls_cert or args.tls_key)
    if bool(args.tls_cert) != bool(args.tls_key):
        return _refuse("--tls-cert and --tls-key are required together")
    if args.tls_client_ca and not tls:
        return _refuse("--tls-client-ca requires direct TLS")
    if args.max_request_mib <= 0:
        return _refuse("--max-request-mib must be positive")
    if args.shutdown_grace_seconds < 0 or args.shutdown_grace_seconds > 3600:
        return _refuse("--shutdown-grace-seconds must be from 0 through 3600")
    if not args.enable_local_measurement and (
        args.operational_measurement_store
        or args.operational_measurement_permissions
    ):
        return _refuse(
            "operational measurement options require --enable-local-measurement"
        )
    operational_measurement_profile = None
    operational_measurement_store = None
    operational_measurement_permissions = None
    if args.enable_local_measurement:
        if not args.operational_measurement_permissions:
            return _refuse(
                "--enable-local-measurement requires an explicit "
                "--operational-measurement-permissions file"
            )
        try:
            with open(
                args.operational_measurement_permissions, encoding="utf-8"
            ) as handle:
                raw_permissions = json.load(handle)
            if not isinstance(raw_permissions, dict) or not raw_permissions:
                raise ValueError("measurement permission map must be a non-empty JSON object")
            operational_measurement_permissions = {}
            for mapped_actor, permission in raw_permissions.items():
                if not str(mapped_actor).strip() or not isinstance(permission, dict):
                    raise ValueError(
                        "measurement permission entries require a non-empty actor and object"
                    )
                if set(permission) != {"subject_label", "grants", "domain"}:
                    raise ValueError(
                        "measurement permission entries require exactly subject_label, "
                        "grants, and domain"
                    )
                operational_measurement_permissions[str(mapped_actor)] = (
                    OperationalMeasurementPermission(
                        subject_label=permission["subject_label"],
                        grants=tuple(permission["grants"]),
                        domain=permission["domain"],
                    )
                )
            operational_measurement_profile = OperationalMeasurementProfile(enabled=True)
            measurement_root = (
                args.operational_measurement_store
                or os.path.join(args.root, "operational-measurement")
            )
            operational_measurement_store = LocalOperationalMeasurementStore(measurement_root)
        except (OSError, ValueError, MeasurementError) as error:
            return _refuse(f"operational measurement: {error}")
    if args.insecure_development:
        if not loopback:
            return _refuse("--insecure-development is loopback-only")
        if args.security_config:
            return _refuse("--insecure-development and --security-config are exclusive")
        security = None
        federation_state = None
        object_codec = None
        actor = args.actor or "local-development"
    else:
        if args.actor:
            return _refuse("--actor is accepted only with --insecure-development")
        if not args.security_config:
            return _refuse("--security-config is required")
        try:
            security = load_security_gate(args.security_config, store_root=args.root)
            object_codec = load_at_rest_codec(args.security_config)
            federation_state = load_federation_verifier_state(
                args.security_config, store_root=args.root
            )
        except (DeploymentConfigurationError, ValueError) as error:
            return _refuse(str(error))
        actor = None
    if not tls and not args.insecure_development and not (
        loopback and args.allow_loopback_http
    ):
        return _refuse("TLS is mandatory outside explicit authenticated loopback HTTP")

    store = CaseStore(
        args.root,
        object_codec=object_codec,
        require_encryption=not args.insecure_development,
    )
    if security is not None:
        store.tenant_id = str(security.configuration.audit_log.tenant_id)
        integrity = store.scan_integrity()
        if not integrity["ok"]:
            store.close()
            if federation_state is not None:
                federation_state.close()
            return _refuse(
                "encrypted local store failed startup integrity/decryption scan: "
                f"{integrity['failures'][:3]}"
            )
    queue = JobQueue(store, autorun=True)
    try:
        server, app = serve_studio(
            args.host, args.port, store=store, queue=queue,
            default_actor=actor, security=security,
            federation_verifier_context=federation_state,
            operational_measurement_profile=operational_measurement_profile,
            operational_measurement_store=operational_measurement_store,
            operational_measurement_permissions=operational_measurement_permissions,
            max_request_bytes=args.max_request_mib * 1024 * 1024,
        )
        scheme = "http"
        if tls:
            context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            context.minimum_version = ssl.TLSVersion.TLSv1_2
            context.load_cert_chain(args.tls_cert, args.tls_key)
            if args.tls_client_ca:
                context.load_verify_locations(cafile=args.tls_client_ca)
                context.verify_mode = ssl.CERT_REQUIRED
            server.socket = context.wrap_socket(server.socket, server_side=True)
            scheme = "https"
        print(f"crg-studio listening on {scheme}://{args.host}:{args.port}")
        print(f"  studio      : {scheme}://{args.host}:{args.port}/studio/")
        print(f"  description : {scheme}://{args.host}:{args.port}/openapi.json")
        print(f"  store root  : {app.store.root}")
        print(
            "  local measurement: "
            + (
                f"enabled at {operational_measurement_store.root} (phone-home false)"
                if operational_measurement_store is not None
                else "disabled (default)"
            )
        )
        print(f"  drain grace : {args.shutdown_grace_seconds:g} seconds")
        if scheme == "http":
            print("  DISCLOSURE  : explicit loopback development transport", file=sys.stderr)
        shutdown_started = threading.Event()

        def request_shutdown(_signum: int, _frame: object) -> None:
            if shutdown_started.is_set():
                return
            shutdown_started.set()
            app.begin_drain()
            threading.Thread(
                target=server.shutdown,
                name="crg-studio-http-shutdown",
                daemon=True,
            ).start()

        previous_sigterm = signal.getsignal(signal.SIGTERM)
        signal.signal(signal.SIGTERM, request_shutdown)
        drain_result = None
        try:
            server.serve_forever()
        except KeyboardInterrupt:  # pragma: no cover
            app.begin_drain()
        finally:
            signal.signal(signal.SIGTERM, previous_sigterm)
            app.begin_drain()
            server.server_close()
            drain_result = queue.graceful_shutdown(
                timeout=args.shutdown_grace_seconds,
                finish_pending=True,
            )
            if not drain_result["drained"]:
                print(
                    "crg-studio: graceful drain timed out; acknowledged work remains "
                    f"pending={len(drain_result['pending_jobs'])} "
                    f"running={len(drain_result['running_jobs'])}",
                    file=sys.stderr,
                )
    finally:
        store.close()
        if federation_state is not None:
            federation_state.close()
    return 1 if drain_result is not None and not drain_result["drained"] else 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
