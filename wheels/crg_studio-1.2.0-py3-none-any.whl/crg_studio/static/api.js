/**
 * The only module in CRG Studio that may talk to the network (spec 41, 38).
 *
 * Specification 41 makes Studio "an optional interface over the same public
 * APIs".  That is enforced structurally here rather than promised: every
 * request Studio can issue is a row in `OPERATIONS`, every row's `path` is a
 * literal string in the exact template form used by `openapi_document()`,
 * and `fetch` appears nowhere else in the Studio source tree.  The test
 * suite parses this file, extracts the path literals, and asserts set
 * equality with the OpenAPI document's `paths` -- in both directions, so a
 * Studio call to an undocumented endpoint fails the build, and so does a
 * documented endpoint that Studio never exercises.
 *
 * The second direction is the interesting one.  A Studio that used half the
 * surface would be evidence of nothing; a Studio that uses every documented
 * endpoint is evidence that the surface of 38.3 is sufficient for the workspaces of
 * 41.1, which is the claim 41's first sentence actually makes.
 */

/** Every operation Studio may invoke.  Paths are OpenAPI templates (38.2). */
export const OPERATIONS = {
  healthLive: { method: 'GET', path: '/health/live', spec: '42, 44' },
  healthReady: { method: 'GET', path: '/health/ready', spec: '42, 44' },
  getMetrics: { method: 'GET', path: '/metrics', spec: '42, 47' },

  // -- separate local operational measurement (CRG-ENH-04) ----------
  getOperationalMeasurementProfile: {
    method: 'GET', path: '/operational-measurement/profile', spec: '14, 17, 25',
  },
  listOperationalMeasurementSessions: {
    method: 'GET', path: '/operational-measurement/sessions', spec: '14, 17, 25',
  },
  startOperationalMeasurementSession: {
    method: 'POST', path: '/operational-measurement/sessions', spec: '14, 17, 25',
  },
  getOperationalMeasurementSession: {
    method: 'GET', path: '/operational-measurement/sessions/{session_id}', spec: '14, 17, 25',
  },
  startOperationalMeasurementActive: {
    method: 'POST', path: '/operational-measurement/sessions/{session_id}/active/start',
    spec: '14, 25',
  },
  endOperationalMeasurementActive: {
    method: 'POST', path: '/operational-measurement/sessions/{session_id}/active/end',
    spec: '14, 25',
  },
  startOperationalMeasurementCompute: {
    method: 'POST', path: '/operational-measurement/sessions/{session_id}/compute/start',
    spec: '14, 25',
  },
  endOperationalMeasurementCompute: {
    method: 'POST', path: '/operational-measurement/sessions/{session_id}/compute/end',
    spec: '14, 25',
  },
  startOperationalMeasurementWait: {
    method: 'POST', path: '/operational-measurement/sessions/{session_id}/wait/start',
    spec: '14, 25',
  },
  endOperationalMeasurementWait: {
    method: 'POST', path: '/operational-measurement/sessions/{session_id}/wait/end',
    spec: '14, 25',
  },
  recordOperationalMeasurementObservation: {
    method: 'POST', path: '/operational-measurement/sessions/{session_id}/observations',
    spec: '14, 25',
  },
  recordOperationalMeasurementCounterfactual: {
    method: 'POST', path: '/operational-measurement/sessions/{session_id}/counterfactuals',
    spec: '14, 25',
  },
  endOperationalMeasurementSession: {
    method: 'POST', path: '/operational-measurement/sessions/{session_id}/end', spec: '14, 25',
  },
  exportOperationalMeasurementSession: {
    method: 'GET', path: '/operational-measurement/sessions/{session_id}/export',
    spec: '14, 17, 25, 45',
  },
  verifyOperationalMeasurementExport: {
    method: 'POST', path: '/operational-measurement/exports/verify', spec: '25, 45',
  },
  previewOperationalMeasurementRetention: {
    method: 'POST', path: '/operational-measurement/retention/preview', spec: '17, 25',
  },
  enforceOperationalMeasurementRetention: {
    method: 'POST', path: '/operational-measurement/retention/enforce', spec: '17, 25',
  },
  deleteOperationalMeasurementSession: {
    method: 'POST', path: '/operational-measurement/sessions/{session_id}/delete', spec: '17, 25',
  },
  // -- case lifecycle (11.2, 16) --------------------------------------
  createCase: { method: 'POST', path: '/cases', spec: '11.1' },
  getCase: { method: 'GET', path: '/cases/{case_id}', spec: '11.1' },
  validateCase: { method: 'POST', path: '/cases/{case_id}/validate', spec: '11.2' },
  createBranch: { method: 'POST', path: '/cases/{case_id}/branches', spec: '16.2' },
  mergeCase: { method: 'POST', path: '/cases/{case_id}/merge', spec: '16.3' },

  // -- registry, family, geometry (27, 28, 19) ------------------------
  importRegistry: { method: 'POST', path: '/cases/{case_id}/import', spec: '37' },
  previewRegistryIntake: {
    method: 'POST', path: '/cases/{case_id}/registry-intake/preview', spec: '21.2, 37',
  },
  confirmRegistryIntake: {
    method: 'POST', path: '/cases/{case_id}/registry-intake/confirm', spec: '21.2, 37',
  },
  generateFamily: { method: 'POST', path: '/cases/{case_id}/generate', spec: '28' },
  evaluateFamily: { method: 'POST', path: '/cases/{case_id}/evaluate', spec: '22.2' },
  buildGeometry: { method: 'POST', path: '/cases/{case_id}/geometry', spec: '19' },
  previewPhaseAnalysis: {
    method: 'POST', path: '/cases/{case_id}/phases/preview', spec: '19, 22, 30',
  },
  analyzePhase: {
    method: 'POST', path: '/cases/{case_id}/phases', spec: '19, 22, 30',
  },

  // -- decision (26, 29, 30, 31) --------------------------------------
  compileQuery: { method: 'POST', path: '/cases/{case_id}/queries/compile', spec: '26' },
  previewCommitment: {
    method: 'POST', path: '/cases/{case_id}/commitments/preview', spec: '20, 26, 27, 29',
  },
  compareCommitment: {
    method: 'POST', path: '/cases/{case_id}/commitments', spec: '20, 26, 27, 29',
  },
  previewComparativeEvaluation: {
    method: 'POST', path: '/cases/{case_id}/comparative-evaluations/preview',
    spec: '21.2, 27',
  },
  generateComparativeEvaluation: {
    method: 'POST', path: '/cases/{case_id}/comparative-evaluations', spec: '21.2, 27',
  },
  getComparativeEvaluation: {
    method: 'GET', path: '/cases/{case_id}/comparative-evaluations/{evaluation_id}',
    spec: '21.2, 25',
  },
  verifyComparativeEvaluation: {
    method: 'POST', path: '/comparative-evaluations/verify', spec: '21.2, 25',
  },
  previewComparativeChange: {
    method: 'POST', path: '/cases/{case_id}/comparative-changes/preview',
    spec: '18, 21.2, 25, 30',
  },
  generateComparativeChange: {
    method: 'POST', path: '/cases/{case_id}/comparative-changes',
    spec: '18, 21.2, 25, 30',
  },
  getComparativeChange: {
    method: 'GET', path: '/cases/{case_id}/comparative-changes/{comparison_id}',
    spec: '18, 21.2, 25, 30',
  },
  verifyComparativeChange: {
    method: 'POST', path: '/comparative-changes/verify', spec: '21.2, 25, 30',
  },
  certifyCase: { method: 'POST', path: '/cases/{case_id}/certify', spec: '29' },
  classifyChange: { method: 'POST', path: '/cases/{case_id}/changes', spec: '30' },
  previewChange: {
    method: 'POST', path: '/cases/{case_id}/changes/preview', spec: '18, 30',
  },
  previewDecisionChallenge: {
    method: 'POST', path: '/cases/{case_id}/decision-challenges/preview',
    spec: '18, 21.2, 24, 25, 30',
  },
  recordDecisionChallenge: {
    method: 'POST', path: '/cases/{case_id}/decision-challenges',
    spec: '18, 21.2, 24, 25, 30',
  },
  getDecisionChallenge: {
    method: 'GET', path: '/cases/{case_id}/decision-challenges/{challenge_id}',
    spec: '18, 21.2, 24, 25, 30',
  },
  verifyDecisionChallenge: {
    method: 'POST', path: '/decision-challenges/verify', spec: '24, 25, 30',
  },
  recomputeCase: { method: 'POST', path: '/cases/{case_id}/recompute', spec: '30.3' },
  planConversion: { method: 'POST', path: '/cases/{case_id}/convert', spec: '31' },
  planQualification: {
    method: 'POST', path: '/cases/{case_id}/qualification-plans', spec: '34',
  },
  createEvaluatorRequest: {
    method: 'POST', path: '/cases/{case_id}/evaluator-requests', spec: '32.1',
  },

  // -- reading the record (18, 29.4, 17) ------------------------------
  getDependencies: { method: 'GET', path: '/cases/{case_id}/dependencies', spec: '18' },
  listCertificates: { method: 'GET', path: '/cases/{case_id}/certificates', spec: '29.4' },
  migrateCase: { method: 'POST', path: '/cases/{case_id}/migrate', spec: '15.3' },
  redactObject: { method: 'POST', path: '/cases/{case_id}/redact', spec: '17.2' },
  createRetentionPolicy: {
    method: 'POST', path: '/retention/policies', spec: '17, 42.1, 44.5',
  },
  listRetentionPolicies: {
    method: 'GET', path: '/retention/policies', spec: '17, 44.5',
  },
  evaluateRetention: {
    method: 'POST', path: '/retention/evaluate', spec: '17, 42.1, 44.5',
  },
  enforceRetention: {
    method: 'POST', path: '/retention/enforce', spec: '17, 42.1, 44.5',
  },
  setObjectLegalHold: {
    method: 'POST', path: '/objects/{object_hash}/legal-hold', spec: '17.5, 42.3, 44.5',
  },

  // -- evidence, technology, federation (33, 35) ----------------------
  registerEvidence: { method: 'POST', path: '/evidence', spec: '33.2' },
  assembleTechnologyContract: {
    method: 'POST', path: '/technology-contracts/assemble', spec: '33.6',
  },
  issueCapabilityEnvelope: { method: 'POST', path: '/capability-envelopes', spec: '35.2' },
  evaluatePrivately: { method: 'POST', path: '/private-evaluations', spec: '35.3' },
  revokeCapability: {
    method: 'POST', path: '/capability-envelopes/{subject_id}/revoke', spec: '35.4',
  },
  executeTransition: {
    method: 'POST', path: '/transitions/{plan_id}/execute', spec: '32.4, 32.5',
  },

  // -- deployment event delivery (38.2, 44.7) ------------------------
  createWebhookSubscription: {
    method: 'POST', path: '/webhooks/subscriptions', spec: '38.2',
  },
  listWebhookSubscriptions: {
    method: 'GET', path: '/webhooks/subscriptions', spec: '38.2',
  },
  deleteWebhookSubscription: {
    method: 'DELETE', path: '/webhooks/subscriptions/{subscription_id}', spec: '38.2',
  },

  // -- portable bundles and independent verification (25, 39) ---------
  importBundle: { method: 'POST', path: '/bundles/import', spec: '39' },
  verifyBundle: { method: 'POST', path: '/bundles/verify', spec: '25' },
  verifyPhaseAnalysis: {
    method: 'POST', path: '/phase-analyses/verify', spec: '24, 30',
  },
  verifyCertifiedDelta: {
    method: 'POST', path: '/certified-deltas/verify', spec: '24, 30',
  },
  exportBundle: {
    method: 'GET', path: '/bundles/{bundle_id}/export', spec: '39', binary: true,
  },

  // -- asynchronous jobs and events (42.4, 38.5) ----------------------
  getJob: { method: 'GET', path: '/jobs/{job_id}', spec: '42.4' },
  getJobResult: { method: 'GET', path: '/jobs/{job_id}/result', spec: '42.4' },
  cancelJob: { method: 'POST', path: '/jobs/{job_id}/cancel', spec: '42.4' },
  retryJob: { method: 'POST', path: '/jobs/{job_id}/retry', spec: '42.4' },
  listEvents: { method: 'GET', path: '/events', spec: '38.5' },
  exportAudit: { method: 'GET', path: '/audit/export', spec: '42.3, 44.5, 44.7' },
  // The two Server-Sent Events subscriptions of 38.2.  They are declared
  // here rather than only in the generated SDKs because the set equality
  // this file's header describes is asserted in both directions: a
  // documented endpoint absent from this table fails the build.  They are
  // read through `EventSource`, not `fetch`, which is why no other module
  // needs to touch them.
  streamEvents: { method: 'GET', path: '/events/stream', spec: '38.2', stream: true },
  streamCaseEvents: {
    method: 'GET', path: '/cases/{case_id}/events/stream', spec: '38.2', stream: true,
  },

  // -- the description itself (38.2, 6.12) ----------------------------
  getOpenApi: { method: 'GET', path: '/openapi.json', spec: '38.2' },
};

/** Fill an OpenAPI path template.  Missing parameters are a programming error. */
export function expandPath(template, params = {}) {
  return template.replace(/\{([^}]+)\}/g, (_match, name) => {
    const value = params[name];
    if (value === undefined || value === null || value === '') {
      throw new Error(`the path parameter "${name}" is required by ${template}`);
    }
    return encodeURIComponent(String(value));
  });
}

/**
 * A refusal carried as an exception, with the server's remedy intact.
 *
 * 6.6 makes the reference implementation fail closed and 38.3 gives every
 * refusal a category, a status, and a remedy.  Studio must not flatten that
 * into "something went wrong": the remedy text is frequently the only thing
 * that tells a user which of 21.5's claim rules blocked them.
 */
export class ApiRefusal extends Error {
  constructor(status, body, operation) {
    const error = (body && body.error) || {};
    super(error.message || `request refused with status ${status}`);
    this.name = 'ApiRefusal';
    this.status = status;
    this.category = error.category || 'unknown';
    this.remedy = error.remedy || '';
    this.detail = error.detail || null;
    this.operation = operation;
    this.body = body;
  }
}

/**
 * The client supports the three security schemes published by OpenAPI:
 * TLS-protected Basic, OIDC Bearer, and service ApiKey. `actor` remains only
 * for the explicitly insecure loopback-development profile. Secrets stay in
 * memory and are never written to browser storage or the request log.
 */
export class StudioApi {
  constructor(options = {}) {
    this.base = options.base || '';
    this.actor = options.actor || '';
    this.username = options.username || '';
    this.password = options.password || '';
    this.bearerToken = options.bearerToken || '';
    this.apiKey = options.apiKey || '';
    // Window.fetch is specified as a method in several browser/webview
    // implementations and throws "Illegal invocation" when detached from its
    // receiver. Preserve the receiver once, at construction, so workspaces
    // that make a real request behave like the case-local empty states.
    this.fetchImpl = options.fetch
      || (typeof globalThis.fetch === 'function'
        ? (...args) => globalThis.fetch(...args) : null);
    this.correlationCounter = 0;
    this.log = [];
  }

  headers(operation) {
    const headers = { Accept: 'application/json' };
    if (operation.method !== 'GET') {
      headers['Content-Type'] = 'application/json';
    }
    if (this.actor) {
      headers['X-CRG-Actor'] = this.actor;
    }
    const authenticationModes = [
      Boolean(this.username || this.password),
      Boolean(this.bearerToken),
      Boolean(this.apiKey),
    ].filter(Boolean).length;
    if (authenticationModes > 1) {
      throw new Error('Studio refuses multiple simultaneous authentication schemes');
    }
    if (this.username || this.password) {
      const bytes = new TextEncoder().encode(`${this.username}:${this.password}`);
      let binary = '';
      bytes.forEach((value) => { binary += String.fromCharCode(value); });
      headers.Authorization = `Basic ${btoa(binary)}`;
    } else if (this.bearerToken) {
      headers.Authorization = `Bearer ${this.bearerToken}`;
    } else if (this.apiKey) {
      headers.Authorization = `ApiKey ${this.apiKey}`;
    }
    this.correlationCounter += 1;
    headers['X-CRG-Correlation-Id'] = `studio-${this.correlationCounter}`;
    return headers;
  }

  async call(name, { params = {}, body = null, query = null, idempotencyKey = null } = {}) {
    const operation = OPERATIONS[name];
    if (!operation) {
      throw new Error(`no documented operation named "${name}"`);
    }
    let url = this.base + expandPath(operation.path, params);
    if (query) {
      const search = new URLSearchParams(query).toString();
      if (search) url += `?${search}`;
    }
    const headers = this.headers(operation);
    if (idempotencyKey) headers['Idempotency-Key'] = idempotencyKey;
    const init = { method: operation.method, headers };
    if (body !== null && operation.method !== 'GET') {
      init.body = JSON.stringify(body);
    }
    const response = await this.fetchImpl(url, init);
    this.log.push({
      operation: name, method: operation.method, url, status: response.status,
    });
    if (operation.binary) {
      if (!response.ok) throw new ApiRefusal(response.status, await this.#json(response), name);
      return { blob: await response.blob(), headers: response.headers };
    }
    const payload = await this.#json(response);
    if (!response.ok) throw new ApiRefusal(response.status, payload, name);
    return payload;
  }

  async #json(response) {
    try {
      return await response.json();
    } catch (_error) {
      return null;
    }
  }

  /**
   * Drive one long-running action to its result (38.3, 42.4).
   *
   * Every heavy endpoint answers 202 with a job identifier, never a value.
   * Studio therefore never has a synchronous "compute" button: it submits,
   * polls, and reports progress, and a blocked outcome arrives as a 422 from
   * `/jobs/{job_id}/result` -- an `ApiRefusal` whose `detail` is the
   * certificate an auditor needs, not a dialog saying the run failed.
   */
  async run(name, options = {}, { onProgress = null, attempts = 200, delay = 25 } = {}) {
    const accepted = await this.call(name, options);
    const jobId = accepted && accepted.job_id;
    if (!jobId) return { job: null, result: accepted };
    let job = null;
    for (let i = 0; i < attempts; i += 1) {
      const seen = await this.call('getJob', { params: { job_id: jobId } });
      job = seen.job || seen;
      if (onProgress) onProgress(job);
      if (['SUCCEEDED', 'FAILED', 'CANCELLED'].includes(job.status)) break;
      await new Promise((resolve) => { setTimeout(resolve, delay); });
    }
    const result = await this.call('getJobResult', { params: { job_id: jobId } });
    return { job, result };
  }

  cancel(jobId) {
    return this.call('cancelJob', { params: { job_id: jobId } });
  }

  retry(jobId) {
    return this.call('retryJob', { params: { job_id: jobId } });
  }

  /** The download URL for a portable bundle (39).  Used as an anchor href. */
  bundleHref(caseId, authority = '') {
    const path = expandPath(OPERATIONS.exportBundle.path, { bundle_id: caseId });
    const search = authority ? `?authority=${encodeURIComponent(authority)}` : '';
    return this.base + path + search;
  }
}

export default StudioApi;
