/**
 * The Studio shell: navigation, focus management, and the data each
 * workspace needs (spec 41, 41.2, 47.7).
 *
 * Two responsibilities and no third.  It owns the DOM and it owns the
 * sequence of documented API calls each workspace requires; every byte of
 * markup comes from a workspace module's pure `render`, and every request
 * goes through `api.js`.  That split is what makes the headless tests
 * possible: the renderers can be exercised under Node with fixture JSON, and
 * the only untested surface is the part that genuinely needs a browser.
 *
 * The keyboard behaviour is deliberate rather than inherited.  The workspace
 * list is a vertical tablist with roving tabindex: Tab reaches the list once,
 * arrow keys move within it, Home and End jump to the ends, and activating a
 * workspace moves focus into the panel so the next Tab continues into the
 * content rather than back through seventeen tabs.  No element anywhere in
 * Studio carries a positive tabindex, so the tab order and the reading order
 * are the same order.
 */

import { StudioApi, ApiRefusal, OPERATIONS } from './api.js';
import { UX_PRINCIPLES, WORKSPACES } from './manifest.js';
import { esc, refusal } from './render.js';
import {
  comparativeChangeBody, comparativeEvaluationBody, registryIntakeBody, safeCommitmentBody,
} from './guided-authoring.js';

export {
  comparativeChangeBody, comparativeEvaluationBody, registryIntakeBody, safeCommitmentBody,
};

/** Stable browser marks used by the §47.6 product-performance gate. */
export const PERFORMANCE_MARKS = Object.freeze({
  moduleStart: 'crg-studio-module-start',
  firstWorkspaceRendered: 'crg-studio-first-workspace-rendered',
  interactionReady: 'crg-studio-interaction-ready',
  moduleToReady: 'crg-studio-module-to-ready',
});

function performanceMark(name) {
  if (typeof window === 'undefined' || !window.performance
      || typeof window.performance.mark !== 'function') return;
  window.performance.mark(name);
}

function browserNow(document) {
  if (typeof window !== 'undefined' && window.performance
      && typeof window.performance.now === 'function') return window.performance.now();
  // Some operated/webview profiles intentionally withhold the Performance
  // API. Event.timeStamp is the same monotonic document clock and keeps the
  // measurement available without falling back to the system wall clock.
  if (document && typeof document.createEvent === 'function') {
    try {
      return Number(document.createEvent('Event').timeStamp);
    } catch (_error) {
      return null;
    }
  }
  return null;
}

performanceMark(PERFORMANCE_MARKS.moduleStart);

/* ------------------------------------------------------------------ */
/* pure rendering: exercised headlessly by the test suite              */
/* ------------------------------------------------------------------ */

/** The workspace tablist.  Exactly one tab is in the tab order at a time. */
export function renderNav(workspaces = WORKSPACES, activeId = workspaces[0].id) {
  let group = '';
  return workspaces.map((workspace) => {
    const active = workspace.id === activeId;
    const heading = workspace.group && workspace.group !== group
      ? `<div class="crg-nav__group" role="presentation">${esc(workspace.group)}</div>` : '';
    group = workspace.group || group;
    return heading + `<button type="button" role="tab" class="crg-nav__tab" `
      + `id="tab-${esc(workspace.id)}" data-workspace="${esc(workspace.id)}" `
      + `aria-selected="${active ? 'true' : 'false'}" `
      + `data-search="${esc(`${workspace.title} ${workspace.purpose} ${workspace.group || ''}`.toLowerCase())}" `
      + `aria-controls="crg-main" tabindex="${active ? '0' : '-1'}">`
      + `<span class="crg-nav__title">${esc(workspace.title)}</span>`
      + `<span class="crg-nav__purpose">${esc(workspace.purpose)}</span>`
      + `</button>`;
  }).join('');
}

/** The decision-reading rules shown inside the platform navigation popup. */
export function renderPrinciples(principles = UX_PRINCIPLES) {
  return `<dl class="crg-dl">`
    + principles.map(([id, title, description]) => `<div class="crg-dl__row" `
      + `data-ux-principle="${esc(id)}">`
      + `<dt class="crg-dl__term">${esc(title)}</dt>`
      + `<dd class="crg-dl__value">${esc(description)}</dd></div>`).join('')
    + `</dl>`;
}

export const TOUR_STEPS = [
  {
    phase: 'Welcome', workspace: 'case-setup', action: 'Start in Case Setup',
    title: 'One defensible decision, from source to verification',
    description: 'Studio keeps the alternatives, evidence, geometry, decision claim, change history, and independent verification in one auditable case.',
    guidance: ['Use the left workflow in order when starting fresh.', 'You can revisit any workspace without losing the case context.', 'A refusal is an actionable result, never a hidden error.'],
  },
  {
    phase: 'Prepare', workspace: 'case-setup', action: 'Open Case Setup',
    title: 'Frame the case and bring in the alternatives',
    description: 'Create or select a case, then import a governed registry. Studio preserves missing and rejected values instead of repairing them silently.',
    guidance: ['Case Setup establishes identity and scope.', 'Registry Import shows accepted and rejected rows.', 'Check the completeness basis before interpreting a winner.'],
  },
  {
    phase: 'Model', workspace: 'realization-explorer', action: 'Open Realization Explorer',
    title: 'Understand what each realization means',
    description: 'Inspect legal, infeasible, unsupported, unevaluated, and rejected candidates together with their obligations and evidence classes.',
    guidance: ['Realizations are the candidate family.', 'Obligations explain what each candidate requires.', 'Absent evidence is never displayed as zero.'],
  },
  {
    phase: 'Decide', workspace: 'decision-query', action: 'Open Decision Query',
    title: 'Ask a bounded question and inspect its warrant',
    description: 'Build the minimum sufficient geometry, compile the decision query, and inspect winners, ties, ambiguity, margins, and claim scope.',
    guidance: ['Geometry shows the decision frontier.', 'The query compiler selects the sound retained object.', 'Decision Center explains why the result exists.'],
  },
  {
    phase: 'Evolve', workspace: 'change-impact', action: 'Open Change Impact',
    title: 'Keep the decision current as evidence and systems change',
    description: 'Trace selective invalidation, plan qualification or conversion, and register physical feedback without erasing the prior state.',
    guidance: ['Change Impact shows what must be recomputed.', 'Evidence and qualification separate knowledge from assumptions.', 'Physical transitions require an explicitly configured executor.'],
  },
  {
    phase: 'Govern', workspace: 'verification-center', action: 'Open Verification Center',
    title: 'Verify independently, then govern release and action',
    description: 'Upload a portable .crg bundle for independent verification, review audit history, manage federation/revocation, and export the case.',
    guidance: ['Verified and replayable are different statuses.', 'The verifier owns its trust context and clock.', 'Audit, branches, webhooks, and revocation preserve operational accountability.'],
  },
];

export function renderTourStep(step) {
  const record = step || TOUR_STEPS[0];
  return `<section class="crg-guide-step" data-guide-phase="${esc(record.phase)}">`
    + `<p class="crg-guide-step__phase">${esc(record.phase)}</p>`
    + `<h3>${esc(record.title)}</h3>`
    + `<p class="crg-guide-step__description">${esc(record.description)}</p>`
    + `<ul class="crg-guide-step__list">${record.guidance.map((item) => `<li>${esc(item)}</li>`).join('')}</ul>`
    + `</section>`;
}

/** A direct, non-linear map of the guide's product phases. */
export function renderTourMap(steps = TOUR_STEPS, activeIndex = 0) {
  return steps.map((step, index) => `<button class="crg-guide__map-step" type="button" `
    + `data-guide-index="${index}"${index === activeIndex ? ' aria-current="step"' : ''}>`
    + `${esc(step.phase)}</button>`).join('');
}

/* ------------------------------------------------------------------ */
/* forms: what the user typed, in the shape the typed request expects  */
/* ------------------------------------------------------------------ */

/**
 * Form control name to request field, per specification 38.3's request
 * bodies.
 *
 * An explicit table rather than a naming convention.  Studio sends typed
 * requests to a surface that fails closed on an unrecognised field (10.1,
 * 6.6), so a control whose name happens not to match is better caught here
 * than turned into a plausible-looking request the server will refuse for a
 * reason the user cannot act on.
 */
const FIELD_MAP = {
  'case-id': 'case_id',
  'case-title': 'title',
  'import-source': 'source_id',
  'import-payload': null,
  'intake-source-content': 'source_text',
  'intake-mapping-profile': 'mapping_profile',
  'intake-provenance': 'provenance',
  'intake-expected-preview-hash': 'expected_preview_hash',
  'intake-accept-partial': 'accept_partial',
  'intake-request': null,
  generator: 'generator',
  'generator-request': null,
  question: 'question',
  'query-document': 'query',
  'commitment-request': null,
  'comparison-request': null,
  'comparison-record': 'record',
  'comparison-evaluation-id': 'evaluation_id',
  'change-comparison-request': null,
  'change-comparison-record': 'record',
  'change-comparison-inspect-id': 'comparison_id',
  'challenge-id': 'challenge_id',
  'phase-profile': 'profile_id',
  'phase-stability': 'stability_parameter',
  'phase-tolerance': 'policy_tolerance',
  retained: 'retained',
  'change-set': 'set',
  'change-reason': 'reason',
  'change-authority': 'authority',
  'evidence-record': 'evidence',
  experiments: 'experiments',
  'burden-weights': 'burden_weights',
  'conversion-source': 'source',
  'conversion-target': 'target',
  'evaluator-request': 'evaluator_request',
  'envelope-target': 'target_context',
  'envelope-request': null,
  'revoke-subject': 'subject_id',
  'revoke-reason': 'reason',
  'transition-plan': 'plan_id',
  'transition-request': null,
  'webhook-request': null,
  'webhook-subscription': 'subscription_id',
  'verify-level': 'level',
  'verify-bundle': 'bundle_base64',
  'verify-bundle-file': 'bundle_base64',
  'branch-name': 'name',
  'branch-purpose': 'purpose',
  'merge-source': 'source_case_id',
  'redact-hash': 'object_hash',
  'redact-reason': 'reason',
  'redact-authority': 'authority',
  'retention-policy-request': null,
  'retention-run-request': null,
  'legal-hold-object': 'object_hash',
  'legal-hold-request': null,
  'audit-authority': 'authority',
  'audit-after-sequence': 'after_sequence',
  'audit-limit': 'limit',
  'measurement-session-id': 'session_id',
  'measurement-purpose-code': 'purpose_code',
  'measurement-scope-code': 'scope_code',
  'measurement-metric-code': 'metric_code',
  'measurement-numerator': 'numerator',
  'measurement-denominator': 'denominator',
  'measurement-unit-code': 'unit_code',
  'measurement-class': 'measurement_class',
  'measurement-basis-code': 'basis_code',
  'measurement-export': 'export',
  'measurement-retention-age': 'maximum_age_seconds',
  'measurement-retention-as-of': 'as_of',
  'measurement-retention-preview': 'preview',
  'measurement-confirmation-hash': 'confirmation_hash',
  'measurement-expected-content-hash': 'expected_content_hash',
};

/** Fields whose value is a document rather than a scalar. */
const DOCUMENT_FIELDS = new Set([
  'import-payload', 'generator-request', 'query-document', 'evidence-record',
  'intake-mapping-profile', 'intake-provenance', 'intake-request',
  'commitment-request',
  'comparison-request', 'comparison-record',
  'change-comparison-request', 'change-comparison-record',
  'experiments', 'burden-weights', 'conversion-source', 'conversion-target',
  'evaluator-request', 'envelope-request', 'change-set',
  'transition-request', 'webhook-request',
  'retention-policy-request', 'retention-run-request', 'legal-hold-request',
  'measurement-export', 'measurement-retention-preview',
]);

/** Fields the user writes one item per line. */
const LIST_FIELDS = new Set(['retained']);

/** Fields whose select value is a JSON boolean at the public API boundary. */
const BOOLEAN_FIELDS = new Set(['intake-accept-partial']);

/** Exact integer fields; conversion never passes through binary float. */
const INTEGER_FIELDS = new Set([
  'measurement-numerator', 'measurement-denominator', 'measurement-retention-age',
]);

const CHALLENGE_INPUT_FIELDS = {
  OBJECTIVE: ['objective-key', 'objective-value'],
  PRICE: ['price-value', 'price-unit'],
  TECHNOLOGY_COORDINATE: [
    'technology-coordinate-id', 'technology-value', 'technology-unit',
  ],
  EVIDENCE_VALUE: [
    'evidence-value-evidence-id', 'evidence-value-value', 'evidence-value-class',
  ],
  EVIDENCE_VALIDITY: ['evidence-validity-evidence-id', 'evidence-validity-status'],
  CAPABILITY: ['capability-id', 'capability-value'],
  LEGALITY: ['legality-realization-id', 'legality-status'],
  POLICY_TOLERANCE: ['tolerance-value'],
  RETENTION_POLICY: ['retention-policy-id', 'retention-policy-value'],
  PHYSICAL_CONSTRAINT: ['constraint-id', 'constraint-value', 'constraint-unit'],
};

/** Build the closed ordinary-path Decision Challenge request from labelled controls. */
export function decisionChallengeBody(values = {}) {
  const read = (name) => String(values[`challenge-${name}`] ?? '').trim();
  const mutationType = read('mutation-type');
  const raw = {};
  (CHALLENGE_INPUT_FIELDS[mutationType] || []).forEach((name) => {
    raw[name] = read(name);
  });
  let input;
  switch (mutationType) {
    case 'OBJECTIVE':
      input = { objective: { [raw['objective-key']]: raw['objective-value'] } };
      break;
    case 'PRICE':
      input = { value: raw['price-value'], unit: raw['price-unit'] };
      break;
    case 'TECHNOLOGY_COORDINATE':
      input = {
        coordinate_id: raw['technology-coordinate-id'],
        value: raw['technology-value'], unit: raw['technology-unit'],
      };
      break;
    case 'EVIDENCE_VALUE':
      input = {
        evidence_id: raw['evidence-value-evidence-id'],
        value: raw['evidence-value-value'], evidence_class: raw['evidence-value-class'],
      };
      break;
    case 'EVIDENCE_VALIDITY':
      input = {
        evidence_id: raw['evidence-validity-evidence-id'],
        validity: raw['evidence-validity-status'],
      };
      break;
    case 'CAPABILITY':
      input = { capability_id: raw['capability-id'], value: raw['capability-value'] };
      break;
    case 'LEGALITY':
      input = {
        realization_id: raw['legality-realization-id'], legality: raw['legality-status'],
      };
      break;
    case 'POLICY_TOLERANCE':
      input = { value: raw['tolerance-value'] };
      break;
    case 'RETENTION_POLICY':
      input = {
        policy_id: raw['retention-policy-id'], policy: raw['retention-policy-value'],
      };
      break;
    case 'PHYSICAL_CONSTRAINT':
      input = {
        constraint_id: raw['constraint-id'], value: raw['constraint-value'],
        unit: raw['constraint-unit'],
      };
      break;
    default:
      input = {};
  }
  const body = {
    challenge_id: read('id'),
    evidence_id: read('evidence-id'),
    operations: [{
      operation_id: read('operation-id'),
      mutation_type: mutationType,
      preview_operation: read('preview-operation'),
      target_path: read('target-path'),
      input,
    }],
  };
  const promotion = {
    request_id: read('promotion-request-id'),
    governed_operation: read('promotion-operation'),
    requested_by: read('promotion-requested-by'),
    reason: read('promotion-reason'),
  };
  if (Object.values(promotion).some(Boolean)) body.promotion_request = promotion;
  return body;
}

/** Extract the canonical record from either a job result or direct replay response. */
export function displayedDecisionChallenge(lastAction = {}) {
  const response = lastAction.result || {};
  const result = response.outputs || response;
  return result.challenge && result.challenge.record_type === 'DecisionChallengeRecord'
    ? result.challenge : null;
}

/** Extract the displayed v1.2 comparison from a job, inspect, or verify response. */
export function displayedComparativeChange(lastAction = {}) {
  const response = lastAction.result || {};
  const result = response.outputs || response;
  const record = result.comparative_change;
  return record && record.record_type === 'ComparativeChangeEvidence' ? record : null;
}

/**
 * Turn collected control values into a typed request body.
 *
 * A `null` entry in `FIELD_MAP` means "this control holds a whole document":
 * its parsed object is merged into the body rather than nested under a key,
 * which is how the raw request editors in the import, generation, query, and
 * federation workspaces let a user send exactly the request 38.3 documents
 * without Studio standing between them and it.
 */
export function formBody(values) {
  const body = {};
  Object.entries(values || {}).forEach(([name, raw]) => {
    const text = typeof raw === 'string' ? raw.trim() : raw;
    if (text === '' || text === undefined || text === null) return;
    const key = Object.prototype.hasOwnProperty.call(FIELD_MAP, name)
      ? FIELD_MAP[name]
      : name.replace(/-/g, '_');
    if (DOCUMENT_FIELDS.has(name)) {
      let parsed;
      try {
        parsed = JSON.parse(text);
      } catch (_error) {
        // Not JSON: send it as text under its mapped key so the server's own
        // validation, not a silent client-side guess, decides what it means.
        // Never dropped -- 6.11 forbids silent truncation, and a control
        // whose contents vanish on the way to the server is exactly that.
        body[key || name.replace(/-/g, '_')] = text;
        return;
      }
      if (key === null && parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
        Object.assign(body, parsed);
      } else {
        body[key || name.replace(/-/g, '_')] = parsed;
      }
      return;
    }
    if (LIST_FIELDS.has(name)) {
      body[key] = text.split('\n').map((line) => line.trim()).filter(Boolean);
      return;
    }
    if (BOOLEAN_FIELDS.has(name)) {
      body[key] = String(text).toLowerCase() === 'true';
      return;
    }
    if (INTEGER_FIELDS.has(name)) {
      if (!/^-?[0-9]+$/.test(String(text))) {
        body[key] = text;
        return;
      }
      const parsed = Number(text);
      // Measurement timings and rational components are exact integers.
      // Never silently round a value outside JavaScript's safe range: retain
      // the text so the closed server schema refuses it instead.
      body[key] = Number.isSafeInteger(parsed) ? parsed : text;
      return;
    }
    if (key) body[key] = text;
  });
  return body;
}

/** Path parameters an operation needs, taken from its own OpenAPI template. */
export function pathParams(operationName, context) {
  const template = (OPERATIONS[operationName] || {}).path || '';
  const params = {};
  (template.match(/\{([^}]+)\}/g) || []).forEach((token) => {
    const name = token.slice(1, -1);
    if (name === 'case_id') params.case_id = context.caseId;
    else if (name === 'bundle_id') params.bundle_id = context.caseId;
    else if (name === 'job_id') params.job_id = context.jobId;
    else if (name === 'subject_id') params.subject_id = context.body && context.body.subject_id;
    else if (name === 'plan_id') params.plan_id = context.body && context.body.plan_id;
    else if (name === 'evaluation_id') {
      params.evaluation_id = context.body && context.body.evaluation_id;
    }
    else if (name === 'challenge_id') {
      params.challenge_id = context.body && context.body.challenge_id;
    }
    else if (name === 'comparison_id') {
      params.comparison_id = context.body && context.body.comparison_id;
    }
    else if (name === 'subscription_id') {
      params.subscription_id = context.body && context.body.subscription_id;
    }
    else if (name === 'object_hash') {
      params.object_hash = context.body && context.body.object_hash;
    }
    else if (name === 'session_id') {
      params.session_id = context.body && context.body.session_id;
    }
  });
  return params;
}

/* ------------------------------------------------------------------ */
/* data: which documented calls each workspace needs                   */
/* ------------------------------------------------------------------ */

/**
 * Fetch what a workspace displays, using only operations declared in
 * `api.js`.
 *
 * A refusal is caught and returned as part of the state rather than thrown,
 * because 6.6 refusals are content: the workspace renders the remedy beside
 * the form that produced it, which is the only place it is actionable.  A
 * workspace with no case yet simply gets an empty state; it never gets a
 * request with an empty path parameter, which would be a client-side bug
 * dressed as a server 404.
 */
export async function fetchState(api, id, context = {}) {
  const { caseId } = context;
  const state = { caseId, actor: api.actor, data: {}, error: null };
  const guardedCase = async (operation, options = {}) => {
    if (!caseId) return null;
    return api.call(operation, { params: { case_id: caseId }, ...options });
  };
  try {
    switch (id) {
      case 'case-setup':
      case 'realization-explorer':
      case 'obligation-explorer':
      case 'geometry-phase-view':
      case 'branch-merge':
        state.data = (await guardedCase('getCase')) || {};
        break;
      case 'registry-import':
        state.data = (await guardedCase('getCase')) || {};
        state.data = { ...state.data, import_report: ((state.data.case || {}).import_report) };
        break;
      case 'decision-query':
        state.data = (await guardedCase('getCase')) || {};
        break;
      case 'decision-center':
      case 'completeness-center': {
        const listed = (await guardedCase('listCertificates')) || {};
        const seen = (await guardedCase('getCase')) || {};
        state.data = { ...listed, case: seen.case };
        break;
      }
      case 'change-impact':
        state.data = {
          dependencies: (await guardedCase('getDependencies')) || null,
          ...((await guardedCase('getCase')) || {}),
        };
        break;
      case 'evidence-graph':
        state.data = { dependencies: (await guardedCase('getDependencies')) || null };
        break;
      case 'audit-approval': {
        const measurement = {
          configuration: await api.call('getOperationalMeasurementProfile'),
          sessions: null,
          error: null,
        };
        const permission = measurement.configuration
          && measurement.configuration.permission;
        if (measurement.configuration && measurement.configuration.enabled
            && permission && (permission.grants || []).includes('READ')) {
          try {
            measurement.sessions = await api.call('listOperationalMeasurementSessions');
          } catch (error) {
            if (error instanceof ApiRefusal) measurement.error = error;
            else throw error;
          }
        }
        const events = await api.call('listEvents', caseId ? { query: { case_id: caseId } } : {});
        const listed = (await guardedCase('listCertificates')) || {};
        const seen = (await guardedCase('getCase')) || {};
        state.data = {
          events: (events && events.events) || [],
          certificates: listed.certificates || [],
          case: seen.case,
          measurement,
        };
        state.exportHref = caseId ? api.bundleHref(caseId) : '#';
        break;
      }
      case 'federation-center': {
        const events = await api.call('listEvents', {});
        state.data = { events: (events && events.events) || [] };
        break;
      }
      case 'verification-center': {
        const listed = (await guardedCase('listCertificates')) || {};
        state.data = { certificates: listed.certificates || [] };
        break;
      }
      case 'qualification-planner':
      case 'conversion-planner':
      case 'physical-feedback':
      default:
        state.data = {};
        break;
    }
  } catch (error) {
    if (error instanceof ApiRefusal) state.error = error;
    else throw error;
  }
  return state;
}

/* ------------------------------------------------------------------ */
/* the browser shell                                                   */
/* ------------------------------------------------------------------ */

const modules = new Map();

async function loadWorkspace(id) {
  if (!modules.has(id)) {
    modules.set(id, (await import(`./workspaces/${id}.js`)).workspace);
  }
  return modules.get(id);
}

export function createStudio(document, options = {}) {
  const api = new StudioApi({
    base: options.base || '', actor: options.actor || '',
    username: options.username || '', password: options.password || '',
    bearerToken: options.bearerToken || '', apiKey: options.apiKey || '',
  });
  const nav = document.getElementById('crg-nav');
  const panel = document.getElementById('crg-workspace');
  const main = document.getElementById('crg-main');
  const status = document.getElementById('crg-status');
  const heading = document.getElementById('crg-main-heading');
  const principles = document.getElementById('crg-principles-body');
  const session = document.getElementById('crg-session');
  const actorInput = document.getElementById('session-actor');
  const authModeInput = document.getElementById('session-auth-mode');
  const usernameInput = document.getElementById('session-username');
  const passwordInput = document.getElementById('session-password');
  const bearerTokenInput = document.getElementById('session-bearer-token');
  const apiKeyInput = document.getElementById('session-api-key');
  const authenticationFields = {
    basic: document.getElementById('session-basic-fields'),
    bearer: document.getElementById('session-bearer-fields'),
    'api-key': document.getElementById('session-api-key-fields'),
    development: document.getElementById('session-development-fields'),
  };
  const caseInput = document.getElementById('session-case');
  const connection = document.getElementById('crg-connection');
  const connectionLabel = document.getElementById('crg-connection-label');
  const presence = document.getElementById('crg-presence');
  const workspaceSearch = document.getElementById('crg-workspace-search');
  const contextWorkspace = document.getElementById('crg-context-workspace');
  const contextCase = document.getElementById('crg-context-case');
  const health = document.getElementById('crg-health');
  const healthLabel = document.getElementById('crg-health-label');
  const progressLabel = document.getElementById('crg-progress-label');
  const progressBar = document.getElementById('crg-progress-bar');
  const themeButton = document.getElementById('crg-theme');
  const activity = document.getElementById('crg-activity');
  const activityTitle = document.getElementById('crg-activity-title');
  const activityDetail = document.getElementById('crg-activity-detail');
  const activityClose = document.getElementById('crg-activity-close');
  const guide = document.getElementById('crg-guide');
  const guideOpen = document.getElementById('crg-guide-open');
  const guideClose = document.getElementById('crg-guide-close');
  const guideContent = document.getElementById('crg-guide-content');
  const guideMap = document.getElementById('crg-guide-map');
  const guideStepLabel = document.getElementById('crg-guide-step-label');
  const guideProgress = document.getElementById('crg-guide-progress');
  const guideBack = document.getElementById('crg-guide-back');
  const guideNext = document.getElementById('crg-guide-next');
  const guideJump = document.getElementById('crg-guide-jump');

  let activeId = WORKSPACES[0].id;
  let caseId = '';
  let tourIndex = 0;
  let firstWorkspaceScheduled = false;
  const forms = {};
  const actionResults = {};

  function scheduleWorkspacePerformance(workspace, startedAt) {
    if (typeof window === 'undefined' || startedAt === null) return;
    const record = (endedAt) => {
      const duration = Math.max(0, endedAt - startedAt);
      const ledger = window.__crgStudioPerformance || { views: [] };
      ledger.views.push({ workspace, duration });
      window.__crgStudioPerformance = ledger;
      if (document.documentElement && document.documentElement.dataset) {
        document.documentElement.dataset.crgStudioViewMetrics = JSON.stringify(ledger.views);
      }
      if (typeof window.CustomEvent === 'function'
          && typeof window.dispatchEvent === 'function') {
        window.dispatchEvent(new window.CustomEvent('crg-studio-view-ready', {
          detail: { workspace, duration },
        }));
      }
    };
    if (panel && panel.classList && typeof panel.addEventListener === 'function') {
      const onAnimationStart = (event) => {
        if (event.animationName !== 'crg-ready-probe') return;
        record(Number(event.timeStamp));
      };
      panel.addEventListener('animationstart', onAnimationStart, { once: true });
      panel.classList.remove('crg-performance-probe');
      // A style/layout flush makes a repeated workspace activation start a new
      // invisible animation; its AnimationEvent timestamp is the browser's
      // post-layout clock even where the Performance API is unavailable.
      void panel.offsetWidth;
      panel.classList.add('crg-performance-probe');
      return;
    }
    const ready = () => {
      const endedAt = browserNow(document);
      if (endedAt !== null) record(endedAt);
    };
    if (typeof window.requestAnimationFrame === 'function') {
      window.requestAnimationFrame(() => window.requestAnimationFrame(ready));
    } else {
      ready();
    }
  }

  function scheduleFirstWorkspaceReady() {
    if (firstWorkspaceScheduled || typeof window === 'undefined') return;
    firstWorkspaceScheduled = true;
    performanceMark(PERFORMANCE_MARKS.firstWorkspaceRendered);
    const ready = () => {
      performanceMark(PERFORMANCE_MARKS.interactionReady);
      if (window.performance && typeof window.performance.measure === 'function') {
        try {
          window.performance.measure(
            PERFORMANCE_MARKS.moduleToReady,
            PERFORMANCE_MARKS.moduleStart,
            PERFORMANCE_MARKS.interactionReady,
          );
        } catch (_error) {
          // A browser that discarded an earlier mark still exposes the
          // interaction-ready mark; measurement collection fails closed.
        }
      }
      if (document.documentElement && document.documentElement.dataset) {
        document.documentElement.dataset.crgStudioReady = 'true';
      }
      if (typeof window.CustomEvent === 'function'
          && typeof window.dispatchEvent === 'function') {
        window.dispatchEvent(new window.CustomEvent('crg-studio-ready', {
          detail: { workspace: activeId },
        }));
      }
    };
    if (typeof window.requestAnimationFrame === 'function') {
      // The second frame is the first point at which the newly inserted
      // workspace has necessarily had an opportunity to paint.
      window.requestAnimationFrame(() => window.requestAnimationFrame(ready));
    } else {
      ready();
    }
  }

  function announce(message) {
    if (status) status.textContent = message;
  }

  function setActivity(open, title = 'Working', detail = 'Preparing your request…') {
    if (!activity) return;
    activity.hidden = !open;
    if (activityTitle) activityTitle.textContent = title;
    if (activityDetail) activityDetail.textContent = detail;
  }

  function paintGuide() {
    const step = TOUR_STEPS[tourIndex];
    if (guideContent) guideContent.innerHTML = renderTourStep(step);
    if (guideMap) guideMap.innerHTML = renderTourMap(TOUR_STEPS, tourIndex);
    if (guideStepLabel) guideStepLabel.textContent = `Step ${tourIndex + 1} of ${TOUR_STEPS.length}`;
    if (guideProgress) {
      guideProgress.max = TOUR_STEPS.length;
      guideProgress.value = tourIndex + 1;
      guideProgress.textContent = `${tourIndex + 1} of ${TOUR_STEPS.length}`;
    }
    if (guideBack) guideBack.disabled = tourIndex === 0;
    if (guideNext) guideNext.textContent = tourIndex === TOUR_STEPS.length - 1 ? 'Finish' : 'Next';
    if (guideJump) guideJump.textContent = step.action;
  }

  function openGuide() {
    tourIndex = 0;
    paintGuide();
    if (!guide) return;
    if (typeof guide.showModal === 'function') guide.showModal();
    else {
      guide.open = true;
      guide.setAttribute('open', '');
    }
    announce('Platform tour opened.');
  }

  function closeGuide() {
    if (!guide) return;
    if (typeof guide.close === 'function') guide.close();
    else {
      guide.open = false;
      if (typeof guide.removeAttribute === 'function') guide.removeAttribute('open');
    }
    if (guideOpen) guideOpen.focus();
    announce('Platform tour closed.');
  }

  function nextGuideStep() {
    if (tourIndex >= TOUR_STEPS.length - 1) {
      closeGuide();
      return;
    }
    tourIndex += 1;
    paintGuide();
  }

  function previousGuideStep() {
    if (tourIndex === 0) return;
    tourIndex -= 1;
    paintGuide();
  }

  function selectGuideStep(event) {
    const target = event.target && typeof event.target.closest === 'function'
      ? event.target.closest('[data-guide-index]') : null;
    if (!target) return;
    const index = Number(target.dataset.guideIndex);
    if (!Number.isInteger(index) || index < 0 || index >= TOUR_STEPS.length) return;
    tourIndex = index;
    paintGuide();
  }

  function cancelGuide(event) {
    if (event && typeof event.preventDefault === 'function') event.preventDefault();
    closeGuide();
  }

  // Native <dialog> implementations normally translate Escape into a
  // `cancel` event.  Some embedded/webview profiles do not, so keep an
  // explicit keyboard fallback at the dialog boundary.  Preventing the
  // default avoids a second native close when both paths are available.
  function keydownGuide(event) {
    if (!event || event.key !== 'Escape') return;
    if (typeof event.preventDefault === 'function') event.preventDefault();
    closeGuide();
  }

  function dismissGuideBackdrop(event) {
    if (event.target === guide) closeGuide();
  }

  function jumpFromGuide() {
    const destination = TOUR_STEPS[tourIndex].workspace;
    closeGuide();
    show(destination, { moveFocus: true });
  }

  function tabs() {
    return Array.from(nav.querySelectorAll('[role="tab"]'));
  }

  function paintNav() {
    nav.innerHTML = renderNav(WORKSPACES, activeId);
  }

  async function show(id, { moveFocus = false, startedAt = null } = {}) {
    const viewStartedAt = startedAt === null ? browserNow(document) : Number(startedAt);
    activeId = id;
    paintNav();
    const meta = WORKSPACES.find((w) => w.id === id) || WORKSPACES[0];
    const index = WORKSPACES.findIndex((w) => w.id === meta.id);
    if (heading) heading.textContent = meta.title;
    if (contextWorkspace) contextWorkspace.textContent = meta.title;
    if (contextCase) contextCase.textContent = caseId ? `Case ${caseId}` : 'No case open';
    if (progressLabel) progressLabel.textContent = `Step ${index + 1} of ${WORKSPACES.length}`;
    if (progressBar) {
      progressBar.max = WORKSPACES.length;
      progressBar.value = index + 1;
      progressBar.textContent = `${index + 1} of ${WORKSPACES.length}`;
    }
    if (main) main.setAttribute('aria-labelledby', `tab-${id}`);
    announce(`Loading ${meta.title}.`);
    panel.innerHTML = `<p class="crg-empty" role="note">Loading ${esc(meta.title)}…</p>`;
    let markup;
    try {
      const workspace = await loadWorkspace(id);
      const state = await fetchState(api, id, { caseId });
      state.form = forms[id] || {};
      state.lastAction = actionResults[id] || null;
      markup = workspace.render(state);
      announce(state.error
        ? `${meta.title} loaded with a refusal from the server.`
        : `${meta.title} loaded.`);
    } catch (error) {
      markup = refusal({
        message: error && error.message ? error.message : String(error),
        remedy: 'This is a client-side failure, not a refusal from the server. '
          + 'The API remains reachable directly.',
        category: 'studio',
      });
      announce(`${meta.title} could not be loaded.`);
    }
    panel.innerHTML = markup;
    scheduleWorkspacePerformance(meta.id, viewStartedAt);
    scheduleFirstWorkspaceReady();
    if (typeof window !== 'undefined' && window.history && window.location) {
      const nextHash = `#${encodeURIComponent(meta.id)}`;
      if (window.location.hash !== nextHash) window.history.replaceState(null, '', nextHash);
    }
    if (moveFocus && main) main.focus();
  }

  function onNavKeydown(event) {
    const list = tabs();
    const index = list.findIndex((tab) => tab === document.activeElement);
    if (index < 0) return;
    let next = null;
    if (event.key === 'ArrowDown' || event.key === 'ArrowRight') next = (index + 1) % list.length;
    else if (event.key === 'ArrowUp' || event.key === 'ArrowLeft') {
      next = (index - 1 + list.length) % list.length;
    } else if (event.key === 'Home') next = 0;
    else if (event.key === 'End') next = list.length - 1;
    if (next === null) return;
    event.preventDefault();
    const target = list[next];
    list.forEach((tab) => tab.setAttribute('tabindex', '-1'));
    target.setAttribute('tabindex', '0');
    target.focus();
  }

  function onNavClick(event) {
    const tab = event.target.closest('[role="tab"]');
    if (!tab) return;
    show(tab.dataset.workspace, { moveFocus: true, startedAt: event.timeStamp });
  }

  function filterWorkspaces() {
    const query = workspaceSearch ? workspaceSearch.value.trim().toLowerCase() : '';
    const list = tabs();
    list.forEach((tab) => {
      tab.hidden = Boolean(query) && !String(tab.dataset.search || '').includes(query);
    });
    nav.querySelectorAll('.crg-nav__group').forEach((headingNode) => {
      let sibling = headingNode.nextElementSibling;
      let visible = false;
      while (sibling && !sibling.classList.contains('crg-nav__group')) {
        if (sibling.getAttribute('role') === 'tab' && !sibling.hidden) visible = true;
        sibling = sibling.nextElementSibling;
      }
      headingNode.hidden = !visible;
    });
  }

  async function checkHealth() {
    try {
      await api.call('healthLive');
      const ready = await api.call('healthReady');
      const ok = !ready || ready.ok !== false;
      if (health) health.dataset.state = ok ? 'ready' : 'unavailable';
      if (healthLabel) healthLabel.textContent = ok ? 'Service ready' : 'Service not ready';
    } catch (_error) {
      if (health) health.dataset.state = 'unavailable';
      if (healthLabel) healthLabel.textContent = 'Service unavailable';
    }
  }

  function applyTheme() {
    if (typeof localStorage === 'undefined' || !document.documentElement) return;
    const current = localStorage.getItem('crg-studio-theme') || 'auto';
    const next = current === 'auto' ? 'light' : current === 'light' ? 'dark' : 'auto';
    localStorage.setItem('crg-studio-theme', next);
    if (next === 'auto') document.documentElement.removeAttribute('data-theme');
    else document.documentElement.setAttribute('data-theme', next);
    if (themeButton) themeButton.title = `Color theme: ${next}`;
    announce(`Color theme set to ${next}.`);
  }

  async function collectForm(fieldNames = null) {
    const values = {};
    const selected = fieldNames && fieldNames.length ? new Set(fieldNames) : null;
    const controls = Array.from(panel.querySelectorAll('input, textarea, select'));
    for (const control of controls) {
      if (!control.name) continue;
      if (selected && !selected.has(control.name)) continue;
      if (control.type === 'file') {
        const file = control.files && control.files[0];
        if (!file) continue;
        const maximum = 24 * 1024 * 1024;
        if (file.size > maximum) {
          throw new Error('This browser upload is limited to 24 MiB after base64 expansion. Use crg-verify locally for larger bundles.');
        }
        const bytes = new Uint8Array(await file.arrayBuffer());
        let binary = '';
        const block = 0x8000;
        for (let offset = 0; offset < bytes.length; offset += block) {
          binary += String.fromCharCode(...bytes.subarray(offset, offset + block));
        }
        values[control.name] = btoa(binary);
      } else {
        values[control.name] = control.value;
      }
    }
    forms[activeId] = { ...(forms[activeId] || {}), ...values };
    return values;
  }

  /**
   * Workspace actions.  Every branch calls a documented operation through
   * `api`, and every long-running one goes through `api.run`, which submits,
   * polls, and reports — because 38.3 answers those with a job identifier and
   * a client that expected a result would be coding against a contract the
   * server does not offer.
   */
  async function onAction(event) {
    const button = event.target.closest('[data-action]');
    if (!button || button.tagName === 'A') return;
    const name = button.dataset.action;
    const fieldNames = String(button.dataset.fields || '').split(/\s+/).filter(Boolean);
    let values;
    try {
      values = await collectForm(fieldNames);
    } catch (error) {
      announce(`Cannot prepare this request: ${error.message}`);
      return null;
    }
    let body;
    if (name === 'preview-decision-challenge' || name === 'record-decision-challenge') {
      body = decisionChallengeBody(values);
    } else if (name === 'preview-intake' || name === 'confirm-intake') {
      body = registryIntakeBody(values, { confirm: name === 'confirm-intake' });
    } else if (name === 'preview-commitment' || name === 'compare-commitment') {
      body = safeCommitmentBody(values);
    } else if (name === 'preview-comparative-evaluation'
        || name === 'generate-comparative-evaluation') {
      body = comparativeEvaluationBody(values);
    } else if (name === 'preview-comparative-change'
        || name === 'generate-comparative-change') {
      body = comparativeChangeBody(values);
    } else {
      body = formBody(values);
    }
    if (name === 'verify-decision-challenge') {
      const record = displayedDecisionChallenge(actionResults[activeId] || {});
      if (!record) {
        announce('Preview, record, or inspect a Decision Challenge before verifying it.');
        return null;
      }
      body = { record };
    }
    if (name === 'verify-comparative-change') {
      const record = displayedComparativeChange(actionResults[activeId] || {});
      if (!record) {
        announce('Preview, generate, or inspect comparative change evidence before verifying it.');
        return null;
      }
      body = { record };
    }
    const long = {
      certify: 'certifyCase', generate: 'generateFamily', evaluate: 'evaluateFamily',
      'preview-commitment': 'previewCommitment',
      'compare-commitment': 'compareCommitment',
      'preview-commitment-json': 'previewCommitment',
      'compare-commitment-json': 'compareCommitment',
      'preview-comparative-evaluation': 'previewComparativeEvaluation',
      'generate-comparative-evaluation': 'generateComparativeEvaluation',
      'preview-comparative-evaluation-json': 'previewComparativeEvaluation',
      'generate-comparative-evaluation-json': 'generateComparativeEvaluation',
      'preview-comparative-change': 'previewComparativeChange',
      'generate-comparative-change': 'generateComparativeChange',
      'preview-comparative-change-json': 'previewComparativeChange',
      'generate-comparative-change-json': 'generateComparativeChange',
      'build-geometry': 'buildGeometry',
      'preview-phase': 'previewPhaseAnalysis', 'analyze-phase': 'analyzePhase',
      'preview-change': 'previewChange', 'classify-change': 'classifyChange',
      'preview-decision-challenge': 'previewDecisionChallenge',
      'record-decision-challenge': 'recordDecisionChallenge',
      recompute: 'recomputeCase', 'plan-conversion': 'planConversion',
      'plan-qualification': 'planQualification', 'import-registry': 'importRegistry',
      'confirm-intake': 'confirmRegistryIntake',
      'confirm-intake-json': 'confirmRegistryIntake',
      migrate: 'migrateCase', 'import-bundle': 'importBundle',
      'assemble-contract': 'assembleTechnologyContract',
    }[name];
    const short = {
      'open-case': 'getCase', 'reload-case': 'getCase', 'create-case': 'createCase',
      'validate-case': 'validateCase', 'branch-case': 'createBranch',
      'create-branch': 'createBranch', 'merge-branch': 'mergeCase',
      'compile-query': 'compileQuery', 'refresh-certificates': 'listCertificates',
      'preview-intake': 'previewRegistryIntake',
      'preview-intake-json': 'previewRegistryIntake',
      'inspect-comparative-evaluation': 'getComparativeEvaluation',
      'verify-comparative-evaluation': 'verifyComparativeEvaluation',
      'inspect-comparative-change': 'getComparativeChange',
      'verify-comparative-change': 'verifyComparativeChange',
      'verify-comparative-change-json': 'verifyComparativeChange',
      'inspect-decision-challenge': 'getDecisionChallenge',
      'verify-decision-challenge': 'verifyDecisionChallenge',
      dependencies: 'getDependencies', 'register-evidence': 'registerEvidence',
      'create-request': 'createEvaluatorRequest', 'request-evaluation': 'createEvaluatorRequest',
      'register-result': 'registerEvidence', 'issue-envelope': 'issueCapabilityEnvelope',
      'evaluate-privately': 'evaluatePrivately', 'verify-bundle': 'verifyBundle',
      'reload-events': 'listEvents', redact: 'redactObject',
      'export-audit': 'exportAudit',
      'export-bundle': 'exportBundle',
      'revoke-capability': 'revokeCapability',
      'execute-transition': 'executeTransition',
      'create-webhook': 'createWebhookSubscription',
      'list-webhooks': 'listWebhookSubscriptions',
      'delete-webhook': 'deleteWebhookSubscription',
      'create-retention-policy': 'createRetentionPolicy',
      'list-retention-policies': 'listRetentionPolicies',
      'evaluate-retention': 'evaluateRetention',
      'enforce-retention': 'enforceRetention',
      'set-legal-hold': 'setObjectLegalHold',
      'measurement-refresh-profile': 'getOperationalMeasurementProfile',
      'measurement-list': 'listOperationalMeasurementSessions',
      'measurement-start': 'startOperationalMeasurementSession',
      'measurement-show': 'getOperationalMeasurementSession',
      'measurement-active-start': 'startOperationalMeasurementActive',
      'measurement-active-end': 'endOperationalMeasurementActive',
      'measurement-compute-start': 'startOperationalMeasurementCompute',
      'measurement-compute-end': 'endOperationalMeasurementCompute',
      'measurement-wait-start': 'startOperationalMeasurementWait',
      'measurement-wait-end': 'endOperationalMeasurementWait',
      'measurement-observe': 'recordOperationalMeasurementObservation',
      'measurement-counterfactual': 'recordOperationalMeasurementCounterfactual',
      'measurement-end': 'endOperationalMeasurementSession',
      'measurement-export-session': 'exportOperationalMeasurementSession',
      'measurement-verify-export': 'verifyOperationalMeasurementExport',
      'measurement-retention-preview-action': 'previewOperationalMeasurementRetention',
      'measurement-retention-enforce-action': 'enforceOperationalMeasurementRetention',
      'measurement-delete': 'deleteOperationalMeasurementSession',
    }[name];
    const operation = long || short;
    if (!operation) return null;
    // Case Setup carries its own case field; typing there selects the case
    // rather than sending an identifier the rest of Studio does not know
    // about, so the header and the workspace cannot disagree about which
    // case is open.
    if (body.case_id && body.case_id !== caseId) {
      caseId = body.case_id;
      if (caseInput) caseInput.value = caseId;
    }
    // Path parameters come from the operation's own template, so an endpoint
    // that is not case-scoped is never sent a case identifier it does not
    // want, and one that is can never be called without it.
    const params = pathParams(operation, { caseId, body });
    // The measurement session identifier is a path parameter on every
    // follow-on operation. Keep it out of the strict closed JSON body.
    if (params.session_id) delete body.session_id;
    if (Object.prototype.hasOwnProperty.call(params, 'case_id') && !caseId) {
      announce('Choose a case first: this operation is scoped to one.');
      return null;
    }
    if (Object.prototype.hasOwnProperty.call(params, 'session_id') && !params.session_id) {
      announce('Enter a pseudonymous session ID beginning psn- first.');
      return null;
    }
    button.disabled = true;
    button.setAttribute('aria-busy', 'true');
    announce('Working…');
    setActivity(true, 'Working on this case', 'Submitting the documented API operation…');
    try {
      if (long) {
        const { job, result } = await api.run(long, { params, body },
          { onProgress: (record) => {
            announce(`Job ${record.status.toLowerCase()}.`);
            setActivity(true, 'Computation in progress', `Job ${record.status.toLowerCase()}.`);
          } });
        announce(`Finished: ${(job && job.status) || 'done'}.`);
        actionResults[activeId] = { operation: long, result };
        await show(activeId);
        return result;
      }
      const query = short === 'exportAudit' ? body : null;
      const result = await api.call(short, { params, body, query });
      actionResults[activeId] = { operation: short, result };
      if (short === 'exportBundle' && result && result.blob) {
        const url = URL.createObjectURL(result.blob);
        const anchor = document.createElement('a');
        anchor.href = url;
        anchor.download = `${caseId || 'crg-case'}.crg`;
        anchor.click();
        URL.revokeObjectURL(url);
      }
      if (short === 'exportAudit' && result && result.record_type === 'AuditExportRecord') {
        const bytes = JSON.stringify(result, null, 2);
        const url = URL.createObjectURL(new Blob([bytes], { type: 'application/json' }));
        const anchor = document.createElement('a');
        const tenant = String(result.tenant_id || 'tenant').replace(/[^A-Za-z0-9._-]+/g, '-');
        anchor.href = url;
        anchor.download = `crg-audit-${tenant}.json`;
        anchor.click();
        URL.revokeObjectURL(url);
      }
      if (short === 'exportOperationalMeasurementSession'
          && result && result.record_type === 'OperationalMeasurementExport') {
        const bytes = JSON.stringify(result, null, 2);
        const url = URL.createObjectURL(new Blob([bytes], { type: 'application/json' }));
        const anchor = document.createElement('a');
        const sessionName = String((result.session || {}).session_id || 'session')
          .replace(/[^A-Za-z0-9._-]+/g, '-');
        anchor.href = url;
        anchor.download = `${sessionName}.measurement.json`;
        anchor.click();
        URL.revokeObjectURL(url);
      }
      announce('Done.');
      await show(activeId);
    } catch (error) {
      if (error instanceof ApiRefusal) {
        panel.insertAdjacentHTML('afterbegin', refusal(error));
        announce(`Refused: ${error.message}`);
      } else {
        announce(`Failed: ${error.message}`);
      }
    } finally {
      button.disabled = false;
      button.removeAttribute('aria-busy');
      setActivity(false);
    }
    return null;
  }

  function authenticationMode() {
    const selected = authModeInput ? authModeInput.value : '';
    return Object.prototype.hasOwnProperty.call(authenticationFields, selected)
      ? selected : 'basic';
  }

  function onPanelChange(event) {
    if (!event.target) return;
    if (event.target.name === 'challenge-mutation-type') {
      const selected = String(event.target.value || '');
      panel.querySelectorAll('[data-challenge-input]').forEach((group) => {
        group.hidden = group.dataset.challengeInput !== selected;
      });
    }
  }

  function showAuthenticationFields() {
    const selected = authenticationMode();
    Object.entries(authenticationFields).forEach(([mode, fields]) => {
      if (fields) fields.hidden = mode !== selected;
    });
  }

  function onSession(event) {
    event.preventDefault();
    const mode = authenticationMode();
    // Clear every other mode before copying the selected secret. This makes
    // the one-scheme invariant visible at the UI boundary as well as api.js.
    api.actor = '';
    api.username = '';
    api.password = '';
    api.bearerToken = '';
    api.apiKey = '';
    if (mode === 'basic') {
      api.username = usernameInput ? usernameInput.value.trim() : '';
      api.password = passwordInput ? passwordInput.value : '';
    } else if (mode === 'bearer') {
      api.bearerToken = bearerTokenInput ? bearerTokenInput.value.trim() : '';
    } else if (mode === 'api-key') {
      api.apiKey = apiKeyInput ? apiKeyInput.value.trim() : '';
    } else {
      api.actor = actorInput ? actorInput.value.trim() : '';
    }
    caseId = caseInput ? caseInput.value.trim() : '';
    const connectionName = mode === 'bearer' ? 'OIDC bearer'
      : mode === 'api-key' ? 'Service identity'
        : api.username || api.actor || 'Connected';
    if (connectionLabel) connectionLabel.textContent = connectionName;
    if (presence) presence.dataset.state = 'connected';
    if (connection) connection.open = false;
    announce(caseId ? `Case ${caseId} selected.` : 'No case selected.');
    show(activeId, { moveFocus: true });
  }

  function start() {
    if (principles) principles.innerHTML = renderPrinciples();
    paintNav();
    nav.addEventListener('click', onNavClick);
    nav.addEventListener('keydown', onNavKeydown);
    panel.addEventListener('click', onAction);
    // Keep the shell's single delegated click listener contract intact while
    // still giving the profile selector a native change boundary.
    panel.onchange = onPanelChange;
    if (session) session.addEventListener('submit', onSession);
    if (authModeInput) authModeInput.addEventListener('change', showAuthenticationFields);
    showAuthenticationFields();
    if (workspaceSearch) workspaceSearch.addEventListener('input', filterWorkspaces);
    if (themeButton) themeButton.addEventListener('click', applyTheme);
    if (activityClose) activityClose.addEventListener('click', () => setActivity(false));
    if (guideOpen) guideOpen.addEventListener('click', openGuide);
    if (guideClose) guideClose.addEventListener('click', closeGuide);
    if (guide) guide.addEventListener('cancel', cancelGuide);
    if (guide) guide.addEventListener('click', dismissGuideBackdrop);
    if (guide) guide.addEventListener('keydown', keydownGuide);
    if (guideMap) guideMap.addEventListener('click', selectGuideStep);
    if (guideBack) guideBack.addEventListener('click', previousGuideStep);
    if (guideNext) guideNext.addEventListener('click', nextGuideStep);
    if (guideJump) guideJump.addEventListener('click', jumpFromGuide);
    if (typeof localStorage !== 'undefined' && document.documentElement) {
      const selected = localStorage.getItem('crg-studio-theme') || 'auto';
      if (selected !== 'auto') document.documentElement.setAttribute('data-theme', selected);
    }
    if (typeof document.addEventListener === 'function') {
      document.addEventListener('keydown', (event) => {
        if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
          event.preventDefault();
          if (workspaceSearch) workspaceSearch.focus();
        }
      });
    }
    const requested = typeof window !== 'undefined'
      ? decodeURIComponent(String(window.location.hash || '').replace(/^#/, '')) : '';
    if (requested && WORKSPACES.some((item) => item.id === requested)) activeId = requested;
    show(activeId);
    checkHealth();
  }

  return { start, show, api, get activeId() { return activeId; } };
}

if (typeof document !== 'undefined' && typeof window !== 'undefined') {
  const studio = createStudio(document, {});
  window.crgStudio = studio;
  studio.start();
}

export default {
  comparativeChangeBody, comparativeEvaluationBody, createStudio,
  decisionChallengeBody, displayedComparativeChange, displayedDecisionChallenge,
  fetchState, formBody, pathParams, renderNav, renderPrinciples,
  renderTourStep, renderTourMap, TOUR_STEPS,
  PERFORMANCE_MARKS, registryIntakeBody, safeCommitmentBody,
};
