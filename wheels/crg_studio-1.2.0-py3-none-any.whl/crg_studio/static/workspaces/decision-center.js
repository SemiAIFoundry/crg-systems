/**
 * Decision Center (spec 41.1): winners, possible winners, retained
 * alternatives, margins, pruning, regret, and claim scope.
 *
 * This workspace renders the canonical human-readable certificate report of
 * 50.2 in its mandatory order.  50.3 permits an implementation to vary
 * typography, language, and accessibility treatment, and forbids hiding or
 * reordering the claim scope, completeness basis, uncertainty, or
 * verification status "in a manner that could mislead the reader".  Studio
 * therefore emits all twenty-one items, numbered, in order, with the
 * `data-report-item` attribute the test suite reads — so the ordering is a
 * checked property rather than a convention that survives until the next
 * redesign.
 *
 * The headline is `decisionHeadline` from `render.js` and not local markup.
 * That is the whole defence against 41.2's fourth principle: there is no
 * code path in this workspace that can name a single realization as the
 * answer, because this workspace does not contain one.
 */

import {
  absent, claimScopePanel, completenessPanel, decisionHeadline, definitionList, disclosure,
  emptyState, esc, evidenceBadge, hashChip, interval, join, marginPanel, outcomeInfo, panel,
  quantity, regretWitnessDetails, solverTrustChip, table, TERMS, verificationChip, whyPanel,
} from '../render.js';
import { action, field, notYet, select, shell } from '../workspace.js';

const meta = {
  id: 'decision-center',
  title: 'Decision Center',
  purpose:
    'Winners, possible winners, retained alternatives, margins, safe commitment, '
    + 'comparative regret, and claim scope.',
  releaseBoundary: 'v1.2-certified-phase-and-change',
  endpoints: [
    'previewCommitment', 'compareCommitment', 'certifyCase', 'listCertificates',
    'previewComparativeEvaluation', 'generateComparativeEvaluation',
    'getComparativeEvaluation', 'verifyComparativeEvaluation',
    'getJob', 'getJobResult', 'cancelJob',
  ],
};

const DEFAULT_COMMITMENT_REQUEST = JSON.stringify({
  family_id: 'future-decisions',
  policies: [
    { policy_id: 'retain-all', policy: 'retain-all' },
    { policy_id: 'universal-monotone', policy: 'universal-monotone' },
  ],
}, null, 2);

const DEFAULT_COMPARISON_REQUEST = JSON.stringify({
  evaluation_id: 'workflow-evaluation-1',
  inputs: {
    family: {
      bundle_id: 'declared-workflow-family',
      schema: { coordinates: [
        { identifier: 'burden', quantity: 'burden', unit: 'declared-unit', direction: 'MINIMIZE' },
      ] },
      realizations: [
        { realization_id: 'A', signature: [{ exact: '1' }], legality: 'LEGAL', evidence_class: 'IMPORTED' },
        { realization_id: 'B', signature: [{ exact: '2' }], legality: 'LEGAL', evidence_class: 'IMPORTED' },
      ],
      completeness: {
        basis_type: 'EXPLICIT_IMPORTED_FAMILY',
        declared_universe: 'the explicitly supplied workflow-evaluation family',
      },
    },
    decision: {
      scope_id: 'declared-workflow-decision',
      observation_level: 'ADDITIVE_PRICE',
      objective_family: { type: 'weighted_sum', weights: { burden: '1' } },
    },
    change: { change_id: 'declared-unchanged-input', changed_fields: [] },
  },
  realization_family_input_id: 'family',
  decision_family_input_id: 'decision',
  technology_scope: { description: 'replace with the exact evaluated technology scope' },
  evidence_scope: { classes: ['IMPORTED'] },
  change_scope: { input_id: 'change' },
  scenario_scope: { case_ids: ['case-1'] },
  held_out_treatment: { kind: 'NONE', reason: 'single declared illustrative workload' },
  workload: [
    { case_id: 'case-1', eligible_ids: ['A', 'B'], work_item_ids: ['decision', 'evidence'] },
  ],
  oracle: {
    oracle_id: 'declared-finite-oracle',
    name: 'Declared finite exact minimum',
    version: '1',
    profile: 'finite-exact-minimum@1',
    input_bindings: 'DERIVE_FROM_EMBEDDED_INPUTS',
    answers: [{ case_id: 'case-1', winner_ids: ['A'], optimum: '1' }],
  },
  methods: [
    {
      method_id: 'crg', name: 'CRG workflow', version: '1', workflow: 'declared-crg-workflow',
      input_bindings: 'DERIVE_FROM_EMBEDDED_INPUTS',
      declared_budget: [{ metric: 'retained_items_per_case', unit: 'items', limit: '2' }],
      trace: [{
        case_id: 'case-1', selected_ids: ['A'], retained_ids: ['A', 'B'],
        achieved_value: '1', affected_ids: ['decision', 'evidence'],
        preserved_ids: ['decision', 'evidence'], invalidated_ids: [],
        verifier_status: 'VERIFIED_RELATIVE',
      }],
    },
    {
      method_id: 'reference', name: 'Declared reference workflow', version: '1',
      workflow: 'declared-reference-workflow',
      input_bindings: 'DERIVE_FROM_EMBEDDED_INPUTS',
      declared_budget: [{ metric: 'retained_items_per_case', unit: 'items', limit: '2' }],
      trace: [{
        case_id: 'case-1', selected_ids: ['B'], retained_ids: ['B'],
        achieved_value: '2', affected_ids: ['decision', 'evidence'],
        preserved_ids: ['evidence'], invalidated_ids: ['decision'],
        verifier_status: 'VERIFIED_RELATIVE',
      }],
    },
  ],
  limitations: [
    'Finite declared workload only',
    'No method ranking, economic interpretation, causal claim, or generalization',
  ],
}, null, 2);

const COMMITMENT_GUIDED_FIELDS = [
  'commitment-family-id', 'commitment-artifact-id',
  ...[1, 2, 3].flatMap((index) => [
    `commitment-policy-${index}-id`, `commitment-policy-${index}-type`,
    `commitment-policy-${index}-protected-ids`,
  ]),
];

const COMPARISON_GUIDED_FIELDS = [
  'comparison-evaluation-id-guided', 'comparison-family-id',
  'comparison-coordinate-id', 'comparison-coordinate-quantity',
  'comparison-coordinate-unit', 'comparison-coordinate-direction',
  'comparison-declared-universe', 'comparison-decision-id',
  'comparison-observation-level', 'comparison-objective-weight',
  'comparison-change-id', 'comparison-changed-fields',
  'comparison-technology-scope', 'comparison-evidence-classes',
  'comparison-case-id', 'comparison-eligible-ids', 'comparison-work-item-ids',
  'comparison-held-out-kind', 'comparison-held-out-reason',
  'comparison-oracle-id', 'comparison-oracle-name', 'comparison-oracle-version',
  'comparison-oracle-winners', 'comparison-oracle-optimum',
  'comparison-budget-metric', 'comparison-budget-unit', 'comparison-budget-limit',
  ...['a', 'b'].flatMap((suffix) => [
    `comparison-candidate-${suffix}-id`, `comparison-candidate-${suffix}-value`,
    `comparison-candidate-${suffix}-legality`,
    `comparison-candidate-${suffix}-evidence-class`,
    `comparison-method-${suffix}-id`, `comparison-method-${suffix}-name`,
    `comparison-method-${suffix}-version`, `comparison-method-${suffix}-workflow`,
    `comparison-method-${suffix}-selected`, `comparison-method-${suffix}-retained`,
    `comparison-method-${suffix}-achieved`, `comparison-method-${suffix}-affected`,
    `comparison-method-${suffix}-preserved`, `comparison-method-${suffix}-invalidated`,
    `comparison-method-${suffix}-verifier-status`,
  ]),
  'comparison-limitations', 'comparison-observation-id',
  'comparison-observation-method-id', 'comparison-observer',
  'comparison-observation-metric', 'comparison-observation-value',
  'comparison-observation-unit', 'comparison-observation-context',
  'comparison-counterfactual-id', 'comparison-counterfactual-statement',
  'comparison-counterfactual-provenance',
];

function formValue(form, name, fallback = '') {
  return Object.prototype.hasOwnProperty.call(form || {}, name) ? form[name] : fallback;
}

/** Wrap one item of the 50.2 report, carrying its mandatory position. */
function item(number, title, body, options = {}) {
  return `<section class="crg-report__item" data-report-item="${number}" `
    + `aria-labelledby="report-${number}-title"`
    + `${options.principle ? ` data-ux-principle="${esc(options.principle)}"` : ''}>`
    + `<h3 class="crg-report__title" id="report-${number}-title">`
    + `<span class="crg-report__number" aria-hidden="true">${number}.</span> ${esc(title)}</h3>`
    + `<div class="crg-report__body">${body}</div></section>`;
}

function objectiveTable(certificate) {
  const values = certificate.objective_values || {};
  const ids = Object.keys(values).sort();
  if (!ids.length) {
    return emptyState('No objective values are recorded on this certificate.');
  }
  return table('Objective value per realization', [
    { label: 'Realization' },
    { label: 'Exact value', hint: 'The value under exact semantics, where one exists (22.2).' },
    { label: 'Arithmetic enclosure', hint: 'Uncertainty from arithmetic and the solver (22.1).' },
    { label: 'Evidence uncertainty', hint: 'Measurement, model, and transfer uncertainty (22.1).' },
    { label: 'Conservative range', hint: 'The range a comparison is allowed to use (22.2).' },
    { label: 'Evidence class' },
  ], ids.map((id) => {
    const value = values[id] || {};
    return {
      attributes: ` data-realization="${esc(id)}"`,
      cells: [
        `<span class="crg-realization__name">${esc(id)}</span>`,
        value.exact === undefined || value.exact === null
          ? absent('UNSUPPORTED') : quantity(value.exact, { unit: value.unit || '' }),
        value.numerical_interval ? interval(value.numerical_interval, { kind: 'numerical' })
          : absent('UNSUPPORTED'),
        value.evidence_interval ? interval(value.evidence_interval, { kind: 'evidence' })
          : absent('UNSUPPORTED'),
        value.combined_interval ? interval(value.combined_interval, { kind: 'combined' })
          : absent('UNSUPPORTED'),
        evidenceBadge(value.evidence_class),
      ],
    };
  }));
}

function infeasiblePanel(certificate) {
  const infeasible = certificate.infeasible || {};
  const ids = Object.keys(infeasible).sort();
  if (!ids.length) return '';
  return panel('Candidates that cannot satisfy the requirement', join([
    `<ul class="crg-list">${ids.map((id) => `<li>`
      + `<span class="crg-realization__name">${esc(id)}</span>: ${esc(infeasible[id])}</li>`).join('')}</ul>`,
    `<p class="crg-prose">These are recorded as infeasible, not as poor candidates. `
    + `The distinction is preserved deliberately: an infeasible realization has no `
    + `objective value to rank (22.7).</p>`,
  ]), { tone: 'warn', principle: 'all-infeasible' });
}

function pruningPanel(certificate) {
  const certificates = certificate.pruning_certificates || [];
  if (!certificates.length) {
    return emptyState('Nothing was pruned. Every candidate in the family is still represented.');
  }
  return table('Pruned alternatives and the certificate that authorised each pruning', [
    { label: 'Pruned' },
    { label: 'Rule' },
    { label: 'Evidence class' },
    { label: 'Justification' },
  ], certificates.map((record) => ({
    cells: [
      `<span class="crg-realization__name">${esc(record.pruned || record.realization_id || '')}</span>`,
      record.rule ? `<code class="crg-code">${esc(record.rule)}</code>` : absent(),
      evidenceBadge(record.evidence_class),
      record.justification ? esc(record.justification) : absent(),
    ],
  })));
}

function geometryPanel(certificate) {
  const requiredObject = (certificate.derivation || {}).required_object;
  return definitionList([
    ['Complete realization registry hash', hashChip(certificate.complete_registry_hash)],
    ['Retained realization registry hash', hashChip(certificate.retained_registry_hash)],
    ['Decision-relevant object required by the query', requiredObject
      ? `<code class="crg-code">${esc(requiredObject)}</code>` : absent()],
    ['Decision-geometry preservation', certificate.geometry_preserved === true
        ? '<span class="crg-prose">Retention preserved the decision-relevant geometry.</span>'
        : certificate.geometry_preserved === false
          ? '<span class="crg-prose">Retention did <strong>not</strong> preserve the '
            + 'decision-relevant geometry, which is why this certificate is blocked (29.2).</span>'
          : absent('UNSUPPORTED')],
    ['Hash distinction', '<span class="crg-prose">Registry hashes identify realization '
      + 'registries. They are not the canonical root hashes of '
      + 'R, Γ, or K.</span>'],
  ]);
}

function certificateReport(certificate, state) {
  const record = certificate || {};
  const info = outcomeInfo(record.outcome);
  const scope = record.scope || {};
  const versions = record.engine_versions || {};
  return `<div class="crg-report" data-certificate="${esc(record.certificate_id || '')}">`
    + item(1, 'Claim', join([
      `<p class="crg-prose crg-prose--lead">${esc(state.claim || info.sentence)}</p>`,
      decisionHeadline(record),
    ]), { principle: 'claim-scope' })
    + item(2, 'Claim scope', claimScopePanel(record.claim_scope), { principle: 'claim-scope' })
    + item(3, 'Completeness basis', completenessPanel(record.completeness),
      { principle: 'completeness' })
    + item(4, 'Decision semantics', definitionList([
      ['Question', scope.question ? esc(scope.question) : absent()],
      ['Decision class', (record.derivation || {}).decision_class
        ? `<code class="crg-code">${esc(record.derivation.decision_class)}</code>` : absent()],
      ['Objective', scope.objective ? esc(scope.objective) : absent()],
      ['Comparison', `<p class="crg-prose">A realization is certified as beating a rival `
        + `only when its worst case is better than the rival's best case, with room to spare `
        + `for the declared indifference tolerance. A printed decimal is not enough (22.3, 22.6).</p>`],
    ]), { principle: 'plain-language' })
    + item(5, 'Required retained object', definitionList([
      ['Smallest object that could answer the question', (record.derivation || {}).required_object
        ? `<code class="crg-code">${esc(record.derivation.required_object)}</code>` : absent()],
      ['Rule that says so', (record.derivation || {}).rule_cited
        ? esc(record.derivation.rule_cited) : absent()],
    ]))
    + item(6, 'Selected, tied, or possible-winner realizations', join([
      decisionHeadline(record),
      objectiveTable(record),
      infeasiblePanel(record),
    ]), { principle: 'tie-vs-ambiguity' })
    + item(7, 'Runner-up and margin', marginPanel(record), { principle: 'margins' })
    + item(8, 'Numerical enclosure', `<p class="crg-prose">Uncertainty introduced by arithmetic `
      + `and the solver is recorded per realization in the table above, in its own column. `
      + `22.1 keeps it separate from evidence uncertainty because the two are reduced by `
      + `different work: better arithmetic, or better measurement.</p>`)
    + item(9, 'Evidence uncertainty', `<p class="crg-prose">Measurement, sampling, calibration, `
      + `transfer, model, and physical uncertainty, also in its own column above. `
      + `The Qualification Planner ranks the experiments that would shrink it.</p>`,
    { principle: 'resolving-evidence' })
    + item(10, 'Policy tolerance', definitionList([
      [TERMS.TOLERANCE(), scope.policy_tolerance !== undefined && scope.policy_tolerance !== null
        ? quantity(scope.policy_tolerance, { unit: scope.unit || '' })
        : absent('UNSUPPORTED')],
      ['What it means', `<p class="crg-prose">Differences smaller than this are treated as `
        + `equivalent by declared policy. It is a decision rule, not an uncertainty: `
        + `it does not shrink when the evidence improves (22.1).</p>`],
    ]), { principle: 'plain-language' })
    + item(11, 'Geometry basis', geometryPanel(record))
    + item(12, 'Retained and pruned alternatives', pruningPanel(record))
    + item(13, 'Regret witness', regretWitnessDetails(record))
    + item(14, 'Evidence classes and lineage', join([
      `<p class="crg-prose">Each objective value above carries the class of evidence that `
      + `produced it. A heuristic value may rank and explain; it may not authorize a `
      + `certified comparison, certified pruning, or a signature (5.3).</p>`,
      whyPanel(record, { title: 'Full derivation and dependencies' }),
    ]), { principle: 'evidence-classes' })
    + item(15, 'Solver trust profile', join([
      solverTrustChip(state.solverTrust || (scope.solver_trust_profile)),
      `<p class="crg-prose">23.1: independently checkable evidence is preferred to trust in `
      + `solver execution. A replay-bound result is reproducible, not proved.</p>`,
    ]), { principle: 'verified-or-replay' })
    + item(16, 'Verification level', join([
      verificationChip(state.verificationStatus || record.verification_status),
      `<p class="crg-prose">Verification is performed by <code class="crg-code">crg-verify</code>, `
      + `which runs without this server, this database, or this interface (25.1). `
      + `Open the Verification Center to run it against an exported bundle.</p>`,
    ]), { principle: 'verified-or-replay' })
    + item(17, 'Dependencies', definitionList([
      ['Depends on', (record.dependencies || []).length
        ? `<ul class="crg-list">${(record.dependencies || [])
          .map((d) => `<li>${hashChip(d)}</li>`).join('')}</ul>` : absent()],
      ['Evidence roots', (record.evidence_roots || []).length
        ? `<ul class="crg-list">${(record.evidence_roots || [])
          .map((d) => `<li>${hashChip(d)}</li>`).join('')}</ul>` : absent()],
    ]))
    + item(18, 'Validity and clock judgment', definitionList([
      ['Valid until', record.expiry ? esc(record.expiry) : absent('UNSUPPORTED')],
      ['Clock judgment', state.clockJudgment ? esc(state.clockJudgment)
        : absent('UNSUPPORTED')],
      ['What an absent judgment means', `<p class="crg-prose">A missing clock judgment is `
        + `not a passing one. Without a trusted time source, validity cannot be asserted `
        + `and the verifier reports it as indeterminate (45).</p>`],
    ]))
    + item(19, 'Reopen conditions', (record.reopen_conditions || []).length
      ? `<ul class="crg-list">${(record.reopen_conditions || [])
        .map((c) => `<li>${esc(c)}</li>`).join('')}</ul>`
      : emptyState('No reopen conditions were recorded on this certificate.'))
    + item(20, 'Signatures', (record.signatures || []).length
      ? `<ul class="crg-list">${(record.signatures || []).map((s) => `<li>`
        + `${esc(s.signer || s.key_id || '')} ${hashChip(s.signature || '')}</li>`).join('')}</ul>`
      : emptyState('Unsigned. An unsigned certificate is still a record; it is not an approval.'))
    + item(21, 'Limitations', join([
      `<ul class="crg-list">`
      + `<li>This certificate speaks only within its claim scope, stated in item 2.</li>`
      + `<li>It speaks only about the family described by its completeness basis, item 3.</li>`
      + `<li>Engine versions: ${Object.keys(versions).length
        ? esc(Object.entries(versions).map(([k, v]) => `${k} ${v}`).join(', '))
        : 'not recorded'}. A different version may reach a different result and must be `
        + `re-verified (15.2).</li>`
      + `</ul>`,
    ]))
    + `</div>`;
}

function certificateChooser(state) {
  const listed = ((state.data || {}).certificates) || [];
  if (!listed.length) return '';
  return table('Certificates issued for this case', [
    { label: 'Certificate' },
    { label: 'Outcome' },
    { label: 'Status', hint: 'The 17.1 lifecycle status of the certificate.' },
    { label: 'Affirmative', hint: 'Whether the outcome authorises anything (6.6).' },
    { label: '' },
  ], listed.map((certificate) => ({
    attributes: ` data-certificate="${esc(certificate.certificate_id || '')}"`,
    cells: [
      hashChip(certificate.certificate_id),
      `<span class="crg-outcome" data-outcome="${esc(certificate.outcome || '')}">`
      + `${esc(outcomeInfo(certificate.outcome).headline)}</span>`,
      certificate.status === 'UNVERIFIABLE_REDACTED'
        ? verificationChip('UNVERIFIABLE_REDACTED')
        : `<span>${esc(certificate.status || '')}</span>`,
      certificate.affirmative ? 'Yes' : 'No — this certificate authorises nothing',
      `<button type="button" class="crg-button crg-button--secondary" `
      + `data-action="show-certificate" data-certificate="${esc(certificate.certificate_id || '')}">`
      + `Open certificate ${esc(certificate.certificate_id || '')}</button>`,
    ],
  })));
}

function identityList(values) {
  const items = values || [];
  if (!items.length) return absent();
  return `<ul class="crg-list">${items.map((value) => `<li>`
    + `<code class="crg-code">${esc(value)}</code></li>`).join('')}</ul>`;
}

function latestCommitment(state) {
  const outputs = ((((state.lastAction || {}).result || {}).outputs) || {});
  if (outputs.artifact) return outputs.artifact;
  const stored = ((((state.data || {}).case || {}).safe_commitments) || {});
  const records = Object.values(stored).filter((record) => record && typeof record === 'object');
  records.sort((left, right) => String(left.artifact_id || '').localeCompare(
    String(right.artifact_id || ''),
  ));
  return records.length ? records[records.length - 1] : null;
}

function commitmentVerification(state) {
  const outputs = ((((state.lastAction || {}).result || {}).outputs) || {});
  return outputs.verification || null;
}

function futureDecisionTable(artifact) {
  const decisions = ((artifact.family || {}).decisions) || [];
  if (!decisions.length) return emptyState('No future decisions are recorded.');
  return table('Future decisions held fixed for every policy', [
    { label: 'Decision' },
    { label: 'Question and objective family' },
    { label: 'Decision class' },
    { label: 'Minimum sufficient object' },
    { label: 'Soundness rule' },
  ], decisions.map((decision) => {
    const scope = decision.scope || {};
    const derivation = decision.derivation || {};
    return { cells: [
      `<code class="crg-code">${esc(decision.decision_id || '')}</code>`,
      join([
        scope.question ? `<p class="crg-prose">${esc(scope.question)}</p>` : '',
        disclosure('Objective-family record', `<pre class="crg-pre" tabindex="0">`
          + `${esc(JSON.stringify(scope.objective_family || {}, null, 2))}</pre>`),
      ]),
      derivation.decision_class
        ? `<code class="crg-code">${esc(derivation.decision_class)}</code>` : absent(),
      derivation.required_object
        ? `<code class="crg-code">${esc(derivation.required_object)}</code>` : absent(),
      derivation.rule_cited ? esc(derivation.rule_cited) : absent(),
    ] };
  }));
}

function decisionResultTable(evaluation) {
  const results = evaluation.decision_results || [];
  if (!results.length) return emptyState(
    'No decision-preservation result was emitted. Read the policy refusal below.',
  );
  return table(`Decision preservation under ${evaluation.policy_id || 'this policy'}`, [
    { label: 'Decision' },
    { label: 'Required object' },
    { label: 'Result' },
    { label: 'Claim consequence' },
    { label: 'Reason' },
  ], results.map((result) => ({ cells: [
    `<code class="crg-code">${esc(result.decision_id || '')}</code>`,
    `<code class="crg-code">${esc(result.required_object || '')}</code>`,
    `<strong data-commitment-result="${esc(result.status || '')}">${esc(result.status || '')}</strong>`,
    esc(result.claim_consequence || ''),
    esc(result.detail || ''),
  ] })));
}

function pruningConditionTable(evaluation) {
  const assessments = evaluation.pruning_assessments || [];
  const rows = [];
  assessments.forEach((assessment) => {
    (assessment.conditions || []).forEach((condition) => {
      rows.push({
        attributes: ` data-pruning-condition="${esc(condition.number || '')}"`,
        cells: [
          `<code class="crg-code">${esc(assessment.candidate_id || '')}</code>`,
          `<code class="crg-code">${esc(assessment.decision_id || '')}</code>`,
          esc(condition.number),
          `<code class="crg-code">${esc(condition.identifier || '')}</code>`,
          `<strong>${esc(condition.status || '')}</strong>`,
          join([
            `<span>${esc(condition.detail || '')}</span>`,
            (condition.evidence || []).length
              ? `<div>${(condition.evidence || []).map((value) => hashChip(value)).join(' ')}</div>`
              : '',
          ]),
        ],
      });
    });
  });
  if (!rows.length) {
    return emptyState(
      evaluation.pruned_ids && evaluation.pruned_ids.length
        ? 'No pruning assessment was emitted; this policy cannot authorize those deletions.'
        : 'This policy pruned nothing, so no candidate-level pruning discharge was required.',
    );
  }
  return table('All ten pruning obligations, candidate by candidate', [
    { label: 'Candidate' },
    { label: 'Decision' },
    { label: '#' },
    { label: 'Obligation' },
    { label: 'Result' },
    { label: 'Evidence and reason' },
  ], rows);
}

function regretEvidenceTable(evaluation) {
  const witnesses = evaluation.regret_evidence || [];
  const bounds = evaluation.regret_bounds || [];
  const sections = [];
  if (witnesses.length) {
    sections.push(table('Constructive regret evidence', [
      { label: 'Decision and witness' },
      { label: 'Lost element and objective family' },
      { label: 'Full infimum' },
      { label: 'Retained infimum' },
      { label: 'Positive gap' },
      { label: 'Scope and proof profile' },
    ], witnesses.map((witness) => ({ cells: [
      `<code class="crg-code">${esc(witness.decision_id || '')}</code><br>`
        + `${hashChip(witness.witness_hash || witness.witness_id)}`,
      disclosure('Exact witness construction', `<pre class="crg-pre" tabindex="0">`
        + `${esc(JSON.stringify({
          lost_element: witness.lost_element,
          objective: witness.objective,
          membership: witness.family_membership_proof,
        }, null, 2))}</pre>`),
      quantity(witness.full_infimum),
      quantity(witness.retained_infimum),
      quantity(witness.gap),
      `<span>${esc(witness.scope || '')}</span><br>`
        + `<code class="crg-code">${esc(witness.verification_program || '')}</code>`,
    ] }))));
  }
  if (bounds.length) {
    sections.push(table('Typed bounded-regret facts', [
      { label: 'Decision and fact' },
      { label: 'Reconstructed bound' },
      { label: 'Declared tolerance' },
      { label: 'Accepted?' },
      { label: 'Proof profile' },
    ], bounds.map((fact) => ({ cells: [
      `<code class="crg-code">${esc(fact.decision_id || '')}</code><br>`
        + `${hashChip(fact.fact_hash || fact.fact_id)}`,
      quantity(fact.bound),
      quantity(fact.tolerance),
      fact.accepted === true ? 'Yes — bound does not exceed tolerance' : 'No',
      `<code class="crg-code">${esc(fact.proof_profile || '')}</code>`,
    ] }))));
  }
  if (!sections.length) {
    sections.push(emptyState(
      'No regret witness or bounded-regret acceptance was required for this evaluation. '
      + 'That absence alone is not proof that an unrecorded reduction would be safe.',
    ));
  }
  return join(sections);
}

function policyEvaluation(evaluation) {
  const refused = String(evaluation.status || '').includes('REFUSED');
  const refusals = evaluation.refusals || [];
  return panel(`Policy ${evaluation.policy_id || ''}: ${evaluation.status || 'UNKNOWN'}`, join([
    definitionList([
      ['Registered policy', `<code class="crg-code">${esc(evaluation.policy || '')}</code>`],
      ['Retained realization identities', identityList(evaluation.retained_ids)],
      ['Pruned realization identities', identityList(evaluation.pruned_ids)],
      ['What this status authorizes', refused
        ? '<strong>Nothing. Refusal preserves the full represented family.</strong>'
        : '<span>The recorded decision results and pruning assessments below control.</span>'],
    ]),
    decisionResultTable(evaluation),
    pruningConditionTable(evaluation),
    regretEvidenceTable(evaluation),
    refusals.length ? panel('Refusals that limit this policy', `<ul class="crg-list">`
      + `${refusals.map((value) => `<li>${esc(value)}</li>`).join('')}</ul>`, { tone: 'warn' }) : '',
    disclosure('Retained fibers and R / Γ / K comparison', `<pre class="crg-pre" tabindex="0" `
      + `aria-label="Canonical retention geometry">${esc(JSON.stringify({
        retained_fibers: evaluation.retained_fibers || [],
        geometry_preview: evaluation.geometry_preview || {},
      }, null, 2))}</pre>`, { principle: 'why' }),
  ]), { tone: refused ? 'warn' : 'neutral', principle: 'claim-scope' });
}

function commitmentInspection(state) {
  const artifact = latestCommitment(state);
  if (!artifact) {
    return notYet(
      'No safe-commitment comparison is open. Preview a comparison without changing the case, '
      + 'or compare and persist an independently verified artifact.',
    );
  }
  const family = artifact.family || {};
  const registry = artifact.registry || {};
  const verification = commitmentVerification(state);
  return panel('Safe commitment across future decisions', join([
    `<p class="crg-prose crg-prose--lead">Every policy below was evaluated against the same `
      + `represented realization family, evidence, numeric policy, and future-decision family. `
      + `A refusal is preserved as a result and authorizes no reduction.</p>`,
    definitionList([
      ['Artifact', hashChip(artifact.artifact_hash || artifact.artifact_id)],
      ['Profile', `<code class="crg-code">${esc(artifact.profile || '')}</code>`],
      ['Future-decision family', `<code class="crg-code">${esc(family.family_id || '')}</code> `
        + `${hashChip(family.family_hash)}`],
      ['Scenario scope held fixed', `<pre class="crg-pre" tabindex="0">`
        + `${esc(JSON.stringify(family.scenario_scope || {}, null, 2))}</pre>`],
      ['Represented family', `<code class="crg-code">${esc(registry.bundle_id || '')}</code> `
        + `${hashChip(registry.bundle_hash)}`],
      ['Completeness basis', `<pre class="crg-pre" tabindex="0">`
        + `${esc(JSON.stringify(registry.completeness || {}, null, 2))}</pre>`],
      ['Independent reconstruction', verification
        ? join([
          verificationChip(verification.status),
          `<span> Attempted ${esc(verification.level_attempted || 'V3')}; achieved `
            + `${esc(verification.level_achieved || 'V3')}.</span>`,
        ])
        : '<span>The stored artifact remains inspectable. Run preview or compare in this session '
          + 'to show the live independent-verifier result.</span>'],
    ]),
    futureDecisionTable(artifact),
    ...(artifact.evaluations || []).map((evaluation) => policyEvaluation(evaluation)),
    disclosure('Complete canonical safe-commitment artifact', `<pre class="crg-pre" tabindex="0" `
      + `role="group" aria-label="Canonical safe-commitment artifact">`
      + `${esc(JSON.stringify(artifact, null, 2))}</pre>`, { principle: 'why' }),
  ]), { id: 'safe-commitment', principle: 'verified-or-replay' });
}

function commitmentControls(state) {
  const form = state.form || {};
  const advancedValue = form['commitment-request'] || DEFAULT_COMMITMENT_REQUEST;
  const policy = (index, defaults = {}) => `<fieldset class="crg-fieldset">`
    + `<legend class="crg-field__label">Retention policy ${index}</legend>`
    + field(`commitment-policy-${index}-id`, 'Policy identity', {
      value: formValue(form, `commitment-policy-${index}-id`, defaults.id || ''),
      required: index < 3,
    })
    + select(`commitment-policy-${index}-type`, 'Registered policy', [
      ['', 'Do not include this policy'],
      ['retain-all', 'Retain all candidates'],
      ['universal-monotone', 'Universal monotone retention'],
      ['retain-all-signatures', 'Retain all distinct signatures'],
      ['retain-all-winners', 'Retain all possible winners'],
    ], { value: formValue(form, `commitment-policy-${index}-type`, defaults.type || '') })
    + field(`commitment-policy-${index}-protected-ids`, 'Protected candidate identities (optional)', {
      multiline: true, rows: 3,
      value: formValue(form, `commitment-policy-${index}-protected-ids`, ''),
      hint: 'One canonical candidate identity per line.',
    })
    + `</fieldset>`;
  return panel('Compare what may be safely retained', join([
    `<p class="crg-prose">Name the future-decision family compiled from this case and compare `
      + `registered retention policies under identical represented geometry, evidence, numeric `
      + `policy, and decision scope. Unsupported policies fail closed and preserve the family.</p>`,
    field('commitment-family-id', 'Future-decision family identity', {
      value: formValue(form, 'commitment-family-id', 'future-decisions'), required: true,
      hint: 'The ordinary path uses the case’s compiled decision query. It never accepts a caller-supplied derivation.',
    }),
    field('commitment-artifact-id', 'Saved artifact identity (optional)', {
      value: formValue(form, 'commitment-artifact-id', ''),
      hint: 'Leave empty for a deterministic generated identity.',
    }),
    policy(1, { id: 'retain-all', type: 'retain-all' }),
    policy(2, { id: 'universal-monotone', type: 'universal-monotone' }),
    policy(3),
    `<div class="crg-actions">`
      + action('preview-commitment', 'Preview without changing the case', {
        operation: 'previewCommitment', fields: COMMITMENT_GUIDED_FIELDS, tone: 'secondary',
      })
      + action('compare-commitment', 'Verify and save comparison', {
        operation: 'compareCommitment', fields: COMMITMENT_GUIDED_FIELDS,
      })
      + `</div>`,
    `<p class="crg-prose"><strong>Preview is non-mutating.</strong> Save occurs only after `
      + `the independent verifier reconstructs the artifact. A producer/verifier disagreement `
      + `is a blocked outcome, never a stored commitment.</p>`,
    disclosure('Advanced mode — canonical request JSON', join([
      `<p class="crg-prose">Use this only for custom future-decision query families, policy `
        + `parameters, or automation. It invokes the same closed public boundary.</p>`,
      field('commitment-request', 'Safe-commitment request JSON', {
        multiline: true, rows: 12, value: advancedValue,
      }),
      `<div class="crg-actions">`
        + action('preview-commitment-json', 'Preview advanced request', {
          operation: 'previewCommitment', fields: ['commitment-request'], tone: 'secondary',
        })
        + action('compare-commitment-json', 'Verify and save advanced request', {
          operation: 'compareCommitment', fields: ['commitment-request'], tone: 'secondary',
        })
        + `</div>`,
    ]), { open: false }),
  ]), { id: 'commitment-authoring', principle: 'verified-or-replay' });
}

function latestComparativeEvaluation(state) {
  const actionResult = ((state.lastAction || {}).result) || {};
  const outputs = actionResult.outputs || {};
  if (outputs.evaluation) return outputs.evaluation;
  if (actionResult.evaluation) return actionResult.evaluation;
  const stored = ((((state.data || {}).case || {}).comparative_evaluations) || {});
  const records = Object.values(stored).filter((record) => record && typeof record === 'object');
  records.sort((left, right) => String(left.evaluation_id || '').localeCompare(
    String(right.evaluation_id || ''),
  ));
  return records.length ? records[records.length - 1] : null;
}

function comparativeVerification(state) {
  const actionResult = ((state.lastAction || {}).result) || {};
  return (actionResult.outputs || {}).verification || actionResult.verification || null;
}

function exactText(value) {
  if (value && typeof value === 'object' && Object.keys(value).length === 1
      && Object.prototype.hasOwnProperty.call(value, 'exact')) return String(value.exact);
  return value === undefined || value === null ? '—' : String(value);
}

function comparativeFactsTable(record) {
  const methods = {};
  (record.methods || []).forEach((method) => { methods[method.method_id] = method; });
  return table('Per-method scoped facts (identity order; no ranking)', [
    { label: 'Method' },
    { label: 'Retention burden', hint: 'Retained memberships / declared denominator.' },
    { label: 'Oracle misses', hint: 'Miss count / declared workload cases.' },
    { label: 'Exact regret', hint: 'Total, maximum, and mean against the declared finite oracle.' },
    { label: 'Work affected / preserved / invalidated' },
    { label: 'Verified attempts' },
  ], (record.results || []).map((result) => {
    const facts = result.system_derived_facts || {};
    const retention = facts.retention_burden || {};
    const misses = facts.oracle_misses || {};
    const regret = facts.regret || {};
    const verification = facts.verification || {};
    const method = methods[result.method_id] || {};
    return { cells: [
      join([
        `<code class="crg-code">${esc(result.method_id || '')}</code>`,
        method.name ? `<span class="crg-prose">${esc(method.name)}</span>` : '',
      ]),
      `${esc(exactText(retention.retained_memberships))} / ${esc(exactText(retention.fraction))}`,
      `${esc(exactText(misses.count))} / ${esc(exactText(misses.fraction))}`,
      `${esc(exactText(regret.total))} / ${esc(exactText(regret.maximum))} / `
        + `${esc(exactText(regret.mean))}`,
      `${esc(exactText((facts.affected_work || {}).count))} / `
        + `${esc(exactText((facts.preserved_work || {}).count))} / `
        + `${esc(exactText((facts.invalidated_work || {}).count))}`,
      `${esc(exactText(verification.verified_count))} / `
        + `${esc(exactText(verification.fraction))}`,
    ] };
  }));
}

function comparativeInspection(state) {
  const record = latestComparativeEvaluation(state);
  if (!record) {
    return notYet(
      'No comparative workflow evaluation is open. Preview the editable finite/exact '
      + 'template, generate a verified record, or paste a portable record for verification.',
    );
  }
  const verification = comparativeVerification(state);
  const comparability = record.comparability || {};
  return panel('Portable comparative workflow evidence', join([
    `<p class="crg-prose crg-prose--lead"><strong>Non-authorizing evidence.</strong> `
      + `This record describes each workflow over the declared workload. It does not rank `
      + `methods, authorize a CRG state, infer economic value, establish causation, or `
      + `generalize beyond its bound inputs and denominators.</p>`,
    definitionList([
      ['Evaluation', `<code class="crg-code">${esc(record.evaluation_id || '')}</code>`],
      ['Record hash', hashChip(record.record_hash)],
      ['Authority / semantic effect', `<strong>${esc(record.authority || 'NON_AUTHORIZING')}`
        + ` / ${esc(record.semantic_effect || 'NONE')}</strong>`],
      ['Design comparability only', `<code class="crg-code">${esc(comparability.status || '')}`
        + `</code>${(comparability.reasons || []).length ? `: ${esc(comparability.reasons.join(', '))}` : ''}`],
      ['Conclusion boundary', `<code class="crg-code">${esc(comparability.conclusion || '')}</code>`],
      ['Independent reconstruction', verification
        ? verificationChip(verification.status)
        : '<span>Open or verify the stored record to show a live verifier result.</span>'],
      ['Claim boundary', `<p class="crg-prose">${esc(record.claim_boundary || '')}</p>`],
    ]),
    comparativeFactsTable(record),
    panel('Limitations and separately labelled observations', join([
      `<ul class="crg-list">${(record.limitations || []).map((item) => `<li>${esc(item)}</li>`).join('')}</ul>`,
      `<p class="crg-prose">Local observations: ${esc((record.local_observations || []).length)}. `
        + `Declared counterfactuals: ${esc((record.declared_counterfactuals || []).length)}. `
        + `Neither category is promoted into system-derived facts.</p>`,
    ]), { tone: 'neutral', principle: 'evidence-classes' }),
    disclosure('Complete canonical comparative evaluation', `<pre class="crg-pre" tabindex="0" `
      + `role="group" aria-label="Canonical comparative workflow evaluation">`
      + `${esc(JSON.stringify(record, null, 2))}</pre>`, { principle: 'why' }),
  ]), { id: 'comparative-evaluation', principle: 'claim-scope' });
}

function comparisonCandidateControls(form, suffix, defaults) {
  const label = suffix.toUpperCase();
  return `<fieldset class="crg-fieldset"><legend class="crg-field__label">Candidate ${label}</legend>`
    + field(`comparison-candidate-${suffix}-id`, 'Candidate identity', {
      value: formValue(form, `comparison-candidate-${suffix}-id`, defaults.id), required: true,
    })
    + field(`comparison-candidate-${suffix}-value`, 'Exact coordinate value', {
      value: formValue(form, `comparison-candidate-${suffix}-value`, defaults.value), required: true,
      hint: 'Enter a canonical exact rational such as 2, 7/3, or -1/4.',
    })
    + select(`comparison-candidate-${suffix}-legality`, 'Legality', [
      ['LEGAL', 'Legal'], ['INFEASIBLE', 'Infeasible'], ['UNKNOWN', 'Unknown'],
    ], { value: formValue(form, `comparison-candidate-${suffix}-legality`, 'LEGAL') })
    + select(`comparison-candidate-${suffix}-evidence-class`, 'Evidence class', [
      ['IMPORTED', 'Imported'], ['MEASURED', 'Measured'], ['MODELED', 'Modeled'],
      ['DECLARED', 'Declared'], ['EXACT', 'Exact'], ['BOUNDED', 'Bounded'],
    ], { value: formValue(form, `comparison-candidate-${suffix}-evidence-class`, 'IMPORTED') })
    + `</fieldset>`;
}

function comparisonMethodControls(form, suffix, defaults) {
  return `<fieldset class="crg-fieldset"><legend class="crg-field__label">${esc(defaults.legend)}</legend>`
    + field(`comparison-method-${suffix}-id`, 'Method identity', {
      value: formValue(form, `comparison-method-${suffix}-id`, defaults.id), required: true,
    })
    + field(`comparison-method-${suffix}-name`, 'Method name', {
      value: formValue(form, `comparison-method-${suffix}-name`, defaults.name), required: true,
    })
    + field(`comparison-method-${suffix}-version`, 'Method version', {
      value: formValue(form, `comparison-method-${suffix}-version`, '1'), required: true,
    })
    + field(`comparison-method-${suffix}-workflow`, 'Workflow declaration', {
      value: formValue(form, `comparison-method-${suffix}-workflow`, defaults.workflow),
      required: true,
    })
    + field(`comparison-method-${suffix}-selected`, 'Selected candidate identities', {
      multiline: true, rows: 2,
      value: formValue(form, `comparison-method-${suffix}-selected`, defaults.selected),
      hint: 'One identity per line; identity order is not a ranking.', required: true,
    })
    + field(`comparison-method-${suffix}-retained`, 'Retained candidate identities', {
      multiline: true, rows: 2,
      value: formValue(form, `comparison-method-${suffix}-retained`, defaults.retained),
      hint: 'One identity per line.', required: true,
    })
    + field(`comparison-method-${suffix}-achieved`, 'Exact achieved value', {
      value: formValue(form, `comparison-method-${suffix}-achieved`, defaults.achieved),
      required: true,
    })
    + field(`comparison-method-${suffix}-affected`, 'Affected work identities', {
      multiline: true, rows: 2,
      value: formValue(form, `comparison-method-${suffix}-affected`, 'decision\nevidence'),
    })
    + field(`comparison-method-${suffix}-preserved`, 'Preserved work identities', {
      multiline: true, rows: 2,
      value: formValue(form, `comparison-method-${suffix}-preserved`, defaults.preserved),
    })
    + field(`comparison-method-${suffix}-invalidated`, 'Invalidated work identities', {
      multiline: true, rows: 2,
      value: formValue(form, `comparison-method-${suffix}-invalidated`, defaults.invalidated),
    })
    + select(`comparison-method-${suffix}-verifier-status`, 'Trace verification status', [
      ['VERIFIED_RELATIVE', 'Verified relative to declared inputs'],
      ['UNVERIFIED', 'Unverified'], ['FAILED', 'Failed'],
    ], { value: formValue(form, `comparison-method-${suffix}-verifier-status`, 'VERIFIED_RELATIVE') })
    + `</fieldset>`;
}

function comparativeControls(state) {
  const record = latestComparativeEvaluation(state);
  const form = state.form || {};
  const requestValue = form['comparison-request'] || DEFAULT_COMPARISON_REQUEST;
  const evaluationId = form['comparison-evaluation-id']
    || (record && record.evaluation_id) || '';
  const portable = form['comparison-record']
    || (record ? JSON.stringify(record, null, 2) : '');
  return panel('Evaluate workflows under one declared design', join([
    `<p class="crg-prose">The guided profile records a finite one-coordinate, two-candidate `
      + `workload, its exact oracle answer, two named workflows, identical declared budgets, `
      + `and their raw observations. No field asks for a ranking or an economic conclusion.</p>`,
    disclosure('1. Evaluation scope and represented family', join([
      field('comparison-evaluation-id-guided', 'Evaluation identity', {
        value: formValue(form, 'comparison-evaluation-id-guided', 'workflow-evaluation-1'),
        required: true,
      }),
      field('comparison-family-id', 'Represented family identity', {
        value: formValue(form, 'comparison-family-id', 'declared-workflow-family'), required: true,
      }),
      field('comparison-coordinate-id', 'Coordinate identity', {
        value: formValue(form, 'comparison-coordinate-id', 'burden'), required: true,
      }),
      field('comparison-coordinate-quantity', 'Coordinate quantity', {
        value: formValue(form, 'comparison-coordinate-quantity', 'burden'), required: true,
      }),
      field('comparison-coordinate-unit', 'Coordinate unit', {
        value: formValue(form, 'comparison-coordinate-unit', 'declared-unit'), required: true,
      }),
      select('comparison-coordinate-direction', 'Preferred direction', [
        ['MINIMIZE', 'Minimize'], ['MAXIMIZE', 'Maximize'],
      ], { value: formValue(form, 'comparison-coordinate-direction', 'MINIMIZE') }),
      field('comparison-declared-universe', 'Declared finite universe', {
        value: formValue(form, 'comparison-declared-universe',
          'the explicitly supplied workflow-evaluation family'), required: true,
      }),
      comparisonCandidateControls(form, 'a', { id: 'A', value: '1' }),
      comparisonCandidateControls(form, 'b', { id: 'B', value: '2' }),
      field('comparison-decision-id', 'Decision scope identity', {
        value: formValue(form, 'comparison-decision-id', 'declared-workflow-decision'), required: true,
      }),
      select('comparison-observation-level', 'Observation level', [
        ['ADDITIVE_PRICE', 'Additive price'], ['PARTIAL_ORDER', 'Partial order'],
      ], { value: formValue(form, 'comparison-observation-level', 'ADDITIVE_PRICE') }),
      field('comparison-objective-weight', 'Exact coordinate weight', {
        value: formValue(form, 'comparison-objective-weight', '1'), required: true,
      }),
      field('comparison-change-id', 'Compared change identity', {
        value: formValue(form, 'comparison-change-id', 'declared-unchanged-input'), required: true,
      }),
      field('comparison-changed-fields', 'Changed fields, one per line', {
        multiline: true, rows: 2, value: formValue(form, 'comparison-changed-fields', ''),
      }),
      field('comparison-technology-scope', 'Exact technology scope', {
        value: formValue(form, 'comparison-technology-scope',
          'replace with the exact evaluated technology scope'), required: true,
      }),
      field('comparison-evidence-classes', 'Included evidence classes', {
        multiline: true, rows: 2,
        value: formValue(form, 'comparison-evidence-classes', 'IMPORTED'),
        hint: 'One evidence class per line.', required: true,
      }),
    ]), { open: true }),
    disclosure('2. Workload, exact oracle, and common budget', join([
      field('comparison-case-id', 'Workload case identity', {
        value: formValue(form, 'comparison-case-id', 'case-1'), required: true,
      }),
      field('comparison-eligible-ids', 'Eligible candidate identities', {
        multiline: true, rows: 2, value: formValue(form, 'comparison-eligible-ids', 'A\nB'),
        hint: 'One identity per line.', required: true,
      }),
      field('comparison-work-item-ids', 'Tracked work-item identities', {
        multiline: true, rows: 2,
        value: formValue(form, 'comparison-work-item-ids', 'decision\nevidence'), required: true,
      }),
      select('comparison-held-out-kind', 'Held-out treatment', [
        ['NONE', 'No held-out cases'], ['DECLARED', 'Declared held-out treatment'],
      ], { value: formValue(form, 'comparison-held-out-kind', 'NONE') }),
      field('comparison-held-out-reason', 'Held-out treatment reason', {
        value: formValue(form, 'comparison-held-out-reason',
          'single declared illustrative workload'), required: true,
      }),
      field('comparison-oracle-id', 'Oracle identity', {
        value: formValue(form, 'comparison-oracle-id', 'declared-finite-oracle'), required: true,
      }),
      field('comparison-oracle-name', 'Oracle name', {
        value: formValue(form, 'comparison-oracle-name', 'Declared finite exact minimum'), required: true,
      }),
      field('comparison-oracle-version', 'Oracle version', {
        value: formValue(form, 'comparison-oracle-version', '1'), required: true,
      }),
      field('comparison-oracle-winners', 'Oracle winner identities', {
        multiline: true, rows: 2,
        value: formValue(form, 'comparison-oracle-winners', 'A'),
        hint: 'One identity per line; identities are not ranked.', required: true,
      }),
      field('comparison-oracle-optimum', 'Exact oracle optimum', {
        value: formValue(form, 'comparison-oracle-optimum', '1'), required: true,
      }),
      field('comparison-budget-metric', 'Common budget metric', {
        value: formValue(form, 'comparison-budget-metric', 'retained_items_per_case'), required: true,
      }),
      field('comparison-budget-unit', 'Common budget unit', {
        value: formValue(form, 'comparison-budget-unit', 'items'), required: true,
      }),
      field('comparison-budget-limit', 'Common exact budget limit', {
        value: formValue(form, 'comparison-budget-limit', '2'), required: true,
      }),
    ]), { open: true }),
    disclosure('3. Observed method traces', join([
      comparisonMethodControls(form, 'a', {
        legend: 'CRG workflow observation', id: 'crg', name: 'CRG workflow',
        workflow: 'declared-crg-workflow', selected: 'A', retained: 'A\nB',
        achieved: '1', preserved: 'decision\nevidence', invalidated: '',
      }),
      comparisonMethodControls(form, 'b', {
        legend: 'Reference workflow observation', id: 'reference',
        name: 'Declared reference workflow', workflow: 'declared-reference-workflow',
        selected: 'B', retained: 'B', achieved: '2', preserved: 'evidence',
        invalidated: 'decision',
      }),
      field('comparison-limitations', 'Evaluation limitations', {
        multiline: true, rows: 4,
        value: formValue(form, 'comparison-limitations',
          'Finite declared workload only\nNo method ranking, economic interpretation, causal claim, or generalization'),
        hint: 'One limitation per line.', required: true,
      }),
      disclosure('Optional non-authorizing local observation', join([
        `<p class="crg-prose">Complete every field to attach one separately classified `
          + `operator observation. It is never promoted into system-derived comparison facts.</p>`,
        field('comparison-observation-id', 'Observation identity', {
          value: formValue(form, 'comparison-observation-id', ''),
        }),
        field('comparison-observation-method-id', 'Observed method identity', {
          value: formValue(form, 'comparison-observation-method-id', ''),
          hint: 'Must name one of the two method identities above.',
        }),
        field('comparison-observer', 'Observer', {
          value: formValue(form, 'comparison-observer', ''),
        }),
        field('comparison-observation-metric', 'Observed metric', {
          value: formValue(form, 'comparison-observation-metric', ''),
        }),
        field('comparison-observation-value', 'Exact observed value', {
          value: formValue(form, 'comparison-observation-value', ''),
        }),
        field('comparison-observation-unit', 'Observation unit', {
          value: formValue(form, 'comparison-observation-unit', ''),
        }),
        field('comparison-observation-context', 'Observation context note', {
          value: formValue(form, 'comparison-observation-context', ''),
        }),
      ]), { open: false }),
      disclosure('Optional user-declared counterfactual', join([
        `<p class="crg-prose">This is sealed as a user declaration, not measured or `
          + `system-derived evidence.</p>`,
        field('comparison-counterfactual-id', 'Counterfactual identity', {
          value: formValue(form, 'comparison-counterfactual-id', ''),
        }),
        field('comparison-counterfactual-statement', 'Counterfactual statement', {
          value: formValue(form, 'comparison-counterfactual-statement', ''),
        }),
        field('comparison-counterfactual-provenance', 'Declaration provenance', {
          value: formValue(form, 'comparison-counterfactual-provenance', ''),
        }),
      ]), { open: false }),
    ]), { open: true }),
    `<div class="crg-actions">`
      + action('preview-comparative-evaluation', 'Preview verified evidence', {
        operation: 'previewComparativeEvaluation', fields: COMPARISON_GUIDED_FIELDS, tone: 'secondary',
      })
      + action('generate-comparative-evaluation', 'Verify and save evidence', {
        operation: 'generateComparativeEvaluation', fields: COMPARISON_GUIDED_FIELDS,
      })
      + `</div>`,
    `<p class="crg-prose"><strong>Preview does not change the case.</strong> Save publishes `
      + `the canonical record and exact verifier input only after independent reconstruction. `
      + `A verifier disagreement publishes nothing.</p>`,
    field('comparison-evaluation-id', 'Stored evaluation identity', {
      value: evaluationId,
      hint: 'Inspect re-runs the independent verifier over the case-stored canonical record.',
    }),
    action('inspect-comparative-evaluation', 'Inspect and reverify stored evidence', {
      operation: 'getComparativeEvaluation', fields: ['comparison-evaluation-id'], tone: 'secondary',
    }),
    disclosure('Advanced mode — canonical request and portable-record JSON', join([
      field('comparison-request', 'Comparative evaluation request JSON', {
        multiline: true, rows: 18, value: requestValue,
        hint: 'Use for larger families, more coordinates, more workload cases, or automation.',
      }),
      `<div class="crg-actions">`
        + action('preview-comparative-evaluation-json', 'Preview advanced request', {
          operation: 'previewComparativeEvaluation', fields: ['comparison-request'], tone: 'secondary',
        })
        + action('generate-comparative-evaluation-json', 'Verify and save advanced request', {
          operation: 'generateComparativeEvaluation', fields: ['comparison-request'], tone: 'secondary',
        })
        + `</div>`,
      field('comparison-record', 'Portable evaluation to verify (canonical JSON)', {
        multiline: true, rows: 10, value: portable,
        hint: 'Verification consumes only this self-contained record; it does not trust Studio, the producer, or case state.',
      }),
      action('verify-comparative-evaluation', 'Verify portable evidence', {
        operation: 'verifyComparativeEvaluation', fields: ['comparison-record'], tone: 'secondary',
      }),
    ]), { open: false }),
  ]), { id: 'comparative-authoring', principle: 'verified-or-replay' });
}

export const workspace = {
  ...meta,
  render(state = {}) {
    const certificate = state.certificate || (state.data || {}).certificate || null;
    const commitment = join([
      commitmentControls(state),
      commitmentInspection(state),
      comparativeControls(state),
      comparativeInspection(state),
    ]);
    const controls = panel('Issue or re-open a decision', join([
      field('retained', 'Realizations to retain, one per line', {
        multiline: true,
        value: (state.form && state.form.retained) || '',
        hint: 'Leave empty to certify over the whole represented family. Retention must '
          + 'preserve the decision-relevant geometry or the certificate is refused (29.2).',
      }),
      `<div class="crg-actions">`
      + action('certify', 'Issue a decision certificate', { operation: 'certifyCase' })
      + action('refresh-certificates', 'Reload certificates', {
        operation: 'listCertificates', tone: 'secondary',
      })
      + `</div>`,
      `<p class="crg-prose">Certification is a long-running action: it returns a job `
      + `identifier and the result arrives when the job finishes (38.3).</p>`,
    ]));
    if (!certificate) {
      return shell(meta, join([
        commitment,
        controls,
        certificateChooser(state),
        notYet('No certificate is open. Issue one, or choose an existing certificate above.'),
      ]), state);
    }
    return shell(meta, join([
      commitment,
      controls,
      certificateChooser(state),
      `<h3 class="crg-section-title">Certificate report</h3>`,
      `<p class="crg-prose">This is the canonical report of specification 50.2, in the `
      + `mandatory order. Every conforming renderer presents the same items in the same `
      + `sequence, so a reader who has seen one has seen them all.</p>`,
      certificateReport(certificate, state),
      disclosure('Certificate as stored', `<pre class="crg-pre" tabindex="0" role="group" `
        + `aria-label="Canonical certificate record">`
        + `${esc(JSON.stringify(certificate, null, 2))}</pre>`, { principle: 'why' }),
    ]), state);
  },
  certificateReport,
};

export default workspace;
