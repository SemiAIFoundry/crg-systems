/**
 * Change Impact (spec 41.1): before-and-after differences, typed edges,
 * preserved claims, and required action.
 *
 * The useful question after a change is not "what broke" but "what survived
 * and why", so the preserved list is rendered first and with reasons.  30
 * makes recomputation proportional to the affected dependency subgraph;
 * showing which certificates were untouched, and which typed edge carried
 * the change to the ones that were, is what makes that claim inspectable
 * rather than merely fast.
 */

import {
  absent, definitionList, disclosure, emptyState, esc, hashChip, join, outcomeInfo, panel,
  quantity, table, verificationChip,
} from '../render.js';
import { action, field, notYet, select, shell } from '../workspace.js';

const meta = {
  id: 'change-impact',
  title: 'Change Impact',
  purpose: 'Certified before-and-after deltas, typed edges, comparative evidence, '
    + 'Decision Challenge, and required action.',
  endpoints: [
    'previewChange', 'classifyChange', 'verifyCertifiedDelta', 'recomputeCase',
    'getCase', 'getDependencies', 'getJobResult',
    'previewDecisionChallenge', 'recordDecisionChallenge',
    'getDecisionChallenge', 'verifyDecisionChallenge',
    'previewComparativeChange', 'generateComparativeChange',
    'getComparativeChange', 'verifyComparativeChange',
  ],
};

const CHALLENGE_MUTATIONS = [
  'OBJECTIVE', 'PRICE', 'TECHNOLOGY_COORDINATE', 'EVIDENCE_VALUE',
  'EVIDENCE_VALIDITY', 'CAPABILITY', 'LEGALITY', 'POLICY_TOLERANCE',
  'RETENTION_POLICY', 'PHYSICAL_CONSTRAINT',
];

const CHALLENGE_PREVIEWS = [
  'BRANCH_PREVIEW', 'PHASE_PREVIEW', 'CHANGE_PREVIEW', 'COMMITMENT_PREVIEW',
  'VERIFIER_REPLAY', 'PHASE_AND_CHANGE_PREVIEW',
];

const CHALLENGE_FIELDS = [
  'challenge-id', 'challenge-evidence-id', 'challenge-operation-id',
  'challenge-mutation-type', 'challenge-preview-operation', 'challenge-target-path',
  'challenge-objective-key', 'challenge-objective-value',
  'challenge-price-value', 'challenge-price-unit',
  'challenge-technology-coordinate-id', 'challenge-technology-value',
  'challenge-technology-unit', 'challenge-evidence-value-evidence-id',
  'challenge-evidence-value-value', 'challenge-evidence-value-class',
  'challenge-evidence-validity-evidence-id', 'challenge-evidence-validity-status',
  'challenge-capability-id', 'challenge-capability-value',
  'challenge-legality-realization-id', 'challenge-legality-status',
  'challenge-tolerance-value', 'challenge-retention-policy-id',
  'challenge-retention-policy-value', 'challenge-constraint-id',
  'challenge-constraint-value', 'challenge-constraint-unit',
  'challenge-promotion-request-id', 'challenge-promotion-operation',
  'challenge-promotion-requested-by', 'challenge-promotion-reason',
];

function challengeInputGroup(type, body, active = 'PRICE') {
  return `<fieldset class="crg-fieldset" data-challenge-input="${esc(type)}"`
    + `${type === active ? '' : ' hidden'}><legend class="crg-field__label">`
    + `${esc(type.replaceAll('_', ' '))} input</legend>${body}</fieldset>`;
}

function challengeRecordFromState(state) {
  const last = state.lastAction || {};
  if (![
    'previewDecisionChallenge', 'recordDecisionChallenge',
    'getDecisionChallenge', 'verifyDecisionChallenge',
  ].includes(last.operation)) return null;
  const response = last.result || {};
  const result = response.outputs || response;
  if (!result.challenge || result.challenge.record_type !== 'DecisionChallengeRecord') return null;
  return { record: result.challenge, verification: result.verification || {} };
}

function idList(values, empty = 'none') {
  return (values || []).length
    ? values.map((value) => `<code class="crg-code">${esc(String(value))}</code>`).join(' ')
    : absent(empty.toUpperCase().replaceAll(' ', '_'));
}

function decisionChallengeResult(state) {
  const entry = challengeRecordFromState(state);
  if (!entry) return emptyState(
    'No Decision Challenge is displayed. Preview, record, or inspect one to replay it here.',
  );
  const record = entry.record;
  const verification = entry.verification;
  const result = record.result || {};
  const noMutation = record.no_mutation_guarantee || {};
  const refusal = record.refusal;
  const promotion = record.promotion_request;
  const phase = result.phase || {};
  const change = result.change || {};
  const minimum = result.proposed_minimum_action || {};
  const regret = result.regret || {};
  const completeness = result.family_completeness || {};
  const reconstructedVerification = result.verification_status || {};
  const replacementRoots = change.replacement_roots || {};
  const common = definitionList([
    ['Challenge identity', `<code class="crg-code" data-decision-challenge-id>`
      + `${esc(record.challenge_id || '')}</code>`],
    ['Record hash', hashChip(record.record_hash)],
    ['Independent replay', verificationChip(verification.status || 'FAILED')],
    ['Authority', `<code class="crg-code" data-decision-challenge-authority>`
      + `${esc(record.authority || 'NON_AUTHORIZING')}</code>`],
    ['Authorizing', `<code class="crg-code">${esc(String(record.authorizing))}</code>`],
    ['Semantic effect', `<code class="crg-code" data-decision-challenge-effect>`
      + `${esc(record.semantic_effect || 'NONE')}</code>`],
    ['Frozen baseline root', hashChip((record.baseline || {}).case_root)],
    ['Active case mutated', `<code class="crg-code" data-decision-challenge-mutated>`
      + `${esc(String(noMutation.active_case_mutated))}</code>`],
    ['Active case superseded', `<code class="crg-code">`
      + `${esc(String(noMutation.active_case_superseded))}</code>`],
    ['Promotion executed', `<code class="crg-code">`
      + `${esc(String(noMutation.promotion_executed))}</code>`],
    ['Mutation performed', `<code class="crg-code">`
      + `${esc(String(noMutation.mutation_performed))}</code>`],
  ]);
  const outcome = refusal ? panel('Typed refusal — no preview was inferred', join([
    definitionList([
      ['Status', `<code class="crg-code">${esc(refusal.status || '')}</code>`],
      ['Reason', `<code class="crg-code">${esc(refusal.reason_code || '')}</code>`],
      ['Detail', `<span class="crg-prose">${esc(refusal.detail || '')}</span>`],
      ['Disposition', `<code class="crg-code">${esc(refusal.disposition || '')}</code>`],
      ['Winner identities', absent('NOT_INFERRED')],
    ]),
  ]), { tone: 'warn', principle: 'why' }) : panel(
    'Independently reconstructed preview — identities are not ranked',
    join([
      definitionList([
        ['Winner identity set (not ranked)', idList(result.winner_ids, 'none stated')],
        ['Phase state', `<code class="crg-code">${esc(phase.state || '')}</code>`],
        ['Nearest phase boundaries', idList(phase.nearest_boundary_ids, 'not applicable')],
        ['Phase evidence replay', `<code class="crg-code">`
          + `${esc(reconstructedVerification.phase || '')}</code>`],
        ['Certified change replay', `<code class="crg-code">`
          + `${esc(reconstructedVerification.delta || '')}</code>`],
        ['Preserved claims', idList(change.preserved_ids, 'none')],
        ['Invalidated claims', idList(change.invalidated_ids, 'none')],
        ['Replacement roots', Object.keys(replacementRoots).length
          ? Object.entries(replacementRoots).sort(([left], [right]) => left.localeCompare(right))
            .map(([identifier, root]) => `${esc(identifier)} ${hashChip(root)}`).join('<br>')
          : absent('NOT_APPLICABLE')],
        ['Proposed minimum action', `<strong data-decision-challenge-minimum>`
          + `${esc(minimum.action || '')}</strong>`],
        ['Why this is minimum', `<span class="crg-prose">${esc(minimum.basis || '')}</span>`],
        ['Regret status', `<code class="crg-code">${esc(regret.status || '')}</code>`],
        ['Regret witnesses', regret.witnesses && regret.witnesses.length
          ? `<code class="crg-code">${esc(JSON.stringify(regret.witnesses))}</code>`
          : absent('NOT_PRESENT_IN_PROFILE')],
        ['Claim scope', `<code class="crg-code">${esc(JSON.stringify(result.claim_scope))}</code>`],
        ['Completeness basis', `<code class="crg-code">`
          + `${esc(String(completeness.basis_type || ''))}</code>`],
        ['Declared universe', esc(String(completeness.declared_universe || ''))],
      ]),
      `<p class="crg-prose"><strong>No score or ranking exists:</strong> this surface lists `
        + `canonical identities and direct verifier states only.</p>`,
    ]), { principle: 'why' },
  );
  const promotionPanel = promotion ? panel(
    'Separate governed promotion proposal — not executed',
    definitionList([
      ['Request', `<code class="crg-code">${esc(promotion.request_id || '')}</code>`],
      ['Governed operation', `<code class="crg-code">`
        + `${esc(promotion.governed_operation || '')}</code>`],
      ['Status', `<code class="crg-code" data-decision-challenge-promotion-status>`
        + `${esc(promotion.status || '')}</code>`],
      ['Execution', `<code class="crg-code">${esc(promotion.execution_status || '')}</code>`],
      ['Authority', `<code class="crg-code">${esc(promotion.authority || '')}</code>`],
    ]), { tone: 'warn', principle: 'why' },
  ) : '';
  return join([
    panel('Decision Challenge replay', common, {
      tone: verification.ok ? 'neutral' : 'warn', principle: 'why',
    }),
    outcome,
    promotionPanel,
    disclosure('Canonical portable record (display only)', `<pre class="crg-pre" tabindex="0" `
      + `role="group" aria-label="Canonical Decision Challenge record">`
      + `${esc(JSON.stringify(record, null, 2))}</pre>`, { principle: 'why' }),
  ]);
}

function decisionChallengePanel(state) {
  const form = state.form || {};
  const caseRecord = (state.data || {}).case || {};
  const deltas = caseRecord.certified_deltas || {};
  const evidenceIds = Object.keys(deltas).sort();
  const targetPaths = Array.from(new Set(evidenceIds.flatMap((evidenceId) => (
    (deltas[evidenceId].changed_fields || []).map((item) => item.path).filter(Boolean)
  )))).sort();
  const active = form['challenge-mutation-type'] || 'PRICE';
  const evidenceChoices = evidenceIds.length
    ? evidenceIds.map((value) => [value, value]) : [['', 'No stored certified delta']];
  const targetChoices = targetPaths.length
    ? targetPaths.map((value) => [value, value]) : [['', 'No certified field path']];
  return panel('Decision Challenge — frozen, non-authorizing, and non-mutating', join([
    `<p class="crg-prose">Challenge one registered input against stored certified phase/change `
      + `evidence. The system derives protocol profiles and every displayed outcome, then `
      + `independently replays the portable record. Recording writes only the auxiliary `
      + `challenge ledger: the active case head and version remain unchanged.</p>`,
    decisionChallengeResult(state),
    field('challenge-id', 'Challenge identity', {
      value: form['challenge-id'] || 'challenge-1', required: true,
    }),
    select('challenge-evidence-id', 'Stored certified change evidence', evidenceChoices, {
      value: form['challenge-evidence-id'] || evidenceIds[0] || '',
      hint: 'The server reconstructs phase and delta verifier inputs from this stored evidence.',
    }),
    field('challenge-operation-id', 'Input operation identity', {
      value: form['challenge-operation-id'] || 'challenge-input-1', required: true,
    }),
    select('challenge-mutation-type', 'Registered input type',
      CHALLENGE_MUTATIONS.map((value) => [value, value.replaceAll('_', ' ')]), {
        value: active,
        hint: 'Only the fields for this closed registered input type are sent.',
      }),
    select('challenge-preview-operation', 'Registered preview operation',
      CHALLENGE_PREVIEWS.map((value) => [value, value.replaceAll('_', ' ')]), {
        value: form['challenge-preview-operation'] || 'PHASE_AND_CHANGE_PREVIEW',
      }),
    select('challenge-target-path', 'Certified field path', targetChoices, {
      value: form['challenge-target-path'] || targetPaths[0] || '',
      hint: 'The input must exactly cover this canonical before/after field difference.',
    }),
    challengeInputGroup('OBJECTIVE', join([
      field('challenge-objective-key', 'Objective field', {
        value: form['challenge-objective-key'] || 'type',
      }),
      field('challenge-objective-value', 'Objective field value', {
        value: form['challenge-objective-value'] || 'weighted_sum',
      }),
    ]), active),
    challengeInputGroup('PRICE', join([
      field('challenge-price-value', 'Exact price value', {
        value: form['challenge-price-value'] || '',
        hint: 'Use an integer or reduced rational string such as 3/4; never a decimal float.',
      }),
      field('challenge-price-unit', 'Price unit', { value: form['challenge-price-unit'] || '' }),
    ]), active),
    challengeInputGroup('TECHNOLOGY_COORDINATE', join([
      field('challenge-technology-coordinate-id', 'Coordinate identity', {
        value: form['challenge-technology-coordinate-id'] || '',
      }),
      field('challenge-technology-value', 'Exact coordinate value', {
        value: form['challenge-technology-value'] || '',
      }),
      field('challenge-technology-unit', 'Coordinate unit', {
        value: form['challenge-technology-unit'] || '',
      }),
    ]), active),
    challengeInputGroup('EVIDENCE_VALUE', join([
      field('challenge-evidence-value-evidence-id', 'Evidence identity', {
        value: form['challenge-evidence-value-evidence-id'] || '',
      }),
      field('challenge-evidence-value-value', 'Evidence value', {
        value: form['challenge-evidence-value-value'] || '',
      }),
      field('challenge-evidence-value-class', 'Evidence class', {
        value: form['challenge-evidence-value-class'] || '',
      }),
    ]), active),
    challengeInputGroup('EVIDENCE_VALIDITY', join([
      field('challenge-evidence-validity-evidence-id', 'Evidence identity', {
        value: form['challenge-evidence-validity-evidence-id'] || '',
      }),
      select('challenge-evidence-validity-status', 'Validity', [
        ['VALID', 'Valid'], ['INVALID', 'Invalid'], ['EXPIRED', 'Expired'], ['REVOKED', 'Revoked'],
      ], { value: form['challenge-evidence-validity-status'] || 'VALID' }),
    ]), active),
    challengeInputGroup('CAPABILITY', join([
      field('challenge-capability-id', 'Capability identity', {
        value: form['challenge-capability-id'] || '',
      }),
      field('challenge-capability-value', 'Capability value', {
        value: form['challenge-capability-value'] || '',
      }),
    ]), active),
    challengeInputGroup('LEGALITY', join([
      field('challenge-legality-realization-id', 'Realization identity', {
        value: form['challenge-legality-realization-id'] || '',
      }),
      select('challenge-legality-status', 'Legality', [
        ['LEGAL', 'Legal'], ['ILLEGAL', 'Illegal'],
      ], { value: form['challenge-legality-status'] || 'LEGAL' }),
    ]), active),
    challengeInputGroup('POLICY_TOLERANCE', field(
      'challenge-tolerance-value', 'Exact policy tolerance', {
        value: form['challenge-tolerance-value'] || '0',
      },
    ), active),
    challengeInputGroup('RETENTION_POLICY', join([
      field('challenge-retention-policy-id', 'Retention policy identity', {
        value: form['challenge-retention-policy-id'] || '',
      }),
      field('challenge-retention-policy-value', 'Retention policy value', {
        value: form['challenge-retention-policy-value'] || '',
      }),
    ]), active),
    challengeInputGroup('PHYSICAL_CONSTRAINT', join([
      field('challenge-constraint-id', 'Constraint identity', {
        value: form['challenge-constraint-id'] || '',
      }),
      field('challenge-constraint-value', 'Exact constraint value', {
        value: form['challenge-constraint-value'] || '',
      }),
      field('challenge-constraint-unit', 'Constraint unit', {
        value: form['challenge-constraint-unit'] || '',
      }),
    ]), active),
    disclosure('Optional separate governed promotion proposal', join([
      `<p class="crg-prose"><strong>PROPOSED / NOT_EXECUTED.</strong> Filling these fields `
        + `only records a request for a later ordinary governed action. This panel cannot `
        + `apply, promote, authorize, or supersede anything.</p>`,
      field('challenge-promotion-request-id', 'Promotion request identity', {
        value: form['challenge-promotion-request-id'] || '',
      }),
      select('challenge-promotion-operation', 'Governed operation', [
        ['', 'No promotion proposal'],
        ['APPLY_CERTIFIED_CHANGE', 'Apply certified change'],
        ['CREATE_GOVERNED_BRANCH', 'Create governed branch'],
        ['SUBMIT_CHANGE_FOR_APPROVAL', 'Submit change for approval'],
      ], { value: form['challenge-promotion-operation'] || '' }),
      field('challenge-promotion-requested-by', 'Requested by', {
        value: form['challenge-promotion-requested-by'] || '',
      }),
      field('challenge-promotion-reason', 'Promotion proposal reason', {
        value: form['challenge-promotion-reason'] || '',
      }),
    ]), { principle: 'why' }),
    `<div class="crg-actions">${action(
      'preview-decision-challenge', 'Preview non-mutating challenge', {
        operation: 'previewDecisionChallenge', fields: CHALLENGE_FIELDS,
      },
    )}${action('record-decision-challenge', 'Record in auxiliary challenge ledger', {
      operation: 'recordDecisionChallenge', fields: CHALLENGE_FIELDS,
    })}${action('inspect-decision-challenge', 'Inspect stored challenge', {
      operation: 'getDecisionChallenge', tone: 'secondary', fields: ['challenge-id'],
    })}${action('verify-decision-challenge', 'Verify displayed record', {
      operation: 'verifyDecisionChallenge', tone: 'secondary',
      disabled: !challengeRecordFromState(state),
    })}</div>`,
  ]), { principle: 'why' });
}

const CLASSIFICATIONS = {
  NO_EFFECT: ['No effect on any claim', 'good',
    'The change touched nothing a certificate depends on.'],
  METADATA_ONLY: ['Metadata only', 'good',
    'Nothing semantic changed, so no certificate is disturbed (16.3).'],
  BOUND_PRESERVING: ['Within the existing bounds', 'good',
    'The change stays inside a bound the certificate already accounted for.'],
  RECOMPUTE_REQUIRED: ['Recomputation required', 'caution',
    'Affected certificates must be recomputed before they may be relied on again.'],
  CLAIM_INVALIDATING: ['Claims invalidated', 'blocked',
    'One or more certificates no longer hold and must be reissued.'],
  REOPEN_REQUIRED: ['Decision must be reopened', 'blocked',
    'A reopen condition recorded on the certificate has been met.'],
};

function classificationPanel(plan) {
  const key = String(plan.classification || '');
  const [label, tone, description] = CLASSIFICATIONS[key]
    || [key || 'Not classified', 'caution', '30 requires every change to be typed before it is applied.'];
  return panel('What this change did to the existing claims', join([
    `<p class="crg-classification crg-classification--${esc(tone)}" `
    + `data-classification="${esc(key)}">`
    + `<strong>${esc(label)}</strong> <span class="crg-visually-hidden">(${esc(key)})</span></p>`,
    `<p class="crg-prose">${esc(description)}</p>`,
  ]), { tone, principle: 'why' });
}

function preservedPanel(plan) {
  const preserved = plan.preserved || [];
  const invalidated = plan.invalidated || [];
  return panel('Claims preserved and claims lost', join([
    `<h4 class="crg-subtitle">Preserved</h4>`,
    preserved.length
      ? `<ul class="crg-list">${preserved.map((id) => `<li>${hashChip(id)} `
        + `<span class="crg-prose">nothing this certificate depends on changed</span></li>`).join('')}</ul>`
      : '<p class="crg-prose">No certificate survived this change unaffected.</p>',
    `<h4 class="crg-subtitle">Invalidated</h4>`,
    invalidated.length
      ? `<ul class="crg-list">${invalidated.map((id) => `<li>${hashChip(id)} `
        + `${verificationChip('FAILED')}</li>`).join('')}</ul>`
      : '<p class="crg-prose">No certificate was invalidated.</p>',
  ]), { tone: invalidated.length ? 'warn' : 'neutral' });
}

function affectedTable(plan) {
  const affected = plan.affected || {};
  const keys = Object.keys(affected).sort();
  if (!keys.length) {
    return emptyState('No object was reached by this change.');
  }
  return table('Objects the change reached, and the edge that carried it', [
    { label: 'Object' },
    { label: 'Typed edge', hint: '18.3 names the edge types; the type is what makes the reach explicit.' },
  ], keys.map((key) => ({
    cells: [hashChip(key), `<code class="crg-code">${esc(affected[key])}</code>`],
  })));
}

function beforeAfter(plan) {
  const diff = plan.diff || plan.differences || [];
  if (!diff.length) {
    return panel('Before and after', emptyState('No field-level differences are recorded.'));
  }
  return table('Field-level differences', [
    { label: 'What changed' },
    { label: 'Before' },
    { label: 'After' },
    { label: 'Unit' },
  ], diff.map((entry) => ({
    cells: [
      entry.path ? `<code class="crg-code">${esc(entry.path)}</code>` : absent(),
      entry.before === undefined ? absent('UNSUPPORTED')
        : quantity(entry.before, { unit: entry.unit || '' }),
      entry.after === undefined ? absent('UNSUPPORTED')
        : quantity(entry.after, { unit: entry.unit || '' }),
      entry.unit ? esc(entry.unit) : absent('NOT_APPLICABLE'),
    ],
  })));
}

function actionsPanel(plan) {
  const actions = plan.required_actions || [];
  return panel('What you must do now', join([
    actions.length
      ? `<ol class="crg-list crg-list--ordered">${actions
        .map((a) => `<li>${esc(a)}</li>`).join('')}</ol>`
      : '<p class="crg-prose">Nothing is required. The change was absorbed without '
        + 'disturbing a claim.</p>',
    `<div class="crg-actions">`
    + action('recompute', 'Recompute the affected certificates', { operation: 'recomputeCase' })
    + action('dependencies', 'Show the dependency graph', {
      operation: 'getDependencies', tone: 'secondary',
    })
    + `</div>`,
  ]), { tone: actions.length ? 'warn' : 'neutral' });
}

function outcomeShift(plan) {
  const before = plan.previous_outcome;
  const after = plan.current_outcome;
  if (!before && !after) return '';
  return panel('Did the answer change?', definitionList([
    ['Before', before ? esc(outcomeInfo(before).headline) : absent()],
    ['After', after ? esc(outcomeInfo(after).headline) : absent()],
    ['Reading this', `<p class="crg-prose">A change from a strict winner to a possible `
      + `winner set is not a regression in the software; it is the system declining to `
      + `keep a claim the evidence no longer supports (22.5).</p>`],
  ]), { principle: 'tie-vs-ambiguity' });
}

function changeForm(state) {
  return panel('Propose a change', join([
    field('change-set', 'Assignments', {
      multiline: true, rows: 6,
      value: (state.form && state.form.set) || '',
      hint: 'Each line names a realization, a coordinate, and the new value.',
    }),
    field('change-reason', 'Declared reason', {
      value: (state.form && state.form.reason) || '',
      hint: '30 requires a declared reason. It becomes part of the change record and is '
        + 'what a later reviewer reads.',
      required: true,
    }),
    field('change-authority', 'Authority', {
      value: (state.form && state.form.authority) || '',
      hint: 'Who is authorising this. 44.7 requires every mutation to be attributable.',
      required: true,
    }),
    `<div class="crg-actions">${action('preview-change', 'Preview certified impact', {
      operation: 'previewChange', fields: ['change-set', 'change-reason', 'change-authority'],
    })}${action('classify-change', 'Verify and apply this change', {
      operation: 'classifyChange', fields: ['change-set', 'change-reason', 'change-authority'],
    })}</div>`,
    `<p class="crg-prose">Preview computes the same before/after evidence without mutating `
      + `the case. Apply persists only after the independent verifier reconstructs the minimum `
      + `valid action.</p>`,
  ]));
}

function latestCertifiedDelta(state) {
  const outputs = ((((state.lastAction || {}).result || {}).outputs) || {});
  if (outputs.certified_delta) {
    return { record: outputs.certified_delta, verification: outputs.verification || null,
      preview: outputs.preview === true };
  }
  const records = (((state.data || {}).case || {}).certified_deltas || {});
  const values = Object.values(records).filter((record) => record
    && record.record_type === 'CertifiedDeltaRecord');
  values.sort((left, right) => String(left.evidence_id || '').localeCompare(
    String(right.evidence_id || ''),
  ));
  return values.length ? { record: values[values.length - 1], verification: null, preview: false }
    : null;
}

function valueText(value) {
  if (value === undefined) return absent('UNSUPPORTED');
  if (value === null) return '<code class="crg-code">null</code>';
  if (typeof value === 'object') {
    return `<code class="crg-code">${esc(JSON.stringify(value))}</code>`;
  }
  return `<code class="crg-code">${esc(String(value))}</code>`;
}

function certifiedDeltaPanel(entry) {
  if (!entry) {
    return panel('Certified before-and-after evidence', emptyState(
      'No CertifiedDeltaRecord is stored or previewed. A legacy change classification alone is not independent change evidence.',
    ));
  }
  const record = entry.record || {};
  const delta = record.delta || {};
  const minimum = record.minimum_recomputation_claim || {};
  const fields = record.changed_fields || [];
  const edges = record.traversed_edges || [];
  const replacements = record.replacement_roots || {};
  const phase = record.phase_evidence || {};
  return panel(entry.preview ? 'Certified change preview — no mutation' : 'Certified change evidence', join([
    definitionList([
      ['Evidence identity', hashChip(record.evidence_id)],
      ['Prior case root', hashChip(delta.prior_root)],
      ['Current case root', hashChip(delta.current_root)],
      ['Independent verification', verificationChip(
        (entry.verification || {}).status || record.verification_status || 'FAILED',
      )],
      ['Minimum valid action', `<strong data-minimum-action="${esc(minimum.action || '')}">`
        + `${esc(minimum.action || '')}</strong>`],
      ['Why that action is minimum', `<span class="crg-prose">${esc(minimum.basis || '')}</span>`],
    ]),
    table('Canonical before-and-after field differences', [
      { label: 'Path' }, { label: 'Category' }, { label: 'Change' },
      { label: 'Before' }, { label: 'After' },
    ], fields.map((item) => ({ cells: [
      `<code class="crg-code">${esc(item.path || '')}</code>`,
      `<code class="crg-code">${esc(item.category || '')}</code>`,
      esc(item.change || ''), valueText(item.prior), valueText(item.current),
    ] }))),
    edges.length ? table('Typed dependency edges actually traversed', [
      { label: 'From' }, { label: 'Edge type' }, { label: 'To' },
      { label: 'Minimum action carried' },
    ], edges.map((edge) => ({ cells: [
      hashChip(edge.source), `<code class="crg-code">${esc(edge.edge_type || '')}</code>`,
      hashChip(edge.target), `<strong>${esc(edge.minimum_action || '')}</strong>`,
    ] }))) : emptyState('No typed dependency edge was traversed.'),
    panel('Preserved, invalidated, and replacement evidence', definitionList([
      ['Preserved claims', (delta.preserved || []).length
        ? (delta.preserved || []).map((value) => hashChip(value)).join(' ') : absent()],
      ['Invalidated claims', (delta.invalidated || []).length
        ? (delta.invalidated || []).map((value) => hashChip(value)).join(' ') : absent()],
      ['Replacement roots', Object.keys(replacements).length
        ? Object.entries(replacements).map(([identifier, root]) => `${esc(identifier)} ${hashChip(root)}`).join('<br>')
        : absent('NOT_APPLICABLE')],
      ['Prior certified phase root', phase.prior_phase_root
        ? hashChip(phase.prior_phase_root) : absent('NOT_APPLICABLE')],
      ['Current certified phase root', phase.current_phase_root
        ? hashChip(phase.current_phase_root) : absent('NOT_APPLICABLE')],
    ]), { principle: 'why' }),
    disclosure('Complete canonical CertifiedDeltaRecord', `<pre class="crg-pre" tabindex="0" `
      + `role="group" aria-label="Canonical certified-delta record">`
      + `${esc(JSON.stringify(record, null, 2))}</pre>`, { principle: 'why' }),
  ]), { tone: entry.preview ? 'neutral' : 'warn', principle: 'why' });
}

const CHANGE_COMPARISON_FIELDS = [
  'change-comparison-id', 'change-comparison-delta-id', 'change-comparison-case-id',
  'change-comparison-scope-id', 'change-comparison-decision-description',
  'change-comparison-evidence-classes', 'change-comparison-field-observation',
  'change-comparison-limitations',
];

function exactCount(value) {
  return value && typeof value === 'object' && Object.keys(value).length === 1
    ? String(value.exact || '0') : 'not stated';
}

function comparisonResultFromState(state) {
  const last = state.lastAction || {};
  const allowed = [
    'previewComparativeChange', 'generateComparativeChange',
    'getComparativeChange', 'verifyComparativeChange',
  ];
  if (!allowed.includes(last.operation)) return null;
  const response = last.result || {};
  const result = response.outputs || response;
  const record = result.comparative_change;
  if (!record || record.record_type !== 'ComparativeChangeEvidence') return null;
  return { record, result, verification: result.verification || {} };
}

function storedChoices(inventory, emptyLabel) {
  const entries = Object.keys(inventory || {}).sort().map((identity) => [identity, identity]);
  return entries.length ? entries : [['', emptyLabel]];
}

function comparativeChangeResult(state) {
  const entry = comparisonResultFromState(state);
  if (!entry) return emptyState(
    'No comparative change record is displayed. Preview, generate, or inspect one first.',
  );
  const record = entry.record;
  const facts = record.system_derived_facts || {};
  const work = (name) => facts[name] || {};
  return panel('Displayed v1.2 comparative change evidence', join([
    definitionList([
      ['Comparison identity', `<code class="crg-code" data-comparative-change-id>`
        + `${esc(record.comparison_id || '')}</code>`],
      ['Independent replay', verificationChip(entry.verification.status || 'FAILED')],
      ['Authority', `<code class="crg-code" data-comparative-change-authority>`
        + `${esc(record.authority || '')}</code>`],
      ['Authorizing', `<code class="crg-code">${esc(String(record.authorizing))}</code>`],
      ['Semantic effect', `<code class="crg-code" data-comparative-change-effect>`
        + `${esc(record.semantic_effect || '')}</code>`],
      ['Decision state mutated', `<code class="crg-code">`
        + `${esc(String(entry.result.decision_state_mutation_performed === true))}</code>`],
      ['Successor case recorded', `<code class="crg-code">`
        + `${esc(String(entry.result.successor_case_recorded === true))}</code>`],
      ['Minimum action', `<strong data-comparative-change-minimum>`
        + `${esc(facts.minimum_action || '')}</strong>`],
    ]),
    table('Exact certified artifact identities', [
      { label: 'State' }, { label: 'Exact count' }, { label: 'Members' },
    ], [
      ['Preserved', work('preserved_work')],
      ['Invalidated', work('invalidated_work')],
      ['Recomputed', work('recomputed_work')],
    ].map(([label, item]) => ({ cells: [
      esc(label), `<code class="crg-code">${esc(exactCount(item.count))}</code>`,
      idList(item.members, 'none'),
    ] }))),
    `<p class="crg-prose"><strong>No strengthened claim:</strong> artifact counts are not `
      + `time, effort, avoided work, cost, savings, ROI, superiority, or a method ranking.</p>`,
    disclosure('Canonical comparative change record (display only)',
      `<pre class="crg-pre" tabindex="0">${esc(JSON.stringify(record, null, 2))}</pre>`,
      { principle: 'why' }),
  ]), { tone: entry.verification.ok ? 'neutral' : 'warn', principle: 'why' });
}

function comparativeChangeAuthoring(state, caseRecord, form) {
  const deltas = caseRecord.certified_deltas || {};
  const stored = caseRecord.comparative_change_evidence || {};
  const deltaIds = Object.keys(deltas).sort();
  const storedIds = Object.keys(stored).sort();
  const displayed = comparisonResultFromState(state);
  const example = {
    comparison_id: 'comparative-change-1', certified_delta_id: deltaIds[0] || 'stored-delta-id',
    decision_scope: { case_id: caseRecord.case_id || state.caseId, scope_id: 'decision-scope-1' },
    evidence_scope: { classes: ['MODELED'], field_observation: false },
    limitations: ['Finite declared case and dependency graph only'],
  };
  return `<section data-comparison-guided="comparative-change">${join([
    `<h4 class="crg-subtitle">v1.2 — certified change comparison</h4>`,
    `<p class="crg-prose">Choose a stored certified delta. Studio sends only its identity and `
      + `your declared scope; the server resolves exact source bytes, independently replays them, `
      + `derives work identities, and independently verifies the result.</p>`,
    comparativeChangeResult(state),
    field('change-comparison-id', 'Comparison identity', {
      value: form['change-comparison-id'] || 'comparative-change-1', required: true,
    }),
    select('change-comparison-delta-id', 'Stored CertifiedDeltaRecord',
      storedChoices(deltas, 'No certified delta stored yet'), {
        value: form['change-comparison-delta-id'] || deltaIds[0] || '',
        hint: 'Record bytes, replay inputs, verifier answers, hashes, and counts are never authored here.',
      }),
    field('change-comparison-case-id', 'Case identity', {
      value: form['change-comparison-case-id'] || caseRecord.case_id || state.caseId || '',
      required: true,
    }),
    field('change-comparison-scope-id', 'Decision scope identity', {
      value: form['change-comparison-scope-id'] || 'decision-scope-1', required: true,
    }),
    field('change-comparison-decision-description', 'Decision scope description', {
      value: form['change-comparison-decision-description'] || 'Declared finite decision scope',
      required: true,
    }),
    field('change-comparison-evidence-classes', 'Evidence classes', {
      multiline: true, rows: 3,
      value: form['change-comparison-evidence-classes'] || 'MODELED', required: true,
      hint: 'One declared class per line.',
    }),
    select('change-comparison-field-observation', 'Contains field observation', [
      ['false', 'No'], ['true', 'Yes'],
    ], { value: form['change-comparison-field-observation'] || 'false' }),
    field('change-comparison-limitations', 'Limitations', {
      multiline: true, rows: 3,
      value: form['change-comparison-limitations']
        || 'Artifact identity counts are not effort or economic quantities\nFinite declared case and dependency graph only',
      required: true, hint: 'One explicit limitation per line.',
    }),
    `<div class="crg-actions">${action('preview-comparative-change',
      'Preview without recording a successor case', {
        operation: 'previewComparativeChange', fields: CHANGE_COMPARISON_FIELDS,
        disabled: !deltaIds.length,
      })}${action('generate-comparative-change', 'Verify and record in successor case', {
      operation: 'generateComparativeChange', fields: CHANGE_COMPARISON_FIELDS,
      disabled: !deltaIds.length,
    })}</div>`,
    select('change-comparison-inspect-id', 'Stored comparison to inspect',
      storedChoices(stored, 'No comparative change stored yet'), {
        value: form['change-comparison-inspect-id'] || storedIds[0] || '',
      }),
    `<div class="crg-actions">${action('inspect-comparative-change', 'Inspect stored comparison', {
      operation: 'getComparativeChange', tone: 'secondary',
      fields: ['change-comparison-inspect-id'], disabled: !storedIds.length,
    })}${action('verify-comparative-change', 'Verify displayed comparison', {
      operation: 'verifyComparativeChange', tone: 'secondary', disabled: !displayed,
    })}</div>`,
    disclosure('Advanced mode — closed request or portable record JSON', join([
      field('change-comparison-request', 'Closed comparative change request JSON', {
        multiline: true, rows: 10,
        value: form['change-comparison-request'] || JSON.stringify(example, null, 2),
      }),
      `<div class="crg-actions">${action('preview-comparative-change-json',
        'Preview advanced request', { operation: 'previewComparativeChange', tone: 'secondary',
          fields: ['change-comparison-request'] })}${action('generate-comparative-change-json',
        'Record advanced request', { operation: 'generateComparativeChange', tone: 'secondary',
          fields: ['change-comparison-request'] })}</div>`,
      field('change-comparison-record', 'Portable ComparativeChangeEvidence JSON', {
        multiline: true, rows: 10, value: form['change-comparison-record'] || '',
      }),
      `<div class="crg-actions">${action('verify-comparative-change-json',
        'Verify advanced portable record', { operation: 'verifyComparativeChange', tone: 'secondary',
          fields: ['change-comparison-record'] })}</div>`,
    ]), { open: false, principle: 'why' }),
  ])}</section>`;
}

function journeyComparisonPanel(state) {
  const form = state.form || {};
  const caseRecord = (state.data || {}).case || {};
  return panel('v1.2 comparative change evidence — stored identities, independent replay', join([
    `<p class="crg-prose"><strong>Evidence, not authority.</strong> These product records expose `
      + `direct change facts while remaining alongside compilers, `
      + `optimization systems, EDA tools, simulators, laboratories, databases, and existing `
      + `engineering workflows. Authority is NON_AUTHORIZING and semantic effect is NONE.</p>`,
    comparativeChangeAuthoring(state, caseRecord, form),
  ]), { principle: 'why' });
}

export const workspace = {
  ...meta,
  render(state = {}) {
    const plan = (state.data || {}).impact || (state.data || {}).plan || state.plan || null;
    const certified = latestCertifiedDelta(state);
    if (!plan) {
      return shell(meta, join([
        changeForm(state),
        certifiedDeltaPanel(certified),
        journeyComparisonPanel(state),
        decisionChallengePanel(state),
        notYet('No change has been classified against this case yet.'),
      ]), state);
    }
    return shell(meta, join([
      changeForm(state),
      certifiedDeltaPanel(certified),
      journeyComparisonPanel(state),
      decisionChallengePanel(state),
      classificationPanel(plan),
      outcomeShift(plan),
      preservedPanel(plan),
      affectedTable(plan),
      beforeAfter(plan),
      actionsPanel(plan),
      disclosure('Change plan as stored', `<pre class="crg-pre" tabindex="0" role="group" `
        + `aria-label="Change impact plan">${esc(JSON.stringify(plan, null, 2))}</pre>`,
      { principle: 'why' }),
    ]), state);
  },
};

export default workspace;
