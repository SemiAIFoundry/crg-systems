"""End-to-end verification of a portable ``.crg`` bundle (spec 39, 25).

A bundle is a directory or a zip archive with the layout of 39.  This module
opens it with nothing but ``zipfile`` and ``json``, recomputes every
inventory hash from the bytes actually stored, and hands each carried
CRG-VIR program to :func:`crg_verify.verify_vir`.  It never asks the bundle
what its own contents hash to.
"""
from __future__ import annotations

import hashlib
import json
import os
import zipfile
from typing import Any, Callable, Dict, List, Mapping, Optional, Tuple

from .canonical import CanonicalError, content_hash, decode, is_hash
from .certificate import (
    VERIFIER_VERSION,
    Level,
    Status,
    VerificationResult,
    verify_certificate,
)
from .federation import verify_federation
from .vir import verify_vir
from .extensions import ProofCheckerRegistry

__all__ = [
    "verify_bundle", "open_bundle", "MANIFEST_REQUIRED", "MANIFEST_DISCLOSURE",
    "LEVEL_REQUIREMENTS",
]

# Section 25.2 is cumulative in this implementation profile: achieving Vn
# means every lower level passed.  Keeping the requirement names public makes
# the profile auditable by another verifier rather than an implicit control
# flow convention.
LEVEL_REQUIREMENTS = {
    Level.V0: ("integrity", "manifest", "signatures", "object_presence"),
    Level.V1: ("schema", "units", "versions", "dependency_closure",
               "migration_validity", "graph_acyclicity"),
    Level.V2: ("objective_evaluation", "comparisons", "ties", "winner_sets",
               "retained_geometry", "claim_scope"),
    Level.V3: ("solver_proofs", "bound_certificates", "regret_witnesses",
               "geometry_equivalence", "completeness_arguments"),
    Level.V4: ("attestation", "nonce", "context", "authorization", "validity",
               "revocation", "release_policy"),
}

MANIFEST_NAME = "manifest.json"
#: Specification 39.1.  All seventeen fields are mandatory, including for a
#: partial bundle.  Section 39.4 permits omissions from the *payload*, not
#: omissions from the manifest that discloses their consequences.  Earlier
#: versions accepted five fields and warned about the rest; that made a
#: manifest pointing at a nonexistent case pass V0.
MANIFEST_REQUIRED = (
    ("bundle_format_version",),
    ("crg_spec_version",),
    ("root_case_object",),
    ("object_inventory",),
    ("artifact_inventory",),
    ("proof_inventory",),
    ("content_hashes",),
    ("external_references",), ("schemas", "schema_identities"),
    ("quantity_registry_version",), ("rule_table_version",), ("signatures",),
    ("encryption",), ("redaction_state",), ("export_authority",),
    ("creation_tool",), ("requested_verification_level",),
)
# Kept as an exported compatibility symbol.  There are no optional 39.1
# disclosures: a producer uses an empty list/object when a category is empty.
MANIFEST_DISCLOSURE: Tuple[Tuple[str, ...], ...] = ()

_REQUIRED_MEMBERS = (
    MANIFEST_NAME,
    "case.json",
    "schemas/referenced-schema-manifest.json",
    "audit/events.jsonl",
    "README.md",
)
_CONTENT_PREFIXES = ("objects/sha256/", "artifacts/sha256/", "proofs/sha256/")

_MIGRATION_CLASSES = {
    "SEMANTICALLY_EQUIVALENT", "SEMANTICALLY_WIDENING",
    "SEMANTICALLY_NARROWING", "SEMANTIC_CHANGE", "LOSSY", "UNVERIFIED",
}
_MIGRATION_PROOF_TYPE = "CRG_MIGRATION_CLASSIFICATION_PROOF_V1"
_MIGRATION_PROOF_VERIFIER = "crg-model:migration-classification-v1"
_MIGRATION_IDENTITY_ALGORITHM = "CANONICAL_IDENTITY_V1"
_MIGRATION_IDENTITY_CHECKS = (
    "SOURCE_VERSION_EQUALS_TARGET_VERSION",
    "ALGORITHM_IS_CANONICAL_IDENTITY_V1",
    "CANONICAL_INPUT_HASH_EQUALS_OUTPUT_HASH",
)
_SUPPORTED_MIGRATION_TRANSFORMS = {
    "crg-schema-0.2.0-identity-v1": (
        "sha256:94a7eb8116798e598d15d60c31585c0c04793e68e6c42672072716d7630a94ea"
    ),
}
_SUPPORTED_MIGRATION_REGISTRY_VERSION = (
    "sha256:34646ece1dfa72122f8809994d34f4667eff91661b5c01c256b79519b81797df"
)


def _migration_evidence_failures(migration: Mapping[str, Any]) -> List[str]:
    """Verify migration classification without importing the producing kernel.

    Version 0.2.0 intentionally recognizes only the canonical identity
    algorithm.  A later transform remains unsupported until this independent
    verifier learns its algorithm and classification rule as well.
    """
    migration_id = migration.get("migration_id")
    prefix = f"migration {migration_id!r}"
    failures: List[str] = []
    required = (
        "migration_id", "source_schema_version", "target_schema_version",
        "migration_class", "source_object_hash", "target_object_hash",
        "transform_id", "transform_descriptor", "transform_hash",
        "migration_registry_descriptor", "migration_registry_version",
        "classification_proof",
        "classification_proof_hash", "classification_verified",
        "transform_input_hash", "transform_output_hash", "actor", "authority",
    )
    missing = [name for name in required if migration.get(name) in (None, "")]
    if missing:
        failures.append(f"{prefix} omits {missing}")
    if migration.get("migration_class") not in _MIGRATION_CLASSES:
        failures.append(f"{prefix} has unknown semantic class")
    for name in (
        "source_object_hash", "target_object_hash", "transform_hash",
        "migration_registry_version", "classification_proof_hash",
        "transform_input_hash", "transform_output_hash",
    ):
        if not is_hash(migration.get(name)):
            failures.append(f"{prefix} has invalid {name}")

    descriptor = migration.get("transform_descriptor")
    registry_descriptor = migration.get("migration_registry_descriptor")
    proof = migration.get("classification_proof")
    if (not isinstance(descriptor, dict) or not isinstance(registry_descriptor, dict)
            or not isinstance(proof, dict)):
        failures.append(
            f"{prefix} has no independently checkable registry/transform/proof objects"
        )
        return failures
    try:
        descriptor_hash = content_hash(descriptor)
        registry_hash = content_hash(registry_descriptor)
        proof_hash = content_hash(proof)
    except CanonicalError as error:
        failures.append(f"{prefix} has noncanonical classification evidence: {error}")
        return failures
    if migration.get("transform_hash") != descriptor_hash:
        failures.append(f"{prefix} transform descriptor hash does not match")
    supported_transform_hash = _SUPPORTED_MIGRATION_TRANSFORMS.get(
        str(descriptor.get("transform_id") or "")
    )
    if supported_transform_hash is None or descriptor_hash != supported_transform_hash:
        failures.append(f"{prefix} transform is not registered by this verifier release")
    if migration.get("migration_registry_version") != registry_hash:
        failures.append(f"{prefix} migration registry descriptor hash does not match")
    registered = registry_descriptor.get("transforms")
    if not isinstance(registered, list) or descriptor not in registered:
        failures.append(f"{prefix} transform is absent from its registry descriptor")
    if migration.get("migration_registry_version") != _SUPPORTED_MIGRATION_REGISTRY_VERSION:
        failures.append(f"{prefix} migration registry version is not supported")
    if migration.get("classification_proof_hash") != proof_hash:
        failures.append(f"{prefix} classification proof hash does not match")
    if migration.get("transform_id") != descriptor.get("transform_id"):
        failures.append(f"{prefix} record and descriptor name different transforms")
    if proof.get("proof_type") != _MIGRATION_PROOF_TYPE:
        failures.append(f"{prefix} uses an unsupported classification proof type")
    if proof.get("verifier_id") != _MIGRATION_PROOF_VERIFIER:
        failures.append(f"{prefix} uses an unsupported classification proof verifier")
    if proof.get("transform_id") != descriptor.get("transform_id"):
        failures.append(f"{prefix} proof names a different transform")
    if proof.get("transform_hash") != descriptor_hash:
        failures.append(f"{prefix} proof is not bound to its transform descriptor")
    if proof.get("migration_class") != descriptor.get("migration_class"):
        failures.append(f"{prefix} proof and descriptor disagree on semantic class")
    if migration.get("migration_class") != descriptor.get("migration_class"):
        failures.append(f"{prefix} record and descriptor disagree on semantic class")
    if proof.get("basis") != descriptor.get("classification_basis"):
        failures.append(f"{prefix} proof and descriptor disagree on classification basis")
    if descriptor.get("algorithm") != _MIGRATION_IDENTITY_ALGORITHM:
        failures.append(f"{prefix} uses an unsupported migration algorithm")
    if descriptor.get("transform_type") != "CRG_SCHEMA_MIGRATION_TRANSFORM_V1":
        failures.append(f"{prefix} uses an unsupported transform descriptor type")
    if descriptor.get("algorithm_version") != "1":
        failures.append(f"{prefix} uses an unsupported migration algorithm version")
    if descriptor.get("source_schema_version") != migration.get("source_schema_version"):
        failures.append(f"{prefix} descriptor disagrees on source schema version")
    if descriptor.get("target_schema_version") != migration.get("target_schema_version"):
        failures.append(f"{prefix} descriptor disagrees on target schema version")
    if descriptor.get("source_schema_version") != descriptor.get("target_schema_version"):
        failures.append(f"{prefix} identity transform changes schema version")
    if descriptor.get("migration_class") != "SEMANTICALLY_EQUIVALENT":
        failures.append(f"{prefix} identity transform is not classified equivalent")
    if tuple(proof.get("checks") or ()) != _MIGRATION_IDENTITY_CHECKS:
        failures.append(f"{prefix} identity proof has incomplete or reordered checks")
    if migration.get("transform_input_hash") != migration.get("transform_output_hash"):
        failures.append(f"{prefix} identity transform input/output hashes differ")
    if migration.get("source_object_hash") != migration.get("transform_input_hash"):
        failures.append(f"{prefix} transform is not bound to the stated source object")
    if migration.get("classification_verified") is not True:
        failures.append(f"{prefix} classification is not recorded as verified")
    return failures


def _inventory(manifest: dict) -> List[dict]:
    """Normalize the object inventory across both 39.1 spellings."""
    entries = manifest.get("object_inventory")
    if entries is None:
        entries = manifest.get("objects") or []
    out: List[dict] = []
    for item in entries:
        if not isinstance(item, dict):
            out.append({"id": None, "hash": None, "path": None, "raw": item})
            continue
        out.append({
            "id": item.get("object_id", item.get("id")),
            "hash": item.get("content_hash", item.get("hash")),
            "path": item.get("path"),
            "byte_length": item.get("byte_length"),
        })
    return out


def _root_case(manifest: dict) -> Any:
    root = manifest.get("root_case_object", manifest.get("root_case"))
    if isinstance(root, dict):
        return root.get("object_id") or root.get("id")
    return root


class _Reader:
    """Uniform read access to a directory or a zip archive."""

    def __init__(self, path: str) -> None:
        self.path = path
        self._zip: Optional[zipfile.ZipFile] = None
        if os.path.isdir(path):
            self.names = sorted(
                os.path.relpath(os.path.join(root, name), path).replace(os.sep, "/")
                for root, _dirs, files in os.walk(path) for name in files)
        elif zipfile.is_zipfile(path):
            self._zip = zipfile.ZipFile(path)
            self.names = sorted(n for n in self._zip.namelist() if not n.endswith("/"))
        else:
            raise FileNotFoundError(f"{path!r} is neither a directory nor a zip archive")

    def read(self, name: str) -> bytes:
        if self._zip is not None:
            return self._zip.read(name)
        with open(os.path.join(self.path, name), "rb") as handle:
            return handle.read()

    def json(self, name: str) -> Any:
        return decode(self.read(name).decode("utf-8"))

    def close(self) -> None:
        if self._zip is not None:
            self._zip.close()

    def manifest_hash(self) -> Tuple[Optional[str], str]:
        """Return the manifest digest anchored outside ``manifest.json``.

        Zip bundles use the deterministic container comment defined by the
        portable-artifact profile.  An expanded directory uses a
        ``manifest.sha256`` sidecar with the same JSON object.  The sidecar is
        deliberately outside the manifest hash preimage.
        """
        raw: Optional[bytes]
        if self._zip is not None:
            raw = self._zip.comment
            source = "zip archive comment"
        else:
            sidecar = "manifest.sha256"
            raw = self.read(sidecar) if sidecar in self.names else None
            source = sidecar
        if not raw:
            return None, f"{source} is absent"
        try:
            metadata = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            return None, f"{source} is not valid JSON: {error}"
        if not isinstance(metadata, dict) or not is_hash(metadata.get("manifest_hash")):
            return None, f"{source} does not contain an algorithm-tagged manifest_hash"
        return str(metadata["manifest_hash"]), source


def open_bundle(path: str) -> _Reader:
    return _Reader(path)


def verify_bundle(
    path: str, *, clock: Optional[str] = None, clock_source: str = "none-supplied",
    level: str = Level.V3, federation_context: Optional[dict] = None,
    signature_verifier: Optional[Callable[[bytes, Mapping[str, Any]], Tuple[bool, str]]] = None,
    extension_registry: Optional[ProofCheckerRegistry] = None,
) -> VerificationResult:
    """Verify a ``.crg`` bundle end to end (spec 25.2, 39)."""
    result = VerificationResult(ok=False)
    result.report.update({"bundle_identity": os.path.basename(path),
                          "verifier_identity": "crg-verify", "verifier_version": VERIFIER_VERSION,
                          "level_attempted": level})
    try:
        reader = _Reader(path)
    except (FileNotFoundError, OSError) as error:
        result.record("bundle_readable", False, str(error))
        result.status = Status.FAILED
        return result.finish()
    try:
        _verify_open(
            result, reader, clock, clock_source, level, federation_context,
            signature_verifier, extension_registry,
        )
    finally:
        reader.close()
    return result


def _fail(result: VerificationResult, name: str, detail: str) -> None:
    result.record(name, False, detail)
    result.status = Status.FAILED
    result.finish()


def _verify_open(result: VerificationResult, reader: _Reader, clock: Optional[str],
                 clock_source: str, level: str,
                 federation_context: Optional[dict],
                 signature_verifier: Optional[
                     Callable[[bytes, Mapping[str, Any]], Tuple[bool, str]]
                 ],
                 extension_registry: Optional[ProofCheckerRegistry]) -> None:
    if level not in Level.ORDER:
        return _fail(result, "verification_level_supported",
                     f"unknown verification level {level!r}; expected one of {Level.ORDER}")

    # -- V0: manifest ---------------------------------------------------
    if MANIFEST_NAME not in reader.names:
        return _fail(result, "manifest_present", f"no {MANIFEST_NAME} in the bundle")
    try:
        manifest_bytes = reader.read(MANIFEST_NAME)
        manifest = decode(manifest_bytes.decode("utf-8"))
    except (ValueError, CanonicalError) as error:
        return _fail(result, "manifest_present", f"manifest is not canonical JSON: {error}")
    if not isinstance(manifest, dict):
        return _fail(result, "manifest_present", "manifest.json is not a JSON object")
    result.record("manifest_present", True, f"{MANIFEST_NAME} decoded")

    canonical_manifest_hash = content_hash(manifest)
    raw_manifest_hash = "sha256:" + hashlib.sha256(manifest_bytes).hexdigest()
    result.record(
        "manifest_canonical",
        canonical_manifest_hash == raw_manifest_hash,
        "manifest bytes are the independent canonical encoding"
        if canonical_manifest_hash == raw_manifest_hash
        else ("manifest bytes are not canonical: raw bytes hash to "
              f"{raw_manifest_hash}, canonical content hashes to {canonical_manifest_hash}"),
    )
    anchored_hash, anchor_detail = reader.manifest_hash()
    result.record(
        "manifest_integrity",
        anchored_hash == raw_manifest_hash,
        f"{anchor_detail} binds manifest.json to {raw_manifest_hash}"
        if anchored_hash == raw_manifest_hash
        else f"{anchor_detail}; expected {raw_manifest_hash}, found {anchored_hash!r}",
    )

    missing_fields = [names[0] for names in MANIFEST_REQUIRED
                      if not any(n in manifest for n in names)]
    result.record("manifest_fields", not missing_fields,
                  f"manifest omits required fields {missing_fields} (39.1)" if missing_fields
                  else f"all {len(MANIFEST_REQUIRED)} core manifest fields present")
    result.report["bundle_identity"] = _root_case(manifest) or result.report["bundle_identity"]

    missing_members = [name for name in _REQUIRED_MEMBERS if name not in reader.names]
    result.record(
        "required_members_present",
        not missing_members,
        f"required members missing: {missing_members}" if missing_members
        else f"all {len(_REQUIRED_MEMBERS)} portable-profile members are present",
    )

    duplicate_names: List[str] = []
    if reader._zip is not None:
        seen = set()
        for name in reader._zip.namelist():
            if name in seen and name not in duplicate_names:
                duplicate_names.append(name)
            seen.add(name)
    result.record(
        "unique_member_names", not duplicate_names,
        f"duplicate archive members are forbidden: {duplicate_names}" if duplicate_names
        else "archive member names are unique",
    )

    unsafe_names = [name for name in reader.names if not _safe_member_name(name)]
    result.record(
        "safe_member_paths", not unsafe_names,
        f"unsafe absolute or traversing member paths: {unsafe_names}" if unsafe_names
        else "all member paths are relative and traversal-free",
    )

    # -- V0: every declared stored byte --------------------------------
    content_entries: Dict[str, str] = {}
    hashes = manifest.get("content_hashes")
    hashes_ok = isinstance(hashes, dict)
    if hashes_ok:
        hashes_ok = hashes.get("algorithm") == "sha256"
        raw_entries = hashes.get("entries")
        hashes_ok = hashes_ok and isinstance(raw_entries, dict)
        if isinstance(raw_entries, dict):
            content_entries = {str(k): str(v) for k, v in raw_entries.items()}
    result.record(
        "content_hash_manifest",
        hashes_ok,
        f"{len(content_entries)} sha256 content entries declared" if hashes_ok
        else "content_hashes must declare algorithm 'sha256' and a mapping of entries",
    )
    content_failures: List[str] = []
    for name, stated in sorted(content_entries.items()):
        if not _safe_member_name(name):
            content_failures.append(f"unsafe declared path {name!r}")
        elif name not in reader.names:
            content_failures.append(f"missing declared member {name}")
        elif not is_hash(stated):
            content_failures.append(f"{name}: invalid digest {stated!r}")
        else:
            actual = _bytes_hash(reader.read(name))
            if actual != stated:
                content_failures.append(f"{name}: manifest states {stated}, bytes hash to {actual}")
    result.record(
        "declared_content_integrity", hashes_ok and not content_failures,
        "; ".join(content_failures) if content_failures
        else f"all {len(content_entries)} declared member hashes match",
    )
    unbound_members = sorted(
        name for name in reader.names
        if name not in {MANIFEST_NAME, "README.md", "manifest.sha256"}
        and not name.startswith("signatures/")
        and name not in content_entries
    )
    result.record(
        "all_payload_members_hash_bound", not unbound_members,
        f"payload members absent from content_hashes: {unbound_members}" if unbound_members
        else "every payload member is bound by content_hashes",
    )

    # -- V0: root case --------------------------------------------------
    root = manifest.get("root_case_object")
    root_failures: List[str] = []
    root_payload: Optional[Any] = None
    if not isinstance(root, dict):
        root_failures.append("root_case_object is not an object")
    else:
        root_id = root.get("object_id")
        root_path = str(root.get("path") or "")
        root_hash = root.get("content_hash")
        if not root_id:
            root_failures.append("root_case_object.object_id is missing")
        if not root_path or not _safe_member_name(root_path):
            root_failures.append("root_case_object.path is missing or unsafe")
        elif root_path not in reader.names:
            root_failures.append(f"root case member is missing: {root_path}")
        else:
            root_bytes = reader.read(root_path)
            actual = _bytes_hash(root_bytes)
            if not is_hash(root_hash) or actual != root_hash:
                root_failures.append(
                    f"root case hash mismatch: manifest states {root_hash!r}, bytes hash to {actual}"
                )
            if content_entries.get(root_path) != root_hash:
                root_failures.append("root case is not bound consistently by content_hashes")
            try:
                root_payload = decode(root_bytes.decode("utf-8"))
            except (UnicodeDecodeError, ValueError, CanonicalError) as error:
                root_failures.append(f"root case is not canonical JSON: {error}")
            else:
                if content_hash(root_payload) != actual:
                    root_failures.append("root case member bytes are not canonical JSON")
                if isinstance(root_payload, dict) and root_payload.get("case_id") != root_id:
                    root_failures.append(
                        "root case object_id does not match case.json case_id"
                    )
    result.record(
        "root_case_integrity", not root_failures,
        "; ".join(root_failures) if root_failures
        else "root case is present, canonical, identity-matched, and hash-bound",
    )

    # -- V0: object inventory integrity ---------------------------------
    objects: Dict[str, Any] = {}
    failures: List[str] = []
    missing: List[str] = []
    for item in _inventory(manifest):
        if "raw" in item:
            failures.append(f"inventory entry {item['raw']!r} is not an object record")
            continue
        name, stated = str(item.get("path") or ""), str(item.get("hash") or "")
        if not _safe_member_name(name):
            failures.append(f"unsafe inventory path {name!r}")
            continue
        if name not in reader.names:
            missing.append(name or stated)
            continue
        try:
            payload = reader.json(name)
        except (ValueError, CanonicalError) as error:
            failures.append(f"{name}: {error}")
            continue
        recomputed = content_hash(payload)
        if not is_hash(stated) or recomputed != stated:
            failures.append(f"{name}: manifest states {stated}, content hashes to {recomputed}")
        elif content_entries.get(name) != stated:
            failures.append(f"{name}: object inventory and content_hashes disagree")
        elif name != f"objects/sha256/{stated.split(':', 1)[1]}.json":
            failures.append(f"{name}: object path is not derived from its content hash")
        elif item.get("byte_length") is not None and item["byte_length"] != len(reader.read(name)):
            failures.append(f"{name}: declared byte_length {item['byte_length']} is incorrect")
        else:
            objects[recomputed] = payload
    result.report["missing_objects"] = missing
    result.record("object_inventory_integrity", not failures and not missing,
                  "; ".join(failures + [f"missing {m}" for m in missing])
                  if (failures or missing)
                  else f"{len(objects)} inventoried objects present and hash-matched")
    partial = manifest.get("partial") or {}
    if missing and not (manifest.get("omitted_objects") or partial.get("omitted_objects")):  # 39.4
        result.record("partial_bundle_disclosure", False,
                      "objects are absent but the manifest declares no omissions, omission "
                      "reason, affected claims, or maximum achievable level (39.4)")

    inventory_paths = {str(item.get("path")) for item in _inventory(manifest)
                       if "raw" not in item and item.get("path")}
    undeclared_objects = sorted(
        name for name in reader.names
        if name.startswith("objects/sha256/") and name not in inventory_paths
    )
    result.record(
        "no_undeclared_objects", not undeclared_objects,
        f"stored objects absent from inventory: {undeclared_objects}" if undeclared_objects
        else "all stored objects are inventoried",
    )

    _verify_binary_inventory(
        result, reader, manifest.get("artifact_inventory"), content_entries,
        kind="artifact", prefix="artifacts/sha256/", id_field="artifact_id",
    )
    _verify_binary_inventory(
        result, reader, manifest.get("proof_inventory"), content_entries,
        kind="proof", prefix="proofs/sha256/", id_field="proof_id",
    )

    _verify_partial_disclosure(result, manifest, level)
    _verify_manifest_semantics(
        result, reader, manifest, manifest_bytes, level, signature_verifier,
    )
    result.report["level_profile"] = {
        "cumulative": True,
        "requirements": {name: list(LEVEL_REQUIREMENTS[name]) for name in Level.ORDER},
    }
    v0_passed = not result.violations

    if level == Level.V0:
        result.finish()
        result.status = Status.INTEGRITY_ONLY if result.ok else Status.FAILED
        result.report.update({"final_status": result.status,
                          "level_achieved": Level.V0 if result.ok else "NONE"})
        return

    # -- V1: structural closure --------------------------------------------
    _verify_structural(result, reader, manifest, objects, root_payload)
    result.finish()
    structural_passed = all(
        passed for name, passed, _detail in result.checks if name.startswith("v1_")
    )
    if level == Level.V1:
        result.status = Status.PARTIALLY_VERIFIED if result.ok else Status.FAILED
        v1_achieved = (Level.V1 if result.ok else
                       Level.V0 if v0_passed else "NONE")
        result.report.update({"final_status": result.status,
                              "level_achieved": v1_achieved})
        return
    # -- V2: the carried decision program or certificate -------------------
    programs = sorted(n for n in reader.names
                      if n.startswith("verification/programs/") and n.endswith(".json"))
    inner: List[Tuple[str, VerificationResult]] = []
    for name in programs:
        try:
            document = reader.json(name)
        except (ValueError, CanonicalError) as error:
            result.record(f"vir[{name}]", False, f"not canonical JSON: {error}")
            continue
        inner.append((name, verify_vir(
            document, clock=clock, clock_source=clock_source,
            extension_registry=extension_registry,
        )))
    if not programs:
        # Fall back to certificate objects, with the bundle's own objects as
        # the dependency store.
        certificates = [p for p in objects.values()
                        if isinstance(p, dict) and "certificate_id" in p and "outcome" in p]
        if not certificates:
            result.record("verification_program_present", False,
                          "the bundle carries no CRG-VIR program and no decision certificate, "
                          "so no claim can be verified (24.1, 39.1)")
        for certificate in certificates:
            inner.append((str(certificate.get("certificate_id")), verify_certificate(
                certificate, registry=_registry_from(objects, certificate),
                clock=clock, clock_source=clock_source)))

    for name, sub in inner:
        result.checks.extend((f"{name}::{c}", p, d) for c, p, d in sub.checks)
        result.violations.extend(f"{name}::{v}" for v in sub.violations)
        result.warnings.extend(f"{name}::{w}" for w in sub.warnings)
    result.report["claims"] = [{"program": n, "status": s.status, "ok": s.ok, "report": s.report}
                               for n, s in inner]
    # 25.3 requires the report itself to carry time, claim, and signature
    # judgments.  A single-claim bundle surfaces them directly rather than
    # burying them a level down where a reader could miss them (50.3).
    if len(inner) == 1:
        for key in ("time_judgment", "claim_judgment", "unsupported_checks"):
            if key in inner[0][1].report:
                result.report[key] = inner[0][1].report[key]
    result.report.setdefault("signature_judgment",
                             "NOT_SIGNED" if not (manifest.get("signatures") or [])
                             else "UNCHECKED_PROFILE")

    result.finish()
    statuses = {s.status for _n, s in inner}
    if Status.EXPIRED in statuses:
        result.status = Status.EXPIRED
    elif not result.ok:
        result.status = Status.FAILED
    elif len(statuses) == 1:
        result.status = statuses.pop()
    elif statuses:
        result.status = Status.PARTIALLY_VERIFIED
    else:
        result.status = Status.INTEGRITY_ONLY
    decision_passed = bool(inner) and all(sub.ok for _name, sub in inner)
    if not v0_passed:
        achieved = "NONE"
    elif not structural_passed:
        achieved = Level.V0
    elif decision_passed:
        achieved = Level.V2
    else:
        achieved = Level.V1

    # -- V3: proof program, not merely a recomputed decision ---------------
    if level in (Level.V3, Level.V4) and decision_passed and v0_passed and structural_passed:
        proof_programs = [
            name for name, sub in inner
            if (sub.report.get("level_achieved") == Level.V3
                and name.startswith("verification/programs/"))
        ]
        result.record(
            "v3_proof_profile",
            bool(proof_programs),
            (f"{len(proof_programs)} self-contained CRG-VIR proof program(s) passed"
             if proof_programs else
             "decision recomputation passed, but no self-contained CRG-VIR proof program "
             "established the V3 proof checks of section 25.2"),
        )
        result.finish()
        proof_passed = bool(proof_programs)
        if proof_passed:
            achieved = Level.V3
        else:
            result.status = Status.PARTIALLY_VERIFIED

    # -- V4: verifier-owned federation trust inputs ------------------------
    if level == Level.V4 and achieved == Level.V3:
        envelopes = [
            value for value in objects.values()
            if (isinstance(value, dict) and value.get("envelope_id")
                and value.get("bounded_result") is not None
                and value.get("target_context_fingerprint"))
        ]
        v4_checks, v4_report, v4_status = verify_federation(
            envelopes,
            context=federation_context,
            clock=clock,
            clock_source=clock_source,
        )
        for name, passed, detail in v4_checks:
            result.record(name, passed, detail)
        result.report.update(v4_report)
        result.finish()
        if result.ok:
            achieved = Level.V4
            result.status = v4_status
        else:
            result.status = v4_status

    result.report.update({"final_status": result.status,
                          "level_achieved": achieved})


def _verify_structural(
    result: VerificationResult,
    reader: _Reader,
    manifest: dict,
    objects: Dict[str, Any],
    root_case: Any,
) -> None:
    """Cumulative V1 checks from section 25.2.

    This is intentionally schema-independent: the verifier does not import
    the kernel's validators.  It checks the portable schema identities and
    the closed structural invariants directly from bundle bytes.
    """
    schema_failures: List[str] = []
    try:
        schema_manifest = reader.json("schemas/referenced-schema-manifest.json")
    except (ValueError, CanonicalError, KeyError) as error:
        schema_manifest = {}
        schema_failures.append(f"schema manifest cannot be decoded: {error}")
    declared_schemas = manifest.get("schema_identities")
    carried_schemas = (
        schema_manifest.get("schema_identities")
        if isinstance(schema_manifest, dict) else None
    )
    if not isinstance(declared_schemas, list) or declared_schemas != carried_schemas:
        schema_failures.append(
            "manifest schema_identities do not exactly match the carried schema manifest"
        )
    for index, identity in enumerate(declared_schemas or []):
        if not isinstance(identity, dict) or not identity.get("schema_id"):
            schema_failures.append(f"schema identity {index} has no schema_id")
        elif not is_hash(identity.get("schema_hash")):
            schema_failures.append(f"schema identity {index} has no valid schema_hash")
    result.record(
        "v1_schema_identity",
        not schema_failures,
        "; ".join(schema_failures) if schema_failures
        else f"{len(declared_schemas or [])} schema identities are hash-bound and matched",
    )

    version_failures: List[str] = []
    if manifest.get("bundle_format_version") != "1.0.0":
        version_failures.append(
            f"unsupported bundle format {manifest.get('bundle_format_version')!r}"
        )
    if manifest.get("crg_spec_version") != "0.2.0":
        version_failures.append(
            f"unsupported CRG specification version {manifest.get('crg_spec_version')!r}"
        )
    for name in ("quantity_registry_version", "rule_table_version"):
        value = manifest.get(name)
        if not isinstance(value, str) or not value or value.lower() == "unset":
            version_failures.append(f"{name} is not pinned")
    result.record(
        "v1_versions_supported",
        not version_failures,
        "; ".join(version_failures) if version_failures
        else "bundle, spec, quantity-registry, and rule-table versions are pinned and supported",
    )

    unit_failures: List[str] = []
    schemas_seen = 0
    for object_hash, value in objects.items():
        if not isinstance(value, dict):
            continue
        schema = value.get("schema") or value.get("coordinate_schema")
        if not isinstance(schema, dict) or not isinstance(schema.get("coordinates"), list):
            continue
        coordinates = schema["coordinates"]
        schemas_seen += 1
        identifiers: List[str] = []
        for index, coordinate in enumerate(coordinates):
            if not isinstance(coordinate, dict):
                unit_failures.append(f"{object_hash}: coordinate {index} is not an object")
                continue
            missing = [name for name in ("identifier", "quantity", "unit", "direction")
                       if not coordinate.get(name)]
            if missing:
                unit_failures.append(
                    f"{object_hash}: coordinate {index} omits {missing}"
                )
            identifier = str(coordinate.get("identifier") or "")
            if identifier in identifiers:
                unit_failures.append(f"{object_hash}: duplicate coordinate {identifier!r}")
            identifiers.append(identifier)
            if coordinate.get("direction") not in ("MINIMIZE", "MAXIMIZE"):
                unit_failures.append(
                    f"{object_hash}: coordinate {identifier!r} has unsupported direction"
                )
        for record in value.get("realizations") or value.get("entries") or []:
            if not isinstance(record, dict):
                unit_failures.append(f"{object_hash}: realization is not an object")
                continue
            signature = record.get("signature")
            if not isinstance(signature, list) or len(signature) != len(coordinates):
                unit_failures.append(
                    f"{object_hash}: realization {record.get('realization_id')!r} has "
                    f"signature dimension {len(signature) if isinstance(signature, list) else 'invalid'}; "
                    f"schema dimension is {len(coordinates)}"
                )
    result.record(
        "v1_units_and_coordinate_schemas",
        schemas_seen > 0 and not unit_failures,
        "; ".join(unit_failures) if unit_failures
        else f"{schemas_seen} coordinate schema(s) have explicit quantities, units, and dimensions",
    )

    identities = set(objects)
    identities.update(str(item.get("id")) for item in _inventory(manifest) if item.get("id"))
    root = manifest.get("root_case_object") or {}
    if isinstance(root, dict):
        identities.update(str(root.get(name)) for name in ("object_id", "content_hash")
                          if root.get(name))
    external = manifest.get("external_references") or []
    external_ids = {
        str(reference.get("immutable_identity"))
        for reference in external if isinstance(reference, dict) and reference.get("immutable_identity")
    }
    edges: List[Tuple[str, str, str]] = []
    migrations: List[dict] = []
    for value in objects.values():
        if not isinstance(value, dict):
            continue
        candidates = [value]
        candidates.extend(item for item in (value.get("dependency_edges") or [])
                          if isinstance(item, dict))
        for item in candidates:
            if item.get("edge_id") and item.get("source") and item.get("target"):
                edges.append((str(item["source"]), str(item["target"]), str(item["edge_id"])))
        if value.get("record_type") == "MigrationRecord" or value.get("migration_id"):
            migrations.append(value)

    open_edges = [edge_id for source, target, edge_id in edges
                  if source not in identities | external_ids or target not in identities | external_ids]
    result.record(
        "v1_dependency_closure",
        not open_edges,
        f"dependency edges have unresolved endpoints: {open_edges}" if open_edges
        else f"all endpoints of {len(edges)} typed dependency edge(s) are bundle-closed",
    )
    cyclic = _cycle_nodes(edges)
    result.record(
        "v1_dependency_acyclic",
        not cyclic,
        f"dependency graph contains a cycle through {cyclic}" if cyclic
        else f"the {len(edges)}-edge dependency graph is acyclic",
    )

    migration_failures: List[str] = []
    for migration in migrations:
        migration_failures.extend(_migration_evidence_failures(migration))
    result.record(
        "v1_migration_records",
        not migration_failures,
        "; ".join(migration_failures) if migration_failures
        else (f"{len(migrations)} migration record(s) have independently verified "
              "registered transform and classification evidence"),
    )


def _cycle_nodes(edges: List[Tuple[str, str, str]]) -> List[str]:
    adjacency: Dict[str, List[str]] = {}
    for source, target, _edge_id in edges:
        adjacency.setdefault(source, []).append(target)
    for targets in adjacency.values():
        targets.sort()
    visited: set = set()
    for node in sorted(adjacency):
        if node in visited:
            continue
        path: List[str] = [node]
        active = {node}
        stack: List[Tuple[str, int]] = [(node, 0)]
        while stack:
            current, index = stack[-1]
            targets = adjacency.get(current, [])
            if index >= len(targets):
                stack.pop()
                path.pop()
                active.remove(current)
                visited.add(current)
                continue
            target = targets[index]
            stack[-1] = (current, index + 1)
            if target in active:
                start = path.index(target)
                return path[start:] + [target]
            if target in visited:
                continue
            path.append(target)
            active.add(target)
            stack.append((target, 0))
    return []


def _bytes_hash(data: bytes) -> str:
    return "sha256:" + hashlib.sha256(data).hexdigest()


def _safe_member_name(name: str) -> bool:
    if not isinstance(name, str) or not name or "\\" in name:
        return False
    if name.startswith("/") or name.startswith("../"):
        return False
    parts = name.split("/")
    return all(part not in ("", ".", "..") for part in parts)


def _verify_binary_inventory(
    result: VerificationResult, reader: _Reader, inventory: Any,
    content_entries: Dict[str, str], *, kind: str, prefix: str, id_field: str,
) -> None:
    failures: List[str] = []
    paths = set()
    if not isinstance(inventory, list):
        failures.append(f"{kind}_inventory is not an array")
        inventory = []
    for item in inventory:
        if not isinstance(item, dict):
            failures.append(f"malformed {kind} entry {item!r}")
            continue
        identity = item.get(id_field)
        path = str(item.get("path") or "")
        stated = item.get("content_hash")
        if not identity or not _safe_member_name(path) or not path.startswith(prefix):
            failures.append(f"{kind} entry lacks identity or has unsafe/noncanonical path {path!r}")
            continue
        paths.add(path)
        if path not in reader.names:
            failures.append(f"missing {kind} member {path}")
            continue
        actual = _bytes_hash(reader.read(path))
        if not is_hash(stated) or actual != stated:
            failures.append(f"{path}: inventory states {stated!r}, bytes hash to {actual}")
        if content_entries.get(path) != stated:
            failures.append(f"{path}: {kind} inventory and content_hashes disagree")
        expected = prefix + str(stated).split(":", 1)[-1]
        if path != expected:
            failures.append(f"{path}: content-addressed path must be {expected}")
        length = item.get("byte_length")
        if length is not None and length != len(reader.read(path)):
            failures.append(f"{path}: declared byte_length {length} is incorrect")
    extras = sorted(name for name in reader.names if name.startswith(prefix) and name not in paths)
    if extras:
        failures.append(f"stored {kind}s absent from inventory: {extras}")
    result.record(
        f"{kind}_inventory_integrity", not failures,
        "; ".join(failures) if failures else f"all {len(paths)} {kind}s are inventoried and hash-bound",
    )


def _verify_partial_disclosure(
    result: VerificationResult, manifest: dict, requested_level: str
) -> None:
    partial = manifest.get("partial")
    if partial is None:
        result.note("partial_bundle_disclosure", "bundle does not declare itself partial")
        return
    required = (
        "omitted_objects", "omission_reason", "affected_claims",
        "expected_external_dependencies", "maximum_verification_level",
    )
    missing = [name for name in required if not isinstance(partial, dict) or name not in partial]
    result.record(
        "partial_bundle_disclosure", not missing,
        f"partial disclosure omits {missing} (39.4)" if missing
        else "partial bundle declares omissions, reason, affected claims, dependencies, and ceiling",
    )
    if missing or not isinstance(partial, dict):
        return
    aliases = {
        "V0": Level.V0, "INTEGRITY_ONLY": Level.V0,
        "V1": Level.V1, "STRUCTURAL_ONLY": Level.V1,
        "V2": Level.V2, "DECISION_ONLY": Level.V2,
        "V3": Level.V3, "PROOF": Level.V3, "PROOF_ONLY": Level.V3,
        "V4": Level.V4, "FEDERATION": Level.V4,
    }
    stated = str(partial.get("maximum_verification_level") or "").upper()
    ceiling = aliases.get(stated)
    permitted = (
        ceiling is not None
        and Level.ORDER.index(requested_level) <= Level.ORDER.index(ceiling)
    )
    result.record(
        "partial_bundle_level_ceiling",
        permitted,
        (f"requested {requested_level} is within declared ceiling {ceiling}"
         if permitted else
         f"requested {requested_level} exceeds or cannot interpret declared ceiling {stated!r}"),
    )


def _verify_manifest_semantics(
    result: VerificationResult, reader: _Reader, manifest: dict, manifest_bytes: bytes,
    requested_level: str,
    signature_verifier: Optional[
        Callable[[bytes, Mapping[str, Any]], Tuple[bool, str]]
    ],
) -> None:
    failures: List[str] = []
    for field in (
        "object_inventory", "artifact_inventory", "proof_inventory",
        "external_references", "schema_identities", "signatures",
    ):
        if not isinstance(manifest.get(field), list):
            failures.append(f"{field} must be an array")
    for field in ("encryption", "redaction_state", "export_authority", "creation_tool"):
        if not isinstance(manifest.get(field), dict):
            failures.append(f"{field} must be an object")
    tool = manifest.get("creation_tool")
    if isinstance(tool, dict) and (not tool.get("name") or not tool.get("version")):
        failures.append("creation_tool must declare name and version")
    for field in (
        "bundle_format_version", "crg_spec_version", "quantity_registry_version",
        "rule_table_version", "requested_verification_level",
    ):
        if not isinstance(manifest.get(field), str) or not manifest.get(field):
            failures.append(f"{field} must be a nonempty string")
    result.record(
        "manifest_field_types", not failures,
        "; ".join(failures) if failures else "manifest field shapes are valid",
    )

    reference_failures: List[str] = []
    reference_fields = (
        "immutable_identity", "expected_content_hash", "retrieval_policy",
        "required_access", "validity", "offline_behavior", "unavailable_behavior",
    )
    references = manifest.get("external_references")
    if isinstance(references, list):
        for index, reference in enumerate(references):
            if not isinstance(reference, dict):
                reference_failures.append(f"reference {index} is not an object")
                continue
            missing = [field for field in reference_fields if field not in reference]
            if missing:
                reference_failures.append(f"reference {index} omits {missing}")
            digest = reference.get("expected_content_hash")
            if digest is not None and not is_hash(digest):
                reference_failures.append(f"reference {index} has invalid expected_content_hash")
    result.record(
        "external_reference_profiles", not reference_failures,
        "; ".join(reference_failures) if reference_failures
        else f"{len(references or [])} external references are immutable and policy-complete",
    )

    encryption = manifest.get("encryption")
    encryption_failures: List[str] = []
    if isinstance(encryption, dict):
        encrypted = encryption.get("encrypted_objects") or []
        if encrypted and not encryption.get("protected_content_present"):
            encryption_failures.append("encrypted objects are listed but protected_content_present is false")
        for field in (
            "encrypted_objects", "claims_depending_on_protected_content",
            "verifier_capabilities_required", "independently_checkable",
        ):
            if field not in encryption:
                encryption_failures.append(f"encryption metadata omits {field}")
        if encrypted and requested_level != Level.V0 and not encryption.get("independently_checkable"):
            encryption_failures.append(
                f"encrypted content is not independently checkable at requested level {requested_level}"
            )
    result.record(
        "encryption_disclosure", not encryption_failures,
        "; ".join(encryption_failures) if encryption_failures
        else "encryption consequences are explicitly disclosed",
    )

    signatures = manifest.get("signatures")
    if isinstance(signatures, list) and signatures:
        if "signatures/manifest.sig" not in reader.names:
            result.record(
                "signature_verification", False,
                "the manifest declares signatures but signatures/manifest.sig is absent",
            )
            result.report["signature_judgment"] = "MISSING"
        elif signature_verifier is None:
            result.record(
                "signature_verification", False,
                "the bundle declares signatures, but no supported signature verifier was "
                "supplied to the dependency-free core; authenticity is not established",
            )
            result.report["signature_judgment"] = "UNSUPPORTED_PROFILE"
        else:
            try:
                document = decode(reader.read("signatures/manifest.sig").decode("utf-8"))
                if not isinstance(document, dict):
                    raise ValueError("signature document is not a JSON object")
                verified, detail = signature_verifier(manifest_bytes, document)
            except Exception as error:  # fail closed at the optional trust-provider boundary
                verified, detail = False, f"signature verifier failed: {type(error).__name__}: {error}"
            result.record("signature_verification", bool(verified), str(detail))
            result.report["signature_judgment"] = "VERIFIED" if verified else "FAILED"
    else:
        stray = "signatures/manifest.sig" in reader.names
        result.record(
            "signature_verification", not stray,
            "signature member is present but the manifest declares no signature descriptor"
            if stray else "bundle declares no signatures; integrity only",
        )
        result.report["signature_judgment"] = "UNDECLARED" if stray else "NOT_SIGNED"


def _registry_from(objects: Dict[str, Any], certificate: dict) -> dict:
    """Assemble a verification registry from the bundle's own objects."""
    registry: Dict[str, Any] = {"objects": objects}
    bundle = objects.get(certificate.get("retained_registry_hash")) or objects.get(
        certificate.get("complete_registry_hash"))
    if isinstance(bundle, dict):
        registry["schema"] = bundle.get("schema") or {}
        registry["entries"] = [
            {"realization_id": r.get("realization_id"), "signature": r.get("signature", []),
             "legality": r.get("legality", "LEGAL"),
             "evidence_class": r.get("evidence_class", "IMPORTED"),
             "attributes": r.get("attributes") or {}}
            for r in bundle.get("realizations", [])]
    return registry
