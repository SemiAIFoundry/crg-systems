"""The thirteen roles of 44.3, what each may do, and separation of duties.

Normative basis: 44.3 (minimum roles, verbatim), 44.2 (role-based access
control, delegated signing authority, approval separation), 29.4 and 30.5
(certificates and delta certificates carry an approval record), 6.6.

Two design choices are worth defending.

**Roles grant permissions; permissions gate operations.**  A role table that
maps role names directly onto endpoint names has to be edited every time an
endpoint is added, and the edit is invisible in review -- somebody adds
``"Viewer"`` to a new write endpoint and nothing in the diff looks like a
privilege grant.  Naming an intermediate permission (``case:certify``) makes
the grant explicit and makes the *set* of things a role can do readable in one
place.

**No role implies another.**  There is no hierarchy in which System
Administrator silently contains Certificate Signer.  44.2 requires *approval
separation*, and a hierarchy is precisely the mechanism that dissolves it:
if the top role contains every other role, then the person holding it can
propose and approve the same change.  :data:`SEPARATION_OF_DUTIES` states the
pairs that must not be exercised by one identity on one object, and
:func:`separation_violation` checks it.  System Administrator here is an
administrator of the *system*, not a universal signer: it cannot sign
certificates or publish packs, and that is the whole point.
"""
from __future__ import annotations

from typing import Any, Dict, FrozenSet, Iterable, Mapping, Optional, Tuple

__all__ = [
    "ROLES",
    "PERMISSIONS",
    "ROLE_PERMISSIONS",
    "OPERATION_PERMISSIONS",
    "SEPARATION_OF_DUTIES",
    "permissions_for",
    "role_permits",
    "operation_permission",
    "separation_violation",
    "unknown_roles",
]

#: Specification 44.3, verbatim and in its order.  Exactly thirteen.
ROLES: Tuple[str, ...] = (
    "Viewer",
    "Contributor",
    "Registry Importer",
    "Generator Author",
    "Pack Publisher",
    "Evidence Steward",
    "Qualification Author",
    "Decision Approver",
    "Certificate Signer",
    "Federation Operator",
    "Security Administrator",
    "Auditor",
    "System Administrator",
)

#: The permission vocabulary.  ``<resource>:<verb>``; ``*`` never appears,
#: because a wildcard permission is a role table that cannot be reviewed.
PERMISSIONS: Tuple[str, ...] = (
    "case:read",
    "case:create",
    "case:update",
    "case:branch",
    "case:merge",
    "case:migrate",
    "case:validate",
    "registry:import",
    "generator:run",
    "generator:author",
    "geometry:build",
    "query:compile",
    "decision:evaluate",
    "decision:certify",
    "certificate:read",
    "certificate:sign",
    "certificate:revoke",
    "change:classify",
    "change:approve",
    "conversion:plan",
    "evidence:read",
    "evidence:register",
    "evidence:retire",
    "contract:assemble",
    "qualification:plan",
    "experiment:record",
    "pack:publish",
    "pack:install",
    "federation:issue_envelope",
    "federation:evaluate_private",
    "federation:revoke",
    "bundle:import",
    "bundle:export",
    "object:redact",
    "object:erase",
    "object:legal_hold",
    "retention:manage",
    "retention:enforce",
    "key:manage",
    "key:destroy",
    "tenant:manage",
    "identity:manage",
    "policy:manage",
    "audit:read",
    "audit:export",
    "job:manage",
    "system:configure",
)

_P = set(PERMISSIONS)

#: 44.3's roles mapped onto 44.2's capabilities.  Flat by construction.
ROLE_PERMISSIONS: Dict[str, FrozenSet[str]] = {
    "Viewer": frozenset({
        "case:read", "certificate:read", "evidence:read",
    }),
    "Contributor": frozenset({
        "case:read", "case:create", "case:update", "case:branch", "case:merge",
        "case:validate", "geometry:build", "query:compile", "decision:evaluate",
        "generator:run", "change:classify", "conversion:plan", "certificate:read",
        "evidence:read", "bundle:export",
    }),
    "Registry Importer": frozenset({
        "case:read", "registry:import",
    }),
    "Generator Author": frozenset({
        "case:read", "generator:run", "generator:author",
    }),
    "Pack Publisher": frozenset({
        "case:read", "pack:publish", "pack:install",
    }),
    "Evidence Steward": frozenset({
        "case:read", "evidence:read", "evidence:register", "evidence:retire",
        "contract:assemble",
    }),
    "Qualification Author": frozenset({
        "case:read", "evidence:read", "qualification:plan", "experiment:record",
    }),
    # Approves a decision.  Deliberately cannot *sign* the resulting
    # certificate: 44.2's approval separation (see SEPARATION_OF_DUTIES).
    "Decision Approver": frozenset({
        "case:read", "certificate:read", "decision:evaluate", "decision:certify",
        "change:approve",
    }),
    # Signs.  Deliberately cannot approve.
    "Certificate Signer": frozenset({
        "case:read", "certificate:read", "certificate:sign", "certificate:revoke",
    }),
    "Federation Operator": frozenset({
        "case:read", "certificate:read", "federation:issue_envelope",
        "federation:evaluate_private", "federation:revoke",
    }),
    "Security Administrator": frozenset({
        "case:read", "object:redact", "object:erase", "object:legal_hold",
        "key:manage", "key:destroy", "identity:manage", "policy:manage",
        "retention:manage", "retention:enforce", "tenant:manage", "audit:read",
    }),
    # Read-only, and read-only including the audit log.  An Auditor that could
    # write would be able to edit the record of its own writes.
    "Auditor": frozenset({
        "case:read", "certificate:read", "evidence:read", "audit:read",
        "audit:export",
    }),
    # Operates the system.  Note what is absent: certificate:sign,
    # change:approve, pack:publish, object:erase, audit:export.
    "System Administrator": frozenset({
        "case:read", "case:migrate", "case:update", "bundle:import", "bundle:export",
        "job:manage", "system:configure", "pack:install", "tenant:manage",
        "retention:manage",
    }),
}

#: Operation identifiers (crg-server's ``operation_id``) mapped onto the single
#: permission that gates them.  One permission per operation: an operation that
#: needed two would be doing two things.
OPERATION_PERMISSIONS: Dict[str, str] = {
    "createCase": "case:create",
    "getCase": "case:read",
    "validateCase": "case:validate",
    "createBranch": "case:branch",
    "mergeCase": "case:merge",
    "importRegistry": "registry:import",
    "generateFamily": "generator:run",
    "evaluateFamily": "decision:evaluate",
    "buildGeometry": "geometry:build",
    "compileQuery": "query:compile",
    "certifyCase": "decision:certify",
    "classifyChange": "change:classify",
    "recomputeCase": "decision:certify",
    "planConversion": "conversion:plan",
    "planQualification": "qualification:plan",
    "createEvaluatorRequest": "experiment:record",
    "getDependencies": "case:read",
    "listCertificates": "certificate:read",
    "migrateCase": "case:migrate",
    "redactObject": "object:redact",
    "createRetentionPolicy": "retention:manage",
    "listRetentionPolicies": "retention:manage",
    "evaluateRetention": "retention:manage",
    "enforceRetention": "retention:enforce",
    "setObjectLegalHold": "object:legal_hold",
    "registerEvidence": "evidence:register",
    "assembleTechnologyContract": "contract:assemble",
    "issueCapabilityEnvelope": "federation:issue_envelope",
    "evaluatePrivately": "federation:evaluate_private",
    "revokeCapability": "federation:revoke",
    "importBundle": "bundle:import",
    "verifyBundle": "certificate:read",
    "exportBundle": "bundle:export",
    "getJob": "case:read",
    "getJobResult": "case:read",
    "cancelJob": "job:manage",
    "retryJob": "job:manage",
    "listEvents": "audit:read",
    "streamEvents": "audit:read",
    "streamCaseEvents": "audit:read",
    "exportAudit": "audit:export",
    "getOpenApi": "case:read",
    "healthLive": "case:read",
    "healthReady": "case:read",
    "getMetrics": "audit:read",
    "createWebhookSubscription": "system:configure",
    "listWebhookSubscriptions": "system:configure",
    "deleteWebhookSubscription": "system:configure",
    "executeTransition": "system:configure",
}

#: Pairs of permissions that one identity MUST NOT exercise over the same
#: object (44.2, "approval separation").  Order-independent.
SEPARATION_OF_DUTIES: Tuple[Tuple[str, str, str], ...] = (
    (
        "decision:certify",
        "certificate:sign",
        "the identity that approves a decision may not also sign its certificate",
    ),
    (
        "change:classify",
        "change:approve",
        "the identity that proposes a change may not also approve it",
    ),
    (
        "object:redact",
        "object:legal_hold",
        "the identity that releases a legal hold may not also perform the removal "
        "that the hold was preventing (17.5)",
    ),
    (
        "key:destroy",
        "audit:export",
        "the identity that destroys a key may not also be the sole exporter of the "
        "audit record of the destruction (17.4, 44.7)",
    ),
)


def unknown_roles(roles: Iterable[str]) -> Tuple[str, ...]:
    """Role names outside 44.3.  A deployment inventing roles should know."""
    known = set(ROLES)
    return tuple(sorted({str(r) for r in roles} - known))


def permissions_for(roles: Iterable[str]) -> FrozenSet[str]:
    """Union the permissions of the roles held.  Unknown roles grant nothing."""
    granted: set = set()
    for role in roles:
        granted |= ROLE_PERMISSIONS.get(str(role), frozenset())
    return frozenset(granted)


def role_permits(roles: Iterable[str], permission: str) -> bool:
    return str(permission) in permissions_for(roles)


def operation_permission(operation_id: str) -> Optional[str]:
    """The permission gating ``operation_id``, or ``None`` if unmapped.

    ``None`` is not "allowed".  The caller -- see
    :class:`crg_security.gate.ServerSecurityGate` -- treats an unmapped
    operation as a refusal, because a new endpoint that nobody remembered to
    map must fail closed (6.6).
    """
    return OPERATION_PERMISSIONS.get(str(operation_id))


def separation_violation(
    roles: Iterable[str],
    permission: str,
    *,
    previously_exercised: Iterable[str] = (),
) -> Optional[Tuple[str, str, str]]:
    """Return the violated separation rule, or ``None``.

    ``previously_exercised`` is the set of permissions this identity already
    used *on this object*.  Separation of duties is a property of an object's
    history, not of a role table: holding both roles is a policy smell, but
    exercising both on one certificate is the actual violation.
    """
    held = permissions_for(roles)
    used = {str(p) for p in previously_exercised}
    wanted = str(permission)
    for first, second, why in SEPARATION_OF_DUTIES:
        if wanted == second and first in used:
            return (first, second, why)
        if wanted == first and second in used:
            return (second, first, why)
        # Also a violation when a single identity holds both and is about to
        # complete the pair in one step.
        if wanted == second and first in used and first in held:
            return (first, second, why)
    return None


def role_catalog() -> Dict[str, Any]:
    """A publishable description of the role model (51)."""
    return {
        "spec": "44.3",
        "role_count": len(ROLES),
        "roles": [
            {"role": role, "permissions": sorted(ROLE_PERMISSIONS[role])} for role in ROLES
        ],
        "separation_of_duties": [
            {"first": a, "second": b, "rationale": why} for a, b, why in SEPARATION_OF_DUTIES
        ],
        "hierarchy": (
            "none; no role contains another, so that 44.2's approval separation "
            "cannot be dissolved by holding a single senior role"
        ),
    }


# A construction-time check: every permission a role grants must be in the
# declared vocabulary, and every declared permission must be reachable.  A
# typo in a role table is a silent privilege change, and this is cheaper than
# discovering it in production.
for _role, _perms in ROLE_PERMISSIONS.items():
    _unknown = set(_perms) - _P
    if _unknown:  # pragma: no cover - a source error, not a runtime one
        raise AssertionError(f"role {_role!r} grants undeclared permissions {sorted(_unknown)}")
for _op, _perm in OPERATION_PERMISSIONS.items():
    if _perm not in _P:  # pragma: no cover - a source error
        raise AssertionError(f"operation {_op!r} maps to undeclared permission {_perm!r}")
