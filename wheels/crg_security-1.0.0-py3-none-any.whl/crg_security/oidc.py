"""Production OIDC JWT validation with TLS discovery and rotating JWKS.

This is the resource-server half of OpenID Connect: a CRG API receives a
Bearer JWT issued by a configured provider and validates it against that
provider's discovery document and public key set.  It deliberately does not
implement an authorization-code/browser redirect flow and does not hold a
client secret.

Security invariants are structural:

* discovery and JWKS are HTTPS-only and bounded before JSON parsing;
* the discovery ``issuer`` must equal the configured issuer byte-for-byte;
* algorithms are a deployment allow-list, never selected only by the token;
* ``kid`` resolves exactly one compatible signing key and refreshes JWKS once
  on a miss, which supports rotation without trying every key;
* duplicate JSON members, JOSE ``crit`` extensions, ``alg=none``, symmetric
  keys, malformed ECDSA signatures, and unknown key types fail closed; and
* issuer, audience, authorized-party, subject, NumericDate, tenant, role and
  required-claim checks precede construction of a :class:`Principal`.
"""
from __future__ import annotations

import base64
import json
import re
import ssl
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Any, Callable, Dict, Mapping, Optional, Sequence, Tuple

from .clock import Clock, iso
from .errors import AuthenticationError, ConfigurationError, CredentialExpiredError
from .identity import FederatedIdentityProvider, Principal, SubjectKind
from .profile import require_production_crypto
from .roles import unknown_roles

__all__ = ["OidcHttpClient", "OidcProvider"]

_SUPPORTED_ALGORITHMS = ("RS256", "ES256", "EdDSA")
_B64U = re.compile(r"^[A-Za-z0-9_-]+$")


def _strict_json(payload: bytes, *, where: str) -> Mapping[str, Any]:
    def object_pairs(pairs):
        result: Dict[str, Any] = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f"duplicate JSON member {key!r}")
            result[str(key)] = value
        return result

    try:
        value = json.loads(payload.decode("utf-8"), object_pairs_hook=object_pairs)
    except (UnicodeDecodeError, ValueError, json.JSONDecodeError) as error:
        raise AuthenticationError(
            f"{where} is not strict UTF-8 JSON: {error}",
            remedy="malformed or ambiguous identity metadata is refused",
        ) from error
    if not isinstance(value, Mapping):
        raise AuthenticationError(f"{where} must be a JSON object")
    return dict(value)


def _b64u(value: Any, *, where: str) -> bytes:
    text = str(value or "")
    if not text or "=" in text or _B64U.fullmatch(text) is None:
        raise AuthenticationError(f"{where} is not unpadded base64url")
    try:
        return base64.b64decode(
            text + "=" * (-len(text) % 4), altchars=b"-_", validate=True
        )
    except (ValueError, TypeError) as error:
        raise AuthenticationError(f"{where} is not valid base64url") from error


def _https_url(value: Any, *, where: str) -> str:
    url = str(value or "").strip()
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme.lower() != "https" or not parsed.hostname or parsed.username:
        raise ConfigurationError(
            f"{where} must be an absolute HTTPS URL without user information",
            remedy="OIDC trust metadata and keys must be fetched through authenticated TLS",
        )
    if parsed.fragment:
        raise ConfigurationError(f"{where} must not contain a fragment")
    return url


@dataclass(frozen=True)
class _FetchedJson:
    document: Mapping[str, Any]
    final_url: str


class OidcHttpClient:
    """Bounded TLS-only JSON transport used by discovery and JWKS refresh."""

    def __init__(
        self,
        *,
        ca_file: str = "",
        timeout_seconds: float = 5.0,
        max_response_bytes: int = 1 << 20,
    ) -> None:
        self.timeout_seconds = float(timeout_seconds)
        self.max_response_bytes = int(max_response_bytes)
        if self.timeout_seconds <= 0 or self.max_response_bytes <= 0:
            raise ConfigurationError("OIDC HTTP timeout and response limit must be positive")
        try:
            self.context = ssl.create_default_context(cafile=str(ca_file) or None)
            self.context.minimum_version = ssl.TLSVersion.TLSv1_2
        except (OSError, ssl.SSLError) as error:
            raise ConfigurationError(f"cannot load OIDC TLS trust roots: {error}") from error

    def fetch_json(self, url: str) -> Mapping[str, Any]:
        requested = _https_url(url, where="OIDC metadata URL")
        request = urllib.request.Request(
            requested,
            headers={"Accept": "application/json", "User-Agent": "crg-security/1.0.0"},
            method="GET",
        )
        try:
            with urllib.request.urlopen(
                request, timeout=self.timeout_seconds, context=self.context
            ) as response:
                final_url = _https_url(response.geturl(), where="OIDC redirect target")
                declared = response.headers.get("Content-Length")
                if declared is not None and int(declared) > self.max_response_bytes:
                    raise AuthenticationError("OIDC metadata exceeds the configured byte limit")
                payload = response.read(self.max_response_bytes + 1)
                media_type = str(response.headers.get_content_type() or "").lower()
        except AuthenticationError:
            raise
        except (urllib.error.URLError, urllib.error.HTTPError, OSError, ValueError) as error:
            raise AuthenticationError(
                f"OIDC metadata fetch failed: {error}",
                remedy="verify IdP reachability, TLS trust, URL and response bounds",
            ) from error
        if len(payload) > self.max_response_bytes:
            raise AuthenticationError("OIDC metadata exceeds the configured byte limit")
        if media_type not in {"application/json", "application/jwk-set+json"}:
            raise AuthenticationError(
                f"OIDC metadata has unsupported media type {media_type!r}"
            )
        # A redirect may change host (some IdPs use a metadata CDN), but it may
        # never leave HTTPS.  The discovery document still pins issuer and
        # jwks_uri, so the redirect cannot widen token authority.
        return _strict_json(payload, where=f"OIDC document from {final_url}")


class OidcProvider(FederatedIdentityProvider):
    """A production OIDC provider for JWT Bearer authentication."""

    protocol = "oidc"
    production = True

    def __init__(
        self,
        *,
        provider_id: str,
        issuer: str,
        audience: str,
        discovery_url: str = "",
        allowed_algorithms: Sequence[str] = ("RS256",),
        role_claim: str = "roles",
        tenant_claim: str = "tenant_id",
        tenant_map: Optional[Mapping[str, str]] = None,
        allowed_tenants: Sequence[str] = (),
        role_map: Optional[Mapping[str, Sequence[str]]] = None,
        default_tenant: str = "",
        attribute_claims: Sequence[str] = ("name", "email", "groups"),
        display_name_claim: str = "name",
        required_claims: Optional[Mapping[str, Any]] = None,
        accepted_types: Sequence[str] = ("JWT", "at+jwt"),
        allow_missing_type: bool = True,
        require_issued_at: bool = True,
        max_clock_skew_seconds: float = 60.0,
        max_token_age_seconds: Optional[float] = None,
        jwks_cache_seconds: float = 300.0,
        kid_miss_refresh_seconds: float = 30.0,
        max_token_bytes: int = 32768,
        http_client: Optional[OidcHttpClient] = None,
        fetch_json: Optional[Callable[[str], Mapping[str, Any]]] = None,
        monotonic: Callable[[], float] = time.monotonic,
    ) -> None:
        require_production_crypto("production OIDC JWT verification")
        self.provider_id = str(provider_id).strip()
        self.issuer = _https_url(issuer, where="OIDC issuer")
        if urllib.parse.urlsplit(self.issuer).query:
            raise ConfigurationError("OIDC issuer identifiers must not contain a query")
        self.audience = str(audience).strip()
        if not self.provider_id or not self.audience:
            raise ConfigurationError("OIDC provider_id and audience are required")
        self.discovery_url = _https_url(
            discovery_url or self.issuer.rstrip("/") + "/.well-known/openid-configuration",
            where="OIDC discovery URL",
        )
        algorithms = tuple(dict.fromkeys(str(item) for item in allowed_algorithms))
        unsupported = sorted(set(algorithms) - set(_SUPPORTED_ALGORITHMS))
        if not algorithms or unsupported:
            raise ConfigurationError(
                f"unsupported OIDC algorithms {unsupported}; supported: {_SUPPORTED_ALGORITHMS}"
            )
        self.allowed_algorithms = algorithms
        self.role_claim = str(role_claim)
        self.tenant_claim = str(tenant_claim)
        self.tenant_map = {str(k): str(v) for k, v in (tenant_map or {}).items()}
        self.allowed_tenants = frozenset(str(item) for item in allowed_tenants)
        self.role_map = {
            str(key): tuple(str(role) for role in value)
            for key, value in (role_map or {}).items()
        }
        invalid_roles = sorted({
            role for roles in self.role_map.values() for role in unknown_roles(roles)
        })
        if invalid_roles:
            raise ConfigurationError(f"OIDC role_map names unknown CRG roles {invalid_roles}")
        self.default_tenant = str(default_tenant)
        self.attribute_claims = tuple(str(item) for item in attribute_claims)
        self.display_name_claim = str(display_name_claim)
        self.required_claims = dict(required_claims or {})
        self.accepted_types = tuple(str(item) for item in accepted_types)
        self.allow_missing_type = bool(allow_missing_type)
        self.require_issued_at = bool(require_issued_at)
        self.max_clock_skew_seconds = float(max_clock_skew_seconds)
        self.max_token_age_seconds = (
            None if max_token_age_seconds is None else float(max_token_age_seconds)
        )
        self.jwks_cache_seconds = float(jwks_cache_seconds)
        self.kid_miss_refresh_seconds = float(kid_miss_refresh_seconds)
        self.max_token_bytes = int(max_token_bytes)
        if (
            self.max_clock_skew_seconds < 0
            or self.jwks_cache_seconds <= 0
            or self.kid_miss_refresh_seconds <= 0
            or self.max_token_bytes <= 0
            or self.max_token_age_seconds is not None and self.max_token_age_seconds <= 0
        ):
            raise ConfigurationError("OIDC skew, cache, token-age and size bounds are invalid")
        self._fetch_json = fetch_json or (http_client or OidcHttpClient()).fetch_json
        self._monotonic = monotonic
        self._lock = threading.RLock()
        self._jwks_uri = ""
        self._keys: Dict[str, Mapping[str, Any]] = {}
        self._cache_until = float("-inf")
        self._next_kid_miss_refresh = float("-inf")
        self._load_discovery_and_keys()

    def _load_discovery_and_keys(self) -> None:
        discovery = dict(self._fetch_json(self.discovery_url))
        if str(discovery.get("issuer") or "") != self.issuer:
            raise ConfigurationError(
                "OIDC discovery issuer does not match the configured issuer exactly"
            )
        self._jwks_uri = _https_url(discovery.get("jwks_uri"), where="OIDC jwks_uri")
        declared = discovery.get("id_token_signing_alg_values_supported")
        if not isinstance(declared, list):
            raise ConfigurationError(
                "OIDC discovery must declare id_token_signing_alg_values_supported"
            )
        missing = sorted(set(self.allowed_algorithms) - {str(item) for item in declared})
        if missing:
            raise ConfigurationError(
                f"configured OIDC algorithms are not declared by discovery: {missing}"
            )
        self._refresh_keys()

    def _refresh_keys(self) -> None:
        document = dict(self._fetch_json(self._jwks_uri))
        entries = document.get("keys")
        if not isinstance(entries, list) or not entries:
            raise AuthenticationError("OIDC JWKS contains no keys")
        keys: Dict[str, Mapping[str, Any]] = {}
        for raw in entries:
            if not isinstance(raw, Mapping):
                raise AuthenticationError("OIDC JWKS keys must be JSON objects")
            key = dict(raw)
            kid = str(key.get("kid") or "")
            if not kid or kid in keys:
                raise AuthenticationError("every OIDC JWK requires a unique non-empty kid")
            if key.get("use") not in (None, "sig"):
                continue
            operations = key.get("key_ops")
            if operations is not None and (
                not isinstance(operations, list) or "verify" not in operations
            ):
                continue
            keys[kid] = key
        if not keys:
            raise AuthenticationError("OIDC JWKS contains no signature-verification keys")
        self._keys = keys
        self._cache_until = self._monotonic() + self.jwks_cache_seconds

    def _key(self, kid: str, alg: str) -> Mapping[str, Any]:
        with self._lock:
            moment = self._monotonic()
            refreshed = False
            if moment >= self._cache_until:
                self._refresh_keys()
                refreshed = True
            key = self._keys.get(kid)
            if key is None and not refreshed and moment >= self._next_kid_miss_refresh:
                self._refresh_keys()  # one rotation refresh on kid miss
                self._next_kid_miss_refresh = moment + self.kid_miss_refresh_seconds
                key = self._keys.get(kid)
            if key is None:
                raise AuthenticationError(
                    f"OIDC token names unknown kid {kid!r}",
                    detail={"known_kids": sorted(self._keys)},
                )
            declared_alg = str(key.get("alg") or "")
            if declared_alg and declared_alg != alg:
                raise AuthenticationError("OIDC JWK alg does not match the token alg")
            expected_kty = {"RS256": "RSA", "ES256": "EC", "EdDSA": "OKP"}[alg]
            if str(key.get("kty") or "") != expected_kty:
                raise AuthenticationError("OIDC JWK type is incompatible with token alg")
            return key

    @staticmethod
    def _verify_signature(
        alg: str, key: Mapping[str, Any], signing_input: bytes, signature: bytes
    ) -> None:
        require_production_crypto("production OIDC JWT verification")
        from cryptography.exceptions import InvalidSignature
        from cryptography.hazmat.primitives import hashes
        from cryptography.hazmat.primitives.asymmetric import ec, ed25519, padding, rsa
        from cryptography.hazmat.primitives.asymmetric.utils import encode_dss_signature

        try:
            if alg == "RS256":
                n = int.from_bytes(_b64u(key.get("n"), where="RSA modulus"), "big")
                e = int.from_bytes(_b64u(key.get("e"), where="RSA exponent"), "big")
                if n.bit_length() < 2048 or e < 3 or e % 2 == 0:
                    raise AuthenticationError("OIDC RSA key does not meet the 2048-bit baseline")
                public = rsa.RSAPublicNumbers(e, n).public_key()
                public.verify(signature, signing_input, padding.PKCS1v15(), hashes.SHA256())
            elif alg == "ES256":
                if key.get("crv") != "P-256" or len(signature) != 64:
                    raise AuthenticationError("ES256 requires P-256 and a 64-byte JOSE signature")
                x = int.from_bytes(_b64u(key.get("x"), where="EC x"), "big")
                y = int.from_bytes(_b64u(key.get("y"), where="EC y"), "big")
                public = ec.EllipticCurvePublicNumbers(x, y, ec.SECP256R1()).public_key()
                der = encode_dss_signature(
                    int.from_bytes(signature[:32], "big"),
                    int.from_bytes(signature[32:], "big"),
                )
                public.verify(der, signing_input, ec.ECDSA(hashes.SHA256()))
            else:
                if key.get("crv") != "Ed25519":
                    raise AuthenticationError("EdDSA OIDC keys must declare crv Ed25519")
                public = ed25519.Ed25519PublicKey.from_public_bytes(
                    _b64u(key.get("x"), where="Ed25519 x")
                )
                public.verify(signature, signing_input)
        except InvalidSignature as error:
            raise AuthenticationError("OIDC token signature does not verify") from error
        except AuthenticationError:
            raise
        except (ValueError, TypeError) as error:
            raise AuthenticationError(f"OIDC public key is malformed: {error}") from error

    @staticmethod
    def _numeric_date(claims: Mapping[str, Any], name: str, *, required: bool) -> Optional[int]:
        value = claims.get(name)
        if value is None:
            if required:
                raise AuthenticationError(f"OIDC token requires NumericDate claim {name!r}")
            return None
        if isinstance(value, bool) or not isinstance(value, int):
            raise AuthenticationError(f"OIDC claim {name!r} must be an integer NumericDate")
        return value

    def _validate_claims(self, claims: Mapping[str, Any], *, clock: Clock) -> Principal:
        if str(claims.get("iss") or "") != self.issuer:
            raise AuthenticationError("OIDC token issuer does not match configured issuer")
        audience = claims.get("aud")
        audiences = (
            [str(item) for item in audience]
            if isinstance(audience, list) else [str(audience or "")]
        )
        if self.audience not in audiences:
            raise AuthenticationError("OIDC token audience does not include this CRG service")
        if len(audiences) > 1 and str(claims.get("azp") or "") != self.audience:
            raise AuthenticationError("multi-audience OIDC token requires matching azp")
        subject = str(claims.get("sub") or "")
        if not subject:
            raise AuthenticationError("OIDC token carries no subject")
        for name, expected in self.required_claims.items():
            if claims.get(name) != expected:
                raise AuthenticationError(f"OIDC required claim {name!r} does not match")

        exp = self._numeric_date(claims, "exp", required=True)
        iat = self._numeric_date(claims, "iat", required=self.require_issued_at)
        nbf = self._numeric_date(claims, "nbf", required=False)
        now = int(clock.now().timestamp())
        skew = int(self.max_clock_skew_seconds)
        assert exp is not None
        if now >= exp + skew:
            raise CredentialExpiredError("OIDC token has expired")
        if nbf is not None and now + skew < nbf:
            raise AuthenticationError("OIDC token is not yet valid")
        if iat is not None and iat > now + skew:
            raise AuthenticationError("OIDC token was issued in the future")
        if (
            iat is not None and self.max_token_age_seconds is not None
            and now - iat > self.max_token_age_seconds + skew
        ):
            raise CredentialExpiredError("OIDC token exceeds the configured maximum age")

        raw_roles = claims.get(self.role_claim)
        if raw_roles is None:
            raw_roles = []
        if isinstance(raw_roles, str):
            raw_roles = [raw_roles]
        if not isinstance(raw_roles, list):
            raise AuthenticationError("OIDC role claim must be a string or array")
        roles = []
        for raw in raw_roles:
            roles.extend(self.role_map.get(str(raw), (str(raw),)))
        invalid = unknown_roles(roles)
        if invalid:
            raise AuthenticationError(f"OIDC token maps to unknown CRG roles {list(invalid)}")

        asserted_tenant = str(claims.get(self.tenant_claim) or "")
        tenant = self.tenant_map.get(asserted_tenant, asserted_tenant) or self.default_tenant
        if not tenant:
            raise AuthenticationError("OIDC token does not establish a CRG tenant")
        if self.allowed_tenants and tenant not in self.allowed_tenants:
            raise AuthenticationError("OIDC token maps outside this deployment's tenant set")
        attributes = {
            name: claims[name] for name in self.attribute_claims if name in claims
        }
        import datetime as _dt
        expires_at = iso(_dt.datetime.fromtimestamp(exp, tz=_dt.timezone.utc))
        return Principal(
            subject_id=subject,
            tenant_id=tenant,
            kind=SubjectKind.FEDERATED_USER,
            display_name=str(claims.get(self.display_name_claim) or subject),
            roles=tuple(sorted(set(roles))),
            attributes=attributes,
            authentication_method="oidc-jwt",
            provider_id=self.provider_id,
            session_id=str(claims.get("jti") or ""),
            authenticated_at=iso(clock.now()),
            expires_at=expires_at,
            clock_source=clock.source,
            clock_trust_level=clock.trust_level,
        )

    def validate(self, credential: Any, *, clock: Clock) -> Principal:
        token = str(credential or "")
        if len(token.encode("utf-8")) > self.max_token_bytes:
            raise AuthenticationError("OIDC token exceeds the configured byte limit")
        parts = token.split(".")
        if len(parts) != 3 or not all(parts):
            raise AuthenticationError("OIDC bearer token is not a three-segment JWT")
        header_segment, payload_segment, signature_segment = parts
        header = _strict_json(_b64u(header_segment, where="JWT header"), where="JWT header")
        claims = _strict_json(_b64u(payload_segment, where="JWT payload"), where="JWT payload")
        if header.get("crit") not in (None, []):
            raise AuthenticationError("OIDC token declares unsupported critical JOSE headers")
        if header.get("b64") is False:
            raise AuthenticationError("OIDC token detached/unencoded payload is unsupported")
        token_type = str(header.get("typ") or "")
        if (token_type and token_type not in self.accepted_types) or (
            not token_type and not self.allow_missing_type
        ):
            raise AuthenticationError("OIDC token type is not accepted by this profile")
        alg = str(header.get("alg") or "")
        if alg not in self.allowed_algorithms:
            raise AuthenticationError(
                f"OIDC token alg {alg!r} is outside the deployment allow-list"
            )
        kid = str(header.get("kid") or "")
        if not kid:
            raise AuthenticationError("OIDC token requires a kid")
        key = self._key(kid, alg)
        signing_input = f"{header_segment}.{payload_segment}".encode("ascii")
        self._verify_signature(
            alg, key, signing_input, _b64u(signature_segment, where="JWT signature")
        )
        return self._validate_claims(claims, clock=clock)

    def disclosure(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "provider_id": self.provider_id,
                "protocol": self.protocol,
                "production": True,
                "mode": "OIDC JWT resource-server validation",
                "issuer": self.issuer,
                "audience": self.audience,
                "discovery_url": self.discovery_url,
                "jwks_uri": self._jwks_uri,
                "allowed_algorithms": list(self.allowed_algorithms),
                "cached_key_ids": sorted(self._keys),
                "jwks_cache_seconds": self.jwks_cache_seconds,
                "kid_miss_refresh_seconds": self.kid_miss_refresh_seconds,
                "authorization_code_flow": False,
                "saml_xml": False,
            }
