/**
 * Audit and Approval (spec 41.1): object history, signatures, approvals,
 * redactions, and exports.
 *
 * The workspace an auditor lives in, so it is the one that must never
 * flatter the record.  A redacted object is shown as a tombstone with the
 * certificates it broke, and those certificates are shown as
 * `UNVERIFIABLE_REDACTED` rather than quietly dropped from the list: 17.3
 * says a certificate whose supporting content was removed must not be
 * reported as valid, and the way an interface breaks that rule is by not
 * mentioning it.
 *
 * Export is offered prominently because 6.12 and 47.8 make portability a
 * property of the product rather than a feature of it. An auditor who can
 * leave with a verifiable bundle does not have to trust this screen.
 */

import {
  absent, definitionList, disclosure, emptyState, esc, hashChip, join, outcomeInfo, panel,
  table, verificationChip,
} from '../render.js';
import { action, field, notYet, shell } from '../workspace.js';

const meta = {
  id: 'audit-approval',
  title: 'Audit and Approval',
  purpose: 'Object history, signatures, approvals, redactions, and exports.',
  endpoints: ['listEvents', 'getCase', 'listCertificates', 'redactObject', 'migrateCase',
    'exportBundle', 'exportAudit', 'createWebhookSubscription', 'listWebhookSubscriptions',
    'deleteWebhookSubscription', 'createRetentionPolicy', 'listRetentionPolicies',
    'evaluateRetention', 'enforceRetention', 'setObjectLegalHold'],
};

const RETENTION_OPERATIONS = new Set([
  'createRetentionPolicy', 'listRetentionPolicies', 'evaluateRetention',
  'enforceRetention', 'setObjectLegalHold',
]);

function retentionResult(state) {
  const last = state.lastAction || {};
  if (!RETENTION_OPERATIONS.has(last.operation) || last.result === undefined) return '';
  return disclosure(
    `Last retention response: ${last.operation}`,
    `<pre class="crg-pre" tabindex="0" role="group" aria-label="Last retention response">`
      + `${esc(JSON.stringify(last.result, null, 2))}</pre>`,
    { open: true, principle: 'why' },
  );
}

function retentionPanel(state) {
  const form = state.form || {};
  return panel('Retention and legal hold', join([
    `<p class="crg-prose">Operational retention changes storage lifecycle under §17. `
      + `It is not the decision-retention policy of §29.3. Always list the active policy, `
      + `run a bounded preview, review every decision, and enforce only the reviewed cursor.</p>`,
    retentionResult(state),
    field('retention-policy-request', 'Policy document', {
      multiline: true, rows: 12, value: form['retention-policy-request'] || '',
      hint: 'JSON policy_id, version, object_types, minimum_age_seconds, action, reason, effective_at, and authority.',
    }),
    `<div class="crg-actions">`
      + action('create-retention-policy', 'Register policy', {
        operation: 'createRetentionPolicy', fields: ['retention-policy-request'],
      })
      + action('list-retention-policies', 'List policies', {
        operation: 'listRetentionPolicies', tone: 'secondary',
        fields: ['retention-policy-request'],
      })
      + `</div>`,
    field('retention-run-request', 'Bounded run request', {
      multiline: true, rows: 7, value: form['retention-run-request'] || '',
      hint: 'JSON policy_hash, authority, limit, and optional after_hash. Evaluation time is server-owned.',
    }),
    `<div class="crg-actions">`
      + action('evaluate-retention', 'Preview this batch', {
        operation: 'evaluateRetention', tone: 'secondary',
        fields: ['retention-run-request'],
      })
      + action('enforce-retention', 'Enforce reviewed batch', {
        operation: 'enforceRetention', tone: 'danger',
        fields: ['retention-run-request'],
      })
      + `</div>`,
    field('legal-hold-object', 'Object content hash', {
      value: form['legal-hold-object'] || '',
      hint: 'The lowercase sha256 content address to hold or release.',
    }),
    field('legal-hold-request', 'Legal-hold instruction', {
      multiline: true, rows: 4, value: form['legal-hold-request'] || '',
      hint: 'JSON with held (a boolean) and authority. A release is separately audited.',
    }),
    `<div class="crg-actions">${action('set-legal-hold', 'Apply legal-hold instruction', {
      operation: 'setObjectLegalHold', tone: 'danger',
      fields: ['legal-hold-object', 'legal-hold-request'],
    })}</div>`,
  ]), { tone: 'warn', principle: 'why' });
}

function eventTable(events) {
  if (!events.length) {
    return emptyState('No events are recorded. The event log is append-only; an empty log '
      + 'means nothing has happened, not that history was cleared.');
  }
  return table('Event log', [
    { label: 'When' },
    { label: 'Event' },
    { label: 'Actor' },
    { label: 'Objects' },
    { label: 'Correlation' },
  ], events.map((event) => ({
    attributes: ` data-event="${esc(event.event || '')}"`,
    cells: [
      event.timestamp ? esc(event.timestamp) : absent(),
      `<code class="crg-code">${esc(event.event || '')}</code>`,
      event.actor ? esc(event.actor)
        : `<span class="crg-unmapped">Unattributed</span>`,
      (event.object_hashes || []).length
        ? `<ul class="crg-list crg-list--deps">${(event.object_hashes || [])
          .map((h) => `<li>${hashChip(h)}</li>`).join('')}</ul>`
        : absent('NOT_APPLICABLE'),
      event.correlation_id ? hashChip(event.correlation_id) : absent(),
    ],
  })));
}

function certificateTable(certificates) {
  if (!certificates.length) {
    return emptyState('No certificates have been issued for this case.');
  }
  return table('Certificates and their standing', [
    { label: 'Certificate' },
    { label: 'Outcome' },
    { label: 'Standing' },
    { label: 'Authorises anything?' },
    { label: 'Issued' },
  ], certificates.map((certificate) => ({
    attributes: ` data-certificate-status="${esc(certificate.status || '')}"`,
    cells: [
      hashChip(certificate.certificate_id),
      esc(outcomeInfo(certificate.outcome).headline),
      certificate.status === 'UNVERIFIABLE_REDACTED'
        ? verificationChip('UNVERIFIABLE_REDACTED')
        : `<span>${esc(certificate.status || '')}</span>`,
      certificate.affirmative
        ? 'Yes, within its claim scope'
        : 'No — this certificate is a record of a refusal',
      certificate.issued_at ? esc(certificate.issued_at) : absent(),
    ],
  })));
}

function redactionPanel(state) {
  const record = (state.data || {}).case || {};
  const tombstones = record.tombstones || [];
  const affected = state.affected_certificates || [];
  return panel('Redactions and tombstones', join([
    tombstones.length
      ? table('Tombstones', [
        { label: 'Removed object' },
        { label: 'Reason' },
        { label: 'Authority' },
        { label: 'When' },
      ], tombstones.map((tombstone) => ({
        cells: [
          hashChip(tombstone.object_hash || tombstone.hash),
          tombstone.reason ? esc(tombstone.reason) : absent(),
          tombstone.authority ? esc(tombstone.authority) : absent(),
          tombstone.recorded_at ? esc(tombstone.recorded_at) : absent(),
        ],
      })))
      : '<p class="crg-prose">Nothing has been redacted from this case.</p>',
    affected.length
      ? `<p class="crg-prose"><strong>Certificates broken by redaction:</strong></p>`
        + `<ul class="crg-list">${affected.map((id) => `<li>${hashChip(id)} `
          + `${verificationChip('UNVERIFIABLE_REDACTED')}</li>`).join('')}</ul>`
      : '',
    `<p class="crg-prose">A redaction removes content and leaves a tombstone. The object is `
    + `gone; the fact that it existed, and that it was removed by a named authority for a `
    + `recorded reason, is not (17.2).</p>`,
    field('redact-hash', 'Object to redact', {
      value: (state.form && state.form.redactHash) || '',
      hint: 'The content hash of the object to remove. This cannot be undone.',
    }),
    field('redact-reason', 'Reason', {
      value: (state.form && state.form.redactReason) || '',
      hint: 'Recorded on the tombstone and readable forever.',
      required: true,
    }),
    field('redact-authority', 'Authority', {
      value: (state.form && state.form.redactAuthority) || '',
      hint: 'Who authorises the removal (17.2, 44.7).',
      required: true,
    }),
    `<div class="crg-actions">${action('redact', 'Redact this object', {
      operation: 'redactObject', tone: 'danger',
    })}</div>`,
  ]), { tone: tombstones.length ? 'warn' : 'neutral' });
}

function approvalsPanel(state) {
  const approvals = state.approvals || ((state.data || {}).case || {}).approvals || [];
  if (!approvals.length) {
    return panel('Approvals', emptyState(
      'No approvals are recorded. An approval is a signed statement by a named person that '
      + 'a specific certificate may be relied on; the absence of one is not a rejection.',
    ));
  }
  return table('Approvals', [
    { label: 'Certificate' },
    { label: 'Approver' },
    { label: 'Role' },
    { label: 'When' },
    { label: 'Signature' },
  ], approvals.map((approval) => ({
    cells: [
      hashChip(approval.certificate_id),
      approval.approver ? esc(approval.approver) : absent(),
      approval.role ? esc(approval.role) : absent(),
      approval.approved_at ? esc(approval.approved_at) : absent(),
      approval.signature ? hashChip(approval.signature)
        : `<span class="crg-unmapped">Unsigned</span>`,
    ],
  })));
}

function migrationPanel(state) {
  const record = (state.data || {}).case || {};
  const migrationRecords = [...(record.migrations || []), ...(record.migration_records || [])]
    .filter((item, index, all) => item && all.findIndex((candidate) => (
      candidate && candidate.migration_id === item.migration_id
    )) === index);
  return panel('Schema version and migration', join([
    definitionList([
      ['Schema version', record.schema_version ? esc(record.schema_version) : absent()],
      ['Migration history', migrationRecords.length
        ? `<ul class="crg-list">${migrationRecords.map((m) => `<li>`
          + `${esc(m.source_schema_version || m.from || '')} to `
          + `${esc(m.target_schema_version || m.to || '')}, class `
          + `<code class="crg-code">${esc(m.migration_class || '')}</code>`
          + `${m.transform_id ? ` via <code class="crg-code">${esc(m.transform_id)}</code>` : ''}`
          + `${m.classification_verified === true
            ? ` — independently checkable proof ${hashChip(m.classification_proof_hash)}`
            : ' — classification proof not verified'}</li>`).join('')}</ul>`
        : '<span class="crg-prose">This case has never been migrated.</span>'],
    ]),
    `<p class="crg-prose">A certificate is pinned to the schema version it was issued under. `
    + `The selected transform—not this form—owns the semantic class. The class field is only `
    + `an assertion and a mismatch is refused. No certificate is inherited: even the registered `
    + `identity path leaves it pending re-verification (15.2, 15.5).</p>`,
    `<div class="crg-actions">${action('migrate', 'Migrate this case', {
      operation: 'migrateCase', tone: 'secondary',
      fields: ['target_schema_version', 'transform_id', 'migration_class', 'authority'],
    })}</div>`,
  ]));
}

function exportPanel(state) {
  const form = state.form || {};
  const last = state.lastAction || {};
  const audit = last.operation === 'exportAudit' ? last.result : null;
  const auditResult = audit ? disclosure(
    'Last security-audit export',
    definitionList([
      ['Tenant', esc(audit.tenant_id || '')],
      ['Entries in page', esc(String((audit.range || {}).entry_count || 0))],
      ['Next cursor', esc(String((audit.range || {}).next_after_sequence ?? -1))],
      ['More pages', (audit.range || {}).has_more ? 'Yes' : 'No'],
      ['Checkpoint', audit.checkpoint_status === 'SIGNED'
        ? `${verificationChip('UNVERIFIED')} Signature present; verify it offline with the trusted public key.`
        : `${verificationChip('UNVERIFIED')} Unsigned; internal consistency only.`],
      ['Artifact hash', hashChip(audit.artifact_hash)],
    ])
      + `<p class="crg-prose">${esc(audit.verification_scope || '')}</p>`,
    { open: true, principle: 'verified-or-replay' },
  ) : '';
  return panel('Leave with the evidence', join([
    `<p class="crg-prose">Export a portable <code class="crg-code">.crg</code> bundle and `
    + `verify it yourself with <code class="crg-code">crg-verify</code>, which needs no `
    + `server, no database, and no network (25.1, 39). A case that can only be read through `
    + `this interface is a case you are trusting this interface about.</p>`,
    `<div class="crg-actions">`
    + `<a class="crg-button crg-button--primary" data-action="export-bundle" `
    + `href="${esc(state.exportHref || '#')}" download>Download the portable bundle`
    + `</a>`
    + action('reload-events', 'Reload the event log', { operation: 'listEvents', tone: 'secondary' })
    + `</div>`,
    `<hr>`,
    `<p class="crg-prose"><strong>Export the security authorization chain.</strong> `
    + `This tenant-scoped JSON is bounded and resumable. Internal hash consistency does not `
    + `prove the host did not rewrite history; require a signed or independently published `
    + `checkpoint for that stronger claim (44.7).</p>`,
    auditResult,
    field('audit-authority', 'Records authority', {
      value: form['audit-authority'] || '', required: true,
      hint: 'The accountable authority receiving this evidence; it is recorded in the artifact.',
    }),
    field('audit-after-sequence', 'After sequence', {
      value: form['audit-after-sequence'] || '-1',
      hint: 'Use -1 for the first page, then the exact next cursor returned by the prior page.',
    }),
    field('audit-limit', 'Maximum entries', {
      value: form['audit-limit'] || '100',
      hint: 'A bounded integer from 1 through 1000.',
    }),
    `<div class="crg-actions">${action('export-audit', 'Download security audit evidence', {
      operation: 'exportAudit', tone: 'secondary',
      fields: ['audit-authority', 'audit-after-sequence', 'audit-limit'],
    })}</div>`,
  ]), { principle: 'verified-or-replay' });
}

function webhookPanel(state) {
  return panel('Signed event delivery', join([
    `<p class="crg-prose">Register an HTTPS receiver for signed case and governance events. The shared secret is submitted once over this authenticated connection and is never written to browser storage.</p>`,
    field('webhook-request', 'Webhook subscription', {
      multiline: true, rows: 8,
      value: (state.form && state.form['webhook-request']) || '',
      hint: 'JSON with endpoint, a 32-byte-or-longer secret, selected events, and optional retry policy.',
    }),
    field('webhook-subscription', 'Subscription ID to remove', {
      value: (state.form && state.form['webhook-subscription']) || '',
    }),
    `<div class="crg-actions">`
    + action('create-webhook', 'Register receiver', { operation: 'createWebhookSubscription' })
    + action('list-webhooks', 'List receivers', { operation: 'listWebhookSubscriptions', tone: 'secondary' })
    + action('delete-webhook', 'Remove receiver', { operation: 'deleteWebhookSubscription', tone: 'danger' })
    + `</div>`,
  ]));
}

export const workspace = {
  ...meta,
  render(state = {}) {
    const payload = state.data || {};
    const events = payload.events || [];
    const certificates = payload.certificates || [];
    if (!events.length && !certificates.length && !payload.case) {
      return shell(meta, join([
        exportPanel(state),
        retentionPanel(state),
        webhookPanel(state),
        notYet('No case is open, so there is no history to audit.'),
      ]), state);
    }
    return shell(meta, join([
      exportPanel(state),
      retentionPanel(state),
      webhookPanel(state),
      certificateTable(certificates),
      approvalsPanel(state),
      redactionPanel(state),
      migrationPanel(state),
      eventTable(events),
      disclosure('Event log as stored', `<pre class="crg-pre" tabindex="0" role="group" `
        + `aria-label="Event log">${esc(JSON.stringify(events, null, 2))}</pre>`,
      { principle: 'why' }),
    ]), state);
  },
};

export default workspace;
