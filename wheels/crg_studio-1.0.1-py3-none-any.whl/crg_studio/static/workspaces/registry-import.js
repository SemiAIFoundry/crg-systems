/**
 * Registry Import (spec 41.1): mapping, units, evidence, warnings,
 * duplicates, and import report.
 *
 * Import is where a case acquires most of its ways to be wrong, so this
 * workspace is deliberately pessimistic.  An unmapped source column is shown
 * as unmapped and never defaulted; a row whose coordinate had no value is
 * shown absent and never zero (41.2); and the completeness basis that import
 * produced is shown next to the warnings that qualify it, because
 * `EXPLICIT_IMPORTED_FAMILY` is exactly the basis that a hurried reader
 * mistakes for a complete one.
 */

import {
  absent, completenessPanel, definitionList, emptyState, esc, evidenceBadge, evidenceLegend,
  hashChip, join, panel, quantity, table,
} from '../render.js';
import { action, field, notYet, shell } from '../workspace.js';

const meta = {
  id: 'registry-import',
  title: 'Registry Import',
  purpose: 'Mapping, units, evidence, warnings, duplicates, and import report.',
  endpoints: ['importRegistry', 'importBundle', 'getJob', 'getJobResult'],
};

function mappingTable(mapping) {
  const rows = Object.entries(mapping || {});
  if (!rows.length) {
    return emptyState('No column mapping is recorded for this import.');
  }
  return table('How source columns were mapped', [
    { label: 'Source column' },
    { label: 'Coordinate' },
    { label: 'Unit', hint: 'Every dimensioned quantity carries a unit profile (13.1).' },
    { label: 'Evidence class' },
  ], rows.map(([source, target]) => ({
    cells: [
      `<code class="crg-code">${esc(source)}</code>`,
      target && target.coordinate
        ? `<code class="crg-code">${esc(target.coordinate)}</code>`
        : `<span class="crg-unmapped">Not mapped — this column was not imported</span>`,
      target && target.unit ? esc(target.unit) : absent('NOT_APPLICABLE'),
      evidenceBadge((target && target.evidence_class) || 'IMPORTED'),
    ],
  })));
}

function warningsPanel(report) {
  const warnings = report.warnings || [];
  const duplicates = report.duplicates || [];
  const rejected = report.rejected || [];
  return panel('What import could not do cleanly', join([
    warnings.length
      ? `<h4 class="crg-subtitle">Warnings</h4><ul class="crg-list">`
        + warnings.map((w) => `<li>${esc(typeof w === 'string' ? w : JSON.stringify(w))}</li>`).join('')
        + `</ul>`
      : '<p class="crg-prose">No warnings were raised.</p>',
    duplicates.length
      ? `<h4 class="crg-subtitle">Duplicates</h4><ul class="crg-list">`
        + duplicates.map((d) => `<li>${esc(typeof d === 'string' ? d : JSON.stringify(d))}</li>`).join('')
        + `</ul><p class="crg-prose">Duplicates were kept as distinct records rather than `
        + `merged. Merging them would be a semantic judgment the importer is not allowed `
        + `to make silently (6.9).</p>`
      : '<p class="crg-prose">No duplicate candidates were detected.</p>',
    rejected.length
      ? `<h4 class="crg-subtitle">Rejected rows</h4><ul class="crg-list">`
        + rejected.map((r) => `<li>${esc(typeof r === 'string' ? r : JSON.stringify(r))}</li>`).join('')
        + `</ul><p class="crg-prose">A rejected row is recorded, not dropped. 6.11 forbids `
        + `silent truncation, so the count above and the registry disagree on purpose.</p>`
      : '<p class="crg-prose">No rows were rejected.</p>',
  ]), { tone: warnings.length || rejected.length ? 'warn' : 'neutral' });
}

function importedRows(report) {
  const records = report.records || report.realizations || [];
  if (!records.length) return emptyState('No candidate records are listed in this report.');
  const coordinates = report.coordinates || [];
  return table('Imported candidates', [
    { label: 'Candidate' },
    ...coordinates.map((c) => ({ label: c.identifier || String(c), hint: c.unit || '' })),
    { label: 'Evidence class' },
  ], records.map((record) => ({
    attributes: ` data-realization="${esc(record.realization_id || '')}"`,
    cells: [
      `<span class="crg-realization__name">${esc(record.realization_id || '')}</span>`,
      ...coordinates.map((c, index) => {
        const identifier = c.identifier || String(c);
        const values = record.values || {};
        const value = values[identifier] !== undefined
          ? values[identifier]
          : (record.signature || [])[index];
        return quantity(value, { unit: c.unit || '' });
      }),
      evidenceBadge(record.evidence_class || 'IMPORTED'),
    ],
  })));
}

function importForm(state) {
  return panel('Import a registry', join([
    field('import-source', 'Source identifier', {
      value: (state.form && state.form.sourceId) || '',
      hint: 'Who or what this family came from. Recorded on every imported record (33.2).',
    }),
    field('import-payload', 'Import request', {
      multiline: true, rows: 10,
      value: (state.form && state.form.payload) || '',
      hint: 'The typed import request of specification 37. Studio sends it unchanged; '
        + 'it does not rewrite your mapping.',
    }),
    `<div class="crg-actions">`
    + action('import-registry', 'Import into this case', { operation: 'importRegistry' })
    + action('import-bundle', 'Import a portable .crg bundle instead', {
      operation: 'importBundle', tone: 'secondary',
    })
    + `</div>`,
  ]));
}

export const workspace = {
  ...meta,
  render(state = {}) {
    const report = (state.data || {}).import_report || (state.data || {}).report || null;
    if (!report) {
      return shell(meta, join([
        importForm(state),
        notYet('Nothing has been imported into this case yet.'),
      ]), state);
    }
    return shell(meta, join([
      importForm(state),
      panel('Import report', definitionList([
        ['Source', report.source_id ? esc(report.source_id) : absent()],
        ['Source hash', report.source_hash ? hashChip(report.source_hash) : absent()],
        ['Candidates accepted', report.accepted !== undefined
          ? esc(String(report.accepted)) : absent()],
        ['Candidates rejected', (report.rejected || []).length
          ? esc(String((report.rejected || []).length)) : 'None'],
        ['Registry hash', report.registry_hash ? hashChip(report.registry_hash) : absent()],
      ])),
      completenessPanel(report.completeness),
      mappingTable(report.mapping),
      warningsPanel(report),
      importedRows(report),
      panel('How to read the evidence badges', evidenceLegend(),
        { principle: 'evidence-classes' }),
    ]), state);
  },
};

export default workspace;
