/**
 * The workspace manifest: specification 41.1, verbatim and in order.
 *
 * Kept in its own module so that the navigation, the module loader, and the
 * test suite all read the same list.  The Python package carries the same
 * table in `crg_studio.WORKSPACES`, and `tests/test_studio.py` asserts the
 * two agree and that every entry has a module on disk — a workspace cannot
 * be quietly dropped from the product by editing one of the three places.
 */

export const WORKSPACES = [
  { id: 'case-setup', title: 'Case Setup', group: 'Prepare', step: 1,
    purpose: 'Source, contracts, hierarchy, packs, completeness, and branch selection' },
  { id: 'registry-import', title: 'Registry Import', group: 'Prepare', step: 2,
    purpose: 'Mapping, units, evidence, warnings, duplicates, and import report' },
  { id: 'realization-explorer', title: 'Realization Explorer', group: 'Model', step: 3,
    purpose: 'Legal and rejected candidates, fibers, parentage, choices, and witnesses' },
  { id: 'obligation-explorer', title: 'Obligation Explorer', group: 'Model', step: 4,
    purpose: 'Typed coordinates, units, accounting, scopes, and uncertainty' },
  { id: 'geometry-phase-view', title: 'Geometry and Phase View', group: 'Decide', step: 5,
    purpose: 'R, Gamma, K, envelopes, ledgers, boundaries, and ties' },
  { id: 'decision-query', title: 'Decision Query', group: 'Decide', step: 6,
    purpose: 'Query authoring, derivation, required object, and refusal explanations' },
  { id: 'decision-center', title: 'Decision Center', group: 'Decide', step: 7,
    purpose: 'Winners, possible winners, retained alternatives, margins, pruning, regret, and claim scope' },
  { id: 'completeness-center', title: 'Completeness Center', group: 'Decide', step: 8,
    purpose: 'Family basis, known omissions, bounds, truncation, and claim implications' },
  { id: 'change-impact', title: 'Change Impact', group: 'Evolve', step: 9,
    purpose: 'Before-and-after differences, typed edges, preserved claims, and required action' },
  { id: 'evidence-graph', title: 'Evidence Graph', group: 'Evolve', step: 10,
    purpose: 'Source context, applicability, uncertainty, conflict, and lineage' },
  { id: 'qualification-planner', title: 'Qualification Planner', group: 'Evolve', step: 11,
    purpose: 'Desired state, thresholds, experiments, burden, and stopping' },
  { id: 'conversion-planner', title: 'Conversion Planner', group: 'Evolve', step: 12,
    purpose: 'Ownership maps, retained regions, residual transfers, and schedules' },
  { id: 'physical-feedback', title: 'Physical Feedback', group: 'Evolve', step: 13,
    purpose: 'Evaluator requests, results, evidence classes, and witness refinement' },
  { id: 'verification-center', title: 'Verification Center', group: 'Govern', step: 14,
    purpose: 'Verification level, proof status, failures, expiry, and signatures' },
  { id: 'federation-center', title: 'Federation Center', group: 'Govern', step: 15,
    purpose: 'Capability envelopes, requests, release policies, and revocation' },
  { id: 'branch-merge', title: 'Branch and Merge', group: 'Govern', step: 16,
    purpose: 'Divergence, reconciliation, conflict resolution, and certificate effect' },
  { id: 'audit-approval', title: 'Audit and Approval', group: 'Govern', step: 17,
    purpose: 'Object history, signatures, approvals, redactions, and exports' },
];

/** Specification 41.2, one entry per MUST, in the order the spec lists them. */
export const UX_PRINCIPLES = [
  ['why', 'Explain why a result exists',
    'Every decision on screen links to its derivation record, the rule it cited, and what it depends on.'],
  ['claim-scope', 'Show the scope of every claim',
    'A claim scope is rendered inside the same element as the realization it qualifies, always.'],
  ['completeness', 'Show the completeness basis',
    'What was covered, what was not, and what that costs the claim.'],
  ['evidence-classes', 'Keep the evidence classes distinct',
    'Exact, constructive, bounded, measured, modeled, imported, declared, and heuristic each carry '
    + 'their own label, glyph, and pattern. Colour is never the only signal.'],
  ['tie-vs-ambiguity', 'Distinguish a tie from ambiguity',
    'A proven tie will not be separated by more evidence. An ambiguous result will. They are '
    + 'different words, different tones, and different next steps.'],
  ['no-zero', 'Never show an absent value as zero',
    'An absent coordinate renders as a dash with its reason. It never renders as a number.'],
  ['all-infeasible', 'Preserve all-infeasible states',
    'When nothing satisfies the requirement, the least-bad candidate is not promoted to an answer.'],
  ['margins', 'Show what would have to change',
    'The closest rival, its recorded margin, and the active bottlenecks named by the certificate. '
    + 'Phase-boundary claims require separate phase-analysis evidence.'],
  ['resolving-evidence', 'Show what would resolve the uncertainty',
    'The experiment ranked most capable of narrowing the result, and what it would settle.'],
  ['verified-or-replay', 'Say whether a result is verified or merely replayable',
    'An independently checked certificate and a reproducible run are different claims.'],
  ['keyboard', 'Work from the keyboard',
    'Skip link, arrow-key workspace navigation, visible focus, and focus moved to the content '
    + 'when a workspace opens.'],
  ['plain-language', 'Do not require the notation',
    'Every symbol is introduced by its plain-language name; the symbol is secondary.'],
];

export default WORKSPACES;
