"""Producer-side derivation for authority-bound continued validity.

The independent copy lives in :mod:`crg_verify.lifecycle`.  Keeping this copy
in the producer package ensures the verifier does not author the result it is
asked to check.
"""
from __future__ import annotations

import datetime as dt
from typing import Any, Dict, Mapping, Sequence

from crg_model.canonical import content_hash, is_hash


DIMENSIONS = (
    "EVIDENCE_VALIDITY", "VERIFIER_TIME", "DEPENDENCY_STATUS", "CHANGE_EVENTS",
    "REVOCATION", "REDACTION", "MIGRATION", "BRANCH_STATE", "SUPERSESSION",
    "APPROVALS",
)


def _instant(value: Any) -> dt.datetime | None:
    if not isinstance(value, str) or not value:
        return None
    try:
        parsed = dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=dt.timezone.utc)


def _expiry(source: Mapping[str, Any]) -> dt.datetime | None:
    artifact = source["artifact"]
    value = artifact.get("expiry")
    if value is None and isinstance(artifact.get("validity"), Mapping):
        value = artifact["validity"].get("expires_at")
    return _instant(value)


def _now(source: Mapping[str, Any]) -> dt.datetime | None:
    authority = source["authority_snapshot"]
    return _instant((authority.get("clock") or {}).get("verifier_evaluation_time"))


def _roots(value: Any) -> tuple[str, ...] | None:
    if not isinstance(value, (list, tuple)):
        return None
    result = tuple(str(item) for item in value)
    return result if all(is_hash(item) for item in result) else None


def _identifiers(value: Any) -> tuple[str, ...] | None:
    if not isinstance(value, (list, tuple)):
        return None
    result = tuple(str(item) for item in value)
    if any(not item for item in result) or len(set(result)) != len(result):
        return None
    return result


def _derive(name: str, source: Mapping[str, Any]) -> tuple[str, str]:
    artifact = source["artifact"]
    artifact_status = str(source["artifact_status"])
    if name == "EVIDENCE_VALIDITY":
        roots = _roots(artifact.get("evidence_roots"))
        if roots is None:
            return "INDETERMINATE", "artifact omits an explicit evidence-root inventory"
        statuses = source["evidence_statuses"]
        missing = [root for root in roots if root not in statuses]
        if missing:
            return "UNAVAILABLE", f"evidence status is unavailable for {missing}"
        values = {statuses[root] for root in roots}
        if "REVOKED" in values:
            return "REVOKED", "at least one bound evidence object is revoked"
        if values.intersection({"REDACTED", "UNVERIFIABLE_REDACTED"}):
            return "REDACTED", "at least one bound evidence object is redacted"
        if values - {"ACTIVE"}:
            return "INDETERMINATE", f"evidence has non-current statuses {sorted(values - {'ACTIVE'})}"
        expiry, now = _expiry(source), _now(source)
        if expiry is None:
            return "INDETERMINATE", "artifact has no verifier-evaluable expiry assertion"
        if now is None:
            return "INDETERMINATE", "deployment verifier clock is unavailable"
        if now > expiry:
            return "EXPIRED", "artifact expiry precedes the deployment verifier clock"
        return "CURRENT", f"all {len(roots)} explicit evidence roots are active and the artifact is unexpired"
    if name == "VERIFIER_TIME":
        trust = (source["authority_snapshot"].get("clock") or {}).get("verifier_clock_trust_level")
        expiry, now = _expiry(source), _now(source)
        if trust not in {"SYNCHRONIZED", "ATTESTED"}:
            return "TIME_INDETERMINATE", "deployment clock is not synchronized or attested"
        if expiry is None:
            return "TIME_INDETERMINATE", "artifact has no expiry for the verifier clock to judge"
        if now is None:
            return "TIME_INDETERMINATE", "deployment verifier clock is unavailable"
        return ("EXPIRED", "artifact is expired at the deployment verifier clock") if now > expiry else ("CURRENT", "deployment-approved verifier clock places the artifact inside validity")
    if name == "DEPENDENCY_STATUS":
        # DecisionCertificate.dependencies are governed realization/object
        # identities, not necessarily content hashes.  Requiring hashes here
        # would make every ordinary certificate permanently indeterminate.
        roots = _identifiers(artifact.get("dependencies"))
        if roots is None:
            return "INDETERMINATE", "artifact omits an explicit dependency inventory"
        statuses = source["dependency_statuses"]
        missing = [root for root in roots if root not in statuses]
        if missing:
            return "INDETERMINATE", f"dependency status is absent for {missing}"
        values = {statuses[root] for root in roots}
        if values.intersection({"REVOKED", "REDACTED", "UNVERIFIABLE_REDACTED", "BLOCKED"}):
            return "BLOCKED", "a bound dependency is revoked, redacted, unavailable, or blocked"
        if values.intersection({"STALE", "SUPERSEDED"}):
            return "STALE", "a bound dependency is stale or superseded"
        if values - {"ACTIVE"}:
            return "INDETERMINATE", f"dependencies have unknown statuses {sorted(values - {'ACTIVE'})}"
        return "CURRENT", f"all {len(roots)} explicitly bound dependencies are active"
    if name == "CHANGE_EVENTS":
        case = source["case"]
        if case.get("deltas") is None or case.get("history") is None:
            return "BLOCKED", "canonical case omits delta or history evidence"
        history_changed = bool(case.get("deltas")) or any(
            isinstance(item, Mapping)
            and str(item.get("operation") or "") in {
                "change", "merge", "migrate", "redact", "classify-change",
            }
            for item in case.get("history") or ()
        )
        audit_events = source.get("audit_events")
        if not isinstance(audit_events, (list, tuple)):
            return "BLOCKED", "canonical audit evidence is unavailable"
        audit_changed = any(
            isinstance(item, Mapping)
            and str(item.get("event") or "") in {
                "case.merged", "case.migrated", "case.redacted", "case.reopened",
                "change.classified", "certificate.stale", "evidence.expired",
                "evidence.retired", "object.redacted", "object.revoked",
            }
            for item in audit_events
        )
        changed = history_changed or audit_changed
        return ("REVALIDATION_REQUIRED", "canonical delta/history or audit evidence records a decision-relevant change") if changed else ("NONE", "canonical delta/history and audit evidence contain no decision-relevant change")
    if name == "REVOCATION":
        if artifact_status == "REVOKED":
            return "REVOKED", "artifact object status is REVOKED"
        if artifact_status in {"ACTIVE", "STALE", "SUPERSEDED", "REDACTED", "UNVERIFIABLE_REDACTED"}:
            return "NOT_REVOKED", f"artifact status {artifact_status} is not revocation"
        return "UNKNOWN", f"revocation cannot be derived from status {artifact_status!r}"
    if name == "REDACTION":
        if artifact_status == "REDACTED":
            return "REDACTED", "artifact object status is REDACTED"
        if artifact_status == "UNVERIFIABLE_REDACTED":
            return "UNVERIFIABLE_REDACTED", "artifact support is redacted without sufficient proof"
        if artifact_status in {"ACTIVE", "STALE", "SUPERSEDED", "REVOKED"}:
            return "AVAILABLE", f"artifact bytes remain available with status {artifact_status}"
        return "UNKNOWN", f"availability cannot be derived from status {artifact_status!r}"
    if name == "MIGRATION":
        related = [
            item for item in source["migration_records"]
            if isinstance(item, Mapping)
            and source["artifact_root"] in {
                item.get("source_object_hash"), item.get("transformed_object_hash"),
                item.get("lifecycle_record_hash"),
            }
        ]
        if not related:
            return "ORIGINAL", "canonical migration inventory contains no related migration"
        latest = related[-1]
        if latest.get("migration_class") == "SEMANTICALLY_EQUIVALENT" and latest.get("disposition") == "UNCHANGED_LIFECYCLE_REVERIFIED" and latest.get("substantive_artifact_reissued") is False:
            return "SEMANTICALLY_EQUIVALENT_VERIFIED", "registered equivalent migration and lifecycle replay are present"
        if latest.get("migration_class") in {"LOSSY", "SEMANTICALLY_DIFFERENT"}:
            return "LOSSY", "latest related migration is lossy or semantically different"
        return "UNVERIFIED", "related migration lacks registered equivalence and independent replay"
    if name == "BRANCH_STATE":
        case, branch = source["case"], source["case"].get("branch_id")
        if not isinstance(branch, str) or not branch:
            return "UNKNOWN", "canonical case omits branch identity"
        if any(isinstance(item, Mapping) and item.get("automatic") is False for item in case.get("merge_decisions") or ()):
            return "MERGE_RECONCILIATION_REQUIRED", "canonical merge record has unresolved semantic conflict"
        return ("LINEAR_CURRENT", "case is the current linear main branch") if branch == "main" and not (case.get("parent_case_refs") or []) else ("BRANCHED_CURRENT", f"case is on explicit branch {branch!r} without unresolved conflict")
    if name == "SUPERSESSION":
        if artifact_status == "SUPERSEDED":
            return "SUPERSEDED", "artifact object status is SUPERSEDED"
        if artifact_status in {"ACTIVE", "STALE", "REVOKED", "REDACTED", "UNVERIFIABLE_REDACTED"}:
            return "CURRENT", f"artifact has not been marked superseded (status {artifact_status})"
        return "UNKNOWN", f"supersession cannot be derived from status {artifact_status!r}"
    if name == "APPROVALS":
        record, envelope = source.get("authorization_record"), source.get("authorization_inputs")
        if record is None or envelope is None:
            return "INDETERMINATE", "no deployment-authority-bound lifecycle authorization is present"
        if not isinstance(record, Mapping) or not isinstance(envelope, Mapping):
            return "INDETERMINATE", "lifecycle authorization evidence is malformed"
        if envelope.get("record_hash") != content_hash(record):
            return "SIGNATURE_UNVERIFIED", "authorization envelope is bound to different bytes"
        if envelope.get("verifier_operation") != "verify_lifecycle_authorization_v2":
            return "SIGNATURE_UNVERIFIED", "authorization was not produced by authority replay v2"
        if record.get("artifact_hash") != source["artifact_root"]:
            return "MISSING", "authorization applies to a different artifact"
        if record.get("authorized") is True:
            return "CURRENT", "deployment policy, authenticated principals, and cryptographic approvals authorize this artifact"
        if record.get("separation_failures"):
            return "SEPARATION_OF_DUTIES_FAILED", "authorization fails separation of duties"
        reasons = list(record.get("rejected_approvals") or ())
        if any("WITHDRAWN" in str(item) for item in reasons):
            return "WITHDRAWN", "a required approval is withdrawn"
        if any("EXPIRED" in str(item) for item in reasons):
            return "EXPIRED", "a required approval is expired"
        return "MISSING", "authorization lacks required active approvals"
    raise ValueError(f"unregistered continued-validity dimension {name!r}")


def derive_continued_validity_dimensions(source: Mapping[str, Any]) -> tuple[Dict[str, Any], ...]:
    """Derive direct states; caller-supplied dimension declarations are unused."""

    if not isinstance(source, Mapping):
        raise ValueError("continued-validity canonical source must be an object")
    for field, value in (("case", source.get("case")), ("artifact", source.get("artifact"))):
        if not isinstance(value, Mapping) or source.get(f"{field}_root") != content_hash(value):
            raise ValueError(f"continued-validity {field} root does not match canonical bytes")
    if source.get("audit_root") != content_hash(source.get("audit_events")):
        raise ValueError("continued-validity audit root does not match canonical events")
    result = []
    for name in DIMENSIONS:
        state, detail = _derive(name, source)
        result.append({
            "name": name,
            "state": state,
            "source_hash": content_hash({"dimension": name, "canonical_validity_source": source}),
            "detail": detail,
        })
    return tuple(result)
