"""Local product boundary for domain-pack and source-adapter assurance.

These operations deliberately sit beside external engineering systems.  Pack
authoring validates declaration-only JSON and never executes extensions.
Source-adapter verification consumes caller-supplied portable bytes and never
contacts an originating server.  Neither path grants permissions, establishes
source truth, changes case state, or authorizes a CRG decision.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Mapping

import crg_generate
import crg_verify


__all__ = [
    "ExtensionSurfaceError",
    "validate_pack_manifest",
    "assure_first_party_packs",
    "verify_source_adapter_definition_file",
    "verify_source_adapter_output_files",
    "verify_source_adapter_report_file",
    "render_pack_authoring_report",
    "render_first_party_pack_assurance",
    "render_source_adapter_verification",
]


class ExtensionSurfaceError(ValueError):
    """A portable extension input could not be read or was the wrong type."""


class _DuplicateMember(ValueError):
    pass


def _closed_object(pairs):
    result: Dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise _DuplicateMember(f"duplicate JSON object member {key!r}")
        result[key] = value
    return result


def _json_object(path: str | Path, what: str) -> Dict[str, Any]:
    location = Path(path)
    try:
        value = json.loads(
            location.read_text(encoding="utf-8"),
            object_pairs_hook=_closed_object,
        )
    except (OSError, UnicodeDecodeError, json.JSONDecodeError, _DuplicateMember) as error:
        raise ExtensionSurfaceError(f"could not read {what}: {error}") from error
    if not isinstance(value, dict):
        raise ExtensionSurfaceError(f"{what} must be a JSON object")
    return value


def _bytes(path: str | Path, what: str) -> bytes:
    try:
        return Path(path).read_bytes()
    except OSError as error:
        raise ExtensionSurfaceError(f"could not read {what}: {error}") from error


def validate_pack_manifest(path: str | Path) -> Dict[str, Any]:
    """Validate one exact manifest byte sequence without executing extensions."""

    source = _bytes(path, "pack manifest")
    report = crg_generate.validate_pack_manifest_json(source)
    record = report.to_canonical()
    verification = crg_verify.verify_pack_authoring_report(record, source)
    return {
        "record": record,
        "record_hash": report.report_hash(),
        "verification": verification.to_json(),
        "accepted": report.accepted and verification.ok,
        "authorization_effect": "NONE",
        "execution_performed": False,
    }


def assure_first_party_packs() -> Dict[str, Any]:
    """Run the executable obligation-effect assurance over all shipped packs."""

    report = crg_generate.build_first_party_pack_assurance_report()
    record = report.to_canonical()
    return {
        "record": record,
        "record_hash": report.report_hash(),
        "assured": report.assured,
        "authorization_effect": "NONE",
        "external_plugin_conformance_established": False,
    }


def verify_source_adapter_definition_file(path: str | Path) -> Dict[str, Any]:
    record = _json_object(path, "source-adapter definition")
    result = crg_verify.verify_source_adapter_definition(record)
    return {
        "record_type": "SourceAdapterDefinition",
        "verification": result.to_json(),
        "authorization_effect": "NONE",
        "source_truth_established": False,
    }


def verify_source_adapter_output_files(
    record_path: str | Path,
    definition_path: str | Path,
    original_source_path: str | Path,
    normalized_source_path: str | Path,
) -> Dict[str, Any]:
    record = _json_object(record_path, "source-adapter output")
    definition = _json_object(definition_path, "source-adapter definition")
    original = _bytes(original_source_path, "original source snapshot")
    normalized = _bytes(normalized_source_path, "normalized source snapshot")
    result = crg_verify.verify_source_adapter_output(
        record,
        definition,
        original_source=original,
        normalized_source=normalized,
    )
    return {
        "record_type": "SourceAdapterOutput",
        "verification": result.to_json(),
        "original_source_bytes": len(original),
        "normalized_source_bytes": len(normalized),
        "authorization_effect": "NONE",
        "source_truth_established": False,
        "originating_server_contacted": False,
    }


def verify_source_adapter_report_file(path: str | Path) -> Dict[str, Any]:
    record = _json_object(path, "source-adapter conformance report")
    result = crg_verify.verify_source_adapter_conformance_report(record)
    return {
        "record_type": "SourceAdapterConformanceReport",
        "verification": result.to_json(),
        "authorization_effect": "NONE",
        "source_truth_established": False,
        "fixture_execution_replayed": False,
    }


def render_pack_authoring_report(payload: Mapping[str, Any]) -> str:
    record = payload.get("record") or {}
    diagnostics = record.get("diagnostics") or []
    lines = [
        "Domain-pack authoring validation",
        f"  disposition       : {record.get('disposition', 'UNKNOWN')}",
        f"  specification     : {record.get('spec_version', 'unresolved')}",
        f"  manifest          : {record.get('manifest_identity') or 'unresolved'}",
        f"  manifest version  : {record.get('manifest_version') or 'unresolved'}",
        f"  source hash       : {record.get('source_hash', '')}",
        f"  manifest hash     : {record.get('manifest_hash') or 'not derived'}",
        f"  pack hash         : {record.get('pack_hash') or 'not derived'}",
        f"  diagnostics       : {len(diagnostics)}",
        f"  independently checked: {bool((payload.get('verification') or {}).get('ok'))}",
        "  extension executed: no",
        "  authority effect  : none",
    ]
    for item in diagnostics:
        if isinstance(item, Mapping) and item.get("status") == "REFUSED":
            lines.append(
                f"    REFUSED {item.get('code', '')} {item.get('path', '')}: "
                f"{item.get('message', '')}"
            )
    return "\n".join(lines)


def render_first_party_pack_assurance(payload: Mapping[str, Any]) -> str:
    record = payload.get("record") or {}
    return "\n".join(
        [
            "First-party domain-pack obligation assurance",
            f"  disposition       : {record.get('disposition', 'UNKNOWN')}",
            f"  reference packs   : {record.get('reference_pack_count', 0)}",
            (
                "  legality-affecting: "
                f"{record.get('legality_affecting_extractor_count', 0)}"
            ),
            f"  report hash       : {payload.get('record_hash', '')}",
            "  external plugins  : not covered",
            "  authority effect  : none",
        ]
    )


def render_source_adapter_verification(payload: Mapping[str, Any]) -> str:
    verification = payload.get("verification") or {}
    return "\n".join(
        [
            f"{payload.get('record_type', 'Source-adapter record')} verification",
            f"  status             : {verification.get('status', 'FAILED')}",
            f"  ok                 : {verification.get('ok', False)}",
            "  originating server : not contacted",
            "  source truth       : not established",
            "  authority effect   : none",
        ]
    )
