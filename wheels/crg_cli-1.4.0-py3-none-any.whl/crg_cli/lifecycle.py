"""Closed product boundary for the CRG decision lifecycle.

The lifecycle producers live in ``etq_qualify``, ``crg_convert`` and
``crg_feedback``.  This module gives the CLI, server, SDKs and Studio one
portable operation vocabulary without weakening those producer contracts.
Every operation derives content roots from supplied documents, calls the
registered producer, and then calls the independent ``crg_verify.lifecycle``
implementation before anything can be persisted.

The surface intentionally exposes direct states.  It does not manufacture a
confidence, readiness, health, ROI, or other synthetic score.  Legacy
signature-verification records remain integrity-only evidence *about* a
signature; authority v2 records are emitted only after the server has actually
replayed Ed25519 under its deployment-owned trust context.
"""
from __future__ import annotations

import copy
from typing import Any, Dict, Mapping, MutableMapping, Sequence, Tuple

import crg_verify
from crg_convert import (
    BufferingPlan,
    Cell,
    CompletionCheck,
    ConversionRecord,
    DecisionScopedConversion,
    DuplicationPolicy,
    LogicalSpace,
    ResidualRegion,
    RetainedIntersection,
    RouteStep,
    ScheduleWave,
    SecondaryReport,
    SolverEvidence,
    assess_conversion_binding,
    bind_conversion_to_decision,
)
from crg_feedback import (
    ApprovalRecord,
    ApprovalWithdrawal,
    ContinuedValidityView,
    LifecycleDimension,
    ReopenTrigger,
    SeparationOfDutiesPolicy,
    SignatureVerificationRecord,
    build_lifecycle_replay_record,
    evaluate_lifecycle_authorization,
    record_backup_restore_recovery,
    record_migration_reverification,
    resilience_verification_inputs,
)
from crg_model.canonical import canonical_json, content_hash
from crg_model.edges import DependencyEdge
from crg_model.numeric import Exact, Interval
from etq_evidence import (
    AccessPolicy,
    ContextDescriptor,
    EvidenceRecord,
    MethodDescriptor,
    Provenance,
    UncertaintyBudget,
    ValidityWindow,
    VerificationClock,
)
from etq_qualify import (
    BurdenDimension,
    BurdenVector,
    ETQDecisionLoop,
    ETQStepRecord,
    ExperimentResult,
    LoopArtifactRef,
    QualificationResult,
    QualificationState,
    ReplacementRecord,
    ResultIngestionRecord,
    SelectiveRevalidationRecord,
    TargetEvaluation,
    ingest_result_as_evidence,
    issue_replacement,
    plan_selective_revalidation,
    qualification_disposition,
)

from .store import CaseError, record_history
from .lifecycle_authority import derive_continued_validity_dimensions

__all__ = [
    "LIFECYCLE_OPERATIONS",
    "ETQ_LIFECYCLE_OPERATIONS",
    "DECISION_LIFECYCLE_OPERATIONS",
    "RESILIENCE_LIFECYCLE_OPERATIONS",
    "LIFECYCLE_RECORD_TYPES",
    "ETQ_LIFECYCLE_RECORD_TYPES",
    "DECISION_LIFECYCLE_RECORD_TYPES",
    "RESILIENCE_LIFECYCLE_RECORD_TYPES",
    "LIFECYCLE_INPUT_CONTRACTS",
    "LIFECYCLE_VERIFIER_CONTRACTS",
    "LifecycleVerificationError",
    "build_verified_lifecycle_record",
    "verify_lifecycle_record",
    "persist_lifecycle_record",
    "inspect_lifecycle_record",
    "portable_lifecycle_objects",
    "render_lifecycle_report",
]


ETQ_LIFECYCLE_OPERATIONS = (
    "CREATE_ETQ_LOOP",
    "APPEND_ETQ_STEP",
    "INGEST_RESULT",
    "PLAN_REVALIDATION",
    "ISSUE_REPLACEMENT",
    "QUALIFICATION_DISPOSITION",
)

_CORE_DECISION_LIFECYCLE_OPERATIONS = (
    "BIND_CONVERSION",
    "ASSESS_CONVERSION",
    "RECORD_SIGNATURE_VERIFICATION",
    "ISSUE_APPROVAL",
    "ISSUE_APPROVAL_WITHDRAWAL",
    "EVALUATE_LIFECYCLE_AUTHORIZATION",
    "BUILD_CONTINUED_VALIDITY",
)

RESILIENCE_LIFECYCLE_OPERATIONS = (
    "BUILD_LIFECYCLE_REPLAY",
    "RECORD_BACKUP_RESTORE_RECOVERY",
    "RECORD_MIGRATION_REVERIFICATION",
)

DECISION_LIFECYCLE_OPERATIONS = (
    _CORE_DECISION_LIFECYCLE_OPERATIONS + RESILIENCE_LIFECYCLE_OPERATIONS
)

LIFECYCLE_OPERATIONS = ETQ_LIFECYCLE_OPERATIONS + DECISION_LIFECYCLE_OPERATIONS

# OpenAPI consumes this exact authoring vocabulary.  Each value is
# ``(required_fields, optional_fields)``; carried canonical documents remain
# documents, while the operation-level input object is always closed.
LIFECYCLE_INPUT_CONTRACTS = {
    "CREATE_ETQ_LOOP": ((
        "loop_id", "target_decision_id", "predicate_id", "target_context",
        "declared_stopping_conditions",
    ), ()),
    "APPEND_ETQ_STEP": (("loop_id", "authority", "verification_basis"), (
        "artifacts", "refusal",
    )),
    "INGEST_RESULT": ((
        "result", "ingestion_id", "plan_id", "evidence_id", "method", "provenance",
        "validity", "access",
    ), ("evidence_status", "prior_evidence")),
    "PLAN_REVALIDATION": ((
        "record_id", "changed_source", "changed_properties", "dependency_edges",
        "artifact_universe", "dependency_completeness_basis",
    ), ()),
    "ISSUE_REPLACEMENT": ((
        "revalidation_record_id", "replacement_id", "prior_artifact_id",
        "replacement_artifact_id", "prior_artifact", "replacement_artifact",
        "verification_basis",
    ), ()),
    "QUALIFICATION_DISPOSITION": ((
        "qualification_result", "ingestions", "required_evidence_ids", "verification_basis",
    ), ("minimum_evidence_status",)),
    "BIND_CONVERSION": ((
        "conversion_record", "binding_id", "source_case", "target_case",
        "retained_geometry", "decision_scope", "decision_certificate",
        "retained_geometry_relation", "decision_scope_relation", "authority",
        "semantic_verifications",
    ), ("dependencies",)),
    "ASSESS_CONVERSION": ((
        "binding_id", "current_conversion_record", "current_retained_geometry",
        "current_decision_scope", "current_decision_certificate",
    ), ()),
    "RECORD_SIGNATURE_VERIFICATION": ((
        "verification_id", "signature_id", "signature_content", "signed_content",
    ), (
        "key_id", "algorithm", "verifier_id", "verifier_version", "checked_at",
        "verified", "failure_reason", "trusted_record_root",
    )),
    "ISSUE_APPROVAL": ((
        "approval_id", "artifact", "action", "role", "validity",
        "signature_verification",
    ), (
        "subject_id", "organization", "signed_at", "authority",
        "trusted_signature_roots", "signature_content",
    )),
    "ISSUE_APPROVAL_WITHDRAWAL": ((
        "withdrawal_id", "approval_id", "reason", "signature_verification",
    ), (
        "withdrawn_by", "occurred_at", "authority", "trusted_signature_roots",
        "signature_content",
    )),
    "EVALUATE_LIFECYCLE_AUTHORIZATION": ((
        "artifact", "action", "approval_ids", "withdrawal_ids",
    ), ("policy_id", "policy", "clock", "trusted_signature_roots")),
    "BUILD_CONTINUED_VALIDITY": ((
        "view_id", "case_id", "artifact_id", "artifact", "reopen_triggers",
        "trigger_sources", "dependencies",
    ), ("evaluated_at", "verifier_clock", "dimensions", "dimension_sources")),
    "BUILD_LIFECYCLE_REPLAY": ((
        "replay_id", "source_checkpoint", "records", "verification_inputs",
    ), ()),
    "RECORD_BACKUP_RESTORE_RECOVERY": ((
        "recovery_id", "source_snapshot", "backup_snapshot", "restored_snapshot",
        "replay_record", "replay_source_checkpoint", "replay_records",
        "replay_verification_inputs", "authority",
    ), ()),
    "RECORD_MIGRATION_REVERIFICATION": ((
        "reverification_id", "migration_record", "source_object", "transformed_object",
        "lifecycle_record", "lifecycle_verification_inputs", "authority",
    ), ()),
}

ETQ_LIFECYCLE_RECORD_TYPES = (
    "ETQDecisionLoop",
    "ResultIngestionRecord",
    "SelectiveRevalidationRecord",
    "ReplacementRecord",
    "QualificationDisposition",
)

_CORE_DECISION_LIFECYCLE_RECORD_TYPES = (
    "DecisionScopedConversion",
    "ConversionBindingImpact",
    "SignatureVerificationRecord",
    "ApprovalRecord",
    "ApprovalWithdrawal",
    "LifecycleAuthorization",
    "ContinuedValidityView",
)

RESILIENCE_LIFECYCLE_RECORD_TYPES = (
    "LifecycleReplayRecord",
    "BackupRestoreRecoveryRecord",
    "MigrationReverificationRecord",
)

DECISION_LIFECYCLE_RECORD_TYPES = (
    _CORE_DECISION_LIFECYCLE_RECORD_TYPES + RESILIENCE_LIFECYCLE_RECORD_TYPES
)

LIFECYCLE_RECORD_TYPES = ETQ_LIFECYCLE_RECORD_TYPES + DECISION_LIFECYCLE_RECORD_TYPES

_IDENTITY_FIELDS = {
    "ETQDecisionLoop": "loop_id",
    "ResultIngestionRecord": "ingestion_id",
    "SelectiveRevalidationRecord": "record_id",
    "ReplacementRecord": "replacement_id",
    "DecisionScopedConversion": "binding_id",
    "SignatureVerificationRecord": "verification_id",
    "ApprovalRecord": "approval_id",
    "ApprovalWithdrawal": "withdrawal_id",
    "ContinuedValidityView": "view_id",
    "LifecycleReplayRecord": "replay_id",
    "BackupRestoreRecoveryRecord": "recovery_id",
    "MigrationReverificationRecord": "reverification_id",
}

# These are derived judgments over state that may legitimately be evaluated
# again without mutating the prior judgment.  Their producers deliberately
# have no caller-chosen identity, so the exact record root is their portable
# immutable identity rather than a coarse plan/artifact alias.
_CONTENT_IDENTIFIED_RECORDS = frozenset(
    {"QualificationDisposition", "ConversionBindingImpact", "LifecycleAuthorization"}
)

_DIRECT_STATE_FIELDS = {
    "ETQDecisionLoop": ("complete", "refused", "next_step"),
    "SelectiveRevalidationRecord": ("state",),
    "QualificationDisposition": ("state", "stopping_condition"),
    "DecisionScopedConversion": ("ready_for_transition_planning",),
    "ConversionBindingImpact": ("status", "preserved_binding"),
    "SignatureVerificationRecord": ("verified",),
    "LifecycleAuthorization": ("authorized", "missing_roles", "separation_failures"),
    "ContinuedValidityView": ("status", "blocking_dimensions"),
    "LifecycleReplayRecord": ("replay_complete", "final_state_hash"),
    "BackupRestoreRecoveryRecord": (
        "integrity_status", "semantic_replay_required", "inventory_root",
    ),
    "MigrationReverificationRecord": (
        "migration_class", "disposition", "substantive_artifact_reissued",
    ),
}

_RECORD_WORKSTREAM = {
    **{record_type: "v1.3/ETQ_LIFECYCLE" for record_type in ETQ_LIFECYCLE_RECORD_TYPES},
    **{
        record_type: "v1.4/DECISION_LIFECYCLE"
        for record_type in DECISION_LIFECYCLE_RECORD_TYPES
    },
}

_VERIFIER_INPUT_FIELDS = {
    "verify_etq_decision_loop": frozenset(),
    "verify_result_ingestion_record": frozenset({"result_record", "new_evidence", "prior_evidence"}),
    "verify_selective_revalidation_record": frozenset({"dependency_edges", "artifact_universe"}),
    "verify_replacement_record": frozenset({
        "revalidation_record", "prior_artifact", "replacement_artifact",
        "dependency_edges", "artifact_universe",
    }),
    "verify_qualification_disposition": frozenset({
        "qualification_result", "ingestions", "required_evidence_ids",
        "verification_basis", "minimum_evidence_status",
    }),
    "verify_decision_scoped_conversion": frozenset({
        "conversion_record", "source_case", "target_case", "retained_geometry",
        "decision_scope", "decision_certificate", "semantic_verifications", "dependencies",
    }),
    "verify_conversion_binding_impact": frozenset({
        "binding", "current_conversion_record", "current_retained_geometry",
        "current_decision_scope", "current_decision_certificate",
    }),
    "verify_signature_verification_record": frozenset({
        "signature_content", "trusted_record_root", "signed_content", "cryptography_replayed",
    }),
    "verify_approval_record": frozenset({
        "trusted_signature_roots", "signature_content", "artifact",
    }),
    "verify_approval_withdrawal": frozenset({
        "trusted_signature_roots", "signature_content", "approval",
    }),
    "verify_lifecycle_authorization": frozenset({
        "approvals", "withdrawals", "policy", "clock", "trusted_signature_roots", "artifact",
    }),
    "verify_continued_validity_view": frozenset({
        "artifact", "dimension_sources", "trigger_sources", "dependencies",
    }),
    "verify_signature_verification_record_v2": frozenset({
        "signature_content", "signed_content", "authority_snapshot",
    }),
    "verify_approval_record_v2": frozenset({
        "signature_content", "artifact", "authority_snapshot", "principal",
    }),
    "verify_approval_withdrawal_v2": frozenset({
        "signature_content", "approval", "authority_snapshot", "principal",
    }),
    "verify_lifecycle_authorization_v2": frozenset({
        "approvals", "withdrawals", "policy", "clock", "artifact",
        "authority_snapshot", "approval_signature_inputs",
        "withdrawal_signature_inputs",
    }),
    "verify_continued_validity_view_v2": frozenset({
        "artifact", "dimension_sources", "trigger_sources", "dependencies",
        "validity_source",
    }),
    "verify_lifecycle_replay_record": frozenset({
        "source_checkpoint", "records", "verification_inputs",
    }),
    "verify_backup_restore_recovery_record": frozenset({
        "source_snapshot", "backup_snapshot", "restored_snapshot", "replay_record",
        "replay_source_checkpoint", "replay_records", "replay_verification_inputs",
    }),
    "verify_migration_reverification_record": frozenset({
        "migration_record", "source_object", "transformed_object", "lifecycle_record",
        "lifecycle_verification_inputs",
    }),
}

_RECORD_VERIFIER_OPERATIONS = {
    "ETQDecisionLoop": "verify_etq_decision_loop",
    "ResultIngestionRecord": "verify_result_ingestion_record",
    "SelectiveRevalidationRecord": "verify_selective_revalidation_record",
    "ReplacementRecord": "verify_replacement_record",
    "QualificationDisposition": "verify_qualification_disposition",
    "DecisionScopedConversion": "verify_decision_scoped_conversion",
    "ConversionBindingImpact": "verify_conversion_binding_impact",
    "SignatureVerificationRecord": "verify_signature_verification_record_v2",
    "ApprovalRecord": "verify_approval_record_v2",
    "ApprovalWithdrawal": "verify_approval_withdrawal_v2",
    "LifecycleAuthorization": "verify_lifecycle_authorization_v2",
    "ContinuedValidityView": "verify_continued_validity_view_v2",
    "LifecycleReplayRecord": "verify_lifecycle_replay_record",
    "BackupRestoreRecoveryRecord": "verify_backup_restore_recovery_record",
    "MigrationReverificationRecord": "verify_migration_reverification_record",
}

LIFECYCLE_VERIFIER_CONTRACTS = {
    record_type: (
        operation,
        _RECORD_WORKSTREAM[record_type],
        tuple(sorted(_VERIFIER_INPUT_FIELDS[operation])),
    )
    for record_type, operation in _RECORD_VERIFIER_OPERATIONS.items()
}


class LifecycleVerificationError(CaseError):
    """The independent lifecycle implementation rejected producer output."""


def _object(value: Any, where: str) -> Dict[str, Any]:
    if not isinstance(value, Mapping):
        raise CaseError(f"{where} must be a JSON object")
    return copy.deepcopy(dict(value))


def _closed(
    value: Any,
    where: str,
    required: Sequence[str],
    optional: Sequence[str] = (),
) -> Dict[str, Any]:
    result = _object(value, where)
    missing = sorted(set(required) - set(result))
    unknown = sorted(set(result) - set(required) - set(optional))
    if missing:
        raise CaseError(f"{where} is missing required field(s): {', '.join(missing)}")
    if unknown:
        raise CaseError(
            f"{where} contains unsupported field(s): {', '.join(unknown)}; "
            "derived states, hashes, authority effects, scores, and mutations are not accepted"
        )
    return result


def _sequence(value: Any, where: str) -> Tuple[Any, ...]:
    if not isinstance(value, (list, tuple)):
        raise CaseError(f"{where} must be a JSON array")
    return tuple(copy.deepcopy(item) for item in value)


def _strings(value: Any, where: str) -> Tuple[str, ...]:
    values = _sequence(value, where)
    if any(not isinstance(item, str) or not item for item in values):
        raise CaseError(f"{where} must contain non-empty strings")
    return tuple(values)


def _exact(value: Any, where: str) -> Exact:
    item = _closed(value, where, ("exact",))
    raw = item["exact"]
    if not isinstance(raw, str):
        raise CaseError(f"{where}.exact must be a rational string; floats are forbidden")
    try:
        result = Exact(raw)
    except (TypeError, ValueError, ZeroDivisionError) as error:
        raise CaseError(f"{where} is not an exact rational: {error}") from error
    if result.to_canonical() != item:
        raise CaseError(f"{where} is not in canonical exact-rational form")
    return result


def _optional_exact(value: Any, where: str) -> Exact | None:
    return None if value is None else _exact(value, where)


def _interval(value: Any, where: str) -> Interval:
    item = _closed(value, where, ("lo", "hi"))
    result = Interval(_exact(item["lo"], f"{where}.lo"), _exact(item["hi"], f"{where}.hi"))
    if result.to_canonical() != item:
        raise CaseError(f"{where} is not a canonical exact interval")
    return result


def _canonical_instance(value: Any, instance: Any, where: str) -> Any:
    expected = instance.to_canonical()
    if canonical_json(expected) != canonical_json(value):
        raise CaseError(
            f"{where} is not the canonical form of the registered producer object"
        )
    return instance


def _context(value: Any, where: str) -> ContextDescriptor:
    item = _closed(value, where, ("context_id", "context_type", "fields"))
    return _canonical_instance(
        item,
        ContextDescriptor(item["context_id"], item["context_type"], item["fields"]),
        where,
    )


def _method(value: Any, where: str) -> MethodDescriptor:
    item = _closed(
        value,
        where,
        ("method_id", "method_class", "evidence_class"),
        ("instrument", "version", "parameters"),
    )
    return _canonical_instance(
        item,
        MethodDescriptor(
            item["method_id"],
            item["method_class"],
            item["evidence_class"],
            item.get("instrument"),
            item.get("version"),
            tuple(sorted((item.get("parameters") or {}).items())),
        ),
        where,
    )


def _provenance(value: Any, where: str, *, derived_result_hash: str | None = None) -> Provenance:
    item = _closed(
        value,
        where,
        ("source_id", "issuer", "integrity", "chain"),
        ("provenance_status", "issued_at", "signature", "notes"),
    )
    chain = item["chain"]
    if chain == ["DERIVE_FROM_RETURNED_RESULT"]:
        if derived_result_hash is None:
            raise CaseError(f"{where} cannot derive a result hash in this operation")
        chain = [derived_result_hash]
        item["chain"] = chain
        # ``provenance_status`` is derived by the producer and therefore may
        # be omitted (or replaced) in the authoring shorthand.
        item["provenance_status"] = "VALID"
    instance = Provenance(
        source_id=item["source_id"],
        issuer=item["issuer"],
        issued_at=item.get("issued_at"),
        chain=tuple(chain),
        integrity=item["integrity"],
        signature=item.get("signature"),
        notes=tuple(item.get("notes") or ()),
    )
    expected = instance.to_canonical()
    if canonical_json(expected) != canonical_json(item):
        raise CaseError(f"{where} is not canonical after deriving the returned-result binding")
    return instance


def _access(value: Any, where: str) -> AccessPolicy:
    item = _closed(
        value,
        where,
        (
            "classification",
            "permitted_roles",
            "permitted_subjects",
            "redaction_required",
            "export_permitted",
        ),
    )
    return _canonical_instance(
        item,
        AccessPolicy(
            item["classification"],
            tuple(item["permitted_roles"]),
            tuple(item["permitted_subjects"]),
            item["redaction_required"],
            item["export_permitted"],
        ),
        where,
    )


def _validity(value: Any, where: str) -> ValidityWindow:
    item = _closed(
        value,
        where,
        ("issuer_clock_source",),
        ("issued_at", "not_before", "expires_at", "max_age_seconds", "revalidation_triggers"),
    )
    return _canonical_instance(
        item,
        ValidityWindow(
            issued_at=item.get("issued_at"),
            not_before=item.get("not_before"),
            expires_at=item.get("expires_at"),
            max_age_seconds=item.get("max_age_seconds"),
            revalidation_triggers=tuple(item.get("revalidation_triggers") or ()),
            issuer_clock_source=item["issuer_clock_source"],
        ),
        where,
    )


def _clock(value: Any, where: str) -> VerificationClock:
    item = _closed(
        value,
        where,
        ("verifier_evaluation_time", "verifier_clock_source", "verifier_clock_trust_level"),
    )
    return _canonical_instance(
        item,
        VerificationClock(
            item["verifier_evaluation_time"],
            item["verifier_clock_source"],
            item["verifier_clock_trust_level"],
        ),
        where,
    )


def _uncertainty(value: Any, where: str) -> UncertaintyBudget:
    item = _closed(
        value,
        where,
        ("measurement", "sampling", "calibration", "transfer", "model", "component_order"),
        ("basis",),
    )
    if item["component_order"] != ["measurement", "sampling", "calibration", "transfer", "model"]:
        raise CaseError(f"{where}.component_order is not the registered five-component order")
    return _canonical_instance(
        item,
        UncertaintyBudget(
            measurement=_interval(item["measurement"], f"{where}.measurement"),
            sampling=_interval(item["sampling"], f"{where}.sampling"),
            calibration=_interval(item["calibration"], f"{where}.calibration"),
            transfer=_interval(item["transfer"], f"{where}.transfer"),
            model=_interval(item["model"], f"{where}.model"),
            basis=item.get("basis", ""),
        ),
        where,
    )


def _burden(value: Any, where: str) -> BurdenVector:
    item = _closed(value, where, ("declared_dimensions", "values"), ("basis",))
    values = _object(item["values"], f"{where}.values")
    declared = item["declared_dimensions"]
    if not isinstance(declared, list) or not all(isinstance(name, str) for name in declared):
        raise CaseError(f"{where}.declared_dimensions must be an array of strings")
    if len(set(declared)) != len(declared):
        raise CaseError(f"{where}.declared_dimensions repeats a burden dimension")
    unknown = set(declared) - set(BurdenDimension.ORDER)
    if unknown:
        raise CaseError(f"{where}.declared_dimensions contains unknown dimensions {sorted(unknown)}")
    governed = [name for name in BurdenDimension.ORDER if name in set(declared)]
    if declared != governed:
        raise CaseError(
            f"{where}.declared_dimensions is not in the governed burden-dimension order"
        )
    if set(values) != set(declared):
        raise CaseError(f"{where} declared dimensions and values do not name the same dimensions")
    instance = BurdenVector(
        [
            (name, _exact(values[name], f"{where}.values.{name}"))
            for name in declared
        ],
        basis=item.get("basis", ""),
    )
    return _canonical_instance(item, instance, where)


def _experiment_result(value: Any, where: str) -> ExperimentResult:
    item = _closed(
        value,
        where,
        ("experiment_id", "measurand", "unit", "status", "correlation_assumption", "uncertainty"),
        (
            "observed",
            "context",
            "observed_ambiguity",
            "ambiguity_metric",
            "burden_incurred",
            "regret_upper_bound",
            "possible_winners",
            "guaranteed_winner",
            "manual_adjudication_required",
            "manual_adjudication_reason",
            "notes",
        ),
    )
    instance = ExperimentResult(
        experiment_id=item["experiment_id"],
        measurand=item["measurand"],
        unit=item["unit"],
        observed=_interval(item["observed"], f"{where}.observed") if "observed" in item else None,
        uncertainty=_uncertainty(item["uncertainty"], f"{where}.uncertainty"),
        correlation_assumption=item["correlation_assumption"],
        context=_context(item["context"], f"{where}.context") if "context" in item else None,
        observed_ambiguity=_optional_exact(item.get("observed_ambiguity"), f"{where}.observed_ambiguity"),
        ambiguity_metric=item.get("ambiguity_metric"),
        status=item["status"],
        burden_incurred=_burden(item["burden_incurred"], f"{where}.burden_incurred") if "burden_incurred" in item else None,
        regret_upper_bound=_optional_exact(item.get("regret_upper_bound"), f"{where}.regret_upper_bound"),
        possible_winners=tuple(item["possible_winners"]) if "possible_winners" in item else None,
        guaranteed_winner=item.get("guaranteed_winner"),
        manual_adjudication_required=item.get("manual_adjudication_required", False),
        manual_adjudication_reason=item.get("manual_adjudication_reason", ""),
        notes=tuple(item.get("notes") or ()),
    )
    return _canonical_instance(item, instance, where)


def _state(value: Any, where: str) -> QualificationState:
    item = _closed(
        value,
        where,
        (
            "plan_id", "step", "coordinate_bounds", "predicate_state", "ambiguity_metric",
            "ambiguity", "ambiguity_derivable", "cumulative_burden", "completed_experiments",
            "remaining_experiments", "informative_remaining", "manual_adjudication_required",
        ),
        ("regret_upper_bound", "possible_winners", "guaranteed_winner", "manual_adjudication_reason", "notes"),
    )
    bounds = _object(item["coordinate_bounds"], f"{where}.coordinate_bounds")
    instance = QualificationState(
        plan_id=item["plan_id"],
        coordinate_bounds=tuple(
            (name, _interval(bound, f"{where}.coordinate_bounds.{name}"))
            for name, bound in bounds.items()
        ),
        predicate_state=item["predicate_state"],
        ambiguity_metric=item["ambiguity_metric"],
        ambiguity=_exact(item["ambiguity"], f"{where}.ambiguity"),
        cumulative_burden=_burden(item["cumulative_burden"], f"{where}.cumulative_burden"),
        completed_experiments=tuple(item["completed_experiments"]),
        remaining_experiments=tuple(item["remaining_experiments"]),
        informative_remaining=tuple(item["informative_remaining"]),
        ambiguity_derivable=item["ambiguity_derivable"],
        regret_upper_bound=_optional_exact(item.get("regret_upper_bound"), f"{where}.regret_upper_bound"),
        possible_winners=tuple(item.get("possible_winners") or ()),
        guaranteed_winner=item.get("guaranteed_winner"),
        manual_adjudication_required=item["manual_adjudication_required"],
        manual_adjudication_reason=item.get("manual_adjudication_reason", ""),
        step=item["step"],
        notes=tuple(item.get("notes") or ()),
    )
    return _canonical_instance(item, instance, where)


def _target_evaluation(value: Any, where: str) -> TargetEvaluation:
    item = _closed(
        value,
        where,
        ("target_id", "predicate_id", "coordinate_id", "measurand_status", "coordinate_status"),
        ("measurand", "observed", "carried_coordinate_bound", "detail"),
    )
    instance = TargetEvaluation(
        target_id=item["target_id"],
        predicate_id=item["predicate_id"],
        coordinate_id=item["coordinate_id"],
        measurand=item.get("measurand"),
        measurand_status=item["measurand_status"],
        coordinate_status=item["coordinate_status"],
        observed=_interval(item["observed"], f"{where}.observed") if "observed" in item else None,
        carried_coordinate_bound=_interval(item["carried_coordinate_bound"], f"{where}.carried_coordinate_bound") if "carried_coordinate_bound" in item else None,
        detail=item.get("detail", ""),
    )
    return _canonical_instance(item, instance, where)


def _qualification_result(value: Any, where: str) -> QualificationResult:
    item = _closed(
        value,
        where,
        (
            "plan_id", "experiment_id", "result_status", "predicate_state_before",
            "predicate_state_after", "ambiguity_before", "ambiguity_after", "residual_ambiguity",
            "residual_metric", "burden_incurred", "cumulative_burden", "target_evaluations",
            "stopped", "stopping_reason", "stopping_detail", "prior_state", "state",
            "warnings", "verification_basis",
        ),
    )
    instance = QualificationResult(
        plan_id=item["plan_id"],
        experiment_id=item["experiment_id"],
        result_status=item["result_status"],
        prior_state=_state(item["prior_state"], f"{where}.prior_state"),
        state=_state(item["state"], f"{where}.state"),
        target_evaluations=tuple(
            _target_evaluation(raw, f"{where}.target_evaluations[{index}]")
            for index, raw in enumerate(_sequence(item["target_evaluations"], f"{where}.target_evaluations"))
        ),
        predicate_state_before=item["predicate_state_before"],
        predicate_state_after=item["predicate_state_after"],
        ambiguity_before=_exact(item["ambiguity_before"], f"{where}.ambiguity_before"),
        ambiguity_after=_exact(item["ambiguity_after"], f"{where}.ambiguity_after"),
        burden_incurred=_burden(item["burden_incurred"], f"{where}.burden_incurred"),
        cumulative_burden=_burden(item["cumulative_burden"], f"{where}.cumulative_burden"),
        stopped=item["stopped"],
        stopping_reason=item["stopping_reason"],
        stopping_detail=item["stopping_detail"],
        residual_ambiguity=_exact(item["residual_ambiguity"], f"{where}.residual_ambiguity"),
        residual_metric=item["residual_metric"],
        warnings=tuple(item["warnings"]),
        verification_basis=tuple(item["verification_basis"]),
    )
    return _canonical_instance(item, instance, where)


def _evidence(value: Any, where: str) -> EvidenceRecord:
    item = _closed(
        value,
        where,
        (
            "record_type", "spec_section", "evidence_id", "quantity", "unit", "Y_value",
            "U_uncertainty", "C_source_context", "M_method", "P_provenance", "V_validity",
            "A_access", "evidence_status", "status",
        ),
        ("supersedes", "superseded_by", "scenarios", "notes"),
    )
    if item["record_type"] != "etq.evidence_record" or item["spec_section"] != "33.2":
        raise CaseError(f"{where} is not a registered ETQ evidence record")
    instance = EvidenceRecord(
        evidence_id=item["evidence_id"],
        quantity=item["quantity"],
        unit=item["unit"],
        value=_interval(item["Y_value"], f"{where}.Y_value"),
        uncertainty=_uncertainty(item["U_uncertainty"], f"{where}.U_uncertainty"),
        source_context=_context(item["C_source_context"], f"{where}.C_source_context"),
        method=_method(item["M_method"], f"{where}.M_method"),
        provenance=_provenance(item["P_provenance"], f"{where}.P_provenance"),
        validity=_validity(item["V_validity"], f"{where}.V_validity"),
        access=_access(item["A_access"], f"{where}.A_access"),
        evidence_status=item["evidence_status"],
        status=item["status"],
        supersedes=tuple(item.get("supersedes") or ()),
        superseded_by=item.get("superseded_by"),
        scenarios=tuple(
            _interval(raw, f"{where}.scenarios[{index}]")
            for index, raw in enumerate(item.get("scenarios") or ())
        ),
        notes=tuple(item.get("notes") or ()),
    )
    return _canonical_instance(item, instance, where)


def _dependency_edge(value: Any, where: str) -> DependencyEdge:
    item = _closed(
        value,
        where,
        (
            "edge_id", "source", "target", "edge_type", "minimum_action", "transitive",
            "validity_propagation_rule", "edge_version", "source_property", "scope",
            "invalidation_predicate",
        ),
    )
    instance = DependencyEdge(
        item["edge_id"],
        item["source"],
        item["target"],
        item["edge_type"],
        None if item["source_property"] == "*" else item["source_property"],
        None if item["scope"] == "GLOBAL" else item["scope"],
        None if item["invalidation_predicate"] == "EDGE_TYPE_TRIGGER:" + item["edge_type"] else item["invalidation_predicate"],
        item["edge_version"],
    )
    return _canonical_instance(item, instance, where)


def _loop(value: Any, where: str) -> ETQDecisionLoop:
    item = _object(value, where)
    steps = []
    for index, raw in enumerate(item.get("steps") or ()):
        step = _object(raw, f"{where}.steps[{index}]")
        outputs = tuple(
            LoopArtifactRef(
                output["artifact_id"], output["artifact_type"], output["content_hash"],
                tuple(output["parent_hashes"]), output["status"], output["evidence_class"],
            )
            for output in step.get("outputs") or ()
        )
        refusal = step.get("refusal") or {}
        steps.append(
            ETQStepRecord(
                step["step"], outputs, tuple(step["input_hashes"]), step["authority"],
                tuple(step["verification_basis"]), refusal.get("code"), refusal.get("detail", ""),
            )
        )
    instance = ETQDecisionLoop(
        item.get("loop_id", ""), item.get("target_decision_id", ""), item.get("predicate_id", ""),
        item.get("target_context_hash", ""), tuple(item.get("declared_stopping_conditions") or ()),
        tuple(steps), item.get("schema_version", ""),
    )
    return _canonical_instance(item, instance, where)


def _revalidation(value: Any, where: str) -> SelectiveRevalidationRecord:
    item = _object(value, where)
    instance = SelectiveRevalidationRecord(
        item.get("record_id", ""), item.get("changed_source", ""),
        tuple(item.get("changed_properties") or ()), item.get("dependency_graph_hash", ""),
        item.get("dependency_completeness_basis", ""),
        tuple((raw["artifact_id"], raw["minimum_action"]) for raw in item.get("affected") or ()),
        tuple(item.get("preserved") or ()), tuple(item.get("replacement_required") or ()),
        item.get("state", ""),
    )
    return _canonical_instance(item, instance, where)


def _ingestion(value: Any, where: str) -> ResultIngestionRecord:
    item = _object(value, where)
    instance = ResultIngestionRecord(
        item.get("ingestion_id", ""), item.get("plan_id", ""), item.get("experiment_id", ""),
        item.get("result_hash", ""), item.get("new_evidence_id", ""),
        item.get("new_evidence_hash", ""), item.get("evidence_class", ""),
        item.get("evidence_status", ""), tuple(item.get("prior_evidence_ids") or ()),
        tuple(item.get("prior_evidence_hashes") or ()), item.get("preserved_prior_records", False),
    )
    return _canonical_instance(item, instance, where)


def _space(value: Any, where: str) -> LogicalSpace:
    item = _closed(value, where, ("identifier", "axes"), ("total_elements", "bytes_per_element"))
    return _canonical_instance(
        item,
        LogicalSpace(item["identifier"], tuple(item["axes"]), item.get("total_elements"), item.get("bytes_per_element")),
        where,
    )


def _cell(value: Any, where: str) -> Cell:
    item = _closed(value, where, ("index", "box", "measure"), ("owner",))
    instance = Cell(
        item["index"],
        tuple(
            (_exact(bounds[0], f"{where}.box[{index}][0]"), _exact(bounds[1], f"{where}.box[{index}][1]"))
            for index, bounds in enumerate(item["box"])
        ),
        item.get("owner"),
    )
    return _canonical_instance(item, instance, where)


def _conversion(value: Any, where: str) -> ConversionRecord:
    item = _object(value, where)
    retained = tuple(
        RetainedIntersection(
            raw["source_cell"], raw["target_cell"], _exact(raw["measure"], f"{where}.retained[{i}].measure"),
            _optional_exact(raw.get("elements"), f"{where}.retained[{i}].elements"),
            _optional_exact(raw.get("bytes"), f"{where}.retained[{i}].bytes"),
        ) for i, raw in enumerate(item.get("retained") or ())
    )
    residual = tuple(
        ResidualRegion(
            raw["target_cell"], raw["from_source_cell"], raw["to_source_cell"],
            _exact(raw["measure"], f"{where}.residual[{i}].measure"),
            _optional_exact(raw.get("elements"), f"{where}.residual[{i}].elements"),
            _optional_exact(raw.get("bytes"), f"{where}.residual[{i}].bytes"),
        ) for i, raw in enumerate(item.get("residual") or ())
    )
    route = tuple(
        RouteStep(
            raw["step_id"], raw["origin"], raw["destination"], raw["target_cell"],
            _exact(raw["measure"], f"{where}.route[{i}].measure"), raw["wave"],
            _optional_exact(raw.get("elements"), f"{where}.route[{i}].elements"),
            _optional_exact(raw.get("bytes"), f"{where}.route[{i}].bytes"),
        ) for i, raw in enumerate(item.get("route") or ())
    )
    schedule = tuple(
        ScheduleWave(raw["index"], tuple(raw["steps"]), _exact(raw["measure"], f"{where}.schedule[{i}].measure"))
        for i, raw in enumerate(item.get("schedule") or ())
    )
    buffering = item.get("buffering") or {}
    duplication = item.get("duplication") or {}
    solver = item.get("solver_evidence") or {}
    secondary_raw = item.get("secondary")
    secondary = None
    if secondary_raw is not None:
        secondary = SecondaryReport(
            secondary_raw["objective"], secondary_raw["direction"],
            _exact(secondary_raw["value"], f"{where}.secondary.value"),
            _exact(secondary_raw["baseline_value"], f"{where}.secondary.baseline_value"),
            secondary_raw["retention_preserved"], secondary_raw["trade_permitted"],
            secondary_raw["trade_refused"],
            _optional_exact(secondary_raw.get("refused_gain"), f"{where}.secondary.refused_gain"),
            _optional_exact(secondary_raw.get("refused_retention_loss"), f"{where}.secondary.refused_retention_loss"),
            secondary_raw.get("refusal_reason"), secondary_raw.get("authorization"),
        )
    instance = ConversionRecord(
        record_id=item.get("record_id", ""),
        source_space=_space(item.get("source_space"), f"{where}.source_space"),
        target_space=_space(item.get("target_space"), f"{where}.target_space"),
        source_cells=tuple(_cell(raw, f"{where}.source_cells[{i}]") for i, raw in enumerate(item.get("source_cells") or ())),
        target_cells=tuple(_cell(raw, f"{where}.target_cells[{i}]") for i, raw in enumerate(item.get("target_cells") or ())),
        assignment={pair[0]: pair[1] for pair in item.get("assignment") or ()},
        retained=retained,
        residual=residual,
        retained_fraction=_exact(item.get("retained_fraction"), f"{where}.retained_fraction"),
        moved_fraction=_exact(item.get("moved_fraction"), f"{where}.moved_fraction"),
        route=route,
        schedule=schedule,
        consistency_epoch=item.get("consistency_epoch", ""),
        buffering=BufferingPlan(
            _exact(buffering.get("per_device_fraction"), f"{where}.buffering.per_device_fraction"),
            _exact(buffering.get("peak_in_flight_fraction"), f"{where}.buffering.peak_in_flight_fraction"),
            buffering.get("waves"), buffering.get("policy", ""),
        ),
        duplication=DuplicationPolicy(
            duplication.get("mode", ""), tuple(tuple(group) for group in duplication.get("multicast_groups") or ()),
            duplication.get("transient_copies_permitted"), duplication.get("replication_factor"),
        ),
        completion_checks=tuple(
            CompletionCheck(raw["name"], raw["statement"], raw["expected"])
            for raw in item.get("completion_checks") or ()
        ),
        failure_behavior=item.get("failure_behavior", ""),
        rollback_behavior=item.get("rollback_behavior", ""),
        solver_evidence=SolverEvidence(
            solver.get("method", ""), solver.get("arithmetic_profile", ""),
            solver.get("solver_trust_profile", ""),
            tuple(_exact(raw, f"{where}.solver_evidence.row_potentials[{i}]") for i, raw in enumerate(solver.get("row_potentials") or ())),
            tuple(_exact(raw, f"{where}.solver_evidence.column_potentials[{i}]") for i, raw in enumerate(solver.get("column_potentials") or ())),
            solver.get("nested", False),
            _optional_exact(solver.get("closed_form_value"), f"{where}.solver_evidence.closed_form_value"),
            solver.get("closed_form_agrees"), tuple(solver.get("notes") or ()),
        ),
        verification_program=tuple(item.get("verification_program") or ()),
        ownership_contract=item.get("ownership_contract", ""),
        retained_elements=_optional_exact(item.get("retained_elements"), f"{where}.retained_elements"),
        moved_elements=_optional_exact(item.get("moved_elements"), f"{where}.moved_elements"),
        retained_bytes=_optional_exact(item.get("retained_bytes"), f"{where}.retained_bytes"),
        moved_bytes=_optional_exact(item.get("moved_bytes"), f"{where}.moved_bytes"),
        secondary=secondary,
        identity=item.get("identity", False),
    )
    return _canonical_instance(item, instance, where)


def _binding(value: Any, where: str) -> DecisionScopedConversion:
    item = _object(value, where)
    instance = DecisionScopedConversion(
        item.get("binding_id", ""), item.get("conversion_record_id", ""),
        item.get("conversion_record_hash", ""), item.get("source_case_root", ""),
        item.get("target_case_root", ""), item.get("retained_geometry_hash", ""),
        item.get("decision_scope_hash", ""), item.get("decision_certificate_hash", ""),
        item.get("retained_geometry_relation", ""), item.get("decision_scope_relation", ""),
        item.get("authority", ""), tuple(item.get("dependency_hashes") or ()),
        tuple(item.get("semantic_verification_hashes") or ()),
        tuple((raw["check"], raw["passed"]) for raw in item.get("invariant_checks") or ()),
        tuple(item.get("verification_program") or ()), item.get("schema_version", ""),
    )
    return _canonical_instance(item, instance, where)


def _signature(value: Any, where: str) -> SignatureVerificationRecord:
    item = _object(value, where)
    instance = SignatureVerificationRecord(
        item.get("verification_id", ""), item.get("signature_id", ""),
        item.get("signature_hash", ""), item.get("signed_content_hash", ""),
        item.get("key_id", ""), item.get("algorithm", ""), item.get("verifier_id", ""),
        item.get("verifier_version", ""), item.get("checked_at", ""),
        item.get("verified", False), item.get("failure_reason", ""),
    )
    return _canonical_instance(item, instance, where)


def _approval(value: Any, where: str) -> ApprovalRecord:
    item = _object(value, where)
    payload = _object(item.get("payload"), f"{where}.payload")
    instance = ApprovalRecord(
        item.get("approval_id", ""), payload.get("artifact_hash", ""), payload.get("action", ""),
        payload.get("subject_id", ""), payload.get("role", ""), payload.get("organization", ""),
        payload.get("signed_at", ""), _validity(payload.get("validity"), f"{where}.payload.validity"),
        _signature(item.get("signature_verification"), f"{where}.signature_verification"),
        payload.get("authority", ""),
    )
    return _canonical_instance(item, instance, where)


def _withdrawal(value: Any, where: str) -> ApprovalWithdrawal:
    item = _object(value, where)
    payload = _object(item.get("payload"), f"{where}.payload")
    instance = ApprovalWithdrawal(
        item.get("withdrawal_id", ""), payload.get("approval_hash", ""),
        payload.get("withdrawn_by", ""), payload.get("reason", ""), payload.get("occurred_at", ""),
        payload.get("authority", ""),
        _signature(item.get("signature_verification"), f"{where}.signature_verification"),
    )
    return _canonical_instance(item, instance, where)


def _policy(value: Any, where: str) -> SeparationOfDutiesPolicy:
    item = _closed(
        value, where,
        ("policy_id", "required_roles", "incompatible_role_pairs", "distinct_subjects_for_required_roles", "authority"),
    )
    return _canonical_instance(
        item,
        SeparationOfDutiesPolicy(
            item["policy_id"], tuple(item["required_roles"]),
            tuple(tuple(pair) for pair in item["incompatible_role_pairs"]),
            item["distinct_subjects_for_required_roles"], item["authority"],
        ),
        where,
    )


def _verification_inputs(operation: str, record: Mapping[str, Any], **inputs: Any) -> dict:
    return {
        "verification_profile": "crg-lifecycle/independent-replay@1",
        "first_release_attribution": _RECORD_WORKSTREAM[record["record_type"]],
        "verifier_operation": operation,
        "record_type": record["record_type"],
        "record_hash": content_hash(record),
        "inputs": copy.deepcopy(inputs),
    }


def verify_lifecycle_record(record: Any, verification_inputs: Any):
    """Dispatch one exact portable record to the independent implementation."""

    document = _object(record, "lifecycle record")
    envelope = _closed(
        verification_inputs,
        "lifecycle verification inputs",
        (
            "verification_profile", "first_release_attribution", "verifier_operation",
            "record_type", "record_hash", "inputs",
        ),
    )
    if envelope["verification_profile"] != "crg-lifecycle/independent-replay@1":
        raise CaseError("unsupported lifecycle verification profile")
    if envelope["record_type"] != document.get("record_type"):
        raise CaseError("lifecycle verification record_type does not match the record")
    if envelope["first_release_attribution"] != _RECORD_WORKSTREAM.get(document.get("record_type")):
        raise CaseError("lifecycle verification inputs carry incorrect first-release attribution")
    if envelope["record_hash"] != content_hash(document):
        raise CaseError("lifecycle verification inputs are bound to different record bytes")
    inputs = _object(envelope["inputs"], "lifecycle verifier inputs.inputs")
    operation = envelope["verifier_operation"]
    expected_fields = _VERIFIER_INPUT_FIELDS.get(operation)
    if expected_fields is None:
        raise CaseError(f"unsupported lifecycle verifier operation {operation!r}")
    if set(inputs) != expected_fields:
        raise CaseError(
            f"{operation} requires exact replay fields {sorted(expected_fields)}; "
            f"found {sorted(inputs)}"
        )
    if operation == "verify_signature_verification_record" and inputs.get(
        "cryptography_replayed"
    ) is not False:
        raise CaseError(
            "SignatureVerificationRecord replay must disclose cryptography_replayed=false"
        )
    portable_binding_ok = True
    if operation == "verify_signature_verification_record":
        portable_binding_ok = (
            content_hash(inputs["signed_content"]) == document.get("signed_content_hash")
        )
    elif operation in {"verify_approval_record", "verify_approval_record_v2"}:
        portable_binding_ok = (
            content_hash(inputs["artifact"])
            == (document.get("payload") or {}).get("artifact_hash")
        )
    elif operation in {"verify_approval_withdrawal", "verify_approval_withdrawal_v2"}:
        portable_binding_ok = (
            content_hash(inputs["approval"])
            == (document.get("payload") or {}).get("approval_hash")
        )
    elif operation in {"verify_lifecycle_authorization", "verify_lifecycle_authorization_v2"}:
        portable_binding_ok = (
            content_hash(inputs["artifact"]) == document.get("artifact_hash")
        )
    if not portable_binding_ok:
        raise LifecycleVerificationError(
            "portable lifecycle source document does not match the producer-bound content root"
        )
    dispatch = {
        "verify_etq_decision_loop": lambda: crg_verify.verify_etq_decision_loop(document),
        "verify_result_ingestion_record": lambda: crg_verify.verify_result_ingestion_record(
            document, inputs["result_record"], inputs["new_evidence"], inputs.get("prior_evidence", ())
        ),
        "verify_selective_revalidation_record": lambda: crg_verify.verify_selective_revalidation_record(
            document, inputs["dependency_edges"], inputs["artifact_universe"]
        ),
        "verify_replacement_record": lambda: crg_verify.verify_replacement_record(
            document, inputs["revalidation_record"], inputs["prior_artifact"],
            inputs["replacement_artifact"], inputs["dependency_edges"], inputs["artifact_universe"]
        ),
        "verify_qualification_disposition": lambda: crg_verify.verify_qualification_disposition(
            document, inputs["qualification_result"], inputs["ingestions"],
            inputs["required_evidence_ids"], inputs["verification_basis"],
            minimum_evidence_status=inputs["minimum_evidence_status"],
        ),
        "verify_decision_scoped_conversion": lambda: crg_verify.verify_decision_scoped_conversion(
            document, inputs["conversion_record"], inputs["source_case"], inputs["target_case"],
            inputs["retained_geometry"], inputs["decision_scope"], inputs["decision_certificate"],
            inputs["semantic_verifications"], inputs.get("dependencies", ()),
        ),
        "verify_conversion_binding_impact": lambda: crg_verify.verify_conversion_binding_impact(
            document, inputs["binding"], inputs["current_conversion_record"],
            inputs["current_retained_geometry"], inputs["current_decision_scope"],
            inputs["current_decision_certificate"],
        ),
        "verify_signature_verification_record": lambda: crg_verify.verify_signature_verification_record(
            document,
            signature_content=inputs.get("signature_content"),
            trusted_record_root=inputs.get("trusted_record_root"),
        ),
        "verify_approval_record": lambda: crg_verify.verify_approval_record(
            document, inputs["trusted_signature_roots"],
            signature_content=inputs.get("signature_content"),
        ),
        "verify_approval_withdrawal": lambda: crg_verify.verify_approval_withdrawal(
            document, inputs["trusted_signature_roots"],
            signature_content=inputs.get("signature_content"),
        ),
        "verify_lifecycle_authorization": lambda: crg_verify.verify_lifecycle_authorization(
            document, inputs["approvals"], inputs["withdrawals"], inputs["policy"],
            inputs["clock"], inputs["trusted_signature_roots"],
        ),
        "verify_continued_validity_view": lambda: crg_verify.verify_continued_validity_view(
            document, inputs["artifact"], inputs["dimension_sources"], inputs["trigger_sources"],
            inputs["dependencies"],
        ),
        "verify_signature_verification_record_v2": lambda: crg_verify.verify_signature_verification_record(
            document,
            signature_content=inputs["signature_content"],
            signed_content=inputs["signed_content"],
            authority_snapshot=inputs["authority_snapshot"],
        ),
        "verify_approval_record_v2": lambda: crg_verify.verify_approval_record(
            document,
            signature_content=inputs["signature_content"],
            authority_snapshot=inputs["authority_snapshot"],
            principal=inputs["principal"],
        ),
        "verify_approval_withdrawal_v2": lambda: crg_verify.verify_approval_withdrawal(
            document,
            signature_content=inputs["signature_content"],
            authority_snapshot=inputs["authority_snapshot"],
            principal=inputs["principal"],
            approval=inputs["approval"],
        ),
        "verify_lifecycle_authorization_v2": lambda: crg_verify.verify_lifecycle_authorization(
            document, inputs["approvals"], inputs["withdrawals"], inputs["policy"],
            inputs["clock"], authority_snapshot=inputs["authority_snapshot"],
            approval_signature_inputs=inputs["approval_signature_inputs"],
            withdrawal_signature_inputs=inputs["withdrawal_signature_inputs"],
        ),
        "verify_continued_validity_view_v2": lambda: crg_verify.verify_continued_validity_view(
            document, inputs["artifact"], inputs["dimension_sources"], inputs["trigger_sources"],
            inputs["dependencies"], validity_source=inputs["validity_source"],
        ),
        "verify_lifecycle_replay_record": lambda: crg_verify.verify_lifecycle_replay_record(
            document, inputs["source_checkpoint"], inputs["records"],
            inputs["verification_inputs"],
        ),
        "verify_backup_restore_recovery_record": lambda: (
            crg_verify.verify_backup_restore_recovery_record(
                document, inputs["source_snapshot"], inputs["backup_snapshot"],
                inputs["restored_snapshot"], inputs["replay_record"],
                inputs["replay_source_checkpoint"], inputs["replay_records"],
                inputs["replay_verification_inputs"],
            )
        ),
        "verify_migration_reverification_record": lambda: (
            crg_verify.verify_migration_reverification_record(
                document, inputs["migration_record"], inputs["source_object"],
                inputs["transformed_object"], inputs["lifecycle_record"],
                inputs["lifecycle_verification_inputs"],
            )
        ),
    }
    result = dispatch[operation]()
    if not result.ok:
        detail = "; ".join(result.violations) or result.status
        raise LifecycleVerificationError(
            f"independent lifecycle replay failed; no record may be published: {detail}"
        )
    return result


def _stored_record(case: Mapping[str, Any], record_type: str, identity: str) -> dict:
    records = case.get("lifecycle_records") or {}
    by_type = records.get(record_type) if isinstance(records, Mapping) else None
    raw = by_type.get(identity) if isinstance(by_type, Mapping) else None
    if not isinstance(raw, Mapping):
        raise CaseError(f"no lifecycle {record_type} {identity!r} exists in this case")
    return copy.deepcopy(dict(raw))


def _stored_inputs(case: Mapping[str, Any], record_type: str, identity: str) -> dict:
    inventory = case.get("lifecycle_verification_inputs") or {}
    by_type = inventory.get(record_type) if isinstance(inventory, Mapping) else None
    raw = by_type.get(identity) if isinstance(by_type, Mapping) else None
    if not isinstance(raw, Mapping):
        raise CaseError(
            f"lifecycle {record_type} {identity!r} has no retained independent-verifier inputs"
        )
    return copy.deepcopy(dict(raw))


def _build_etq_lifecycle(
    operation: str, raw: Any, case: Mapping[str, Any]
) -> Tuple[dict, dict, Tuple[Tuple[str, dict], ...]]:
    """Build one v1.3 ETQ-lifecycle record and its independent-replay inputs."""

    if operation not in ETQ_LIFECYCLE_OPERATIONS:
        raise CaseError(f"unsupported v1.3 ETQ lifecycle operation {operation!r}")

    if operation == "CREATE_ETQ_LOOP":
        value = _closed(
            raw, operation,
            ("loop_id", "target_decision_id", "predicate_id", "target_context", "declared_stopping_conditions"),
        )
        loop = ETQDecisionLoop(
            value["loop_id"], value["target_decision_id"], value["predicate_id"],
            content_hash(value["target_context"]), tuple(value["declared_stopping_conditions"]),
        )
        record = loop.to_canonical()
        inputs = _verification_inputs("verify_etq_decision_loop", record)
        return record, inputs, ()

    if operation == "APPEND_ETQ_STEP":
        value = _closed(
            raw, operation, ("loop_id", "authority", "verification_basis"),
            ("artifacts", "refusal"),
        )
        prior_doc = _stored_record(case, "ETQDecisionLoop", value["loop_id"])
        loop = _loop(prior_doc, "stored ETQDecisionLoop")
        artifacts = []
        prior_outputs = tuple(
            output.content_hash for output in (loop.steps[-1].outputs if loop.steps else ())
        )
        for index, raw_artifact in enumerate(value.get("artifacts") or ()):
            artifact = _closed(
                raw_artifact, f"{operation}.artifacts[{index}]",
                ("artifact_id", "artifact_type", "content"), ("status", "evidence_class"),
            )
            artifacts.append(
                LoopArtifactRef(
                    artifact["artifact_id"], artifact["artifact_type"], content_hash(artifact["content"]),
                    prior_outputs, artifact.get("status", "ACTIVE"), artifact.get("evidence_class", "DECLARED"),
                )
            )
        refusal = value.get("refusal")
        refusal_value = _closed(refusal, f"{operation}.refusal", ("code", "detail")) if refusal is not None else {}
        step = ETQStepRecord(
            loop.next_step or "", tuple(artifacts), prior_outputs, value["authority"],
            tuple(value["verification_basis"]), refusal_value.get("code"), refusal_value.get("detail", ""),
        )
        record = loop.append(step).to_canonical()
        inputs = _verification_inputs("verify_etq_decision_loop", record)
        return record, inputs, ()

    if operation == "INGEST_RESULT":
        value = _closed(
            raw, operation,
            ("result", "ingestion_id", "plan_id", "evidence_id", "method", "provenance", "validity", "access"),
            ("evidence_status", "prior_evidence"),
        )
        result = _experiment_result(value["result"], f"{operation}.result")
        result_doc = result.to_canonical()
        prior = tuple(
            _evidence(item, f"{operation}.prior_evidence[{index}]")
            for index, item in enumerate(value.get("prior_evidence") or ())
        )
        new_evidence, ingestion = ingest_result_as_evidence(
            result,
            ingestion_id=value["ingestion_id"], plan_id=value["plan_id"], evidence_id=value["evidence_id"],
            method=_method(value["method"], f"{operation}.method"),
            provenance=_provenance(
                value["provenance"], f"{operation}.provenance",
                derived_result_hash=content_hash(result_doc),
            ),
            validity=_validity(value["validity"], f"{operation}.validity"),
            access=_access(value["access"], f"{operation}.access"),
            evidence_status=value.get("evidence_status", "PROVISIONAL"), prior_evidence=prior,
        )
        record, evidence_doc = ingestion.to_canonical(), new_evidence.to_canonical()
        inputs = _verification_inputs(
            "verify_result_ingestion_record", record,
            result_record=result_doc, new_evidence=evidence_doc,
            prior_evidence=[item.to_canonical() for item in prior],
        )
        return record, inputs, ((f"evidence:{new_evidence.evidence_id}", evidence_doc),)

    if operation == "PLAN_REVALIDATION":
        value = _closed(
            raw, operation,
            ("record_id", "changed_source", "changed_properties", "dependency_edges", "artifact_universe", "dependency_completeness_basis"),
        )
        edges = tuple(
            _dependency_edge(item, f"{operation}.dependency_edges[{index}]")
            for index, item in enumerate(value["dependency_edges"])
        )
        plan = plan_selective_revalidation(
            record_id=value["record_id"], changed_source=value["changed_source"],
            changed_properties=value["changed_properties"], dependency_edges=edges,
            artifact_universe=value["artifact_universe"],
            dependency_completeness_basis=value["dependency_completeness_basis"],
        )
        record = plan.to_canonical()
        inputs = _verification_inputs(
            "verify_selective_revalidation_record", record,
            dependency_edges=[edge.to_canonical() for edge in edges],
            artifact_universe=list(value["artifact_universe"]),
        )
        return record, inputs, ()

    if operation == "ISSUE_REPLACEMENT":
        value = _closed(
            raw, operation,
            ("revalidation_record_id", "replacement_id", "prior_artifact_id", "replacement_artifact_id", "prior_artifact", "replacement_artifact", "verification_basis"),
        )
        revalidation_doc = _stored_record(
            case, "SelectiveRevalidationRecord", value["revalidation_record_id"]
        )
        revalidation_inputs = _stored_inputs(
            case, "SelectiveRevalidationRecord", value["revalidation_record_id"]
        )["inputs"]
        plan = _revalidation(revalidation_doc, f"{operation}.revalidation_record")
        replacement = issue_replacement(
            plan,
            replacement_id=value["replacement_id"], prior_artifact_id=value["prior_artifact_id"],
            replacement_artifact_id=value["replacement_artifact_id"],
            prior_artifact_hash=content_hash(value["prior_artifact"]),
            replacement_artifact_hash=content_hash(value["replacement_artifact"]),
            verification_basis=value["verification_basis"],
        )
        record = replacement.to_canonical()
        inputs = _verification_inputs(
            "verify_replacement_record", record,
            revalidation_record=revalidation_doc, prior_artifact=value["prior_artifact"],
            replacement_artifact=value["replacement_artifact"],
            dependency_edges=revalidation_inputs["dependency_edges"],
            artifact_universe=revalidation_inputs["artifact_universe"],
        )
        return record, inputs, ()

    if operation == "QUALIFICATION_DISPOSITION":
        value = _closed(
            raw, operation,
            ("qualification_result", "ingestions", "required_evidence_ids", "verification_basis"),
            ("minimum_evidence_status",),
        )
        result = _qualification_result(value["qualification_result"], f"{operation}.qualification_result")
        ingestions = tuple(
            _ingestion(item, f"{operation}.ingestions[{index}]")
            for index, item in enumerate(value["ingestions"])
        )
        minimum = value.get("minimum_evidence_status", "QUALIFIED")
        disposition = qualification_disposition(
            result, ingestions=ingestions, required_evidence_ids=value["required_evidence_ids"],
            verification_basis=value["verification_basis"], minimum_evidence_status=minimum,
        )
        record = disposition.to_canonical()
        inputs = _verification_inputs(
            "verify_qualification_disposition", record,
            qualification_result=result.to_canonical(),
            ingestions=[item.to_canonical() for item in ingestions],
            required_evidence_ids=list(value["required_evidence_ids"]),
            verification_basis=list(value["verification_basis"]), minimum_evidence_status=minimum,
        )
        return record, inputs, ()

    raise CaseError(f"unsupported v1.3 ETQ lifecycle operation {operation!r}")


def _authority(value: Any, operation: str) -> Dict[str, Any]:
    if not isinstance(value, Mapping):
        raise CaseError(
            f"{operation} requires a deployment-owned lifecycle authority snapshot"
        )
    snapshot = copy.deepcopy(dict(value))
    required = {
        "profile", "schema_version", "trust_context", "trust_context_root",
        "policy_roots", "clock", "clock_root", "principal", "principal_binding_root",
    }
    if set(snapshot) != required or snapshot.get("profile") != "crg.lifecycle-authority-snapshot":
        raise CaseError(f"{operation} received an unsupported lifecycle authority snapshot")
    permitted_roles = {
        "RECORD_SIGNATURE_VERIFICATION": {"Decision Approver", "Certificate Signer"},
        "ISSUE_APPROVAL": {"Decision Approver"},
        "ISSUE_APPROVAL_WITHDRAWAL": {"Decision Approver"},
        "EVALUATE_LIFECYCLE_AUTHORIZATION": {"Decision Approver"},
        "BUILD_CONTINUED_VALIDITY": {"Decision Approver"},
    }
    held_roles = set((snapshot.get("principal") or {}).get("roles") or ())
    if operation in permitted_roles and not held_roles.intersection(
        permitted_roles[operation]
    ):
        raise CaseError(
            f"{operation} authenticated principal lacks its least-privilege lifecycle role"
        )
    return snapshot


def _deployment_policy(authority: Mapping[str, Any], action: str, operation: str) -> dict:
    policies = (authority.get("trust_context") or {}).get("policies") or {}
    matches = [policy for policy in policies.values() if action in policy.get("actions", ())]
    if len(matches) != 1:
        raise CaseError(f"{operation} action {action!r} has no unique deployment policy")
    selected = copy.deepcopy(dict(matches[0]))
    selected.pop("actions", None)
    return selected


def _authority_principal(authority: Mapping[str, Any], operation: str) -> dict:
    principal = _object(authority.get("principal"), f"{operation}.authenticated_principal")
    if not principal.get("subject_id") or not principal.get("roles"):
        raise CaseError(f"{operation} has no authenticated principal binding")
    return principal


def _stored_signature_material(
    case: Mapping[str, Any], verification_id: str
) -> tuple[dict, dict, dict]:
    signature_doc = _stored_record(case, "SignatureVerificationRecord", verification_id)
    envelope = _stored_inputs(case, "SignatureVerificationRecord", verification_id)
    if envelope.get("verifier_operation") != "verify_signature_verification_record_v2":
        raise CaseError("approval signatures must originate from cryptographic authority replay v2")
    inputs = _object(envelope.get("inputs"), "stored signature verification inputs")
    return (
        signature_doc,
        _object(inputs.get("signature_content"), "stored signature material"),
        _object(inputs.get("signed_content"), "stored signed lifecycle content"),
    )


def _build_decision_lifecycle(
    operation: str, raw: Any, case: Mapping[str, Any], *,
    authority_snapshot: Any = None,
    producer_crypto_judgment: Any = None,
    validity_source: Any = None,
) -> Tuple[dict, dict, Tuple[Tuple[str, dict], ...]]:
    """Build one v1.4 decision-lifecycle record and its independent-replay inputs."""

    if operation not in _CORE_DECISION_LIFECYCLE_OPERATIONS:
        raise CaseError(f"unsupported v1.4 decision lifecycle operation {operation!r}")

    if operation == "BIND_CONVERSION":
        value = _closed(
            raw, operation,
            (
                "conversion_record", "binding_id", "source_case", "target_case", "retained_geometry",
                "decision_scope", "decision_certificate", "retained_geometry_relation",
                "decision_scope_relation", "authority", "semantic_verifications",
            ),
            ("dependencies",),
        )
        conversion = _conversion(value["conversion_record"], f"{operation}.conversion_record")
        semantics = list(value["semantic_verifications"])
        dependencies = list(value.get("dependencies") or ())
        binding = bind_conversion_to_decision(
            conversion, binding_id=value["binding_id"],
            source_case_root=content_hash(value["source_case"]), target_case_root=content_hash(value["target_case"]),
            retained_geometry_hash=content_hash(value["retained_geometry"]),
            decision_scope_hash=content_hash(value["decision_scope"]),
            decision_certificate_hash=content_hash(value["decision_certificate"]),
            retained_geometry_relation=value["retained_geometry_relation"],
            decision_scope_relation=value["decision_scope_relation"], authority=value["authority"],
            semantic_verification_hashes=tuple(content_hash(item) for item in semantics),
            dependency_hashes=tuple(content_hash(item) for item in dependencies),
        )
        record = binding.to_canonical()
        inputs = _verification_inputs(
            "verify_decision_scoped_conversion", record,
            conversion_record=conversion.to_canonical(), source_case=value["source_case"],
            target_case=value["target_case"], retained_geometry=value["retained_geometry"],
            decision_scope=value["decision_scope"], decision_certificate=value["decision_certificate"],
            semantic_verifications=semantics, dependencies=dependencies,
        )
        return record, inputs, ()

    if operation == "ASSESS_CONVERSION":
        value = _closed(
            raw, operation,
            ("binding_id", "current_conversion_record", "current_retained_geometry", "current_decision_scope", "current_decision_certificate"),
        )
        binding_doc = _stored_record(case, "DecisionScopedConversion", value["binding_id"])
        binding = _binding(binding_doc, f"{operation}.binding")
        impact = assess_conversion_binding(
            binding,
            conversion_record_hash=content_hash(value["current_conversion_record"]),
            retained_geometry_hash=content_hash(value["current_retained_geometry"]),
            decision_scope_hash=content_hash(value["current_decision_scope"]),
            decision_certificate_hash=content_hash(value["current_decision_certificate"]),
        )
        record = impact.to_canonical()
        inputs = _verification_inputs(
            "verify_conversion_binding_impact", record,
            binding=binding_doc, current_conversion_record=value["current_conversion_record"],
            current_retained_geometry=value["current_retained_geometry"],
            current_decision_scope=value["current_decision_scope"],
            current_decision_certificate=value["current_decision_certificate"],
        )
        return record, inputs, ()

    if operation == "RECORD_SIGNATURE_VERIFICATION":
        value = _closed(
            raw, operation,
            ("verification_id", "signature_id", "signature_content", "signed_content"),
            (
                "key_id", "algorithm", "verifier_id", "verifier_version", "checked_at",
                "verified", "failure_reason", "trusted_record_root",
            ),
        )
        authority = _authority(authority_snapshot, operation)
        judgment = _object(producer_crypto_judgment, f"{operation}.producer_crypto_judgment")
        if judgment.get("verified") is not True or judgment.get("status") != "VERIFIED":
            raise CaseError(
                f"{operation} refused cryptography: {judgment.get('reason') or 'unverified'}"
            )
        material = _object(value["signature_content"], f"{operation}.signature_content")
        key_id = str(material.get("key_id") or "")
        context = _object(authority["trust_context"], f"{operation}.trust_context")
        checked_at = authority["clock"]["verifier_evaluation_time"]
        derived = {
            "key_id": key_id,
            "algorithm": "ed25519",
            "verifier_id": "crg-security:Ed25519",
            "verifier_version": context["context_version"],
            "checked_at": checked_at,
            "verified": True,
        }
        for field, expected in derived.items():
            if field in value and value[field] != expected:
                raise CaseError(f"{operation}.{field} is deployment-derived and disagrees with the caller")
        if value.get("trusted_record_root") is not None:
            raise CaseError(f"{operation} callers cannot nominate a trusted record root")
        signature = SignatureVerificationRecord(
            value["verification_id"], value["signature_id"], content_hash(value["signature_content"]),
            content_hash(value["signed_content"]), key_id, "ed25519",
            "crg-security:Ed25519", context["context_version"], checked_at, True, "",
        )
        record = signature.to_canonical()
        inputs = _verification_inputs(
            "verify_signature_verification_record_v2", record,
            signature_content=value["signature_content"],
            signed_content=value["signed_content"], authority_snapshot=authority,
        )
        return record, inputs, ()

    if operation == "ISSUE_APPROVAL":
        value = _closed(
            raw, operation,
            ("approval_id", "artifact", "action", "role", "validity", "signature_verification"),
            ("subject_id", "organization", "signed_at", "authority", "trusted_signature_roots", "signature_content"),
        )
        authority = _authority(authority_snapshot, operation)
        principal = _authority_principal(authority, operation)
        policy_doc = _deployment_policy(authority, value["action"], operation)
        if value.get("trusted_signature_roots"):
            raise CaseError(f"{operation} callers cannot nominate signature trust roots")
        validity = _validity(value["validity"], f"{operation}.validity")
        subject_id = principal["subject_id"]
        subject = (authority["trust_context"].get("subjects") or {}).get(subject_id) or {}
        organization = subject.get("organization")
        role = value["role"]
        if role not in set(subject.get("approval_roles") or ()):
            raise CaseError(f"{operation} role {role!r} is not registered for authenticated subject")
        supplied_signature = _object(value["signature_verification"], f"{operation}.signature_verification")
        verification_id = str(supplied_signature.get("verification_id") or "")
        signature_doc, signature_content, signed_content = _stored_signature_material(
            case, verification_id
        )
        if supplied_signature != signature_doc:
            raise CaseError(f"{operation} signature verification is not the stored immutable record")
        if value.get("signature_content") is not None and value["signature_content"] != signature_content:
            raise CaseError(f"{operation} caller signature bytes disagree with the stored replay input")
        expected_signed = {
            "artifact_hash": content_hash(value["artifact"]),
            "action": value["action"],
            "subject_id": subject_id,
            "role": role,
            "organization": organization,
            "validity": validity.to_canonical(),
            "authority": policy_doc["authority"],
        }
        if set(signed_content) != set(expected_signed) | {"signed_at"}:
            raise CaseError(
                f"{operation} signed payload is not the closed approval contract"
            )
        for field, expected in expected_signed.items():
            if signed_content.get(field) != expected:
                raise CaseError(
                    f"{operation} signed payload {field} disagrees with deployment authority"
                )
        signed_at = str(signed_content.get("signed_at") or "")
        if not signed_at:
            raise CaseError(f"{operation} signed payload omits signed_at")
        for field, expected in (
            ("subject_id", subject_id), ("organization", organization),
            ("signed_at", signed_at), ("authority", policy_doc["authority"]),
        ):
            if field in value and value[field] != expected:
                raise CaseError(f"{operation}.{field} disagrees with the signed deployment-bound payload")
        signature = _signature(signature_doc, f"{operation}.signature_verification")
        approval = ApprovalRecord(
            value["approval_id"], content_hash(value["artifact"]), value["action"], subject_id,
            role, organization, signed_at,
            validity, signature, policy_doc["authority"],
        )
        record = approval.to_canonical()
        inputs = _verification_inputs(
            "verify_approval_record_v2", record,
            signature_content=signature_content, artifact=value["artifact"],
            authority_snapshot=authority, principal=principal,
        )
        return record, inputs, ()

    if operation == "ISSUE_APPROVAL_WITHDRAWAL":
        value = _closed(
            raw, operation,
            ("withdrawal_id", "approval_id", "reason", "signature_verification"),
            ("withdrawn_by", "occurred_at", "authority", "trusted_signature_roots", "signature_content"),
        )
        authority = _authority(authority_snapshot, operation)
        principal = _authority_principal(authority, operation)
        if value.get("trusted_signature_roots"):
            raise CaseError(f"{operation} callers cannot nominate signature trust roots")
        approval_doc = _stored_record(case, "ApprovalRecord", value["approval_id"])
        approval_payload = _object(approval_doc.get("payload"), f"{operation}.approval.payload")
        if approval_payload.get("subject_id") != principal["subject_id"]:
            raise CaseError(f"{operation} authenticated principal does not own the approval")
        policy_doc = _deployment_policy(authority, approval_payload["action"], operation)
        withdrawn_by = principal["subject_id"]
        supplied_signature = _object(value["signature_verification"], f"{operation}.signature_verification")
        verification_id = str(supplied_signature.get("verification_id") or "")
        signature_doc, signature_content, signed_content = _stored_signature_material(
            case, verification_id
        )
        if supplied_signature != signature_doc:
            raise CaseError(f"{operation} signature verification is not the stored immutable record")
        if value.get("signature_content") is not None and value["signature_content"] != signature_content:
            raise CaseError(f"{operation} caller signature bytes disagree with stored replay input")
        expected_signed = {
            "approval_hash": content_hash(approval_doc),
            "withdrawn_by": withdrawn_by,
            "reason": value["reason"],
            "authority": policy_doc["authority"],
        }
        if set(signed_content) != set(expected_signed) | {"occurred_at"}:
            raise CaseError(
                f"{operation} signed payload is not the closed withdrawal contract"
            )
        for field, expected in expected_signed.items():
            if signed_content.get(field) != expected:
                raise CaseError(
                    f"{operation} signed payload {field} disagrees with deployment authority"
                )
        occurred_at = str(signed_content.get("occurred_at") or "")
        if not occurred_at:
            raise CaseError(f"{operation} signed payload omits occurred_at")
        for field, expected in (
            ("withdrawn_by", withdrawn_by), ("occurred_at", occurred_at),
            ("authority", policy_doc["authority"]),
        ):
            if field in value and value[field] != expected:
                raise CaseError(f"{operation}.{field} disagrees with the signed deployment-bound payload")
        signature = _signature(signature_doc, f"{operation}.signature_verification")
        withdrawal = ApprovalWithdrawal(
            value["withdrawal_id"], content_hash(approval_doc), withdrawn_by, value["reason"],
            occurred_at, policy_doc["authority"], signature,
        )
        record = withdrawal.to_canonical()
        inputs = _verification_inputs(
            "verify_approval_withdrawal_v2", record,
            signature_content=signature_content, approval=approval_doc,
            authority_snapshot=authority, principal=principal,
        )
        return record, inputs, ()

    if operation == "EVALUATE_LIFECYCLE_AUTHORIZATION":
        value = _closed(
            raw, operation,
            ("artifact", "action", "approval_ids", "withdrawal_ids"),
            ("policy_id", "policy", "clock", "trusted_signature_roots"),
        )
        authority = _authority(authority_snapshot, operation)
        if value.get("trusted_signature_roots"):
            raise CaseError(f"{operation} callers cannot nominate signature trust roots")
        approvals_doc = [_stored_record(case, "ApprovalRecord", identity) for identity in value["approval_ids"]]
        withdrawals_doc = [_stored_record(case, "ApprovalWithdrawal", identity) for identity in value["withdrawal_ids"]]
        approvals = tuple(_approval(raw, f"{operation}.approvals[{i}]") for i, raw in enumerate(approvals_doc))
        withdrawals = tuple(_withdrawal(raw, f"{operation}.withdrawals[{i}]") for i, raw in enumerate(withdrawals_doc))
        policy_doc = _deployment_policy(authority, value["action"], operation)
        if value.get("policy_id") is not None and value["policy_id"] != policy_doc["policy_id"]:
            raise CaseError(f"{operation}.policy_id is not selected by the deployment")
        if value.get("policy") is not None and value["policy"] != policy_doc:
            raise CaseError(f"{operation}.policy is deployment-owned and cannot be replaced")
        if value.get("clock") is not None and value["clock"] != authority["clock"]:
            raise CaseError(f"{operation}.clock is deployment-owned and cannot be replaced")
        policy = _policy(policy_doc, f"{operation}.policy")
        clock = _clock(authority["clock"], f"{operation}.clock")
        authorization = evaluate_lifecycle_authorization(
            artifact_hash=content_hash(value["artifact"]), action=value["action"], approvals=approvals,
            withdrawals=withdrawals, policy=policy, clock=clock,
        )
        record = authorization.to_canonical()
        approval_signature_inputs = {}
        for approval_doc in approvals_doc:
            identity = str(approval_doc["approval_id"])
            stored = _stored_inputs(case, "ApprovalRecord", identity)
            if stored.get("verifier_operation") != "verify_approval_record_v2":
                raise CaseError(f"{operation} approval {identity!r} is not authority replay v2")
            source = stored["inputs"]
            approval_signature_inputs[identity] = {
                "signature_content": source["signature_content"],
                "principal": source["principal"],
                "authority_snapshot": source["authority_snapshot"],
            }
        withdrawal_signature_inputs = {}
        for withdrawal_doc in withdrawals_doc:
            identity = str(withdrawal_doc["withdrawal_id"])
            stored = _stored_inputs(case, "ApprovalWithdrawal", identity)
            if stored.get("verifier_operation") != "verify_approval_withdrawal_v2":
                raise CaseError(f"{operation} withdrawal {identity!r} is not authority replay v2")
            source = stored["inputs"]
            withdrawal_signature_inputs[identity] = {
                "signature_content": source["signature_content"],
                "principal": source["principal"],
                "approval": source["approval"],
                "authority_snapshot": source["authority_snapshot"],
            }
        inputs = _verification_inputs(
            "verify_lifecycle_authorization_v2", record,
            approvals=approvals_doc, withdrawals=withdrawals_doc, policy=policy.to_canonical(),
            clock=clock.to_canonical(), artifact=value["artifact"], authority_snapshot=authority,
            approval_signature_inputs=approval_signature_inputs,
            withdrawal_signature_inputs=withdrawal_signature_inputs,
        )
        return record, inputs, ()

    if operation == "BUILD_CONTINUED_VALIDITY":
        value = _closed(
            raw, operation,
            ("view_id", "case_id", "artifact_id", "artifact", "reopen_triggers", "trigger_sources", "dependencies"),
            ("evaluated_at", "verifier_clock", "dimensions", "dimension_sources"),
        )
        authority = _authority(authority_snapshot, operation)
        source = _object(validity_source, f"{operation}.canonical_validity_source")
        if source.get("authority_snapshot") != authority or source.get("artifact") != value["artifact"]:
            raise CaseError(f"{operation} canonical validity source is not deployment/artifact bound")
        derived_dimensions = derive_continued_validity_dimensions(source)
        dimension_sources = {
            item["name"]: {"dimension": item["name"], "canonical_validity_source": source}
            for item in derived_dimensions
        }
        dimensions = [
            LifecycleDimension(item["name"], item["state"], item["source_hash"], item["detail"])
            for item in derived_dimensions
        ]
        trigger_sources = _object(value["trigger_sources"], f"{operation}.trigger_sources")
        triggers = []
        for index, raw_trigger in enumerate(value["reopen_triggers"]):
            trigger = _closed(
                raw_trigger, f"{operation}.reopen_triggers[{index}]", ("trigger_id", "condition", "action"),
            )
            trigger_id = trigger["trigger_id"]
            if trigger_id not in trigger_sources:
                raise CaseError(f"{operation}.trigger_sources lacks evidence for {trigger_id!r}")
            triggers.append(
                ReopenTrigger(trigger_id, trigger["condition"], content_hash(trigger_sources[trigger_id]), trigger["action"])
            )
        dependencies = list(value["dependencies"])
        clock_doc = authority["clock"]
        if value.get("verifier_clock") is not None and value["verifier_clock"] != clock_doc:
            raise CaseError(f"{operation}.verifier_clock is deployment-owned")
        evaluated_at = clock_doc["verifier_evaluation_time"]
        if value.get("evaluated_at") is not None and value["evaluated_at"] != evaluated_at:
            raise CaseError(f"{operation}.evaluated_at is deployment-clock-derived")
        clock = _clock(clock_doc, f"{operation}.verifier_clock")
        view = ContinuedValidityView(
            value["view_id"], value["case_id"], value["artifact_id"], content_hash(value["artifact"]),
            evaluated_at, clock, tuple(dimensions), tuple(triggers),
            tuple(content_hash(item) for item in dependencies),
        )
        record = view.to_canonical()
        inputs = _verification_inputs(
            "verify_continued_validity_view_v2", record,
            artifact=value["artifact"], dimension_sources=dimension_sources,
            trigger_sources=trigger_sources, dependencies=dependencies,
            validity_source=source,
        )
        return record, inputs, ()

    raise CaseError(f"unsupported v1.4 decision lifecycle operation {operation!r}")


def _build_resilience_lifecycle(
    operation: str, raw: Any, case: Mapping[str, Any]
) -> Tuple[dict, dict, Tuple[Tuple[str, dict], ...]]:
    """Build one claim-bounded v1.4 portable lifecycle-resilience record."""

    del case  # resilience requests carry every byte needed for independent replay
    if operation not in RESILIENCE_LIFECYCLE_OPERATIONS:
        raise CaseError(f"unsupported v1.4 lifecycle resilience operation {operation!r}")

    if operation == "BUILD_LIFECYCLE_REPLAY":
        value = _closed(
            raw, operation,
            ("replay_id", "source_checkpoint", "records", "verification_inputs"),
        )
        records = tuple(
            _object(item, f"{operation}.records[{index}]")
            for index, item in enumerate(_sequence(value["records"], f"{operation}.records"))
        )
        verifier_inputs = tuple(
            _object(item, f"{operation}.verification_inputs[{index}]")
            for index, item in enumerate(
                _sequence(value["verification_inputs"], f"{operation}.verification_inputs")
            )
        )
        if not records or len(records) != len(verifier_inputs):
            raise CaseError(
                f"{operation} requires non-empty one-to-one records and verification_inputs"
            )
        replay = build_lifecycle_replay_record(
            value["replay_id"], value["source_checkpoint"],
            tuple(zip(records, verifier_inputs)),
        )
        record = replay.to_canonical()
        inputs = resilience_verification_inputs(
            record, source_checkpoint=value["source_checkpoint"],
            records=list(records), verification_inputs=list(verifier_inputs),
        )
        return record, inputs, ()

    if operation == "RECORD_BACKUP_RESTORE_RECOVERY":
        value = _closed(
            raw, operation,
            (
                "recovery_id", "source_snapshot", "backup_snapshot", "restored_snapshot",
                "replay_record", "replay_source_checkpoint", "replay_records",
                "replay_verification_inputs", "authority",
            ),
        )
        snapshots = tuple(
            _object(value[name], f"{operation}.{name}")
            for name in ("source_snapshot", "backup_snapshot", "restored_snapshot")
        )
        replay_record = _object(value["replay_record"], f"{operation}.replay_record")
        recovery = record_backup_restore_recovery(
            value["recovery_id"], snapshots[0], snapshots[1], snapshots[2], replay_record,
            authority=value["authority"],
        )
        record = recovery.to_canonical()
        inputs = resilience_verification_inputs(
            record,
            source_snapshot=snapshots[0], backup_snapshot=snapshots[1],
            restored_snapshot=snapshots[2], replay_record=replay_record,
            replay_source_checkpoint=value["replay_source_checkpoint"],
            replay_records=list(_sequence(value["replay_records"], f"{operation}.replay_records")),
            replay_verification_inputs=list(
                _sequence(
                    value["replay_verification_inputs"],
                    f"{operation}.replay_verification_inputs",
                )
            ),
        )
        companions = tuple(
            (f"resilience-snapshot:{snapshot['snapshot_id']}", snapshot)
            for snapshot in snapshots
        )
        return record, inputs, companions

    if operation == "RECORD_MIGRATION_REVERIFICATION":
        value = _closed(
            raw, operation,
            (
                "reverification_id", "migration_record", "source_object",
                "transformed_object", "lifecycle_record",
                "lifecycle_verification_inputs", "authority",
            ),
        )
        migration_record = _object(
            value["migration_record"], f"{operation}.migration_record"
        )
        lifecycle_record = _object(
            value["lifecycle_record"], f"{operation}.lifecycle_record"
        )
        lifecycle_inputs = _object(
            value["lifecycle_verification_inputs"],
            f"{operation}.lifecycle_verification_inputs",
        )
        reverification = record_migration_reverification(
            value["reverification_id"], migration_record, value["source_object"],
            value["transformed_object"], lifecycle_record, lifecycle_inputs,
            authority=value["authority"],
        )
        record = reverification.to_canonical()
        inputs = resilience_verification_inputs(
            record, migration_record=migration_record,
            source_object=value["source_object"],
            transformed_object=value["transformed_object"],
            lifecycle_record=lifecycle_record,
            lifecycle_verification_inputs=lifecycle_inputs,
        )
        return record, inputs, ()

    raise CaseError(f"unsupported v1.4 lifecycle resilience operation {operation!r}")


def _build(
    operation: str, raw: Any, case: Mapping[str, Any], *,
    authority_snapshot: Any = None,
    producer_crypto_judgment: Any = None,
    validity_source: Any = None,
) -> Tuple[dict, dict, Tuple[Tuple[str, dict], ...]]:
    """Dispatch to a release-owned producer surface without crossing release families."""

    if operation in ETQ_LIFECYCLE_OPERATIONS:
        return _build_etq_lifecycle(operation, raw, case)
    if operation in _CORE_DECISION_LIFECYCLE_OPERATIONS:
        return _build_decision_lifecycle(
            operation, raw, case,
            authority_snapshot=authority_snapshot,
            producer_crypto_judgment=producer_crypto_judgment,
            validity_source=validity_source,
        )
    if operation in RESILIENCE_LIFECYCLE_OPERATIONS:
        return _build_resilience_lifecycle(operation, raw, case)
    raise CaseError(f"unsupported lifecycle operation {operation!r}")


def build_verified_lifecycle_record(
    request: Any, case: Mapping[str, Any] | None = None, *,
    authority_snapshot: Any = None,
    producer_crypto_judgment: Any = None,
    validity_source: Any = None,
) -> Tuple[dict, dict, Any, Tuple[Tuple[str, dict], ...]]:
    """Produce and independently replay one lifecycle record."""

    value = _closed(request, "lifecycle request", ("operation", "inputs"))
    operation = value["operation"]
    if operation not in LIFECYCLE_OPERATIONS:
        raise CaseError(
            f"unknown lifecycle operation {operation!r}; expected one of {list(LIFECYCLE_OPERATIONS)}"
        )
    try:
        record, inputs, companions = _build(
            operation, value["inputs"], case or {},
            authority_snapshot=authority_snapshot,
            producer_crypto_judgment=producer_crypto_judgment,
            validity_source=validity_source,
        )
        verification = verify_lifecycle_record(record, inputs)
    except LifecycleVerificationError:
        raise
    except (KeyError, TypeError, ValueError) as error:
        raise CaseError(f"{operation} request is invalid: {error}") from error
    return record, inputs, verification, companions


def _identity(record: Mapping[str, Any]) -> Tuple[str, str]:
    record_type = str(record.get("record_type") or "")
    if record_type in _CONTENT_IDENTIFIED_RECORDS:
        return record_type, content_hash(record)
    field = _IDENTITY_FIELDS.get(record_type)
    if field is None:
        raise CaseError(f"unsupported lifecycle record_type {record_type!r}")
    identity = str(record.get(field) or "").strip()
    if not identity:
        raise CaseError(f"lifecycle {record_type} has no {field}")
    return record_type, identity


def persist_lifecycle_record(
    case: MutableMapping[str, Any],
    record: Mapping[str, Any],
    verification_inputs: Mapping[str, Any],
    companions: Sequence[Tuple[str, Mapping[str, Any]]] = (),
) -> Tuple[str, str]:
    """Persist a verified immutable version and its exact replay inputs."""

    verification = verify_lifecycle_record(record, verification_inputs)
    record_type, identity = _identity(record)
    canonical = copy.deepcopy(dict(record))
    existing = ((case.get("lifecycle_records") or {}).get(record_type) or {}).get(identity)
    if existing is not None and content_hash(existing) != content_hash(canonical):
        if record_type != "ETQDecisionLoop":
            raise CaseError(
                f"lifecycle {record_type} {identity!r} already names different content; "
                "use a new immutable identity"
            )
        prior_steps = existing.get("steps") if isinstance(existing, Mapping) else None
        next_steps = canonical.get("steps")
        if not isinstance(prior_steps, list) or not isinstance(next_steps, list) or next_steps[: len(prior_steps)] != prior_steps or len(next_steps) != len(prior_steps) + 1:
            raise CaseError("an ETQ loop update must be exactly one immutable-prefix append")
    # Preflight every companion before changing any case dictionary.  Snapshot
    # identity conflicts therefore fail atomically rather than leaving a
    # published record whose portable companions were only partly written.
    prepared_companions: Dict[str, dict] = {}
    existing_companions = case.get("lifecycle_companion_objects") or {}
    if not isinstance(existing_companions, Mapping):
        raise CaseError("lifecycle_companion_objects must be an object")
    for object_id, document in companions:
        name = str(object_id).strip()
        if not name:
            raise CaseError("lifecycle companion identity must be a non-empty string")
        canonical_companion = _object(document, f"lifecycle companion {name!r}")
        prior = prepared_companions.get(name)
        if prior is None:
            prior = existing_companions.get(name)
        if prior is not None and content_hash(prior) != content_hash(canonical_companion):
            raise CaseError(f"lifecycle companion {name!r} already names different bytes")
        prepared_companions[name] = canonical_companion
    root = content_hash(canonical)
    case.setdefault("lifecycle_record_versions", {}).setdefault(record_type, {})[root] = canonical
    case.setdefault("lifecycle_verification_input_versions", {}).setdefault(record_type, {})[root] = copy.deepcopy(dict(verification_inputs))
    case.setdefault("lifecycle_records", {}).setdefault(record_type, {})[identity] = canonical
    case.setdefault("lifecycle_verification_inputs", {}).setdefault(record_type, {})[identity] = copy.deepcopy(dict(verification_inputs))
    if prepared_companions:
        objects = case.setdefault("lifecycle_companion_objects", {})
        for object_id, document in prepared_companions.items():
            objects[object_id] = copy.deepcopy(document)
    record_history(
        case,
        "lifecycle publish",
        {
            "record_type": record_type,
            "record_id": identity,
            "record_hash": root,
            "independently_verified": True,
            "verifier_status": verification.status,
            "mutation_effect": "APPEND_ONLY_RECORD",
        },
    )
    return record_type, identity


def inspect_lifecycle_record(case: Mapping[str, Any], record_type: str, identity: str) -> dict:
    record = _stored_record(case, record_type, identity)
    inputs = _stored_inputs(case, record_type, identity)
    verification = verify_lifecycle_record(record, inputs)
    return {
        "record": record,
        "verification_inputs": inputs,
        "verification": verification.to_json(),
        "direct_state": {
            key: copy.deepcopy(record[key])
            for key in _DIRECT_STATE_FIELDS.get(record_type, ())
            if key in record
        },
        "report": render_lifecycle_report(record, verification),
    }


def portable_lifecycle_objects(case: Mapping[str, Any]) -> Dict[str, Any]:
    """Return every current/versioned record, replay input, and companion object."""

    objects: Dict[str, Any] = {}
    expected_snapshot_roots = set()
    versions = case.get("lifecycle_record_versions") or {}
    input_versions = case.get("lifecycle_verification_input_versions") or {}
    if isinstance(versions, Mapping):
        for record_type, by_hash in sorted(versions.items()):
            if not isinstance(by_hash, Mapping):
                continue
            for root, record in sorted(by_hash.items()):
                if not isinstance(record, Mapping):
                    continue
                inputs = (input_versions.get(record_type) or {}).get(root) if isinstance(input_versions, Mapping) else None
                if not isinstance(inputs, Mapping):
                    raise CaseError(f"lifecycle version {record_type} {root} lacks verifier inputs")
                verify_lifecycle_record(record, inputs)
                if record_type == "BackupRestoreRecoveryRecord":
                    replay_inputs = inputs.get("inputs") or {}
                    for field in (
                        "source_snapshot", "backup_snapshot", "restored_snapshot",
                    ):
                        snapshot = replay_inputs.get(field)
                        if not isinstance(snapshot, Mapping):
                            raise CaseError(
                                f"recovery version {root} lacks carried {field}"
                            )
                        expected_snapshot_roots.add(content_hash(snapshot))
                token = root.split(":", 1)[-1]
                objects[f"lifecycle:{record_type}:{token}"] = copy.deepcopy(dict(record))
                objects[f"lifecycle-verification-inputs:{record_type}:{token}"] = copy.deepcopy(dict(inputs))
    companions = case.get("lifecycle_companion_objects") or {}
    actual_snapshot_roots = set()
    if isinstance(companions, Mapping):
        for object_id, document in sorted(companions.items()):
            if isinstance(document, Mapping):
                if document.get("record_type") == "LifecyclePortableSnapshot":
                    snapshot_root = content_hash(document)
                    if snapshot_root not in expected_snapshot_roots:
                        raise CaseError(
                            f"lifecycle snapshot companion {object_id!r} is not bound to an "
                            "independently verified BackupRestoreRecoveryRecord"
                        )
                    actual_snapshot_roots.add(snapshot_root)
                objects[f"lifecycle-companion:{object_id}"] = copy.deepcopy(dict(document))
    missing_snapshots = sorted(expected_snapshot_roots - actual_snapshot_roots)
    if missing_snapshots:
        raise CaseError(
            "portable recovery export lacks hash-bound LifecyclePortableSnapshot "
            f"companions {missing_snapshots}"
        )
    return objects


def render_lifecycle_report(record: Mapping[str, Any], verification: Any = None) -> str:
    record_type, identity = _identity(record)
    lines = [
        "CRG DECISION LIFECYCLE RECORD",
        "=" * 29,
        "",
        f"Record type: {record_type}",
        f"Identity: {identity}",
        f"Record hash: {content_hash(record)}",
        f"Profile: {record.get('profile', 'not stated')}@{record.get('schema_version', 'not stated')}",
        f"First release: {_RECORD_WORKSTREAM[record_type]}",
        "Mutation effect: APPEND_ONLY_RECORD",
        "Commercial inference: NONE — no ROI, savings, or superiority is inferred.",
    ]
    direct = _DIRECT_STATE_FIELDS.get(record_type, ())
    if direct:
        lines.extend(["", "DIRECT STATES"])
        for field in direct:
            if field in record:
                lines.append(f"- {field}: {record[field]}")
    if record_type == "SignatureVerificationRecord":
        lines.extend(
            [
                "",
                "Claim boundary: signature-verification evidence only; cryptography is not replayed by this surface.",
            ]
        )
    elif record.get("claim_boundary"):
        lines.extend(["", "CLAIM BOUNDARY", str(record["claim_boundary"])])
    else:
        lines.extend(
            [
                "",
                "Claim boundary: this record states only its registered lifecycle facts; it does not imply ROI, confidence, readiness, or undeclared authority.",
            ]
        )
    if verification is not None:
        lines.extend(["", "INDEPENDENT VERIFICATION", f"Status: {verification.status}"])
        for name, passed, detail in verification.checks:
            lines.append(f"- {name}: {'PASS' if passed else 'FAIL'} — {detail}")
    return "\n".join(lines) + "\n"
