"""Decision-scoped lifecycle bindings for ownership/layout conversion.

The conversion theorem certifies minimum movement for a declared conversion
instance.  It does not, by itself, establish that the conversion preserves the
geometry or decision scope of a case.  Roadmap workstream E requires those
objects to be integrated explicitly.  This additive module creates that
binding while keeping execution authorization in ``crg_feedback``.

Normative basis: master specification sections 12, 18, 31, and 32.5, plus
canonical product roadmap section 6.5.  A binding is refused unless every
conversion invariant can be independently recomputed from the record and all
semantic inputs are content-addressed.  ``ready_for_transition_planning`` is
therefore a narrow statement about record completeness; it is not runtime
authorization, physical signoff, or evidence that a transition was executed.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Sequence, Tuple

from crg_model.canonical import content_hash, is_hash

from .record import ConversionRecord

__all__ = [
    "CONVERSION_BINDING_PROFILE",
    "CONVERSION_BINDING_SCHEMA_VERSION",
    "ConversionBindingError",
    "ConversionBindingStatus",
    "DecisionScopedConversion",
    "ConversionBindingImpact",
    "bind_conversion_to_decision",
    "assess_conversion_binding",
]

CONVERSION_BINDING_PROFILE = "crg.decision-scoped-conversion"
CONVERSION_BINDING_SCHEMA_VERSION = "1.0.0"


class ConversionBindingError(ValueError):
    """A conversion cannot be bound to the declared decision context."""


def _hash(value: str, field_name: str) -> str:
    value = str(value)
    if not is_hash(value):
        raise ConversionBindingError(f"{field_name} must be an algorithm-tagged SHA-256 hash")
    return value


class ConversionBindingStatus:
    CURRENT = "CURRENT"
    REVALIDATION_REQUIRED = "REVALIDATION_REQUIRED"
    REOPEN_REQUIRED = "REOPEN_REQUIRED"


@dataclass(frozen=True)
class DecisionScopedConversion:
    """A verified conversion record bound to retained geometry and decision scope."""

    binding_id: str
    conversion_record_id: str
    conversion_record_hash: str
    source_case_root: str
    target_case_root: str
    retained_geometry_hash: str
    decision_scope_hash: str
    decision_certificate_hash: str
    retained_geometry_relation: str
    decision_scope_relation: str
    authority: str
    dependency_hashes: Tuple[str, ...]
    semantic_verification_hashes: Tuple[str, ...]
    invariant_checks: Tuple[Tuple[str, bool], ...]
    verification_program: Tuple[str, ...]
    schema_version: str = CONVERSION_BINDING_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if not self.binding_id or not self.conversion_record_id:
            raise ConversionBindingError("a conversion binding requires stable identities")
        for name in (
            "conversion_record_hash",
            "source_case_root",
            "target_case_root",
            "retained_geometry_hash",
            "decision_scope_hash",
            "decision_certificate_hash",
        ):
            object.__setattr__(self, name, _hash(getattr(self, name), name))
        dependencies = tuple(_hash(v, "dependency_hash") for v in self.dependency_hashes)
        if len(set(dependencies)) != len(dependencies):
            raise ConversionBindingError("conversion binding dependencies contain duplicates")
        object.__setattr__(self, "dependency_hashes", dependencies)
        verification = tuple(
            _hash(v, "semantic_verification_hash") for v in self.semantic_verification_hashes
        )
        if not verification:
            raise ConversionBindingError(
                "the retained-geometry and decision-scope relations require verification evidence"
            )
        if len(set(verification)) != len(verification):
            raise ConversionBindingError("semantic verification evidence contains duplicates")
        object.__setattr__(self, "semantic_verification_hashes", verification)
        if not self.retained_geometry_relation:
            raise ConversionBindingError(
                "the binding must state how retained intersections map to retained geometry"
            )
        if not self.decision_scope_relation:
            raise ConversionBindingError(
                "the binding must state why the conversion is inside the decision scope"
            )
        if not self.authority:
            raise ConversionBindingError("the semantic binding requires a named authority")
        if not self.invariant_checks or not all(ok for _, ok in self.invariant_checks):
            failed = sorted(name for name, ok in self.invariant_checks if not ok)
            raise ConversionBindingError(
                f"conversion record invariants do not establish a binding: {failed or ['ABSENT']}"
            )
        if not self.verification_program:
            raise ConversionBindingError("the conversion binding has no verification program")

    @property
    def ready_for_transition_planning(self) -> bool:
        """True only for complete binding evidence; never runtime authorization."""
        return all(ok for _, ok in self.invariant_checks)

    def to_canonical(self) -> dict:
        return {
            "record_type": "DecisionScopedConversion",
            "profile": CONVERSION_BINDING_PROFILE,
            "schema_version": self.schema_version,
            "binding_id": self.binding_id,
            "conversion_record_id": self.conversion_record_id,
            "conversion_record_hash": self.conversion_record_hash,
            "source_case_root": self.source_case_root,
            "target_case_root": self.target_case_root,
            "retained_geometry_hash": self.retained_geometry_hash,
            "decision_scope_hash": self.decision_scope_hash,
            "decision_certificate_hash": self.decision_certificate_hash,
            "retained_geometry_relation": self.retained_geometry_relation,
            "decision_scope_relation": self.decision_scope_relation,
            "authority": self.authority,
            "dependency_hashes": list(self.dependency_hashes),
            "semantic_verification_hashes": list(self.semantic_verification_hashes),
            "invariant_checks": [
                {"check": name, "passed": passed} for name, passed in self.invariant_checks
            ],
            "verification_program": list(self.verification_program),
            "ready_for_transition_planning": self.ready_for_transition_planning,
            "claim_boundary": (
                "record binding only; not transition authorization, execution evidence, "
                "physical signoff, or a continued-validity judgment"
            ),
        }

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())


@dataclass(frozen=True)
class ConversionBindingImpact:
    """Direct change consequences for a prior decision-scoped binding."""

    binding_hash: str
    status: str
    changed_inputs: Tuple[str, ...]
    required_actions: Tuple[str, ...]
    preserved_binding: bool

    def __post_init__(self) -> None:
        object.__setattr__(self, "binding_hash", _hash(self.binding_hash, "binding_hash"))
        if self.status not in {
            ConversionBindingStatus.CURRENT,
            ConversionBindingStatus.REVALIDATION_REQUIRED,
            ConversionBindingStatus.REOPEN_REQUIRED,
        }:
            raise ConversionBindingError(f"unknown conversion-binding status {self.status!r}")
        if self.status == ConversionBindingStatus.CURRENT and self.changed_inputs:
            raise ConversionBindingError("a CURRENT binding cannot report changed semantic inputs")
        if self.status != ConversionBindingStatus.CURRENT and self.preserved_binding:
            raise ConversionBindingError("a changed semantic input cannot preserve the old binding")

    def to_canonical(self) -> dict:
        return {
            "record_type": "ConversionBindingImpact",
            "profile": CONVERSION_BINDING_PROFILE,
            "schema_version": CONVERSION_BINDING_SCHEMA_VERSION,
            "binding_hash": self.binding_hash,
            "status": self.status,
            "changed_inputs": list(self.changed_inputs),
            "required_actions": list(self.required_actions),
            "preserved_binding": self.preserved_binding,
        }


def bind_conversion_to_decision(
    record: ConversionRecord,
    *,
    binding_id: str,
    source_case_root: str,
    target_case_root: str,
    retained_geometry_hash: str,
    decision_scope_hash: str,
    decision_certificate_hash: str,
    retained_geometry_relation: str,
    decision_scope_relation: str,
    authority: str,
    semantic_verification_hashes: Sequence[str],
    dependency_hashes: Sequence[str] = (),
) -> DecisionScopedConversion:
    """Recompute conversion invariants and bind the exact record to its decision."""
    if not isinstance(record, ConversionRecord):
        raise ConversionBindingError("record must be a ConversionRecord")
    checks = tuple(sorted(record.check_invariants().items()))
    if not checks or not all(ok for _, ok in checks):
        failed = sorted(name for name, ok in checks if not ok)
        raise ConversionBindingError(
            "conversion cannot enter the decision lifecycle because its independently "
            f"recomputed invariants fail: {failed}"
        )
    return DecisionScopedConversion(
        binding_id=binding_id,
        conversion_record_id=record.record_id,
        conversion_record_hash=record.record_hash(),
        source_case_root=source_case_root,
        target_case_root=target_case_root,
        retained_geometry_hash=retained_geometry_hash,
        decision_scope_hash=decision_scope_hash,
        decision_certificate_hash=decision_certificate_hash,
        retained_geometry_relation=retained_geometry_relation,
        decision_scope_relation=decision_scope_relation,
        authority=authority,
        dependency_hashes=tuple(dependency_hashes),
        semantic_verification_hashes=tuple(semantic_verification_hashes),
        invariant_checks=checks,
        verification_program=tuple(record.verification_program),
    )


def assess_conversion_binding(
    binding: DecisionScopedConversion,
    *,
    conversion_record_hash: Optional[str] = None,
    retained_geometry_hash: Optional[str] = None,
    decision_scope_hash: Optional[str] = None,
    decision_certificate_hash: Optional[str] = None,
) -> ConversionBindingImpact:
    """Classify exact current inputs without silently rebinding changed content."""
    supplied = {
        "conversion_record_hash": conversion_record_hash or binding.conversion_record_hash,
        "retained_geometry_hash": retained_geometry_hash or binding.retained_geometry_hash,
        "decision_scope_hash": decision_scope_hash or binding.decision_scope_hash,
        "decision_certificate_hash": decision_certificate_hash or binding.decision_certificate_hash,
    }
    for name, value in supplied.items():
        supplied[name] = _hash(value, name)
    changed = tuple(
        name for name, value in supplied.items() if value != getattr(binding, name)
    )
    if not changed:
        return ConversionBindingImpact(
            binding.fingerprint(), ConversionBindingStatus.CURRENT, (), (), True
        )
    structural = {"conversion_record_hash", "retained_geometry_hash", "decision_scope_hash"}
    if structural.intersection(changed):
        status = ConversionBindingStatus.REOPEN_REQUIRED
        actions = ("RECOMPUTE_OR_VERIFY_CONVERSION", "ISSUE_NEW_DECISION_SCOPED_BINDING")
    else:
        status = ConversionBindingStatus.REVALIDATION_REQUIRED
        actions = ("REVALIDATE_DECISION_CERTIFICATE", "ISSUE_NEW_DECISION_SCOPED_BINDING")
    return ConversionBindingImpact(binding.fingerprint(), status, changed, actions, False)
