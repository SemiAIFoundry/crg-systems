"""crg-conformance: the versioned CRG Systems conformance suite (spec 48, 49).

Reference implementation of sections 48 (conformance architecture) and 49 (test
strategy) of the CRG Operational Systems Master Specification v0.2.0.

This package is not a test suite for the CRG Systems reference modules.  It is
the published suite that decides whether *any* implementation may describe
itself as CRG-conformant, and the difference shows up in three places.

**It calls through an adapter, not into the kernel (48.3).**  Every operation
crosses :class:`crg_conformance.adapter.Implementation` as plain JSON.  The
bundled :mod:`crg_conformance.reference` is one implementation of that contract
and has no privileged position; ``run_all(implementation=other)`` tests
``other`` with the same eighteen invariants and the same twenty-seven vectors.
Specification 48.3 requires a deliberately independent implementation to be
tested for interoperability, and treats divergence as a specification defect
until resolved -- which is impossible to act on if the suite can only test one
codebase.

**Its expectations are data (49.3).**  The twenty-seven required golden cases
live in ``golden/*.json`` with their inputs, their expected outcomes, their
specification citations and a rationale line each.  A harness in another
language reads the same files.

**It reports what it observed (48.2).**  A profile with one failing mandatory
case is not conformant.  An implementation that cannot name itself and its
version is not officially conformant however many cases it passed.  Where
official conformance is unavailable the report states the compatibility
sentence the implementer *is* entitled to publish instead, because 48.2 says an
implementation may truthfully describe compatibility without claiming official
conformance, and a suite that offered only "pass" and "fail" would push honest
implementers toward the wrong one.

Usage::

    from crg_conformance import run_all, conformance_report
    print(conformance_report(run_all()))                     # the reference
    print(conformance_report(run_all(implementation=mine)))  # anyone else
"""
from .adapter import (
    OPERATIONS,
    AdapterError,
    BaseImplementation,
    Implementation,
    OperationSpec,
    UnsupportedOperation,
    operations_for,
)
from .golden import (
    GoldenStep,
    GoldenVector,
    golden_directory,
    load_vectors,
    run_vector,
    run_vectors,
)
from .invariants import INVARIANTS, InvariantSpec, invariant_ids, run_invariant, run_invariants
from .profiles import (
    SPEC_VERSION,
    SUITE_VERSION,
    CaseResult,
    ConformanceReport,
    ConformanceStatus,
    Profile,
    ProfileResult,
    conformance_report,
    run_all,
    run_profile,
)
from .javascript import JavascriptImplementation, javascript_implementation
from .advancement import (
    A2_TRANSACTION_CASE_IDS,
    A2TransactionCaseResult,
    run_a2_transaction_conformance,
)

__version__ = SUITE_VERSION

__all__ = [
    # profiles and reporting (spec 48)
    "Profile",
    "CaseResult",
    "ProfileResult",
    "ConformanceReport",
    "ConformanceStatus",
    "run_profile",
    "run_all",
    "conformance_report",
    "SPEC_VERSION",
    "SUITE_VERSION",
    # the adapter boundary (spec 48.3)
    "Implementation",
    "BaseImplementation",
    "OperationSpec",
    "OPERATIONS",
    "operations_for",
    "AdapterError",
    "UnsupportedOperation",
    "JavascriptImplementation",
    "javascript_implementation",
    # A2 transaction/event verifier vectors
    "A2_TRANSACTION_CASE_IDS",
    "A2TransactionCaseResult",
    "run_a2_transaction_conformance",
    # required invariants (spec 49.2)
    "INVARIANTS",
    "InvariantSpec",
    "invariant_ids",
    "run_invariant",
    "run_invariants",
    # required golden cases (spec 49.3)
    "GoldenVector",
    "GoldenStep",
    "load_vectors",
    "golden_directory",
    "run_vector",
    "run_vectors",
]
