"""A2 transaction vectors over a supplied independent verifier.

The vectors are transport-neutral JSON mutations.  They do not call the
producer or inspect its store; a Python, JavaScript, or external verifier can
consume the same cases and must agree on the result.
"""
from __future__ import annotations

import copy
from dataclasses import dataclass
from typing import Any, Callable, Dict, Mapping, Sequence, Tuple

from crg_model.canonical import content_hash

__all__ = [
    "A2TransactionCaseResult",
    "A2_TRANSACTION_CASE_IDS",
    "run_a2_transaction_conformance",
]

A2_TRANSACTION_CASE_IDS: Tuple[str, ...] = (
    "A2-TX-AUTHENTIC",
    "A2-TX-SEQUENCE-GAP",
    "A2-TX-DUPLICATE-EVENT",
    "A2-TX-STALE-PARENT",
    "A2-TX-LATE-PARENT",
    "A2-TX-REPLAYED-TRANSACTION",
    "A2-TX-ACKNOWLEDGEMENT-DRIFT",
    "A2-TX-UNSUPPORTED-PROFILE",
)


@dataclass(frozen=True)
class A2TransactionCaseResult:
    case_id: str
    expected_ok: bool
    observed_ok: bool

    @property
    def passed(self) -> bool:
        return self.expected_ok is self.observed_ok

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "case_id": self.case_id,
            "expected_ok": self.expected_ok,
            "observed_ok": self.observed_ok,
            "passed": self.passed,
        }


def _seal(record: Dict[str, Any], field: str) -> None:
    record[field] = content_hash({
        key: value for key, value in record.items() if key != field
    })


def _observed_ok(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, Mapping):
        return value.get("ok") is True
    return getattr(value, "ok", False) is True


def _cases(
    receipt: Mapping[str, Any], events: Sequence[Mapping[str, Any]],
) -> Tuple[Tuple[str, bool, Dict[str, Any], list[Dict[str, Any]]], ...]:
    authentic_receipt = copy.deepcopy(dict(receipt))
    authentic_events = [copy.deepcopy(dict(event)) for event in events]
    cases = [("A2-TX-AUTHENTIC", True, authentic_receipt, authentic_events)]

    gap_receipt = copy.deepcopy(authentic_receipt)
    gap_events = copy.deepcopy(authentic_events)
    gap_events[1]["sequence"] += 1
    _seal(gap_events[1], "event_hash")
    cases.append(("A2-TX-SEQUENCE-GAP", False, gap_receipt, gap_events))

    duplicate_events = copy.deepcopy(authentic_events)
    duplicate_events.append(copy.deepcopy(duplicate_events[1]))
    cases.append((
        "A2-TX-DUPLICATE-EVENT", False,
        copy.deepcopy(authentic_receipt), duplicate_events,
    ))

    stale_events = copy.deepcopy(authentic_events)
    stale_events[1]["causal_parent_ids"] = ["missing-parent"]
    _seal(stale_events[1], "event_hash")
    cases.append((
        "A2-TX-STALE-PARENT", False,
        copy.deepcopy(authentic_receipt), stale_events,
    ))

    late_events = copy.deepcopy(authentic_events)
    late_events[2]["causal_parent_ids"] = [late_events[3]["event_id"]]
    _seal(late_events[2], "event_hash")
    cases.append((
        "A2-TX-LATE-PARENT", False,
        copy.deepcopy(authentic_receipt), late_events,
    ))

    replay_events = copy.deepcopy(authentic_events)
    replay_events[1]["transaction"]["transaction_id"] = "replayed-transaction"
    _seal(replay_events[1], "event_hash")
    cases.append((
        "A2-TX-REPLAYED-TRANSACTION", False,
        copy.deepcopy(authentic_receipt), replay_events,
    ))

    ack_receipt = copy.deepcopy(authentic_receipt)
    ack_receipt["acknowledged_event_ids"] = []
    _seal(ack_receipt, "receipt_hash")
    cases.append((
        "A2-TX-ACKNOWLEDGEMENT-DRIFT", False, ack_receipt,
        copy.deepcopy(authentic_events),
    ))

    unsupported_receipt = copy.deepcopy(authentic_receipt)
    unsupported_receipt["profile"] = "crg-agent-transaction/unsupported@99"
    _seal(unsupported_receipt, "receipt_hash")
    cases.append((
        "A2-TX-UNSUPPORTED-PROFILE", False, unsupported_receipt,
        copy.deepcopy(authentic_events),
    ))
    return tuple(cases)


def run_a2_transaction_conformance(
    verifier: Callable[[Mapping[str, Any], Sequence[Mapping[str, Any]]], Any],
    receipt: Mapping[str, Any],
    events: Sequence[Mapping[str, Any]],
) -> Dict[str, Any]:
    """Run the fixed A2 vector set through one supplied verifier."""
    results = []
    for case_id, expected, candidate, sources in _cases(receipt, events):
        observed = _observed_ok(verifier(candidate, sources))
        results.append(A2TransactionCaseResult(case_id, expected, observed))
    return {
        "profile": "crg-conformance/a2-agent-transaction@1",
        "cases": [result.to_canonical() for result in results],
        "passed": all(result.passed for result in results),
        "case_count": len(results),
        "authority": "CONFORMANCE_OBSERVATION_ONLY",
        "execution_authorized": False,
    }
