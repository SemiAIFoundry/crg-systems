"""The required CRG invariants (spec 49.2).

Specification 49.2 says *tests MUST verify* eighteen prohibitions.  They are not
eighteen assertions about the reference implementation; they are eighteen
distinctions the specification refuses to let any implementation collapse, and
each one names a specific way a plausible system silently produces a wrong
answer that looks right:

===  ============================================================  ============
 #   prohibition (49.2, verbatim order)                            enforced in
===  ============================================================  ============
  1  no merging of distinct realization fibers                     19.2, 19.6
  2  no unitless obligation arithmetic                             13.1-13.4
  3  no pruning under scope mismatch                               29.2
  4  no affirmative result from expired evidence                   33.3, 45.3
  5  no treatment of ungenerated as infeasible                     28.4, 28.6
  6  no loss of ties                                               22.4
  7  no conversion of ambiguity into a midpoint winner             22.5
  8  no certificate validity after an affected dependency          30.3, 25.4
     becomes stale
  9  no secondary conversion optimization that violates the        31.3
     primary movement optimum
 10  no runtime transition without valid guards and rollback       32.5
     where consistency may be affected
 11  no global winner claim over an unknown incomplete family      21.4, 21.5
 12  no exact-geometry claim from unproved support samples         19.5, 20.3
 13  no strong certificate from heuristic solver output            5.3, 23.6
 14  no migration inheritance without semantic classification      15.4, 15.5
 15  no dependency cycles                                          18.3
 16  no automatic semantic merge                                   16.3
 17  no valid status when required content is redacted             25.4, 44.2
 18  no use of wall-clock time for monotonic runtime dwell         45.6
===  ============================================================  ============

Each check is a function of the implementation under test returning
``(passed, detail)``.  ``detail`` names what was violated -- not "assertion
failed" -- because a conformance report that cannot say which distinction an
implementation collapsed cannot be acted on by the implementer who has to fix
it, and 48.2 requires that report to be published.

The checks reach the implementation only through
:meth:`crg_conformance.adapter.Implementation.invoke`, so every one of them is
as applicable to a foreign implementation as to the bundled reference.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Iterator, Optional, Tuple

from .adapter import UnsupportedOperation
from .profiles import CaseResult, Profile

__all__ = [
    "InvariantSpec",
    "INVARIANTS",
    "invariant_ids",
    "run_invariant",
    "run_invariants",
    # the eighteen checks
    "no_merging_of_distinct_realization_fibers",
    "no_unitless_obligation_arithmetic",
    "no_pruning_under_scope_mismatch",
    "no_affirmative_result_from_expired_evidence",
    "no_treatment_of_ungenerated_as_infeasible",
    "no_loss_of_ties",
    "no_conversion_of_ambiguity_into_a_midpoint_winner",
    "no_certificate_validity_after_affected_dependency_becomes_stale",
    "no_secondary_optimization_violating_primary_movement_optimum",
    "no_runtime_transition_without_valid_guards_and_rollback",
    "no_global_winner_claim_over_unknown_incomplete_family",
    "no_exact_geometry_claim_from_unproved_support_samples",
    "no_strong_certificate_from_heuristic_solver_output",
    "no_migration_inheritance_without_semantic_classification",
    "no_dependency_cycles",
    "no_automatic_semantic_merge",
    "no_valid_status_when_required_content_is_redacted",
    "no_wall_clock_time_for_monotonic_runtime_dwell",
]

Check = Callable[[Any], Tuple[bool, str]]


# ===========================================================================
# 1. no merging of distinct realization fibers (19.2, 19.6)
# ===========================================================================
def no_merging_of_distinct_realization_fibers(implementation: Any) -> Tuple[bool, str]:
    """Two realizations may share one signature and still be two realizations.

    Two paths to one point in signature space are two engineering objects with
    two bills of material, two supply chains and two risk profiles.  An
    implementation that de-duplicates by signature has silently chosen one of
    them and can no longer say which, so the choice never reaches the person it
    belongs to.
    """
    result = implementation.invoke("build_geometry", {
        "points": {"rho-a": ["2", "3"], "rho-b": ["2", "3"], "rho-c": ["5", "1"]},
    })
    fibers = result["fibers"]
    recovered = sorted(i for f in fibers for i in f["realization_ids"])
    if recovered != ["rho-a", "rho-b", "rho-c"]:
        return False, (
            "R lost a realization: three legal realizations went in and "
            f"{recovered} came back; distinct realizations were merged (spec 19.2)")
    shared = [f for f in fibers if f["signature"] == ["2", "3"]]
    if len(shared) != 1:
        return False, (
            f"the signature (2, 3) produced {len(shared)} fibers; one signature is "
            "one fiber (spec 19.2)")
    if sorted(shared[0]["realization_ids"]) != ["rho-a", "rho-b"]:
        return False, (
            "the fiber over signature (2, 3) carries "
            f"{shared[0]['realization_ids']} but rho-a and rho-b both realize it; "
            "the fiber was collapsed to a single representative (spec 19.2, 19.6)")
    if len(fibers) != 2:
        return False, (
            f"two distinct signatures produced {len(fibers)} fibers (spec 19.2)")
    if result.get("verify_errors"):
        return False, f"geometry self-verification failed: {result['verify_errors']}"
    return True, (
        "rho-a and rho-b share signature (2, 3) and remain separately recoverable "
        "from the fiber over it; three realizations in, three out, two fibers")


# ===========================================================================
# 2. no unitless obligation arithmetic (13.1-13.4)
# ===========================================================================
def no_unitless_obligation_arithmetic(implementation: Any) -> Tuple[bool, str]:
    """A quantity without a declared unit is not a number you may add.

    Every unit-mismatch catastrophe in engineering has the same shape: two
    numbers that were never comparable were added because the type system said
    they were both floats.
    """
    same = implementation.invoke("quantity_add", {
        "a": {"value": "3/4", "unit": "m"}, "b": {"value": "1/4", "unit": "m"}})
    if not same.get("ok") or same.get("value") != "1/1":
        return False, (
            "addition within one declared unit must succeed and be exact; got "
            f"ok={same.get('ok')} value={same.get('value')!r}")
    mismatch = implementation.invoke("quantity_add", {
        "a": {"value": "3/4", "unit": "m"}, "b": {"value": "1/4", "unit": "s"}})
    if mismatch.get("ok") or mismatch.get("value") is not None:
        return False, (
            f"3/4 m + 1/4 s was accepted and produced {mismatch.get('value')!r}; "
            "arithmetic across two declared units is not defined (spec 13.2)")
    if not mismatch.get("refusal"):
        return False, "the unit mismatch was refused without naming a reason (spec 13.2)"
    for label, operand in (("b", {"value": "1/4", "unit": None}),
                           ("b", {"value": "1/4", "unit": ""})):
        unitless = implementation.invoke("quantity_add", {
            "a": {"value": "3/4", "unit": "m"}, "b": operand})
        if unitless.get("ok") or unitless.get("value") is not None:
            return False, (
                f"a quantity with unit {operand['unit']!r} was admitted into obligation "
                "arithmetic; an unstated unit is not a dimensionless one (spec 13.1)")
    return True, (
        "same-unit addition is exact (3/4 m + 1/4 m = 1/1 m); a unit mismatch and an "
        "absent unit are each refused with a stated reason")


# ===========================================================================
# 3. no pruning under scope mismatch (29.2 condition 3)
# ===========================================================================
_PRUNE_FAMILY = {"left": ["0", "10"], "mid": ["5", "5"], "right": ["10", "0"]}


def no_pruning_under_scope_mismatch(implementation: Any) -> Tuple[bool, str]:
    """A bound proved for one decision does not authorize deletion for another.

    This is the invariant that makes retention auditable at all.  A bound is a
    statement about an objective; carrying it to a different objective is not a
    shortcut, it is a different claim.
    """
    matched = implementation.invoke("prune", {
        "candidates": _PRUNE_FAMILY, "scope_id": "prune-scope",
        "objective": {"latency": "1", "energy": "3"},
        "prune_candidates": ["mid"]})
    if matched.get("pruned") != ["mid"]:
        return False, (
            "a candidate whose bound was issued under the query's own scope was not "
            f"pruned; got pruned={matched.get('pruned')}.  The invariant is that a "
            "scope MISMATCH blocks pruning, not that pruning never happens")
    mismatched = implementation.invoke("prune", {
        "candidates": _PRUNE_FAMILY, "scope_id": "prune-scope",
        "objective": {"latency": "1", "energy": "3"},
        "prune_candidates": ["mid"],
        "bound_scopes": {"mid": "some-other-decision"}})
    if mismatched.get("pruned"):
        return False, (
            f"pruned {mismatched['pruned']} on a bound issued under decision scope "
            "'some-other-decision' while the query scope was 'prune-scope'; "
            "spec 29.2 condition 3 requires the scopes to match")
    if "mid" not in (mismatched.get("retained") or []):
        return False, (
            "the scope-mismatched candidate was neither pruned nor retained; it must "
            "survive the retention set (spec 29.2)")
    if not mismatched.get("refusal"):
        return False, (
            "pruning under a scope mismatch was declined without a stated reason; "
            "an unexplained empty result is indistinguishable from a numeric near miss")
    return True, (
        "a scope-matched bound prunes 'mid'; the identical bound issued under "
        "'some-other-decision' prunes nothing and the refusal names the mismatch")


# ===========================================================================
# 4. no affirmative result from expired evidence (33.3, 45.3)
# ===========================================================================
def no_affirmative_result_from_expired_evidence(implementation: Any) -> Tuple[bool, str]:
    """Expiry is a fact about the evidence, not a warning to be overridden."""
    current = implementation.invoke("evidence_applicability", {
        "clock_at": "2026-06-01T00:00:00Z"})
    if not current.get("affirmative") or current.get("status") != "APPLICABLE":
        return False, (
            "unexpired evidence under an unexpired rule must yield a value; got "
            f"status={current.get('status')!r} value={current.get('value')!r}")
    expired_evidence = implementation.invoke("evidence_applicability", {
        "clock_at": "2026-06-01T00:00:00Z",
        "evidence_expires_at": "2026-02-01T00:00:00Z"})
    if expired_evidence.get("affirmative") or expired_evidence.get("value") is not None:
        return False, (
            "evidence that expired 2026-02-01 produced the affirmative value "
            f"{expired_evidence.get('value')!r} at clock 2026-06-01 (spec 45.3)")
    if expired_evidence.get("status") != "EXPIRED":
        return False, (
            f"expired evidence reported status {expired_evidence.get('status')!r}; "
            "EXPIRED is a distinct status and must not be folded into a generic refusal")
    expired_rule = implementation.invoke("evidence_applicability", {
        "clock_at": "2026-06-01T00:00:00Z",
        "rule_expiration": "2026-02-01T00:00:00Z"})
    if expired_rule.get("affirmative") or expired_rule.get("value") is not None:
        return False, (
            "an applicability rule that expired 2026-02-01 still carried evidence at "
            f"clock 2026-06-01 and produced {expired_rule.get('value')!r} (spec 33.3)")
    return True, (
        "current evidence yields a bounded value; expired evidence yields EXPIRED with "
        f"reason {expired_evidence.get('reason_code')!r} and no value, and an expired "
        f"rule yields {expired_rule.get('reason_code')!r} and no value")


# ===========================================================================
# 5. no treatment of ungenerated as infeasible (28.4, 28.6)
# ===========================================================================
def no_treatment_of_ungenerated_as_infeasible(implementation: Any) -> Tuple[bool, str]:
    """"We did not look there" is not "there is nothing there".

    A search truncated at depth one has said nothing about depth two.  An
    implementation that reports the unexplored region as infeasible has turned
    a budget limit into a physical claim.
    """
    closed = implementation.invoke("generate_family", {"generator": "placement"})
    if closed.get("ungenerated_count"):
        return False, (
            "a closure that reached its fixpoint still reported "
            f"{closed['ungenerated_count']} ungenerated region(s)")
    truncated = implementation.invoke("generate_family",
                                      {"generator": "placement", "max_depth": 1})
    if not truncated.get("ungenerated_count"):
        return False, (
            "a closure truncated at depth 1 reported no ungenerated region; the "
            "unexpanded frontier and everything below it is UNGENERATED (spec 28.4)")
    if truncated.get("infeasible_count"):
        return False, (
            f"the truncated closure reported {truncated['infeasible_count']} INFEASIBLE "
            "realization(s); truncation establishes nothing about feasibility "
            "(spec 28.4, 28.6)")
    statuses = set((truncated.get("statuses") or {}).values())
    if "INFEASIBLE" in statuses or "UNGENERATED" in statuses:
        return False, (
            f"generated records carry legality {sorted(statuses)}; UNGENERATED is a "
            "property of a region that has no record, and INFEASIBLE is a verdict on "
            "a record that was evaluated (spec 28.6)")
    if truncated.get("basis") != "TRUNCATED_BY_DECLARED_RULE":
        return False, (
            f"a truncated closure derived basis {truncated.get('basis')!r}; "
            "TRUNCATED_BY_DECLARED_RULE is what truncation means (spec 21.2)")
    return True, (
        f"the fixpoint run has 0 ungenerated regions; the depth-1 run has "
        f"{truncated['ungenerated_count']} ungenerated region(s), 0 INFEASIBLE "
        "realizations, and basis TRUNCATED_BY_DECLARED_RULE")


# ===========================================================================
# 6. no loss of ties (22.4)
# ===========================================================================
def no_loss_of_ties(implementation: Any) -> Tuple[bool, str]:
    """Two exactly equal candidates are two answers, not one answer and a rounding.

    Tie-breaking is a policy decision.  Whoever makes it must know they made it,
    which means the tie has to survive the arithmetic to reach them.
    """
    tie = implementation.invoke("certify_decision", {
        "candidates": {"a": ["5", "5"], "b": ["4", "6"]},
        "objective": {"latency": "1", "energy": "1"}})
    winners = sorted(tie.get("winners") or [])
    if winners != ["a", "b"]:
        return False, (
            "a = (5, 5) and b = (4, 6) both value 10 under weights (1, 1), but the "
            f"certificate selected {winners}; the tie was broken silently (spec 22.4)")
    if sorted(tie.get("ties") or []) != ["a", "b"]:
        return False, (
            f"both candidates were selected but the tie set is {tie.get('ties')}; a "
            "reader cannot tell a tie from a joint winner without it")
    if tie.get("margin") is not None:
        return False, (
            f"a margin of {tie['margin']} was reported between exactly equal "
            "candidates; there is no margin between equals to report")
    tolerance = implementation.invoke("certify_decision", {
        "candidates": {"a": ["5", "5"], "b": ["5", "501/100"]},
        "objective": {"latency": "1", "energy": "1"}, "tolerance": "1/10"})
    if sorted(tolerance.get("winners") or []) != ["a", "b"]:
        return False, (
            "candidates 1/100 apart under a declared policy tolerance of 1/10 were "
            f"separated into {tolerance.get('winners')}; a declared tolerance makes "
            "them indistinguishable as a matter of policy (spec 22.4)")
    return True, (
        f"the exact tie yields {tie['outcome']} over both candidates with no margin; "
        f"the tolerance-driven tie yields {tolerance['outcome']} over both")


# ===========================================================================
# 7. no conversion of ambiguity into a midpoint winner (22.5)
# ===========================================================================
def no_conversion_of_ambiguity_into_a_midpoint_winner(
        implementation: Any) -> Tuple[bool, str]:
    """An overlapping enclosure is not resolved by taking its centre.

    Collapsing [1, 3] to 2 and [2, 7/2] to 11/4 produces a confident winner out
    of two measurements that do not distinguish the candidates at all.  The
    honest answer is the set.
    """
    result = implementation.invoke("certify_decision", {
        "candidates": {"a": ["1", "1"], "b": ["2", "2"], "c": ["50", "50"]},
        "evidence_intervals": {"a": ["1", "3"], "b": ["2", "7/2"], "c": ["99", "101"]},
        "objective": {"latency": "1", "energy": "1"}})
    winners = sorted(result.get("winners") or [])
    if result.get("winner_count") == 1:
        return False, (
            f"candidate {winners} was certified the winner although the enclosures "
            "[1, 3] and [2, 7/2] overlap; a point inside an interval is not a "
            "measurement (spec 22.5)")
    if winners != ["a", "b"]:
        return False, (
            f"the possible-winner set is {winners}; a and b overlap and must both be "
            "in it, and c ([99, 101]) must not")
    if result.get("outcome") != "POSSIBLE_WINNER_SET":
        return False, (
            f"an unresolved comparison reported outcome {result.get('outcome')!r}; "
            "the outcome must say the comparison did not resolve")
    if result.get("margin") is not None:
        return False, (
            f"a margin of {result['margin']} was reported over an unresolved set")
    boundary = implementation.invoke("phase_boundary", {
        "bounds": {"throughput": ["110", "130"], "yield_loss": ["3", "6"]},
        "thresholds": ["120"]})
    if not boundary.get("crosses"):
        return False, ("the fixture enclosure was expected to straddle the declared "
                       "phase boundary but did not; the invariant was not exercised")
    if boundary.get("resolved"):
        return False, (
            "an enclosure straddling a declared phase boundary was resolved to "
            f"{boundary.get('region_state')!r}; neither side is established (spec 34.5)")
    return True, (
        f"overlapping enclosures yield {result['outcome']} over ['a', 'b'] with no "
        f"margin; the boundary-crossing region stays {boundary['region_state']}")


# ===========================================================================
# 8. no certificate validity after an affected dependency becomes stale (30.3)
# ===========================================================================
def no_certificate_validity_after_affected_dependency_becomes_stale(
        implementation: Any) -> Tuple[bool, str]:
    """A certificate is a claim about inputs.  When an input moves, so does it.

    The dual obligation matters as much: an *unaffected* certificate must
    survive, or every change invalidates everything and the classification is
    theatre.
    """
    changed = implementation.invoke("classify_change", {
        "changed_object": "price-a", "changed_properties": ["price.package_gbps"],
        "certificate_under_test": "cert-a"})
    if changed.get("certificate_status_after") == changed.get("certificate_status_before"):
        return False, (
            "cert-a depends on price-a, price-a changed, and cert-a's status stayed "
            f"{changed.get('certificate_status_after')!r} (spec 30.3)")
    if changed.get("certificate_status_after") != "STALE":
        return False, (
            "the affected certificate was marked "
            f"{changed.get('certificate_status_after')!r} rather than STALE")
    if "cert-a" not in (changed.get("invalidated") or []):
        return False, (
            f"the impact plan invalidated {changed.get('invalidated')}, which does not "
            "include the certificate whose dependency changed")
    if "cert-b" not in (changed.get("preserved") or []):
        return False, (
            "cert-b sits on a disjoint branch and was not preserved; propagation must "
            "stop where the typed edges stop (spec 30.3)")
    unrelated = implementation.invoke("classify_change", {
        "changed_object": "price-b", "changed_properties": ["price.package_gbps"],
        "certificate_under_test": "cert-a"})
    if unrelated.get("certificate_status_after") != "ACTIVE":
        return False, (
            "a change on the other branch marked cert-a "
            f"{unrelated.get('certificate_status_after')!r}; an unaffected certificate "
            "must survive")
    verified = implementation.invoke("verify_certificate",
                                     {"stale_dependencies": ["first"]})
    if verified.get("ok"):
        return False, (
            "the independent verifier returned "
            f"{verified.get('status')!r} for a certificate whose pinned dependency has "
            "moved on; a content-addressed dependency that no longer hashes to the "
            "pinned value is a stale dependency (spec 25.4)")
    return True, (
        "price-a changes: cert-a goes ACTIVE -> STALE and is invalidated, cert-b is "
        f"preserved; price-b changes: cert-a stays ACTIVE; and the verifier returns "
        f"{verified.get('status')!r} on a moved dependency")


# ===========================================================================
# 9. no secondary optimization violating the primary movement optimum (31.3)
# ===========================================================================
_SECONDARY_LAYOUT = {"source": {"K": 12, "C": 4}, "target": {"K": 12, "C": 6}}


def no_secondary_optimization_violating_primary_movement_optimum(
        implementation: Any) -> Tuple[bool, str]:
    """Routing, energy and makespan are optimized *inside* the retention optimum.

    A secondary objective that is allowed to move data is not a secondary
    objective; it is a second primary one, and the contract that authorized the
    conversion did not agree to it.
    """
    cost = tuple(tuple("1" if (i, j) != (0, 1) else "0" for j in range(12))
                 for i in range(12))
    refused = implementation.invoke("secondary_objective", dict(
        _SECONDARY_LAYOUT, kind="ENERGY", cost=[list(row) for row in cost]))
    if not refused.get("primary_respected"):
        return False, (
            "a secondary ENERGY optimization moved off the primary retention optimum "
            f"({refused.get('achieved_retention')} vs {refused.get('primary_retained')}) "
            "with no contract authorization (spec 31.3)")
    if refused.get("achieved_retention") != refused.get("primary_retained"):
        return False, (
            f"retention fell to {refused.get('achieved_retention')} from the primary "
            f"optimum {refused.get('primary_retained')} without express authorization")
    if not refused.get("trade_refused"):
        return False, (
            "a cheaper secondary assignment existed only at lower retention and the "
            "refusal was not recorded; an unrecorded refusal cannot be audited")
    unattributed = implementation.invoke("secondary_objective", dict(
        _SECONDARY_LAYOUT, kind="ENERGY", cost=[list(row) for row in cost],
        permit_movement_trade=True))
    if unattributed.get("ok"):
        return False, (
            "a movement trade was permitted by a bare boolean with no contract clause "
            "named; 31.3 requires an express authorization, not a flag")
    authorized = implementation.invoke("secondary_objective", dict(
        _SECONDARY_LAYOUT, kind="ENERGY", cost=[list(row) for row in cost],
        permit_movement_trade=True, authorization="conversion contract clause 7.2"))
    if not authorized.get("trade_permitted"):
        return False, (
            "an expressly authorized movement trade was not taken; 31.3 permits it "
            "when the governing contract says so, and refusing it would be a "
            "different error")
    return True, (
        f"the unauthorized ENERGY trade is refused and retention holds at "
        f"{refused['primary_retained']}; a bare permit flag is refused for naming no "
        f"clause; the clause-authorized trade is taken and discloses retention "
        f"{authorized.get('achieved_retention')}")


# ===========================================================================
# 10. no runtime transition without valid guards and rollback (32.5)
# ===========================================================================
def no_runtime_transition_without_valid_guards_and_rollback(
        implementation: Any) -> Tuple[bool, str]:
    """Fourteen plan items, and no item is ever defaulted.

    A synthesized phase guard or rollback presents an omission as a decision.
    The system would then be reconfigured on the strength of a guard nobody
    wrote.
    """
    complete = implementation.invoke("runtime_transition", {})
    if complete.get("status") != "COMPLETED" or not complete.get("guards_valid"):
        return False, (
            "a fully specified L1 plan with fresh telemetry did not complete; got "
            f"status={complete.get('status')!r} guards_valid="
            f"{complete.get('guards_valid')}.  The invariant is that an incomplete "
            "plan is refused, not that no transition ever runs")
    without_rollback = implementation.invoke("runtime_transition",
                                             {"drop_items": ["rollback"]})
    if without_rollback.get("status") not in ("INCOMPLETE_PLAN", "REFUSED",
                                              "NOT_AUTHORIZED"):
        return False, (
            "a transition plan with no rollback reached status "
            f"{without_rollback.get('status')!r}; 32.5 requires the rollback and "
            "forbids defaulting it")
    if "rollback" not in (without_rollback.get("missing") or []):
        return False, (
            "the plan was refused without naming the missing item; the implementer "
            "cannot fix what the refusal does not name")
    without_guard = implementation.invoke("runtime_transition",
                                          {"drop_items": ["phase_guard"]})
    if without_guard.get("status") not in ("INCOMPLETE_PLAN", "REFUSED",
                                           "NOT_AUTHORIZED"):
        return False, (
            "a transition plan with no phase guard reached status "
            f"{without_guard.get('status')!r} (spec 32.5)")
    stale = implementation.invoke("runtime_transition", {"telemetry_age_ticks": 5000})
    if stale.get("status") not in ("REFUSED", "NOT_AUTHORIZED"):
        return False, (
            "a transition was planned on telemetry 5000 ticks old against a declared "
            f"250-tick freshness window; got status={stale.get('status')!r}")
    if stale.get("refusal_reason") != "STALE_TELEMETRY":
        return False, (
            f"the stale-telemetry refusal was reported as "
            f"{stale.get('refusal_reason')!r}; a stale sensor and a failed guard have "
            "different remedies and must not share a reason code")
    failed = implementation.invoke("runtime_transition",
                                   {"observed_throughput": "900"})
    if not failed.get("rolled_back") or not failed.get("rollback_verified"):
        return False, (
            "a failed postcondition left the system at "
            f"{failed.get('final_config_id')!r} with rolled_back="
            f"{failed.get('rolled_back')} and rollback_verified="
            f"{failed.get('rollback_verified')}; a rollback that is not verified to "
            "have returned the source configuration is not a recovery")
    return True, (
        "the complete plan completes; dropping the rollback and dropping the phase "
        "guard are each refused by name; stale telemetry refuses with "
        "STALE_TELEMETRY; and a failed postcondition rolls back to a verified source "
        "configuration")


# ===========================================================================
# 11. no global winner claim over an unknown incomplete family (21.4, 21.5)
# ===========================================================================
_GLOBAL_FAMILY = {"fast": ["1", "1"], "slow": ["5", "5"]}


def no_global_winner_claim_over_unknown_incomplete_family(
        implementation: Any) -> Tuple[bool, str]:
    """The same winner over a different family is a different claim.

    "The best option" and "the best of the three we happen to have imported"
    are separated by exactly one fact: whether anything else exists.
    """
    exhaustive = implementation.invoke("certify_decision", {
        "candidates": _GLOBAL_FAMILY, "basis": "EXHAUSTIVE_DECLARED_UNIVERSE"})
    if not exhaustive.get("global_claim"):
        return False, (
            "a winner over an exhaustively declared universe was not permitted a "
            f"global claim (claim scope {exhaustive.get('claim_scope')!r}); the "
            "invariant bites on incomplete families, not complete ones")
    imported = implementation.invoke("certify_decision", {
        "candidates": _GLOBAL_FAMILY, "basis": "EXPLICIT_IMPORTED_FAMILY"})
    if imported.get("global_claim"):
        return False, (
            "an explicitly imported family produced claim scope "
            f"{imported.get('claim_scope')!r}, which carries a globally phrased "
            "winner; importing one more candidate could overturn it (spec 21.5)")
    if imported.get("claim_scope") != "RELATIVE_EXPLICIT_FAMILY":
        return False, (
            f"an imported family derived claim scope {imported.get('claim_scope')!r}; "
            "21.4 fixes RELATIVE_EXPLICIT_FAMILY for it")
    if not imported.get("reopen_conditions"):
        return False, (
            "a relative claim carried no reopen condition; the reader is not told "
            "what would overturn it (spec 21.5)")
    incomplete = implementation.invoke("certify_decision", {
        "candidates": _GLOBAL_FAMILY, "basis": "KNOWN_INCOMPLETE"})
    if incomplete.get("global_claim") or incomplete.get("winners"):
        return False, (
            "a KNOWN_INCOMPLETE family produced winner(s) "
            f"{incomplete.get('winners')} at claim scope "
            f"{incomplete.get('claim_scope')!r}; a partial family supports no winner "
            "claim at all (spec 21.4, 21.5)")
    bounded_unproved = implementation.invoke("certify_decision", {
        "candidates": _GLOBAL_FAMILY, "basis": "BOUNDED_UNENUMERATED_FAMILY"})
    if bounded_unproved.get("global_claim"):
        return False, (
            "a declared remainder bound with no recorded closure proof produced the "
            f"global claim scope {bounded_unproved.get('claim_scope')!r}; a bound "
            "closes the remainder only with a proof (spec 21.6)")
    bounded_proved = implementation.invoke("certify_decision", {
        "candidates": _GLOBAL_FAMILY, "basis": "BOUNDED_UNENUMERATED_FAMILY",
        "closure_proof": "proof-2026-03: every unenumerated member costs at least 100"})
    if not bounded_proved.get("global_claim"):
        return False, (
            "a remainder bound with a recorded closure proof was still denied a global "
            f"claim (scope {bounded_proved.get('claim_scope')!r}); 21.6 licenses "
            "BOUNDED_REMAINDER_GLOBAL exactly there")
    return True, (
        f"exhaustive -> {exhaustive['claim_scope']} (global); imported -> "
        f"{imported['claim_scope']} with a reopen condition; known-incomplete -> "
        f"{incomplete['claim_scope']} with no winner; bounded without proof -> "
        f"{bounded_unproved['claim_scope']}; bounded with proof -> "
        f"{bounded_proved['claim_scope']}")


# ===========================================================================
# 12. no exact-geometry claim from unproved support samples (19.5, 20.3)
# ===========================================================================
def no_exact_geometry_claim_from_unproved_support_samples(
        implementation: Any) -> Tuple[bool, str]:
    """A finite price sample bounds the support error; it does not prove equality.

    An implementation may narrow the sample set until the error reads zero.
    That number is a statement about the sample set, and the artifact must keep
    saying so.
    """
    sampled = implementation.invoke("support_claim", {
        # The inner region is the *worse* family: its generators must lie in the
        # outer region's upper set for 20.1's envelope to hold at all.
        "inner": {"a": ["0", "12"], "b": ["6", "6"], "c": ["12", "0"]},
        "outer": {"a": ["0", "10"], "b": ["4", "4"], "c": ["10", "0"]}})
    if sampled.get("claim_limit") != "APPROXIMATE_NOT_EXACT_GEOMETRY":
        return False, (
            f"a sampled envelope carried claim limit {sampled.get('claim_limit')!r}; "
            "20.3 requires every sampled envelope to be stamped as an approximation")
    if sampled.get("samples_proved"):
        return False, (
            "the envelope asserts its price sample set was proved determining; the "
            "artifact carries no such proof (spec 19.5)")
    if sampled.get("exact"):
        return False, (
            "an exactness claim was made on the strength of a sampled support bound "
            f"(bound {sampled.get('bound')!r}) although region inclusion holds in one "
            "direction only")
    narrowed = implementation.invoke("support_claim", {
        # The inner region is the *worse* family: its generators must lie in the
        # outer region's upper set for 20.1's envelope to hold at all.
        "inner": {"a": ["0", "12"], "b": ["6", "6"], "c": ["12", "0"]},
        "outer": {"a": ["0", "10"], "b": ["4", "4"], "c": ["10", "0"]},
        "price_samples": [["1", "0"], ["0", "1"]]})
    if narrowed.get("exact"):
        return False, (
            f"narrowing the price domain to two vectors drove the bound to "
            f"{narrowed.get('bound')!r} and the implementation upgraded that to an "
            "exactness claim, although the regions genuinely differ "
            f"(inclusion_backward={narrowed.get('inclusion_backward')})")
    if narrowed.get("claim_limit") != "APPROXIMATE_NOT_EXACT_GEOMETRY":
        return False, (
            "the narrowed-domain envelope dropped its approximation stamp")
    return True, (
        f"the sampled envelope carries bound {sampled['bound']} over "
        f"{sampled.get('sample_count')} declared price vectors, claim limit "
        f"{sampled['claim_limit']}, and exact=False; narrowing the domain drives the "
        f"bound to {narrowed['bound']} and still does not buy exactness")


# ===========================================================================
# 13. no strong certificate from heuristic solver output (5.3, 23.6)
# ===========================================================================
def no_strong_certificate_from_heuristic_solver_output(
        implementation: Any) -> Tuple[bool, str]:
    """A heuristic may propose or rank.  It may not authorize.

    The dangerous case is not a heuristic that is wrong; it is a heuristic that
    is usually right, whose output has been carried into an artifact that says
    "certified".
    """
    result = implementation.invoke("verify_certificate", {"heuristic_solver_trust": True})
    if result.get("heuristic_never_authorizes") is None:
        return False, (
            "the verifier ran no heuristic-authorization check at all; the absence of "
            "a check is not a pass (spec 23.6)")
    if result.get("heuristic_never_authorizes"):
        return False, (
            f"a certificate with outcome {result.get('outcome')!r} rests on decision "
            "values whose solver trust profile is HEURISTIC and the verifier passed it; "
            f"detail: {result.get('heuristic_detail')!r}")
    if result.get("ok"):
        return False, (
            f"the verifier returned {result.get('status')!r} overall for a "
            "heuristic-authorized certified outcome")
    return True, (
        f"a certified outcome resting on HEURISTIC-classed decision values is refused "
        f"by the independent verifier: status {result.get('status')!r}, "
        f"heuristic_never_authorizes=False -- {result.get('heuristic_detail')}")


# ===========================================================================
# 14. no migration inheritance without semantic classification (15.4, 15.5)
# ===========================================================================
def no_migration_inheritance_without_semantic_classification(
        implementation: Any) -> Tuple[bool, str]:
    """A certificate crosses a schema boundary only across a proved equivalence.

    Migration is where old claims quietly acquire new meanings.  Carrying a
    certificate across an unclassified migration republishes a claim about
    yesterday's semantics as a claim about today's.
    """
    unclassified = implementation.invoke("migrate", {"target_schema_version": "0.3.0"})
    if unclassified.get("inherited"):
        return False, (
            "certificates were carried across a migration with no declared semantic "
            f"classification (reported class {unclassified.get('classification')!r})")
    if unclassified.get("active_certificates"):
        return False, (
            "an unclassified migration left "
            f"{unclassified['active_certificates']} active; they must be superseded "
            "and revalidation required (spec 15.5)")
    if not unclassified.get("revalidation_required"):
        return False, (
            "an unclassified migration did not require revalidation; silence is not a "
            "classification")
    equivalent_label_only = implementation.invoke("migrate", {
        "target_schema_version": "0.3.0",
        "migration_class": "SEMANTICALLY_EQUIVALENT"})
    if equivalent_label_only.get("inherited") or equivalent_label_only.get("ok"):
        return False, (
            "a caller-supplied SEMANTICALLY_EQUIVALENT label authorized an unregistered "
            "transform; 15.3-15.6 require the transform and its semantic evidence to be "
            "versioned records, not request assertions")
    widening = implementation.invoke("migrate", {
        "target_schema_version": "0.3.0", "migration_class": "SEMANTICALLY_WIDENING"})
    if widening.get("inherited"):
        return False, (
            "a SEMANTICALLY_WIDENING migration carried its certificates; a widened "
            "schema admits records the original claim never ranged over")
    unknown = implementation.invoke("migrate", {
        "target_schema_version": "0.3.0", "migration_class": "PROBABLY_FINE"})
    if unknown.get("ok") or unknown.get("inherited"):
        return False, (
            "an unrecognized migration class was accepted; 15.4 fixes the class set")
    return True, (
        f"no class -> {unclassified['classification']}, nothing inherited, "
        "revalidation required; an unproved SEMANTICALLY_EQUIVALENT label is refused; "
        "SEMANTICALLY_WIDENING -> not inherited; an unknown class is rejected")


# ===========================================================================
# 15. no dependency cycles (18.3)
# ===========================================================================
def no_dependency_cycles(implementation: Any) -> Tuple[bool, str]:
    """A cycle in the dependency graph makes "recompute what changed" undefined."""
    acyclic = implementation.invoke("dependency_graph", {
        "nodes": ["a", "b", "c"],
        "edges": [{"source": "a", "target": "b"}, {"source": "b", "target": "c"}]})
    if not acyclic.get("ok"):
        return False, (
            f"an acyclic graph was refused: {acyclic.get('refusal')!r}")
    cyclic = implementation.invoke("dependency_graph", {
        "nodes": ["a", "b", "c"],
        "edges": [{"source": "a", "target": "b"}, {"source": "b", "target": "c"},
                  {"source": "c", "target": "a"}]})
    if cyclic.get("ok"):
        return False, "the edge closing the cycle a -> b -> c -> a was accepted (spec 18.3)"
    if not cyclic.get("cycle"):
        return False, (
            "the cycle was refused without being named; an unnamed cycle cannot be "
            "broken by the person who has to break it")
    if cyclic.get("retained_edges") != 2:
        return False, (
            f"{cyclic.get('retained_edges')} edges survived the refusal; the rejected "
            "edge must be rolled back, or the graph is still cyclic")
    if cyclic.get("residual_cycle"):
        return False, (
            f"after the refusal the graph still contains the cycle "
            f"{cyclic['residual_cycle']}")
    return True, (
        f"the acyclic graph is accepted; the closing edge is refused naming "
        f"{cyclic['cycle']}, is rolled back, and leaves no residual cycle")


# ===========================================================================
# 16. no automatic semantic merge (16.3)
# ===========================================================================
def no_automatic_semantic_merge(implementation: Any) -> Tuple[bool, str]:
    """Two registries that differ are a disagreement, not a union to compute."""
    clean = implementation.invoke("merge_branches", {
        "source": {"title": "north site (renamed)"},
        "target": {"owner": "ops-2"},
        "rules": [{"rule_id": "r-meta", "fields": ["title", "owner"]}]})
    if not clean.get("auto_merged"):
        return False, (
            "disjoint nonsemantic metadata under a registered rule was not merged "
            f"automatically (decision {clean.get('decision')!r}); 16.3 permits exactly "
            "that, and refusing it would be a different error")
    semantic = implementation.invoke("merge_branches", {
        "source": {"registry": {"members": ["a", "b", "c"]}},
        "target": {"registry": {"members": ["a", "b", "d"]}},
        "rules": [{"rule_id": "r-meta", "fields": ["title", "owner"]}]})
    if semantic.get("auto_merged") or semantic.get("ok"):
        return False, (
            "two differing realization registries were merged automatically "
            f"(decision {semantic.get('decision')!r}); 16.3 forbids it")
    if not semantic.get("semantic_conflicts"):
        return False, (
            "the semantic difference was refused without being identified as semantic")
    if not semantic.get("required_actions"):
        return False, (
            "the refusal named no reconciliation procedure; 16.4 fixes one and the "
            "user is otherwise left with a dead end")
    overlapping = implementation.invoke("merge_branches", {
        "source": {"title": "north site (a)"}, "target": {"title": "north site (b)"},
        "rules": [{"rule_id": "r-meta", "fields": ["title"]}]})
    if overlapping.get("auto_merged"):
        return False, (
            "the same nonsemantic field was changed on both branches and merged "
            "automatically; 16.3 permits automatic merge only for disjoint fields")
    unregistered = implementation.invoke("merge_branches", {
        "source": {"description": "changed"}, "target": {}, "rules": []})
    if unregistered.get("auto_merged"):
        return False, (
            "a field with no registered merge rule was merged automatically")
    return True, (
        f"disjoint registered metadata merges ({clean['decision']}); differing "
        f"registries refuse ({semantic['decision']}) naming "
        f"{semantic['semantic_conflicts']} and the 16.4 procedure; an overlapping "
        f"field and an unregistered field each require manual reconciliation")


# ===========================================================================
# 17. no valid status when required content is redacted (25.4, 44.2)
# ===========================================================================
def no_valid_status_when_required_content_is_redacted(
        implementation: Any) -> Tuple[bool, str]:
    """What could not be read could not be checked, and must not read as checked.

    The failure mode is an artifact that verifies because the thing that would
    have failed was removed.
    """
    authorized = implementation.invoke("redacted_evidence", {"requester": "signer"})
    if not authorized.get("affirmative"):
        return False, (
            "an authorized reader of active evidence got no affirmative result "
            f"(status {authorized.get('status')!r}); the invariant bites on redaction, "
            "not on access")
    denied = implementation.invoke("redacted_evidence", {"requester": "outsider"})
    if denied.get("affirmative"):
        return False, (
            "an unauthorized reader received an affirmative result over restricted "
            "evidence (spec 44.2)")
    if denied.get("verification_status") == "VERIFIED":
        return False, (
            "a technology contract assembled without readable evidence reported "
            "VERIFIED (spec 6.6: fail closed)")
    anonymous = implementation.invoke("redacted_evidence", {"requester": None})
    if anonymous.get("affirmative"):
        return False, (
            "restricted evidence was released to an unidentified requester (spec 44.2)")
    withheld = implementation.invoke("redacted_evidence", {"object_status": "REDACTED",
                                                           "requester": "signer"})
    if withheld.get("affirmative"):
        return False, (
            "evidence carrying lifecycle status REDACTED still produced an affirmative "
            "result")
    # The certificate arm: a dependency withheld from an otherwise populated
    # artifact must not verify.
    partial = implementation.invoke("verify_certificate", {"withhold": ["first"]})
    if partial.get("ok"):
        return False, (
            "a certificate verified although a pinned dependency was withheld from the "
            f"artifact (status {partial.get('status')!r}); the content that would have "
            "been checked was not present")
    # And a wholly redacted artifact must at minimum not report an *unqualified*
    # affirmative: a status reached without running a required check is not a
    # verification of it.
    total = implementation.invoke("verify_certificate", {"withhold_all": True})
    if total.get("ok"):
        return False, (
            "a certificate reported ok=true with every pinned dependency withheld; "
            f"status was {total.get('status')!r} (spec 6.6, 25.3-25.4)")
    if total.get("affirmative"):
        return False, (
            f"a certificate reported the unqualified affirmative status "
            f"{total.get('status')!r} with every pinned dependency withheld and no "
            "disclosure of the unrun checks (spec 25.4)")
    return True, (
        f"authorized access is affirmative; unauthorized, unidentified and "
        f"lifecycle-REDACTED access are each refused with a stated reason "
        f"({denied.get('reason')!r}); a withheld dependency yields "
        f"{partial.get('status')!r}; and total redaction yields "
        f"{total.get('status')!r} qualified by {len(total.get('unsupported_checks') or [])} "
        "disclosed unrun check(s)")


def _advisory_total_redaction_downgrades_status(
        implementation: Any) -> Tuple[bool, str]:
    """Advisory (25.4): total redaction should downgrade the status, not warn.

    Specification 25.3 defines ``PARTIALLY_VERIFIED``, ``INTEGRITY_ONLY`` and
    ``UNVERIFIABLE_REDACTED`` precisely so a verifier can say "I could not check
    this" in the status field, where a downstream consumer that reads only the
    status will see it.  A verifier that reports ``VERIFIED`` and puts the gap in
    a warning has satisfied the letter of 49.2 -- the gap is disclosed -- while
    leaving a consumer who reads one field with an over-claim.

    This is recorded as an advisory rather than a mandatory failure because
    49.2's prohibition is on a *valid status* with redacted content, and a status
    carrying an explicit unsupported-check list is a qualified one.  The
    distinction is thin, and the report says so rather than hiding it.
    """
    total = implementation.invoke("verify_certificate", {"withhold_all": True})
    downgraded = total.get("status") in (
        "PARTIALLY_VERIFIED", "INTEGRITY_ONLY", "UNVERIFIABLE_REDACTED", "FAILED")
    if downgraded:
        return True, (
            f"total redaction downgrades the status to {total.get('status')!r}")
    return False, (
        f"with every pinned dependency withheld the verifier reports status "
        f"{total.get('status')!r} and moves the gap into "
        f"{len(total.get('unsupported_checks') or [])} unsupported-check warning(s). "
        "The gap is disclosed, so 49.2's prohibition on a valid status is arguably "
        "met, but 25.3 provides PARTIALLY_VERIFIED / UNVERIFIABLE_REDACTED for exactly "
        "this and a consumer reading only the status field sees an over-claim")


# ===========================================================================
# 18. no wall-clock time for monotonic runtime dwell (45.6)
# ===========================================================================
def no_wall_clock_time_for_monotonic_runtime_dwell(
        implementation: Any) -> Tuple[bool, str]:
    """Dwell is elapsed *operation*, and the wall clock does not measure it.

    A wall clock is adjusted, stepped, and occasionally moved backwards. If
    dwell is read from it, a clock correction can satisfy a safety hold that
    the running system never actually satisfied.
    """
    satisfied = implementation.invoke("monotonic_dwell",
                                      {"minimum_ticks": 5000, "dwell_ticks": 8000})
    if not satisfied.get("dwell_satisfied"):
        return False, (
            "8000 monotonic ticks did not satisfy a 5000-tick dwell requirement; the "
            "invariant is about the *source* of the measurement, not about refusing "
            "every dwell")
    if satisfied.get("source") != "MONOTONIC_TICKS":
        return False, (
            f"dwell was measured from {satisfied.get('source')!r}; 45.6 requires a "
            "monotonic tick source")
    jumped = implementation.invoke("monotonic_dwell", {
        "minimum_ticks": 5000, "dwell_ticks": 10,
        "wall_clock": "2099-01-01T00:00:00Z"})
    if jumped.get("dwell_satisfied"):
        return False, (
            "the wall clock was advanced to 2099 while the condition had held for 10 "
            "monotonic ticks, and the 5000-tick dwell requirement was reported as "
            "satisfied; the requirement was met by a clock adjustment, not by the "
            "running system (spec 45.6)")
    if "DWELL_NOT_MET" not in (jumped.get("gate_refusals") or []):
        return False, (
            f"the unmet dwell did not reach the transition gate: refusals "
            f"{jumped.get('gate_refusals')}")
    offenders = satisfied.get("wall_clock_calls") or {}
    if offenders:
        return False, (
            "the runtime-control sources call a process or wall clock directly: "
            f"{sorted(offenders)}; every time value on this path must arrive as a "
            "supplied clock (spec 45.1)")
    return True, (
        "8000 monotonic ticks satisfy a 5000-tick dwell; advancing the wall clock to "
        "2099 with 10 monotonic ticks elapsed does not, and refuses with "
        "DWELL_NOT_MET; no wall-clock or process-clock call appears in the "
        "runtime-control sources")


# ===========================================================================
# registry
# ===========================================================================
@dataclass(frozen=True)
class InvariantSpec:
    """One required invariant of specification 49.2."""

    invariant_id: str
    title: str
    spec_section: str
    profile: str
    check: Check
    rationale: str
    mandatory: bool = True


INVARIANTS: Tuple[InvariantSpec, ...] = (
    InvariantSpec(
        "INV-01/no-merging-of-distinct-realization-fibers",
        "no merging of distinct realization fibers",
        "49.2; 19.2, 19.6", Profile.CRG_GEOMETRY,
        no_merging_of_distinct_realization_fibers,
        "Two realizations at one signature are two engineering objects; merging "
        "them makes the choice between them invisible."),
    InvariantSpec(
        "INV-02/no-unitless-obligation-arithmetic",
        "no unitless obligation arithmetic",
        "49.2; 13.1-13.4", Profile.CRG_DATA,
        no_unitless_obligation_arithmetic,
        "An unstated unit is not a dimensionless one, and adding across two is "
        "not an approximation of anything."),
    InvariantSpec(
        "INV-03/no-pruning-under-scope-mismatch",
        "no pruning under scope mismatch",
        "49.2; 29.2 condition 3", Profile.CRG_CERTIFY,
        no_pruning_under_scope_mismatch,
        "A bound proved for one objective deletes candidates that another "
        "objective would have chosen."),
    InvariantSpec(
        "INV-04/no-affirmative-result-from-expired-evidence",
        "no affirmative result from expired evidence",
        "49.2; 33.3, 45.3", Profile.ETQ_EVIDENCE,
        no_affirmative_result_from_expired_evidence,
        "Expiry is a fact about the evidence, and a decision resting on it "
        "inherits the fact."),
    InvariantSpec(
        "INV-05/no-treatment-of-ungenerated-as-infeasible",
        "no treatment of ungenerated as infeasible",
        "49.2; 28.4, 28.6", Profile.CRG_GENERATE,
        no_treatment_of_ungenerated_as_infeasible,
        "Reporting an unexplored region as infeasible turns a compute budget "
        "into a physical claim."),
    InvariantSpec(
        "INV-06/no-loss-of-ties",
        "no loss of ties",
        "49.2; 22.4", Profile.CRG_CERTIFY,
        no_loss_of_ties,
        "Tie-breaking is a policy decision and must reach the person entitled "
        "to make it."),
    InvariantSpec(
        "INV-07/no-conversion-of-ambiguity-into-a-midpoint-winner",
        "no conversion of ambiguity into a midpoint winner",
        "49.2; 22.5", Profile.CRG_CERTIFY,
        no_conversion_of_ambiguity_into_a_midpoint_winner,
        "Collapsing an enclosure to its centre manufactures a confident answer "
        "from measurements that do not distinguish the candidates."),
    InvariantSpec(
        "INV-08/no-certificate-validity-after-stale-dependency",
        "no certificate validity after an affected dependency becomes stale",
        "49.2; 30.3, 25.4", Profile.CRG_CHANGE,
        no_certificate_validity_after_affected_dependency_becomes_stale,
        "A certificate is a claim about inputs; when an input moves the claim "
        "moves with it, and only that far."),
    InvariantSpec(
        "INV-09/no-secondary-optimization-violating-primary-optimum",
        "no secondary conversion optimization that violates the primary "
        "movement optimum",
        "49.2; 31.3", Profile.CRG_CONVERT,
        no_secondary_optimization_violating_primary_movement_optimum,
        "A secondary objective allowed to move data is a second primary one, "
        "which the conversion contract did not authorize."),
    InvariantSpec(
        "INV-10/no-runtime-transition-without-guards-and-rollback",
        "no runtime transition without valid guards and rollback where "
        "consistency may be affected",
        "49.2; 32.5", Profile.CRG_FEEDBACK,
        no_runtime_transition_without_valid_guards_and_rollback,
        "A defaulted guard or rollback presents an omission as a decision, and "
        "a running system is reconfigured on it."),
    InvariantSpec(
        "INV-11/no-global-winner-over-incomplete-family",
        "no global winner claim over an unknown incomplete family",
        "49.2; 21.4, 21.5", Profile.CRG_CERTIFY,
        no_global_winner_claim_over_unknown_incomplete_family,
        "'The best option' and 'the best of what we imported' differ by exactly "
        "one fact, and the artifact must carry it."),
    InvariantSpec(
        "INV-12/no-exact-geometry-from-unproved-samples",
        "no exact-geometry claim from unproved support samples",
        "49.2; 19.5, 20.3", Profile.CRG_GEOMETRY,
        no_exact_geometry_claim_from_unproved_support_samples,
        "A sampled bound is a statement about the sample set, and narrowing the "
        "set can drive it to zero without proving anything."),
    InvariantSpec(
        "INV-13/no-strong-certificate-from-heuristic-output",
        "no strong certificate from heuristic solver output",
        "49.2; 5.3, 23.6", Profile.CRG_VERIFY,
        no_strong_certificate_from_heuristic_solver_output,
        "A heuristic that is usually right is the dangerous one: its output "
        "reaches an artifact that says 'certified'."),
    InvariantSpec(
        "INV-14/no-migration-inheritance-without-classification",
        "no migration inheritance without semantic classification",
        "49.2; 15.4, 15.5", Profile.CRG_CHANGE,
        no_migration_inheritance_without_semantic_classification,
        "Migration republishes old claims under new semantics unless an "
        "equivalence was recorded."),
    InvariantSpec(
        "INV-15/no-dependency-cycles",
        "no dependency cycles",
        "49.2; 18.3", Profile.CRG_DATA,
        no_dependency_cycles,
        "A cycle makes 'recompute the minimum affected subgraph' undefined."),
    InvariantSpec(
        "INV-16/no-automatic-semantic-merge",
        "no automatic semantic merge",
        "49.2; 16.3", Profile.CRG_CHANGE,
        no_automatic_semantic_merge,
        "Two differing registries are a disagreement between people, not a "
        "union to compute."),
    InvariantSpec(
        "INV-17/no-valid-status-when-required-content-is-redacted",
        "no valid status when required content is redacted",
        "49.2; 25.4, 44.2, 6.6", Profile.ETQ_EVIDENCE,
        no_valid_status_when_required_content_is_redacted,
        "An artifact must not verify because the thing that would have failed "
        "was removed from it."),
    InvariantSpec(
        "INV-17a/redaction-should-downgrade-the-status",
        "advisory: total redaction should downgrade the status, not only warn",
        "49.2; 25.3, 25.4", Profile.CRG_VERIFY,
        _advisory_total_redaction_downgrades_status,
        "25.3 provides PARTIALLY_VERIFIED and UNVERIFIABLE_REDACTED so the gap "
        "appears in the field a downstream consumer actually reads.",
        mandatory=False),
    InvariantSpec(
        "INV-18/no-wall-clock-for-monotonic-dwell",
        "no use of wall-clock time for monotonic runtime dwell",
        "49.2; 45.6", Profile.CRG_FEEDBACK,
        no_wall_clock_time_for_monotonic_runtime_dwell,
        "A clock correction could otherwise satisfy a safety hold the running "
        "system never satisfied."),
)


def invariant_ids() -> Tuple[str, ...]:
    return tuple(spec.invariant_id for spec in INVARIANTS)


def run_invariant(spec: InvariantSpec, implementation: Any) -> CaseResult:
    """Run one invariant against ``implementation`` and never raise."""
    try:
        passed, detail = spec.check(implementation)
    except UnsupportedOperation as error:
        return CaseResult(
            case_id=spec.invariant_id, kind="INVARIANT", profile=spec.profile,
            spec_section=spec.spec_section, passed=False,
            title=spec.title, rationale=spec.rationale, mandatory=spec.mandatory,
            unsupported=True,
            detail=(f"the implementation declared profile {spec.profile} but does not "
                    f"implement {error.operation!r}: {error.detail}"))
    except Exception as error:                    # noqa: BLE001 - a crash is a failure
        return CaseResult(
            case_id=spec.invariant_id, kind="INVARIANT", profile=spec.profile,
            spec_section=spec.spec_section, passed=False,
            title=spec.title, rationale=spec.rationale, mandatory=spec.mandatory,
            detail=(f"the check could not complete: {type(error).__name__}: {error}"))
    return CaseResult(
        case_id=spec.invariant_id, kind="INVARIANT", profile=spec.profile,
        spec_section=spec.spec_section, passed=bool(passed),
        title=spec.title, rationale=spec.rationale, mandatory=spec.mandatory,
        detail=detail)


def run_invariants(implementation: Any, *,
                   profile: Optional[str] = None) -> Iterator[CaseResult]:
    """Run every invariant, or every invariant a given profile owns."""
    for spec in INVARIANTS:
        if profile is not None and spec.profile != profile:
            continue
        yield run_invariant(spec, implementation)
