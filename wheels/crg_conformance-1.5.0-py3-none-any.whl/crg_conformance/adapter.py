"""The conformance adapter boundary (spec 48.3).

A regression suite calls the code it ships with.  A *conformance* suite calls
whatever implementation it is pointed at, and the difference is this module.

Specification 48.3 requires that, before ``CRG-CERTIFY`` is declared stable, at
least one deliberately independent implementation of ``CRG-DATA``,
``CRG-GEOMETRY``, ``CRG-QUERY`` and ``CRG-VERIFY`` be used to test
interoperability, and that any divergence between independent implementations
be treated as a specification defect until resolved.  That is only possible if
the suite has a stated, minimal, language-neutral contract for what a
conforming implementation must expose.

The contract is one method::

    invoke(operation: str, request: Mapping[str, Any]) -> dict[str, Any]

with :data:`OPERATIONS` naming every operation, the profile that requires it,
and the specification section that governs it.  Everything crossing the
boundary is plain JSON: strings, booleans, integers, lists, dicts, and ``None``.
Exact rationals cross as canonical ``"p/q"`` or ``"p"`` strings, never as binary
floating point (spec 14.2) and never as a language-specific object.

Three consequences follow, and all three are the point:

* a golden vector (spec 49.3) can name its operation as a *string* and carry its
  input and expected outcome as *data*, so the same file tests any
  implementation;
* an implementation written in another language needs one RPC shim, not a port
  of this package; and
* an implementation may decline a profile it does not implement.  Declining is
  honest and is reported as such (spec 48.2 requires unsupported optional
  profiles to be *disclosed*); silently returning a wrong answer is not, and
  fails.

An implementation that is asked for an operation outside its declared profiles
raises :class:`UnsupportedOperation`.  An implementation that is asked for an
operation *inside* a profile it declared and cannot answer it also raises
:class:`UnsupportedOperation` -- and that is a conformance failure, because the
declaration was wrong.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Mapping, Protocol, Sequence, runtime_checkable

__all__ = [
    "AdapterError",
    "UnsupportedOperation",
    "OperationSpec",
    "OPERATIONS",
    "operations_for",
    "Implementation",
    "BaseImplementation",
]


class AdapterError(Exception):
    """An implementation could not answer an operation it declared support for."""


class UnsupportedOperation(AdapterError):
    """The implementation does not implement this operation.

    Raised by an adapter, never by the suite.  How the suite scores it depends
    on whether the owning profile was declared:

    * profile not declared -- the profile is skipped and disclosed (48.2);
    * profile declared -- every case using the operation fails, because the
      declaration was untrue.
    """

    def __init__(self, operation: str, detail: str = "") -> None:
        self.operation = operation
        self.detail = detail
        message = f"operation {operation!r} is not implemented"
        if detail:
            message = f"{message}: {detail}"
        super().__init__(message)


@dataclass(frozen=True)
class OperationSpec:
    """One operation of the adapter contract.

    ``profile`` is the specification 48.1 profile that requires the operation;
    ``spec_section`` is the normative section the operation's behaviour is
    judged against, and is reproduced in every report line that cites it.
    """

    name: str
    profile: str
    spec_section: str
    summary: str
    request_keys: Sequence[str] = field(default_factory=tuple)
    response_keys: Sequence[str] = field(default_factory=tuple)


# ---------------------------------------------------------------------------
# the operation set (spec 48.1 capability table)
# ---------------------------------------------------------------------------
# Each row answers one question: what must an implementation be able to *do*
# before it may claim the profile in column two?  The set is deliberately
# small.  It is not an API for building CRG systems; it is the smallest set of
# externally observable behaviours in which every required invariant of 49.2 and
# every required golden case of 49.3 can be stated.
_SPECS: Sequence[OperationSpec] = (
    # -- CRG-DATA: canonical records, quantities, units, hashing, versions,
    #    and bundle validation -----------------------------------------------
    OperationSpec(
        "canonical_hash", "CRG-DATA", "6.5, 14.3",
        "Content-address a canonical record; identity is derived from content.",
        ("payload",), ("hash",),
    ),
    OperationSpec(
        "quantity_add", "CRG-DATA", "13.1-13.4",
        "Add two declared quantities; refuse a missing or mismatched unit.",
        ("a", "b"), ("ok", "value", "unit", "refusal"),
    ),
    OperationSpec(
        "dependency_graph", "CRG-DATA", "18.1-18.3",
        "Build a typed dependency graph; refuse a cycle and name it.",
        ("nodes", "edges"), ("ok", "cycle", "refusal", "retained_edges"),
    ),
    OperationSpec(
        "bundle_verify", "CRG-DATA", "39, 25.6",
        "Write, read back, and independently verify a portable bundle; detect corruption.",
        ("corrupt",), ("clean_ok", "corrupt_ok", "corrupt_status", "corrupt_reason"),
    ),
    # -- CRG-GEOMETRY: canonical R, Gamma, K, fibers, envelopes ---------------
    OperationSpec(
        "build_geometry", "CRG-GEOMETRY", "19.2-19.6",
        "Build R, Gamma and K from a realization family, preserving fibers.",
        ("points", "legality"),
        ("fibers", "frontier", "vertices", "realization_count", "verify_errors"),
    ),
    OperationSpec(
        "support_claim", "CRG-GEOMETRY", "19.5, 20.1-20.3",
        "Bound support-function error over a declared price sample set.",
        ("inner", "outer", "price_samples"),
        ("exact", "bound", "claim_limit", "samples_proved"),
    ),
    # -- CRG-QUERY: decision language, derivation records, soundness ----------
    OperationSpec(
        "compile_query", "CRG-QUERY", "26.4, 26.6",
        "Compile a decision query to an observation level and a required object.",
        ("query",),
        ("ok", "observation_level", "required_object", "refusal", "rule_cited"),
    ),
    # -- CRG-GENERATE: generator interface, legality, rejection states --------
    OperationSpec(
        "generate_family", "CRG-GENERATE", "21.2-21.6, 28.3-28.6",
        "Close a generator set and derive the completeness basis from what generation did.",
        ("generator", "max_depth", "determinism"),
        ("basis", "claim_scope", "statuses", "ungenerated_regions",
         "infeasible_count", "deterministic"),
    ),
    # -- CRG-CERTIFY: safe commitment, pruning, retention, regret, certificates
    OperationSpec(
        "certify_decision", "CRG-CERTIFY", "21.4-21.5, 22.3-22.7, 29",
        "Issue a decision certificate; keep ties, ambiguity and infeasibility distinct.",
        ("candidates", "objective", "tolerance", "basis"),
        ("outcome", "winners", "ties", "claim_scope", "global_claim", "margin"),
    ),
    OperationSpec(
        "prune", "CRG-CERTIFY", "29.2",
        "Issue certified pruning; refuse a bound issued under another decision scope.",
        ("candidates", "objective", "scopes"),
        ("pruned", "retained", "refusal"),
    ),
    OperationSpec(
        "retention", "CRG-CERTIFY", "22.2, 27.3-27.4",
        "Compute the retention set for declared scopes and expose the regret of a loss.",
        ("scopes",),
        ("initial_retained", "winner_under_later_objective", "retained_covers_it",
         "union_covers_it", "truncated_outcome", "regret_witness"),
    ),
    OperationSpec(
        "regret_witness", "CRG-CERTIFY", "27.3-27.4",
        "Construct and independently re-verify a constructive regret witness.",
        ("full_frontier", "retained_frontier", "tamper"),
        ("phi", "verified", "detail"),
    ),
    # -- CRG-VERIFY: CRG-VIR, proof checking, verification levels, reports ----
    OperationSpec(
        "verify_certificate", "CRG-VERIFY", "24, 25.2-25.5",
        "Independently re-derive and check a certificate against its dependencies.",
        ("stale_dependencies", "withhold", "withhold_all", "heuristic_solver_trust"),
        ("status", "ok", "reasons", "warnings", "unsupported_checks"),
    ),
    # -- CRG-CHANGE: typed edges, reprice, re-embed, reopen, delta certificates
    OperationSpec(
        "classify_change", "CRG-CHANGE", "30.2-30.4",
        "Classify a change, propagate along typed edges, and stale only what is affected.",
        ("changed_object", "changed_properties"),
        ("action", "stale", "preserved", "invalidated", "reason"),
    ),
    OperationSpec(
        "migrate", "CRG-CHANGE", "15.3-15.5",
        "Migrate a case to a target schema version under a declared semantic class.",
        ("target_schema_version", "migration_class"),
        ("ok", "classification", "inherited", "revalidation_required", "reason"),
    ),
    OperationSpec(
        "merge_branches", "CRG-CHANGE", "16.3-16.4",
        "Decide whether two branches may merge; never merge semantic objects automatically.",
        ("source", "target", "rules"),
        ("ok", "decision", "auto_merged", "conflicts", "reason"),
    ),
    # -- CRG-CONVERT: minimum-movement conversion and verification ------------
    OperationSpec(
        "convert_layout", "CRG-CONVERT", "31.2",
        "Convert between layouts at the exact maximum-retention assignment optimum.",
        ("source", "target"),
        ("retained", "moved", "nested", "closed_form_applies", "identity", "solver_method"),
    ),
    OperationSpec(
        "secondary_objective", "CRG-CONVERT", "31.3",
        "Optimize a secondary objective without moving off the primary movement optimum.",
        ("kind", "cost", "permit_movement_trade", "authorization"),
        ("ok", "primary_retained", "achieved_retention", "trade_refused", "primary_respected"),
    ),
    # -- CRG-FEEDBACK: evaluator protocol, witnesses, transition records ------
    OperationSpec(
        "evaluator_result", "CRG-FEEDBACK", "32.1",
        "Ingest an evaluator response; a tool failure is not physical infeasibility.",
        ("kind", "promote_to"),
        ("feasibility", "evidence_class", "signoff", "marks_infeasible"),
    ),
    OperationSpec(
        "runtime_transition", "CRG-FEEDBACK", "32.4-32.5",
        "Plan, authorize and execute a runtime transition, or fail closed.",
        ("drop_items", "telemetry_age_ticks", "observed_throughput", "fail_restore"),
        ("status", "refusal_reason", "rolled_back", "guards_valid", "rollback_present"),
    ),
    OperationSpec(
        "monotonic_dwell", "CRG-FEEDBACK", "32.5, 45.6",
        "Judge runtime dwell on a monotonic tick source, never on the wall clock.",
        ("minimum_ticks", "dwell_ticks", "wall_clock"),
        ("dwell_satisfied", "source", "wall_clock_calls", "reason"),
    ),
    # -- ETQ-EVIDENCE: evidence, applicability, uncertainty, conflict ---------
    OperationSpec(
        "evidence_applicability", "ETQ-EVIDENCE", "33.3, 45.3",
        "Select and apply an applicability rule under a supplied clock.",
        ("clock_at", "rule_expiration", "evidence_expires_at", "no_rules"),
        ("status", "reason_code", "value", "time_status"),
    ),
    OperationSpec(
        "evidence_conflict", "ETQ-EVIDENCE", "33.4-33.5",
        "Classify an evidence set and fuse it, or refuse to fuse a contradiction.",
        ("members",), ("relation", "fused", "refusal"),
    ),
    OperationSpec(
        "redacted_evidence", "ETQ-EVIDENCE", "33.2, 44.2, 6.6",
        "Report the status of evidence whose required content is withheld.",
        ("requester", "object_status"),
        ("status", "reason", "affirmative", "verification_status"),
    ),
    # -- ETQ-QUALIFY: inverse qualification, ranking, stopping ----------------
    OperationSpec(
        "qualify", "ETQ-QUALIFY", "34.4-34.5",
        "Report the possible-winner set and whether a declared stopping rule fired.",
        ("candidates", "stopping_rules", "state_overrides"),
        ("ambiguity", "possible_winners", "guaranteed_winners", "stopped", "stop_reason"),
    ),
    OperationSpec(
        "phase_boundary", "ETQ-QUALIFY", "34.2, 34.5",
        "Report whether a bounded coordinate straddles a declared phase boundary.",
        ("bounds", "thresholds"),
        ("crosses", "resolved", "region_state", "phase_boundary_uncertainty"),
    ),
    OperationSpec(
        "rank_experiments", "ETQ-QUALIFY", "34.4",
        "Rank experiments so cheapness never buys rank that information did not earn.",
        ("experiments", "basis"), ("ranking", "reason"),
    ),
    # -- ETQ-FEDERATE: envelopes, signatures, release, revocation, evaluation -
    OperationSpec(
        "verify_envelope", "ETQ-FEDERATE", "35.2-35.4",
        "Verify a capability envelope and release the minimum authorized result.",
        ("nonce", "ledger", "registry", "revoke_this", "clock_at", "expires_at"),
        ("outcome", "reason_code", "replay_checked", "release_kind",
         "boolean_is_none", "boolean_is_false"),
    ),
)

#: Every operation of the adapter contract, keyed by name.
OPERATIONS: Mapping[str, OperationSpec] = {spec.name: spec for spec in _SPECS}


def operations_for(profile: str) -> tuple[str, ...]:
    """Operation names a given specification 48.1 profile requires."""
    return tuple(name for name, spec in OPERATIONS.items() if spec.profile == profile)


# ---------------------------------------------------------------------------
# the implementation contract
# ---------------------------------------------------------------------------
@runtime_checkable
class Implementation(Protocol):
    """What a candidate implementation must expose to be testable (spec 48.2).

    The five attributes are not decoration.  Specification 48.2 makes official
    conformance conditional on *identifying implementation and version* and on
    *disclosing unsupported optional profiles*, so an implementation that
    cannot state its own identity or its own profile set cannot be officially
    conformant however many cases it passes -- and the report says so.
    """

    #: Implementation identifier, e.g. ``"crg-systems-reference"``.
    name: str
    #: Implementation version, distinct from the specification version.
    version: str
    #: Specification version this implementation targets.
    spec_version: str
    #: Profiles of specification 48.1 the implementation claims to support.
    supported_profiles: frozenset
    #: The governance policy the implementation asserts it meets (48.2), or
    #: ``None`` when none is asserted.  The suite cannot verify a governance
    #: policy; it can only record whether one was declared, and it reports the
    #: difference rather than assuming compliance.
    governance_policy: Any

    def invoke(self, operation: str, request: Mapping[str, Any]) -> Dict[str, Any]:
        """Run one adapter operation and return plain JSON-able data."""
        ...  # pragma: no cover


class BaseImplementation:
    """Convenience base that dispatches ``invoke`` to ``op_<operation>`` methods.

    Implementors are free to ignore it: :class:`Implementation` is a protocol,
    and any object with the five attributes and an ``invoke`` method conforms.
    """

    name = "unnamed-implementation"
    version = "0.0.0"
    spec_version = "0.2.0"
    supported_profiles: frozenset = frozenset()
    governance_policy: Any = None

    def invoke(self, operation: str, request: Mapping[str, Any]) -> Dict[str, Any]:
        if operation not in OPERATIONS:
            raise AdapterError(f"unknown adapter operation {operation!r}")
        handler = getattr(self, f"op_{operation}", None)
        if handler is None:
            raise UnsupportedOperation(
                operation,
                f"{self.name} exposes no handler for it",
            )
        result = handler(dict(request))
        if not isinstance(result, dict):
            raise AdapterError(
                f"operation {operation!r} returned {type(result).__name__}, "
                "but the adapter boundary carries plain JSON objects only"
            )
        return result

    def declares(self, profile: str) -> bool:
        """Whether this implementation claims the given 48.1 profile."""
        return profile in self.supported_profiles
