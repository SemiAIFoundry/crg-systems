"""Adapter for the deliberately independent JavaScript 48.3 stack.

The wrapper is transport only: one JSON request enters a separate Node process
and one JSON response returns.  No reference-kernel function is called, and the
JavaScript executable imports no Python-produced module or artifact.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path
from typing import Any, Dict, Mapping, Optional

from .adapter import AdapterError, OPERATIONS, UnsupportedOperation

__all__ = ["JavascriptImplementation", "javascript_implementation"]


def _default_script() -> Path:
    return Path(__file__).resolve().parent / "javascript_stack" / "bin" / "crg-stack-js.mjs"


class JavascriptImplementation:
    """A foreign-process implementation of DATA, GEOMETRY, QUERY and VERIFY."""

    governance_policy = None
    conformance_report_published = False
    governance_policy_met = False

    def __init__(self, *, node: str = "", script: str = "") -> None:
        self.node = node or os.environ.get("CRG_NODE", "") or shutil.which("node") or ""
        self.script = Path(script or os.environ.get("CRG_JAVASCRIPT_STACK", "")
                           or _default_script()).resolve()
        if not self.node:
            raise AdapterError("the independent JavaScript stack requires Node 22+")
        if not self.script.is_file():
            raise AdapterError(f"no independent JavaScript stack at {self.script}")
        description = self._run(["--describe"], None)
        self.name = str(description.get("implementation") or "")
        self.version = str(description.get("version") or "")
        self.spec_version = str(description.get("spec_version") or "")
        self.supported_profiles = frozenset(
            str(value) for value in description.get("supported_profiles") or ()
        )
        self.operations = frozenset(str(value) for value in description.get("operations") or ())
        if not self.name or not self.version or not self.spec_version:
            raise AdapterError("the independent JavaScript stack did not identify itself")

    def _run(self, arguments: list[str], request: Optional[Mapping[str, Any]]) -> Dict[str, Any]:
        process = subprocess.run(
            [self.node, str(self.script), *arguments],
            input="" if request is None else json.dumps(request, ensure_ascii=False),
            capture_output=True,
            text=True,
            cwd=str(self.script.parents[1]),
        )
        if process.returncode != 0:
            detail = process.stderr.strip() or process.stdout.strip() or "no diagnostic"
            raise AdapterError(
                f"independent JavaScript stack exited {process.returncode}: {detail}"
            )
        try:
            value = json.loads(process.stdout)
        except json.JSONDecodeError as error:
            raise AdapterError(f"independent JavaScript response is not JSON: {error}") from error
        if not isinstance(value, dict):
            raise AdapterError("independent JavaScript response is not a JSON object")
        return value

    def invoke(self, operation: str, request: Mapping[str, Any]) -> Dict[str, Any]:
        if operation not in OPERATIONS:
            raise AdapterError(f"unknown adapter operation {operation!r}")
        if operation not in self.operations:
            raise UnsupportedOperation(operation, f"{self.name} does not declare it")
        return self._run([operation], request)


def javascript_implementation(**kwargs: Any) -> JavascriptImplementation:
    return JavascriptImplementation(**kwargs)
