"""Golden vectors: the required cases of specification 49.3, as data.

Specification 49.3 requires the conformance suite to include twenty-seven named
cases.  They are stored in ``golden/*.json`` and not in Python, and that is a
design decision with a purpose: 48.3 requires a *deliberately independent*
implementation to be tested against the same expectations, and an expectation
written as a Python assertion can only ever test Python.  A vector file can be
read by a harness in any language, and a disagreement between two
implementations over the same file is exactly the specification defect 48.3
says it is.

Vector format
-------------
::

    {
      "id":       "G-01-identity-and-permutation-layouts",
      "title":    "identity and permutation layouts",
      "profile":  "CRG-CONVERT",
      "spec":     "49.3; 31.2",
      "rationale": "one line saying what a failure here would mean",
      "mandatory": true,
      "steps": [
        {
          "name":      "identity",
          "operation": "convert_layout",
          "input":     { ... },
          "expect":            { "retained": "1/1" },
          "expect_in":         { "status": ["EXPIRED", "REFUSED"] },
          "expect_contains":   { "refusal": "scope mismatch" },
          "expect_present":    ["cycle"],
          "expect_absent":     ["value"]
        }
      ]
    }

``expect`` is exact equality on each named key; keys the response carries but
the vector does not name are ignored, so a vector does not break when an
implementation reports more than the specification requires.  ``expect_present``
requires a non-empty value, ``expect_absent`` requires ``None`` or an empty
one, ``expect_contains`` a case-insensitive substring, and ``expect_in``
membership in a permitted set -- the last for the cases where the specification
fixes a distinction but not a spelling.

Steps in one vector run in order against one implementation object, which is
how the replay case (49.3, "replayed capability envelope") presents the same
nonce to the same verifier twice.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from typing import Any, Dict, Iterator, List, Mapping, Optional, Sequence, Tuple

from .adapter import OPERATIONS, UnsupportedOperation
from .profiles import CaseResult, Profile

__all__ = [
    "GoldenVector",
    "GoldenStep",
    "golden_directory",
    "load_vectors",
    "run_vector",
    "run_vectors",
    "match",
]

_REQUIRED_FIELDS = ("id", "title", "profile", "spec", "rationale", "steps")


def golden_directory() -> str:
    """Where the shipped golden vectors live."""
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(os.path.dirname(here), "golden")


@dataclass(frozen=True)
class GoldenStep:
    """One operation call inside a golden vector."""

    name: str
    operation: str
    input: Mapping[str, Any] = field(default_factory=dict)
    expect: Mapping[str, Any] = field(default_factory=dict)
    expect_in: Mapping[str, Sequence[Any]] = field(default_factory=dict)
    expect_contains: Mapping[str, str] = field(default_factory=dict)
    expect_present: Sequence[str] = ()
    expect_absent: Sequence[str] = ()


@dataclass(frozen=True)
class GoldenVector:
    """One required golden case of specification 49.3."""

    vector_id: str
    title: str
    profile: str
    spec: str
    rationale: str
    steps: Tuple[GoldenStep, ...]
    mandatory: bool = True
    source_file: str = ""


class GoldenVectorError(ValueError):
    """A vector file is not a well-formed golden vector."""


def _step(raw: Mapping[str, Any], vector_id: str, index: int,
          profile: str) -> GoldenStep:
    if "operation" not in raw:
        raise GoldenVectorError(f"{vector_id} step {index}: no operation named")
    operation = raw["operation"]
    if operation not in OPERATIONS:
        raise GoldenVectorError(
            f"{vector_id} step {index}: {operation!r} is not an adapter operation")
    # A vector must be runnable by an implementation that declared its profile
    # and nothing else, or profile scoping means nothing: an implementation
    # could fail CRG-CONVERT because of a CRG-CERTIFY operation it never claimed.
    owner = OPERATIONS[operation].profile
    if owner != profile:
        raise GoldenVectorError(
            f"{vector_id} step {index}: operation {operation!r} belongs to profile "
            f"{owner}, but the vector declares {profile}")
    return GoldenStep(
        name=raw.get("name", f"step-{index}"),
        operation=operation,
        input=raw.get("input", {}),
        expect=raw.get("expect", {}),
        expect_in=raw.get("expect_in", {}),
        expect_contains=raw.get("expect_contains", {}),
        expect_present=tuple(raw.get("expect_present", ())),
        expect_absent=tuple(raw.get("expect_absent", ())),
    )


def _vector(document: Mapping[str, Any], path: str) -> GoldenVector:
    missing = [f for f in _REQUIRED_FIELDS if f not in document]
    if missing:
        raise GoldenVectorError(f"{path}: missing required field(s) {missing}")
    vector_id = document["id"]
    profile = document["profile"]
    if not Profile.known(profile):
        raise GoldenVectorError(
            f"{vector_id}: {profile!r} is not a specification 48.1 profile")
    steps = document["steps"]
    if not steps:
        raise GoldenVectorError(f"{vector_id}: a vector with no step tests nothing")
    return GoldenVector(
        vector_id=vector_id,
        title=document["title"],
        profile=profile,
        spec=document["spec"],
        rationale=document["rationale"],
        steps=tuple(_step(s, vector_id, i, profile) for i, s in enumerate(steps)),
        mandatory=bool(document.get("mandatory", True)),
        source_file=os.path.basename(path),
    )


def load_vectors(directory: Optional[str] = None) -> Tuple[GoldenVector, ...]:
    """Load and validate every vector in ``directory`` (default: the shipped set)."""
    directory = directory or golden_directory()
    if not os.path.isdir(directory):
        raise GoldenVectorError(f"no golden vector directory at {directory}")
    vectors: List[GoldenVector] = []
    for name in sorted(os.listdir(directory)):
        if not name.endswith(".json"):
            continue
        path = os.path.join(directory, name)
        with open(path, encoding="utf-8") as handle:
            try:
                document = json.load(handle)
            except json.JSONDecodeError as error:
                raise GoldenVectorError(f"{path}: {error}") from error
        vectors.append(_vector(document, path))
    if not vectors:
        raise GoldenVectorError(f"no golden vectors found in {directory}")
    seen: Dict[str, str] = {}
    for vector in vectors:
        if vector.vector_id in seen:
            raise GoldenVectorError(
                f"duplicate vector id {vector.vector_id!r} in {vector.source_file} "
                f"and {seen[vector.vector_id]}")
        seen[vector.vector_id] = vector.source_file
    return tuple(vectors)


# ---------------------------------------------------------------------------
# matching
# ---------------------------------------------------------------------------
def _empty(value: Any) -> bool:
    return value is None or value == "" or value == [] or value == {} or value is False


def match(step: GoldenStep, response: Mapping[str, Any]) -> List[str]:
    """Compare one response against one step's expectations.

    Returns the list of mismatches, each naming the key, the expectation and
    what was observed.  An empty list is a pass.
    """
    problems: List[str] = []
    for key, expected in step.expect.items():
        if key not in response:
            problems.append(f"{key}: expected {expected!r}, but the response has no "
                            f"such field")
            continue
        observed = response[key]
        if observed != expected:
            problems.append(f"{key}: expected {expected!r}, observed {observed!r}")
    for key, permitted in step.expect_in.items():
        observed = response.get(key)
        if observed not in permitted:
            problems.append(
                f"{key}: expected one of {list(permitted)!r}, observed {observed!r}")
    for key, needle in step.expect_contains.items():
        observed = response.get(key)
        text = "" if observed is None else str(observed)
        if needle.lower() not in text.lower():
            problems.append(
                f"{key}: expected text containing {needle!r}, observed {text!r}")
    for key in step.expect_present:
        if key not in response or _empty(response[key]):
            problems.append(
                f"{key}: expected a non-empty value, observed {response.get(key)!r}")
    for key in step.expect_absent:
        if key in response and not _empty(response[key]):
            problems.append(
                f"{key}: expected no value, observed {response[key]!r}")
    return problems


# ---------------------------------------------------------------------------
# running
# ---------------------------------------------------------------------------
def run_vector(vector: GoldenVector, implementation: Any) -> CaseResult:
    """Run one golden vector against ``implementation`` and never raise."""
    def result(passed: bool, detail: str, unsupported: bool = False) -> CaseResult:
        return CaseResult(
            case_id=vector.vector_id, kind="GOLDEN", profile=vector.profile,
            spec_section=vector.spec, passed=passed, title=vector.title,
            rationale=vector.rationale, mandatory=vector.mandatory,
            unsupported=unsupported, detail=detail)

    observed_summary: List[str] = []
    for step in vector.steps:
        try:
            response = implementation.invoke(step.operation, step.input)
        except UnsupportedOperation as error:
            return result(
                False,
                f"step {step.name!r}: the implementation declared profile "
                f"{vector.profile} but does not implement {error.operation!r}",
                unsupported=True)
        except Exception as error:                # noqa: BLE001 - a crash is a failure
            return result(
                False,
                f"step {step.name!r} ({step.operation}) raised "
                f"{type(error).__name__}: {error}")
        problems = match(step, response)
        if problems:
            return result(
                False,
                f"step {step.name!r} ({step.operation}): " + "; ".join(problems))
        checked = sorted(set(step.expect)
                         | set(step.expect_in)
                         | set(step.expect_contains)
                         | set(step.expect_present)
                         | set(step.expect_absent))
        observed_summary.append(f"{step.name}: {len(checked)} expectation(s) met "
                                f"({', '.join(checked)})")
    return result(True, "; ".join(observed_summary))


def run_vectors(implementation: Any, *, profile: Optional[str] = None,
                directory: Optional[str] = None) -> Iterator[CaseResult]:
    """Run every golden vector, or every vector a given profile owns."""
    for vector in load_vectors(directory):
        if profile is not None and vector.profile != profile:
            continue
        yield run_vector(vector, implementation)
