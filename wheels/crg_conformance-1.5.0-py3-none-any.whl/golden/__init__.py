"""Packaged CRG conformance golden vectors (specification section 49.3)."""
