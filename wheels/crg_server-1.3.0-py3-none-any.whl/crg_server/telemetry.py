"""Small, dependency-free OpenTelemetry Protocol trace exporter.

The reference server deliberately keeps its local profile installable without
network dependencies.  That does not mean an enterprise deployment may be a
black box.  This module implements the two interoperable pieces needed at the
HTTP boundary without importing an observability SDK:

* W3C ``traceparent`` extraction and propagation; and
* OTLP/HTTP JSON export to a deployment-owned collector.

Export is bounded and asynchronous.  A collector outage therefore increments
an observable failure/drop counter but never changes the result of a CRG
operation.  No request body, credential, evidence value, or case content is
placed in a span; attributes are restricted to route metadata and outcome.
"""
from __future__ import annotations

import json
import queue
import re
import secrets
import ssl
import threading
import time
import urllib.parse
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Dict, Mapping, Optional


TRACEPARENT = re.compile(
    r"^(?P<version>[0-9a-f]{2})-(?P<trace>[0-9a-f]{32})-"
    r"(?P<parent>[0-9a-f]{16})-(?P<flags>[0-9a-f]{2})$"
)


class TelemetryConfigurationError(ValueError):
    """An exporter configuration would weaken the deployment boundary."""


def _nonzero_hex(length: int) -> str:
    while True:
        value = secrets.token_hex(length // 2)
        if int(value, 16):
            return value


def _loopback(hostname: str) -> bool:
    return hostname in {"localhost", "127.0.0.1", "::1"}


@dataclass(frozen=True)
class SpanContext:
    trace_id: str
    span_id: str
    parent_span_id: str
    trace_flags: str
    start_ns: int
    name: str

    @property
    def traceparent(self) -> str:
        return f"00-{self.trace_id}-{self.span_id}-{self.trace_flags}"


def parse_traceparent(value: str) -> Optional[Dict[str, str]]:
    """Return a valid W3C parent or ``None`` for an absent/malformed value."""
    match = TRACEPARENT.fullmatch(str(value or "").strip().lower())
    if match is None or match.group("version") == "ff":
        return None
    if int(match.group("trace"), 16) == 0 or int(match.group("parent"), 16) == 0:
        return None
    return {
        "trace_id": match.group("trace"),
        "parent_span_id": match.group("parent"),
        "trace_flags": match.group("flags"),
    }


def parse_otlp_headers(value: str) -> Dict[str, str]:
    """Parse the standard comma-separated OTLP exporter header environment."""
    result: Dict[str, str] = {}
    if not str(value or "").strip():
        return result
    for item in str(value).split(","):
        if "=" not in item:
            raise TelemetryConfigurationError(
                "OTEL_EXPORTER_OTLP_HEADERS entries must be name=value"
            )
        raw_name, raw_value = item.split("=", 1)
        name = urllib.parse.unquote(raw_name.strip())
        header_value = urllib.parse.unquote(raw_value.strip())
        if not name or any(character in name + header_value for character in "\r\n"):
            raise TelemetryConfigurationError("OTLP exporter headers are malformed")
        if name.lower() in {"content-type", "content-length", "host"}:
            raise TelemetryConfigurationError(f"OTLP exporter header {name!r} is reserved")
        result[name] = header_value
    return result


def _attributes(values: Mapping[str, Any]) -> list:
    rows = []
    for key, value in sorted(values.items()):
        if value is None:
            continue
        if isinstance(value, bool):
            encoded = {"boolValue": value}
        elif isinstance(value, int):
            encoded = {"intValue": str(value)}
        elif isinstance(value, float):
            encoded = {"doubleValue": value}
        else:
            encoded = {"stringValue": str(value)}
        rows.append({"key": str(key), "value": encoded})
    return rows


class OtlpTelemetry:
    """W3C propagation plus a bounded OTLP/HTTP JSON exporter.

    ``sender`` is an injection seam for tests and embedders.  Its input is the
    complete OTLP document.  Production uses an HTTPS endpoint, except that a
    loopback HTTP collector may be selected explicitly (the usual sidecar
    topology).  The queue bound is part of the trust profile: observability
    cannot consume unbounded memory when the collector is unavailable.
    """

    def __init__(
        self,
        endpoint: str = "",
        *,
        service_name: str = "crg-server",
        queue_size: int = 2048,
        timeout_seconds: float = 2.0,
        ca_file: str = "",
        headers: Optional[Mapping[str, str]] = None,
        sender: Optional[Callable[[Mapping[str, Any]], None]] = None,
        synchronous: bool = False,
    ) -> None:
        if queue_size <= 0 or timeout_seconds <= 0:
            raise TelemetryConfigurationError("telemetry queue and timeout must be positive")
        self.endpoint = str(endpoint or "").strip()
        self.service_name = str(service_name or "crg-server")
        self.timeout_seconds = float(timeout_seconds)
        self.ca_file = str(ca_file or "").strip()
        self.headers = {str(key): str(value) for key, value in (headers or {}).items()}
        self._sender = sender
        self._synchronous = bool(synchronous)
        self._queue: "queue.Queue[Optional[Mapping[str, Any]]]" = queue.Queue(queue_size)
        self._lock = threading.Lock()
        self._exported = 0
        self._failures = 0
        self._dropped = 0
        self._closed = False
        self._thread: Optional[threading.Thread] = None
        if self.endpoint:
            parsed = urllib.parse.urlparse(self.endpoint)
            if parsed.scheme not in {"http", "https"} or not parsed.hostname:
                raise TelemetryConfigurationError("OTLP traces endpoint must be an HTTP(S) URL")
            if parsed.scheme != "https" and not _loopback(parsed.hostname):
                raise TelemetryConfigurationError(
                    "cleartext OTLP export is permitted only to a loopback collector"
                )
        if self.ca_file and not Path(self.ca_file).is_file():
            raise TelemetryConfigurationError(f"OTLP CA file does not exist: {self.ca_file}")
        for name, value in self.headers.items():
            if (not name or any(character in name + value for character in "\r\n")
                    or name.lower() in {"content-type", "content-length", "host"}):
                raise TelemetryConfigurationError(f"unsafe OTLP exporter header {name!r}")
        if self.enabled and not self._synchronous:
            self._thread = threading.Thread(
                target=self._run, name="crg-otlp-exporter", daemon=True
            )
            self._thread.start()

    @property
    def enabled(self) -> bool:
        return self._sender is not None or bool(self.endpoint)

    def start(self, *, name: str, traceparent: str = "") -> SpanContext:
        parent = parse_traceparent(traceparent)
        return SpanContext(
            trace_id=(parent or {}).get("trace_id") or _nonzero_hex(32),
            span_id=_nonzero_hex(16),
            parent_span_id=(parent or {}).get("parent_span_id") or "",
            trace_flags=(parent or {}).get("trace_flags") or "01",
            start_ns=time.time_ns(),
            name=str(name or "HTTP request"),
        )

    def finish(self, span: SpanContext, attributes: Mapping[str, Any]) -> None:
        if not self.enabled or self._closed:
            return
        document = self._document(span, attributes)
        if self._synchronous:
            self._send_counted(document)
            return
        try:
            self._queue.put_nowait(document)
        except queue.Full:
            with self._lock:
                self._dropped += 1

    def _document(self, span: SpanContext, attributes: Mapping[str, Any]) -> Dict[str, Any]:
        status_code = int(attributes.get("http.response.status_code") or 0)
        record = {
            "traceId": span.trace_id,
            "spanId": span.span_id,
            "name": span.name,
            "kind": 2,
            "startTimeUnixNano": str(span.start_ns),
            "endTimeUnixNano": str(time.time_ns()),
            "attributes": _attributes(attributes),
            "status": {"code": 2 if status_code >= 400 else 1},
        }
        if span.parent_span_id:
            record["parentSpanId"] = span.parent_span_id
        return {
            "resourceSpans": [{
                "resource": {"attributes": _attributes({
                    "service.name": self.service_name,
                    "service.version": "1.3.0",
                })},
                "scopeSpans": [{
                    "scope": {"name": "crg-server.http", "version": "1.3.0"},
                    "spans": [record],
                }],
            }]
        }

    def _send(self, document: Mapping[str, Any]) -> None:
        if self._sender is not None:
            self._sender(document)
            return
        payload = json.dumps(document, sort_keys=True, separators=(",", ":")).encode()
        request = urllib.request.Request(
            self.endpoint,
            data=payload,
            method="POST",
            headers={"Content-Type": "application/json", **self.headers},
        )
        context = ssl.create_default_context(cafile=self.ca_file or None)
        with urllib.request.urlopen(
            request, timeout=self.timeout_seconds, context=context
        ) as response:
            if not 200 <= int(response.status) < 300:
                raise RuntimeError(f"OTLP collector returned HTTP {response.status}")

    def _send_counted(self, document: Mapping[str, Any]) -> None:
        try:
            self._send(document)
        except Exception:  # exporter failure is isolated from the CRG request
            with self._lock:
                self._failures += 1
        else:
            with self._lock:
                self._exported += 1

    def _run(self) -> None:
        while True:
            document = self._queue.get()
            try:
                if document is None:
                    return
                self._send_counted(document)
            finally:
                self._queue.task_done()

    def metrics(self) -> Dict[str, int]:
        with self._lock:
            return {
                "enabled": 1 if self.enabled else 0,
                "pending": self._queue.qsize(),
                "exported": self._exported,
                "failures": self._failures,
                "dropped": self._dropped,
            }

    def close(self, timeout_seconds: float = 2.0) -> None:
        if self._closed:
            return
        self._closed = True
        if self._thread is not None:
            try:
                self._queue.put(None, timeout=max(0.0, float(timeout_seconds)))
            except queue.Full:
                with self._lock:
                    self._dropped += 1
                return
            self._thread.join(max(0.0, float(timeout_seconds)))


__all__ = [
    "OtlpTelemetry", "SpanContext", "TelemetryConfigurationError",
    "parse_otlp_headers", "parse_traceparent",
]
