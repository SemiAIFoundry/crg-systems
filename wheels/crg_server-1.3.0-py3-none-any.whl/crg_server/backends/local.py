"""The shipped local profile, behind the interface.

Normative basis: 42.2 (local profile: SQLite or equivalent metadata,
filesystem content storage, a local worker, no required external services,
import and export parity with server mode), 42.1 (storage model), 6.2
(portable state), 6.3 (no central-service dependency), 17 (deletion,
retention, redaction, tombstones), 18 (typed dependency graph), 44.7 (audit).

This module contains no new persistence.  It contains an *adaptation*.
:class:`crg_server.store.CaseStore` already is 42.2 -- SQLite metadata, a
directory of canonical JSON named by content hash, a JSONL audit file -- and
the point of this file is to demonstrate that the interface in
:mod:`crg_server.backends.base` was derived from that class rather than
invented next to it.  If the local profile could not be expressed through the
interface, the interface would be describing a store nobody ships, and the
PostgreSQL and S3 adapters would be conforming to a fiction.

So :class:`SqliteFilesystemBackend` *wraps* a live ``CaseStore`` and calls its
public methods.  It does not subclass it, does not reimplement it, and does
not require it to change.  Where the interface needs something ``CaseStore``
does not expose as a method -- writing a tombstone row without also running
the whole 17.3 dependent-downgrade, for instance -- it goes through the
connection ``CaseStore.connection()`` hands out, against the tables
``crg_server.store.SCHEMA_SQL`` already declares.  No new table is created and
no existing statement is changed, which means a store written by the server
today is readable through this adapter today and vice versa.  That is 42.2's
"import and export parity" holding across the seam as well as across the CLI
boundary.

**One real constraint, stated rather than hidden.**  The object-store half of
the interface deals in *bytes*; ``CaseStore`` deals in *canonical JSON
objects*, because 14.3 canonicalization is what its addresses are computed
over.  This adapter therefore accepts only payloads that are already the
canonical encoding of a JSON value, and refuses anything else with a
:class:`~crg_server.errors.UsageError`.  Every byte string the server stores
satisfies that, so nothing is lost in practice -- but a deployment that wanted
to keep opaque binary artifacts in the local profile would need the object
directory to stop going through ``CaseStore``, and this docstring is where
that would be discovered rather than at the failure.

**What is real here.**  All of it.  This adapter is exercised against the same
on-disk store the reference server uses, by the same contract suite that runs
against the PostgreSQL and S3 adapters.  Unlike those two, nothing about this
file is aspirational.
"""
from __future__ import annotations

import json
import os
from contextlib import contextmanager
from typing import Any, Dict, Iterator, List, Mapping, Optional, Sequence, Union

from crg_model.canonical import canonical_json
from crg_model.envelope import utc_now

from ..errors import ConflictError, NotFoundError, UsageError
from ..store import CaseStore
from .base import (
    DEFAULT_PERMITTED_DISCLOSURE,
    STRICT_LOCAL_CONSISTENCY,
    AuditRecord,
    BackendUnavailableError,
    CaseVersionRecord,
    CertificateRecord,
    ConsistencyModel,
    EdgeRecord,
    IdempotencyRecord,
    JobRecord,
    ObjectRecord,
    TombstoneRecord,
    split_digest,
    verify_digest,
)
from .composite import CompositeBackend

__all__ = [
    "SqliteFilesystemBackend",
    "LocalObjectStore",
    "LocalMetadataStore",
    "canonical_payload",
]


def canonical_payload(value: Any) -> bytes:
    """The canonical encoding of ``value`` (14.3), as bytes.

    Exposed because the contract suite and the server both need to turn a
    mapping into the exact bytes whose hash is its address, and there must be
    exactly one function that does it.
    """
    return canonical_json(value).encode("utf-8")


def _decode_canonical(payload: bytes, *, digest: str) -> Any:
    """Bytes to JSON value, insisting the bytes *are* the canonical encoding.

    Round-tripping and comparing is not paranoia here: it is the only thing
    that keeps ``put_content`` honest.  If a caller handed over bytes that
    decode to the same value but encode differently (key order, whitespace),
    ``CaseStore`` would store the *canonical* form and the resulting address
    would not be the address the caller declared -- silently putting content
    somewhere other than where the caller was told.
    """
    try:
        value = json.loads(payload.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise UsageError(
            f"the local profile stores canonical JSON only; payload for {digest} "
            f"is not JSON ({error})",
            remedy=(
                "the 42.2 object directory is CaseStore's, and CaseStore addresses "
                "canonical JSON (14.3); use an object store that accepts opaque "
                "bytes if binary artifacts are needed"
            ),
        ) from error
    if canonical_payload(value) != payload:
        raise UsageError(
            f"payload for {digest} is JSON but not its canonical encoding (14.3)",
            remedy="encode with crg_model.canonical.canonical_json before storing",
        )
    return value


class LocalObjectStore:
    """:class:`~crg_server.backends.base.ObjectStoreBackend` over ``CaseStore``.

    Content addressing, deduplication, immutability, the redaction-
    resurrection refusal (17.2), and the on-read integrity check all come from
    ``CaseStore`` unchanged; this class translates between bytes and canonical
    values and re-verifies the digest at the seam.

    The re-verification is deliberately redundant with ``CaseStore``'s own.
    :func:`~crg_server.backends.base.verify_digest` is called on every read in
    every adapter so that the contract suite tests *one* rule -- "a returned
    object whose bytes do not hash to its address is a hard failure" -- and
    tests it identically everywhere, rather than testing the filesystem's
    version of it and hoping S3's version agrees.
    """

    def __init__(self, store: CaseStore) -> None:
        self._store = store
        self._closed = False

    # -- content ----------------------------------------------------------
    def put_content(
        self,
        digest: str,
        payload: bytes,
        *,
        object_type: str = "OpaqueRecord",
        created_by: str = "crg-server",
        legal_hold: bool = False,
    ) -> bool:
        split_digest(digest)
        verify_digest(digest, payload, where="local put_content (caller-declared address)")
        value = _decode_canonical(payload, digest=digest)
        existed = self._store.has_object(digest)
        written = self._store.put_object(
            value,
            object_type=object_type,
            created_by=created_by,
            legal_hold=legal_hold,
        )
        if written != digest:
            # Unreachable given the checks above; kept because "unreachable"
            # is a claim and 6.6 says an unknown state fails closed.
            raise BackendUnavailableError(
                f"CaseStore stored payload declared as {digest} at {written}",
                remedy="this store is inconsistent with its own canonicalization; quarantine it",
                detail={"declared": digest, "stored": written},
            )
        return not existed

    def get_content(self, digest: str) -> bytes:
        split_digest(digest)
        value = self._store.get_object(digest)
        payload = canonical_payload(value)
        verify_digest(digest, payload, where="local get_content (filesystem)")
        return payload

    def has_content(self, digest: str) -> bool:
        return bool(self._store.has_object(digest))

    def delete_content(self, digest: str) -> bool:
        """Remove bytes, keep the row.  Refuses under legal hold (17.5).

        Deliberately *not* ``CaseStore.redact``: that method is the whole 17.2
        plus 17.3 composition, and this is the primitive underneath it.
        :meth:`SqliteFilesystemBackend.redact` composes the same steps in the
        same order for every backend, so that the contract suite tests one
        redaction and not one per store.
        """
        connection = self._store.connection()
        with connection.transaction(immediate=True):
            row = connection.execute(
                "SELECT path, present, legal_hold FROM objects WHERE content_hash = ?",
                (digest,),
            ).fetchone()
            if row is None:
                return False
            if bool(row["legal_hold"]):
                raise ConflictError(
                    f"object {digest} is under legal hold and MUST NOT be deleted or "
                    "cryptographically erased until the hold is released (17.5)",
                    remedy="release the hold under authorized policy, then redact",
                    detail={"content_hash": digest},
                )
            if not row["present"]:
                return False
            path = os.path.join(self._store.root, str(row["path"]))
            if os.path.exists(path):
                os.remove(path)
            connection.execute(
                "UPDATE objects SET present = 0 WHERE content_hash = ?", (digest,)
            )
        return True

    def content_metadata(self, digest: str) -> ObjectRecord:
        record = self._store.object_metadata(digest)
        connection = self._store.connection()
        row = connection.execute(
            "SELECT reason FROM object_status WHERE content_hash = ?", (digest,)
        ).fetchone()
        return ObjectRecord(
            content_hash=str(record["content_hash"]),
            object_type=str(record["object_type"]),
            byte_length=int(record["byte_length"]),
            created_at=str(record["created_at"]),
            created_by=str(record["created_by"]),
            present=bool(record["present"]),
            legal_hold=bool(record["legal_hold"]),
            status=str(record["status"]),
            status_reason=str(row["reason"]) if row else "",
        )

    def content_status(self, digest: str) -> str:
        return str(self._store.object_status(digest))

    def set_content_status(self, digest: str, status: str, *, reason: str = "") -> None:
        # ``CaseStore.set_object_status`` restricts to the 12 vocabulary and
        # raises UsageError otherwise, which is the behaviour the interface
        # declares; the internal INTEGRITY_FAILED marker it also writes is not
        # reachable through this path and that is correct -- it is a store
        # diagnosis, not a lifecycle state a caller may assert.
        self._store.set_object_status(digest, status, reason=reason)

    def legal_hold(self, digest: str) -> bool:
        row = self._store.connection().execute(
            "SELECT legal_hold FROM objects WHERE content_hash = ?", (digest,)
        ).fetchone()
        return bool(row["legal_hold"]) if row else False

    def set_legal_hold(self, digest: str, held: bool, *, authority: str = "") -> None:
        connection = self._store.connection()
        with connection._lock:
            row = connection.execute(
                "SELECT content_hash FROM objects WHERE content_hash = ?", (digest,)
            ).fetchone()
            if row is None:
                # 17.5 holds may precede the object.  ``CaseStore.set_legal_hold``
                # would silently update nothing; record the intent instead so the
                # hold is in force when the bytes arrive.
                connection.execute(
                    "INSERT INTO objects (content_hash, object_type, path, byte_length, "
                    "created_at, created_by, present, legal_hold) VALUES (?,?,?,?,?,?,0,?)",
                    (digest, "PendingLegalHold", "", 0, utc_now(), authority or "legal-hold",
                     1 if held else 0),
                )
                return
            self._store.set_legal_hold(digest, held, authority=authority)

    def list_digests(self, *, limit: Optional[int] = None) -> List[str]:
        rows = self._store.connection().execute(
            "SELECT content_hash FROM objects WHERE present = 1 ORDER BY content_hash ASC"
        ).fetchall()
        digests = [str(r["content_hash"]) for r in rows]
        return digests if limit is None else digests[: int(limit)]

    def consistency(self) -> ConsistencyModel:
        return STRICT_LOCAL_CONSISTENCY

    def close(self) -> None:
        self._closed = True  # the CaseStore is owned by the composite


class LocalMetadataStore:
    """:class:`~crg_server.backends.base.MetadataBackend` over ``CaseStore``.

    Reads and writes exactly the tables ``crg_server.store.SCHEMA_SQL``
    declares, through the serialized connection ``CaseStore`` publishes.  It
    adds no schema, so a store this adapter has written is still a store the
    unwrapped server can open, which is 6.2's portability requirement holding
    across the seam.
    """

    def __init__(self, store: CaseStore) -> None:
        self._store = store
        # Share CaseStore's connection lock so adapter read/validate/write
        # units cannot interleave with the server's direct persistence calls.
        self._lock = store.connection()._lock
        self._depth = 0

    # -- unit of work -----------------------------------------------------
    @contextmanager
    def transaction(self) -> Iterator[None]:
        """Mutual exclusion, not rollback.  See :data:`STRICT_LOCAL_CONSISTENCY`.

        ``CaseStore`` commits at each of its own statements, so wrapping a
        sequence in ``BEGIN``/``ROLLBACK`` here would either be a lie (the
        inner commits already landed) or would require changing ``CaseStore``.
        What this *does* guarantee is that no other caller interleaves, which
        is what 16.1's read-head-then-append needs.  The consistency model
        says ``MUTUAL_EXCLUSION`` so a caller who needs more can find out by
        asking rather than by losing data.
        """
        with self._lock:
            self._depth += 1
            try:
                yield
            finally:
                self._depth -= 1

    def initialize(self) -> None:
        """No-op: ``CaseStore.__init__`` already ran ``SCHEMA_SQL``."""
        return None

    def lock_dependency_graph(self, case_id: str) -> None:
        """The enclosing local transaction already holds the process lock."""
        return None

    # -- cases ------------------------------------------------------------
    def put_case_version(self, record: CaseVersionRecord) -> None:
        connection = self._store.connection()
        with self._lock:
            existing = connection.execute(
                "SELECT content_hash FROM cases WHERE case_id = ? AND case_version = ?",
                (record.case_id, int(record.case_version)),
            ).fetchone()
            if existing is not None:
                raise ConflictError(
                    f"case {record.case_id!r} already has a version "
                    f"{record.case_version}; history is append-only (15.3)",
                    remedy="re-read the head version, re-apply the change, and retry (16.1)",
                    detail={"case_id": record.case_id,
                            "case_version": int(record.case_version),
                            "existing_content_hash": str(existing["content_hash"])},
                )
            connection.execute(
                "INSERT INTO cases (case_id, case_version, content_hash, branch_id, "
                "derived_from, parent_version, status, created_at, created_by) "
                "VALUES (?,?,?,?,?,?,?,?,?)",
                (
                    record.case_id,
                    int(record.case_version),
                    record.content_hash,
                    record.branch_id,
                    record.derived_from or None,
                    record.parent_version,
                    record.status,
                    record.created_at or utc_now(),
                    record.created_by,
                ),
            )
            connection.commit()

    def head_version(self, case_id: str) -> int:
        return int(self._store.head_version(case_id))

    def case_version(
        self, case_id: str, version: Union[int, str, None] = None
    ) -> CaseVersionRecord:
        connection = self._store.connection()
        if version is None:
            row = connection.execute(
                "SELECT * FROM cases WHERE case_id = ? ORDER BY case_version DESC LIMIT 1",
                (case_id,),
            ).fetchone()
        elif isinstance(version, str) and version.startswith("sha256:"):
            row = connection.execute(
                "SELECT * FROM cases WHERE case_id = ? AND content_hash = ?",
                (case_id, version),
            ).fetchone()
        else:
            try:
                ordinal = int(version)
            except (TypeError, ValueError):
                raise UsageError(
                    f"version {version!r} is neither an ordinal nor a sha256 content hash"
                ) from None
            row = connection.execute(
                "SELECT * FROM cases WHERE case_id = ? AND case_version = ?",
                (case_id, ordinal),
            ).fetchone()
        if row is None:
            raise NotFoundError(
                f"no case {case_id!r}" + ("" if version is None else f" at version {version!r}"),
                remedy="POST /cases to create one, or GET /cases/{case_id} for the head",
            )
        return _case_row(row)

    def list_case_versions(self, case_id: str) -> List[CaseVersionRecord]:
        rows = self._store.connection().execute(
            "SELECT * FROM cases WHERE case_id = ? ORDER BY case_version ASC", (case_id,)
        ).fetchall()
        return [_case_row(row) for row in rows]

    def list_case_ids(self) -> List[str]:
        return list(self._store.list_cases())

    # -- edges ------------------------------------------------------------
    def record_edge(self, record: EdgeRecord) -> None:
        connection = self._store.connection()
        connection.execute(
            "INSERT OR REPLACE INTO edges (edge_id, case_id, source, target, edge_type, "
            "scope, minimum_action, recorded_at) VALUES (?,?,?,?,?,?,?,?)",
            (
                record.edge_id,
                record.case_id or None,
                record.source,
                record.target,
                record.edge_type,
                record.scope,
                record.minimum_action,
                record.recorded_at or utc_now(),
            ),
        )
        connection.commit()

    def edges_from(self, source: str) -> List[EdgeRecord]:
        return [_edge_row(r) for r in self._store.edges_from(source)]

    def edges_to(self, target: str) -> List[EdgeRecord]:
        return [_edge_row(r) for r in self._store.edges_to(target)]

    def edges_for_case(self, case_id: str) -> List[EdgeRecord]:
        return [_edge_row(r) for r in self._store.edges_for(case_id)]

    # -- certificates -----------------------------------------------------
    def register_certificate(self, record: CertificateRecord) -> None:
        connection = self._store.connection()
        connection.execute(
            "INSERT OR REPLACE INTO certificates (case_id, certificate_id, content_hash, "
            "job_id, outcome, affirmative, registered_at) VALUES (?,?,?,?,?,?,?)",
            (
                record.case_id,
                record.certificate_id,
                record.content_hash,
                record.job_id,
                record.outcome,
                1 if record.affirmative else 0,
                record.registered_at or utc_now(),
            ),
        )
        connection.commit()

    def certificate(self, case_id: str, certificate_id: str) -> CertificateRecord:
        row = self._store.connection().execute(
            "SELECT * FROM certificates WHERE case_id = ? AND certificate_id = ?",
            (case_id, certificate_id),
        ).fetchone()
        if row is None:
            raise NotFoundError(f"no certificate {certificate_id!r} in case {case_id!r}")
        return _certificate_row(row)

    def list_certificates(self, case_id: str) -> List[CertificateRecord]:
        rows = self._store.connection().execute(
            "SELECT * FROM certificates WHERE case_id = ? ORDER BY certificate_id ASC",
            (case_id,),
        ).fetchall()
        return [_certificate_row(row) for row in rows]

    def unregister_certificates(self, job_id: str) -> int:
        return int(self._store.unregister_certificates(job_id))

    # -- idempotency ------------------------------------------------------
    def idempotency_lookup(self, key: str) -> Optional[IdempotencyRecord]:
        row = self._store.idempotent_lookup(key)
        if row is None:
            return None
        return IdempotencyRecord(
            key=str(row["key"]),
            request_hash=str(row["request_hash"]),
            response_json=str(row["response_json"]),
            status=int(row["status"]),
            created_at=str(row["created_at"]),
        )

    def idempotency_record(self, record: IdempotencyRecord) -> None:
        connection = self._store.connection()
        connection.execute(
            "INSERT OR REPLACE INTO idempotency (key, request_hash, response_json, "
            "status, created_at) VALUES (?,?,?,?,?)",
            (
                record.key,
                record.request_hash,
                record.response_json,
                int(record.status),
                record.created_at or utc_now(),
            ),
        )
        connection.commit()

    def list_idempotency(self) -> List[IdempotencyRecord]:
        rows = self._store.connection().execute(
            "SELECT key, request_hash, response_json, status, created_at "
            "FROM idempotency ORDER BY key ASC"
        ).fetchall()
        return [
            IdempotencyRecord(
                key=str(row["key"]), request_hash=str(row["request_hash"]),
                response_json=str(row["response_json"]), status=int(row["status"]),
                created_at=str(row["created_at"]),
            )
            for row in rows
        ]

    # -- jobs -------------------------------------------------------------
    def save_job(self, record: JobRecord) -> None:
        connection = self._store.connection()
        with connection.transaction(immediate=True):
            connection.execute(
                "INSERT OR REPLACE INTO jobs (job_id, record_json, updated_at) VALUES (?,?,?)",
                (record.job_id, record.record_json, record.updated_at or utc_now()),
            )
            if record.payload_json:
                connection.execute(
                    "INSERT OR REPLACE INTO job_payloads (job_id, payload_json, created_at) "
                    "VALUES (?,?,?)",
                    (record.job_id, record.payload_json, utc_now()),
                )

    def compare_and_set_job(
        self,
        record: JobRecord,
        *,
        expected_statuses: Sequence[str],
        expected_phase: str,
    ) -> bool:
        document = json.loads(record.record_json)
        changed = self._store.compare_and_set_job(
            record.job_id,
            document,
            expected_statuses=expected_statuses,
            expected_phase=expected_phase,
        )
        if changed and record.payload_json:
            self._store.save_job_payload(record.job_id, json.loads(record.payload_json))
        return changed

    def load_job(self, job_id: str) -> Optional[JobRecord]:
        connection = self._store.connection()
        row = connection.execute(
            "SELECT * FROM jobs WHERE job_id = ?", (job_id,)
        ).fetchone()
        if row is None:
            return None
        payload = connection.execute(
            "SELECT payload_json FROM job_payloads WHERE job_id = ?", (job_id,)
        ).fetchone()
        return JobRecord(
            job_id=str(row["job_id"]),
            record_json=str(row["record_json"]),
            updated_at=str(row["updated_at"]),
            payload_json=str(payload["payload_json"]) if payload else "",
        )

    def list_jobs(self) -> List[JobRecord]:
        rows = self._store.connection().execute(
            "SELECT j.*, p.payload_json FROM jobs AS j "
            "LEFT JOIN job_payloads AS p ON p.job_id = j.job_id "
            "ORDER BY j.job_id ASC"
        ).fetchall()
        return [
            JobRecord(
                job_id=str(r["job_id"]),
                record_json=str(r["record_json"]),
                updated_at=str(r["updated_at"]),
                payload_json=str(r["payload_json"] or ""),
            )
            for r in rows
        ]

    # -- audit ------------------------------------------------------------
    def append_audit(self, recorded_at: str, event_json: str) -> int:
        """Append to both the table and ``audit.jsonl``.

        Both, because 6.2 requires the state to be exportable without a
        running service and a JSONL file is the form an auditor can read with
        ``cat``; and append-only in both, because 44.7 requires an immutable
        event and a log a caller can rewrite is not one.
        """
        connection = self._store.connection()
        with self._lock:
            result = connection.execute(
                "INSERT INTO audit (recorded_at, event_json) VALUES (?,?)",
                (recorded_at or utc_now(), event_json),
            )
            with open(self._store.audit_path, "a", encoding="utf-8") as handle:
                handle.write(event_json + "\n")
        return int(result.lastrowid or 0)

    def read_audit(
        self, *, after_seq: int = 0, limit: Optional[int] = None
    ) -> List[AuditRecord]:
        rows = self._store.connection().execute(
            "SELECT seq, recorded_at, event_json FROM audit WHERE seq > ? ORDER BY seq ASC",
            (int(after_seq),),
        ).fetchall()
        records = [
            AuditRecord(
                seq=int(r["seq"]),
                recorded_at=str(r["recorded_at"]),
                event_json=str(r["event_json"]),
            )
            for r in rows
        ]
        return records if limit is None else records[: int(limit)]

    # -- tombstones -------------------------------------------------------
    def put_tombstone(self, record: TombstoneRecord) -> None:
        connection = self._store.connection()
        with self._lock:
            existing = connection.execute(
                "SELECT content_hash FROM tombstones WHERE content_hash = ?",
                (record.content_hash,),
            ).fetchone()
            if existing is not None:
                return
            connection.execute(
                "INSERT INTO tombstones (content_hash, object_id, object_type, reason, "
                "authority, removed_at, legal_hold, permitted_disclosure, edges_json) "
                "VALUES (?,?,?,?,?,?,?,?,?)",
                (
                    record.content_hash,
                    record.object_id,
                    record.object_type,
                    record.reason,
                    record.authority,
                    record.removed_at or utc_now(),
                    1 if record.legal_hold else 0,
                    record.permitted_disclosure,
                    record.dependency_edges_json,
                ),
            )

    def get_tombstone(self, digest: str) -> Optional[TombstoneRecord]:
        row = self._store.connection().execute(
            "SELECT * FROM tombstones WHERE content_hash = ?", (digest,)
        ).fetchone()
        return _tombstone_row(row) if row else None

    def list_tombstones(self) -> List[TombstoneRecord]:
        rows = self._store.connection().execute(
            "SELECT * FROM tombstones ORDER BY content_hash ASC"
        ).fetchall()
        return [_tombstone_row(row) for row in rows]

    def consistency(self) -> ConsistencyModel:
        return STRICT_LOCAL_CONSISTENCY

    def close(self) -> None:
        return None  # the CaseStore is owned by the composite


# ---------------------------------------------------------------------------
# Row adapters.  One place per shape, so a column rename in SCHEMA_SQL breaks
# here rather than in nine call sites.
# ---------------------------------------------------------------------------
def _case_row(row: Any) -> CaseVersionRecord:
    return CaseVersionRecord(
        case_id=str(row["case_id"]),
        case_version=int(row["case_version"]),
        content_hash=str(row["content_hash"]),
        branch_id=str(row["branch_id"] or "main"),
        derived_from=str(row["derived_from"] or ""),
        parent_version=(int(row["parent_version"])
                        if row["parent_version"] is not None else None),
        status=str(row["status"]),
        created_at=str(row["created_at"]),
        created_by=str(row["created_by"]),
    )


def _edge_row(row: Mapping[str, Any]) -> EdgeRecord:
    return EdgeRecord(
        edge_id=str(row["edge_id"]),
        source=str(row["source"]),
        target=str(row["target"]),
        edge_type=str(row["edge_type"]),
        case_id=str(row["case_id"] or ""),
        scope=str(row["scope"] or ""),
        minimum_action=str(row["minimum_action"] or ""),
        recorded_at=str(row["recorded_at"]),
    )


def _certificate_row(row: Any) -> CertificateRecord:
    return CertificateRecord(
        case_id=str(row["case_id"]),
        certificate_id=str(row["certificate_id"]),
        content_hash=str(row["content_hash"]),
        job_id=str(row["job_id"]),
        outcome=str(row["outcome"]),
        affirmative=bool(row["affirmative"]),
        registered_at=str(row["registered_at"]),
    )


def _tombstone_row(row: Any) -> TombstoneRecord:
    return TombstoneRecord(
        content_hash=str(row["content_hash"]),
        object_id=str(row["object_id"]),
        object_type=str(row["object_type"]),
        reason=str(row["reason"]),
        authority=str(row["authority"]),
        removed_at=str(row["removed_at"]),
        legal_hold=bool(row["legal_hold"]),
        permitted_disclosure=str(row["permitted_disclosure"]),
        dependency_edges_json=str(row["edges_json"]),
    )


class SqliteFilesystemBackend:
    """The 42.2 profile as a :class:`~crg_server.backends.base.StoreBackend`.

    Constructed either from a root directory (it makes the ``CaseStore``) or
    from an existing ``CaseStore`` (it wraps the one the server already holds).
    The second form is what makes the conformance claim meaningful: the
    contract suite runs against the *same live store* the reference server
    uses, not a copy built to satisfy the interface.
    """

    def __init__(
        self,
        root: Optional[str] = None,
        *,
        store: Optional[CaseStore] = None,
    ) -> None:
        if store is None and root is None:
            raise UsageError(
                "SqliteFilesystemBackend needs a root directory or an existing CaseStore"
            )
        self._owns_store = store is None
        self._store = store if store is not None else CaseStore(str(root))
        self._objects = LocalObjectStore(self._store)
        self._metadata = LocalMetadataStore(self._store)
        #: The *same* class the enterprise pairing uses.  Redaction, the 17.3
        #: downgrade, and case reads therefore run identical code here and
        #: over PostgreSQL plus S3, which is the whole point of the seam.
        self._composite = CompositeBackend(
            self._objects, self._metadata, name="sqlite+filesystem", initialize=False
        )

    @property
    def store(self) -> CaseStore:
        """The wrapped ``CaseStore``.  Local-profile-specific; not interface."""
        return self._store

    @property
    def objects(self) -> LocalObjectStore:
        return self._objects

    @property
    def metadata(self) -> LocalMetadataStore:
        return self._metadata

    def put_case(
        self,
        case: Mapping[str, Any],
        *,
        expected_parent_version: Optional[int] = None,
        created_by: str = "crg-server",
    ) -> CaseVersionRecord:
        return self._composite.put_case(
            case,
            expected_parent_version=expected_parent_version,
            created_by=created_by,
        )

    def get_case(
        self, case_id: str, version: Union[int, str, None] = None
    ) -> Dict[str, Any]:
        return self._composite.get_case(case_id, version)

    def redact(
        self,
        digest: str,
        *,
        reason: str,
        authority: str,
        permitted_disclosure: str = DEFAULT_PERMITTED_DISCLOSURE,
    ) -> TombstoneRecord:
        return self._composite.redact(
            digest,
            reason=reason,
            authority=authority,
            permitted_disclosure=permitted_disclosure,
        )

    def dependents_of(self, source: str) -> List[str]:
        return self._composite.dependents_of(source)

    def consistency(self) -> ConsistencyModel:
        return STRICT_LOCAL_CONSISTENCY

    def close(self) -> None:
        self._objects.close()
        self._metadata.close()
        if self._owns_store:
            self._store.close()

    def __enter__(self) -> "SqliteFilesystemBackend":
        return self

    def __exit__(self, *_exc: Any) -> None:
        self.close()

# v1.3 composite closure: this product path is phase-bound to ETQ integration.
