"""Server/job boundary for the six v1.3 ETQ lifecycle operations."""
from __future__ import annotations

from typing import Any, Mapping

from crg_cli.lifecycle import (
    LifecycleVerificationError,
    build_verified_lifecycle_record,
    inspect_lifecycle_record,
    persist_lifecycle_record,
    render_lifecycle_report,
    verify_lifecycle_record,
)

from .errors import BlockedOutcome, NotFoundError, UsageError
from .jobs import JobContext, JobResult

__all__ = ["op_publish", "inspect_record", "verify_request"]


def op_publish(context: JobContext) -> JobResult:
    """Produce, independently replay, and append one typed v1.3 ETQ record."""

    request = context.inputs.get("request") or {}
    case = dict(context.inputs["case"])
    try:
        record, verifier_inputs, verification, companions = (
            build_verified_lifecycle_record(request, case)
        )
    except LifecycleVerificationError as error:
        raise BlockedOutcome(
            "independent ETQ lifecycle replay disagreed with the producer",
            outcome="BLOCKED_VERIFIER_DISAGREEMENT",
            detail={"message": str(error)},
            remedy="publish nothing; repair and independently test the ETQ boundary",
        ) from error
    record_type, record_id = persist_lifecycle_record(
        case, record, verifier_inputs, companions
    )
    direct_state = inspect_lifecycle_record(
        case, record_type, record_id
    )["direct_state"]
    report = render_lifecycle_report(record, verification)
    context.log(
        f"ETQ lifecycle {record_type} {record_id} independently replayed; "
        f"generation={verifier_inputs['first_release_attribution']}"
    )
    objects = [
        (f"lifecycle:{record_type}:{record_id}", record),
        (
            f"lifecycle-verification-inputs:{record_type}:{record_id}",
            verifier_inputs,
        ),
    ]
    objects.extend(companions)
    return JobResult(
        outputs={
            "record_type": record_type,
            "record_id": record_id,
            "record": record,
            "verification_inputs": verifier_inputs,
            "verification": verification.to_json(),
            "direct_state": direct_state,
            "report": report,
        },
        objects=objects,
        case=case,
        proof_artifacts=[{
            "proof_type": "ETQ_LIFECYCLE_INDEPENDENT_REPLAY",
            "record_type": record_type,
            "record_hash": verifier_inputs["record_hash"],
            "verifier": "crg-verify",
            "status": verification.status,
            "first_release_attribution": "v1.3/ETQ_LIFECYCLE",
            "direct_state": direct_state,
            "synthetic_score": False,
            "commercial_inference": False,
        }],
    )


def inspect_record(case: Mapping[str, Any], record_type: str, record_id: str) -> dict:
    try:
        return inspect_lifecycle_record(case, record_type, record_id)
    except Exception as error:
        if "no lifecycle" in str(error):
            raise NotFoundError(
                f"no lifecycle {record_type} {record_id!r} in this case",
                remedy=(
                    "publish the dependency-ordered ETQ record or choose an "
                    "identity listed on the case"
                ),
            ) from error
        raise


def verify_request(request: Any) -> dict:
    if not isinstance(request, Mapping) or set(request) != {
        "record", "verification_inputs",
    }:
        raise UsageError(
            "lifecycle verification requires exactly {'record', 'verification_inputs'}",
            remedy=(
                "pass the canonical ETQ record and the exact portable "
                "independent-replay envelope"
            ),
        )
    if not isinstance(request.get("record"), Mapping):
        raise UsageError("lifecycle verification record must be a JSON object")
    if not isinstance(request.get("verification_inputs"), Mapping):
        raise UsageError("lifecycle verification inputs must be a JSON object")
    try:
        verification = verify_lifecycle_record(
            request["record"], request["verification_inputs"]
        )
    except LifecycleVerificationError as error:
        raise BlockedOutcome(
            "independent ETQ lifecycle replay failed",
            outcome="BLOCKED_VERIFICATION_FAILED",
            detail={"message": str(error)},
            remedy=(
                "do not rely on this record; recover the exact canonical "
                "producer output and replay inputs"
            ),
        ) from error
    record = dict(request["record"])
    return {
        "record": record,
        "verification_inputs": dict(request["verification_inputs"]),
        "verification": verification.to_json(),
        "report": render_lifecycle_report(record, verification),
    }
