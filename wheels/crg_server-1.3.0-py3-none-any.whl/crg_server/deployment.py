"""Secure construction of the shipped network deployment.

The application object deliberately still supports an unconfigured in-process
profile for tests and embedding.  This module is the stricter boundary used by
``crg-serve``: credentials come from environment variables, authorization is
deny-by-default, the audit chain is durable, and every router operation must
have an authorization mapping before the socket is opened.
"""
from __future__ import annotations

import json
import os
import base64
from pathlib import Path
from typing import Any, Dict, Mapping

from crg_security import (
    HashChainedAuditLog,
    IdentityBroker,
    LocalAccountDirectory,
    PolicyEngine,
    PolicySet,
    SecurityConfiguration,
    ServerSecurityGate,
    SystemClock,
    KeyVault,
    EnvelopeEncryptor,
    PersistentObjectEnvelopeCodec,
    AES_GCM_PROFILE,
    OidcHttpClient,
    OidcProvider,
)

from .app import ENDPOINTS
from .federation_state import load_federation_verifier_state

__all__ = [
    "DeploymentConfigurationError", "load_security_gate", "load_at_rest_codec",
    "load_federation_verifier_state",
]


class DeploymentConfigurationError(ValueError):
    """A startup configuration is unsafe, incomplete, or ambiguous."""


def _mapping(value: Any, name: str) -> Dict[str, Any]:
    if not isinstance(value, Mapping):
        raise DeploymentConfigurationError(f"{name} must be a JSON object")
    return dict(value)


def _secret_from_environment(entry: Mapping[str, Any], field: str) -> str:
    env_name = str(entry.get(field) or "").strip()
    if not env_name:
        raise DeploymentConfigurationError(
            f"{field} is required; secrets must be named by environment variable"
        )
    value = os.environ.get(env_name)
    if value is None or not value:
        raise DeploymentConfigurationError(
            f"environment variable {env_name!r}, named by {field}, is not set"
        )
    return value


def load_security_gate(path: str, *, store_root: str) -> ServerSecurityGate:
    """Load one authenticated, single-tenant deployment configuration.

    No secret value is accepted in the JSON file.  Each local account names a
    ``password_env`` and the deployment names ``pepper_env``; this keeps
    credentials out of release artifacts and command-line process listings.
    """
    config_path = Path(path).expanduser().resolve()
    try:
        document = _mapping(json.loads(config_path.read_text(encoding="utf-8")), "config")
    except (OSError, json.JSONDecodeError) as error:
        raise DeploymentConfigurationError(
            f"cannot read security configuration {str(config_path)!r}: {error}"
        ) from error

    forbidden_secret_fields = {"password", "pepper", "secret", "api_key"}
    present = forbidden_secret_fields.intersection(document)
    if present:
        raise DeploymentConfigurationError(
            f"security configuration contains secret-valued fields {sorted(present)}; "
            "name environment variables instead"
        )

    profile = str(document.get("profile") or "authenticated-single-tenant")
    if profile != "authenticated-single-tenant":
        raise DeploymentConfigurationError(
            f"unsupported security profile {profile!r}; this executable implements "
            "'authenticated-single-tenant' and refuses to imply multi-tenant isolation"
        )
    tenant_id = str(document.get("tenant_id") or "").strip()
    if not tenant_id:
        raise DeploymentConfigurationError("tenant_id is required")

    clock = SystemClock()
    account_documents = document.get("accounts", [])
    if not isinstance(account_documents, list):
        raise DeploymentConfigurationError("accounts must be a JSON array")
    oidc_documents = document.get("oidc_providers", [])
    if not isinstance(oidc_documents, list):
        raise DeploymentConfigurationError("oidc_providers must be a JSON array")
    if len(oidc_documents) > 1:
        raise DeploymentConfigurationError(
            "this Bearer boundary supports exactly one production OIDC provider; "
            "multiple issuers require an explicit issuer-routing policy"
        )
    if not account_documents and not oidc_documents:
        raise DeploymentConfigurationError(
            "configure at least one local account or one production OIDC provider"
        )
    accounts = None
    if account_documents:
        pepper = _secret_from_environment(document, "pepper_env").encode("utf-8")
        accounts = LocalAccountDirectory(
            tenant_id=tenant_id,
            clock=clock,
            pepper=pepper,
        )
    for index, raw_account in enumerate(account_documents):
        account = _mapping(raw_account, f"accounts[{index}]")
        if "password" in account:
            raise DeploymentConfigurationError(
                f"accounts[{index}] contains password; use password_env"
            )
        username = str(account.get("username") or "").strip()
        if not username:
            raise DeploymentConfigurationError(f"accounts[{index}].username is required")
        roles = account.get("roles")
        if not isinstance(roles, list) or not roles:
            raise DeploymentConfigurationError(
                f"accounts[{index}].roles must be a non-empty JSON array"
            )
        case_scope = account.get("case_scope", ["*"])
        if not isinstance(case_scope, list):
            raise DeploymentConfigurationError(
                f"accounts[{index}].case_scope must be a JSON array"
            )
        organization = account.get("organization")
        if organization is not None and (
            not isinstance(organization, str) or not organization.strip()
        ):
            raise DeploymentConfigurationError(
                f"accounts[{index}].organization must be a non-empty string when supplied"
            )
        attributes = {"case_scope": [str(case_id) for case_id in case_scope]}
        if organization is not None:
            # Lifecycle authority is deliberately bound to the authenticated
            # principal rather than to a caller-authored request field.  Keep
            # this deployment attribute explicit instead of accepting an
            # arbitrary account attributes object.
            attributes["organization"] = organization.strip()
        accounts.create_account(
            username=username,
            password=_secret_from_environment(account, "password_env"),
            roles=[str(role) for role in roles],
            attributes=attributes,
            display_name=str(account.get("display_name") or username),
            account_id=str(account.get("account_id") or f"acct:{tenant_id}:{username}"),
            credential_not_before=account.get("credential_not_before"),
            credential_not_after=account.get("credential_not_after"),
        )

    providers = []
    for index, raw_provider in enumerate(oidc_documents):
        provider = _mapping(raw_provider, f"oidc_providers[{index}]")
        forbidden = {"client_secret", "private_key", "token"}.intersection(provider)
        if forbidden:
            raise DeploymentConfigurationError(
                f"oidc_providers[{index}] contains secret-valued fields {sorted(forbidden)}; "
                "the resource-server profile must not hold an OIDC client secret"
            )
        algorithms = provider.get("allowed_algorithms", ["RS256"])
        if not isinstance(algorithms, list) or not algorithms:
            raise DeploymentConfigurationError(
                f"oidc_providers[{index}].allowed_algorithms must be a non-empty array"
            )
        role_map_raw = provider.get("role_map", {})
        role_map = _mapping(role_map_raw, f"oidc_providers[{index}].role_map")
        for group, roles in role_map.items():
            if not isinstance(roles, list):
                raise DeploymentConfigurationError(
                    f"oidc_providers[{index}].role_map[{group!r}] must be an array"
                )
        tenant_map = _mapping(
            provider.get("tenant_map", {}), f"oidc_providers[{index}].tenant_map"
        )
        if any(str(value) != tenant_id for value in tenant_map.values()):
            raise DeploymentConfigurationError(
                f"oidc_providers[{index}].tenant_map may map only to configured tenant "
                f"{tenant_id!r} in the single-tenant profile"
            )
        default_tenant = str(provider.get("default_tenant") or "")
        if default_tenant and default_tenant != tenant_id:
            raise DeploymentConfigurationError(
                f"oidc_providers[{index}].default_tenant must equal {tenant_id!r}"
            )
        attributes = provider.get("attribute_claims", ["name", "email", "groups"])
        accepted_types = provider.get("accepted_types", ["JWT", "at+jwt"])
        if not isinstance(attributes, list) or not isinstance(accepted_types, list):
            raise DeploymentConfigurationError(
                f"oidc_providers[{index}] attribute_claims and accepted_types must be arrays"
            )
        ca_file = str(provider.get("ca_file") or "")
        if ca_file and not Path(ca_file).is_absolute():
            ca_file = str((config_path.parent / ca_file).resolve())
        try:
            http_client = OidcHttpClient(
                ca_file=ca_file,
                timeout_seconds=float(provider.get("timeout_seconds", 5)),
                max_response_bytes=int(provider.get("max_response_bytes", 1 << 20)),
            )
            providers.append(OidcProvider(
                provider_id=str(provider.get("provider_id") or "oidc"),
                issuer=str(provider.get("issuer") or ""),
                audience=str(provider.get("audience") or ""),
                discovery_url=str(provider.get("discovery_url") or ""),
                allowed_algorithms=[str(item) for item in algorithms],
                role_claim=str(provider.get("role_claim") or "roles"),
                tenant_claim=str(provider.get("tenant_claim") or "tenant_id"),
                tenant_map={str(k): str(v) for k, v in tenant_map.items()},
                allowed_tenants=(tenant_id,),
                role_map={str(k): [str(item) for item in v] for k, v in role_map.items()},
                default_tenant=default_tenant,
                attribute_claims=[str(item) for item in attributes],
                display_name_claim=str(provider.get("display_name_claim") or "name"),
                required_claims=_mapping(
                    provider.get("required_claims", {}),
                    f"oidc_providers[{index}].required_claims",
                ),
                accepted_types=[str(item) for item in accepted_types],
                allow_missing_type=bool(provider.get("allow_missing_type", True)),
                require_issued_at=bool(provider.get("require_issued_at", True)),
                max_clock_skew_seconds=float(provider.get("max_clock_skew_seconds", 60)),
                max_token_age_seconds=provider.get("max_token_age_seconds"),
                jwks_cache_seconds=float(provider.get("jwks_cache_seconds", 300)),
                kid_miss_refresh_seconds=float(
                    provider.get("kid_miss_refresh_seconds", 30)
                ),
                max_token_bytes=int(provider.get("max_token_bytes", 32768)),
                http_client=http_client,
            ))
        except Exception as error:
            raise DeploymentConfigurationError(
                f"cannot configure oidc_providers[{index}]: {error}"
            ) from error

    audit_path = Path(store_root).expanduser().resolve() / "security" / "audit.jsonl"
    audit_log = HashChainedAuditLog(
        clock=clock,
        tenant_id=tenant_id,
        path=str(audit_path),
    )
    policy_document = document.get("policy")
    policy = (
        PolicySet.from_canonical(_mapping(policy_document, "policy"))
        if policy_document is not None
        else PolicySet(policy_id="rbac-only")
    )
    engine = PolicyEngine(
        policy,
        audit_log=audit_log,
        clock=clock,
        require_declarative_permit=bool(document.get("require_declarative_permit", False)),
    )
    broker = IdentityBroker(clock=clock, accounts=accounts, providers=providers)
    anonymous = document.get(
        "anonymous_operations", ["getOpenApi", "healthLive", "healthReady"]
    )
    if not isinstance(anonymous, list):
        raise DeploymentConfigurationError("anonymous_operations must be a JSON array")
    gate = ServerSecurityGate(SecurityConfiguration(
        broker=broker,
        engine=engine,
        clock=clock,
        audit_log=audit_log,
        required=True,
        anonymous_operations=tuple(str(item) for item in anonymous),
    ))
    unmapped = gate.unmapped_operations([endpoint.operation_id for endpoint in ENDPOINTS])
    if unmapped:
        raise DeploymentConfigurationError(
            f"authorization map is incomplete for operations {list(unmapped)}"
        )
    return gate


def load_at_rest_codec(path: str) -> PersistentObjectEnvelopeCodec:
    """Load the mandatory local-store envelope codec from a security config.

    Key bytes are never accepted in the JSON document.  A stable externally
    managed 32-byte KEK is supplied as strict base64 through the named
    environment variable, so encrypted bytes remain readable after restart.
    Production startup accepts AES-256-GCM only and never substitutes the
    standard-library test profile.
    """
    config_path = Path(path).expanduser().resolve()
    try:
        document = _mapping(json.loads(config_path.read_text(encoding="utf-8")), "config")
    except (OSError, json.JSONDecodeError) as error:
        raise DeploymentConfigurationError(
            f"cannot read security configuration {str(config_path)!r}: {error}"
        ) from error
    tenant_id = str(document.get("tenant_id") or "").strip()
    if not tenant_id:
        raise DeploymentConfigurationError("tenant_id is required")
    raw = _mapping(document.get("at_rest_encryption"), "at_rest_encryption")
    profile = str(raw.get("profile") or "")
    if profile != AES_GCM_PROFILE:
        raise DeploymentConfigurationError(
            f"at_rest_encryption.profile must be {AES_GCM_PROFILE!r}; received {profile!r}"
        )
    key_id = str(raw.get("key_id") or "").strip()
    if not key_id:
        raise DeploymentConfigurationError("at_rest_encryption.key_id is required")
    encoded = _secret_from_environment(raw, "key_material_env")
    try:
        material = base64.b64decode(encoded, validate=True)
    except (ValueError, TypeError) as error:
        raise DeploymentConfigurationError(
            "at-rest key material must be strict base64"
        ) from error
    clock = SystemClock()
    try:
        vault = KeyVault(clock=clock, profile=profile)
        vault.create(
            tenant_id=tenant_id,
            key_id=key_id,
            profile=profile,
            customer_managed=True,
            material=material,
        )
        return PersistentObjectEnvelopeCodec(
            EnvelopeEncryptor(vault, clock=clock, profile=profile),
            tenant_key_id=key_id,
        )
    except Exception as error:  # normalize security configuration failures at startup
        raise DeploymentConfigurationError(
            f"cannot configure AES-256-GCM at-rest encryption: {error}"
        ) from error

# v1.3 composite closure: this product path is phase-bound to ETQ integration.
