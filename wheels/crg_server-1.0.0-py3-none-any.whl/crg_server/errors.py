"""Typed failures at the process boundary, and the status codes they carry.

Normative basis: 6.6 (fail closed), 10.1 (external systems interact through
typed requests and responses), 38.3 (principal endpoints), 44.2 (identity
and authorization).

Specification 6.6 says a blocked, unresolved, or unauthorized outcome must
never be presented as a success.  Over HTTP that is a statement about status
codes, so this module fixes the mapping once and every handler raises rather
than returns:

======================  ======  ===================================
Condition               Status  Meaning
======================  ======  ===================================
malformed request       400     the caller asked for something ill-formed
no identity             401     the request carried no actor
identity insufficient   403     the actor holds no role for this operation
absent object           404     nothing of that identity exists here
wrong method            405     the route exists, the verb does not
conflict or staleness   409     optimistic-lock failure, key reuse, legal hold
redacted content        410     the content is gone and a tombstone remains
non-JSON payload        415     the integration surface is JSON only
scope mismatch          422     the request is well-formed and inadmissible
blocked outcome         422     a refusal, returned as a refusal
======================  ======  ===================================

There is deliberately no code in this table that lets a caller receive
``200`` together with a decision that did not carry.  ``BlockedOutcome``
exists precisely so that the one interesting failure -- a certification that
refused -- has a way out of a handler that is not a success body.
"""
from __future__ import annotations

from typing import Any, Dict, Optional

__all__ = [
    "ServerError",
    "UsageError",
    "UnauthorizedError",
    "ForbiddenError",
    "NotFoundError",
    "MethodNotAllowedError",
    "ConflictError",
    "IntegrityError",
    "PayloadTooLargeError",
    "RedactedError",
    "UnsupportedMediaTypeError",
    "ScopeMismatchError",
    "ServiceUnavailableError",
    "BlockedOutcome",
    "error_body",
    "from_security_error",
]


class ServerError(Exception):
    """Base of every failure the integration surface reports as data.

    ``status`` is the HTTP status the boundary emits, ``category`` is the
    stable machine token a client branches on, and ``remedy`` says what the
    caller can do about it.  A failure without a remedy is a failure the
    integrator will retry blindly (6.6).
    """

    status: int = 500
    category: str = "INTERNAL"

    def __init__(
        self,
        message: str,
        *,
        remedy: str = "",
        detail: Optional[Dict[str, Any]] = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.remedy = remedy
        self.detail: Dict[str, Any] = dict(detail or {})

    def to_canonical(self) -> Dict[str, Any]:
        record: Dict[str, Any] = {
            "category": self.category,
            "status": self.status,
            "message": self.message,
        }
        if self.remedy:
            record["remedy"] = self.remedy
        if self.detail:
            record["detail"] = self.detail
        return record


class UsageError(ServerError):
    """The request is ill-formed: 400 (spec 38.3)."""

    status = 400
    category = "USAGE"


class UnauthorizedError(ServerError):
    """No identity was presented: 401 (spec 44.2)."""

    status = 401
    category = "UNAUTHENTICATED"


class ForbiddenError(ServerError):
    """The actor holds no role for this operation: 403 (spec 44.2, 44.3)."""

    status = 403
    category = "FORBIDDEN"


class NotFoundError(ServerError):
    """No object of that identity exists here: 404."""

    status = 404
    category = "NOT_FOUND"


class MethodNotAllowedError(ServerError):
    """The route exists and this verb does not: 405."""

    status = 405
    category = "METHOD_NOT_ALLOWED"


class ConflictError(ServerError):
    """Optimistic-lock failure, key reuse, or legal hold: 409.

    Specification 16.1 requires concurrent updates to use optimistic locking
    against an expected parent version; a mismatch is a conflict and not a
    silent last-writer-wins.  17.5 makes an attempt to delete an object under
    legal hold the same kind of refusal.
    """

    status = 409
    category = "CONFLICT"


class PayloadTooLargeError(ServerError):
    """The request exceeds the deployment's declared resource boundary: 413."""

    status = 413
    category = "PAYLOAD_TOO_LARGE"


class IntegrityError(ServerError):
    """Stored bytes no longer match their content address: 500.

    This is an internal trust failure, never a caller conflict.  Returning the
    decoded bytes would let corruption silently influence a certificate;
    returning 404 would hide that a protected object was lost.
    """

    status = 500
    category = "INTEGRITY_FAILURE"


class RedactedError(ServerError):
    """The content was removed and a tombstone remains: 410 (spec 17.2).

    The identity, hash, and dependency structure survive, so the response
    carries the tombstone.  Returning 404 here would erase the distinction
    between ``never existed`` and ``existed and was removed under authority``,
    which 17.1 keeps as two states.
    """

    status = 410
    category = "REDACTED"


class UnsupportedMediaTypeError(ServerError):
    """The integration surface is JSON only: 415 (spec 38.2)."""

    status = 415
    category = "UNSUPPORTED_MEDIA_TYPE"


class ScopeMismatchError(ServerError):
    """Well-formed and inadmissible: 422 (spec 21.5, 26.6, 29.2).

    A decision scope that does not match the compiled derivation, a claim
    whose completeness basis cannot support it, or an operation outside the
    declared decision scope of a branch.
    """

    status = 422
    category = "SCOPE_MISMATCH"


class ServiceUnavailableError(ServerError):
    """A required configured dependency is absent or not trustworthy: 503."""

    status = 503
    category = "DEPENDENCY_UNAVAILABLE"


class BlockedOutcome(ServerError):
    """A refusal, returned as a refusal: 422 (spec 6.6, 29.5).

    ``BLOCKED_SCOPE_MISMATCH``, ``BLOCKED_INCOMPLETE_EVIDENCE``,
    ``BLOCKED_GEOMETRY_LOSS``, ``ALL_INFEASIBLE``, and the ambiguous outcomes
    are results the engine genuinely produced, so they are carried in the
    body -- but never behind a ``200``.  A client that only checks the status
    line must not be able to read a blocked decision as a certified one.
    """

    status = 422
    category = "BLOCKED"

    def __init__(
        self,
        message: str,
        *,
        outcome: str,
        remedy: str = "",
        detail: Optional[Dict[str, Any]] = None,
    ) -> None:
        super().__init__(message, remedy=remedy, detail=detail)
        self.outcome = outcome
        self.detail.setdefault("outcome", outcome)
        self.detail.setdefault("affirmative", False)


def error_body(error: ServerError) -> Dict[str, Any]:
    """The canonical error envelope every non-2xx response carries."""
    return {"error": error.to_canonical()}


def from_security_error(error: Exception) -> ServerError:
    """Adapt a security gate's refusal to a boundary error (44.2, 38.2).

    ``crg-server`` deliberately does not import ``crg-security``: the optional
    security gate is duck-typed, so a deployment may plug in its own, and the
    server's standard-library-only dependency set (9.2) stays intact for the
    deployments that plug in nothing.  The cost of that choice is that a gate's
    exceptions are not instances of :class:`ServerError`, and this function is
    where that is paid -- once, by reading the ``status`` and ``category`` the
    refusal already carries.

    An exception carrying no ``status`` becomes a 500 rather than a 403.  That
    is deliberate: an unexpected failure inside an authorization path is a
    *fault*, not a decision, and reporting it as a clean denial would hide a
    broken gate behind a plausible-looking refusal.
    """
    if isinstance(error, ServerError):
        return error
    status = getattr(error, "status", None)
    message = str(getattr(error, "message", None) or error)
    remedy = str(getattr(error, "remedy", "") or "")
    detail = dict(getattr(error, "detail", None) or {})
    category = str(getattr(error, "category", "") or "")
    if not isinstance(status, int):
        return ServerError(
            f"the configured security gate raised {type(error).__name__}: {message}",
            remedy="this is a fault in the gate, not an authorization decision; a broken "
                   "gate must not be reported as a clean refusal (6.6)",
            detail={"gate_exception": type(error).__name__},
        )
    mapping = {
        400: UsageError,
        401: UnauthorizedError,
        403: ForbiddenError,
        404: NotFoundError,
        409: ConflictError,
        410: RedactedError,
        415: UnsupportedMediaTypeError,
        422: ScopeMismatchError,
        503: ServiceUnavailableError,
    }
    cls = mapping.get(int(status), ServerError)
    adapted = cls(message, remedy=remedy, detail=detail)
    if category:
        adapted.detail.setdefault("security_category", category)
    return adapted
