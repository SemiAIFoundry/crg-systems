"""Persistence: relational metadata, a content-addressed object store, an
append-only audit log, a typed dependency index, and tombstones.

Normative basis: 42.1 (storage model), 42.2 (local profile), 6.2 (portable
state), 6.4 (immutable provenance), 10.1 (external systems shall not directly
mutate canonical CRG objects), 12 (common object envelope), 14.3--14.4
(canonicalization and hashing), 16.1 (optimistic locking), 17 (deletion,
retention, redaction, tombstones), 18 (typed dependency graph), 44.7 (audit).

The local profile of 42.2 is SQLite metadata plus filesystem content, and
that is exactly what this is: ``sqlite3`` for identity, status, policy, and
indexed queries; a directory of canonical JSON named by content hash for the
objects themselves; a JSONL file opened in append mode for audit.

The whole point of the class is one negative property.  **There is no
mutate-in-place path.**  :meth:`CaseStore.put_object` is the only writer of
canonical content and it is addressed by the hash of what it writes, so
"changing" an object is not expressible: a change produces a *successor*
object with the predecessor in ``parent_hashes`` (:meth:`put_successor`).
That is 10.1 made structural rather than documented -- an integration client
holding a store handle still cannot edit a certificate, because the operation
does not exist.

Two things do change, and both are metadata rather than canonical content,
which 42.1 explicitly separates:

* **status** -- an object may become ``SUPERSEDED``, ``STALE``, or
  ``UNVERIFIABLE_REDACTED`` without its bytes changing (12, 17.1); and
* **presence** -- :meth:`redact` removes bytes and leaves the identity, hash,
  type, and dependency edges standing as a ``TombstoneRecord`` (17.2).

:mod:`crg_cli.store` already owns the canonical shape of a case on disk and
the tabular import profile.  This module builds on it rather than restating
it: ``new_case``, ``load_bundle``, ``load_scope``, ``load_derivation``,
``record_history``, and ``import_table`` are re-exported and used unchanged,
so a case written by the CLI is a case this server can serve and vice versa.
"""
from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import tempfile
import threading
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from crg_model.canonical import canonical_json, content_hash
from crg_model.case import refresh_case_metadata
from crg_model.edges import EDGE_SEMANTICS, DependencyEdge, DependencyGraph, EdgeType
from crg_model.envelope import ObjectStatus, utc_now

# crg-cli owns the on-disk case shape and the tabular import profile; the
# server persists the same documents rather than inventing a second dialect.
from crg_cli.store import (  # noqa: F401  (re-exported on purpose)
    CaseError,
    import_table,
    load_bundle,
    load_derivation,
    load_scope,
    new_case,
    record_history,
)

from .errors import ConflictError, IntegrityError, NotFoundError, RedactedError, UsageError

__all__ = [
    "CaseStore",
    "Tombstone",
    "CERTIFICATE_STATUSES",
    "SCHEMA_SQL",
    "CaseError",
    "load_bundle",
    "load_scope",
    "load_derivation",
    "new_case",
    "record_history",
    "import_table",
]

#: Statuses a stored certificate may hold in the metadata store.  These are
#: 17.1 states, not verification verdicts: the verifier decides whether a
#: certificate is *correct*, this decides whether it is still *checkable*.
CERTIFICATE_STATUSES = (
    ObjectStatus.ACTIVE,
    ObjectStatus.SUPERSEDED,
    ObjectStatus.STALE,
    ObjectStatus.REVOKED,
    ObjectStatus.UNVERIFIABLE_REDACTED,
)

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS objects (
    content_hash   TEXT PRIMARY KEY,
    object_type    TEXT NOT NULL,
    path           TEXT NOT NULL,
    byte_length    INTEGER NOT NULL,
    created_at     TEXT NOT NULL,
    created_by     TEXT NOT NULL,
    present        INTEGER NOT NULL DEFAULT 1,
    legal_hold     INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS object_status (
    content_hash   TEXT PRIMARY KEY,
    status         TEXT NOT NULL,
    reason         TEXT NOT NULL DEFAULT '',
    changed_at     TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS cases (
    case_id        TEXT NOT NULL,
    case_version   INTEGER NOT NULL,
    content_hash   TEXT NOT NULL,
    branch_id      TEXT,
    derived_from   TEXT,
    parent_version INTEGER,
    status         TEXT NOT NULL,
    created_at     TEXT NOT NULL,
    created_by     TEXT NOT NULL,
    PRIMARY KEY (case_id, case_version)
);
CREATE TABLE IF NOT EXISTS edges (
    edge_id        TEXT PRIMARY KEY,
    case_id        TEXT,
    source         TEXT NOT NULL,
    target         TEXT NOT NULL,
    edge_type      TEXT NOT NULL,
    scope          TEXT NOT NULL DEFAULT '',
    minimum_action TEXT NOT NULL DEFAULT '',
    recorded_at    TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS certificates (
    case_id        TEXT NOT NULL,
    certificate_id TEXT NOT NULL,
    content_hash   TEXT NOT NULL,
    job_id         TEXT NOT NULL,
    outcome        TEXT NOT NULL,
    affirmative    INTEGER NOT NULL,
    registered_at  TEXT NOT NULL,
    PRIMARY KEY (case_id, certificate_id)
);
CREATE TABLE IF NOT EXISTS tombstones (
    content_hash        TEXT PRIMARY KEY,
    object_id           TEXT NOT NULL,
    object_type         TEXT NOT NULL,
    reason              TEXT NOT NULL,
    authority           TEXT NOT NULL,
    removed_at          TEXT NOT NULL,
    legal_hold          INTEGER NOT NULL DEFAULT 0,
    permitted_disclosure TEXT NOT NULL DEFAULT '',
    edges_json          TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS audit (
    seq            INTEGER PRIMARY KEY AUTOINCREMENT,
    recorded_at    TEXT NOT NULL,
    event_json     TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS idempotency (
    key            TEXT PRIMARY KEY,
    request_hash   TEXT NOT NULL,
    response_json  TEXT NOT NULL,
    status         INTEGER NOT NULL,
    created_at     TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS canonical_results (
    request_hash   TEXT PRIMARY KEY,
    response_json  TEXT NOT NULL,
    status         INTEGER NOT NULL,
    created_at     TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS jobs (
    job_id         TEXT PRIMARY KEY,
    record_json    TEXT NOT NULL,
    updated_at     TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS schema_migrations (
    version        INTEGER PRIMARY KEY,
    name           TEXT NOT NULL,
    applied_at     TEXT NOT NULL
);
"""

DB_SCHEMA_VERSION = 3
DATABASE_MIGRATIONS: Tuple[Tuple[int, str, str], ...] = (
    (2, "durable-job-payloads", """
        CREATE TABLE IF NOT EXISTS job_payloads (
            job_id         TEXT PRIMARY KEY,
            payload_json   TEXT NOT NULL,
            created_at     TEXT NOT NULL,
            FOREIGN KEY(job_id) REFERENCES jobs(job_id)
        );
    """),
    (3, "encrypted-object-storage-metadata", """
        ALTER TABLE objects ADD COLUMN storage_encoding TEXT NOT NULL DEFAULT 'canonical-json';
        ALTER TABLE objects ADD COLUMN stored_byte_length INTEGER;
        ALTER TABLE objects ADD COLUMN stored_content_hash TEXT;
    """),
)


class _Result:
    """Rows already materialized under the lock.

    Call sites write ``execute(...).fetchone()``; if the cursor were returned
    and the fetch happened after the lock was released, a second request
    thread could interleave a write between the two.  So the rows are read
    while the lock is still held and this object is what the caller sees.
    """

    __slots__ = ("_rows", "rowcount", "lastrowid")

    def __init__(self, rows: List[Any], rowcount: int, lastrowid: Any) -> None:
        self._rows = rows
        self.rowcount = rowcount
        self.lastrowid = lastrowid

    def fetchone(self) -> Any:
        return self._rows[0] if self._rows else None

    def fetchall(self) -> List[Any]:
        return list(self._rows)

    def __iter__(self):
        return iter(self._rows)


class _SerializedConnection:
    """A ``sqlite3`` connection serialized by a re-entrant lock.

    Specification 42.2 asks the standalone profile for SQLite metadata and a
    local worker with no external services; 47.4 still expects the surface to
    be available while that worker runs.  A threading HTTP server therefore
    touches this connection from several threads, and SQLite objects belong to
    the thread that made them.  Serializing every statement is the honest
    resolution for the local profile: correct, and slow in exactly the way a
    single-node deployment can afford.  42.3's enterprise profile answers the
    same question with PostgreSQL and a connection pool.
    """

    def __init__(self, connection: sqlite3.Connection) -> None:
        self._connection = connection
        self._lock = threading.RLock()

    def execute(self, sql: str, parameters: Sequence[Any] = ()) -> _Result:
        with self._lock:
            cursor = self._connection.execute(sql, parameters)
            rows = cursor.fetchall() if cursor.description is not None else []
            return _Result(rows, cursor.rowcount, cursor.lastrowid)

    def executescript(self, script: str) -> None:
        with self._lock:
            self._connection.executescript(script)

    def commit(self) -> None:
        with self._lock:
            self._connection.commit()

    def rollback(self) -> None:
        with self._lock:
            self._connection.rollback()

    @contextmanager
    def transaction(self, *, immediate: bool = False):
        """Hold the connection lock across one real SQLite transaction."""
        with self._lock:
            self._connection.execute("BEGIN IMMEDIATE" if immediate else "BEGIN")
            try:
                yield
            except BaseException:
                self._connection.rollback()
                raise
            else:
                self._connection.commit()

    def close(self) -> None:
        with self._lock:
            self._connection.close()


@dataclass(frozen=True)
class Tombstone:
    """A ``TombstoneRecord`` (spec 17.2).

    Every field 17.2 permits a tombstone to preserve is preserved, because the
    reason the record exists at all is that a dependent claim must remain
    *explicable* after its support is gone.  A tombstone that dropped the
    dependency edges would leave a certificate referring to a hash with no way
    to say what that hash used to be to it.
    """

    object_id: str
    content_hash: str
    object_type: str
    reason: str
    authority: str
    removed_at: str
    dependency_edges: Tuple[Dict[str, Any], ...] = ()
    legal_hold: bool = False
    permitted_disclosure: str = "identity, hash, type, and dependency structure only"
    affected_certificates: Tuple[str, ...] = ()

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "record_type": "TombstoneRecord",
            "object_id": self.object_id,
            "content_hash": self.content_hash,
            "object_type": self.object_type,
            "removal_reason": self.reason,
            "removal_authority": self.authority,
            "removal_time": self.removed_at,
            "legal_hold": self.legal_hold,
            "permitted_disclosure": self.permitted_disclosure,
            "dependency_edges": [dict(e) for e in self.dependency_edges],
            "affected_certificates": list(self.affected_certificates),
        }


def _object_type_of(payload: Any) -> str:
    if isinstance(payload, Mapping):
        for key in ("object_type", "record_type"):
            value = payload.get(key)
            if value:
                return str(value)
        if "certificate_id" in payload and "outcome" in payload:
            return "DecisionCertificate"
        if "bundle_id" in payload and "realizations" in payload:
            return "RealizationBundle"
        if "case_id" in payload and "status" in payload:
            return "CRGCase"
        if "delta_id" in payload:
            return "DeltaCertificate"
    return "OpaqueRecord"


def _fsync_directory(path: str) -> None:
    """Persist a rename/unlink in ``path`` where the platform supports it."""
    flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0)
    descriptor = os.open(path, flags)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


class CaseStore:
    """SQLite metadata plus a content-addressed filesystem object store.

    ``root`` holds ``metadata.sqlite3``, ``objects/sha256/...``, and
    ``audit.jsonl``.  The three together are the complete state: 6.2 requires
    a deployment to be exportable and re-importable without a running service,
    and a store whose truth lived in process memory would not be.
    """

    def __init__(
        self,
        root: str,
        *,
        object_codec: Optional[Any] = None,
        require_encryption: bool = False,
    ) -> None:
        self.root = os.path.abspath(root)
        self.objects_dir = os.path.join(self.root, "objects", "sha256")
        self.audit_path = os.path.join(self.root, "audit.jsonl")
        self.database_path = os.path.join(self.root, "metadata.sqlite3")
        self._object_codec = object_codec
        self.require_encryption = bool(require_encryption)
        if self.require_encryption and self._object_codec is None:
            raise CaseError(
                "encrypted local storage was required but no object codec was configured"
            )
        if self._object_codec is not None:
            for method in ("encode", "decode"):
                if not callable(getattr(self._object_codec, method, None)):
                    raise CaseError(f"object codec does not implement {method}()")
            if not str(getattr(self._object_codec, "storage_encoding", "")).strip():
                raise CaseError("object codec does not declare a storage_encoding")
        os.makedirs(self.objects_dir, exist_ok=True)
        raw = sqlite3.connect(self.database_path, check_same_thread=False)
        raw.row_factory = sqlite3.Row
        self._connection = _SerializedConnection(raw)
        self._connection.executescript(SCHEMA_SQL)
        self._apply_database_migrations()
        self._connection.commit()
        #: The same re-entrant lock the connection serializes on, so a
        #: multi-statement section (read the head version, then insert the
        #: successor) is atomic against another request thread rather than
        #: merely being individually serialized (16.1).
        self._write_lock = self._connection._lock
        #: Counts every write of new object bytes.  A test asserting that an
        #: idempotent replay did not recompute reads this rather than timing.
        self.object_writes = 0
        self._upgrade_legacy_protected_value_bindings()

    def _apply_database_migrations(self) -> None:
        row = self._connection.execute(
            "SELECT MAX(version) AS version FROM schema_migrations"
        ).fetchone()
        current = int(row["version"] or 0) if row else 0
        if current == 0:
            self._connection.execute(
                "INSERT INTO schema_migrations (version, name, applied_at) VALUES (?,?,?)",
                (1, "baseline-local-store", utc_now()),
            )
            current = 1
        for version, name, sql in DATABASE_MIGRATIONS:
            if version <= current:
                continue
            self._connection.executescript(sql)
            self._connection.execute(
                "INSERT INTO schema_migrations (version, name, applied_at) VALUES (?,?,?)",
                (version, name, utc_now()),
            )
            current = version
        if current != DB_SCHEMA_VERSION:
            raise CaseError(
                f"database schema is at {current}; runtime expects {DB_SCHEMA_VERSION}"
            )

    def database_schema_version(self) -> int:
        row = self._connection.execute(
            "SELECT MAX(version) AS version FROM schema_migrations"
        ).fetchone()
        return int(row["version"] or 0) if row else 0

    def scan_integrity(self) -> Dict[str, Any]:
        """Authenticate every protected value and report missing/orphaned bytes."""
        rows = self._connection.execute(
            "SELECT content_hash, path FROM objects ORDER BY content_hash"
        ).fetchall()
        failures: List[Dict[str, str]] = []
        declared_paths = set()
        for row in rows:
            digest = str(row["content_hash"])
            declared_paths.add(os.path.abspath(os.path.join(self.root, str(row["path"]))))
            try:
                self.get_object(digest)
            except Exception as error:  # noqa: BLE001 - the report preserves every failure
                failures.append({
                    "content_hash": digest,
                    "error": f"{type(error).__name__}: {error}",
                })
        protected_checked = 0
        protected_specs = (
            ("audit", "seq", "event_json", "StoreAuditEvent"),
            ("idempotency", "key", "response_json", "IdempotentResponse"),
            ("canonical_results", "request_hash", "response_json", "CanonicalResponse"),
            ("jobs", "job_id", "record_json", "PersistedJobRecord"),
            ("job_payloads", "job_id", "payload_json", "PersistedJobPayload"),
        )
        for table, key_column, value_column, record_type in protected_specs:
            protected_rows = self._connection.execute(
                f"SELECT {key_column}, {value_column} FROM {table}"
            ).fetchall()
            for protected_row in protected_rows:
                context_id = str(protected_row[key_column])
                protected_checked += 1
                try:
                    self._decode_protected_json(
                        str(protected_row[value_column]),
                        record_type=record_type,
                        context_id=context_id,
                    )
                except Exception as error:  # noqa: BLE001 - preserve every failure
                    failures.append({
                        "content_hash": f"sqlite:{table}:{context_id}",
                        "error": f"{type(error).__name__}: {error}",
                    })
        audit_rows = self._connection.execute(
            "SELECT event_json FROM audit ORDER BY seq ASC"
        ).fetchall()
        expected_audit = [str(row["event_json"]) for row in audit_rows]
        try:
            with open(self.audit_path, "r", encoding="utf-8") as handle:
                physical_audit = [line.rstrip("\n") for line in handle]
        except FileNotFoundError:
            physical_audit = []
        if physical_audit != expected_audit:
            failures.append({
                "content_hash": "audit.jsonl",
                "error": "physical audit mirror does not match the ordered database audit",
            })
        present_paths = {
            os.path.abspath(os.path.join(directory, filename))
            for directory, _subdirectories, filenames in os.walk(self.objects_dir)
            for filename in filenames
            if not filename.startswith(".")
        }
        orphans = sorted(os.path.relpath(path, self.root)
                         for path in present_paths - declared_paths)
        return {
            "ok": not failures and not orphans,
            "objects_checked": len(rows),
            "protected_values_checked": protected_checked,
            "failures": failures,
            "orphaned_paths": orphans,
            "database_schema_version": self.database_schema_version(),
            "checked_at": utc_now(),
        }

    # -- lifecycle ---------------------------------------------------------
    def connection(self) -> sqlite3.Connection:
        return self._connection

    def close(self) -> None:
        self._connection.close()

    def __enter__(self) -> "CaseStore":
        return self

    def __exit__(self, *_exc: Any) -> None:
        self.close()

    # -- content-addressed objects (42.1) ----------------------------------
    def _path_for(self, digest: str) -> str:
        hexdigest = digest.split(":", 1)[1]
        return os.path.join(self.objects_dir, hexdigest[:2], f"{hexdigest}.json")

    def put_object(
        self,
        obj: Any,
        *,
        object_type: Optional[str] = None,
        created_by: str = "crg-server",
        dependencies: Sequence[Any] = (),
        case_id: Optional[str] = None,
        legal_hold: bool = False,
    ) -> str:
        """Store ``obj`` and return its content hash (spec 14.4, 42.1).

        Immutable and deduplicating: the address *is* the hash of the
        canonical content, so storing identical content twice writes bytes
        once and returns the same address.  Storing different content under an
        existing address is not expressible.

        A previously redacted hash is not resurrected by re-submission: 17.2
        makes removal an authorized act, and letting any caller undo it by
        posting the bytes again would make the tombstone advisory.
        """
        if hasattr(obj, "to_canonical"):
            obj = obj.to_canonical()
        digest = content_hash(obj)
        with self._write_lock:
            return self._put_object_locked(
                obj, digest, object_type, created_by, dependencies, case_id, legal_hold
            )

    def _put_object_locked(
        self,
        obj: Any,
        digest: str,
        object_type: Optional[str],
        created_by: str,
        dependencies: Sequence[Any],
        case_id: Optional[str],
        legal_hold: bool,
    ) -> str:
        if self.is_redacted(digest):
            raise RedactedError(
                f"object {digest} was redacted under authority and cannot be re-stored",
                remedy="17.2: removal is an authorized act; reinstatement requires the same",
                detail={"tombstone": self.tombstone(digest).to_canonical()},
            )
        row = self._connection.execute(
            "SELECT content_hash FROM objects WHERE content_hash = ?", (digest,)
        ).fetchone()
        if row is None:
            path = self._path_for(digest)
            os.makedirs(os.path.dirname(path), exist_ok=True)
            plaintext = canonical_json(obj).encode("utf-8")
            resolved_type = object_type or _object_type_of(obj)
            if self._object_codec is None:
                storage_encoding = "canonical-json"
                payload = plaintext
            else:
                envelope = self._object_codec.encode(
                    obj,
                    object_id=digest,
                    object_type=resolved_type,
                    created_by=created_by,
                    case_id=case_id,
                    dependency_edges=tuple(
                        edge.to_canonical() if hasattr(edge, "to_canonical") else dict(edge)
                        for edge in dependencies
                    ),
                    legal_hold=legal_hold,
                )
                payload = canonical_json(envelope).encode("utf-8")
                storage_encoding = str(self._object_codec.storage_encoding)
            stored_digest = "sha256:" + hashlib.sha256(payload).hexdigest()
            descriptor, temporary = tempfile.mkstemp(
                prefix=".crg-object-", suffix=".tmp", dir=os.path.dirname(path)
            )
            installed = False
            try:
                with os.fdopen(descriptor, "wb") as handle:
                    handle.write(payload)
                    handle.flush()
                    os.fsync(handle.fileno())
                self._connection.execute("BEGIN IMMEDIATE")
                self._connection.execute(
                    "INSERT INTO objects (content_hash, object_type, path, byte_length, "
                    "created_at, created_by, present, legal_hold, storage_encoding, "
                    "stored_byte_length, stored_content_hash) "
                    "VALUES (?,?,?,?,?,?,1,?,?,?,?)",
                    (
                        digest,
                        resolved_type,
                        os.path.relpath(path, self.root),
                        len(plaintext),
                        utc_now(),
                        created_by,
                        1 if legal_hold else 0,
                        storage_encoding,
                        len(payload),
                        stored_digest,
                    ),
                )
                self._connection.execute(
                    "INSERT OR REPLACE INTO object_status "
                    "(content_hash, status, reason, changed_at) VALUES (?,?,?,?)",
                    (digest, ObjectStatus.ACTIVE, "", utc_now()),
                )
                os.replace(temporary, path)
                installed = True
                _fsync_directory(os.path.dirname(path))
                self._connection.commit()
                self.object_writes += 1
            except Exception:
                self._connection.rollback()
                if installed and os.path.exists(path):
                    os.unlink(path)
                    _fsync_directory(os.path.dirname(path))
                elif os.path.exists(temporary):
                    os.unlink(temporary)
                raise
        if dependencies:
            self.record_edges(dependencies, case_id=case_id)
        return digest

    def put_successor(
        self,
        predecessor_hash: Optional[str],
        obj: Mapping[str, Any],
        **kwargs: Any,
    ) -> str:
        """Store a *successor* of ``predecessor_hash`` (spec 10.1, 12, 15.3).

        This is the only shape a change may take.  ``parent_hashes`` records
        the predecessor, so the lineage is in the content and survives export;
        the predecessor itself is untouched, which is what 15.3 means by
        "migration MUST NOT silently rewrite historical objects".
        """
        record = dict(obj)
        parents = list(record.get("parent_hashes") or ())
        if predecessor_hash and predecessor_hash not in parents:
            parents.append(predecessor_hash)
        if parents:
            record["parent_hashes"] = parents
        return self.put_object(record, **kwargs)

    def has_object(self, digest: str) -> bool:
        row = self._connection.execute(
            "SELECT present FROM objects WHERE content_hash = ?", (digest,)
        ).fetchone()
        return row is not None and bool(row["present"])

    def get_object(self, digest: str) -> Any:
        """Read canonical content by hash.

        A redacted hash raises :class:`~crg_server.errors.RedactedError`
        carrying the tombstone, never :class:`NotFoundError`: 17.1 keeps
        "absent" and "removed under authority" as two states and this is the
        boundary at which they would otherwise collapse.
        """
        row = self._connection.execute(
            "SELECT path, present, byte_length, object_type, storage_encoding, "
            "stored_byte_length, stored_content_hash FROM objects WHERE content_hash = ?",
            (digest,)
        ).fetchone()
        if row is None:
            raise NotFoundError(
                f"no object {digest} in this store",
                remedy="store it first; objects are addressed by the hash of their content",
            )
        if not row["present"]:
            raise RedactedError(
                f"object {digest} has been redacted (17.2)",
                remedy="the tombstone preserves identity, hash, type, and dependency edges",
                detail={"tombstone": self.tombstone(digest).to_canonical()},
            )
        path = os.path.join(self.root, row["path"])
        try:
            with open(path, "rb") as handle:
                payload = handle.read()
        except OSError as error:
            self._mark_integrity_failure(digest, f"stored object cannot be read: {error}")
            raise IntegrityError(
                f"stored object {digest} cannot be read",
                remedy="run the store integrity scanner and restore the object from a verified bundle",
                detail={"path": row["path"], "error": str(error)},
            ) from error
        stored_actual = "sha256:" + hashlib.sha256(payload).hexdigest()
        storage_encoding = str(row["storage_encoding"] or "canonical-json")
        stored_length = (
            int(row["stored_byte_length"])
            if row["stored_byte_length"] is not None else int(row["byte_length"])
        )
        stored_expected = str(row["stored_content_hash"] or digest)
        failures = []
        if len(payload) != stored_length:
            failures.append(
                f"stored byte length is {len(payload)}, metadata declares {stored_length}"
            )
        if stored_actual != stored_expected:
            failures.append(f"stored bytes hash to {stored_actual}, metadata declares {stored_expected}")
        try:
            stored_object = json.loads(payload.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            failures.append(f"stored content is not JSON: {error}")
            stored_object = None
        if stored_object is not None:
            try:
                canonical_stored = canonical_json(stored_object).encode("utf-8")
            except (TypeError, ValueError) as error:
                failures.append(f"stored content has no canonical encoding: {error}")
            else:
                if canonical_stored != payload:
                    failures.append("stored bytes are not the canonical JSON encoding")
        obj = None
        if stored_object is not None and not failures:
            if storage_encoding == "canonical-json":
                if self.require_encryption:
                    failures.append("plaintext object found in an encryption-required store")
                obj = stored_object
            else:
                if self._object_codec is None:
                    failures.append(
                        f"object uses {storage_encoding!r} but no decryption codec is configured"
                    )
                elif storage_encoding != str(self._object_codec.storage_encoding):
                    failures.append(
                        f"object uses {storage_encoding!r}, configured codec declares "
                        f"{self._object_codec.storage_encoding!r}"
                    )
                else:
                    try:
                        obj = self._object_codec.decode(
                            stored_object,
                            expected_object_id=digest,
                            expected_object_type=str(row["object_type"]),
                        )
                    except Exception as error:  # codec failures are integrity failures
                        failures.append(f"encrypted object cannot be authenticated/decrypted: {error}")
        if obj is not None:
            plaintext = canonical_json(obj).encode("utf-8")
            actual = "sha256:" + hashlib.sha256(plaintext).hexdigest()
            if len(plaintext) != int(row["byte_length"]):
                failures.append(
                    f"plaintext byte length is {len(plaintext)}, metadata declares {row['byte_length']}"
                )
            if actual != digest:
                failures.append(f"plaintext bytes hash to {actual}")
        if failures:
            detail = "; ".join(failures)
            self._mark_integrity_failure(digest, detail)
            raise IntegrityError(
                f"stored object {digest} failed content-addressed integrity verification",
                remedy="quarantine this store and restore the object from a verified bundle",
                detail={"path": row["path"], "failures": failures},
            )
        return obj

    def _mark_integrity_failure(self, digest: str, reason: str) -> None:
        self._connection.execute(
            "INSERT OR REPLACE INTO object_status (content_hash, status, reason, changed_at) "
            "VALUES (?,?,?,?)",
            (digest, "INTEGRITY_FAILED", reason, utc_now()),
        )
        self._connection.commit()

    def object_metadata(self, digest: str) -> Dict[str, Any]:
        row = self._connection.execute(
            "SELECT * FROM objects WHERE content_hash = ?", (digest,)
        ).fetchone()
        if row is None:
            raise NotFoundError(f"no object {digest} in this store")
        record = dict(row)
        record["status"] = self.object_status(digest)
        record["present"] = bool(record["present"])
        record["legal_hold"] = bool(record["legal_hold"])
        return record

    def object_status(self, digest: str) -> str:
        row = self._connection.execute(
            "SELECT status FROM object_status WHERE content_hash = ?", (digest,)
        ).fetchone()
        return str(row["status"]) if row else ObjectStatus.ACTIVE

    @staticmethod
    def _bound_record_type(record_type: str, context_id: Optional[str]) -> str:
        """Return a non-secret AEAD type binding for one relational row.

        The lookup key itself can contain user material, so only its digest is
        placed in the authenticated envelope metadata. Binding the envelope
        to that digest prevents a valid ciphertext from being transplanted to
        another row of the same record class.
        """
        if context_id is None:
            return record_type
        context_digest = hashlib.sha256(str(context_id).encode("utf-8")).hexdigest()
        return f"{record_type}@sha256:{context_digest}"

    def _encode_protected_json(
        self,
        value: Any,
        *,
        record_type: str,
        context_id: Optional[str] = None,
    ) -> str:
        """Encode a sensitive SQLite/JSONL value under the store envelope.

        Object blobs are not the only protected data at rest: job inputs,
        cached responses, and audit detail can contain evidence or claims.
        They use the same authenticated envelope and customer key, while
        retaining their existing relational lookup keys.
        """
        if self._object_codec is None:
            if self.require_encryption:
                raise IntegrityError("protected database value cannot be written unencrypted")
            return canonical_json(value)
        logical_id = content_hash(value)
        bound_type = self._bound_record_type(record_type, context_id)
        envelope = self._object_codec.encode(
            value,
            object_id=logical_id,
            object_type=bound_type,
            created_by="crg-server",
            case_id=None,
            dependency_edges=(),
            legal_hold=False,
        )
        return canonical_json(envelope)

    def _decode_protected_json(
        self,
        encoded: str,
        *,
        record_type: str,
        context_id: Optional[str] = None,
    ) -> Any:
        try:
            value = json.loads(str(encoded))
        except json.JSONDecodeError as error:
            raise IntegrityError(f"protected {record_type} value is not JSON: {error}") from error
        encrypted = isinstance(value, Mapping) and value.get("record_type") == "EncryptedObject"
        if not encrypted:
            if self.require_encryption:
                raise IntegrityError(
                    f"plaintext {record_type} value found in an encryption-required store"
                )
            return value
        if self._object_codec is None:
            raise IntegrityError(
                f"encrypted {record_type} value cannot be read without a decryption codec"
            )
        expected = str(value.get("content_hash") or "")
        bound_type = self._bound_record_type(record_type, context_id)
        try:
            return self._object_codec.decode(
                value,
                expected_object_id=expected,
                expected_object_type=bound_type,
            )
        except Exception as error:
            raise IntegrityError(
                f"encrypted {record_type} value failed authentication/decryption: {error}"
            ) from error

    def _upgrade_legacy_protected_value_bindings(self) -> None:
        """Bind pre-context encrypted relational values to their row keys.

        The upgrade is restart-safe: each row is replaced atomically, and a
        mixed old/new database is completed on the next open. Plaintext local
        profile rows are intentionally untouched; encryption-required startup
        rejects them through its integrity scan rather than laundering them.
        """
        if self._object_codec is None:
            return
        specifications = (
            ("audit", "seq", "event_json", "StoreAuditEvent"),
            ("idempotency", "key", "response_json", "IdempotentResponse"),
            ("canonical_results", "request_hash", "response_json", "CanonicalResponse"),
            ("jobs", "job_id", "record_json", "PersistedJobRecord"),
            ("job_payloads", "job_id", "payload_json", "PersistedJobPayload"),
        )
        audit_changed = False
        for table, key_column, value_column, record_type in specifications:
            rows = self._connection.execute(
                f"SELECT {key_column}, {value_column} FROM {table}"
            ).fetchall()
            for row in rows:
                context_id = str(row[key_column])
                encoded = str(row[value_column])
                try:
                    envelope = json.loads(encoded)
                except json.JSONDecodeError:
                    continue
                if not isinstance(envelope, Mapping) or envelope.get("record_type") != "EncryptedObject":
                    continue
                if str(envelope.get("object_type") or "") != record_type:
                    continue
                plaintext = self._decode_protected_json(encoded, record_type=record_type)
                rebound = self._encode_protected_json(
                    plaintext, record_type=record_type, context_id=context_id
                )
                self._connection.execute(
                    f"UPDATE {table} SET {value_column} = ? WHERE {key_column} = ?",
                    (rebound, row[key_column]),
                )
                audit_changed = audit_changed or table == "audit"
        self._connection.commit()
        if audit_changed:
            rows = self._connection.execute(
                "SELECT event_json FROM audit ORDER BY seq ASC"
            ).fetchall()
            descriptor, temporary = tempfile.mkstemp(
                prefix=".audit-migration-", suffix=".jsonl", dir=self.root
            )
            try:
                with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                    for row in rows:
                        handle.write(str(row["event_json"]) + "\n")
                    handle.flush()
                    os.fsync(handle.fileno())
                os.replace(temporary, self.audit_path)
                _fsync_directory(self.root)
            finally:
                if os.path.exists(temporary):
                    os.unlink(temporary)

    def set_object_status(self, digest: str, status: str, *, reason: str = "") -> None:
        """Record a lifecycle status against an object (spec 12, 17.1).

        This changes *metadata*, never content.  The bytes at ``digest`` still
        hash to ``digest`` afterwards, which is why an independent verifier can
        keep checking them and reach its own conclusion (9.3).
        """
        if status not in ObjectStatus.ALL:
            raise UsageError(f"unknown object status {status!r} (spec 12)")
        self._connection.execute(
            "INSERT OR REPLACE INTO object_status (content_hash, status, reason, changed_at) "
            "VALUES (?,?,?,?)",
            (digest, status, reason, utc_now()),
        )
        self._connection.commit()

    def set_legal_hold(self, digest: str, held: bool, *, authority: str = "") -> None:
        """Place or release a legal hold (spec 17.5)."""
        self._connection.execute(
            "UPDATE objects SET legal_hold = ? WHERE content_hash = ?",
            (1 if held else 0, digest),
        )
        self._connection.commit()
        self.append_audit(
            {
                "event": "legal_hold.changed",
                "content_hash": digest,
                "held": held,
                "authority": authority,
                "recorded_at": utc_now(),
            }
        )

    # -- cases (42.1, 11, 16.1) -------------------------------------------
    def put_case(
        self,
        case: Mapping[str, Any],
        *,
        expected_parent_version: Optional[int] = None,
        created_by: str = "crg-server",
        derived_from: Optional[Mapping[str, Any]] = None,
    ) -> str:
        """Append a new case version and return its content hash.

        Each branch has a linear history (16.1) and concurrent updates use
        optimistic locking against an expected parent version.  Supplying a
        stale ``expected_parent_version`` is a conflict rather than an
        overwrite -- the caller read one state, reasoned about it, and would
        otherwise silently discard the state that arrived meanwhile.
        """
        case_id = str(case.get("case_id") or "")
        if not case_id:
            raise UsageError("a case must carry a case_id (spec 11.1)")
        with self._write_lock:
            return self._put_case_locked(case, case_id, expected_parent_version, created_by,
                                         derived_from)

    def _put_case_locked(
        self,
        case: Mapping[str, Any],
        case_id: str,
        expected_parent_version: Optional[int],
        created_by: str,
        derived_from: Optional[Mapping[str, Any]],
    ) -> str:
        head = self.head_version(case_id)
        if expected_parent_version is not None and expected_parent_version != head:
            raise ConflictError(
                f"case {case_id!r} is at version {head}, not {expected_parent_version}",
                remedy="re-read the case, re-apply the change, and retry (16.1)",
                detail={"case_id": case_id, "head_version": head,
                        "expected_parent_version": expected_parent_version},
            )
        version = head + 1
        body = dict(case)
        body.setdefault("branch_id", body.get("branch_id") or "main")
        body["case_version"] = version
        if derived_from:
            body["derived_from"] = dict(derived_from)
        refresh_case_metadata(body)
        digest = self.put_object(body, object_type="CRGCase", created_by=created_by)
        self._connection.execute(
            "INSERT INTO cases (case_id, case_version, content_hash, branch_id, derived_from, "
            "parent_version, status, created_at, created_by) VALUES (?,?,?,?,?,?,?,?,?)",
            (
                case_id,
                version,
                digest,
                str(body.get("branch_id")),
                canonical_json(body["derived_from"]) if body.get("derived_from") else None,
                head or None,
                str(body.get("status") or "DRAFT"),
                utc_now(),
                created_by,
            ),
        )
        self._connection.commit()
        return digest

    def head_version(self, case_id: str) -> int:
        row = self._connection.execute(
            "SELECT MAX(case_version) AS v FROM cases WHERE case_id = ?", (case_id,)
        ).fetchone()
        return int(row["v"]) if row and row["v"] is not None else 0

    def case_exists(self, case_id: str) -> bool:
        return self.head_version(case_id) > 0

    def get_case(self, case_id: str, version: Optional[Any] = None) -> Dict[str, Any]:
        """Read a case version.  ``version`` is an ordinal or a content hash.

        11.2: a prior case version MUST remain addressable after supersession,
        so this reads history as readily as it reads the head.
        """
        if version is None:
            row = self._connection.execute(
                "SELECT content_hash FROM cases WHERE case_id = ? "
                "ORDER BY case_version DESC LIMIT 1",
                (case_id,),
            ).fetchone()
        elif isinstance(version, str) and version.startswith("sha256:"):
            row = self._connection.execute(
                "SELECT content_hash FROM cases WHERE case_id = ? AND content_hash = ?",
                (case_id, version),
            ).fetchone()
        else:
            try:
                ordinal = int(version)
            except (TypeError, ValueError):
                raise UsageError(
                    f"version {version!r} is neither an ordinal nor a sha256 content hash"
                ) from None
            row = self._connection.execute(
                "SELECT content_hash FROM cases WHERE case_id = ? AND case_version = ?",
                (case_id, ordinal),
            ).fetchone()
        if row is None:
            raise NotFoundError(
                f"no case {case_id!r}" + ("" if version is None else f" at version {version!r}"),
                remedy="POST /cases to create one, or GET /cases/{case_id} for the head",
            )
        return dict(self.get_object(str(row["content_hash"])))

    def list_versions(self, case_id: str) -> List[str]:
        """Every stored version of ``case_id``, oldest first, by content hash."""
        rows = self._connection.execute(
            "SELECT content_hash FROM cases WHERE case_id = ? ORDER BY case_version ASC",
            (case_id,),
        ).fetchall()
        return [str(r["content_hash"]) for r in rows]

    def case_index(self, case_id: str) -> List[Dict[str, Any]]:
        rows = self._connection.execute(
            "SELECT case_version, content_hash, branch_id, parent_version, status, created_at, "
            "derived_from FROM cases WHERE case_id = ? ORDER BY case_version ASC",
            (case_id,),
        ).fetchall()
        out: List[Dict[str, Any]] = []
        for row in rows:
            record = dict(row)
            if record.get("derived_from"):
                record["derived_from"] = json.loads(str(record["derived_from"]))
            out.append(record)
        return out

    def list_cases(self) -> List[str]:
        rows = self._connection.execute(
            "SELECT DISTINCT case_id FROM cases ORDER BY case_id"
        ).fetchall()
        return [str(r["case_id"]) for r in rows]

    # -- typed dependency index (18) ---------------------------------------
    def record_edges(self, edges: Iterable[Any], *, case_id: Optional[str] = None) -> List[str]:
        """Index typed dependency edges (spec 18.2).

        A generic ``depends_on`` is explicitly insufficient for
        certificate-authorizing behaviour (18.1), so the edge type is stored
        and the minimum recomputation action is resolved from
        :data:`crg_model.edges.EDGE_SEMANTICS` at write time rather than
        guessed at read time.
        """
        normalized: List[Tuple[DependencyEdge, str]] = []
        for edge in edges:
            if isinstance(edge, DependencyEdge):
                scope = str(getattr(edge, "scope", "") or "")
                typed = edge
            else:
                mapping = dict(edge)
                source = str(mapping["source"])
                target = str(mapping["target"])
                edge_type = str(mapping["edge_type"])
                edge_id = str(mapping.get("edge_id") or f"{source}->{target}#{edge_type}")
                scope = str(mapping.get("scope") or "")
                typed = DependencyEdge(edge_id=edge_id, source=source, target=target,
                                       edge_type=edge_type, scope=scope or None)
            normalized.append((typed, scope))

        replacement_ids = {typed.edge_id for typed, _scope in normalized}
        with self._write_lock:
            if case_id is None:
                rows = self._connection.execute(
                    "SELECT edge_id, source, target, edge_type, scope FROM edges "
                    "WHERE case_id IS NULL ORDER BY edge_id"
                ).fetchall()
            else:
                rows = self._connection.execute(
                    "SELECT edge_id, source, target, edge_type, scope FROM edges "
                    "WHERE case_id = ? ORDER BY edge_id", (case_id,)
                ).fetchall()
            graph = DependencyGraph()
            graph.add_edges(
                DependencyEdge(edge_id=str(row["edge_id"]), source=str(row["source"]),
                               target=str(row["target"]), edge_type=str(row["edge_type"]),
                               scope=str(row["scope"] or "") or None)
                for row in rows if str(row["edge_id"]) not in replacement_ids
            )
            try:
                graph.add_edges(typed for typed, _scope in normalized)
            except ValueError as exc:
                raise ConflictError(
                    f"dependency batch would violate acyclicity: {exc}",
                    remedy="represent feedback through successor versions, producing a DAG",
                ) from exc
            for typed, scope in normalized:
                self._connection.execute(
                    "INSERT OR REPLACE INTO edges (edge_id, case_id, source, target, edge_type, "
                    "scope, minimum_action, recorded_at) VALUES (?,?,?,?,?,?,?,?)",
                    (typed.edge_id, case_id, typed.source, typed.target, typed.edge_type,
                     scope, typed.minimum_action, utc_now()),
                )
            self._connection.commit()
        return [typed.edge_id for typed, _scope in normalized]

    def edges_for(self, case_id: str) -> List[Dict[str, Any]]:
        rows = self._connection.execute(
            "SELECT * FROM edges WHERE case_id = ? ORDER BY edge_id", (case_id,)
        ).fetchall()
        return [dict(r) for r in rows]

    def edges_from(self, source: str) -> List[Dict[str, Any]]:
        rows = self._connection.execute(
            "SELECT * FROM edges WHERE source = ? ORDER BY edge_id", (source,)
        ).fetchall()
        return [dict(r) for r in rows]

    def edges_to(self, target: str) -> List[Dict[str, Any]]:
        rows = self._connection.execute(
            "SELECT * FROM edges WHERE target = ? ORDER BY edge_id", (target,)
        ).fetchall()
        return [dict(r) for r in rows]

    def dependents_of(self, source: str) -> List[str]:
        """Reachable descendants of ``source`` (spec 18.5, incremental traversal)."""
        seen: List[str] = []
        frontier = [source]
        visited = {source}
        while frontier:
            current = frontier.pop()
            for edge in self.edges_from(current):
                target = str(edge["target"])
                if target in visited:
                    continue
                visited.add(target)
                seen.append(target)
                frontier.append(target)
        return sorted(seen)

    # -- certificates (registration is the gate, spec 42.4) -----------------
    def register_certificate(
        self,
        case_id: str,
        certificate: Mapping[str, Any],
        *,
        job: Any,
        dependencies: Sequence[Any] = (),
    ) -> str:
        """Register a certificate produced by a *successful* job (spec 42.4).

        Specification 42.4: "A failed job MUST NOT produce a valid certificate
        unless a separately valid partial-result pathway exists."  This method
        is the only way a certificate becomes visible to
        ``GET /cases/{id}/certificates``, and it refuses any job whose status
        is not ``SUCCEEDED``.  There is therefore no ordering of calls, and no
        exception handler anywhere else in the server, that can leave a failed
        computation holding a live certificate.
        """
        status = str(getattr(job, "status", "") or "")
        if status != "SUCCEEDED":
            raise ConflictError(
                f"job {getattr(job, 'job_id', '?')} is {status or 'UNKNOWN'}; a certificate may "
                "only be registered by a SUCCEEDED job (42.4)",
                remedy="inspect the job's failure category and logs",
                detail={"job_status": status},
            )
        certificate_id = str(certificate.get("certificate_id") or "")
        if not certificate_id:
            raise UsageError("a certificate must carry a certificate_id (spec 29.4)")
        digest = self.put_object(certificate, object_type="DecisionCertificate")
        outcome = str(certificate.get("outcome") or "")
        affirmative = bool(certificate.get("affirmative", not outcome.startswith("BLOCKED")))
        self._connection.execute(
            "INSERT OR REPLACE INTO certificates (case_id, certificate_id, content_hash, job_id, "
            "outcome, affirmative, registered_at) VALUES (?,?,?,?,?,?,?)",
            (
                case_id,
                certificate_id,
                digest,
                str(getattr(job, "job_id", "")),
                outcome,
                1 if affirmative else 0,
                utc_now(),
            ),
        )
        self._connection.commit()
        if dependencies:
            self.record_edges(dependencies, case_id=case_id)
        return digest

    def unregister_certificates(self, job_id: str) -> int:
        """Withdraw the registrations made by ``job_id`` (spec 42.4).

        Used only when a commit failed partway.  It removes *registrations*,
        which are metadata; the certificate content stays in the object store
        under its hash, because 6.4 makes provenance immutable and an object
        that was written is a fact even when the run that wrote it was not
        allowed to keep it.  What disappears is the claim that the certificate
        is live.
        """
        cursor = self._connection.execute(
            "DELETE FROM certificates WHERE job_id = ?", (job_id,)
        )
        self._connection.commit()
        return int(cursor.rowcount or 0)

    def list_certificates(self, case_id: str) -> List[Dict[str, Any]]:
        rows = self._connection.execute(
            "SELECT * FROM certificates WHERE case_id = ? ORDER BY certificate_id", (case_id,)
        ).fetchall()
        out: List[Dict[str, Any]] = []
        for row in rows:
            record = dict(row)
            record["affirmative"] = bool(record["affirmative"])
            record["status"] = self.object_status(str(record["content_hash"]))
            out.append(record)
        return out

    def certificate_status(self, case_id: str, certificate_id: str) -> str:
        row = self._connection.execute(
            "SELECT content_hash FROM certificates WHERE case_id = ? AND certificate_id = ?",
            (case_id, certificate_id),
        ).fetchone()
        if row is None:
            raise NotFoundError(f"no certificate {certificate_id!r} in case {case_id!r}")
        return self.object_status(str(row["content_hash"]))

    # -- audit (44.7, 42.1) -------------------------------------------------
    def append_audit(self, event: Any) -> None:
        """Append one immutable audit event.

        Append-only in both stores: the SQLite table has an autoincrementing
        sequence and no update or delete path on this class, and the JSONL
        file is opened in ``"a"`` mode.  44.7 requires *every*
        authorization-sensitive operation to produce an immutable audit event,
        and an audit log a caller can rewrite is not one.
        """
        if hasattr(event, "to_canonical"):
            event = event.to_canonical()
        if not isinstance(event, Mapping):
            raise UsageError("an audit event must be a mapping (spec 44.7)")
        record = dict(event)
        record.setdefault("recorded_at", utc_now())
        with self._write_lock:
            inserted = self._connection.execute(
                "INSERT INTO audit (recorded_at, event_json) VALUES (?,?)",
                (str(record["recorded_at"]), ""),
            )
            seq = int(inserted.lastrowid)
            try:
                payload = self._encode_protected_json(
                    record, record_type="StoreAuditEvent", context_id=str(seq)
                )
                self._connection.execute(
                    "UPDATE audit SET event_json = ? WHERE seq = ?", (payload, seq)
                )
                self._connection.commit()
            except Exception:
                self._connection.rollback()
                raise
        with open(self.audit_path, "a", encoding="utf-8") as handle:
            handle.write(payload + "\n")

    def audit_log(self, *, case_id: Optional[str] = None) -> List[Dict[str, Any]]:
        rows = self._connection.execute(
            "SELECT seq, event_json FROM audit ORDER BY seq ASC"
        ).fetchall()
        events = [
            self._decode_protected_json(
                str(r["event_json"]), record_type="StoreAuditEvent", context_id=str(r["seq"])
            )
            for r in rows
        ]
        if case_id is not None:
            events = [e for e in events if e.get("case_id") == case_id]
        return events

    def audit_records(
        self, *, after_seq: int = 0, limit: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """Ordered audit rows with their durable sequence numbers."""
        rows = self._connection.execute(
            "SELECT seq, recorded_at, event_json FROM audit WHERE seq > ? ORDER BY seq ASC",
            (int(after_seq),),
        ).fetchall()
        records = [
            {"seq": int(row["seq"]), "recorded_at": str(row["recorded_at"]),
             "event": self._decode_protected_json(
                 str(row["event_json"]), record_type="StoreAuditEvent",
                 context_id=str(row["seq"]),
             )}
            for row in rows
        ]
        return records if limit is None else records[: int(limit)]

    # -- redaction and tombstones (17) --------------------------------------
    def is_redacted(self, digest: str) -> bool:
        row = self._connection.execute(
            "SELECT content_hash FROM tombstones WHERE content_hash = ?", (digest,)
        ).fetchone()
        return row is not None

    def tombstone(self, digest: str) -> Tombstone:
        row = self._connection.execute(
            "SELECT * FROM tombstones WHERE content_hash = ?", (digest,)
        ).fetchone()
        if row is None:
            raise NotFoundError(f"no tombstone for {digest}")
        return Tombstone(
            object_id=str(row["object_id"]),
            content_hash=str(row["content_hash"]),
            object_type=str(row["object_type"]),
            reason=str(row["reason"]),
            authority=str(row["authority"]),
            removed_at=str(row["removed_at"]),
            dependency_edges=tuple(json.loads(str(row["edges_json"]))),
            legal_hold=bool(row["legal_hold"]),
            permitted_disclosure=str(row["permitted_disclosure"]),
            affected_certificates=tuple(
                str(r["certificate_id"])
                for r in self._connection.execute(
                    "SELECT certificate_id FROM certificates WHERE content_hash IN "
                    "(SELECT content_hash FROM object_status WHERE status = ?) "
                    "ORDER BY certificate_id",
                    (ObjectStatus.UNVERIFIABLE_REDACTED,),
                ).fetchall()
            ),
        )

    def tombstones(self) -> List[Dict[str, Any]]:
        rows = self._connection.execute(
            "SELECT content_hash FROM tombstones ORDER BY content_hash"
        ).fetchall()
        return [self.tombstone(str(r["content_hash"])).to_canonical() for r in rows]

    def redact(
        self,
        digest: str,
        *,
        reason: str,
        authority: str,
        permitted_disclosure: str = "identity, hash, type, and dependency structure only",
    ) -> Tombstone:
        """Remove content, preserve identity and structure (spec 17.2, 17.3).

        The bytes go.  The hash, the object type, and every typed dependency
        edge touching the object stay, as a ``TombstoneRecord``.

        The second half is the part that matters more.  17.3: a certificate
        whose necessary supporting content has been removed MUST become
        ``UNVERIFIABLE_REDACTED`` unless it contains a separately sufficient
        proof artifact that remains available -- and the system MUST NOT
        silently report such a certificate as valid.  So every reachable
        dependent certificate is walked (18.5) and re-statused here, at the
        moment of removal, rather than left for a later verification pass that
        a caller might not run.  A certificate that carries its own sufficient
        proof artifact, and whose artifact is still present, keeps its status
        and gains a recorded note saying why.

        17.5: an object under legal hold is not removable, and the attempt is
        a conflict.
        """
        if not reason:
            raise UsageError("redaction requires a stated reason (17.2)")
        if not authority:
            raise UsageError("redaction requires a named removal authority (17.2)")
        row = self._connection.execute(
            "SELECT * FROM objects WHERE content_hash = ?", (digest,)
        ).fetchone()
        if row is None:
            raise NotFoundError(f"no object {digest} to redact")
        if bool(row["legal_hold"]):
            raise ConflictError(
                f"object {digest} is under legal hold and MUST NOT be deleted or "
                "cryptographically erased until the hold is released (17.5)",
                remedy="release the hold under authorized policy, then redact",
                detail={"content_hash": digest},
            )
        if self.is_redacted(digest):
            return self.tombstone(digest)

        edges = [
            dict(e)
            for e in (
                self._connection.execute(
                    "SELECT * FROM edges WHERE source = ? OR target = ? ORDER BY edge_id",
                    (digest, digest),
                ).fetchall()
            )
        ]
        try:
            payload = self.get_object(digest)
            object_id = str(payload.get("object_id") or payload.get("bundle_id")
                            or payload.get("case_id") or digest) if isinstance(payload, Mapping) \
                else digest
        except (NotFoundError, RedactedError, OSError, ValueError):
            object_id = digest

        path = os.path.join(self.root, str(row["path"]))
        if os.path.exists(path):
            os.remove(path)
        self._connection.execute(
            "UPDATE objects SET present = 0 WHERE content_hash = ?", (digest,)
        )
        removed_at = utc_now()
        self._connection.execute(
            "INSERT INTO tombstones (content_hash, object_id, object_type, reason, authority, "
            "removed_at, legal_hold, permitted_disclosure, edges_json) VALUES (?,?,?,?,?,?,?,?,?)",
            (
                digest,
                object_id,
                str(row["object_type"]),
                reason,
                authority,
                removed_at,
                0,
                permitted_disclosure,
                json.dumps(edges, sort_keys=True),
            ),
        )
        self.set_object_status(digest, ObjectStatus.REDACTED, reason=reason)
        self._connection.commit()

        affected = self._downgrade_dependents(digest, reason=reason)
        self.append_audit(
            {
                "event": "object.redacted",
                "content_hash": digest,
                "object_type": str(row["object_type"]),
                "reason": reason,
                "authority": authority,
                "removed_at": removed_at,
                "affected_certificates": affected,
            }
        )
        return Tombstone(
            object_id=object_id,
            content_hash=digest,
            object_type=str(row["object_type"]),
            reason=reason,
            authority=authority,
            removed_at=removed_at,
            dependency_edges=tuple(edges),
            legal_hold=False,
            permitted_disclosure=permitted_disclosure,
            affected_certificates=tuple(affected),
        )

    def _sufficient_proof_available(self, certificate: Mapping[str, Any]) -> bool:
        """17.3's escape hatch, read strictly.

        A certificate survives redaction of its support only if it carries a
        proof artifact that is *separately sufficient* and *remains
        available*.  Both halves are checked: the artifact must declare
        ``sufficiency == "SELF_CONTAINED"`` and its own content must still be
        present in this store.  An artifact that merely exists, or one that is
        itself redacted, buys nothing.
        """
        artifacts = certificate.get("proof_artifacts") or ()
        for artifact in artifacts:
            if not isinstance(artifact, Mapping):
                continue
            if str(artifact.get("sufficiency") or "") != "SELF_CONTAINED":
                continue
            artifact_hash = str(artifact.get("content_hash") or "")
            if artifact_hash and self.has_object(artifact_hash):
                return True
        return False

    def _downgrade_dependents(self, digest: str, *, reason: str) -> List[str]:
        """Re-status every certificate reachable from a redacted object (17.3)."""
        affected: List[str] = []
        reachable = set(self.dependents_of(digest))
        rows = self._connection.execute("SELECT * FROM certificates").fetchall()
        for row in rows:
            cert_hash = str(row["content_hash"])
            cert_id = str(row["certificate_id"])
            if cert_hash not in reachable and cert_id not in reachable:
                continue
            try:
                certificate = self.get_object(cert_hash)
            except (NotFoundError, RedactedError):
                certificate = {}
            if isinstance(certificate, Mapping) and self._sufficient_proof_available(certificate):
                self.set_object_status(
                    cert_hash,
                    ObjectStatus.ACTIVE,
                    reason=(
                        "supporting content was redacted, but a separately sufficient "
                        "proof artifact remains available (17.3)"
                    ),
                )
                continue
            self.set_object_status(
                cert_hash,
                ObjectStatus.UNVERIFIABLE_REDACTED,
                reason=f"supporting object {digest} was redacted: {reason} (17.3)",
            )
            affected.append(cert_id)
        return sorted(affected)

    # -- idempotency (38.4) -------------------------------------------------
    def idempotent_lookup(self, key: str) -> Optional[Dict[str, Any]]:
        row = self._connection.execute(
            "SELECT * FROM idempotency WHERE key = ?", (key,)
        ).fetchone()
        if row is None:
            return None
        record = dict(row)
        response = self._decode_protected_json(
            str(record["response_json"]), record_type="IdempotentResponse", context_id=key
        )
        record["response_json"] = canonical_json(response)
        return record

    def idempotent_record(
        self, key: str, request_hash: str, response: Any, status: int
    ) -> None:
        self._connection.execute(
            "INSERT OR REPLACE INTO idempotency (key, request_hash, response_json, status, "
            "created_at) VALUES (?,?,?,?,?)",
            (key, request_hash,
             self._encode_protected_json(
                 response, record_type="IdempotentResponse", context_id=key
             ),
             int(status), utc_now()),
        )
        self._connection.commit()

    def canonical_lookup(self, request_hash: str) -> Optional[Dict[str, Any]]:
        row = self._connection.execute(
            "SELECT * FROM canonical_results WHERE request_hash = ?", (request_hash,)
        ).fetchone()
        if row is None:
            return None
        record = dict(row)
        response = self._decode_protected_json(
            str(record["response_json"]), record_type="CanonicalResponse",
            context_id=request_hash,
        )
        record["response_json"] = canonical_json(response)
        return record

    def canonical_record(self, request_hash: str, response: Any, status: int) -> None:
        self._connection.execute(
            "INSERT OR REPLACE INTO canonical_results (request_hash, response_json, status, "
            "created_at) VALUES (?,?,?,?)",
            (request_hash,
             self._encode_protected_json(
                 response, record_type="CanonicalResponse", context_id=request_hash
             ),
             int(status), utc_now()),
        )
        self._connection.commit()

    # -- job persistence ----------------------------------------------------
    def save_job(self, job_id: str, record: Mapping[str, Any]) -> None:
        self._connection.execute(
            "INSERT OR REPLACE INTO jobs (job_id, record_json, updated_at) VALUES (?,?,?)",
            (job_id, self._encode_protected_json(
                dict(record), record_type="PersistedJobRecord", context_id=job_id
            ), utc_now()),
        )
        self._connection.commit()

    def compare_and_set_job(
        self,
        job_id: str,
        record: Mapping[str, Any],
        *,
        expected_statuses: Sequence[str],
        expected_phase: str,
    ) -> bool:
        """Atomically move one job from an expected execution state.

        ``BEGIN IMMEDIATE`` makes the read/compare/write indivisible across
        both request threads and separate worker processes.  The protected
        JSON remains authenticated with the job identifier as AEAD context.
        """
        with self._connection.transaction(immediate=True):
            row = self._connection.execute(
                "SELECT record_json FROM jobs WHERE job_id = ?", (job_id,)
            ).fetchone()
            if row is None:
                return False
            current = self._decode_protected_json(
                str(row["record_json"]),
                record_type="PersistedJobRecord",
                context_id=job_id,
            )
            status = str(current.get("status"))
            phase = current.get("execution_phase")
            if phase is None:
                phase = (
                    "QUEUED" if status == "QUEUED"
                    else "EXECUTING" if status == "RUNNING"
                    else "TERMINAL"
                )
            if (
                status not in {str(value) for value in expected_statuses}
                or str(phase) != str(expected_phase)
            ):
                return False
            self._connection.execute(
                "UPDATE jobs SET record_json = ?, updated_at = ? WHERE job_id = ?",
                (
                    self._encode_protected_json(
                        dict(record),
                        record_type="PersistedJobRecord",
                        context_id=job_id,
                    ),
                    utc_now(),
                    job_id,
                ),
            )
        return True

    def load_job(self, job_id: str) -> Optional[Dict[str, Any]]:
        row = self._connection.execute(
            "SELECT record_json FROM jobs WHERE job_id = ?", (job_id,)
        ).fetchone()
        return (
            self._decode_protected_json(
                str(row["record_json"]), record_type="PersistedJobRecord", context_id=job_id
            ) if row else None
        )

    def list_jobs(self) -> List[Dict[str, Any]]:
        rows = self._connection.execute(
            "SELECT job_id, record_json FROM jobs ORDER BY job_id"
        ).fetchall()
        return [
            self._decode_protected_json(
                str(r["record_json"]), record_type="PersistedJobRecord",
                context_id=str(r["job_id"]),
            ) for r in rows
        ]

    def save_job_payload(self, job_id: str, payload: Mapping[str, Any]) -> None:
        """Persist the replay input separately from the export-safe job record."""
        self._connection.execute(
            "INSERT OR REPLACE INTO job_payloads (job_id, payload_json, created_at) "
            "VALUES (?,?,?)",
            (job_id, self._encode_protected_json(
                dict(payload), record_type="PersistedJobPayload", context_id=job_id
            ), utc_now()),
        )
        self._connection.commit()

    def load_job_payload(self, job_id: str) -> Optional[Dict[str, Any]]:
        row = self._connection.execute(
            "SELECT payload_json FROM job_payloads WHERE job_id = ?", (job_id,)
        ).fetchone()
        return (
            self._decode_protected_json(
                str(row["payload_json"]), record_type="PersistedJobPayload",
                context_id=job_id,
            ) if row else None
        )
