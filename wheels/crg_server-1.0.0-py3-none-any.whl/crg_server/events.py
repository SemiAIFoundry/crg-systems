"""The declared event vocabulary, its carrier, and a webhook-shaped payload.

Normative basis: 38.5 (events), 38.2 (webhooks and event streaming), 44.7
(every authorization-sensitive operation produces an immutable audit event).

Specification 38.5 does two things at once.  It fixes a *vocabulary* -- a
closed list of event names -- and it fixes a *carrier*: every event MUST
carry case ID, branch ID, object hashes, timestamp, actor, correlation ID,
and schema version.  Both are enforced structurally here.  An event name
outside the vocabulary raises rather than being emitted as a novel string,
because a subscriber filtering on ``decision.certified`` cannot be expected
to also guess ``decision.certified.v2``; and an event missing a required
carrier field raises, because a correlation ID that is sometimes absent is a
correlation ID no operator can build a trace on.

The bus is in-process and synchronous.  38.2 asks the reference server for
Server-Sent Events, WebSocket, or equivalent plus webhooks; those are
transports over this vocabulary, not separate semantics.  What this module
provides is the semantics plus :func:`webhook_payload`, which *builds* the
delivery a webhook would carry -- signature included -- without opening a
socket.  A test can then assert the exact bytes an integrator would receive,
which is the property that actually matters, and no test needs a network.
"""
from __future__ import annotations

import hashlib
import hmac
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Mapping, Optional, Sequence, Tuple

from crg_model.canonical import canonical_json, content_hash
from crg_model.envelope import new_object_id, utc_now

from .errors import UsageError

__all__ = [
    "EVENT_VOCABULARY",
    "REQUIRED_EVENT_FIELDS",
    "WEBHOOK_SIGNATURE_PROFILE",
    "Event",
    "EventBus",
    "webhook_payload",
]

#: Specification 38.5.  Closed by construction: :meth:`EventBus.emit` refuses
#: any name not in this tuple.
EVENT_VOCABULARY: Tuple[str, ...] = (
    "case.created",
    "case.validated",
    "case.branched",
    "case.merged",
    "case.migrated",
    "case.redacted",
    "registry.imported",
    "realization.generated",
    "realization.rejected",
    "geometry.updated",
    "query.compiled",
    "decision.certified",
    "decision.blocked",
    "certificate.verified",
    "certificate.stale",
    "change.classified",
    "case.reopened",
    "evidence.registered",
    "evidence.expired",
    "technology_contract.updated",
    "qualification.planned",
    "experiment.completed",
    "conversion.planned",
    "transition.executed",
    "transition.rolled_back",
    "capability.revoked",
)

#: Specification 38.5, "Every event MUST carry".
REQUIRED_EVENT_FIELDS: Tuple[str, ...] = (
    "case_id",
    "branch_id",
    "object_hashes",
    "timestamp",
    "actor",
    "correlation_id",
    "schema_version",
)

#: The webhook delivery signature profile.  Symmetric, and labelled as such:
#: a shared secret authenticates the *sender to a receiver that holds the same
#: secret* and proves nothing to a third party (compare 14.5, which requires
#: Ed25519 over canonical manifests for portable artifacts).
WEBHOOK_SIGNATURE_PROFILE = "HMAC-SHA256-SHARED-SECRET"

SCHEMA_VERSION = "0.2.0"


@dataclass(frozen=True)
class Event:
    """One emitted event with the full 38.5 carrier.

    ``object_hashes`` is a tuple of content hashes the event refers to.  It is
    part of the carrier and not an optional annotation: an event that says a
    decision was certified without naming the certificate it certified cannot
    be correlated with the object store afterwards.
    """

    event: str
    case_id: Optional[str]
    branch_id: Optional[str]
    object_hashes: Tuple[str, ...]
    timestamp: str
    actor: str
    correlation_id: str
    schema_version: str = SCHEMA_VERSION
    detail: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.event not in EVENT_VOCABULARY:
            raise UsageError(
                f"unknown event name {self.event!r}",
                remedy=(
                    "38.5 fixes a closed event vocabulary; emit one of "
                    f"{list(EVENT_VOCABULARY)} or extend the specification"
                ),
            )
        if not self.actor:
            raise UsageError(
                "an event must name its actor (38.5)",
                remedy="supply an actor identity on the originating request",
            )
        if not self.correlation_id:
            raise UsageError(
                "an event must carry a correlation ID (38.5)",
                remedy="supply a correlation ID on the originating request",
            )
        if not self.timestamp:
            raise UsageError("an event must carry a timestamp (38.5)")
        object.__setattr__(self, "object_hashes", tuple(str(h) for h in self.object_hashes))

    def to_canonical(self) -> Dict[str, Any]:
        record: Dict[str, Any] = {
            "event": self.event,
            "case_id": self.case_id,
            "branch_id": self.branch_id,
            "object_hashes": list(self.object_hashes),
            "timestamp": self.timestamp,
            "actor": self.actor,
            "correlation_id": self.correlation_id,
            "schema_version": self.schema_version,
        }
        if self.detail:
            record["detail"] = dict(self.detail)
        return record

    def event_hash(self) -> str:
        return content_hash(self.to_canonical())


class EventBus:
    """In-process publication of the 38.5 vocabulary.

    Subscribers are plain callables.  A subscriber that raises does not stop
    the emission: an integration listener is outside the trusted computing
    base of 9.2, and a broken listener must not be able to prevent an audit
    record from being written.  Its failure is recorded on the bus instead.
    """

    def __init__(self, store: Any = None) -> None:
        self._subscribers: List[Callable[[Event], None]] = []
        self._history: List[Event] = []
        self._store = store
        self.subscriber_failures: List[Tuple[str, str]] = []

    # -- subscription ------------------------------------------------------
    def subscribe(self, callback: Callable[[Event], None]) -> Callable[[], None]:
        """Register ``callback``; returns a zero-argument unsubscribe."""
        self._subscribers.append(callback)

        def _unsubscribe() -> None:
            if callback in self._subscribers:
                self._subscribers.remove(callback)

        return _unsubscribe

    # -- emission ----------------------------------------------------------
    def emit(
        self,
        event: str,
        *,
        actor: str,
        correlation_id: str,
        case_id: Optional[str] = None,
        branch_id: Optional[str] = None,
        object_hashes: Sequence[str] = (),
        detail: Optional[Mapping[str, Any]] = None,
        timestamp: Optional[str] = None,
    ) -> Event:
        record = Event(
            event=event,
            case_id=case_id,
            branch_id=branch_id,
            object_hashes=tuple(object_hashes),
            timestamp=timestamp or utc_now(),
            actor=actor,
            correlation_id=correlation_id,
            detail=dict(detail or {}),
        )
        self._history.append(record)
        # 44.7: the audit record is written before subscribers run, so a
        # subscriber that raises cannot cost the deployment its audit trail.
        if self._store is not None:
            self._store.append_audit(record.to_canonical())
        for callback in list(self._subscribers):
            try:
                callback(record)
            except Exception as error:  # noqa: BLE001 - listeners are untrusted
                self.subscriber_failures.append((record.event, f"{type(error).__name__}: {error}"))
        return record

    # -- inspection --------------------------------------------------------
    @property
    def history(self) -> Tuple[Event, ...]:
        return tuple(self._history)

    def names(self) -> Tuple[str, ...]:
        return tuple(e.event for e in self._history)

    def since(self, index: int) -> Tuple[Event, ...]:
        return tuple(self._history[index:])


def webhook_payload(
    event: Event,
    *,
    endpoint: str,
    secret: Optional[bytes] = None,
    delivery_id: Optional[str] = None,
) -> Dict[str, Any]:
    """Build the delivery a webhook subscriber would receive (spec 38.2).

    Nothing is sent.  The return value is the complete delivery -- headers,
    canonical body bytes, and signature -- so that an integrator can be tested
    against the exact payload without a network, and so that a deployment can
    hand the result to whatever transport it actually uses.

    The signature is computed over the canonical JSON of the body (14.3), not
    over whatever byte string a serializer happened to produce, so a receiver
    that re-canonicalizes reaches the same digest.
    """
    body = {
        "delivery_id": delivery_id or new_object_id("delivery"),
        "endpoint": endpoint,
        "event": event.to_canonical(),
    }
    payload = canonical_json(body).encode("utf-8")
    headers = {
        "Content-Type": "application/json",
        "CRG-Event": event.event,
        "CRG-Correlation-Id": event.correlation_id,
        "CRG-Delivery-Id": str(body["delivery_id"]),
        "CRG-Schema-Version": event.schema_version,
    }
    if secret is None:
        headers["CRG-Signature-Profile"] = "UNSIGNED"
        signature = None
    else:
        headers["CRG-Signature-Profile"] = WEBHOOK_SIGNATURE_PROFILE
        signature = hmac.new(secret, payload, hashlib.sha256).hexdigest()
        headers["CRG-Signature"] = f"sha256={signature}"
    return {
        "endpoint": endpoint,
        "method": "POST",
        "headers": headers,
        "body": body,
        "body_bytes": payload,
        "signature": signature,
        "signature_profile": headers["CRG-Signature-Profile"],
    }
