"""Durable verifier-owned V4 trust, nonce, and revocation state.

The capability envelope is untrusted input.  This module owns everything that
corroborates it and persists the replay decision transactionally, scoped to a
single authenticated tenant.  Request bodies can select neither keys nor
revocations nor their own nonce history.
"""
from __future__ import annotations

import json
import os
import sqlite3
import threading
from pathlib import Path
from typing import Any, Dict, Iterator, Mapping, MutableSet, Optional

from crg_model.envelope import utc_now

__all__ = [
    "FederationStateError", "ReplayDetectedError", "PersistentNonceLedger",
    "FederationVerifierState", "load_federation_verifier_state",
]


class FederationStateError(ValueError):
    """Federation trust state is absent, inconsistent, or cross-tenant."""


class ReplayDetectedError(FederationStateError):
    """A nonce lost the atomic uniqueness race and must be refused."""


SCHEMA = """
CREATE TABLE IF NOT EXISTS federation_nonces (
    tenant_id   TEXT NOT NULL,
    nonce       TEXT NOT NULL,
    consumed_at TEXT NOT NULL,
    PRIMARY KEY (tenant_id, nonce)
);
CREATE TABLE IF NOT EXISTS federation_revocations (
    tenant_id   TEXT NOT NULL,
    registry_id TEXT NOT NULL,
    subject     TEXT NOT NULL,
    reason      TEXT NOT NULL DEFAULT '',
    revoked_at  TEXT NOT NULL,
    PRIMARY KEY (tenant_id, registry_id, subject)
);
CREATE TABLE IF NOT EXISTS federation_events (
    seq         INTEGER PRIMARY KEY AUTOINCREMENT,
    tenant_id   TEXT NOT NULL,
    event       TEXT NOT NULL,
    subject     TEXT NOT NULL,
    recorded_at TEXT NOT NULL,
    detail_json TEXT NOT NULL
);
"""


class PersistentNonceLedger(MutableSet[str]):
    """A tenant-bound set whose ``add`` is a durable atomic consume.

    The independent verifier first asks membership and consumes only after all
    other V4 checks pass. Two concurrent verifiers may both observe freshness;
    the database uniqueness constraint then lets only one ``add`` commit. The
    loser raises instead of returning a second success.
    """

    def __init__(self, state: "FederationVerifierState") -> None:
        self._state = state

    def __contains__(self, nonce: object) -> bool:
        token = str(nonce or "")
        if not token:
            return False
        with self._state._lock:
            row = self._state._connection.execute(
                "SELECT 1 FROM federation_nonces WHERE tenant_id=? AND nonce=?",
                (self._state.tenant_id, token),
            ).fetchone()
        return row is not None

    def add(self, nonce: str) -> None:
        token = str(nonce or "").strip()
        if not token:
            raise FederationStateError("a consumed nonce must be non-empty")
        now = utc_now()
        with self._state._lock:
            try:
                self._state._connection.execute("BEGIN IMMEDIATE")
                self._state._connection.execute(
                    "INSERT INTO federation_nonces(tenant_id,nonce,consumed_at) VALUES(?,?,?)",
                    (self._state.tenant_id, token, now),
                )
                self._state._event_locked("nonce.consumed", token, {})
                self._state._connection.commit()
            except sqlite3.IntegrityError as exc:
                self._state._connection.rollback()
                raise ReplayDetectedError(
                    f"nonce {token!r} was already consumed in tenant {self._state.tenant_id!r}"
                ) from exc
            except Exception:
                self._state._connection.rollback()
                raise

    def discard(self, nonce: str) -> None:
        # Replay history is append-only. A MutableSet method exists only so the
        # verifier sees a normal set interface; erasing consumption would turn
        # a replay into a fresh request and is therefore refused.
        raise FederationStateError("consumed nonce history is append-only and cannot be discarded")

    def __iter__(self) -> Iterator[str]:
        with self._state._lock:
            rows = self._state._connection.execute(
                "SELECT nonce FROM federation_nonces WHERE tenant_id=? ORDER BY nonce",
                (self._state.tenant_id,),
            ).fetchall()
        return iter(tuple(str(row[0]) for row in rows))

    def __len__(self) -> int:
        with self._state._lock:
            row = self._state._connection.execute(
                "SELECT COUNT(*) FROM federation_nonces WHERE tenant_id=?",
                (self._state.tenant_id,),
            ).fetchone()
        return int(row[0])


class FederationVerifierState:
    """One tenant's persistent verifier authority and mutable live state."""

    def __init__(
        self, path: str, *, tenant_id: str, trusted_keys: Mapping[str, Mapping[str, Any]],
        trusted_issuers: Any, expected_context: str, authorized_rules: Any,
        revocation_registry_id: str, requested_release_kind: Optional[str] = None,
        require_attestation: bool = False, expected_code_identity: Optional[str] = None,
        expected_input_commitment: Optional[str] = None,
    ) -> None:
        self.tenant_id = str(tenant_id).strip()
        self.revocation_registry_id = str(revocation_registry_id).strip()
        if not self.tenant_id or not self.revocation_registry_id:
            raise FederationStateError("tenant_id and revocation_registry_id are required")
        if not trusted_keys or not expected_context or not trusted_issuers or not authorized_rules:
            raise FederationStateError(
                "trusted_keys, trusted_issuers, expected_context, and authorized_rules are required"
            )
        self._base: Dict[str, Any] = {
            "trusted_keys": {str(k): dict(v) for k, v in trusted_keys.items()},
            "trusted_issuers": tuple(str(v) for v in trusted_issuers),
            "expected_context": str(expected_context),
            "authorized_rules": tuple(str(v) for v in authorized_rules),
            "requested_release_kind": requested_release_kind,
            "require_attestation": bool(require_attestation),
            "expected_code_identity": expected_code_identity,
            "expected_input_commitment": expected_input_commitment,
        }
        target = Path(path).expanduser().resolve()
        target.parent.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(target.parent, 0o700)
        except OSError:
            pass
        self.path = str(target)
        self._lock = threading.RLock()
        self._connection = sqlite3.connect(self.path, check_same_thread=False, isolation_level=None)
        self._connection.execute("PRAGMA journal_mode=WAL")
        self._connection.execute("PRAGMA synchronous=FULL")
        self._connection.execute("PRAGMA foreign_keys=ON")
        self._connection.executescript(SCHEMA)
        try:
            os.chmod(self.path, 0o600)
        except OSError:
            pass
        self.nonce_ledger = PersistentNonceLedger(self)

    def _event_locked(self, event: str, subject: str, detail: Mapping[str, Any]) -> None:
        self._connection.execute(
            "INSERT INTO federation_events(tenant_id,event,subject,recorded_at,detail_json) "
            "VALUES(?,?,?,?,?)",
            (self.tenant_id, event, subject, utc_now(), json.dumps(dict(detail), sort_keys=True)),
        )

    def revoke(self, subject: str, *, reason: str) -> None:
        token = str(subject).strip()
        if not token or not str(reason).strip():
            raise FederationStateError("revocation requires a subject and reason")
        with self._lock:
            self._connection.execute("BEGIN IMMEDIATE")
            try:
                self._connection.execute(
                    "INSERT OR REPLACE INTO federation_revocations"
                    "(tenant_id,registry_id,subject,reason,revoked_at) VALUES(?,?,?,?,?)",
                    (self.tenant_id, self.revocation_registry_id, token, str(reason), utc_now()),
                )
                self._event_locked("subject.revoked", token, {"reason": str(reason)})
                self._connection.commit()
            except Exception:
                self._connection.rollback()
                raise

    def revoked_subjects(self) -> tuple[str, ...]:
        with self._lock:
            rows = self._connection.execute(
                "SELECT subject FROM federation_revocations WHERE tenant_id=? AND registry_id=? "
                "ORDER BY subject",
                (self.tenant_id, self.revocation_registry_id),
            ).fetchall()
        return tuple(str(row[0]) for row in rows)

    def context_for(self, principal: Any) -> Dict[str, Any]:
        if principal is None:
            raise FederationStateError("V4 server verification requires an authenticated principal")
        principal_tenant = str(getattr(principal, "tenant_id", "") or "")
        if principal_tenant != self.tenant_id:
            raise FederationStateError(
                f"principal tenant {principal_tenant!r} cannot use federation state for {self.tenant_id!r}"
            )
        context = dict(self._base)
        context["requester"] = {
            "subject_id": str(getattr(principal, "subject_id", "") or ""),
            "roles": list(getattr(principal, "roles", ()) or ()),
            "tenant_id": principal_tenant,
        }
        context["nonce_ledger"] = self.nonce_ledger
        context["revocations"] = {
            "registry_id": self.revocation_registry_id,
            "subjects": list(self.revoked_subjects()),
        }
        return context

    def __call__(self, _request: Any, principal: Any = None) -> Dict[str, Any]:
        return self.context_for(principal)

    def disclosure(self) -> Dict[str, Any]:
        return {
            "tenant_id": self.tenant_id,
            "database": self.path,
            "trusted_key_ids": sorted(self._base["trusted_keys"]),
            "trusted_issuers": list(self._base["trusted_issuers"]),
            "expected_context": self._base["expected_context"],
            "authorized_rules": list(self._base["authorized_rules"]),
            "revocation_registry_id": self.revocation_registry_id,
            "revoked_subject_count": len(self.revoked_subjects()),
            "consumed_nonce_count": len(self.nonce_ledger),
        }

    def integrity_check(self) -> Dict[str, Any]:
        with self._lock:
            rows = self._connection.execute("PRAGMA integrity_check").fetchall()
        messages = [str(row[0]) for row in rows]
        return {"ok": messages == ["ok"], "messages": messages,
                "tenant_id": self.tenant_id}

    def close(self) -> None:
        with self._lock:
            self._connection.close()


def load_federation_verifier_state(config_path: str, *, store_root: str) -> Optional[FederationVerifierState]:
    """Load public verifier trust policy from the deployment JSON.

    The optional top-level ``federation`` object contains no private key. If it
    is absent, V4 remains unsupported and fails closed; if present, every trust
    field is mandatory and startup refuses an incomplete policy.
    """
    path = Path(config_path).expanduser().resolve()
    try:
        document = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise FederationStateError(f"cannot read deployment config {str(path)!r}: {exc}") from exc
    federation = document.get("federation") if isinstance(document, Mapping) else None
    if federation is None:
        return None
    if not isinstance(federation, Mapping):
        raise FederationStateError("federation must be a JSON object")
    tenant_id = str(document.get("tenant_id") or "")
    raw_keys = federation.get("trusted_keys")
    if not isinstance(raw_keys, Mapping):
        raise FederationStateError("federation.trusted_keys must be an object keyed by key id")
    state = FederationVerifierState(
        str(Path(store_root).expanduser().resolve() / "federation" / "state.sqlite3"),
        tenant_id=tenant_id,
        trusted_keys={str(k): dict(v) for k, v in raw_keys.items() if isinstance(v, Mapping)},
        trusted_issuers=federation.get("trusted_issuers") or (),
        expected_context=str(federation.get("expected_context") or ""),
        authorized_rules=federation.get("authorized_rules") or (),
        revocation_registry_id=str(federation.get("revocation_registry_id") or ""),
        requested_release_kind=federation.get("requested_release_kind"),
        require_attestation=bool(federation.get("require_attestation", False)),
        expected_code_identity=federation.get("expected_code_identity"),
        expected_input_commitment=federation.get("expected_input_commitment"),
    )
    for entry in federation.get("revoked_subjects") or ():
        if isinstance(entry, Mapping):
            state.revoke(str(entry.get("subject") or ""), reason=str(entry.get("reason") or "configured"))
        else:
            state.revoke(str(entry), reason="configured")
    return state
