"""Branching, concurrency, and merge policy.

Normative basis: section 16 in full, with 11.1 (case metadata), 17.1
(supersession), 18 (typed dependencies), and 30 (change classification)
behind it.

Three rules from section 16 shape this module, and each is structural.

**A branch is a case (16.2).**  A divergence creates an explicit branch with
a ``BranchRecord`` naming parent case and version, branch point, purpose,
creator, access policy, intended decision scope, and expected reconciliation
behaviour.  All seven are required arguments of :func:`create_branch`; there
is no default purpose and no inferred reconciliation, because a branch whose
purpose was defaulted is one nobody has to justify later.

**Parent certificates do not travel (16.5).**  The new case starts with an
empty active certificate set.  The parent's certificates are copied into
``inherited_certificates`` as historical evidence, and they can be reused only
after dependency-aware revalidation.  Copying them into the active set would
let a claim about one branch's registry silently become a claim about
another's.

**Semantic objects are never merged automatically (16.3).**
:func:`merge_policy` refuses by *type*: the nine object classes 16.3 lists are
enumerated in :data:`SEMANTIC_OBJECTS`, and any difference in one of them
yields a decision that is not automatic, whatever the diff looks like.
Automatic merge is available only for nonsemantic metadata, only when the
changed fields are disjoint, and only when a registered merge rule covers
them -- all three conditions from 16.3, all three checked.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Dict, List, Mapping, Optional, Sequence, Set, Tuple

from crg_model.canonical import canonical_json, content_hash
from crg_model.envelope import utc_now
from crg_model.lifecycle import CaseState, LifecycleError, set_case_state

from .errors import ConflictError, NotFoundError, UsageError

__all__ = [
    "SEMANTIC_OBJECTS",
    "NONSEMANTIC_METADATA",
    "BRANCH_RECORD_REQUIRED",
    "MergeDecisionKind",
    "MergeDecision",
    "MergeRule",
    "BranchRecord",
    "create_branch",
    "merge_policy",
]

#: Specification 16.3, verbatim.  The keys are the case fields that carry each
#: class of semantic object in the case document this server persists.
SEMANTIC_OBJECTS: Dict[str, str] = {
    "contract": "computation contracts",
    "resource_contract": "resource contracts",
    "legality": "legality rules",
    "registry": "realization registries",
    "evidence": "evidence",
    "technology_contract": "technology contracts",
    "scope": "decision queries",
    "derivation": "decision queries",
    "certificates": "certificates",
    "applicability_rules": "applicability rules",
}

#: Fields that carry no decision semantics and may therefore be merged when
#: 16.3's other two conditions also hold.
NONSEMANTIC_METADATA: Tuple[str, ...] = (
    "title",
    "owner",
    "labels",
    "description",
    "external_links",
)

#: Specification 16.2.
BRANCH_RECORD_REQUIRED: Tuple[str, ...] = (
    "parent_case",
    "parent_version",
    "branch_point",
    "purpose",
    "creator",
    "access_policy",
    "intended_decision_scope",
    "expected_reconciliation",
)


class MergeDecisionKind:
    """What a merge request may be answered with."""

    #: 16.3: semantic objects differ.  Refused, and it is not a fault.
    REFUSED_SEMANTIC = "REFUSED_SEMANTIC"
    #: 16.4: a human-authored reconciliation is required.
    MANUAL_RECONCILIATION_REQUIRED = "MANUAL_RECONCILIATION_REQUIRED"
    #: 16.3: disjoint nonsemantic metadata under a registered rule.
    AUTOMATIC_METADATA = "AUTOMATIC_METADATA"
    #: Nothing differs.
    NO_DIFFERENCE = "NO_DIFFERENCE"


@dataclass(frozen=True)
class MergeRule:
    """A registered merge rule for nonsemantic metadata (spec 16.3)."""

    rule_id: str
    fields: Tuple[str, ...]
    strategy: str = "PREFER_SOURCE"
    registered_by: str = ""

    def covers(self, field_name: str) -> bool:
        return field_name in self.fields


@dataclass(frozen=True)
class MergeDecision:
    """The answer to a merge request.

    ``automatic`` is the only field a caller needs to branch on, and it is
    ``False`` for every semantic difference by construction.  The rest exists
    so that a refusal is *actionable*: which objects conflicted, what 16.4
    requires next, and which rule (if any) authorized what did merge.
    """

    decision: str
    automatic: bool
    semantic_conflicts: Tuple[str, ...] = ()
    nonsemantic_fields: Tuple[str, ...] = ()
    overlapping_fields: Tuple[str, ...] = ()
    unregistered_fields: Tuple[str, ...] = ()
    required_actions: Tuple[str, ...] = ()
    registered_rules: Tuple[str, ...] = ()
    rationale: str = ""
    source_case: str = ""
    target_case: str = ""
    merged_metadata: Mapping[str, Any] = field(default_factory=dict)

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "record_type": "MergeDecisionRecord",
            "decision": self.decision,
            "automatic": self.automatic,
            "source_case": self.source_case,
            "target_case": self.target_case,
            "semantic_conflicts": list(self.semantic_conflicts),
            "nonsemantic_fields": list(self.nonsemantic_fields),
            "overlapping_fields": list(self.overlapping_fields),
            "unregistered_fields": list(self.unregistered_fields),
            "required_actions": list(self.required_actions),
            "registered_rules": list(self.registered_rules),
            "rationale": self.rationale,
            "merged_metadata": dict(self.merged_metadata),
        }


@dataclass(frozen=True)
class BranchRecord:
    """Specification 16.2: what a branch MUST identify."""

    branch_id: str
    case_id: str
    parent_case: str
    parent_version: int
    parent_content_hash: str
    branch_point: str
    purpose: str
    creator: str
    access_policy: str
    intended_decision_scope: str
    expected_reconciliation: str
    created_at: str = field(default_factory=utc_now)

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "record_type": "BranchRecord",
            "branch_id": self.branch_id,
            "case_id": self.case_id,
            "parent_case": self.parent_case,
            "parent_version": self.parent_version,
            "parent_content_hash": self.parent_content_hash,
            "branch_point": self.branch_point,
            "purpose": self.purpose,
            "creator": self.creator,
            "access_policy": self.access_policy,
            "intended_decision_scope": self.intended_decision_scope,
            "expected_reconciliation": self.expected_reconciliation,
            "created_at": self.created_at,
        }


def create_branch(
    store: Any,
    case_id: str,
    *,
    name: str,
    purpose: str = "",
    creator: str = "",
    access_policy: str = "inherited",
    intended_decision_scope: str = "",
    expected_reconciliation: str = "MANUAL_RECONCILIATION",
    version: Optional[Any] = None,
) -> str:
    """Branch ``case_id`` at ``version`` and return the new case identifier.

    The branch is a new case (16.2).  It carries ``derived_from``, naming the
    parent case, the parent version ordinal, and the parent's content hash --
    the third of those is what makes the lineage checkable after export, since
    a version ordinal means nothing outside the store that assigned it.

    The active certificate set of the new case is empty (16.5).  Parent
    certificates are preserved under ``inherited_certificates`` with status
    ``HISTORICAL_EVIDENCE`` and a note stating the condition on their reuse.
    """
    if not name:
        raise UsageError(
            "a branch must be named (16.2)",
            remedy="supply a branch name; an anonymous divergence is not a branch",
        )
    if not purpose:
        raise UsageError(
            "a branch must declare its purpose (16.2)",
            remedy="state why this divergence exists before it acquires certificates",
        )
    if not creator:
        raise UsageError("a branch must name its creator (16.2)")

    parent = store.get_case(case_id, version)
    parent_ordinal = int(parent.get("case_version") or store.head_version(case_id))
    versions = store.list_versions(case_id)
    parent_hash = content_hash(parent)
    if parent_hash not in versions and versions:
        parent_hash = versions[parent_ordinal - 1] if 0 < parent_ordinal <= len(versions) \
            else versions[-1]

    branch_case_id = f"{case_id}@{name}"
    if store.case_exists(branch_case_id):
        raise ConflictError(
            f"branch {name!r} of case {case_id!r} already exists",
            remedy="choose another branch name or continue on the existing branch",
            detail={"case_id": branch_case_id},
        )

    child = json.loads(canonical_json(parent))
    child["case_id"] = branch_case_id
    child["branch_id"] = name
    # 11.2 lists BRANCHED among the states a case MAY become.  The child
    # inherits the parent's status and then transitions from it through the
    # lifecycle machine, so the branch record itself carries the leg
    # ``<parent status> -> BRANCHED`` and a branch of a revoked or archived
    # case is refused rather than quietly created (16.2, 6.4).
    try:
        set_case_state(
            child,
            CaseState.BRANCHED,
            reason=f"branched from {case_id}@{parent_ordinal} as {name!r}",
            actor=str(creator or "unattested"),
        )
    except LifecycleError as error:
        raise ConflictError(
            f"case {case_id!r} cannot be branched from state {error.current}: {error}",
            remedy="11.2 declares the case lifecycle; a terminal case cannot be branched",
            detail={"from_state": error.current, "to_state": error.target},
        ) from None
    child["parent_case_refs"] = list(parent.get("parent_case_refs") or ()) + [
        {"case_id": case_id, "case_version": parent_ordinal, "content_hash": parent_hash}
    ]
    # 16.5: parent-branch certificates do not automatically become
    # certificates of the branch.  They stay as historical evidence.
    inherited = dict(parent.get("certificates") or {})
    child["certificates"] = {}
    child["inherited_certificates"] = {
        cert_id: {
            **dict(cert),
            "status": "HISTORICAL_EVIDENCE",
            "inherited_from": {"case_id": case_id, "case_version": parent_ordinal},
            "reuse_condition": (
                "16.5: reusable only after dependency-aware revalidation on this branch"
            ),
        }
        for cert_id, cert in inherited.items()
    }
    record = BranchRecord(
        branch_id=name,
        case_id=branch_case_id,
        parent_case=case_id,
        parent_version=parent_ordinal,
        parent_content_hash=parent_hash,
        branch_point=parent_hash,
        purpose=purpose,
        creator=creator,
        access_policy=access_policy or str(parent.get("access_policy") or "inherited"),
        intended_decision_scope=intended_decision_scope
        or str((parent.get("scope") or {}).get("scope_id") or "undeclared"),
        expected_reconciliation=expected_reconciliation,
    )
    child["branch_record"] = record.to_canonical()
    child.setdefault("history", []).append(
        {"command": "branch", "from": case_id, "at": record.created_at}
    )
    store.put_case(
        child,
        created_by=creator,
        derived_from={
            "case_id": case_id,
            "case_version": parent_ordinal,
            "content_hash": parent_hash,
            "branch_point": record.branch_point,
        },
    )
    store.put_object(record.to_canonical(), object_type="BranchRecord", created_by=creator)
    return branch_case_id


def _semantic_differences(source: Mapping[str, Any], target: Mapping[str, Any]) -> List[str]:
    differing: List[str] = []
    for field_name, description in sorted(SEMANTIC_OBJECTS.items()):
        left = source.get(field_name)
        right = target.get(field_name)
        if left is None and right is None:
            continue
        if canonical_json(left) != canonical_json(right):
            differing.append(f"{field_name} ({description})")
    return sorted(set(differing))


def _metadata_differences(case: Mapping[str, Any], base: Mapping[str, Any]) -> Set[str]:
    changed: Set[str] = set()
    for field_name in NONSEMANTIC_METADATA:
        if canonical_json(case.get(field_name)) != canonical_json(base.get(field_name)):
            changed.add(field_name)
    return changed


def merge_policy(
    source_case: Mapping[str, Any],
    target_case: Mapping[str, Any],
    *,
    base_case: Optional[Mapping[str, Any]] = None,
    registered_rules: Sequence[MergeRule] = (),
) -> MergeDecision:
    """Decide whether a merge may proceed automatically (spec 16.3, 16.4).

    Returns a decision; never performs a semantic merge.  When semantic
    objects differ the decision is ``REFUSED_SEMANTIC`` and
    :attr:`MergeDecision.required_actions` carries 16.4's list -- a new case
    version, a ``MergeDecisionRecord``, explicit conflict resolutions, a
    dependency diff, a change classification, invalidation of affected
    certificates, and re-verification or reissuance of preserved claims -- so
    the caller receives the procedure rather than only the refusal.
    """
    source_id = str(source_case.get("case_id") or "")
    target_id = str(target_case.get("case_id") or "")
    conflicts = tuple(_semantic_differences(source_case, target_case))
    rules = tuple(registered_rules)

    if conflicts:
        return MergeDecision(
            decision=MergeDecisionKind.REFUSED_SEMANTIC,
            automatic=False,
            semantic_conflicts=conflicts,
            source_case=source_id,
            target_case=target_id,
            rationale=(
                "16.3: CRG SHALL NOT automatically merge semantic objects. "
                f"{len(conflicts)} semantic object(s) differ between these cases."
            ),
            required_actions=(
                "create a new case version",
                "record a MergeDecisionRecord",
                "record explicit conflict resolutions",
                "record a dependency diff",
                "record a change classification",
                "invalidate affected certificates",
                "re-verify or reissue preserved claims",
            ),
            registered_rules=tuple(r.rule_id for r in rules),
        )

    if base_case is None:
        changed_without_base = tuple(sorted(_metadata_differences(source_case, target_case)))
        if changed_without_base:
            return MergeDecision(
                decision=MergeDecisionKind.MANUAL_RECONCILIATION_REQUIRED,
                automatic=False,
                nonsemantic_fields=changed_without_base,
                unregistered_fields=changed_without_base,
                source_case=source_id,
                target_case=target_id,
                rationale=(
                    "16.3 cannot prove that metadata edits are disjoint without the "
                    "common branch-point case"
                ),
                required_actions=("supply the common branch point",),
                registered_rules=tuple(r.rule_id for r in rules),
            )
        return MergeDecision(
            decision=MergeDecisionKind.NO_DIFFERENCE,
            automatic=True,
            source_case=source_id,
            target_case=target_id,
            rationale="no semantic object and no registered metadata field differs",
            registered_rules=tuple(r.rule_id for r in rules),
        )

    base = base_case
    changed_in_source = _metadata_differences(source_case, base)
    changed_in_target = _metadata_differences(target_case, base)
    overlapping = tuple(sorted(changed_in_source & changed_in_target))
    changed = tuple(sorted(changed_in_source | changed_in_target))
    unregistered = tuple(
        sorted(f for f in changed if not any(rule.covers(f) for rule in rules))
    )

    if not changed:
        return MergeDecision(
            decision=MergeDecisionKind.NO_DIFFERENCE,
            automatic=True,
            source_case=source_id,
            target_case=target_id,
            rationale="no semantic object and no registered metadata field differs",
            registered_rules=tuple(r.rule_id for r in rules),
        )

    if overlapping or unregistered:
        return MergeDecision(
            decision=MergeDecisionKind.MANUAL_RECONCILIATION_REQUIRED,
            automatic=False,
            nonsemantic_fields=changed,
            overlapping_fields=overlapping,
            unregistered_fields=unregistered,
            source_case=source_id,
            target_case=target_id,
            rationale=(
                "16.3 permits automatic merge of nonsemantic metadata only when the "
                "fields are disjoint and the merge rule is registered; "
                f"overlapping={list(overlapping)} unregistered={list(unregistered)}"
            ),
            required_actions=("record explicit conflict resolutions", "record a dependency diff"),
            registered_rules=tuple(r.rule_id for r in rules),
        )

    merged = {
        name: (source_case.get(name) if name in changed_in_source else target_case.get(name))
        for name in changed
    }
    return MergeDecision(
        decision=MergeDecisionKind.AUTOMATIC_METADATA,
        automatic=True,
        nonsemantic_fields=changed,
        source_case=source_id,
        target_case=target_id,
        merged_metadata=merged,
        rationale=(
            "16.3: the changed fields are nonsemantic, disjoint, and covered by a "
            "registered merge rule"
        ),
        registered_rules=tuple(r.rule_id for r in rules),
    )
