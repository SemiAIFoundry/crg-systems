"""Server-Sent Events over the 38.5 vocabulary: framing, filtering, resumption.

Normative basis: 38.2 (the reference server SHALL provide event streaming
through Server-Sent Events, WebSocket, **or equivalent**), 38.5 (the closed
event vocabulary and its mandatory carrier), 6.6 (fail closed).

38.2 offers three transports and requires one.  This module implements
Server-Sent Events and does not implement WebSocket, and the choice is not an
accident of convenience.  A CRG event stream is unidirectional -- the server
publishes, the subscriber listens, and there is no message a subscriber could
usefully send back over the same socket that is not already a request against
38.3 -- so the bidirectional framing of WebSocket would buy nothing and cost
a second protocol to test.  More to the point, SSE has a *resumption* story
built into the protocol: the ``id:`` field and the ``Last-Event-ID`` request
header together let a subscriber that lost its connection say exactly where
it stopped, and this bus can answer exactly that question because
:meth:`crg_server.events.EventBus.since` is an ordinal cursor over an
append-only history.  A dropped WebSocket, by contrast, leaves the gap to be
reconstructed by an application-level protocol somebody would have to invent.
Resumption is the property an integrator's audit trail depends on, so the
transport that has it wins.  A deployment that needs WebSocket can drive
:class:`EventStream` from its own socket loop; what it would be adding is a
framing layer, not semantics.

Three design decisions are worth the reader's time.

**The stream is an iterable of framed byte chunks, not a socket.**
:class:`crg_server.app.Response` is synchronous and returns bytes, and it
stays that way: a streaming response carries an :class:`EventStream` beside
its body, ``make_handler`` writes and flushes each chunk as it arrives, and a
test pulls the same chunks deterministically without opening a port.  This
means the assertions in the test suite are about *framing bytes* -- the exact
``id:``/``event:``/``data:`` records an integrator's ``EventSource`` will
parse -- rather than about a Python object that a transport might yet render
differently.

**Event identifiers are bus ordinals, not per-stream sequence numbers.**  A
filtered stream still numbers its records with the position of the event in
the global history, so ``Last-Event-ID: 7`` means "I have seen everything up
to and including the seventh event", and the server resumes with
``since(7)``.  Numbering a filtered stream 1, 2, 3 would be prettier and
would make resumption wrong the moment the filter changed or an unmatched
event landed in between: the subscriber would ask to resume from *its* third
record and the server would have no way to map that onto the history.

**An event name the vocabulary does not contain is refused at subscription.**
38.5 fixes a closed list.  A subscriber that asks to filter on
``decision.approved`` has either misread the specification or is written
against a different one, and silently returning an empty stream would let
that mistake run in production for as long as nothing interesting happened.
It is a 400 with the vocabulary attached (6.6).
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Iterator, List, Mapping, Optional, Tuple

from crg_model.canonical import canonical_json

from .errors import UsageError
from .events import EVENT_VOCABULARY, Event, EventBus

__all__ = [
    "SSE_CONTENT_TYPE",
    "SSE_HEADERS",
    "SSE_KEEPALIVE",
    "DEFAULT_RETRY_MS",
    "DEFAULT_HEARTBEAT_SECONDS",
    "EventFilter",
    "EventStream",
    "sse_frame",
    "sse_comment",
    "parse_event_names",
    "parse_last_event_id",
    "build_event_stream",
]

#: 38.2.  SSE is defined to be UTF-8, so no charset parameter is emitted; a
#: receiver that guessed anything else would already be non-conforming.
SSE_CONTENT_TYPE = "text/event-stream"

#: The headers a streaming response must carry to survive the middleboxes a
#: real deployment sits behind.  ``no-cache`` stops a proxy replaying a stale
#: prefix; ``X-Accel-Buffering: no`` stops nginx holding chunks until its
#: buffer fills, which turns a live stream into a batch delivered minutes
#: late; ``keep-alive`` says the connection is meant to stay open.
SSE_HEADERS: Dict[str, str] = {
    "Cache-Control": "no-cache",
    "Connection": "keep-alive",
    "X-Accel-Buffering": "no",
}

#: A comment line.  The SSE grammar ignores a record whose first character is
#: a colon, which is how a server proves the connection is alive without
#: inventing a heartbeat event that 38.5's closed vocabulary does not contain.
SSE_KEEPALIVE = b": keepalive\n\n"

#: How long a disconnected subscriber should wait before reconnecting, in
#: milliseconds.  Sent once, as the first record, so the value is on the wire
#: before anything can go wrong rather than after.
DEFAULT_RETRY_MS = 3000

#: Seconds of silence after which a keepalive comment is emitted.
DEFAULT_HEARTBEAT_SECONDS = 15


# ---------------------------------------------------------------------------
# framing (the SSE wire format)
# ---------------------------------------------------------------------------
def sse_frame(
    data: str,
    *,
    event: Optional[str] = None,
    event_id: Optional[str] = None,
    retry_ms: Optional[int] = None,
) -> bytes:
    """One SSE record, terminated by the blank line the grammar requires.

    ``data`` is split on newlines and each line is emitted as its own
    ``data:`` field, because a raw newline inside a field value would end the
    field and a second newline would end the *record*.  A payload that
    happens to contain a line break must not be able to truncate the stream.
    """
    lines: List[str] = []
    if event_id is not None:
        lines.append(f"id: {event_id}")
    if event is not None:
        lines.append(f"event: {event}")
    if retry_ms is not None:
        lines.append(f"retry: {int(retry_ms)}")
    for line in data.split("\n"):
        lines.append(f"data: {line}")
    return ("\n".join(lines) + "\n\n").encode("utf-8")


def sse_comment(text: str) -> bytes:
    """A comment record.  Every line is prefixed with ``:`` and ignored."""
    body = "\n".join(f": {line}" for line in text.split("\n"))
    return (body + "\n\n").encode("utf-8")


def _retry_preamble(retry_ms: int) -> bytes:
    return (f"retry: {int(retry_ms)}\n\n").encode("utf-8")


# ---------------------------------------------------------------------------
# filtering (38.5's vocabulary is closed, so a filter over it is closed too)
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class EventFilter:
    """Which events a subscriber asked for.  Empty means "everything".

    Validated on construction rather than on match: a filter naming a name
    outside :data:`crg_server.events.EVENT_VOCABULARY` is refused when the
    subscription is made, so the subscriber learns at connect time instead of
    inferring it from an empty stream (6.6).
    """

    names: Tuple[str, ...] = ()
    case_id: Optional[str] = None
    branch_id: Optional[str] = None

    def __post_init__(self) -> None:
        unknown = [name for name in self.names if name not in EVENT_VOCABULARY]
        if unknown:
            raise UsageError(
                f"unknown event name(s) {unknown} in the stream filter",
                remedy=(
                    "38.5 fixes a closed event vocabulary; filter on one of "
                    f"{list(EVENT_VOCABULARY)}"
                ),
                detail={"unknown": unknown, "vocabulary": list(EVENT_VOCABULARY)},
            )
        object.__setattr__(self, "names", tuple(self.names))

    def matches(self, event: Event) -> bool:
        if self.names and event.event not in self.names:
            return False
        if self.case_id is not None and event.case_id != self.case_id:
            return False
        if self.branch_id is not None and event.branch_id != self.branch_id:
            return False
        return True

    def describe(self) -> Dict[str, Any]:
        return {
            "names": list(self.names) or list(EVENT_VOCABULARY),
            "case_id": self.case_id,
            "branch_id": self.branch_id,
        }


def parse_event_names(raw: Optional[str]) -> Tuple[str, ...]:
    """``"case.created,decision.certified"`` -> a validated tuple."""
    if not raw:
        return ()
    return tuple(part.strip() for part in str(raw).split(",") if part.strip())


def parse_last_event_id(
    headers: Mapping[str, str], query: Mapping[str, str]
) -> int:
    """Where to resume from (38.2).

    The ``Last-Event-ID`` header is what a browser ``EventSource`` sends by
    itself, so it wins; ``?since=`` exists for a client that is reconnecting
    deliberately rather than being reconnected by its runtime.  A value that
    is not a non-negative integer is refused rather than rounded down to
    zero, because replaying the whole history to a subscriber that asked for
    a resumption is a silent duplicate delivery (6.6).
    """
    raw = headers.get("last-event-id")
    if raw is None:
        raw = headers.get("Last-Event-ID")
    if raw is None:
        raw = query.get("since")
    if raw is None or str(raw).strip() == "":
        return 0
    text = str(raw).strip()
    if not text.isdigit():
        raise UsageError(
            f"Last-Event-ID {text!r} is not an event ordinal",
            remedy=(
                "this stream numbers records with the ordinal of the event in the "
                "server's history; resume with the id of the last record received"
            ),
        )
    return int(text)


# ---------------------------------------------------------------------------
# the stream
# ---------------------------------------------------------------------------
@dataclass
class EventStream:
    """A resumable, filtered SSE view of an :class:`EventBus`.

    Iterating yields framed byte chunks.  Iteration is *repeatable*: every
    call to :meth:`frames` starts a fresh cursor at ``last_event_id``, so a
    handler can take a deterministic :meth:`snapshot` of what is already
    available for an in-process caller and still hand the live iterator to a
    socket, and the two see the same prefix.

    Nothing in the follow loop sleeps by itself.  ``idle`` is called when the
    bus has produced nothing, ``clock`` decides when a keepalive is due, and
    ``stop`` decides when to hang up.  A test supplies all three and gets a
    deterministic pull; the reference handler supplies a short
    :func:`time.sleep` and a socket-liveness check.
    """

    bus: EventBus
    filter: EventFilter = field(default_factory=EventFilter)
    last_event_id: int = 0
    retry_ms: int = DEFAULT_RETRY_MS
    heartbeat_seconds: int = DEFAULT_HEARTBEAT_SECONDS
    follow: bool = True
    clock: Callable[[], float] = time.monotonic
    idle: Callable[[], None] = lambda: time.sleep(0.05)
    stop: Callable[[], bool] = lambda: False

    # -- iteration ---------------------------------------------------------
    def frames(
        self, *, follow: Optional[bool] = None, limit: Optional[int] = None
    ) -> Iterator[bytes]:
        """Yield framed chunks from ``last_event_id`` onwards.

        ``limit`` bounds the number of *event* records (not keepalives) and
        exists so that a test can pull a finite prefix of an endless stream
        without a timeout deciding when the test ends.
        """
        following = self.follow if follow is None else follow
        yield _retry_preamble(self.retry_ms)
        cursor = int(self.last_event_id)
        delivered = 0
        quiet_since = self.clock()
        while True:
            pending = self.bus.since(cursor)
            if pending:
                for event in pending:
                    cursor += 1
                    if not self.filter.matches(event):
                        continue
                    yield self.frame_for(event, cursor)
                    delivered += 1
                    quiet_since = self.clock()
                    if limit is not None and delivered >= limit:
                        return
                continue
            if not following:
                return
            if self.stop():
                return
            now = self.clock()
            if now - quiet_since >= self.heartbeat_seconds:
                quiet_since = now
                yield SSE_KEEPALIVE
            self.idle()

    def __iter__(self) -> Iterator[bytes]:
        return self.frames()

    def snapshot(self, *, limit: Optional[int] = None) -> bytes:
        """Everything available right now, framed, with no live tail.

        This is what an in-process ``dispatch`` returns as the response body:
        a caller that is not holding a socket still gets well-formed SSE
        bytes rather than an empty body and a promise.
        """
        return b"".join(self.frames(follow=False, limit=limit))

    # -- one record --------------------------------------------------------
    def frame_for(self, event: Event, ordinal: int) -> bytes:
        """Frame one event.  ``data`` is the canonical JSON of 38.5's carrier.

        Canonical (14.3) rather than ``json.dumps`` so that two deployments
        streaming the same event put the same bytes on the wire, and so that
        a subscriber may hash what it received and compare it with what the
        audit log recorded.
        """
        return sse_frame(
            canonical_json(event.to_canonical()),
            event=event.event,
            event_id=str(ordinal),
        )

    # -- description -------------------------------------------------------
    def describe(self) -> Dict[str, Any]:
        return {
            "transport": "server-sent-events",
            "spec": "38.2, 38.5",
            "retry_ms": self.retry_ms,
            "heartbeat_seconds": self.heartbeat_seconds,
            "resume_from": self.last_event_id,
            "filter": self.filter.describe(),
        }


def build_event_stream(
    bus: EventBus,
    *,
    query: Optional[Mapping[str, str]] = None,
    headers: Optional[Mapping[str, str]] = None,
    case_id: Optional[str] = None,
    **overrides: Any,
) -> EventStream:
    """Build a stream from a decoded request (38.2).

    ``case_id`` from the route wins over ``?case_id=``: a scoped route that
    could be widened by a query parameter would be a scope the deployment's
    authorization table never saw (44.3).
    """
    query = dict(query or {})
    headers = {str(k).lower(): str(v) for k, v in dict(headers or {}).items()}
    scoped = case_id if case_id is not None else (query.get("case_id") or None)
    event_filter = EventFilter(
        names=parse_event_names(query.get("event") or query.get("events")),
        case_id=scoped,
        branch_id=query.get("branch_id") or None,
    )
    follow = str(query.get("follow", "true")).lower() not in {"0", "false", "no"}
    stream = EventStream(
        bus=bus,
        filter=event_filter,
        last_event_id=parse_last_event_id(headers, query),
        follow=follow,
    )
    for name, value in overrides.items():
        setattr(stream, name, value)
    return stream
