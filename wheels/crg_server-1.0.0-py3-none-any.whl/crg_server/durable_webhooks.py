"""Restart-safe webhook delivery sourced from the immutable audit sequence.

The in-memory dispatcher defines payload and retry semantics.  This module is
the deployment carrier: every attempt is appended to the same durable audit
log as its source event, and a delivery ID is derived from source sequence,
event hash, and subscription ID.  A crash therefore causes an idempotent
replay with the same receiver-visible ID rather than an untraceable duplicate.
Secrets are supplied at startup through named environment variables and are
never serialized into state or audit records.
"""
from __future__ import annotations

import hashlib
import json
import os
import time
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
from typing import Any, Callable, Dict, List, Mapping, Optional, Sequence, Tuple
from urllib.parse import urlsplit

from crg_model.canonical import canonical_json, content_hash

from .errors import UsageError
from .events import EVENT_VOCABULARY, Event, webhook_payload
from .webhooks import (
    DeliveryOutcome,
    TransportResponse,
    WebhookSubscription,
    WebhookTransportError,
    backoff_delay,
    urllib_transport,
)

__all__ = ["DurableWebhookPump", "load_webhook_subscriptions"]


def _epoch_fraction() -> Fraction:
    return Fraction(time.time_ns(), 1_000_000_000)


def _delivery_id(source_seq: int, event_hash: str, subscription_id: str) -> str:
    payload = canonical_json({
        "profile": "CRG-DURABLE-WEBHOOK-V1",
        "source_audit_seq": int(source_seq),
        "event_hash": event_hash,
        "subscription_id": subscription_id,
    }).encode("utf-8")
    return "delivery-" + hashlib.sha256(payload).hexdigest()


def load_webhook_subscriptions(
    path: str,
    *,
    environ: Optional[Mapping[str, str]] = None,
) -> Tuple[WebhookSubscription, ...]:
    """Load operator-owned endpoints while resolving secrets only from env."""
    source = Path(path)
    try:
        document = json.loads(source.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise UsageError(f"cannot load webhook configuration {source}: {error}") from error
    if document.get("profile") != "CRG-WEBHOOK-CONFIG-V1":
        raise UsageError("webhook configuration profile must be CRG-WEBHOOK-CONFIG-V1")
    environment = os.environ if environ is None else environ
    subscriptions: List[WebhookSubscription] = []
    seen = set()
    for raw in document.get("subscriptions") or ():
        identifier = str(raw.get("subscription_id") or "").strip()
        endpoint = str(raw.get("endpoint") or "").strip()
        secret_env = str(raw.get("secret_env") or "").strip()
        if not identifier or identifier in seen:
            raise UsageError("webhook subscription IDs must be nonempty and unique")
        seen.add(identifier)
        parsed = urlsplit(endpoint)
        if parsed.scheme != "https" or not parsed.hostname:
            raise UsageError(
                f"webhook {identifier!r} must use an absolute HTTPS endpoint"
            )
        if not secret_env or secret_env not in environment:
            raise UsageError(
                f"webhook {identifier!r} secret environment variable is unavailable"
            )
        secret = str(environment[secret_env]).encode("utf-8")
        if len(secret) < 32:
            raise UsageError(f"webhook {identifier!r} secret must be at least 32 bytes")
        events = tuple(str(value) for value in (raw.get("events") or ()))
        unknown = sorted(set(events) - set(EVENT_VOCABULARY))
        if unknown:
            raise UsageError(f"webhook {identifier!r} names unknown events {unknown}")
        subscriptions.append(WebhookSubscription(
            subscription_id=identifier,
            endpoint=endpoint,
            secret=secret,
            events=events,
            enabled=bool(raw.get("enabled", True)),
            max_attempts=int(raw.get("max_attempts", 5)),
            base_delay=Fraction(str(raw.get("base_delay_seconds", "1"))),
            backoff_factor=Fraction(str(raw.get("backoff_factor", "2"))),
            max_delay=Fraction(str(raw.get("max_delay_seconds", "60"))),
            created_by=str(raw.get("created_by") or "deployment-config"),
        ))
        candidate = subscriptions[-1]
        if candidate.max_attempts < 1:
            raise UsageError(f"webhook {identifier!r} max_attempts must be at least 1")
        if candidate.base_delay <= 0 or candidate.backoff_factor < 1 or candidate.max_delay <= 0:
            raise UsageError(f"webhook {identifier!r} retry schedule is not positive")
    return tuple(subscriptions)


@dataclass
class DurableWebhookPump:
    store: Any
    subscriptions: Sequence[WebhookSubscription]
    transport: Callable[..., TransportResponse] = urllib_transport
    clock: Callable[[], Fraction] = _epoch_fraction
    jitter: Callable[[], Fraction] = lambda: Fraction(0)
    worker_id: str = "webhook-worker"
    claim: Optional[Callable[[str, str], bool]] = None
    release: Optional[Callable[[str, str], bool]] = None

    def _attempts(self, delivery_id: str) -> List[Dict[str, Any]]:
        return [
            dict(row["event"])
            for row in self.store.audit_records()
            if row["event"].get("record_type") == "WebhookDeliveryAttempt"
            and row["event"].get("delivery_id") == delivery_id
        ]

    @staticmethod
    def _event(record: Mapping[str, Any]) -> Optional[Event]:
        if record.get("event") not in EVENT_VOCABULARY:
            return None
        try:
            return Event(
                event=str(record["event"]), case_id=record.get("case_id"),
                branch_id=record.get("branch_id"),
                object_hashes=tuple(record.get("object_hashes") or ()),
                timestamp=str(record["timestamp"]), actor=str(record["actor"]),
                correlation_id=str(record["correlation_id"]),
                schema_version=str(record.get("schema_version") or "0.2.0"),
                detail=dict(record.get("detail") or {}),
            )
        except (KeyError, TypeError, UsageError):
            return None

    def pump(self, *, limit: Optional[int] = None) -> Tuple[Dict[str, Any], ...]:
        """Make at most one due attempt per source-event/subscription pair."""
        emitted: List[Dict[str, Any]] = []
        for source in self.store.audit_records():
            event = self._event(source["event"])
            if event is None:
                continue
            for subscription in sorted(self.subscriptions, key=lambda value: value.subscription_id):
                if not subscription.matches(event):
                    continue
                if limit is not None and len(emitted) >= int(limit):
                    return tuple(emitted)
                identifier = _delivery_id(
                    int(source["seq"]), event.event_hash(), subscription.subscription_id
                )
                claim_key = f"webhook:{identifier}"
                if self.claim is not None and not self.claim(claim_key, self.worker_id):
                    continue
                try:
                    attempts = self._attempts(identifier)
                    if attempts and attempts[-1].get("outcome") in DeliveryOutcome.TERMINAL:
                        continue
                    now = Fraction(self.clock())
                    if attempts:
                        next_text = attempts[-1].get("next_attempt_at_epoch_seconds")
                        if next_text is not None and Fraction(str(next_text)) > now:
                            continue
                    number = len(attempts) + 1
                    payload = webhook_payload(
                        event, endpoint=subscription.endpoint,
                        secret=subscription.secret, delivery_id=identifier,
                    )
                    started = Fraction(self.clock())
                    status: Optional[int] = None
                    transport_error: Optional[str] = None
                    response_prefix = ""
                    try:
                        response = self.transport(
                            subscription.endpoint, payload["headers"], payload["body_bytes"]
                        )
                        status = int(response.status)
                        response_prefix = bytes(response.body or b"")[:200].decode(
                            "utf-8", "replace"
                        )
                    except WebhookTransportError as error:
                        transport_error = str(error)
                    except Exception as error:  # noqa: BLE001 - injected transport is untrusted
                        transport_error = f"{type(error).__name__}: {error}"
                    finished = Fraction(self.clock())
                    accepted = status is not None and 200 <= status < 300
                    next_at: Optional[Fraction] = None
                    if accepted:
                        outcome = DeliveryOutcome.DELIVERED
                    elif number >= subscription.max_attempts:
                        outcome = DeliveryOutcome.DEAD_LETTER
                    else:
                        outcome = DeliveryOutcome.RETRY_SCHEDULED
                        next_at = now + backoff_delay(
                            number, base=subscription.base_delay,
                            factor=subscription.backoff_factor,
                            maximum=subscription.max_delay,
                            jitter=Fraction(self.jitter()),
                        )
                    record: Dict[str, Any] = {
                        "record_type": "WebhookDeliveryAttempt",
                        "delivery_id": identifier,
                        "subscription_id": subscription.subscription_id,
                        "source_audit_seq": int(source["seq"]),
                        "event_name": event.event,
                        "event_hash": event.event_hash(),
                        "attempt": number,
                        "max_attempts": subscription.max_attempts,
                        "scheduled_at_epoch_seconds": str(now),
                        "attempted_at_epoch_seconds": str(started),
                        "duration_seconds": str(finished - started),
                        "http_status": status,
                        "transport_error": transport_error,
                        "response_body_prefix": response_prefix,
                        "outcome": outcome,
                        "next_attempt_at_epoch_seconds": (
                            None if next_at is None else str(next_at)
                        ),
                    }
                    record["content_hash"] = content_hash(record)
                    self.store.append_audit(record)
                    emitted.append(record)
                finally:
                    if self.release is not None and self.claim is not None:
                        if not self.release(claim_key, self.worker_id):
                            raise UsageError(
                                f"store did not release webhook claim {claim_key!r}"
                            )
        return tuple(emitted)
