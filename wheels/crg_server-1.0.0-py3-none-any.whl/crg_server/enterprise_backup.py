"""Verified logical backup and restore for the 42.3 application store."""
from __future__ import annotations

import hashlib
import json
import shutil
import tarfile
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional

from crg_model.canonical import canonical_json
from crg_model.envelope import utc_now

from .backends import (
    ApplicationStore,
    CaseVersionRecord,
    CertificateRecord,
    EdgeRecord,
    IdempotencyRecord,
    JobRecord,
    TombstoneRecord,
)

FORMAT = "crg-enterprise-logical-backup-v1"
MAX_ARCHIVE_MEMBERS = 100_000
MAX_EXPANDED_BYTES = 512 * 1024 * 1024 * 1024
MAX_METADATA_BYTES = 512 * 1024 * 1024


def _sha(payload: bytes) -> str:
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def _file_sha(path: Path) -> str:
    hasher = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            hasher.update(chunk)
    return "sha256:" + hasher.hexdigest()


def _member_path(root: Path, relative: str) -> Path:
    candidate = (root / relative).resolve()
    if root.resolve() not in candidate.parents:
        raise ValueError(f"backup manifest path escapes root: {relative!r}")
    return candidate


def _empty(store: ApplicationStore) -> bool:
    metadata = store.metadata
    return not any((
        store.objects.list_digests(),
        metadata.list_case_ids(),
        metadata.list_jobs(),
        metadata.list_idempotency(),
        metadata.read_audit(),
        metadata.list_tombstones(),
    ))


def create_enterprise_backup(store: ApplicationStore, output: str) -> Dict[str, Any]:
    """Write a hash-verified logical snapshot without database/vendor tooling."""
    target = Path(output).expanduser().resolve()
    if target.exists():
        raise ValueError(f"backup output {target!s} already exists")
    integrity = store.scan_integrity()
    if not integrity["ok"]:
        raise ValueError("refusing to back up an enterprise store that fails integrity")
    metadata = store.metadata
    case_ids = metadata.list_case_ids()
    case_versions = [
        record.to_canonical()
        for case_id in case_ids
        for record in metadata.list_case_versions(case_id)
    ]
    edge_map: Dict[str, Dict[str, Any]] = {}
    for case_id in [""] + case_ids:
        for record in metadata.edges_for_case(case_id):
            edge_map[record.edge_id] = record.to_canonical()
    document = {
        "case_versions": case_versions,
        "edges": [edge_map[key] for key in sorted(edge_map)],
        "certificates": [
            record.to_canonical()
            for case_id in case_ids
            for record in metadata.list_certificates(case_id)
        ],
        "idempotency": [record.to_canonical() for record in metadata.list_idempotency()],
        "jobs": [record.to_canonical() for record in metadata.list_jobs()],
        "audit": [record.to_canonical() for record in metadata.read_audit()],
        "tombstones": [record.to_canonical() for record in metadata.list_tombstones()],
    }
    with tempfile.TemporaryDirectory(prefix="crg-enterprise-backup-") as temporary:
        stage = Path(temporary) / "backup"
        objects = stage / "objects"
        objects.mkdir(parents=True)
        object_entries: List[Dict[str, Any]] = []
        for digest in store.objects.list_digests():
            payload = store.objects.get_content(digest)
            record = store.objects.content_metadata(digest).to_canonical()
            name = digest.split(":", 1)[1] + ".json"
            (objects / name).write_bytes(payload)
            object_entries.append({
                **record, "path": f"objects/{name}",
                "payload_sha256": _sha(payload), "payload_length": len(payload),
            })
        metadata_bytes = canonical_json(document).encode("utf-8")
        (stage / "metadata.json").write_bytes(metadata_bytes)
        manifest = {
            "format": FORMAT,
            "created_at": utc_now(),
            "tenant_id": store.tenant_id,
            "database_schema_version": store.database_schema_version(),
            "objects": object_entries,
            "metadata_path": "metadata.json",
            "metadata_sha256": _sha(metadata_bytes),
            "metadata_length": len(metadata_bytes),
            "integrity_scan": integrity,
            "consistency": store.backend.consistency().to_canonical(),
            "restore_semantics": {
                "target_must_be_empty": True,
                "audit_order_preserved": True,
                "audit_sequence_numbers_reassigned_by_target": True,
                "storage_ingest_timestamps_reassigned": True,
            },
        }
        (stage / "backup-manifest.json").write_text(
            canonical_json(manifest) + "\n", encoding="utf-8"
        )
        target.parent.mkdir(parents=True, exist_ok=True)
        with tarfile.open(target, "x:gz") as archive:
            archive.add(stage, arcname="backup", recursive=True)
    return {
        **manifest,
        "output": str(target),
        "archive_sha256": _file_sha(target),
    }


def _extract(archive: Path, stage: Path) -> Path:
    with tarfile.open(archive, "r:gz") as source:
        members = source.getmembers()
        if len(members) > MAX_ARCHIVE_MEMBERS:
            raise ValueError(f"backup has {len(members)} members; limit is {MAX_ARCHIVE_MEMBERS}")
        expanded = sum(max(0, int(member.size)) for member in members)
        if expanded > MAX_EXPANDED_BYTES:
            raise ValueError(f"backup expands to {expanded} bytes; limit is {MAX_EXPANDED_BYTES}")
        for member in members:
            if member.issym() or member.islnk() or not (member.isfile() or member.isdir()):
                raise ValueError(f"unsupported backup member {member.name!r}")
            destination = (stage / member.name).resolve()
            if stage.resolve() not in destination.parents and destination != stage.resolve():
                raise ValueError(f"backup member escapes extraction root: {member.name!r}")
            if member.isdir():
                destination.mkdir(parents=True, exist_ok=True)
            else:
                destination.parent.mkdir(parents=True, exist_ok=True)
                handle = source.extractfile(member)
                if handle is None:
                    raise ValueError(f"cannot read backup member {member.name!r}")
                with handle, destination.open("xb") as output:
                    shutil.copyfileobj(handle, output)
    return stage / "backup"


def restore_enterprise_backup(
    archive: str, store: ApplicationStore, *, expected_tenant: Optional[str] = None
) -> Dict[str, Any]:
    """Restore into an empty backend, verifying every byte before the first write."""
    source = Path(archive).expanduser().resolve()
    if not source.is_file():
        raise ValueError(f"no backup archive at {source!s}")
    if not _empty(store):
        raise ValueError("enterprise restore target must be empty")
    with tempfile.TemporaryDirectory(prefix="crg-enterprise-restore-") as temporary:
        root = _extract(source, Path(temporary))
        manifest = json.loads((root / "backup-manifest.json").read_text(encoding="utf-8"))
        if manifest.get("format") != FORMAT:
            raise ValueError("enterprise backup format is unsupported")
        tenant = str(manifest.get("tenant_id") or "")
        required_tenant = expected_tenant if expected_tenant is not None else store.tenant_id
        if required_tenant and tenant != required_tenant:
            raise ValueError(
                f"backup tenant {tenant!r} does not match restore tenant {required_tenant!r}"
            )
        source_schema = int(manifest.get("database_schema_version") or 0)
        target_schema = store.database_schema_version()
        if source_schema and target_schema and source_schema != target_schema:
            raise ValueError(
                f"backup database schema {source_schema} does not match target {target_schema}"
            )
        metadata_path = _member_path(root, str(manifest["metadata_path"]))
        if int(manifest["metadata_length"]) > MAX_METADATA_BYTES:
            raise ValueError(
                f"enterprise backup metadata exceeds {MAX_METADATA_BYTES} bytes"
            )
        metadata_bytes = metadata_path.read_bytes()
        if len(metadata_bytes) != int(manifest["metadata_length"]):
            raise ValueError("enterprise backup metadata length mismatch")
        if _sha(metadata_bytes) != manifest["metadata_sha256"]:
            raise ValueError("enterprise backup metadata hash mismatch")
        object_entries: List[Mapping[str, Any]] = []
        listed_paths = {"backup-manifest.json", str(manifest["metadata_path"])}
        for entry in manifest.get("objects") or ():
            relative = str(entry["path"])
            if relative in listed_paths:
                raise ValueError(f"duplicate backup manifest path {relative!r}")
            listed_paths.add(relative)
            payload = _member_path(root, relative).read_bytes()
            if len(payload) != int(entry["payload_length"]):
                raise ValueError(f"backup object length mismatch: {entry['content_hash']}")
            if _sha(payload) != entry["payload_sha256"] or _sha(payload) != entry["content_hash"]:
                raise ValueError(f"backup object hash mismatch: {entry['content_hash']}")
            object_entries.append(entry)
        actual_paths = {
            path.relative_to(root).as_posix()
            for path in root.rglob("*") if path.is_file()
        }
        if actual_paths != listed_paths:
            raise ValueError(
                "backup member inventory differs from its manifest: "
                f"extra={sorted(actual_paths - listed_paths)}, "
                f"missing={sorted(listed_paths - actual_paths)}"
            )
        document = json.loads(metadata_bytes.decode("utf-8"))

        # Second pass: the entire archive has already verified, so writes can
        # begin without retaining every protected object in memory.
        for entry in object_entries:
            payload = _member_path(root, str(entry["path"])).read_bytes()
            store.objects.put_content(
                str(entry["content_hash"]), payload,
                object_type=str(entry.get("object_type") or "OpaqueRecord"),
                created_by=str(entry.get("created_by") or "backup-restore"),
                legal_hold=bool(entry.get("legal_hold")),
            )
            status = str(entry.get("status") or "ACTIVE")
            if status != "ACTIVE" or entry.get("status_reason"):
                store.objects.set_content_status(
                    str(entry["content_hash"]), status,
                    reason=str(entry.get("status_reason") or ""),
                )

        metadata = store.metadata
        with metadata.transaction():
            for value in document.get("case_versions") or ():
                metadata.put_case_version(CaseVersionRecord(**value))
            for value in document.get("edges") or ():
                metadata.record_edge(EdgeRecord(**value))
            for value in document.get("certificates") or ():
                metadata.register_certificate(CertificateRecord(**value))
            for value in document.get("idempotency") or ():
                metadata.idempotency_record(IdempotencyRecord(**value))
            for value in document.get("jobs") or ():
                metadata.save_job(JobRecord(**value))
            for value in document.get("tombstones") or ():
                metadata.put_tombstone(TombstoneRecord(
                    content_hash=str(value["content_hash"]),
                    object_id=str(value["object_id"]),
                    object_type=str(value["object_type"]),
                    reason=str(value["removal_reason"]),
                    authority=str(value["removal_authority"]),
                    removed_at=str(value["removal_time"]),
                    legal_hold=bool(value.get("legal_hold")),
                    permitted_disclosure=str(value.get("permitted_disclosure") or "none"),
                    dependency_edges_json=str(value.get("dependency_edges_json") or "[]"),
                ))
            for value in document.get("audit") or ():
                metadata.append_audit(str(value["recorded_at"]), str(value["event_json"]))
    integrity = store.scan_integrity()
    if not integrity["ok"]:
        raise ValueError("restored enterprise store failed its integrity scan")
    return {
        "ok": True,
        "tenant_id": store.tenant_id,
        "integrity_scan": integrity,
        "objects_restored": len(object_entries),
        "case_versions_restored": len(document.get("case_versions") or ()),
        "audit_events_restored": len(document.get("audit") or ()),
        "restored_at": utc_now(),
    }
