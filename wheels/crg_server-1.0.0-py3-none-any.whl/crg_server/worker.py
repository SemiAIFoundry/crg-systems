"""``crg-worker`` -- durable out-of-process execution for the 42.3 profile."""
from __future__ import annotations

import argparse
import os
import signal
import sys
import time
from pathlib import Path
from typing import Any, List, Optional

from crg_model.envelope import new_object_id, utc_now

from .app import JOB_BODIES
from .backends import ApplicationStore, BackendError, backend_config_from_env, select_backend
from .durable_webhooks import DurableWebhookPump, load_webhook_subscriptions
from .errors import UsageError
from .events import EventBus
from .jobs import JobQueue
from .store import CaseStore
from .deployment import load_at_rest_codec


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="crg-worker", description="Run persisted CRG jobs outside the HTTP process"
    )
    parser.add_argument("--root", default=".crg-server")
    parser.add_argument("--storage-backend", choices=("local", "environment"),
                        default="environment")
    parser.add_argument(
        "--security-config",
        help="required for local storage; supplies the AES-256-GCM key by environment name",
    )
    parser.add_argument("--poll-seconds", type=float, default=1.0)
    parser.add_argument("--heartbeat-seconds", type=float, default=10.0)
    parser.add_argument("--once", action="store_true",
                        help="refresh and drain once, then exit")
    parser.add_argument(
        "--webhook-config",
        help="CRG-WEBHOOK-CONFIG-V1 JSON; secrets are resolved from named env vars",
    )
    return parser


def _open_store(args: argparse.Namespace) -> Any:
    if args.storage_backend == "local":
        if not args.security_config:
            raise ValueError("local external workers require --security-config")
        return CaseStore(
            args.root,
            object_codec=load_at_rest_codec(args.security_config),
            require_encryption=True,
        )
    config = backend_config_from_env()
    tenant_id = str(config.get("tenant_id") or "")
    if not tenant_id:
        raise ValueError("CRG_STORE_TENANT is required for an external worker")
    backend = select_backend(config)
    return ApplicationStore(backend, root_label="external-worker", tenant_id=tenant_id)


def _local_lock(store: CaseStore) -> Any:
    try:
        import fcntl
    except ImportError as error:  # pragma: no cover - Unix production profiles
        raise RuntimeError("local external-worker locking requires fcntl") from error
    path = Path(store.root) / "worker.lock"
    handle = path.open("a+", encoding="utf-8")
    try:
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError as error:
        handle.close()
        raise RuntimeError("another local CRG worker holds the deployment lease") from error
    return handle


def main(argv: Optional[List[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    if args.poll_seconds <= 0 or args.poll_seconds > 60:
        print("crg-worker: --poll-seconds must be in (0, 60]", file=sys.stderr)
        return 2
    if args.heartbeat_seconds <= 0 or args.heartbeat_seconds > 60:
        print("crg-worker: --heartbeat-seconds must be in (0, 60]", file=sys.stderr)
        return 2
    try:
        store = _open_store(args)
    except (BackendError, ValueError, RuntimeError) as error:
        print(f"crg-worker: configuration refused: {error}", file=sys.stderr)
        return 2

    worker_id = new_object_id("worker")
    local_handle = None
    try:
        if isinstance(store, CaseStore):
            local_handle = _local_lock(store)
        queue = JobQueue(
            store,
            autorun=False,
            # The local profile has an exclusive process lock, so it can
            # recover every RUNNING record at startup. Enterprise recovery is
            # per job and happens only after acquiring that job's PostgreSQL
            # session claim.
            recover_interrupted=isinstance(store, CaseStore),
            events=EventBus(store),
            isolate_bodies=True,
            # Bundle import intentionally owns a storage transaction inside
            # its body. All compute kernels are pure and receive no store
            # handle in the isolated child.
            in_process_kinds=("importBundle",),
        )
        for kind, body in JOB_BODIES.items():
            queue.register(kind, body)
        webhook_pump = None
        if args.webhook_config:
            subscriptions = load_webhook_subscriptions(args.webhook_config)
            webhook_pump = DurableWebhookPump(
                store=store,
                subscriptions=subscriptions,
                worker_id=worker_id,
                claim=(None if isinstance(store, CaseStore) else store.acquire_job_lock),
                release=(None if isinstance(store, CaseStore) else store.release_job_lock),
            )
        stopping = False

        def stop(_signum: int, _frame: Any) -> None:
            nonlocal stopping
            stopping = True
            queue.begin_drain()

        signal.signal(signal.SIGTERM, stop)
        signal.signal(signal.SIGINT, stop)
        mode = "exclusive local lease" if isinstance(store, CaseStore) else "per-job claims"
        print(f"crg-worker {worker_id} started with {mode}")
        last_heartbeat = float("-inf")

        def heartbeat_if_due() -> None:
            nonlocal last_heartbeat
            moment = time.monotonic()
            if moment - last_heartbeat < args.heartbeat_seconds:
                return
            store.append_audit({
                "record_type": "WorkerHeartbeat",
                "event": "worker.heartbeat",
                "worker_id": worker_id,
                "timestamp": utc_now(),
                "execution_mode": mode,
                "tenant_id": str(getattr(store, "tenant_id", "") or ""),
            })
            last_heartbeat = moment

        while not stopping:
            heartbeat_if_due()
            queue.refresh()
            if isinstance(store, CaseStore):
                # One job at a time keeps SIGTERM observable between accepted
                # records.  The current job finishes; durable queued work is
                # left for the replacement worker instead of extending a pod
                # termination indefinitely.
                for job_id in queue.recoverable():
                    if stopping:
                        break
                    queue.run(job_id)
            else:
                for job_id in queue.recoverable():
                    if stopping:
                        break
                    if not store.acquire_job_lock(job_id, worker_id):
                        continue
                    try:
                        queue.run(job_id, recover_running=True)
                    finally:
                        if not store.release_job_lock(job_id, worker_id):
                            raise RuntimeError(
                                f"PostgreSQL did not release claim for job {job_id}"
                            )
            if webhook_pump is not None:
                webhook_pump.pump()
            heartbeat_if_due()
            if args.once:
                break
            time.sleep(args.poll_seconds)
        return 0
    except (BackendError, RuntimeError, ValueError, UsageError) as error:
        print(f"crg-worker: failed closed: {error}", file=sys.stderr)
        return 1
    finally:
        if local_handle is not None:
            local_handle.close()
        store.close()


if __name__ == "__main__":
    raise SystemExit(main())
