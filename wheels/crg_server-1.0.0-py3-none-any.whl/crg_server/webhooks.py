"""Webhook delivery: subscriptions, exact backoff, dead-letter, and the log.

Normative basis: 38.2 (the reference server SHALL provide webhooks), 38.5
(the closed event vocabulary and its mandatory carrier), 6.6 (fail closed),
42.4 (retry history is recorded, not inferred), 44.7 (an authorization- or
delivery-relevant action leaves an immutable record).

:func:`crg_server.events.webhook_payload` already builds the *delivery* -- the
canonical body, the headers, and the HMAC over those exact bytes.  What was
missing was everything that happens after the first attempt fails, which is
the only part of a webhook system anybody ever has trouble with.  This module
supplies it, and it supplies it in a shape a test can pin down completely.

**Nothing here sleeps and nothing here draws a random number.**  A retry
schedule that is computed inside ``time.sleep`` cannot be asserted on; it can
only be waited for, which makes the test slow and, worse, makes it pass for
the wrong reason when the schedule is wrong by a factor a slow machine hides.
So the clock is a supplied callable returning exact seconds, the jitter is a
supplied callable returning an exact fraction in ``[0, 1]``, and the delay for
attempt *n* is a closed-form expression in both:

    raw(n)   = min(base * factor**(n-1), maximum)
    delay(n) = raw(n) + raw(n) * JITTER_RATIO * jitter()

Every value is a :class:`fractions.Fraction`.  There is no float in the
schedule, so "the third retry is at 5 seconds" is a statement a test can make
about equality rather than about tolerance.  The jitter is *additive and
one-sided* -- it only ever pushes a retry later -- because a jitter that
could pull a retry earlier than its exponential floor would let a herd of
subscribers re-converge on the same instant, which is the thing jitter exists
to prevent.

**The transport is injected.**  The default is :func:`urllib_transport`,
which is a real POST over :mod:`urllib.request`; a test passes an in-process
callable and no test in this repository opens a socket.  That is a real
limitation and it is stated plainly: these tests prove the delivery *logic*
-- schedule, body, signature, log, dead-letter -- and they do not prove that
a socket was opened, that TLS was negotiated, or that a proxy did not eat the
body.

**A subscription without a secret is refused at registration.**  Not at
delivery, and not by sending it unsigned.  6.6's rule is that the refusal
happens at the earliest point the system can tell something is wrong, and the
earliest point here is the moment somebody asks for an unauthenticated
integration channel.  Likewise a subscription naming an event outside 38.5's
closed vocabulary is refused there, rather than accepted and never fired.

**Every attempt is a record, and every record is hashed.**  42.4 requires a
job's retry history to be a record rather than a log line, and a webhook has
the same problem for the same reason: "we tried three times" is not evidence,
and an operator arguing with an integrator about whether a delivery was made
needs the status, the response prefix, the scheduled instant, the actual
instant, and the attempt number.  :class:`DeliveryAttempt` carries all of
them and content-hashes the tuple, so a delivery log entry that was edited
afterwards no longer matches its own hash.
"""
from __future__ import annotations

import hashlib
import hmac
import itertools
from dataclasses import dataclass
from fractions import Fraction
from typing import Any, Callable, Dict, List, Mapping, Optional, Sequence, Tuple

from crg_model.canonical import content_hash
from crg_model.envelope import new_object_id

from .errors import UsageError
from .events import EVENT_VOCABULARY, WEBHOOK_SIGNATURE_PROFILE, Event, EventBus, webhook_payload

__all__ = [
    "DEFAULT_BASE_DELAY_SECONDS",
    "DEFAULT_BACKOFF_FACTOR",
    "DEFAULT_MAX_DELAY_SECONDS",
    "DEFAULT_MAX_ATTEMPTS",
    "JITTER_RATIO",
    "DeliveryOutcome",
    "DeliveryAttempt",
    "PendingDelivery",
    "TransportResponse",
    "WebhookTransportError",
    "WebhookSubscription",
    "WebhookDispatcher",
    "backoff_delay",
    "urllib_transport",
    "verify_webhook_signature",
]

#: The reference schedule.  Exact rationals, so the schedule is a statement
#: about equality rather than about floating-point proximity (14.2).
DEFAULT_BASE_DELAY_SECONDS = Fraction(1)
DEFAULT_BACKOFF_FACTOR = Fraction(2)
DEFAULT_MAX_DELAY_SECONDS = Fraction(60)

#: How many times a delivery is attempted before it is dead-lettered.  Bounded
#: on purpose: an unbounded retry is a denial-of-service the deployment aims
#: at its own integrator, and it hides a permanently broken endpoint behind
#: traffic instead of surfacing it.
DEFAULT_MAX_ATTEMPTS = 5

#: The share of the exponential floor that jitter may add.  One quarter, and
#: additive only -- see the module docstring.
JITTER_RATIO = Fraction(1, 4)


class DeliveryOutcome:
    """What became of one attempt, and of the delivery as a whole."""

    DELIVERED = "DELIVERED"
    RETRY_SCHEDULED = "RETRY_SCHEDULED"
    DEAD_LETTER = "DEAD_LETTER"
    SUPPRESSED = "SUPPRESSED"

    TERMINAL = frozenset({DELIVERED, DEAD_LETTER, SUPPRESSED})


class WebhookTransportError(Exception):
    """The transport could not complete the request at all.

    Distinct from an HTTP status: a 500 is a receiver that answered, and a
    connection refused is a receiver that did not.  The log records which,
    because the remedies differ.
    """


@dataclass(frozen=True)
class TransportResponse:
    """What a transport returns when the receiver answered."""

    status: int
    body: bytes = b""

    @property
    def accepted(self) -> bool:
        return 200 <= self.status < 300


# ---------------------------------------------------------------------------
# subscriptions
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class WebhookSubscription:
    """One registered integration endpoint (38.2).

    ``events`` empty means "the whole vocabulary".  It is *not* a wildcard
    string: 38.5's list is closed, so "everything" is expressible as the
    absence of a filter and there is no name to typo.
    """

    subscription_id: str
    endpoint: str
    secret: bytes
    events: Tuple[str, ...] = ()
    enabled: bool = True
    max_attempts: int = DEFAULT_MAX_ATTEMPTS
    base_delay: Fraction = DEFAULT_BASE_DELAY_SECONDS
    backoff_factor: Fraction = DEFAULT_BACKOFF_FACTOR
    max_delay: Fraction = DEFAULT_MAX_DELAY_SECONDS
    created_by: str = ""

    def matches(self, event: Event) -> bool:
        return self.enabled and (not self.events or event.event in self.events)

    def describe(self) -> Dict[str, Any]:
        """Everything about the subscription except the secret.

        The secret is never returned, not even to the caller that set it:
        44.4 scrubs secret-shaped fields from anything that gets recorded,
        and a registration response is something that gets recorded.
        """
        return {
            "subscription_id": self.subscription_id,
            "endpoint": self.endpoint,
            "events": list(self.events) or list(EVENT_VOCABULARY),
            "enabled": self.enabled,
            "max_attempts": self.max_attempts,
            "base_delay_seconds": str(self.base_delay),
            "backoff_factor": str(self.backoff_factor),
            "max_delay_seconds": str(self.max_delay),
            "signature_profile": WEBHOOK_SIGNATURE_PROFILE,
            "secret": "[REDACTED]",
            "created_by": self.created_by,
        }


# ---------------------------------------------------------------------------
# the schedule
# ---------------------------------------------------------------------------
def backoff_delay(
    attempt: int,
    *,
    base: Fraction = DEFAULT_BASE_DELAY_SECONDS,
    factor: Fraction = DEFAULT_BACKOFF_FACTOR,
    maximum: Fraction = DEFAULT_MAX_DELAY_SECONDS,
    jitter: Fraction = Fraction(0),
) -> Fraction:
    """Seconds to wait after ``attempt`` failed.  Exact, one-sided, capped.

    ``attempt`` is 1-based and names the attempt that *just* failed, so the
    first retry waits ``base`` and not ``base * factor``.
    """
    if attempt < 1:
        raise UsageError("an attempt number is 1-based")
    if not (Fraction(0) <= Fraction(jitter) <= Fraction(1)):
        raise UsageError(
            f"the jitter source returned {jitter}, which is outside [0, 1]",
            remedy="a jitter source returns an exact fraction of the permitted spread",
        )
    raw = min(Fraction(base) * Fraction(factor) ** (attempt - 1), Fraction(maximum))
    return raw + raw * JITTER_RATIO * Fraction(jitter)


# ---------------------------------------------------------------------------
# the delivery log
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class DeliveryAttempt:
    """One row of the delivery log (42.4's retry history, for webhooks).

    ``scheduled_at`` and ``attempted_at`` are exact seconds on the supplied
    clock and are recorded separately on purpose: the difference between them
    is queue lag, and an operator who can only see one of the two cannot tell
    a slow receiver from a backed-up dispatcher.
    """

    delivery_id: str
    subscription_id: str
    event_id: str
    event_name: str
    event_hash: str
    attempt: int
    max_attempts: int
    scheduled_at: Fraction
    attempted_at: Fraction
    duration: Fraction
    status: Optional[int]
    transport_error: Optional[str]
    response_body_prefix: str
    outcome: str
    next_attempt_at: Optional[Fraction] = None

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "record_type": "WebhookDeliveryAttempt",
            "delivery_id": self.delivery_id,
            "subscription_id": self.subscription_id,
            "event_id": self.event_id,
            "event_name": self.event_name,
            "event_hash": self.event_hash,
            "attempt": self.attempt,
            "max_attempts": self.max_attempts,
            "scheduled_at_seconds": str(self.scheduled_at),
            "attempted_at_seconds": str(self.attempted_at),
            "duration_seconds": str(self.duration),
            "http_status": self.status,
            "transport_error": self.transport_error,
            "response_body_prefix": self.response_body_prefix,
            "outcome": self.outcome,
            "next_attempt_at_seconds": (
                None if self.next_attempt_at is None else str(self.next_attempt_at)
            ),
        }

    def record_hash(self) -> str:
        return content_hash(self.to_canonical())


@dataclass
class PendingDelivery:
    """One event owed to one subscription, and where it is in the schedule."""

    delivery_id: str
    subscription_id: str
    event_id: str
    event_name: str
    event_hash: str
    endpoint: str
    headers: Dict[str, str]
    body_bytes: bytes
    attempt: int
    scheduled_at: Fraction
    state: str = "PENDING"

    def describe(self) -> Dict[str, Any]:
        return {
            "delivery_id": self.delivery_id,
            "subscription_id": self.subscription_id,
            "event_id": self.event_id,
            "event_name": self.event_name,
            "event_hash": self.event_hash,
            "attempt": self.attempt,
            "scheduled_at_seconds": str(self.scheduled_at),
            "state": self.state,
        }


# ---------------------------------------------------------------------------
# transports
# ---------------------------------------------------------------------------
def urllib_transport(
    endpoint: str, headers: Mapping[str, str], body: bytes, *, timeout: float = 10.0
) -> TransportResponse:
    """The default transport: one real POST, standard library only.

    Imported lazily so that a deployment which injects its own transport --
    or a test suite which injects an in-process receiver -- never touches
    :mod:`urllib.request` at all.
    """
    import urllib.error
    import urllib.request

    request = urllib.request.Request(
        endpoint, data=body, headers=dict(headers), method="POST"
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return TransportResponse(int(response.status), response.read())
    except urllib.error.HTTPError as error:  # the receiver answered, badly
        return TransportResponse(int(error.code), error.read() or b"")
    except Exception as error:  # noqa: BLE001 - every transport failure is one kind
        raise WebhookTransportError(f"{type(error).__name__}: {error}") from error


# ---------------------------------------------------------------------------
# signature verification, from the receiver's side
# ---------------------------------------------------------------------------
def verify_webhook_signature(
    body: bytes, signature_header: Optional[str], secret: bytes
) -> bool:
    """What an integrator writes at the other end of the wire (38.2, 14.5).

    Published here rather than left as an exercise because an integrator who
    has to reconstruct the scheme from prose usually reconstructs it slightly
    wrong -- comparing with ``==`` instead of a constant-time compare, or
    hashing the parsed object instead of the received bytes, which lets a
    re-serializer smuggle a change past the check.  This function hashes the
    *bytes that arrived*.

    The profile is symmetric (:data:`WEBHOOK_SIGNATURE_PROFILE`) and proves
    only that the sender holds the same shared secret.  It is not, and must
    not be presented as, the Ed25519 signature 14.5 requires over a portable
    artifact's manifest.
    """
    if not signature_header:
        return False
    text = str(signature_header).strip()
    if text.startswith("sha256="):
        text = text[len("sha256="):]
    expected = hmac.new(secret, body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, text)


# ---------------------------------------------------------------------------
# the dispatcher
# ---------------------------------------------------------------------------
class WebhookDispatcher:
    """Registrations, the queue, the schedule, the log, and the dead letters.

    Attach it to a bus with :meth:`subscribe_to`; every emitted event is then
    fanned out to the matching enabled subscriptions as :class:`PendingDelivery`
    entries scheduled for *now*.  Nothing is sent until :meth:`pump` runs, so
    the caller owns the thread and the clock, and a deployment that wants a
    background sender writes the loop it wants around :meth:`pump`.
    """

    def __init__(
        self,
        *,
        transport: Optional[Callable[..., TransportResponse]] = None,
        clock: Optional[Callable[[], Fraction]] = None,
        jitter: Optional[Callable[[], Fraction]] = None,
        body_prefix_bytes: int = 200,
        delivery_ids: Optional[Callable[[], str]] = None,
        event_ids: Optional[Callable[[], str]] = None,
    ) -> None:
        self.transport = transport or urllib_transport
        self.clock = clock or _monotonic_fraction
        #: Default jitter is *zero*, not ``random.random``.  A module that
        #: reaches for :mod:`random` by default is a module whose schedule
        #: cannot be reproduced, and 47.1 asks the opposite.  A deployment
        #: that wants spread passes a source; the reference behaviour is a
        #: pure exponential.
        self.jitter = jitter or (lambda: Fraction(0))
        self._jitter_supplied = jitter is not None
        self.body_prefix_bytes = int(body_prefix_bytes)
        self._delivery_ids = delivery_ids or (lambda: new_object_id("delivery"))
        self._event_counter = itertools.count(1)
        self._event_ids = event_ids or (lambda: f"evt-{next(self._event_counter):08d}")
        self._subscriptions: Dict[str, WebhookSubscription] = {}
        self._queue: List[PendingDelivery] = []
        self.log: List[DeliveryAttempt] = []
        self.dead_letters: List[PendingDelivery] = []
        self.delivered: List[PendingDelivery] = []

    # -- registration (38.2) ----------------------------------------------
    def register(
        self,
        endpoint: str,
        *,
        secret: Optional[bytes],
        events: Sequence[str] = (),
        subscription_id: Optional[str] = None,
        max_attempts: int = DEFAULT_MAX_ATTEMPTS,
        base_delay: Fraction = DEFAULT_BASE_DELAY_SECONDS,
        backoff_factor: Fraction = DEFAULT_BACKOFF_FACTOR,
        max_delay: Fraction = DEFAULT_MAX_DELAY_SECONDS,
        created_by: str = "",
        enabled: bool = True,
    ) -> WebhookSubscription:
        """Register a delivery target.  Refuses more than it accepts (6.6)."""
        if not endpoint or not str(endpoint).strip():
            raise UsageError(
                "a webhook subscription must name a target endpoint",
                remedy="register with an absolute URL the deployment can reach",
            )
        if not secret:
            raise UsageError(
                "a webhook subscription must carry a shared secret",
                remedy=(
                    "38.2 deliveries are signed with "
                    f"{WEBHOOK_SIGNATURE_PROFILE}; an unsigned delivery is an "
                    "unauthenticated integration channel, so it is refused here "
                    "rather than at delivery time (6.6)"
                ),
            )
        unknown = [name for name in events if name not in EVENT_VOCABULARY]
        if unknown:
            raise UsageError(
                f"unknown event name(s) {unknown} in the subscription",
                remedy=(
                    "38.5 fixes a closed event vocabulary; subscribe to one of "
                    f"{list(EVENT_VOCABULARY)}"
                ),
                detail={"unknown": unknown, "vocabulary": list(EVENT_VOCABULARY)},
            )
        if int(max_attempts) < 1:
            raise UsageError("max_attempts must be at least 1")
        identifier = subscription_id or new_object_id("websub")
        if identifier in self._subscriptions:
            raise UsageError(f"subscription {identifier!r} is already registered")
        subscription = WebhookSubscription(
            subscription_id=identifier,
            endpoint=str(endpoint),
            secret=bytes(secret),
            events=tuple(events),
            enabled=bool(enabled),
            max_attempts=int(max_attempts),
            base_delay=Fraction(base_delay),
            backoff_factor=Fraction(backoff_factor),
            max_delay=Fraction(max_delay),
            created_by=str(created_by),
        )
        self._subscriptions[identifier] = subscription
        return subscription

    def get(self, subscription_id: str) -> WebhookSubscription:
        try:
            return self._subscriptions[subscription_id]
        except KeyError:
            raise UsageError(
                f"no webhook subscription {subscription_id!r}",
                remedy="list the registered subscriptions before addressing one",
            ) from None

    def subscriptions(self) -> Tuple[WebhookSubscription, ...]:
        return tuple(self._subscriptions[key] for key in sorted(self._subscriptions))

    def set_enabled(self, subscription_id: str, enabled: bool) -> WebhookSubscription:
        """Enable or disable without losing the registration or the log."""
        current = self.get(subscription_id)
        updated = WebhookSubscription(
            subscription_id=current.subscription_id,
            endpoint=current.endpoint,
            secret=current.secret,
            events=current.events,
            enabled=bool(enabled),
            max_attempts=current.max_attempts,
            base_delay=current.base_delay,
            backoff_factor=current.backoff_factor,
            max_delay=current.max_delay,
            created_by=current.created_by,
        )
        self._subscriptions[subscription_id] = updated
        return updated

    def enable(self, subscription_id: str) -> WebhookSubscription:
        return self.set_enabled(subscription_id, True)

    def disable(self, subscription_id: str) -> WebhookSubscription:
        return self.set_enabled(subscription_id, False)

    def delete(self, subscription_id: str) -> WebhookSubscription:
        """Remove a subscription.  Queued deliveries for it are suppressed.

        The delivery log is *not* removed.  A subscription that was deleted
        because it was leaking is exactly the subscription whose delivery
        history somebody will need afterwards (44.7).
        """
        removed = self.get(subscription_id)
        del self._subscriptions[subscription_id]
        for pending in self._queue:
            if pending.subscription_id == subscription_id:
                pending.state = DeliveryOutcome.SUPPRESSED
        self._queue = [
            p for p in self._queue if p.state != DeliveryOutcome.SUPPRESSED
        ]
        return removed

    # -- fan-out ------------------------------------------------------------
    def subscribe_to(self, bus: EventBus) -> Callable[[], None]:
        """Attach to an :class:`EventBus`; returns the unsubscribe callable."""
        return bus.subscribe(self.dispatch)

    def dispatch(self, event: Event, *, event_id: Optional[str] = None) -> Tuple[PendingDelivery, ...]:
        """Queue one delivery per matching enabled subscription.

        The body and the signature are computed *once*, here, and reused on
        every retry.  A retry that re-signed a freshly built body would carry
        a different ``delivery_id`` and a different signature, which defeats
        the receiver-side deduplication the ``CRG-Delivery-Id`` header exists
        to enable.
        """
        identifier = event_id or self._event_ids()
        digest = event.event_hash()
        now = Fraction(self.clock())
        queued: List[PendingDelivery] = []
        for subscription in self.subscriptions():
            if not subscription.matches(event):
                continue
            delivery_id = self._delivery_ids()
            payload = webhook_payload(
                event,
                endpoint=subscription.endpoint,
                secret=subscription.secret,
                delivery_id=delivery_id,
            )
            headers = dict(payload["headers"])
            headers["CRG-Subscription-Id"] = subscription.subscription_id
            pending = PendingDelivery(
                delivery_id=delivery_id,
                subscription_id=subscription.subscription_id,
                event_id=identifier,
                event_name=event.event,
                event_hash=digest,
                endpoint=subscription.endpoint,
                headers=headers,
                body_bytes=bytes(payload["body_bytes"]),
                attempt=1,
                scheduled_at=now,
            )
            self._queue.append(pending)
            queued.append(pending)
        return tuple(queued)

    # -- sending ------------------------------------------------------------
    def due(self, now: Optional[Fraction] = None) -> Tuple[PendingDelivery, ...]:
        moment = Fraction(self.clock() if now is None else now)
        return tuple(p for p in self._queue if p.scheduled_at <= moment)

    def pump(self, now: Optional[Fraction] = None) -> Tuple[DeliveryAttempt, ...]:
        """Attempt every delivery whose scheduled instant has arrived.

        One attempt per due delivery per call, never a loop that retries
        inside itself: the whole point of the schedule is that the next
        attempt happens *later*, and a pump that retried immediately would
        exhaust ``max_attempts`` against a receiver that was merely restarting.
        """
        attempts: List[DeliveryAttempt] = []
        for pending in self.due(now):
            attempts.append(self._attempt(pending))
        return tuple(attempts)

    def _attempt(self, pending: PendingDelivery) -> DeliveryAttempt:
        subscription = self._subscriptions.get(pending.subscription_id)
        started = Fraction(self.clock())
        status: Optional[int] = None
        transport_error: Optional[str] = None
        body_prefix = ""
        try:
            response = self.transport(
                pending.endpoint, dict(pending.headers), pending.body_bytes
            )
            status = int(getattr(response, "status", 0))
            raw = bytes(getattr(response, "body", b"") or b"")
            body_prefix = raw[: self.body_prefix_bytes].decode("utf-8", "replace")
        except WebhookTransportError as error:
            transport_error = str(error)
        except Exception as error:  # noqa: BLE001 - an injected transport is untrusted
            transport_error = f"{type(error).__name__}: {error}"
        finished = Fraction(self.clock())

        accepted = status is not None and 200 <= status < 300
        max_attempts = subscription.max_attempts if subscription else pending.attempt
        next_at: Optional[Fraction] = None
        if accepted:
            outcome = DeliveryOutcome.DELIVERED
            pending.state = outcome
            self._queue.remove(pending)
            self.delivered.append(pending)
        elif subscription is None:
            outcome = DeliveryOutcome.SUPPRESSED
            pending.state = outcome
            self._queue.remove(pending)
        elif pending.attempt >= max_attempts:
            outcome = DeliveryOutcome.DEAD_LETTER
            pending.state = outcome
            self._queue.remove(pending)
            self.dead_letters.append(pending)
        else:
            outcome = DeliveryOutcome.RETRY_SCHEDULED
            delay = backoff_delay(
                pending.attempt,
                base=subscription.base_delay,
                factor=subscription.backoff_factor,
                maximum=subscription.max_delay,
                jitter=Fraction(self.jitter()),
            )
            next_at = pending.scheduled_at + delay
            record_scheduled = pending.scheduled_at
            pending.scheduled_at = next_at
            pending.attempt += 1
            pending.state = outcome
            attempt = DeliveryAttempt(
                delivery_id=pending.delivery_id,
                subscription_id=pending.subscription_id,
                event_id=pending.event_id,
                event_name=pending.event_name,
                event_hash=pending.event_hash,
                attempt=pending.attempt - 1,
                max_attempts=max_attempts,
                scheduled_at=record_scheduled,
                attempted_at=started,
                duration=finished - started,
                status=status,
                transport_error=transport_error,
                response_body_prefix=body_prefix,
                outcome=outcome,
                next_attempt_at=next_at,
            )
            self.log.append(attempt)
            return attempt

        attempt = DeliveryAttempt(
            delivery_id=pending.delivery_id,
            subscription_id=pending.subscription_id,
            event_id=pending.event_id,
            event_name=pending.event_name,
            event_hash=pending.event_hash,
            attempt=pending.attempt,
            max_attempts=max_attempts,
            scheduled_at=pending.scheduled_at,
            attempted_at=started,
            duration=finished - started,
            status=status,
            transport_error=transport_error,
            response_body_prefix=body_prefix,
            outcome=outcome,
            next_attempt_at=None,
        )
        self.log.append(attempt)
        return attempt

    # -- inspection ---------------------------------------------------------
    def pending(self) -> Tuple[PendingDelivery, ...]:
        return tuple(self._queue)

    def schedule_for(self, delivery_id: str) -> Tuple[Fraction, ...]:
        """Every instant at which ``delivery_id`` was or will be attempted."""
        instants = [
            row.scheduled_at for row in self.log if row.delivery_id == delivery_id
        ]
        for pending in self._queue:
            if pending.delivery_id == delivery_id:
                instants.append(pending.scheduled_at)
        return tuple(instants)

    def delivery_log(self) -> Tuple[Dict[str, Any], ...]:
        """The log as canonical records, each carrying its own content hash."""
        return tuple(
            {**row.to_canonical(), "content_hash": row.record_hash()} for row in self.log
        )

    def describe(self) -> Dict[str, Any]:
        return {
            "spec": "38.2",
            "signature_profile": WEBHOOK_SIGNATURE_PROFILE,
            "subscriptions": [s.describe() for s in self.subscriptions()],
            "pending": [p.describe() for p in self._queue],
            "dead_letters": [p.describe() for p in self.dead_letters],
            "attempts_logged": len(self.log),
            "jitter_source": (
                "supplied" if self._jitter_supplied else "none (pure exponential)"
            ),
        }


def _monotonic_fraction() -> Fraction:
    """The default clock: monotonic seconds, converted to an exact rational.

    :func:`time.monotonic_ns` rather than :func:`time.monotonic` so the
    conversion is exact.  A float second turned into a ``Fraction`` would
    carry the binary approximation into a schedule this module promises is
    exact (14.2).
    """
    import time

    return Fraction(time.monotonic_ns(), 1_000_000_000)
