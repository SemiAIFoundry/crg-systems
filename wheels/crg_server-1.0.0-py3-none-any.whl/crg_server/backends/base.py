"""The persistence seam: what a CRG store must be able to do, stated once.

Normative basis: 42.1 (storage model: relational metadata, content-addressed
object store, graph indexes, append-only audit, job queue), 42.2 (local
profile: SQLite plus filesystem, no required external services), 42.3
(enterprise profile: PostgreSQL or equivalent, S3-compatible object storage,
legal hold, customer-managed encryption, air-gapped deployment), 42.4 (job
semantics), 6.2 (portable state), 6.3 (no central-service dependency), 6.6
(fail closed), 17 (deletion, retention, redaction, tombstones), 18 (typed
dependency graph), 44.4 (encryption at rest), 44.5 (multi-tenancy), 44.7
(audit).

Specification 42.1 does not name products.  It names *five separable
responsibilities* -- relational metadata, content-addressed objects, graph
indexes, an append-only audit log, and a job queue -- and 42.2/42.3 then give
two profiles that answer them with different machinery.  The reference server
answers all five with one class, :class:`crg_server.store.CaseStore`, because
SQLite and a directory are what a single node needs.  That is a legitimate
implementation of 42.1.  It is not an *interface*, and without an interface
"support PostgreSQL and S3" is a rewrite rather than a configuration change.

This module is the interface.  It is derived from what ``CaseStore`` actually
does, not from what a storage layer might in principle do, and it is split
along 42.1's own seam rather than into one flat blob:

* :class:`ObjectStoreBackend` -- the content-addressed object store.  Bytes,
  addressed by the hash of those bytes, plus the small mutable envelope 42.1
  keeps *out* of the content (presence, lifecycle status, legal hold).  This
  is the half an S3-compatible store replaces.
* :class:`MetadataBackend` -- identity, status, policy, and indexed queries:
  cases and their versions, typed dependency edges, certificate registrations,
  idempotency records, jobs, tombstones, and the append-only audit log.  This
  is the half PostgreSQL replaces.
* :class:`StoreBackend` -- the composite, which is what the server holds.  A
  deployment may mix: SQLite metadata with S3 objects, PostgreSQL metadata
  with a filesystem, or either pair.  The split exists so that mixing is
  expressible.

**Why the split is at exactly this line.**  The two halves have different
consistency stories and the difference is not cosmetic.  A relational store
gives you multi-statement atomicity; an object store, in general, does not
give you read-after-write on a *listing*, may not give it on a *read* in
compatible implementations, and never gives you a transaction that spans it
and a database.  Pretending otherwise inside one interface would mean every
caller silently assuming the strongest guarantee.  So each implementation
publishes a :class:`ConsistencyModel` and the composite publishes the
(weaker) join of the two, and the ordering rule below is stated rather than
assumed.

**What content addressing buys back.**  Eventual consistency is survivable
here in a way it would not be for mutable objects, because the address *is*
the hash of the content.  A stale read cannot return the wrong version of an
object: there is only ever one version at an address.  The two failures that
remain are (a) a read that misses an object that was written -- which is
detectable, because the writer knows what it wrote -- and (b) a read that
returns bytes which are not the object -- which is detectable, because the
bytes either hash to the address or they do not.  Both are therefore hard
errors in this interface rather than warnings, and both are named:
:class:`EventualConsistencyError` and
:class:`crg_server.errors.IntegrityError`.  That is 6.6 applied to storage:
an unknown state fails closed.

**The ordering rule.**  There is no distributed transaction here and this
interface does not pretend to offer one.  A composite write MUST write
content before metadata.  A crash between the two then leaves an *orphan
object* -- bytes at an address nothing points to, which are garbage, are
harmless, and are reclaimed by the next identical write because content
addressing deduplicates.  The other order would leave a *dangling metadata
row* -- a case version, or a certificate registration, naming a hash whose
bytes are absent -- which is a claim the store cannot support, and 6.6 says a
claim the store cannot support must not be presented as a success.  Deletion
runs the other way for the same reason: tombstone first (17.2), bytes second,
so an interrupted redaction leaves content that is already unreadable through
the API rather than content that is gone with nothing explaining why.

Nothing in this module imports a database driver, an HTTP client, or a cloud
SDK.  9.2's standard-library-only constraint on the kernel holds all the way
through: an adapter receives its ``connect()`` callable or its client object
from the caller, so the seam is testable without a server and installable
without a wheel.
"""
from __future__ import annotations

import hashlib
import inspect
from dataclasses import dataclass
from typing import (
    Any,
    ClassVar,
    ContextManager,
    Dict,
    List,
    Mapping,
    Optional,
    Protocol,
    Tuple,
    Union,
    runtime_checkable,
)

# ConflictError, NotFoundError and RedactedError are imported for the
# ``:class:`` cross-references in the interface docstrings below: this module
# is the normative statement of each method's failure semantics, and a
# reference that does not resolve is a failure mode nobody can look up.
from ..errors import (  # noqa: F401
    ConflictError,
    IntegrityError,
    NotFoundError,
    RedactedError,
    ServerError,
    UsageError,
)

__all__ = [
    "BackendError",
    "BackendUnavailableError",
    "BackendConfigurationError",
    "DriverNotInstalledError",
    "EventualConsistencyError",
    "ConsistencyModel",
    "STRICT_LOCAL_CONSISTENCY",
    "ObjectRecord",
    "CaseVersionRecord",
    "EdgeRecord",
    "CertificateRecord",
    "IdempotencyRecord",
    "JobRecord",
    "AuditRecord",
    "TombstoneRecord",
    "ObjectStoreBackend",
    "MetadataBackend",
    "StoreBackend",
    "OBJECT_STORE_METHODS",
    "METADATA_METHODS",
    "STORE_METHODS",
    "digest_of",
    "verify_digest",
    "split_digest",
    "conformance_complaints",
    "require_conformance",
    "DEFAULT_PERMITTED_DISCLOSURE",
]

#: 17.2 fixes what a tombstone may still disclose.  Repeated here so every
#: backend that mints one without being handed a value mints the same one.
DEFAULT_PERMITTED_DISCLOSURE = "identity, hash, type, and dependency structure only"


# ---------------------------------------------------------------------------
# Typed failures (6.6)
# ---------------------------------------------------------------------------
class BackendError(ServerError):
    """A storage backend failed in a way the caller did not cause.

    Distinct from :class:`~crg_server.errors.UsageError` on purpose: a caller
    who receives this learns that the *store* is the problem, and retrying the
    identical request is a reasonable thing to consider.  A caller who
    receives ``UsageError`` learns the opposite.
    """

    status = 500
    category = "BACKEND"


class BackendUnavailableError(BackendError):
    """The backend could not be reached, or answered in a way we cannot trust.

    Every driver exception that is not one of this package's own typed
    failures arrives here.  That is deliberate and it is the 6.6 rule applied
    to a network: a timeout, a reset connection, a throttling response, and an
    unrecognised server error all leave the operation's outcome *unknown*, and
    an unknown outcome is reported as a failure rather than guessed at.  In
    particular a write that raised this may or may not have landed; the caller
    must re-read before concluding anything, and because writes here are
    content-addressed and idempotent, simply retrying is safe.
    """

    status = 503
    category = "BACKEND_UNAVAILABLE"


class BackendConfigurationError(BackendError):
    """The deployment asked for a backend that cannot be built as described.

    Raised at construction or selection time, never mid-request.  An unknown
    backend name is this error and never a silent fall back to the local
    profile: 42.3 deployments differ from 42.2 deployments in where the data
    lives, and a typo that quietly writes enterprise data to a local directory
    is a data-loss incident wearing a default value's clothes.
    """

    status = 500
    category = "BACKEND_CONFIGURATION"


class DriverNotInstalledError(BackendConfigurationError):
    """The adapter is present; the driver it would need is not.

    Carries the exact install line in :attr:`remedy`.  This is raised from the
    adapter's *constructor*, so ``import crg_server.backends.postgres``
    succeeds on a machine with no PostgreSQL client library and the failure
    arrives with a name attached at the moment somebody actually asks for a
    connection.  An ``ImportError`` at module import would take the whole
    package down on a local-profile deployment that never wanted PostgreSQL.
    """

    status = 500
    category = "DRIVER_NOT_INSTALLED"


class EventualConsistencyError(BackendUnavailableError):
    """An object this process wrote was not there when this process read it.

    An eventually consistent object store is permitted to do this and it is
    not, by itself, corruption.  It is nonetheless a hard failure at this
    seam.  The alternative is to return :class:`NotFoundError`, and a caller
    cannot distinguish "this object was never stored" from "this object is
    stored and the replica has not caught up" -- so a certificate whose
    supporting evidence is merely *late* would be reported as a certificate
    with missing evidence.  17.1 keeps absent and removed as separate states
    for the same reason; this adds a third, *not yet visible*, rather than
    collapsing it into the first.

    Recovery is to retry: the object is durable, the read is stale.
    """

    status = 503
    category = "BACKEND_NOT_YET_CONSISTENT"


# ---------------------------------------------------------------------------
# Consistency (42.1, 42.3)
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class ConsistencyModel:
    """What an implementation actually guarantees, published rather than assumed.

    Every field is a closed vocabulary token, so a deployment check can branch
    on it, and ``notes`` carries the prose a reviewer needs.

    ``read_after_write``
        ``STRICT`` -- a successful write is visible to the next read, full
        stop.  ``MONITORED`` -- the store does not promise it, and this
        adapter detects a violation and raises
        :class:`EventualConsistencyError` for writes it performed itself.
        ``EVENTUAL`` -- neither promised nor detected.  No implementation here
        is allowed to be ``EVENTUAL``; the value exists so a third-party
        adapter can be honest.
    ``list_after_write``
        Same vocabulary, for enumeration.  Object stores commonly give
        read-after-write on a key and only eventual consistency on a listing,
        which is why enumeration is never load-bearing in this interface.
    ``multi_statement_atomicity``
        ``TRANSACTIONAL`` -- BEGIN/COMMIT/ROLLBACK with real rollback.
        ``MUTUAL_EXCLUSION`` -- statements are serialized against other
        callers but a partial sequence is not undone.  ``NONE``.
    ``cross_store_atomicity``
        Between the object half and the metadata half.  Always ``NONE`` for a
        composite of two systems; ``MUTUAL_EXCLUSION`` when one process owns
        both.  See this module's docstring for the ordering rule that makes
        ``NONE`` survivable.
    """

    name: str
    read_after_write: str
    list_after_write: str
    multi_statement_atomicity: str
    cross_store_atomicity: str
    notes: str = ""

    #: Closed vocabularies, ordered weakest-last, so a deployment check can
    #: validate a third-party adapter's self-description rather than trust it.
    READ_LEVELS: ClassVar[Tuple[str, ...]] = ("STRICT", "MONITORED", "EVENTUAL")
    ATOMICITY_LEVELS: ClassVar[Tuple[str, ...]] = (
        "TRANSACTIONAL", "MUTUAL_EXCLUSION", "NONE",
    )

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "read_after_write": self.read_after_write,
            "list_after_write": self.list_after_write,
            "multi_statement_atomicity": self.multi_statement_atomicity,
            "cross_store_atomicity": self.cross_store_atomicity,
            "notes": self.notes,
        }

    def join(self, other: "ConsistencyModel", *, name: str) -> "ConsistencyModel":
        """The guarantee a composite of ``self`` and ``other`` may claim.

        Weakest wins on every axis, and ``cross_store_atomicity`` collapses to
        ``NONE`` because two systems that each have transactions still have no
        transaction *between* them.
        """
        order = {"STRICT": 0, "MONITORED": 1, "EVENTUAL": 2}
        atom = {"TRANSACTIONAL": 0, "MUTUAL_EXCLUSION": 1, "NONE": 2}

        def weaker(a: str, b: str, table: Mapping[str, int]) -> str:
            return a if table.get(a, 99) >= table.get(b, 99) else b

        return ConsistencyModel(
            name=name,
            read_after_write=weaker(self.read_after_write, other.read_after_write, order),
            list_after_write=weaker(self.list_after_write, other.list_after_write, order),
            multi_statement_atomicity=weaker(
                self.multi_statement_atomicity, other.multi_statement_atomicity, atom
            ),
            cross_store_atomicity="NONE",
            notes=(
                "composite of two independent systems: content is written before "
                "metadata so an interrupted write leaves a reclaimable orphan object "
                "rather than a metadata row naming absent bytes; deletion runs the "
                "other way, tombstone before bytes (17.2)."
            ),
        )


#: The 42.2 profile's model, stated once so both the local backend and the
#: contract suite can name it.
STRICT_LOCAL_CONSISTENCY = ConsistencyModel(
    name="sqlite+filesystem",
    read_after_write="STRICT",
    list_after_write="STRICT",
    multi_statement_atomicity="MUTUAL_EXCLUSION",
    cross_store_atomicity="MUTUAL_EXCLUSION",
    notes=(
        "One process, one SQLite connection serialized by a re-entrant lock, one "
        "directory.  Reads see writes because there is nowhere else for a write to "
        "be.  Atomicity is mutual exclusion rather than rollback: the wrapped "
        "CaseStore commits at each of its own statements, so a sequence interrupted "
        "midway is not undone -- it is merely never interleaved with another "
        "caller's sequence."
    ),
)


# ---------------------------------------------------------------------------
# Row shapes.  Every backend returns these, so a caller cannot tell which one
# answered without asking.
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class ObjectRecord:
    """The mutable envelope 42.1 keeps outside the content.

    ``present`` is 17.1's distinction between *absent* and *removed under
    authority* seen from the object store's side: the record survives
    redaction with ``present=False`` so that the tombstone has something to
    hang identity on.
    """

    content_hash: str
    object_type: str
    byte_length: int
    created_at: str
    created_by: str
    present: bool = True
    legal_hold: bool = False
    status: str = "ACTIVE"
    status_reason: str = ""

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "content_hash": self.content_hash,
            "object_type": self.object_type,
            "byte_length": int(self.byte_length),
            "created_at": self.created_at,
            "created_by": self.created_by,
            "present": bool(self.present),
            "legal_hold": bool(self.legal_hold),
            "status": self.status,
            "status_reason": self.status_reason,
        }


@dataclass(frozen=True)
class CaseVersionRecord:
    """One row of a case's linear per-branch history (11.2, 16.1)."""

    case_id: str
    case_version: int
    content_hash: str
    branch_id: str = "main"
    derived_from: str = ""
    parent_version: Optional[int] = None
    status: str = "DRAFT"
    created_at: str = ""
    created_by: str = "crg-server"

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "case_id": self.case_id,
            "case_version": int(self.case_version),
            "content_hash": self.content_hash,
            "branch_id": self.branch_id,
            "derived_from": self.derived_from,
            "parent_version": self.parent_version,
            "status": self.status,
            "created_at": self.created_at,
            "created_by": self.created_by,
        }


@dataclass(frozen=True)
class EdgeRecord:
    """A typed dependency edge (18.2, 18.3).

    ``minimum_action`` is resolved from :data:`crg_model.edges.EDGE_SEMANTICS`
    at write time by the caller, not guessed at read time, because 18.1 makes
    an untyped ``depends_on`` explicitly insufficient for certificate-
    authorizing behaviour.
    """

    edge_id: str
    source: str
    target: str
    edge_type: str
    case_id: str = ""
    scope: str = ""
    minimum_action: str = ""
    recorded_at: str = ""

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "edge_id": self.edge_id,
            "case_id": self.case_id,
            "source": self.source,
            "target": self.target,
            "edge_type": self.edge_type,
            "scope": self.scope,
            "minimum_action": self.minimum_action,
            "recorded_at": self.recorded_at,
        }


@dataclass(frozen=True)
class CertificateRecord:
    """A certificate *registration* (42.4).

    Registration is metadata; the certificate itself is content in the object
    store.  Withdrawing a registration therefore does not and must not delete
    the certificate: 6.4 makes provenance immutable, and an object that was
    written is a fact even when the run that wrote it was not allowed to keep
    it.  What a withdrawal removes is the claim that the certificate is live.
    """

    case_id: str
    certificate_id: str
    content_hash: str
    job_id: str = ""
    outcome: str = ""
    affirmative: bool = True
    registered_at: str = ""

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "case_id": self.case_id,
            "certificate_id": self.certificate_id,
            "content_hash": self.content_hash,
            "job_id": self.job_id,
            "outcome": self.outcome,
            "affirmative": bool(self.affirmative),
            "registered_at": self.registered_at,
        }


@dataclass(frozen=True)
class IdempotencyRecord:
    """A replayable response keyed by an idempotency key (38.4)."""

    key: str
    request_hash: str
    response_json: str
    status: int
    created_at: str = ""

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "key": self.key,
            "request_hash": self.request_hash,
            "response_json": self.response_json,
            "status": int(self.status),
            "created_at": self.created_at,
        }


@dataclass(frozen=True)
class JobRecord:
    """A persisted job (42.4).

    The interface stores the record as canonical JSON text rather than as a
    column per field.  42.4 lists thirteen things a job MUST record and the
    shape of several of them (logs, retry history, proof artifacts) is a list;
    normalising them into a relational schema here would fix a shape that
    :mod:`crg_server.jobs` owns.  ``record_json`` is what the local profile
    already persists, byte for byte.
    """

    job_id: str
    record_json: str
    updated_at: str = ""
    payload_json: str = ""

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "job_id": self.job_id,
            "record_json": self.record_json,
            "updated_at": self.updated_at,
            "payload_json": self.payload_json,
        }


@dataclass(frozen=True)
class AuditRecord:
    """One append-only audit entry (44.7, 42.1).

    ``seq`` is assigned by the store and is monotonically increasing.  It is
    the ordering, not ``recorded_at``: two events in the same wall-clock
    millisecond still have an order, and a clock that steps backwards must not
    be able to reorder the log.
    """

    seq: int
    recorded_at: str
    event_json: str

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "seq": int(self.seq),
            "recorded_at": self.recorded_at,
            "event_json": self.event_json,
        }


@dataclass(frozen=True)
class TombstoneRecord:
    """A ``TombstoneRecord`` as 17.2 defines it, in backend-row form.

    ``dependency_edges_json`` is the canonical JSON of the edges that touched
    the object, kept because a dependent claim must remain *explicable* after
    its support is gone.  A tombstone that dropped the edges would leave a
    certificate referring to a hash with no way to say what that hash used to
    be to it.
    """

    content_hash: str
    object_id: str
    object_type: str
    reason: str
    authority: str
    removed_at: str
    legal_hold: bool = False
    permitted_disclosure: str = DEFAULT_PERMITTED_DISCLOSURE
    dependency_edges_json: str = "[]"

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "record_type": "TombstoneRecord",
            "content_hash": self.content_hash,
            "object_id": self.object_id,
            "object_type": self.object_type,
            "removal_reason": self.reason,
            "removal_authority": self.authority,
            "removal_time": self.removed_at,
            "legal_hold": bool(self.legal_hold),
            "permitted_disclosure": self.permitted_disclosure,
            "dependency_edges_json": self.dependency_edges_json,
        }


# ---------------------------------------------------------------------------
# Digest helpers.  The address is a trust boundary, so the check lives here
# and every adapter calls it rather than reimplementing it.
# ---------------------------------------------------------------------------
def digest_of(payload: bytes) -> str:
    """Return the ``sha256:<hex>`` address of ``payload``.

    Identical to :func:`crg_model.canonical.content_hash` applied to the
    canonical encoding, and stated over bytes because a backend moves bytes.
    """
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def split_digest(digest: str) -> Tuple[str, str]:
    """Split ``sha256:<hex>`` into ``("sha256", hex)``, validating the shape.

    Fails closed on anything else: an address this layer cannot parse is not
    treated as an opaque key, because a key that is not a hash cannot be
    verified on read and would silently disable the one check that makes an
    untrusted object store usable.
    """
    algorithm, _, hexdigest = digest.partition(":")
    if algorithm != "sha256" or len(hexdigest) != 64:
        raise UsageError(
            f"{digest!r} is not a sha256 content address (spec 14.4)",
            remedy="addresses are 'sha256:' followed by 64 lowercase hex characters",
        )
    if any(character not in "0123456789abcdef" for character in hexdigest):
        raise UsageError(
            f"{digest!r} is not a sha256 content address (spec 14.4)",
            remedy="addresses are 'sha256:' followed by 64 lowercase hex characters",
        )
    return algorithm, hexdigest


def verify_digest(digest: str, payload: bytes, *, where: str) -> None:
    """Raise :class:`IntegrityError` unless ``payload`` hashes to ``digest``.

    **Never trust the store.**  This is called on every read, in every
    adapter, including the local one, and a mismatch is a hard failure and not
    a warning.  Returning the bytes with a log line would let corruption --
    or a tampered object in a bucket somebody else can also write to -- reach
    a certificate, and 6.6 forbids presenting an unresolved outcome as a
    success.  ``where`` names the layer so an operator can tell a corrupted
    filesystem from a corrupted bucket from a corrupted transfer.
    """
    actual = digest_of(payload)
    if actual != digest:
        raise IntegrityError(
            f"{where}: bytes stored at {digest} hash to {actual}",
            remedy=(
                "quarantine this store and restore the object from a verified "
                "bundle; the content address is a trust boundary, not a filename"
            ),
            detail={"expected": digest, "actual": actual, "layer": where,
                    "byte_length": len(payload)},
        )


# ---------------------------------------------------------------------------
# The interfaces
# ---------------------------------------------------------------------------
@runtime_checkable
class ObjectStoreBackend(Protocol):
    """The content-addressed half of 42.1.  S3 replaces this.

    Bytes are immutable and addressed by their own hash.  There is no
    mutate-in-place operation and there is deliberately no way to express one:
    "changing" an object produces a *successor* at a different address, which
    is 10.1 made structural rather than documented.

    Three things around the bytes do change, and 42.1 puts all three in the
    envelope rather than in the content: presence (17.2 redaction), lifecycle
    status (12, 17.1), and legal hold (17.5).

    Failure semantics, uniformly across implementations:

    ``NotFoundError``
        Nothing was ever stored at this address, as far as this store knows.
    ``RedactedError``
        Content was stored and removed under authority (17.2).  Never
        collapsed into ``NotFoundError``: 17.1 keeps them as two states.
    ``IntegrityError``
        Bytes came back that do not hash to the address they were fetched
        from, or a declared length did not match.  A trust failure, not a
        caller error.
    ``ConflictError``
        The operation is refused by policy the store enforces -- today, legal
        hold (17.5).
    ``EventualConsistencyError``
        This process wrote the object and the store then said it was absent.
    ``BackendUnavailableError``
        Anything else the underlying system raised.  The outcome is unknown
        and unknown fails closed (6.6).
    """

    def put_content(
        self,
        digest: str,
        payload: bytes,
        *,
        object_type: str = "OpaqueRecord",
        created_by: str = "crg-server",
        legal_hold: bool = False,
    ) -> bool:
        """Store ``payload`` at ``digest``; return whether bytes were written.

        Write-once and deduplicating.  ``False`` means the address was already
        occupied and nothing was transferred -- which is safe precisely
        because the address is the hash, so the occupant cannot be different
        content.  Implementations MUST verify ``digest_of(payload) == digest``
        before writing anything; a caller that supplies a mismatched pair gets
        :class:`IntegrityError` and no write, because accepting it would put
        content at an address that does not describe it and destroy the
        verification every read depends on.

        A digest bearing a tombstone raises :class:`RedactedError` rather than
        being resurrected: 17.2 makes removal an authorized act, and letting
        any caller undo it by posting the bytes again would make the tombstone
        advisory.
        """
        ...

    def get_content(self, digest: str) -> bytes:
        """Return the bytes at ``digest``, verified against it.

        The verification is not optional and not configurable.  See
        :func:`verify_digest`.
        """
        ...

    def has_content(self, digest: str) -> bool:
        """Whether present *and not redacted*.

        Returns ``False`` for a redacted digest, because the question this
        answers is "can I read the bytes".  Use :meth:`content_metadata` to
        distinguish absent from removed.
        """
        ...

    def delete_content(self, digest: str) -> bool:
        """Remove the bytes, keep the envelope (17.2).

        Returns whether bytes were actually removed.  Refuses with
        :class:`ConflictError` while a legal hold is in force (17.5).

        This is the primitive.  It does not write the tombstone and does not
        re-status dependents; :meth:`StoreBackend.redact` composes all three
        in the order the module docstring fixes.  Calling this alone is
        legitimate only for content whose tombstone already exists.
        """
        ...

    def content_metadata(self, digest: str) -> ObjectRecord:
        """The envelope.  Survives redaction with ``present=False``."""
        ...

    def content_status(self, digest: str) -> str:
        """The 12/17.1 lifecycle status, ``ACTIVE`` if none was recorded."""
        ...

    def set_content_status(self, digest: str, status: str, *, reason: str = "") -> None:
        """Record a lifecycle status.  Changes metadata, never content.

        The bytes at ``digest`` still hash to ``digest`` afterwards, which is
        why an independent verifier can keep checking them and reach its own
        conclusion (9.3).  An unrecognised status is a
        :class:`~crg_server.errors.UsageError`, not a stored string: 12 fixes
        the vocabulary and a store that accepted novel statuses would let a
        caller invent a state no reader knows how to fail closed on.
        """
        ...

    def legal_hold(self, digest: str) -> bool:
        """Whether a hold is in force (17.5)."""
        ...

    def set_legal_hold(self, digest: str, held: bool, *, authority: str = "") -> None:
        """Place or release a hold (17.5, 42.3).

        Placing a hold on an unknown digest is allowed and is not a mistake:
        an organisation under a preservation order may need the hold to be in
        place before the object arrives.  Releasing one is an authorized act
        and ``authority`` is carried into the audit event the composite emits.
        """
        ...

    def list_digests(self, *, limit: Optional[int] = None) -> List[str]:
        """Enumerate stored addresses, ascending.

        Enumeration is never load-bearing in this interface: on an object
        store it is the weakest-consistency operation there is (see
        :attr:`ConsistencyModel.list_after_write`).  It exists for export
        (6.2) and operator tooling, and no correctness property depends on a
        listing being complete at any instant.
        """
        ...

    def consistency(self) -> ConsistencyModel:
        """What this implementation actually guarantees."""
        ...

    def close(self) -> None:
        """Release handles.  Idempotent; closing twice is not an error."""
        ...


@runtime_checkable
class MetadataBackend(Protocol):
    """The relational half of 42.1.  PostgreSQL replaces this.

    Identity, status, policy, indexed queries, graph indexes for dependency
    traversal (18.5), the append-only audit log (44.7), the job table (42.4),
    idempotency records (38.4), and tombstones (17.2).

    No method here stores canonical content.  Rows reference content by hash,
    which is what makes the two halves separable and what makes 6.2's export
    a matter of copying a directory and a dump rather than reconstructing a
    graph.

    Failure semantics: :class:`NotFoundError` for a row that does not exist,
    :class:`ConflictError` for an optimistic-lock violation (16.1),
    :class:`~crg_server.errors.UsageError` for a malformed record, and
    :class:`BackendUnavailableError` for everything the driver raised --
    including a failure *during* commit, where the transaction's outcome is
    genuinely unknown and 6.6 requires that be reported rather than assumed
    either way.
    """

    def initialize(self) -> None:
        """Create schema if absent.  Idempotent and safe to run concurrently."""
        ...

    def transaction(self) -> ContextManager[None]:
        """A unit of work.

        On clean exit the work commits; on any exception it is rolled back (or,
        where the implementation offers only mutual exclusion, the lock is
        released and the partial sequence stands -- which is why
        :meth:`consistency` publishes ``multi_statement_atomicity`` and callers
        that need real rollback must check it rather than assume it).
        Re-entrant: a nested ``with`` joins the outer unit rather than opening
        a second one.
        """
        ...

    def lock_dependency_graph(self, case_id: str) -> None:
        """Serialize validation and mutation of one case's dependency DAG."""
        ...

    # -- cases (11.2, 16.1) -------------------------------------------------
    def put_case_version(self, record: CaseVersionRecord) -> None:
        """Append one case version.

        Append-only: a ``(case_id, case_version)`` that already exists is a
        :class:`ConflictError`, never an overwrite.  15.3 forbids silently
        rewriting historical objects and this is where that would happen.
        """
        ...

    def head_version(self, case_id: str) -> int:
        """Highest stored ordinal, ``0`` for an unknown case.

        ``0`` rather than ``NotFoundError`` because the caller's next move is
        almost always "so the next version is ``head + 1``", and version 1 of
        a new case is exactly right.
        """
        ...

    def case_version(
        self, case_id: str, version: Union[int, str, None] = None
    ) -> CaseVersionRecord:
        """One version: ``None`` for head, an ordinal, or a content hash.

        11.2 requires a prior version to remain addressable after
        supersession, so history reads as readily as the head.
        """
        ...

    def list_case_versions(self, case_id: str) -> List[CaseVersionRecord]:
        """Every version, oldest first.  Empty list for an unknown case."""
        ...

    def list_case_ids(self) -> List[str]:
        """Every known case identifier, ascending."""
        ...

    # -- typed dependency graph (18) ---------------------------------------
    def record_edge(self, record: EdgeRecord) -> None:
        """Index one typed edge, replacing any edge with the same ``edge_id``.

        Replacement rather than conflict: an edge identity is
        ``source -> target # type`` and re-recording it is a caller restating
        a fact, not asserting a new one.
        """
        ...

    def edges_from(self, source: str) -> List[EdgeRecord]:
        """Outgoing edges, ``edge_id`` ascending.  Forward traversal (18.5)."""
        ...

    def edges_to(self, target: str) -> List[EdgeRecord]:
        """Incoming edges, ``edge_id`` ascending.  Reverse traversal.

        The reverse direction is the one impact analysis needs -- "what
        depends on the thing I am about to change" (18.5, 30) -- and it is the
        direction a naive schema makes a table scan.  Implementations MUST
        index it.
        """
        ...

    def edges_for_case(self, case_id: str) -> List[EdgeRecord]:
        """Every edge recorded against a case, ``edge_id`` ascending."""
        ...

    # -- certificates (42.4) ------------------------------------------------
    def register_certificate(self, record: CertificateRecord) -> None:
        """Record that a certificate is live for a case.

        The 42.4 gate -- that a failed job MUST NOT produce a valid
        certificate -- is enforced *above* this method, by the caller that
        checks the job's status.  This layer stores what it is told; putting
        the gate here as well would duplicate it, and a duplicated gate is a
        gate that will eventually disagree with itself.
        """
        ...

    def certificate(self, case_id: str, certificate_id: str) -> CertificateRecord:
        """One registration, or :class:`NotFoundError`."""
        ...

    def list_certificates(self, case_id: str) -> List[CertificateRecord]:
        """Live registrations for a case, ``certificate_id`` ascending."""
        ...

    def unregister_certificates(self, job_id: str) -> int:
        """Withdraw the registrations made by a job; return how many.

        Used when a commit failed partway.  Removes *registrations* only; the
        certificate content stays at its address (6.4).
        """
        ...

    # -- idempotency (38.4) -------------------------------------------------
    def idempotency_lookup(self, key: str) -> Optional[IdempotencyRecord]:
        """The recorded response for a key, or ``None``.

        ``None`` rather than an exception: absence is the ordinary case on a
        first request, and an exception would make the ordinary path the
        exceptional one.
        """
        ...

    def idempotency_record(self, record: IdempotencyRecord) -> None:
        """Record a response against a key, replacing any earlier record."""
        ...

    def list_idempotency(self) -> List[IdempotencyRecord]:
        """Every replay record, key ascending, for verified recovery/export."""
        ...

    # -- jobs (42.4) --------------------------------------------------------
    def save_job(self, record: JobRecord) -> None:
        """Persist or update a job record."""
        ...

    def compare_and_set_job(
        self,
        record: JobRecord,
        *,
        expected_statuses: Sequence[str],
        expected_phase: str,
    ) -> bool:
        """Replace a job iff its durable status and publication phase match."""
        ...

    def load_job(self, job_id: str) -> Optional[JobRecord]:
        """One job record, or ``None``."""
        ...

    def list_jobs(self) -> List[JobRecord]:
        """Every job record, ``job_id`` ascending."""
        ...

    # -- audit (44.7) -------------------------------------------------------
    def append_audit(self, recorded_at: str, event_json: str) -> int:
        """Append one immutable event; return its assigned sequence number.

        Append-only in the strong sense: this interface has no update and no
        delete for audit rows, so there is no call a compromised caller can
        make to rewrite history.  That is not the same as tamper-*proof* --
        anyone with direct database access can still edit a table -- and no
        implementation here claims otherwise.
        """
        ...

    def read_audit(
        self, *, after_seq: int = 0, limit: Optional[int] = None
    ) -> List[AuditRecord]:
        """Events with ``seq > after_seq``, ascending, up to ``limit``."""
        ...

    # -- tombstones (17.2) --------------------------------------------------
    def put_tombstone(self, record: TombstoneRecord) -> None:
        """Record a removal.  Re-recording an existing tombstone is a no-op.

        Idempotent because redaction may be retried after a partial failure,
        and the second attempt must not be a conflict that leaves an operator
        unsure whether the first one landed.
        """
        ...

    def get_tombstone(self, digest: str) -> Optional[TombstoneRecord]:
        """The tombstone for a digest, or ``None`` if it was never removed."""
        ...

    def list_tombstones(self) -> List[TombstoneRecord]:
        """Every tombstone, ``content_hash`` ascending.  17.2 export."""
        ...

    def consistency(self) -> ConsistencyModel:
        """What this implementation actually guarantees."""
        ...

    def close(self) -> None:
        """Release handles.  Idempotent."""
        ...


@runtime_checkable
class StoreBackend(Protocol):
    """The composite the server holds: both halves plus what spans them.

    A deployment picks one object store and one metadata store; this joins
    them, publishes the joined :class:`ConsistencyModel`, and owns the two
    operations that are inherently cross-store -- reading a case (metadata
    resolves a hash, the object store returns the bytes) and redacting an
    object (tombstone in metadata, bytes out of the object store, dependents
    re-statused).
    """

    @property
    def objects(self) -> ObjectStoreBackend:
        """The content-addressed half."""
        ...

    @property
    def metadata(self) -> MetadataBackend:
        """The relational half."""
        ...

    def put_case(
        self,
        case: Mapping[str, Any],
        *,
        expected_parent_version: Optional[int] = None,
        created_by: str = "crg-server",
    ) -> CaseVersionRecord:
        """Append a case version: content first, then the metadata row (16.1).

        Cross-store, which is why it is here and not on either half.  A stale
        ``expected_parent_version`` is a :class:`ConflictError`.
        """
        ...

    def get_case(
        self, case_id: str, version: Union[int, str, None] = None
    ) -> Dict[str, Any]:
        """Read a case version: metadata resolves the address, objects verify it.

        ``None`` is head, an ``int`` is an ordinal, a ``sha256:`` string is a
        content address.  11.2 keeps history as readable as the head.
        """
        ...

    def redact(
        self,
        digest: str,
        *,
        reason: str,
        authority: str,
        permitted_disclosure: str = DEFAULT_PERMITTED_DISCLOSURE,
    ) -> TombstoneRecord:
        """Remove content, preserve identity and structure (17.2, 17.3, 17.5).

        In this order, and the order is the contract:

        1. refuse if a legal hold is in force (17.5) -- ``ConflictError``;
        2. collect the typed edges touching the object, because the tombstone
           must carry them;
        3. write the tombstone (17.2);
        4. delete the bytes;
        5. status the object ``REDACTED`` and every reachable dependent
           certificate ``UNVERIFIABLE_REDACTED`` unless it carries a
           separately sufficient proof artifact that is still present (17.3);
        6. append an audit event (44.7).

        Steps 3 and 4 in that order because an interrupted redaction must
        leave content already unreadable through the API rather than content
        gone with nothing to explain it.  Re-running after an interruption is
        safe: every step is idempotent.
        """
        ...

    def dependents_of(self, source: str) -> List[str]:
        """Every node reachable from ``source`` by outgoing edges (18.5)."""
        ...

    def consistency(self) -> ConsistencyModel:
        """The joined guarantee.  Weakest on every axis; see :meth:`ConsistencyModel.join`."""
        ...

    def close(self) -> None:
        """Close both halves.  Idempotent."""
        ...


# ---------------------------------------------------------------------------
# Conformance checking.  ``runtime_checkable`` Protocols only check that names
# exist; a seam whose whole claim is "these are interchangeable" needs more
# than that, so arity is checked too.
# ---------------------------------------------------------------------------
def _protocol_methods(protocol: type) -> Tuple[str, ...]:
    names = []
    for name, value in vars(protocol).items():
        if name.startswith("_"):
            continue
        if isinstance(value, property):
            names.append(name)
        elif callable(value):
            names.append(name)
    return tuple(sorted(names))


#: The interfaces as flat name tuples, so a test can assert against a literal
#: rather than against whatever the class happens to contain today.
OBJECT_STORE_METHODS: Tuple[str, ...] = (
    "close",
    "consistency",
    "content_metadata",
    "content_status",
    "delete_content",
    "get_content",
    "has_content",
    "legal_hold",
    "list_digests",
    "put_content",
    "set_content_status",
    "set_legal_hold",
)

METADATA_METHODS: Tuple[str, ...] = (
    "append_audit",
    "case_version",
    "certificate",
    "close",
    "compare_and_set_job",
    "consistency",
    "edges_for_case",
    "edges_from",
    "edges_to",
    "get_tombstone",
    "head_version",
    "idempotency_lookup",
    "idempotency_record",
    "initialize",
    "list_case_ids",
    "list_case_versions",
    "list_certificates",
    "list_idempotency",
    "list_jobs",
    "list_tombstones",
    "load_job",
    "lock_dependency_graph",
    "put_case_version",
    "put_tombstone",
    "read_audit",
    "record_edge",
    "register_certificate",
    "save_job",
    "transaction",
    "unregister_certificates",
)

STORE_METHODS: Tuple[str, ...] = (
    "close",
    "consistency",
    "dependents_of",
    "get_case",
    "metadata",
    "objects",
    "put_case",
    "redact",
)


def _signature_complaint(name: str, declared: Any, actual: Any) -> str:
    """Compare parameter *names* and kinds, ignoring defaults and annotations.

    Names rather than positions because every method in this interface is
    called with keywords for anything optional, so a backend that renamed
    ``reason`` to ``why`` would type-check and then fail at the one call site
    that matters.
    """
    try:
        want = inspect.signature(declared)
        have = inspect.signature(actual)
    except (TypeError, ValueError) as error:  # builtins, C functions
        return f"{name}: signature not introspectable ({error})"
    want_names = [p for p in want.parameters if p != "self"]
    have_names = [p for p in have.parameters if p != "self"]
    if want_names != have_names:
        return f"{name}: parameters {have_names} do not match interface {want_names}"
    for parameter in want_names:
        if want.parameters[parameter].kind is not have.parameters[parameter].kind:
            return (
                f"{name}: parameter {parameter!r} is "
                f"{have.parameters[parameter].kind.description}, interface declares "
                f"{want.parameters[parameter].kind.description}"
            )
    return ""


def conformance_complaints(candidate: Any, protocol: type) -> List[str]:
    """Every way ``candidate`` fails to be a ``protocol``.  Empty list is pass.

    Returns complaints rather than raising so a test can print all of them at
    once; a seam that reports one missing method per run is a seam nobody
    finishes wiring up.
    """
    complaints: List[str] = []
    for name in _protocol_methods(protocol):
        declared = getattr(protocol, name)
        if isinstance(declared, property):
            if not hasattr(candidate, name):
                complaints.append(f"{name}: missing (interface declares a property)")
            continue
        actual = getattr(candidate, name, None)
        if actual is None:
            complaints.append(f"{name}: missing")
            continue
        if not callable(actual):
            complaints.append(f"{name}: present but not callable ({type(actual).__name__})")
            continue
        complaint = _signature_complaint(name, declared, actual)
        if complaint:
            complaints.append(complaint)
    return complaints


def require_conformance(candidate: Any, protocol: type) -> None:
    """Raise :class:`BackendConfigurationError` unless ``candidate`` conforms.

    Called by :func:`crg_server.backends.select_backend` on whatever a
    deployment configured, so a mis-wired third-party adapter is refused at
    start-up with a list of what is wrong rather than at 3am with an
    ``AttributeError`` inside a certification.
    """
    complaints = conformance_complaints(candidate, protocol)
    if complaints:
        raise BackendConfigurationError(
            f"{type(candidate).__name__} does not implement {protocol.__name__}",
            remedy="implement the missing methods with the declared parameter names",
            detail={"complaints": complaints, "interface": protocol.__name__},
        )
