"""Persistence backends: the 42.1 seam, its three implementations, and the
factory that proves backend choice is configuration rather than code.

Normative basis: 42.1 (storage model), 42.2 (local profile), 42.3 (enterprise
profile), 6.3 (no central-service dependency), 6.6 (fail closed), 9.2
(standard-library-only kernel).

Specification 42.2 and 42.3 describe two deployments of the same system, not
two systems.  The only way to say that and mean it is to have one interface,
more than one implementation, and a single test suite that both must pass --
otherwise "supports PostgreSQL" is a plan.  That is what this subpackage is:

* :mod:`~crg_server.backends.base` -- the interface, split along 42.1's own
  seam into a content-addressed object store and a relational metadata store,
  with each implementation's consistency model published rather than assumed.
* :mod:`~crg_server.backends.local` -- 42.2, by adapting the ``CaseStore`` the
  server already ships.  **Real.**  It is the shipped store, wrapped.
* :mod:`~crg_server.backends.postgres` -- 42.3's relational half.
  **Interface-complete; live contract passed on PostgreSQL 16.**
* :mod:`~crg_server.backends.s3` -- 42.3's object half.
  **Interface-complete; live contract passed on single-node MinIO.**
* :mod:`~crg_server.backends.composite` -- the join, and the two operations
  (case reads, redaction) that genuinely span both halves.
* :mod:`~crg_server.backends.fakes` -- the doubles that execute the two
  enterprise adapters for real, faults included, and cannot substitute for a
  real distributed/HA service qualification. Read the adapter module
  disclosures before quoting any of this.

Neither enterprise adapter imports its driver.  ``import
crg_server.backends`` on a machine with no ``psycopg`` and no ``boto3``
succeeds, and it succeeds *by design* -- 42.2 promises "no required external
services" and an enterprise adapter that broke the local profile's dependency
set would break that promise for every deployment that never wanted it.  The
refusal arrives instead from
:class:`~crg_server.backends.base.DriverNotInstalledError`, at construction,
naming the package and the install line.

:func:`select_backend` is the whole configuration story.  It refuses an
unknown backend name rather than defaulting to the local profile: 42.2 and
42.3 differ in *where the data lives*, and a typo that quietly wrote
enterprise data to a local directory would be a data-loss incident wearing a
default value's clothes (6.6).
"""
from __future__ import annotations

import hashlib
import os
from typing import Any, Dict, Mapping, Optional, Tuple

from .base import (
    METADATA_METHODS,
    OBJECT_STORE_METHODS,
    STORE_METHODS,
    AuditRecord,
    BackendConfigurationError,
    BackendError,
    BackendUnavailableError,
    CaseVersionRecord,
    CertificateRecord,
    ConsistencyModel,
    DriverNotInstalledError,
    EdgeRecord,
    EventualConsistencyError,
    IdempotencyRecord,
    JobRecord,
    MetadataBackend,
    ObjectRecord,
    ObjectStoreBackend,
    StoreBackend,
    TombstoneRecord,
    conformance_complaints,
    digest_of,
    require_conformance,
    split_digest,
    verify_digest,
)
from .composite import CompositeBackend
from .facade import ApplicationStore
from .local import LocalMetadataStore, LocalObjectStore, SqliteFilesystemBackend

__all__ = [
    # interface
    "ObjectStoreBackend",
    "MetadataBackend",
    "StoreBackend",
    "ConsistencyModel",
    "ObjectRecord",
    "CaseVersionRecord",
    "EdgeRecord",
    "CertificateRecord",
    "IdempotencyRecord",
    "JobRecord",
    "AuditRecord",
    "TombstoneRecord",
    "OBJECT_STORE_METHODS",
    "METADATA_METHODS",
    "STORE_METHODS",
    "conformance_complaints",
    "require_conformance",
    "digest_of",
    "split_digest",
    "verify_digest",
    # errors
    "BackendError",
    "BackendUnavailableError",
    "BackendConfigurationError",
    "DriverNotInstalledError",
    "EventualConsistencyError",
    # implementations
    "SqliteFilesystemBackend",
    "LocalObjectStore",
    "LocalMetadataStore",
    "CompositeBackend",
    "ApplicationStore",
    # configuration
    "BACKEND_NAMES",
    "OBJECT_STORE_NAMES",
    "METADATA_NAMES",
    "select_backend",
    "backend_config_from_env",
]

#: The composite profiles a deployment may name.  Closed: an unrecognised
#: value is refused (6.6), never defaulted.
BACKEND_NAMES: Tuple[str, ...] = ("local", "composite")

#: The halves a ``composite`` profile may pair.  ``filesystem`` and ``sqlite``
#: are the 42.2 components used on their own -- a deployment that wanted
#: PostgreSQL metadata with local disks, or S3 objects with SQLite metadata,
#: is expressible and is a legitimate reading of 42.3's "or equivalent".
OBJECT_STORE_NAMES: Tuple[str, ...] = ("filesystem", "s3")
METADATA_NAMES: Tuple[str, ...] = ("sqlite", "postgres")


def _refuse(name: str, kind: str, known: Tuple[str, ...]) -> BackendConfigurationError:
    return BackendConfigurationError(
        f"unknown {kind} backend {name!r}",
        remedy=(
            f"use one of {list(known)}.  There is deliberately no default: 42.2 and "
            "42.3 differ in where the data lives, and silently falling back to the "
            "local profile would write enterprise data to a directory (6.6)"
        ),
        detail={"requested": name, "known": list(known), "kind": kind},
    )


def _require(config: Mapping[str, Any], key: str, *, kind: str) -> Any:
    if key not in config or config[key] in (None, ""):
        raise BackendConfigurationError(
            f"the {kind} backend requires {key!r}",
            remedy=f"add {key!r} to the {kind} backend configuration",
            detail={"missing": key, "kind": kind, "supplied": sorted(config)},
        )
    return config[key]


def _build_object_store(config: Mapping[str, Any]) -> ObjectStoreBackend:
    name = str(config.get("backend") or "")
    if name == "filesystem":
        from .local import SqliteFilesystemBackend as _Local

        root = _require(config, "root", kind="filesystem object store")
        return _Local(str(root)).objects
    if name == "s3":
        from .s3 import S3ObjectStore  # local import: keeps boto3 optional

        return S3ObjectStore(
            bucket=str(_require(config, "bucket", kind="s3 object store")),
            client=config.get("client"),
            prefix=str(config.get("prefix", "crg/")),
            multipart_threshold=int(
                config.get("multipart_threshold", 8 * 1024 * 1024)
            ),
            part_size=int(config.get("part_size", 8 * 1024 * 1024)),
            server_side_encryption=str(config.get("server_side_encryption", "")),
            kms_key_id=str(config.get("kms_key_id", "")),
            conditional_writes=bool(config.get("conditional_writes", True)),
            client_kwargs=config.get("client_kwargs"),
        )
    raise _refuse(name, "object store", OBJECT_STORE_NAMES)


def _build_metadata_store(config: Mapping[str, Any]) -> MetadataBackend:
    name = str(config.get("backend") or "")
    if name == "sqlite":
        from .local import SqliteFilesystemBackend as _Local

        root = _require(config, "root", kind="sqlite metadata store")
        return _Local(str(root)).metadata
    if name == "postgres":
        from .postgres import PostgresMetadataStore  # local import: keeps psycopg optional

        return PostgresMetadataStore(
            connect=config.get("connect"),
            dsn=str(config.get("dsn", "")),
            driver_errors=tuple(config.get("driver_errors") or ()),
        )
    raise _refuse(name, "metadata", METADATA_NAMES)


def select_backend(config: Optional[Mapping[str, Any]] = None) -> Any:
    """Build the store a deployment configured.  Backend choice is data.

    ``config`` is a mapping, so it can come from a JSON file, an environment
    block (see :func:`backend_config_from_env`), or a test.  Two shapes::

        {"backend": "local", "root": "/var/lib/crg"}

        {"backend": "composite",
         "objects":  {"backend": "s3", "bucket": "crg-prod", "client": ...},
         "metadata": {"backend": "postgres", "dsn": "postgresql://..."}}

    Everything this function can refuse, it refuses *here*, at start-up: an
    unknown backend name, a missing bucket, a missing DSN with no driver
    installed, an adapter that does not implement the interface.  6.6's fail
    closed is most useful before a request has been accepted, and a storage
    misconfiguration discovered during a certification is a misconfiguration
    discovered too late.
    """
    if config is None:
        raise BackendConfigurationError(
            "no storage configuration was supplied",
            remedy=(
                "pass {'backend': 'local', 'root': ...} for the 42.2 profile, or a "
                "'composite' pairing for 42.3.  There is no default"
            ),
            detail={"known": list(BACKEND_NAMES)},
        )
    name = str(config.get("backend") or "")
    if name == "local":
        root = _require(config, "root", kind="local")
        backend = SqliteFilesystemBackend(str(root))
        require_conformance(backend, StoreBackend)
        return backend
    if name == "composite":
        objects = _build_object_store(
            config.get("objects") or {"backend": "__missing__"}
        )
        metadata = _build_metadata_store(
            config.get("metadata") or {"backend": "__missing__"}
        )
        backend = CompositeBackend(
            objects,
            metadata,
            name=str(config.get("name") or "composite"),
            initialize=bool(config.get("initialize", True)),
        )
        require_conformance(backend, StoreBackend)
        return backend
    raise _refuse(name, "store", BACKEND_NAMES)


def backend_config_from_env(
    env: Optional[Mapping[str, str]] = None,
) -> Dict[str, Any]:
    """Read a :func:`select_backend` config out of the process environment.

    ``CRG_STORE_BACKEND`` selects the profile; ``CRG_STORE_ROOT``,
    ``CRG_OBJECT_BACKEND``, ``CRG_S3_BUCKET``, ``CRG_S3_PREFIX``,
    ``CRG_METADATA_BACKEND``, and ``CRG_POSTGRES_DSN`` fill it in.  A client
    object cannot come from an environment variable, so an ``s3`` selection
    built this way will construct a real boto3 client -- and raise
    :class:`DriverNotInstalledError` by name if boto3 is absent, which is the
    intended behaviour rather than a gap.

    No variable has a default.  An empty environment produces a config that
    :func:`select_backend` refuses, which is the correct outcome: a server
    that started with no storage configuration and picked one is a server
    whose data location nobody decided.
    """
    source = os.environ if env is None else env
    tenant_id = str(source.get("CRG_STORE_TENANT", "")).strip()
    config: Dict[str, Any] = {
        "backend": source.get("CRG_STORE_BACKEND", ""),
        "tenant_id": tenant_id,
    }
    if config["backend"] == "local":
        config["root"] = source.get("CRG_STORE_ROOT", "")
        return config
    if config["backend"] == "composite":
        objects: Dict[str, Any] = {"backend": source.get("CRG_OBJECT_BACKEND", "")}
        if objects["backend"] == "s3":
            objects["bucket"] = source.get("CRG_S3_BUCKET", "")
            base_prefix = source.get("CRG_S3_PREFIX", "crg/").rstrip("/") + "/"
            if tenant_id:
                partition = hashlib.sha256(tenant_id.encode("utf-8")).hexdigest()[:24]
                base_prefix += f"tenants/{partition}/"
            objects["prefix"] = base_prefix
            objects["server_side_encryption"] = source.get("CRG_S3_SSE", "")
            objects["kms_key_id"] = source.get("CRG_S3_KMS_KEY_ID", "")
            client_kwargs: Dict[str, Any] = {}
            if source.get("CRG_S3_ENDPOINT_URL"):
                client_kwargs["endpoint_url"] = source["CRG_S3_ENDPOINT_URL"]
            if source.get("CRG_S3_REGION"):
                client_kwargs["region_name"] = source["CRG_S3_REGION"]
            if client_kwargs:
                objects["client_kwargs"] = client_kwargs
        else:
            objects["root"] = source.get("CRG_STORE_ROOT", "")
        metadata: Dict[str, Any] = {"backend": source.get("CRG_METADATA_BACKEND", "")}
        if metadata["backend"] == "postgres":
            metadata["dsn"] = source.get("CRG_POSTGRES_DSN", "")
        else:
            metadata["root"] = source.get("CRG_STORE_ROOT", "")
        config["objects"] = objects
        config["metadata"] = metadata
    return config
