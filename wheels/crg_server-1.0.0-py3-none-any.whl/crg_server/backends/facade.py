"""Application-facing facade for the pluggable 42.1 storage backends.

The backend protocols deliberately expose storage primitives.  The server,
job queue, event bus, and bundle code use the richer ``CaseStore`` surface.
This class is the only translation between those two vocabularies, which
keeps every application path identical for the 42.2 local and 42.3
PostgreSQL/S3 profiles.

It does not weaken either boundary: object reads are still verified by the
object adapter, cases still use optimistic version insertion, and certificate
registration still refuses every job that is not terminally ``SUCCEEDED``.
"""
from __future__ import annotations

import json
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence

from crg_model.canonical import canonical_json
from crg_model.case import refresh_case_metadata
from crg_model.edges import DependencyEdge, DependencyGraph
from crg_model.envelope import utc_now

from ..errors import ConflictError, NotFoundError, UsageError
from .base import (
    CertificateRecord,
    EdgeRecord,
    IdempotencyRecord,
    JobRecord as BackendJobRecord,
    StoreBackend,
    TombstoneRecord,
    digest_of,
    require_conformance,
)

__all__ = ["ApplicationStore"]


def _object_type_of(value: Any) -> str:
    if isinstance(value, Mapping):
        for key in ("object_type", "record_type"):
            if value.get(key):
                return str(value[key])
        if value.get("certificate_id") and value.get("outcome"):
            return "DecisionCertificate"
        if value.get("case_id") and value.get("status"):
            return "CRGCase"
    return "OpaqueRecord"


class ApplicationStore:
    """Adapt a conforming :class:`StoreBackend` to the live server surface."""

    def __init__(
        self,
        backend: StoreBackend,
        *,
        root_label: str = "enterprise",
        tenant_id: str = "",
    ) -> None:
        require_conformance(backend, StoreBackend)
        self.backend = backend
        self.objects = backend.objects
        self.metadata = backend.metadata
        # ``crg-serve`` prints this value; it is a disclosure label, never a
        # filesystem path used by the enterprise profile.
        self.root = root_label
        self.tenant_id = str(tenant_id).strip()
        self._closed = False

    # -- protected canonical objects -------------------------------------
    def put_object(
        self,
        obj: Any,
        *,
        object_type: Optional[str] = None,
        created_by: str = "crg-server",
        dependencies: Sequence[Any] = (),
        case_id: Optional[str] = None,
        legal_hold: bool = False,
    ) -> str:
        if hasattr(obj, "to_canonical"):
            obj = obj.to_canonical()
        payload = canonical_json(obj).encode("utf-8")
        digest = digest_of(payload)
        self.objects.put_content(
            digest,
            payload,
            object_type=object_type or _object_type_of(obj),
            created_by=created_by,
            legal_hold=legal_hold,
        )
        if dependencies:
            self.record_edges(dependencies, case_id=case_id)
        return digest

    def put_successor(
        self, predecessor_hash: Optional[str], obj: Mapping[str, Any], **kwargs: Any
    ) -> str:
        record = dict(obj)
        parents = list(record.get("parent_hashes") or ())
        if predecessor_hash and predecessor_hash not in parents:
            parents.append(predecessor_hash)
        if parents:
            record["parent_hashes"] = parents
        return self.put_object(record, **kwargs)

    def get_object(self, digest: str) -> Any:
        payload = self.objects.get_content(digest)
        try:
            return json.loads(payload.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise UsageError(f"protected object {digest} is not canonical JSON: {error}") from error

    def has_object(self, digest: str) -> bool:
        return self.objects.has_content(digest)

    def object_metadata(self, digest: str) -> Dict[str, Any]:
        return self.objects.content_metadata(digest).to_canonical()

    def object_status(self, digest: str) -> str:
        return self.objects.content_status(digest)

    def set_object_status(self, digest: str, status: str, *, reason: str = "") -> None:
        self.objects.set_content_status(digest, status, reason=reason)

    def set_legal_hold(self, digest: str, held: bool, *, authority: str = "") -> None:
        self.objects.set_legal_hold(digest, held, authority=authority)
        self.append_audit({
            "event": "legal_hold.changed", "content_hash": digest,
            "held": bool(held), "authority": authority, "recorded_at": utc_now(),
        })

    # -- case history -----------------------------------------------------
    def put_case(
        self,
        case: Mapping[str, Any],
        *,
        expected_parent_version: Optional[int] = None,
        created_by: str = "crg-server",
        derived_from: Optional[Mapping[str, Any]] = None,
    ) -> str:
        body = dict(case)
        if derived_from:
            body["derived_from"] = dict(derived_from)
        refresh_case_metadata(body)
        record = self.backend.put_case(
            body,
            expected_parent_version=expected_parent_version,
            created_by=created_by,
        )
        return record.content_hash

    def get_case(self, case_id: str, version: Optional[Any] = None) -> Dict[str, Any]:
        return self.backend.get_case(case_id, version)

    def head_version(self, case_id: str) -> int:
        return self.metadata.head_version(case_id)

    def case_exists(self, case_id: str) -> bool:
        return self.head_version(case_id) > 0

    def list_versions(self, case_id: str) -> List[str]:
        return [r.content_hash for r in self.metadata.list_case_versions(case_id)]

    def case_index(self, case_id: str) -> List[Dict[str, Any]]:
        result: List[Dict[str, Any]] = []
        for record in self.metadata.list_case_versions(case_id):
            item = record.to_canonical()
            if item.get("derived_from"):
                try:
                    item["derived_from"] = json.loads(str(item["derived_from"]))
                except json.JSONDecodeError:
                    pass
            result.append(item)
        return result

    def list_cases(self) -> List[str]:
        return self.metadata.list_case_ids()

    # -- typed dependency graph ------------------------------------------
    def record_edges(
        self, edges: Iterable[Any], *, case_id: Optional[str] = None
    ) -> List[str]:
        records: List[EdgeRecord] = []
        typed_edges: List[DependencyEdge] = []
        for edge in edges:
            if isinstance(edge, DependencyEdge):
                source, target = edge.source, edge.target
                edge_type = str(edge.edge_type)
                edge_id = str(edge.edge_id)
                scope = str(getattr(edge, "scope", "") or "")
            else:
                value = dict(edge)
                source, target = str(value["source"]), str(value["target"])
                edge_type = str(value["edge_type"])
                edge_id = str(value.get("edge_id") or f"{source}->{target}#{edge_type}")
                scope = str(value.get("scope") or "")
            typed = DependencyEdge(edge_id=edge_id, source=source, target=target,
                                   edge_type=edge_type, scope=scope or None)
            typed_edges.append(typed)
            records.append(EdgeRecord(
                edge_id=edge_id, case_id=str(case_id or ""), source=source,
                target=target, edge_type=edge_type, scope=scope,
                minimum_action=typed.minimum_action, recorded_at=utc_now(),
            ))
        graph_id = str(case_id or "")
        replacement_ids = {edge.edge_id for edge in typed_edges}
        with self.metadata.transaction():
            self.metadata.lock_dependency_graph(graph_id)
            existing = self.metadata.edges_for_case(graph_id)
            graph = DependencyGraph()
            graph.add_edges(
                DependencyEdge(edge_id=row.edge_id, source=row.source, target=row.target,
                               edge_type=row.edge_type, scope=row.scope or None)
                for row in existing if row.edge_id not in replacement_ids
            )
            try:
                graph.add_edges(typed_edges)
            except ValueError as exc:
                raise ConflictError(
                    f"dependency batch would violate acyclicity: {exc}",
                    remedy="represent feedback through successor versions, producing a DAG",
                ) from exc
            for record in records:
                self.metadata.record_edge(record)
        return [record.edge_id for record in records]

    def edges_for(self, case_id: str) -> List[Dict[str, Any]]:
        return [r.to_canonical() for r in self.metadata.edges_for_case(case_id)]

    def edges_from(self, source: str) -> List[Dict[str, Any]]:
        return [r.to_canonical() for r in self.metadata.edges_from(source)]

    def edges_to(self, target: str) -> List[Dict[str, Any]]:
        return [r.to_canonical() for r in self.metadata.edges_to(target)]

    def dependents_of(self, source: str) -> List[str]:
        return self.backend.dependents_of(source)

    # -- certificates -----------------------------------------------------
    def register_certificate(
        self,
        case_id: str,
        certificate: Mapping[str, Any],
        *,
        job: Any,
        dependencies: Sequence[Any] = (),
    ) -> str:
        status = str(getattr(job, "status", "") or "")
        if status != "SUCCEEDED":
            raise ConflictError(
                f"job {getattr(job, 'job_id', '?')} is {status or 'UNKNOWN'}; "
                "a certificate may only be registered by a SUCCEEDED job (42.4)"
            )
        certificate_id = str(certificate.get("certificate_id") or "")
        if not certificate_id:
            raise UsageError("a certificate must carry a certificate_id (spec 29.4)")
        digest = self.put_object(
            certificate, object_type="DecisionCertificate",
            created_by=str(getattr(job, "actor", "crg-server")),
        )
        outcome = str(certificate.get("outcome") or "")
        self.metadata.register_certificate(CertificateRecord(
            case_id=case_id,
            certificate_id=certificate_id,
            content_hash=digest,
            job_id=str(getattr(job, "job_id", "")),
            outcome=outcome,
            affirmative=bool(certificate.get("affirmative", not outcome.startswith("BLOCKED"))),
            registered_at=utc_now(),
        ))
        if dependencies:
            self.record_edges(dependencies, case_id=case_id)
        return digest

    def unregister_certificates(self, job_id: str) -> int:
        return self.metadata.unregister_certificates(job_id)

    def list_certificates(self, case_id: str) -> List[Dict[str, Any]]:
        result = []
        for record in self.metadata.list_certificates(case_id):
            item = record.to_canonical()
            item["status"] = self.objects.content_status(record.content_hash)
            result.append(item)
        return result

    def certificate_status(self, case_id: str, certificate_id: str) -> str:
        record = self.metadata.certificate(case_id, certificate_id)
        return self.objects.content_status(record.content_hash)

    # -- audit, replay, and jobs -----------------------------------------
    def append_audit(self, event: Any) -> None:
        if hasattr(event, "to_canonical"):
            event = event.to_canonical()
        if not isinstance(event, Mapping):
            raise UsageError("an audit event must be a mapping (spec 44.7)")
        record = dict(event)
        supplied_tenant = str(record.get("tenant_id") or "")
        if self.tenant_id and supplied_tenant and supplied_tenant != self.tenant_id:
            raise UsageError(
                f"audit event for tenant {supplied_tenant!r} cannot enter store "
                f"bound to {self.tenant_id!r} (44.5)"
            )
        if self.tenant_id:
            record["tenant_id"] = self.tenant_id
        record.setdefault("recorded_at", utc_now())
        self.metadata.append_audit(str(record["recorded_at"]), canonical_json(record))

    def audit_log(self, *, case_id: Optional[str] = None) -> List[Dict[str, Any]]:
        events = [json.loads(record.event_json) for record in self.metadata.read_audit()]
        return events if case_id is None else [e for e in events if e.get("case_id") == case_id]

    def audit_records(
        self, *, after_seq: int = 0, limit: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        return [
            {"seq": record.seq, "recorded_at": record.recorded_at,
             "event": json.loads(record.event_json)}
            for record in self.metadata.read_audit(after_seq=after_seq, limit=limit)
        ]

    @staticmethod
    def _replay_key(namespace: str, key: str) -> str:
        return f"{namespace}:{key}"

    def _lookup_replay(self, namespace: str, key: str) -> Optional[Dict[str, Any]]:
        record = self.metadata.idempotency_lookup(self._replay_key(namespace, key))
        return record.to_canonical() if record else None

    def _record_replay(
        self, namespace: str, key: str, request_hash: str, response: Any, status: int
    ) -> None:
        self.metadata.idempotency_record(IdempotencyRecord(
            key=self._replay_key(namespace, key), request_hash=request_hash,
            response_json=canonical_json(response), status=int(status), created_at=utc_now(),
        ))

    def idempotent_lookup(self, key: str) -> Optional[Dict[str, Any]]:
        return self._lookup_replay("client", key)

    def idempotent_record(self, key: str, request_hash: str, response: Any, status: int) -> None:
        self._record_replay("client", key, request_hash, response, status)

    def canonical_lookup(self, request_hash: str) -> Optional[Dict[str, Any]]:
        return self._lookup_replay("canonical", request_hash)

    def canonical_record(self, request_hash: str, response: Any, status: int) -> None:
        self._record_replay("canonical", request_hash, request_hash, response, status)

    def save_job(self, job_id: str, record: Mapping[str, Any]) -> None:
        existing = self.metadata.load_job(job_id)
        payload_json = existing.payload_json if existing else ""
        self.metadata.save_job(BackendJobRecord(
            job_id=job_id, record_json=canonical_json(dict(record)),
            updated_at=utc_now(), payload_json=payload_json,
        ))

    def compare_and_set_job(
        self,
        job_id: str,
        record: Mapping[str, Any],
        *,
        expected_statuses: Sequence[str],
        expected_phase: str,
    ) -> bool:
        existing = self.metadata.load_job(job_id)
        if existing is None:
            return False
        return bool(self.metadata.compare_and_set_job(
            BackendJobRecord(
                job_id=job_id,
                record_json=canonical_json(dict(record)),
                updated_at=utc_now(),
                payload_json=existing.payload_json,
            ),
            expected_statuses=expected_statuses,
            expected_phase=expected_phase,
        ))

    def load_job(self, job_id: str) -> Optional[Dict[str, Any]]:
        record = self.metadata.load_job(job_id)
        return json.loads(record.record_json) if record else None

    def list_jobs(self) -> List[Dict[str, Any]]:
        return [json.loads(record.record_json) for record in self.metadata.list_jobs()]

    def save_job_payload(self, job_id: str, payload: Mapping[str, Any]) -> None:
        existing = self.metadata.load_job(job_id)
        if existing is None:
            raise NotFoundError(f"cannot persist payload for unknown job {job_id!r}")
        self.metadata.save_job(BackendJobRecord(
            job_id=job_id, record_json=existing.record_json,
            updated_at=utc_now(), payload_json=canonical_json(dict(payload)),
        ))

    def load_job_payload(self, job_id: str) -> Optional[Dict[str, Any]]:
        record = self.metadata.load_job(job_id)
        return json.loads(record.payload_json) if record and record.payload_json else None

    # -- deletion and operational checks ---------------------------------
    def is_redacted(self, digest: str) -> bool:
        return self.metadata.get_tombstone(digest) is not None

    def tombstone(self, digest: str) -> TombstoneRecord:
        record = self.metadata.get_tombstone(digest)
        if record is None:
            raise NotFoundError(f"no tombstone for {digest}")
        return record

    def tombstones(self) -> List[Dict[str, Any]]:
        result = []
        for record in self.metadata.list_tombstones():
            item = record.to_canonical()
            item["dependency_edges"] = json.loads(record.dependency_edges_json)
            item.pop("dependency_edges_json", None)
            result.append(item)
        return result

    def redact(self, digest: str, **kwargs: Any) -> TombstoneRecord:
        return self.backend.redact(digest, **kwargs)

    def scan_integrity(self) -> Dict[str, Any]:
        failures: List[Dict[str, str]] = []
        digests = self.objects.list_digests()
        for digest in digests:
            try:
                self.objects.get_content(digest)
            except Exception as error:  # noqa: BLE001 - report every protected object
                failures.append({"content_hash": digest,
                                 "error": f"{type(error).__name__}: {error}"})
        for case_id in self.metadata.list_case_ids():
            for version in self.metadata.list_case_versions(case_id):
                if not self.objects.has_content(version.content_hash):
                    failures.append({"content_hash": version.content_hash,
                                     "error": f"case {case_id} metadata has no content"})
        return {
            "ok": not failures, "objects_checked": len(digests),
            "failures": failures, "orphaned_paths": [],
            "backend": self.backend.consistency().to_canonical(), "checked_at": utc_now(),
        }

    def acquire_worker_lock(self, worker_id: str) -> bool:
        acquire = getattr(self.metadata, "acquire_worker_lock", None)
        if acquire is None:
            raise UsageError(
                "this metadata backend has no crash-released external-worker lease"
            )
        return bool(acquire(worker_id))

    def database_schema_version(self) -> int:
        version = getattr(self.metadata, "schema_version", None)
        return int(version()) if version is not None else 0

    def release_worker_lock(self, worker_id: str) -> bool:
        release = getattr(self.metadata, "release_worker_lock", None)
        return bool(release(worker_id)) if release is not None else False

    def acquire_job_lock(self, job_id: str, worker_id: str) -> bool:
        acquire = getattr(self.metadata, "acquire_job_lock", None)
        if acquire is None:
            raise UsageError(
                "this metadata backend has no crash-released per-job worker claim"
            )
        return bool(acquire(job_id, worker_id))

    def release_job_lock(self, job_id: str, worker_id: str) -> bool:
        release = getattr(self.metadata, "release_job_lock", None)
        return bool(release(job_id, worker_id)) if release is not None else False

    def close(self) -> None:
        if not self._closed:
            self._closed = True
            self.backend.close()

    def __enter__(self) -> "ApplicationStore":
        return self

    def __exit__(self, *_exc: Any) -> None:
        self.close()
