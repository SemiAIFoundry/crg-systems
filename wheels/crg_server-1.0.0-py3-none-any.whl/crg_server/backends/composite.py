"""Joining an object store to a metadata store, and the operations that span both.

Normative basis: 42.1 (the storage model is *two* stores plus indexes, not
one), 42.3 (enterprise profile pairs PostgreSQL with S3-compatible object
storage), 6.6 (fail closed), 11.2 (a prior case version remains addressable),
16.1 (optimistic locking), 17.2--17.5 (redaction, tombstones, legal hold),
18.5 (dependency traversal), 44.7 (audit).

42.1 separates canonical content from indexed metadata, and the moment those
are two systems there is no transaction between them.  This module is where
that fact is confronted instead of ignored.

Two operations genuinely span the halves and both live here so that there is
exactly one implementation of each, shared by every backend pairing:

* **reading a case** -- metadata resolves an identifier to a content address,
  the object store returns bytes, and the bytes are verified against the
  address before anything looks inside them; and
* **redacting an object** -- a tombstone in metadata (17.2), bytes out of the
  object store, dependents re-statused (17.3), an audit event (44.7).

The write ordering is content-before-metadata and the deletion ordering is
tombstone-before-bytes.  Both are argued in
:mod:`crg_server.backends.base`'s docstring; the short form is that each
order chooses the failure that leaves the store *understating* what it holds
rather than overstating it, because 6.6 forbids the second.

A composite is honest about what it cannot promise.  :meth:`consistency`
returns the join of its two halves, and ``cross_store_atomicity`` is
``NONE`` -- always, even when both halves are strongly consistent, because two
systems that each have transactions still have no transaction between them.
"""
from __future__ import annotations

import json
from typing import Any, Dict, List, Mapping, Optional, Union

from crg_model.canonical import canonical_json
from crg_model.envelope import ObjectStatus, utc_now

from ..errors import ConflictError, NotFoundError, RedactedError, UsageError
from .base import (
    DEFAULT_PERMITTED_DISCLOSURE,
    CaseVersionRecord,
    ConsistencyModel,
    MetadataBackend,
    ObjectStoreBackend,
    TombstoneRecord,
    digest_of,
    require_conformance,
)

__all__ = ["CompositeBackend", "CompositeOperations"]


class CompositeOperations:
    """The cross-store operations, independent of which halves are plugged in.

    Held rather than inherited by :class:`~crg_server.backends.local.
    SqliteFilesystemBackend` so that the local profile and the enterprise
    profile run *identical* code for redaction and case reads.  If they ran
    different code, "the contract suite passes against all three backends"
    would be a weaker claim than it sounds: the interesting part is not that
    each store can delete a row, it is that 17.3's downgrade rule behaves the
    same over PostgreSQL and S3 as it does over SQLite and a directory.
    """

    def __init__(self, objects: ObjectStoreBackend, metadata: MetadataBackend) -> None:
        self._objects = objects
        self._metadata = metadata

    # -- cases (11.2, 16.1) -----------------------------------------------
    def put_case(
        self,
        case: Mapping[str, Any],
        *,
        expected_parent_version: Optional[int] = None,
        created_by: str = "crg-server",
    ) -> CaseVersionRecord:
        """Append a case version: content first, then the metadata row.

        Optimistic locking per 16.1.  A stale ``expected_parent_version`` is a
        :class:`~crg_server.errors.ConflictError` and never an overwrite: the
        caller read one state, reasoned about it, and would otherwise silently
        discard the state that arrived meanwhile.

        The check and the insert happen inside one
        :meth:`MetadataBackend.transaction`, which is why that method exists on
        the interface at all.  Over PostgreSQL that is an advisory lock plus
        ``SELECT ... FOR UPDATE``; over SQLite it is the serialized
        connection's lock.  The content write happens *before* the transaction
        opens, deliberately: holding a database transaction open across a
        network write to an object store is how a deployment discovers what
        its lock timeout is.

        This layer does not refresh the case envelope -- no ``updated_at``, no
        recomputed derived metadata.  :mod:`crg_server.operations` owns that,
        and a storage adapter that quietly edited a case body would be a
        mutate-in-place path wearing a helper's clothes (10.1).
        """
        case_id = str(case.get("case_id") or "")
        if not case_id:
            raise UsageError("a case must carry a case_id (spec 11.1)")
        with self._metadata.transaction():
            head = self._metadata.head_version(case_id)
            if expected_parent_version is not None and expected_parent_version != head:
                raise ConflictError(
                    f"case {case_id!r} is at version {head}, not {expected_parent_version}",
                    remedy="re-read the case, re-apply the change, and retry (16.1)",
                    detail={"case_id": case_id, "head_version": head,
                            "expected_parent_version": expected_parent_version},
                )
            version = head + 1
            body = dict(case)
            body["case_version"] = version
            body.setdefault("branch_id", body.get("branch_id") or "main")
            payload = canonical_json(body).encode("utf-8")
            digest = digest_of(payload)
            # Content first.  An interrupted write here leaves bytes nothing
            # points at; the other order would leave a version row naming
            # bytes that are not there.
            self._objects.put_content(
                digest, payload, object_type="CRGCase", created_by=created_by
            )
            record = CaseVersionRecord(
                case_id=case_id,
                case_version=version,
                content_hash=digest,
                branch_id=str(body.get("branch_id") or "main"),
                derived_from=(canonical_json(body["derived_from"])
                              if body.get("derived_from") else ""),
                parent_version=head or None,
                status=str(body.get("status") or "DRAFT"),
                created_at=utc_now(),
                created_by=created_by,
            )
            self._metadata.put_case_version(record)
        return record

    def get_case(
        self, case_id: str, version: Union[int, str, None] = None
    ) -> Dict[str, Any]:
        """Read a case version.  ``None`` is head; an int is an ordinal; a
        ``sha256:`` string is a content address (11.2)."""
        record = self._metadata.case_version(case_id, version)
        payload = self._objects.get_content(record.content_hash)
        value = json.loads(payload.decode("utf-8"))
        if not isinstance(value, dict):
            raise NotFoundError(
                f"case {case_id!r} version {record.case_version} does not decode to an object",
                detail={"content_hash": record.content_hash},
            )
        return value

    # -- dependency traversal (18.5) --------------------------------------
    def dependents_of(self, source: str) -> List[str]:
        """Every node reachable from ``source`` along outgoing edges.

        Breadth of the frontier rather than recursion, because 18.5's graph is
        caller-supplied and a cycle -- which the typed edge vocabulary does not
        forbid -- must terminate rather than blow the stack.  ``visited``
        makes it terminate.
        """
        seen: List[str] = []
        frontier = [source]
        visited = {source}
        while frontier:
            current = frontier.pop()
            for edge in self._metadata.edges_from(current):
                target = edge.target
                if target in visited:
                    continue
                visited.add(target)
                seen.append(target)
                frontier.append(target)
        return sorted(seen)

    # -- redaction (17) ----------------------------------------------------
    def redact(
        self,
        digest: str,
        *,
        reason: str,
        authority: str,
        permitted_disclosure: str = DEFAULT_PERMITTED_DISCLOSURE,
    ) -> TombstoneRecord:
        """Remove content, preserve identity and structure (17.2, 17.3, 17.5).

        The bytes go.  The hash, the object type, and every typed dependency
        edge touching the object stay, as a tombstone.

        The second half is the part that matters more.  17.3: a certificate
        whose necessary supporting content has been removed MUST become
        ``UNVERIFIABLE_REDACTED`` unless it contains a separately sufficient
        proof artifact that remains available -- and the system MUST NOT
        silently report such a certificate as valid.  So every reachable
        dependent certificate is re-statused *here*, at the moment of removal,
        rather than left for a later verification pass a caller might not run.

        Idempotent throughout, because a redaction interrupted between the
        tombstone and the delete must be safe to re-run.  A second call
        returns the existing tombstone unchanged.
        """
        if not reason:
            raise UsageError("redaction requires a stated reason (17.2)")
        if not authority:
            raise UsageError("redaction requires a named removal authority (17.2)")

        existing = self._metadata.get_tombstone(digest)
        if existing is not None and not self._objects.has_content(digest):
            return existing

        if self._objects.legal_hold(digest):
            raise ConflictError(
                f"object {digest} is under legal hold and MUST NOT be deleted or "
                "cryptographically erased until the hold is released (17.5)",
                remedy="release the hold under authorized policy, then redact",
                detail={"content_hash": digest},
            )

        metadata = self._objects.content_metadata(digest)  # NotFoundError if absent
        edges = [
            edge.to_canonical()
            for edge in sorted(
                list(self._metadata.edges_from(digest)) + list(self._metadata.edges_to(digest)),
                key=lambda e: e.edge_id,
            )
        ]
        object_id = self._object_id_of(digest) or digest
        removed_at = utc_now()
        tombstone = TombstoneRecord(
            content_hash=digest,
            object_id=object_id,
            object_type=metadata.object_type,
            reason=reason,
            authority=authority,
            removed_at=removed_at,
            legal_hold=False,
            permitted_disclosure=permitted_disclosure,
            dependency_edges_json=json.dumps(edges, sort_keys=True),
        )
        # Tombstone before bytes: an interruption then leaves content that is
        # already unreadable through the API rather than content that is gone
        # with nothing to explain it (17.2).
        self._metadata.put_tombstone(tombstone)
        self._objects.delete_content(digest)
        self._objects.set_content_status(digest, ObjectStatus.REDACTED, reason=reason)

        affected = self._downgrade_dependents(digest, reason=reason)
        self._metadata.append_audit(
            removed_at,
            canonical_json(
                {
                    "event": "object.redacted",
                    "content_hash": digest,
                    "object_type": metadata.object_type,
                    "reason": reason,
                    "authority": authority,
                    "removed_at": removed_at,
                    "affected_certificates": affected,
                }
            ),
        )
        return tombstone

    def _object_id_of(self, digest: str) -> str:
        """The object's declared identity, read before the bytes are removed.

        Best-effort by design: a tombstone whose ``object_id`` fell back to the
        content hash is still a valid tombstone, and failing the whole
        redaction because a payload would not decode would make removal
        impossible for exactly the objects most likely to need removing.
        """
        try:
            payload = self._objects.get_content(digest)
            value = json.loads(payload.decode("utf-8"))
        except (NotFoundError, RedactedError, UnicodeDecodeError, json.JSONDecodeError):
            return ""
        if isinstance(value, Mapping):
            for key in ("object_id", "bundle_id", "case_id", "certificate_id"):
                candidate = value.get(key)
                if candidate:
                    return str(candidate)
        return ""

    def _sufficient_proof_available(self, certificate: Mapping[str, Any]) -> bool:
        """17.3's escape hatch, read strictly.

        A certificate survives redaction of its support only if it carries a
        proof artifact that is *separately sufficient* and *remains
        available*.  Both halves are checked: the artifact must declare
        ``sufficiency == "SELF_CONTAINED"`` and its own content must still be
        present.  An artifact that merely exists, or one that is itself
        redacted, buys nothing.
        """
        artifacts = certificate.get("proof_artifacts") or ()
        if not isinstance(artifacts, (list, tuple)):
            return False
        for artifact in artifacts:
            if not isinstance(artifact, Mapping):
                continue
            if str(artifact.get("sufficiency") or "") != "SELF_CONTAINED":
                continue
            artifact_hash = str(artifact.get("content_hash") or "")
            if artifact_hash and self._objects.has_content(artifact_hash):
                return True
        return False

    def _downgrade_dependents(self, digest: str, *, reason: str) -> List[str]:
        """Re-status every certificate reachable from a redacted object (17.3)."""
        affected: List[str] = []
        reachable = set(self.dependents_of(digest))
        if not reachable:
            return affected
        for case_id in self._metadata.list_case_ids():
            for record in self._metadata.list_certificates(case_id):
                if record.content_hash not in reachable and record.certificate_id not in reachable:
                    continue
                try:
                    payload = self._objects.get_content(record.content_hash)
                    certificate = json.loads(payload.decode("utf-8"))
                except (NotFoundError, RedactedError, UnicodeDecodeError,
                        json.JSONDecodeError):
                    certificate = {}
                if isinstance(certificate, Mapping) and self._sufficient_proof_available(
                    certificate
                ):
                    self._objects.set_content_status(
                        record.content_hash,
                        ObjectStatus.ACTIVE,
                        reason=(
                            "supporting content was redacted, but a separately sufficient "
                            "proof artifact remains available (17.3)"
                        ),
                    )
                    continue
                self._objects.set_content_status(
                    record.content_hash,
                    ObjectStatus.UNVERIFIABLE_REDACTED,
                    reason=f"supporting object {digest} was redacted: {reason} (17.3)",
                )
                affected.append(record.certificate_id)
        return sorted(affected)


class CompositeBackend(CompositeOperations):
    """A :class:`~crg_server.backends.base.StoreBackend` made of two halves.

    This is the 42.3 shape: hand it a
    :class:`~crg_server.backends.s3.S3ObjectStore` and a
    :class:`~crg_server.backends.postgres.PostgresMetadataStore` and it is the
    enterprise profile; hand it the local object store and a PostgreSQL
    metadata store and it is a deployment that wanted shared metadata and
    local disks.  The pairing is the configuration decision 42.3 leaves open,
    and nothing above this class needs to know which pairing it got.

    Both halves are conformance-checked at construction.  A third-party
    adapter that is missing a method fails here, at start-up, with the list of
    what is missing -- not at 3am inside a certification with an
    ``AttributeError``.
    """

    def __init__(
        self,
        objects: ObjectStoreBackend,
        metadata: MetadataBackend,
        *,
        name: str = "composite",
        initialize: bool = True,
    ) -> None:
        require_conformance(objects, ObjectStoreBackend)
        require_conformance(metadata, MetadataBackend)
        super().__init__(objects, metadata)
        self._name = name
        self._closed = False
        if initialize:
            metadata.initialize()

    @property
    def objects(self) -> ObjectStoreBackend:
        return self._objects

    @property
    def metadata(self) -> MetadataBackend:
        return self._metadata

    def consistency(self) -> ConsistencyModel:
        return self._objects.consistency().join(
            self._metadata.consistency(), name=self._name
        )

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        self._objects.close()
        self._metadata.close()

    def __enter__(self) -> "CompositeBackend":
        return self

    def __exit__(self, *_exc: Any) -> None:
        self.close()
