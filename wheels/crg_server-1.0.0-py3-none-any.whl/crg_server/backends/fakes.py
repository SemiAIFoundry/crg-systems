"""In-memory doubles that really execute what the adapters really send.

Normative basis: 42.3 (the enterprise profile this repository cannot host),
6.6 (fail closed), 47 (the reference implementation is judged by what it can
demonstrate), 61 (test artifacts ship with the build).

There is no PostgreSQL server and no S3 endpoint in this repository, and
there never will be one: 61's artifact set is a source tree that must be
verifiable offline, and 42.3's air-gapped deployment is precisely the case
where "just spin up a container in CI" is not an available answer.  The
choice is therefore between shipping two adapters that nothing executes and
shipping two doubles that execute them properly.  This module is the second
choice, and it is worth being exact about what that does and does not buy.

**These are not stubs.**  :class:`FakeDbapiConnection` contains a small SQL
interpreter.  It parses the ``CREATE TABLE``, ``CREATE INDEX``, ``INSERT ...
ON CONFLICT ... RETURNING``, ``SELECT ... WHERE ... ORDER BY ... LIMIT ... FOR
UPDATE``, ``UPDATE``, and ``DELETE ... RETURNING`` statements that
:mod:`crg_server.backends.postgres` actually emits, binds ``%s`` parameters
positionally, and evaluates them against dictionaries.  A statement naming a
column that does not exist fails.  A statement with the wrong number of
parameters fails.  An ``ON CONFLICT`` that was left off fails as a duplicate
key.  An ``ORDER BY`` in the wrong direction produces a wrong answer that the
contract suite catches.  :class:`FakeS3Client` likewise implements the
conditional-put semantics, the 404 taxonomy, and pagination rather than
returning canned successes.

**They still cannot catch what matters most.**  A fake written by the same
author as the adapter shares the author's misunderstandings.  If this file
believes ``ON CONFLICT (a, b) DO UPDATE SET x = EXCLUDED.x`` is spelled the
way :mod:`crg_server.backends.postgres` spells it, and both are wrong, both
agree.  Everything in the two adapters' docstrings about SQL dialect, type
coercion, isolation levels, S3 error codes, IAM, and multipart behaviour is
undetectable from here **by construction**.  The doubles prove control flow
and interface conformance.  They prove nothing about PostgreSQL or S3.

**Fault injection is the part that earns its keep.**  6.6 requires that an
unknown state fails closed, and the only way to assert that is to produce
unknown states on demand.  :class:`Faults` can make the object store lose a
read-after-write, return a 500, throttle, drop the connection, or hand back
bytes that are not the object; :class:`FakeDbapiConnection` can fail a
specific statement, fail on commit, or fail on rollback.  The contract suite
uses every one of them to assert that the adapter raises a typed error rather
than returning a plausible-looking answer.
"""
from __future__ import annotations

import io
import re
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

__all__ = [
    "FakeDbapiError",
    "FakeOperationalError",
    "FakeProgrammingError",
    "FakeIntegrityError",
    "FakeCursor",
    "FakeDbapiConnection",
    "FakeS3Client",
    "FakeClientError",
    "FakeNetworkError",
    "Faults",
    "connect_factory",
]


# ---------------------------------------------------------------------------
# DBAPI 2.0 exception shapes
# ---------------------------------------------------------------------------
class FakeDbapiError(Exception):
    """Base of the fake driver's errors, matching DBAPI 2.0's ``Error``."""


class FakeOperationalError(FakeDbapiError):
    """Connection lost, server gone, statement timed out."""


class FakeProgrammingError(FakeDbapiError):
    """The SQL is wrong: unknown table, unknown column, bad parameter count."""


class FakeIntegrityError(FakeDbapiError):
    """A constraint was violated -- duplicate primary key, mostly."""


# ---------------------------------------------------------------------------
# A very small SQL interpreter
# ---------------------------------------------------------------------------
_CREATE_TABLE = re.compile(
    r"^CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(\w+)\s*\((.*)\)\s*$",
    re.IGNORECASE | re.DOTALL,
)
_CREATE_INDEX = re.compile(
    r"^CREATE\s+INDEX\s+(?:IF\s+NOT\s+EXISTS\s+)?(\w+)\s+ON\s+(\w+)\s*\((.*)\)\s*$",
    re.IGNORECASE | re.DOTALL,
)
_INSERT = re.compile(
    r"^INSERT\s+INTO\s+(\w+)\s*\(([^)]*)\)\s*VALUES\s*\(([^)]*)\)"
    r"(?:\s+ON\s+CONFLICT\s*\(([^)]*)\)\s*DO\s+(NOTHING|UPDATE\s+SET\s+(.*?)))?"
    r"(?:\s+RETURNING\s+(\w+))?\s*$",
    re.IGNORECASE | re.DOTALL,
)
_SELECT = re.compile(
    r"^SELECT\s+(?:(DISTINCT)\s+)?(.*?)\s+FROM\s+(\w+)"
    r"(?:\s+WHERE\s+(.*?))?"
    r"(?:\s+ORDER\s+BY\s+(.*?))?"
    r"(?:\s+LIMIT\s+(\d+))?"
    r"(?:\s+FOR\s+UPDATE)?\s*$",
    re.IGNORECASE | re.DOTALL,
)
_UPDATE = re.compile(
    r"^UPDATE\s+(\w+)\s+SET\s+(.*?)(?:\s+WHERE\s+(.*?))?\s*$", re.IGNORECASE | re.DOTALL
)
_DELETE = re.compile(
    r"^DELETE\s+FROM\s+(\w+)(?:\s+WHERE\s+(.*?))?(?:\s+RETURNING\s+(\w+))?\s*$",
    re.IGNORECASE | re.DOTALL,
)
_FUNCTION_SELECT = re.compile(r"^SELECT\s+(\w+)\s*\((.*)\)\s*$", re.IGNORECASE | re.DOTALL)
_PREDICATE = re.compile(r"^(\w+)\s*(=|>|<|>=|<=|<>|!=)\s*%s$", re.IGNORECASE)
_IS_NULL = re.compile(r"^(\w+)\s+IS\s+(NOT\s+)?NULL$", re.IGNORECASE)


@dataclass
class _Column:
    name: str
    type_name: str
    serial: bool = False
    default: Any = None


@dataclass
class _Table:
    name: str
    columns: List[_Column]
    primary_key: Tuple[str, ...]
    rows: List[Dict[str, Any]] = field(default_factory=list)
    next_serial: int = 1

    def column_names(self) -> Tuple[str, ...]:
        return tuple(column.name for column in self.columns)

    def require_columns(self, names: Iterable[str]) -> None:
        known = set(self.column_names())
        for name in names:
            if name not in known:
                raise FakeProgrammingError(
                    f'column "{name}" of relation "{self.name}" does not exist'
                )


def _split_top_level(text: str, separator: str = ",") -> List[str]:
    """Split on ``separator`` at parenthesis depth zero."""
    parts: List[str] = []
    depth = 0
    current: List[str] = []
    for character in text:
        if character == "(":
            depth += 1
        elif character == ")":
            depth -= 1
        if character == separator and depth == 0:
            parts.append("".join(current))
            current = []
        else:
            current.append(character)
    parts.append("".join(current))
    return [part.strip() for part in parts if part.strip()]


def _parse_columns(body: str) -> Tuple[List[_Column], Tuple[str, ...]]:
    columns: List[_Column] = []
    primary_key: Tuple[str, ...] = ()
    for clause in _split_top_level(body):
        upper = clause.upper()
        if upper.startswith("PRIMARY KEY"):
            inner = clause[clause.index("(") + 1: clause.rindex(")")]
            primary_key = tuple(name.strip() for name in inner.split(","))
            continue
        if upper.startswith(("CONSTRAINT ", "UNIQUE ", "FOREIGN KEY", "CHECK ")):
            continue
        tokens = clause.split()
        name = tokens[0]
        type_name = tokens[1].upper() if len(tokens) > 1 else "TEXT"
        serial = type_name in ("SERIAL", "BIGSERIAL")
        default: Any = None
        if "DEFAULT" in upper:
            index = upper.index("DEFAULT") + len("DEFAULT")
            literal = clause[index:].split()[0].strip()
            default = _literal(literal)
        column = _Column(name=name, type_name=type_name, serial=serial, default=default)
        columns.append(column)
        if "PRIMARY KEY" in upper and not primary_key:
            primary_key = (name,)
    return columns, primary_key


def _literal(token: str) -> Any:
    token = token.strip().rstrip(",")
    upper = token.upper()
    if upper == "TRUE":
        return True
    if upper == "FALSE":
        return False
    if upper == "NULL":
        return None
    if token.startswith("'") and token.endswith("'") and len(token) >= 2:
        return token[1:-1]
    try:
        return int(token)
    except ValueError:
        return token


class FakeCursor:
    """A DBAPI 2.0 cursor over :class:`FakeDbapiConnection`'s tables.

    Implements exactly the surface :mod:`crg_server.backends.postgres` uses:
    ``execute``, ``executemany``, ``fetchone``, ``fetchall``, ``close``,
    ``description``, ``rowcount``.  ``description`` is ``None`` for statements
    that return no rows, which is the DBAPI signal the adapter branches on --
    getting that wrong in the fake would hide a real bug in the adapter.
    """

    def __init__(self, connection: "FakeDbapiConnection") -> None:
        self._connection = connection
        self._rows: List[Tuple[Any, ...]] = []
        self.description: Optional[List[Tuple[Any, ...]]] = None
        self.rowcount: int = -1
        self.closed = False

    def execute(self, sql: str, parameters: Sequence[Any] = ()) -> "FakeCursor":
        if self.closed:
            raise FakeProgrammingError("cursor is closed")
        rows, columns, count = self._connection._run(sql, tuple(parameters))
        self._rows = rows
        self.description = (
            [(name, None, None, None, None, None, None) for name in columns]
            if columns is not None
            else None
        )
        self.rowcount = count
        return self

    def executemany(self, sql: str, seq_of_parameters: Iterable[Sequence[Any]]) -> "FakeCursor":
        total = 0
        for parameters in seq_of_parameters:
            self.execute(sql, parameters)
            total += max(self.rowcount, 0)
        self._rows = []
        self.description = None
        self.rowcount = total
        return self

    def fetchone(self) -> Optional[Tuple[Any, ...]]:
        return self._rows.pop(0) if self._rows else None

    def fetchall(self) -> List[Tuple[Any, ...]]:
        rows, self._rows = self._rows, []
        return rows

    def close(self) -> None:
        self.closed = True

    def __enter__(self) -> "FakeCursor":
        return self

    def __exit__(self, *_exc: Any) -> None:
        self.close()


class FakeDbapiConnection:
    """A DBAPI 2.0 connection that executes SQL against dictionaries.

    Paramstyle is ``%s``, positionally bound, matching psycopg.  A statement
    whose ``%s`` count does not match the parameter tuple raises
    :class:`FakeProgrammingError`, because a mismatched parameter list is one
    of the two mistakes an untested SQL adapter is most likely to contain and
    a fake that quietly tolerated it would be useless.

    Transactions are real enough to test with: uncommitted work lives in a
    shadow copy and ``rollback`` discards it.  They are *not* real enough to
    test isolation with -- there is one connection, no MVCC, and no
    concurrency.  See this module's docstring.
    """

    #: DBAPI 2.0 module-level attributes, exposed on the connection so an
    #: adapter that wants to classify driver errors can find them without
    #: importing anything.
    Error = FakeDbapiError
    OperationalError = FakeOperationalError
    ProgrammingError = FakeProgrammingError
    IntegrityError = FakeIntegrityError
    paramstyle = "format"

    def __init__(self) -> None:
        self.tables: Dict[str, _Table] = {}
        self.indexes: Dict[str, Tuple[str, Tuple[str, ...]]] = {}
        self.statements: List[Tuple[str, Tuple[Any, ...]]] = []
        self.commits = 0
        self.rollbacks = 0
        self.closed = False
        self.advisory_locks: List[Tuple[Any, ...]] = []
        #: ``(predicate, exception)`` pairs.  The first predicate that matches
        #: a statement raises, once, then is discarded.
        self._traps: List[Tuple[Callable[[str], bool], BaseException]] = []
        self._fail_commit: Optional[BaseException] = None
        self._fail_rollback: Optional[BaseException] = None
        self._pending: Optional[Dict[str, List[Dict[str, Any]]]] = None

    # -- fault injection ---------------------------------------------------
    def fail_next(self, error: BaseException, *, matching: str = "") -> None:
        """Make the next statement containing ``matching`` raise ``error``.

        Empty ``matching`` traps the very next statement.  One-shot: the trap
        is consumed when it fires, so a test can assert that the *retry*
        succeeds, which is the half of fail-closed behaviour that is easy to
        forget to check.
        """
        needle = matching.upper()

        def predicate(sql: str) -> bool:
            return not needle or needle in sql.upper()

        self._traps.append((predicate, error))

    def fail_commit(self, error: BaseException) -> None:
        """Make the next ``commit()`` raise -- the genuinely ambiguous failure.

        A commit that raises leaves the transaction's outcome unknown: it may
        have been applied before the connection dropped.  6.6 says report it.
        """
        self._fail_commit = error

    def fail_rollback(self, error: BaseException) -> None:
        """Make the next ``rollback()`` raise, stranding the session."""
        self._fail_rollback = error

    def _trap(self, sql: str) -> None:
        for index, (predicate, error) in enumerate(self._traps):
            if predicate(sql):
                del self._traps[index]
                raise error
        return None

    # -- DBAPI -------------------------------------------------------------
    def cursor(self) -> FakeCursor:
        if self.closed:
            raise FakeProgrammingError("connection is closed")
        return FakeCursor(self)

    def commit(self) -> None:
        if self.closed:
            raise FakeProgrammingError("connection is closed")
        if self._fail_commit is not None:
            error, self._fail_commit = self._fail_commit, None
            raise error
        self._pending = None
        self.commits += 1

    def rollback(self) -> None:
        if self._fail_rollback is not None:
            error, self._fail_rollback = self._fail_rollback, None
            raise error
        if self._pending is not None:
            for name, rows in self._pending.items():
                self.tables[name].rows = rows
            self._pending = None
        self.rollbacks += 1

    def close(self) -> None:
        self.closed = True

    # -- execution ---------------------------------------------------------
    def _snapshot(self, table: _Table) -> None:
        if self._pending is None:
            self._pending = {}
        if table.name not in self._pending:
            self._pending[table.name] = [dict(row) for row in table.rows]

    def _table(self, name: str) -> _Table:
        table = self.tables.get(name)
        if table is None:
            raise FakeProgrammingError(f'relation "{name}" does not exist')
        return table

    def _run(
        self, sql: str, parameters: Tuple[Any, ...]
    ) -> Tuple[List[Tuple[Any, ...]], Optional[List[str]], int]:
        if self.closed:
            raise FakeProgrammingError("connection is closed")
        statement = " ".join(sql.split())
        self._trap(statement)
        self.statements.append((statement, parameters))
        expected = statement.count("%s")
        if expected != len(parameters):
            raise FakeProgrammingError(
                f"statement takes {expected} parameters, {len(parameters)} were supplied: "
                f"{statement}"
            )
        remaining = list(parameters)

        match = _CREATE_TABLE.match(statement)
        if match:
            return self._create_table(match)
        match = _CREATE_INDEX.match(statement)
        if match:
            return self._create_index(match)
        match = _INSERT.match(statement)
        if match:
            return self._insert(match, remaining)
        match = _UPDATE.match(statement)
        if match:
            return self._update(match, remaining)
        match = _DELETE.match(statement)
        if match:
            return self._delete(match, remaining)
        match = _SELECT.match(statement)
        if match:
            return self._select(match, remaining)
        match = _FUNCTION_SELECT.match(statement)
        if match:
            return self._function(match, remaining)
        raise FakeProgrammingError(f"syntax error at or near: {statement}")

    # -- DDL ---------------------------------------------------------------
    def _create_table(self, match: "re.Match[str]") -> Tuple[List[Tuple[Any, ...]], None, int]:
        name = match.group(1)
        if name in self.tables:
            return [], None, 0
        columns, primary_key = _parse_columns(match.group(2))
        self.tables[name] = _Table(name=name, columns=columns, primary_key=primary_key)
        return [], None, 0

    def _create_index(self, match: "re.Match[str]") -> Tuple[List[Tuple[Any, ...]], None, int]:
        index_name, table_name, body = match.group(1), match.group(2), match.group(3)
        table = self._table(table_name)
        columns = tuple(
            part.split()[0] for part in _split_top_level(body)
        )
        table.require_columns(columns)
        self.indexes[index_name] = (table_name, columns)
        return [], None, 0

    # -- DML ---------------------------------------------------------------
    def _insert(
        self, match: "re.Match[str]", parameters: List[Any]
    ) -> Tuple[List[Tuple[Any, ...]], Optional[List[str]], int]:
        table = self._table(match.group(1))
        column_names = [name.strip() for name in match.group(2).split(",")]
        table.require_columns(column_names)
        placeholders = _split_top_level(match.group(3))
        values: List[Any] = []
        for placeholder in placeholders:
            if placeholder == "%s":
                values.append(parameters.pop(0))
            else:
                values.append(_literal(placeholder))
        if len(values) != len(column_names):
            raise FakeProgrammingError(
                f"INSERT has {len(column_names)} target columns and {len(values)} values"
            )
        conflict_columns = (
            tuple(name.strip() for name in match.group(4).split(","))
            if match.group(4)
            else ()
        )
        conflict_action = (match.group(5) or "").strip().upper()
        update_body = match.group(6)
        returning = match.group(7)

        row = {column.name: column.default for column in table.columns}
        row.update(dict(zip(column_names, values)))
        for column in table.columns:
            if column.serial and row.get(column.name) is None:
                row[column.name] = table.next_serial
                table.next_serial += 1

        key_columns = conflict_columns or table.primary_key
        existing = None
        if key_columns:
            table.require_columns(key_columns)
            for candidate in table.rows:
                if all(candidate.get(name) == row.get(name) for name in key_columns):
                    existing = candidate
                    break

        self._snapshot(table)
        if existing is not None:
            if not conflict_columns:
                raise FakeIntegrityError(
                    f'duplicate key value violates unique constraint "{table.name}_pkey"'
                )
            if conflict_action.startswith("NOTHING"):
                return ([], [returning], 0) if returning else ([], None, 0)
            assignments = _split_top_level(update_body or "")
            for assignment in assignments:
                target, _, source = assignment.partition("=")
                target = target.strip()
                source = source.strip()
                table.require_columns([target])
                if source.upper().startswith("EXCLUDED."):
                    existing[target] = row.get(source.split(".", 1)[1].strip())
                elif source == "%s":
                    existing[target] = parameters.pop(0)
                else:
                    existing[target] = _literal(source)
            if returning:
                return [(existing.get(returning),)], [returning], 1
            return [], None, 1

        table.rows.append(row)
        if returning:
            return [(row.get(returning),)], [returning], 1
        return [], None, 1

    def _update(
        self, match: "re.Match[str]", parameters: List[Any]
    ) -> Tuple[List[Tuple[Any, ...]], None, int]:
        table = self._table(match.group(1))
        assignments = _split_top_level(match.group(2))
        set_pairs: List[Tuple[str, Any]] = []
        for assignment in assignments:
            target, _, source = assignment.partition("=")
            target = target.strip()
            table.require_columns([target])
            source = source.strip()
            set_pairs.append((target, parameters.pop(0) if source == "%s" else _literal(source)))
        predicate = self._compile_where(table, match.group(3), parameters)
        self._snapshot(table)
        count = 0
        for row in table.rows:
            if predicate(row):
                for name, value in set_pairs:
                    row[name] = value
                count += 1
        return [], None, count

    def _delete(
        self, match: "re.Match[str]", parameters: List[Any]
    ) -> Tuple[List[Tuple[Any, ...]], Optional[List[str]], int]:
        table = self._table(match.group(1))
        predicate = self._compile_where(table, match.group(2), parameters)
        returning = match.group(3)
        self._snapshot(table)
        removed = [row for row in table.rows if predicate(row)]
        table.rows = [row for row in table.rows if not predicate(row)]
        if returning:
            table.require_columns([returning])
            return [(row.get(returning),) for row in removed], [returning], len(removed)
        return [], None, len(removed)

    def _select(
        self, match: "re.Match[str]", parameters: List[Any]
    ) -> Tuple[List[Tuple[Any, ...]], List[str], int]:
        distinct = bool(match.group(1))
        projection = match.group(2).strip()
        table = self._table(match.group(3))
        predicate = self._compile_where(table, match.group(4), parameters)
        rows = [row for row in table.rows if predicate(row)]

        order_by = match.group(5)
        if order_by:
            for term in reversed(_split_top_level(order_by)):
                tokens = term.split()
                column = tokens[0]
                table.require_columns([column])
                descending = len(tokens) > 1 and tokens[1].upper() == "DESC"
                rows.sort(key=lambda r, c=column: _sort_key(r.get(c)), reverse=descending)

        if projection == "*":
            columns = list(table.column_names())
        else:
            columns = [name.strip() for name in _split_top_level(projection)]
            table.require_columns(columns)
        result = [tuple(row.get(name) for name in columns) for row in rows]
        if distinct:
            seen: List[Tuple[Any, ...]] = []
            for entry in result:
                if entry not in seen:
                    seen.append(entry)
            result = seen
        limit = match.group(6)
        if limit is not None:
            result = result[: int(limit)]
        return result, columns, len(result)

    def _function(
        self, match: "re.Match[str]", parameters: List[Any]
    ) -> Tuple[List[Tuple[Any, ...]], List[str], int]:
        """``SELECT pg_advisory_xact_lock(%s, %s)`` and friends.

        Recorded rather than ignored: the contract suite asserts that the
        adapter really does take the lock before the 16.1 read-then-append,
        and a fake that discarded the call could not support that assertion.
        The lock has no effect -- there is one connection and no concurrency.
        """
        name = match.group(1)
        arguments = [
            parameters.pop(0) if token.strip() == "%s" else _literal(token)
            for token in _split_top_level(match.group(2))
        ]
        if name.lower().startswith("pg_advisory") or name.lower().startswith("pg_try_advisory"):
            self.advisory_locks.append(tuple(arguments))
            value = True if name.lower().startswith(("pg_try_", "pg_advisory_unlock")) else None
            return [(value,)], [name], 1
        raise FakeProgrammingError(f'function "{name}" does not exist')

    # -- WHERE -------------------------------------------------------------
    def _compile_where(
        self, table: _Table, clause: Optional[str], parameters: List[Any]
    ) -> Callable[[Mapping[str, Any]], bool]:
        """Compile a conjunction of simple predicates.

        Deliberately narrow: ``col <op> %s``, ``col IS [NOT] NULL``, and
        ``AND`` between them, plus parenthesised ``OR`` of the same.  Anything
        the adapter sends that is outside this grammar raises rather than
        being ignored, because a ``WHERE`` clause silently treated as "match
        everything" would turn a scoped ``DELETE`` into a table truncation and
        the test would still pass.
        """
        if not clause:
            return lambda row: True
        conjuncts = re.split(r"\s+AND\s+", clause.strip(), flags=re.IGNORECASE)
        tests: List[Callable[[Mapping[str, Any]], bool]] = []
        for conjunct in conjuncts:
            conjunct = conjunct.strip()
            if conjunct.startswith("(") and conjunct.endswith(")"):
                inner = conjunct[1:-1]
                disjuncts = re.split(r"\s+OR\s+", inner, flags=re.IGNORECASE)
                sub = [self._compile_predicate(table, part, parameters) for part in disjuncts]
                tests.append(lambda row, s=sub: any(test(row) for test in s))
                continue
            tests.append(self._compile_predicate(table, conjunct, parameters))
        return lambda row: all(test(row) for test in tests)

    def _compile_predicate(
        self, table: _Table, text: str, parameters: List[Any]
    ) -> Callable[[Mapping[str, Any]], bool]:
        text = text.strip()
        match = _IS_NULL.match(text)
        if match:
            column = match.group(1)
            table.require_columns([column])
            negated = bool(match.group(2))
            if negated:
                return lambda row, c=column: row.get(c) is not None
            return lambda row, c=column: row.get(c) is None
        match = _PREDICATE.match(text)
        if match:
            column, operator = match.group(1), match.group(2)
            table.require_columns([column])
            value = parameters.pop(0)
            if operator == "=":
                return lambda row, c=column, v=value: row.get(c) == v
            if operator in ("<>", "!="):
                return lambda row, c=column, v=value: row.get(c) != v
            if operator == ">":
                return lambda row, c=column, v=value: _gt(row.get(c), v)
            if operator == "<":
                return lambda row, c=column, v=value: _gt(v, row.get(c))
            if operator == ">=":
                return lambda row, c=column, v=value: not _gt(v, row.get(c))
            if operator == "<=":
                return lambda row, c=column, v=value: not _gt(row.get(c), v)
        raise FakeProgrammingError(f"unsupported predicate in this fake: {text!r}")


def _sort_key(value: Any) -> Tuple[int, Any]:
    """Order NULLs last, then by type-stable key.

    PostgreSQL's default is ``NULLS LAST`` for ``ASC``; matching it here keeps
    an adapter that relies on the default from looking correct in the fake and
    wrong on a server -- at least for this one detail.
    """
    if value is None:
        return (1, "")
    if isinstance(value, bool):
        return (0, int(value))
    if isinstance(value, (int, float)):
        return (0, value)
    return (0, str(value))


def _gt(left: Any, right: Any) -> bool:
    if left is None or right is None:
        return False
    if isinstance(left, (int, float)) and isinstance(right, (int, float)):
        return left > right
    return str(left) > str(right)


def connect_factory(connection: FakeDbapiConnection) -> Callable[[], FakeDbapiConnection]:
    """A ``connect()`` callable returning ``connection``.

    What a deployment passes as ``PostgresMetadataStore(connect=...)``, so the
    contract suite exercises the same injection path production would.
    """

    def connect() -> FakeDbapiConnection:
        return connection

    return connect


# ---------------------------------------------------------------------------
# S3
# ---------------------------------------------------------------------------
class FakeNetworkError(Exception):
    """A transport failure with no S3 response attached at all.

    The nastiest case for an adapter, because there is no error code to
    classify: it must fall back to "unknown, therefore closed" rather than to
    "probably a 404".
    """


class FakeClientError(Exception):
    """``botocore.exceptions.ClientError``-shaped.

    Duck-typed against ``error.response["Error"]["Code"]`` exactly as
    :func:`crg_server.backends.s3._error_code` reads it, so the adapter's
    classification logic is what runs.
    """

    def __init__(self, code: str, message: str = "", status: int = 400) -> None:
        super().__init__(f"{code}: {message}" if message else code)
        self.response: Dict[str, Any] = {
            "Error": {"Code": code, "Message": message or code},
            "ResponseMetadata": {"HTTPStatusCode": status},
        }


@dataclass
class Faults:
    """What the fake object store should do wrong, and how many times.

    Each counter is decremented as it fires, so a test can inject one failure
    and then assert that the retry succeeds.  That second half matters: an
    adapter that failed closed by falling over permanently would satisfy 6.6
    and be useless.

    ``corrupt_keys`` is the one that is not a counter, because byte corruption
    is not transient: once a stored object is wrong it stays wrong, and the
    adapter must refuse it every time rather than on a first read only.
    """

    read_after_write_misses: int = 0
    transient_500: int = 0
    throttle: int = 0
    network_errors: int = 0
    access_denied: int = 0
    corrupt_keys: set = field(default_factory=set)
    #: Only these operations are affected; empty means all of them.
    operations: Tuple[str, ...] = ()

    def applies_to(self, operation: str) -> bool:
        return not self.operations or operation in self.operations


class FakeS3Client:
    """The subset of the boto3 S3 surface :mod:`crg_server.backends.s3` calls.

    ``put_object``, ``get_object``, ``head_object``, ``delete_object``,
    ``list_objects_v2``, and the four multipart operations, with real
    conditional-put semantics (``IfNoneMatch: '*'`` raises
    ``PreconditionFailed`` when the key exists), real pagination via
    ``ContinuationToken``, and ``Body`` returned as a stream so that an
    adapter which forgot to ``read()`` it fails here rather than in
    production.

    Faults are checked *before* the operation is performed, which is the
    pessimistic order: a fault-injected write does not land.  A real network
    failure may well leave the write landed, and that ambiguity is exactly
    what :class:`~crg_server.backends.base.BackendUnavailableError` reports --
    but the fake cannot simulate "it worked and you do not know", so the
    contract suite asserts only the half it can: that the caller is told, in a
    typed way, that it does not know.
    """

    def __init__(self, *, faults: Optional[Faults] = None) -> None:
        self.objects: Dict[str, Dict[str, Any]] = {}
        self.faults = faults or Faults()
        self.calls: List[Tuple[str, str]] = []
        #: Keys written with ``If-None-Match: '*'``.  Recorded so a test can
        #: assert that the write-once rule was enforced by the *store* and not
        #: merely by the adapter's own bookkeeping -- the two are
        #: indistinguishable in outcome here, and only one of them survives a
        #: second writer.
        self.conditional_puts: List[str] = []
        self.uploads: Dict[str, Dict[str, Any]] = {}
        self.aborted_uploads: List[str] = []
        self._next_upload = 1

    # -- fault plumbing ----------------------------------------------------
    def _maybe_fail(self, operation: str, key: str) -> None:
        faults = self.faults
        if not faults.applies_to(operation):
            return
        if faults.network_errors > 0:
            faults.network_errors -= 1
            raise FakeNetworkError(f"connection reset during {operation} of {key}")
        if faults.throttle > 0:
            faults.throttle -= 1
            raise FakeClientError("SlowDown", "Please reduce your request rate", 503)
        if faults.transient_500 > 0:
            faults.transient_500 -= 1
            raise FakeClientError("InternalError", "We encountered an internal error", 500)
        if faults.access_denied > 0:
            faults.access_denied -= 1
            raise FakeClientError("AccessDenied", "Access Denied", 403)

    def _maybe_miss(self, operation: str, key: str) -> bool:
        if operation in ("get_object", "head_object") and self.faults.read_after_write_misses > 0:
            self.faults.read_after_write_misses -= 1
            return True
        return False

    # -- the surface -------------------------------------------------------
    def put_object(self, **kwargs: Any) -> Dict[str, Any]:
        key = str(kwargs["Key"])
        self.calls.append(("put_object", key))
        self._maybe_fail("put_object", key)
        if kwargs.get("IfNoneMatch") == "*":
            self.conditional_puts.append(key)
            if key in self.objects:
                raise FakeClientError(
                    "PreconditionFailed", "At least one of the pre-conditions you "
                    "specified did not hold", 412,
                )
        body = kwargs["Body"]
        payload = bytes(body) if isinstance(body, (bytes, bytearray)) else bytes(body.read())
        self.objects[key] = {
            "Body": payload,
            "Metadata": dict(kwargs.get("Metadata") or {}),
            "ContentType": kwargs.get("ContentType", "binary/octet-stream"),
            "ServerSideEncryption": kwargs.get("ServerSideEncryption"),
            "SSEKMSKeyId": kwargs.get("SSEKMSKeyId"),
        }
        return {"ETag": f'"{len(payload)}"'}

    def get_object(self, **kwargs: Any) -> Dict[str, Any]:
        key = str(kwargs["Key"])
        self.calls.append(("get_object", key))
        self._maybe_fail("get_object", key)
        if self._maybe_miss("get_object", key) or key not in self.objects:
            raise FakeClientError("NoSuchKey", "The specified key does not exist.", 404)
        entry = self.objects[key]
        payload = bytes(entry["Body"])
        if key in self.faults.corrupt_keys:
            payload = _corrupt(payload)
        return {
            "Body": io.BytesIO(payload),
            "ContentLength": len(payload),
            "Metadata": dict(entry["Metadata"]),
            "ETag": f'"{len(payload)}"',
        }

    def head_object(self, **kwargs: Any) -> Dict[str, Any]:
        key = str(kwargs["Key"])
        self.calls.append(("head_object", key))
        self._maybe_fail("head_object", key)
        if self._maybe_miss("head_object", key) or key not in self.objects:
            raise FakeClientError("404", "Not Found", 404)
        entry = self.objects[key]
        return {
            "ContentLength": len(entry["Body"]),
            "Metadata": dict(entry["Metadata"]),
            "ETag": f'"{len(entry["Body"])}"',
        }

    def delete_object(self, **kwargs: Any) -> Dict[str, Any]:
        key = str(kwargs["Key"])
        self.calls.append(("delete_object", key))
        self._maybe_fail("delete_object", key)
        self.objects.pop(key, None)
        return {"DeleteMarker": False}

    def list_objects_v2(self, **kwargs: Any) -> Dict[str, Any]:
        prefix = str(kwargs.get("Prefix") or "")
        self.calls.append(("list_objects_v2", prefix))
        self._maybe_fail("list_objects_v2", prefix)
        keys = sorted(key for key in self.objects if key.startswith(prefix))
        token = kwargs.get("ContinuationToken")
        start = keys.index(token) if token in keys else 0
        page_size = int(kwargs.get("MaxKeys") or 1000)
        window = keys[start: start + page_size]
        truncated = start + page_size < len(keys)
        response: Dict[str, Any] = {
            "Contents": [
                {"Key": key, "Size": len(self.objects[key]["Body"])} for key in window
            ],
            "IsTruncated": truncated,
            "KeyCount": len(window),
        }
        if truncated:
            response["NextContinuationToken"] = keys[start + page_size]
        return response

    # -- multipart ---------------------------------------------------------
    def create_multipart_upload(self, **kwargs: Any) -> Dict[str, Any]:
        key = str(kwargs["Key"])
        self.calls.append(("create_multipart_upload", key))
        self._maybe_fail("create_multipart_upload", key)
        upload_id = f"upload-{self._next_upload}"
        self._next_upload += 1
        self.uploads[upload_id] = {"Key": key, "Parts": {}}
        return {"UploadId": upload_id, "Key": key, "Bucket": kwargs.get("Bucket")}

    def upload_part(self, **kwargs: Any) -> Dict[str, Any]:
        upload_id = str(kwargs["UploadId"])
        self.calls.append(("upload_part", upload_id))
        self._maybe_fail("upload_part", str(kwargs["Key"]))
        upload = self.uploads.get(upload_id)
        if upload is None:
            raise FakeClientError("NoSuchUpload", "The specified upload does not exist.", 404)
        body = kwargs["Body"]
        payload = bytes(body) if isinstance(body, (bytes, bytearray)) else bytes(body.read())
        number = int(kwargs["PartNumber"])
        upload["Parts"][number] = payload
        return {"ETag": f'"part-{number}"'}

    def complete_multipart_upload(self, **kwargs: Any) -> Dict[str, Any]:
        upload_id = str(kwargs["UploadId"])
        self.calls.append(("complete_multipart_upload", upload_id))
        self._maybe_fail("complete_multipart_upload", str(kwargs["Key"]))
        upload = self.uploads.pop(upload_id, None)
        if upload is None:
            raise FakeClientError("NoSuchUpload", "The specified upload does not exist.", 404)
        declared = [int(part["PartNumber"]) for part in kwargs["MultipartUpload"]["Parts"]]
        if sorted(declared) != sorted(upload["Parts"]):
            raise FakeClientError(
                "InvalidPart", "One or more of the specified parts could not be found.", 400
            )
        payload = b"".join(upload["Parts"][number] for number in sorted(upload["Parts"]))
        self.objects[str(kwargs["Key"])] = {
            "Body": payload,
            "Metadata": {},
            "ContentType": "application/json",
            "ServerSideEncryption": None,
            "SSEKMSKeyId": None,
        }
        return {"ETag": f'"{len(payload)}-{len(declared)}"', "Key": kwargs["Key"]}

    def abort_multipart_upload(self, **kwargs: Any) -> Dict[str, Any]:
        upload_id = str(kwargs["UploadId"])
        self.calls.append(("abort_multipart_upload", upload_id))
        self.uploads.pop(upload_id, None)
        self.aborted_uploads.append(upload_id)
        return {}


def _corrupt(payload: bytes) -> bytes:
    """Flip one byte.  Enough to break the hash and nothing else.

    A wholesale replacement would also be caught by a length check, and the
    point is to prove the *hash* verification fires -- an adapter that only
    compared lengths would pass a cruder test and ship a hole.
    """
    if not payload:
        return b"\x00"
    mutated = bytearray(payload)
    mutated[len(mutated) // 2] ^= 0x01
    return bytes(mutated)
