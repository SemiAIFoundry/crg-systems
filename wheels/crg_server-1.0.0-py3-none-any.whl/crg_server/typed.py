"""Typed request decoding: JSON in, kernel dataclasses out.

Normative basis: 10.1 (external systems shall interact through typed requests
and responses, and shall not directly mutate canonical CRG objects), 14.2
(numeric representations), 38.2 (API styles), 48.3 (adversarial
implementation).

Specification 10.1 draws the boundary this module implements.  An integrator
sends JSON; the kernel accepts typed objects and nothing else.  The decoder
is driven by the ``dataclasses`` metadata of the target type rather than by a
hand-written adapter per record, which matters for a reason beyond brevity:
a hand-written adapter drifts from the type it adapts, and a decoder that
silently drops a field the kernel later added would let a request specify
less than the caller thinks it did.  Here an unknown key is an error and a
missing required field is an error, so a request is either fully understood
or refused.

Two refusals are load-bearing.

**No float ever enters a typed field (14.2).**  A JSON number that is not an
integer decodes to a Python ``float``, and this module refuses it by type
rather than converting it: ``0.1`` is not a rational the caller wrote, it is
the nearest binary approximation of one, and the whole certifying path below
is exact.  Send ``"1/10"`` or ``"0.1"`` as a *string* and it becomes
``Exact(1, 10)`` exactly.

**No unknown key is ignored (48.3).**  An adversarial or merely stale client
that sends ``{"tie_tolerance": ...}`` to a type that has no such field is
told so, rather than having its tolerance quietly disregarded and receiving a
certificate that answers a different question.
"""
from __future__ import annotations

import dataclasses
import sys
import typing
from fractions import Fraction
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple, Type, TypeVar, Union

from crg_model.numeric import Exact, Interval

from .errors import UsageError

__all__ = ["decode", "decode_exact", "decode_interval", "encode"]

T = TypeVar("T")

_NONE = type(None)


def decode_exact(value: Any, *, where: str = "value") -> Exact:
    """Decode an exact rational (spec 14.2).

    Accepts an integer, a decimal or fractional *string*, a ``{"exact": ...}``
    canonical form, or a ``[numerator, denominator]`` pair.  Refuses a JSON
    float: see the module docstring.
    """
    if isinstance(value, Exact):
        return value
    if isinstance(value, bool):
        raise UsageError(f"{where}: a boolean is not a quantity (14.2)")
    if isinstance(value, float):
        raise UsageError(
            f"{where}: {value!r} is a binary float, not an exact rational",
            remedy='send the rational as a string, e.g. "0.1" or "1/10" (14.2)',
        )
    if isinstance(value, Mapping):
        if "exact" in value:
            return decode_exact(value["exact"], where=where)
        if "numerator" in value and "denominator" in value:
            return Exact(Fraction(int(value["numerator"]), int(value["denominator"])))
        raise UsageError(f"{where}: {dict(value)!r} is not an exact-rational encoding")
    if isinstance(value, (list, tuple)) and len(value) == 2:
        return Exact(Fraction(int(value[0]), int(value[1])))
    try:
        return Exact(value)
    except (TypeError, ValueError, ZeroDivisionError) as error:
        raise UsageError(f"{where}: {value!r} is not an exact rational ({error})") from None


def decode_interval(value: Any, *, where: str = "interval") -> Interval:
    """Decode an exact interval (spec 14.2, 22.2)."""
    if isinstance(value, Interval):
        return value
    if isinstance(value, Mapping):
        if "lo" in value or "hi" in value:
            lo = decode_exact(value.get("lo", value.get("hi")), where=f"{where}.lo")
            hi = decode_exact(value.get("hi", value.get("lo")), where=f"{where}.hi")
            return Interval(lo, hi)
        if "interval" in value:
            return decode_interval(value["interval"], where=where)
        return Interval(decode_exact(value, where=where))
    if isinstance(value, (list, tuple)):
        if len(value) == 1:
            return Interval(decode_exact(value[0], where=where))
        if len(value) == 2:
            return Interval(
                decode_exact(value[0], where=f"{where}[0]"),
                decode_exact(value[1], where=f"{where}[1]"),
            )
        raise UsageError(f"{where}: an interval is [lo, hi] or [point], not {len(value)} elements")
    return Interval(decode_exact(value, where=where))


def _hints_for(cls: type) -> Dict[str, Any]:
    module = sys.modules.get(cls.__module__)
    namespace = dict(vars(module)) if module else {}
    namespace.setdefault("Exact", Exact)
    namespace.setdefault("Interval", Interval)
    try:
        return typing.get_type_hints(cls, globalns=namespace)
    except Exception:  # noqa: BLE001 - fall back to the raw annotations
        return dict(getattr(cls, "__annotations__", {}))


def _decode_value(annotation: Any, value: Any, *, where: str) -> Any:
    origin = typing.get_origin(annotation)
    args = typing.get_args(annotation)

    if annotation is Any or annotation is None:
        return value
    if annotation is Exact:
        return decode_exact(value, where=where)
    if annotation is Interval:
        return decode_interval(value, where=where)

    if origin is Union:
        if value is None and _NONE in args:
            return None
        alternatives = [a for a in args if a is not _NONE]
        last: Optional[Exception] = None
        for alternative in alternatives:
            try:
                return _decode_value(alternative, value, where=where)
            except UsageError as error:
                last = error
        if last is not None:
            raise last
        return value

    if origin in (tuple, Tuple):
        if not isinstance(value, (list, tuple)):
            raise UsageError(f"{where}: expected a list, got {type(value).__name__}")
        if len(args) == 2 and args[1] is Ellipsis:
            return tuple(
                _decode_value(args[0], item, where=f"{where}[{i}]")
                for i, item in enumerate(value)
            )
        if args:
            if len(value) != len(args):
                raise UsageError(
                    f"{where}: expected {len(args)} elements, got {len(value)}"
                )
            return tuple(
                _decode_value(a, item, where=f"{where}[{i}]")
                for i, (a, item) in enumerate(zip(args, value))
            )
        return tuple(value)

    if origin in (list, Sequence, typing.List) or origin is typing.Sequence:
        if not isinstance(value, (list, tuple)):
            raise UsageError(f"{where}: expected a list, got {type(value).__name__}")
        inner = args[0] if args else Any
        return [
            _decode_value(inner, item, where=f"{where}[{i}]") for i, item in enumerate(value)
        ]

    if origin in (dict, Mapping, typing.Dict) or origin is typing.Mapping:
        if not isinstance(value, Mapping):
            raise UsageError(f"{where}: expected an object, got {type(value).__name__}")
        inner = args[1] if len(args) == 2 else Any
        return {
            str(k): _decode_value(inner, v, where=f"{where}.{k}") for k, v in value.items()
        }

    if dataclasses.is_dataclass(annotation):
        return decode(annotation, value, where=where)

    if annotation is bytes:
        if isinstance(value, (bytes, bytearray)):
            return bytes(value)
        if isinstance(value, str):
            try:
                return bytes.fromhex(value)
            except ValueError:
                return value.encode("utf-8")
        raise UsageError(f"{where}: expected a hex string for a byte field")

    if annotation is bool:
        if not isinstance(value, bool):
            raise UsageError(f"{where}: expected a boolean, got {type(value).__name__}")
        return value
    if annotation is int:
        if isinstance(value, bool) or not isinstance(value, int):
            raise UsageError(f"{where}: expected an integer, got {type(value).__name__}")
        return value
    if annotation is str:
        if not isinstance(value, str):
            raise UsageError(f"{where}: expected a string, got {type(value).__name__}")
        return value
    if annotation is float:  # pragma: no cover - no certifying field is a float
        raise UsageError(f"{where}: floats do not appear on a certifying path (14.2)")
    return value


def decode(cls: Type[T], payload: Any, *, where: str = "") -> T:
    """Build an instance of the dataclass ``cls`` from JSON ``payload``.

    Missing required fields and unknown keys are both errors, and the message
    names the type and the field so an integrator does not have to read the
    kernel source to find out what was wanted.
    """
    label = where or getattr(cls, "__name__", str(cls))
    if isinstance(payload, cls):  # already typed
        return payload
    if not isinstance(payload, Mapping):
        raise UsageError(
            f"{label}: expected a JSON object describing a {getattr(cls, '__name__', cls)}, "
            f"got {type(payload).__name__}"
        )
    if not dataclasses.is_dataclass(cls):  # pragma: no cover - internal contract
        raise UsageError(f"{label}: {cls!r} is not a typed record")

    hints = _hints_for(cls)
    fields = {f.name: f for f in dataclasses.fields(cls) if f.init}
    unknown = sorted(set(payload) - set(fields))
    if unknown:
        raise UsageError(
            f"{label}: unknown field(s) {unknown}",
            remedy=f"accepted fields are {sorted(fields)}",
            detail={"type": getattr(cls, "__name__", str(cls)), "unknown_fields": unknown},
        )
    kwargs: Dict[str, Any] = {}
    for name, spec in fields.items():
        if name not in payload:
            has_default = (
                spec.default is not dataclasses.MISSING
                or spec.default_factory is not dataclasses.MISSING  # type: ignore[misc]
            )
            if has_default:
                continue
            raise UsageError(
                f"{label}: required field {name!r} is absent",
                remedy=f"supply {name!r}; it has no default because the specification gives none",
                detail={"type": getattr(cls, "__name__", str(cls)), "missing_field": name},
            )
        kwargs[name] = _decode_value(
            hints.get(name, Any), payload[name], where=f"{label}.{name}"
        )
    try:
        return cls(**kwargs)  # type: ignore[call-arg]
    except UsageError:
        raise
    except Exception as error:  # noqa: BLE001 - the kernel's own validation speaks here
        raise UsageError(
            f"{label}: {type(error).__name__}: {error}",
            detail={"type": getattr(cls, "__name__", str(cls))},
        ) from None


def encode(value: Any) -> Any:
    """Project a kernel object back to canonical JSON (spec 14.3).

    ``to_canonical`` is used where the object defines it, because that method
    *is* the canonical form the hashes are taken over; re-deriving one here
    would produce a second dialect and a second set of hashes.
    """
    if hasattr(value, "to_canonical"):
        return value.to_canonical()
    if isinstance(value, (Exact, Interval)):
        return value.to_canonical()
    if dataclasses.is_dataclass(value) and not isinstance(value, type):
        return {f.name: encode(getattr(value, f.name)) for f in dataclasses.fields(value)}
    if isinstance(value, Mapping):
        return {str(k): encode(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set, frozenset)):
        return [encode(v) for v in value]
    if isinstance(value, bytes):
        return value.hex()
    return value
