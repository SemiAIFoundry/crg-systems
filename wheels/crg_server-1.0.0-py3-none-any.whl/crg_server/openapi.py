"""The OpenAPI 3.1 description, generated from the endpoint table.

Normative basis: 38.2 (the reference server SHALL provide REST with OpenAPI
3.1), 38.3 (principal endpoints), 38.4 (idempotency), 38.5 (events), 6.6
(fail closed), 6.12 (anti-lock-in), 51 (documentation requirements).

The document is *generated* from :data:`crg_server.app.ENDPOINTS` rather than
maintained beside it.  A hand-written description drifts, and a drifted
description is worse than none: an integrator generating a client from it
would produce code that calls endpoints this server does not have and omits
ones it does.  Because the table is the same object the router walks, the
description and the behaviour cannot disagree.

Three things the document says that a naive generator would omit, and that
6.6 makes load-bearing:

* every long-running operation documents ``202`` with a job identifier as its
  *success* response, so a generated client is shaped around the asynchronous
  contract of 38.3 rather than discovering it at runtime;
* every operation documents its refusal statuses, including ``422`` for a
  blocked outcome, so a client's error handling is written against the real
  set; and
* ``Idempotency-Key`` appears as a documented header on every mutation
  (38.4), because an idempotency mechanism nobody can discover is one nobody
  uses.
"""
from __future__ import annotations

from typing import Any, Dict, List

__all__ = ["OPENAPI_VERSION", "openapi_document", "endpoint_paths"]

OPENAPI_VERSION = "3.1.0"

_ERROR_SCHEMA = {
    "type": "object",
    "required": ["error"],
    "properties": {
        "error": {
            "type": "object",
            "required": ["category", "status", "message"],
            "properties": {
                "category": {"type": "string"},
                "status": {"type": "integer"},
                "message": {"type": "string"},
                "remedy": {"type": "string"},
                "detail": {"type": "object", "additionalProperties": True},
            },
        }
    },
}

_JOB_ACCEPTED_SCHEMA = {
    "type": "object",
    "required": ["job_id", "status"],
    "properties": {
        "job_id": {"type": "string"},
        "kind": {"type": "string"},
        "status": {"type": "string",
                   "enum": ["QUEUED", "RUNNING", "SUCCEEDED", "FAILED", "CANCELLED"]},
        "case_id": {"type": ["string", "null"]},
        "input_hash": {"type": "string"},
        "links": {"type": "object", "additionalProperties": {"type": "string"}},
    },
}

_EVENT_SCHEMA = {
    "type": "object",
    "required": [
        "event", "case_id", "branch_id", "object_hashes", "timestamp", "actor",
        "correlation_id", "schema_version",
    ],
    "properties": {
        "event": {"type": "string"},
        "case_id": {"type": ["string", "null"]},
        "branch_id": {"type": ["string", "null"]},
        "object_hashes": {"type": "array", "items": {"type": "string"}},
        "timestamp": {"type": "string"},
        "actor": {"type": "string"},
        "correlation_id": {"type": "string"},
        "schema_version": {"type": "string"},
        "detail": {"type": "object", "additionalProperties": True},
    },
}

_AUDIT_HASH_SCHEMA = {"type": "string", "pattern": "^sha256:[0-9a-f]{64}$"}

_AUDIT_ENTRY_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "required": [
        "sequence", "timestamp", "tenant_id", "actor", "action", "resource",
        "decision", "outcome", "correlation_id", "rule_id", "detail",
        "previous_hash", "entry_hash",
    ],
    "properties": {
        "sequence": {"type": "integer", "minimum": 0},
        "timestamp": {"type": "string", "format": "date-time"},
        "tenant_id": {"type": "string", "minLength": 1},
        "actor": {"type": "string"},
        "action": {"type": "string"},
        "resource": {"type": "string"},
        "decision": {"type": "string"},
        "outcome": {"type": "string"},
        "correlation_id": {"type": "string"},
        "rule_id": {"type": "string"},
        "detail": {"type": "object", "additionalProperties": True},
        "previous_hash": _AUDIT_HASH_SCHEMA,
        "entry_hash": _AUDIT_HASH_SCHEMA,
    },
}

_AUDIT_EXPORT_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "required": [
        "record_type", "format_version", "tenant_id", "requested_by", "authority",
        "exported_at", "clock_source", "clock_trust_level", "range",
        "total_entry_count", "genesis_hash", "predecessor_hash", "page_head_hash",
        "chain_head_hash", "chain_verification", "checkpoint_status", "checkpoint",
        "entries", "verification_scope", "artifact_hash",
    ],
    "properties": {
        "record_type": {"type": "string", "const": "AuditExportRecord"},
        "format_version": {"type": "string", "const": "1.0.0"},
        "tenant_id": {"type": "string", "minLength": 1},
        "requested_by": {"type": "string", "minLength": 1},
        "authority": {"type": "string", "minLength": 1},
        "exported_at": {"type": "string", "format": "date-time"},
        "clock_source": {"type": "string"},
        "clock_trust_level": {"type": "string"},
        "range": {
            "type": "object", "additionalProperties": False,
            "required": ["after_sequence", "start_sequence", "end_sequence",
                         "entry_count", "next_after_sequence", "has_more"],
            "properties": {
                "after_sequence": {"type": "integer", "minimum": -1},
                "start_sequence": {"type": ["integer", "null"], "minimum": 0},
                "end_sequence": {"type": ["integer", "null"], "minimum": 0},
                "entry_count": {"type": "integer", "minimum": 0, "maximum": 1000},
                "next_after_sequence": {"type": "integer", "minimum": -1},
                "has_more": {"type": "boolean"},
            },
        },
        "total_entry_count": {"type": "integer", "minimum": 0},
        "genesis_hash": _AUDIT_HASH_SCHEMA,
        "predecessor_hash": _AUDIT_HASH_SCHEMA,
        "page_head_hash": _AUDIT_HASH_SCHEMA,
        "chain_head_hash": _AUDIT_HASH_SCHEMA,
        "chain_verification": {"type": "object", "additionalProperties": True},
        "checkpoint_status": {"type": "string", "enum": ["SIGNED", "UNSIGNED"]},
        "checkpoint": {"type": "object", "additionalProperties": True},
        "entries": {"type": "array", "maxItems": 1000, "items": _AUDIT_ENTRY_SCHEMA},
        "verification_scope": {"type": "string"},
        "artifact_hash": _AUDIT_HASH_SCHEMA,
    },
}

_TOMBSTONE_SCHEMA = {
    "type": "object",
    "required": ["content_hash", "object_type", "removal_reason", "removal_authority"],
    "properties": {
        "record_type": {"type": "string", "const": "TombstoneRecord"},
        "object_id": {"type": "string"},
        "content_hash": {"type": "string"},
        "object_type": {"type": "string"},
        "removal_reason": {"type": "string"},
        "removal_authority": {"type": "string"},
        "removal_time": {"type": "string"},
        "legal_hold": {"type": "boolean"},
        "permitted_disclosure": {"type": "string"},
        "dependency_edges": {"type": "array", "items": {"type": "object"}},
    },
}

_JOB_SCHEMA = {
    "type": "object",
    "description": "Every item specification 42.4 requires a job to record.",
    "required": [
        "job_id", "kind", "canonical_inputs", "engine_versions", "resource_limits",
        "status", "logs", "outputs", "failure_category", "retry_history",
        "cancellation", "determinism_status", "solver_trust_profile", "proof_artifacts",
        "execution_phase",
    ],
    "properties": {
        "job_id": {"type": "string"},
        "kind": {"type": "string"},
        "case_id": {"type": ["string", "null"]},
        "branch_id": {"type": ["string", "null"]},
        "canonical_inputs": {"type": "object", "additionalProperties": True},
        "input_hash": {"type": "string"},
        "engine_versions": {"type": "object", "additionalProperties": {"type": "string"}},
        "resource_limits": {"type": "object", "additionalProperties": True},
        "status": {"type": "string", "enum": [
            "QUEUED", "RUNNING", "SUCCEEDED", "FAILED", "CANCELLED"
        ]},
        "execution_phase": {"type": "string", "enum": [
            "QUEUED", "EXECUTING", "COMMITTING", "TERMINAL"
        ]},
        "started_at": {"type": ["string", "null"]},
        "completed_at": {"type": ["string", "null"]},
        "logs": {"type": "array", "items": {"type": "string"}},
        "outputs": {"type": "object", "additionalProperties": True},
        "failure_category": {"type": ["string", "null"]},
        "retry_history": {"type": "array", "items": {"type": "object"}},
        "cancellation": {"type": ["object", "null"]},
        "determinism_status": {"type": "string"},
        "solver_trust_profile": {"type": "string"},
        "proof_artifacts": {"type": "array", "items": {"type": "object"}},
    },
}

_EXACT_SCHEMA = {
    "description": (
        "An exact rational (14.2).  Send a string such as \"3/4\" or \"0.25\", an "
        "integer, or {\"numerator\": n, \"denominator\": d}.  A JSON float is refused: "
        "no float appears on a certifying path."
    ),
    "oneOf": [
        {"type": "string"},
        {"type": "integer"},
        {
            "type": "object",
            "required": ["numerator", "denominator"],
            "properties": {
                "numerator": {"type": "integer"},
                "denominator": {"type": "integer"},
            },
        },
    ],
}


def _responses(endpoint: Any) -> Dict[str, Any]:
    responses: Dict[str, Any] = {}
    if endpoint.long_running:
        responses["202"] = {
            "description": (
                "Accepted.  38.3: a long-running action returns a job identifier, "
                "not a result.  Poll GET /jobs/{job_id}/result."
            ),
            "content": {"application/json": {"schema": _JOB_ACCEPTED_SCHEMA}},
        }
    elif getattr(endpoint, "streaming", False):
        # 38.2 event streaming.  The response is an endless sequence of SSE
        # records, not one document, and the description says so: a generated
        # client that read this as a body would block until the subscription
        # ended, which for a live stream is never.
        responses[str(endpoint.success_status)] = {
            "description": (
                f"An open Server-Sent Events stream ({endpoint.summary}).  Each "
                "record carries id (the event ordinal), event (a name from the "
                "38.5 vocabulary), and data (the canonical JSON of the 38.5 "
                "carrier).  Comment records beginning ': ' are keepalives.  "
                "Reconnect with Last-Event-ID to resume with no gap and no "
                "duplicate."
            ),
            "content": {
                endpoint.produces: {
                    "schema": {
                        "type": "string",
                        "contentMediaType": endpoint.produces,
                        "description": "The SSE wire format of the WHATWG HTML "
                                       "specification, as required by 38.2.",
                    }
                }
            },
            "headers": {
                "Cache-Control": {"schema": {"type": "string", "const": "no-cache"}},
                "X-Accel-Buffering": {"schema": {"type": "string", "const": "no"}},
            },
        }
    elif endpoint.operation_id == "exportAudit":
        responses[str(endpoint.success_status)] = {
            "description": "A bounded, canonical tenant security-audit page.",
            "content": {
                "application/json": {
                    "schema": {"$ref": "#/components/schemas/AuditExportRecord"}
                }
            },
            "headers": {
                "Content-Disposition": {"schema": {"type": "string"}},
                "Cache-Control": {"schema": {"type": "string", "const": "no-store"}},
            },
        }
    else:
        responses[str(endpoint.success_status)] = {
            "description": f"Success ({endpoint.summary}).",
            "content": {endpoint.produces: {"schema": {"type": "object"}}}
            if endpoint.produces == "application/json"
            else {endpoint.produces: {"schema": {"type": "string", "format": "binary"}}},
        }
    detail = {
        400: "Malformed or inadmissible request.",
        401: "No actor identity was presented (44.2).",
        403: "The actor holds no role authorizing this operation (44.3).",
        404: "No object of that identity exists here.",
        405: "The route exists and this verb does not.",
        409: (
            "Conflict: stale parent version (16.1), idempotency key reuse (38.4), "
            "legal hold (17.5), or a job that produced no result (42.4)."
        ),
        410: "The content was redacted; the tombstone is returned (17.2).",
        413: "The request exceeds the deployment's declared byte or archive-expansion limit.",
        415: "This surface is JSON only (38.2).",
        422: (
            "Scope mismatch or a blocked outcome.  6.6: a refusal is never reported "
            "behind a 200."
        ),
        503: "A required local dependency is unavailable; readiness fails closed.",
    }
    for status in endpoint.failure_statuses:
        responses[str(status)] = {
            "description": detail.get(status, "Refused."),
            "content": {"application/json": {"schema": _ERROR_SCHEMA}},
        }
    return responses


def _parameters(endpoint: Any, *, authenticated: bool) -> List[Dict[str, Any]]:
    parameters: List[Dict[str, Any]] = [
        {
            "name": name,
            "in": "path",
            "required": True,
            "schema": {"type": "string"},
            "description": f"Identifier bound by the route {endpoint.path}.",
        }
        for name in endpoint.parameters
    ]
    for name, description in getattr(endpoint, "query_parameters", ()):
        parameters.append(
            {
                "name": name,
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
                "description": description,
            }
        )
    for name, description in getattr(endpoint, "header_parameters", ()):
        parameters.append(
            {
                "name": name,
                "in": "header",
                "required": False,
                "schema": {"type": "string"},
                "description": description,
            }
        )
    if endpoint.case_scoped and endpoint.method == "GET":
        parameters.append(
            {
                "name": "version",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
                "description": (
                    "A version ordinal or a sha256 content hash.  11.2: a prior case "
                    "version remains addressable after supersession."
                ),
            }
        )
    if not authenticated:
        parameters.append(
            {
                "name": "X-CRG-Actor",
                "in": "header",
                "required": endpoint.method != "GET",
                "schema": {"type": "string"},
                "description": (
                    "Unverified development-profile actor assertion. This is not an "
                    "authentication mechanism and must not be exposed to an untrusted network."
                ),
            }
        )
    parameters.append(
        {
            "name": "X-CRG-Correlation-Id",
            "in": "header",
            "required": False,
            "schema": {"type": "string"},
            "description": "38.5: every emitted event carries this correlation identifier.",
        }
    )
    parameters.append(
        {
            "name": "traceparent",
            "in": "header",
            "required": False,
            "schema": {
                "type": "string",
                "pattern": "^[0-9a-f]{2}-[0-9a-f]{32}-[0-9a-f]{16}-[0-9a-f]{2}$",
            },
            "description": (
                "Optional W3C Trace Context parent. A valid trace id is propagated "
                "with a fresh server span id; malformed input starts a new trace."
            ),
        }
    )
    if endpoint.method == "POST":
        parameters.append(
            {
                "name": "Idempotency-Key",
                "in": "header",
                "required": False,
                "schema": {"type": "string"},
                "description": (
                    "38.4: mutation requests support idempotency keys.  An identical "
                    "canonical request under the same key replays the recorded response; "
                    "a different request under the same key is a 409."
                ),
            }
        )
    return parameters


def _request_body(endpoint: Any) -> Dict[str, Any]:
    properties = {
        name: {"description": f"See specification {endpoint.spec}."}
        for name in endpoint.request_fields
    }
    return {
        "required": bool(endpoint.request_fields),
        "content": {
            "application/json": {
                "schema": {
                    "type": "object",
                    "properties": properties,
                    "additionalProperties": True,
                    "description": (
                        "10.1: external systems interact through typed requests and "
                        "responses, and never mutate canonical CRG objects directly."
                    ),
                }
            }
        },
    }


def endpoint_paths() -> List[str]:
    """Every ``METHOD path`` pair this server implements."""
    from .app import ENDPOINTS

    return [f"{e.method} {e.path}" for e in ENDPOINTS]


def openapi_document(*, authenticated: bool = True) -> Dict[str, Any]:
    """The complete OpenAPI 3.1 description of the integration surface (38.2)."""
    from .app import ENDPOINTS, ROLE_REQUIREMENTS
    from .events import EVENT_VOCABULARY

    paths: Dict[str, Any] = {}
    for endpoint in ENDPOINTS:
        operation: Dict[str, Any] = {
            "operationId": endpoint.operation_id,
            "summary": endpoint.summary,
            "description": (
                f"Specification {endpoint.spec}."
                + (
                    "  This action is long-running and returns a job identifier (38.3)."
                    if endpoint.long_running
                    else ""
                )
                + (
                    "  Identical canonical requests resolve to the existing "
                    "content-addressed result (38.4)."
                    if endpoint.content_addressed
                    else ""
                )
            ),
            "tags": [endpoint.path.strip("/").split("/")[0] or "root"],
            "parameters": _parameters(endpoint, authenticated=authenticated),
            "responses": _responses(endpoint),
        }
        required_roles = ROLE_REQUIREMENTS.get(endpoint.operation_id)
        if required_roles:
            operation["x-crg-required-roles"] = list(required_roles)
        operation["x-crg-spec-reference"] = endpoint.spec
        operation["x-crg-long-running"] = endpoint.long_running
        if getattr(endpoint, "streaming", False):
            # A generated client needs to know, before it calls, that this
            # operation returns an iterator rather than a document (38.2).
            operation["x-crg-streaming"] = True
            operation["x-crg-stream-transport"] = "server-sent-events"
        if endpoint.method == "POST":
            operation["requestBody"] = _request_body(endpoint)
        if authenticated and endpoint.operation_id in {
            "getOpenApi", "healthLive", "healthReady"
        }:
            operation["security"] = []
        paths.setdefault(endpoint.path, {})[endpoint.method.lower()] = operation

    return {
        "openapi": OPENAPI_VERSION,
        "info": {
            "title": "CRG Systems headless integration surface",
            "version": "1.0.0",
            "summary": "Import, augment, certify, verify, and export CRG cases",
            "description": (
                "The secured CRG Systems API. Long-running actions return job "
                "identifiers, mutations accept idempotency keys, and blocked or "
                "unauthorized outcomes are never represented as successful results."
            ),
            "license": {
                "name": "CRG Systems Research and Noncommercial License 1.0",
                "identifier": "LicenseRef-CRG-Research-Noncommercial-1.0",
            },
            "x-commercial-license-required": True,
        },
        "servers": [{"url": "/", "description": "this deployment"}],
        "paths": paths,
        "components": {
            "schemas": {
                "Error": _ERROR_SCHEMA,
                "JobAccepted": _JOB_ACCEPTED_SCHEMA,
                "JobRecord": _JOB_SCHEMA,
                "Event": _EVENT_SCHEMA,
                "AuditEntry": _AUDIT_ENTRY_SCHEMA,
                "AuditExportRecord": _AUDIT_EXPORT_SCHEMA,
                "TombstoneRecord": _TOMBSTONE_SCHEMA,
                "Exact": _EXACT_SCHEMA,
            },
            "securitySchemes": {
                "BasicAuth": {
                    "type": "http",
                    "scheme": "basic",
                    "description": "TLS-protected local account authentication (44.2, 44.4).",
                },
                "BearerAuth": {
                    "type": "http",
                    "scheme": "bearer",
                    "description": "Federated identity adapter token (44.2).",
                },
                "ApiKeyAuth": {
                    "type": "apiKey",
                    "in": "header",
                    "name": "Authorization",
                    "description": "Service identity as 'ApiKey <key_id>.<secret>' (44.2).",
                },
            } if authenticated else {},
        },
        "security": ([{"BasicAuth": []}, {"BearerAuth": []}, {"ApiKeyAuth": []}]
                     if authenticated else []),
        "x-crg-authentication-profile": (
            "configured-authentication" if authenticated else "unverified-development-actor"
        ),
        "x-crg-spec-version": "0.2.0",
        "x-crg-event-vocabulary": list(EVENT_VOCABULARY),
        "x-crg-object-statuses": [
            "SUPERSEDED", "EXPIRED", "REVOKED", "REDACTED", "CRYPTOGRAPHICALLY_ERASED",
            "LEGALLY_DELETED", "UNAVAILABLE", "INVALID", "UNVERIFIABLE_REDACTED",
        ],
        "x-crg-minimum-roles": [
            "Viewer", "Contributor", "Registry Importer", "Generator Author",
            "Pack Publisher", "Evidence Steward", "Qualification Author",
            "Decision Approver", "Certificate Signer", "Federation Operator",
            "Auditor", "Security Administrator", "System Administrator",
        ],
    }
