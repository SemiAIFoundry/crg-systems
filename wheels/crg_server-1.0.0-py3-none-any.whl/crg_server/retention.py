"""Governed operational retention over the section 17 storage primitives.

Normative basis: 17.1--17.6 (distinct lifecycle states, tombstones,
certificate effect, auditable removal, legal hold, portable disclosure), 42.1
(content and lifecycle metadata are separate), 44.5 (tenant-scoped storage and
audit), and Gate 7's required "retention and legal hold" output.

The storage backends already own the dangerous primitive: ``redact`` writes a
tombstone before deleting bytes, refuses a legal hold, downgrades dependent
certificates, and audits the removal.  This module deliberately does not
reimplement any of that.  It adds the missing policy plane:

* immutable, content-addressed ``RetentionPolicyRecord`` objects;
* deterministic evaluation against a server-owned explicit clock;
* bounded, resumable dry runs and enforcement sweeps;
* a second legal-hold check at the moment of removal;
* immutable ``RetentionRunRecord`` evidence for every sweep; and
* an audit event binding the policy, run, authority, cursor and outcomes.

There is no ambient "delete everything older than N" default.  An operator
must name an active policy hash, a removal authority, and a bounded batch.
Unknown metadata and races fail closed as recorded refusals, never deletion.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

from crg_model.envelope import ObjectStatus, utc_now

from .errors import ConflictError, NotFoundError, ServerError, UsageError

__all__ = [
    "RetentionAction",
    "RetentionDecision",
    "RetentionPolicy",
    "RetentionEngine",
    "RETENTION_CONTROL_TYPES",
    "retention_engine_for_store",
]


class RetentionAction:
    """The only lifecycle changes an operational policy may authorize."""

    MARK_EXPIRED = "MARK_EXPIRED"
    REDACT = "REDACT"
    LEGALLY_DELETE = "LEGALLY_DELETE"
    ALL = frozenset({MARK_EXPIRED, REDACT, LEGALLY_DELETE})
    REMOVES_CONTENT = frozenset({REDACT, LEGALLY_DELETE})


RETENTION_CONTROL_TYPES = frozenset({"RetentionPolicyRecord", "RetentionRunRecord"})
DEFAULT_ELIGIBLE_STATUSES = (
    ObjectStatus.ACTIVE,
    ObjectStatus.SUPERSEDED,
    ObjectStatus.EXPIRED,
    ObjectStatus.STALE,
    ObjectStatus.INVALID,
    ObjectStatus.REVOKED,
)


def _instant(value: str, label: str) -> datetime:
    text = str(value or "")
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError as error:
        raise UsageError(
            f"{label} must be an ISO-8601 timestamp with an explicit timezone"
        ) from error
    if parsed.tzinfo is None:
        raise UsageError(f"{label} must carry an explicit timezone")
    return parsed.astimezone(timezone.utc)


def _age_seconds(created_at: str, as_of: str) -> int:
    created = _instant(created_at, "object created_at")
    observed = _instant(as_of, "retention evaluation time")
    delta = observed - created
    # Integer arithmetic only. A future-created object has age -1 and is
    # refused as clock skew, not rounded to zero and made eligible.
    return delta.days * 86400 + delta.seconds


@dataclass(frozen=True)
class RetentionPolicy:
    policy_id: str
    version: str
    object_types: Tuple[str, ...]
    minimum_age_seconds: int
    action: str
    reason: str
    created_at: str
    created_by: str
    effective_at: str
    enabled: bool = True
    eligible_statuses: Tuple[str, ...] = DEFAULT_ELIGIBLE_STATUSES
    predecessor_hash: str = ""
    permitted_disclosure: str = "identity-hash-type-reason-authority-time-status"

    def __post_init__(self) -> None:
        object.__setattr__(self, "policy_id", str(self.policy_id).strip())
        object.__setattr__(self, "version", str(self.version).strip())
        object.__setattr__(self, "object_types", tuple(sorted(set(
            str(value).strip() for value in self.object_types if str(value).strip()
        ))))
        object.__setattr__(self, "eligible_statuses", tuple(sorted(set(
            str(value).strip() for value in self.eligible_statuses if str(value).strip()
        ))))
        if not self.policy_id or not self.version:
            raise UsageError("a retention policy requires policy_id and version")
        if not self.object_types:
            raise UsageError("a retention policy requires at least one object_type")
        forbidden = RETENTION_CONTROL_TYPES.intersection(self.object_types)
        if forbidden:
            raise UsageError(
                f"retention control records cannot target themselves: {sorted(forbidden)}"
            )
        if isinstance(self.minimum_age_seconds, bool) or not isinstance(
            self.minimum_age_seconds, int
        ) or self.minimum_age_seconds < 0:
            raise UsageError("minimum_age_seconds must be an exact non-negative integer")
        if self.action not in RetentionAction.ALL:
            raise UsageError(
                f"unknown retention action {self.action!r}; use {sorted(RetentionAction.ALL)}"
            )
        if not str(self.reason).strip():
            raise UsageError("a retention policy requires a stated removal/lifecycle reason")
        if not str(self.created_by).strip():
            raise UsageError("a retention policy requires a named creator")
        _instant(self.created_at, "retention policy created_at")
        _instant(self.effective_at, "retention policy effective_at")
        unknown = set(self.eligible_statuses) - set(ObjectStatus.ALL)
        if unknown:
            raise UsageError(f"unknown eligible lifecycle statuses: {sorted(unknown)}")
        removed = {
            ObjectStatus.REDACTED,
            ObjectStatus.CRYPTOGRAPHICALLY_ERASED,
            ObjectStatus.LEGALLY_DELETED,
            ObjectStatus.UNAVAILABLE,
            ObjectStatus.UNVERIFIABLE_REDACTED,
        }
        if removed.intersection(self.eligible_statuses):
            raise UsageError(
                "a retention policy cannot re-target content that is already removed or "
                "unavailable"
            )

    @classmethod
    def from_mapping(
        cls, value: Mapping[str, Any], *, created_by: str, created_at: Optional[str] = None
    ) -> "RetentionPolicy":
        created = str(value.get("created_at") or created_at or utc_now())
        return cls(
            policy_id=str(value.get("policy_id") or ""),
            version=str(value.get("version") or ""),
            object_types=tuple(value.get("object_types") or ()),
            minimum_age_seconds=value.get("minimum_age_seconds"),
            action=str(value.get("action") or ""),
            reason=str(value.get("reason") or ""),
            created_at=created,
            created_by=str(value.get("created_by") or created_by),
            effective_at=str(value.get("effective_at") or created),
            enabled=bool(value.get("enabled", True)),
            eligible_statuses=tuple(
                value.get("eligible_statuses") or DEFAULT_ELIGIBLE_STATUSES
            ),
            predecessor_hash=str(value.get("predecessor_hash") or ""),
            permitted_disclosure=str(
                value.get("permitted_disclosure")
                or "identity-hash-type-reason-authority-time-status"
            ),
        )

    @classmethod
    def from_canonical(cls, value: Mapping[str, Any]) -> "RetentionPolicy":
        if value.get("record_type") != "RetentionPolicyRecord":
            raise UsageError("the selected object is not a RetentionPolicyRecord")
        return cls(
            policy_id=str(value.get("policy_id") or ""),
            version=str(value.get("version") or ""),
            object_types=tuple(value.get("object_types") or ()),
            minimum_age_seconds=value.get("minimum_age_seconds"),
            action=str(value.get("action") or ""),
            reason=str(value.get("reason") or ""),
            created_at=str(value.get("created_at") or ""),
            created_by=str(value.get("created_by") or ""),
            effective_at=str(value.get("effective_at") or ""),
            enabled=bool(value.get("enabled")),
            eligible_statuses=tuple(value.get("eligible_statuses") or ()),
            predecessor_hash=str(value.get("predecessor_hash") or ""),
            permitted_disclosure=str(value.get("permitted_disclosure") or ""),
        )

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "record_type": "RetentionPolicyRecord",
            "policy_id": self.policy_id,
            "version": self.version,
            "object_types": list(self.object_types),
            "minimum_age_seconds": self.minimum_age_seconds,
            "action": self.action,
            "reason": self.reason,
            "created_at": self.created_at,
            "created_by": self.created_by,
            "effective_at": self.effective_at,
            "enabled": bool(self.enabled),
            "eligible_statuses": list(self.eligible_statuses),
            "predecessor_hash": self.predecessor_hash,
            "permitted_disclosure": self.permitted_disclosure,
        }


@dataclass(frozen=True)
class RetentionDecision:
    content_hash: str
    object_type: str
    created_at: str
    status_before: str
    legal_hold: bool
    age_seconds: int
    decision: str
    reason: str
    status_after: str = ""

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "content_hash": self.content_hash,
            "object_type": self.object_type,
            "created_at": self.created_at,
            "status_before": self.status_before,
            "legal_hold": bool(self.legal_hold),
            "age_seconds": self.age_seconds,
            "decision": self.decision,
            "reason": self.reason,
            "status_after": self.status_after or self.status_before,
        }


class RetentionEngine:
    """Evaluate and enforce one immutable policy against one tenant-bound store."""

    def __init__(self, store: Any) -> None:
        required = (
            "put_object", "get_object", "object_metadata", "object_status",
            "set_object_status", "append_audit", "redact", "objects",
        )
        missing = [name for name in required if not hasattr(store, name)]
        if missing:
            raise TypeError(f"retention store is missing {missing}")
        self.store = store

    def policies(self) -> List[Dict[str, Any]]:
        result: List[Dict[str, Any]] = []
        for digest in self.store.objects.list_digests():
            metadata = self.store.objects.content_metadata(digest)
            if metadata.object_type != "RetentionPolicyRecord":
                continue
            value = self.store.get_object(digest)
            policy = RetentionPolicy.from_canonical(value)
            row = policy.to_canonical()
            row.update({
                "content_hash": digest,
                "status": metadata.status,
                "legal_hold": bool(metadata.legal_hold),
            })
            result.append(row)
        return sorted(result, key=lambda row: (
            str(row["policy_id"]), str(row["version"]), str(row["content_hash"])
        ))

    def register(self, policy: RetentionPolicy, *, authority: str) -> str:
        named_authority = str(authority).strip()
        if not named_authority:
            raise UsageError("registering a retention policy requires a named authority")
        active_same = [
            row for row in self.policies()
            if row["policy_id"] == policy.policy_id and row["status"] == ObjectStatus.ACTIVE
        ]
        if policy.predecessor_hash:
            predecessor = next(
                (row for row in active_same
                 if row["content_hash"] == policy.predecessor_hash), None
            )
            if predecessor is None:
                raise ConflictError(
                    "the predecessor is absent, inactive, or belongs to another policy",
                    remedy="name the current ACTIVE policy hash; policy succession is explicit",
                    detail={"policy_id": policy.policy_id,
                            "predecessor_hash": policy.predecessor_hash},
                )
        elif active_same:
            # Exact idempotent replay is allowed; divergent parallel ACTIVE
            # policies are not.
            canonical = policy.to_canonical()
            for row in active_same:
                if self.store.get_object(row["content_hash"]) == canonical:
                    return str(row["content_hash"])
            raise ConflictError(
                f"policy {policy.policy_id!r} already has an ACTIVE version",
                remedy="create a successor that names predecessor_hash",
                detail={"active": [row["content_hash"] for row in active_same]},
            )
        digest = self.store.put_object(
            policy.to_canonical(), object_type="RetentionPolicyRecord",
            created_by=policy.created_by, legal_hold=True,
        )
        if policy.predecessor_hash:
            self.store.set_object_status(
                policy.predecessor_hash, ObjectStatus.SUPERSEDED,
                reason=f"superseded by retention policy {digest}",
            )
        self.store.append_audit({
            "event": "retention.policy.registered",
            "policy_id": policy.policy_id,
            "policy_version": policy.version,
            "policy_hash": digest,
            "predecessor_hash": policy.predecessor_hash,
            "authority": named_authority,
        })
        return digest

    def _policy(self, digest: str) -> RetentionPolicy:
        try:
            metadata = self.store.objects.content_metadata(str(digest))
        except NotFoundError:
            raise NotFoundError(f"no retention policy exists at {digest}") from None
        if metadata.object_type != "RetentionPolicyRecord":
            raise UsageError(f"object {digest} is not a RetentionPolicyRecord")
        if metadata.status != ObjectStatus.ACTIVE:
            raise ConflictError(
                f"retention policy {digest} is {metadata.status}, not ACTIVE",
                remedy="select the current ACTIVE successor policy",
            )
        return RetentionPolicy.from_canonical(self.store.get_object(str(digest)))

    def evaluate(
        self,
        policy_hash: str,
        *,
        as_of: str,
        limit: int = 100,
        after_hash: str = "",
    ) -> Dict[str, Any]:
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 1000:
            raise UsageError("retention limit must be an integer from 1 through 1000")
        observed = _instant(as_of, "retention evaluation time")
        policy = self._policy(policy_hash)
        effective = _instant(policy.effective_at, "retention policy effective_at")
        digests = [
            digest for digest in self.store.objects.list_digests()
            if not after_hash or digest > after_hash
        ]
        decisions: List[RetentionDecision] = []
        for digest in digests:
            metadata = self.store.objects.content_metadata(digest)
            if metadata.object_type not in policy.object_types:
                continue
            if len(decisions) >= limit:
                break
            try:
                age = _age_seconds(metadata.created_at, as_of)
            except UsageError as error:
                decisions.append(RetentionDecision(
                    digest, metadata.object_type, metadata.created_at, metadata.status,
                    bool(metadata.legal_hold), -1, "REFUSED_INVALID_METADATA", str(error),
                ))
                continue
            decision, reason = "ELIGIBLE", "the object satisfies the active policy"
            if not policy.enabled:
                decision, reason = "SKIP_DISABLED", "the policy is disabled"
            elif observed < effective:
                decision, reason = "SKIP_NOT_EFFECTIVE", "the policy is not effective yet"
            elif age < 0:
                decision, reason = (
                    "REFUSED_CLOCK_SKEW", "object creation time is after evaluation time"
                )
            elif metadata.status not in policy.eligible_statuses:
                decision, reason = (
                    "SKIP_STATUS", f"status {metadata.status} is not eligible"
                )
            elif policy.action == RetentionAction.MARK_EXPIRED \
                    and metadata.status == ObjectStatus.EXPIRED:
                decision, reason = "SKIP_ALREADY_APPLIED", "object is already EXPIRED"
            elif age < policy.minimum_age_seconds:
                decision, reason = (
                    "SKIP_TOO_YOUNG",
                    f"age {age}s is below {policy.minimum_age_seconds}s",
                )
            elif policy.action in RetentionAction.REMOVES_CONTENT and metadata.legal_hold:
                decision, reason = (
                    "SKIP_LEGAL_HOLD",
                    "17.5 forbids deletion or erasure while legal hold is active",
                )
            decisions.append(RetentionDecision(
                digest, metadata.object_type, metadata.created_at, metadata.status,
                bool(metadata.legal_hold), age, decision, reason,
            ))
        # If the loop stopped because the batch filled, continue after the
        # last decision. A skipped nonmatching digest never becomes a cursor.
        has_more = False
        if decisions:
            cursor = decisions[-1].content_hash
            for digest in digests:
                if digest <= cursor:
                    continue
                metadata = self.store.objects.content_metadata(digest)
                if metadata.object_type in policy.object_types:
                    has_more = True
                    break
        else:
            cursor = after_hash
        return {
            "record_type": "RetentionEvaluationRecord",
            "policy_hash": policy_hash,
            "policy_id": policy.policy_id,
            "policy_version": policy.version,
            "action": policy.action,
            "as_of": as_of,
            "limit": limit,
            "after_hash": after_hash,
            "next_after_hash": cursor,
            "has_more": has_more,
            "decisions": [decision.to_canonical() for decision in decisions],
        }

    def run(
        self,
        policy_hash: str,
        *,
        authority: str,
        actor: str = "",
        dry_run: bool,
        as_of: Optional[str] = None,
        limit: int = 100,
        after_hash: str = "",
    ) -> Dict[str, Any]:
        named_authority = str(authority).strip()
        if not named_authority:
            raise UsageError("a retention run requires a named authority")
        authenticated_actor = str(actor).strip() or named_authority
        observed_at = str(as_of or utc_now())
        evaluation = self.evaluate(
            policy_hash, as_of=observed_at, limit=limit, after_hash=after_hash
        )
        policy = self._policy(policy_hash)
        decisions: List[Dict[str, Any]] = []
        for original in evaluation["decisions"]:
            decision = dict(original)
            if dry_run or decision["decision"] != "ELIGIBLE":
                decisions.append(decision)
                continue
            digest = str(decision["content_hash"])
            try:
                current = self.store.objects.content_metadata(digest)
                if current.status != decision["status_before"]:
                    decision.update({
                        "decision": "REFUSED_CONCURRENT_CHANGE",
                        "reason": (
                            f"status changed from {decision['status_before']} to "
                            f"{current.status} after evaluation"
                        ),
                        "status_after": current.status,
                    })
                elif evaluation["action"] in RetentionAction.REMOVES_CONTENT \
                        and current.legal_hold:
                    decision.update({
                        "decision": "SKIP_LEGAL_HOLD",
                        "reason": "a legal hold was present at the removal boundary",
                        "status_after": current.status,
                    })
                elif evaluation["action"] == RetentionAction.MARK_EXPIRED:
                    self.store.set_object_status(
                        digest, ObjectStatus.EXPIRED,
                        reason=f"retention policy {policy_hash}: {evaluation['policy_id']}",
                    )
                    decision.update({"decision": "APPLIED", "status_after": ObjectStatus.EXPIRED})
                else:
                    self.store.redact(
                        digest,
                        reason=(
                            f"retention policy {evaluation['policy_id']}@"
                            f"{evaluation['policy_version']}: "
                            f"{policy.reason}"
                        ),
                        authority=named_authority,
                        permitted_disclosure=policy.permitted_disclosure,
                    )
                    target = (
                        ObjectStatus.LEGALLY_DELETED
                        if evaluation["action"] == RetentionAction.LEGALLY_DELETE
                        else ObjectStatus.REDACTED
                    )
                    if target == ObjectStatus.LEGALLY_DELETED:
                        self.store.set_object_status(
                            digest, target,
                            reason=f"retention policy {policy_hash}",
                        )
                    decision.update({"decision": "APPLIED", "status_after": target})
            except ConflictError as error:
                # Most commonly a hold won after evaluation. The destructive
                # primitive is the final authority and remains fail closed.
                decision.update({
                    "decision": "SKIP_LEGAL_HOLD",
                    "reason": str(error),
                    "status_after": decision["status_before"],
                })
            except NotFoundError as error:
                decision.update({
                    "decision": "REFUSED_CONCURRENT_CHANGE",
                    "reason": str(error),
                    "status_after": ObjectStatus.UNAVAILABLE,
                })
            except ServerError as error:
                # A typed storage or integrity failure is evidence about this
                # target, not permission to lose the already-applied prefix
                # of the batch without a run record.
                decision.update({
                    "decision": "REFUSED_BACKEND_FAILURE",
                    "reason": f"{error.category}: {error}",
                    "status_after": decision["status_before"],
                })
            decisions.append(decision)
        counts: Dict[str, int] = {}
        for decision in decisions:
            key = str(decision["decision"])
            counts[key] = counts.get(key, 0) + 1
        run_record = {
            "record_type": "RetentionRunRecord",
            "policy_hash": policy_hash,
            "policy_id": evaluation["policy_id"],
            "policy_version": evaluation["policy_version"],
            "action": evaluation["action"],
            "mode": "DRY_RUN" if dry_run else "ENFORCE",
            "as_of": observed_at,
            "actor": authenticated_actor,
            "authority": named_authority,
            "limit": limit,
            "after_hash": after_hash,
            "next_after_hash": evaluation["next_after_hash"],
            "has_more": bool(evaluation["has_more"]),
            "counts": dict(sorted(counts.items())),
            "decisions": decisions,
        }
        run_hash = self.store.put_object(
            run_record, object_type="RetentionRunRecord",
            created_by=authenticated_actor, legal_hold=True,
        )
        self.store.append_audit({
            "event": "retention.run.completed",
            "run_hash": run_hash,
            "policy_hash": policy_hash,
            "policy_id": evaluation["policy_id"],
            "mode": run_record["mode"],
            "actor": authenticated_actor,
            "authority": named_authority,
            "counts": run_record["counts"],
            "next_after_hash": run_record["next_after_hash"],
            "has_more": run_record["has_more"],
        })
        return {"run_hash": run_hash, "run": run_record}


def retention_engine_for_store(store: Any) -> RetentionEngine:
    """Return one engine over either shipped application-store vocabulary.

    The standalone server historically holds ``CaseStore`` directly, while
    the enterprise profile holds ``ApplicationStore``.  They are two
    deployments of the same 42.1 model.  Adapt the first through the same
    reviewed backend facade rather than maintaining a second retention path.
    The wrapper is intentionally retained by the engine for the request/run
    lifetime and is never closed independently of the server-owned store.
    """
    if all(hasattr(store, name) for name in ("objects", "metadata", "put_object")):
        return RetentionEngine(store)
    from .store import CaseStore
    if isinstance(store, CaseStore):
        from .backends.facade import ApplicationStore
        from .backends.local import SqliteFilesystemBackend
        tenant = str(getattr(store, "tenant_id", "") or "")
        return RetentionEngine(ApplicationStore(
            SqliteFilesystemBackend(store=store), root_label=str(store.root),
            tenant_id=tenant,
        ))
    raise TypeError("the server store cannot be adapted to the retention interface")
