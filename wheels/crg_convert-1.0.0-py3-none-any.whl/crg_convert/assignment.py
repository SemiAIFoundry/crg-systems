"""Exact combinatorial optimizers for ownership conversion.

Normative basis: master specification 31.2 (primary optimization).  The
equal-capacity one-to-one case is the maximum-weight bipartite assignment

    max_pi  sum_i w_{i,pi(i)},

solved here by Kuhn-Munkres / Jonker-Volgenant over exact rationals.  The
generalized cases named by 31.2 -- min-cost flow, capacitated matching,
``b``-matching, replicated ownership, reconstruction sources, failed-device
exclusions, heterogeneous capacities, partial availability -- are served by
the transportation solver in this module.

Every number handled here is a :class:`crg_model.numeric.Exact` rational.
Binary floating point is refused at the boundary and never constructed
internally: this module's output is a certificate input (spec 14.2, 22.2),
and near-ties are exactly the cases a float implementation resolves
wrongly and silently.

Each optimum is returned with an independently checkable witness.  For the
assignment problem the witness is the linear-programming dual potential
pair ``(u, v)`` satisfying ``u_i + v_j >= w_ij`` everywhere with equality on
every matched pair; recomputing that pair certifies optimality without
re-running the solver (spec 31.5, "exact assignment witnesses are
independently checkable").
"""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from typing import Dict, List, Mapping, Optional, Sequence, Tuple

from crg_model.numeric import Exact

__all__ = [
    "ConversionError",
    "SolverFailure",
    "AssignmentSolution",
    "FlowSolution",
    "max_retention_assignment",
    "solve_max_assignment",
    "solve_min_assignment",
    "verify_assignment",
    "assignment_value",
    "min_cost_flow",
    "min_cost_flow_arcs",
    "b_matching",
]


class ConversionError(Exception):
    """Base class for refusals raised by crg-convert.

    Specification 6.6: the module fails closed.  A refusal is always
    distinguishable from a proven infeasibility.
    """


class SolverFailure(ConversionError):
    """A solver did not reach an optimum.

    Specification 31.5: "tool failure does not become infeasibility".  This
    exception is raised instead of returning an infeasible verdict, so a
    caller can never read an exhausted iteration budget as a proof that no
    conversion exists.
    """


# ----------------------------------------------------------------------
# exact boundary
# ----------------------------------------------------------------------

def _frac(value) -> Fraction:
    """Coerce an admissible exact input to :class:`fractions.Fraction`."""
    if isinstance(value, Exact):
        return value.value
    if isinstance(value, Fraction):
        return value
    if isinstance(value, bool):  # bool is an int subclass; refuse it explicitly
        raise TypeError("bool is not an admissible weight")
    if isinstance(value, int):
        return Fraction(value)
    if isinstance(value, str):
        return Fraction(value)
    if isinstance(value, float):
        raise TypeError(
            "float is not admissible in an assignment that authorizes a "
            "conversion record; supply Exact, Fraction, int, or a rational string"
        )
    raise TypeError(f"cannot interpret {type(value)!r} as an exact weight")


def _matrix(weights) -> List[List[Fraction]]:
    rows = [list(row) for row in weights]
    if not rows:
        return []
    width = len(rows[0])
    for row in rows:
        if len(row) != width:
            raise ValueError("weight matrix rows must all have the same length")
    return [[_frac(v) for v in row] for row in rows]


# ----------------------------------------------------------------------
# maximum-weight assignment
# ----------------------------------------------------------------------

@dataclass(frozen=True)
class AssignmentSolution:
    """An optimal assignment together with its dual optimality witness.

    ``assignment`` maps source index to target index and omits the padding
    pairs introduced to square a rectangular instance.  ``potentials`` are
    the dual variables of the padded problem, in max-weight orientation.
    """

    assignment: Dict[int, int]
    value: Exact
    rows: int
    columns: int
    padded_size: int
    row_potentials: Tuple[Exact, ...]
    column_potentials: Tuple[Exact, ...]
    sense: str = "MAXIMIZE"

    @property
    def is_permutation(self) -> bool:
        return self.rows == self.columns and len(self.assignment) == self.rows

    def to_canonical(self) -> dict:
        return {
            "sense": self.sense,
            "rows": self.rows,
            "columns": self.columns,
            "padded_size": self.padded_size,
            "assignment": [[i, self.assignment[i]] for i in sorted(self.assignment)],
            "value": self.value.to_canonical(),
            "row_potentials": [p.to_canonical() for p in self.row_potentials],
            "column_potentials": [p.to_canonical() for p in self.column_potentials],
        }


def _hungarian_min(cost: List[List[Fraction]]) -> Tuple[List[int], List[Fraction], List[Fraction]]:
    """Jonker-Volgenant minimum-cost perfect assignment on a square matrix.

    Returns ``(match, u, v)`` where ``match[j]`` is the row assigned to
    column ``j`` and the potentials satisfy ``u_i + v_j <= cost_ij`` with
    equality on matched pairs.  Comparisons are strict ``<``, so ties
    resolve to the lowest index and the result is deterministic.
    """
    n = len(cost)
    if n == 0:
        return [], [], []
    zero = Fraction(0)
    u = [zero] * (n + 1)
    v = [zero] * (n + 1)
    p = [0] * (n + 1)   # p[j] = row matched to column j (1-based; 0 = free)
    way = [0] * (n + 1)
    for i in range(1, n + 1):
        p[0] = i
        j0 = 0
        minv: List[Optional[Fraction]] = [None] * (n + 1)
        used = [False] * (n + 1)
        while True:
            used[j0] = True
            i0 = p[j0]
            delta: Optional[Fraction] = None
            j1 = -1
            for j in range(1, n + 1):
                if used[j]:
                    continue
                cur = cost[i0 - 1][j - 1] - u[i0] - v[j]
                if minv[j] is None or cur < minv[j]:
                    minv[j] = cur
                    way[j] = j0
                if delta is None or minv[j] < delta:
                    delta = minv[j]
                    j1 = j
            if delta is None:
                raise SolverFailure("assignment search exhausted before a free column was reached")
            for j in range(n + 1):
                if used[j]:
                    u[p[j]] += delta
                    v[j] -= delta
                else:
                    minv[j] = minv[j] - delta  # type: ignore[operator]
            j0 = j1
            if p[j0] == 0:
                break
        while j0:
            j1 = way[j0]
            p[j0] = p[j1]
            j0 = j1
    return p, u, v


def solve_max_assignment(weights) -> AssignmentSolution:
    """Maximum-weight bipartite assignment over exact rationals (spec 31.2).

    Rectangular instances are squared with zero-weight padding, which is the
    correct relaxation when the two ownership cell sets differ in size: an
    unmatched target cell retains nothing.  Padding pairs are stripped from
    the returned assignment.
    """
    w = _matrix(weights)
    rows = len(w)
    cols = len(w[0]) if rows else 0
    if rows == 0 or cols == 0:
        return AssignmentSolution({}, Exact(0), rows, cols, 0, (), ())
    n = max(rows, cols)
    zero = Fraction(0)
    padded = [
        [w[i][j] if i < rows and j < cols else zero for j in range(n)]
        for i in range(n)
    ]
    cost = [[-value for value in row] for row in padded]
    match, u, v = _hungarian_min(cost)

    assignment: Dict[int, int] = {}
    total = zero
    for j in range(1, n + 1):
        i = match[j] - 1
        col = j - 1
        if i < rows and col < cols:
            assignment[i] = col
            total += w[i][col]
    # min-cost potentials u_i + v_j <= -w_ij  =>  (-u_i) + (-v_j) >= w_ij
    row_pot = tuple(Exact(-u[i + 1]) for i in range(n))
    col_pot = tuple(Exact(-v[j + 1]) for j in range(n))
    solution = AssignmentSolution(
        assignment=assignment,
        value=Exact(total),
        rows=rows,
        columns=cols,
        padded_size=n,
        row_potentials=row_pot,
        column_potentials=col_pot,
    )
    if not verify_assignment(weights, solution):
        raise SolverFailure(
            "assignment solver produced a solution whose dual witness does not certify optimality"
        )
    return solution


def solve_min_assignment(costs) -> AssignmentSolution:
    """Minimum-cost assignment; used for the secondary objective (spec 31.3)."""
    c = _matrix(costs)
    negated = [[-value for value in row] for row in c]
    maximal = solve_max_assignment(negated)
    return AssignmentSolution(
        assignment=maximal.assignment,
        value=Exact(-maximal.value.value),
        rows=maximal.rows,
        columns=maximal.columns,
        padded_size=maximal.padded_size,
        row_potentials=tuple(Exact(-p.value) for p in maximal.row_potentials),
        column_potentials=tuple(Exact(-p.value) for p in maximal.column_potentials),
        sense="MINIMIZE",
    )


def max_retention_assignment(weights) -> Tuple[Dict[int, int], Exact]:
    """Return ``(assignment, retained)`` for the primary optimum of 31.2.

    ``weights[i][j]`` is the represented data retained when source device
    ``i`` assumes target ownership ``j``.  The returned retention is the
    exact rational ``r* = max_pi sum_i w_{i,pi(i)}``.
    """
    solution = solve_max_assignment(weights)
    return solution.assignment, solution.value


def assignment_value(weights, assignment: Mapping[int, int]) -> Exact:
    """Exact objective value of a stated assignment (no optimization)."""
    w = _matrix(weights)
    total = Fraction(0)
    seen_targets = set()
    for i, j in assignment.items():
        if not (0 <= i < len(w)) or not (0 <= j < len(w[0])):
            raise ValueError(f"assignment pair ({i}, {j}) is outside the weight matrix")
        if j in seen_targets:
            raise ValueError(f"target {j} is claimed by more than one source")
        seen_targets.add(j)
        total += w[i][j]
    return Exact(total)


def verify_assignment(weights, solution: AssignmentSolution) -> bool:
    """Independently check the dual witness of an assignment optimum.

    Specification 31.5.  The check is complementary slackness on the padded
    problem: dual feasibility ``u_i + v_j >= w_ij`` for every pair, equality
    on every matched pair, and ``sum u + sum v == value``.  It never calls
    the solver, so it is a genuine second opinion.
    """
    w = _matrix(weights)
    rows, cols, n = solution.rows, solution.columns, solution.padded_size
    if rows == 0 or cols == 0:
        return solution.value == Exact(0) and not solution.assignment
    if len(solution.row_potentials) != n or len(solution.column_potentials) != n:
        return False
    sign = -1 if solution.sense == "MINIMIZE" else 1
    u = [p.value * sign for p in solution.row_potentials]
    v = [p.value * sign for p in solution.column_potentials]
    zero = Fraction(0)

    def weight(i: int, j: int) -> Fraction:
        if i < rows and j < cols:
            return w[i][j] * sign
        return zero

    for i in range(n):
        for j in range(n):
            if u[i] + v[j] < weight(i, j):
                return False
    targets = set()
    for i, j in solution.assignment.items():
        if j in targets:
            return False
        targets.add(j)
        if u[i] + v[j] != weight(i, j):
            return False
    if sum(u) + sum(v) != solution.value.value * sign:
        return False
    return True


# ----------------------------------------------------------------------
# transportation / min-cost flow (spec 31.2 generalized cases)
# ----------------------------------------------------------------------

@dataclass(frozen=True)
class FlowSolution:
    """An exact minimum-cost transportation plan.

    ``feasible`` is a proven verdict, never a solver timeout: an exhausted
    budget raises :class:`SolverFailure` instead (spec 31.5).
    """

    flow: Dict[Tuple[int, int], Exact]
    cost: Exact
    shipped: Exact
    feasible: bool
    unmet_demand: Tuple[Exact, ...] = ()
    reason: Optional[str] = None

    def arcs(self) -> List[Tuple[int, int, Exact]]:
        return [(i, j, self.flow[(i, j)]) for (i, j) in sorted(self.flow)]

    def to_canonical(self) -> dict:
        record = {
            "feasible": self.feasible,
            "cost": self.cost.to_canonical(),
            "shipped": self.shipped.to_canonical(),
            "flow": [
                {"source": i, "target": j, "amount": self.flow[(i, j)].to_canonical()}
                for (i, j) in sorted(self.flow)
            ],
        }
        if self.reason:
            record["reason"] = self.reason
        return record


@dataclass
class _Arc:
    to: int
    capacity: Optional[Fraction]
    cost: Fraction
    flow: Fraction = Fraction(0)
    partner: int = 0
    tag: Optional[Tuple[int, int, int]] = None


def min_cost_flow_arcs(
    arcs: Sequence[Tuple[int, int, Optional[object], object]],
    supplies: Sequence,
    demands: Sequence,
    *,
    max_iterations: Optional[int] = None,
) -> FlowSolution:
    """Exact bipartite transportation problem stated as an explicit arc list.

    ``arcs`` are ``(source, target, capacity, cost)`` tuples; ``capacity``
    may be ``None`` for an uncapacitated arc, and parallel arcs between the
    same pair are permitted (that is how a piecewise cost -- retain in place
    at zero cost up to the overlap, then move -- is expressed).

    Solved by successive shortest paths with Bellman-Ford over exact
    rationals.  The underlying graph is acyclic, so no negative cycle can
    exist and the augmenting sequence is well defined.
    """
    n = len(supplies)
    m = len(demands)
    sup = [_frac(s) for s in supplies]
    dem = [_frac(d) for d in demands]
    if any(s < 0 for s in sup) or any(d < 0 for d in dem):
        raise ValueError("supplies and demands must be nonnegative")

    total_demand = sum(dem, Fraction(0))
    total_supply = sum(sup, Fraction(0))

    # node 0 = super source, 1..n = sources, n+1..n+m = targets, last = sink
    source_node = 0
    sink_node = n + m + 1
    graph: List[List[_Arc]] = [[] for _ in range(n + m + 2)]

    def add(u: int, v: int, capacity: Optional[Fraction], cost: Fraction,
            tag: Optional[Tuple[int, int, int]] = None) -> None:
        forward = _Arc(v, capacity, cost, Fraction(0), len(graph[v]), tag)
        backward = _Arc(u, Fraction(0), -cost, Fraction(0), len(graph[u]), None)
        graph[u].append(forward)
        graph[v].append(backward)

    for i, s in enumerate(sup):
        add(source_node, 1 + i, s, Fraction(0))
    for j, d in enumerate(dem):
        add(n + 1 + j, sink_node, d, Fraction(0))
    for index, (i, j, capacity, cost) in enumerate(arcs):
        if not (0 <= i < n) or not (0 <= j < m):
            raise ValueError(f"arc ({i}, {j}) is outside the supply/demand index range")
        cap = None if capacity is None else _frac(capacity)
        if cap is not None and cap < 0:
            raise ValueError("arc capacity must be nonnegative")
        add(1 + i, n + 1 + j, cap, _frac(cost), (i, j, index))

    budget = max_iterations if max_iterations is not None else 4 * (len(arcs) + n + m) + 16
    remaining = total_demand
    total_cost = Fraction(0)
    iterations = 0

    while remaining > 0:
        iterations += 1
        if iterations > budget:
            raise SolverFailure(
                "min-cost flow exceeded its augmentation budget; this is a solver "
                "failure and MUST NOT be reported as infeasibility (spec 31.5)"
            )
        # Bellman-Ford over the residual graph.
        dist: List[Optional[Fraction]] = [None] * len(graph)
        dist[source_node] = Fraction(0)
        prev_node = [-1] * len(graph)
        prev_arc = [-1] * len(graph)
        for _ in range(len(graph)):
            changed = False
            for u in range(len(graph)):
                if dist[u] is None:
                    continue
                for idx, arc in enumerate(graph[u]):
                    residual = None if arc.capacity is None else arc.capacity - arc.flow
                    if residual is not None and residual <= 0:
                        continue
                    candidate = dist[u] + arc.cost
                    if dist[arc.to] is None or candidate < dist[arc.to]:
                        dist[arc.to] = candidate
                        prev_node[arc.to] = u
                        prev_arc[arc.to] = idx
                        changed = True
            if not changed:
                break
        else:
            raise SolverFailure("residual graph did not settle; negative cycle suspected")
        if dist[sink_node] is None:
            break  # no augmenting path: demand cannot be met

        bottleneck: Optional[Fraction] = remaining
        node = sink_node
        while node != source_node:
            arc = graph[prev_node[node]][prev_arc[node]]
            if arc.capacity is not None:
                residual = arc.capacity - arc.flow
                if bottleneck is None or residual < bottleneck:
                    bottleneck = residual
            node = prev_node[node]
        if bottleneck is None or bottleneck <= 0:
            raise SolverFailure("augmenting path with nonpositive residual capacity")

        node = sink_node
        while node != source_node:
            u = prev_node[node]
            arc = graph[u][prev_arc[node]]
            arc.flow += bottleneck
            graph[node][arc.partner].flow -= bottleneck
            total_cost += arc.cost * bottleneck
            node = u
        remaining -= bottleneck

    flow: Dict[Tuple[int, int], Fraction] = {}
    for u in range(1, n + 1):
        for arc in graph[u]:
            if arc.tag is None or arc.flow <= 0:
                continue
            i, j, _ = arc.tag
            flow[(i, j)] = flow.get((i, j), Fraction(0)) + arc.flow

    shipped = total_demand - remaining
    feasible = remaining == 0
    unmet: Tuple[Exact, ...] = ()
    reason = None
    if not feasible:
        served = [Fraction(0)] * m
        for (i, j), value in flow.items():
            served[j] += value
        unmet = tuple(Exact(dem[j] - served[j]) for j in range(m))
        reason = (
            "PROVEN_INFEASIBLE_SUPPLY_SHORTFALL"
            if total_supply < total_demand
            else "PROVEN_INFEASIBLE_ARC_CAPACITY"
        )
    return FlowSolution(
        flow={k: Exact(v) for k, v in flow.items()},
        cost=Exact(total_cost),
        shipped=Exact(shipped),
        feasible=feasible,
        unmet_demand=unmet,
        reason=reason,
    )


def min_cost_flow(
    costs,
    supplies: Sequence,
    demands: Sequence,
    *,
    capacities=None,
    maximize: bool = False,
) -> FlowSolution:
    """Exact min-cost (or max-value) transportation problem (spec 31.2).

    This is the generalized-case solver: heterogeneous capacities, partial
    availability, failed-device exclusion (drop the row or set its supply to
    zero), reconstruction sources (an extra row), and replicated or
    divisible ownership all reduce to it.  ``demands`` must be met exactly,
    which is how "target coverage is complete" (31.5) is enforced.
    """
    c = _matrix(costs)
    arcs: List[Tuple[int, int, Optional[object], object]] = []
    for i, row in enumerate(c):
        for j, value in enumerate(row):
            cap = None
            if capacities is not None:
                cap = capacities[i][j]
                if cap is None:
                    pass
                elif _frac(cap) == 0:
                    continue
            arcs.append((i, j, cap, -value if maximize else value))
    solution = min_cost_flow_arcs(arcs, supplies, demands)
    if maximize:
        return FlowSolution(
            flow=solution.flow,
            cost=Exact(-solution.cost.value),
            shipped=solution.shipped,
            feasible=solution.feasible,
            unmet_demand=solution.unmet_demand,
            reason=solution.reason,
        )
    return solution


def b_matching(
    weights,
    source_degrees: Sequence[int],
    target_degrees: Sequence[int],
    *,
    multiplicity: int = 1,
) -> Tuple[List[Tuple[int, int, int]], Exact]:
    """Maximum-weight degree-constrained bipartite ``b``-matching (spec 31.2).

    Source device ``i`` may assume at most ``source_degrees[i]`` target
    ownerships; target cell ``j`` must receive exactly ``target_degrees[j]``
    owners, which expresses replicated ownership.  ``multiplicity`` bounds
    how many times one pair may be selected (``1`` for a simple b-matching).

    Returns ``([(source, target, multiplicity)], total_weight)``.  All data
    are integral, so the transportation optimum is integral and no rounding
    step exists to introduce error.
    """
    w = _matrix(weights)
    rows = len(w)
    cols = len(w[0]) if rows else 0
    if len(source_degrees) != rows or len(target_degrees) != cols:
        raise ValueError("degree sequences must match the weight matrix shape")
    if any(int(d) != d or d < 0 for d in list(source_degrees) + list(target_degrees)):
        raise ValueError("degree bounds must be nonnegative integers")
    caps = [[Fraction(multiplicity)] * cols for _ in range(rows)]
    solution = min_cost_flow(
        [[Exact(v) for v in row] for row in w],
        [Fraction(int(d)) for d in source_degrees],
        [Fraction(int(d)) for d in target_degrees],
        capacities=caps,
        maximize=True,
    )
    if not solution.feasible:
        raise ConversionError(
            f"no b-matching meets the declared target degrees ({solution.reason})"
        )
    edges: List[Tuple[int, int, int]] = []
    for (i, j) in sorted(solution.flow):
        amount = solution.flow[(i, j)].value
        if amount == 0:
            continue
        if amount.denominator != 1:
            raise SolverFailure("b-matching produced a fractional selection")
        edges.append((i, j, int(amount)))
    return edges, solution.cost
