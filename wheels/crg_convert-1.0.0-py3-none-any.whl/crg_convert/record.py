"""The conversion record and its constituent objects.

Normative basis: master specification 31.4 (output) and 31.5 (required
invariants).  Section 31.4 enumerates fifteen mandatory items; each is a
field of :class:`ConversionRecord` and each is canonically encodable, so a
conversion record hashes like any other CRG object (spec 14.3, 14.4).

The record is self-checking.  :meth:`ConversionRecord.check_invariants`
recomputes every invariant of 31.5 from the record's own contents -- it
does not consult the solver -- which is what makes the record verifiable
by a party that did not run the conversion.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

from crg_model.canonical import content_hash
from crg_model.numeric import ArithmeticProfile, Exact

__all__ = [
    "OwnershipContract",
    "SolverMethod",
    "LogicalSpace",
    "Cell",
    "RetainedIntersection",
    "ResidualRegion",
    "RouteStep",
    "ScheduleWave",
    "BufferingPlan",
    "DuplicationPolicy",
    "CompletionCheck",
    "SolverEvidence",
    "SecondaryReport",
    "ConversionRecord",
    "VERIFICATION_PROGRAM",
]


class OwnershipContract:
    """Declared ownership semantics of a conversion (spec 31.2).

    ``EXCLUSIVE_ONE_TO_ONE`` is the contract of the aligned-layout law: one
    owner per target cell, one target cell per device, equal capacity.
    ``DIVISIBLE`` permits a target cell's elements to be split across
    owners, which is the only way a heterogeneous-capacity instance stays
    exactly solvable; it is a different contract and is named as such.
    """

    EXCLUSIVE_ONE_TO_ONE = "EXCLUSIVE_ONE_TO_ONE"
    DIVISIBLE = "DIVISIBLE"
    REPLICATED = "REPLICATED"


class SolverMethod:
    EXACT_ASSIGNMENT = "EXACT_ASSIGNMENT_KUHN_MUNKRES"
    MIN_COST_FLOW = "MIN_COST_FLOW"
    B_MATCHING = "B_MATCHING"


#: The checks an independent party must run against a conversion record
#: (spec 31.4 "verification program", 31.5 required invariants).
VERIFICATION_PROGRAM: Tuple[str, ...] = (
    "IDENTITY_LAYOUT_MOVES_ZERO",
    "TARGET_COVERAGE_COMPLETE",
    "SOURCE_MASS_CONSERVED",
    "NO_UNDECLARED_DUPLICATION",
    "ASSIGNMENT_IS_ONE_TO_ONE",
    "RETAINED_PLUS_MOVED_EQUALS_TOTAL",
    "RETENTION_MATCHES_ASSIGNMENT_WITNESS",
    "SECONDARY_PRESERVES_PRIMARY_OPTIMUM",
    "ARITHMETIC_IS_EXACT_RATIONAL",
)


@dataclass(frozen=True)
class LogicalSpace:
    """A normalized logical space (spec 31.4 "source and target logical spaces").

    The space is the unit box over its declared axes; total measure is 1 by
    construction, so retained and moved fractions are directly comparable
    across layouts.  ``total_elements`` and ``bytes_per_element``, when
    declared, turn measures into the element and byte counts 31.4 requires.
    """

    identifier: str
    axes: Tuple[str, ...]
    total_elements: Optional[int] = None
    bytes_per_element: Optional[int] = None

    def __post_init__(self) -> None:
        if not self.axes:
            raise ValueError("a logical space must declare at least one axis")
        if len(set(self.axes)) != len(self.axes):
            raise ValueError("duplicate axis names in logical space")
        for name, value in (("total_elements", self.total_elements),
                            ("bytes_per_element", self.bytes_per_element)):
            if value is not None and (not isinstance(value, int) or value < 0):
                raise ValueError(f"{name} must be a nonnegative integer or None")

    @property
    def dimension(self) -> int:
        return len(self.axes)

    def elements_in(self, measure: Exact) -> Optional[Exact]:
        if self.total_elements is None:
            return None
        return measure * Exact(self.total_elements)

    def bytes_in(self, measure: Exact) -> Optional[Exact]:
        if self.total_elements is None or self.bytes_per_element is None:
            return None
        return measure * Exact(self.total_elements * self.bytes_per_element)

    def to_canonical(self) -> dict:
        record = {"identifier": self.identifier, "axes": list(self.axes)}
        if self.total_elements is not None:
            record["total_elements"] = self.total_elements
        if self.bytes_per_element is not None:
            record["bytes_per_element"] = self.bytes_per_element
        return record


@dataclass(frozen=True)
class Cell:
    """One ownership cell: an axis-aligned box of the normalized space.

    ``box`` is a tuple of ``(lo, hi)`` exact rational bounds, one per axis.
    """

    index: int
    box: Tuple[Tuple[Exact, Exact], ...]
    owner: Optional[str] = None

    @property
    def measure(self) -> Exact:
        total = Exact(1)
        for lo, hi in self.box:
            total = total * (hi - lo)
        return total

    def intersection_measure(self, other: "Cell") -> Exact:
        """Exact rational area of ``self ∩ other`` (zero if disjoint)."""
        if len(self.box) != len(other.box):
            raise ValueError("cells live in spaces of different dimension")
        total = Exact(1)
        for (a_lo, a_hi), (b_lo, b_hi) in zip(self.box, other.box):
            lo = a_lo if a_lo > b_lo else b_lo
            hi = a_hi if a_hi < b_hi else b_hi
            if not (hi > lo):
                return Exact(0)
            total = total * (hi - lo)
        return total

    def to_canonical(self) -> dict:
        record = {
            "index": self.index,
            "box": [[lo.to_canonical(), hi.to_canonical()] for lo, hi in self.box],
            "measure": self.measure.to_canonical(),
        }
        if self.owner:
            record["owner"] = self.owner
        return record


@dataclass(frozen=True)
class RetainedIntersection:
    """Data that keeps its owner: ``S_i ∩ T_j`` for an assigned pair."""

    source_cell: int
    target_cell: int
    measure: Exact
    elements: Optional[Exact] = None
    bytes_: Optional[Exact] = None

    def to_canonical(self) -> dict:
        record = {
            "source_cell": self.source_cell,
            "target_cell": self.target_cell,
            "measure": self.measure.to_canonical(),
        }
        if self.elements is not None:
            record["elements"] = self.elements.to_canonical()
        if self.bytes_ is not None:
            record["bytes"] = self.bytes_.to_canonical()
        return record


@dataclass(frozen=True)
class ResidualRegion:
    """A target remainder: ``S_k ∩ T_j`` for the source ``k`` that owns it.

    Every element of the residual has exactly one source owner, so the
    residual regions of a target cell partition that cell's remainder and
    nothing is transferred twice (spec 31.5).
    """

    target_cell: int
    from_source_cell: int
    to_source_cell: int
    measure: Exact
    elements: Optional[Exact] = None
    bytes_: Optional[Exact] = None

    def to_canonical(self) -> dict:
        record = {
            "target_cell": self.target_cell,
            "from_source_cell": self.from_source_cell,
            "to_source_cell": self.to_source_cell,
            "measure": self.measure.to_canonical(),
        }
        if self.elements is not None:
            record["elements"] = self.elements.to_canonical()
        if self.bytes_ is not None:
            record["bytes"] = self.bytes_.to_canonical()
        return record


@dataclass(frozen=True)
class RouteStep:
    """One movement on the transition plan (spec 31.4 "route and schedule")."""

    step_id: str
    origin: int
    destination: int
    target_cell: int
    measure: Exact
    wave: int
    elements: Optional[Exact] = None
    bytes_: Optional[Exact] = None

    def to_canonical(self) -> dict:
        record = {
            "step_id": self.step_id,
            "origin": self.origin,
            "destination": self.destination,
            "target_cell": self.target_cell,
            "measure": self.measure.to_canonical(),
            "wave": self.wave,
        }
        if self.elements is not None:
            record["elements"] = self.elements.to_canonical()
        if self.bytes_ is not None:
            record["bytes"] = self.bytes_.to_canonical()
        return record


@dataclass(frozen=True)
class ScheduleWave:
    """A set of steps that may run concurrently.

    Waves are a proper edge colouring of the movement multigraph: within a
    wave no device is the origin or the destination of two steps, which
    bounds the per-device buffer to one in-flight transfer.
    """

    index: int
    steps: Tuple[str, ...]
    measure: Exact

    def to_canonical(self) -> dict:
        return {
            "index": self.index,
            "steps": list(self.steps),
            "measure": self.measure.to_canonical(),
        }


@dataclass(frozen=True)
class BufferingPlan:
    """Buffering obligation of the schedule (spec 31.4 "buffering")."""

    per_device_fraction: Exact
    peak_in_flight_fraction: Exact
    waves: int
    policy: str = "SINGLE_IN_FLIGHT_PER_DEVICE"

    def to_canonical(self) -> dict:
        return {
            "policy": self.policy,
            "per_device_fraction": self.per_device_fraction.to_canonical(),
            "peak_in_flight_fraction": self.peak_in_flight_fraction.to_canonical(),
            "waves": self.waves,
        }


@dataclass(frozen=True)
class DuplicationPolicy:
    """Declared duplication or multicast semantics (spec 31.4, 31.5).

    ``NONE`` states that no element exists on two owners at commit time.
    Any transient copy is declared explicitly, so a later audit that finds a
    duplicate can tell a declared copy from a silent one.
    """

    mode: str = "NONE"
    multicast_groups: Tuple[Tuple[int, ...], ...] = ()
    transient_copies_permitted: bool = True
    replication_factor: int = 1

    def to_canonical(self) -> dict:
        return {
            "mode": self.mode,
            "multicast_groups": [list(g) for g in self.multicast_groups],
            "transient_copies_permitted": self.transient_copies_permitted,
            "replication_factor": self.replication_factor,
        }


@dataclass(frozen=True)
class CompletionCheck:
    """A named, recomputable completion condition (spec 31.4)."""

    name: str
    statement: str
    expected: str = "EXACT_EQUALITY"

    def to_canonical(self) -> dict:
        return {"name": self.name, "statement": self.statement, "expected": self.expected}


@dataclass(frozen=True)
class SolverEvidence:
    """How the optimum was obtained and how to recheck it (spec 31.4, 23.3).

    ``row_potentials`` / ``column_potentials`` are the assignment dual
    witness; ``closed_form_agrees`` records whether the nested closed form
    of 31.2 was applicable and, if so, whether it agreed with the general
    assignment optimum.
    """

    method: str
    arithmetic_profile: str = ArithmeticProfile.EXACT_RATIONAL
    solver_trust_profile: str = "EXACT_RECOMPUTED"
    row_potentials: Tuple[Exact, ...] = ()
    column_potentials: Tuple[Exact, ...] = ()
    nested: bool = False
    closed_form_value: Optional[Exact] = None
    closed_form_agrees: Optional[bool] = None
    notes: Tuple[str, ...] = ()

    def to_canonical(self) -> dict:
        record = {
            "method": self.method,
            "arithmetic_profile": self.arithmetic_profile,
            "solver_trust_profile": self.solver_trust_profile,
            "nested": self.nested,
            "row_potentials": [p.to_canonical() for p in self.row_potentials],
            "column_potentials": [p.to_canonical() for p in self.column_potentials],
        }
        if self.closed_form_value is not None:
            record["closed_form_value"] = self.closed_form_value.to_canonical()
        if self.closed_form_agrees is not None:
            record["closed_form_agrees"] = self.closed_form_agrees
        if self.notes:
            record["notes"] = list(self.notes)
        return record


@dataclass(frozen=True)
class SecondaryReport:
    """Outcome of the lexicographic secondary stage (spec 31.3).

    ``retention_preserved`` is the 31.5 invariant "secondary optimization
    does not violate the primary optimum".  ``trade_refused`` records a
    secondary improvement that was available only by moving more data and
    was declined because the governing contract did not permit the trade.
    """

    objective: str
    direction: str
    value: Exact
    baseline_value: Exact
    retention_preserved: bool
    trade_permitted: bool = False
    trade_refused: bool = False
    refused_gain: Optional[Exact] = None
    refused_retention_loss: Optional[Exact] = None
    refusal_reason: Optional[str] = None
    authorization: Optional[str] = None

    @property
    def primary_respected(self) -> bool:
        """31.5 as qualified by 31.3.

        Either retention stayed at ``M*``, or the extra movement was taken
        under a named contract authorization.  A trade with no authorization
        is exactly the silent increase 31.3 forbids, and fails here.
        """
        if self.retention_preserved:
            return True
        return bool(self.trade_permitted and self.authorization)

    def to_canonical(self) -> dict:
        record = {
            "objective": self.objective,
            "direction": self.direction,
            "value": self.value.to_canonical(),
            "baseline_value": self.baseline_value.to_canonical(),
            "retention_preserved": self.retention_preserved,
            "trade_permitted": self.trade_permitted,
            "trade_refused": self.trade_refused,
            "primary_respected": self.primary_respected,
        }
        if self.authorization:
            record["authorization"] = self.authorization
        if self.refused_gain is not None:
            record["refused_gain"] = self.refused_gain.to_canonical()
        if self.refused_retention_loss is not None:
            record["refused_retention_loss"] = self.refused_retention_loss.to_canonical()
        if self.refusal_reason:
            record["refusal_reason"] = self.refusal_reason
        return record


@dataclass
class ConversionRecord:
    """The conversion record required by specification 31.4.

    Every field of the 31.4 list is present: source and target logical
    spaces; source and target ownership cells; assignment; retained
    intersections; residual regions; byte or element counts; route and
    schedule; consistency epoch; buffering; duplication or multicast;
    completion checks; failure behavior; rollback behavior; solver
    evidence; and verification program.
    """

    record_id: str
    source_space: LogicalSpace
    target_space: LogicalSpace
    source_cells: Tuple[Cell, ...]
    target_cells: Tuple[Cell, ...]
    assignment: Dict[int, int]
    retained: Tuple[RetainedIntersection, ...]
    residual: Tuple[ResidualRegion, ...]
    retained_fraction: Exact
    moved_fraction: Exact
    route: Tuple[RouteStep, ...]
    schedule: Tuple[ScheduleWave, ...]
    consistency_epoch: str
    buffering: BufferingPlan
    duplication: DuplicationPolicy
    completion_checks: Tuple[CompletionCheck, ...]
    failure_behavior: str
    rollback_behavior: str
    solver_evidence: SolverEvidence
    verification_program: Tuple[str, ...] = VERIFICATION_PROGRAM
    ownership_contract: str = OwnershipContract.EXCLUSIVE_ONE_TO_ONE
    retained_elements: Optional[Exact] = None
    moved_elements: Optional[Exact] = None
    retained_bytes: Optional[Exact] = None
    moved_bytes: Optional[Exact] = None
    secondary: Optional[SecondaryReport] = None
    identity: bool = False

    # -- invariants (spec 31.5) ---------------------------------------
    def check_invariants(self) -> Dict[str, bool]:
        """Recompute every 31.5 invariant from the record alone.

        The solver is not consulted.  A caller who received only this
        record can run the same function and reach the same verdict.
        """
        results: Dict[str, bool] = {}

        results["ARITHMETIC_IS_EXACT_RATIONAL"] = (
            self.solver_evidence.arithmetic_profile == ArithmeticProfile.EXACT_RATIONAL
            and all(
                isinstance(value, Exact)
                for value in (self.retained_fraction, self.moved_fraction)
            )
        )

        results["RETAINED_PLUS_MOVED_EQUALS_TOTAL"] = (
            self.retained_fraction + self.moved_fraction == Exact(1)
        )

        # assignment is injective on both sides
        sources = [i for i in self.assignment]
        targets = list(self.assignment.values())
        results["ASSIGNMENT_IS_ONE_TO_ONE"] = (
            len(set(sources)) == len(sources) and len(set(targets)) == len(targets)
        )

        # retention equals the sum of the retained intersections
        retained_total = Exact(0)
        for item in self.retained:
            retained_total = retained_total + item.measure
        results["RETENTION_MATCHES_ASSIGNMENT_WITNESS"] = (
            retained_total == self.retained_fraction
        )

        # Target coverage: retained + residual per target equals |T_j|.  No
        # duplication: the measure claimed for a (source, target) pair never
        # exceeds the exact overlap |S_i ∩ T_j|, recomputed here from the
        # cells so the check does not trust the solver's own numbers.
        per_target: Dict[int, Exact] = {cell.index: Exact(0) for cell in self.target_cells}
        claimed: Dict[Tuple[int, int], Exact] = {}
        for item in self.retained:
            per_target[item.target_cell] = per_target[item.target_cell] + item.measure
            key = (item.source_cell, item.target_cell)
            claimed[key] = claimed.get(key, Exact(0)) + item.measure
        for item in self.residual:
            per_target[item.target_cell] = per_target[item.target_cell] + item.measure
            key = (item.from_source_cell, item.target_cell)
            claimed[key] = claimed.get(key, Exact(0)) + item.measure
        results["TARGET_COVERAGE_COMPLETE"] = all(
            per_target[cell.index] == cell.measure for cell in self.target_cells
        )
        by_index_source = {cell.index: cell for cell in self.source_cells}
        by_index_target = {cell.index: cell for cell in self.target_cells}
        within_overlap = True
        for (i, j), measure in claimed.items():
            overlap = by_index_source[i].intersection_measure(by_index_target[j])
            if measure > overlap:
                within_overlap = False
                break
        results["NO_UNDECLARED_DUPLICATION"] = (
            within_overlap if self.duplication.mode == "NONE" else True
        )
        results["RETAINED_WITHIN_OVERLAP"] = all(
            item.measure
            <= by_index_source[item.source_cell].intersection_measure(
                by_index_target[item.target_cell]
            )
            for item in self.retained
        )

        # source mass: every source cell gives up exactly what it owns
        per_source: Dict[int, Exact] = {cell.index: Exact(0) for cell in self.source_cells}
        for item in self.retained:
            per_source[item.source_cell] = per_source[item.source_cell] + item.measure
        for item in self.residual:
            per_source[item.from_source_cell] = (
                per_source[item.from_source_cell] + item.measure
            )
        results["SOURCE_MASS_CONSERVED"] = all(
            per_source[cell.index] == cell.measure for cell in self.source_cells
        )

        moved_total = Exact(0)
        for item in self.residual:
            moved_total = moved_total + item.measure
        results["RESIDUAL_MATCHES_MOVED_FRACTION"] = moved_total == self.moved_fraction

        results["IDENTITY_LAYOUT_MOVES_ZERO"] = (
            (self.moved_fraction == Exact(0) and not self.route)
            if self.identity
            else True
        )

        results["SECONDARY_PRESERVES_PRIMARY_OPTIMUM"] = (
            self.secondary.primary_respected if self.secondary is not None else True
        )

        route_total = Exact(0)
        for step in self.route:
            route_total = route_total + step.measure
        results["ROUTE_MATCHES_RESIDUAL"] = route_total == self.moved_fraction

        return results

    @property
    def invariants_hold(self) -> bool:
        return all(self.check_invariants().values())

    def failed_invariants(self) -> List[str]:
        return sorted(name for name, ok in self.check_invariants().items() if not ok)

    # -- canonical form ------------------------------------------------
    def to_canonical(self) -> dict:
        record = {
            "record_id": self.record_id,
            "ownership_contract": self.ownership_contract,
            "source_space": self.source_space.to_canonical(),
            "target_space": self.target_space.to_canonical(),
            "source_cells": [c.to_canonical() for c in self.source_cells],
            "target_cells": [c.to_canonical() for c in self.target_cells],
            "assignment": [[i, self.assignment[i]] for i in sorted(self.assignment)],
            "retained": [r.to_canonical() for r in self.retained],
            "residual": [r.to_canonical() for r in self.residual],
            "retained_fraction": self.retained_fraction.to_canonical(),
            "moved_fraction": self.moved_fraction.to_canonical(),
            "route": [s.to_canonical() for s in self.route],
            "schedule": [w.to_canonical() for w in self.schedule],
            "consistency_epoch": self.consistency_epoch,
            "buffering": self.buffering.to_canonical(),
            "duplication": self.duplication.to_canonical(),
            "completion_checks": [c.to_canonical() for c in self.completion_checks],
            "failure_behavior": self.failure_behavior,
            "rollback_behavior": self.rollback_behavior,
            "solver_evidence": self.solver_evidence.to_canonical(),
            "verification_program": list(self.verification_program),
            "identity": self.identity,
        }
        for key, value in (
            ("retained_elements", self.retained_elements),
            ("moved_elements", self.moved_elements),
            ("retained_bytes", self.retained_bytes),
            ("moved_bytes", self.moved_bytes),
        ):
            if value is not None:
                record[key] = value.to_canonical()
        if self.secondary is not None:
            record["secondary"] = self.secondary.to_canonical()
        return record

    def record_hash(self) -> str:
        return content_hash(self.to_canonical())
