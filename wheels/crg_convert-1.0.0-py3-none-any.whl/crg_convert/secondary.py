"""Lexicographic secondary optimization subject to the retention optimum.

Normative basis: master specification 31.3.  The system establishes the
maximum-retention optimum ``M*`` first, then optimizes routing, makespan,
congestion, energy, buffering, or transition risk **subject to ``M = M*``**.
A secondary objective MUST NOT silently increase represented movement
unless the governing contract expressly permits the trade.

The restriction to ``M = M*`` is enforced exactly, not by a penalty weight.
Linear-programming duality gives the admissible arc set directly: with dual
potentials ``(u, v)`` optimal for the retention problem, a perfect matching
is retention-optimal **if and only if** every one of its arcs is tight,
``u_i + v_j = w_ij``.  So the secondary stage is a minimum-cost assignment
restricted to the tight subgraph, which is again an exact Kuhn-Munkres
solve.  No large-M scalarization is used on the retention term, so no
rounding regime can let the secondary objective erode ``M*``.
"""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from typing import Dict, Optional, Tuple

from crg_model.numeric import Exact

from .assignment import (
    AssignmentSolution,
    ConversionError,
    SolverFailure,
    assignment_value,
    solve_max_assignment,
    solve_min_assignment,
)
from .record import SecondaryReport

__all__ = [
    "SecondaryObjectiveKind",
    "SecondaryObjective",
    "SecondaryOutcome",
    "SecondaryOptimumViolation",
    "optimize_secondary",
]


class SecondaryObjectiveKind:
    """The secondary objectives named by specification 31.3."""

    ROUTING = "ROUTING"
    MAKESPAN = "MAKESPAN"
    CONGESTION = "CONGESTION"
    ENERGY = "ENERGY"
    BUFFERING = "BUFFERING"
    TRANSITION_RISK = "TRANSITION_RISK"

    ALL = frozenset(
        {ROUTING, MAKESPAN, CONGESTION, ENERGY, BUFFERING, TRANSITION_RISK}
    )


class SecondaryOptimumViolation(ConversionError):
    """Raised when a secondary stage would violate the primary optimum.

    Specification 31.5: "secondary optimization does not violate the
    primary optimum".  This is a refusal, not a warning.
    """


@dataclass(frozen=True)
class SecondaryObjective:
    """A declared secondary objective and its authorization state (31.3).

    ``cost[i][j]`` is the secondary cost incurred when source device ``i``
    assumes target ownership ``j``.  ``permit_movement_trade`` is the
    express contract permission of 31.3; it is only honoured together with
    a non-empty ``authorization`` naming the governing clause, so a trade
    can never be enabled by an unattributed boolean.
    """

    kind: str
    cost: Tuple[Tuple[Exact, ...], ...]
    direction: str = "MINIMIZE"
    permit_movement_trade: bool = False
    authorization: Optional[str] = None
    label: str = ""

    def __post_init__(self) -> None:
        if self.kind not in SecondaryObjectiveKind.ALL:
            raise ValueError(
                f"unknown secondary objective {self.kind!r}; specification 31.3 names "
                f"{sorted(SecondaryObjectiveKind.ALL)}"
            )
        if self.direction != "MINIMIZE":
            raise ValueError("secondary objectives are stated as minimizations")
        if self.permit_movement_trade and not self.authorization:
            raise ValueError(
                "a movement trade requires an express contract authorization "
                "(spec 31.3); set SecondaryObjective.authorization to the clause"
            )

    @property
    def rows(self) -> int:
        return len(self.cost)

    @property
    def columns(self) -> int:
        return len(self.cost[0]) if self.cost else 0


@dataclass(frozen=True)
class SecondaryOutcome:
    """The assignment chosen after the lexicographic second stage."""

    assignment: Dict[int, int]
    retention: Exact
    secondary_value: Exact
    report: SecondaryReport


def _as_matrix(values) -> Tuple[Tuple[Exact, ...], ...]:
    return tuple(
        tuple(v if isinstance(v, Exact) else Exact(v) for v in row) for row in values
    )


def optimize_secondary(
    weights,
    objective: SecondaryObjective,
    *,
    primary: Optional[AssignmentSolution] = None,
) -> SecondaryOutcome:
    """Optimize ``objective`` subject to ``M = M*`` (spec 31.3).

    Returns the retention-optimal assignment with the least secondary cost.
    If a strictly cheaper assignment exists only at lower retention, the
    trade is taken only when the contract expressly permits it; otherwise
    the trade is refused and the refusal, its foregone gain, and the
    movement it would have cost are written into the report.
    """
    w = _as_matrix(weights)
    cost = _as_matrix(objective.cost)
    n = len(w)
    if n == 0 or len(w[0]) != n:
        raise ConversionError(
            "the lexicographic secondary stage is defined on the one-to-one "
            "equal-capacity contract, which requires a square weight matrix"
        )
    if objective.rows != n or objective.columns != n:
        raise ValueError("secondary cost matrix must match the weight matrix shape")

    solution = primary if primary is not None else solve_max_assignment(w)
    optimum = solution.value

    # Tight subgraph: u_i + v_j == w_ij.  Every retention-optimal perfect
    # matching lies inside it, and every perfect matching inside it is
    # retention-optimal (complementary slackness).
    u = [p.value for p in solution.row_potentials]
    v = [p.value for p in solution.column_potentials]
    tight = [
        [u[i] + v[j] == w[i][j].value for j in range(n)]
        for i in range(n)
    ]

    flat = [cost[i][j].value for i in range(n) for j in range(n)]
    low, high = min(flat), max(flat)
    forbidden = Fraction(n) * (high - low) + 1  # strictly above any tight total
    restricted = [
        [
            (cost[i][j].value - low) if tight[i][j] else forbidden
            for j in range(n)
        ]
        for i in range(n)
    ]
    restricted_solution = solve_min_assignment(restricted)
    constrained = restricted_solution.assignment
    if any(not tight[i][j] for i, j in constrained.items()):
        raise SolverFailure(
            "no retention-optimal assignment was found inside the tight subgraph"
        )
    constrained_retention = assignment_value(w, constrained)
    if constrained_retention != optimum:
        raise SecondaryOptimumViolation(
            f"secondary stage returned retention {constrained_retention} below the "
            f"primary optimum {optimum}"
        )
    constrained_cost = _value_of(cost, constrained)

    # What the secondary objective could reach if retention were free.
    free_solution = solve_min_assignment(cost)
    free_assignment = free_solution.assignment
    free_cost = _value_of(cost, free_assignment)
    free_retention = assignment_value(w, free_assignment)

    gain = constrained_cost - free_cost
    retention_loss = optimum - free_retention

    if gain > Exact(0) and retention_loss <= Exact(0):
        raise SolverFailure(
            "a cheaper assignment exists at full retention but was not found inside "
            "the tight subgraph; the dual witness cannot be correct"
        )

    if gain > Exact(0) and retention_loss > Exact(0):
        if objective.permit_movement_trade:
            report = SecondaryReport(
                objective=objective.kind,
                direction=objective.direction,
                value=free_cost,
                baseline_value=constrained_cost,
                retention_preserved=False,
                trade_permitted=True,
                trade_refused=False,
                refused_gain=None,
                refused_retention_loss=None,
                refusal_reason=None,
                authorization=objective.authorization,
            )
            return SecondaryOutcome(
                assignment=dict(free_assignment),
                retention=free_retention,
                secondary_value=free_cost,
                report=report,
            )
        report = SecondaryReport(
            objective=objective.kind,
            direction=objective.direction,
            value=constrained_cost,
            baseline_value=constrained_cost,
            retention_preserved=True,
            trade_permitted=False,
            trade_refused=True,
            refused_gain=gain,
            refused_retention_loss=retention_loss,
            refusal_reason=(
                f"a {objective.kind} improvement of {gain} was available only by "
                f"moving an additional {retention_loss} of represented data; the "
                "governing contract does not expressly permit the trade, so it is "
                "refused (spec 31.3)"
            ),
            authorization=None,
        )
        return SecondaryOutcome(
            assignment=dict(constrained),
            retention=optimum,
            secondary_value=constrained_cost,
            report=report,
        )

    report = SecondaryReport(
        objective=objective.kind,
        direction=objective.direction,
        value=constrained_cost,
        baseline_value=constrained_cost,
        retention_preserved=True,
        trade_permitted=objective.permit_movement_trade,
        trade_refused=False,
        authorization=objective.authorization,
    )
    return SecondaryOutcome(
        assignment=dict(constrained),
        retention=optimum,
        secondary_value=constrained_cost,
        report=report,
    )


def _value_of(cost: Tuple[Tuple[Exact, ...], ...], assignment: Dict[int, int]) -> Exact:
    total = Exact(0)
    for i, j in assignment.items():
        total = total + cost[i][j]
    return total
