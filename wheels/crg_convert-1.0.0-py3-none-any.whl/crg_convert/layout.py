"""Layouts, exact cell overlaps, and the conversion driver.

Normative basis: master specification section 31 (OID-CRG-004).  The
governing law is the aligned-layout assignment theorem of the CRG theory
corpus: for equal-capacity source and target partitions of one normalized
logical space, chiplet relabeling free and bijective,

    r*(C, C') = max_pi sum_i |S_i ∩ T_pi(i)|,      mu* = 1 - r*,

and **if** ``C | C'`` or ``C' | C`` then ``r* = min(C, C') / max(C, C')``.
The closed form holds because every nonempty intersection then has area
``1/(kK)``, the intersection bipartite graph is ``k``-regular on both
sides, and a regular bipartite graph has a perfect matching.

For nonnested factors the closed form need not hold, and the difference is
not a rounding artifact.  At ``K = 12``, ``C = 4``, ``C' = 6`` the exact
retained fraction is ``1/2``, not the ``2/3`` the nested formula would
give; at ``K = 12``, ``C = 3``, ``C' = 4`` it is ``35/72``, not ``3/4``.
This module therefore never applies the closed form as a shortcut: it
always solves the assignment, and uses the closed form only as an
independent cross-check on the pairs where the theorem licenses it.
"""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from typing import Dict, List, Mapping, Optional, Sequence, Tuple

from crg_model.numeric import Exact

from .assignment import (
    AssignmentSolution,
    ConversionError,
    SolverFailure,
    min_cost_flow_arcs,
    solve_max_assignment,
)
from .record import (
    BufferingPlan,
    Cell,
    CompletionCheck,
    ConversionRecord,
    DuplicationPolicy,
    LogicalSpace,
    OwnershipContract,
    ResidualRegion,
    RetainedIntersection,
    RouteStep,
    ScheduleWave,
    SolverEvidence,
    SolverMethod,
    VERIFICATION_PROGRAM,
)
from .secondary import SecondaryObjective, optimize_secondary

__all__ = [
    "Layout",
    "cell_overlaps",
    "nested_closed_form",
    "is_nested",
    "convert",
    "retained_fraction",
    "moved_fraction",
    "COMPLETION_CHECKS",
]


DEFAULT_AXES_2D = ("sequence", "feature")
DEFAULT_AXIS_1D = ("index",)


COMPLETION_CHECKS: Tuple[CompletionCheck, ...] = (
    CompletionCheck(
        "TARGET_CELLS_COVERED",
        "for every target cell T_j: sum of retained and residual measures equals |T_j|",
    ),
    CompletionCheck(
        "SOURCE_CELLS_DRAINED",
        "for every source cell S_i: retained plus residual-out equals |S_i|",
    ),
    CompletionCheck(
        "MOVED_MEASURE_DELIVERED",
        "sum of route step measures equals the moved fraction",
    ),
    CompletionCheck(
        "EPOCH_COMMITTED",
        "every route step reports delivery before the consistency epoch advances",
        expected="ALL_STEPS_ACKNOWLEDGED",
    ),
)

FAILURE_BEHAVIOR = (
    "FAIL_CLOSED: a step that does not acknowledge before the epoch boundary aborts "
    "the epoch; the conversion is not partially committed and no ownership change "
    "takes effect (spec 6.6, 31.5)"
)
ROLLBACK_BEHAVIOR = (
    "SOURCE_OWNERSHIP_RETAINED_UNTIL_EPOCH_COMMIT: source cells keep authoritative "
    "ownership of every residual region until the epoch commits, so rollback is the "
    "no-op of discarding delivered copies (spec 31.4)"
)


# ----------------------------------------------------------------------
# layouts
# ----------------------------------------------------------------------

@dataclass(frozen=True)
class Layout:
    """An equal-capacity cell partition of a normalized logical space.

    The space is the unit box ``[0,1]^d``.  ``divisions[a]`` is the number
    of equal parts along axis ``a``, so the layout has ``prod(divisions)``
    cells, each of measure ``1 / prod(divisions)``.  Cells are indexed
    row-major with axis 0 outermost, which makes the index order canonical.

    ``measures`` builds the non-uniform case: a one-dimensional partition
    into consecutive intervals of the declared exact measures.  Such a
    layout is *not* equal-capacity and :func:`convert` refuses to apply the
    equal-capacity assignment law to it (spec 31.2).
    """

    divisions: Tuple[int, ...]
    space: LogicalSpace
    measures: Optional[Tuple[Exact, ...]] = None
    label: str = ""

    def __init__(
        self,
        divisions: Sequence[int] | int = (),
        *,
        space: Optional[LogicalSpace] = None,
        measures: Optional[Sequence] = None,
        label: str = "",
        total_elements: Optional[int] = None,
        bytes_per_element: Optional[int] = None,
    ) -> None:
        if measures is not None:
            exact_measures = tuple(
                m if isinstance(m, Exact) else Exact(m) for m in measures
            )
            if not exact_measures:
                raise ValueError("a layout needs at least one cell")
            if any(m <= Exact(0) for m in exact_measures):
                raise ValueError("cell measures must be strictly positive")
            total = Exact(0)
            for m in exact_measures:
                total = total + m
            if total != Exact(1):
                raise ValueError(
                    f"cell measures must partition the normalized space exactly; got {total}"
                )
            object.__setattr__(self, "divisions", (len(exact_measures),))
            object.__setattr__(self, "measures", exact_measures)
            axes = DEFAULT_AXIS_1D
        else:
            if isinstance(divisions, int):
                divisions = (divisions,)
            div = tuple(int(d) for d in divisions)
            if not div:
                raise ValueError("a layout needs at least one axis")
            if any(d < 1 for d in div):
                raise ValueError("every axis must have at least one division")
            object.__setattr__(self, "divisions", div)
            object.__setattr__(self, "measures", None)
            axes = DEFAULT_AXES_2D[: len(div)] if len(div) <= 2 else tuple(
                f"axis{a}" for a in range(len(div))
            )
        if space is None:
            space = LogicalSpace(
                identifier=label or "normalized-logical-space",
                axes=axes,
                total_elements=total_elements,
                bytes_per_element=bytes_per_element,
            )
        elif total_elements is not None or bytes_per_element is not None:
            raise ValueError("declare element counts on the space or on the layout, not both")
        if space.dimension != len(self.divisions):
            raise ValueError(
                f"space declares {space.dimension} axes but the layout has "
                f"{len(self.divisions)} axes"
            )
        object.__setattr__(self, "space", space)
        object.__setattr__(self, "label", label)

    # -- constructors --------------------------------------------------
    @classmethod
    def aligned(
        cls,
        total_cells: int,
        partitions: int,
        *,
        space: Optional[LogicalSpace] = None,
        label: str = "",
        total_elements: Optional[int] = None,
        bytes_per_element: Optional[int] = None,
    ) -> "Layout":
        """The two-dimensional aligned layout of the conversion theorem.

        ``K = total_cells = C * T`` cells implement an aligned layout over
        the normalized tensor; ``C = partitions`` splits axis 0 and
        ``T = K / C`` splits axis 1.  ``C`` must divide ``K``.
        """
        if total_cells < 1 or partitions < 1:
            raise ValueError("total_cells and partitions must be positive")
        if total_cells % partitions:
            raise ValueError(
                f"aligned layout requires C | K; {partitions} does not divide {total_cells}"
            )
        return cls(
            (partitions, total_cells // partitions),
            space=space,
            label=label or f"K{total_cells}-C{partitions}",
            total_elements=total_elements,
            bytes_per_element=bytes_per_element,
        )

    # -- structure -----------------------------------------------------
    @property
    def cell_count(self) -> int:
        if self.measures is not None:
            return len(self.measures)
        count = 1
        for d in self.divisions:
            count *= d
        return count

    @property
    def partitions(self) -> int:
        """``C``: the division count along axis 0 (the theorem's parameter)."""
        return self.divisions[0]

    @property
    def dimension(self) -> int:
        return len(self.divisions)

    @property
    def is_uniform_grid(self) -> bool:
        return self.measures is None

    @property
    def cell_measure(self) -> Exact:
        if self.measures is not None:
            raise ValueError("a non-uniform layout has no single cell measure")
        return Exact(Fraction(1, self.cell_count))

    @property
    def is_equal_capacity(self) -> bool:
        if self.measures is None:
            return True
        first = self.measures[0]
        return all(m == first for m in self.measures)

    def cells(self) -> Tuple[Cell, ...]:
        """The ownership cells, in canonical index order."""
        if self.measures is not None:
            out: List[Cell] = []
            lo = Exact(0)
            for index, m in enumerate(self.measures):
                hi = lo + m
                out.append(Cell(index=index, box=((lo, hi),), owner=f"{self.label or 'cell'}-{index}"))
                lo = hi
            return tuple(out)
        boxes: List[Cell] = []
        for index in range(self.cell_count):
            coords: List[Tuple[Exact, Exact]] = []
            residue = index
            for axis in range(len(self.divisions) - 1, -1, -1):
                d = self.divisions[axis]
                coords.append((Exact(Fraction(residue % d, d)), Exact(Fraction(residue % d + 1, d))))
                residue //= d
            coords.reverse()
            boxes.append(
                Cell(index=index, box=tuple(coords), owner=f"{self.label or 'cell'}-{index}")
            )
        return tuple(boxes)

    def same_cells_as(self, other: "Layout") -> bool:
        return tuple(c.box for c in self.cells()) == tuple(c.box for c in other.cells())

    def to_canonical(self) -> dict:
        record = {
            "divisions": list(self.divisions),
            "cell_count": self.cell_count,
            "space": self.space.to_canonical(),
            "equal_capacity": self.is_equal_capacity,
        }
        if self.measures is not None:
            record["measures"] = [m.to_canonical() for m in self.measures]
        if self.label:
            record["label"] = self.label
        return record

    def __repr__(self) -> str:  # pragma: no cover - display only
        if self.measures is not None:
            return f"Layout(measures={[str(m) for m in self.measures]})"
        return f"Layout(divisions={self.divisions})"


# ----------------------------------------------------------------------
# exact overlaps and the closed form
# ----------------------------------------------------------------------

def cell_overlaps(source: Layout, target: Layout) -> List[List[Exact]]:
    """Exact rational intersection areas ``|S_i ∩ T_j|`` (spec 31.2).

    Row ``i`` is the source cell, column ``j`` the target cell.  Every
    entry is an exact rational; no floating point is constructed anywhere
    on this path.
    """
    if source.space.dimension != target.space.dimension:
        raise ValueError("source and target layouts live in spaces of different dimension")
    source_cells = source.cells()
    target_cells = target.cells()
    return [[s.intersection_measure(t) for t in target_cells] for s in source_cells]


def is_nested(c: int, c_prime: int) -> bool:
    """``True`` when ``c | c'`` or ``c' | c`` (spec 31.2 closed-form hypothesis)."""
    if c < 1 or c_prime < 1:
        raise ValueError("partition counts must be positive")
    return c_prime % c == 0 or c % c_prime == 0


def nested_closed_form(c: int, c_prime: int) -> Exact:
    """``r* = min(C, C') / max(C, C')`` when one partition count divides the other.

    Refuses the nonnested case rather than returning a value that is merely
    plausible: at ``K = 12`` the nonnested pairs ``(4, 6)`` and ``(3, 4)``
    have exact optima ``1/2`` and ``35/72``, while this formula would say
    ``2/3`` and ``3/4``.
    """
    if not is_nested(c, c_prime):
        raise ValueError(
            f"the closed form is licensed only when C | C' or C' | C; "
            f"({c}, {c_prime}) is nonnested and requires the assignment oracle"
        )
    return Exact(Fraction(min(c, c_prime), max(c, c_prime)))


def retained_fraction(source: Layout, target: Layout) -> Exact:
    """``r*``: the exact maximum retained fraction (spec 31.2)."""
    _, value = _primary_assignment(source, target)
    return value


def moved_fraction(source: Layout, target: Layout) -> Exact:
    """``mu* = 1 - r*``: the exact minimum moved fraction (spec 31.2)."""
    return Exact(1) - retained_fraction(source, target)


def _primary_assignment(source: Layout, target: Layout) -> Tuple[AssignmentSolution, Exact]:
    solution = solve_max_assignment(cell_overlaps(source, target))
    return solution, solution.value


def _closed_form_context(source: Layout, target: Layout) -> Optional[Tuple[int, int]]:
    """``(C, C')`` when the closed-form theorem's hypothesis is met."""
    if not (source.is_uniform_grid and target.is_uniform_grid):
        return None
    if source.cell_count != target.cell_count:
        return None
    if source.dimension != target.dimension:
        return None
    if source.dimension == 2:
        return source.partitions, target.partitions
    if source.dimension == 1:
        return source.cell_count, target.cell_count
    return None


# ----------------------------------------------------------------------
# conversion
# ----------------------------------------------------------------------

def convert(
    source: Layout,
    target: Layout,
    *,
    secondary: Optional[SecondaryObjective] = None,
    device_capacities: Optional[Sequence] = None,
    record_id: Optional[str] = None,
    consistency_epoch: Optional[str] = None,
    duplication: Optional[DuplicationPolicy] = None,
) -> ConversionRecord:
    """Convert ownership from ``source`` to ``target`` and emit the record.

    Routing (spec 31.2):

    * Both layouts equal-capacity and no device capacity constraints
      declared -> the exclusive one-to-one contract, solved as the
      maximum-weight assignment.  The nested closed form is evaluated as an
      independent cross-check where the theorem licenses it, never as a
      substitute for the solve.
    * Otherwise -> heterogeneous capacities, partial availability, or a
      failed device.  The equal-capacity assignment law does not apply and
      is not used; the instance is routed to the min-cost-flow solver under
      the divisible ownership contract, and the record says so.

    The residual schedule retains each assigned intersection in place and
    moves only each target remainder, from the unique source that owns
    those elements, so target coverage is complete and nothing is
    transferred twice (spec 31.5).
    """
    if source.space.dimension != target.space.dimension:
        raise ValueError("source and target layouts live in spaces of different dimension")
    if (
        source.space.total_elements is not None
        and target.space.total_elements is not None
        and source.space.total_elements != target.space.total_elements
    ):
        raise ValueError("source and target spaces disagree on the represented element count")

    overlaps = cell_overlaps(source, target)
    source_cells = source.cells()
    target_cells = target.cells()
    identity = source.same_cells_as(target)

    heterogeneous = (
        device_capacities is not None
        or not source.is_equal_capacity
        or not target.is_equal_capacity
    )
    if heterogeneous:
        if secondary is not None:
            raise ConversionError(
                "the lexicographic secondary stage of 31.3 is defined on the "
                "one-to-one equal-capacity contract; state the secondary objective "
                "as flow costs for the generalized case instead"
            )
        return _convert_heterogeneous(
            source,
            target,
            overlaps,
            device_capacities,
            record_id=record_id,
            consistency_epoch=consistency_epoch,
            duplication=duplication,
            identity=identity,
        )

    solution, optimum = _primary_assignment(source, target)
    assignment = dict(solution.assignment)
    retained_value = optimum
    secondary_report = None
    notes: List[str] = []

    if secondary is not None:
        outcome = optimize_secondary(overlaps, secondary, primary=solution)
        assignment = outcome.assignment
        retained_value = outcome.retention
        secondary_report = outcome.report
        if not secondary_report.primary_respected:
            raise SolverFailure(
                "secondary stage returned an unauthorized movement increase"
            )
        if retained_value > optimum:
            raise SolverFailure("secondary stage reported retention above the primary optimum")

    context = _closed_form_context(source, target)
    nested = False
    closed_form_value: Optional[Exact] = None
    closed_form_agrees: Optional[bool] = None
    if context is not None:
        c, c_prime = context
        nested = is_nested(c, c_prime)
        if nested:
            closed_form_value = nested_closed_form(c, c_prime)
            closed_form_agrees = closed_form_value == optimum
            if not closed_form_agrees:
                raise SolverFailure(
                    f"nested closed form {closed_form_value} disagrees with the "
                    f"assignment optimum {optimum} for C={c}, C'={c_prime}"
                )
        else:
            notes.append(
                f"nonnested C={c}, C'={c_prime}: the closed form min/max = "
                f"{Fraction(min(c, c_prime), max(c, c_prime))} is not licensed; the "
                f"assignment optimum is {optimum}"
            )

    retained, residual = _decompose(overlaps, assignment, source_cells, target_cells)
    evidence = SolverEvidence(
        method=SolverMethod.EXACT_ASSIGNMENT,
        row_potentials=solution.row_potentials,
        column_potentials=solution.column_potentials,
        nested=nested,
        closed_form_value=closed_form_value,
        closed_form_agrees=closed_form_agrees,
        notes=tuple(notes),
    )
    return _assemble(
        source=source,
        target=target,
        source_cells=source_cells,
        target_cells=target_cells,
        assignment=assignment,
        retained=retained,
        residual=residual,
        retained_value=retained_value,
        evidence=evidence,
        contract=OwnershipContract.EXCLUSIVE_ONE_TO_ONE,
        identity=identity,
        record_id=record_id,
        consistency_epoch=consistency_epoch,
        duplication=duplication,
        secondary=secondary_report,
    )


def _decompose(
    overlaps: List[List[Exact]],
    assignment: Mapping[int, int],
    source_cells: Sequence[Cell],
    target_cells: Sequence[Cell],
) -> Tuple[List[RetainedIntersection], List[ResidualRegion]]:
    """Retained intersections and the residual-only movement set (31.4).

    Each assigned intersection stays in place.  Each target remainder is
    moved from the unique source that owns those elements, so every element
    of every target cell is accounted for exactly once.
    """
    owner_of_target: Dict[int, int] = {j: i for i, j in assignment.items()}
    # A target cell the assignment left unmatched has no incumbent owner; it
    # is served by a newly provisioned device, numbered past the source range
    # so that it is never confused with an existing owner.
    next_new_device = len(source_cells)
    for j in range(len(target_cells)):
        if j not in owner_of_target:
            owner_of_target[j] = next_new_device
            next_new_device += 1
    retained: List[RetainedIntersection] = []
    residual: List[ResidualRegion] = []
    for j in range(len(target_cells)):
        owner = owner_of_target[j]
        for i in range(len(source_cells)):
            measure = overlaps[i][j]
            if measure == Exact(0):
                continue
            if i == owner:
                retained.append(RetainedIntersection(source_cell=i, target_cell=j, measure=measure))
            else:
                residual.append(
                    ResidualRegion(
                        target_cell=j,
                        from_source_cell=i,
                        to_source_cell=owner,
                        measure=measure,
                    )
                )
    return retained, residual


def _convert_heterogeneous(
    source: Layout,
    target: Layout,
    overlaps: List[List[Exact]],
    device_capacities: Optional[Sequence],
    *,
    record_id: Optional[str],
    consistency_epoch: Optional[str],
    duplication: Optional[DuplicationPolicy],
    identity: bool,
) -> ConversionRecord:
    """Generalized conversion by exact min-cost flow (spec 31.2).

    Two parallel arcs per pair express the piecewise cost: device ``i`` may
    hold up to ``|S_i ∩ T_j|`` of target cell ``j`` at zero cost, because it
    already holds those elements, and any further amount costs one unit of
    represented movement.  Target demands are equalities, so target
    coverage is complete by construction.  Supplies are the declared
    post-conversion device capacities: a failed device is a zero supply and
    partial availability is a reduced one.
    """
    source_cells = source.cells()
    target_cells = target.cells()
    n = len(source_cells)
    m = len(target_cells)

    if device_capacities is None:
        capacities = [cell.measure for cell in target_cells[:n]]
        capacities += [Exact(0)] * (n - len(capacities))
    else:
        if len(device_capacities) != n:
            raise ValueError("device_capacities must declare one capacity per source cell")
        capacities = [c if isinstance(c, Exact) else Exact(c) for c in device_capacities]
    total_capacity = Exact(0)
    for c in capacities:
        total_capacity = total_capacity + c
    if total_capacity < Exact(1):
        raise ConversionError(
            f"declared device capacities total {total_capacity} < 1 and cannot hold the "
            "represented data; this is a proven infeasibility of the stated instance, "
            "not a solver failure"
        )

    arcs: List[Tuple[int, int, Optional[object], object]] = []
    retain_arc: Dict[Tuple[int, int], int] = {}
    for i in range(n):
        for j in range(m):
            if overlaps[i][j] > Exact(0):
                retain_arc[(i, j)] = len(arcs)
                arcs.append((i, j, overlaps[i][j], Exact(0)))
            arcs.append((i, j, None, Exact(1)))
    demands = [cell.measure for cell in target_cells]
    solution = min_cost_flow_arcs(arcs, capacities, demands)
    if not solution.feasible:
        raise ConversionError(
            f"target coverage is unreachable under the declared capacities ({solution.reason})"
        )

    # Split the per-pair flow back into its retained and moved parts.
    retained_flow: Dict[Tuple[int, int], Exact] = {}
    moved_in: Dict[Tuple[int, int], Exact] = {}
    for (i, j), amount in solution.flow.items():
        cap = overlaps[i][j]
        keep = amount if amount < cap else cap
        if keep > Exact(0):
            retained_flow[(i, j)] = keep
        extra = amount - keep
        if extra > Exact(0):
            moved_in[(i, j)] = extra

    retained: List[RetainedIntersection] = []
    retained_total = Exact(0)
    for (i, j) in sorted(retained_flow):
        retained.append(RetainedIntersection(source_cell=i, target_cell=j, measure=retained_flow[(i, j)]))
        retained_total = retained_total + retained_flow[(i, j)]

    # For each target cell, the elements not retained in place are matched
    # to the devices that will hold them.  Both sides sum to the same
    # measure per target cell, so the pairing conserves mass exactly.
    residual: List[ResidualRegion] = []
    for j in range(m):
        leftovers = [
            [i, overlaps[i][j] - retained_flow.get((i, j), Exact(0))]
            for i in range(n)
            if overlaps[i][j] - retained_flow.get((i, j), Exact(0)) > Exact(0)
        ]
        needs = [[i, moved_in[(i, j)]] for i in range(n) if (i, j) in moved_in]
        li = 0
        for need in needs:
            while need[1] > Exact(0):
                if li >= len(leftovers):
                    raise SolverFailure(
                        f"target cell {j} needs more moved data than its sources hold"
                    )
                available = leftovers[li][1]
                if available == Exact(0):
                    li += 1
                    continue
                step = available if available < need[1] else need[1]
                residual.append(
                    ResidualRegion(
                        target_cell=j,
                        from_source_cell=leftovers[li][0],
                        to_source_cell=need[0],
                        measure=step,
                    )
                )
                leftovers[li][1] = available - step
                need[1] = need[1] - step
                if leftovers[li][1] == Exact(0):
                    li += 1
        if any(item[1] > Exact(0) for item in leftovers):
            raise SolverFailure(f"target cell {j} left source data unplaced")

    evidence = SolverEvidence(
        method=SolverMethod.MIN_COST_FLOW,
        nested=False,
        notes=(
            "heterogeneous capacity or declared availability: the equal-capacity "
            "one-to-one assignment law of 31.2 does not apply and was not used",
            f"declared device capacities total {total_capacity}",
        ),
    )
    return _assemble(
        source=source,
        target=target,
        source_cells=source_cells,
        target_cells=target_cells,
        assignment={},
        retained=retained,
        residual=residual,
        retained_value=retained_total,
        evidence=evidence,
        contract=OwnershipContract.DIVISIBLE,
        identity=identity and retained_total == Exact(1),
        record_id=record_id,
        consistency_epoch=consistency_epoch,
        duplication=duplication,
        secondary=None,
    )


# ----------------------------------------------------------------------
# record assembly
# ----------------------------------------------------------------------

def _assemble(
    *,
    source: Layout,
    target: Layout,
    source_cells: Sequence[Cell],
    target_cells: Sequence[Cell],
    assignment: Dict[int, int],
    retained: Sequence[RetainedIntersection],
    residual: Sequence[ResidualRegion],
    retained_value: Exact,
    evidence: SolverEvidence,
    contract: str,
    identity: bool,
    record_id: Optional[str],
    consistency_epoch: Optional[str],
    duplication: Optional[DuplicationPolicy],
    secondary,
) -> ConversionRecord:
    space = source.space
    moved_value = Exact(1) - retained_value

    retained_full = tuple(
        RetainedIntersection(
            source_cell=r.source_cell,
            target_cell=r.target_cell,
            measure=r.measure,
            elements=space.elements_in(r.measure),
            bytes_=space.bytes_in(r.measure),
        )
        for r in retained
    )
    residual_full = tuple(
        ResidualRegion(
            target_cell=r.target_cell,
            from_source_cell=r.from_source_cell,
            to_source_cell=r.to_source_cell,
            measure=r.measure,
            elements=space.elements_in(r.measure),
            bytes_=space.bytes_in(r.measure),
        )
        for r in residual
    )

    route, schedule, buffering = _schedule(residual_full, space)
    epoch = consistency_epoch or _epoch_identifier(source, target)
    record = ConversionRecord(
        record_id=record_id or f"conversion-{source.label or 'src'}-to-{target.label or 'tgt'}",
        source_space=source.space,
        target_space=target.space,
        source_cells=tuple(source_cells),
        target_cells=tuple(target_cells),
        assignment=dict(assignment),
        retained=retained_full,
        residual=residual_full,
        retained_fraction=retained_value,
        moved_fraction=moved_value,
        route=route,
        schedule=schedule,
        consistency_epoch=epoch,
        buffering=buffering,
        duplication=duplication or DuplicationPolicy(),
        completion_checks=COMPLETION_CHECKS,
        failure_behavior=FAILURE_BEHAVIOR,
        rollback_behavior=ROLLBACK_BEHAVIOR,
        solver_evidence=evidence,
        verification_program=VERIFICATION_PROGRAM,
        ownership_contract=contract,
        retained_elements=space.elements_in(retained_value),
        moved_elements=space.elements_in(moved_value),
        retained_bytes=space.bytes_in(retained_value),
        moved_bytes=space.bytes_in(moved_value),
        secondary=secondary,
        identity=identity,
    )
    failures = record.failed_invariants()
    if failures:
        raise SolverFailure(
            "conversion record violates specification 31.5 invariants: " + ", ".join(failures)
        )
    return record


def _schedule(
    residual: Sequence[ResidualRegion], space: LogicalSpace
) -> Tuple[Tuple[RouteStep, ...], Tuple[ScheduleWave, ...], BufferingPlan]:
    """Route, wave schedule, and buffering obligation (spec 31.4).

    Waves are a greedy proper edge colouring of the movement multigraph: no
    device is the origin or the destination of two steps in the same wave,
    so one transfer buffer per device suffices.
    """
    ordered = sorted(
        residual,
        key=lambda r: (r.target_cell, r.from_source_cell, r.to_source_cell, r.measure.value),
    )
    used_by_wave: List[set] = []
    steps: List[RouteStep] = []
    for position, item in enumerate(ordered):
        endpoints = {item.from_source_cell, item.to_source_cell}
        wave = 0
        while True:
            if wave == len(used_by_wave):
                used_by_wave.append(set())
            if not (used_by_wave[wave] & endpoints):
                used_by_wave[wave] |= endpoints
                break
            wave += 1
        steps.append(
            RouteStep(
                step_id=f"step-{position:04d}",
                origin=item.from_source_cell,
                destination=item.to_source_cell,
                target_cell=item.target_cell,
                measure=item.measure,
                wave=wave,
                elements=item.elements,
                bytes_=item.bytes_,
            )
        )
    waves: List[ScheduleWave] = []
    for index in range(len(used_by_wave)):
        members = [s for s in steps if s.wave == index]
        total = Exact(0)
        for s in members:
            total = total + s.measure
        waves.append(
            ScheduleWave(index=index, steps=tuple(s.step_id for s in members), measure=total)
        )
    per_device = Exact(0)
    for s in steps:
        if s.measure > per_device:
            per_device = s.measure
    peak = Exact(0)
    for w in waves:
        if w.measure > peak:
            peak = w.measure
    return tuple(steps), tuple(waves), BufferingPlan(
        per_device_fraction=per_device,
        peak_in_flight_fraction=peak,
        waves=len(waves),
    )


def _epoch_identifier(source: Layout, target: Layout) -> str:
    return (
        f"epoch:{source.label or 'src'}->{target.label or 'tgt'}"
        f":cells{source.cell_count}->{target.cell_count}"
    )
