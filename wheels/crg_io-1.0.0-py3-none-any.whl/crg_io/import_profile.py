"""Registry Import Profile: bring the alternatives you already have.

Normative basis: master specification section 37 (Registry Import Profile),
with section 21 (completeness basis and claim scope), section 14.2 (numeric
representations), and section 5.3 (evidence classes).

The governing onboarding principle of 37.1 is that a user must not be
required to author a realization generator before receiving value from CRG.
This module is that door: a candidate table becomes a
:class:`~crg_model.records.RealizationBundle` plus an :class:`ImportReport`.

Three properties of this importer are safety properties, not conveniences:

1. **No float ever enters the model.**  Every numeric cell is parsed to an
   exact rational (``crg_model.numeric.Exact``) by an explicit grammar.
   ``float()`` is not called anywhere in this file.  A cell that cannot be
   read exactly is refused, never rounded.
2. **Nothing is silently dropped or silently zeroed** (37.3, 6.11).  A row
   that fails lands in :attr:`ImportReport.rejected` with a per-row reason and
   is carried into the bundle's canonical form; a missing optional field stays
   missing rather than becoming ``0``.
3. **The completeness basis is ``EXPLICIT_IMPORTED_FAMILY``** (21.2).
   Importing a table proves what the table contains and nothing about the
   universe of legal realizations, so the derived claim scope is
   ``RELATIVE_EXPLICIT_FAMILY`` (21.4) and every downstream certificate says so.

Two specification ambiguities are resolved here, and both are resolved by
failing closed:

* A duplicate realization identifier is an *error*, but a row-scoped one: the
  first occurrence is kept, the duplicate is rejected with a reason, and
  :attr:`ImportReport.has_errors` becomes true.  Structural faults (a missing
  identity column, a missing coordinate column, a duplicated header) raise
  :class:`ImportProfileError` instead, because no row-level report could
  describe them honestly.
* An interval-valued coordinate cell (37.6 shows one) is refused rather than
  collapsed to a midpoint or an endpoint, because a signature coordinate is a
  point in exact signature space (19.1) and inventing that point would be a
  fabrication.  Evidence uncertainty belongs in an evidence record, not in the
  coordinate.
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import os
import re
from dataclasses import dataclass, field
from fractions import Fraction
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple, Union

from crg_model.completeness import (
    ClaimScope,
    CompletenessBasis,
    CompletenessBasisType,
    derive_claim_scope,
)
from crg_model.envelope import EvidenceClass
from crg_model.numeric import Exact
from crg_model.records import (
    Coordinate,
    CoordinateSchema,
    Direction,
    RealizationBundle,
    RealizationRecord,
    Signature,
)

from .report import _kv, _rule, _section, _wrap

__all__ = [
    "IMPORTER_ID",
    "IMPORTER_VERSION",
    "JSON_IMPORTER_ID",
    "MAPPING_IMPORTER_ID",
    "MAPPING_FORMATS",
    "ImportProfileError",
    "ExactParseError",
    "RejectedRow",
    "ImportReport",
    "parse_exact",
    "parse_exact_value",
    "infer_schema",
    "import_tabular",
    "import_json",
    "import_mapping_export",
    "file_fingerprint",
]

IMPORTER_ID = "crg-io.tabular"
IMPORTER_VERSION = "1.0.0"
JSON_IMPORTER_ID = "crg-io.json"
MAPPING_IMPORTER_ID = "crg-io.mapping-export"

#: Guard against a decimal exponent large enough to be a denial of service.
#: ``1e400`` is perfectly exact as a rational; ``1e400000000`` is a bomb.
MAX_EXPONENT = 4096


class ImportProfileError(ValueError):
    """A structural fault that no per-row report could describe honestly."""


class ExactParseError(ValueError):
    """A cell that cannot be read as an exact rational (spec 14.2)."""


# ---------------------------------------------------------------------------
# exact cell parsing (spec 14.2)
# ---------------------------------------------------------------------------

_DECIMAL_RE = re.compile(r"^[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?$")
_RATIO_RE = re.compile(r"^([+-]?[0-9]+)\s*/\s*([+-]?[0-9]+)$")
_EXPONENT_RE = re.compile(r"[eE]([+-]?[0-9]+)$")
_INTERVAL_RE = re.compile(r"^[\[\(].*[\]\)]$")


def parse_exact(text: str) -> Exact:
    """Parse ``text`` to an exact rational, or raise :class:`ExactParseError`.

    Accepted forms (spec 14.2): integer ``12``; decimal ``2.25``; scientific
    ``225e-2``; rational ``9/4``.  Every accepted form is exact by
    construction -- the decimal and scientific forms are read as
    ``Fraction`` over a power of ten, never through binary floating point.

    Refused: empty cells, ``nan``/``inf``, thousands separators, hexadecimal,
    interval literals, and anything else whose exact value is not determined
    by the text.  Refusal is the point: a value that cannot be read exactly
    cannot authorize a certificate (spec 22.6).
    """
    if not isinstance(text, str):
        raise ExactParseError(f"expected a text cell, got {type(text).__name__}")
    token = text.strip()
    if token == "":
        raise ExactParseError(
            "empty cell; a missing value MUST remain missing and MUST NOT become zero (spec 37.3)"
        )
    lowered = token.lower()
    if lowered in {"nan", "+nan", "-nan", "inf", "+inf", "-inf", "infinity", "-infinity"}:
        raise ExactParseError(
            f"{token!r} is a floating-point special value with no exact rational meaning"
        )
    if _INTERVAL_RE.match(token):
        raise ExactParseError(
            f"{token!r} is interval-valued; a signature coordinate is a point in exact "
            "signature space (spec 19.1), so record the uncertainty as evidence rather "
            "than collapsing it to a point"
        )
    ratio = _RATIO_RE.match(token)
    if ratio:
        numerator, denominator = int(ratio.group(1)), int(ratio.group(2))
        if denominator == 0:
            raise ExactParseError(f"{token!r} has a zero denominator")
        return Exact(Fraction(numerator, denominator))
    if not _DECIMAL_RE.match(token):
        raise ExactParseError(
            f"{token!r} is not an exact numeric literal; use an integer (12), a decimal "
            "(2.25), a scientific decimal (225e-2), or a rational (9/4)"
        )
    exponent = _EXPONENT_RE.search(token)
    if exponent and abs(int(exponent.group(1))) > MAX_EXPONENT:
        raise ExactParseError(
            f"{token!r} has an exponent beyond the import guard of {MAX_EXPONENT}"
        )
    return Exact(Fraction(token))


def parse_exact_value(value: Any, *, field_name: str = "value") -> Exact:
    """Parse a JSON-native value to an exact rational, or raise (spec 14.2).

    A structured registry (JSON, a mapping export) delivers numbers as native
    Python objects, so the exactness rule of 14.2 has to be enforced on the
    *object*, not on a re-serialised string.  The dispatch is deliberate:

    * a **string** is read by :func:`parse_exact` -- so ``"2.25"``, ``"225e-2"``
      and ``"9/4"`` are all accepted and read exactly;
    * a Python **int** is already an exact integer and is accepted;
    * a Python **float** is refused.  A JSON number written bare (``2.25``) is
      decoded by :func:`json.loads` as a binary float that has *already* lost
      the value's exact identity -- ``0.1`` is not one tenth -- so it cannot be
      recovered here and MUST NOT be silently rounded into the model (14.2,
      22.6).  The remedy is to quote it: ``"2.25"`` is exact, ``2.25`` is not;
    * a **bool** is refused before the int check (``True`` is an ``int``
      subclass but is not a magnitude);
    * anything else (a list -- i.e. an interval -- a dict, ``None``) is refused,
      because a signature coordinate is a single point in exact signature space
      (19.1).
    """
    if isinstance(value, bool):
        raise ExactParseError(
            f"{field_name} is the boolean {value!r}; a boolean is not an exact magnitude"
        )
    if isinstance(value, str):
        return parse_exact(value)
    if isinstance(value, int):
        return Exact(value)
    if isinstance(value, float):
        raise ExactParseError(
            f"{field_name} is the JSON float {value!r}; a binary float has already lost the "
            "value's exact identity and MUST NOT be silently rounded into a signature. Provide "
            "it as a quoted string ('2.25', '225e-2', or '9/4') so it is read exactly (spec 14.2)"
        )
    if isinstance(value, (list, tuple)):
        raise ExactParseError(
            f"{field_name} is a sequence {value!r}; a signature coordinate is a single point in "
            "exact signature space (spec 19.1), so record interval uncertainty as evidence "
            "rather than as the coordinate"
        )
    raise ExactParseError(
        f"{field_name} is a {type(value).__name__}; expected a numeric string or an integer"
    )


def file_fingerprint(raw: bytes) -> str:
    """``sha256:<hex>`` over the raw source bytes (spec 37.4 source fingerprint)."""
    return "sha256:" + hashlib.sha256(raw).hexdigest()


# ---------------------------------------------------------------------------
# schema inference (spec 37.4 inferred fields, 13.2 quantity definition)
# ---------------------------------------------------------------------------

#: Unit tokens the header sniffer recognises.  An unrecognised suffix is left
#: alone and the unit becomes dimensionless, which is a declaration that the
#: unit is unknown -- never a guess (spec 13.1, 13.4).
KNOWN_UNITS: Tuple[str, ...] = (
    "ns", "us", "ms", "s", "min", "hr",
    "pj", "nj", "uj", "mj", "j", "kj",
    "mw", "w", "kw",
    "usd", "eur", "gbp", "jpy",
    "kb", "mb", "gb", "tb",
    "mm2", "um2", "mm", "um", "nm",
    "ops", "gops", "tops", "flops", "gflops",
    "pct", "ratio", "count", "bits", "bytes",
)

DIMENSIONLESS = "1"

_UNIT_ANNOTATION_RE = re.compile(r"^(?P<base>[^\[\(]+?)\s*[\[\(](?P<unit>[^\]\)]+)[\]\)]$")
_DIRECTION_RE = re.compile(r"^(?P<head>.+)\|(?P<direction>MAX|MIN|MAXIMIZE|MINIMIZE)$", re.I)


def _split_direction(column: str) -> Tuple[str, str]:
    match = _DIRECTION_RE.match(column.strip())
    if not match:
        return column.strip(), Direction.MINIMIZE
    head = match.group("head").strip()
    token = match.group("direction").upper()
    direction = Direction.MAXIMIZE if token.startswith("MAX") else Direction.MINIMIZE
    return head, direction


def _split_unit(name: str) -> Tuple[str, str]:
    """Return ``(quantity, unit)`` for a column name.

    ``latency (ms)`` and ``latency[ms]`` and ``latency_ms`` all read as
    quantity ``latency`` in unit ``ms``.  Anything else is dimensionless.
    """
    annotated = _UNIT_ANNOTATION_RE.match(name)
    if annotated:
        return annotated.group("base").strip(), annotated.group("unit").strip()
    if "_" in name:
        base, _, suffix = name.rpartition("_")
        if base and suffix.lower() in KNOWN_UNITS:
            return base, suffix.lower()
    return name, DIMENSIONLESS


def infer_schema(
    path: Union[str, os.PathLike],
    *,
    coordinate_columns: Union[Mapping[str, str], Sequence[str]],
) -> CoordinateSchema:
    """Infer a :class:`CoordinateSchema` from the header of a tabular source.

    The quantity and unit are read from the header text by the conventions in
    :func:`_split_unit`; the optimisation direction defaults to ``MINIMIZE``
    and may be declared as a ``|MAX`` header suffix.  Inference is a
    convenience for the first run only: the resulting schema is an ordinary
    declared schema and the caller remains responsible for it (spec 13.1).
    """
    header = _read_header(path)
    mapping = _normalize_coordinate_columns(coordinate_columns)
    # A direction annotation may be written into the header cell itself
    # (``tput_gops|MAX``) or supplied by the caller alone, so either spelling
    # counts as present.
    missing = [
        column
        for column in mapping
        if column not in header and _strip_annotations(column) not in header
    ]
    if missing:
        raise ImportProfileError(
            "coordinate columns absent from the source header: " + ", ".join(sorted(missing))
        )
    coordinates: List[Coordinate] = []
    for column, identifier in mapping.items():
        name, direction = _split_direction(column)
        quantity, unit = _split_unit(name)
        coordinates.append(
            Coordinate(
                identifier=identifier,
                quantity=quantity,
                unit=unit,
                direction=direction,
            )
        )
    return CoordinateSchema(coordinates=tuple(coordinates))


def _strip_annotations(column: str) -> str:
    head, _ = _split_direction(column)
    return head


def _normalize_coordinate_columns(
    coordinate_columns: Union[Mapping[str, str], Sequence[str]],
) -> "Dict[str, str]":
    """Normalise the caller's coordinate columns to ``{column: identifier}``.

    A mapping is taken verbatim.  A sequence of column names maps each column
    to a coordinate identifier equal to the column name with any ``|MAX``
    direction annotation removed.
    """
    if isinstance(coordinate_columns, Mapping):
        mapping = {str(k): str(v) for k, v in coordinate_columns.items()}
    else:
        mapping = {}
        for column in coordinate_columns:
            mapping[str(column)] = _strip_annotations(str(column))
    if not mapping:
        raise ImportProfileError("no coordinate columns were declared")
    identifiers = list(mapping.values())
    if len(set(identifiers)) != len(identifiers):
        raise ImportProfileError("two source columns map to the same coordinate identifier")
    return mapping


# ---------------------------------------------------------------------------
# reading
# ---------------------------------------------------------------------------


def _delimiter_for(path: Union[str, os.PathLike], header_line: str) -> str:
    suffix = os.path.splitext(str(path))[1].lower()
    if suffix in {".tsv", ".tab"}:
        return "\t"
    if suffix == ".csv":
        return ","
    if "\t" in header_line and "," not in header_line:
        return "\t"
    if ";" in header_line and "," not in header_line:
        return ";"
    return ","


def _read_bytes(path: Union[str, os.PathLike]) -> bytes:
    with open(path, "rb") as handle:
        return handle.read()


def _decode(raw: bytes) -> str:
    try:
        return raw.decode("utf-8-sig")
    except UnicodeDecodeError as exc:  # pragma: no cover - defensive
        raise ImportProfileError(f"source is not valid UTF-8: {exc}") from exc


def _rows(path: Union[str, os.PathLike], raw: bytes) -> Tuple[List[str], List[List[str]]]:
    text = _decode(raw)
    first_line = text.split("\n", 1)[0]
    delimiter = _delimiter_for(path, first_line)
    reader = csv.reader(io.StringIO(text, newline=""), delimiter=delimiter)
    records = [row for row in reader if any(cell.strip() for cell in row)]
    if not records:
        raise ImportProfileError("source contains no header row")
    header = [cell.strip() for cell in records[0]]
    if any(header.count(name) > 1 for name in header):
        duplicates = sorted({name for name in header if header.count(name) > 1})
        raise ImportProfileError("duplicate header columns: " + ", ".join(duplicates))
    return header, records[1:]


def _read_header(path: Union[str, os.PathLike]) -> List[str]:
    header, _ = _rows(path, _read_bytes(path))
    return header


# ---------------------------------------------------------------------------
# report (spec 37.4)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class RejectedRow:
    """One refused row, carried rather than dropped (spec 6.11, 37.3)."""

    row_number: int
    realization_id: Optional[str]
    reason: str
    column: Optional[str] = None
    raw: str = ""

    def to_dict(self) -> Dict[str, Any]:
        record: Dict[str, Any] = {"row_number": self.row_number, "reason": self.reason}
        if self.realization_id:
            record["realization_id"] = self.realization_id
        if self.column:
            record["column"] = self.column
        if self.raw:
            record["raw"] = self.raw
        return record

    def to_canonical(self) -> Dict[str, Any]:
        return self.to_dict()


@dataclass
class ImportReport:
    """Specification 37.4: what every import must tell its user."""

    source_path: str
    source_fingerprint: str
    importer_id: str = IMPORTER_ID
    importer_version: str = IMPORTER_VERSION
    rows_read: int = 0
    accepted: Tuple[str, ...] = ()
    rejected: Tuple[RejectedRow, ...] = ()
    field_mapping: Dict[str, str] = field(default_factory=dict)
    coordinate_mapping: Dict[str, Dict[str, str]] = field(default_factory=dict)
    quantity_mappings: Dict[str, str] = field(default_factory=dict)
    unit_conversions: Tuple[str, ...] = ()
    dropped_fields: Tuple[str, ...] = ()
    unsupported_fields: Tuple[str, ...] = ()
    duplicate_handling: str = "REJECT_DUPLICATE_ID"
    identity_policy: str = ""
    missing_evidence: Tuple[str, ...] = ()
    inferred_fields: Tuple[str, ...] = ()
    user_overrides: Tuple[str, ...] = ()
    warnings: Tuple[str, ...] = ()
    completeness_basis: Optional[CompletenessBasis] = None
    claim_scope: str = ClaimScope.RELATIVE_EXPLICIT_FAMILY
    canonical_output_hash: Optional[str] = None
    bundle_id: str = ""

    # -- derived -------------------------------------------------------
    @property
    def accepted_count(self) -> int:
        return len(self.accepted)

    @property
    def rejected_count(self) -> int:
        return len(self.rejected)

    @property
    def has_errors(self) -> bool:
        """True when any row was refused; a clean import has no rejections."""
        return bool(self.rejected)

    def rejection_reasons(self) -> Dict[str, str]:
        return {r.realization_id or f"row-{r.row_number}": r.reason for r in self.rejected}

    def to_canonical(self) -> Dict[str, Any]:
        record: Dict[str, Any] = {
            "source_path": self.source_path,
            "source_fingerprint": self.source_fingerprint,
            "importer": {"id": self.importer_id, "version": self.importer_version},
            "rows_read": self.rows_read,
            "accepted": list(self.accepted),
            "rejected": [r.to_canonical() for r in self.rejected],
            "field_mapping": dict(self.field_mapping),
            "coordinate_mapping": {k: dict(v) for k, v in self.coordinate_mapping.items()},
            "quantity_mappings": dict(self.quantity_mappings),
            "unit_conversions": list(self.unit_conversions),
            "dropped_fields": list(self.dropped_fields),
            "unsupported_fields": list(self.unsupported_fields),
            "duplicate_handling": self.duplicate_handling,
            "identity_policy": self.identity_policy,
            "missing_evidence": list(self.missing_evidence),
            "inferred_fields": list(self.inferred_fields),
            "user_overrides": list(self.user_overrides),
            "warnings": list(self.warnings),
            "claim_scope": self.claim_scope,
        }
        if self.completeness_basis is not None:
            record["completeness_basis"] = self.completeness_basis.to_canonical()
        if self.canonical_output_hash:
            record["canonical_output_hash"] = self.canonical_output_hash
        if self.bundle_id:
            record["bundle_id"] = self.bundle_id
        return record

    # -- rendering -----------------------------------------------------
    def render(self, width: int = 88) -> str:
        """Deterministic plain-ASCII rendering of the import report."""
        lines: List[str] = []
        lines.append(_rule("=", width))
        lines.append("CRG REGISTRY IMPORT REPORT")
        lines.append(_rule("=", width))
        lines.extend(_kv("source", self.source_path, width))
        lines.extend(_kv("source fingerprint", self.source_fingerprint, width))
        lines.extend(_kv("importer", f"{self.importer_id}@{self.importer_version}", width))
        lines.extend(_kv("bundle id", self.bundle_id or "(unset)", width))
        lines.extend(_kv("canonical output hash", self.canonical_output_hash or "(unset)", width))
        lines.append("")

        lines.extend(_section(1, "COMPLETENESS BASIS AND CLAIM SCOPE", width))
        basis = self.completeness_basis
        if basis is not None:
            lines.extend(_kv("basis type", basis.basis_type, width))
            lines.extend(_kv("declared universe", basis.declared_universe, width))
            if basis.closure_procedure:
                lines.extend(_kv("import procedure", basis.closure_procedure, width))
            if basis.source_or_generator_hash:
                lines.extend(_kv("source hash", basis.source_or_generator_hash, width))
            if basis.known_omissions:
                for omission in basis.known_omissions:
                    lines.extend(_kv("known omission", omission, width))
        lines.extend(_kv("derived claim scope", self.claim_scope, width))
        lines.extend(
            _wrap(
                "An import establishes what the table contains and nothing about the "
                "universe of legal realizations; every certificate over this bundle is "
                "therefore relative to the explicitly imported family (spec 21.2, 21.4).",
                width,
                indent=2,
            )
        )
        lines.append("")

        lines.extend(_section(2, "ROW DISPOSITION", width))
        lines.extend(_kv("rows read", str(self.rows_read), width))
        lines.extend(_kv("accepted", str(self.accepted_count), width))
        lines.extend(_kv("rejected", str(self.rejected_count), width))
        for realization_id in self.accepted:
            lines.append(f"  + {realization_id}")
        for row in self.rejected:
            label = row.realization_id or "(no id)"
            column = f" [column {row.column}]" if row.column else ""
            lines.extend(
                _wrap(f"- row {row.row_number} {label}{column}: {row.reason}", width, indent=2)
            )
        lines.append("")

        lines.extend(_section(3, "FIELD AND COORDINATE MAPPING", width))
        for column in sorted(self.field_mapping):
            lines.extend(_kv(column, self.field_mapping[column], width))
        for column in sorted(self.coordinate_mapping):
            detail = self.coordinate_mapping[column]
            rendered = ", ".join(f"{k}={detail[k]}" for k in sorted(detail))
            lines.extend(_kv(f"coordinate {column}", rendered, width))
        for column in sorted(self.quantity_mappings):
            lines.extend(_kv(f"quantity {column}", self.quantity_mappings[column], width))
        lines.append("")

        lines.extend(_section(4, "IDENTITY, DUPLICATES, AND UNSUPPORTED FIELDS", width))
        lines.extend(_kv("identity policy", self.identity_policy, width))
        lines.extend(_kv("duplicate handling", self.duplicate_handling, width))
        lines.extend(_kv("unit conversions", _listing(self.unit_conversions), width))
        lines.extend(_kv("dropped fields", _listing(self.dropped_fields), width))
        lines.extend(_kv("unsupported fields", _listing(self.unsupported_fields), width))
        lines.extend(_kv("inferred fields", _listing(self.inferred_fields), width))
        lines.extend(_kv("user overrides", _listing(self.user_overrides), width))
        lines.extend(_kv("missing evidence", _listing(self.missing_evidence), width))
        lines.append("")

        lines.extend(_section(5, "WARNINGS", width))
        if self.warnings:
            for warning in self.warnings:
                lines.extend(_wrap(f"! {warning}", width, indent=2))
        else:
            lines.append("  (none)")
        lines.append(_rule("=", width))
        return "\n".join(lines) + "\n"

    def __str__(self) -> str:  # pragma: no cover - display only
        return self.render()


def _listing(values: Iterable[str]) -> str:
    values = list(values)
    return ", ".join(values) if values else "(none)"


# ---------------------------------------------------------------------------
# the importer (spec 37.5 reference importer 1)
# ---------------------------------------------------------------------------

#: Attribute columns promoted to first-class record fields (spec 37.3).
EVIDENCE_COLUMNS = ("evidence_class", "evidence")
LEGALITY_COLUMNS = ("legality", "feasibility", "feasibility_status")
_LEGAL_TOKENS = {
    "LEGAL": "LEGAL",
    "FEASIBLE": "LEGAL",
    "TRUE": "LEGAL",
    "YES": "LEGAL",
    "ILLEGAL": "ILLEGAL",
    "INFEASIBLE": "INFEASIBLE",
    "FALSE": "INFEASIBLE",
    "NO": "INFEASIBLE",
    "UNKNOWN": "UNEVALUATED",
}


def default_completeness(
    source_path: str, fingerprint: str, rejected_count: int = 0
) -> CompletenessBasis:
    """The only basis a table import may assert (spec 21.2, 37.6)."""
    omissions: List[str] = [
        "candidates absent from the imported table are not represented and are not claimed",
    ]
    if rejected_count:
        omissions.append(
            f"{rejected_count} source row(s) were refused and are not represented; "
            "see the import report"
        )
    return CompletenessBasis(
        basis_type=CompletenessBasisType.EXPLICIT_IMPORTED_FAMILY,
        declared_universe=f"explicitly imported candidates from {os.path.basename(source_path)}",
        source_or_generator_hash=fingerprint,
        generator_versions=(f"{IMPORTER_ID}@{IMPORTER_VERSION}",),
        closure_procedure=(
            "tabular import: the family is exactly the accepted rows of the source table; "
            "no closure or enumeration argument is claimed (spec 37.1)"
        ),
        known_omissions=tuple(omissions),
    )


def _check_completeness(basis: CompletenessBasis) -> None:
    """Refuse a completeness claim an import cannot support (spec 21.2, 21.6)."""
    if basis.basis_type == CompletenessBasisType.EXHAUSTIVE_DECLARED_UNIVERSE and not (
        basis.closure_proof
    ):
        raise ImportProfileError(
            "a table import cannot establish EXHAUSTIVE_DECLARED_UNIVERSE: reading a file "
            "proves what the file contains, not that the declared universe was enumerated. "
            "Supply a closure proof with the basis, or use EXPLICIT_IMPORTED_FAMILY "
            "(spec 21.2, 21.6)."
        )
    if basis.basis_type == CompletenessBasisType.GENERATOR_CLOSED and not basis.closure_procedure:
        raise ImportProfileError(
            "GENERATOR_CLOSED requires a declared closure procedure (spec 21.3)"
        )


def import_tabular(
    path: Union[str, os.PathLike],
    *,
    schema: CoordinateSchema,
    id_column: str,
    coordinate_columns: Union[Mapping[str, str], Sequence[str]],
    attribute_columns: Sequence[str] = (),
    completeness: Optional[CompletenessBasis] = None,
) -> Tuple[RealizationBundle, ImportReport]:
    """Import a CSV/TSV candidate table into a bundle and a report (spec 37).

    ``coordinate_columns`` is either ``{source column: coordinate identifier}``
    or a sequence of source column names whose coordinate identifiers equal the
    column names.  Every coordinate of ``schema`` MUST be covered; a coordinate
    the table does not carry is a structural error, because a signature with a
    guessed component is not a signature.

    ``MAXIMIZE`` coordinates are negated on the way in so that the stored
    signature is in the single minimise convention that dominance and Pareto
    logic use (see ``crg_model.records.Signature``).  The negation is recorded
    in :attr:`ImportReport.coordinate_mapping` and as a warning, because a
    silent sign change would be exactly the kind of hidden transformation this
    specification forbids.

    Returns ``(bundle, report)``.  The bundle's completeness basis defaults to
    ``EXPLICIT_IMPORTED_FAMILY``.
    """
    source_path = os.fspath(path)
    raw = _read_bytes(source_path)
    fingerprint = file_fingerprint(raw)
    header, records = _rows(source_path, raw)

    mapping = _normalize_coordinate_columns(coordinate_columns)
    warnings: List[str] = []
    inferred: List[str] = []

    if id_column not in header:
        raise ImportProfileError(
            f"identity column {id_column!r} is absent from the source header; "
            f"columns are: {', '.join(header)}"
        )
    missing_columns = [column for column in mapping if column not in header]
    if missing_columns:
        raise ImportProfileError(
            "coordinate columns absent from the source header: "
            + ", ".join(sorted(missing_columns))
            + f"; columns are: {', '.join(header)}"
        )
    declared = set(schema.identifiers)
    mapped = set(mapping.values())
    if mapped - declared:
        raise ImportProfileError(
            "coordinate identifiers not present in the declared schema: "
            + ", ".join(sorted(mapped - declared))
        )
    if declared - mapped:
        raise ImportProfileError(
            "the source does not carry every declared coordinate; unmapped: "
            + ", ".join(sorted(declared - mapped))
            + " (spec 19.1: a signature has no optional components)"
        )

    index_of = {name: position for position, name in enumerate(header)}
    coordinate_order = list(schema.identifiers)
    column_for = {identifier: column for column, identifier in mapping.items()}
    coordinate_by_id = {c.identifier: c for c in schema.coordinates}

    attribute_columns = tuple(attribute_columns)
    unknown_attributes = [c for c in attribute_columns if c not in header]
    if unknown_attributes:
        raise ImportProfileError(
            "attribute columns absent from the source header: "
            + ", ".join(sorted(unknown_attributes))
        )

    consumed = {id_column, *mapping.keys(), *attribute_columns}
    dropped = tuple(sorted(name for name in header if name not in consumed))
    if dropped:
        warnings.append(
            "source columns present but not imported (they remain unsupported rather than "
            "guessed, spec 37.3): " + ", ".join(dropped)
        )

    field_mapping: Dict[str, str] = {id_column: "realization_id"}
    coordinate_mapping: Dict[str, Dict[str, str]] = {}
    quantity_mappings: Dict[str, str] = {}
    for identifier in coordinate_order:
        coordinate = coordinate_by_id[identifier]
        column = column_for[identifier]
        detail = {
            "coordinate": identifier,
            "quantity": coordinate.quantity,
            "unit": coordinate.unit,
            "direction": coordinate.direction,
        }
        if coordinate.direction == Direction.MAXIMIZE:
            detail["orientation"] = "NEGATED_INTO_MINIMIZE_CONVENTION"
            warnings.append(
                f"coordinate {identifier!r} is declared MAXIMIZE; stored signature values "
                "are negated into the canonical minimise convention"
            )
        else:
            detail["orientation"] = "AS_DECLARED"
        coordinate_mapping[column] = detail
        field_mapping[column] = f"signature.{identifier}"
        quantity_mappings[identifier] = f"{coordinate.quantity} [{coordinate.unit}]"

    evidence_column: Optional[str] = None
    legality_column: Optional[str] = None
    for column in attribute_columns:
        lowered = column.strip().lower()
        if lowered in EVIDENCE_COLUMNS and evidence_column is None:
            evidence_column = column
            field_mapping[column] = "evidence_class"
        elif lowered in LEGALITY_COLUMNS and legality_column is None:
            legality_column = column
            field_mapping[column] = "legality"
        else:
            field_mapping[column] = f"attributes.{column}"

    accepted: List[str] = []
    rejected: List[RejectedRow] = []
    missing_evidence: List[str] = []
    realizations: List[RealizationRecord] = []
    seen: Dict[str, int] = {}

    for offset, row in enumerate(records):
        # Row 1 is the header, so data rows start at 2.
        row_number = offset + 2
        raw_text = ",".join(cell.strip() for cell in row)
        if len(row) < len(header):
            rejected.append(
                RejectedRow(
                    row_number=row_number,
                    realization_id=None,
                    reason=(
                        f"row has {len(row)} cells but the header declares {len(header)}; "
                        "short rows are refused rather than padded with zeros (spec 37.3)"
                    ),
                    raw=raw_text,
                )
            )
            continue
        if len(row) > len(header):
            rejected.append(
                RejectedRow(
                    row_number=row_number,
                    realization_id=None,
                    reason=(
                        f"row has {len(row)} cells but the header declares {len(header)}; "
                        "surplus cells cannot be attributed to a column"
                    ),
                    raw=raw_text,
                )
            )
            continue

        realization_id = row[index_of[id_column]].strip()
        if not realization_id:
            rejected.append(
                RejectedRow(
                    row_number=row_number,
                    realization_id=None,
                    reason=f"empty identity cell in column {id_column!r} (spec 14.1)",
                    column=id_column,
                    raw=raw_text,
                )
            )
            continue
        if realization_id in seen:
            rejected.append(
                RejectedRow(
                    row_number=row_number,
                    realization_id=realization_id,
                    reason=(
                        f"duplicate realization id; first seen at row {seen[realization_id]}. "
                        "Identity must be unique within an imported family (spec 14.1); the "
                        "duplicate is refused, not merged and not overwritten."
                    ),
                    column=id_column,
                    raw=raw_text,
                )
            )
            continue

        values: List[Exact] = []
        failure: Optional[RejectedRow] = None
        for identifier in coordinate_order:
            column = column_for[identifier]
            cell = row[index_of[column]]
            try:
                value = parse_exact(cell)
            except ExactParseError as exc:
                failure = RejectedRow(
                    row_number=row_number,
                    realization_id=realization_id,
                    reason=f"coordinate {identifier!r}: {exc}",
                    column=column,
                    raw=raw_text,
                )
                break
            if coordinate_by_id[identifier].direction == Direction.MAXIMIZE:
                value = -value
            values.append(value)
        if failure is not None:
            rejected.append(failure)
            continue

        evidence_class = EvidenceClass.IMPORTED
        if evidence_column is not None:
            token = row[index_of[evidence_column]].strip().upper()
            if not token:
                missing_evidence.append(
                    f"{realization_id}: no evidence class declared; defaulted to IMPORTED"
                )
            elif token not in EvidenceClass.ALL:
                rejected.append(
                    RejectedRow(
                        row_number=row_number,
                        realization_id=realization_id,
                        reason=(
                            f"unknown evidence class {token!r}; the distinct classes of "
                            "spec 5.3 are: " + ", ".join(sorted(EvidenceClass.ALL))
                        ),
                        column=evidence_column,
                        raw=raw_text,
                    )
                )
                continue
            else:
                evidence_class = token

        # Absence of a legality/feasibility result is not evidence of
        # legality.  Keep the candidate visible but outside exact R until an
        # evaluator supplies a verdict (spec 28.6, 37.3).
        legality = "UNEVALUATED"
        if legality_column is not None:
            token = row[index_of[legality_column]].strip().upper()
            if token and token not in _LEGAL_TOKENS:
                rejected.append(
                    RejectedRow(
                        row_number=row_number,
                        realization_id=realization_id,
                        reason=(
                            f"unrecognised feasibility token {token!r}; expected one of: "
                            + ", ".join(sorted(_LEGAL_TOKENS))
                        ),
                        column=legality_column,
                        raw=raw_text,
                    )
                )
                continue
            if token:
                legality = _LEGAL_TOKENS[token]
            else:
                missing_evidence.append(
                    f"{realization_id}: no feasibility verdict declared; kept UNEVALUATED"
                )
        else:
            missing_evidence.append(
                f"{realization_id}: no feasibility column declared; kept UNEVALUATED"
            )

        attributes: Dict[str, Any] = {}
        for column in attribute_columns:
            if column in {evidence_column, legality_column}:
                continue
            cell = row[index_of[column]].strip()
            if cell == "":
                # 37.3: missing MUST remain missing, never zero, never "".
                missing_evidence.append(f"{realization_id}: attribute {column!r} is absent")
                continue
            attributes[column] = cell

        realizations.append(
            RealizationRecord(
                realization_id=realization_id,
                signature=Signature(values),
                attributes=attributes,
                legality=legality,
                evidence_class=evidence_class,
                generator=f"{IMPORTER_ID}@{IMPORTER_VERSION}",
            )
        )
        seen[realization_id] = row_number
        accepted.append(realization_id)

    if completeness is None:
        basis = default_completeness(source_path, fingerprint, len(rejected))
        inferred.append("completeness_basis = EXPLICIT_IMPORTED_FAMILY (import default)")
        overrides: Tuple[str, ...] = ()
    else:
        _check_completeness(completeness)
        basis = completeness
        overrides = (f"completeness_basis = {completeness.basis_type} (caller supplied)",)
        if basis.basis_type != CompletenessBasisType.EXPLICIT_IMPORTED_FAMILY:
            warnings.append(
                f"the caller overrode the import completeness basis to {basis.basis_type}; "
                "the evidence for that claim is the caller's, not this importer's (spec 21.3)"
            )

    if not accepted:
        warnings.append(
            "no row was accepted; the imported family is empty and no decision can be "
            "certified over it (spec 22.7, 6.6)"
        )
    if rejected:
        warnings.append(
            f"{len(rejected)} of {len(records)} source rows were refused and are retained in "
            "the bundle's rejection record; they are absent from the represented family"
        )

    bundle = RealizationBundle(
        bundle_id=f"registry-{fingerprint.split(':', 1)[1][:16]}",
        schema=schema,
        realizations=realizations,
        completeness=basis,
        rejected=[row.to_dict() for row in rejected],
        source_fingerprint=fingerprint,
    )

    report = ImportReport(
        source_path=source_path,
        source_fingerprint=fingerprint,
        rows_read=len(records),
        accepted=tuple(accepted),
        rejected=tuple(rejected),
        field_mapping=field_mapping,
        coordinate_mapping=coordinate_mapping,
        quantity_mappings=quantity_mappings,
        unit_conversions=(
            "none applied; every coordinate is imported in its declared source unit "
            "(spec 13.1)",
        ),
        dropped_fields=dropped,
        unsupported_fields=dropped,
        duplicate_handling=(
            "REJECT_DUPLICATE_ID: the first occurrence is kept and every later row with the "
            "same identity is refused with a reason"
        ),
        identity_policy=(
            f"verbatim from column {id_column!r}; identities must be unique and non-empty"
        ),
        missing_evidence=tuple(missing_evidence),
        inferred_fields=tuple(inferred),
        user_overrides=overrides,
        warnings=tuple(warnings),
        completeness_basis=basis,
        claim_scope=derive_claim_scope(basis),
        canonical_output_hash=bundle.bundle_hash(),
        bundle_id=bundle.bundle_id,
    )
    return bundle, report


# ---------------------------------------------------------------------------
# structured-registry helpers shared by the JSON and mapping-export importers
# ---------------------------------------------------------------------------

#: Keys accepted as the candidate identity, in precedence order (spec 14.1).
_ID_KEYS: Tuple[str, ...] = ("realization_id", "candidate_id", "id", "name", "candidate")
#: Per-record keys the structured importers understand; anything else is
#: carried into the report as an unsupported field rather than guessed at.
_RESERVED_RECORD_KEYS = frozenset(
    _ID_KEYS
    + (
        "signature", "coordinates", "attributes", "realization_metadata",
        "evidence_class", "evidence", "legality", "feasibility", "feasibility_status",
        "source", "source_reference", "technology_context", "context", "uncertainty",
        "dependencies", "coordinate_evidence",
        "completeness_basis", "completeness",
    )
)
_FEASIBILITY_KEYS = ("legality", "feasibility", "feasibility_status")


def _record_identity(record: Mapping[str, Any]) -> Optional[str]:
    for key in _ID_KEYS:
        if key not in record:
            continue
        value = record[key]
        # ``None`` and booleans must not become the invented identities
        # ``"None"``/``"True"`` merely because Python can stringify them.
        if value is None or isinstance(value, bool):
            continue
        if isinstance(value, (str, int)) and str(value).strip():
            return str(value).strip()
    return None


def _record_coordinate_source(record: Mapping[str, Any]) -> Any:
    """The object a record's signature is read from (``signature`` or ``coordinates``)."""
    if "signature" in record:
        return record["signature"]
    if "coordinates" in record:
        return record["coordinates"]
    return None


def _coordinate_value(source: Any, identifier: str, position: int) -> Tuple[bool, Any]:
    """Return ``(present, raw_value)`` for one coordinate of a record.

    A ``signature`` list is positional against the declared schema order; a
    ``signature``/``coordinates`` mapping is keyed by coordinate identifier. The
    section 37.6 nested form ``{value: ..., evidence_class: ...}`` is unwrapped
    to its ``value``.  A coordinate the record does not carry is *absent*, and
    absent stays absent -- the caller rejects the row rather than invent a zero
    (spec 37.3, 19.1).
    """
    if isinstance(source, (list, tuple)):
        if position < len(source):
            return True, source[position]
        return False, None
    if isinstance(source, Mapping):
        if identifier not in source:
            return False, None
        cell = source[identifier]
        if isinstance(cell, Mapping):
            if "value" not in cell:
                return False, None
            return True, cell["value"]
        return True, cell
    return False, None


def _infer_schema_from_records(records: Sequence[Mapping[str, Any]]) -> CoordinateSchema:
    """Infer a minimise-convention schema from the first record's coordinate keys.

    Inference is a first-run convenience only (spec 13.1, mirroring
    :func:`infer_schema`): the direction defaults to ``MINIMIZE``, the unit is
    declared unknown (dimensionless), and the coordinate order is the sorted key
    order so that two runs of the same data agree.  A ``signature`` given as a
    bare list cannot be inferred from, because a list carries no identifiers.
    """
    for record in records:
        source = _record_coordinate_source(record)
        if isinstance(source, Mapping) and source:
            identifiers = sorted(str(k) for k in source)
            return CoordinateSchema(
                coordinates=tuple(
                    Coordinate(identifier=i, quantity=i, unit=DIMENSIONLESS,
                               direction=Direction.MINIMIZE)
                    for i in identifiers
                )
            )
        if isinstance(source, (list, tuple)):
            raise ImportProfileError(
                "a signature given as a bare list carries no coordinate identifiers, so a "
                "schema cannot be inferred; declare a schema or key the signature by coordinate"
            )
    raise ImportProfileError("no record carries a signature from which to infer a schema")


def _feasibility_token(record: Mapping[str, Any]) -> Optional[str]:
    for key in _FEASIBILITY_KEYS:
        if key in record and record[key] is not None and str(record[key]).strip():
            return str(record[key]).strip()
    return None


def _import_records(
    records: Sequence[Mapping[str, Any]],
    *,
    schema: CoordinateSchema,
    source_path: str,
    fingerprint: str,
    importer_id: str,
    importer_version: str,
    format_label: str,
    completeness: Optional[CompletenessBasis],
    inferred_schema: bool,
    default_evidence_class: str = EvidenceClass.IMPORTED,
) -> Tuple[RealizationBundle, ImportReport]:
    """Turn already-parsed structured records into a bundle and an import report.

    This is the shared workhorse behind :func:`import_json` and
    :func:`import_mapping_export`.  Every property of the tabular importer holds
    here too: numerics are parsed to exact rationals or the row is refused with a
    per-row reason (14.2, 6.11); a ``MAXIMIZE`` coordinate is negated into the
    canonical minimise convention and the negation is disclosed; the completeness
    basis is ``EXPLICIT_IMPORTED_FAMILY`` and no import may assert closure
    (21.2); and a missing optional field stays missing rather than becoming zero
    (37.3).
    """
    coordinate_order = list(schema.identifiers)
    coordinate_by_id = {c.identifier: c for c in schema.coordinates}

    coordinate_mapping: Dict[str, Dict[str, str]] = {}
    quantity_mappings: Dict[str, str] = {}
    field_mapping: Dict[str, str] = {"(identity)": "realization_id"}
    warnings: List[str] = []
    for identifier in coordinate_order:
        coordinate = coordinate_by_id[identifier]
        detail = {
            "coordinate": identifier,
            "quantity": coordinate.quantity,
            "unit": coordinate.unit,
            "direction": coordinate.direction,
        }
        if coordinate.direction == Direction.MAXIMIZE:
            detail["orientation"] = "NEGATED_INTO_MINIMIZE_CONVENTION"
            warnings.append(
                f"coordinate {identifier!r} is declared MAXIMIZE; stored signature values "
                "are negated into the canonical minimise convention"
            )
        else:
            detail["orientation"] = "AS_DECLARED"
        coordinate_mapping[identifier] = detail
        field_mapping[identifier] = f"signature.{identifier}"
        quantity_mappings[identifier] = f"{coordinate.quantity} [{coordinate.unit}]"

    accepted: List[str] = []
    rejected: List[RejectedRow] = []
    missing_evidence: List[str] = []
    realizations: List[RealizationRecord] = []
    seen: Dict[str, int] = {}
    unsupported: set = set()

    for offset, record in enumerate(records):
        row_number = offset + 1
        if not isinstance(record, Mapping):
            rejected.append(RejectedRow(
                row_number=row_number, realization_id=None,
                reason=f"record is a {type(record).__name__}, not an object with named fields",
                raw=repr(record)[:120],
            ))
            continue
        raw_text = json.dumps(record, sort_keys=True, default=str)[:200]
        realization_id = _record_identity(record)
        if realization_id is None:
            rejected.append(RejectedRow(
                row_number=row_number, realization_id=None,
                reason=(
                    "no non-empty identity field; declare one of "
                    + ", ".join(_ID_KEYS) + " (spec 14.1: CRG will not invent an identity)"
                ),
                raw=raw_text,
            ))
            continue
        if realization_id in seen:
            rejected.append(RejectedRow(
                row_number=row_number, realization_id=realization_id,
                reason=(
                    f"duplicate realization id; first seen at record {seen[realization_id]}. "
                    "The duplicate is refused, not merged and not overwritten (spec 14.1)"
                ),
                raw=raw_text,
            ))
            continue

        for key in record:
            if str(key) not in _RESERVED_RECORD_KEYS:
                unsupported.add(str(key))

        source = _record_coordinate_source(record)
        if source is None:
            rejected.append(RejectedRow(
                row_number=row_number, realization_id=realization_id,
                reason="record carries neither a 'signature' nor a 'coordinates' field",
                raw=raw_text,
            ))
            continue

        values: List[Exact] = []
        failure: Optional[RejectedRow] = None
        for position, identifier in enumerate(coordinate_order):
            present, raw_value = _coordinate_value(source, identifier, position)
            if not present:
                failure = RejectedRow(
                    row_number=row_number, realization_id=realization_id,
                    reason=(
                        f"coordinate {identifier!r} is absent; a signature has no optional "
                        "components and a missing coordinate is never defaulted (spec 19.1, 37.3)"
                    ),
                    column=identifier, raw=raw_text,
                )
                break
            try:
                value = parse_exact_value(raw_value, field_name=f"coordinate {identifier!r}")
            except ExactParseError as exc:
                failure = RejectedRow(
                    row_number=row_number, realization_id=realization_id,
                    reason=str(exc), column=identifier, raw=raw_text,
                )
                break
            if coordinate_by_id[identifier].direction == Direction.MAXIMIZE:
                value = -value
            values.append(value)
        if failure is not None:
            rejected.append(failure)
            continue

        evidence_class = default_evidence_class
        declared_evidence = record.get("evidence_class") or record.get("evidence")
        if declared_evidence is not None and str(declared_evidence).strip():
            token = str(declared_evidence).strip().upper()
            if token not in EvidenceClass.ALL:
                rejected.append(RejectedRow(
                    row_number=row_number, realization_id=realization_id,
                    reason=(
                        f"unknown evidence class {token!r}; the distinct classes of spec 5.3 "
                        "are: " + ", ".join(sorted(EvidenceClass.ALL))
                    ),
                    column="evidence_class", raw=raw_text,
                ))
                continue
            evidence_class = token
        else:
            missing_evidence.append(
                f"{realization_id}: no evidence class declared; defaulted to {evidence_class}"
            )

        legality = "UNEVALUATED"
        feasibility = _feasibility_token(record)
        if feasibility is not None:
            token = feasibility.upper()
            if token not in _LEGAL_TOKENS:
                rejected.append(RejectedRow(
                    row_number=row_number, realization_id=realization_id,
                    reason=(
                        f"unrecognised feasibility token {token!r}; expected one of: "
                        + ", ".join(sorted(_LEGAL_TOKENS))
                    ),
                    column="legality", raw=raw_text,
                ))
                continue
            legality = _LEGAL_TOKENS[token]
        else:
            missing_evidence.append(
                f"{realization_id}: no feasibility verdict declared; kept UNEVALUATED"
            )

        attributes: Dict[str, Any] = {}
        for container in ("attributes", "realization_metadata"):
            block = record.get(container)
            if isinstance(block, Mapping):
                for key, cell in block.items():
                    if cell in (None, ""):
                        # 37.3: a missing attribute stays missing, never "".
                        missing_evidence.append(
                            f"{realization_id}: attribute {key!r} is absent"
                        )
                        continue
                    attributes[str(key)] = cell

        # Section 37.3's optional provenance/context/uncertainty/dependency
        # fields have no dedicated slot in the v0.2.0 RealizationRecord.  They
        # are therefore preserved losslessly as named attributes rather than
        # being silently discarded.  Coordinate-scoped evidence in the 37.6
        # nested form is preserved separately from the exact point value.
        for key in (
            "source", "source_reference", "technology_context", "context",
            "uncertainty", "dependencies", "coordinate_evidence",
        ):
            if key in record and record[key] not in (None, ""):
                attributes[key] = record[key]
        if isinstance(source, Mapping):
            nested_evidence: Dict[str, Any] = {}
            for identifier in coordinate_order:
                cell = source.get(identifier)
                if isinstance(cell, Mapping):
                    detail = {str(k): v for k, v in cell.items() if str(k) != "value"}
                    if detail:
                        nested_evidence[identifier] = detail
            if nested_evidence:
                prior = attributes.get("coordinate_evidence")
                if isinstance(prior, Mapping):
                    nested_evidence = {**dict(prior), **nested_evidence}
                attributes["coordinate_evidence"] = nested_evidence

        realizations.append(RealizationRecord(
            realization_id=realization_id,
            signature=Signature(values),
            attributes=attributes,
            legality=legality,
            evidence_class=evidence_class,
            generator=f"{importer_id}@{importer_version}",
        ))
        seen[realization_id] = row_number
        accepted.append(realization_id)

    inferred: List[str] = []
    if inferred_schema:
        inferred.append(
            "coordinate schema inferred from record keys (MINIMIZE, dimensionless); "
            "the caller remains responsible for it (spec 13.1)"
        )
    if completeness is None:
        basis = default_completeness(source_path, fingerprint, len(rejected))
        inferred.append("completeness_basis = EXPLICIT_IMPORTED_FAMILY (import default)")
        overrides: Tuple[str, ...] = ()
    else:
        _check_completeness(completeness)
        basis = completeness
        overrides = (f"completeness_basis = {completeness.basis_type} (caller supplied)",)
        if basis.basis_type != CompletenessBasisType.EXPLICIT_IMPORTED_FAMILY:
            warnings.append(
                f"the caller overrode the import completeness basis to {basis.basis_type}; "
                "the evidence for that claim is the caller's, not this importer's (spec 21.3)"
            )

    if not accepted:
        warnings.append(
            "no record was accepted; the imported family is empty and no decision can be "
            "certified over it (spec 22.7, 6.6)"
        )
    if rejected:
        warnings.append(
            f"{len(rejected)} of {len(records)} records were refused and are retained in the "
            "bundle's rejection record; they are absent from the represented family"
        )

    bundle = RealizationBundle(
        bundle_id=f"registry-{fingerprint.split(':', 1)[1][:16]}",
        schema=schema,
        realizations=realizations,
        completeness=basis,
        rejected=[row.to_dict() for row in rejected],
        source_fingerprint=fingerprint,
    )
    report = ImportReport(
        source_path=source_path,
        source_fingerprint=fingerprint,
        importer_id=importer_id,
        importer_version=importer_version,
        rows_read=len(records),
        accepted=tuple(accepted),
        rejected=tuple(rejected),
        field_mapping=field_mapping,
        coordinate_mapping=coordinate_mapping,
        quantity_mappings=quantity_mappings,
        unit_conversions=(
            f"none applied; every coordinate is imported in its declared source unit via the "
            f"{format_label} (spec 13.1)",
        ),
        dropped_fields=tuple(sorted(unsupported)),
        unsupported_fields=tuple(sorted(unsupported)),
        duplicate_handling=(
            "REJECT_DUPLICATE_ID: the first occurrence is kept and every later record with the "
            "same identity is refused with a reason"
        ),
        identity_policy=(
            "verbatim from the first present of " + ", ".join(_ID_KEYS)
            + "; identities must be unique and non-empty"
        ),
        missing_evidence=tuple(missing_evidence),
        inferred_fields=tuple(inferred),
        user_overrides=overrides,
        warnings=tuple(warnings),
        completeness_basis=basis,
        claim_scope=derive_claim_scope(basis),
        canonical_output_hash=bundle.bundle_hash(),
        bundle_id=bundle.bundle_id,
    )
    return bundle, report


# ---------------------------------------------------------------------------
# canonical JSON registry importer (spec 37.2 canonical JSON, 37.5)
# ---------------------------------------------------------------------------


def _load_json_document(path: Union[str, os.PathLike]) -> Tuple[Any, str, str]:
    source_path = os.fspath(path)
    raw = _read_bytes(source_path)
    fingerprint = file_fingerprint(raw)
    try:
        document = json.loads(_decode(raw))
    except json.JSONDecodeError as exc:
        raise ImportProfileError(f"source is not valid JSON: {exc}") from exc
    return document, source_path, fingerprint


def _records_of(document: Any) -> List[Any]:
    if isinstance(document, list):
        return list(document)
    if isinstance(document, Mapping):
        for key in ("realizations", "records", "rows", "candidates"):
            if key in document:
                block = document[key]
                if not isinstance(block, (list, tuple)):
                    raise ImportProfileError(f"{key!r} must be a list of realization records")
                return list(block)
        raise ImportProfileError(
            "a JSON registry object must carry a 'realizations' (or 'records'/'candidates') list"
        )
    raise ImportProfileError("a JSON registry is a list of records or an object carrying one")


def _schema_from_document(schema_spec: Mapping[str, Any]) -> CoordinateSchema:
    coordinates = schema_spec.get("coordinates")
    if not coordinates:
        raise ImportProfileError("a declared schema must carry a non-empty 'coordinates' list")
    built: List[Coordinate] = []
    for entry in coordinates:
        identifier = str(entry["identifier"])
        built.append(Coordinate(
            identifier=identifier,
            quantity=str(entry.get("quantity", identifier)),
            unit=str(entry.get("unit", DIMENSIONLESS)),
            direction=str(entry.get("direction", Direction.MINIMIZE)),
            accounting_scope=entry.get("accounting_scope"),
        ))
    return CoordinateSchema(coordinates=tuple(built))


def import_json(
    path: Union[str, os.PathLike],
    *,
    schema: Optional[CoordinateSchema] = None,
    completeness: Optional[CompletenessBasis] = None,
) -> Tuple[RealizationBundle, ImportReport]:
    """Import a canonical-JSON realization registry (spec 37.2, 37.5).

    The document is either a JSON list of realization records or an object with
    a ``realizations`` list (``records``/``rows``/``candidates`` are accepted
    aliases) and an optional ``schema``.  Each record carries an identity, a
    signature -- as ``{coordinate: value}``, as a positional list in the declared
    schema order, or as the section 37.6 nested ``coordinates`` form -- and
    optional ``attributes``, ``evidence_class`` and ``legality``.

    Numerics are exact-rational only: a value written as a quoted string is read
    by the 14.2 grammar (``"2.25"``, ``"225e-2"``, ``"9/4"``), a JSON integer is
    kept exactly, and a **bare JSON float is refused** because it has already
    lost the value's exact identity (see :func:`parse_exact_value`).  The
    completeness basis is ``EXPLICIT_IMPORTED_FAMILY`` and nothing stronger
    (21.2); ``schema`` (argument) overrides a document schema, and with neither
    present the schema is inferred from the first record's coordinate keys.

    Returns ``(bundle, report)``.
    """
    document, source_path, fingerprint = _load_json_document(path)
    records = _records_of(document)
    doc_schema = document.get("schema") if isinstance(document, Mapping) else None

    inferred_schema = False
    if schema is not None:
        resolved = schema
    elif doc_schema is not None:
        resolved = _schema_from_document(doc_schema)
    elif records:
        resolved = _infer_schema_from_records([r for r in records if isinstance(r, Mapping)])
        inferred_schema = True
    else:
        raise ImportProfileError("the JSON registry declares no records to import")

    # A common canonical-table JSON representation uses one named field per
    # coordinate (the same mapping as CSV) rather than nesting under
    # ``signature``.  Normalize that shape explicitly when every declared
    # coordinate is present.  Partial flat rows are left untouched so the
    # shared importer reports the missing signature instead of inventing one.
    normalized_records: List[Any] = []
    for record in records:
        if (
            isinstance(record, Mapping)
            and _record_coordinate_source(record) is None
            and all(identifier in record for identifier in resolved.identifiers)
        ):
            normalized = dict(record)
            normalized["signature"] = {
                identifier: normalized.pop(identifier) for identifier in resolved.identifiers
            }
            normalized_records.append(normalized)
        else:
            normalized_records.append(record)

    return _import_records(
        normalized_records,
        schema=resolved,
        source_path=source_path,
        fingerprint=fingerprint,
        importer_id=JSON_IMPORTER_ID,
        importer_version=IMPORTER_VERSION,
        format_label="canonical JSON registry importer",
        completeness=completeness,
        inferred_schema=inferred_schema,
    )


# ---------------------------------------------------------------------------
# Timeloop-/ZigZag-family mapping-export importer (spec 37.2, 37.5 importer 2)
# ---------------------------------------------------------------------------

#: External mapping-export shapes this reference importer recognises.  A mapping
#: export is a list of evaluated mappings, each with a mapping identity, a
#: ``metrics`` block of modelled figures of merit, and an opaque ``mapping``
#: descriptor (loop nest, tiling, spatial factors).  Timeloop and ZigZag both
#: emit this shape; the schema below is the documented normal form.
MAPPING_FORMATS: Tuple[str, ...] = (
    "timeloop-mapping-export",
    "zigzag-mapping-export",
    "mapping-export",
)


def _mapping_objectives(
    document: Mapping[str, Any], mappings: Sequence[Mapping[str, Any]]
) -> Tuple[CoordinateSchema, List[Tuple[str, str]], bool]:
    """Resolve the coordinate schema and ``(metric -> coordinate)`` map.

    An explicit ``objectives`` list is authoritative; otherwise every metric of
    the first mapping whose value reads as an exact rational becomes a
    minimise-convention coordinate, and the choice is disclosed as inferred.
    """
    declared = document.get("objectives")
    if declared:
        built: List[Coordinate] = []
        metric_to_coordinate: List[Tuple[str, str]] = []
        for entry in declared:
            metric = str(entry["metric"])
            coordinate = str(entry.get("coordinate", metric))
            built.append(Coordinate(
                identifier=coordinate,
                quantity=str(entry.get("quantity", metric)),
                unit=str(entry.get("unit", DIMENSIONLESS)),
                direction=str(entry.get("direction", Direction.MINIMIZE)),
            ))
            metric_to_coordinate.append((metric, coordinate))
        return CoordinateSchema(coordinates=tuple(built)), metric_to_coordinate, False

    if not mappings:
        raise ImportProfileError("the mapping export declares no mappings to import")
    first_metrics = mappings[0].get("metrics")
    if not isinstance(first_metrics, Mapping) or not first_metrics:
        raise ImportProfileError(
            "cannot infer objectives: the first mapping carries no 'metrics' block; declare an "
            "'objectives' list of {metric, coordinate, unit, direction}"
        )
    metric_names: List[str] = []
    for metric in sorted(first_metrics):
        try:
            parse_exact_value(first_metrics[metric], field_name=f"metric {metric!r}")
        except ExactParseError:
            continue
        metric_names.append(metric)
    if not metric_names:
        raise ImportProfileError(
            "cannot infer objectives: no metric of the first mapping reads as an exact rational"
        )
    schema = CoordinateSchema(coordinates=tuple(
        Coordinate(identifier=m, quantity=m, unit=DIMENSIONLESS, direction=Direction.MINIMIZE)
        for m in metric_names
    ))
    return schema, [(m, m) for m in metric_names], True


def import_mapping_export(
    path: Union[str, os.PathLike],
    *,
    completeness: Optional[CompletenessBasis] = None,
) -> Tuple[RealizationBundle, ImportReport]:
    """Import a Timeloop-/ZigZag-family mapping export (spec 37.5 importer 2).

    Documented schema (the normal form both tools reduce to)::

        {
          "format": "timeloop-mapping-export",      # or zigzag-mapping-export
          "objectives": [                            # optional; inferred if absent
            {"metric": "cycles",   "coordinate": "latency", "unit": "cycle"},
            {"metric": "energy_pj","coordinate": "energy",  "unit": "pJ"}
          ],
          "mappings": [
            {"mapping_id": "m0",
             "metrics": {"cycles": "12400", "energy_pj": "7.5"},
             "mapping": {"loop_nest": "...", "spatial": "..."},   # -> attributes
             "valid": true},                                       # -> legality
            ...
          ]
        }

    Each evaluated mapping becomes one realization: the selected ``metrics``
    become the signature (exact rationals; a bare float is refused), the opaque
    ``mapping`` descriptor becomes attributes, and ``valid``/``feasible``
    becomes the legality.  As with every importer the basis is
    ``EXPLICIT_IMPORTED_FAMILY`` -- a set of evaluated mappings is exactly the
    explicit family it enumerates and asserts no closure over the mapping space
    (21.2).  Returns ``(bundle, report)``.
    """
    document, source_path, fingerprint = _load_json_document(path)
    if not isinstance(document, Mapping):
        raise ImportProfileError("a mapping export is a JSON object with a 'mappings' list")
    declared_format = str(document.get("format", "mapping-export")).strip().lower()
    if declared_format not in MAPPING_FORMATS:
        raise ImportProfileError(
            f"unrecognised mapping-export format {declared_format!r}; this reference importer "
            "handles: " + ", ".join(MAPPING_FORMATS)
        )
    raw_mappings = document.get("mappings")
    if not isinstance(raw_mappings, (list, tuple)):
        raise ImportProfileError("a mapping export must carry a 'mappings' list")
    mappings = [m for m in raw_mappings if isinstance(m, Mapping)]

    schema, metric_to_coordinate, inferred = _mapping_objectives(document, mappings)

    # Normalise each mapping into the generic structured-record shape the shared
    # workhorse understands: metrics -> signature, descriptor -> attributes.
    normalized: List[Dict[str, Any]] = []
    for mapping in raw_mappings:
        if not isinstance(mapping, Mapping):
            normalized.append({"__malformed__": repr(mapping)})
            continue
        metrics = mapping.get("metrics")
        signature: Dict[str, Any] = {}
        if isinstance(metrics, Mapping):
            for metric, coordinate in metric_to_coordinate:
                if metric in metrics:
                    signature[coordinate] = metrics[metric]
        record: Dict[str, Any] = {"signature": signature}
        for key in _ID_KEYS:
            if key in mapping:
                record[key] = mapping[key]
        if "mapping_id" in mapping and "realization_id" not in record:
            record["realization_id"] = mapping["mapping_id"]
        descriptor = mapping.get("mapping") or mapping.get("descriptor")
        if isinstance(descriptor, Mapping):
            record["attributes"] = dict(descriptor)
        for key in ("valid", "feasible", "legality", "feasibility", "feasibility_status"):
            if key in mapping:
                value = mapping[key]
                if isinstance(value, bool):
                    record["legality"] = "LEGAL" if value else "INFEASIBLE"
                else:
                    record["legality"] = value
                break
        if "evidence_class" in mapping:
            record["evidence_class"] = mapping["evidence_class"]
        normalized.append(record)

    bundle, report = _import_records(
        normalized,
        schema=schema,
        source_path=source_path,
        fingerprint=fingerprint,
        importer_id=MAPPING_IMPORTER_ID,
        importer_version=IMPORTER_VERSION,
        format_label=f"{declared_format} importer",
        completeness=completeness,
        inferred_schema=inferred,
    )
    return bundle, report
