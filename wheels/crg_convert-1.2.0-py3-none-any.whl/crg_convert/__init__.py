"""crg-convert: minimum-movement ownership and layout conversion (OID-CRG-004).

Reference implementation of master specification section 31.  The module
maximizes logically retained data under a change of ownership or layout and
generates the residual movement plan.

The governing law is the exact aligned-layout assignment theorem: for
equal-capacity source and target partitions of one normalized logical
space, the retained fraction is the maximum-weight bipartite assignment
``r* = max_pi sum_i |S_i ∩ T_pi(i)|`` and the moved fraction is ``1 - r*``.
When one partition count divides the other the optimum collapses to the
closed form ``min(C, C') / max(C, C')``; when it does not, the closed form
is simply wrong, and this module refuses to use it there.  At ``K = 12``,
``C = 4 -> C' = 6`` retains ``1/2``, not ``2/3``; ``C = 3 -> C' = 4``
retains ``35/72``, not ``3/4``.

Everything on this path is an exact rational.  A conversion record is a
certificate input, and the assignment instances that matter are exactly the
near-ties a floating-point implementation resolves wrongly and silently.

At the v1.2 boundary, certified typed changes may refer to conversion records,
but conversion itself remains this non-authorizing minimum-movement kernel;
no later decision authority is inferred by importing the package.
"""
from .assignment import (
    AssignmentSolution,
    ConversionError,
    FlowSolution,
    SolverFailure,
    assignment_value,
    b_matching,
    max_retention_assignment,
    min_cost_flow,
    min_cost_flow_arcs,
    solve_max_assignment,
    solve_min_assignment,
    verify_assignment,
)
from .layout import (
    COMPLETION_CHECKS,
    Layout,
    cell_overlaps,
    convert,
    is_nested,
    moved_fraction,
    nested_closed_form,
    retained_fraction,
)
from .record import (
    VERIFICATION_PROGRAM,
    BufferingPlan,
    Cell,
    CompletionCheck,
    ConversionRecord,
    DuplicationPolicy,
    LogicalSpace,
    OwnershipContract,
    ResidualRegion,
    RetainedIntersection,
    RouteStep,
    ScheduleWave,
    SecondaryReport,
    SolverEvidence,
    SolverMethod,
)
from .secondary import (
    SecondaryObjective,
    SecondaryObjectiveKind,
    SecondaryOptimumViolation,
    SecondaryOutcome,
    optimize_secondary,
)

__all__ = [
    "AssignmentSolution",
    "ConversionError",
    "FlowSolution",
    "SolverFailure",
    "assignment_value",
    "b_matching",
    "max_retention_assignment",
    "min_cost_flow",
    "min_cost_flow_arcs",
    "solve_max_assignment",
    "solve_min_assignment",
    "verify_assignment",
    "COMPLETION_CHECKS",
    "Layout",
    "cell_overlaps",
    "convert",
    "is_nested",
    "moved_fraction",
    "nested_closed_form",
    "retained_fraction",
    "VERIFICATION_PROGRAM",
    "BufferingPlan",
    "Cell",
    "CompletionCheck",
    "ConversionRecord",
    "DuplicationPolicy",
    "LogicalSpace",
    "OwnershipContract",
    "ResidualRegion",
    "RetainedIntersection",
    "RouteStep",
    "ScheduleWave",
    "SecondaryReport",
    "SolverEvidence",
    "SolverMethod",
    "SecondaryObjective",
    "SecondaryObjectiveKind",
    "SecondaryOptimumViolation",
    "SecondaryOutcome",
    "optimize_secondary",
]

__version__ = "1.2.0"
SPEC_VERSION = "0.2.0"
