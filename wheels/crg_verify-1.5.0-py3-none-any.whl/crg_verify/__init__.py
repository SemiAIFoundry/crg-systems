"""crg-verify: the independent CRG certificate verifier.

Reference implementation of master specification sections 24 (CRG-VIR) and
25 (independent certificate verifier), operating inside the verification
zone of section 9.1.

Independence is the product here, not a nicety.  This package imports the
Python standard library and no CRG kernel -- no ``crg_model``, no
``crg_geometry``, no ``crg_certify``, no ``crg_change``, no ``crg_io``.
V0--V3 load no third-party distribution.  V4 dynamically loads the optional
Ed25519 provider and fails closed when it is unavailable.  Canonicalization, hashing, exact rational
arithmetic, interval comparison, dominance, minima over generator sets, the
claim-scope table of 21.4, the decision-observation mapping of 26.4, and the
regret construction of 27.3 are each re-implemented here from the
specification text.

That is deliberate.  Specification 9.3 says the verifier MUST NOT assume the
originating solver, plugin, server, or organization is correct merely
because it issued a certificate-shaped artifact.  A verifier that called the
kernel's comparison code would inherit exactly the errors it exists to
catch; a verifier that reused the kernel's canonicalizer could never expose
a canonicalization disagreement (25.5).  So this package re-derives, and
where its re-derivation disagrees with the certificate, the certificate is
the thing that is wrong.
"""
from .arith import (
    ArithError,
    dominates,
    interval,
    minimum,
    positive_part_sup,
    rational,
    strictly_below,
    weakly_dominates,
)
from .canonical import (
    CanonicalError,
    canonical_bytes,
    canonical_json,
    content_hash,
    hash_without,
    is_hash,
)
from .certificate import (
    Level,
    Status,
    TimeStatus,
    VerificationResult,
    derive_claim_scope,
    evaluate_objective,
    required_object_for,
    verify_certificate,
)
from .bundle import verify_bundle
from .audit import AuditExportResult, audit_export_hash, verify_audit_export
from .federation import verify_federation
from .report import render_report
from .extensions import ExtensionCheckerError, ProofCheckerDeclaration, ProofCheckerRegistry
from .vir import BASELINE_OPERATIONS, VIR_VERSION, emit_vir, verify_vir
from .vir_ast import AST_VERSION, VirProgramError, evaluate_program
from .commitment import verify_safe_commitment
from .design_space import verify_agent_design_space
from .phase_delta import verify_certified_delta_record, verify_phase_analysis_record
from .phase_binding import (
    verify_certified_phase_binding,
    verify_certified_phase_consumption,
)
from .comparison import verify_comparative_workflow_evaluation
from .comparative_change import verify_comparative_change_evidence
from .cumulative_comparison import verify_cumulative_lifecycle_comparison
from .challenge import verify_decision_challenge_record
from .action_mapping import verify_action_mapping_profile
from .assessment import verify_commitment_event, verify_validation_assessment
from .transition import verify_transition_record
from .multi_agent import verify_multi_agent_operation
from .advancement import (
    reconcile_verification_results,
    verify_agent_event,
    verify_agent_transaction_receipt,
    verify_assessment_context_roots,
    verify_canonical_package,
    verify_execution_profile_contract,
    verify_execution_receipt,
    verify_resolved_profile_lock,
)
from .intake import (
    verify_registry_intake_confirmation,
    verify_registry_intake_preview,
    verify_registry_mapping_profile,
    verify_registry_source_snapshot,
)
from .source_adapter import (
    verify_source_adapter_conformance_report,
    verify_source_adapter_definition,
    verify_source_adapter_output,
)
from .pack_authoring import verify_pack_authoring_report
from .lifecycle import (
    derive_continued_validity_dimensions,
    verify_approval_record,
    verify_approval_withdrawal,
    verify_continued_validity_view,
    verify_conversion_binding_impact,
    verify_decision_scoped_conversion,
    verify_etq_decision_loop,
    verify_lifecycle_authorization,
    verify_qualification_disposition,
    verify_replacement_record,
    verify_result_ingestion_record,
    verify_selective_revalidation_record,
    verify_signature_verification_record,
)
from .resilience import (
    verify_backup_restore_recovery_record,
    verify_lifecycle_replay_record,
    verify_migration_reverification_record,
)
from .local_recovery import verify_local_admin_recovery_evidence
from .portable_lifecycle import (
    LIFECYCLE_FIRST_RELEASE_ATTRIBUTION,
    LIFECYCLE_RECORD_TYPES,
    verify_lifecycle_replay_envelope,
)

__version__ = "1.5.0"
SPEC_VERSION = "0.2.0"

__all__ = [
    "ArithError",
    "AuditExportResult",
    "AST_VERSION",
    "BASELINE_OPERATIONS",
    "CanonicalError",
    "ExtensionCheckerError",
    "Level",
    "ProofCheckerDeclaration",
    "ProofCheckerRegistry",
    "SPEC_VERSION",
    "Status",
    "TimeStatus",
    "VIR_VERSION",
    "VirProgramError",
    "VerificationResult",
    "canonical_bytes",
    "canonical_json",
    "content_hash",
    "audit_export_hash",
    "derive_claim_scope",
    "dominates",
    "emit_vir",
    "evaluate_program",
    "evaluate_objective",
    "hash_without",
    "interval",
    "is_hash",
    "minimum",
    "positive_part_sup",
    "rational",
    "render_report",
    "required_object_for",
    "strictly_below",
    "verify_bundle",
    "verify_audit_export",
    "verify_federation",
    "verify_certificate",
    "verify_certified_delta_record",
    "verify_vir",
    "verify_phase_analysis_record",
    "verify_certified_phase_binding",
    "verify_certified_phase_consumption",
    "verify_safe_commitment",
    "verify_agent_design_space",
    "verify_comparative_workflow_evaluation",
    "verify_comparative_change_evidence",
    "verify_cumulative_lifecycle_comparison",
    "verify_decision_challenge_record",
    "verify_action_mapping_profile",
    "verify_commitment_event",
    "verify_validation_assessment",
    "verify_transition_record",
    "verify_multi_agent_operation",
    "reconcile_verification_results",
    "verify_agent_event",
    "verify_assessment_context_roots",
    "verify_canonical_package",
    "verify_execution_profile_contract",
    "verify_execution_receipt",
    "verify_resolved_profile_lock",
    "verify_registry_intake_confirmation",
    "verify_registry_intake_preview",
    "verify_registry_mapping_profile",
    "verify_registry_source_snapshot",
    "verify_source_adapter_conformance_report",
    "verify_source_adapter_definition",
    "verify_source_adapter_output",
    "verify_pack_authoring_report",
    "derive_continued_validity_dimensions",
    "verify_approval_record",
    "verify_approval_withdrawal",
    "verify_continued_validity_view",
    "verify_conversion_binding_impact",
    "verify_decision_scoped_conversion",
    "verify_etq_decision_loop",
    "verify_lifecycle_authorization",
    "verify_qualification_disposition",
    "verify_replacement_record",
    "verify_result_ingestion_record",
    "verify_selective_revalidation_record",
    "verify_signature_verification_record",
    "verify_backup_restore_recovery_record",
    "verify_lifecycle_replay_record",
    "verify_migration_reverification_record",
    "verify_local_admin_recovery_evidence",
    "verify_lifecycle_replay_envelope",
    "LIFECYCLE_FIRST_RELEASE_ATTRIBUTION",
    "LIFECYCLE_RECORD_TYPES",
    "weakly_dominates",
]
