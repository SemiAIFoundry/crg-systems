"""Independent A1 package, resolution, event, and execution verification.

This module deliberately depends only on the verifier's own canonicalizer and
the Python standard library.  It does not import ``crg_generate``,
``crg_server``, or their schemas, so producer/verifier drift remains visible.
"""
from __future__ import annotations

import hashlib
import io
import json
import re
import tarfile
import unicodedata
from typing import Any, Mapping, Sequence

from .canonical import canonical_bytes, content_hash, hash_without, is_hash
from .certificate import Status, VerificationResult

__all__ = [
    "reconcile_verification_results",
    "verify_agent_event",
    "verify_agent_transaction_receipt",
    "verify_assessment_context_roots",
    "verify_canonical_package",
    "verify_execution_profile_contract",
    "verify_execution_receipt",
    "verify_resolved_profile_lock",
]

_CONTROL = "CRG-PACKAGE.json"
_MEDIA = "application/vnd.crg.package.v1.tar"
_HASH = re.compile(r"^sha256:[0-9a-f]{64}$")
_SEMVER = re.compile(r"^(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)$")
_IDENTIFIER = re.compile(r"^[a-z0-9]+(?:[._-][a-z0-9]+)*$")
_MODES = {0o644, 0o755}
_FORMS = {"DECLARATIVE", "EXECUTABLE", "AGGREGATE", "PROFILE", "DATA_RESOURCE"}
_FAILURES = {
    "OK", "SIGNATURE_ABSENT", "SIGNATURE_INVALID", "SIGNATURE_PROFILE_UNKNOWN",
    "UNKNOWN_SIGNING_KEY", "UNKNOWN_PERMISSION", "PERMISSION_NOT_DECLARED",
    "POLICY_ERROR", "FILESYSTEM_VIOLATION", "NETWORK_VIOLATION",
    "SUBPROCESS_VIOLATION", "SECRET_VIOLATION", "MODULE_NOT_ALLOWED",
    "CPU_QUOTA_EXCEEDED", "MEMORY_QUOTA_EXCEEDED", "FILESIZE_QUOTA_EXCEEDED",
    "PROCESS_QUOTA_EXCEEDED", "WALL_CLOCK_TIMEOUT", "PLUGIN_ERROR",
    "CHILD_CRASHED", "MALFORMED_CHILD_OUTPUT", "NONDETERMINISTIC_OUTPUT",
    "ENVIRONMENT_MISMATCH", "HOST_ERROR",
}


class _Invalid(ValueError):
    pass


def reconcile_verification_results(
    *, producer_accepted: bool, independent_result: VerificationResult
) -> dict[str, Any]:
    """Make producer/verifier disagreement an explicit, non-authorizing refusal."""

    if not isinstance(producer_accepted, bool) or not isinstance(independent_result, VerificationResult):
        raise TypeError("verification reconciliation requires a boolean and VerificationResult")
    agreed = producer_accepted is independent_result.ok
    return {
        "status": "AGREED" if agreed else "REFUSED_PRODUCER_VERIFIER_DISAGREEMENT",
        "producer_accepted": producer_accepted,
        "independent_accepted": independent_result.ok,
        "independent_status": independent_result.status,
        "authority": "VERIFICATION_RECONCILIATION_ONLY",
        "execution_authorized": False,
        "accepted": agreed and producer_accepted,
    }


def _keys(value: Any, fields: Sequence[str] | set[str], label: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping) or set(value) != set(fields):
        raise _Invalid(f"{label} fields differ")
    return value


def _text(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value:
        raise _Invalid(f"{label} must be non-empty text")
    return value


def _hash(value: Any, label: str) -> str:
    if not isinstance(value, str) or _HASH.fullmatch(value) is None:
        raise _Invalid(f"{label} is not an algorithm-tagged SHA-256 hash")
    return value


def _sorted_strings(value: Any, label: str) -> list[str]:
    if not isinstance(value, list) or any(not isinstance(item, str) or not item for item in value):
        raise _Invalid(f"{label} is not a string array")
    if value != sorted(set(value), key=lambda item: item.encode("utf-8")):
        raise _Invalid(f"{label} is not UTF-8 sorted and unique")
    return value


def _result(name: str, status: str, report: Mapping[str, Any], check) -> VerificationResult:
    result = VerificationResult(ok=False, status=Status.FAILED)
    try:
        check(result)
        if not result.violations:
            result.status = status
            result.report.update(report)
    except (KeyError, TypeError, ValueError, _Invalid, tarfile.TarError) as error:
        result.record(f"{name}_decode", False, str(error))
        result.status = Status.FAILED
    return result.finish()


def _decode_json(data: bytes, label: str) -> Mapping[str, Any]:
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise _Invalid(f"{label} repeats JSON key {key!r}")
            result[key] = value
        return result

    try:
        value = json.loads(
            data.decode("utf-8"), object_pairs_hook=pairs,
            parse_float=lambda token: (_ for _ in ()).throw(_Invalid(f"{label} contains float {token}")),
            parse_constant=lambda token: (_ for _ in ()).throw(_Invalid(f"{label} contains {token}")),
        )
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise _Invalid(f"{label} is not exact UTF-8 JSON: {error}") from error
    if not isinstance(value, Mapping):
        raise _Invalid(f"{label} is not an object")
    return value


def _path(value: Any) -> str:
    if not isinstance(value, str) or not value or "\\" in value or "\0" in value:
        raise _Invalid("package path is not portable POSIX text")
    if value.startswith("/") or value.endswith("/"):
        raise _Invalid("package path is not normalized")
    if unicodedata.normalize("NFC", value) != value or any(
        part in {"", ".", ".."} for part in value.split("/")
    ):
        raise _Invalid("package path aliases, traverses, or is not NFC")
    return value


def _archive(manifest: Mapping[str, Any], payloads: Mapping[str, bytes]) -> bytes:
    buffer = io.BytesIO()
    rows = {row["path"]: row for row in manifest["payload_inventory"]}
    with tarfile.open(fileobj=buffer, mode="w", format=tarfile.USTAR_FORMAT) as archive:
        control_bytes = canonical_bytes(manifest)
        control = tarfile.TarInfo(_CONTROL)
        control.size, control.mode = len(control_bytes), 0o644
        control.uid = control.gid = control.mtime = 0
        control.uname = control.gname = "root"
        archive.addfile(control, io.BytesIO(control_bytes))
        for path in sorted(payloads, key=lambda item: item.encode("utf-8")):
            data = payloads[path]
            member = tarfile.TarInfo(path)
            member.size, member.mode = len(data), int(rows[path]["mode"], 8)
            member.uid = member.gid = member.mtime = 0
            member.uname = member.gname = "root"
            archive.addfile(member, io.BytesIO(data))
    return buffer.getvalue()


def verify_canonical_package(
    archive_bytes: Any,
    envelope: Any,
    *,
    max_archive_bytes: int = 64 * 1024 * 1024,
    max_members: int = 8192,
) -> VerificationResult:
    """Reconstruct a canonical package without executing package content."""

    def check(result: VerificationResult) -> None:
        if not isinstance(archive_bytes, bytes):
            raise _Invalid("archive must be bytes")
        if (
            not isinstance(max_archive_bytes, int) or isinstance(max_archive_bytes, bool)
            or max_archive_bytes < 1 or len(archive_bytes) > max_archive_bytes
        ):
            raise _Invalid("archive exceeds the verifier byte limit")
        if not isinstance(max_members, int) or isinstance(max_members, bool) or max_members < 1:
            raise _Invalid("archive member limit is invalid")
        env = _keys(envelope, {
            "record_type", "schema_version", "manifest_hash", "archive",
            "signed_content_hash", "detached_signature", "transparency", "retrieval",
            "revocation", "envelope_hash",
        }, "distribution envelope")
        if env["record_type"] != "PackageDistributionEnvelope" or env["schema_version"] != "1.0.0":
            raise _Invalid("distribution envelope type/version differs")
        if env["envelope_hash"] != hash_without(dict(env), "envelope_hash"):
            raise _Invalid("distribution envelope hash differs")
        digest = "sha256:" + hashlib.sha256(archive_bytes).hexdigest()
        archive_identity = _keys(env["archive"], {"media_type", "bytes", "sha256"}, "archive identity")
        if archive_identity != {"media_type": _MEDIA, "bytes": len(archive_bytes), "sha256": digest}:
            raise _Invalid("archive identity differs")
        retrieval = _keys(env["retrieval"], {"locator", "retrieved_at", "archive_digest"}, "retrieval")
        _text(retrieval["locator"], "retrieval locator")
        _text(retrieval["retrieved_at"], "retrieval time")
        if retrieval["archive_digest"] != digest:
            raise _Invalid("retrieval archive identity differs")
        signed = content_hash({"manifest_hash": env["manifest_hash"], "archive_digest": digest, "media_type": _MEDIA})
        if env["signed_content_hash"] != signed:
            raise _Invalid("signed-content identity differs")
        for label, fields in (
            ("detached_signature", {"profile", "algorithm", "key_id", "signed_content_hash", "signature"}),
            ("transparency", {"log_id", "entry_id", "integrated_at", "signed_content_hash", "inclusion_proof_hash"}),
        ):
            row = env[label]
            if row is not None:
                row = _keys(row, fields, label)
                if row["signed_content_hash"] != signed:
                    raise _Invalid(f"{label} binds different content")
        revocation = _keys(env["revocation"], {"status", "record_hash"}, "revocation")
        if revocation["status"] not in {"ACTIVE", "REVOKED", "UNAVAILABLE"}:
            raise _Invalid("revocation status is unknown")
        if (revocation["status"] == "REVOKED") != is_hash(revocation["record_hash"]):
            raise _Invalid("revocation record relation differs")

        with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode="r:") as archive:
            members = archive.getmembers()
            if len(members) > max_members:
                raise _Invalid("archive exceeds the verifier member limit")
            if not members or members[0].name != _CONTROL:
                raise _Invalid("control file is not the first archive member")
            names = [member.name for member in members]
            if len(names) != len(set(names)):
                raise _Invalid("archive repeats a member")
            for index, member in enumerate(members):
                if index:
                    _path(member.name)
                if not member.isfile() or member.issym() or member.islnk():
                    raise _Invalid("archive contains a non-regular member")
                if (
                    member.mode not in _MODES or member.uid != 0 or member.gid != 0
                    or member.uname != "root" or member.gname != "root" or member.mtime != 0
                    or member.linkname or member.devmajor != 0 or member.devminor != 0
                ):
                    raise _Invalid("archive metadata is not canonical")
            if members[0].mode != 0o644:
                raise _Invalid("control file mode differs")
            control = archive.extractfile(members[0])
            if control is None:
                raise _Invalid("control file has no bytes")
            raw_manifest = control.read()
            manifest = _decode_json(raw_manifest, "package manifest")
            if raw_manifest != canonical_bytes(manifest):
                raise _Invalid("package manifest JSON is not canonical")
            manifest = _keys(manifest, {
                "record_type", "schema_version", "format_profile", "package_form",
                "domain_manifest", "domain_manifest_hash", "control_files",
                "excluded_from_archive", "path_policy", "payload_inventory",
                "payload_root", "manifest_hash",
            }, "package manifest")
            if (
                manifest["record_type"] != "CanonicalPackageManifest"
                or manifest["schema_version"] != "1.0.0"
                or manifest["format_profile"] != "crg-canonical-package/ustar@1"
                or manifest["package_form"] not in _FORMS
            ):
                raise _Invalid("package manifest type/version/profile/form differs")
            if manifest["manifest_hash"] != hash_without(dict(manifest), "manifest_hash"):
                raise _Invalid("package manifest hash differs")
            domain_fields = {
                "identity", "version", "publisher", "supported_spec_versions", "permissions",
                "input_schemas", "output_schemas", "determinism_status", "external_dependencies",
                "resource_requirements", "failure_modes", "license", "provenance",
                "security_classification", "quantity_registry_additions", "proof_implications",
                "conformance_tests",
            }
            domain = _keys(manifest["domain_manifest"], domain_fields, "domain manifest")
            for field in domain_fields - {"resource_requirements", "provenance"}:
                if field in {"supported_spec_versions", "permissions", "input_schemas", "output_schemas", "external_dependencies", "failure_modes", "quantity_registry_additions", "proof_implications", "conformance_tests"}:
                    _sorted_strings(domain[field], f"domain manifest {field}")
                else:
                    _text(domain[field], f"domain manifest {field}")
            if manifest["domain_manifest_hash"] != content_hash(domain):
                raise _Invalid("domain manifest hash differs")
            if env["manifest_hash"] != manifest["manifest_hash"]:
                raise _Invalid("envelope names a different manifest")
            if manifest["control_files"] != [_CONTROL] or manifest["excluded_from_archive"] != ["DETACHED-SIGNATURE.json", "TRANSPARENCY.json"]:
                raise _Invalid("package control or exclusion inventory differs")
            if manifest["path_policy"] != {
                "normalization": "POSIX_RELATIVE_NFC_CALLER_SUPPLIED", "allowed_modes": ["0644", "0755"],
                "timestamp": 0, "symlinks": "PROHIBITED", "extra_files": "REFUSED",
            }:
                raise _Invalid("package path policy differs")
            rows, payloads = [], {}
            for member in members[1:]:
                handle = archive.extractfile(member)
                if handle is None:
                    raise _Invalid("payload member has no bytes")
                data = handle.read()
                payloads[member.name] = data
                rows.append({
                    "path": member.name, "mode": f"{member.mode:04o}", "bytes": len(data),
                    "sha256": "sha256:" + hashlib.sha256(data).hexdigest(),
                })
            rows.sort(key=lambda row: row["path"].encode("utf-8"))
            for row in manifest["payload_inventory"]:
                _keys(row, {"path", "mode", "bytes", "sha256"}, "payload inventory row")
                _path(row["path"])
            if rows != manifest["payload_inventory"] or manifest["payload_root"] != content_hash(rows):
                raise _Invalid("payload inventory/root differs from archive")
            if names != [_CONTROL] + [row["path"] for row in rows]:
                raise _Invalid("archive order or extra-file set differs")
            if _archive(manifest, payloads) != archive_bytes:
                raise _Invalid("archive is not the canonical USTAR encoding")
        result.record("package_identity", True, "manifest, payload, archive, and envelope identities reconstruct")
        result.record("package_authority", True, "package content was inspected as data and was not executed")
        result.report.update({
            "manifest_hash": manifest["manifest_hash"], "archive_digest": digest,
            "payload_root": manifest["payload_root"], "payload_count": len(rows),
            "authority": "INDEPENDENT_PACKAGE_VERIFICATION_ONLY", "execution_authorized": False,
        })

    return _result("canonical_package", "VERIFIED_CANONICAL_PACKAGE", {}, check)


def verify_resolved_profile_lock(value: Any) -> VerificationResult:
    top = {
        "record_type", "schema_version", "resolver", "root_requests", "selected_features",
        "platform", "packages", "dependency_graph", "conflict_graph", "namespace_authority",
        "overrides", "host_capabilities", "semantic_composition_root",
        "resolution_admission_root", "authority", "execution_authorized", "lock_hash",
    }

    def check(result: VerificationResult) -> None:
        record = _keys(value, top, "resolved profile lock")
        if record["record_type"] != "ResolvedProfileLock" or record["schema_version"] != "1.0.0":
            raise _Invalid("resolved profile lock type/version differs")
        resolver = _keys(record["resolver"], {"id", "version", "composition_abi"}, "resolver")
        if resolver["id"] != "crg-generate.package-resolver" or _SEMVER.fullmatch(resolver["version"]) is None or _SEMVER.fullmatch(resolver["composition_abi"]) is None:
            raise _Invalid("resolver identity/version differs")
        if record["authority"] != "RESOLUTION_RECORD_ONLY" or record["execution_authorized"] is not False:
            raise _Invalid("resolution record exceeds its authority")
        if record["lock_hash"] != hash_without(dict(record), "lock_hash"):
            raise _Invalid("resolved profile lock hash differs")
        packages = record["packages"]
        if not isinstance(packages, list) or not packages:
            raise _Invalid("resolved package set is empty")
        package_fields = {
            "package_id", "namespace", "publisher", "version", "package_form", "manifest_hash",
            "domain_manifest_hash", "archive_digest", "selected_features", "provides_capabilities",
            "requires_capabilities", "registry_origin", "mirror_state", "trust_state",
        }
        ids, semantic_rows = [], []
        provided = set(_sorted_strings(record["host_capabilities"], "host capabilities"))
        for row in packages:
            row = _keys(row, package_fields, "resolved package")
            package_id = _text(row["package_id"], "package_id")
            if _IDENTIFIER.fullmatch(package_id) is None or _SEMVER.fullmatch(row["version"]) is None:
                raise _Invalid("resolved package identity/version is invalid")
            if row["package_form"] not in _FORMS:
                raise _Invalid("resolved package form is invalid")
            for field in ("manifest_hash", "domain_manifest_hash", "archive_digest"):
                _hash(row[field], field)
            for field in ("selected_features", "provides_capabilities", "requires_capabilities"):
                _sorted_strings(row[field], field)
            mirror = _keys(row["mirror_state"], {"mirror_id", "snapshot_hash", "status"}, "mirror state")
            _hash(mirror["snapshot_hash"], "mirror snapshot")
            trust = _keys(row["trust_state"], {"snapshot_hash", "status", "signature_status", "advisory_status", "revocation_status"}, "trust state")
            _hash(trust["snapshot_hash"], "trust snapshot")
            if trust["status"] != "CURRENT" or trust["signature_status"] != "VERIFIED" or trust["advisory_status"] not in {"CLEAR", "ACKNOWLEDGED"} or trust["revocation_status"] != "ACTIVE":
                raise _Invalid("resolved package trust/advisory/revocation state is not admissible")
            ids.append(package_id)
            provided.update(row["provides_capabilities"])
            semantic_rows.append({
                "package_id": package_id, "version": row["version"], "package_form": row["package_form"],
                "manifest_hash": row["manifest_hash"], "domain_manifest_hash": row["domain_manifest_hash"],
                "selected_features": row["selected_features"],
            })
        if ids != sorted(set(ids), key=lambda item: item.encode("utf-8")):
            raise _Invalid("resolved packages are not sorted and unique")
        namespace_rows = record["namespace_authority"]
        authorities = {}
        for row in namespace_rows:
            row = _keys(row, {"namespace", "publishers"}, "namespace authority")
            authorities[_text(row["namespace"], "namespace")] = _sorted_strings(row["publishers"], "publishers")
        if list(authorities) != sorted(authorities, key=lambda item: item.encode("utf-8")):
            raise _Invalid("namespace authority is not sorted and unique")
        package_map = {row["package_id"]: row for row in packages}
        for row in packages:
            if row["publisher"] not in authorities.get(row["namespace"], []):
                raise _Invalid("resolved publisher lacks namespace authority")
            missing = set(row["requires_capabilities"]) - provided
            if missing:
                raise _Invalid("resolved package has unsatisfied capabilities")
        edges = record["dependency_graph"]
        edge_key = lambda row: (row["from"].encode(), row["to"].encode(), row["kind"], row["feature"] or "", row["constraint"])
        if edges != sorted(edges, key=edge_key):
            raise _Invalid("dependency graph is not canonical")
        for edge in edges:
            edge = _keys(edge, {"from", "to", "constraint", "kind", "feature"}, "dependency edge")
            if edge["from"] not in package_map or edge["to"] not in package_map or edge["kind"] not in {"REQUIRED", "OPTIONAL_FEATURE"}:
                raise _Invalid("dependency graph references an invalid package or kind")
        if any(_keys(row, {"from", "to", "active"}, "conflict edge")["active"] is not False for row in record["conflict_graph"]):
            raise _Invalid("resolved conflict graph contains an active conflict")
        semantic = {
            "composition_abi": resolver["composition_abi"], "root_requests": record["root_requests"],
            "selected_features": record["selected_features"], "packages": semantic_rows,
            "dependency_graph": edges,
        }
        if record["semantic_composition_root"] != content_hash(semantic):
            raise _Invalid("semantic composition root differs")
        resolution = content_hash({
            key: item for key, item in record.items()
            if key not in {"semantic_composition_root", "resolution_admission_root", "lock_hash"}
        })
        if record["resolution_admission_root"] != resolution:
            raise _Invalid("resolution/admission root differs")
        result.record("resolution_identity", True, "semantic and resolution roots independently reconstruct")
        result.record("resolution_trust", True, "publisher, trust, advisory, revocation, conflict, and capability gates hold")
        result.record("resolution_authority", True, "resolution record is non-authorizing")
        result.report.update({
            "lock_hash": record["lock_hash"], "semantic_composition_root": record["semantic_composition_root"],
            "resolution_admission_root": record["resolution_admission_root"],
            "authority": "INDEPENDENT_RESOLUTION_VERIFICATION_ONLY", "execution_authorized": False,
        })

    return _result("resolved_profile_lock", "VERIFIED_RESOLVED_PROFILE_LOCK", {}, check)


def verify_assessment_context_roots(value: Any, *, resolved_profile_lock: Any | None = None) -> VerificationResult:
    fields = {
        "record_type", "schema_version", "profile", "inputs", "semantic_composition_root",
        "host_policy_action_mapping_root", "execution_deployment_root",
        "resolution_admission_root", "authority", "execution_authorized", "context_hash",
    }

    def check(result: VerificationResult) -> None:
        record = _keys(value, fields, "assessment context")
        if record["record_type"] != "AssessmentContextRoots" or record["schema_version"] != "1.0.0" or record["profile"] != "crg-assessment-context/four-root@1":
            raise _Invalid("assessment context type/version/profile differs")
        if record["authority"] != "ASSESSMENT_CONTEXT_ONLY" or record["execution_authorized"] is not False:
            raise _Invalid("assessment context exceeds its authority")
        inputs = _keys(record["inputs"], {
            "resolved_profile_lock_hash", "action_mapping_profile_hash", "host_policy_snapshot_hash",
            "execution_profile_hash", "deployment_profile_hash",
        }, "assessment context inputs")
        for field in inputs:
            _hash(inputs[field], field)
        if record["context_hash"] != hash_without(dict(record), "context_hash"):
            raise _Invalid("assessment context hash differs")
        if record["host_policy_action_mapping_root"] != content_hash({
            "action_mapping_profile_hash": inputs["action_mapping_profile_hash"],
            "host_policy_snapshot_hash": inputs["host_policy_snapshot_hash"],
        }):
            raise _Invalid("host-policy/action-mapping root differs")
        if record["execution_deployment_root"] != content_hash({
            "execution_profile_hash": inputs["execution_profile_hash"],
            "deployment_profile_hash": inputs["deployment_profile_hash"],
        }):
            raise _Invalid("execution/deployment root differs")
        if resolved_profile_lock is not None:
            lock_result = verify_resolved_profile_lock(resolved_profile_lock)
            if not lock_result.ok:
                raise _Invalid("bound resolved profile lock is invalid")
            if inputs["resolved_profile_lock_hash"] != resolved_profile_lock["lock_hash"] or record["semantic_composition_root"] != resolved_profile_lock["semantic_composition_root"] or record["resolution_admission_root"] != resolved_profile_lock["resolution_admission_root"]:
                raise _Invalid("assessment context differs from the bound resolved profile lock")
        result.record("four_root_identity", True, "four independent context roots reconstruct and cross-bind")
        result.record("context_authority", True, "assessment context is non-authorizing")
        result.report.update({"context_hash": record["context_hash"], "authority": "INDEPENDENT_CONTEXT_VERIFICATION_ONLY", "execution_authorized": False})

    return _result("assessment_context", "VERIFIED_ASSESSMENT_CONTEXT_ROOTS", {}, check)


def verify_agent_event(value: Any) -> VerificationResult:
    top = {
        "record_type", "schema_version", "protocol_version", "minimum_reader_version",
        "event_id", "event_type", "actor", "case_id", "branch_id", "proposal_id",
        "action_id", "causal_parent_ids", "ordering_relation", "sequence",
        "idempotency_key", "deduplication_key", "correlation_id", "occurred_at",
        "delivery", "transport", "transaction", "payload_hash", "authority",
        "execution_authorized", "event_hash",
    }
    allowed = {
        "ASSESS": {"assessment.requested", "assessment.completed"},
        "COMMIT": {"commitment.proposed", "commitment.dispositioned", "action.recorded"},
        "ACKNOWLEDGE": {"acknowledgement.recorded"},
    }

    def check(result: VerificationResult) -> None:
        record = _keys(value, top, "agent event")
        if (record["record_type"], record["schema_version"], record["protocol_version"], record["minimum_reader_version"]) != ("AgentEvent", "1.0.0", "1.0.0", "1.0.0"):
            raise _Invalid("agent event type or ABI version differs")
        if record["authority"] != "EVENT_CARRIER_ONLY" or record["execution_authorized"] is not False:
            raise _Invalid("agent event exceeds carrier authority")
        if record["event_hash"] != hash_without(dict(record), "event_hash"):
            raise _Invalid("agent event hash differs")
        parents = _sorted_strings(record["causal_parent_ids"], "causal parents")
        if record["sequence"] < 1 or (record["ordering_relation"] == "ROOT") != (parents == []):
            raise _Invalid("agent event sequence/causal ordering differs")
        if record["case_id"] is None and record["branch_id"] is not None:
            raise _Invalid("agent event names a branch without a case")
        _keys(record["actor"], {"actor_id", "actor_kind"}, "actor")
        delivery = _keys(record["delivery"], {"delivery_id", "attempt", "max_attempts", "ack_required", "acknowledged_event_id", "retry_of_event_id"}, "delivery")
        if delivery["attempt"] < 1 or delivery["attempt"] > delivery["max_attempts"] or (delivery["attempt"] == 1) != (delivery["retry_of_event_id"] is None):
            raise _Invalid("agent event retry relation differs")
        transport = _keys(record["transport"], {"profile", "mapping_version"}, "transport")
        if transport["profile"] not in {"BATCH_FILE", "QUEUE", "LOCAL_PROCESS", "HTTP", "GRPC"} or transport["mapping_version"] != "1.0.0":
            raise _Invalid("agent event transport mapping is unsupported")
        transaction = _keys(record["transaction"], {"transaction_id", "phase", "request_hash", "prior_phase_event_id"}, "transaction")
        phase = transaction["phase"]
        if phase not in allowed or record["event_type"] not in allowed[phase] or (phase == "ASSESS") != (transaction["prior_phase_event_id"] is None):
            raise _Invalid("agent event transaction phase relation differs")
        if phase == "COMMIT" and record["proposal_id"] is None:
            raise _Invalid("COMMIT event omits proposal identity")
        if record["event_type"] == "action.recorded" and record["action_id"] is None:
            raise _Invalid("action event omits action identity")
        if phase == "ACKNOWLEDGE":
            if not delivery["ack_required"] or delivery["acknowledged_event_id"] is None:
                raise _Invalid("acknowledgement event relation differs")
        elif delivery["acknowledged_event_id"] is not None:
            raise _Invalid("non-acknowledgement event binds an acknowledgement")
        result.record("event_identity", True, "event identity and ABI structure independently reconstruct")
        result.record("event_causality", True, "ordering, delivery, retry, transaction, and acknowledgement relations hold")
        result.record("event_authority", True, "event is a non-authorizing carrier")
        result.report.update({"event_hash": record["event_hash"], "authority": "INDEPENDENT_EVENT_VERIFICATION_ONLY", "execution_authorized": False})

    return _result("agent_event", "VERIFIED_AGENT_EVENT", {}, check)


def verify_agent_transaction_receipt(
    value: Any, *, events: Sequence[Mapping[str, Any]]
) -> VerificationResult:
    """Independently reconstruct an A2 assess/commit/ack transaction."""

    top = {
        "record_type", "schema_version", "profile", "transaction_id", "events",
        "sequence_start", "sequence_end", "acknowledged_event_ids",
        "unacknowledged_event_ids", "status", "authority",
        "execution_authorized", "receipt_hash",
    }
    row_fields = {
        "event_id", "event_hash", "event_type", "phase", "sequence",
        "causal_parent_ids", "request_hash", "payload_hash", "ingestion_status",
    }

    def check(result: VerificationResult) -> None:
        record = _keys(value, top, "agent transaction receipt")
        if (
            record["record_type"] != "AgentTransactionReceipt"
            or record["schema_version"] != "1.0.0"
            or record["profile"] != "crg-agent-transaction/assess-commit-ack@1"
        ):
            raise _Invalid("agent transaction receipt type/version/profile differs")
        if (
            record["authority"] != "TRANSACTION_EVIDENCE_ONLY"
            or record["execution_authorized"] is not False
            or record["receipt_hash"] != hash_without(dict(record), "receipt_hash")
        ):
            raise _Invalid("agent transaction receipt identity/authority differs")
        if not isinstance(events, Sequence) or isinstance(events, (str, bytes)) or not events:
            raise _Invalid("agent transaction verification requires source events")
        source: dict[str, Mapping[str, Any]] = {}
        for event in events:
            verification = verify_agent_event(event)
            if not verification.ok:
                raise _Invalid("agent transaction contains an invalid source event")
            event_id = str(event["event_id"])
            if event_id in source:
                raise _Invalid("agent transaction repeats a source event")
            if event["transaction"]["transaction_id"] != record["transaction_id"]:
                raise _Invalid("agent transaction source event names another transaction")
            source[event_id] = event
        rows = record["events"]
        if not isinstance(rows, list) or not rows:
            raise _Invalid("agent transaction receipt event rows are empty")
        expected_rows = []
        statuses = {"ACCEPTED", "ACKNOWLEDGED", "RETRY_SCHEDULED"}
        source_in_order = sorted(source.values(), key=lambda event: (event["sequence"], event["event_id"]))
        prior_ids: set[str] = set()
        sequences: list[int] = []
        for event in source_in_order:
            if any(parent not in prior_ids for parent in event["causal_parent_ids"]):
                raise _Invalid("agent transaction causal parent closure differs")
            prior_ids.add(event["event_id"])
            sequences.append(event["sequence"])
        if sequences != list(range(sequences[0], sequences[-1] + 1)):
            raise _Invalid("agent transaction sequence has a gap or duplicate")
        status_by_id: dict[str, str] = {}
        for row in rows:
            row = _keys(row, row_fields, "agent transaction event row")
            if row["ingestion_status"] not in statuses:
                raise _Invalid("agent transaction ingestion status is not accepted")
            status_by_id[str(row["event_id"])] = str(row["ingestion_status"])
        if len(status_by_id) != len(rows) or set(status_by_id) != set(source):
            raise _Invalid("agent transaction receipt/source event inventory differs")
        for event in source_in_order:
            expected_rows.append({
                "event_id": event["event_id"],
                "event_hash": event["event_hash"],
                "event_type": event["event_type"],
                "phase": event["transaction"]["phase"],
                "sequence": event["sequence"],
                "causal_parent_ids": list(event["causal_parent_ids"]),
                "request_hash": event["transaction"]["request_hash"],
                "payload_hash": event["payload_hash"],
                "ingestion_status": status_by_id[event["event_id"]],
            })
        if rows != expected_rows:
            raise _Invalid("agent transaction event rows differ from source events")
        if record["sequence_start"] != sequences[0] or record["sequence_end"] != sequences[-1]:
            raise _Invalid("agent transaction sequence bounds differ")
        acknowledged = sorted({
            event["delivery"]["acknowledged_event_id"]
            for event in source_in_order
            if event["event_type"] == "acknowledgement.recorded"
        })
        required = {
            event["event_id"]
            for event in source_in_order
            if event["event_type"] != "acknowledgement.recorded"
            and event["delivery"]["ack_required"]
        }
        unacknowledged = sorted(required - set(acknowledged))
        if (
            record["acknowledged_event_ids"] != acknowledged
            or record["unacknowledged_event_ids"] != unacknowledged
            or record["status"] != ("ACKNOWLEDGED" if not unacknowledged else "OPEN")
        ):
            raise _Invalid("agent transaction acknowledgement state differs")
        phases = [event["transaction"]["phase"] for event in source_in_order]
        if phases[0] != "ASSESS" or "COMMIT" not in phases or phases[-1] != "ACKNOWLEDGE":
            raise _Invalid("agent transaction does not contain assess/commit/ack phases")
        result.record("transaction_identity", True, "receipt and source events reconstruct")
        result.record("transaction_causality", True, "sequence, parent, and phase closure hold")
        result.record("transaction_acknowledgement", True, "acknowledged and pending sets reconstruct")
        result.report.update({
            "receipt_hash": record["receipt_hash"],
            "transaction_id": record["transaction_id"],
            "status": record["status"],
            "authority": "INDEPENDENT_TRANSACTION_VERIFICATION_ONLY",
            "execution_authorized": False,
        })

    return _result("agent_transaction", "VERIFIED_AGENT_TRANSACTION_RECEIPT", {}, check)


def verify_execution_profile_contract(value: Any) -> VerificationResult:
    top = {
        "record_type", "schema_version", "profile_id", "profile_version", "package_lock_hash",
        "wire", "capability_handles", "ambient_authority", "permissions", "data_classification",
        "budgets", "termination", "runtime", "determinism", "audit", "limitations",
        "authority", "execution_authorized", "contract_hash",
    }

    def check(result: VerificationResult) -> None:
        record = _keys(value, top, "execution profile")
        if record["record_type"] != "ExecutionProfileContract" or record["schema_version"] != "1.0.0":
            raise _Invalid("execution profile type/version differs")
        if record["contract_hash"] != hash_without(dict(record), "contract_hash"):
            raise _Invalid("execution profile hash differs")
        if record["authority"] != "EXECUTION_CONTRACT_ONLY" or record["execution_authorized"] is not False:
            raise _Invalid("execution profile exceeds contract authority")
        runtime = _keys(record["runtime"], {"isolation_profile", "support_level", "policy_hash", "runner", "kernel", "platform", "image_identity", "kernel_enforced"}, "runtime")
        supported = runtime["support_level"] == "SUPPORTED"
        if runtime["isolation_profile"] not in {"PROCESS_REFERENCE", "OCI_KERNEL"} or runtime["support_level"] not in {"SUPPORTED", "EXPERIMENTAL"} or supported != (runtime["isolation_profile"] == "OCI_KERNEL" and runtime["kernel_enforced"] is True):
            raise _Invalid("execution support claim differs from the isolation boundary")
        for name in ("runner", "kernel", "platform"):
            identity = _keys(runtime[name], {"id", "hash"}, name)
            _text(identity["id"], f"{name}.id"); _hash(identity["hash"], f"{name}.hash")
        _hash(runtime["policy_hash"], "policy hash")
        ambient = _keys(record["ambient_authority"], {"network", "filesystem", "secrets", "environment", "time", "randomness"}, "ambient authority")
        determinism = _keys(record["determinism"], {"replay_required", "time_source", "randomness_source"}, "determinism")
        if ambient["time"] != "DENIED" or ambient["randomness"] != "DENIED" or determinism["time_source"] != "NONE" or determinism["randomness_source"] != "NONE":
            raise _Invalid("ambient time/randomness was admitted")
        if supported and (record["permissions"] or record["capability_handles"] or record["limitations"] or determinism["replay_required"] is not True):
            raise _Invalid("supported v1 profile exceeds deterministic pure computation")
        wire = _keys(record["wire"], {"protocol", "request_encoding", "reply_encoding", "request_schema_hash", "reply_schema_hash", "max_request_bytes", "max_reply_bytes", "max_output_bytes"}, "wire")
        if wire["protocol"] != "crg-sandbox/1" or wire["request_encoding"] != "CANONICAL_JSON_STDIN" or wire["reply_encoding"] != "CANONICAL_JSON_DEDICATED_CHANNEL":
            raise _Invalid("execution wire ABI differs")
        for name in ("max_request_bytes", "max_reply_bytes", "max_output_bytes"):
            if not isinstance(wire[name], int) or isinstance(wire[name], bool) or wire[name] <= 0:
                raise _Invalid("execution wire budget is invalid")
        budgets = _keys(record["budgets"], {"resource_quota", "filesystem_read_bytes", "filesystem_write_bytes", "network_requests", "network_bytes", "output_bytes"}, "budgets")
        if any(not isinstance(budgets[name], int) or isinstance(budgets[name], bool) or budgets[name] < 0 for name in budgets if name != "resource_quota"):
            raise _Invalid("execution budget is invalid")
        if supported and any(budgets[name] != 0 for name in ("filesystem_read_bytes", "filesystem_write_bytes", "network_requests", "network_bytes")):
            raise _Invalid("supported pure execution carries a side-effect budget")
        if record["termination"] != {"timeout_action": "KILL_PROCESS_GROUP", "cancellation": "REFUSE_BEFORE_START_OR_KILL_PROCESS_GROUP", "partial_output": "REFUSED"}:
            raise _Invalid("execution termination contract differs")
        result.record("execution_profile_identity", True, "profile identity, ABI, runtime, and budgets independently reconstruct")
        result.record("execution_profile_support", True, "supported status is limited to deterministic pure OCI execution")
        result.record("execution_profile_authority", True, "profile is a contract, not an execution authorization")
        result.report.update({"contract_hash": record["contract_hash"], "support_level": runtime["support_level"], "authority": "INDEPENDENT_EXECUTION_PROFILE_VERIFICATION_ONLY", "execution_authorized": False})

    return _result("execution_profile", "VERIFIED_EXECUTION_PROFILE_CONTRACT", {}, check)


def _audit_chain(record_hashes: Sequence[str]) -> str:
    digest = hashlib.sha256(b"crg-sandbox-log/1")
    for value in record_hashes:
        digest.update(_hash(value, "audit record hash").encode("ascii"))
    return "sha256:" + digest.hexdigest()


def verify_execution_receipt(
    value: Any,
    *,
    execution_profile: Any,
    invocation_record: Mapping[str, Any] | None = None,
    audit_record_hashes: Sequence[str] | None = None,
) -> VerificationResult:
    top = {
        "record_type", "schema_version", "execution_profile_hash", "request_hash", "reply_hash",
        "outcome", "side_effects", "side_effect_disposition", "invocation_record_hash",
        "environment_hash", "audit_chain_hash", "authority", "action_authorized", "receipt_hash",
    }

    def check(result: VerificationResult) -> None:
        profile_result = verify_execution_profile_contract(execution_profile)
        if not profile_result.ok:
            raise _Invalid("bound execution profile is invalid")
        record = _keys(value, top, "execution receipt")
        if record["record_type"] != "ExecutionReceipt" or record["schema_version"] != "1.0.0":
            raise _Invalid("execution receipt type/version differs")
        if record["receipt_hash"] != hash_without(dict(record), "receipt_hash"):
            raise _Invalid("execution receipt hash differs")
        if record["execution_profile_hash"] != execution_profile["contract_hash"]:
            raise _Invalid("execution receipt binds a different profile")
        if record["authority"] != "EXECUTION_EVIDENCE_ONLY" or record["action_authorized"] is not False:
            raise _Invalid("execution receipt exceeds evidence authority")
        if record["side_effects"] != [] or record["side_effect_disposition"] != "NONE_PERMITTED":
            raise _Invalid("pure execution receipt claims a side effect")
        outcome = _keys(record["outcome"], {"status", "failure_category", "timed_out", "terminating_signal"}, "outcome")
        if outcome["failure_category"] not in _FAILURES or (outcome["status"] == "SUCCEEDED") != (outcome["failure_category"] == "OK"):
            raise _Invalid("execution outcome/failure relation differs")
        if invocation_record is not None:
            invocation_hash = content_hash(invocation_record)
            if record["invocation_record_hash"] != invocation_hash:
                raise _Invalid("invocation record identity differs")
            expected_reply = invocation_record.get("output_hash") or None
            if record["request_hash"] != invocation_record.get("input_hash") or record["reply_hash"] != expected_reply or record["environment_hash"] != invocation_record.get("environment_hash"):
                raise _Invalid("execution receipt request/reply/environment binding differs")
            if invocation_record.get("policy_hash") != execution_profile["runtime"]["policy_hash"]:
                raise _Invalid("invocation policy differs from execution profile")
            if outcome["failure_category"] != invocation_record.get("failure_category") or outcome["timed_out"] is not invocation_record.get("timed_out") or outcome["terminating_signal"] != (invocation_record.get("terminating_signal") or None):
                raise _Invalid("execution receipt outcome differs from invocation record")
        if audit_record_hashes is not None:
            if not audit_record_hashes or audit_record_hashes[-1] != record["invocation_record_hash"] or record["audit_chain_hash"] != _audit_chain(audit_record_hashes):
                raise _Invalid("execution audit-chain binding differs")
        result.record("execution_receipt_identity", True, "receipt and profile identities independently reconstruct")
        if invocation_record is not None:
            result.record("execution_invocation_binding", True, "request, reply, environment, policy, and outcome bind the invocation")
        if audit_record_hashes is not None:
            result.record("execution_audit_chain", True, "audit chain independently reconstructs through the invocation")
        result.record("execution_receipt_authority", True, "receipt is evidence only and carries no direct side effect")
        result.report.update({"receipt_hash": record["receipt_hash"], "authority": "INDEPENDENT_EXECUTION_RECEIPT_VERIFICATION_ONLY", "action_authorized": False})

    return _result("execution_receipt", "VERIFIED_EXECUTION_RECEIPT", {}, check)
