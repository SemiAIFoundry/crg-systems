"""Independent structural and outcome verification for ``TransitionRecord``.

The producer lives in :mod:`crg_feedback.transition`.  This module imports
none of that code: it reconstructs the action, postcondition, rollback, and
non-execution relationships from the portable record alone.
"""
from __future__ import annotations

from typing import Any, Mapping, Sequence

from .canonical import content_hash, is_hash
from .certificate import Status, VerificationResult

__all__ = ["verify_transition_record"]

_BASE_FIELDS = {
    "record_id", "plan_id", "status", "level", "source_config_id",
    "target_config_id", "final_config_id", "returned_to_source",
    "started_ticks", "finished_ticks", "checkpoint", "rollback_plan",
    "audit_spec", "clock", "steps", "postcondition_results", "refusals",
    "audit",
}
_OPTIONAL_FIELDS = {"checkpoint_token", "rollback_of", "approver_identity"}
_STATUSES = {
    "PLANNED", "AUTHORIZED", "COMPLETED", "ROLLED_BACK",
    "ROLLBACK_FAILED", "REFUSED",
}
_LEVELS = {
    "L0_OFFLINE", "L1_SUPERVISED", "L2_AUTOMATED_BOUNDED",
    "L3_ADAPTIVE_CERTIFIED",
}


class _Invalid(ValueError):
    pass


def _object(value: Any, label: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise _Invalid(f"{label} must be an object")
    return value


def _fields(
    value: Any,
    required: Sequence[str] | set[str],
    optional: Sequence[str] | set[str],
    label: str,
) -> Mapping[str, Any]:
    item = _object(value, label)
    required_set, optional_set = set(required), set(optional)
    if not required_set.issubset(item) or set(item) - required_set - optional_set:
        raise _Invalid(f"{label} fields differ")
    return item


def _text(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value:
        raise _Invalid(f"{label} must be a non-empty string")
    return value


def _integer(value: Any, label: str, *, minimum: int = 0) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise _Invalid(f"{label} must be an integer >= {minimum}")
    return value


def _array(value: Any, label: str) -> list[Any]:
    if not isinstance(value, list):
        raise _Invalid(f"{label} must be an array")
    return value


def _checkpoint(value: Any, source: str) -> Mapping[str, Any]:
    item = _fields(
        value,
        {"checkpoint_id", "configuration_id", "configuration_hash",
         "captured_at_ticks", "restorable"},
        {"contents_hash"},
        "checkpoint",
    )
    _text(item["checkpoint_id"], "checkpoint_id")
    if _text(item["configuration_id"], "checkpoint configuration") != source:
        raise _Invalid("checkpoint does not bind the source configuration")
    if not is_hash(item["configuration_hash"]):
        raise _Invalid("checkpoint configuration_hash is invalid")
    if "contents_hash" in item and not is_hash(item["contents_hash"]):
        raise _Invalid("checkpoint contents_hash is invalid")
    _integer(item["captured_at_ticks"], "checkpoint captured_at_ticks")
    if item["restorable"] is not True:
        raise _Invalid("checkpoint is not restorable")
    return item


def _rollback(value: Any, checkpoint_id: str) -> Mapping[str, Any]:
    item = _fields(
        value,
        {"rollback_id", "checkpoint_id", "steps", "bounded_ticks",
         "restores_consistency"},
        {"verification_signal"},
        "rollback plan",
    )
    _text(item["rollback_id"], "rollback_id")
    if item["checkpoint_id"] != checkpoint_id:
        raise _Invalid("rollback plan names a different checkpoint")
    steps = _array(item["steps"], "rollback steps")
    if not steps or any(not isinstance(step, str) or not step for step in steps):
        raise _Invalid("rollback steps must be a non-empty string array")
    _integer(item["bounded_ticks"], "rollback bounded_ticks", minimum=1)
    if not isinstance(item["restores_consistency"], bool):
        raise _Invalid("rollback restores_consistency must be boolean")
    return item


def _step(value: Any, started: int, finished: int) -> None:
    item = _fields(value, {"name", "at_ticks", "ok"}, {"detail"}, "transition step")
    _text(item["name"], "transition step name")
    ticks = _integer(item["at_ticks"], "transition step ticks")
    if ticks < started or ticks > finished:
        raise _Invalid("transition step lies outside the recorded attempt interval")
    if not isinstance(item["ok"], bool):
        raise _Invalid("transition step ok must be boolean")


def _postcondition(value: Any) -> bool:
    item = _fields(
        value,
        {"condition_id", "signal", "comparator", "threshold", "satisfied"},
        {"observed", "detail"},
        "postcondition result",
    )
    _text(item["condition_id"], "postcondition condition_id")
    _text(item["signal"], "postcondition signal")
    _text(item["comparator"], "postcondition comparator")
    _object(item["threshold"], "postcondition threshold")
    if "observed" in item:
        _object(item["observed"], "postcondition observed")
    if not isinstance(item["satisfied"], bool):
        raise _Invalid("postcondition satisfied must be boolean")
    return item["satisfied"]


def _refusal(value: Any) -> str:
    item = _fields(value, {"reason", "detail"}, {"subject"}, "refusal")
    reason = _text(item["reason"], "refusal reason")
    _text(item["detail"], "refusal detail")
    return reason


def _audit(value: Any) -> None:
    rows = _array(value, "audit")
    last_ticks = -1
    for index, raw in enumerate(rows, 1):
        item = _fields(raw, {"sequence", "at_ticks", "event"}, {"detail"}, "audit entry")
        if _integer(item["sequence"], "audit sequence", minimum=1) != index:
            raise _Invalid("audit sequence is not contiguous")
        ticks = _integer(item["at_ticks"], "audit ticks")
        if ticks < last_ticks:
            raise _Invalid("audit monotonic ticks move backwards")
        last_ticks = ticks
        _text(item["event"], "audit event")


def verify_transition_record(record: Mapping[str, Any]) -> VerificationResult:
    """Verify one portable action/non-action/rollback record independently."""

    result = VerificationResult(ok=False)
    try:
        item = _fields(record, _BASE_FIELDS, _OPTIONAL_FIELDS, "transition record")
        for field in ("record_id", "plan_id", "source_config_id", "target_config_id",
                      "final_config_id"):
            _text(item[field], field)
        status = _text(item["status"], "status")
        if status not in _STATUSES:
            raise _Invalid("transition status is unsupported")
        if item["level"] not in _LEVELS:
            raise _Invalid("transition maturity level is unsupported")
        started = _integer(item["started_ticks"], "started_ticks")
        finished = _integer(item["finished_ticks"], "finished_ticks")
        if finished < started:
            raise _Invalid("transition finished before it started")
        returned = item["final_config_id"] == item["source_config_id"]
        if item["returned_to_source"] is not returned:
            raise _Invalid("returned_to_source differs from the final configuration")

        checkpoint = _checkpoint(item["checkpoint"], item["source_config_id"])
        _rollback(item["rollback_plan"], checkpoint["checkpoint_id"])
        audit_spec = _fields(
            item["audit_spec"], {"audit_id", "sink", "retained_fields"},
            {"signer"}, "audit spec",
        )
        _text(audit_spec["audit_id"], "audit_id")
        _text(audit_spec["sink"], "audit sink")
        retained = _array(audit_spec["retained_fields"], "retained_fields")
        if not retained or any(not isinstance(field, str) or not field for field in retained):
            raise _Invalid("audit retained_fields must be non-empty")
        clock = _fields(
            item["clock"], {"tick_unit", "clock_source", "clock_trust_level", "wall_clock"},
            {"monotonic_ticks"}, "transition clock",
        )
        _text(clock["tick_unit"], "clock tick_unit")
        _text(clock["clock_source"], "clock source")
        _text(clock["clock_trust_level"], "clock trust")
        _object(clock["wall_clock"], "wall clock")

        for step in _array(item["steps"], "transition steps"):
            _step(step, started, finished)
        postconditions = [
            _postcondition(value)
            for value in _array(item["postcondition_results"], "postconditions")
        ]
        refusal_reasons = [
            _refusal(value) for value in _array(item["refusals"], "refusals")
        ]
        _audit(item["audit"])

        if status == "COMPLETED":
            if item["final_config_id"] != item["target_config_id"] or returned:
                raise _Invalid("COMPLETED transition did not end at the target")
            if refusal_reasons or any(not value for value in postconditions):
                raise _Invalid("COMPLETED transition carries a refusal or failed postcondition")
            disposition = "ACTION_COMPLETED"
        elif status == "ROLLED_BACK":
            if not returned or item.get("rollback_of") is None:
                raise _Invalid("ROLLED_BACK transition lacks verified source return lineage")
            disposition = "ACTION_ROLLED_BACK"
        elif status == "ROLLBACK_FAILED":
            if item.get("rollback_of") is None or "ROLLBACK_FAILED" not in refusal_reasons:
                raise _Invalid("ROLLBACK_FAILED transition lacks rollback lineage/reason")
            disposition = "ROLLBACK_FAILED"
        elif status == "REFUSED":
            if not refusal_reasons:
                raise _Invalid("REFUSED transition has no reason")
            disposition = "ACTION_NOT_CONFIRMED"
        else:
            disposition = "NO_ACTION_RECORDED"

        result.record("transition_structure", True, "closed portable transition record")
        result.record("transition_outcome", True, disposition)
        result.status = "VERIFIED_TRANSITION_RECORD"
        result.report.update({
            "artifact_hash": content_hash(dict(item)),
            "status": status,
            "disposition": disposition,
            "action_occurred": status in {"COMPLETED", "ROLLED_BACK", "ROLLBACK_FAILED"},
            "rollback_occurred": status in {"ROLLED_BACK", "ROLLBACK_FAILED"},
            "refusal_reasons": refusal_reasons,
        })
    except (KeyError, TypeError, _Invalid, ValueError) as error:
        result.record("transition_record", False, str(error))
        result.status = Status.FAILED
    return result.finish()
