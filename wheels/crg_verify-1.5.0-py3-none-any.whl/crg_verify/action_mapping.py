"""Independent verifier for non-authorizing ActionMappingProfile records."""

from __future__ import annotations

import re
from typing import Any, Mapping, Sequence

from .canonical import hash_without, is_hash
from .certificate import Status, VerificationResult

__all__ = ["verify_action_mapping_profile"]

_TOP = (
    "record_type", "schema_version", "profile_id", "profile_version",
    "authority", "execution_authorized", "mappings", "unknown_action_result",
    "unsupported_action_result", "profile_hash",
)
_MAPPING = ("action_class", "scope", "subject", "target", "assessment", "host_policy")
_SEMVER = re.compile(r"(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)")
_ACTION = re.compile(r"[A-Z][A-Z0-9_]*")
_PERMISSION = re.compile(r"[a-z][a-z0-9_-]*:[a-z][a-z0-9_-]*")
_ASSESSMENT_RECORD_TYPES = frozenset({
    "SafeCommitmentArtifact",
    "PhaseAnalysisRecord",
    "CertifiedDeltaRecord",
    "LifecycleAuthorization",
    "ContinuedValidityView",
    "DecisionChallengeRecord",
})
_ROLES = frozenset({
    "Viewer", "Contributor", "Registry Importer", "Generator Author",
    "Pack Publisher", "Evidence Steward", "Qualification Author",
    "Decision Approver", "Certificate Signer", "Federation Operator",
    "Security Administrator", "Auditor", "System Administrator",
})
_PERMISSIONS = frozenset({
    "case:read", "case:create", "case:update", "case:branch", "case:merge",
    "case:migrate", "case:validate", "registry:import", "generator:run",
    "generator:author", "geometry:build", "query:compile", "decision:evaluate",
    "decision:certify", "certificate:read", "certificate:sign",
    "certificate:revoke", "change:classify", "change:approve", "conversion:plan",
    "evidence:read", "evidence:register", "evidence:retire", "contract:assemble",
    "qualification:plan", "experiment:record", "pack:publish", "pack:install",
    "federation:issue_envelope", "federation:evaluate_private",
    "federation:revoke", "bundle:import", "bundle:export", "object:redact",
    "object:erase", "object:legal_hold", "retention:manage", "retention:enforce",
    "key:manage", "key:destroy", "tenant:manage", "identity:manage",
    "policy:manage", "audit:read", "audit:export", "job:manage",
    "system:configure", "lifecycle:publish", "lifecycle:read",
    "lifecycle:signature_verify", "lifecycle:approval_issue",
    "lifecycle:approval_withdraw", "lifecycle:authorization_evaluate",
    "lifecycle:validity_publish", "measurement:capture", "measurement:read",
    "measurement:export", "measurement:delete", "measurement:retention",
})


class _Invalid(ValueError):
    pass


def _keys(value: Any, keys: Sequence[str], field: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping) or set(value) != set(keys):
        raise _Invalid(f"{field} fields differ")
    return value


def _strings(value: Any, field: str, *, nonempty: bool = False) -> list[str]:
    if not isinstance(value, list) or (nonempty and not value):
        raise _Invalid(f"{field} must be a{' non-empty' if nonempty else ''} array")
    if not all(isinstance(item, str) and item for item in value):
        raise _Invalid(f"{field} contains an invalid identifier")
    if value != sorted(set(value)):
        raise _Invalid(f"{field} must be sorted and unique")
    return value


def verify_action_mapping_profile(value: Any) -> VerificationResult:
    """Reconstruct profile identity and fail closed on unknown or authority-bearing data."""

    result = VerificationResult(ok=False, status=Status.FAILED)
    try:
        record = _keys(value, _TOP, "profile")
        if record.get("record_type") != "ActionMappingProfile" or record.get("schema_version") != "1.0.0":
            raise _Invalid("profile type/version differs")
        if not isinstance(record.get("profile_id"), str) or not record["profile_id"]:
            raise _Invalid("profile_id is invalid")
        if not isinstance(record.get("profile_version"), str) or _SEMVER.fullmatch(record["profile_version"]) is None:
            raise _Invalid("profile_version is invalid")
        result.record(
            "authority_boundary",
            record.get("authority") == "NON_AUTHORIZING" and record.get("execution_authorized") is False,
            "profile is non-authorizing and cannot execute a host action",
        )
        if record.get("unknown_action_result") != "REFUSED_UNKNOWN_ACTION" or record.get("unsupported_action_result") != "REFUSED_UNSUPPORTED_ACTION_CONTEXT":
            raise _Invalid("fail-closed action results differ")
        if not is_hash(record.get("profile_hash")) or record["profile_hash"] != hash_without(dict(record), "profile_hash"):
            raise _Invalid("profile_hash differs from independent canonical reconstruction")
        mappings = record.get("mappings")
        if not isinstance(mappings, list) or not mappings:
            raise _Invalid("mappings must be a non-empty array")
        actions: list[str] = []
        for index, raw in enumerate(mappings):
            mapping = _keys(raw, _MAPPING, f"mappings[{index}]")
            action = mapping.get("action_class")
            if not isinstance(action, str) or _ACTION.fullmatch(action) is None:
                raise _Invalid(f"mappings[{index}].action_class is invalid")
            actions.append(action)
            scope = _keys(mapping.get("scope"), ("domain", "resource_type"), f"mappings[{index}].scope")
            if not all(isinstance(scope.get(name), str) and scope[name] for name in scope):
                raise _Invalid(f"mappings[{index}].scope is invalid")
            subject = _keys(mapping.get("subject"), ("allowed_actor_kinds", "required_roles"), f"mappings[{index}].subject")
            _strings(subject.get("allowed_actor_kinds"), f"mappings[{index}].allowed_actor_kinds", nonempty=True)
            roles = _strings(subject.get("required_roles"), f"mappings[{index}].required_roles")
            if any(role not in _ROLES for role in roles):
                raise _Invalid(f"mappings[{index}].required_roles names an unknown role")
            target = _keys(mapping.get("target"), ("case_id_required", "branch_id_required", "causal_parent_required"), f"mappings[{index}].target")
            if not all(type(target[name]) is bool for name in target):
                raise _Invalid(f"mappings[{index}].target flags are invalid")
            assessment = _keys(mapping.get("assessment"), ("record_type", "profile", "required_statuses", "required_evidence", "verifier"), f"mappings[{index}].assessment")
            if not isinstance(assessment.get("record_type"), str) or not isinstance(assessment.get("profile"), str):
                raise _Invalid(f"mappings[{index}].assessment identity is invalid")
            if assessment["record_type"] not in _ASSESSMENT_RECORD_TYPES:
                raise _Invalid(f"mappings[{index}].assessment record type is unsupported")
            _strings(assessment.get("required_statuses"), f"mappings[{index}].required_statuses", nonempty=True)
            _strings(assessment.get("required_evidence"), f"mappings[{index}].required_evidence", nonempty=True)
            verifier = _keys(assessment.get("verifier"), ("program", "profile"), f"mappings[{index}].verifier")
            if not all(isinstance(verifier.get(name), str) and verifier[name] for name in verifier):
                raise _Invalid(f"mappings[{index}].verifier identity is invalid")
            policy = _keys(mapping.get("host_policy"), ("policy_id", "policy_version", "permission"), f"mappings[{index}].host_policy")
            if not isinstance(policy.get("policy_id"), str) or not policy["policy_id"] or not isinstance(policy.get("policy_version"), str) or _SEMVER.fullmatch(policy["policy_version"]) is None or not isinstance(policy.get("permission"), str) or _PERMISSION.fullmatch(policy["permission"]) is None:
                raise _Invalid(f"mappings[{index}].host_policy identity is invalid")
            if policy["permission"] not in _PERMISSIONS:
                raise _Invalid(f"mappings[{index}].host_policy permission is unknown")
        if actions != sorted(set(actions)):
            raise _Invalid("action mappings are not sorted and unique")
        result.record("profile_shape", True, f"{len(mappings)} closed action mappings reconstructed")
        result.record("profile_identity", True, "profile_hash matches independent canonical hashing")
        result.record("assessment_bindings", True, "every mapping binds assessment, evidence, and verifier identities")
        result.record("host_policy_bindings", True, "every mapping binds a versioned host-policy permission")
        if result.violations:
            result.status = Status.FAILED
        else:
            result.status = "VERIFIED_NON_AUTHORIZING_MAPPING"
            result.report = {
                "artifact_type": "ActionMappingProfile",
                "mapping_count": len(mappings),
                "profile_hash": record["profile_hash"],
                "execution_authorized": False,
            }
    except (KeyError, TypeError, _Invalid, ValueError) as error:
        result.record("profile_decode", False, str(error))
        result.status = Status.FAILED
    return result.finish()
