"""Independent verifier for bounded A6 multi-agent coordination records.

The verifier consumes portable grant/proposal/conflict/reconciliation records.
It does not import the server coordinator and it never selects or applies a
proposal.  In particular, arrival order and last-writer-wins are invalid
resolution authorities.
"""
from __future__ import annotations

import re
from typing import Any, Mapping

from .canonical import content_hash
from .certificate import Status, VerificationResult

__all__ = ["verify_multi_agent_operation"]

_HASH = re.compile(r"^sha256:[0-9a-f]{64}$")
_GRANT_FIELDS = {
    "record_type", "schema_version", "grant_id", "agent_id", "organization",
    "tenant_id", "roles", "case_ids", "branch_ids", "permitted_actions",
    "budget", "revoked", "authority", "execution_authorized", "grant_hash",
}
_PROPOSAL_FIELDS = {
    "record_type", "schema_version", "proposal_id", "grant_hash", "agent_id",
    "organization", "tenant_id", "case_id", "branch_id", "action",
    "expected_parent_version", "causal_parent_ids", "event_hash", "payload_hash",
    "cost_units", "elapsed_ticks", "authority", "execution_authorized",
    "proposal_hash",
}
_CONFLICT_FIELDS = {
    "record_type", "schema_version", "conflict_id", "case_id", "branch_id",
    "expected_parent_version", "proposal_ids", "resolution_status",
    "arrival_order_authoritative", "last_writer_wins", "authority",
    "execution_authorized", "conflict_hash",
}
_RECONCILIATION_FIELDS = {
    "record_type", "schema_version", "reconciliation_id", "conflict_hash",
    "proposal_ids", "selected_proposal_id", "resolved_by",
    "resolution_authority", "rationale", "arrival_order_authoritative",
    "last_writer_wins", "mutation_applied", "authority",
    "execution_authorized", "reconciliation_hash",
}


class _Invalid(ValueError):
    pass


def _exact(value: Any, fields: set[str], label: str) -> dict[str, Any]:
    if not isinstance(value, Mapping) or set(value) != fields:
        raise _Invalid(f"{label} fields differ")
    return dict(value)


def _text(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value:
        raise _Invalid(f"{label} must be non-empty text")
    return value


def _hash(value: Any, label: str) -> str:
    if not isinstance(value, str) or not _HASH.fullmatch(value):
        raise _Invalid(f"{label} is not a SHA-256 identity")
    return value


def _integer(value: Any, label: str, minimum: int = 0) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise _Invalid(f"{label} must be an integer >= {minimum}")
    return value


def _sorted_strings(value: Any, label: str) -> list[str]:
    if not isinstance(value, list) or any(not isinstance(item, str) or not item for item in value):
        raise _Invalid(f"{label} must be a string array")
    if value != sorted(set(value), key=lambda item: item.encode("utf-8")):
        raise _Invalid(f"{label} must be UTF-8 sorted and unique")
    return value


def _identity(record: dict[str, Any], field: str, label: str) -> None:
    supplied = _hash(record[field], field)
    expected = content_hash({key: value for key, value in record.items() if key != field})
    if supplied != expected:
        raise _Invalid(f"{label} identity differs")


def _grant(value: Any) -> dict[str, Any]:
    item = _exact(value, _GRANT_FIELDS, "agent grant")
    if item["record_type"] != "AgentOperationGrant" or item["schema_version"] != "1.0.0":
        raise _Invalid("agent grant type/version differs")
    for field in ("grant_id", "agent_id", "organization", "tenant_id"):
        _text(item[field], field)
    for field in ("roles", "case_ids", "branch_ids", "permitted_actions"):
        _sorted_strings(item[field], field)
    budget = _exact(item["budget"], {"max_proposals", "max_cost_units", "max_elapsed_ticks"}, "budget")
    for field in budget:
        _integer(budget[field], field, 1)
    if not isinstance(item["revoked"], bool):
        raise _Invalid("grant revoked flag must be boolean")
    if item["authority"] != "DEPLOYMENT_SCOPED_AGENT_GRANT" or item["execution_authorized"] is not False:
        raise _Invalid("agent grant authority differs")
    _identity(item, "grant_hash", "agent grant")
    return item


def _proposal(value: Any, grants: dict[str, dict[str, Any]]) -> dict[str, Any]:
    item = _exact(value, _PROPOSAL_FIELDS, "agent proposal")
    if item["record_type"] != "AgentProposalRecord" or item["schema_version"] != "1.0.0":
        raise _Invalid("agent proposal type/version differs")
    for field in ("proposal_id", "agent_id", "organization", "tenant_id", "case_id", "branch_id", "action"):
        _text(item[field], field)
    for field in ("grant_hash", "event_hash", "payload_hash"):
        _hash(item[field], field)
    _integer(item["expected_parent_version"], "expected_parent_version", 1)
    _integer(item["cost_units"], "cost_units")
    _integer(item["elapsed_ticks"], "elapsed_ticks")
    _sorted_strings(item["causal_parent_ids"], "causal_parent_ids")
    if item["authority"] != "PROPOSAL_ONLY" or item["execution_authorized"] is not False:
        raise _Invalid("agent proposal authority differs")
    grant = grants.get(item["grant_hash"])
    if grant is None or item["agent_id"] != grant["agent_id"]:
        raise _Invalid("agent proposal names another grant or agent")
    if item["organization"] != grant["organization"] or item["tenant_id"] != grant["tenant_id"]:
        raise _Invalid("agent proposal crosses organization or tenant")
    if item["case_id"] not in grant["case_ids"] or item["branch_id"] not in grant["branch_ids"]:
        raise _Invalid("agent proposal exceeds its case or branch scope")
    if item["action"] not in grant["permitted_actions"]:
        raise _Invalid("agent proposal exceeds its permission scope")
    _identity(item, "proposal_hash", "agent proposal")
    return item


def verify_multi_agent_operation(bundle: Mapping[str, Any]) -> VerificationResult:
    """Reconstruct one grant's proposal and reconciliation relationships."""

    result = VerificationResult(ok=False)
    try:
        outer = _exact(bundle, {"grants", "proposals", "conflict", "reconciliation"}, "multi-agent bundle")
        if not isinstance(outer["grants"], list) or not outer["grants"]:
            raise _Invalid("multi-agent bundle requires grants")
        grant_rows = [_grant(value) for value in outer["grants"]]
        if [item["agent_id"] for item in grant_rows] != sorted(
            {item["agent_id"] for item in grant_rows}, key=lambda item: item.encode("utf-8")
        ):
            raise _Invalid("agent grants must be sorted and unique")
        if any(item["revoked"] for item in grant_rows):
            raise _Invalid("a revoked grant cannot validate active proposals")
        grants = {item["grant_hash"]: item for item in grant_rows}
        if not isinstance(outer["proposals"], list) or not outer["proposals"]:
            raise _Invalid("multi-agent bundle requires proposals")
        proposals = [_proposal(value, grants) for value in outer["proposals"]]
        ids = [item["proposal_id"] for item in proposals]
        if ids != sorted(set(ids), key=lambda item: item.encode("utf-8")):
            raise _Invalid("proposals must be sorted and unique")
        for grant_hash, grant in grants.items():
            selected = [item for item in proposals if item["grant_hash"] == grant_hash]
            budget = grant["budget"]
            if len(selected) > budget["max_proposals"]:
                raise _Invalid("proposal count exceeds the grant budget")
            if sum(item["cost_units"] for item in selected) > budget["max_cost_units"]:
                raise _Invalid("proposal cost exceeds the grant budget")
            if sum(item["elapsed_ticks"] for item in selected) > budget["max_elapsed_ticks"]:
                raise _Invalid("proposal elapsed ticks exceed the grant budget")

        conflict = None
        if outer["conflict"] is not None:
            conflict = _exact(outer["conflict"], _CONFLICT_FIELDS, "agent conflict")
            if conflict["record_type"] != "AgentConflictRecord" or conflict["schema_version"] != "1.0.0":
                raise _Invalid("agent conflict type/version differs")
            conflict_ids = _sorted_strings(conflict["proposal_ids"], "conflict proposal_ids")
            selected = [item for item in proposals if item["proposal_id"] in conflict_ids]
            if len(selected) != len(conflict_ids) or len(selected) < 2:
                raise _Invalid("conflict proposal identities are incomplete")
            anchors = {(p["case_id"], p["branch_id"], p["expected_parent_version"]) for p in selected}
            if len(anchors) != 1 or len({p["payload_hash"] for p in selected}) < 2:
                raise _Invalid("conflict is not a concurrent divergent proposal set")
            case_id, branch_id, parent = next(iter(anchors))
            if (conflict["case_id"], conflict["branch_id"], conflict["expected_parent_version"]) != (case_id, branch_id, parent):
                raise _Invalid("conflict anchor differs from its proposals")
            if conflict["resolution_status"] != "RECONCILIATION_REQUIRED":
                raise _Invalid("conflict does not require reconciliation")
            if conflict["arrival_order_authoritative"] is not False or conflict["last_writer_wins"] is not False:
                raise _Invalid("conflict relies on arrival order or last-writer-wins")
            if conflict["authority"] != "CONFLICT_EVIDENCE_ONLY" or conflict["execution_authorized"] is not False:
                raise _Invalid("conflict authority differs")
            _identity(conflict, "conflict_hash", "agent conflict")

        reconciliation = outer["reconciliation"]
        if reconciliation is not None:
            if conflict is None:
                raise _Invalid("reconciliation has no conflict")
            reconciliation = _exact(reconciliation, _RECONCILIATION_FIELDS, "agent reconciliation")
            if reconciliation["record_type"] != "AgentReconciliationRecord" or reconciliation["schema_version"] != "1.0.0":
                raise _Invalid("agent reconciliation type/version differs")
            if reconciliation["conflict_hash"] != conflict["conflict_hash"] or reconciliation["proposal_ids"] != conflict["proposal_ids"]:
                raise _Invalid("reconciliation names another conflict")
            if reconciliation["selected_proposal_id"] is not None and reconciliation["selected_proposal_id"] not in conflict["proposal_ids"]:
                raise _Invalid("reconciliation selects a proposal outside the conflict")
            if reconciliation["resolution_authority"] not in {"HUMAN", "ADMITTED_POLICY"}:
                raise _Invalid("reconciliation lacks human or admitted-policy authority")
            _text(reconciliation["resolved_by"], "resolved_by")
            _text(reconciliation["rationale"], "rationale")
            if reconciliation["arrival_order_authoritative"] is not False or reconciliation["last_writer_wins"] is not False:
                raise _Invalid("reconciliation relies on arrival order or last-writer-wins")
            if reconciliation["mutation_applied"] is not False or reconciliation["execution_authorized"] is not False:
                raise _Invalid("reconciliation improperly claims mutation or execution")
            if reconciliation["authority"] != "RECONCILIATION_DECISION_ONLY":
                raise _Invalid("reconciliation authority differs")
            _identity(reconciliation, "reconciliation_hash", "agent reconciliation")

        result.status = "VERIFIED_MULTI_AGENT_COORDINATION"
        result.report.update({
            "artifact_hash": content_hash(bundle),
            "grant_count": len(grant_rows),
            "proposal_count": len(proposals),
            "conflict_recorded": conflict is not None,
            "reconciled": reconciliation is not None,
            "mutation_applied": False,
            "execution_authorized": False,
        })
        result.record("bounded_multi_agent_coordination", True, "grant, causal proposals, budgets, and reconciliation agree")
    except (KeyError, TypeError, ValueError) as error:
        result.status = Status.FAILED
        result.record("bounded_multi_agent_coordination", False, str(error))
    return result.finish()
