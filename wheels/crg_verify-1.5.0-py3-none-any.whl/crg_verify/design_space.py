"""Stdlib-only verifier for the agent design-space result envelope.

The checker is code-separated from ``crg_cli.design_space`` and imports no
producer, model, geometry, generation, or certification package.  It
reconstructs envelope bindings, the bounded compiler-operator-DAG generator
closure, exact planar R/Gamma/K, induced retained spaces, and delegates the
embedded SafeCommitmentArtifact to this package's independent finite/exact
verifier.  It imports no producer or generator code.
"""
from __future__ import annotations

from fractions import Fraction
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple

from .arith import ZERO, ArithError, fmt, rational
from .canonical import CanonicalError, canonical_bytes, content_hash, hash_without
from .certificate import Level, Status, VerificationResult, derive_claim_scope
from .commitment import verify_safe_commitment

__all__ = ["verify_agent_design_space"]

SCHEMA_VERSION = "1.5.0"
PROFILE = "crg-agent-design-space/compiler-operator-dag@1"
GENERATOR_ID = "crg-generate.reference.compiler-graph@0.2.0"
GENERATOR_DEFINITION_HASH = (
    "sha256:4afbe44ce5337eb9dd126aacfe808430e5a6f2ff494a05daaf9feedb7c2de6db"
)
GENERATOR_SET_HASH = "sha256:67fec4918bd95c9105869c7154850359f75f83dc40cafb12e8e5ffde144aa110"
TRANSFORM_FUSE = "fuse-adjacent-operators"
TRANSFORM_INLINE = "inline-fused-intermediate"
TRANSFORM_REORDER = "reorder-independent-operators"
TRANSFORMATIONS = (TRANSFORM_FUSE, TRANSFORM_INLINE, TRANSFORM_REORDER)
CLOSURE_PROCEDURE = (
    "breadth-first fixpoint of the declared generator set: the frontier is expanded in "
    "ascending realization-identifier order, generators are applied in ascending "
    "identity@version order, every child identity is derived from (parent, generator, "
    "transformation, exact signature, attributes), and expansion stops when one full "
    "sweep produces no identity that is not already present"
)
MAX_DEPTH = 64
MAX_REALIZATIONS = 4096
MAX_OPERATORS = 64
MAX_DEPENDENCIES = 256
MAX_DECISIONS = 32
MAX_POLICIES = 16
MAX_IDENTIFIER_LENGTH = 128
MAX_EXACT_TEXT_LENGTH = 128
MAX_REORDERINGS = 16
MAX_RESULT_BYTES = 16 * 1024 * 1024
MAX_ANALYSIS_WORK_UNITS = 512
MAX_VERIFIER_JSON_DEPTH = 64
MAX_VERIFIER_JSON_NODES = MAX_OPERATORS * MAX_REALIZATIONS
MAX_VERIFIER_CONTAINER_ITEMS = 4 * MAX_REALIZATIONS
MAX_VERIFIER_STRING_CHARACTERS = MAX_RESULT_BYTES // 16
GENERATOR_REPLAY_PROFILE = "crg-verify/compiler-operator-dag-closure@1"
VERIFICATION_SCOPE = "COMPILER_DAG_CLOSURE_GEOMETRY_AND_SAFE_COMMITMENT"
REPLAY_REQUIREMENT = (
    "the code-separated stdlib verifier must independently reexecute the pinned bounded "
    "compiler-DAG generator closure; the producer trace is not proof"
)
EXPECTED_SCHEMA = {
    "coordinates": [
        {
            "identifier": "peak_live_memory",
            "quantity": "compiler.peak_live_memory",
            "unit": "word",
            "direction": "MINIMIZE",
            "accounting_scope": "per-invocation",
        },
        {
            "identifier": "instruction_count",
            "quantity": "compiler.instruction_count",
            "unit": "instruction",
            "direction": "MINIMIZE",
            "accounting_scope": "per-invocation",
        },
    ],
    "technology_context": "an abstract single-address-space machine with no memory hierarchy",
}

_TOP_LEVEL_FIELDS = {
    "record_type", "schema_version", "profile", "request_id", "request_hash", "request",
    "graph", "generation_source", "generation_context", "generation_report",
    "represented_family", "geometry", "safe_commitment", "reduced_search_spaces",
    "resource_boundary", "refusals", "authority", "replay", "verification_target",
    "result_hash",
}
_RESOURCE_FIELDS = {
    "profile_caps", "input_counts", "applied_limits", "explored_realizations",
    "accepted_realizations", "rejected_candidates", "ungenerated_regions", "truncated",
    "reached_fixpoint", "depth_reached", "analysis_work_units",
    "generation_probe_max_realizations", "canonical_result_bytes",
}
_REPLAY_FIELDS = {
    "profile", "generator_replay_profile", "source_fingerprint", "context_fingerprint",
    "generator_definition_hashes", "canonical_output_hash", "closure_trace_present",
    "generator_closure_reexecution_status", "requirement",
}


def _closed_shape_failures(result: Mapping[str, Any]) -> List[str]:
    failures: List[str] = []
    if (
        len(result) != len(_TOP_LEVEL_FIELDS)
        or any(key not in _TOP_LEVEL_FIELDS for key in result)
    ):
        failures.append("top-level result fields differ from the registered closed envelope")
    expected_shapes = (
        ("graph", {"input_kind", "model", "graph_hash"}),
        ("represented_family", {"bundle_hash", "bundle"}),
        (
            "authority",
            {"execution_authorized", "lifecycle_transition_authorized", "release_authorized", "scope"},
        ),
        ("replay", _REPLAY_FIELDS),
        (
            "verification_target",
            {"program", "scope", "safe_commitment_hash", "generator_closure_reexecution"},
        ),
        ("resource_boundary", _RESOURCE_FIELDS),
    )
    for name, fields in expected_shapes:
        value = result.get(name)
        if (
            not isinstance(value, dict)
            or len(value) != len(fields)
            or any(key not in fields for key in value)
        ):
            failures.append(f"{name} fields differ from the registered closed envelope")
    for name in (
        "request", "generation_source", "generation_context", "generation_report",
        "geometry", "safe_commitment",
    ):
        if not isinstance(result.get(name), dict):
            failures.append(f"{name} must be an object")
    for name in ("reduced_search_spaces", "refusals"):
        if not isinstance(result.get(name), list):
            failures.append(f"{name} must be an array")
    authority = result.get("authority")
    if not isinstance(authority, dict):
        authority = {}
    if authority.get("scope") != "NON_MUTATING_DESIGN_ANALYSIS_ONLY":
        failures.append("authority scope is not the registered non-mutating scope")
    replay = result.get("replay")
    if not isinstance(replay, dict):
        replay = {}
    if replay.get("profile") != "crg-agent-design-space/trace-binding@1":
        failures.append("replay trace-binding profile differs from the registered profile")
    return failures


def _resource_preflight_failures(result: Mapping[str, Any]) -> List[str]:
    """Fail fast on hostile decoded JSON before canonical hashing or reconstruction."""
    failures: List[str] = []

    def bounded(value: Any, maximum: int, path: str) -> None:
        if isinstance(value, (list, dict)) and len(value) > maximum:
            failures.append(f"{path} has {len(value)} items; verifier cap is {maximum}")

    represented = result.get("represented_family") or {}
    bundle = represented.get("bundle") if isinstance(represented, dict) else None
    if isinstance(bundle, dict):
        bounded(bundle.get("realizations"), MAX_REALIZATIONS, "represented_family.bundle.realizations")
        bounded(bundle.get("rejected"), MAX_REALIZATIONS, "represented_family.bundle.rejected")
    bounded(result.get("reduced_search_spaces"), MAX_POLICIES, "reduced_search_spaces")
    bounded(result.get("refusals"), 2 * MAX_REALIZATIONS, "refusals")

    report = result.get("generation_report") or {}
    if isinstance(report, dict):
        for name, maximum in (
            ("accepted", MAX_REALIZATIONS),
            ("rejected", MAX_REALIZATIONS),
            ("ungenerated", MAX_REALIZATIONS),
            ("obligations", 3 * MAX_REALIZATIONS),
            ("fibers", MAX_REALIZATIONS),
            ("dependency_edges", 2 * MAX_REALIZATIONS),
            ("warnings", MAX_REALIZATIONS),
        ):
            bounded(report.get(name), maximum, f"generation_report.{name}")
        closure = report.get("closure") or {}
        if isinstance(closure, dict):
            for name, maximum in (
                ("invocations", MAX_REALIZATIONS),
                ("failures", MAX_REALIZATIONS),
                ("ungenerated", MAX_REALIZATIONS),
                ("warnings", MAX_REALIZATIONS),
                ("unexpanded", MAX_REALIZATIONS),
            ):
                bounded(closure.get(name), maximum, f"generation_report.closure.{name}")

    commitment = result.get("safe_commitment") or {}
    if isinstance(commitment, dict):
        policies = commitment.get("policies")
        evaluations = commitment.get("evaluations")
        family = commitment.get("family") or {}
        registry = commitment.get("registry") or {}
        bounded(policies, MAX_POLICIES, "safe_commitment.policies")
        bounded(evaluations, MAX_POLICIES, "safe_commitment.evaluations")
        if isinstance(family, dict):
            bounded(family.get("decisions"), MAX_DECISIONS, "safe_commitment.family.decisions")
        if isinstance(registry, dict):
            bounded(registry.get("entries"), MAX_REALIZATIONS, "safe_commitment.registry.entries")
            registry_bundle = registry.get("bundle") or {}
            if isinstance(registry_bundle, dict):
                bounded(
                    registry_bundle.get("realizations"),
                    MAX_REALIZATIONS,
                    "safe_commitment.registry.bundle.realizations",
                )
        assessment_count = decision_result_count = 0
        if isinstance(evaluations, list):
            for index, evaluation in enumerate(evaluations[: MAX_POLICIES + 1]):
                if not isinstance(evaluation, dict):
                    continue
                bounded(evaluation.get("retained_ids"), MAX_REALIZATIONS, f"evaluation[{index}].retained_ids")
                bounded(evaluation.get("pruned_ids"), MAX_REALIZATIONS, f"evaluation[{index}].pruned_ids")
                bounded(evaluation.get("retained_fibers"), MAX_REALIZATIONS, f"evaluation[{index}].retained_fibers")
                assessments = evaluation.get("pruning_assessments")
                decisions = evaluation.get("decision_results")
                bounded(assessments, MAX_ANALYSIS_WORK_UNITS, f"evaluation[{index}].pruning_assessments")
                bounded(decisions, MAX_DECISIONS, f"evaluation[{index}].decision_results")
                assessment_count += len(assessments) if isinstance(assessments, list) else 0
                decision_result_count += len(decisions) if isinstance(decisions, list) else 0
        if assessment_count > MAX_ANALYSIS_WORK_UNITS:
            failures.append(
                f"safe_commitment has {assessment_count} pruning assessments; verifier cap is "
                f"{MAX_ANALYSIS_WORK_UNITS}"
            )
        if decision_result_count > MAX_DECISIONS * MAX_POLICIES:
            failures.append("safe_commitment decision-result cross-product exceeds profile caps")

    reductions = result.get("reduced_search_spaces")
    reduction_assessments = reduction_decisions = 0
    if isinstance(reductions, list):
        for index, reduction in enumerate(reductions[: MAX_POLICIES + 1]):
            if not isinstance(reduction, dict):
                continue
            for name in ("retained_ids", "pruned_ids", "retained_realizations"):
                bounded(reduction.get(name), MAX_REALIZATIONS, f"reduction[{index}].{name}")
            bounded(reduction.get("certificates"), MAX_ANALYSIS_WORK_UNITS, f"reduction[{index}].certificates")
            assessments = reduction.get("pruning_assessments")
            decisions = reduction.get("decision_results")
            bounded(assessments, MAX_ANALYSIS_WORK_UNITS, f"reduction[{index}].pruning_assessments")
            bounded(decisions, MAX_DECISIONS, f"reduction[{index}].decision_results")
            reduction_assessments += len(assessments) if isinstance(assessments, list) else 0
            reduction_decisions += len(decisions) if isinstance(decisions, list) else 0
    if reduction_assessments > MAX_ANALYSIS_WORK_UNITS:
        failures.append("reduced-space assessment cross-product exceeds the verifier work cap")
    if reduction_decisions > MAX_DECISIONS * MAX_POLICIES:
        failures.append("reduced-space decision-result cross-product exceeds profile caps")
    if failures:
        return failures

    stack: List[Tuple[Any, int, str, bool]] = [(result, 0, "result", False)]
    active_containers: set[int] = set()
    nodes = 0
    while stack:
        value, depth, path, exiting = stack.pop()
        if exiting:
            active_containers.discard(id(value))
            continue
        nodes += 1
        if nodes > MAX_VERIFIER_JSON_NODES:
            return [
                f"decoded result exceeds verifier node cap {MAX_VERIFIER_JSON_NODES}"
            ]
        if depth > MAX_VERIFIER_JSON_DEPTH:
            return [f"decoded result exceeds verifier depth cap {MAX_VERIFIER_JSON_DEPTH}"]
        if isinstance(value, str):
            if len(value) > MAX_VERIFIER_STRING_CHARACTERS:
                return [
                    f"{path} exceeds verifier string cap {MAX_VERIFIER_STRING_CHARACTERS}"
                ]
            continue
        if value is None or isinstance(value, (bool, int, float)):
            continue
        if isinstance(value, (dict, list)):
            identity = id(value)
            if identity in active_containers:
                return [f"{path} contains a non-JSON container cycle"]
            active_containers.add(identity)
            stack.append((value, depth, path, True))
            if len(value) > MAX_VERIFIER_CONTAINER_ITEMS:
                return [
                    f"{path} has {len(value)} items; generic verifier container cap is "
                    f"{MAX_VERIFIER_CONTAINER_ITEMS}"
                ]
            if isinstance(value, dict):
                for key, item in value.items():
                    if not isinstance(key, str):
                        return [f"{path} contains a non-string object key"]
                    stack.append((item, depth + 1, f"{path}.{key}", False))
            else:
                for index, item in enumerate(value):
                    stack.append((item, depth + 1, f"{path}[{index}]", False))
            continue
        return [f"{path} contains non-JSON value {type(value).__name__}"]
    try:
        encoded_size = len(canonical_bytes(result))
    except Exception as error:
        return [f"decoded result is not canonically encodable: {error}"]
    if encoded_size > MAX_RESULT_BYTES:
        return [
            f"canonical result is {encoded_size} bytes; verifier cap is {MAX_RESULT_BYTES}"
        ]
    return []


def _nested_unknown_field_failures(result: Mapping[str, Any]) -> List[str]:
    """Reject schema-forbidden nested properties without importing producer schemas."""
    failures: List[str] = []

    def closed(value: Any, allowed: Iterable[str], path: str) -> None:
        if not isinstance(value, dict):
            return
        unknown = sorted(set(value) - set(allowed))
        if unknown:
            failures.append(f"{path} has schema-forbidden field(s): {unknown}")

    def exact(value: Any, path: str) -> None:
        closed(value, {"exact"}, path)

    def signature(value: Any, path: str) -> None:
        if isinstance(value, list):
            for index, item in enumerate(value):
                exact(item, f"{path}[{index}]")

    def coordinate_schema(value: Any, path: str) -> None:
        closed(value, {"coordinates", "technology_context"}, path)
        if isinstance(value, dict) and isinstance(value.get("coordinates"), list):
            for index, item in enumerate(value["coordinates"]):
                closed(
                    item,
                    {"identifier", "quantity", "unit", "direction", "accounting_scope"},
                    f"{path}.coordinates[{index}]",
                )

    def completeness(value: Any, path: str) -> None:
        closed(
            value,
            {
                "basis_type", "declared_universe", "source_or_generator_hash",
                "closure_procedure", "closure_proof", "truncation_rule",
                "generator_versions", "known_omissions", "dependencies",
                "remainder_bound", "validity",
            },
            path,
        )

    def realization(value: Any, path: str) -> None:
        closed(
            value,
            {
                "realization_id", "signature", "legality", "evidence_class", "attributes",
                "witness", "parent", "generator",
            },
            path,
        )
        if isinstance(value, dict):
            signature(value.get("signature"), f"{path}.signature")

    def bundle(value: Any, path: str) -> None:
        closed(
            value,
            {"bundle_id", "schema", "realizations", "completeness", "rejected", "source_fingerprint"},
            path,
        )
        if not isinstance(value, dict):
            return
        coordinate_schema(value.get("schema"), f"{path}.schema")
        completeness(value.get("completeness"), f"{path}.completeness")
        for index, item in enumerate(value.get("realizations") or []):
            realization(item, f"{path}.realizations[{index}]")
        for index, item in enumerate(value.get("rejected") or []):
            closed(
                item,
                {
                    "realization_id", "legality", "reason", "generator", "transformation",
                    "parent", "transformations", "reason_code",
                },
                f"{path}.rejected[{index}]",
            )

    source = result.get("generation_source") or {}
    closed(
        source,
        {
            "source_id", "source_type", "seeds", "computation_contract", "resource_contract",
            "hierarchy_contract", "metadata", "declared_universe",
        },
        "generation_source",
    )
    if isinstance(source, dict):
        for index, item in enumerate(source.get("seeds") or []):
            realization(item, f"generation_source.seeds[{index}]")
        for name in ("computation_contract", "resource_contract"):
            closed(
                source.get(name),
                {"contract_id", "version", "graph_hash", "memory_capacity_words"},
                f"generation_source.{name}",
            )

    context = result.get("generation_context") or {}
    closed(
        context,
        {"schema", "capabilities", "parameters", "permissions", "declared_universe", "validity"},
        "generation_context",
    )
    if isinstance(context, dict):
        coordinate_schema(context.get("schema"), "generation_context.schema")
        parameters = context.get("parameters")
        closed(parameters, {"operator_dag"}, "generation_context.parameters")

    report = result.get("generation_report") or {}
    closed(
        report,
        {
            "source", "context_fingerprint", "engine", "generators",
            "generator_definition_hashes", "contract_violations", "accepted", "rejected",
            "legality_tally", "ungenerated", "obligations", "fibers", "dependency_edges",
            "completeness_rationale", "claim_scope", "warnings", "closure",
            "completeness_basis", "bundle_id", "canonical_output_hash",
        },
        "generation_report",
    )
    if isinstance(report, dict):
        closed(report.get("source"), {"source_id", "source_type", "fingerprint"}, "generation_report.source")
        closed(report.get("engine"), {"id", "version"}, "generation_report.engine")
        completeness(report.get("completeness_basis"), "generation_report.completeness_basis")
        for index, item in enumerate(report.get("rejected") or []):
            closed(
                item,
                {"realization_id", "legality", "reason", "generator", "transformation", "parent"},
                f"generation_report.rejected[{index}]",
            )
        for index, item in enumerate(report.get("ungenerated") or []):
            closed(
                item,
                {"generator", "transformations", "legality", "reason_code", "reason"},
                f"generation_report.ungenerated[{index}]",
            )
        for index, item in enumerate(report.get("obligations") or []):
            closed(
                item,
                {
                    "obligation_type", "realization_id", "name", "evidence_class", "value",
                    "unit", "scope", "source",
                },
                f"generation_report.obligations[{index}]",
            )
        for index, item in enumerate(report.get("fibers") or []):
            closed(item, {"signature", "realization_ids"}, f"generation_report.fibers[{index}]")
        for index, item in enumerate(report.get("dependency_edges") or []):
            closed(
                item,
                {
                    "edge_id", "source", "target", "edge_type", "minimum_action", "transitive",
                    "validity_propagation_rule", "edge_version", "source_property", "scope",
                    "invalidation_predicate",
                },
                f"generation_report.dependency_edges[{index}]",
            )
        closure = report.get("closure") or {}
        closed(
            closure,
            {
                "reached_fixpoint", "truncated", "depth_reached", "size", "generator_set_hash",
                "generator_versions", "definition_hashes", "closure_procedure",
                "truncation_rule", "declared_max_depth", "declared_max_size",
                "effective_max_depth", "effective_max_size", "unexpanded", "invocations",
                "failures", "ungenerated", "warnings",
            },
            "generation_report.closure",
        )
        if isinstance(closure, dict):
            for index, item in enumerate(closure.get("invocations") or []):
                closed(
                    item,
                    {"generator", "definition_hash", "parent_id", "depth", "proposed", "accepted", "outcome", "refused"},
                    f"generation_report.closure.invocations[{index}]",
                )
            for index, item in enumerate(closure.get("failures") or []):
                closed(
                    item,
                    {"generator", "definition_hash", "parent_id", "reason", "failure_semantics"},
                    f"generation_report.closure.failures[{index}]",
                )

    represented = result.get("represented_family") or {}
    if isinstance(represented, dict):
        bundle(represented.get("bundle"), "represented_family.bundle")

    geometry = result.get("geometry") or {}
    closed(geometry, {"R", "GAMMA", "K"}, "geometry")
    if isinstance(geometry, dict):
        record_fields = {
            "R": {"record_type", "schema", "fibers", "completeness"},
            "GAMMA": {"record_type", "schema", "frontier", "recession_cone", "dominated_available", "completeness"},
            "K": {"record_type", "schema", "vertices", "halfspaces", "recession_cone", "completeness"},
        }
        for name, allowed in record_fields.items():
            carrier = geometry.get(name) or {}
            closed(carrier, {"root_hash", "record"}, f"geometry.{name}")
            if isinstance(carrier, dict):
                record = carrier.get("record") or {}
                closed(record, allowed, f"geometry.{name}.record")
                if isinstance(record, dict):
                    coordinate_schema(record.get("schema"), f"geometry.{name}.record.schema")
                    completeness(record.get("completeness"), f"geometry.{name}.record.completeness")
                    for field in ("frontier", "vertices"):
                        for index, point in enumerate(record.get(field) or []):
                            signature(point, f"geometry.{name}.record.{field}[{index}]")
                    for index, fiber in enumerate(record.get("fibers") or []):
                        closed(fiber, {"signature", "realization_ids"}, f"geometry.R.record.fibers[{index}]")
                        if isinstance(fiber, dict):
                            signature(fiber.get("signature"), f"geometry.R.record.fibers[{index}].signature")

    def derivation(value: Any, path: str) -> None:
        closed(
            value,
            {"query_hash", "mapping_table_version", "decision_class", "required_object", "rule_cited", "notes", "refusals"},
            path,
        )

    def decision_result(value: Any, path: str) -> None:
        closed(
            value,
            {"decision_id", "status", "required_object", "soundness_derivation", "detail", "claim_consequence"},
            path,
        )
        if isinstance(value, dict):
            derivation(value.get("soundness_derivation"), f"{path}.soundness_derivation")

    def assessment(value: Any, path: str) -> None:
        closed(value, {"record_type", "candidate_id", "decision_id", "conditions", "authorized", "certificate"}, path)
        if not isinstance(value, dict):
            return
        for index, condition in enumerate(value.get("conditions") or []):
            closed(condition, {"number", "identifier", "status", "detail", "evidence"}, f"{path}.conditions[{index}]")
        closed(
            value.get("certificate"),
            {"pruned_id", "lower_bound", "incumbent_id", "incumbent_upper", "scope_id", "tie_policy_satisfied", "geometry_preserved", "dependencies_valid", "certificate_hash"},
            f"{path}.certificate",
        )

    commitment = result.get("safe_commitment") or {}
    closed(
        commitment,
        {"record_type", "schema_version", "profile", "artifact_id", "family", "registry", "policies", "evaluations", "artifact_hash"},
        "safe_commitment",
    )
    if isinstance(commitment, dict):
        family = commitment.get("family") or {}
        closed(family, {"record_type", "family_id", "decisions", "scenario_scope", "authority", "validity", "family_hash"}, "safe_commitment.family")
        if isinstance(family, dict):
            for index, item in enumerate(family.get("decisions") or []):
                closed(item, {"decision_id", "scope", "derivation"}, f"safe_commitment.family.decisions[{index}]")
                if isinstance(item, dict):
                    closed(
                        item.get("scope"),
                        {"scope_id", "observation_level", "objective_family", "technology_domain", "tie_tolerance", "retain_all_ties", "retention_policy", "uncertainty_mode", "validity", "coordinate_schema"},
                        f"safe_commitment.family.decisions[{index}].scope",
                    )
                    derivation(item.get("derivation"), f"safe_commitment.family.decisions[{index}].derivation")
        registry = commitment.get("registry") or {}
        closed(registry, {"bundle_id", "bundle_hash", "bundle", "schema", "completeness", "entries"}, "safe_commitment.registry")
        if isinstance(registry, dict):
            bundle(registry.get("bundle"), "safe_commitment.registry.bundle")
            coordinate_schema(registry.get("schema"), "safe_commitment.registry.schema")
            completeness(registry.get("completeness"), "safe_commitment.registry.completeness")
            for index, item in enumerate(registry.get("entries") or []):
                closed(item, {"realization_id", "signature", "legality", "attributes", "evidence_class"}, f"safe_commitment.registry.entries[{index}]")
                if isinstance(item, dict):
                    signature(item.get("signature"), f"safe_commitment.registry.entries[{index}].signature")
        for index, item in enumerate(commitment.get("policies") or []):
            closed(item, {"record_type", "policy_id", "family_id", "policy", "parameters", "protected_ids", "protected_classes"}, f"safe_commitment.policies[{index}]")
        for index, evaluation in enumerate(commitment.get("evaluations") or []):
            path = f"safe_commitment.evaluations[{index}]"
            closed(
                evaluation,
                {"record_type", "policy_id", "family_id", "policy", "status", "retained_ids", "pruned_ids", "retained_fibers", "geometry_preview", "decision_results", "pruning_assessments", "regret_evidence", "regret_bounds", "refusals"},
                path,
            )
            if not isinstance(evaluation, dict):
                continue
            closed(evaluation.get("geometry_preview"), {"R", "fibers", "GAMMA", "K"}, f"{path}.geometry_preview")
            for child_index, item in enumerate(evaluation.get("decision_results") or []):
                decision_result(item, f"{path}.decision_results[{child_index}]")
            for child_index, item in enumerate(evaluation.get("pruning_assessments") or []):
                assessment(item, f"{path}.pruning_assessments[{child_index}]")
            for child_index, item in enumerate(evaluation.get("regret_evidence") or []):
                closed(item, {"record_type", "witness_id", "decision_id", "full_registry_hash", "retained_registry_hash", "lost_element", "objective", "family_membership_proof", "full_generators", "retained_generators", "full_infimum", "retained_infimum", "gap", "numeric_interval", "evidence_interval", "validity", "completeness", "scope", "dependencies", "verification_program", "evidence_class", "witness_hash"}, f"{path}.regret_evidence[{child_index}]")
            for child_index, item in enumerate(evaluation.get("regret_bounds") or []):
                closed(item, {"record_type", "fact_id", "decision_id", "objective_family", "coordinate_order", "full_values", "retained_ids", "bound", "tolerance", "accepted", "completeness", "dependencies", "proof_profile", "evidence_class", "fact_hash"}, f"{path}.regret_bounds[{child_index}]")

    for index, reduction in enumerate(result.get("reduced_search_spaces") or []):
        path = f"reduced_search_spaces[{index}]"
        closed(
            reduction,
            {"policy_id", "policy", "status", "claim_scope", "completeness", "retained_ids", "pruned_ids", "retained_realizations", "decision_results", "pruning_assessments", "certificates", "refusals", "execution_authorized"},
            path,
        )
        if not isinstance(reduction, dict):
            continue
        completeness(reduction.get("completeness"), f"{path}.completeness")
        for child_index, item in enumerate(reduction.get("retained_realizations") or []):
            realization(item, f"{path}.retained_realizations[{child_index}]")
        for child_index, item in enumerate(reduction.get("decision_results") or []):
            decision_result(item, f"{path}.decision_results[{child_index}]")
        for child_index, item in enumerate(reduction.get("pruning_assessments") or []):
            assessment(item, f"{path}.pruning_assessments[{child_index}]")

    for index, item in enumerate(result.get("refusals") or []):
        closed(item, {"source", "detail"}, f"refusals[{index}]")
    boundary = result.get("resource_boundary") or {}
    if isinstance(boundary, dict):
        closed(boundary.get("profile_caps"), set(_profile_caps()), "resource_boundary.profile_caps")
        closed(
            boundary.get("input_counts"),
            {"operators", "dependencies", "decisions", "policies", "max_reorderings", "max_identifier_length_observed", "max_exact_text_length_observed"},
            "resource_boundary.input_counts",
        )
        closed(boundary.get("applied_limits"), {"max_realizations", "max_depth"}, "resource_boundary.applied_limits")
    return failures


def _point(raw: Any) -> Tuple[Fraction, ...]:
    if not isinstance(raw, list) or not raw:
        raise ValueError("a realization signature must be a non-empty array")
    return tuple(rational(value) for value in raw)


def _canonical_point(point: Sequence[Fraction]) -> List[dict]:
    return [{"exact": fmt(value)} for value in point]


def _pareto(points: Iterable[Tuple[Fraction, ...]]) -> List[Tuple[Fraction, ...]]:
    unique = sorted(set(points))
    return [
        point
        for point in unique
        if not any(
            other != point
            and all(left <= right for left, right in zip(other, point))
            and any(left < right for left, right in zip(other, point))
            for other in unique
        )
    ]


def _cross(
    origin: Tuple[Fraction, ...],
    first: Tuple[Fraction, ...],
    second: Tuple[Fraction, ...],
) -> Fraction:
    return (
        (first[0] - origin[0]) * (second[1] - origin[1])
        - (first[1] - origin[1]) * (second[0] - origin[0])
    )


def _planar_k(points: Iterable[Tuple[Fraction, ...]]) -> List[Tuple[Fraction, ...]]:
    frontier = sorted(_pareto(points))
    if any(len(point) != 2 for point in frontier):
        raise ValueError("the registered design-space verifier supports planar K only")
    hull: List[Tuple[Fraction, ...]] = []
    for point in frontier:
        while len(hull) >= 2 and _cross(hull[-2], hull[-1], point) <= ZERO:
            hull.pop()
        hull.append(point)
    return hull


def _geometry_failures(result: Mapping[str, Any], bundle: Mapping[str, Any]) -> List[str]:
    failures: List[str] = []
    realizations = bundle.get("realizations")
    if not isinstance(realizations, list) or not realizations:
        return ["represented bundle must contain realizations"]
    schema = bundle.get("schema")
    completeness = bundle.get("completeness")
    if not isinstance(schema, dict) or not isinstance(completeness, dict):
        return ["represented bundle must carry schema and completeness objects"]
    grouped: Dict[Tuple[Fraction, ...], List[str]] = {}
    try:
        for item in realizations:
            if not isinstance(item, dict):
                raise ValueError("every realization must be an object")
            identifier = item.get("realization_id")
            if not isinstance(identifier, str) or not identifier:
                raise ValueError("every realization needs a non-empty identity")
            if item.get("legality") == "LEGAL":
                grouped.setdefault(_point(item.get("signature")), []).append(identifier)
    except (ArithError, TypeError, ValueError) as error:
        return [f"represented family is not exact and reconstructible: {error}"]
    if not grouped:
        return ["represented family has no legal realization"]

    r_expected = {
        "record_type": "R",
        "schema": schema,
        "fibers": [
            {
                "signature": _canonical_point(point),
                "realization_ids": sorted(grouped[point]),
            }
            for point in sorted(grouped)
        ],
        "completeness": completeness,
    }
    frontier = _pareto(grouped)
    gamma_expected = {
        "record_type": "GAMMA",
        "schema": schema,
        "frontier": [_canonical_point(point) for point in frontier],
        "recession_cone": "NONNEGATIVE_ORTHANT",
        "dominated_available": True,
        "completeness": completeness,
    }
    k_expected = {
        "record_type": "K",
        "schema": schema,
        "vertices": [_canonical_point(point) for point in _planar_k(grouped)],
        "recession_cone": "NONNEGATIVE_ORTHANT",
        "completeness": completeness,
    }
    geometry = result.get("geometry")
    if not isinstance(geometry, dict):
        return ["geometry must be an object"]
    for name, expected in (("R", r_expected), ("GAMMA", gamma_expected), ("K", k_expected)):
        carried = geometry.get(name)
        if not isinstance(carried, dict):
            failures.append(f"geometry {name} is absent")
            continue
        record = carried.get("record")
        if record != expected:
            failures.append(f"geometry {name} does not equal the independently reconstructed record")
        try:
            actual = content_hash(record)
        except (CanonicalError, TypeError, ValueError) as error:
            failures.append(f"geometry {name} cannot be hashed: {error}")
        else:
            if carried.get("root_hash") != actual:
                failures.append(f"geometry {name} root hash does not seal its record")
    return failures


def _reduction_failures(result: Mapping[str, Any], bundle: Mapping[str, Any]) -> List[str]:
    failures: List[str] = []
    commitment = result.get("safe_commitment")
    reductions = result.get("reduced_search_spaces")
    if not isinstance(commitment, dict) or not isinstance(reductions, list):
        return ["safe_commitment and reduced_search_spaces must be present"]
    evaluations = commitment.get("evaluations")
    if not isinstance(evaluations, list):
        return ["safe commitment has no evaluation array"]
    by_policy = {
        item.get("policy_id"): item
        for item in evaluations
        if isinstance(item, dict) and isinstance(item.get("policy_id"), str)
    }
    realization_by_id = {
        item.get("realization_id"): item
        for item in bundle.get("realizations", [])
        if isinstance(item, dict) and isinstance(item.get("realization_id"), str)
    }
    seen: set[str] = set()
    claim_scope = derive_claim_scope(bundle.get("completeness") or {})
    for reduction in reductions:
        if not isinstance(reduction, dict):
            failures.append("every reduced search space must be an object")
            continue
        identifier = reduction.get("policy_id")
        evaluation = by_policy.get(identifier)
        if not isinstance(identifier, str) or identifier in seen or evaluation is None:
            failures.append(f"reduction policy identity {identifier!r} is unknown or duplicated")
            continue
        seen.add(identifier)
        for field in (
            "policy", "status", "retained_ids", "pruned_ids", "decision_results",
            "pruning_assessments", "refusals",
        ):
            if reduction.get(field) != evaluation.get(field):
                failures.append(f"reduction {identifier!r} {field} differs from safe commitment")
        expected_records = [
            realization_by_id[item]
            for item in evaluation.get("retained_ids", [])
            if item in realization_by_id
        ]
        if reduction.get("retained_realizations") != expected_records:
            failures.append(f"reduction {identifier!r} retained realization projection differs")
        expected_certificates = [
            item.get("certificate")
            for item in evaluation.get("pruning_assessments", [])
            if isinstance(item, dict) and item.get("authorized") and item.get("certificate")
        ]
        if reduction.get("certificates") != expected_certificates:
            failures.append(f"reduction {identifier!r} certificate projection differs")
        if reduction.get("claim_scope") != claim_scope:
            failures.append(f"reduction {identifier!r} claim scope is not derived from completeness")
        if reduction.get("completeness") != bundle.get("completeness"):
            failures.append(f"reduction {identifier!r} completeness differs from the bundle")
        if reduction.get("execution_authorized") is not False:
            failures.append(f"reduction {identifier!r} improperly grants execution authority")
    if seen != set(by_policy):
        failures.append("reduced search spaces do not cover every safe-commitment evaluation")
    return failures


def _canonical_fraction(value: Fraction) -> str:
    return fmt(value)


def _graph_for_replay(raw: Any) -> dict:
    if not isinstance(raw, dict):
        raise ValueError("compiler operator DAG must be an object")
    expected_fields = {
        "operators", "declared_order", "max_reorderings", "fusion_saving_share",
        "memory_capacity_words",
    }
    if set(raw) != expected_fields:
        raise ValueError("compiler operator DAG fields are not the registered closed profile")
    operators_raw = raw.get("operators")
    order_raw = raw.get("declared_order")
    if not isinstance(operators_raw, dict) or not operators_raw:
        raise ValueError("compiler operator DAG has no operators")
    if len(operators_raw) > MAX_OPERATORS:
        raise ValueError("compiler operator DAG exceeds the operator cap")
    if not isinstance(order_raw, list) or not order_raw:
        raise ValueError("compiler operator DAG has no declared order")
    order: List[str] = []
    for item in order_raw:
        if (
            not isinstance(item, str) or not item or len(item) > MAX_IDENTIFIER_LENGTH
            or "," in item or ">" in item
        ):
            raise ValueError("operator identities must be non-empty and delimiter-free")
        order.append(item)
    if len(set(order)) != len(order) or set(order) != set(operators_raw):
        raise ValueError("declared order must name every operator exactly once")
    position = {name: index for index, name in enumerate(order)}
    operators: Dict[str, dict] = {}
    for name in sorted(operators_raw):
        if not isinstance(name, str) or not name or len(name) > MAX_IDENTIFIER_LENGTH:
            raise ValueError("operator identity is outside the registered length domain")
        body = operators_raw[name]
        if not isinstance(body, dict) or set(body) != {"instructions", "output_words", "consumes"}:
            raise ValueError(f"operator {name!r} is not a closed operator record")
        instructions = rational(body.get("instructions"))
        output_words = rational(body.get("output_words"))
        if any(
            not isinstance(value, str) or len(value) > MAX_EXACT_TEXT_LENGTH
            for value in (body.get("instructions"), body.get("output_words"))
        ):
            raise ValueError(f"operator {name!r} exact text exceeds the registered cap")
        if instructions < ZERO or output_words < ZERO:
            raise ValueError(f"operator {name!r} has a negative exact cost")
        if body.get("instructions") != _canonical_fraction(instructions):
            raise ValueError(f"operator {name!r} instructions are not canonical")
        if body.get("output_words") != _canonical_fraction(output_words):
            raise ValueError(f"operator {name!r} output_words are not canonical")
        consumes_raw = body.get("consumes")
        if not isinstance(consumes_raw, list) or consumes_raw != sorted(set(consumes_raw)):
            raise ValueError(f"operator {name!r} dependencies are not sorted and unique")
        if any(
            not isinstance(item, str) or not item or len(item) > MAX_IDENTIFIER_LENGTH
            for item in consumes_raw
        ):
            raise ValueError(f"operator {name!r} dependency identity is inadmissible")
        consumes: Tuple[str, ...] = tuple(consumes_raw)
        for producer in consumes:
            if producer not in operators_raw:
                raise ValueError(f"operator {name!r} consumes undeclared {producer!r}")
            if position[producer] >= position[name]:
                raise ValueError("declared operator order is not topological")
        operators[name] = {
            "instructions": instructions,
            "output_words": output_words,
            "consumes": consumes,
        }
    dependency_count = sum(len(body["consumes"]) for body in operators.values())
    if dependency_count > MAX_DEPENDENCIES:
        raise ValueError("compiler operator DAG exceeds the dependency cap")
    if len(operators) > 1:
        adjacent = {name: set() for name in operators}
        for consumer, body in operators.items():
            for producer in body["consumes"]:
                adjacent[consumer].add(producer)
                adjacent[producer].add(consumer)
        seen = {order[0]}
        frontier = [order[0]]
        while frontier:
            current = frontier.pop()
            for neighbor in sorted(adjacent[current] - seen):
                seen.add(neighbor)
                frontier.append(neighbor)
        if seen != set(operators):
            raise ValueError("compiler operator DAG is disconnected")
    max_reorderings = raw.get("max_reorderings")
    if (
        isinstance(max_reorderings, bool) or not isinstance(max_reorderings, int)
        or max_reorderings < 0 or max_reorderings > MAX_REORDERINGS
    ):
        raise ValueError("max_reorderings must be a nonnegative integer")
    share_raw = raw.get("fusion_saving_share")
    capacity_raw = raw.get("memory_capacity_words")
    if any(
        not isinstance(value, str) or len(value) > MAX_EXACT_TEXT_LENGTH
        for value in (share_raw, capacity_raw)
    ):
        raise ValueError("compiler operator DAG exact text exceeds the registered cap")
    share = rational(share_raw)
    capacity = rational(capacity_raw)
    if raw.get("fusion_saving_share") != _canonical_fraction(share):
        raise ValueError("fusion_saving_share is not canonical")
    if raw.get("memory_capacity_words") != _canonical_fraction(capacity):
        raise ValueError("memory_capacity_words is not canonical")
    if share < ZERO or share > Fraction(1) or capacity < ZERO:
        raise ValueError("fusion share/capacity is outside the registered exact domain")
    consumers = {
        name: tuple(sorted(other for other in order if name in operators[other]["consumes"]))
        for name in sorted(order)
    }
    return {
        "order": tuple(order),
        "position": position,
        "operators": operators,
        "consumers": consumers,
        "max_reorderings": max_reorderings,
        "fusion_saving_share": share,
        "capacity": capacity,
        "dependency_count": dependency_count,
    }


def _request_input_counts(request: Any, model: Mapping[str, Any]) -> dict:
    if not isinstance(request, dict):
        raise ValueError("request must be an object")
    if set(request) != {
        "record_type", "schema_version", "profile", "request_id", "input_kind",
        "operator_dag", "decisions", "policies", "limits",
    }:
        raise ValueError("request fields differ from the registered closed profile")
    if (
        request.get("record_type") != "AgentDesignSpaceRequest"
        or request.get("schema_version") != SCHEMA_VERSION
        or request.get("profile") != PROFILE
        or request.get("input_kind") != "COMPILER_OPERATOR_DAG"
    ):
        raise ValueError("request constants differ from the registered profile")
    request_id = request.get("request_id")
    if (
        not isinstance(request_id, str) or not request_id
        or len(request_id) > MAX_IDENTIFIER_LENGTH
    ):
        raise ValueError("request identity is outside the registered length domain")
    decisions = request.get("decisions")
    policies = request.get("policies")
    if not isinstance(decisions, list) or not decisions or len(decisions) > MAX_DECISIONS:
        raise ValueError("decision count is outside the registered bounded profile")
    if not isinstance(policies, list) or not policies or len(policies) > MAX_POLICIES:
        raise ValueError("policy count is outside the registered bounded profile")
    identifiers = [request_id, *model["order"], *model["order"]]
    exact_texts = [
        request["operator_dag"]["fusion_saving_share"],
        request["operator_dag"]["memory_capacity_words"],
    ]
    for name in model["order"]:
        operator = request["operator_dag"]["operators"][name]
        identifiers.extend(operator["consumes"])
        exact_texts.extend((operator["instructions"], operator["output_words"]))
    decision_ids: List[str] = []
    for decision in decisions:
        if not isinstance(decision, dict) or set(decision) != {"decision_id", "query"}:
            raise ValueError("every decision must be an object")
        identifier = decision.get("decision_id")
        if (
            not isinstance(identifier, str) or not identifier
            or len(identifier) > MAX_IDENTIFIER_LENGTH
        ):
            raise ValueError("decision identity is outside the registered length domain")
        decision_ids.append(identifier)
        query = decision.get("query")
        if not isinstance(query, dict):
            raise ValueError("every decision query must be an object")
        if not {"objective_family"} <= set(query) <= {
            "objective_family", "ties", "requested_object"
        }:
            raise ValueError("decision query fields differ from the registered closed profile")
        objective = query.get("objective_family")
        if not isinstance(objective, dict) or not {"type"} <= set(objective) <= {
            "type", "weights"
        }:
            raise ValueError("every decision must carry an objective family")
        weights = objective.get("weights") or {}
        if not isinstance(weights, dict):
            raise ValueError("decision weights must be an object")
        exact_texts.extend(weights.values())
        ties = query.get("ties") or {}
        if not isinstance(ties, dict) or not set(ties) <= {
            "policy_tolerance", "retain_all"
        }:
            raise ValueError("decision ties must be an object")
        if "policy_tolerance" in ties:
            exact_texts.append(ties["policy_tolerance"])
    if len(set(decision_ids)) != len(decision_ids):
        raise ValueError("decision identities are duplicated")
    identifiers.extend(decision_ids)
    policy_ids: List[str] = []
    for policy in policies:
        if not isinstance(policy, dict) or set(policy) != {"policy_id", "policy"}:
            raise ValueError("every policy must be an object")
        identifier = policy.get("policy_id")
        if (
            not isinstance(identifier, str) or not identifier
            or len(identifier) > MAX_IDENTIFIER_LENGTH
        ):
            raise ValueError("policy identity is outside the registered length domain")
        policy_ids.append(identifier)
    if len(set(policy_ids)) != len(policy_ids):
        raise ValueError("policy identities are duplicated")
    identifiers.extend(policy_ids)
    if any(
        not isinstance(value, str) or len(value) > MAX_EXACT_TEXT_LENGTH
        for value in exact_texts
    ):
        raise ValueError("request exact text exceeds the registered length domain")
    return {
        "operators": len(model["operators"]),
        "dependencies": model["dependency_count"],
        "decisions": len(decisions),
        "policies": len(policies),
        "max_reorderings": model["max_reorderings"],
        "max_identifier_length_observed": max(map(len, identifiers)),
        "max_exact_text_length_observed": max(map(len, exact_texts)),
    }


def _profile_caps() -> dict:
    return {
        "max_operators": MAX_OPERATORS,
        "max_dependencies": MAX_DEPENDENCIES,
        "max_decisions": MAX_DECISIONS,
        "max_policies": MAX_POLICIES,
        "max_identifier_length": MAX_IDENTIFIER_LENGTH,
        "max_exact_text_length": MAX_EXACT_TEXT_LENGTH,
        "max_reorderings": MAX_REORDERINGS,
        "max_realizations": MAX_REALIZATIONS,
        "max_depth": MAX_DEPTH,
        "max_result_bytes": MAX_RESULT_BYTES,
        "max_analysis_work_units": MAX_ANALYSIS_WORK_UNITS,
    }


def _depends_on(model: Mapping[str, Any], later: str, earlier: str) -> bool:
    frontier = list(model["operators"][later]["consumes"])
    seen: set[str] = set()
    while frontier:
        current = frontier.pop()
        if current in seen:
            continue
        seen.add(current)
        if current == earlier:
            return True
        frontier.extend(model["operators"][current]["consumes"])
    return False


def _signature_for(
    model: Mapping[str, Any], schedule: Sequence[str], fused: str, inlined: str
) -> Tuple[Fraction, Fraction]:
    positions = {name: index for index, name in enumerate(schedule)}
    if set(positions) != set(model["order"]) or len(positions) != len(model["order"]):
        raise ValueError("a replay schedule is not a permutation of the declared DAG")
    occupancy = [ZERO for _ in schedule]
    for name in sorted(model["order"]):
        if name == inlined:
            continue
        start = positions[name]
        consumers = model["consumers"][name]
        end = max(positions[item] for item in consumers) if consumers else start
        for step in range(start, end + 1):
            occupancy[step] += model["operators"][name]["output_words"]
    peak = max(occupancy)
    instructions = sum(
        (model["operators"][name]["instructions"] for name in sorted(model["order"])),
        ZERO,
    )
    if fused:
        producer, separator, consumer = fused.partition(">")
        if not separator or not producer or not consumer:
            raise ValueError("a replay fused pair is malformed")
        instructions -= (
            model["fusion_saving_share"] * model["operators"][consumer]["instructions"]
        )
        if inlined:
            for outside in model["consumers"][inlined]:
                if outside != consumer:
                    instructions += model["operators"][inlined]["instructions"]
    return peak, instructions


def _signature_document(signature: Sequence[Fraction]) -> List[dict]:
    return [{"exact": _canonical_fraction(value)} for value in signature]


def _derive_id(
    parent: Any,
    generator: str,
    transformation: str,
    signature: Sequence[Fraction],
    attributes: Mapping[str, Any],
    prefix: str,
) -> str:
    digest = content_hash(
        {
            "parent": parent,
            "generator": generator,
            "transformation": transformation,
            "signature": _signature_document(signature),
            "attributes": dict(attributes),
        }
    )
    return f"{prefix}-{digest.split(':', 1)[1][:24]}"


def _state_record(state: Mapping[str, Any], legality: str) -> dict:
    record = {
        "realization_id": state["realization_id"],
        "signature": _signature_document(state["signature"]),
        "legality": legality,
        "evidence_class": state["evidence_class"],
        "attributes": dict(state["attributes"]),
    }
    for field in ("witness", "parent", "generator"):
        if state.get(field) is not None:
            record[field] = state[field]
    return record


def _seed_state(model: Mapping[str, Any], source_id: str) -> dict:
    schedule = tuple(model["order"])
    signature = _signature_for(model, schedule, "", "")
    attributes = {
        "schedule": ",".join(schedule),
        "fused_pair": "",
        "inlined_value": "",
        "reorderings": 0,
        "crg_transformation": "SEED",
        "crg_derivation_path": "SEED",
        "crg_depth": 0,
    }
    return {
        "realization_id": _derive_id(
            None, source_id, "SEED", signature, attributes, "seed"
        ),
        "schedule": schedule,
        "fused": "",
        "inlined": "",
        "reorderings": 0,
        "signature": signature,
        "attributes": attributes,
        "evidence_class": "CONSTRUCTIVE",
        "witness": None,
        "parent": None,
        "generator": None,
    }


def _child_state(
    model: Mapping[str, Any],
    parent: Mapping[str, Any],
    transformation: str,
    schedule: Sequence[str],
    fused: str,
    inlined: str,
    reorderings: int,
) -> dict:
    signature = _signature_for(model, schedule, fused, inlined)
    attributes = {
        "schedule": ",".join(schedule),
        "fused_pair": fused,
        "inlined_value": inlined,
        "reorderings": reorderings,
        "crg_transformation": transformation,
        "crg_generator_definition_hash": GENERATOR_DEFINITION_HASH,
        "crg_derivation_path": (
            f"{parent['attributes']['crg_derivation_path']}>{transformation}"
        ),
        "crg_depth": parent["attributes"]["crg_depth"] + 1,
    }
    identifier = _derive_id(
        parent["realization_id"],
        GENERATOR_ID,
        transformation,
        signature,
        attributes,
        "rz",
    )
    return {
        "realization_id": identifier,
        "schedule": tuple(schedule),
        "fused": fused,
        "inlined": inlined,
        "reorderings": reorderings,
        "signature": signature,
        "attributes": attributes,
        "evidence_class": "CONSTRUCTIVE",
        "witness": f"CONSTRUCTIVE_TRANSFORMATION:{GENERATOR_ID}:{transformation}",
        "parent": parent["realization_id"],
        "generator": GENERATOR_ID,
    }


def _propose_states(model: Mapping[str, Any], parent: Mapping[str, Any]) -> List[dict]:
    schedule = tuple(parent["schedule"])
    fused = str(parent["fused"])
    inlined = str(parent["inlined"])
    reorderings = int(parent["reorderings"])
    children: List[dict] = []
    if not fused:
        for position in range(len(schedule) - 1):
            producer, consumer = schedule[position], schedule[position + 1]
            if producer in model["operators"][consumer]["consumes"]:
                children.append(
                    _child_state(
                        model, parent, TRANSFORM_FUSE, schedule,
                        f"{producer}>{consumer}", inlined, reorderings,
                    )
                )
    if fused and not inlined:
        producer = fused.partition(">")[0]
        children.append(
            _child_state(
                model, parent, TRANSFORM_INLINE, schedule, fused, producer, reorderings
            )
        )
    if not fused and reorderings < model["max_reorderings"]:
        for position in range(len(schedule) - 1):
            left, right = schedule[position], schedule[position + 1]
            independent = not _depends_on(model, left, right) and not _depends_on(
                model, right, left
            )
            if not independent or model["position"][left] >= model["position"][right]:
                continue
            reordered = list(schedule)
            reordered[position], reordered[position + 1] = right, left
            children.append(
                _child_state(
                    model, parent, TRANSFORM_REORDER, reordered, fused, inlined,
                    reorderings + 1,
                )
            )
    return children


def _bounded_closure(
    model: Mapping[str, Any], source_id: str, max_depth: int, max_size: int
) -> Tuple[List[dict], dict]:
    seed = _seed_state(model, source_id)
    records = [seed]
    by_id = {seed["realization_id"]: seed}
    frontier = [seed]
    depth = 0
    truncated = False
    truncation_rule = None
    unexpanded: List[str] = []
    invocations: List[dict] = []
    reached_fixpoint = False
    while frontier:
        if depth >= max_depth:
            truncated = True
            truncation_rule = (
                f"MAX_DEPTH={max_depth} (caller-declared): breadth-first expansion was "
                f"stopped at depth {depth} with {len(frontier)} unexpanded parent(s); the "
                "family below that depth was never generated and is UNGENERATED, not empty "
                "(spec 6.11, 21.2 TRUNCATED_BY_DECLARED_RULE)"
            )
            unexpanded = [item["realization_id"] for item in frontier]
            break
        next_frontier: List[dict] = []
        for parent in frontier:
            proposed: List[str] = []
            accepted: List[str] = []
            for child in _propose_states(model, parent):
                identifier = child["realization_id"]
                proposed.append(identifier)
                if identifier in by_id:
                    continue
                if len(by_id) >= max_size:
                    truncated = True
                    truncation_rule = (
                        f"MAX_SIZE={max_size} (caller-declared): expansion was stopped "
                        f"after {len(by_id)} realizations while children of "
                        f"{parent['realization_id']!r} were still being produced; the "
                        "remainder was never generated and is UNGENERATED, not empty "
                        "(spec 6.11, 21.2 TRUNCATED_BY_DECLARED_RULE)"
                    )
                    unexpanded = [parent["realization_id"]] + [
                        item["realization_id"] for item in next_frontier
                    ]
                    break
                by_id[identifier] = child
                records.append(child)
                next_frontier.append(child)
                accepted.append(identifier)
            invocation = {
                "generator": GENERATOR_ID,
                "definition_hash": GENERATOR_DEFINITION_HASH,
                "parent_id": parent["realization_id"],
                "depth": depth,
                "proposed": proposed,
                "outcome": "OK",
            }
            if accepted:
                invocation["accepted"] = accepted
            invocations.append(invocation)
            if truncated:
                break
        if truncated:
            break
        depth += 1
        if not next_frontier:
            reached_fixpoint = True
            break
        frontier = sorted(next_frontier, key=lambda item: item["realization_id"])
    ungenerated: List[dict] = []
    if truncated:
        ungenerated.append(
            {
                "generator": GENERATOR_ID,
                "transformations": list(TRANSFORMATIONS),
                "legality": "UNGENERATED",
                "reason_code": "CLOSURE_TRUNCATED",
                "reason": truncation_rule,
            }
        )
    closure = {
        "reached_fixpoint": reached_fixpoint,
        "truncated": truncated,
        "depth_reached": depth,
        "size": len(records),
        "generator_set_hash": GENERATOR_SET_HASH,
        "generator_versions": [GENERATOR_ID],
        "definition_hashes": {GENERATOR_ID: GENERATOR_DEFINITION_HASH},
        "closure_procedure": CLOSURE_PROCEDURE,
        "effective_max_depth": max_depth,
        "effective_max_size": max_size,
        "invocations": invocations,
        "failures": [],
        "ungenerated": ungenerated,
        "warnings": [],
        "declared_max_depth": max_depth,
        "declared_max_size": max_size,
    }
    if truncation_rule is not None:
        closure["truncation_rule"] = truncation_rule
    if unexpanded:
        closure["unexpanded"] = unexpanded
    return records, closure


def _legality(model: Mapping[str, Any], state: Mapping[str, Any]) -> Tuple[str, str]:
    peak, instructions = state["signature"]
    if peak < ZERO:
        return "ILLEGAL", (
            "crg-generate.nonnegative-signature: coordinate 0 is "
            f"{_canonical_fraction(peak)}; a signature coordinate below zero is not a point "
            "the declared schema can represent (spec 19.1)"
        )
    if instructions < ZERO:
        return "ILLEGAL", (
            "crg-generate.nonnegative-signature: coordinate 1 is "
            f"{_canonical_fraction(instructions)}; a signature coordinate below zero is not "
            "a point the declared schema can represent (spec 19.1)"
        )
    if peak > model["capacity"]:
        return "INFEASIBLE", (
            "crg-generate.reference.compiler-graph.memory-capacity: peak live memory "
            f"{_canonical_fraction(peak)} words exceeds the declared capacity "
            f"{_canonical_fraction(model['capacity'])} words; the schedule is constructible "
            "but not realizable on this machine"
        )
    return "LEGAL", ""


def _expected_completeness(
    source: Mapping[str, Any], context_hash: str, closure: Mapping[str, Any]
) -> Tuple[dict, str, List[str]]:
    declared = source.get("declared_universe")
    if closure["truncated"]:
        region = closure["ungenerated"][0]
        omissions = [f"{region['generator']}: {region['reason']}"]
        if closure.get("unexpanded"):
            members = closure["unexpanded"][:8]
            omissions.append(
                "the unexpanded frontier ("
                + ", ".join(members)
                + (", ..." if len(closure["unexpanded"]) > 8 else "")
                + ") and everything below it is UNGENERATED"
            )
        basis = {
            "basis_type": "TRUNCATED_BY_DECLARED_RULE",
            "declared_universe": declared,
            "source_or_generator_hash": GENERATOR_SET_HASH,
            "closure_procedure": CLOSURE_PROCEDURE,
            "truncation_rule": closure["truncation_rule"],
            "generator_versions": [GENERATOR_ID],
            "known_omissions": omissions,
            "dependencies": [GENERATOR_ID, context_hash],
        }
        rationale = [
            "the closure did not reach a fixpoint: a declared limit stopped it, so the "
            "unexpanded remainder was never generated (spec 6.11, 21.2)"
        ]
        return basis, "PARTIAL_FAMILY", rationale
    basis = {
        "basis_type": "GENERATOR_CLOSED",
        "declared_universe": declared,
        "source_or_generator_hash": GENERATOR_SET_HASH,
        "closure_procedure": CLOSURE_PROCEDURE,
        "closure_proof": (
            "fixpoint: one full sweep of the frontier under every declared generator "
            f"produced no realization identity that was not already present, at depth "
            f"{closure['depth_reached']} over {closure['size']} realization(s), under "
            f"generator set {GENERATOR_SET_HASH}"
        ),
        "generator_versions": [GENERATOR_ID],
        "dependencies": [GENERATOR_ID, context_hash],
    }
    rationale = [
        "the closure reached a fixpoint with no declared limit hit, every generator is "
        "reproducible and declares that it closes the family, and no region was left "
        "unentered (spec 21.2 GENERATOR_CLOSED)"
    ]
    return basis, "GENERATOR_CLOSED_FAMILY", rationale


def _closure_replay_failures(
    artifact: Mapping[str, Any], bundle: Mapping[str, Any]
) -> Tuple[List[str], bool, Dict[str, Any]]:
    failures: List[str] = []
    report = artifact.get("generation_report") or {}
    source = artifact.get("generation_source") or {}
    context = artifact.get("generation_context") or {}
    request = artifact.get("request") or {}
    try:
        model = _graph_for_replay((artifact.get("graph") or {}).get("model"))
        input_counts = _request_input_counts(request, model)
        limits = request.get("limits")
        if not isinstance(limits, dict) or set(limits) != {"max_realizations", "max_depth"}:
            raise ValueError("the applied generation limits are not a closed object")
        max_size, max_depth = limits["max_realizations"], limits["max_depth"]
        if (
            isinstance(max_size, bool) or not isinstance(max_size, int) or max_size <= 0
            or max_size > MAX_REALIZATIONS
            or isinstance(max_depth, bool) or not isinstance(max_depth, int) or max_depth <= 0
            or max_depth > MAX_DEPTH
        ):
            raise ValueError("generation limits are outside the registered bounded profile")
        source_id = source.get("source_id")
        if not isinstance(source_id, str) or not source_id:
            raise ValueError("generation source has no identity")
        graph_hash = content_hash((artifact.get("graph") or {}).get("model"))
        expected_source_id = "agent-design-" + graph_hash.split(":", 1)[1][:24]
        if source_id != expected_source_id:
            raise ValueError("generation source identity is not graph-derived")
        analysis_multiplier = len(request["decisions"]) * len(request["policies"])
        registered_generation_probe_max = min(
            max_size, MAX_ANALYSIS_WORK_UNITS // analysis_multiplier + 1
        )
        resource_boundary = artifact.get("resource_boundary")
        if not isinstance(resource_boundary, dict):
            raise ValueError("resource boundary is absent")
        generation_probe_max = resource_boundary.get(
            "generation_probe_max_realizations"
        )
        if (
            isinstance(generation_probe_max, bool)
            or not isinstance(generation_probe_max, int)
            or generation_probe_max <= 0
            or generation_probe_max > registered_generation_probe_max
        ):
            raise ValueError(
                "generation probe is outside the request and registered work bounds"
            )
        states, expected_closure = _bounded_closure(
            model, source_id, max_depth, generation_probe_max
        )
        if (
            generation_probe_max < registered_generation_probe_max
            and not expected_closure["reached_fixpoint"]
        ):
            raise ValueError(
                "a reduced aggregate-work probe did not reach the generator fixpoint"
            )
        analysis_work_units = (
            len(states) * len(request["decisions"]) * len(request["policies"])
        )
        if analysis_work_units > MAX_ANALYSIS_WORK_UNITS:
            raise ValueError("analysis cross-product exceeds the registered work-unit cap")
    except (ArithError, CanonicalError, KeyError, TypeError, ValueError) as error:
        return [f"compiler-DAG closure input cannot be replayed: {error}"], False, {}

    if context.get("schema") != EXPECTED_SCHEMA or bundle.get("schema") != EXPECTED_SCHEMA:
        failures.append("compiler-DAG coordinate schema differs from the registered profile")
    if source.get("source_type") != "OPERATOR_DAG":
        failures.append("generation source type is not OPERATOR_DAG")
    carried_definitions = report.get("generator_definition_hashes")
    if carried_definitions != {GENERATOR_ID: GENERATOR_DEFINITION_HASH}:
        failures.append("generation report does not carry the pinned compiler generator definition")
    if (artifact.get("replay") or {}).get("generator_definition_hashes") != {
        GENERATOR_ID: GENERATOR_DEFINITION_HASH
    }:
        failures.append("replay does not carry the pinned compiler generator definition")
    if report.get("closure") != expected_closure:
        failures.append("bounded breadth-first invocation/fixpoint trace differs from reexecution")

    evaluated: List[Tuple[dict, str, str]] = []
    for state in states:
        legality, reason = _legality(model, state)
        evaluated.append((_state_record(state, legality), legality, reason))
    expected_records = sorted((item[0] for item in evaluated), key=lambda item: item["realization_id"])
    if bundle.get("realizations") != expected_records:
        failures.append("represented realizations differ from independently regenerated closure")

    seed_source = _state_record(states[0], "UNEVALUATED")
    if source.get("seeds") != [seed_source]:
        failures.append("generation source seed differs from independently reconstructed seed")
    context_hash = content_hash(context)
    source_hash = content_hash(source)
    expected_basis, expected_scope, expected_rationale = _expected_completeness(
        source, context_hash, expected_closure
    )
    if bundle.get("completeness") != expected_basis:
        failures.append("bundle completeness is not derived from replayed closure state")
    if report.get("completeness_basis") != expected_basis:
        failures.append("generation report completeness differs from replayed closure state")
    if report.get("claim_scope") != expected_scope:
        failures.append("generation claim scope differs from replayed completeness")
    if report.get("completeness_rationale") != expected_rationale:
        failures.append("generation completeness rationale differs from replayed closure state")

    expected_bundle_id = "reg-" + content_hash(
        {
            "source": source_hash,
            "context": context_hash,
            "generators": [GENERATOR_ID],
            "generator_set": GENERATOR_SET_HASH,
            "engine": "crg-generate@0.2.0",
        }
    ).split(":", 1)[1][:24]
    if bundle.get("bundle_id") != expected_bundle_id or report.get("bundle_id") != expected_bundle_id:
        failures.append("bundle identity is not independently derived from replay inputs")

    rejected = []
    for record, legality, reason in evaluated:
        if legality == "LEGAL":
            continue
        item = {
            "realization_id": record["realization_id"],
            "legality": legality,
            "reason": reason,
        }
        for field in ("generator",):
            if record.get(field):
                item[field] = record[field]
        transformation = (record.get("attributes") or {}).get("crg_transformation")
        if transformation:
            item["transformation"] = transformation
        if record.get("parent"):
            item["parent"] = record["parent"]
        rejected.append(item)
    expected_ungenerated = list(expected_closure["ungenerated"])
    if report.get("rejected") != rejected:
        failures.append("generation rejected-candidate ledger differs from replayed legality")
    if report.get("ungenerated") != expected_ungenerated:
        failures.append("generation ungenerated regions differ from replayed truncation")
    if bundle.get("rejected", []) != rejected + expected_ungenerated:
        failures.append("bundle rejected/ungenerated ledger differs from replay")

    accepted_ids = sorted(
        record["realization_id"] for record, legality, _reason in evaluated if legality == "LEGAL"
    )
    if report.get("accepted") != accepted_ids:
        failures.append("generation accepted identities differ from replayed legality")
    statuses = ("ILLEGAL", "INFEASIBLE", "LEGAL", "UNEVALUATED", "UNGENERATED", "UNSUPPORTED")
    tally = {status: 0 for status in statuses}
    for _record, legality, _reason in evaluated:
        tally[legality] += 1
    tally["UNGENERATED"] = len(expected_ungenerated)
    if report.get("legality_tally") != tally:
        failures.append("generation legality tally differs from replayed predicates")

    fibers: Dict[str, List[str]] = {}
    for record, legality, _reason in evaluated:
        if legality != "LEGAL":
            continue
        key = content_hash(record["signature"])
        fibers.setdefault(key, []).append(record["realization_id"])
    expected_fibers = {
        key: sorted(value) for key, value in sorted(fibers.items())
    }
    if report.get("fibers") != expected_fibers:
        failures.append("generation fibers differ from replayed legal signatures")

    expected_obligations: List[dict] = []
    for state in states:
        if state["generator"] is None:
            continue
        for name, value, unit in (
            ("peak_live_memory", state["signature"][0], "word"),
            ("instruction_count", state["signature"][1], "instruction"),
        ):
            expected_obligations.append(
                {
                    "obligation_type": "RESOURCE",
                    "realization_id": state["realization_id"],
                    "name": name,
                    "evidence_class": "EXACT",
                    "value": {"exact": _canonical_fraction(value)},
                    "unit": unit,
                    "scope": "per-invocation",
                    "source": GENERATOR_ID,
                }
            )
        materialized = sum(
            1
            for name in sorted(model["order"])
            if model["consumers"][name] and name != state["inlined"]
        )
        expected_obligations.append(
            {
                "obligation_type": "ACCOUNTING",
                "realization_id": state["realization_id"],
                "name": "materialized_intermediates",
                "evidence_class": "EXACT",
                "value": {"exact": str(materialized)},
                "unit": "value",
                "scope": "per-invocation",
                "source": GENERATOR_ID,
            }
        )
    expected_obligations.sort(
        key=lambda item: (item["realization_id"], item["obligation_type"], item["name"])
    )
    if report.get("obligations") != expected_obligations:
        failures.append("generation obligations differ from independent exact extraction")

    complete = (
        not failures
        and expected_closure["reached_fixpoint"]
        and not expected_closure["truncated"]
        and expected_basis["basis_type"] == "GENERATOR_CLOSED"
    )
    facts = {
        "realization_count": len(states),
        "accepted_count": len(accepted_ids),
        "rejected_count": len(rejected),
        "depth_reached": expected_closure["depth_reached"],
        "truncated": expected_closure["truncated"],
        "reached_fixpoint": expected_closure["reached_fixpoint"],
        "generator_definition_hash": GENERATOR_DEFINITION_HASH,
        "input_counts": input_counts,
        "analysis_work_units": analysis_work_units,
    }
    return failures, complete, facts


def _binding_failures(result: Mapping[str, Any]) -> List[str]:
    failures: List[str] = _closed_shape_failures(result)
    request = result.get("request")
    graph = result.get("graph")
    source = result.get("generation_source")
    context = result.get("generation_context")
    report = result.get("generation_report")
    represented = result.get("represented_family")
    replay = result.get("replay")
    if not all(isinstance(item, dict) for item in (request, graph, source, context, report, represented, replay)):
        return ["request, graph, source, context, report, family, and replay must be objects"]
    try:
        request_hash = content_hash(request)
        graph_hash = content_hash(graph.get("model"))
        source_hash = content_hash(source)
        context_hash = content_hash(context)
        bundle = represented.get("bundle")
        bundle_hash = content_hash(bundle)
    except (CanonicalError, TypeError, ValueError) as error:
        return [f"a bound component cannot be canonically hashed: {error}"]
    checks = (
        (result.get("request_hash") == request_hash, "request_hash does not seal request"),
        (result.get("request_id") == request.get("request_id"), "request identity differs"),
        (graph.get("graph_hash") == graph_hash, "graph_hash does not seal graph.model"),
        (graph.get("input_kind") == "COMPILER_OPERATOR_DAG", "graph input kind differs"),
        (graph.get("model") == request.get("operator_dag"), "graph model differs from request"),
        (((context.get("parameters") or {}).get("operator_dag")) == graph.get("model"),
         "generation context is not bound to graph model"),
        (((source.get("computation_contract") or {}).get("graph_hash")) == graph_hash,
         "generation source computation contract is not graph-bound"),
        (((source.get("metadata") or {}).get("request_hash")) == request_hash,
         "generation source metadata is not request-bound"),
        (((report.get("source") or {}).get("fingerprint")) == source_hash,
         "generation report source fingerprint differs"),
        (report.get("context_fingerprint") == context_hash,
         "generation report context fingerprint differs"),
        (represented.get("bundle_hash") == bundle_hash, "bundle_hash does not seal bundle"),
        (report.get("canonical_output_hash") == bundle_hash,
         "generation report output hash differs from bundle"),
        ((bundle or {}).get("source_fingerprint") == source_hash,
         "bundle source fingerprint differs"),
        (replay.get("source_fingerprint") == source_hash,
         "replay source fingerprint differs"),
        (replay.get("context_fingerprint") == context_hash,
         "replay context fingerprint differs"),
        (replay.get("canonical_output_hash") == bundle_hash,
         "replay output hash differs"),
        (replay.get("generator_definition_hashes") == report.get("generator_definition_hashes"),
         "replay generator definition hashes differ"),
        (replay.get("generator_replay_profile") == GENERATOR_REPLAY_PROFILE,
         "generator replay profile differs from the registered independent checker"),
        (replay.get("generator_closure_reexecution_status") == "REQUIRED",
         "producer generator replay requirement is absent"),
        (replay.get("requirement") == REPLAY_REQUIREMENT,
         "generator replay requirement text differs from the registered profile"),
        (replay.get("closure_trace_present") is True and isinstance(report.get("closure"), dict),
         "replay does not carry the required closure trace"),
    )
    failures.extend(detail for passed, detail in checks if not passed)

    commitment = result.get("safe_commitment")
    if not isinstance(commitment, dict):
        failures.append("safe commitment is absent")
    else:
        registry = commitment.get("registry") or {}
        expected_legal_bundle = dict(bundle or {})
        expected_legal_bundle["bundle_id"] = f"{expected_legal_bundle.get('bundle_id')}::legal"
        expected_legal_bundle["realizations"] = [
            item
            for item in (expected_legal_bundle.get("realizations") or [])
            if isinstance(item, dict) and item.get("legality") == "LEGAL"
        ]
        try:
            expected_legal_hash = content_hash(expected_legal_bundle)
        except (CanonicalError, TypeError, ValueError) as error:
            failures.append(f"legal decision-analysis subfamily cannot be hashed: {error}")
            expected_legal_hash = None
        if registry.get("bundle") != expected_legal_bundle:
            failures.append(
                "safe commitment registry is not the exact legal subfamily of the replayed family"
            )
        if registry.get("bundle_hash") != expected_legal_hash:
            failures.append("safe commitment bundle hash does not seal the legal subfamily")
        target = result.get("verification_target") or {}
        if target.get("safe_commitment_hash") != commitment.get("artifact_hash"):
            failures.append("verification target does not bind the safe commitment")
        if (
            target.get("program") != "crg_verify.verify_agent_design_space"
            or target.get("scope") != VERIFICATION_SCOPE
            or target.get("generator_closure_reexecution") is not True
        ):
            failures.append("verification target does not require the registered full replay scope")

        expected_refusals: List[dict] = []
        for item in sorted(
            (bundle or {}).get("realizations") or [],
            key=lambda value: value.get("realization_id", "")
            if isinstance(value, dict) else "",
        ):
            if isinstance(item, dict) and item.get("legality") != "LEGAL":
                expected_refusals.append(
                    {
                        "source": f"generation:{item.get('realization_id')}",
                        "detail": (
                            f"{item.get('legality')}: retained in the replayed generator registry "
                            "as evidence but excluded from the legal decision-analysis subfamily"
                        ),
                    }
                )
        for decision in ((commitment.get("family") or {}).get("decisions") or []):
            if not isinstance(decision, dict):
                continue
            for detail in ((decision.get("derivation") or {}).get("refusals") or []):
                expected_refusals.append(
                    {"source": f"decision:{decision.get('decision_id')}", "detail": detail}
                )
        for evaluation in commitment.get("evaluations") or []:
            if not isinstance(evaluation, dict):
                continue
            for detail in evaluation.get("refusals") or []:
                expected_refusals.append(
                    {"source": f"policy:{evaluation.get('policy_id')}", "detail": detail}
                )
        if result.get("refusals") != expected_refusals:
            failures.append("top-level refusals are not the exact generated/commitment projection")

    boundary = result.get("resource_boundary")
    closure = report.get("closure") or {}
    limits = request.get("limits") or {}
    if not isinstance(boundary, dict):
        failures.append("resource boundary is absent")
    else:
        try:
            model = _graph_for_replay(graph.get("model"))
            counts = _request_input_counts(request, model)
            encoded_size = len(canonical_bytes(result))
            analysis_multiplier = (
                len(request.get("decisions") or [])
                * len(request.get("policies") or [])
            )
            registered_generation_probe_max = min(
                limits.get("max_realizations"),
                MAX_ANALYSIS_WORK_UNITS // analysis_multiplier + 1,
            )
            generation_probe_max = boundary.get(
                "generation_probe_max_realizations"
            )
            if (
                isinstance(generation_probe_max, bool)
                or not isinstance(generation_probe_max, int)
                or generation_probe_max <= 0
                or generation_probe_max > registered_generation_probe_max
            ):
                raise ValueError(
                    "generation probe is outside the request and registered work bounds"
                )
            if (
                generation_probe_max < registered_generation_probe_max
                and closure.get("reached_fixpoint") is not True
            ):
                raise ValueError(
                    "a reduced aggregate-work probe must carry a reached fixpoint"
                )
            expected = {
                "profile_caps": _profile_caps(),
                "input_counts": counts,
                "applied_limits": limits,
                "explored_realizations": closure.get("size"),
                "accepted_realizations": len(report.get("accepted") or []),
                "rejected_candidates": len(report.get("rejected") or []),
                "ungenerated_regions": len(report.get("ungenerated") or []),
                "truncated": closure.get("truncated"),
                "reached_fixpoint": closure.get("reached_fixpoint"),
                "depth_reached": closure.get("depth_reached"),
                "analysis_work_units": (
                    closure.get("size")
                    * len(request.get("decisions") or [])
                    * len(request.get("policies") or [])
                ),
                "generation_probe_max_realizations": generation_probe_max,
                "canonical_result_bytes": encoded_size,
            }
            if boundary != expected:
                failures.append(
                    "resource boundary does not exactly project profile caps, inputs, limits, "
                    "counts, and canonical bytes"
                )
            if encoded_size > MAX_RESULT_BYTES:
                failures.append("canonical result exceeds the registered byte cap")
        except (ArithError, CanonicalError, KeyError, TypeError, ValueError) as error:
            failures.append(f"resource boundary cannot be independently reconstructed: {error}")
    authority = result.get("authority") or {}
    if any(authority.get(field) is not False for field in (
        "execution_authorized", "lifecycle_transition_authorized", "release_authorized"
    )):
        failures.append("design-space result grants forbidden authority")
    return failures


def verify_agent_design_space(artifact: Any) -> VerificationResult:
    """Independently verify the bounded compiler-DAG closure and result mathematics."""
    result = VerificationResult(ok=False, status=Status.FAILED)
    result.report.update(
        {
            "artifact_type": "AgentDesignSpaceResult",
            "profile": artifact.get("profile") if isinstance(artifact, Mapping) else None,
            "level_attempted": Level.V3,
            "level_achieved": "NONE",
            "verification_scope": VERIFICATION_SCOPE,
            "generator_closure_reexecution": False,
            "generator_closure_complete": False,
        }
    )
    if not isinstance(artifact, Mapping):
        result.record("artifact_shape", False, "agent design-space result must be an object")
        return result.finish()
    artifact = dict(artifact)
    registered = (
        artifact.get("record_type") == "AgentDesignSpaceResult"
        and artifact.get("schema_version") == SCHEMA_VERSION
        and artifact.get("profile") == PROFILE
    )
    result.record("registered_profile", registered, f"schema/profile must be {SCHEMA_VERSION}/{PROFILE}")
    shape_failures = _closed_shape_failures(artifact)
    result.record(
        "closed_result_shape",
        not shape_failures,
        "; ".join(shape_failures)
        if shape_failures else "top-level and nested result envelope shapes are closed",
    )
    if shape_failures:
        result.finish()
        result.status = Status.FAILED
        return result

    preflight_failures = _resource_preflight_failures(artifact)
    result.record(
        "resource_preflight",
        not preflight_failures,
        "; ".join(preflight_failures)
        if preflight_failures else "decoded shape, cardinalities, nodes, depth, strings, and canonical bytes are bounded",
    )
    if preflight_failures:
        result.finish()
        result.status = Status.FAILED
        return result

    nested_failures = _nested_unknown_field_failures(artifact)
    result.record(
        "closed_nested_schema",
        not nested_failures,
        "; ".join(nested_failures)
        if nested_failures else "schema-closed nested objects contain no undeclared fields",
    )
    if nested_failures:
        result.finish()
        result.status = Status.FAILED
        return result

    try:
        recomputed_hash = hash_without(artifact, "result_hash")
        integrity = artifact.get("result_hash") == recomputed_hash
        detail = f"stated {artifact.get('result_hash')}; recomputed {recomputed_hash}"
    except Exception as error:  # total public boundary over arbitrary decoded JSON
        integrity = False
        detail = f"canonical hashing failed: {error}"
    result.record("result_integrity", integrity, detail)

    try:
        binding_failures = _binding_failures(artifact)
    except Exception as error:  # malformed nested JSON must be a FAILED result, never an escape
        binding_failures = [f"trace reconstruction raised {type(error).__name__}: {error}"]
    result.record(
        "trace_bindings",
        not binding_failures,
        "; ".join(binding_failures) if binding_failures else "request, graph, source, context, limits, and bundle are hash-bound",
    )
    bundle = ((artifact.get("represented_family") or {}).get("bundle") or {})
    try:
        replay_failures, replay_complete, replay_facts = _closure_replay_failures(
            artifact, bundle
        )
    except Exception as error:
        replay_failures = [
            f"generator replay raised {type(error).__name__}: {error}"
        ]
        replay_complete = False
        replay_facts = {}
    result.record(
        "generator_closure_reexecuted",
        not replay_failures,
        "; ".join(replay_failures)
        if replay_failures
        else (
            "pinned compiler-DAG seed, transformations, breadth-first closure, legality, "
            "completeness, and ledgers independently reconstructed"
        ),
    )
    result.report["generator_replay"] = replay_facts
    try:
        geometry_failures = _geometry_failures(artifact, bundle)
    except Exception as error:
        geometry_failures = [
            f"geometry reconstruction raised {type(error).__name__}: {error}"
        ]
    result.record(
        "exact_geometry_reconstructed",
        not geometry_failures,
        "; ".join(geometry_failures) if geometry_failures else "finite exact planar R, Gamma, and K reconstructed",
    )
    commitment = artifact.get("safe_commitment") or {}
    try:
        commitment_result = verify_safe_commitment(commitment)
    except Exception as error:
        commitment_result = VerificationResult(ok=False, status=Status.FAILED)
        commitment_result.record(
            "safe_commitment_total_boundary",
            False,
            f"safe-commitment verification raised {type(error).__name__}: {error}",
        )
        commitment_result.finish()
    result.record(
        "safe_commitment_verified",
        commitment_result.ok,
        "; ".join(commitment_result.violations) if not commitment_result.ok else commitment_result.status,
    )
    try:
        reduction_failures = _reduction_failures(artifact, bundle)
    except Exception as error:
        reduction_failures = [
            f"reduction reconstruction raised {type(error).__name__}: {error}"
        ]
    result.record(
        "reduced_spaces_reconstructed",
        not reduction_failures,
        "; ".join(reduction_failures) if reduction_failures else "every induced space is an exact safe-commitment projection",
    )
    result.finish()
    if not registered:
        result.status = Status.UNSUPPORTED_PROFILE
    elif result.ok:
        result.status = Status.VERIFIED if replay_complete else Status.PARTIALLY_VERIFIED
        result.report["level_achieved"] = Level.V3
        if not replay_complete:
            result.warn(
                "the pinned bounded generator was independently reexecuted, but the "
                "caller-declared limit truncated closure; the ungenerated remainder prevents "
                "full-family verification"
            )
    else:
        result.status = Status.FAILED
    result.report["safe_commitment_status"] = commitment_result.status
    result.report["generator_closure_reexecution"] = not replay_failures
    result.report["generator_closure_complete"] = replay_complete
    return result
