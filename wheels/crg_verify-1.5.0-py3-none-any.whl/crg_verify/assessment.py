"""Independent reconstruction of A1.2 event and assessment records."""
from __future__ import annotations

import re
from typing import Any, Mapping, Sequence

from .canonical import content_hash, hash_without, is_hash
from .certificate import Status, VerificationResult

__all__ = ["verify_commitment_event", "verify_validation_assessment"]

_EVENT_FIELDS = (
    "record_type", "schema_version", "profile", "event_id", "action_class",
    "action_mapping_profile_hash", "mapping_hash", "case_id", "branch_id",
    "proposal_id", "causal_parent_id", "actor", "target",
    "assessment_requirement", "authority", "execution_authorized",
    "action_occurred", "created_at", "event_hash",
)
_ASSESSMENT_FIELDS = (
    "record_type", "schema_version", "profile", "assessment_id",
    "commitment_event_hash", "context_roots", "semantic_inputs", "semantic_result", "validity",
    "disagreement", "limitations", "separation_contract", "authority",
    "authorizing", "execution_authorized", "assessment_hash",
)
_INPUT_FIELDS = (
    "record_type", "profile", "artifact_hash", "verification_status",
    "evidence_classes", "verifier",
)
_ACTION = re.compile(r"[A-Z][A-Z0-9_]*")
_RECORD_TYPES = frozenset({
    "SafeCommitmentArtifact", "PhaseAnalysisRecord", "CertifiedDeltaRecord",
    "LifecycleAuthorization", "ContinuedValidityView", "DecisionChallengeRecord",
})
_VERIFICATION_STATUSES = frozenset({
    "VERIFIED", "VERIFIED_RELATIVE", "VERIFIED_WITH_BOUNDED_REMAINDER",
    "INTEGRITY_ONLY", "REPLAY_BOUND", "PARTIALLY_VERIFIED",
    "INDEPENDENTLY_VERIFIED", "FAILED", "EXPIRED", "REVOKED",
    "TIME_INDETERMINATE", "UNVERIFIABLE_REDACTED", "UNSUPPORTED_PROFILE",
})
_FAILURE_STATUSES = frozenset({
    "FAILED", "EXPIRED", "REVOKED", "TIME_INDETERMINATE",
    "UNVERIFIABLE_REDACTED", "UNSUPPORTED_PROFILE",
})


class _Invalid(ValueError):
    pass


def _keys(value: Any, fields: Sequence[str], label: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping) or set(value) != set(fields):
        raise _Invalid(f"{label} fields differ")
    return value


def _text(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value:
        raise _Invalid(f"{label} is invalid")
    return value


def _strings(value: Any, label: str, *, nonempty: bool = False) -> list[str]:
    if not isinstance(value, list) or (nonempty and not value):
        raise _Invalid(f"{label} must be a{' non-empty' if nonempty else ''} array")
    if any(not isinstance(item, str) or not item for item in value):
        raise _Invalid(f"{label} contains an invalid identifier")
    if value != sorted(set(value)):
        raise _Invalid(f"{label} must be sorted and unique")
    return value


def _event(record: Any, result: VerificationResult) -> Mapping[str, Any]:
    event = _keys(record, _EVENT_FIELDS, "commitment event")
    if event.get("record_type") != "CommitmentEventRecord" or event.get("schema_version") != "1.0.0" or event.get("profile") != "crg-commitment-event/v1":
        raise _Invalid("commitment event type/version/profile differs")
    _text(event.get("event_id"), "event_id")
    if not isinstance(event.get("action_class"), str) or _ACTION.fullmatch(event["action_class"]) is None:
        raise _Invalid("action_class is invalid")
    for field in ("action_mapping_profile_hash", "mapping_hash", "event_hash"):
        if not is_hash(event.get(field)):
            raise _Invalid(f"{field} is invalid")
    if event["event_hash"] != hash_without(dict(event), "event_hash"):
        raise _Invalid("event_hash differs from independent canonical reconstruction")
    for field in ("case_id", "branch_id", "causal_parent_id"):
        if event.get(field) is not None and (not isinstance(event[field], str) or not event[field]):
            raise _Invalid(f"{field} is invalid")
    if event.get("case_id") is None and event.get("branch_id") is not None:
        raise _Invalid("a branch cannot be named without a case")
    _text(event.get("proposal_id"), "proposal_id")
    actor = _keys(event.get("actor"), ("actor_id", "actor_kind"), "actor")
    _text(actor.get("actor_id"), "actor_id")
    _text(actor.get("actor_kind"), "actor_kind")
    target = _keys(event.get("target"), ("object_type", "object_id", "current_hash", "proposed_hash"), "target")
    _text(target.get("object_type"), "target.object_type")
    _text(target.get("object_id"), "target.object_id")
    if target.get("current_hash") is not None and not is_hash(target.get("current_hash")):
        raise _Invalid("target.current_hash is invalid")
    if not is_hash(target.get("proposed_hash")) or target.get("proposed_hash") == target.get("current_hash"):
        raise _Invalid("target proposed identity is invalid or unchanged")
    requirement = _keys(
        event.get("assessment_requirement"),
        ("record_type", "profile", "required_statuses", "required_evidence", "verifier"),
        "assessment_requirement",
    )
    if requirement.get("record_type") not in _RECORD_TYPES:
        raise _Invalid("assessment requirement record type is unsupported")
    _text(requirement.get("profile"), "assessment requirement profile")
    _strings(requirement.get("required_statuses"), "required_statuses", nonempty=True)
    _strings(requirement.get("required_evidence"), "required_evidence", nonempty=True)
    verifier = _keys(requirement.get("verifier"), ("program", "profile"), "assessment verifier")
    _text(verifier.get("program"), "assessment verifier program")
    _text(verifier.get("profile"), "assessment verifier profile")
    result.record(
        "authority_boundary",
        event.get("authority") == "NON_AUTHORIZING_PROPOSAL"
        and event.get("execution_authorized") is False
        and event.get("action_occurred") is False,
        "event proposes an action but neither authorizes nor records execution",
    )
    return event


def verify_commitment_event(value: Any) -> VerificationResult:
    result = VerificationResult(ok=False, status=Status.FAILED)
    try:
        event = _event(value, result)
        result.record("event_identity", True, "event hash matches independent canonical reconstruction")
        result.record("assessment_requirement", True, "event binds the exact semantic requirement and verifier")
        if result.violations:
            result.status = Status.FAILED
        else:
            result.status = "VERIFIED_NON_AUTHORIZING_COMMITMENT_EVENT"
            result.report = {
                "artifact_type": "CommitmentEventRecord",
                "event_hash": event["event_hash"],
                "execution_authorized": False,
                "action_occurred": False,
            }
    except (KeyError, TypeError, _Invalid, ValueError) as error:
        result.record("event_decode", False, str(error))
        result.status = Status.FAILED
    return result.finish()


def _semantic_inputs(value: Any) -> list[Mapping[str, Any]]:
    if not isinstance(value, list) or not value:
        raise _Invalid("semantic_inputs must be a non-empty array")
    inputs = []
    for index, raw in enumerate(value):
        item = _keys(raw, _INPUT_FIELDS, f"semantic_inputs[{index}]")
        if item.get("record_type") not in _RECORD_TYPES:
            raise _Invalid(f"semantic_inputs[{index}] record type is unsupported")
        _text(item.get("profile"), f"semantic_inputs[{index}].profile")
        if not is_hash(item.get("artifact_hash")):
            raise _Invalid(f"semantic_inputs[{index}].artifact_hash is invalid")
        if item.get("verification_status") not in _VERIFICATION_STATUSES:
            raise _Invalid(f"semantic_inputs[{index}].verification_status is unsupported")
        _strings(item.get("evidence_classes"), f"semantic_inputs[{index}].evidence_classes", nonempty=True)
        verifier = _keys(item.get("verifier"), ("program", "profile"), f"semantic_inputs[{index}].verifier")
        _text(verifier.get("program"), f"semantic_inputs[{index}].verifier.program")
        _text(verifier.get("profile"), f"semantic_inputs[{index}].verifier.profile")
        inputs.append(item)
    identities = [(item["record_type"], item["artifact_hash"]) for item in inputs]
    if identities != sorted(set(identities)):
        raise _Invalid("semantic_inputs must be sorted and unique")
    return inputs


def _derived(event: Mapping[str, Any], inputs: Sequence[Mapping[str, Any]], validity: Mapping[str, Any], disagreement: Mapping[str, Any]) -> dict[str, Any]:
    requirement = event["assessment_requirement"]
    evidence = set(requirement["required_evidence"])
    matched = [
        item for item in inputs
        if item["record_type"] == requirement["record_type"]
        and item["profile"] == requirement["profile"]
        and item["verification_status"] in requirement["required_statuses"]
        and item["verifier"] == requirement["verifier"]
        and evidence.issubset(set(item["evidence_classes"]))
    ]
    satisfied = bool(matched) and not any(
        item["verification_status"] in _FAILURE_STATUSES for item in inputs
    )
    if validity["status"] == "INDETERMINATE" or disagreement["status"] != "NONE":
        status = "INDETERMINATE"
    elif satisfied and validity["status"] == "CURRENT":
        status = "ESTABLISHED"
    else:
        status = "NOT_ESTABLISHED"
    return {"status": status, "requirement_satisfied": satisfied}


def verify_validation_assessment(value: Any, *, commitment_event: Mapping[str, Any]) -> VerificationResult:
    result = VerificationResult(ok=False, status=Status.FAILED)
    try:
        event_result = verify_commitment_event(commitment_event)
        if not event_result.ok:
            raise _Invalid("bound commitment event is invalid")
        event = commitment_event
        record = _keys(value, _ASSESSMENT_FIELDS, "validation assessment")
        if record.get("record_type") != "ValidationAssessmentRecord" or record.get("schema_version") != "1.0.0" or record.get("profile") != "crg-validation-assessment/v1":
            raise _Invalid("validation assessment type/version/profile differs")
        _text(record.get("assessment_id"), "assessment_id")
        if not is_hash(record.get("commitment_event_hash")) or record["commitment_event_hash"] != event["event_hash"]:
            raise _Invalid("commitment event binding differs")
        if not is_hash(record.get("assessment_hash")) or record["assessment_hash"] != hash_without(dict(record), "assessment_hash"):
            raise _Invalid("assessment_hash differs from independent canonical reconstruction")
        context = _keys(
            record.get("context_roots"),
            (
                "record_type", "schema_version", "profile", "inputs",
                "semantic_composition_root", "host_policy_action_mapping_root",
                "execution_deployment_root", "resolution_admission_root",
                "authority", "execution_authorized", "context_hash",
            ),
            "context_roots",
        )
        if (
            context.get("record_type") != "AssessmentContextRoots"
            or context.get("schema_version") != "1.0.0"
            or context.get("profile") != "crg-assessment-context/four-root@1"
            or context.get("authority") != "ASSESSMENT_CONTEXT_ONLY"
            or context.get("execution_authorized") is not False
        ):
            raise _Invalid("assessment context type/version/profile/authority differs")
        inputs = _keys(
            context.get("inputs"),
            (
                "resolved_profile_lock_hash", "action_mapping_profile_hash",
                "host_policy_snapshot_hash", "execution_profile_hash",
                "deployment_profile_hash",
            ),
            "context_roots.inputs",
        )
        for field in inputs:
            if not is_hash(inputs[field]):
                raise _Invalid(f"context_roots.inputs.{field} is invalid")
        for field in (
            "semantic_composition_root", "host_policy_action_mapping_root",
            "execution_deployment_root", "resolution_admission_root", "context_hash",
        ):
            if not is_hash(context.get(field)):
                raise _Invalid(f"context_roots.{field} is invalid")
        if context["context_hash"] != hash_without(dict(context), "context_hash"):
            raise _Invalid("assessment context hash differs")
        if inputs["action_mapping_profile_hash"] != event["action_mapping_profile_hash"]:
            raise _Invalid("assessment context action-mapping binding differs")
        if context["host_policy_action_mapping_root"] != content_hash({
            "action_mapping_profile_hash": inputs["action_mapping_profile_hash"],
            "host_policy_snapshot_hash": inputs["host_policy_snapshot_hash"],
        }):
            raise _Invalid("host-policy/action-mapping root differs")
        if context["execution_deployment_root"] != content_hash({
            "execution_profile_hash": inputs["execution_profile_hash"],
            "deployment_profile_hash": inputs["deployment_profile_hash"],
        }):
            raise _Invalid("execution/deployment root differs")
        inputs = _semantic_inputs(record.get("semantic_inputs"))
        result_value = _keys(record.get("semantic_result"), ("status", "requirement_satisfied"), "semantic_result")
        validity = _keys(record.get("validity"), ("status", "evaluated_at", "expires_at", "revocation_record_hash"), "validity")
        if validity.get("status") not in {"CURRENT", "EXPIRED", "REVOKED", "INDETERMINATE"}:
            raise _Invalid("validity status is unsupported")
        _text(validity.get("evaluated_at"), "validity.evaluated_at")
        if validity.get("expires_at") is not None:
            _text(validity.get("expires_at"), "validity.expires_at")
        if (validity.get("status") == "REVOKED") != is_hash(validity.get("revocation_record_hash")):
            raise _Invalid("revocation identity must be present exactly for REVOKED validity")
        disagreement = _keys(record.get("disagreement"), ("status", "details"), "disagreement")
        if disagreement.get("status") not in {"NONE", "PRODUCER_VERIFIER_DISAGREEMENT", "MULTIPLE_VERIFIER_DISAGREEMENT", "VERIFIER_UNAVAILABLE", "UNRESOLVED"}:
            raise _Invalid("disagreement status is unsupported")
        details = _strings(disagreement.get("details"), "disagreement.details")
        if (disagreement["status"] == "NONE") != (details == []):
            raise _Invalid("disagreement detail/state relation differs")
        _strings(record.get("limitations"), "limitations")
        separation = _keys(
            record.get("separation_contract"),
            ("host_disposition_record_type", "action_record_type", "host_disposition_embedded", "action_receipt_embedded"),
            "separation_contract",
        )
        if separation != {
            "host_disposition_record_type": "LifecycleAuthorization",
            "action_record_type": "TransitionRecord",
            "host_disposition_embedded": False,
            "action_receipt_embedded": False,
        }:
            raise _Invalid("assessment embeds or redefines host disposition/action evidence")
        expected = _derived(event, inputs, validity, disagreement)
        if dict(result_value) != expected:
            raise _Invalid("semantic_result differs from independent mapped-evidence reconstruction")
        result.record(
            "authority_boundary",
            record.get("authority") == "SEMANTIC_ASSESSMENT_ONLY"
            and record.get("authorizing") is False
            and record.get("execution_authorized") is False,
            "semantic assessment is distinct from host authorization and execution",
        )
        result.record("assessment_identity", True, "assessment hash and event binding reconstruct")
        result.record("four_root_context", True, "assessment binds semantic, policy, execution, and resolution roots")
        result.record("semantic_reconstruction", True, f"semantic result independently derived as {expected['status']}")
        result.record("lifecycle_state", True, f"validity={validity['status']} disagreement={disagreement['status']}")
        if result.violations:
            result.status = Status.FAILED
        else:
            result.status = "VERIFIED_SEMANTIC_ASSESSMENT"
            result.report = {
                "artifact_type": "ValidationAssessmentRecord",
                "assessment_hash": record["assessment_hash"],
                "semantic_status": expected["status"],
                "host_disposition_included": False,
                "action_receipt_included": False,
            }
    except (KeyError, TypeError, _Invalid, ValueError) as error:
        result.record("assessment_decode", False, str(error))
        result.status = Status.FAILED
    return result.finish()
