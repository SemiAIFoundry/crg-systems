"""crg-change: reprice, re-embed, reopen, or revalidate (OID-CRG-003).

Reference implementation of master specification section 30, built on the
typed dependency graph of section 18.  The module executes the minimum
valid recomputation after a change: it classifies the change, propagates
it along typed edges only as far as the edges reach, preserves every
certificate outside the affected subgraph, orchestrates recomputation
through a caller-supplied callback, and emits a delta certificate.
"""
from .classify import (
    CLASS_ACTION,
    Classification,
    ObjectKind,
    PropertyClass,
    classify_change,
    classify_property,
    explain_change,
    minimum_action,
)
from .diff import (
    ChangeKind,
    canonical_form,
    diff_objects,
    object_relative,
    property_closure,
)
from .plan import (
    build_impact_plan,
    certificate_dependencies,
    mark_stale,
    object_kind_of,
    object_kinds_of,
)
from .apply import apply_change, case_root, case_view

__all__ = [
    "CLASS_ACTION",
    "Classification",
    "ObjectKind",
    "PropertyClass",
    "classify_change",
    "classify_property",
    "explain_change",
    "minimum_action",
    "ChangeKind",
    "canonical_form",
    "diff_objects",
    "object_relative",
    "property_closure",
    "build_impact_plan",
    "certificate_dependencies",
    "mark_stale",
    "object_kind_of",
    "object_kinds_of",
    "apply_change",
    "case_root",
    "case_view",
]

__version__ = "1.0.1"
SPEC_VERSION = "0.2.0"
