"""A stdlib validator for the published CRG JSON Schemas.

Normative basis: master specification section 43 (the reference technology
profile names JSON Schema Draft 2020-12), section 12 and 12.1 (the canonical
record types the schemas describe), section 14.2 (numeric representations),
section 14.3 (canonicalization) and section 6.6 (fail closed).

Why a validator lives in the kernel at all.  Section 43 recommends Pydantic
and a Draft 2020-12 library, but 43 also says the stack "is recommended but is
not normative", and the kernel packages of this implementation are
stdlib-only on purpose: a verifier or an air-gapped importer that must pull a
schema library before it can read a record has a supply chain the record
itself does not have (6.3, 45.5).  So the schemas are published as ordinary
Draft 2020-12 documents that *any* conforming library can consume, and this
module implements the subset of the dialect those documents actually use.

**The exactness rule the schemas enforce, and why.**  A JSON ``number`` is,
in every mainstream parser, a binary float.  14.2 forbids binary floating
point as a canonical hash input without a declared canonical encoding, and
14.3 requires numeric normalization to be defined.  A schema that typed a
budget, a tolerance, a signature coordinate, or a confidence as ``number``
would therefore have licensed exactly the value the rest of this
implementation spends its effort refusing.  Every exact-valued field in
``schemas/`` is instead typed ``["string", "integer"]`` with a documented
``pattern``, and this validator rejects a float against that type.  The
schemas say so in their own ``description`` fields, so the rule survives being
read outside this repository.

**Unknown keywords are refused, not ignored.**  Draft 2020-12 says an
unrecognised keyword is an annotation and has no assertion effect.  That is
the right rule for a general-purpose validator and the wrong one here: a
schema in ``schemas/`` that used ``minimum`` would silently stop constraining
anything, and the reader would have no way to tell.  :func:`validate` raises
:class:`SchemaError` when a schema uses a keyword this module does not
implement, so the published schemas and the validator cannot drift apart
without something failing loudly.

Implemented assertion keywords: ``type`` (including the array form),
``required``, ``properties``, ``additionalProperties``, ``items``,
``minItems``, ``enum``, ``const``, ``pattern``, ``anyOf``, ``oneOf``,
``allOf``, ``$ref`` (within the local schema set, including ``#/$defs/...``
pointers), and the boolean schemas ``true`` / ``false``.  Annotation
keywords carried but not asserted: ``$id``, ``$schema``, ``$defs``,
``title``, ``description``, ``$comment``, ``examples``,
``x-crg-record-type``.
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

__all__ = [
    "SchemaError",
    "SchemaValidationError",
    "SchemaRegistry",
    "DEFAULT_SCHEMA_REGISTRY",
    "SCHEMA_ROOT",
    "DIALECT",
    "EXACT_NUMERIC_PATTERN",
    "ASSERTION_KEYWORDS",
    "ANNOTATION_KEYWORDS",
    "validate",
    "validate_or_raise",
    "schema_for",
    "load_schema",
    "record_types",
]

#: The dialect every published schema declares (spec 43).
DIALECT = "https://json-schema.org/draft/2020-12/schema"

#: The pattern every exact-numeric string field carries.  An optional sign,
#: then either a decimal (``12``, ``-0.25``) or a rational (``3/4``,
#: ``-11/7``).  Both parse to an exact ``fractions.Fraction``; neither has a
#: binary floating-point image (spec 14.2).
EXACT_NUMERIC_PATTERN = r"^-?(?:[0-9]+(?:\.[0-9]+)?|[0-9]+/[0-9]*[1-9][0-9]*)$"

#: ``sha256:<64 hex>`` -- the algorithm-tagged hash form of 14.4.
HASH_PATTERN = r"^sha256:[0-9a-f]{64}$"

ASSERTION_KEYWORDS = frozenset(
    {
        "$ref",
        "type",
        "required",
        "properties",
        "additionalProperties",
        "items",
        "minItems",
        "enum",
        "const",
        "pattern",
        "anyOf",
        "oneOf",
        "allOf",
    }
)

ANNOTATION_KEYWORDS = frozenset(
    {
        "$id",
        "$schema",
        "$defs",
        "title",
        "description",
        "$comment",
        "examples",
        "default",
        "deprecated",
        "x-crg-record-type",
        "x-crg-spec-section",
        "x-crg-exactness",
    }
)

_TYPE_NAMES = {
    "null",
    "boolean",
    "object",
    "array",
    "string",
    "integer",
    "number",
}


class SchemaError(ValueError):
    """The *schema* is not usable: malformed, unknown keyword, dangling ref."""


class SchemaValidationError(ValueError):
    """The *instance* does not satisfy the schema.  Carries every violation."""

    def __init__(self, violations: Sequence[str], record_type: str = "") -> None:
        self.violations = tuple(violations)
        self.record_type = record_type
        subject = f"{record_type} " if record_type else ""
        super().__init__(
            f"{subject}record does not validate:\n  - " + "\n  - ".join(self.violations)
        )


# ---------------------------------------------------------------------------
# locating the published schema set
# ---------------------------------------------------------------------------
def _default_schema_root() -> Path:
    """Return the bundled schema directory, overridable by ``CRG_SCHEMA_ROOT``.

    Release wheels carry the complete schema set inside :mod:`crg_model`, so
    validation never depends on a source checkout or a network resource.  The
    override remains available for controlled compatibility testing.
    """
    override = os.environ.get("CRG_SCHEMA_ROOT")
    if override:
        return Path(override)
    bundled = Path(__file__).resolve().parent / "schemas"
    if not (bundled / "index.json").is_file():
        raise SchemaError(
            f"the installed CRG schema set is incomplete: {bundled / 'index.json'} is missing"
        )
    return bundled


SCHEMA_ROOT: Path = _default_schema_root()


# ---------------------------------------------------------------------------
# the registry
# ---------------------------------------------------------------------------
@dataclass
class SchemaRegistry:
    """The published schema set, loaded once and resolved by ``$id`` or path.

    ``index.json`` is the authoritative record-type -> path map (it is what a
    third party reads to find the schema for a record it received); this class
    reads it and additionally indexes every schema by its own ``$id`` and by
    its filename, so a ``$ref`` may be written either way.
    """

    root: Path = field(default_factory=lambda: SCHEMA_ROOT)
    _by_id: Dict[str, dict] = field(default_factory=dict, repr=False)
    _by_path: Dict[str, dict] = field(default_factory=dict, repr=False)
    _by_record_type: Dict[str, str] = field(default_factory=dict, repr=False)
    _loaded: bool = field(default=False, repr=False)

    # -- loading -------------------------------------------------------
    def load(self) -> "SchemaRegistry":
        if self._loaded:
            return self
        index_path = self.root / "index.json"
        if not index_path.exists():
            raise SchemaError(
                f"no schema index at {index_path}; the published schema set is the "
                "authoritative description of the canonical record types (spec 12.1, 43)"
            )
        with index_path.open(encoding="utf-8") as handle:
            index = json.load(handle)
        for entry in index.get("schemas", []):
            self._by_record_type[str(entry["record_type"])] = str(entry["path"])
        for path in sorted(self.root.rglob("*.schema.json")):
            with path.open(encoding="utf-8") as handle:
                document = json.load(handle)
            relative = path.relative_to(self.root).as_posix()
            self._by_path[relative] = document
            self._by_path[path.name] = document
            identity = document.get("$id")
            if identity:
                self._by_id[str(identity)] = document
        self._loaded = True
        return self

    # -- lookup --------------------------------------------------------
    @property
    def index(self) -> Dict[str, str]:
        """``record type -> schema path``, from ``index.json``."""
        self.load()
        return dict(self._by_record_type)

    def record_types(self) -> Tuple[str, ...]:
        self.load()
        return tuple(sorted(self._by_record_type))

    def paths(self) -> Tuple[str, ...]:
        self.load()
        return tuple(sorted({p for p in self._by_path if "/" in p or p.endswith(".schema.json")}))

    def schema_for(self, record_type: str) -> dict:
        """The schema ``index.json`` maps ``record_type`` to."""
        self.load()
        path = self._by_record_type.get(record_type)
        if path is None:
            raise SchemaError(
                f"record type {record_type!r} is not in the schema index; known types are "
                f"{sorted(self._by_record_type)}"
            )
        return self.load_schema(path)

    def load_schema(self, reference: str) -> dict:
        """Resolve a ``$id``, a relative path, or a bare filename."""
        self.load()
        document = self._by_id.get(reference) or self._by_path.get(reference)
        if document is None:
            raise SchemaError(
                f"no published schema for reference {reference!r}; this validator resolves "
                "only within the local schema set (spec 25.1: a verifier consults no network)"
            )
        return document

    # -- validation ----------------------------------------------------
    def validate(self, instance: Any, schema: Any) -> List[str]:
        return _Validator(self).validate(instance, schema)


DEFAULT_SCHEMA_REGISTRY = SchemaRegistry()


def schema_for(record_type: str, registry: Optional[SchemaRegistry] = None) -> dict:
    return (registry or DEFAULT_SCHEMA_REGISTRY).schema_for(record_type)


def load_schema(reference: str, registry: Optional[SchemaRegistry] = None) -> dict:
    return (registry or DEFAULT_SCHEMA_REGISTRY).load_schema(reference)


def record_types(registry: Optional[SchemaRegistry] = None) -> Tuple[str, ...]:
    return (registry or DEFAULT_SCHEMA_REGISTRY).record_types()


# ---------------------------------------------------------------------------
# the validator
# ---------------------------------------------------------------------------
class _Validator:
    """The Draft 2020-12 subset this repository's schemas actually use."""

    def __init__(self, registry: SchemaRegistry) -> None:
        self.registry = registry

    # -- entry point ---------------------------------------------------
    def validate(self, instance: Any, schema: Any) -> List[str]:
        violations: List[str] = []
        self._check(instance, schema, "$", violations, base=schema)
        return violations

    # -- keyword dispatch ----------------------------------------------
    def _check(
        self,
        instance: Any,
        schema: Any,
        path: str,
        violations: List[str],
        *,
        base: Any,
    ) -> None:
        if schema is True or schema == {}:
            return
        if schema is False:
            violations.append(f"{path}: the schema admits no value here")
            return
        if not isinstance(schema, Mapping):
            raise SchemaError(f"{path}: a schema is an object or a boolean, got {type(schema)!r}")

        unknown = sorted(set(schema) - ASSERTION_KEYWORDS - ANNOTATION_KEYWORDS)
        if unknown:
            raise SchemaError(
                f"{path}: schema uses keyword(s) {unknown}, which this validator does not "
                "implement. Draft 2020-12 would treat them as annotations with no assertion "
                "effect; refusing them instead keeps the published schemas and this validator "
                "from drifting apart silently (spec 6.6, 6.11)"
            )

        if "$ref" in schema:
            target, target_base = self._resolve(str(schema["$ref"]), base, path)
            self._check(instance, target, path, violations, base=target_base)
            # Draft 2020-12 evaluates sibling keywords alongside $ref; the
            # published schemas do not rely on that, but honouring it costs
            # nothing and avoids a surprising silent drop.
        if "type" in schema:
            self._check_type(instance, schema["type"], path, violations)
        if "const" in schema and instance != schema["const"]:
            violations.append(f"{path}: expected the constant {schema['const']!r}, got {instance!r}")
        if "enum" in schema:
            options = schema["enum"]
            if not isinstance(options, list):
                raise SchemaError(f"{path}: 'enum' MUST be an array")
            if instance not in options:
                violations.append(
                    f"{path}: {instance!r} is not one of the declared values {options}"
                )
        if "pattern" in schema and isinstance(instance, str):
            pattern = str(schema["pattern"])
            if re.search(pattern, instance) is None:
                violations.append(
                    f"{path}: {instance!r} does not match the declared pattern {pattern!r}"
                    + (
                        "; exact numeric fields carry a string-or-integer type and this "
                        "pattern precisely so that a binary float cannot enter canonical "
                        "content (spec 14.2)"
                        if pattern == EXACT_NUMERIC_PATTERN
                        else ""
                    )
                )
        if isinstance(instance, Mapping):
            self._check_object(instance, schema, path, violations, base=base)
        if isinstance(instance, list):
            self._check_array(instance, schema, path, violations, base=base)
        for keyword in ("allOf", "anyOf", "oneOf"):
            if keyword in schema:
                self._check_combinator(
                    keyword, instance, schema[keyword], path, violations, base=base
                )

    # -- type ----------------------------------------------------------
    def _check_type(self, instance: Any, declared: Any, path: str, violations: List[str]) -> None:
        names = [declared] if isinstance(declared, str) else list(declared)
        for name in names:
            if name not in _TYPE_NAMES:
                raise SchemaError(f"{path}: {name!r} is not a JSON Schema type name")
            if name == "number":
                raise SchemaError(
                    f"{path}: the published CRG schemas never type a field 'number'. A JSON "
                    "number decodes to a binary float in every mainstream parser, and 14.2 "
                    "forbids binary floating point in canonical content without a declared "
                    "canonical encoding. Exact values are typed [\"string\", \"integer\"] "
                    f"with the pattern {EXACT_NUMERIC_PATTERN!r}"
                )
        if any(self._is_type(instance, name) for name in names):
            return
        violations.append(
            f"{path}: expected type {names if len(names) > 1 else names[0]!r}, got "
            f"{_type_name(instance)}"
            + (
                " -- a JSON number is a binary float and cannot carry an exact CRG value; "
                "supply it as a decimal or rational string, or as an integer (spec 14.2)"
                if isinstance(instance, float)
                else ""
            )
        )

    @staticmethod
    def _is_type(instance: Any, name: str) -> bool:
        if name == "null":
            return instance is None
        if name == "boolean":
            return isinstance(instance, bool)
        if name == "object":
            return isinstance(instance, Mapping)
        if name == "array":
            return isinstance(instance, list)
        if name == "string":
            return isinstance(instance, str)
        if name == "integer":
            # ``bool`` is a subclass of ``int`` in Python and is emphatically
            # not an integer here: a capability flag typed as an integer would
            # silently satisfy an exact-value field.
            return isinstance(instance, int) and not isinstance(instance, bool)
        if name == "number":  # pragma: no cover -- refused above
            return isinstance(instance, (int, float)) and not isinstance(instance, bool)
        return False

    # -- object --------------------------------------------------------
    def _check_object(
        self, instance: Mapping[str, Any], schema: Mapping[str, Any], path: str,
        violations: List[str], *, base: Any,
    ) -> None:
        required = schema.get("required", [])
        if not isinstance(required, list):
            raise SchemaError(f"{path}: 'required' MUST be an array")
        for name in required:
            if name not in instance:
                violations.append(
                    f"{path}: required property {name!r} is absent"
                )
        properties = schema.get("properties", {})
        if properties and not isinstance(properties, Mapping):
            raise SchemaError(f"{path}: 'properties' MUST be an object")
        for name, subschema in (properties or {}).items():
            if name in instance:
                self._check(instance[name], subschema, f"{path}.{name}", violations, base=base)
        if "additionalProperties" in schema:
            allowed = set(properties or {})
            extra = sorted(set(instance) - allowed)
            additional = schema["additionalProperties"]
            if additional is False:
                for name in extra:
                    violations.append(
                        f"{path}: property {name!r} is not declared and the schema forbids "
                        "additional properties"
                    )
            elif additional is not True:
                for name in extra:
                    self._check(
                        instance[name], additional, f"{path}.{name}", violations, base=base
                    )

    # -- array ---------------------------------------------------------
    def _check_array(
        self, instance: List[Any], schema: Mapping[str, Any], path: str,
        violations: List[str], *, base: Any,
    ) -> None:
        if "minItems" in schema:
            minimum = schema["minItems"]
            if not isinstance(minimum, int) or isinstance(minimum, bool):
                raise SchemaError(f"{path}: 'minItems' MUST be an integer")
            if len(instance) < minimum:
                violations.append(
                    f"{path}: {len(instance)} item(s), but the schema requires at least "
                    f"{minimum}"
                )
        if "items" in schema:
            for index, item in enumerate(instance):
                self._check(item, schema["items"], f"{path}[{index}]", violations, base=base)

    # -- combinators ---------------------------------------------------
    def _check_combinator(
        self, keyword: str, instance: Any, options: Any, path: str,
        violations: List[str], *, base: Any,
    ) -> None:
        if not isinstance(options, list) or not options:
            raise SchemaError(f"{path}: {keyword!r} MUST be a non-empty array of schemas")
        results = []
        for index, option in enumerate(options):
            local: List[str] = []
            self._check(instance, option, f"{path}<{keyword}[{index}]>", local, base=base)
            results.append(local)
        satisfied = [i for i, local in enumerate(results) if not local]
        if keyword == "allOf":
            for local in results:
                violations.extend(local)
        elif keyword == "anyOf" and not satisfied:
            violations.append(
                f"{path}: no branch of 'anyOf' is satisfied; the closest failures were "
                + "; ".join(min(results, key=len))
            )
        elif keyword == "oneOf" and len(satisfied) != 1:
            violations.append(
                f"{path}: 'oneOf' requires exactly one satisfied branch, {len(satisfied)} "
                "were satisfied"
            )

    # -- $ref ----------------------------------------------------------
    def _resolve(self, reference: str, base: Any, path: str) -> Tuple[Any, Any]:
        """Resolve a reference inside the local schema set.

        Three forms are supported and no others: a local JSON pointer
        (``#/$defs/name``), a bare filename or relative path within
        ``schemas/``, and a full ``$id``.  A network reference is not
        resolvable and never will be: 25.1 requires verification to consult no
        network, and a schema that could only be understood by fetching a URL
        would put that requirement out of reach.
        """
        if reference.startswith("#"):
            return self._pointer(base, reference[1:], path), base
        if "#" in reference:
            document_ref, _, pointer = reference.partition("#")
            document = self.registry.load_schema(document_ref)
            return self._pointer(document, pointer, path), document
        if reference.startswith(("http://", "https://")):
            # An ``$id`` of the published set is an https URL; it resolves
            # against the loaded documents, never against the network.
            document = self.registry.load_schema(reference)
            return document, document
        document = self.registry.load_schema(reference)
        return document, document

    @staticmethod
    def _pointer(document: Any, pointer: str, path: str) -> Any:
        node = document
        for token in [t for t in pointer.split("/") if t]:
            token = token.replace("~1", "/").replace("~0", "~")
            if not isinstance(node, Mapping) or token not in node:
                raise SchemaError(
                    f"{path}: JSON pointer {pointer!r} does not resolve inside the schema"
                )
            node = node[token]
        return node


def _type_name(value: Any) -> str:
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, float):
        return "number (binary float)"
    if isinstance(value, int):
        return "integer"
    if isinstance(value, str):
        return "string"
    if isinstance(value, Mapping):
        return "object"
    if isinstance(value, list):
        return "array"
    return type(value).__name__


# ---------------------------------------------------------------------------
# public functions
# ---------------------------------------------------------------------------
def validate(
    record: Any,
    schema: Any,
    *,
    registry: Optional[SchemaRegistry] = None,
) -> List[str]:
    """Validate ``record`` against ``schema``; return every violation.

    ``schema`` may be a schema object, a record-type name present in
    ``schemas/index.json``, a schema ``$id``, or a path within ``schemas/``.
    An empty list means the record validates.

    Returning violations rather than raising is deliberate and matches
    :func:`crg_generate.packs.validate_pack`: a caller fixing a record wants
    every problem at once.  :func:`validate_or_raise` is the fail-closed form.
    """
    registry = registry or DEFAULT_SCHEMA_REGISTRY
    resolved = _resolve_schema_argument(schema, registry)
    return registry.validate(record, resolved)


def validate_or_raise(
    record: Any,
    schema: Any,
    *,
    registry: Optional[SchemaRegistry] = None,
) -> Any:
    """Validate and return ``record``, or raise :class:`SchemaValidationError`."""
    registry = registry or DEFAULT_SCHEMA_REGISTRY
    resolved = _resolve_schema_argument(schema, registry)
    violations = registry.validate(record, resolved)
    if violations:
        raise SchemaValidationError(
            violations,
            record_type=str(resolved.get("x-crg-record-type", "")) if isinstance(resolved, Mapping) else "",
        )
    return record


def _resolve_schema_argument(schema: Any, registry: SchemaRegistry) -> Any:
    if isinstance(schema, Mapping) or isinstance(schema, bool):
        return schema
    if isinstance(schema, str):
        try:
            return registry.schema_for(schema)
        except SchemaError:
            return registry.load_schema(schema)
    raise SchemaError(f"cannot read {type(schema)!r} as a schema, a record type, or a reference")
