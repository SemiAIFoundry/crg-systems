"""Canonical ``CRGCase`` aggregate metadata (specification section 11).

The operational packages still add module-owned payloads to a case mapping,
but the aggregate envelope is created and refreshed here once.  This avoids a
CLI case, a server case, and an exported case quietly acquiring different
mandatory metadata.
"""
from __future__ import annotations

from typing import Any, Dict, Mapping, MutableMapping, Optional

from .canonical import content_hash, is_hash
from .envelope import utc_now

__all__ = [
    "REQUIRED_CASE_FIELDS", "new_case_record", "refresh_case_metadata",
    "validate_case_metadata",
]

REQUIRED_CASE_FIELDS = (
    "case_id", "branch_id", "schema_version", "case_version", "title", "owner",
    "created_at", "created_by", "root_object_hashes", "source_fingerprint",
    "status", "access_policy", "dependency_root", "audit_root",
    "completeness_basis_ref", "extension_namespaces", "parent_case_refs",
)

_ROOT_COMPONENTS = (
    "contract", "registry", "import_report", "generation_report", "geometry",
    "scope", "derivation", "certificates", "deltas", "evidence",
    "technology_contracts", "qualification", "evaluations", "transitions",
    "migrations", "branches", "merge_decisions", "tombstones", "approvals",
)


def new_case_record(
    case_id: str, contract: Optional[Mapping[str, Any]] = None, *,
    branch_id: str = "main", title: Optional[str] = None, owner: str = "unassigned",
    created_by: str = "crg", created_at: Optional[str] = None,
) -> Dict[str, Any]:
    if not str(case_id):
        raise ValueError("a CRGCase requires a nonempty case_id")
    case: Dict[str, Any] = {
        "case_id": str(case_id),
        "branch_id": str(branch_id),
        "crg_spec_version": "0.2.0",
        "schema_version": "0.2.0",
        "case_version": 1,
        "title": str(title or case_id),
        "owner": str(owner),
        "created_at": str(created_at or utc_now()),
        "created_by": str(created_by),
        "root_object_hashes": {},
        "source_fingerprint": None,
        "status": "DRAFT",
        "access_policy": "private",
        "dependency_root": content_hash([]),
        "audit_root": content_hash([]),
        "completeness_basis_ref": None,
        "extension_namespaces": [],
        "parent_case_refs": [],
        "contract": dict(contract or {}),
        "registry": None,
        "import_report": None,
        "geometry": {},
        "scope": None,
        "derivation": None,
        "certificates": {},
        "deltas": {},
        "history": [],
    }
    refresh_case_metadata(case)
    return case


def refresh_case_metadata(case: MutableMapping[str, Any]) -> MutableMapping[str, Any]:
    """Refresh roots derived from the aggregate without changing its identity."""
    roots: Dict[str, str] = {}
    for name in _ROOT_COMPONENTS:
        value = case.get(name)
        if value not in (None, {}, []):
            roots[name] = content_hash(value)
    case["root_object_hashes"] = roots

    registry = case.get("registry")
    report = case.get("import_report") or case.get("generation_report") or {}
    if isinstance(report, Mapping) and report.get("source_fingerprint"):
        case["source_fingerprint"] = report["source_fingerprint"]
    elif isinstance(registry, Mapping) and registry.get("source_fingerprint"):
        case["source_fingerprint"] = registry["source_fingerprint"]

    completeness = registry.get("completeness") if isinstance(registry, Mapping) else None
    case["completeness_basis_ref"] = content_hash(completeness) if completeness else None
    edges = case.get("dependency_edges") or case.get("edges") or []
    case["dependency_root"] = content_hash(edges)
    audit_material = {
        "history": case.get("history") or [],
        "lifecycle": case.get("lifecycle") or {},
    }
    case["audit_root"] = content_hash(audit_material)
    return case


def validate_case_metadata(case: Mapping[str, Any]) -> list[str]:
    problems = [field for field in REQUIRED_CASE_FIELDS if field not in case]
    violations = [f"case metadata omits {field!r} (11.1)" for field in problems]
    for field in ("case_id", "branch_id", "schema_version", "title", "owner",
                  "created_at", "created_by", "status", "access_policy"):
        if field in case and not isinstance(case[field], str):
            violations.append(f"case metadata {field!r} must be a string")
    if not isinstance(case.get("case_version"), int) or int(case.get("case_version") or 0) < 1:
        violations.append("case_version must be a positive integer")
    if not isinstance(case.get("root_object_hashes"), Mapping):
        violations.append("root_object_hashes must be a mapping")
    else:
        for name, digest in case["root_object_hashes"].items():
            if not is_hash(digest):
                violations.append(f"root_object_hashes[{name!r}] is not an algorithm-tagged hash")
    for field in ("dependency_root", "audit_root"):
        if not is_hash(case.get(field)):
            violations.append(f"{field} is not an algorithm-tagged hash")
    for field in ("extension_namespaces", "parent_case_refs"):
        if not isinstance(case.get(field), list):
            violations.append(f"{field} must be an array")
    for field in ("source_fingerprint", "completeness_basis_ref"):
        value = case.get(field)
        if value is not None and not is_hash(value):
            violations.append(f"{field} must be null or an algorithm-tagged hash")
    return violations
