"""The case lifecycle, as an enforced state machine.

Normative basis: master specification section 11.2 (case lifecycle), read
against section 6.6 (fail closed), section 6.4 (immutable provenance) and
section 17.1 (distinct states).

Why a machine and not a string.  Before this module the case status was an
imperative assignment: every operation wrote whatever status it thought
appropriate, and nothing anywhere could say that ``DRAFT -> CERTIFIED`` was
not a thing that happens.  A lifecycle that cannot refuse a transition is
documentation, not a lifecycle; and the specific transitions it must refuse
are the ones that would let a case present a certificate it never earned.

The declared chain of 11.2 is::

    DRAFT -> VALIDATED -> IMPORTED_OR_GENERATED -> EVALUATED -> CERTIFIED
                                                                  |
                                                                  v
                                                              COMMITTED
    CERTIFIED / COMMITTED -> STALE -> REOPENED -> CERTIFIED

and 11.2 adds that a case MAY *also* become ``BLOCKED``, ``BRANCHED``,
``MERGED``, ``SUPERSEDED``, ``ARCHIVED``, ``REVOKED``,
``PARTIALLY_REDACTED`` or ``UNVERIFIABLE``.

Three readings had to be resolved, and each is recorded here rather than
buried in a table:

1. **``IMPORTED_OR_GENERATED`` versus the stored value ``GENERATED``.**  The
   reference implementation has emitted, stored, and hashed the string
   ``"GENERATED"`` since before this module existed.  Renaming it would
   change the content hash of every case that has one.  The specification's
   name is therefore added as an *alias* to the same value --
   ``CaseState.IMPORTED_OR_GENERATED is CaseState.GENERATED`` -- exactly as
   :class:`crg_model.records.DecisionOutcome` reconciles its two renamed
   outcomes with 29.5.  One string is emitted and hashed; two names refer to
   it.

2. **Is backwards movement inside the preparation phase legal?**  11.2 draws
   the chain as an order but says nothing about re-importing a registry or
   rebuilding geometry on a case that has not yet certified anything.  A case
   in ``{DRAFT, VALIDATED, GENERATED, EVALUATED}`` has issued no claim, so no
   claim can be invalidated by revisiting it; the resolution taken here is
   that movement *backwards* within the preparation phase is legal and
   movement *forwards* is one step at a time.  ``DRAFT -> CERTIFIED`` is
   therefore illegal, and so is ``EVALUATED -> COMMITTED``, while
   ``EVALUATED -> GENERATED`` (rebuild the geometry) is legal.  Once a case
   has certified, the door closes: returning to preparation requires the
   declared ``STALE -> REOPENED`` route, because that route is the one that
   records *why* the claim stopped holding (30.5).

3. **Which of the auxiliary states are terminal?**  11.2 says a prior case
   version MUST remain addressable after supersession, which is a statement
   about addressability, not about further transitions.  ``ARCHIVED``,
   ``REVOKED`` and ``SUPERSEDED`` are read here as terminal: a superseded
   case version is a historical record, and a record that can still change is
   not a record (6.4).  The remaining auxiliary states -- ``BLOCKED``,
   ``BRANCHED``, ``MERGED``, ``PARTIALLY_REDACTED``, ``UNVERIFIABLE`` -- are
   conditions a case is *in*, and a case may leave them.

What the machine actually refuses, and therefore what it is worth:

* every transition out of ``ARCHIVED``, ``REVOKED`` or ``SUPERSEDED``;
* every forward skip in the chain (``DRAFT -> GENERATED``,
  ``VALIDATED -> CERTIFIED``, ``GENERATED -> COMMITTED``, ...);
* ``COMMITTED -> `` anything but ``STALE`` or an auxiliary state -- a
  committed case cannot quietly go back to being evaluated;
* ``CERTIFIED -> `` any preparation state -- the ``STALE``/``REOPENED`` route
  exists precisely so that the reason is recorded;
* ``STALE -> CERTIFIED`` without passing through ``REOPENED``;
* any unrecognised state name at all.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, FrozenSet, List, Mapping, MutableMapping, Optional, Tuple

from .envelope import utc_now

__all__ = [
    "CaseState",
    "LifecycleError",
    "PRINCIPAL_PATH",
    "PREPARATION_STATES",
    "AUXILIARY_STATES",
    "TERMINAL_STATES",
    "TRANSITIONS",
    "is_legal_transition",
    "legal_targets",
    "check_transition",
    "LifecycleTransition",
    "CaseLifecycle",
    "case_state",
    "set_case_state",
]


class LifecycleError(ValueError):
    """An illegal case-lifecycle transition was attempted (spec 11.2)."""

    def __init__(self, current: str, target: str, detail: str) -> None:
        self.current = current
        self.target = target
        super().__init__(detail)


class CaseState:
    """The complete state vocabulary of specification 11.2."""

    # -- the declared chain ------------------------------------------------
    DRAFT = "DRAFT"
    VALIDATED = "VALIDATED"
    #: Wire value ``"GENERATED"``; 11.2 names this node ``IMPORTED_OR_GENERATED``.
    GENERATED = "GENERATED"
    IMPORTED_OR_GENERATED = GENERATED
    EVALUATED = "EVALUATED"
    CERTIFIED = "CERTIFIED"
    COMMITTED = "COMMITTED"
    STALE = "STALE"
    REOPENED = "REOPENED"

    # -- "A case MAY also become" ------------------------------------------
    BLOCKED = "BLOCKED"
    BRANCHED = "BRANCHED"
    MERGED = "MERGED"
    SUPERSEDED = "SUPERSEDED"
    ARCHIVED = "ARCHIVED"
    REVOKED = "REVOKED"
    PARTIALLY_REDACTED = "PARTIALLY_REDACTED"
    UNVERIFIABLE = "UNVERIFIABLE"

    ALL: FrozenSet[str] = frozenset(
        {
            DRAFT,
            VALIDATED,
            GENERATED,
            EVALUATED,
            CERTIFIED,
            COMMITTED,
            STALE,
            REOPENED,
            BLOCKED,
            BRANCHED,
            MERGED,
            SUPERSEDED,
            ARCHIVED,
            REVOKED,
            PARTIALLY_REDACTED,
            UNVERIFIABLE,
        }
    )


#: The declared chain of 11.2, in order.
PRINCIPAL_PATH: Tuple[str, ...] = (
    CaseState.DRAFT,
    CaseState.VALIDATED,
    CaseState.GENERATED,
    CaseState.EVALUATED,
    CaseState.CERTIFIED,
    CaseState.COMMITTED,
)

#: States in which the case has issued no claim, so revisiting them
#: invalidates nothing (reading 2 in the module docstring).
PREPARATION_STATES: FrozenSet[str] = frozenset(
    {CaseState.DRAFT, CaseState.VALIDATED, CaseState.GENERATED, CaseState.EVALUATED}
)

#: The "A case MAY also become" set of 11.2.
AUXILIARY_STATES: FrozenSet[str] = frozenset(
    {
        CaseState.BLOCKED,
        CaseState.BRANCHED,
        CaseState.MERGED,
        CaseState.SUPERSEDED,
        CaseState.ARCHIVED,
        CaseState.REVOKED,
        CaseState.PARTIALLY_REDACTED,
        CaseState.UNVERIFIABLE,
    }
)

#: No transition leaves these (reading 3 in the module docstring).
TERMINAL_STATES: FrozenSet[str] = frozenset(
    {CaseState.ARCHIVED, CaseState.REVOKED, CaseState.SUPERSEDED}
)

#: Auxiliary states a case may leave, and where it may go.  A blocked or
#: redacted case returns to work; it does not return to ``DRAFT``, because the
#: registry it already holds does not stop existing.
_RESUMABLE_AUXILIARY: FrozenSet[str] = AUXILIARY_STATES - TERMINAL_STATES


def _principal_successor(state: str) -> Optional[str]:
    if state in PRINCIPAL_PATH:
        index = PRINCIPAL_PATH.index(state)
        if index + 1 < len(PRINCIPAL_PATH):
            return PRINCIPAL_PATH[index + 1]
    return None


def _build_transitions() -> Dict[str, FrozenSet[str]]:
    table: Dict[str, FrozenSet[str]] = {}

    # Preparation phase: one step forward, free movement backwards, and a
    # self-transition (re-import, re-generate, re-evaluate).
    for state in PREPARATION_STATES:
        index = PRINCIPAL_PATH.index(state)
        backwards = set(PRINCIPAL_PATH[: index + 1]) & PREPARATION_STATES
        forward = {_principal_successor(state)} - {None}
        table[state] = frozenset(backwards | forward | AUXILIARY_STATES)  # type: ignore[arg-type]

    # CERTIFIED: commit it, let it go stale, reopen it, or certify again
    # (11.2 draws all three arrows out of the CERTIFIED node).  Notably NOT
    # any preparation state: that route runs through STALE/REOPENED so the
    # reason is on the record.
    table[CaseState.CERTIFIED] = frozenset(
        {CaseState.COMMITTED, CaseState.STALE, CaseState.REOPENED, CaseState.CERTIFIED}
        | AUXILIARY_STATES
    )
    # COMMITTED: a committed decision only ever goes stale.
    table[CaseState.COMMITTED] = frozenset({CaseState.STALE} | AUXILIARY_STATES)
    # STALE: the only declared exit is REOPENED.
    table[CaseState.STALE] = frozenset({CaseState.REOPENED} | AUXILIARY_STATES)
    # REOPENED: 11.2 draws REOPENED -> CERTIFIED.  Reopening is what returns a
    # case to work, so the preparation states it must pass through to get
    # there -- rebuild geometry, recompile the query -- are legal too.  What
    # is not legal is REOPENED -> COMMITTED: a reopened case commits nothing
    # until it has certified again.
    table[CaseState.REOPENED] = frozenset(
        {CaseState.CERTIFIED, CaseState.GENERATED, CaseState.EVALUATED} | AUXILIARY_STATES
    )

    # Resumable auxiliary states: return to work or to another condition.  A
    # self-transition is legal here and only here -- blocking an already
    # blocked case for a second reason, or redacting a second object from an
    # already partially redacted one, are both ordinary and both need to be
    # recorded as separate transitions.
    for state in sorted(_RESUMABLE_AUXILIARY):
        table[state] = frozenset(
            {
                CaseState.VALIDATED,
                CaseState.GENERATED,
                CaseState.EVALUATED,
                CaseState.CERTIFIED,
                CaseState.REOPENED,
            }
            | AUXILIARY_STATES
        )

    # Terminal states: nothing leaves.
    for state in sorted(TERMINAL_STATES):
        table[state] = frozenset()

    return table


#: ``state -> the states it may legally become`` (specification 11.2).
TRANSITIONS: Dict[str, FrozenSet[str]] = _build_transitions()


def legal_targets(current: str) -> Tuple[str, ...]:
    """Every state ``current`` may legally become, sorted."""
    if current not in CaseState.ALL:
        raise LifecycleError(current, "", f"{current!r} is not a case state of specification 11.2")
    return tuple(sorted(TRANSITIONS[current]))


def is_legal_transition(current: str, target: str) -> bool:
    """Whether ``current -> target`` is a transition 11.2 permits."""
    if current not in CaseState.ALL or target not in CaseState.ALL:
        return False
    return target in TRANSITIONS[current]


def check_transition(current: str, target: str) -> str:
    """Return ``target``, or raise :class:`LifecycleError` (spec 6.6).

    The error message names the reason rather than the rule number alone: a
    caller that tried to skip the chain and a caller that tried to leave a
    terminal state have made different mistakes.
    """
    if current not in CaseState.ALL:
        raise LifecycleError(
            current,
            target,
            f"the case is in state {current!r}, which is not a case state of specification "
            f"11.2; the declared states are {sorted(CaseState.ALL)}",
        )
    if target not in CaseState.ALL:
        raise LifecycleError(
            current,
            target,
            f"{target!r} is not a case state of specification 11.2; the declared states are "
            f"{sorted(CaseState.ALL)}",
        )
    if target in TRANSITIONS[current]:
        return target

    if current in TERMINAL_STATES:
        detail = (
            f"a {current} case is a historical record and 6.4 makes provenance immutable; no "
            f"transition leaves {current}, so it cannot become {target}"
        )
    elif current in PREPARATION_STATES and target in PRINCIPAL_PATH:
        expected = _principal_successor(current)
        detail = (
            f"{current} -> {target} skips the chain of 11.2; the next declared step from "
            f"{current} is {expected}. A case may not arrive at a state it did not earn"
        )
    elif current in (CaseState.CERTIFIED, CaseState.COMMITTED) and target in PREPARATION_STATES:
        detail = (
            f"a {current} case does not return to {target} directly; 11.2 routes it through "
            "STALE and REOPENED so that the reason the claim stopped holding is on the record "
            "(spec 30.5)"
        )
    elif current == CaseState.STALE:
        detail = (
            f"a STALE case may only become REOPENED, not {target}; re-certifying without "
            "reopening would issue a claim with no recorded reason for the reissue (11.2)"
        )
    else:
        detail = (
            f"{current} -> {target} is not a transition specification 11.2 declares; from "
            f"{current} a case may become {sorted(TRANSITIONS[current])}"
        )
    raise LifecycleError(current, target, detail)


# ---------------------------------------------------------------------------
# the recorded lifecycle
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class LifecycleTransition:
    """One recorded, legal transition (11.2 plus 6.4 immutable provenance)."""

    from_state: str
    to_state: str
    reason: str = ""
    actor: str = "unattested"
    at: str = field(default_factory=utc_now)

    def to_canonical(self) -> dict:
        record: Dict[str, Any] = {
            "from_state": self.from_state,
            "to_state": self.to_state,
            "actor": self.actor,
            "at": self.at,
        }
        if self.reason:
            record["reason"] = self.reason
        return record

    @classmethod
    def from_canonical(cls, record: Mapping[str, Any]) -> "LifecycleTransition":
        return cls(
            from_state=str(record["from_state"]),
            to_state=str(record["to_state"]),
            reason=str(record.get("reason", "")),
            actor=str(record.get("actor", "unattested")),
            at=str(record.get("at", "")),
        )


@dataclass
class CaseLifecycle:
    """A case's state plus the ordered history of how it got there.

    The history is append-only: :meth:`advance` never rewrites an entry, so
    the record of a case that went ``CERTIFIED -> STALE -> REOPENED ->
    CERTIFIED`` still shows all four, which is what makes the second
    certificate auditable (6.4).
    """

    state: str = CaseState.DRAFT
    history: Tuple[LifecycleTransition, ...] = ()

    def __post_init__(self) -> None:
        if self.state not in CaseState.ALL:
            raise LifecycleError(
                self.state, "", f"{self.state!r} is not a case state of specification 11.2"
            )

    @property
    def is_terminal(self) -> bool:
        return self.state in TERMINAL_STATES

    def may_become(self, target: str) -> bool:
        return is_legal_transition(self.state, target)

    def legal_targets(self) -> Tuple[str, ...]:
        return legal_targets(self.state)

    def advance(
        self,
        target: str,
        *,
        reason: str = "",
        actor: str = "unattested",
        at: Optional[str] = None,
    ) -> "CaseLifecycle":
        """Move to ``target``, recording the transition, or raise."""
        check_transition(self.state, target)
        transition = LifecycleTransition(
            from_state=self.state,
            to_state=target,
            reason=reason,
            actor=actor,
            at=at or utc_now(),
        )
        self.history = self.history + (transition,)
        self.state = target
        return self

    def to_canonical(self) -> dict:
        return {
            "state": self.state,
            "history": [t.to_canonical() for t in self.history],
        }

    @classmethod
    def from_canonical(cls, record: Mapping[str, Any]) -> "CaseLifecycle":
        return cls(
            state=str(record.get("state", CaseState.DRAFT)),
            history=tuple(
                LifecycleTransition.from_canonical(t) for t in record.get("history", ())
            ),
        )


# ---------------------------------------------------------------------------
# operating on a case mapping
# ---------------------------------------------------------------------------
#: Where the recorded transition history lives on a case body.
LIFECYCLE_KEY = "lifecycle"


def case_state(case: Mapping[str, Any]) -> str:
    """The case's current lifecycle state, defaulting to ``DRAFT``."""
    return str(case.get("status") or CaseState.DRAFT)


def set_case_state(
    case: MutableMapping[str, Any],
    target: str,
    *,
    reason: str = "",
    actor: str = "unattested",
    at: Optional[str] = None,
) -> str:
    """Move a case body to ``target``, or raise :class:`LifecycleError`.

    This is the only supported way to change ``case["status"]``.  It checks
    the transition against 11.2, writes the new status, and appends the
    transition to ``case["lifecycle"]["history"]`` so that the case carries
    its own audit of how it reached the state it is in.
    """
    current = case_state(case)
    check_transition(current, target)
    lifecycle = CaseLifecycle.from_canonical(
        case.get(LIFECYCLE_KEY) or {"state": current, "history": []}
    )
    # The stored history may be behind the stored status (for instance on a
    # case written before this module existed).  Re-seat the lifecycle on the
    # authoritative status before advancing, rather than inventing a
    # transition that never happened.
    lifecycle.state = current
    lifecycle.advance(target, reason=reason, actor=actor, at=at)
    case["status"] = target
    case[LIFECYCLE_KEY] = lifecycle.to_canonical()
    return target
