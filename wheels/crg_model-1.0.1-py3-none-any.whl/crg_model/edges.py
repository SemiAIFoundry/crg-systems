"""Typed dependency graph: normative edge types and invalidation behaviour.

Normative basis: master specification section 18.  A generic untyped
``depends_on`` edge is explicitly insufficient for certificate-authorizing
behaviour (18.1), so every edge below carries its trigger, minimum
recomputation action, and transitivity rule.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Sequence, Set, Tuple

__all__ = ["Action", "EdgeType", "EDGE_SEMANTICS", "DependencyEdge", "DependencyGraph"]


class Action:
    """Minimum recomputation actions (spec 18.3, 30)."""

    NO_OPERATION = "NO_OPERATION"
    REVALIDATE_ONLY = "REVALIDATE_ONLY"
    REPRICE = "REPRICE"
    RE_EMBED = "RE_EMBED"
    RE_EVALUATE = "RE_EVALUATE"
    RECOMPUTE_VALUE = "RECOMPUTE_VALUE"
    REOPEN = "REOPEN"
    BLOCK = "BLOCK"

    #: Ordered by increasing severity so a union of actions is well defined.
    SEVERITY = {
        NO_OPERATION: 0,
        REVALIDATE_ONLY: 1,
        RECOMPUTE_VALUE: 2,
        REPRICE: 3,
        RE_EMBED: 4,
        RE_EVALUATE: 5,
        REOPEN: 6,
        BLOCK: 7,
    }

    @classmethod
    def max(cls, actions: Iterable[str]) -> str:
        best = cls.NO_OPERATION
        for action in actions:
            if cls.SEVERITY.get(action, 0) > cls.SEVERITY[best]:
                best = action
        return best


class EdgeType:
    """Specification 18.3."""

    DERIVES_VALUE_FROM = "DERIVES_VALUE_FROM"
    DEPENDS_ON_VALIDITY_OF = "DEPENDS_ON_VALIDITY_OF"
    DEPENDS_ON_MEMBERSHIP_OF = "DEPENDS_ON_MEMBERSHIP_OF"
    DEPENDS_ON_SCOPE_OF = "DEPENDS_ON_SCOPE_OF"
    DEPENDS_ON_PRICE_OF = "DEPENDS_ON_PRICE_OF"
    DEPENDS_ON_EMBEDDING_OF = "DEPENDS_ON_EMBEDDING_OF"
    DEPENDS_ON_CAPABILITY_OF = "DEPENDS_ON_CAPABILITY_OF"
    DEPENDS_ON_RULE_VERSION = "DEPENDS_ON_RULE_VERSION"
    DEPENDS_ON_GENERATOR_VERSION = "DEPENDS_ON_GENERATOR_VERSION"
    DEPENDS_ON_TOOL_IDENTITY = "DEPENDS_ON_TOOL_IDENTITY"
    DEPENDS_ON_SIGNATURE = "DEPENDS_ON_SIGNATURE"
    DEPENDS_ON_CONTEXT_FINGERPRINT = "DEPENDS_ON_CONTEXT_FINGERPRINT"
    DEPENDS_ON_CLOCK = "DEPENDS_ON_CLOCK"
    DEPENDS_ON_ACCESS = "DEPENDS_ON_ACCESS"
    DERIVED_FROM_VERSION = "DERIVED_FROM_VERSION"
    PROVES = "PROVES"
    WITNESSES = "WITNESSES"


@dataclass(frozen=True)
class _Semantics:
    trigger: str
    minimum_action: str
    transitive: bool


#: Table 18.3 encoded exactly.  ``transitive`` records whether invalidation
#: propagates further along outgoing edges of the affected object.
EDGE_SEMANTICS: Dict[str, _Semantics] = {
    EdgeType.DERIVES_VALUE_FROM: _Semantics(
        "source value or uncertainty changes", Action.RECOMPUTE_VALUE, True
    ),
    EdgeType.DEPENDS_ON_VALIDITY_OF: _Semantics(
        "source expires, is revoked, or becomes invalid", Action.REVALIDATE_ONLY, True
    ),
    EdgeType.DEPENDS_ON_MEMBERSHIP_OF: _Semantics(
        "registry membership changes", Action.REOPEN, True
    ),
    EdgeType.DEPENDS_ON_SCOPE_OF: _Semantics(
        "computation, resource, accounting, or decision scope changes", Action.REOPEN, True
    ),
    EdgeType.DEPENDS_ON_PRICE_OF: _Semantics(
        "price or service coefficient changes", Action.REPRICE, True
    ),
    EdgeType.DEPENDS_ON_EMBEDDING_OF: _Semantics(
        "placement, routing, physical model, or embedding constraint changes",
        Action.RE_EMBED,
        True,
    ),
    EdgeType.DEPENDS_ON_CAPABILITY_OF: _Semantics(
        "primitive, hierarchy, capability, or legal transformation changes", Action.REOPEN, True
    ),
    EdgeType.DEPENDS_ON_RULE_VERSION: _Semantics(
        "applicability, legality, or transformation rule changes", Action.REVALIDATE_ONLY, True
    ),
    EdgeType.DEPENDS_ON_GENERATOR_VERSION: _Semantics(
        "generator semantics or emitted family changes", Action.REOPEN, True
    ),
    EdgeType.DEPENDS_ON_TOOL_IDENTITY: _Semantics(
        "evaluator or model identity changes", Action.RE_EVALUATE, True
    ),
    EdgeType.DEPENDS_ON_SIGNATURE: _Semantics(
        "signature becomes invalid or key is revoked", Action.BLOCK, True
    ),
    EdgeType.DEPENDS_ON_CONTEXT_FINGERPRINT: _Semantics(
        "source or target context changes", Action.REVALIDATE_ONLY, True
    ),
    EdgeType.DEPENDS_ON_CLOCK: _Semantics(
        "validity or freshness threshold is crossed", Action.BLOCK, True
    ),
    EdgeType.DEPENDS_ON_ACCESS: _Semantics(
        "supporting content becomes unavailable or redacted", Action.BLOCK, True
    ),
    EdgeType.DERIVED_FROM_VERSION: _Semantics(
        "historical lineage changes", Action.NO_OPERATION, False
    ),
    EdgeType.PROVES: _Semantics("proof artifact fails verification", Action.BLOCK, True),
    EdgeType.WITNESSES: _Semantics(
        "constructive witness becomes invalid", Action.RECOMPUTE_VALUE, True
    ),
}


@dataclass
class DependencyEdge:
    """Specification 18.2: required edge fields."""

    edge_id: str
    source: str
    target: str
    edge_type: str
    source_property: Optional[str] = None
    scope: Optional[str] = None
    invalidation_predicate: Optional[str] = None
    edge_version: str = "1"

    def __post_init__(self) -> None:
        if self.edge_type not in EDGE_SEMANTICS:
            raise ValueError(f"unknown dependency edge type {self.edge_type!r}")

    @property
    def semantics(self) -> _Semantics:
        return EDGE_SEMANTICS[self.edge_type]

    @property
    def minimum_action(self) -> str:
        return self.semantics.minimum_action

    @property
    def transitive(self) -> bool:
        return self.semantics.transitive

    @property
    def validity_propagation_rule(self) -> str:
        """The explicit §18.2 validity consequence of this typed edge."""
        if self.minimum_action == Action.NO_OPERATION:
            return "PRESERVE_TARGET"
        if self.minimum_action == Action.REVALIDATE_ONLY:
            return "REVALIDATE_TARGET"
        if self.minimum_action == Action.BLOCK:
            return "BLOCK_TARGET"
        return "MARK_TARGET_STALE"

    def triggered_by(self, changed_properties: Optional[Set[str]]) -> bool:
        """An edge fires when the changed property matches its source property.

        A ``None`` property set means "the source object changed in an
        unspecified way", which fires every edge -- the conservative reading
        required by specification 30.4.
        """
        if changed_properties is None:
            return True
        if self.source_property is None:
            return True
        return self.source_property in changed_properties

    def to_canonical(self) -> dict:
        record = {
            "edge_id": self.edge_id,
            "source": self.source,
            "target": self.target,
            "edge_type": self.edge_type,
            "minimum_action": self.minimum_action,
            "transitive": self.transitive,
            "validity_propagation_rule": self.validity_propagation_rule,
            "edge_version": self.edge_version,
            "source_property": self.source_property or "*",
            "scope": self.scope or "GLOBAL",
            "invalidation_predicate": self.invalidation_predicate or (
                "EDGE_TYPE_TRIGGER:" + self.edge_type
            ),
        }
        return record


class DependencyGraph:
    """Acyclic typed dependency graph with incremental propagation (spec 18.4, 18.5)."""

    def __init__(self) -> None:
        self._out: Dict[str, List[DependencyEdge]] = {}
        self._nodes: Set[str] = set()

    def add_edge(self, edge: DependencyEdge) -> None:
        self.add_edges((edge,))

    def add_edges(self, edges: Iterable[DependencyEdge]) -> None:
        """Add a batch transactionally and validate acyclicity once.

        Re-running a whole-graph cycle check for every imported edge makes an
        E-edge import quadratic.  This public bulk path appends an arbitrary
        iterable, performs one O(V+E) check, and restores the exact prior
        graph if iteration fails or the completed batch contains a cycle.
        """
        original_lengths: Dict[str, int] = {}
        new_nodes: Set[str] = set()
        added = False
        try:
            for edge in edges:
                if not isinstance(edge, DependencyEdge):
                    raise TypeError("dependency batches may contain only DependencyEdge records")
                if edge.source not in self._nodes:
                    new_nodes.add(edge.source)
                if edge.target not in self._nodes:
                    new_nodes.add(edge.target)
                self._nodes.add(edge.source)
                self._nodes.add(edge.target)
                outgoing = self._out.setdefault(edge.source, [])
                original_lengths.setdefault(edge.source, len(outgoing))
                outgoing.append(edge)
                added = True
            if not added:
                return
            cycle = self.find_cycle()
            if cycle:
                raise ValueError(f"dependency cycle would be created: {' -> '.join(cycle)}")
        except Exception:
            for source, length in original_lengths.items():
                del self._out[source][length:]
                if not self._out[source]:
                    del self._out[source]
            self._nodes.difference_update(new_nodes)
            raise

    def edges_from(self, node: str) -> List[DependencyEdge]:
        return list(self._out.get(node, ()))

    @property
    def nodes(self) -> Set[str]:
        return set(self._nodes)

    def find_cycle(self) -> Optional[List[str]]:
        """Return one directed cycle using iterative O(V+E) depth-first search.

        An explicit frame stack avoids Python's recursion ceiling for imported
        dependency chains, which are routinely much deeper than 1,000 nodes.
        """
        WHITE, GREY, BLACK = 0, 1, 2
        colour: Dict[str, int] = {n: WHITE for n in self._nodes}
        for root in self._nodes:
            if colour[root] != WHITE:
                continue
            colour[root] = GREY
            path: List[str] = [root]
            positions: Dict[str, int] = {root: 0}
            frames: List[Tuple[str, int]] = [(root, 0)]
            while frames:
                node, index = frames[-1]
                outgoing = self._out.get(node, ())
                if index >= len(outgoing):
                    frames.pop()
                    positions.pop(node, None)
                    path.pop()
                    colour[node] = BLACK
                    continue
                frames[-1] = (node, index + 1)
                nxt = outgoing[index].target
                state = colour.get(nxt, WHITE)
                if state == GREY:
                    start = positions[nxt]
                    return path[start:] + [nxt]
                if state == WHITE:
                    colour[nxt] = GREY
                    positions[nxt] = len(path)
                    path.append(nxt)
                    frames.append((nxt, 0))
        return None

    def propagate(
        self, changed: Dict[str, Optional[Set[str]]]
    ) -> Dict[str, str]:
        """Return {affected_object: minimum_action} for a set of changed sources.

        Traverses only reachable affected descendants (spec 18.5); unaffected
        objects are absent from the result and their certificates are therefore
        preserved.
        """
        impact: Dict[str, str] = {}
        frontier: List[Tuple[str, Optional[Set[str]]]] = list(changed.items())
        seen_edges: Set[str] = set()
        while frontier:
            node, props = frontier.pop()
            for edge in self._out.get(node, ()):
                if edge.edge_id in seen_edges:
                    continue
                if not edge.triggered_by(props):
                    continue
                seen_edges.add(edge.edge_id)
                action = edge.minimum_action
                prior = impact.get(edge.target, Action.NO_OPERATION)
                impact[edge.target] = Action.max((prior, action))
                if edge.transitive and action != Action.NO_OPERATION:
                    frontier.append((edge.target, None))
        return impact
