"""AI-contribution provenance (specification 46).

Normative basis: master specification section 46 (AI-assistance policy), read
against section 5.3 (evidence classes), section 6.4 (immutable provenance),
section 6.5 (deterministic authority) and section 12 (common object envelope).

Section 46 has three parts, and this module is the third.

*The permissions* -- what AI may do -- are advisory and need no code: they
describe uses of a tool outside the kernel.

*The prohibitions* -- what AI MUST NOT independently do -- are already
enforced **structurally** by the rest of this implementation, and that is a
stronger guarantee than a runtime check would be.  There is no code path
anywhere in the kernel by which a model output can certify semantic
equivalence, authorize legality, register an applicability rule, fuse
evidence, certify pruning, sign an envelope, approve a transition, suppress
ambiguity, change completeness status, or overwrite a deterministic output:
every one of those actions is reachable only through a function whose inputs
are exact values and declared rules, and :class:`crg_model.envelope.EvidenceClass`
already refuses ``HEURISTIC`` as an authorizing class.  :data:`PROHIBITED_ACTS`
below names them so a reader can check that claim, and
:func:`assert_may_not_certify` gives a host a single place to fail closed if it
ever builds a path the kernel does not have.

*The record* -- what every AI contribution affecting a case MUST carry -- is
the part that was missing, and is what this module supplies.  46 makes eight
fields mandatory:

    model identity; model version; prompt or task identity; output;
    confidence where supplied; reviewer; accepted, modified, or rejected
    disposition; and downstream objects influenced.

:class:`AIContributionRecord` carries all eight, refuses a float confidence
(14.2), refuses a disposition outside the declared three, and refuses a
record whose disposition is ``ACCEPTED`` or ``MODIFIED`` with no named human
reviewer -- because an unreviewed accepted contribution is precisely the case
46's governing rule forbids:

    AI may propose; CRG mechanisms certify.

:func:`attach_ai_contribution` puts the record on a case, where it appears in
the case's canonical form and therefore in its content hash and in any ``.crg``
bundle exported from it.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, FrozenSet, List, Mapping, MutableMapping, Optional, Sequence, Tuple

from .canonical import content_hash
from .envelope import EvidenceClass, new_object_id, utc_now
from .numeric import Exact

__all__ = [
    "AIProvenanceError",
    "Disposition",
    "PROHIBITED_ACTS",
    "assert_may_not_certify",
    "AIContributionRecord",
    "AI_CONTRIBUTIONS_KEY",
    "attach_ai_contribution",
    "case_ai_contributions",
]


class AIProvenanceError(ValueError):
    """An AI-contribution record is not admissible (spec 46)."""


class Disposition:
    """The three dispositions section 46 names, and nothing else.

    46 says a contribution is *accepted, modified, or rejected*.  There is no
    fourth value and in particular no ``PENDING``: a contribution nobody has
    yet reviewed has no disposition, which is represented by not having a
    record on the case rather than by a record that declines to say.
    """

    ACCEPTED = "ACCEPTED"
    MODIFIED = "MODIFIED"
    REJECTED = "REJECTED"

    ALL: FrozenSet[str] = frozenset({ACCEPTED, MODIFIED, REJECTED})

    #: Dispositions under which the contribution actually reached the case,
    #: and therefore the ones that require a named reviewer.
    INFLUENCING: FrozenSet[str] = frozenset({ACCEPTED, MODIFIED})


#: The ten acts of specification 46 that AI MUST NOT independently perform.
#: Enumerated so that a host, a conformance suite, or a reader can check the
#: structural claim made in the module docstring against a list rather than
#: against prose.
PROHIBITED_ACTS: Tuple[str, ...] = (
    "CERTIFY_SEMANTIC_EQUIVALENCE",
    "AUTHORIZE_LEGALITY",
    "REGISTER_APPLICABILITY_RULE_AS_AUTHORITATIVE",
    "FUSE_CONFLICTING_EVIDENCE",
    "CERTIFY_PRUNING",
    "SIGN_EVIDENCE_OR_CAPABILITY_ENVELOPE",
    "APPROVE_RUNTIME_TRANSITION",
    "SUPPRESS_AMBIGUITY",
    "CHANGE_COMPLETENESS_STATUS",
    "OVERWRITE_DETERMINISTIC_OUTPUT",
)


def assert_may_not_certify(act: str) -> None:
    """Fail closed if ``act`` is one section 46 forbids AI to do alone.

    A host that wires a model output into a new code path calls this at that
    path's entrance.  The kernel itself never needs to: it has no such path.
    """
    if act in PROHIBITED_ACTS:
        raise AIProvenanceError(
            f"specification 46 forbids an AI contribution from independently performing "
            f"{act}. AI may propose; CRG mechanisms certify. Route the proposal through the "
            "deterministic mechanism that owns this act and record the proposal with an "
            "AIContributionRecord"
        )


def _text(value: Any, field_name: str) -> str:
    if isinstance(value, float):
        raise AIProvenanceError(
            f"{field_name} is a binary float; an AI-contribution record is a hash input and "
            "14.2 admits no float in canonical content"
        )
    return str(value)


def _strings(values: Any, field_name: str) -> Tuple[str, ...]:
    if values is None:
        return ()
    if isinstance(values, (str, bytes)):
        raise AIProvenanceError(
            f"{field_name} is a list of strings; a bare string would read as a list of its "
            "characters"
        )
    return tuple(_text(v, f"{field_name} entry") for v in values)


@dataclass(frozen=True)
class AIContributionRecord:
    """One AI contribution affecting a case (specification 46).

    Every field 46 makes mandatory is present and, except for ``confidence``,
    required to be non-empty.  ``confidence`` is optional because 46 says
    *"confidence where supplied"* -- but when it is supplied it is an exact
    rational in ``[0, 1]``, never a float: a confidence is a number that ends
    up in a content hash, and 14.2 gives a float no canonical image.

    ``output`` is the model's actual output text or a hash of it.  Storing the
    hash rather than the text is a legitimate choice for a large or sensitive
    output and is why ``output_is_hash`` exists: a reader must be able to tell
    a short output from a digest of a long one without guessing.

    ``downstream_objects`` is the field that makes the record useful rather
    than ceremonial.  It is what turns "a model helped with this case" into
    "these three objects would not have their present content but for this
    contribution", which is the question an auditor actually asks.

    The evidence class is fixed at ``HEURISTIC`` and cannot be set: a model
    output is a proposal, 5.3 says a heuristic may rank or propose and never
    authorize, and letting a caller label a contribution ``EXACT`` would be
    the one-line defeat of the whole policy.
    """

    contribution_id: str
    model_identity: str
    model_version: str
    task_identity: str
    output: str
    reviewer: str
    disposition: str
    downstream_objects: Tuple[str, ...] = ()
    confidence: Optional[Exact] = None
    output_is_hash: bool = False
    prompt_hash: str = ""
    reviewer_role: str = ""
    review_notes: str = ""
    created_at: str = field(default_factory=utc_now)

    OBJECT_TYPE = "AIContributionRecord"
    #: 5.3: a proposal is never an authorizing evidence class.
    EVIDENCE_CLASS = EvidenceClass.HEURISTIC

    def __init__(
        self,
        *,
        model_identity: str,
        model_version: str,
        task_identity: str,
        output: str,
        reviewer: str,
        disposition: str,
        downstream_objects: Any = (),
        confidence: Any = None,
        output_is_hash: bool = False,
        prompt_hash: str = "",
        reviewer_role: str = "",
        review_notes: str = "",
        contribution_id: Optional[str] = None,
        created_at: Optional[str] = None,
    ) -> None:
        set_ = object.__setattr__
        set_(self, "contribution_id", _text(contribution_id or new_object_id("ai"), "contribution_id"))
        set_(self, "model_identity", _text(model_identity, "model_identity"))
        set_(self, "model_version", _text(model_version, "model_version"))
        set_(self, "task_identity", _text(task_identity, "task_identity"))
        set_(self, "output", _text(output, "output"))
        set_(self, "reviewer", _text(reviewer, "reviewer"))
        set_(self, "disposition", _text(disposition, "disposition"))
        set_(self, "downstream_objects", _strings(downstream_objects, "downstream_objects"))
        if confidence is None:
            set_(self, "confidence", None)
        else:
            try:
                set_(self, "confidence", confidence if isinstance(confidence, Exact) else Exact(confidence))
            except TypeError as error:
                raise AIProvenanceError(f"confidence: {error}") from None
        if not isinstance(output_is_hash, bool):
            raise AIProvenanceError("'output_is_hash' MUST be a bool")
        set_(self, "output_is_hash", output_is_hash)
        set_(self, "prompt_hash", _text(prompt_hash, "prompt_hash"))
        set_(self, "reviewer_role", _text(reviewer_role, "reviewer_role"))
        set_(self, "review_notes", _text(review_notes, "review_notes"))
        set_(self, "created_at", _text(created_at or utc_now(), "created_at"))

    # -- validation ----------------------------------------------------
    def validate(self) -> List[str]:
        """Every reason the record is not admissible, or an empty list."""
        violations: List[str] = []
        for name in (
            "contribution_id",
            "model_identity",
            "model_version",
            "task_identity",
            "output",
            "reviewer",
            "disposition",
        ):
            if not getattr(self, name):
                violations.append(
                    f"the record omits {name!r}, which specification 46 makes mandatory for "
                    "every AI contribution affecting a case"
                )
        if self.disposition and self.disposition not in Disposition.ALL:
            violations.append(
                f"disposition {self.disposition!r} is not one of the three 46 names: "
                f"{sorted(Disposition.ALL)}"
            )
        if self.confidence is not None and not (Exact(0) <= self.confidence <= Exact(1)):
            violations.append(
                f"confidence {self.confidence} is outside [0, 1]; a confidence that is not a "
                "proportion is not a confidence"
            )
        if self.disposition in Disposition.INFLUENCING:
            if not self.reviewer or self.reviewer.lower() in ("", "none", "unattested", "unreviewed"):
                violations.append(
                    f"the contribution is {self.disposition} but names no reviewer; 46 makes "
                    "the reviewer mandatory, and an accepted contribution with no reviewer is "
                    "exactly the unreviewed acceptance the policy exists to prevent"
                )
            if not self.downstream_objects:
                violations.append(
                    f"the contribution is {self.disposition} but names no downstream object; "
                    "a contribution that reached the case influenced something, and 46 "
                    "requires the record to say what"
                )
        if self.disposition == Disposition.REJECTED and self.downstream_objects:
            violations.append(
                "the contribution is REJECTED yet names downstream objects it influenced; a "
                "rejected proposal that nonetheless changed an object was not rejected "
                "(spec 46, 6.6)"
            )
        return sorted(set(violations))

    def require_valid(self) -> "AIContributionRecord":
        """Fail closed (6.6): raise unless the record validates cleanly."""
        violations = self.validate()
        if violations:
            raise AIProvenanceError(
                "AI-contribution record is not admissible (spec 46):\n  - "
                + "\n  - ".join(violations)
            )
        return self

    @property
    def influenced_the_case(self) -> bool:
        return self.disposition in Disposition.INFLUENCING

    # -- canonical form ------------------------------------------------
    def to_canonical(self) -> dict:
        record: Dict[str, Any] = {
            "object_type": self.OBJECT_TYPE,
            "contribution_id": self.contribution_id,
            "model_identity": self.model_identity,
            "model_version": self.model_version,
            "task_identity": self.task_identity,
            "output": self.output,
            "output_is_hash": self.output_is_hash,
            "reviewer": self.reviewer,
            "disposition": self.disposition,
            "downstream_objects": list(self.downstream_objects),
            "evidence_class": self.EVIDENCE_CLASS,
            "created_at": self.created_at,
        }
        if self.confidence is not None:
            record["confidence"] = self.confidence.to_canonical()
        if self.prompt_hash:
            record["prompt_hash"] = self.prompt_hash
        if self.reviewer_role:
            record["reviewer_role"] = self.reviewer_role
        if self.review_notes:
            record["review_notes"] = self.review_notes
        return record

    @classmethod
    def from_canonical(cls, record: Mapping[str, Any]) -> "AIContributionRecord":
        confidence = record.get("confidence")
        return cls(
            contribution_id=record.get("contribution_id"),
            model_identity=record["model_identity"],
            model_version=record["model_version"],
            task_identity=record["task_identity"],
            output=record["output"],
            output_is_hash=bool(record.get("output_is_hash", False)),
            reviewer=record["reviewer"],
            disposition=record["disposition"],
            downstream_objects=record.get("downstream_objects", ()),
            confidence=None if confidence is None else Exact.from_canonical(confidence),
            prompt_hash=record.get("prompt_hash", ""),
            reviewer_role=record.get("reviewer_role", ""),
            review_notes=record.get("review_notes", ""),
            created_at=record.get("created_at"),
        )

    def content_hash(self) -> str:
        return content_hash(self.to_canonical())


# ---------------------------------------------------------------------------
# attaching to a case
# ---------------------------------------------------------------------------
#: Where AI-contribution records live on a case body.  Section 11 lists what a
#: case binds; 46 requires the record to be *on the case*, so it lives in the
#: case body and therefore inside the case's own canonical form and hash.
AI_CONTRIBUTIONS_KEY = "ai_contributions"


def attach_ai_contribution(
    case: MutableMapping[str, Any], record: AIContributionRecord
) -> dict:
    """Attach a validated AI-contribution record to a case (spec 46).

    The record is validated first and refused if it is not admissible: an
    invalid provenance record on a case is worse than none, because it looks
    like compliance.  Attachment is append-only and idempotent by
    ``contribution_id`` -- re-attaching the same identifier with different
    content is refused, since 6.4 makes provenance immutable.
    """
    record.require_valid()
    canonical = record.to_canonical()
    existing: List[dict] = list(case.get(AI_CONTRIBUTIONS_KEY) or [])
    for entry in existing:
        if entry.get("contribution_id") == record.contribution_id:
            if entry == canonical:
                return canonical
            raise AIProvenanceError(
                f"contribution {record.contribution_id!r} is already recorded on this case "
                "with different content; provenance is immutable (spec 6.4). Record a new "
                "contribution instead of rewriting the old one"
            )
    existing.append(canonical)
    existing.sort(key=lambda e: (str(e.get("created_at", "")), str(e.get("contribution_id", ""))))
    case[AI_CONTRIBUTIONS_KEY] = existing
    return canonical


def case_ai_contributions(case: Mapping[str, Any]) -> Tuple[AIContributionRecord, ...]:
    """Decode the AI-contribution records attached to a case."""
    return tuple(
        AIContributionRecord.from_canonical(entry)
        for entry in (case.get(AI_CONTRIBUTIONS_KEY) or [])
    )
