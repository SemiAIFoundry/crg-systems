"""The three case contracts and the adapter manifest, as typed records.

Normative basis: master specification section 12 (common object envelope),
section 12.1 (canonical record types -- ``ComputationContract``,
``ResourceContract``, ``HierarchyContract``, ``AdapterManifest``), read against
section 11 (a ``CRGCase`` *binds* a computation contract, a resource contract,
and a hierarchy and ownership description), section 14.2 (numeric
representations) and section 36.1 (adapters are an extension type).

Why these four are here and not in :mod:`crg_model.records`.  Everything in
``records.py`` is produced *by* the kernel: a realization, a geometry record, a
certificate.  These four are the opposite -- they are what a case is given
before any CRG reasoning happens.  ``crg_generate.registry.GenerationSource``
carries the first three as untyped mappings, which was enough to pass them
through but not enough to *check* them: an untyped mapping cannot refuse a
float budget, cannot notice that a placement rule names a level the hierarchy
does not declare, and cannot say which of the fields 12.1 makes required are
absent.  This module supplies the check.

Three properties are enforced throughout, and they are the reason the types
exist at all:

* **No binary floating point, anywhere** (14.2).  Every numeric field -- a
  budget, a capacity, a concurrency limit -- is an
  :class:`~crg_model.numeric.Exact`, which refuses a ``float`` at construction.
  A contract is a hash input, and a float has no canonical decimal image.
* **Declared-or-absent, never guessed** (6.6).  Every field 12.1 makes
  required defaults to an empty value, so an omitted execution model reads as
  *omitted* rather than as a plausible default.  :meth:`validate` reports every
  omission at once; :meth:`require_valid` fails closed on the first call.
* **Internal reference integrity.**  A resource contract that names a
  hierarchy level, or a hierarchy contract whose placement rule names a
  location, is checked against its own declarations.  A dangling internal
  reference is a violation, not a warning.

Each type exposes ``to_canonical()`` (14.3), ``from_canonical()`` so the
encoding round-trips, and ``content_hash()`` (14.4).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

from .canonical import content_hash
from .numeric import Exact

__all__ = [
    "ContractError",
    "ContractPort",
    "ExecutionModel",
    "ApproximationPolicy",
    "AccountingRule",
    "ComputationContract",
    "ResourceContract",
    "HierarchyLevel",
    "HierarchyLocation",
    "HierarchyInterface",
    "PlacementRule",
    "HierarchyContract",
    "AdapterFidelity",
    "AdapterManifest",
]


class ContractError(ValueError):
    """A contract or manifest is not admissible."""


# ---------------------------------------------------------------------------
# shared helpers
# ---------------------------------------------------------------------------
def _text(value: Any, field_name: str) -> str:
    if isinstance(value, float):
        raise ContractError(
            f"{field_name} is a binary float; a contract is a hash input and 14.2 admits "
            "no float in canonical content"
        )
    return str(value)


def _string_tuple(values: Any, field_name: str) -> Tuple[str, ...]:
    """Coerce to a tuple of strings, refusing a bare string.

    A bare string passed where a list belongs would read as a list of its
    characters, which is exactly the kind of silent misreading 6.11 forbids.
    """
    if values is None:
        return ()
    if isinstance(values, (str, bytes)):
        raise ContractError(
            f"{field_name} is a list of strings; a bare string would read as a list of its "
            "characters"
        )
    return tuple(_text(v, f"{field_name} entry") for v in values)


def _exact_map(values: Any, field_name: str) -> Tuple[Tuple[str, Exact], ...]:
    """Sorted ``(name, Exact)`` pairs.  ``Exact`` refuses float (14.2)."""
    if values is None:
        return ()
    items = values.items() if isinstance(values, Mapping) else values
    pairs: List[Tuple[str, Exact]] = []
    for key, value in items:
        if not isinstance(key, str):
            raise ContractError(f"{field_name} keys MUST be strings, got {type(key)!r}")
        try:
            pairs.append((key, value if isinstance(value, Exact) else Exact(value)))
        except TypeError as error:
            raise ContractError(f"{field_name}[{key!r}]: {error}") from None
    pairs.sort(key=lambda kv: kv[0])
    return tuple(pairs)


def _string_map(values: Any, field_name: str) -> Tuple[Tuple[str, str], ...]:
    if values is None:
        return ()
    items = values.items() if isinstance(values, Mapping) else values
    pairs: List[Tuple[str, str]] = []
    for key, value in items:
        if not isinstance(key, str):
            raise ContractError(f"{field_name} keys MUST be strings, got {type(key)!r}")
        pairs.append((key, _text(value, f"{field_name}[{key!r}]")))
    pairs.sort(key=lambda kv: kv[0])
    return tuple(pairs)


def _canonical_exact_map(pairs: Sequence[Tuple[str, Exact]]) -> Dict[str, Any]:
    return {key: value.to_canonical() for key, value in pairs}


def _missing(record: Any, required: Sequence[str]) -> List[str]:
    out: List[str] = []
    for name in required:
        value = getattr(record, name)
        if value in ("", (), {}, None):
            out.append(name)
    return out


class _Contract:
    """Shared validation surface for the four types in this module."""

    #: Fields specification 12.1 makes required for this record.
    REQUIRED: Tuple[str, ...] = ()
    #: The registered ``object_type`` of specification 12.
    OBJECT_TYPE: str = ""

    def validate(self) -> List[str]:
        """Every reason this record is not admissible, or an empty list."""
        violations = [
            f"{self.OBJECT_TYPE} omits {name!r}, which specification 12.1 makes required "
            "content"
            for name in _missing(self, self.REQUIRED)
        ]
        violations.extend(self._extra_violations())
        return sorted(set(violations))

    def _extra_violations(self) -> List[str]:
        return []

    def require_valid(self) -> "_Contract":
        """Fail closed (6.6): raise unless the record validates cleanly."""
        violations = self.validate()
        if violations:
            raise ContractError(
                f"{self.OBJECT_TYPE} is not admissible:\n  - " + "\n  - ".join(violations)
            )
        return self

    def content_hash(self) -> str:
        return content_hash(self.to_canonical())  # type: ignore[attr-defined]


# ---------------------------------------------------------------------------
# ComputationContract (spec 12.1)
# ---------------------------------------------------------------------------
class ExecutionModel:
    """Declared execution model of a computation contract (12.1)."""

    BATCH = "BATCH"
    STREAMING = "STREAMING"
    INTERACTIVE = "INTERACTIVE"
    DATAFLOW = "DATAFLOW"
    EVENT_DRIVEN = "EVENT_DRIVEN"
    UNDECLARED = "UNDECLARED"

    ALL = frozenset({BATCH, STREAMING, INTERACTIVE, DATAFLOW, EVENT_DRIVEN, UNDECLARED})


class ApproximationPolicy:
    """What approximation the contract permits (12.1 "approximation").

    ``NONE_PERMITTED`` and ``UNDECLARED`` are deliberately distinct.  A
    contract that forbids approximation has made a statement; a contract that
    never mentioned approximation has not, and 6.6 forbids reading the second
    as the first.
    """

    NONE_PERMITTED = "NONE_PERMITTED"
    BOUNDED_ERROR = "BOUNDED_ERROR"
    STATISTICAL = "STATISTICAL"
    BEST_EFFORT = "BEST_EFFORT"
    UNDECLARED = "UNDECLARED"

    ALL = frozenset({NONE_PERMITTED, BOUNDED_ERROR, STATISTICAL, BEST_EFFORT, UNDECLARED})

    #: Only these two let a downstream claim rest on the contract's semantics
    #: without a separately declared error bound (20.5).
    EXACT_SEMANTICS = frozenset({NONE_PERMITTED})


@dataclass(frozen=True)
class ContractPort:
    """One declared input or output of a computation contract.

    ``datatype`` is the caller's own type vocabulary; this module does not
    interpret it.  ``unit`` is optional because a port may be dimensionless,
    but when present it is a plain unit identifier that
    :mod:`crg_model.units` can resolve.
    """

    name: str
    datatype: str
    unit: Optional[str] = None
    description: str = ""
    required: bool = True

    def __post_init__(self) -> None:
        if not self.name:
            raise ContractError("a contract port MUST be named (spec 12.1)")
        if not self.datatype:
            raise ContractError(f"contract port {self.name!r} declares no datatype")
        if not isinstance(self.required, bool):
            raise ContractError(f"contract port {self.name!r}: 'required' MUST be a bool")

    def to_canonical(self) -> dict:
        record: Dict[str, Any] = {
            "name": self.name,
            "datatype": self.datatype,
            "required": self.required,
        }
        if self.unit:
            record["unit"] = self.unit
        if self.description:
            record["description"] = self.description
        return record

    @classmethod
    def from_canonical(cls, record: Mapping[str, Any]) -> "ContractPort":
        return cls(
            name=_text(record["name"], "port name"),
            datatype=_text(record["datatype"], "port datatype"),
            unit=record.get("unit"),
            description=_text(record.get("description", ""), "port description"),
            required=bool(record.get("required", True)),
        )


@dataclass(frozen=True)
class ComputationContract(_Contract):
    """What is computed, and under what correctness (spec 12.1).

    12.1 requires: *semantics, inputs, outputs, ownership, correctness,
    approximation, workload, execution model, source hash, exclusions*.  Each
    is a field below, in that order.

    ``exclusions`` is the field that most often goes unwritten and matters
    most: it is the contract's declaration of what it does *not* cover, and a
    certificate whose scope silently exceeded the contract's exclusions would
    be claiming something the contract never offered (21.4).
    """

    contract_id: str
    version: str = ""
    semantics: str = ""
    inputs: Tuple[ContractPort, ...] = ()
    outputs: Tuple[ContractPort, ...] = ()
    ownership: Tuple[Tuple[str, str], ...] = ()
    correctness: str = ""
    approximation: str = ApproximationPolicy.UNDECLARED
    approximation_bound: Optional[Exact] = None
    workload: Tuple[Tuple[str, Exact], ...] = ()
    execution_model: str = ExecutionModel.UNDECLARED
    source_hash: str = ""
    exclusions: Tuple[str, ...] = ()

    OBJECT_TYPE = "ComputationContract"
    REQUIRED = (
        "contract_id",
        "version",
        "semantics",
        "inputs",
        "outputs",
        "ownership",
        "correctness",
        "approximation",
        "workload",
        "execution_model",
        "source_hash",
        "exclusions",
    )

    def __init__(
        self,
        contract_id: str,
        *,
        version: str = "",
        semantics: str = "",
        inputs: Sequence[Any] = (),
        outputs: Sequence[Any] = (),
        ownership: Any = (),
        correctness: str = "",
        approximation: str = ApproximationPolicy.UNDECLARED,
        approximation_bound: Any = None,
        workload: Any = (),
        execution_model: str = ExecutionModel.UNDECLARED,
        source_hash: str = "",
        exclusions: Any = (),
    ) -> None:
        set_ = object.__setattr__
        set_(self, "contract_id", _text(contract_id, "contract_id"))
        set_(self, "version", _text(version, "version"))
        set_(self, "semantics", _text(semantics, "semantics"))
        set_(self, "inputs", tuple(_as_port(p) for p in inputs))
        set_(self, "outputs", tuple(_as_port(p) for p in outputs))
        set_(self, "ownership", _string_map(ownership, "ownership"))
        set_(self, "correctness", _text(correctness, "correctness"))
        set_(self, "approximation", _text(approximation, "approximation"))
        if approximation_bound is None:
            set_(self, "approximation_bound", None)
        else:
            try:
                set_(
                    self,
                    "approximation_bound",
                    approximation_bound
                    if isinstance(approximation_bound, Exact)
                    else Exact(approximation_bound),
                )
            except TypeError as error:
                raise ContractError(f"approximation_bound: {error}") from None
        set_(self, "workload", _exact_map(workload, "workload"))
        set_(self, "execution_model", _text(execution_model, "execution_model"))
        set_(self, "source_hash", _text(source_hash, "source_hash"))
        set_(self, "exclusions", _string_tuple(exclusions, "exclusions"))

    # -- validation ----------------------------------------------------
    def _extra_violations(self) -> List[str]:
        violations: List[str] = []
        if self.execution_model and self.execution_model not in ExecutionModel.ALL:
            violations.append(
                f"execution model {self.execution_model!r} is outside the declared "
                f"vocabulary {sorted(ExecutionModel.ALL)} (spec 12.1)"
            )
        if self.approximation and self.approximation not in ApproximationPolicy.ALL:
            violations.append(
                f"approximation policy {self.approximation!r} is outside the declared "
                f"vocabulary {sorted(ApproximationPolicy.ALL)} (spec 12.1)"
            )
        if (
            self.approximation == ApproximationPolicy.BOUNDED_ERROR
            and self.approximation_bound is None
        ):
            violations.append(
                "the contract declares BOUNDED_ERROR approximation but states no bound; an "
                "error semantics without an error is not a bound (spec 20.2)"
            )
        if (
            self.approximation_bound is not None
            and self.approximation == ApproximationPolicy.NONE_PERMITTED
        ):
            violations.append(
                "the contract permits no approximation yet declares an approximation bound; "
                "the two statements contradict each other (spec 6.6)"
            )
        names = [p.name for p in self.inputs]
        if len(set(names)) != len(names):
            violations.append("two inputs share a name; a port name is an identity (12.1)")
        names = [p.name for p in self.outputs]
        if len(set(names)) != len(names):
            violations.append("two outputs share a name; a port name is an identity (12.1)")
        return violations

    # -- canonical form ------------------------------------------------
    def to_canonical(self) -> dict:
        record: Dict[str, Any] = {
            "object_type": self.OBJECT_TYPE,
            "contract_id": self.contract_id,
            "version": self.version,
            "semantics": self.semantics,
            "inputs": [p.to_canonical() for p in self.inputs],
            "outputs": [p.to_canonical() for p in self.outputs],
            "ownership": dict(self.ownership),
            "correctness": self.correctness,
            "approximation": self.approximation,
            "workload": _canonical_exact_map(self.workload),
            "execution_model": self.execution_model,
            "source_hash": self.source_hash,
            "exclusions": list(self.exclusions),
        }
        if self.approximation_bound is not None:
            record["approximation_bound"] = self.approximation_bound.to_canonical()
        return record

    @classmethod
    def from_canonical(cls, record: Mapping[str, Any]) -> "ComputationContract":
        bound = record.get("approximation_bound")
        return cls(
            record["contract_id"],
            version=record.get("version", ""),
            semantics=record.get("semantics", ""),
            inputs=[ContractPort.from_canonical(p) for p in record.get("inputs", ())],
            outputs=[ContractPort.from_canonical(p) for p in record.get("outputs", ())],
            ownership=record.get("ownership", {}),
            correctness=record.get("correctness", ""),
            approximation=record.get("approximation", ApproximationPolicy.UNDECLARED),
            approximation_bound=None if bound is None else Exact.from_canonical(bound),
            workload={k: Exact.from_canonical(v) for k, v in record.get("workload", {}).items()},
            execution_model=record.get("execution_model", ExecutionModel.UNDECLARED),
            source_hash=record.get("source_hash", ""),
            exclusions=record.get("exclusions", ()),
        )


def _as_port(value: Any) -> ContractPort:
    if isinstance(value, ContractPort):
        return value
    if isinstance(value, Mapping):
        return ContractPort.from_canonical(value)
    raise ContractError(f"cannot read {type(value)!r} as a contract port")


# ---------------------------------------------------------------------------
# ResourceContract (spec 12.1)
# ---------------------------------------------------------------------------
class AccountingRule:
    """How a resource composes across a realization (12.1 "accounting").

    The distinction matters for geometry: an ``ADDITIVE`` coordinate supports
    a price-based (K) observation and a ``MAX`` one does not, so recording
    the rule is what lets 26.4 pick the minimum sufficient object rather than
    guess it.
    """

    ADDITIVE = "ADDITIVE"
    MAX = "MAX"
    MIN = "MIN"
    PEAK = "PEAK"
    NON_COMPOSABLE = "NON_COMPOSABLE"

    ALL = frozenset({ADDITIVE, MAX, MIN, PEAK, NON_COMPOSABLE})


@dataclass(frozen=True)
class ResourceContract(_Contract):
    """What may be spent, transformed, and gated (spec 12.1).

    12.1 requires: *legal transformations, resource types, accounting,
    hierarchy, budgets, concurrency, capability gates, exclusions*.

    ``budgets`` and ``concurrency`` are exact rationals, never floats: a
    budget is the boundary of an ``INFEASIBLE`` verdict, and a verdict decided
    by a rounding error is not a verdict (14.2, 22.6).
    """

    contract_id: str
    version: str = ""
    legal_transformations: Tuple[str, ...] = ()
    resource_types: Tuple[str, ...] = ()
    accounting: Tuple[Tuple[str, str], ...] = ()
    hierarchy_contract_ref: str = ""
    budgets: Tuple[Tuple[str, Exact], ...] = ()
    concurrency: Tuple[Tuple[str, Exact], ...] = ()
    capability_gates: Tuple[str, ...] = ()
    exclusions: Tuple[str, ...] = ()

    OBJECT_TYPE = "ResourceContract"
    REQUIRED = (
        "contract_id",
        "version",
        "legal_transformations",
        "resource_types",
        "accounting",
        "hierarchy_contract_ref",
        "budgets",
        "concurrency",
        "capability_gates",
        "exclusions",
    )

    def __init__(
        self,
        contract_id: str,
        *,
        version: str = "",
        legal_transformations: Any = (),
        resource_types: Any = (),
        accounting: Any = (),
        hierarchy_contract_ref: str = "",
        budgets: Any = (),
        concurrency: Any = (),
        capability_gates: Any = (),
        exclusions: Any = (),
    ) -> None:
        set_ = object.__setattr__
        set_(self, "contract_id", _text(contract_id, "contract_id"))
        set_(self, "version", _text(version, "version"))
        set_(
            self,
            "legal_transformations",
            _string_tuple(legal_transformations, "legal_transformations"),
        )
        set_(self, "resource_types", _string_tuple(resource_types, "resource_types"))
        set_(self, "accounting", _string_map(accounting, "accounting"))
        set_(self, "hierarchy_contract_ref", _text(hierarchy_contract_ref, "hierarchy_contract_ref"))
        set_(self, "budgets", _exact_map(budgets, "budgets"))
        set_(self, "concurrency", _exact_map(concurrency, "concurrency"))
        set_(self, "capability_gates", _string_tuple(capability_gates, "capability_gates"))
        set_(self, "exclusions", _string_tuple(exclusions, "exclusions"))

    def budget(self, resource: str) -> Optional[Exact]:
        for name, value in self.budgets:
            if name == resource:
                return value
        return None

    def accounting_rule(self, resource: str) -> Optional[str]:
        for name, rule in self.accounting:
            if name == resource:
                return rule
        return None

    def _extra_violations(self) -> List[str]:
        violations: List[str] = []
        declared = set(self.resource_types)
        for name, rule in self.accounting:
            if rule not in AccountingRule.ALL:
                violations.append(
                    f"accounting rule {rule!r} for {name!r} is outside the declared "
                    f"vocabulary {sorted(AccountingRule.ALL)} (spec 12.1)"
                )
            if declared and name not in declared:
                violations.append(
                    f"accounting declares a rule for resource {name!r}, which is not in the "
                    f"declared resource types {sorted(declared)}; an accounting rule for an "
                    "undeclared resource governs nothing (spec 12.1)"
                )
        for name, _value in self.budgets:
            if declared and name not in declared:
                violations.append(
                    f"a budget is declared for resource {name!r}, which is not in the "
                    f"declared resource types {sorted(declared)}; a budget on an undeclared "
                    "resource can never be checked (spec 6.6)"
                )
        for name, value in self.concurrency:
            if value < Exact(0):
                violations.append(
                    f"concurrency limit {name!r} is {value}; a negative concurrency limit is "
                    "not a limit"
                )
        for name, rule in self.accounting:
            if rule == AccountingRule.NON_COMPOSABLE and self.budget(name) is not None:
                violations.append(
                    f"resource {name!r} is declared NON_COMPOSABLE yet carries a budget; a "
                    "budget presumes the resource composes across the realization (12.1)"
                )
        return violations

    def to_canonical(self) -> dict:
        return {
            "object_type": self.OBJECT_TYPE,
            "contract_id": self.contract_id,
            "version": self.version,
            "legal_transformations": list(self.legal_transformations),
            "resource_types": list(self.resource_types),
            "accounting": dict(self.accounting),
            "hierarchy_contract_ref": self.hierarchy_contract_ref,
            "budgets": _canonical_exact_map(self.budgets),
            "concurrency": _canonical_exact_map(self.concurrency),
            "capability_gates": list(self.capability_gates),
            "exclusions": list(self.exclusions),
        }

    @classmethod
    def from_canonical(cls, record: Mapping[str, Any]) -> "ResourceContract":
        return cls(
            record["contract_id"],
            version=record.get("version", ""),
            legal_transformations=record.get("legal_transformations", ()),
            resource_types=record.get("resource_types", ()),
            accounting=record.get("accounting", {}),
            hierarchy_contract_ref=record.get("hierarchy_contract_ref", ""),
            budgets={k: Exact.from_canonical(v) for k, v in record.get("budgets", {}).items()},
            concurrency={
                k: Exact.from_canonical(v) for k, v in record.get("concurrency", {}).items()
            },
            capability_gates=record.get("capability_gates", ()),
            exclusions=record.get("exclusions", ()),
        )


# ---------------------------------------------------------------------------
# HierarchyContract (spec 12.1)
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class HierarchyLevel:
    """One named level of the hierarchy, with its depth.

    ``depth`` is an integer, ``0`` being the outermost declared level.  Levels
    are an *order*, not a set: a placement rule that says "no lower than
    level X" is meaningless without one.
    """

    name: str
    depth: int
    description: str = ""

    def __post_init__(self) -> None:
        if not self.name:
            raise ContractError("a hierarchy level MUST be named (spec 12.1)")
        if isinstance(self.depth, bool) or not isinstance(self.depth, int):
            raise ContractError(
                f"hierarchy level {self.name!r}: depth MUST be an integer, got "
                f"{type(self.depth)!r}"
            )
        if self.depth < 0:
            raise ContractError(f"hierarchy level {self.name!r}: depth MUST be nonnegative")

    def to_canonical(self) -> dict:
        record: Dict[str, Any] = {"name": self.name, "depth": self.depth}
        if self.description:
            record["description"] = self.description
        return record

    @classmethod
    def from_canonical(cls, record: Mapping[str, Any]) -> "HierarchyLevel":
        return cls(
            name=_text(record["name"], "level name"),
            depth=int(record["depth"]),
            description=_text(record.get("description", ""), "level description"),
        )


@dataclass(frozen=True)
class HierarchyLocation:
    """A named place at a declared level, in a declared ownership domain."""

    name: str
    level: str
    ownership_domain: str = ""
    capacity: Optional[Exact] = None

    def __init__(
        self,
        name: str,
        level: str,
        ownership_domain: str = "",
        capacity: Any = None,
    ) -> None:
        set_ = object.__setattr__
        if not name:
            raise ContractError("a hierarchy location MUST be named (spec 12.1)")
        if not level:
            raise ContractError(f"location {name!r} declares no level")
        set_(self, "name", _text(name, "location name"))
        set_(self, "level", _text(level, "location level"))
        set_(self, "ownership_domain", _text(ownership_domain, "ownership_domain"))
        if capacity is None:
            set_(self, "capacity", None)
        else:
            try:
                set_(self, "capacity", capacity if isinstance(capacity, Exact) else Exact(capacity))
            except TypeError as error:
                raise ContractError(f"location {name!r}: capacity {error}") from None

    def to_canonical(self) -> dict:
        record: Dict[str, Any] = {"name": self.name, "level": self.level}
        if self.ownership_domain:
            record["ownership_domain"] = self.ownership_domain
        if self.capacity is not None:
            record["capacity"] = self.capacity.to_canonical()
        return record

    @classmethod
    def from_canonical(cls, record: Mapping[str, Any]) -> "HierarchyLocation":
        capacity = record.get("capacity")
        return cls(
            name=_text(record["name"], "location name"),
            level=_text(record["level"], "location level"),
            ownership_domain=_text(record.get("ownership_domain", ""), "ownership_domain"),
            capacity=None if capacity is None else Exact.from_canonical(capacity),
        )


@dataclass(frozen=True)
class HierarchyInterface:
    """A declared interface between two locations.

    ``kind`` is the caller's vocabulary.  ``bidirectional`` is explicit
    because an interface that happens to be usable in one direction is a
    different topology from one usable in both, and 12.1 asks for interfaces,
    not adjacency.
    """

    name: str
    source: str
    target: str
    kind: str = ""
    bidirectional: bool = False

    def __post_init__(self) -> None:
        if not self.name:
            raise ContractError("a hierarchy interface MUST be named (spec 12.1)")
        if not self.source or not self.target:
            raise ContractError(f"interface {self.name!r} MUST declare a source and a target")
        if not isinstance(self.bidirectional, bool):
            raise ContractError(f"interface {self.name!r}: 'bidirectional' MUST be a bool")

    def to_canonical(self) -> dict:
        record: Dict[str, Any] = {
            "name": self.name,
            "source": self.source,
            "target": self.target,
            "bidirectional": self.bidirectional,
        }
        if self.kind:
            record["kind"] = self.kind
        return record

    @classmethod
    def from_canonical(cls, record: Mapping[str, Any]) -> "HierarchyInterface":
        return cls(
            name=_text(record["name"], "interface name"),
            source=_text(record["source"], "interface source"),
            target=_text(record["target"], "interface target"),
            kind=_text(record.get("kind", ""), "interface kind"),
            bidirectional=bool(record.get("bidirectional", False)),
        )


@dataclass(frozen=True)
class PlacementRule:
    """One declared constraint on where something may be placed.

    ``effect`` is ``PERMIT`` or ``FORBID`` and is mandatory: a rule that does
    not say which way it points is not a rule, and defaulting it would decide
    the case for the author (6.6).
    """

    rule_id: str
    effect: str
    subject: str
    locations: Tuple[str, ...] = ()
    rationale: str = ""

    PERMIT = "PERMIT"
    FORBID = "FORBID"
    EFFECTS = frozenset({PERMIT, FORBID})

    def __init__(
        self,
        rule_id: str,
        effect: str,
        subject: str,
        locations: Any = (),
        rationale: str = "",
    ) -> None:
        set_ = object.__setattr__
        if not rule_id:
            raise ContractError("a placement rule MUST be identified (spec 12.1)")
        if effect not in PlacementRule.EFFECTS:
            raise ContractError(
                f"placement rule {rule_id!r}: effect MUST be one of "
                f"{sorted(PlacementRule.EFFECTS)}, got {effect!r}"
            )
        if not subject:
            raise ContractError(f"placement rule {rule_id!r} declares no subject")
        set_(self, "rule_id", _text(rule_id, "rule_id"))
        set_(self, "effect", effect)
        set_(self, "subject", _text(subject, "subject"))
        set_(self, "locations", _string_tuple(locations, "locations"))
        set_(self, "rationale", _text(rationale, "rationale"))

    def to_canonical(self) -> dict:
        record: Dict[str, Any] = {
            "rule_id": self.rule_id,
            "effect": self.effect,
            "subject": self.subject,
            "locations": list(self.locations),
        }
        if self.rationale:
            record["rationale"] = self.rationale
        return record

    @classmethod
    def from_canonical(cls, record: Mapping[str, Any]) -> "PlacementRule":
        return cls(
            rule_id=_text(record["rule_id"], "rule_id"),
            effect=_text(record["effect"], "effect"),
            subject=_text(record["subject"], "subject"),
            locations=record.get("locations", ()),
            rationale=_text(record.get("rationale", ""), "rationale"),
        )


@dataclass(frozen=True)
class HierarchyContract(_Contract):
    """Where things may live and who owns them (spec 12.1).

    12.1 requires: *levels, locations, interfaces, ownership domains,
    placement rules, topology abstractions*.

    Internal references are checked, not assumed.  A location at an undeclared
    level, an interface between undeclared locations, or a placement rule
    naming an undeclared location are each a violation: a hierarchy that
    refers outside itself cannot bound a placement, and an unbounded placement
    cannot support an obligation (18.1).
    """

    contract_id: str
    version: str = ""
    levels: Tuple[HierarchyLevel, ...] = ()
    locations: Tuple[HierarchyLocation, ...] = ()
    interfaces: Tuple[HierarchyInterface, ...] = ()
    ownership_domains: Tuple[str, ...] = ()
    placement_rules: Tuple[PlacementRule, ...] = ()
    topology_abstractions: Tuple[str, ...] = ()

    OBJECT_TYPE = "HierarchyContract"
    REQUIRED = (
        "contract_id",
        "version",
        "levels",
        "locations",
        "interfaces",
        "ownership_domains",
        "placement_rules",
        "topology_abstractions",
    )

    def __init__(
        self,
        contract_id: str,
        *,
        version: str = "",
        levels: Sequence[Any] = (),
        locations: Sequence[Any] = (),
        interfaces: Sequence[Any] = (),
        ownership_domains: Any = (),
        placement_rules: Sequence[Any] = (),
        topology_abstractions: Any = (),
    ) -> None:
        set_ = object.__setattr__
        set_(self, "contract_id", _text(contract_id, "contract_id"))
        set_(self, "version", _text(version, "version"))
        set_(self, "levels", tuple(_as(HierarchyLevel, v) for v in levels))
        set_(self, "locations", tuple(_as(HierarchyLocation, v) for v in locations))
        set_(self, "interfaces", tuple(_as(HierarchyInterface, v) for v in interfaces))
        set_(self, "ownership_domains", _string_tuple(ownership_domains, "ownership_domains"))
        set_(self, "placement_rules", tuple(_as(PlacementRule, v) for v in placement_rules))
        set_(
            self,
            "topology_abstractions",
            _string_tuple(topology_abstractions, "topology_abstractions"),
        )

    @property
    def level_names(self) -> Tuple[str, ...]:
        return tuple(level.name for level in sorted(self.levels, key=lambda l: (l.depth, l.name)))

    @property
    def location_names(self) -> Tuple[str, ...]:
        return tuple(location.name for location in self.locations)

    def _extra_violations(self) -> List[str]:
        violations: List[str] = []
        level_names = {level.name for level in self.levels}
        location_names = {location.name for location in self.locations}
        domains = set(self.ownership_domains)

        depths = [level.depth for level in self.levels]
        if len(set(depths)) != len(depths):
            violations.append(
                "two hierarchy levels share a depth; levels are an order, and an order with "
                "ties cannot bound a placement rule (spec 12.1)"
            )
        if len(level_names) != len(self.levels):
            violations.append("two hierarchy levels share a name (spec 12.1)")
        if len(location_names) != len(self.locations):
            violations.append("two hierarchy locations share a name (spec 12.1)")

        for location in self.locations:
            if location.level not in level_names:
                violations.append(
                    f"location {location.name!r} sits at level {location.level!r}, which the "
                    f"contract does not declare; declared levels are {sorted(level_names)}"
                )
            if location.ownership_domain and domains and location.ownership_domain not in domains:
                violations.append(
                    f"location {location.name!r} is owned by {location.ownership_domain!r}, "
                    f"which is not a declared ownership domain {sorted(domains)}"
                )
        for interface in self.interfaces:
            for endpoint in (interface.source, interface.target):
                if endpoint not in location_names:
                    violations.append(
                        f"interface {interface.name!r} touches location {endpoint!r}, which "
                        "the contract does not declare; an interface to nowhere abstracts no "
                        "topology (spec 12.1)"
                    )
        for rule in self.placement_rules:
            for name in rule.locations:
                if name not in location_names and name not in level_names:
                    violations.append(
                        f"placement rule {rule.rule_id!r} names {name!r}, which is neither a "
                        "declared location nor a declared level; a rule that cannot be "
                        "evaluated cannot be enforced (spec 6.6)"
                    )
        return violations

    def to_canonical(self) -> dict:
        return {
            "object_type": self.OBJECT_TYPE,
            "contract_id": self.contract_id,
            "version": self.version,
            "levels": [level.to_canonical() for level in self.levels],
            "locations": [location.to_canonical() for location in self.locations],
            "interfaces": [interface.to_canonical() for interface in self.interfaces],
            "ownership_domains": list(self.ownership_domains),
            "placement_rules": [rule.to_canonical() for rule in self.placement_rules],
            "topology_abstractions": list(self.topology_abstractions),
        }

    @classmethod
    def from_canonical(cls, record: Mapping[str, Any]) -> "HierarchyContract":
        return cls(
            record["contract_id"],
            version=record.get("version", ""),
            levels=[HierarchyLevel.from_canonical(v) for v in record.get("levels", ())],
            locations=[HierarchyLocation.from_canonical(v) for v in record.get("locations", ())],
            interfaces=[
                HierarchyInterface.from_canonical(v) for v in record.get("interfaces", ())
            ],
            ownership_domains=record.get("ownership_domains", ()),
            placement_rules=[
                PlacementRule.from_canonical(v) for v in record.get("placement_rules", ())
            ],
            topology_abstractions=record.get("topology_abstractions", ()),
        )


def _as(cls: Any, value: Any) -> Any:
    if isinstance(value, cls):
        return value
    if isinstance(value, Mapping):
        return cls.from_canonical(value)
    raise ContractError(f"cannot read {type(value)!r} as {cls.__name__}")


# ---------------------------------------------------------------------------
# AdapterManifest (spec 12.1, 36.1)
# ---------------------------------------------------------------------------
class AdapterFidelity:
    """What an adapter preserves across the boundary (12.1 "fidelity").

    ``LOSSY_DECLARED`` and ``LOSSY_UNDECLARED`` are separate on purpose.  6.11
    forbids silent truncation: an adapter that loses information and says
    which information it loses is usable; one that loses information without
    saying what is not, and this loader will not let the second present itself
    as the first.
    """

    LOSSLESS = "LOSSLESS"
    LOSSY_DECLARED = "LOSSY_DECLARED"
    LOSSY_UNDECLARED = "LOSSY_UNDECLARED"
    STRUCTURAL_ONLY = "STRUCTURAL_ONLY"

    ALL = frozenset({LOSSLESS, LOSSY_DECLARED, LOSSY_UNDECLARED, STRUCTURAL_ONLY})

    #: Only these may carry an object into a case without a declared loss note.
    PRESERVING = frozenset({LOSSLESS})


@dataclass(frozen=True)
class AdapterManifest(_Contract):
    """An external-system adapter's declaration (spec 12.1, 36.1).

    12.1 requires: *external system, supported inputs and outputs, fidelity,
    failures, permissions, and versions*.

    An adapter is not a domain pack: it does not contribute generators or
    certificate semantics, it moves records across a boundary.  Its manifest
    is therefore much smaller than a :class:`DomainPackManifest`, and its
    ``permissions`` are the permissions of 36.2/36.3 read for a connector --
    an adapter that reaches the network says so here or does not reach it.
    """

    adapter_id: str
    version: str = ""
    external_system: str = ""
    external_system_versions: Tuple[str, ...] = ()
    supported_inputs: Tuple[str, ...] = ()
    supported_outputs: Tuple[str, ...] = ()
    fidelity: str = ""
    declared_losses: Tuple[str, ...] = ()
    failure_modes: Tuple[str, ...] = ()
    permissions: Tuple[str, ...] = ()
    supported_spec_versions: Tuple[str, ...] = ()
    publisher: str = ""

    OBJECT_TYPE = "AdapterManifest"
    REQUIRED = (
        "adapter_id",
        "version",
        "external_system",
        "external_system_versions",
        "supported_inputs",
        "supported_outputs",
        "fidelity",
        "failure_modes",
        "permissions",
        "supported_spec_versions",
        "publisher",
    )

    def __init__(
        self,
        adapter_id: str,
        *,
        version: str = "",
        external_system: str = "",
        external_system_versions: Any = (),
        supported_inputs: Any = (),
        supported_outputs: Any = (),
        fidelity: str = "",
        declared_losses: Any = (),
        failure_modes: Any = (),
        permissions: Any = (),
        supported_spec_versions: Any = (),
        publisher: str = "",
    ) -> None:
        set_ = object.__setattr__
        set_(self, "adapter_id", _text(adapter_id, "adapter_id"))
        set_(self, "version", _text(version, "version"))
        set_(self, "external_system", _text(external_system, "external_system"))
        set_(
            self,
            "external_system_versions",
            _string_tuple(external_system_versions, "external_system_versions"),
        )
        set_(self, "supported_inputs", _string_tuple(supported_inputs, "supported_inputs"))
        set_(self, "supported_outputs", _string_tuple(supported_outputs, "supported_outputs"))
        set_(self, "fidelity", _text(fidelity, "fidelity"))
        set_(self, "declared_losses", _string_tuple(declared_losses, "declared_losses"))
        set_(self, "failure_modes", _string_tuple(failure_modes, "failure_modes"))
        set_(self, "permissions", tuple(sorted(_string_tuple(permissions, "permissions"))))
        set_(
            self,
            "supported_spec_versions",
            _string_tuple(supported_spec_versions, "supported_spec_versions"),
        )
        set_(self, "publisher", _text(publisher, "publisher"))

    @property
    def qualified_id(self) -> str:
        return f"{self.adapter_id}@{self.version}" if self.adapter_id else "(unidentified adapter)"

    def _extra_violations(self) -> List[str]:
        violations: List[str] = []
        if self.fidelity and self.fidelity not in AdapterFidelity.ALL:
            violations.append(
                f"fidelity {self.fidelity!r} is outside the declared vocabulary "
                f"{sorted(AdapterFidelity.ALL)} (spec 12.1)"
            )
        if self.fidelity == AdapterFidelity.LOSSY_DECLARED and not self.declared_losses:
            violations.append(
                "the adapter declares LOSSY_DECLARED fidelity but names no loss; an adapter "
                "that loses information without saying what it loses is LOSSY_UNDECLARED, "
                "and 6.11 forbids presenting the second as the first"
            )
        if self.fidelity == AdapterFidelity.LOSSLESS and self.declared_losses:
            violations.append(
                "the adapter declares LOSSLESS fidelity yet names losses; the two statements "
                "contradict each other (spec 6.6, 6.11)"
            )
        return violations

    def to_canonical(self) -> dict:
        record: Dict[str, Any] = {
            "object_type": self.OBJECT_TYPE,
            "adapter_id": self.adapter_id,
            "version": self.version,
            "external_system": self.external_system,
            "external_system_versions": list(self.external_system_versions),
            "supported_inputs": list(self.supported_inputs),
            "supported_outputs": list(self.supported_outputs),
            "fidelity": self.fidelity,
            "failure_modes": list(self.failure_modes),
            "permissions": list(self.permissions),
            "supported_spec_versions": list(self.supported_spec_versions),
            "publisher": self.publisher,
        }
        if self.declared_losses:
            record["declared_losses"] = list(self.declared_losses)
        return record

    @classmethod
    def from_canonical(cls, record: Mapping[str, Any]) -> "AdapterManifest":
        return cls(
            record["adapter_id"],
            version=record.get("version", ""),
            external_system=record.get("external_system", ""),
            external_system_versions=record.get("external_system_versions", ()),
            supported_inputs=record.get("supported_inputs", ()),
            supported_outputs=record.get("supported_outputs", ()),
            fidelity=record.get("fidelity", ""),
            declared_losses=record.get("declared_losses", ()),
            failure_modes=record.get("failure_modes", ()),
            permissions=record.get("permissions", ()),
            supported_spec_versions=record.get("supported_spec_versions", ()),
            publisher=record.get("publisher", ""),
        )
