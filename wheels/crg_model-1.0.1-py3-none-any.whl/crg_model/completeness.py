"""Completeness basis and certificate claim scope.

Normative basis: master specification section 21.  The software generally
holds a represented family, not a proof of the universal legal family; the
basis type below is what keeps that distinction visible in every claim.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Sequence

__all__ = ["CompletenessBasisType", "ClaimScope", "CompletenessBasis", "derive_claim_scope"]


class CompletenessBasisType:
    """Specification 21.2."""

    EXHAUSTIVE_DECLARED_UNIVERSE = "EXHAUSTIVE_DECLARED_UNIVERSE"
    GENERATOR_CLOSED = "GENERATOR_CLOSED"
    EXPLICIT_IMPORTED_FAMILY = "EXPLICIT_IMPORTED_FAMILY"
    BOUNDED_UNENUMERATED_FAMILY = "BOUNDED_UNENUMERATED_FAMILY"
    TRUNCATED_BY_DECLARED_RULE = "TRUNCATED_BY_DECLARED_RULE"
    KNOWN_INCOMPLETE = "KNOWN_INCOMPLETE"
    UNKNOWN = "UNKNOWN"

    ALL = frozenset(
        {
            EXHAUSTIVE_DECLARED_UNIVERSE,
            GENERATOR_CLOSED,
            EXPLICIT_IMPORTED_FAMILY,
            BOUNDED_UNENUMERATED_FAMILY,
            TRUNCATED_BY_DECLARED_RULE,
            KNOWN_INCOMPLETE,
            UNKNOWN,
        }
    )


class ClaimScope:
    """Specification 21.4."""

    FULL_DECLARED_UNIVERSE = "FULL_DECLARED_UNIVERSE"
    GENERATOR_CLOSED_FAMILY = "GENERATOR_CLOSED_FAMILY"
    BOUNDED_REMAINDER_GLOBAL = "BOUNDED_REMAINDER_GLOBAL"
    RELATIVE_EXPLICIT_FAMILY = "RELATIVE_EXPLICIT_FAMILY"
    PARTIAL_FAMILY = "PARTIAL_FAMILY"

    #: Specification 21.5 -- which scopes may carry a globally phrased winner.
    STRONG = frozenset(
        {FULL_DECLARED_UNIVERSE, GENERATOR_CLOSED_FAMILY, BOUNDED_REMAINDER_GLOBAL}
    )
    RELATIVE_ONLY = frozenset({RELATIVE_EXPLICIT_FAMILY})
    NO_WINNER_CLAIM = frozenset({PARTIAL_FAMILY})


@dataclass
class CompletenessBasis:
    """Specification 21.3: required fields."""

    basis_type: str
    declared_universe: str
    source_or_generator_hash: Optional[str] = None
    generator_versions: Sequence[str] = ()
    closure_procedure: Optional[str] = None
    closure_proof: Optional[str] = None
    truncation_rule: Optional[str] = None
    remainder_bound: Optional[str] = None
    known_omissions: Sequence[str] = ()
    validity: Optional[str] = None
    dependencies: Sequence[str] = ()

    def __post_init__(self) -> None:
        if self.basis_type not in CompletenessBasisType.ALL:
            raise ValueError(f"unknown completeness basis type {self.basis_type!r}")
        if (
            self.basis_type == CompletenessBasisType.BOUNDED_UNENUMERATED_FAMILY
            and not self.remainder_bound
        ):
            raise ValueError(
                "BOUNDED_UNENUMERATED_FAMILY requires a remainder bound (spec 21.3, 21.6)"
            )
        if (
            self.basis_type == CompletenessBasisType.TRUNCATED_BY_DECLARED_RULE
            and not self.truncation_rule
        ):
            raise ValueError("TRUNCATED_BY_DECLARED_RULE requires a recorded truncation rule")

    def to_canonical(self) -> dict:
        record = {
            "basis_type": self.basis_type,
            "declared_universe": self.declared_universe,
        }
        for key, value in (
            ("source_or_generator_hash", self.source_or_generator_hash),
            ("closure_procedure", self.closure_procedure),
            ("closure_proof", self.closure_proof),
            ("truncation_rule", self.truncation_rule),
            ("remainder_bound", self.remainder_bound),
            ("validity", self.validity),
        ):
            if value is not None:
                record[key] = value
        if self.generator_versions:
            record["generator_versions"] = list(self.generator_versions)
        if self.known_omissions:
            record["known_omissions"] = list(self.known_omissions)
        if self.dependencies:
            record["dependencies"] = list(self.dependencies)
        return record


def derive_claim_scope(basis: CompletenessBasis, remainder_bound_closes: bool = False) -> str:
    """Derive the certificate claim scope from the completeness basis (spec 21.4).

    ``remainder_bound_closes`` asserts that a bound provider has proved the
    unenumerated remainder cannot change the declared decision (spec 21.6).
    """
    t = basis.basis_type
    T = CompletenessBasisType
    if t == T.EXHAUSTIVE_DECLARED_UNIVERSE:
        return ClaimScope.FULL_DECLARED_UNIVERSE
    if t == T.GENERATOR_CLOSED:
        return ClaimScope.GENERATOR_CLOSED_FAMILY
    if t == T.BOUNDED_UNENUMERATED_FAMILY:
        return (
            ClaimScope.BOUNDED_REMAINDER_GLOBAL
            if remainder_bound_closes
            else ClaimScope.PARTIAL_FAMILY
        )
    if t == T.EXPLICIT_IMPORTED_FAMILY:
        return ClaimScope.RELATIVE_EXPLICIT_FAMILY
    # TRUNCATED_BY_DECLARED_RULE, KNOWN_INCOMPLETE, UNKNOWN
    return ClaimScope.PARTIAL_FAMILY
