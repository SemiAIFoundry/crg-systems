"""RFC 8785 JSON Canonicalization Scheme (JCS) and CRG content hashing.

Normative basis: master specification section 14.3 (canonicalization),
14.4 (hashing).  Binary floating point MUST NOT enter a canonical hash
without a specified canonical encoding; this module refuses float input
outright and requires exact numeric forms (see crg_model.numeric).
"""
from __future__ import annotations

import hashlib
import json
import re
from fractions import Fraction
from typing import Any

__all__ = [
    "canonical_json",
    "canonical_bytes",
    "content_hash",
    "hash_of",
    "CanonicalizationError",
]

HASH_ALGORITHM = "sha256"
HASH_PREFIX = "sha256:"


class CanonicalizationError(TypeError):
    """Raised when a value cannot be canonically encoded."""


def _serialize_string(value: str) -> str:
    # RFC 8785 mandates the JSON string escaping of RFC 8259 with the
    # shortest possible escapes; json.dumps with ensure_ascii=False and
    # no whitespace matches that behaviour for well-formed input.
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def _serialize(value: Any) -> str:
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, str):
        return _serialize_string(value)
    if isinstance(value, float):
        raise CanonicalizationError(
            "binary floating point is not admissible in canonical CRG content; "
            "use an exact numeric representation (integer, rational, or decimal string)"
        )
    if isinstance(value, int):
        return str(value)
    if isinstance(value, Fraction):
        raise CanonicalizationError(
            "raw Fraction is not canonically encodable; wrap it with "
            "crg_model.numeric.Exact so its representation is explicit"
        )
    if isinstance(value, dict):
        items = []
        for key in sorted(value.keys(), key=_utf16_sort_key):
            if not isinstance(key, str):
                raise CanonicalizationError(f"object keys MUST be strings, got {type(key)!r}")
            items.append(f"{_serialize_string(key)}:{_serialize(value[key])}")
        return "{" + ",".join(items) + "}"
    if isinstance(value, (list, tuple)):
        return "[" + ",".join(_serialize(v) for v in value) + "]"
    to_canonical = getattr(value, "to_canonical", None)
    if callable(to_canonical):
        return _serialize(to_canonical())
    raise CanonicalizationError(f"no canonical encoding for {type(value)!r}")


def _utf16_sort_key(key: str) -> tuple:
    # RFC 8785 sorts object members by UTF-16 code units.
    return tuple(key.encode("utf-16-be"))


def canonical_json(value: Any) -> str:
    """Return the RFC 8785 canonical JSON text for ``value``."""
    return _serialize(value)


def canonical_bytes(value: Any) -> bytes:
    return canonical_json(value).encode("utf-8")


def content_hash(value: Any) -> str:
    """Return ``sha256:<hex>`` over the canonical encoding of ``value``."""
    digest = hashlib.sha256(canonical_bytes(value)).hexdigest()
    return HASH_PREFIX + digest


def hash_of(value: Any) -> str:
    return content_hash(value)


_HASH_RE = re.compile(r"^sha256:[0-9a-f]{64}$")


def is_hash(value: Any) -> bool:
    return isinstance(value, str) and bool(_HASH_RE.match(value))
