"""Registered, replayable schema migrations and classification evidence.

Normative basis: CRG Operational Systems Master Specification 15.3--15.6.
Migration is a trust boundary: a request may select a registered transform and
may assert the class it expects, but it may not *supply* the transform's
semantic class.  This module is the single registry used by the CLI and the
server, and its records contain enough canonical evidence for the independent
verifier to check the currently supported identity transform without importing
this package.

The 0.2.0 release has no historical CRG schema to upgrade.  Its sole honest
path is therefore an identity transform from 0.2.0 to 0.2.0.  Unknown future
paths fail closed until a release adds a concrete algorithm and a separately
reviewable classification rule here.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, Dict, Iterable, Mapping, Optional, Tuple

from .canonical import canonical_json, content_hash

__all__ = [
    "MIGRATION_CLASSES",
    "IDENTITY_ALGORITHM",
    "MigrationError",
    "UnknownMigrationClass",
    "MigrationTransformNotFound",
    "MigrationTransformAmbiguous",
    "MigrationClassMismatch",
    "MigrationProofError",
    "MigrationTransform",
    "MigrationExecution",
    "MigrationRegistry",
    "DEFAULT_MIGRATION_REGISTRY",
    "verify_classification_evidence",
]

MIGRATION_CLASSES: Tuple[str, ...] = (
    "SEMANTICALLY_EQUIVALENT",
    "SEMANTICALLY_WIDENING",
    "SEMANTICALLY_NARROWING",
    "SEMANTIC_CHANGE",
    "LOSSY",
    "UNVERIFIED",
)

IDENTITY_ALGORITHM = "CANONICAL_IDENTITY_V1"
_PROOF_TYPE = "CRG_MIGRATION_CLASSIFICATION_PROOF_V1"
_PROOF_VERIFIER = "crg-model:migration-classification-v1"
_REGISTRY_TYPE = "CRG_MIGRATION_TRANSFORM_REGISTRY_V1"
_IDENTITY_CHECKS: Tuple[str, ...] = (
    "SOURCE_VERSION_EQUALS_TARGET_VERSION",
    "ALGORITHM_IS_CANONICAL_IDENTITY_V1",
    "CANONICAL_INPUT_HASH_EQUALS_OUTPUT_HASH",
)


class MigrationError(ValueError):
    """A requested migration is not supported or its evidence is invalid."""


class UnknownMigrationClass(MigrationError):
    """A class outside the fixed vocabulary of specification 15.4."""


class MigrationTransformNotFound(MigrationError):
    """No installed transform covers the requested source/target path."""


class MigrationTransformAmbiguous(MigrationError):
    """More than one transform covers a path and none was selected."""


class MigrationClassMismatch(MigrationError):
    """The caller's assertion disagrees with the registered classification."""


class MigrationProofError(MigrationError):
    """A transform or its semantic-classification evidence did not verify."""


def _copy(value: Mapping[str, Any]) -> Dict[str, Any]:
    """Canonical JSON round-trip: no aliasing and no unhashable float input."""
    return json.loads(canonical_json(dict(value)))


def _normalize_class(value: Optional[str]) -> Optional[str]:
    if value is None or not str(value).strip():
        return None
    normalized = str(value).strip().upper()
    if normalized not in MIGRATION_CLASSES:
        raise UnknownMigrationClass(
            f"unknown migration class {value!r}; specification 15.4 fixes the "
            f"vocabulary at {list(MIGRATION_CLASSES)}"
        )
    return normalized


@dataclass(frozen=True)
class MigrationTransform:
    """An immutable registered transform plus its classification contract.

    ``algorithm`` is deliberately a closed executable vocabulary rather than
    an arbitrary callback.  A callback's name or a caller-provided hash would
    not let an independent verifier determine what was run.
    """

    transform_id: str
    source_schema_version: str
    target_schema_version: str
    migration_class: str
    algorithm: str
    algorithm_version: str
    description: str
    classification_basis: str

    def __post_init__(self) -> None:
        if not self.transform_id.strip():
            raise MigrationError("a migration transform must have a stable identifier")
        if not self.source_schema_version or not self.target_schema_version:
            raise MigrationError("a migration transform must bind source and target versions")
        normalized = _normalize_class(self.migration_class)
        object.__setattr__(self, "migration_class", str(normalized))
        if self.algorithm != IDENTITY_ALGORITHM:
            raise MigrationError(
                f"unsupported migration algorithm {self.algorithm!r}; add an executable "
                "algorithm and independent classification verifier before registering it"
            )
        if self.source_schema_version != self.target_schema_version:
            raise MigrationError("a canonical identity transform cannot change schema version")
        if self.migration_class != "SEMANTICALLY_EQUIVALENT":
            raise MigrationError("a canonical identity transform can only be semantically equivalent")
        if not self.algorithm_version or not self.classification_basis:
            raise MigrationError("algorithm version and classification basis are mandatory")

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "transform_type": "CRG_SCHEMA_MIGRATION_TRANSFORM_V1",
            "transform_id": self.transform_id,
            "source_schema_version": self.source_schema_version,
            "target_schema_version": self.target_schema_version,
            "migration_class": self.migration_class,
            "algorithm": self.algorithm,
            "algorithm_version": self.algorithm_version,
            "description": self.description,
            "classification_basis": self.classification_basis,
        }

    @property
    def transform_hash(self) -> str:
        return content_hash(self.to_canonical())

    def classification_proof(self) -> Dict[str, Any]:
        """Return the static proof contract bound to this transform descriptor."""
        return {
            "proof_type": _PROOF_TYPE,
            "verifier_id": _PROOF_VERIFIER,
            "transform_id": self.transform_id,
            "transform_hash": self.transform_hash,
            "migration_class": self.migration_class,
            "basis": self.classification_basis,
            "checks": list(_IDENTITY_CHECKS),
        }

    @property
    def classification_proof_hash(self) -> str:
        return content_hash(self.classification_proof())

    def apply(self, source: Mapping[str, Any]) -> Dict[str, Any]:
        actual_version = str(source.get("schema_version") or "")
        if actual_version != self.source_schema_version:
            raise MigrationProofError(
                f"transform {self.transform_id!r} requires source schema "
                f"{self.source_schema_version!r}, got {actual_version!r}"
            )
        target = _copy(source)
        if self.algorithm == IDENTITY_ALGORITHM:
            # The canonical round-trip above is the entire algorithm.  The
            # closed algorithm vocabulary makes this branch independently
            # reproducible rather than a name attached to arbitrary code.
            pass
        if str(target.get("schema_version") or "") != self.target_schema_version:
            raise MigrationProofError(
                f"transform {self.transform_id!r} did not produce target schema "
                f"{self.target_schema_version!r}"
            )
        self.verify_execution(source, target)
        return target

    def verify_execution(
        self, source: Mapping[str, Any], target: Mapping[str, Any]
    ) -> None:
        if self.algorithm == IDENTITY_ALGORITHM and content_hash(source) != content_hash(target):
            raise MigrationProofError(
                f"identity transform {self.transform_id!r} changed canonical content"
            )


@dataclass(frozen=True)
class MigrationExecution:
    """A verified application of one registered transform to one source object."""

    transform: MigrationTransform
    registry_version: str
    registry_descriptor: Mapping[str, Any]
    source_object_hash: str
    transformed_object_hash: str
    transformed: Mapping[str, Any]

    def evidence(self) -> Dict[str, Any]:
        proof = self.transform.classification_proof()
        return {
            "transform_id": self.transform.transform_id,
            "transform_descriptor": self.transform.to_canonical(),
            "transform_hash": self.transform.transform_hash,
            "migration_registry_descriptor": dict(self.registry_descriptor),
            "migration_registry_version": self.registry_version,
            "classification_proof": proof,
            "classification_proof_hash": content_hash(proof),
            "classification_verified": True,
            "transform_input_hash": self.source_object_hash,
            "transform_output_hash": self.transformed_object_hash,
        }


@dataclass(frozen=True)
class MigrationRegistry:
    """Immutable transform lookup by identifier or exact version path."""

    _transforms: Tuple[MigrationTransform, ...] = field(init=False, repr=False)
    _by_id: Mapping[str, MigrationTransform] = field(init=False, repr=False)
    _by_path: Mapping[Tuple[str, str], Tuple[MigrationTransform, ...]] = field(
        init=False, repr=False
    )

    def __init__(self, transforms: Iterable[MigrationTransform]) -> None:
        ordered = tuple(sorted(tuple(transforms), key=lambda item: item.transform_id))
        by_id: Dict[str, MigrationTransform] = {}
        by_path: Dict[Tuple[str, str], Tuple[MigrationTransform, ...]] = {}
        for transform in ordered:
            if transform.transform_id in by_id:
                raise MigrationError(f"duplicate migration transform {transform.transform_id!r}")
            by_id[transform.transform_id] = transform
            path = (transform.source_schema_version, transform.target_schema_version)
            by_path[path] = by_path.get(path, ()) + (transform,)
        object.__setattr__(self, "_transforms", ordered)
        object.__setattr__(self, "_by_id", MappingProxyType(by_id))
        object.__setattr__(self, "_by_path", MappingProxyType(by_path))

    @property
    def transforms(self) -> Tuple[MigrationTransform, ...]:
        return self._transforms

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "registry_type": _REGISTRY_TYPE,
            "transforms": [item.to_canonical() for item in self._transforms],
        }

    @property
    def version(self) -> str:
        return content_hash(self.to_canonical())

    def resolve(
        self,
        source_version: str,
        target_version: str,
        *,
        transform_id: Optional[str] = None,
        declared_class: Optional[str] = None,
    ) -> MigrationTransform:
        asserted_class = _normalize_class(declared_class)
        if transform_id:
            transform = self._by_id.get(str(transform_id))
            if transform is None:
                raise MigrationTransformNotFound(
                    f"no registered migration transform has id {transform_id!r}"
                )
            if (transform.source_schema_version, transform.target_schema_version) != (
                source_version,
                target_version,
            ):
                raise MigrationTransformNotFound(
                    f"registered transform {transform_id!r} covers "
                    f"{transform.source_schema_version} -> {transform.target_schema_version}, "
                    f"not {source_version} -> {target_version}"
                )
        else:
            candidates = self._by_path.get((source_version, target_version), ())
            if not candidates:
                raise MigrationTransformNotFound(
                    f"no registered migration transform exists for "
                    f"{source_version} -> {target_version}"
                )
            if len(candidates) != 1:
                raise MigrationTransformAmbiguous(
                    f"{len(candidates)} registered transforms cover {source_version} -> "
                    f"{target_version}; select one by transform_id"
                )
            transform = candidates[0]
        if asserted_class is not None and asserted_class != transform.migration_class:
            raise MigrationClassMismatch(
                f"declared migration class {asserted_class!r} disagrees with registered "
                f"transform {transform.transform_id!r}, classified "
                f"{transform.migration_class!r}"
            )
        return transform

    def execute(
        self,
        source: Mapping[str, Any],
        target_version: str,
        *,
        transform_id: Optional[str] = None,
        declared_class: Optional[str] = None,
    ) -> MigrationExecution:
        source_version = str(source.get("schema_version") or "")
        transform = self.resolve(
            source_version,
            str(target_version),
            transform_id=transform_id,
            declared_class=declared_class,
        )
        source_hash = content_hash(source)
        transformed = transform.apply(source)
        transformed_hash = content_hash(transformed)
        execution = MigrationExecution(
            transform=transform,
            registry_version=self.version,
            registry_descriptor=MappingProxyType(self.to_canonical()),
            source_object_hash=source_hash,
            transformed_object_hash=transformed_hash,
            transformed=MappingProxyType(transformed),
        )
        verify_classification_evidence(execution.evidence())
        return execution


def verify_classification_evidence(evidence: Mapping[str, Any]) -> None:
    """Independently verify the evidence vocabulary supported by this release.

    This function deliberately consumes a plain mapping, just as the portable
    verifier does.  It does not trust ``classification_verified``; that field
    is an outcome to recompute, not an authorization input.
    """
    descriptor = evidence.get("transform_descriptor")
    proof = evidence.get("classification_proof")
    if not isinstance(descriptor, Mapping) or not isinstance(proof, Mapping):
        raise MigrationProofError("migration evidence omits transform descriptor or proof")
    transform_hash = content_hash(dict(descriptor))
    if evidence.get("transform_hash") != transform_hash:
        raise MigrationProofError("migration transform descriptor hash does not match")
    proof_hash = content_hash(dict(proof))
    if evidence.get("classification_proof_hash") != proof_hash:
        raise MigrationProofError("migration classification proof hash does not match")
    registry_descriptor = evidence.get("migration_registry_descriptor")
    if not isinstance(registry_descriptor, Mapping):
        raise MigrationProofError("migration evidence omits its registry descriptor")
    if content_hash(dict(registry_descriptor)) != evidence.get("migration_registry_version"):
        raise MigrationProofError("migration registry descriptor hash does not match")
    registered = registry_descriptor.get("transforms")
    if not isinstance(registered, list) or dict(descriptor) not in registered:
        raise MigrationProofError("migration transform is absent from its registry descriptor")
    if proof.get("proof_type") != _PROOF_TYPE or proof.get("verifier_id") != _PROOF_VERIFIER:
        raise MigrationProofError("unsupported migration classification proof profile")
    if proof.get("transform_id") != descriptor.get("transform_id"):
        raise MigrationProofError("classification proof names a different transform")
    if proof.get("transform_hash") != transform_hash:
        raise MigrationProofError("classification proof is not bound to the transform")
    if proof.get("migration_class") != descriptor.get("migration_class"):
        raise MigrationProofError("classification proof and transform disagree on semantic class")
    if proof.get("basis") != descriptor.get("classification_basis"):
        raise MigrationProofError("classification proof and transform disagree on their basis")
    if descriptor.get("algorithm") != IDENTITY_ALGORITHM:
        raise MigrationProofError("unsupported migration algorithm in classification evidence")
    if descriptor.get("source_schema_version") != descriptor.get("target_schema_version"):
        raise MigrationProofError("identity transform changes schema version")
    if descriptor.get("migration_class") != "SEMANTICALLY_EQUIVALENT":
        raise MigrationProofError("identity transform has a non-equivalent semantic class")
    if tuple(proof.get("checks") or ()) != _IDENTITY_CHECKS:
        raise MigrationProofError("identity classification proof has incomplete checks")
    if evidence.get("transform_input_hash") != evidence.get("transform_output_hash"):
        raise MigrationProofError("identity transform input and output hashes differ")
    if evidence.get("classification_verified") is not True:
        raise MigrationProofError("migration classification was not recorded as verified")


DEFAULT_MIGRATION_REGISTRY = MigrationRegistry(
    (
        MigrationTransform(
            transform_id="crg-schema-0.2.0-identity-v1",
            source_schema_version="0.2.0",
            target_schema_version="0.2.0",
            migration_class="SEMANTICALLY_EQUIVALENT",
            algorithm=IDENTITY_ALGORITHM,
            algorithm_version="1",
            description=(
                "Canonical identity copy for creating a successor object without changing "
                "the 0.2.0 schema payload"
            ),
            classification_basis=(
                "source and transformed canonical content have identical SHA-256 identities; "
                "the source and target schema versions are both 0.2.0"
            ),
        ),
    )
)
