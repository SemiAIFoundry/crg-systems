"""Exact and interval numerics for certificate-authorizing arithmetic.

Normative basis: master specification section 14.2 (numeric representations)
and section 22 (numeric, uncertainty, tie, and ambiguity semantics).

Three uncertainty concepts are kept structurally separate per 22.1:
  * numerical enclosure  -> Interval produced by arithmetic/solvers
  * evidence uncertainty -> Interval carried from measurement/model
  * policy tolerance     -> a scalar tau applied only at decision time
They are never silently merged; DecisionValue.combined() performs the
one explicit conservative merge and records that it did so.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from fractions import Fraction
from typing import Any, Optional, Union

__all__ = [
    "Exact",
    "Interval",
    "DecisionValue",
    "ArithmeticProfile",
    "SolverTrustProfile",
    "exact",
    # Specification 14.2 numeric-representation zoo (see the bottom of the file).
    "BoundedInterval",
    "OneSidedBound",
    "FiniteScenarioSet",
    "EmpiricalSampleSet",
    "NamedDistribution",
    "SymbolicExpression",
    "SemialgebraicConstraint",
    "BooleanCapabilityPredicate",
    "decode_representation",
    "REPRESENTATION_TYPES",
]

Number = Union[int, str, Fraction, "Exact"]


def _to_fraction(value: Number) -> Fraction:
    if isinstance(value, Exact):
        return value.value
    if isinstance(value, Fraction):
        return value
    if isinstance(value, int):
        return Fraction(value)
    if isinstance(value, str):
        return Fraction(value)
    if isinstance(value, float):
        raise TypeError(
            "float is not an admissible exact input; supply an integer, "
            "a decimal string, or a rational string such as '3/4'"
        )
    raise TypeError(f"cannot interpret {type(value)!r} as an exact number")


@dataclass(frozen=True, order=False)
class Exact:
    """An exact rational value with a canonical, hashable encoding."""

    value: Fraction

    def __init__(self, value: Number) -> None:
        object.__setattr__(self, "value", _to_fraction(value))

    # -- arithmetic ---------------------------------------------------
    def __add__(self, other: Number) -> "Exact":
        return Exact(self.value + _to_fraction(other))

    def __sub__(self, other: Number) -> "Exact":
        return Exact(self.value - _to_fraction(other))

    def __mul__(self, other: Number) -> "Exact":
        return Exact(self.value * _to_fraction(other))

    def __truediv__(self, other: Number) -> "Exact":
        return Exact(self.value / _to_fraction(other))

    __radd__ = __add__
    __rmul__ = __mul__

    def __neg__(self) -> "Exact":
        return Exact(-self.value)

    # -- comparison ---------------------------------------------------
    def __lt__(self, other: Number) -> bool:
        return self.value < _to_fraction(other)

    def __le__(self, other: Number) -> bool:
        return self.value <= _to_fraction(other)

    def __gt__(self, other: Number) -> bool:
        return self.value > _to_fraction(other)

    def __ge__(self, other: Number) -> bool:
        return self.value >= _to_fraction(other)

    def __eq__(self, other: Any) -> bool:
        try:
            return self.value == _to_fraction(other)
        except TypeError:
            return NotImplemented

    def __hash__(self) -> int:
        return hash(self.value)

    # -- canonical form -----------------------------------------------
    def to_canonical(self) -> dict:
        """Canonical encoding: integers stay integral, others are n/d strings."""
        if self.value.denominator == 1:
            return {"exact": str(self.value.numerator)}
        return {"exact": f"{self.value.numerator}/{self.value.denominator}"}

    @classmethod
    def from_canonical(cls, record: dict) -> "Exact":
        """Inverse of :meth:`to_canonical`; ``Fraction`` parses both forms."""
        if not isinstance(record, dict) or "exact" not in record:
            raise ValueError("canonical Exact record MUST carry an 'exact' field")
        return cls(record["exact"])

    def __repr__(self) -> str:  # pragma: no cover - display only
        return f"Exact({self.value})"

    def __str__(self) -> str:
        return str(self.value)


def exact(value: Number) -> Exact:
    return Exact(value)


@dataclass(frozen=True)
class Interval:
    """A closed exact interval [lo, hi] used as a numerical enclosure."""

    lo: Exact
    hi: Exact

    def __init__(self, lo: Number, hi: Optional[Number] = None) -> None:
        low = Exact(lo)
        high = Exact(hi) if hi is not None else low
        if high < low:
            raise ValueError(f"interval upper bound {high} below lower bound {low}")
        object.__setattr__(self, "lo", low)
        object.__setattr__(self, "hi", high)

    @property
    def is_degenerate(self) -> bool:
        return self.lo == self.hi

    @property
    def width(self) -> Exact:
        return self.hi - self.lo

    def __add__(self, other: "Interval") -> "Interval":
        other = _as_interval(other)
        return Interval(self.lo + other.lo, self.hi + other.hi)

    def __sub__(self, other: "Interval") -> "Interval":
        other = _as_interval(other)
        return Interval(self.lo - other.hi, self.hi - other.lo)

    def __mul__(self, other: "Interval") -> "Interval":
        other = _as_interval(other)
        products = [
            self.lo * other.lo,
            self.lo * other.hi,
            self.hi * other.lo,
            self.hi * other.hi,
        ]
        return Interval(min(products, key=lambda e: e.value), max(products, key=lambda e: e.value))

    __radd__ = __add__
    __rmul__ = __mul__

    def scale(self, factor: Number) -> "Interval":
        return self * Interval(factor, factor)

    def union(self, other: "Interval") -> "Interval":
        other = _as_interval(other)
        return Interval(
            min(self.lo, other.lo, key=lambda e: e.value),
            max(self.hi, other.hi, key=lambda e: e.value),
        )

    def overlaps(self, other: "Interval") -> bool:
        other = _as_interval(other)
        return not (self.hi < other.lo or other.hi < self.lo)

    def strictly_below(self, other: "Interval", tolerance: Optional[Number] = None) -> bool:
        """Specification 22.3: U_p + tau < L_q."""
        other = _as_interval(other)
        tau = Exact(tolerance) if tolerance is not None else Exact(0)
        return (self.hi + tau) < other.lo

    def to_canonical(self) -> dict:
        return {"lo": self.lo.to_canonical(), "hi": self.hi.to_canonical()}

    @classmethod
    def from_canonical(cls, record: dict) -> "Interval":
        """Inverse of :meth:`to_canonical` for the closed interval form."""
        return cls(Exact.from_canonical(record["lo"]), Exact.from_canonical(record["hi"]))

    def __repr__(self) -> str:  # pragma: no cover - display only
        if self.is_degenerate:
            return f"Interval({self.lo})"
        return f"Interval({self.lo}, {self.hi})"


def _as_interval(value: Union[Interval, Number]) -> Interval:
    if isinstance(value, Interval):
        return value
    return Interval(value, value)


class ArithmeticProfile:
    """Declared arithmetic regime for a computed value (spec 22.2)."""

    EXACT_RATIONAL = "EXACT_RATIONAL"
    INTERVAL_ENCLOSED = "INTERVAL_ENCLOSED"
    FLOAT_REPLAY_BOUND = "FLOAT_REPLAY_BOUND"
    UNBOUNDED_FLOAT = "UNBOUNDED_FLOAT"

    CERTIFYING = frozenset({EXACT_RATIONAL, INTERVAL_ENCLOSED})


class SolverTrustProfile:
    """Solver trust profiles (specification 23.2).

    The five profiles below are the complete, ordered (strongest to weakest)
    enumeration of 23.2.  Only ``PROOF_CHECKED`` and ``EXACT_RECOMPUTED`` may
    back a fully independently verified decision claim (23.4); together they
    form :data:`CERTIFYING`.  ``DETERMINISTIC_REPLAY`` may support only a
    replay-bound operational certificate that prominently declares solver
    identity, version, seed, and that optimality was not proved (23.5).
    ``DECLARED_NONDETERMINISTIC`` and ``HEURISTIC`` MUST remain distinguishable
    from exact values, certified bounds, and verified optima (23.6).

    This mirrors :class:`ArithmeticProfile`: a string-valued namespace rather
    than :class:`enum.Enum`, so the canonical wire form is the profile name and
    ``DecisionValue.solver_trust_profile`` stays a plain, hashable string.
    """

    PROOF_CHECKED = "PROOF_CHECKED"
    EXACT_RECOMPUTED = "EXACT_RECOMPUTED"
    DETERMINISTIC_REPLAY = "DETERMINISTIC_REPLAY"
    DECLARED_NONDETERMINISTIC = "DECLARED_NONDETERMINISTIC"
    HEURISTIC = "HEURISTIC"

    #: Specification 23.4: the only two profiles that authorize a strong claim.
    CERTIFYING = frozenset({PROOF_CHECKED, EXACT_RECOMPUTED})

    #: All five profiles, strongest to weakest, for enumeration and validation.
    ALL = (
        PROOF_CHECKED,
        EXACT_RECOMPUTED,
        DETERMINISTIC_REPLAY,
        DECLARED_NONDETERMINISTIC,
        HEURISTIC,
    )


@dataclass(frozen=True)
class DecisionValue:
    """A certificate-authorizing objective value (specification 22.2).

    ``numerical`` and ``evidence`` enclosures are stored separately and are
    merged only by :meth:`combined`, which records the merge explicitly.
    """

    coordinate: str
    unit: str
    numerical: Interval
    evidence: Optional[Interval] = None
    exact_value: Optional[Exact] = None
    arithmetic_profile: str = ArithmeticProfile.EXACT_RATIONAL
    solver_trust_profile: str = SolverTrustProfile.EXACT_RECOMPUTED
    policy_tolerance: Exact = field(default_factory=lambda: Exact(0))
    scope: Optional[str] = None
    dependencies: tuple = ()

    def combined(self) -> Interval:
        """Conservative merge of numerical and evidence enclosures."""
        if self.evidence is None:
            return self.numerical
        return Interval(
            min(self.numerical.lo, self.evidence.lo, key=lambda e: e.value),
            max(self.numerical.hi, self.evidence.hi, key=lambda e: e.value),
        )

    @property
    def can_authorize_certificate(self) -> bool:
        return (self.arithmetic_profile in ArithmeticProfile.CERTIFYING
                and self.solver_trust_profile in SolverTrustProfile.CERTIFYING)

    def to_canonical(self) -> dict:
        record = {
            "coordinate": self.coordinate,
            "unit": self.unit,
            "numerical_interval": self.numerical.to_canonical(),
            "combined_interval": self.combined().to_canonical(),
            "arithmetic_profile": self.arithmetic_profile,
            "solver_trust_profile": self.solver_trust_profile,
            "policy_tolerance": self.policy_tolerance.to_canonical(),
        }
        if self.evidence is not None:
            record["evidence_interval"] = self.evidence.to_canonical()
        if self.exact_value is not None:
            record["exact_value"] = self.exact_value.to_canonical()
        if self.scope is not None:
            record["scope"] = self.scope
        if self.dependencies:
            record["dependencies"] = list(self.dependencies)
        return record


# ===========================================================================
# Specification 14.2 numeric-representation zoo
# ===========================================================================
# 14.2 requires that "Canonical schemas MUST support" a fixed list of numeric
# representations.  The exact-arithmetic forms already live above:
#
#   * exact integer, rational, and canonical decimal  -> ``Exact`` (a decimal
#     string such as "0.25" parses to an exact rational, so canonical decimal
#     needs no separate type -- only an exact-rational carrier);
#   * closed interval                                 -> ``Interval``.
#
# The remaining forms are defined below.  Each is a frozen dataclass that
# (a) refuses binary floating point at construction, exactly as ``Exact`` does;
# (b) exposes ``to_canonical()`` producing a self-describing dict tagged with a
#     ``"kind"`` discriminator so distinct representations never collide under
#     14.3/14.4 hashing; and (c) exposes ``from_canonical()`` so the encoding
#     round-trips (``obj == decode_representation(obj.to_canonical())``).
#
# Support tiers -- 14.2 requires the schema to *support* (represent + hash)
# every form, not to implement full arithmetic on each:
#
#   exact arithmetic       Exact, Interval
#   ordered / enclosure    BoundedInterval, OneSidedBound   (membership tests,
#                          usable as enclosures/constraints; no scalar algebra)
#   representation-only    FiniteScenarioSet, EmpiricalSampleSet,
#                          NamedDistribution, SymbolicExpression,
#                          SemialgebraicConstraint, BooleanCapabilityPredicate
#                          (faithful canonical carriers for hashing/transport).


def _reject_float(value: Any, context: str) -> None:
    # ``bool`` is a subclass of ``int`` and is legitimate for capability
    # predicates; only genuine binary floats are refused here.
    if isinstance(value, float):
        raise TypeError(
            f"binary floating point is not admissible for {context}; supply an "
            "exact representation (integer, decimal string, or rational string)"
        )


@dataclass(frozen=True)
class BoundedInterval:
    """Open or half-open bounded interval (specification 14.2).

    The fully closed interval ``[lo, hi]`` is carried by :class:`Interval`;
    this type exists for the strictly-open and half-open cases 14.2 names
    explicitly -- ``(lo, hi)``, ``[lo, hi)``, ``(lo, hi]``.  At least one
    endpoint MUST therefore be open.
    """

    lo: Exact
    hi: Exact
    lower_closed: bool
    upper_closed: bool

    KIND = "bounded_interval"

    def __init__(self, lo: Number, hi: Number, lower_closed: bool, upper_closed: bool) -> None:
        low = Exact(lo)
        high = Exact(hi)
        if not isinstance(lower_closed, bool) or not isinstance(upper_closed, bool):
            raise TypeError("interval closure flags MUST be bool")
        if lower_closed and upper_closed:
            raise ValueError(
                "a fully closed interval MUST use Interval, not BoundedInterval"
            )
        if high < low:
            raise ValueError(f"interval upper bound {high} below lower bound {low}")
        if low == high:
            raise ValueError("a strictly open or half-open interval MUST be non-empty")
        object.__setattr__(self, "lo", low)
        object.__setattr__(self, "hi", high)
        object.__setattr__(self, "lower_closed", lower_closed)
        object.__setattr__(self, "upper_closed", upper_closed)

    def contains(self, value: Number) -> bool:
        v = Exact(value)
        lower_ok = (self.lo <= v) if self.lower_closed else (self.lo < v)
        upper_ok = (v <= self.hi) if self.upper_closed else (v < self.hi)
        return lower_ok and upper_ok

    def to_canonical(self) -> dict:
        return {
            "kind": self.KIND,
            "lo": self.lo.to_canonical(),
            "hi": self.hi.to_canonical(),
            "lower_closed": self.lower_closed,
            "upper_closed": self.upper_closed,
        }

    @classmethod
    def from_canonical(cls, record: dict) -> "BoundedInterval":
        return cls(
            Exact.from_canonical(record["lo"]),
            Exact.from_canonical(record["hi"]),
            record["lower_closed"],
            record["upper_closed"],
        )


@dataclass(frozen=True)
class OneSidedBound:
    """One-sided bound / half-line (specification 14.2).

    Represents ``[b, +inf)``, ``(b, +inf)``, ``(-inf, b]`` or ``(-inf, b)``
    depending on ``side`` (``"LOWER"`` means ``b <= x``; ``"UPPER"`` means
    ``x <= b``) and ``inclusive``.
    """

    bound: Exact
    side: str
    inclusive: bool

    KIND = "one_sided_bound"
    SIDES = ("LOWER", "UPPER")

    def __init__(self, bound: Number, side: str, inclusive: bool = True) -> None:
        if side not in self.SIDES:
            raise ValueError(f"side MUST be one of {self.SIDES}, got {side!r}")
        if not isinstance(inclusive, bool):
            raise TypeError("inclusive MUST be bool")
        object.__setattr__(self, "bound", Exact(bound))
        object.__setattr__(self, "side", side)
        object.__setattr__(self, "inclusive", inclusive)

    def contains(self, value: Number) -> bool:
        v = Exact(value)
        if self.side == "LOWER":
            return (self.bound <= v) if self.inclusive else (self.bound < v)
        return (v <= self.bound) if self.inclusive else (v < self.bound)

    def to_canonical(self) -> dict:
        return {
            "kind": self.KIND,
            "bound": self.bound.to_canonical(),
            "side": self.side,
            "inclusive": self.inclusive,
        }

    @classmethod
    def from_canonical(cls, record: dict) -> "OneSidedBound":
        return cls(Exact.from_canonical(record["bound"]), record["side"], record["inclusive"])


@dataclass(frozen=True)
class FiniteScenarioSet:
    """Finite scenario set (specification 14.2).

    A finite *set* of exact scenario values.  Order is not semantic (14.3), so
    values are deduplicated and sorted for the canonical form.
    """

    values: tuple

    KIND = "finite_scenario_set"

    def __init__(self, values) -> None:
        exact_values = [Exact(v) for v in values]  # refuses float per element
        unique = sorted(set(exact_values), key=lambda e: e.value)
        if not unique:
            raise ValueError("a finite scenario set MUST be non-empty")
        object.__setattr__(self, "values", tuple(unique))

    def __len__(self) -> int:
        return len(self.values)

    def __contains__(self, value: Number) -> bool:
        return Exact(value) in self.values

    def to_canonical(self) -> dict:
        return {"kind": self.KIND, "values": [v.to_canonical() for v in self.values]}

    @classmethod
    def from_canonical(cls, record: dict) -> "FiniteScenarioSet":
        return cls(Exact.from_canonical(v) for v in record["values"])


@dataclass(frozen=True)
class EmpiricalSampleSet:
    """Empirical sample set (specification 14.2).

    A *multiset* of exact observations: unlike :class:`FiniteScenarioSet`,
    duplicates are significant (they carry the empirical frequency).  Order is
    not semantic, so samples are sorted for the canonical form but never
    deduplicated.  Representation-only: it does not define scalar arithmetic.
    """

    samples: tuple

    KIND = "empirical_sample_set"

    def __init__(self, samples) -> None:
        exact_samples = [Exact(v) for v in samples]  # refuses float per element
        if not exact_samples:
            raise ValueError("an empirical sample set MUST be non-empty")
        object.__setattr__(
            self, "samples", tuple(sorted(exact_samples, key=lambda e: e.value))
        )

    def __len__(self) -> int:
        return len(self.samples)

    def to_canonical(self) -> dict:
        return {"kind": self.KIND, "samples": [v.to_canonical() for v in self.samples]}

    @classmethod
    def from_canonical(cls, record: dict) -> "EmpiricalSampleSet":
        return cls(Exact.from_canonical(v) for v in record["samples"])


@dataclass(frozen=True)
class NamedDistribution:
    """Named probability distribution (specification 14.2).

    A distribution family referenced by name with exact parameters (for
    example ``normal`` with ``mean`` and ``sd``).  Representation-only: it
    carries the parameters exactly for hashing and transport; sampling and
    density evaluation are out of scope for the canonical layer.
    """

    name: str
    parameters: tuple  # sorted tuple of (str, Exact) pairs, for frozen hashing

    KIND = "named_distribution"

    def __init__(self, name: str, parameters) -> None:
        if not isinstance(name, str) or not name:
            raise ValueError("distribution name MUST be a non-empty string")
        items = parameters.items() if isinstance(parameters, dict) else parameters
        cleaned = []
        for key, value in items:
            if not isinstance(key, str):
                raise TypeError("distribution parameter names MUST be strings")
            cleaned.append((key, Exact(value)))  # refuses float
        cleaned.sort(key=lambda kv: kv[0])
        object.__setattr__(self, "name", name)
        object.__setattr__(self, "parameters", tuple(cleaned))

    def parameter(self, key: str) -> Exact:
        for name, value in self.parameters:
            if name == key:
                return value
        raise KeyError(key)

    def to_canonical(self) -> dict:
        return {
            "kind": self.KIND,
            "name": self.name,
            "parameters": {k: v.to_canonical() for k, v in self.parameters},
        }

    @classmethod
    def from_canonical(cls, record: dict) -> "NamedDistribution":
        params = {k: Exact.from_canonical(v) for k, v in record["parameters"].items()}
        return cls(record["name"], params)


@dataclass(frozen=True)
class SymbolicExpression:
    """Symbolic expression (specification 14.2).

    A canonical expression string over declared free variables (for example
    ``"a*x + b"`` with variables ``("a", "b", "x")``).  Representation-only:
    the schema transports and hashes the expression; it does not evaluate it.
    """

    expression: str
    variables: tuple

    KIND = "symbolic_expression"

    def __init__(self, expression: str, variables=()) -> None:
        _reject_float(expression, "a symbolic expression")
        if not isinstance(expression, str) or not expression.strip():
            raise ValueError("symbolic expression MUST be a non-empty string")
        names = tuple(variables)
        for name in names:
            if not isinstance(name, str):
                raise TypeError("symbolic variable names MUST be strings")
        object.__setattr__(self, "expression", expression)
        object.__setattr__(self, "variables", tuple(sorted(set(names))))

    def to_canonical(self) -> dict:
        return {
            "kind": self.KIND,
            "expression": self.expression,
            "variables": list(self.variables),
        }

    @classmethod
    def from_canonical(cls, record: dict) -> "SymbolicExpression":
        return cls(record["expression"], record.get("variables", ()))


@dataclass(frozen=True)
class SemialgebraicConstraint:
    """Semialgebraic constraint (specification 14.2).

    A single atomic constraint ``polynomial(vars) <relation> 0`` where
    ``relation`` is one of ``==, !=, <=, <, >=, >``.  A semialgebraic *set* is
    a conjunction of such atoms, represented as several constraints.
    Representation-only.
    """

    polynomial: str
    relation: str
    variables: tuple

    KIND = "semialgebraic_constraint"
    RELATIONS = ("==", "!=", "<=", "<", ">=", ">")

    def __init__(self, polynomial: str, relation: str, variables=()) -> None:
        _reject_float(polynomial, "a semialgebraic polynomial")
        if not isinstance(polynomial, str) or not polynomial.strip():
            raise ValueError("semialgebraic polynomial MUST be a non-empty string")
        if relation not in self.RELATIONS:
            raise ValueError(f"relation MUST be one of {self.RELATIONS}, got {relation!r}")
        names = tuple(variables)
        for name in names:
            if not isinstance(name, str):
                raise TypeError("semialgebraic variable names MUST be strings")
        object.__setattr__(self, "polynomial", polynomial)
        object.__setattr__(self, "relation", relation)
        object.__setattr__(self, "variables", tuple(sorted(set(names))))

    def to_canonical(self) -> dict:
        return {
            "kind": self.KIND,
            "polynomial": self.polynomial,
            "relation": self.relation,
            "variables": list(self.variables),
        }

    @classmethod
    def from_canonical(cls, record: dict) -> "SemialgebraicConstraint":
        return cls(record["polynomial"], record["relation"], record.get("variables", ()))


@dataclass(frozen=True)
class BooleanCapabilityPredicate:
    """Boolean capability predicate (specification 14.2).

    A named capability flag carrying a strict boolean truth value.  ``value``
    MUST be a genuine ``bool``: ``0``/``1`` and ``0.0``/``1.0`` are refused, so
    a capability is never silently coerced from a float or an integer count.
    """

    predicate: str
    value: bool

    KIND = "boolean_capability_predicate"

    def __init__(self, predicate: str, value: bool) -> None:
        if not isinstance(predicate, str) or not predicate:
            raise ValueError("capability predicate name MUST be a non-empty string")
        if not isinstance(value, bool):
            raise TypeError("capability value MUST be a bool, not an int or float")
        object.__setattr__(self, "predicate", predicate)
        object.__setattr__(self, "value", value)

    def __bool__(self) -> bool:
        return self.value

    def to_canonical(self) -> dict:
        return {"kind": self.KIND, "predicate": self.predicate, "value": self.value}

    @classmethod
    def from_canonical(cls, record: dict) -> "BooleanCapabilityPredicate":
        return cls(record["predicate"], record["value"])


#: Discriminator -> representation class, for :func:`decode_representation`.
REPRESENTATION_TYPES = {
    cls.KIND: cls
    for cls in (
        BoundedInterval,
        OneSidedBound,
        FiniteScenarioSet,
        EmpiricalSampleSet,
        NamedDistribution,
        SymbolicExpression,
        SemialgebraicConstraint,
        BooleanCapabilityPredicate,
    )
}


def decode_representation(record: dict):
    """Reconstruct a 14.2 representation from its canonical dict.

    Dispatches on the ``"kind"`` discriminator produced by ``to_canonical``.
    ``Exact`` and ``Interval`` have their own ``from_canonical`` (their
    canonical form is untagged for backward compatibility).
    """
    if not isinstance(record, dict) or "kind" not in record:
        raise ValueError("canonical representation MUST carry a 'kind' discriminator")
    kind = record["kind"]
    cls = REPRESENTATION_TYPES.get(kind)
    if cls is None:
        raise ValueError(f"unknown numeric representation kind {kind!r}")
    return cls.from_canonical(record)
