"""Common object envelope, evidence classes, and lifecycle status.

Normative basis: master specification section 5.3 (evidence classes),
section 11.2 (case lifecycle), section 12 (common object envelope).
"""
from __future__ import annotations

import datetime as _dt
import secrets
import time
import uuid
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, Optional, Sequence, Tuple

from .canonical import content_hash

__all__ = [
    "EvidenceClass",
    "ObjectStatus",
    "CaseStatus",
    "Envelope",
    "CRGObject",
    "new_object_id",
    "utc_now",
]


class EvidenceClass:
    """Specification 5.3.  These MUST remain distinct."""

    EXACT = "EXACT"
    CONSTRUCTIVE = "CONSTRUCTIVE"
    BOUNDED = "BOUNDED"
    MEASURED = "MEASURED"
    MODELED = "MODELED"
    IMPORTED = "IMPORTED"
    DECLARED = "DECLARED"
    HEURISTIC = "HEURISTIC"

    ALL = frozenset(
        {EXACT, CONSTRUCTIVE, BOUNDED, MEASURED, MODELED, IMPORTED, DECLARED, HEURISTIC}
    )
    #: A heuristic may rank or propose; it may never authorize (spec 5.3).
    AUTHORIZING = frozenset({EXACT, CONSTRUCTIVE, BOUNDED, MEASURED, MODELED, IMPORTED, DECLARED})

    @classmethod
    def may_authorize(cls, value: str) -> bool:
        return value in cls.AUTHORIZING


class ObjectStatus:
    ACTIVE = "ACTIVE"
    SUPERSEDED = "SUPERSEDED"
    EXPIRED = "EXPIRED"
    STALE = "STALE"
    INVALID = "INVALID"
    REVOKED = "REVOKED"
    REDACTED = "REDACTED"
    CRYPTOGRAPHICALLY_ERASED = "CRYPTOGRAPHICALLY_ERASED"
    LEGALLY_DELETED = "LEGALLY_DELETED"
    UNAVAILABLE = "UNAVAILABLE"
    UNVERIFIABLE_REDACTED = "UNVERIFIABLE_REDACTED"

    ALL = frozenset(
        {ACTIVE, SUPERSEDED, EXPIRED, STALE, INVALID, REVOKED, REDACTED,
         CRYPTOGRAPHICALLY_ERASED, LEGALLY_DELETED, UNAVAILABLE,
         UNVERIFIABLE_REDACTED}
    )


class CaseStatus:
    DRAFT = "DRAFT"
    VALIDATED = "VALIDATED"
    GENERATED = "GENERATED"
    EVALUATED = "EVALUATED"
    CERTIFIED = "CERTIFIED"
    COMMITTED = "COMMITTED"
    STALE = "STALE"
    REOPENED = "REOPENED"
    BLOCKED = "BLOCKED"
    ARCHIVED = "ARCHIVED"
    REVOKED = "REVOKED"


def new_object_id(
    prefix: str = "obj", *, timestamp_ms: Optional[int] = None,
    entropy: Optional[bytes] = None,
) -> str:
    """Return a sortable UUIDv7-equivalent local identifier (spec 14.1).

    ``timestamp_ms`` and ``entropy`` are explicit inputs for deterministic
    regeneration and golden vectors.  Production callers omit them and get
    the current Unix millisecond plus cryptographic randomness.  Making those
    inputs injectable resolves the specification's otherwise contradictory
    requirements for time-bearing IDs and byte-identical regeneration.
    """
    timestamp_ms = int(time.time_ns() // 1_000_000 if timestamp_ms is None else timestamp_ms)
    if not 0 <= timestamp_ms < (1 << 48):
        raise ValueError("a UUIDv7 timestamp must fit in 48 unsigned bits")
    entropy = secrets.token_bytes(10) if entropy is None else bytes(entropy)
    if len(entropy) != 10:
        raise ValueError("UUIDv7 entropy must contain exactly 10 bytes")
    random_74 = int.from_bytes(entropy, "big") & ((1 << 74) - 1)
    random_a = random_74 >> 62
    random_b = random_74 & ((1 << 62) - 1)
    value = (
        (timestamp_ms << 80)
        | (0x7 << 76)
        | (random_a << 64)
        | (0b10 << 62)
        | random_b
    )
    return f"{prefix}-{uuid.UUID(int=value)}"


def utc_now() -> str:
    return _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


@dataclass
class Envelope:
    """Specification 12: fields every canonical object MUST carry."""

    object_id: str
    object_type: str
    schema_version: str = "0.2.0"
    object_version: int = 1
    content_hash: Optional[str] = None
    parent_hashes: Tuple[str, ...] = ()
    created_at: str = field(default_factory=utc_now)
    created_by: str = "crg"
    status: str = ObjectStatus.ACTIVE
    evidence_class: str = EvidenceClass.EXACT
    access_policy: str = "private"
    dependencies: Tuple[str, ...] = ()
    extensions: Dict[str, Any] = field(default_factory=dict)

    def to_canonical(self, *, include_content_hash: bool = True) -> dict:
        record = {
            "object_id": self.object_id,
            "object_type": self.object_type,
            "schema_version": self.schema_version,
            "object_version": self.object_version,
            "created_at": self.created_at,
            "created_by": self.created_by,
            "status": self.status,
            "evidence_class": self.evidence_class,
            "access_policy": self.access_policy,
        }
        if self.parent_hashes:
            record["parent_hashes"] = list(self.parent_hashes)
        if include_content_hash and self.content_hash is not None:
            record["content_hash"] = self.content_hash
        if self.dependencies:
            record["dependencies"] = list(self.dependencies)
        if self.extensions:
            record["extensions"] = self.extensions
        return record


@dataclass
class CRGObject:
    """Base for every canonical CRG record.

    ``content_hash`` is computed over the envelope plus the body, with the
    hash field itself excluded, so the hash is stable and self-consistent.
    """

    envelope: Envelope

    def body(self) -> dict:
        raise NotImplementedError

    def to_canonical(self) -> dict:
        record = dict(self.envelope.to_canonical())
        record["body"] = self.body()
        return record

    def compute_hash(self) -> str:
        record = dict(self.envelope.to_canonical(include_content_hash=False))
        record["body"] = self.body()
        return content_hash(record)

    def freeze(self) -> "CRGObject":
        """Compute and pin the content hash (spec 6.4 immutable provenance)."""
        self.envelope.content_hash = self.compute_hash()
        return self

    def verify_hash(self) -> bool:
        if self.envelope.content_hash is None:
            return False
        return self.envelope.content_hash == self.compute_hash()
