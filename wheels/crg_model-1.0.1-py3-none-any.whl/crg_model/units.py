"""Governed quantity and unit registry.

Normative basis: master specification section 13 (quantity and unit registry).
This module is the reference implementation of the 13.1 governing rule that
"quantity identity is part of certificate semantics and canonical hashing", so
domain packs MUST NOT mint ungoverned quantity strings and assume global
meaning.

Design constraints, matching the rest of ``crg-model``:

  * stdlib only, Python 3.10, frozen dataclasses;
  * every conversion factor is an exact rational (:class:`crg_model.numeric.Exact`)
    -- a binary ``float`` factor is refused at construction (14.2);
  * a unit mismatch blocks arithmetic across quantities (13.3), and combining
    two coordinates of the *same* quantity in different units requires an
    explicit :meth:`QuantityRegistry.convert` call;
  * currency is its own quantity with no cross-quantity conversion, so there is
    no implicit foreign-exchange path (13.5);
  * offset (affine) units such as degree Celsius are marked as such, and the
    ratio-only :meth:`QuantityRegistry.convert` refuses them with a clear
    message rather than silently applying a ratio; absolute-point conversion is
    available, opt-in, through :meth:`QuantityRegistry.convert_absolute`.

The registry is *versioned* by a content hash of the registered set (13.6), so
the version string changes whenever the set of quantities or units changes.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

from .canonical import content_hash
from .numeric import Exact, Number

__all__ = [
    "Dimension",
    "QuantityDefinition",
    "UnitDefinition",
    "QuantityRegistry",
    "DEFAULT_REGISTRY",
    "UnitRegistryError",
    "UnknownQuantity",
    "UnknownUnit",
    "CrossQuantityConversion",
    "UnitRedefinitionError",
    "OffsetUnitError",
    "validate_coordinate_units",
    "units_compatible",
    "guard_combination",
]

CORE_NAMESPACE = "crg-spec.core"  # 13.6: crg-spec maintains the core registry.


class Dimension:
    """Physical or abstract dimensions used by the core profile (13.2)."""

    TIME = "TIME"
    INFORMATION = "INFORMATION"
    ENERGY = "ENERGY"
    POWER = "POWER"
    CURRENCY = "CURRENCY"
    AREA = "AREA"
    LENGTH = "LENGTH"
    TEMPERATURE = "TEMPERATURE"
    DIMENSIONLESS = "DIMENSIONLESS"


# ---------------------------------------------------------------------------
# errors
# ---------------------------------------------------------------------------


class UnitRegistryError(Exception):
    """Base class for all quantity/unit registry errors."""


class UnknownQuantity(UnitRegistryError, KeyError):
    """A quantity id was referenced but is not registered."""


class UnknownUnit(UnitRegistryError, KeyError):
    """A unit symbol was referenced but is not registered."""


class CrossQuantityConversion(UnitRegistryError):
    """A conversion or combination was attempted across two quantities (13.3).

    This also covers 13.5: currency is its own quantity, so a cross-currency or
    currency-to-physical conversion lands here -- there is no implicit FX.
    """


class UnitRedefinitionError(UnitRegistryError):
    """A quantity or unit was re-registered with a different definition (13.6).

    In particular, a unit's quantity is fixed: re-registering an existing
    symbol against a different quantity is refused.
    """


class OffsetUnitError(UnitRegistryError):
    """A ratio conversion was attempted on an offset (affine) unit (13.2/13.3).

    Offset units such as degree Celsius carry an additive zero point; a naive
    ratio conversion would be wrong.  Use :meth:`QuantityRegistry.convert_absolute`
    for absolute-point conversion, and model temperature *differences* as their
    own quantity.
    """


# ---------------------------------------------------------------------------
# definitions
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class QuantityDefinition:
    """A governed quantity (specification 13.2).

    Section 13.2's identity and interpretation fields are all present in the
    canonical record.  Fields that do not apply to a particular quantity use
    explicit conservative values rather than disappearing from its identity.
    """

    quantity_id: str
    dimension: str
    canonical_unit: str
    allowed_units: Tuple[str, ...]
    namespace: str = CORE_NAMESPACE
    name: str = ""
    definition: str = ""
    direction: Optional[str] = None          # optimization direction, 13.2
    aggregation: str = "NONE"                 # aggregation behavior, 13.2
    accounting_scope: Optional[str] = None    # accounting scope, 13.2
    concurrency_semantics: str = "DECLARED_BY_COORDINATE"
    uncertainty_semantics: str = "EXACT_OR_DECLARED_ENCLOSURE"
    compatibility_relations: Tuple[str, ...] = ()
    definition_version: str = "1"
    currency_basis: Optional[str] = None      # currency/valuation basis, 13.5
    probability_interpretation: Optional[str] = None  # 13.2, where applicable
    offset_scale: bool = False                # affine scale (e.g. temperature)
    deprecation_state: str = "ACTIVE"         # 13.2 deprecation state

    def __post_init__(self) -> None:
        if not self.quantity_id:
            raise ValueError("quantity_id MUST be a non-empty string")
        object.__setattr__(self, "allowed_units", tuple(self.allowed_units))
        object.__setattr__(self, "compatibility_relations",
                           tuple(self.compatibility_relations))
        if self.canonical_unit not in self.allowed_units:
            raise ValueError(
                f"canonical unit {self.canonical_unit!r} MUST appear in allowed_units"
            )

    def to_canonical(self) -> dict:
        record = {
            "quantity_id": self.quantity_id,
            "namespace": self.namespace,
            "dimension": self.dimension,
            "canonical_unit": self.canonical_unit,
            "allowed_units": list(self.allowed_units),
            "aggregation": self.aggregation,
            "concurrency_semantics": self.concurrency_semantics,
            "uncertainty_semantics": self.uncertainty_semantics,
            "compatibility_relations": list(self.compatibility_relations),
            "definition_version": self.definition_version,
            "offset_scale": self.offset_scale,
            "deprecation_state": self.deprecation_state,
        }
        for key, value in (
            ("name", self.name),
            ("definition", self.definition),
            ("direction", self.direction),
            ("accounting_scope", self.accounting_scope),
            ("currency_basis", self.currency_basis),
            ("probability_interpretation", self.probability_interpretation),
        ):
            if value:
                record[key] = value
        return record


@dataclass(frozen=True)
class UnitDefinition:
    """A UCUM-compatible unit (specification 13.3).

    ``factor`` is the exact multiplier that takes a value expressed in this unit
    to the quantity's canonical unit: ``canonical = value * factor``.  It MUST
    be exact; a binary ``float`` is refused at construction.

    ``offset`` is an optional additive zero-point for affine scales such as
    degree Celsius, where ``canonical = value * factor + offset``.  A unit whose
    offset is non-zero is an *offset unit* and MUST NOT be ratio-converted.
    """

    symbol: str
    quantity_id: str
    factor: Exact
    offset: Optional[Exact] = None
    name: str = ""

    def __post_init__(self) -> None:
        if not self.symbol:
            raise ValueError("unit symbol MUST be a non-empty string")
        # Coercion through Exact() refuses float and normalizes int/str inputs.
        object.__setattr__(self, "factor", Exact(self.factor))
        if self.factor == Exact(0):
            raise ValueError("unit factor MUST be non-zero")
        if self.offset is not None:
            object.__setattr__(self, "offset", Exact(self.offset))

    @property
    def is_offset(self) -> bool:
        """True iff this unit carries a non-zero affine zero point (13.2)."""
        return self.offset is not None and self.offset != Exact(0)

    def to_canonical(self) -> dict:
        record = {
            "symbol": self.symbol,
            "quantity_id": self.quantity_id,
            "factor": self.factor.to_canonical(),
        }
        if self.offset is not None:
            record["offset"] = self.offset.to_canonical()
        if self.name:
            record["name"] = self.name
        return record


# ---------------------------------------------------------------------------
# registry
# ---------------------------------------------------------------------------


class QuantityRegistry:
    """A governed set of quantities and units (specification 13).

    Registration is idempotent for identical definitions and refuses a
    conflicting redefinition (13.6).  The :meth:`version` string is a content
    hash of the registered set, so it changes whenever the set changes.
    """

    def __init__(self) -> None:
        self._quantities: Dict[str, QuantityDefinition] = {}
        self._units: Dict[str, UnitDefinition] = {}

    # -- registration ----------------------------------------------------

    def register_quantity(self, q: QuantityDefinition) -> None:
        existing = self._quantities.get(q.quantity_id)
        if existing is not None and existing != q:
            raise UnitRedefinitionError(
                f"quantity {q.quantity_id!r} is already registered with a "
                "different definition; a semantic modification MUST follow the "
                "version and migration discipline of 13.6"
            )
        self._quantities[q.quantity_id] = q

    def register_unit(self, u: UnitDefinition) -> None:
        if u.quantity_id not in self._quantities:
            raise UnknownQuantity(
                f"unit {u.symbol!r} references unregistered quantity "
                f"{u.quantity_id!r}; register the quantity first"
            )
        existing = self._units.get(u.symbol)
        if existing is not None and existing != u:
            if existing.quantity_id != u.quantity_id:
                raise UnitRedefinitionError(
                    f"unit symbol {u.symbol!r} is fixed to quantity "
                    f"{existing.quantity_id!r}; it cannot be re-registered against "
                    f"quantity {u.quantity_id!r} (13.6)"
                )
            raise UnitRedefinitionError(
                f"unit symbol {u.symbol!r} is already registered with a different "
                "definition (13.6)"
            )
        self._units[u.symbol] = u

    # -- lookup ----------------------------------------------------------

    def quantity(self, quantity_id: str) -> QuantityDefinition:
        try:
            return self._quantities[quantity_id]
        except KeyError:
            raise UnknownQuantity(f"quantity {quantity_id!r} is not registered")

    def unit(self, symbol: str) -> UnitDefinition:
        try:
            return self._units[symbol]
        except KeyError:
            raise UnknownUnit(f"unit {symbol!r} is not registered")

    def has_quantity(self, quantity_id: str) -> bool:
        return quantity_id in self._quantities

    def has_unit(self, symbol: str) -> bool:
        return symbol in self._units

    def quantities(self) -> Tuple[QuantityDefinition, ...]:
        return tuple(self._quantities[k] for k in sorted(self._quantities))

    def units(self) -> Tuple[UnitDefinition, ...]:
        return tuple(self._units[k] for k in sorted(self._units))

    # -- conversion ------------------------------------------------------

    def compatible(self, unit_a: str, unit_b: str) -> bool:
        """True iff both units are registered and measure the same quantity."""
        ua = self._units.get(unit_a)
        ub = self._units.get(unit_b)
        if ua is None or ub is None:
            return False
        return ua.quantity_id == ub.quantity_id

    def convert(self, value: Number, from_unit: str, to_unit: str) -> Exact:
        """Exact ratio conversion within one quantity (13.3).

        Raises :class:`CrossQuantityConversion` across quantities (including any
        currency pair, 13.5) and :class:`OffsetUnitError` for offset units,
        which must go through :meth:`convert_absolute`.  ``value`` is coerced
        through :class:`Exact`, so a ``float`` value is refused.
        """
        fu = self.unit(from_unit)
        tu = self.unit(to_unit)
        if fu.quantity_id != tu.quantity_id:
            raise CrossQuantityConversion(
                f"cannot convert {from_unit!r} ({fu.quantity_id}) to {to_unit!r} "
                f"({tu.quantity_id}): arithmetic across distinct quantities is "
                "blocked (13.3); currencies have no implicit conversion (13.5)"
            )
        if fu.is_offset or tu.is_offset:
            raise OffsetUnitError(
                f"{from_unit!r} or {to_unit!r} is an offset (affine) unit; a ratio "
                "conversion would be wrong. Use convert_absolute() for an absolute "
                "point, and model differences as their own quantity"
            )
        return Exact(value) * fu.factor / tu.factor

    def convert_absolute(self, value: Number, from_unit: str, to_unit: str) -> Exact:
        """Exact affine conversion of an absolute point within one quantity.

        Handles offset units: ``canonical = value * factor + offset`` then the
        inverse into the target unit.  For pure ratio units (offset zero) this
        coincides with :meth:`convert`.  This is the opt-in path for degC<->K
        style conversions; it operates only on absolute points, never on
        differences.
        """
        fu = self.unit(from_unit)
        tu = self.unit(to_unit)
        if fu.quantity_id != tu.quantity_id:
            raise CrossQuantityConversion(
                f"cannot convert {from_unit!r} ({fu.quantity_id}) to {to_unit!r} "
                f"({tu.quantity_id}): distinct quantities (13.3)"
            )
        f_offset = fu.offset if fu.offset is not None else Exact(0)
        t_offset = tu.offset if tu.offset is not None else Exact(0)
        canonical = Exact(value) * fu.factor + f_offset
        return (canonical - t_offset) / tu.factor

    # -- governance ------------------------------------------------------

    def version(self) -> str:
        """Content hash of the registered set (13.6).

        Any addition or semantic modification of a quantity or unit changes the
        canonical serialization and therefore this string.
        """
        payload = {
            "namespace": CORE_NAMESPACE,
            "quantities": [q.to_canonical() for q in self.quantities()],
            "units": [u.to_canonical() for u in self.units()],
        }
        return content_hash(payload)

    def copy(self) -> "QuantityRegistry":
        """A shallow copy; definitions are immutable, so this is a safe fork."""
        clone = QuantityRegistry()
        clone._quantities = dict(self._quantities)
        clone._units = dict(self._units)
        return clone


# ---------------------------------------------------------------------------
# default core registry (UCUM-compatible)
# ---------------------------------------------------------------------------


def _build_default_registry() -> QuantityRegistry:
    reg = QuantityRegistry()

    def q(quantity_id, dimension, canonical_unit, allowed, **kw):
        reg.register_quantity(
            QuantityDefinition(
                quantity_id=quantity_id,
                dimension=dimension,
                canonical_unit=canonical_unit,
                allowed_units=tuple(allowed),
                **kw,
            )
        )

    def u(symbol, quantity_id, factor, offset=None, name=""):
        reg.register_unit(
            UnitDefinition(
                symbol=symbol,
                quantity_id=quantity_id,
                factor=Exact(factor),
                offset=None if offset is None else Exact(offset),
                name=name,
            )
        )

    # time -- canonical second, exact sub-second ratios
    q("time", Dimension.TIME, "s", ("s", "ms", "us", "ns"),
      name="time", definition="elapsed physical time", aggregation="SUM")
    u("s", "time", 1, name="second")
    u("ms", "time", "1/1000", name="millisecond")
    u("us", "time", "1/1000000", name="microsecond")
    u("ns", "time", "1/1000000000", name="nanosecond")

    # information -- canonical bit; IEC binary multiples are exact powers of two.
    # (SI decimal multiples such as kB=1000 byte are a *different* scale and are
    # deliberately not aliased onto the binary symbols.)
    q("information", Dimension.INFORMATION, "bit", ("bit", "byte", "KiB", "MiB", "GiB"),
      name="information", definition="quantity of information", aggregation="SUM")
    u("bit", "information", 1, name="bit")
    u("byte", "information", 8, name="byte (octet)")
    u("KiB", "information", 8 * 1024, name="kibibyte")
    u("MiB", "information", 8 * 1024 ** 2, name="mebibyte")
    u("GiB", "information", 8 * 1024 ** 3, name="gibibyte")

    # energy -- canonical joule
    q("energy", Dimension.ENERGY, "J", ("J", "mJ", "uJ", "pJ"),
      name="energy", definition="energy", aggregation="SUM")
    u("J", "energy", 1, name="joule")
    u("mJ", "energy", "1/1000", name="millijoule")
    u("uJ", "energy", "1/1000000", name="microjoule")
    u("pJ", "energy", "1/1000000000000", name="picojoule")

    # power -- canonical watt
    q("power", Dimension.POWER, "W", ("W", "mW"),
      name="power", definition="power", aggregation="NONE")
    u("W", "power", 1, name="watt")
    u("mW", "power", "1/1000", name="milliwatt")

    # currency -- its own quantity, no implicit FX (13.5)
    q("currency_usd", Dimension.CURRENCY, "USD", ("USD",),
      name="US dollar", definition="US dollar currency amount",
      aggregation="SUM", currency_basis="USD nominal")
    u("USD", "currency_usd", 1, name="US dollar")

    # area -- canonical square millimetre
    q("area", Dimension.AREA, "mm2", ("mm2", "m2"),
      name="area", definition="area", aggregation="SUM")
    u("mm2", "area", 1, name="square millimetre")
    u("m2", "area", 1000000, name="square metre")  # 1 m2 = 1e6 mm2, exact

    # length -- canonical millimetre
    q("length", Dimension.LENGTH, "mm", ("mm", "um", "nm"),
      name="length", definition="length", aggregation="NONE")
    u("mm", "length", 1, name="millimetre")
    u("um", "length", "1/1000", name="micrometre")
    u("nm", "length", "1/1000000", name="nanometre")

    # temperature -- affine scale.  Canonical kelvin (a ratio scale); degree
    # Celsius is an OFFSET unit and must not be ratio-converted (13.2/13.3).
    # 273.15 is carried exactly as 27315/100.
    q("temperature", Dimension.TEMPERATURE, "K", ("K", "degC"),
      name="temperature", definition="thermodynamic temperature (absolute)",
      aggregation="NONE", offset_scale=True)
    u("K", "temperature", 1, offset=0, name="kelvin")
    u("degC", "temperature", 1, offset="27315/100", name="degree Celsius")

    # dimensionless -- generic normalized number.  The named 13.4 quantities
    # below remain distinct and are not interchangeable with this carrier.
    q("dimensionless", Dimension.DIMENSIONLESS, "1", ("1", "ratio", "percent"),
      name="dimensionless", definition="generic normalized number",
      aggregation="NONE")
    u("1", "dimensionless", 1, name="one")
    u("ratio", "dimensionless", 1, name="ratio (unit-one synonym)")
    u("percent", "dimensionless", "1/100", name="percent")

    # 13.4: these are intentionally distinct quantities even though each is
    # dimensionless.  Their annotated unit symbols prevent the global unit map
    # from accidentally making them interchangeable through the generic `1`.
    for quantity_id, definition, interpretation in (
        ("yield", "successful output divided by attempted output", "FREQUENCY_RATIO"),
        ("probability", "probability measure on a declared event space", "PROBABILITY"),
        ("utilization", "used capacity divided by declared available capacity", "RATIO"),
        ("reliability", "probability of satisfying a declared service condition", "PROBABILITY"),
        ("normalized_score", "dimensionless score under a named normalization", "SCORE"),
        ("compression_ratio", "uncompressed extent divided by compressed extent", "RATIO"),
    ):
        symbol = "{" + quantity_id + "}"
        q(quantity_id, Dimension.DIMENSIONLESS, symbol, (symbol,),
          name=quantity_id.replace("_", " "), definition=definition,
          aggregation="NONE", probability_interpretation=interpretation)
        u(symbol, quantity_id, 1, name=quantity_id.replace("_", " "))

    # Differences on an affine temperature scale are ratios and must never be
    # confused with absolute temperature points (13.2-13.3).
    q("temperature_difference", Dimension.TEMPERATURE, "K_delta", ("K_delta", "degC_delta"),
      name="temperature difference", definition="difference between two temperatures",
      aggregation="SUM")
    u("K_delta", "temperature_difference", 1, name="kelvin difference")
    u("degC_delta", "temperature_difference", 1, name="degree Celsius difference")

    return reg


#: The pre-populated core registry (13.6).  Treat as read-only; use ``.copy()``
#: to derive an extended registry without mutating the shared default.
DEFAULT_REGISTRY = _build_default_registry()


# ---------------------------------------------------------------------------
# coordinate integration (opt-in)
# ---------------------------------------------------------------------------


def validate_coordinate_units(schema, registry: QuantityRegistry = DEFAULT_REGISTRY) -> List[str]:
    """Return unit-governance violations for a coordinate schema (opt-in).

    This is the non-breaking integration hook for 13.1/13.3: existing schemas
    use free-form ``quantity``/``unit`` strings, so this validator *returns* a
    list of human-readable violations rather than raising, leaving free-form
    usage intact.  A coordinate is flagged when its unit is not registered, or
    when its declared quantity is a governed quantity id that the unit does not
    belong to.  An empty list means every coordinate is unit-governed.
    """
    violations: List[str] = []
    for coord in schema.coordinates:
        if not registry.has_unit(coord.unit):
            violations.append(
                f"coordinate {coord.identifier!r}: unit {coord.unit!r} is not "
                "registered in the governed registry"
            )
            continue
        unit = registry.unit(coord.unit)
        if registry.has_quantity(coord.quantity) and unit.quantity_id != coord.quantity:
            violations.append(
                f"coordinate {coord.identifier!r}: unit {coord.unit!r} measures "
                f"{unit.quantity_id!r}, not the declared quantity {coord.quantity!r}"
            )
    return violations


def units_compatible(coord_a, coord_b, registry: QuantityRegistry = DEFAULT_REGISTRY) -> bool:
    """True iff two coordinates' units are compatible for combination (13.3)."""
    return registry.compatible(coord_a.unit, coord_b.unit)


def guard_combination(coord_a, coord_b, registry: QuantityRegistry = DEFAULT_REGISTRY) -> None:
    """Raise unless two coordinates may be combined arithmetically (13.3).

    Enforcement primitive for "a unit mismatch MUST block arithmetic": raises
    :class:`UnknownUnit` if either unit is ungoverned and
    :class:`CrossQuantityConversion` if the two units measure different
    quantities.  Same-quantity coordinates in different units are permitted, but
    the caller MUST first align them with :meth:`QuantityRegistry.convert`.
    """
    ua = registry.unit(coord_a.unit)
    ub = registry.unit(coord_b.unit)
    if ua.quantity_id != ub.quantity_id:
        raise CrossQuantityConversion(
            f"coordinates {coord_a.identifier!r} ({ua.quantity_id}) and "
            f"{coord_b.identifier!r} ({ub.quantity_id}) measure different "
            "quantities; their combination is blocked (13.3)"
        )
