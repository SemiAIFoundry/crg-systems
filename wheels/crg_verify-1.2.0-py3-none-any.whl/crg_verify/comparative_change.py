"""Independent verifier for v1.2 comparative certified-change evidence.

Only the Python standard library and sibling verifier implementations are
used.  The embedded ``CertifiedDeltaRecord`` is replayed from its exact
before/after cases, dependency edges, replacements, and optional phase
evidence; no producer conclusion is trusted.
"""
from __future__ import annotations

from typing import Any, Mapping

from .canonical import CanonicalError, content_hash, hash_without, is_hash
from .certificate import Status, VerificationResult
from .phase_delta import verify_certified_delta_record

__all__ = ["verify_comparative_change_evidence"]


SCHEMA_VERSION = "1.2.0"
PROFILE = "crg-comparative-change/certified-delta@1"
FIRST_RELEASE = "v1.2/CERTIFIED_PHASE_AND_TYPED_CHANGE"
AUTHORITY = "NON_AUTHORIZING"
CLAIM_BOUNDARY = (
    "Scoped certified-change facts only. Artifact identity counts do not measure "
    "time, effort, cost, avoided work, business savings, ROI, superiority, or an "
    "unexecuted counterfactual, and this record cannot authorize case state."
)

_REQUIRED_INPUTS = frozenset(
    {"prior_case", "current_case", "dependency_edges", "replacements"}
)
_OPTIONAL_INPUTS = frozenset(
    {
        "prior_phase",
        "current_phase",
        "prior_phase_source_r",
        "current_phase_source_r",
    }
)
_TOP_LEVEL_FIELDS = frozenset(
    {
        "record_type",
        "schema_version",
        "profile",
        "first_release_attribution",
        "comparison_id",
        "authority",
        "authorizing",
        "semantic_effect",
        "evidence_class",
        "claim_boundary",
        "scope",
        "certified_delta_binding",
        "work_denominator",
        "system_derived_facts",
        "conclusion",
        "limitations",
        "record_hash",
    }
)
_BINDING_FIELDS = frozenset(
    {
        "certified_delta",
        "verification_inputs",
        "independent_verification",
        "certified_delta_hash",
        "verification_inputs_hash",
        "independent_verification_hash",
        "binding_hash",
    }
)
_SCOPE_FIELDS = frozenset(
    {
        "case_id",
        "event_id",
        "prior_case_root",
        "current_case_root",
        "decision_scope",
        "evidence_scope",
        "change_scope",
        "scope_hash",
    }
)
_FORBIDDEN_FACT_KEYS = frozenset(
    {
        "roi",
        "return_on_investment",
        "savings",
        "superiority",
        "generalization",
        "avoided_work",
        "avoided_recomputation",
        "avoided_effort",
        "cost_reduction",
        "time_reduction",
        "winner_method",
        "method_ranking",
    }
)


def _identity(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value.strip() or value != value.strip():
        raise ValueError(f"{field} must be a normalized non-empty string")
    return value


def _object(value: Any, field: str) -> dict:
    if not isinstance(value, Mapping):
        raise ValueError(f"{field} must be an object")
    return dict(value)


def _ids(value: Any, field: str) -> list[str]:
    if not isinstance(value, list):
        raise ValueError(f"{field} must be a list")
    result = [_identity(item, field) for item in value]
    if len(result) != len(set(result)) or result != sorted(result):
        raise ValueError(f"{field} must contain unique canonically ordered identities")
    return result


def _exact_count(value: int) -> dict:
    return {"exact": str(value)}


def _sealed(value: Mapping[str, Any], key: str) -> tuple[bool, str]:
    stated = value.get(key)
    if not is_hash(stated):
        return False, f"{key} is not a portable SHA-256 hash"
    try:
        actual = hash_without(dict(value), key)
    except (CanonicalError, TypeError, ValueError) as error:
        return False, f"{key} cannot be reconstructed: {error}"
    return stated == actual, f"stated {stated}; reconstructed {actual}"


def _forbidden_paths(value: Any, path: str) -> list[str]:
    failures: list[str] = []
    if isinstance(value, dict):
        for key, item in value.items():
            normalized = str(key).strip().lower().replace("-", "_")
            if normalized in _FORBIDDEN_FACT_KEYS:
                failures.append(f"{path}.{key}")
            failures.extend(_forbidden_paths(item, f"{path}.{key}"))
    elif isinstance(value, list):
        for index, item in enumerate(value):
            failures.extend(_forbidden_paths(item, f"{path}[{index}]"))
    return failures


def _expected_scope(delta: Mapping[str, Any], inputs: Mapping[str, Any], scope: Any) -> dict:
    stated = _object(scope, "scope")
    if set(stated) != _SCOPE_FIELDS:
        raise ValueError("scope has a missing or unsupported field set")
    ok, detail = _sealed(stated, "scope_hash")
    if not ok:
        raise ValueError(detail)
    prior = _object(inputs.get("prior_case"), "verification_inputs.prior_case")
    current = _object(inputs.get("current_case"), "verification_inputs.current_case")
    decision = stated.get("decision_scope")
    if not isinstance(decision, dict) or not isinstance(
        stated.get("evidence_scope"), dict
    ):
        raise ValueError("decision_scope and evidence_scope must be embedded objects")
    prior_case_id = prior.get("case_id")
    current_case_id = current.get("case_id")
    if prior_case_id is None and current_case_id is None:
        case_id = _identity(decision.get("case_id"), "decision_scope.case_id")
    elif prior_case_id is None or current_case_id is None:
        raise ValueError(
            "prior_case and current_case must either both carry case_id or both omit it"
        )
    else:
        case_id = _identity(prior_case_id, "prior_case.case_id")
        if _identity(current_case_id, "current_case.case_id") != case_id:
            raise ValueError("prior and current case identities differ")
    declared_case_id = decision.get("case_id")
    if declared_case_id is not None and (
        _identity(declared_case_id, "decision_scope.case_id") != case_id
    ):
        raise ValueError(
            "decision_scope.case_id differs from the replayed case identity"
        )
    event = _object(delta.get("change_event"), "certified delta change_event")
    changed = _ids(event.get("changed_properties"), "change_event.changed_properties")
    expected = {
        "case_id": case_id,
        "event_id": _identity(event.get("event_id"), "change_event.event_id"),
        "prior_case_root": _identity(delta.get("prior_root"), "delta.prior_root"),
        "current_case_root": _identity(delta.get("current_root"), "delta.current_root"),
        "decision_scope": decision,
        "evidence_scope": stated["evidence_scope"],
        "change_scope": {
            "changed_object": _identity(
                event.get("changed_object"), "change_event.changed_object"
            ),
            "changed_properties": changed,
            "declared_reason": _identity(
                event.get("declared_reason"), "change_event.declared_reason"
            ),
        },
    }
    expected["scope_hash"] = content_hash(expected)
    return expected


def _expected_work(delta: Mapping[str, Any], minimum_action: str) -> tuple[dict, dict]:
    preserved = _ids(delta.get("preserved"), "delta.preserved")
    invalidated = _ids(delta.get("invalidated"), "delta.invalidated")
    recomputed = _ids(delta.get("recomputed"), "delta.recomputed")
    if set(preserved) & set(invalidated):
        raise ValueError("preserved and invalidated work overlap")
    prior = sorted(set(preserved) | set(invalidated))
    denominator = {
        "prior_artifact_work": {
            "members": prior,
            "count": _exact_count(len(prior)),
            "unit": "artifact identities",
        },
        "replacement_output_work": {
            "members": recomputed,
            "count": _exact_count(len(recomputed)),
            "unit": "artifact identities",
        },
    }
    denominator["denominator_hash"] = content_hash(denominator)
    facts = {
        "facts_profile": "crg-certified-change-work/identity-counts@1",
        "minimum_action": minimum_action,
        "preserved_work": {
            "members": preserved,
            "count": _exact_count(len(preserved)),
            "unit": "artifact identities",
        },
        "invalidated_work": {
            "members": invalidated,
            "count": _exact_count(len(invalidated)),
            "unit": "artifact identities",
        },
        "recomputed_work": {
            "members": recomputed,
            "count": _exact_count(len(recomputed)),
            "unit": "artifact identities",
        },
        "prior_work_partition_complete": True,
        "interpretation": (
            "Exact artifact identities under the certified typed dependency closure; "
            "no effort, elapsed-time, cost, or counterfactual quantity is derived."
        ),
    }
    return denominator, facts


def verify_comparative_change_evidence(record: Any) -> VerificationResult:
    """Reconstruct all v1.2 comparative-change facts and replay the delta."""

    result = VerificationResult(
        ok=False,
        status=Status.FAILED,
        report={
            "record_type": "ComparativeChangeEvidence",
            "level_attempted": "V3",
            "level_achieved": "NONE",
            "authority": AUTHORITY,
        },
    )
    if not isinstance(record, Mapping):
        result.record("comparative_change_shape", False, "record must be an object")
        return result.finish()
    artifact = dict(record)
    profile_ok = (
        artifact.get("record_type") == "ComparativeChangeEvidence"
        and artifact.get("schema_version") == SCHEMA_VERSION
        and artifact.get("profile") == PROFILE
        and artifact.get("first_release_attribution") == FIRST_RELEASE
    )
    result.record(
        "comparative_change_profile",
        profile_ok,
        f"registered profile is ComparativeChangeEvidence/{SCHEMA_VERSION}/{PROFILE}",
    )
    shape_ok = set(artifact) == _TOP_LEVEL_FIELDS
    if shape_ok:
        try:
            _identity(artifact.get("comparison_id"), "comparison_id")
        except ValueError:
            shape_ok = False
    result.record(
        "comparative_change_record_shape",
        shape_ok,
        "the profile permits only its complete canonical field set",
    )
    ok, detail = _sealed(artifact, "record_hash")
    result.record("comparative_change_integrity", ok, detail)
    boundary_ok = (
        artifact.get("authority") == AUTHORITY
        and artifact.get("authorizing") is False
        and artifact.get("semantic_effect") == "NONE"
        and artifact.get("evidence_class")
        == "SYSTEM_DERIVED_CERTIFIED_CHANGE_FACTS"
        and artifact.get("claim_boundary") == CLAIM_BOUNDARY
        and artifact.get("conclusion")
        == "NO_METHOD_RANKING_OR_ECONOMIC_CONCLUSION"
    )
    result.record(
        "comparative_change_non_authorizing_boundary",
        boundary_ok,
        "authority, semantic effect, evidence class, claim boundary, and conclusion are fixed",
    )

    binding_failures: list[str] = []
    independent: VerificationResult | None = None
    delta: dict = {}
    inputs: dict = {}
    binding: dict = {}
    try:
        binding = _object(
            artifact.get("certified_delta_binding"), "certified_delta_binding"
        )
        if set(binding) != _BINDING_FIELDS:
            raise ValueError("certified_delta_binding has a missing or unsupported field set")
        ok, detail = _sealed(binding, "binding_hash")
        if not ok:
            binding_failures.append(detail)
        delta = _object(binding.get("certified_delta"), "certified_delta")
        inputs = _object(binding.get("verification_inputs"), "verification_inputs")
        missing = sorted(_REQUIRED_INPUTS - set(inputs))
        unknown = sorted(set(inputs) - _REQUIRED_INPUTS - _OPTIONAL_INPUTS)
        if missing or unknown:
            raise ValueError(
                f"verification_inputs are not closed: missing={missing}, unknown={unknown}"
            )
        expected_hashes = {
            "certified_delta_hash": content_hash(delta),
            "verification_inputs_hash": content_hash(inputs),
            "independent_verification_hash": content_hash(
                binding.get("independent_verification")
            ),
        }
        for field, expected in expected_hashes.items():
            if binding.get(field) != expected:
                binding_failures.append(
                    f"{field} differs from independently reconstructed {expected}"
                )
        independent = verify_certified_delta_record(
            delta,
            inputs["prior_case"],
            inputs["current_case"],
            inputs["dependency_edges"],
            replacements=inputs["replacements"],
            prior_phase=inputs.get("prior_phase"),
            current_phase=inputs.get("current_phase"),
            prior_phase_source_r=inputs.get("prior_phase_source_r"),
            current_phase_source_r=inputs.get("current_phase_source_r"),
        )
        if not independent.ok or independent.status != Status.VERIFIED:
            binding_failures.extend(independent.violations or [
                f"embedded delta replay returned {independent.status}"
            ])
        if binding.get("independent_verification") != independent.to_json():
            binding_failures.append(
                "bound independent result differs from a fresh stdlib-only replay"
            )
    except (CanonicalError, KeyError, TypeError, ValueError) as error:
        binding_failures.append(str(error))
    result.record(
        "comparative_change_delta_independently_replayed",
        not binding_failures,
        "; ".join(binding_failures) if binding_failures else
        "the CertifiedDeltaRecord, exact replay inputs, and verifier result agree",
    )

    reconstruction_failures: list[str] = []
    minimum_action = None
    if independent is not None and independent.ok:
        minimum_action = independent.report.get("minimum_action")
        try:
            delta_body = _object(delta.get("delta"), "certified_delta.delta")
            expected_scope = _expected_scope(delta_body, inputs, artifact.get("scope"))
            if artifact.get("scope") != expected_scope:
                reconstruction_failures.append(
                    "scope does not bind the replayed case roots and change event"
                )
            expected_denominator, expected_facts = _expected_work(
                delta_body, _identity(minimum_action, "minimum action")
            )
            if artifact.get("work_denominator") != expected_denominator:
                reconstruction_failures.append(
                    "work denominator differs from the preserved/invalidated/recomputed identities"
                )
            if artifact.get("system_derived_facts") != expected_facts:
                reconstruction_failures.append(
                    "minimum action or exact work facts differ from independent reconstruction"
                )
        except (CanonicalError, TypeError, ValueError) as error:
            reconstruction_failures.append(str(error))
    else:
        reconstruction_failures.append("a successful independent delta replay is required")
    result.record(
        "comparative_change_facts_reconstructed",
        not reconstruction_failures,
        "; ".join(reconstruction_failures) if reconstruction_failures else
        "minimum action and exact preserved, invalidated, and recomputed identities reconstructed",
    )

    limitations = artifact.get("limitations")
    limitations_ok = (
        isinstance(limitations, list)
        and bool(limitations)
        and all(
            isinstance(item, str) and item and item == item.strip()
            for item in limitations
        )
        and limitations == sorted(limitations)
        and len(limitations) == len(set(limitations))
    )
    result.record(
        "comparative_change_limitations",
        limitations_ok,
        "at least one unique canonically ordered limitation is required",
    )
    forbidden = _forbidden_paths(
        artifact.get("system_derived_facts"), "system_derived_facts"
    )
    result.record(
        "comparative_change_no_strengthened_claim",
        not forbidden,
        f"prohibited conclusion fields: {forbidden}" if forbidden else
        "no ROI, savings, superiority, ranking, or avoided-work field is present",
    )
    try:
        artifact_root = content_hash(artifact)
    except (CanonicalError, TypeError, ValueError):
        artifact_root = None
    result.report.update(
        {
            "artifact_root": artifact_root,
            "comparison_id": artifact.get("comparison_id"),
            "minimum_action": minimum_action,
            "preserved_count": len(
                (artifact.get("system_derived_facts") or {})
                .get("preserved_work", {})
                .get("members", [])
            ) if isinstance(artifact.get("system_derived_facts"), dict) else 0,
            "recomputed_count": len(
                (artifact.get("system_derived_facts") or {})
                .get("recomputed_work", {})
                .get("members", [])
            ) if isinstance(artifact.get("system_derived_facts"), dict) else 0,
            "claim_boundary": CLAIM_BOUNDARY,
        }
    )
    result.finish()
    if not profile_ok:
        result.status = Status.UNSUPPORTED_PROFILE
    elif result.ok:
        result.status = Status.VERIFIED_RELATIVE
        result.report["level_achieved"] = "V3"
    else:
        result.status = Status.FAILED
    return result
