"""Vendor-neutral source-adapter contract and conformance kit.

An adapter sits *alongside* a compiler, optimizer, EDA tool, simulator,
database, or laboratory system.  It does not embed that system in CRG and it
does not authorize a decision.  Its sole role is to turn a caller-supplied
snapshot into the governed registry-intake boundary while preserving the
snapshot and record identities needed to audit the translation.

The conformance runner deliberately reuses :mod:`crg_io.intake` rather than
implementing a second importer.  It independently checks the adapter's
content bindings, executes a fresh intake preview, and proves that every
normalized row has exactly one source-identity binding.  A conformant report
therefore says that the adapter obeyed this translation contract on the
declared fixtures; it says nothing about the truth of the source data and
nothing about the validity of a later CRG decision.
"""
from __future__ import annotations

import re
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from crg_model.canonical import canonical_json, content_hash
from crg_model.completeness import ClaimScope, CompletenessBasisType
from crg_model.envelope import EvidenceClass
from crg_model.units import DEFAULT_REGISTRY, QuantityRegistry

from .import_profile import file_fingerprint
from .intake import (
    CSV_SOURCE,
    JSON_SOURCE,
    RegistryIntakePreview,
    RegistryMappingProfile,
    SourceProvenance,
    preview_registry_intake,
)

__all__ = [
    "SOURCE_ADAPTER_CONTRACT_ID",
    "SOURCE_ADAPTER_CONTRACT_VERSION",
    "SOURCE_ADAPTER_OUTPUT_SCHEMA_VERSION",
    "SOURCE_ADAPTER_REPORT_SCHEMA_VERSION",
    "REVIEWED_IN_PROCESS",
    "SANDBOXED_PROCESS",
    "NOT_EXECUTED",
    "SourceSystemClass",
    "AdapterFixtureCategory",
    "AdapterConformanceRequirement",
    "AdapterExpectedStatus",
    "SourceAdapterError",
    "SourceAdapterRefusal",
    "SourceAdapterDefinition",
    "SourceAdapterRequest",
    "SourceRecordIdentityBinding",
    "PortableSourceReference",
    "SourceAdapterOutput",
    "SourceAdapterFixture",
    "SourceAdapterCaseResult",
    "SourceAdapterConformanceReport",
    "run_source_adapter_conformance",
    "require_conformant_source_adapter",
]


SOURCE_ADAPTER_CONTRACT_ID = "crg.source-adapter"
SOURCE_ADAPTER_CONTRACT_VERSION = "1.0.0"
SOURCE_ADAPTER_OUTPUT_SCHEMA_VERSION = "1.0.0"
SOURCE_ADAPTER_REPORT_SCHEMA_VERSION = "1.0.0"

REVIEWED_IN_PROCESS = "REVIEWED_IN_PROCESS"
SANDBOXED_PROCESS = "SANDBOXED_PROCESS"
NOT_EXECUTED = "NOT_EXECUTED"

_HASH_RE = re.compile(r"^sha256:[0-9a-f]{64}$")
_SEMVER_RE = re.compile(r"^[0-9]+\.[0-9]+\.[0-9]+(?:[-+][0-9A-Za-z.-]+)?$")


class SourceSystemClass:
    COMPILER = "COMPILER"
    OPTIMIZER = "OPTIMIZER"
    EDA = "EDA"
    SIMULATOR = "SIMULATOR"
    DATABASE = "DATABASE"
    LABORATORY = "LABORATORY"
    GENERIC = "GENERIC"

    ALL = frozenset({COMPILER, OPTIMIZER, EDA, SIMULATOR, DATABASE, LABORATORY, GENERIC})


class AdapterFixtureCategory:
    POSITIVE = "POSITIVE"
    NEGATIVE = "NEGATIVE"
    BOUNDARY = "BOUNDARY"
    MALFORMED = "MALFORMED"
    IDENTITY_PRESERVATION = "IDENTITY_PRESERVATION"
    MALICIOUS = "MALICIOUS"

    REQUIRED = frozenset({
        POSITIVE,
        NEGATIVE,
        BOUNDARY,
        MALFORMED,
        IDENTITY_PRESERVATION,
        MALICIOUS,
    })


class AdapterConformanceRequirement:
    VALID_SOURCE = "VALID_SOURCE"
    UNSUPPORTED_MEDIA_REFUSAL = "UNSUPPORTED_MEDIA_REFUSAL"
    EXACT_BOUNDARY = "EXACT_BOUNDARY"
    MALFORMED_SOURCE_REFUSAL = "MALFORMED_SOURCE_REFUSAL"
    IDENTITY_PRESERVATION = "IDENTITY_PRESERVATION"
    REJECTED_ROW_PRESERVATION = "REJECTED_ROW_PRESERVATION"
    REMOTE_DEPENDENCY_REFUSAL = "REMOTE_DEPENDENCY_REFUSAL"
    BINARY_FLOAT_REFUSAL = "BINARY_FLOAT_REFUSAL"
    UNIT_PRESERVATION = "UNIT_PRESERVATION"
    EVIDENCE_PRESERVATION = "EVIDENCE_PRESERVATION"

    REQUIRED = frozenset({
        VALID_SOURCE,
        UNSUPPORTED_MEDIA_REFUSAL,
        EXACT_BOUNDARY,
        MALFORMED_SOURCE_REFUSAL,
        IDENTITY_PRESERVATION,
        REJECTED_ROW_PRESERVATION,
        REMOTE_DEPENDENCY_REFUSAL,
        BINARY_FLOAT_REFUSAL,
        UNIT_PRESERVATION,
        EVIDENCE_PRESERVATION,
    })


class AdapterExpectedStatus:
    SUCCEEDED = "SUCCEEDED"
    REFUSED = "REFUSED"
    ALL = frozenset({SUCCEEDED, REFUSED})


class SourceAdapterError(ValueError):
    """The adapter definition, output, fixture, or conformance result is invalid."""


class SourceAdapterRefusal(SourceAdapterError):
    """A controlled fail-closed refusal produced by the adapter under test."""

    def __init__(self, code: str, detail: str) -> None:
        if not isinstance(code, str) or not code.strip():
            raise SourceAdapterError("adapter refusal code MUST be non-empty")
        if not isinstance(detail, str) or not detail.strip():
            raise SourceAdapterError("adapter refusal detail MUST be non-empty")
        self.code = code
        self.detail = detail
        super().__init__(f"{code}: {detail}")


def _nonempty(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise SourceAdapterError(f"{label} MUST be a non-empty string")
    if "\x00" in value:
        raise SourceAdapterError(f"{label} MUST NOT contain NUL")
    return value


def _hash(value: Any, label: str) -> str:
    if not isinstance(value, str) or not _HASH_RE.fullmatch(value):
        raise SourceAdapterError(f"{label} MUST be a sha256 content hash")
    return value


def _tuple_of_nonempty(values: Iterable[Any], label: str) -> Tuple[str, ...]:
    result = tuple(_nonempty(value, label) for value in values)
    if not result:
        raise SourceAdapterError(f"{label} MUST contain at least one value")
    if len(set(result)) != len(result):
        raise SourceAdapterError(f"{label} contains duplicates")
    return result


def _contains_remote_locator(value: Any) -> bool:
    """Return true when a canonical value embeds an originating-server locator."""
    if isinstance(value, str):
        lowered = value.strip().lower()
        return lowered.startswith(("http://", "https://", "ftp://", "s3://", "gs://"))
    if isinstance(value, Mapping):
        return any(_contains_remote_locator(item) for item in value.values())
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        return any(_contains_remote_locator(item) for item in value)
    return False


@dataclass(frozen=True)
class SourceAdapterDefinition:
    """Immutable declaration for one reviewed source-adapter implementation."""

    adapter_id: str
    adapter_version: str
    source_system_class: str
    implementation_identity: str
    input_media_types: Tuple[str, ...]
    output_source_format: str
    execution_profile: str
    failure_modes: Tuple[str, ...]
    semantic_scope: str
    contract_id: str = SOURCE_ADAPTER_CONTRACT_ID
    contract_version: str = SOURCE_ADAPTER_CONTRACT_VERSION
    determinism_status: str = "DETERMINISTIC"

    def __post_init__(self) -> None:
        _nonempty(self.adapter_id, "adapter_id")
        if not isinstance(self.adapter_version, str) or not _SEMVER_RE.fullmatch(
            self.adapter_version
        ):
            raise SourceAdapterError("adapter_version MUST be a semantic version")
        if self.source_system_class not in SourceSystemClass.ALL:
            raise SourceAdapterError(
                f"source_system_class MUST be one of {sorted(SourceSystemClass.ALL)}"
            )
        _hash(self.implementation_identity, "implementation_identity")
        object.__setattr__(
            self,
            "input_media_types",
            _tuple_of_nonempty(self.input_media_types, "input_media_types"),
        )
        if self.output_source_format not in {CSV_SOURCE, JSON_SOURCE}:
            raise SourceAdapterError("output_source_format MUST be 'csv' or 'json'")
        if self.execution_profile not in {REVIEWED_IN_PROCESS, SANDBOXED_PROCESS}:
            raise SourceAdapterError(
                "execution_profile MUST be REVIEWED_IN_PROCESS or SANDBOXED_PROCESS"
            )
        object.__setattr__(
            self,
            "failure_modes",
            _tuple_of_nonempty(self.failure_modes, "failure_modes"),
        )
        _nonempty(self.semantic_scope, "semantic_scope")
        if self.contract_id != SOURCE_ADAPTER_CONTRACT_ID:
            raise SourceAdapterError("source-adapter contract_id is unsupported")
        if self.contract_version != SOURCE_ADAPTER_CONTRACT_VERSION:
            raise SourceAdapterError("source-adapter contract_version is unsupported")
        if self.determinism_status != "DETERMINISTIC":
            raise SourceAdapterError(
                "the portable source-adapter contract admits deterministic adapters only"
            )

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "record_type": "SourceAdapterDefinition",
            "schema_version": SOURCE_ADAPTER_CONTRACT_VERSION,
            "contract_id": self.contract_id,
            "contract_version": self.contract_version,
            "adapter_id": self.adapter_id,
            "adapter_version": self.adapter_version,
            "extension_type": "SOURCE_ADAPTER",
            "source_system_class": self.source_system_class,
            "implementation_identity": self.implementation_identity,
            "input_media_types": list(self.input_media_types),
            "output_source_format": self.output_source_format,
            "execution_profile": self.execution_profile,
            "determinism_status": self.determinism_status,
            "failure_modes": list(self.failure_modes),
            "semantic_scope": self.semantic_scope,
            "authority": "NON_AUTHORIZING_TRANSLATION",
        }

    def definition_hash(self) -> str:
        return content_hash(self.to_canonical())


@dataclass(frozen=True)
class SourceAdapterRequest:
    """Caller-supplied bytes and provenance; no source-system access is implied."""

    source_bytes: bytes
    media_type: str
    provenance: SourceProvenance

    def __post_init__(self) -> None:
        if not isinstance(self.source_bytes, bytes):
            raise SourceAdapterError("source_bytes MUST be immutable bytes")
        _nonempty(self.media_type, "media_type")
        if not isinstance(self.provenance, SourceProvenance):
            raise SourceAdapterError("provenance MUST be SourceProvenance")

    def snapshot_descriptor(self) -> Dict[str, Any]:
        return {
            "provenance": self.provenance.to_canonical(),
            "media_type": self.media_type,
            "content_hash": file_fingerprint(self.source_bytes),
            "byte_length": len(self.source_bytes),
        }

    def snapshot_hash(self) -> str:
        return content_hash(self.snapshot_descriptor())


@dataclass(frozen=True)
class SourceRecordIdentityBinding:
    """One source record bound to exactly one normalized intake row."""

    source_locator: str
    source_record: Any
    source_record_hash: str
    normalized_row_number: int
    normalized_identity: Optional[str]

    def __post_init__(self) -> None:
        _nonempty(self.source_locator, "source_locator")
        _hash(self.source_record_hash, "source_record_hash")
        try:
            recomputed = content_hash(self.source_record)
        except (TypeError, ValueError) as error:
            raise SourceAdapterError(
                "source_record MUST be canonical hashable content"
            ) from error
        if recomputed != self.source_record_hash:
            raise SourceAdapterError(
                "source_record_hash does not bind the embedded source_record"
            )
        if _contains_remote_locator(self.source_record):
            raise SourceAdapterError(
                "source_record MUST NOT require an originating-server locator"
            )
        if isinstance(self.normalized_row_number, bool) or not isinstance(
            self.normalized_row_number, int
        ) or self.normalized_row_number < 1:
            raise SourceAdapterError("normalized_row_number MUST be a positive integer")
        if self.normalized_identity is not None:
            _nonempty(self.normalized_identity, "normalized_identity")

    def to_canonical(self) -> Dict[str, Any]:
        record: Dict[str, Any] = {
            "source_locator": self.source_locator,
            "source_record": self.source_record,
            "source_record_hash": self.source_record_hash,
            "normalized_row_number": self.normalized_row_number,
        }
        if self.normalized_identity is not None:
            record["normalized_identity"] = self.normalized_identity
        return record


@dataclass(frozen=True)
class PortableSourceReference:
    """Content-addressed reference requiring no originating server."""

    reference_id: str
    role: str
    media_type: str
    content_hash: str
    byte_length: int
    availability: str

    def __post_init__(self) -> None:
        _nonempty(self.reference_id, "reference_id")
        if self.role not in {"ORIGINAL_SOURCE", "NORMALIZED_SOURCE", "MAPPING_PROFILE"}:
            raise SourceAdapterError("portable source-reference role is unsupported")
        _nonempty(self.media_type, "reference media_type")
        _hash(self.content_hash, "reference content_hash")
        if isinstance(self.byte_length, bool) or not isinstance(self.byte_length, int) or self.byte_length < 0:
            raise SourceAdapterError("reference byte_length MUST be a non-negative integer")
        if self.availability not in {"CALLER_SUPPLIED_BYTES", "EMBEDDED_IN_EXPORT"}:
            raise SourceAdapterError(
                "reference availability MUST be CALLER_SUPPLIED_BYTES or EMBEDDED_IN_EXPORT"
            )

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "reference_id": self.reference_id,
            "role": self.role,
            "media_type": self.media_type,
            "content_hash": self.content_hash,
            "byte_length": self.byte_length,
            "availability": self.availability,
        }


@dataclass(frozen=True)
class SourceAdapterOutput:
    """Non-authorizing normalized source plus complete identity bindings."""

    definition_hash: str
    input_snapshot: Mapping[str, Any]
    input_snapshot_hash: str
    normalized_source: bytes
    mapping_profile: RegistryMappingProfile
    identity_bindings: Tuple[SourceRecordIdentityBinding, ...]
    portable_references: Tuple[PortableSourceReference, ...]
    authority: str = "NON_AUTHORIZING_TRANSLATION"
    completeness_basis: str = CompletenessBasisType.EXPLICIT_IMPORTED_FAMILY
    schema_version: str = SOURCE_ADAPTER_OUTPUT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        _hash(self.definition_hash, "definition_hash")
        _hash(self.input_snapshot_hash, "input_snapshot_hash")
        if not isinstance(self.input_snapshot, Mapping):
            raise SourceAdapterError("input_snapshot MUST be an object")
        expected_snapshot_fields = {"provenance", "media_type", "content_hash", "byte_length"}
        if set(self.input_snapshot) != expected_snapshot_fields:
            raise SourceAdapterError("input_snapshot fields are incomplete or unknown")
        provenance = self.input_snapshot.get("provenance")
        if not isinstance(provenance, Mapping) or not {
            "source_id", "source_name", "origin"
        } <= set(provenance) or set(provenance) - {
            "source_id", "source_name", "origin", "producer", "source_version"
        }:
            raise SourceAdapterError("input_snapshot provenance is incomplete or unknown")
        for key in ("source_id", "source_name", "origin"):
            _nonempty(provenance[key], f"input_snapshot provenance {key}")
        _nonempty(self.input_snapshot.get("media_type"), "input_snapshot media_type")
        _hash(self.input_snapshot.get("content_hash"), "input_snapshot content_hash")
        snapshot_length = self.input_snapshot.get("byte_length")
        if isinstance(snapshot_length, bool) or not isinstance(snapshot_length, int) or snapshot_length < 0:
            raise SourceAdapterError("input_snapshot byte_length MUST be a non-negative integer")
        if content_hash(dict(self.input_snapshot)) != self.input_snapshot_hash:
            raise SourceAdapterError("input_snapshot_hash does not bind input_snapshot")
        if not isinstance(self.normalized_source, bytes):
            raise SourceAdapterError("normalized_source MUST be immutable bytes")
        if not isinstance(self.mapping_profile, RegistryMappingProfile):
            raise SourceAdapterError("mapping_profile MUST be RegistryMappingProfile")
        object.__setattr__(self, "identity_bindings", tuple(self.identity_bindings))
        object.__setattr__(self, "portable_references", tuple(self.portable_references))
        if not self.identity_bindings:
            raise SourceAdapterError("source-adapter output MUST bind every normalized row")
        row_numbers = [item.normalized_row_number for item in self.identity_bindings]
        if len(set(row_numbers)) != len(row_numbers):
            raise SourceAdapterError("identity bindings contain duplicate normalized rows")
        locators = [item.source_locator for item in self.identity_bindings]
        if len(set(locators)) != len(locators):
            raise SourceAdapterError("identity bindings collapse duplicate source locators")
        if len({item.reference_id for item in self.portable_references}) != len(
            self.portable_references
        ):
            raise SourceAdapterError("portable references contain duplicate reference_id values")
        if self.authority != "NON_AUTHORIZING_TRANSLATION":
            raise SourceAdapterError("a source adapter cannot grant authorizing authority")
        if self.completeness_basis != CompletenessBasisType.EXPLICIT_IMPORTED_FAMILY:
            raise SourceAdapterError(
                "a source adapter cannot strengthen completeness beyond EXPLICIT_IMPORTED_FAMILY"
            )
        if self.schema_version != SOURCE_ADAPTER_OUTPUT_SCHEMA_VERSION:
            raise SourceAdapterError("source-adapter output schema_version is unsupported")

    def normalized_source_hash(self) -> str:
        return file_fingerprint(self.normalized_source)

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "record_type": "SourceAdapterOutput",
            "schema_version": self.schema_version,
            "authority": self.authority,
            "mutation_performed": False,
            "definition_hash": self.definition_hash,
            "input_snapshot": dict(self.input_snapshot),
            "input_snapshot_hash": self.input_snapshot_hash,
            "normalized_source": {
                "source_format": self.mapping_profile.source_format,
                "content_hash": self.normalized_source_hash(),
                "byte_length": len(self.normalized_source),
            },
            "mapping_profile": self.mapping_profile.to_canonical(),
            "mapping_profile_hash": self.mapping_profile.profile_hash(),
            "identity_bindings": [
                item.to_canonical()
                for item in sorted(self.identity_bindings, key=lambda value: value.normalized_row_number)
            ],
            "portable_references": [
                item.to_canonical()
                for item in sorted(self.portable_references, key=lambda value: value.reference_id)
            ],
            "completeness_basis": self.completeness_basis,
            "claim_scope": ClaimScope.RELATIVE_EXPLICIT_FAMILY,
        }

    def output_hash(self) -> str:
        return content_hash(self.to_canonical())


SourceAdapter = Callable[[SourceAdapterRequest], SourceAdapterOutput]


@dataclass(frozen=True)
class SourceAdapterFixture:
    fixture_id: str
    category: str
    request: SourceAdapterRequest
    expected_status: str
    requirements: Tuple[str, ...]
    expected_refusal_code: Optional[str] = None
    expected_identity_bindings: Tuple[SourceRecordIdentityBinding, ...] = ()
    expected_accepted_ids: Tuple[str, ...] = ()
    expected_rejected_rows: Tuple[int, ...] = ()
    expected_evidence_classes: Mapping[str, str] = field(default_factory=dict)
    expected_units: Mapping[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        _nonempty(self.fixture_id, "fixture_id")
        if self.category not in AdapterFixtureCategory.REQUIRED:
            raise SourceAdapterError("adapter fixture category is unsupported")
        if not isinstance(self.request, SourceAdapterRequest):
            raise SourceAdapterError("adapter fixture request is invalid")
        if self.expected_status not in AdapterExpectedStatus.ALL:
            raise SourceAdapterError("adapter fixture expected_status is unsupported")
        object.__setattr__(self, "requirements", tuple(self.requirements))
        if not self.requirements:
            raise SourceAdapterError("adapter fixture MUST cover a conformance requirement")
        unknown_requirements = sorted(
            set(self.requirements) - AdapterConformanceRequirement.REQUIRED
        )
        if unknown_requirements:
            raise SourceAdapterError(
                f"adapter fixture has unknown requirement(s): {unknown_requirements}"
            )
        if len(set(self.requirements)) != len(self.requirements):
            raise SourceAdapterError("adapter fixture requirements contain duplicates")
        if self.expected_status == AdapterExpectedStatus.REFUSED:
            _nonempty(self.expected_refusal_code, "expected_refusal_code")
            if self.expected_identity_bindings or self.expected_accepted_ids or self.expected_rejected_rows:
                raise SourceAdapterError("a refused fixture cannot declare materialized row outcomes")
        elif self.expected_refusal_code is not None:
            raise SourceAdapterError("a successful fixture cannot declare expected_refusal_code")
        object.__setattr__(self, "expected_identity_bindings", tuple(self.expected_identity_bindings))
        object.__setattr__(self, "expected_accepted_ids", tuple(self.expected_accepted_ids))
        object.__setattr__(self, "expected_rejected_rows", tuple(self.expected_rejected_rows))
        if len(set(self.expected_accepted_ids)) != len(self.expected_accepted_ids):
            raise SourceAdapterError("expected_accepted_ids contains duplicates")
        if len(set(self.expected_rejected_rows)) != len(self.expected_rejected_rows):
            raise SourceAdapterError("expected_rejected_rows contains duplicates")
        for evidence in self.expected_evidence_classes.values():
            if evidence not in EvidenceClass.ALL:
                raise SourceAdapterError(f"unsupported expected evidence class {evidence!r}")


@dataclass(frozen=True)
class SourceAdapterCaseResult:
    fixture_id: str
    category: str
    requirements: Tuple[str, ...]
    expected_status: str
    observed_status: str
    passed: bool
    violations: Tuple[str, ...]
    refusal_code: Optional[str] = None
    output_hash: Optional[str] = None
    preview_hash: Optional[str] = None
    accepted_count: int = 0
    rejected_count: int = 0

    def __post_init__(self) -> None:
        _nonempty(self.fixture_id, "case fixture_id")
        if self.category not in AdapterFixtureCategory.REQUIRED:
            raise SourceAdapterError("case category is unsupported")
        object.__setattr__(self, "requirements", tuple(self.requirements))
        if not self.requirements or set(self.requirements) - AdapterConformanceRequirement.REQUIRED:
            raise SourceAdapterError("case requirements are empty or unsupported")
        if len(set(self.requirements)) != len(self.requirements):
            raise SourceAdapterError("case requirements contain duplicates")
        if self.expected_status not in AdapterExpectedStatus.ALL:
            raise SourceAdapterError("case expected_status is unsupported")
        if self.observed_status not in AdapterExpectedStatus.ALL | {"FAILED", "NOT_RUN"}:
            raise SourceAdapterError("case observed_status is unsupported")
        if not isinstance(self.passed, bool):
            raise SourceAdapterError("case passed MUST be boolean")
        object.__setattr__(self, "violations", tuple(self.violations))
        if self.passed and (
            self.violations or self.expected_status != self.observed_status
        ):
            raise SourceAdapterError(
                "a passing case MUST have no violations and match its expected status"
            )
        if self.refusal_code is not None:
            _nonempty(self.refusal_code, "case refusal_code")
        if self.output_hash is not None:
            _hash(self.output_hash, "case output_hash")
        if self.preview_hash is not None:
            _hash(self.preview_hash, "case preview_hash")
        for value, label in (
            (self.accepted_count, "accepted_count"),
            (self.rejected_count, "rejected_count"),
        ):
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise SourceAdapterError(f"case {label} MUST be a non-negative integer")

    def to_canonical(self) -> Dict[str, Any]:
        record: Dict[str, Any] = {
            "fixture_id": self.fixture_id,
            "category": self.category,
            "requirements": list(self.requirements),
            "expected_status": self.expected_status,
            "observed_status": self.observed_status,
            "passed": self.passed,
            "violations": list(self.violations),
            "accepted_count": self.accepted_count,
            "rejected_count": self.rejected_count,
        }
        if self.refusal_code is not None:
            record["refusal_code"] = self.refusal_code
        if self.output_hash is not None:
            record["output_hash"] = self.output_hash
        if self.preview_hash is not None:
            record["preview_hash"] = self.preview_hash
        return record


@dataclass(frozen=True)
class SourceAdapterConformanceReport:
    definition: SourceAdapterDefinition
    observed_execution_profile: str
    cases: Tuple[SourceAdapterCaseResult, ...]
    coverage: Mapping[str, int]
    requirement_coverage: Mapping[str, int]
    violations: Tuple[str, ...]

    def __post_init__(self) -> None:
        if not isinstance(self.definition, SourceAdapterDefinition):
            raise SourceAdapterError("conformance report definition is invalid")
        if self.observed_execution_profile not in {
            REVIEWED_IN_PROCESS,
            SANDBOXED_PROCESS,
            NOT_EXECUTED,
        }:
            raise SourceAdapterError(
                "conformance report observed_execution_profile is unsupported"
            )
        object.__setattr__(self, "cases", tuple(self.cases))
        object.__setattr__(self, "violations", tuple(self.violations))
        if not self.cases:
            raise SourceAdapterError("conformance report MUST contain fixture cases")
        if set(self.coverage) != AdapterFixtureCategory.REQUIRED:
            raise SourceAdapterError("conformance report category coverage is incomplete")
        if set(self.requirement_coverage) != AdapterConformanceRequirement.REQUIRED:
            raise SourceAdapterError("conformance report requirement coverage is incomplete")
        actual_categories = {category: 0 for category in AdapterFixtureCategory.REQUIRED}
        actual_requirements = {
            requirement: 0 for requirement in AdapterConformanceRequirement.REQUIRED
        }
        for case in self.cases:
            actual_categories[case.category] += 1
            for requirement in case.requirements:
                actual_requirements[requirement] += 1
        if dict(self.coverage) != actual_categories:
            raise SourceAdapterError("conformance report category counts do not match its cases")
        if dict(self.requirement_coverage) != actual_requirements:
            raise SourceAdapterError("conformance report requirement counts do not match its cases")
        if any(
            isinstance(value, bool) or not isinstance(value, int) or value < 0
            for value in (*self.coverage.values(), *self.requirement_coverage.values())
        ):
            raise SourceAdapterError("conformance report coverage counts are invalid")

    @property
    def passed(self) -> bool:
        return (
            not self.violations
            and self.observed_execution_profile == self.definition.execution_profile
            and all(item.passed for item in self.cases)
            and all(value > 0 for value in self.coverage.values())
            and all(value > 0 for value in self.requirement_coverage.values())
        )

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "record_type": "SourceAdapterConformanceReport",
            "schema_version": SOURCE_ADAPTER_REPORT_SCHEMA_VERSION,
            "authority": "NON_AUTHORIZING_CONFORMANCE_EVIDENCE",
            "definition": self.definition.to_canonical(),
            "definition_hash": self.definition.definition_hash(),
            "declared_execution_profile": self.definition.execution_profile,
            "observed_execution_profile": self.observed_execution_profile,
            "required_categories": sorted(AdapterFixtureCategory.REQUIRED),
            "coverage": {name: int(self.coverage.get(name, 0)) for name in sorted(self.coverage)},
            "required_requirements": sorted(AdapterConformanceRequirement.REQUIRED),
            "requirement_coverage": {
                name: int(self.requirement_coverage.get(name, 0))
                for name in sorted(self.requirement_coverage)
            },
            "cases": [item.to_canonical() for item in self.cases],
            "passed": self.passed,
            "violations": list(self.violations),
            "claim": (
                "A passing report establishes only that the adapter was observed under the "
                "stated execution profile and obeyed the source-translation contract on this "
                "fixture suite. It does not establish source-data truth or authorize a decision."
            ),
        }

    def report_hash(self) -> str:
        return content_hash(self.to_canonical())

    def require_passed(self) -> "SourceAdapterConformanceReport":
        if not self.passed:
            details = list(self.violations)
            for case in self.cases:
                details.extend(f"{case.fixture_id}: {item}" for item in case.violations)
            raise SourceAdapterError("source-adapter conformance failed: " + "; ".join(details))
        return self


def _preview_output(
    output: SourceAdapterOutput,
    request: SourceAdapterRequest,
    registry: QuantityRegistry,
) -> RegistryIntakePreview:
    suffix = ".csv" if output.mapping_profile.source_format == CSV_SOURCE else ".json"
    with tempfile.TemporaryDirectory(prefix="crg-adapter-conformance-") as directory:
        path = Path(directory) / ("normalized" + suffix)
        path.write_bytes(output.normalized_source)
        return preview_registry_intake(
            path,
            profile=output.mapping_profile,
            provenance=request.provenance,
            registry=registry,
        )


def _verify_output(
    definition: SourceAdapterDefinition,
    request: SourceAdapterRequest,
    output: SourceAdapterOutput,
    fixture: SourceAdapterFixture,
    registry: QuantityRegistry,
) -> Tuple[List[str], RegistryIntakePreview]:
    violations: List[str] = []
    if output.definition_hash != definition.definition_hash():
        violations.append("output definition_hash does not bind the declared adapter")
    if output.input_snapshot_hash != request.snapshot_hash():
        violations.append("output input_snapshot_hash does not bind the caller-supplied source")
    if dict(output.input_snapshot) != request.snapshot_descriptor():
        violations.append("output input_snapshot does not preserve the caller-supplied descriptor")
    if request.media_type not in definition.input_media_types:
        violations.append("adapter accepted a media type outside its declaration")
    if output.mapping_profile.source_format != definition.output_source_format:
        violations.append("output mapping format differs from the adapter declaration")
    if output.mapping_profile.default_evidence_class != EvidenceClass.IMPORTED:
        violations.append(
            "adapter default evidence class must remain IMPORTED; stronger classes require an "
            "explicit mapped source field"
        )
    if _contains_remote_locator(output.to_canonical()):
        violations.append("output contains an originating-server locator")

    reference_roles = {item.role for item in output.portable_references}
    if reference_roles != {"ORIGINAL_SOURCE", "NORMALIZED_SOURCE", "MAPPING_PROFILE"}:
        violations.append("portable references must cover original source, normalized source, and mapping")
    for reference in output.portable_references:
        if reference.role == "ORIGINAL_SOURCE":
            expected_hash = file_fingerprint(request.source_bytes)
            expected_length = len(request.source_bytes)
        elif reference.role == "NORMALIZED_SOURCE":
            expected_hash = output.normalized_source_hash()
            expected_length = len(output.normalized_source)
        else:
            expected_hash = output.mapping_profile.profile_hash()
            expected_length = len(
                canonical_json(output.mapping_profile.to_canonical()).encode("utf-8")
            )
        if reference.content_hash != expected_hash:
            violations.append(f"{reference.role} portable reference hash is incorrect")
        if reference.byte_length != expected_length:
            violations.append(f"{reference.role} portable reference length is incorrect")

    try:
        preview = _preview_output(output, request, registry)
    except Exception as error:
        raise SourceAdapterError(
            f"normalized source cannot enter the governed intake boundary: {type(error).__name__}: {error}"
        ) from error

    if preview.completeness_basis.basis_type != CompletenessBasisType.EXPLICIT_IMPORTED_FAMILY:
        violations.append("intake preview strengthened adapter completeness")
    if preview.to_canonical().get("claim_scope") != ClaimScope.RELATIVE_EXPLICIT_FAMILY:
        violations.append("intake preview strengthened adapter claim scope")

    preview_rows = {
        item.source_row_number: item.realization_id for item in preview.accepted
    }
    preview_rows.update({
        item.source_row_number: item.realization_id for item in preview.rejected
    })
    binding_rows = {item.normalized_row_number: item for item in output.identity_bindings}
    if set(preview_rows) != set(binding_rows):
        missing = sorted(set(preview_rows) - set(binding_rows))
        extra = sorted(set(binding_rows) - set(preview_rows))
        violations.append(f"identity-binding row coverage mismatch: missing={missing}, extra={extra}")
    for row_number, realization_id in preview_rows.items():
        binding = binding_rows.get(row_number)
        if binding is None:
            continue
        if realization_id is not None and binding.normalized_identity != realization_id:
            violations.append(
                f"row {row_number} identity changed: preview={realization_id!r}, "
                f"binding={binding.normalized_identity!r}"
            )

    expected_bindings = [item.to_canonical() for item in fixture.expected_identity_bindings]
    observed_bindings = [
        item.to_canonical()
        for item in sorted(output.identity_bindings, key=lambda value: value.normalized_row_number)
    ]
    if expected_bindings and observed_bindings != expected_bindings:
        violations.append("source identity bindings differ from the fixture oracle")

    accepted_ids = tuple(item.realization_id for item in preview.accepted)
    rejected_rows = tuple(item.source_row_number for item in preview.rejected)
    if accepted_ids != fixture.expected_accepted_ids:
        violations.append(
            f"accepted identities differ: expected={fixture.expected_accepted_ids}, "
            f"observed={accepted_ids}"
        )
    if rejected_rows != fixture.expected_rejected_rows:
        violations.append(
            f"rejected rows differ: expected={fixture.expected_rejected_rows}, "
            f"observed={rejected_rows}"
        )

    by_id = {item.realization_id: item for item in preview.accepted}
    for realization_id, evidence_class in fixture.expected_evidence_classes.items():
        row = by_id.get(realization_id)
        if row is None:
            violations.append(f"expected evidence identity {realization_id!r} was not accepted")
        elif row.evidence_class != evidence_class:
            violations.append(
                f"evidence class changed for {realization_id!r}: "
                f"expected={evidence_class}, observed={row.evidence_class}"
            )
    observed_units = {
        mapping.coordinate_id: mapping.unit for mapping in output.mapping_profile.coordinates
    }
    for coordinate_id, unit in fixture.expected_units.items():
        if observed_units.get(coordinate_id) != unit:
            violations.append(
                f"unit changed for {coordinate_id!r}: expected={unit!r}, "
                f"observed={observed_units.get(coordinate_id)!r}"
            )
    return violations, preview


def run_source_adapter_conformance(
    definition: SourceAdapterDefinition,
    adapter: SourceAdapter,
    fixtures: Sequence[SourceAdapterFixture],
    *,
    registry: QuantityRegistry = DEFAULT_REGISTRY,
) -> SourceAdapterConformanceReport:
    """Execute the complete deterministic adapter conformance suite.

    The function never invokes a remote system.  Every input is supplied as
    immutable fixture bytes.  Unknown exceptions are failures; only an
    explicit :class:`SourceAdapterRefusal` satisfies a refusal fixture.
    """
    if not isinstance(definition, SourceAdapterDefinition):
        raise SourceAdapterError("definition MUST be SourceAdapterDefinition")
    if not callable(adapter):
        raise SourceAdapterError("adapter MUST be callable")
    fixtures = tuple(fixtures)
    identifiers = [item.fixture_id for item in fixtures]
    if len(set(identifiers)) != len(identifiers):
        raise SourceAdapterError("fixture identifiers contain duplicates")

    coverage = {category: 0 for category in sorted(AdapterFixtureCategory.REQUIRED)}
    requirement_coverage = {
        requirement: 0
        for requirement in sorted(AdapterConformanceRequirement.REQUIRED)
    }
    for fixture in fixtures:
        coverage[fixture.category] += 1
        for requirement in fixture.requirements:
            requirement_coverage[requirement] += 1
    report_violations = tuple(
        f"required fixture category {category} is absent"
        for category, count in coverage.items()
        if count == 0
    ) + tuple(
        f"required conformance requirement {requirement} is absent"
        for requirement, count in requirement_coverage.items()
        if count == 0
    )

    # This entry point is intentionally an in-process conformance runner.  A
    # declaration of SANDBOXED_PROCESS is a promise about observed execution,
    # not permission to call the adapter directly and repeat that promise in a
    # report.  Refuse before invoking untrusted code.  A future sandbox runner
    # must supply independently checkable isolation evidence and set the
    # observed profile itself.
    if definition.execution_profile != REVIEWED_IN_PROCESS:
        refusal = (
            "run_source_adapter_conformance observes REVIEWED_IN_PROCESS only; "
            f"declared profile {definition.execution_profile} was not executed because no "
            "verifier-owned sandbox evidence was supplied"
        )
        return SourceAdapterConformanceReport(
            definition=definition,
            observed_execution_profile=NOT_EXECUTED,
            cases=tuple(
                SourceAdapterCaseResult(
                    fixture_id=fixture.fixture_id,
                    category=fixture.category,
                    requirements=fixture.requirements,
                    expected_status=fixture.expected_status,
                    observed_status="NOT_RUN",
                    passed=False,
                    violations=(refusal,),
                )
                for fixture in fixtures
            ),
            coverage=coverage,
            requirement_coverage=requirement_coverage,
            violations=report_violations + (refusal,),
        )

    cases: List[SourceAdapterCaseResult] = []
    for fixture in fixtures:
        if fixture.request.media_type not in definition.input_media_types and (
            fixture.expected_status == AdapterExpectedStatus.SUCCEEDED
        ):
            cases.append(SourceAdapterCaseResult(
                fixture_id=fixture.fixture_id,
                category=fixture.category,
                requirements=fixture.requirements,
                expected_status=fixture.expected_status,
                observed_status="NOT_RUN",
                passed=False,
                violations=("successful fixture media type is outside the adapter declaration",),
            ))
            continue
        try:
            first = adapter(fixture.request)
        except SourceAdapterRefusal as refusal:
            passed = (
                fixture.expected_status == AdapterExpectedStatus.REFUSED
                and refusal.code == fixture.expected_refusal_code
                and refusal.code in definition.failure_modes
            )
            violations: List[str] = []
            if fixture.expected_status != AdapterExpectedStatus.REFUSED:
                violations.append(f"adapter refused a success fixture with {refusal.code}")
            if refusal.code != fixture.expected_refusal_code:
                violations.append(
                    f"refusal code differs: expected={fixture.expected_refusal_code}, "
                    f"observed={refusal.code}"
                )
            if refusal.code not in definition.failure_modes:
                violations.append("refusal code is absent from the adapter definition")
            cases.append(SourceAdapterCaseResult(
                fixture_id=fixture.fixture_id,
                category=fixture.category,
                requirements=fixture.requirements,
                expected_status=fixture.expected_status,
                observed_status=AdapterExpectedStatus.REFUSED,
                passed=passed,
                violations=tuple(violations),
                refusal_code=refusal.code,
            ))
            continue
        except Exception as error:
            cases.append(SourceAdapterCaseResult(
                fixture_id=fixture.fixture_id,
                category=fixture.category,
                requirements=fixture.requirements,
                expected_status=fixture.expected_status,
                observed_status="FAILED",
                passed=False,
                violations=(f"uncontrolled exception: {type(error).__name__}: {error}",),
            ))
            continue

        if fixture.expected_status == AdapterExpectedStatus.REFUSED:
            cases.append(SourceAdapterCaseResult(
                fixture_id=fixture.fixture_id,
                category=fixture.category,
                requirements=fixture.requirements,
                expected_status=fixture.expected_status,
                observed_status=AdapterExpectedStatus.SUCCEEDED,
                passed=False,
                violations=("adapter accepted a fixture that must be refused",),
                output_hash=first.output_hash() if isinstance(first, SourceAdapterOutput) else None,
            ))
            continue
        if not isinstance(first, SourceAdapterOutput):
            cases.append(SourceAdapterCaseResult(
                fixture_id=fixture.fixture_id,
                category=fixture.category,
                requirements=fixture.requirements,
                expected_status=fixture.expected_status,
                observed_status="FAILED",
                passed=False,
                violations=("adapter returned a value other than SourceAdapterOutput",),
            ))
            continue

        violations = []
        preview: Optional[RegistryIntakePreview] = None
        try:
            violations, preview = _verify_output(
                definition, fixture.request, first, fixture, registry
            )
            replay = adapter(fixture.request)
            if not isinstance(replay, SourceAdapterOutput):
                violations.append("determinism replay returned a non-adapter output")
            else:
                replay_violations, replay_preview = _verify_output(
                    definition, fixture.request, replay, fixture, registry
                )
                violations.extend(f"replay: {item}" for item in replay_violations)
                if replay.output_hash() != first.output_hash():
                    violations.append("determinism replay output hash disagrees")
                if replay.normalized_source != first.normalized_source:
                    violations.append("determinism replay normalized bytes disagree")
                if replay_preview.preview_hash() != preview.preview_hash():
                    violations.append("determinism replay intake preview disagrees")
        except Exception as error:
            violations.append(f"output verification failed: {type(error).__name__}: {error}")

        cases.append(SourceAdapterCaseResult(
            fixture_id=fixture.fixture_id,
            category=fixture.category,
            requirements=fixture.requirements,
            expected_status=fixture.expected_status,
            observed_status=AdapterExpectedStatus.SUCCEEDED,
            passed=not violations,
            violations=tuple(violations),
            output_hash=first.output_hash(),
            preview_hash=preview.preview_hash() if preview is not None else None,
            accepted_count=len(preview.accepted) if preview is not None else 0,
            rejected_count=len(preview.rejected) if preview is not None else 0,
        ))

    return SourceAdapterConformanceReport(
        definition=definition,
        observed_execution_profile=REVIEWED_IN_PROCESS,
        cases=tuple(cases),
        coverage=coverage,
        requirement_coverage=requirement_coverage,
        violations=report_violations,
    )


def require_conformant_source_adapter(
    definition: SourceAdapterDefinition,
    adapter: SourceAdapter,
    fixtures: Sequence[SourceAdapterFixture],
    *,
    registry: QuantityRegistry = DEFAULT_REGISTRY,
) -> SourceAdapterConformanceReport:
    """Run the suite and raise unless every required category passes."""
    return run_source_adapter_conformance(
        definition, adapter, fixtures, registry=registry
    ).require_passed()
