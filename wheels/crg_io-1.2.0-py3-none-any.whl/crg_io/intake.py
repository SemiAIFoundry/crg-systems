"""Deterministic bring-your-own-registry intake preview and mapping profiles.

This module is an additive workbench boundary in front of the specification-37
importers.  It does not certify a decision and it does not write case state.  A
caller first builds a reusable :class:`RegistryMappingProfile`, previews a CSV
or JSON source, presents the canonical preview to a human, and only then asks
for an in-memory registry bundle while binding the exact preview hash.

The safety rules are intentionally narrow:

* mapping, quantity, unit, direction, numeric, identity, and evidence semantics
  are explicit and versioned;
* the governed quantity registry validates every declared unit and no implicit
  conversion is performed;
* binary JSON floats are refused in every mapped certifying field;
* duplicate, missing, unsupported, and unknown data remain visible;
* this path always emits ``EXPLICIT_IMPORTED_FAMILY``.  It has no argument by
  which an import can promote its own completeness claim; and
* materialization requires the hash of a freshly recomputed preview, preventing
  a source or mapping change between review and use.

The legacy ``import_tabular`` and ``import_json`` APIs remain unchanged for
compatibility.  New product surfaces should use this preview-first API.
"""
from __future__ import annotations

import csv
import io
import json
import os
import re
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple, Union

from crg_model.canonical import CanonicalizationError, canonical_json, content_hash
from crg_model.completeness import (
    ClaimScope,
    CompletenessBasis,
    CompletenessBasisType,
)
from crg_model.envelope import EvidenceClass
from crg_model.numeric import Exact
from crg_model.records import (
    Coordinate,
    CoordinateSchema,
    Direction,
    RealizationBundle,
    RealizationRecord,
    Signature,
)
from crg_model.units import DEFAULT_REGISTRY, QuantityRegistry

from .import_profile import (
    _LEGAL_TOKENS,
    ExactParseError,
    ImportProfileError,
    ImportReport,
    RejectedRow,
    file_fingerprint,
    parse_exact,
    parse_exact_value,
)

__all__ = [
    "INTAKE_IMPORTER_ID",
    "INTAKE_IMPORTER_VERSION",
    "MAPPING_PROFILE_SCHEMA_VERSION",
    "INTAKE_PREVIEW_SCHEMA_VERSION",
    "EXACT_RATIONAL_NUMERIC_PROFILE",
    "CSV_SOURCE",
    "JSON_SOURCE",
    "IntakeProfileError",
    "IntakeSourceError",
    "IntakeMaterializationError",
    "StaleIntakePreviewError",
    "SourceProvenance",
    "CoordinateFieldMapping",
    "AttributeFieldMapping",
    "RegistryMappingProfile",
    "IntakeDiagnostic",
    "RegistrySourceSnapshot",
    "PreviewCoordinate",
    "AcceptedIntakeRow",
    "RejectedIntakeRow",
    "RegistryIntakePreview",
    "preview_registry_intake",
    "materialize_registry_intake",
]


INTAKE_IMPORTER_ID = "crg-io.registry-intake"
INTAKE_IMPORTER_VERSION = "1.1.0"
MAPPING_PROFILE_SCHEMA_VERSION = "1.0.0"
INTAKE_PREVIEW_SCHEMA_VERSION = "1.0.0"
EXACT_RATIONAL_NUMERIC_PROFILE = "CRG_EXACT_RATIONAL"
CSV_SOURCE = "csv"
JSON_SOURCE = "json"
CSV_RECORD_PATH = "$rows"
JSON_ROOT_ARRAY = "$"

_SEMVER_RE = re.compile(r"^[0-9]+\.[0-9]+\.[0-9]+(?:[-+][0-9A-Za-z.-]+)?$")
_HASH_RE = re.compile(r"^sha256:[0-9a-f]{64}$")
_MISSING = object()


class IntakeProfileError(ImportProfileError):
    """The reusable mapping profile is structurally or semantically invalid."""


class IntakeSourceError(ImportProfileError):
    """The source cannot be deterministically inspected under the profile."""


class IntakeMaterializationError(ImportProfileError):
    """A reviewed preview cannot safely be materialized."""


class StaleIntakePreviewError(IntakeMaterializationError):
    """The expected preview hash no longer matches the source and profile."""


def _nonempty(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise IntakeProfileError(f"{label} MUST be a non-empty string")
    if "\x00" in value:
        raise IntakeProfileError(f"{label} MUST NOT contain NUL")
    return value


def _field_name(value: Any, label: str) -> str:
    field_name = _nonempty(value, label)
    if field_name.startswith(".") or field_name.endswith(".") or ".." in field_name:
        raise IntakeProfileError(
            f"{label} {field_name!r} is not a valid field path; path segments MUST be non-empty"
        )
    return field_name


def _strict_keys(
    record: Mapping[str, Any], *, allowed: Iterable[str], required: Iterable[str], label: str
) -> None:
    if not isinstance(record, Mapping):
        raise IntakeProfileError(f"{label} MUST be an object")
    allowed_set, required_set = set(allowed), set(required)
    unknown = set(record) - allowed_set
    missing = required_set - set(record)
    if unknown:
        raise IntakeProfileError(
            f"{label} contains unsupported field(s): " + ", ".join(sorted(map(str, unknown)))
        )
    if missing:
        raise IntakeProfileError(
            f"{label} is missing required field(s): " + ", ".join(sorted(missing))
        )


@dataclass(frozen=True)
class SourceProvenance:
    """Caller-declared identity of a source; deliberately contains no clock."""

    source_id: str
    source_name: str
    origin: str
    producer: Optional[str] = None
    source_version: Optional[str] = None

    def __post_init__(self) -> None:
        _nonempty(self.source_id, "source_id")
        _nonempty(self.source_name, "source_name")
        _nonempty(self.origin, "origin")
        if self.producer is not None:
            _nonempty(self.producer, "producer")
        if self.source_version is not None:
            _nonempty(self.source_version, "source_version")

    def to_canonical(self) -> Dict[str, Any]:
        record: Dict[str, Any] = {
            "source_id": self.source_id,
            "source_name": self.source_name,
            "origin": self.origin,
        }
        if self.producer is not None:
            record["producer"] = self.producer
        if self.source_version is not None:
            record["source_version"] = self.source_version
        return record


@dataclass(frozen=True)
class CoordinateFieldMapping:
    """One explicit source-field to governed-coordinate mapping."""

    source_field: str
    coordinate_id: str
    quantity: str
    unit: str
    direction: str
    numeric_profile: str
    unit_field: Optional[str] = None
    evidence_field: Optional[str] = None

    def __post_init__(self) -> None:
        _field_name(self.source_field, "coordinate source_field")
        _nonempty(self.coordinate_id, "coordinate_id")
        _nonempty(self.quantity, "coordinate quantity")
        _nonempty(self.unit, "coordinate unit")
        if self.direction not in Direction.ALL:
            raise IntakeProfileError(
                f"coordinate {self.coordinate_id!r} has unsupported direction "
                f"{self.direction!r}; expected one of {sorted(Direction.ALL)}"
            )
        if self.numeric_profile != EXACT_RATIONAL_NUMERIC_PROFILE:
            raise IntakeProfileError(
                f"coordinate {self.coordinate_id!r} requests unsupported numeric profile "
                f"{self.numeric_profile!r}; this intake boundary supports only "
                f"{EXACT_RATIONAL_NUMERIC_PROFILE!r}"
            )
        if self.unit_field is not None:
            _field_name(self.unit_field, "coordinate unit_field")
        if self.evidence_field is not None:
            _field_name(self.evidence_field, "coordinate evidence_field")

    def to_canonical(self) -> Dict[str, Any]:
        record: Dict[str, Any] = {
            "source_field": self.source_field,
            "coordinate_id": self.coordinate_id,
            "quantity": self.quantity,
            "unit": self.unit,
            "direction": self.direction,
            "numeric_profile": self.numeric_profile,
        }
        if self.unit_field is not None:
            record["unit_field"] = self.unit_field
        if self.evidence_field is not None:
            record["evidence_field"] = self.evidence_field
        return record

    @classmethod
    def from_canonical(cls, record: Mapping[str, Any]) -> "CoordinateFieldMapping":
        allowed = {
            "source_field", "coordinate_id", "quantity", "unit", "direction",
            "numeric_profile", "unit_field", "evidence_field",
        }
        required = {
            "source_field", "coordinate_id", "quantity", "unit", "direction",
            "numeric_profile",
        }
        _strict_keys(record, allowed=allowed, required=required, label="coordinate mapping")
        return cls(**dict(record))


@dataclass(frozen=True)
class AttributeFieldMapping:
    """An explicit non-coordinate source field preserved as realization metadata."""

    source_field: str
    attribute_id: str
    required: bool = False

    def __post_init__(self) -> None:
        _field_name(self.source_field, "attribute source_field")
        _nonempty(self.attribute_id, "attribute_id")
        if not isinstance(self.required, bool):
            raise IntakeProfileError("attribute required MUST be a boolean")

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "source_field": self.source_field,
            "attribute_id": self.attribute_id,
            "required": self.required,
        }

    @classmethod
    def from_canonical(cls, record: Mapping[str, Any]) -> "AttributeFieldMapping":
        _strict_keys(
            record,
            allowed={"source_field", "attribute_id", "required"},
            required={"source_field", "attribute_id", "required"},
            label="attribute mapping",
        )
        return cls(**dict(record))


@dataclass(frozen=True)
class RegistryMappingProfile:
    """Reusable, canonical mapping declaration for CSV or JSON registries."""

    profile_id: str
    profile_version: str
    source_format: str
    record_path: str
    identity_field: str
    coordinates: Tuple[CoordinateFieldMapping, ...]
    quantity_registry_version: str
    default_evidence_class: str
    evidence_field: Optional[str] = None
    feasibility_field: Optional[str] = None
    attributes: Tuple[AttributeFieldMapping, ...] = ()

    def __post_init__(self) -> None:
        _nonempty(self.profile_id, "profile_id")
        if not isinstance(self.profile_version, str) or not _SEMVER_RE.match(self.profile_version):
            raise IntakeProfileError("profile_version MUST be a semantic version")
        if self.source_format not in {CSV_SOURCE, JSON_SOURCE}:
            raise IntakeProfileError("source_format MUST be 'csv' or 'json'")
        _field_name(self.identity_field, "identity_field")
        if self.source_format == CSV_SOURCE and self.record_path != CSV_RECORD_PATH:
            raise IntakeProfileError("a CSV mapping profile MUST use record_path '$rows'")
        if self.source_format == JSON_SOURCE:
            if self.record_path != JSON_ROOT_ARRAY:
                _field_name(self.record_path, "record_path")
        object.__setattr__(self, "coordinates", tuple(self.coordinates))
        object.__setattr__(self, "attributes", tuple(self.attributes))
        if not self.coordinates:
            raise IntakeProfileError("a mapping profile MUST declare at least one coordinate")
        if not _HASH_RE.match(self.quantity_registry_version):
            raise IntakeProfileError("quantity_registry_version MUST be a sha256 content hash")
        if self.default_evidence_class not in EvidenceClass.ALL:
            raise IntakeProfileError(
                f"default_evidence_class {self.default_evidence_class!r} is unsupported; "
                f"expected one of {sorted(EvidenceClass.ALL)}"
            )
        if self.evidence_field is not None:
            _field_name(self.evidence_field, "evidence_field")
        if self.feasibility_field is not None:
            _field_name(self.feasibility_field, "feasibility_field")

        coordinate_ids = [item.coordinate_id for item in self.coordinates]
        value_fields = [item.source_field for item in self.coordinates]
        attribute_ids = [item.attribute_id for item in self.attributes]
        attribute_fields = [item.source_field for item in self.attributes]
        for values, label in (
            (coordinate_ids, "coordinate identifiers"),
            (value_fields, "coordinate source fields"),
            (attribute_ids, "attribute identifiers"),
            (attribute_fields, "attribute source fields"),
        ):
            duplicates = sorted({value for value in values if values.count(value) > 1})
            if duplicates:
                raise IntakeProfileError(
                    f"duplicate {label}: " + ", ".join(duplicates)
                )

        semantic_value_fields = {self.identity_field, *value_fields, *attribute_fields}
        if len(semantic_value_fields) != 1 + len(value_fields) + len(attribute_fields):
            raise IntakeProfileError(
                "identity, coordinate-value, and attribute source fields MUST be disjoint; "
                "one source value cannot silently acquire two semantics"
            )
        metadata_fields = {
            field_name
            for field_name in (
                self.evidence_field,
                self.feasibility_field,
                *(item.unit_field for item in self.coordinates),
                *(item.evidence_field for item in self.coordinates),
            )
            if field_name is not None
        }
        overlap = semantic_value_fields & metadata_fields
        if overlap:
            raise IntakeProfileError(
                "value fields cannot also serve as unit, evidence, or feasibility fields: "
                + ", ".join(sorted(overlap))
            )

    def validate(self, registry: QuantityRegistry = DEFAULT_REGISTRY) -> None:
        """Validate unit/quantity semantics against the exact governed registry."""
        actual_version = registry.version()
        if self.quantity_registry_version != actual_version:
            raise IntakeProfileError(
                "mapping profile quantity_registry_version does not match the active governed "
                f"registry: profile={self.quantity_registry_version}, active={actual_version}"
            )
        for mapping in self.coordinates:
            if not registry.has_quantity(mapping.quantity):
                raise IntakeProfileError(
                    f"coordinate {mapping.coordinate_id!r} declares unsupported quantity "
                    f"{mapping.quantity!r}"
                )
            if not registry.has_unit(mapping.unit):
                raise IntakeProfileError(
                    f"coordinate {mapping.coordinate_id!r} declares unsupported unit "
                    f"{mapping.unit!r}"
                )
            unit = registry.unit(mapping.unit)
            if unit.quantity_id != mapping.quantity:
                raise IntakeProfileError(
                    f"coordinate {mapping.coordinate_id!r}: unit {mapping.unit!r} measures "
                    f"{unit.quantity_id!r}, not declared quantity {mapping.quantity!r}"
                )

    def coordinate_schema(self, registry: QuantityRegistry = DEFAULT_REGISTRY) -> CoordinateSchema:
        self.validate(registry)
        return CoordinateSchema(
            coordinates=tuple(
                Coordinate(
                    identifier=item.coordinate_id,
                    quantity=item.quantity,
                    unit=item.unit,
                    direction=item.direction,
                )
                for item in self.coordinates
            )
        )

    def consumed_fields(self) -> Tuple[str, ...]:
        fields = {self.identity_field}
        if self.evidence_field is not None:
            fields.add(self.evidence_field)
        if self.feasibility_field is not None:
            fields.add(self.feasibility_field)
        for item in self.coordinates:
            fields.add(item.source_field)
            if item.unit_field is not None:
                fields.add(item.unit_field)
            if item.evidence_field is not None:
                fields.add(item.evidence_field)
        for item in self.attributes:
            fields.add(item.source_field)
        return tuple(sorted(fields))

    def to_canonical(self) -> Dict[str, Any]:
        record: Dict[str, Any] = {
            "record_type": "RegistryMappingProfile",
            "schema_version": MAPPING_PROFILE_SCHEMA_VERSION,
            "profile_id": self.profile_id,
            "profile_version": self.profile_version,
            "source_format": self.source_format,
            "record_path": self.record_path,
            "identity_field": self.identity_field,
            "coordinates": [item.to_canonical() for item in self.coordinates],
            "attributes": [item.to_canonical() for item in self.attributes],
            "quantity_registry_version": self.quantity_registry_version,
            "default_evidence_class": self.default_evidence_class,
            "policies": {
                "completeness": CompletenessBasisType.EXPLICIT_IMPORTED_FAMILY,
                "duplicate_identity": "REJECT_EVERY_OCCURRENCE_AFTER_FIRST",
                "unknown_fields": "REPORT_UNSUPPORTED",
                "unit_conversion": "NONE",
                "missing_feasibility": "KEEP_UNEVALUATED",
                "authority": "NON_AUTHORIZING_INTAKE",
            },
        }
        if self.evidence_field is not None:
            record["evidence_field"] = self.evidence_field
        if self.feasibility_field is not None:
            record["feasibility_field"] = self.feasibility_field
        return record

    def profile_hash(self) -> str:
        return content_hash(self.to_canonical())

    @classmethod
    def from_canonical(cls, record: Mapping[str, Any]) -> "RegistryMappingProfile":
        allowed = {
            "record_type", "schema_version", "profile_id", "profile_version",
            "source_format", "record_path", "identity_field", "coordinates",
            "attributes", "quantity_registry_version", "default_evidence_class",
            "evidence_field", "feasibility_field", "policies",
        }
        required = allowed - {"evidence_field", "feasibility_field"}
        _strict_keys(record, allowed=allowed, required=required, label="mapping profile")
        if record["record_type"] != "RegistryMappingProfile":
            raise IntakeProfileError("mapping profile record_type is unsupported")
        if record["schema_version"] != MAPPING_PROFILE_SCHEMA_VERSION:
            raise IntakeProfileError(
                f"mapping profile schema_version {record['schema_version']!r} is unsupported"
            )
        expected_policies = {
            "completeness": CompletenessBasisType.EXPLICIT_IMPORTED_FAMILY,
            "duplicate_identity": "REJECT_EVERY_OCCURRENCE_AFTER_FIRST",
            "unknown_fields": "REPORT_UNSUPPORTED",
            "unit_conversion": "NONE",
            "missing_feasibility": "KEEP_UNEVALUATED",
            "authority": "NON_AUTHORIZING_INTAKE",
        }
        if record["policies"] != expected_policies:
            raise IntakeProfileError(
                "mapping profile policies are unsupported; intake safety policies are fixed"
            )
        coordinates = record["coordinates"]
        attributes = record["attributes"]
        if not isinstance(coordinates, list) or not isinstance(attributes, list):
            raise IntakeProfileError("mapping profile coordinates and attributes MUST be lists")
        return cls(
            profile_id=record["profile_id"],
            profile_version=record["profile_version"],
            source_format=record["source_format"],
            record_path=record["record_path"],
            identity_field=record["identity_field"],
            coordinates=tuple(CoordinateFieldMapping.from_canonical(x) for x in coordinates),
            attributes=tuple(AttributeFieldMapping.from_canonical(x) for x in attributes),
            quantity_registry_version=record["quantity_registry_version"],
            default_evidence_class=record["default_evidence_class"],
            evidence_field=record.get("evidence_field"),
            feasibility_field=record.get("feasibility_field"),
        )


@dataclass(frozen=True)
class IntakeDiagnostic:
    code: str
    severity: str
    message: str
    field: Optional[str] = None
    coordinate_id: Optional[str] = None

    def __post_init__(self) -> None:
        _nonempty(self.code, "diagnostic code")
        if self.severity not in {"ERROR", "WARNING", "INFO"}:
            raise ValueError("diagnostic severity is unsupported")
        _nonempty(self.message, "diagnostic message")

    def to_canonical(self) -> Dict[str, Any]:
        record: Dict[str, Any] = {
            "code": self.code,
            "severity": self.severity,
            "message": self.message,
        }
        if self.field is not None:
            record["field"] = self.field
        if self.coordinate_id is not None:
            record["coordinate_id"] = self.coordinate_id
        return record


@dataclass(frozen=True)
class RegistrySourceSnapshot:
    provenance: SourceProvenance
    source_format: str
    media_type: str
    content_hash: str
    byte_length: int
    record_count: int
    source_fields: Tuple[str, ...]

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "provenance": self.provenance.to_canonical(),
            "source_format": self.source_format,
            "media_type": self.media_type,
            "content_hash": self.content_hash,
            "byte_length": self.byte_length,
            "record_count": self.record_count,
            "source_fields": list(self.source_fields),
        }

    def snapshot_hash(self) -> str:
        return content_hash(self.to_canonical())


@dataclass(frozen=True)
class PreviewCoordinate:
    coordinate_id: str
    source_field: str
    quantity: str
    unit: str
    direction: str
    source_value: Exact
    canonical_minimize_value: Exact
    evidence_class: str

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "coordinate_id": self.coordinate_id,
            "source_field": self.source_field,
            "quantity": self.quantity,
            "unit": self.unit,
            "direction": self.direction,
            "source_value": self.source_value.to_canonical(),
            "canonical_minimize_value": self.canonical_minimize_value.to_canonical(),
            "orientation": (
                "NEGATED_INTO_MINIMIZE_CONVENTION"
                if self.direction == Direction.MAXIMIZE else "AS_DECLARED"
            ),
            "evidence_class": self.evidence_class,
        }


@dataclass(frozen=True)
class AcceptedIntakeRow:
    source_row_number: int
    realization_id: str
    coordinates: Tuple[PreviewCoordinate, ...]
    legality: str
    evidence_class: str
    attributes: Mapping[str, Any] = field(default_factory=dict)
    diagnostics: Tuple[IntakeDiagnostic, ...] = ()

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "source_row_number": self.source_row_number,
            "realization_id": self.realization_id,
            "coordinates": [item.to_canonical() for item in self.coordinates],
            "legality": self.legality,
            "evidence_class": self.evidence_class,
            "attributes": dict(self.attributes),
            "diagnostics": [item.to_canonical() for item in self.diagnostics],
        }


@dataclass(frozen=True)
class RejectedIntakeRow:
    source_row_number: int
    realization_id: Optional[str]
    diagnostics: Tuple[IntakeDiagnostic, ...]

    def to_canonical(self) -> Dict[str, Any]:
        record: Dict[str, Any] = {
            "source_row_number": self.source_row_number,
            "diagnostics": [item.to_canonical() for item in self.diagnostics],
        }
        if self.realization_id is not None:
            record["realization_id"] = self.realization_id
        return record


@dataclass(frozen=True)
class RegistryIntakePreview:
    profile: RegistryMappingProfile
    source_snapshot: RegistrySourceSnapshot
    accepted: Tuple[AcceptedIntakeRow, ...]
    rejected: Tuple[RejectedIntakeRow, ...]
    diagnostics: Tuple[IntakeDiagnostic, ...]
    completeness_basis: CompletenessBasis
    predicted_bundle_hash: str

    @property
    def rows_read(self) -> int:
        return self.source_snapshot.record_count

    @property
    def ready_to_materialize(self) -> bool:
        return bool(self.accepted) and not self.rejected

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "record_type": "RegistryIntakePreview",
            "schema_version": INTAKE_PREVIEW_SCHEMA_VERSION,
            "authority": "NON_AUTHORIZING",
            "mutation_performed": False,
            "profile": self.profile.to_canonical(),
            "profile_hash": self.profile.profile_hash(),
            "source_snapshot": self.source_snapshot.to_canonical(),
            "source_snapshot_hash": self.source_snapshot.snapshot_hash(),
            "rows_read": self.rows_read,
            "accepted": [item.to_canonical() for item in self.accepted],
            "rejected": [item.to_canonical() for item in self.rejected],
            "diagnostics": [item.to_canonical() for item in self.diagnostics],
            "completeness_basis": self.completeness_basis.to_canonical(),
            "claim_scope": ClaimScope.RELATIVE_EXPLICIT_FAMILY,
            "ready_to_materialize": self.ready_to_materialize,
            "predicted_bundle_hash": self.predicted_bundle_hash,
        }

    def preview_hash(self) -> str:
        return content_hash(self.to_canonical())

    def canonical_json(self) -> str:
        return canonical_json(self.to_canonical())


class _BareJSONFloat(str):
    """A lexical bare JSON decimal, kept distinguishable from a quoted string."""


@dataclass(frozen=True)
class _RawRow:
    row_number: int
    record: Optional[Mapping[str, Any]]
    structural_error: Optional[str] = None


def _read_source(path: Union[str, os.PathLike]) -> bytes:
    try:
        with open(os.fspath(path), "rb") as handle:
            return handle.read()
    except OSError as exc:
        raise IntakeSourceError(f"cannot read registry source: {exc}") from exc


def _decode_source(raw: bytes) -> str:
    try:
        return raw.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise IntakeSourceError(f"registry source is not valid UTF-8: {exc}") from exc


def _csv_rows(raw: bytes) -> Tuple[Tuple[str, ...], List[_RawRow]]:
    text = _decode_source(raw)
    try:
        materialized = list(csv.reader(io.StringIO(text), strict=True))
    except csv.Error as exc:
        raise IntakeSourceError(f"registry source is not valid CSV: {exc}") from exc
    if not materialized:
        raise IntakeSourceError("CSV registry contains no header row")
    header = tuple(materialized[0])
    if not header or any(not value.strip() for value in header):
        raise IntakeSourceError("CSV header fields MUST be non-empty")
    duplicates = sorted({name for name in header if header.count(name) > 1})
    if duplicates:
        raise IntakeSourceError("CSV header contains duplicate fields: " + ", ".join(duplicates))
    rows: List[_RawRow] = []
    for index, cells in enumerate(materialized[1:], start=2):
        if len(cells) != len(header):
            rows.append(_RawRow(
                row_number=index,
                record=None,
                structural_error=(
                    f"row has {len(cells)} cells while the header declares {len(header)}; "
                    "cells are never padded, truncated, or guessed"
                ),
            ))
        else:
            rows.append(_RawRow(index, dict(zip(header, cells))))
    return header, rows


def _constant_error(token: str) -> Any:
    raise ValueError(f"non-finite JSON number {token!r} is unsupported")


def _resolve_json_path(value: Any, path: str) -> Any:
    current = value
    for segment in path.split("."):
        if not isinstance(current, Mapping) or segment not in current:
            return _MISSING
        current = current[segment]
    return current


def _flatten_paths(value: Any, prefix: str = "") -> Tuple[str, ...]:
    if isinstance(value, Mapping):
        paths: List[str] = []
        for key in sorted(value):
            path = f"{prefix}.{key}" if prefix else str(key)
            child = value[key]
            if isinstance(child, Mapping) and child:
                paths.extend(_flatten_paths(child, path))
            else:
                paths.append(path)
        return tuple(paths)
    return (prefix,) if prefix else ()


def _json_rows(raw: bytes, record_path: str) -> Tuple[Tuple[str, ...], List[_RawRow]]:
    try:
        document = json.loads(
            _decode_source(raw),
            parse_float=_BareJSONFloat,
            parse_constant=_constant_error,
        )
    except (json.JSONDecodeError, ValueError) as exc:
        raise IntakeSourceError(f"registry source is not valid strict JSON: {exc}") from exc
    records = document if record_path == JSON_ROOT_ARRAY else _resolve_json_path(document, record_path)
    if records is _MISSING:
        raise IntakeSourceError(f"JSON record_path {record_path!r} is absent")
    if not isinstance(records, list):
        raise IntakeSourceError(f"JSON record_path {record_path!r} MUST resolve to a list")
    fields: set[str] = set()
    # A document-level completeness/schema declaration is not part of a row
    # mapping and cannot strengthen this import.  Keep every sibling of the
    # explicit record container visible as an unsupported document field rather
    # than silently ignoring it.
    if isinstance(document, Mapping) and record_path != JSON_ROOT_ARRAY:
        record_container = record_path.split(".", 1)[0]
        for key in sorted(document):
            if key == record_container:
                continue
            document_paths = _flatten_paths(document[key], f"$document.{key}")
            fields.update(document_paths or (f"$document.{key}",))
    rows: List[_RawRow] = []
    for index, record in enumerate(records, start=1):
        if not isinstance(record, Mapping):
            rows.append(_RawRow(
                row_number=index,
                record=None,
                structural_error=f"record is {type(record).__name__}, not an object",
            ))
            continue
        fields.update(_flatten_paths(record))
        rows.append(_RawRow(index, record))
    return tuple(sorted(fields)), rows


def _value_of(record: Mapping[str, Any], field_name: str, source_format: str) -> Any:
    if source_format == CSV_SOURCE:
        return record.get(field_name, _MISSING)
    return _resolve_json_path(record, field_name)


def _is_missing(value: Any) -> bool:
    return value is _MISSING or value is None or (isinstance(value, str) and not value.strip())


def _identity_of(value: Any) -> str:
    if isinstance(value, bool) or isinstance(value, _BareJSONFloat) or isinstance(value, float):
        raise ValueError("identity MUST be an exact text or integer value, not boolean/float")
    if not isinstance(value, (str, int)):
        raise ValueError("identity MUST be an exact text or integer value")
    identity = str(value).strip()
    if not identity:
        raise ValueError("identity is empty")
    if "\x00" in identity:
        raise ValueError("identity contains NUL")
    return identity


def _evidence_of(value: Any, *, fallback: str) -> Tuple[str, bool]:
    if _is_missing(value):
        return fallback, True
    if not isinstance(value, str):
        raise ValueError("evidence class MUST be text")
    token = value.strip().upper()
    if token not in EvidenceClass.ALL:
        raise ValueError(
            f"unsupported evidence class {token!r}; expected one of {sorted(EvidenceClass.ALL)}"
        )
    return token, False


def _legality_of(value: Any) -> Tuple[str, bool]:
    if _is_missing(value):
        return "UNEVALUATED", True
    if isinstance(value, bool):
        return ("LEGAL" if value else "INFEASIBLE"), False
    if not isinstance(value, (str, int)):
        raise ValueError("feasibility MUST be a recognized text token or boolean")
    token = str(value).strip().upper()
    if token not in _LEGAL_TOKENS:
        raise ValueError(
            f"unsupported feasibility token {token!r}; expected one of "
            + ", ".join(sorted(_LEGAL_TOKENS))
        )
    return _LEGAL_TOKENS[token], False


def _assert_certifying_value(value: Any, field_name: str) -> None:
    if isinstance(value, (_BareJSONFloat, float)):
        raise ValueError(
            f"mapped certifying field {field_name!r} contains a bare binary JSON float; "
            "use an integer or quoted exact decimal/rational"
        )
    if isinstance(value, Mapping):
        for key, child in value.items():
            if not isinstance(key, str):
                raise ValueError(f"mapped field {field_name!r} has a non-text object key")
            _assert_certifying_value(child, field_name)
    elif isinstance(value, (list, tuple)):
        for child in value:
            _assert_certifying_value(child, field_name)
    try:
        canonical_json(value)
    except CanonicalizationError as exc:
        raise ValueError(f"mapped field {field_name!r} is not canonical CRG content: {exc}") from exc


def _exact_of(value: Any, source_format: str, field_name: str) -> Exact:
    if isinstance(value, _BareJSONFloat):
        raise ExactParseError(
            f"{field_name} is a bare JSON decimal {str(value)!r}; quote it to preserve its "
            "exact identity"
        )
    if source_format == CSV_SOURCE:
        if not isinstance(value, str):
            raise ExactParseError(f"{field_name} is not a text cell")
        return parse_exact(value)
    return parse_exact_value(value, field_name=field_name)


def _basis_for(
    snapshot: RegistrySourceSnapshot,
    profile: RegistryMappingProfile,
    rejected_count: int,
) -> CompletenessBasis:
    omissions = [
        "candidates absent from the supplied source are not represented and are not claimed",
    ]
    if rejected_count:
        omissions.append(
            f"{rejected_count} source row(s) were refused and are not represented; review the "
            "canonical intake preview"
        )
    return CompletenessBasis(
        basis_type=CompletenessBasisType.EXPLICIT_IMPORTED_FAMILY,
        declared_universe=(
            f"accepted rows of declared source {snapshot.provenance.source_id!r} "
            f"({snapshot.provenance.source_name})"
        ),
        source_or_generator_hash=snapshot.content_hash,
        generator_versions=(
            f"{INTAKE_IMPORTER_ID}@{INTAKE_IMPORTER_VERSION}",
            f"mapping-profile:{profile.profile_hash()}",
        ),
        closure_procedure=(
            "preview-bound registry intake; no enumeration, generator closure, or universe "
            "completeness is asserted"
        ),
        known_omissions=tuple(omissions),
    )


def _unknown_fields(
    fields: Sequence[str], consumed: Sequence[str], source_format: str
) -> Tuple[str, ...]:
    consumed_set = set(consumed)
    unknown: List[str] = []
    for field_name in fields:
        if field_name in consumed_set:
            continue
        if source_format == JSON_SOURCE and any(
            field_name.startswith(mapped + ".") for mapped in consumed_set
        ):
            continue
        unknown.append(field_name)
    return tuple(sorted(unknown))


def _bundle_from_rows(
    profile: RegistryMappingProfile,
    snapshot: RegistrySourceSnapshot,
    accepted: Sequence[AcceptedIntakeRow],
    rejected: Sequence[RejectedIntakeRow],
    basis: CompletenessBasis,
    registry: QuantityRegistry,
) -> RealizationBundle:
    schema = profile.coordinate_schema(registry)
    realizations: List[RealizationRecord] = []
    for row in accepted:
        attributes = dict(row.attributes)
        attributes["source_provenance"] = {
            **snapshot.provenance.to_canonical(),
            "source_fingerprint": snapshot.content_hash,
            "source_row_number": row.source_row_number,
            "mapping_profile_hash": profile.profile_hash(),
        }
        coordinate_evidence = {
            item.coordinate_id: item.evidence_class for item in row.coordinates
        }
        attributes["coordinate_evidence_classes"] = coordinate_evidence
        realizations.append(RealizationRecord(
            realization_id=row.realization_id,
            signature=Signature([item.canonical_minimize_value for item in row.coordinates]),
            attributes=attributes,
            legality=row.legality,
            evidence_class=row.evidence_class,
            generator=f"{INTAKE_IMPORTER_ID}@{INTAKE_IMPORTER_VERSION}",
        ))
    binding_hash = content_hash({
        "source_fingerprint": snapshot.content_hash,
        "mapping_profile_hash": profile.profile_hash(),
    })
    return RealizationBundle(
        bundle_id="registry-" + binding_hash.split(":", 1)[1][:20],
        schema=schema,
        realizations=realizations,
        completeness=basis,
        rejected=[item.to_canonical() for item in rejected],
        source_fingerprint=snapshot.content_hash,
    )


def preview_registry_intake(
    path: Union[str, os.PathLike],
    *,
    profile: RegistryMappingProfile,
    provenance: SourceProvenance,
    registry: QuantityRegistry = DEFAULT_REGISTRY,
) -> RegistryIntakePreview:
    """Return a canonical, non-mutating preview of one source under ``profile``."""
    profile.validate(registry)
    raw = _read_source(path)
    if profile.source_format == CSV_SOURCE:
        source_fields, raw_rows = _csv_rows(raw)
        media_type = "text/csv"
    else:
        source_fields, raw_rows = _json_rows(raw, profile.record_path)
        media_type = "application/json"

    snapshot = RegistrySourceSnapshot(
        provenance=provenance,
        source_format=profile.source_format,
        media_type=media_type,
        content_hash=file_fingerprint(raw),
        byte_length=len(raw),
        record_count=len(raw_rows),
        source_fields=tuple(source_fields),
    )
    unknown = _unknown_fields(source_fields, profile.consumed_fields(), profile.source_format)
    global_diagnostics = tuple(
        IntakeDiagnostic(
            code="UNKNOWN_FIELD",
            severity="WARNING",
            message="source field is not mapped and will remain unsupported",
            field=field_name,
        )
        for field_name in unknown
    )

    accepted: List[AcceptedIntakeRow] = []
    rejected: List[RejectedIntakeRow] = []
    seen: Dict[str, int] = {}

    for raw_row in raw_rows:
        if raw_row.structural_error is not None or raw_row.record is None:
            rejected.append(RejectedIntakeRow(
                source_row_number=raw_row.row_number,
                realization_id=None,
                diagnostics=(IntakeDiagnostic(
                    code="ROW_SHAPE_MISMATCH",
                    severity="ERROR",
                    message=raw_row.structural_error or "source record is unavailable",
                ),),
            ))
            continue
        record = raw_row.record
        row_errors: List[IntakeDiagnostic] = []
        row_warnings: List[IntakeDiagnostic] = []
        identity_value = _value_of(record, profile.identity_field, profile.source_format)
        realization_id: Optional[str] = None
        if _is_missing(identity_value):
            row_errors.append(IntakeDiagnostic(
                code="MISSING_IDENTITY",
                severity="ERROR",
                message="mapped identity field is absent or empty; CRG will not invent one",
                field=profile.identity_field,
            ))
        else:
            try:
                realization_id = _identity_of(identity_value)
            except ValueError as exc:
                row_errors.append(IntakeDiagnostic(
                    code="AMBIGUOUS_IDENTITY",
                    severity="ERROR",
                    message=str(exc),
                    field=profile.identity_field,
                ))
        if realization_id is not None:
            if realization_id in seen:
                row_errors.append(IntakeDiagnostic(
                    code="DUPLICATE_IDENTITY",
                    severity="ERROR",
                    message=(
                        f"identity first appeared at source row {seen[realization_id]}; later "
                        "occurrences are refused, never merged or overwritten"
                    ),
                    field=profile.identity_field,
                ))
            else:
                # Bind the first occurrence even if another mapped field later fails.  A
                # malformed first row plus a valid duplicate is still an ambiguous source.
                seen[realization_id] = raw_row.row_number

        preview_coordinates: List[PreviewCoordinate] = []
        for mapping in profile.coordinates:
            value = _value_of(record, mapping.source_field, profile.source_format)
            if _is_missing(value):
                row_errors.append(IntakeDiagnostic(
                    code="MISSING_COORDINATE",
                    severity="ERROR",
                    message="mapped coordinate is absent; it will not be defaulted to zero",
                    field=mapping.source_field,
                    coordinate_id=mapping.coordinate_id,
                ))
                continue
            try:
                exact_value = _exact_of(value, profile.source_format, mapping.source_field)
            except ExactParseError as exc:
                row_errors.append(IntakeDiagnostic(
                    code="INVALID_EXACT_NUMBER",
                    severity="ERROR",
                    message=str(exc),
                    field=mapping.source_field,
                    coordinate_id=mapping.coordinate_id,
                ))
                continue

            if mapping.unit_field is not None:
                unit_value = _value_of(record, mapping.unit_field, profile.source_format)
                if _is_missing(unit_value):
                    row_errors.append(IntakeDiagnostic(
                        code="MISSING_UNIT",
                        severity="ERROR",
                        message=f"mapped unit field must explicitly equal {mapping.unit!r}",
                        field=mapping.unit_field,
                        coordinate_id=mapping.coordinate_id,
                    ))
                    continue
                if not isinstance(unit_value, str) or unit_value.strip() != mapping.unit:
                    row_errors.append(IntakeDiagnostic(
                        code="UNIT_MISMATCH",
                        severity="ERROR",
                        message=(
                            f"source unit {unit_value!r} does not exactly match declared unit "
                            f"{mapping.unit!r}; this profile performs no implicit conversion"
                        ),
                        field=mapping.unit_field,
                        coordinate_id=mapping.coordinate_id,
                    ))
                    continue

            evidence_field = mapping.evidence_field or profile.evidence_field
            evidence_value = (
                _MISSING if evidence_field is None
                else _value_of(record, evidence_field, profile.source_format)
            )
            try:
                evidence, defaulted = _evidence_of(
                    evidence_value, fallback=profile.default_evidence_class
                )
            except ValueError as exc:
                row_errors.append(IntakeDiagnostic(
                    code="UNSUPPORTED_EVIDENCE_CLASS",
                    severity="ERROR",
                    message=str(exc),
                    field=evidence_field,
                    coordinate_id=mapping.coordinate_id,
                ))
                continue
            if defaulted:
                row_warnings.append(IntakeDiagnostic(
                    code="MISSING_EVIDENCE_DEFAULTED",
                    severity="WARNING",
                    message=(
                        f"no coordinate evidence class was supplied; the profile's explicit "
                        f"default {profile.default_evidence_class!r} applies"
                    ),
                    field=evidence_field,
                    coordinate_id=mapping.coordinate_id,
                ))

            canonical_value = -exact_value if mapping.direction == Direction.MAXIMIZE else exact_value
            preview_coordinates.append(PreviewCoordinate(
                coordinate_id=mapping.coordinate_id,
                source_field=mapping.source_field,
                quantity=mapping.quantity,
                unit=mapping.unit,
                direction=mapping.direction,
                source_value=exact_value,
                canonical_minimize_value=canonical_value,
                evidence_class=evidence,
            ))

        if profile.feasibility_field is None:
            feasibility_value = _MISSING
        else:
            feasibility_value = _value_of(
                record, profile.feasibility_field, profile.source_format
            )
        try:
            legality, missing_feasibility = _legality_of(feasibility_value)
        except ValueError as exc:
            legality, missing_feasibility = "UNEVALUATED", False
            row_errors.append(IntakeDiagnostic(
                code="UNSUPPORTED_FEASIBILITY",
                severity="ERROR",
                message=str(exc),
                field=profile.feasibility_field,
            ))
        if missing_feasibility:
            row_warnings.append(IntakeDiagnostic(
                code="MISSING_FEASIBILITY",
                severity="WARNING",
                message="no feasibility verdict was supplied; candidate remains UNEVALUATED",
                field=profile.feasibility_field,
            ))

        attributes: Dict[str, Any] = {}
        for mapping in profile.attributes:
            value = _value_of(record, mapping.source_field, profile.source_format)
            if _is_missing(value):
                diagnostic = IntakeDiagnostic(
                    code="MISSING_REQUIRED_ATTRIBUTE" if mapping.required else "MISSING_ATTRIBUTE",
                    severity="ERROR" if mapping.required else "WARNING",
                    message=(
                        "required mapped attribute is absent"
                        if mapping.required else "optional mapped attribute is absent and remains missing"
                    ),
                    field=mapping.source_field,
                )
                (row_errors if mapping.required else row_warnings).append(diagnostic)
                continue
            try:
                _assert_certifying_value(value, mapping.source_field)
            except ValueError as exc:
                row_errors.append(IntakeDiagnostic(
                    code="NONCANONICAL_ATTRIBUTE",
                    severity="ERROR",
                    message=str(exc),
                    field=mapping.source_field,
                ))
                continue
            attributes[mapping.attribute_id] = value

        if row_errors:
            rejected.append(RejectedIntakeRow(
                source_row_number=raw_row.row_number,
                realization_id=realization_id,
                diagnostics=tuple(row_errors + row_warnings),
            ))
            continue

        evidence_values = {item.evidence_class for item in preview_coordinates}
        record_evidence = (
            next(iter(evidence_values)) if len(evidence_values) == 1 else EvidenceClass.IMPORTED
        )
        accepted.append(AcceptedIntakeRow(
            source_row_number=raw_row.row_number,
            realization_id=realization_id or "",  # guarded by row_errors above
            coordinates=tuple(preview_coordinates),
            legality=legality,
            evidence_class=record_evidence,
            attributes=attributes,
            diagnostics=tuple(row_warnings),
        ))

    if not accepted:
        global_diagnostics = global_diagnostics + (IntakeDiagnostic(
            code="EMPTY_ACCEPTED_FAMILY",
            severity="WARNING",
            message="no source row was accepted; no decision can be certified over this preview",
        ),)

    basis = _basis_for(snapshot, profile, len(rejected))
    bundle = _bundle_from_rows(profile, snapshot, accepted, rejected, basis, registry)
    return RegistryIntakePreview(
        profile=profile,
        source_snapshot=snapshot,
        accepted=tuple(accepted),
        rejected=tuple(rejected),
        diagnostics=global_diagnostics,
        completeness_basis=basis,
        predicted_bundle_hash=bundle.bundle_hash(),
    )


def _report_from_preview(
    path: Union[str, os.PathLike],
    preview: RegistryIntakePreview,
    bundle: RealizationBundle,
) -> ImportReport:
    profile = preview.profile
    field_mapping: Dict[str, str] = {profile.identity_field: "realization_id"}
    coordinate_mapping: Dict[str, Dict[str, str]] = {}
    quantity_mappings: Dict[str, str] = {}
    for mapping in profile.coordinates:
        field_mapping[mapping.source_field] = f"signature.{mapping.coordinate_id}"
        coordinate_mapping[mapping.source_field] = {
            "coordinate": mapping.coordinate_id,
            "quantity": mapping.quantity,
            "unit": mapping.unit,
            "direction": mapping.direction,
            "orientation": (
                "NEGATED_INTO_MINIMIZE_CONVENTION"
                if mapping.direction == Direction.MAXIMIZE else "AS_DECLARED"
            ),
            "numeric_profile": mapping.numeric_profile,
        }
        quantity_mappings[mapping.coordinate_id] = f"{mapping.quantity} [{mapping.unit}]"
        if mapping.unit_field is not None:
            field_mapping[mapping.unit_field] = f"unit.{mapping.coordinate_id}"
        if mapping.evidence_field is not None:
            field_mapping[mapping.evidence_field] = f"evidence.{mapping.coordinate_id}"
    if profile.evidence_field is not None:
        field_mapping[profile.evidence_field] = "evidence.*"
    if profile.feasibility_field is not None:
        field_mapping[profile.feasibility_field] = "legality"
    for mapping in profile.attributes:
        field_mapping[mapping.source_field] = f"attributes.{mapping.attribute_id}"

    unknown = tuple(
        item.field for item in preview.diagnostics
        if item.code == "UNKNOWN_FIELD" and item.field is not None
    )
    rejected = tuple(RejectedRow(
        row_number=item.source_row_number,
        realization_id=item.realization_id,
        reason="; ".join(diagnostic.message for diagnostic in item.diagnostics),
        column=next((diagnostic.field for diagnostic in item.diagnostics if diagnostic.field), None),
    ) for item in preview.rejected)
    row_warnings = [
        diagnostic.message
        for row in preview.accepted
        for diagnostic in row.diagnostics
    ]
    missing_evidence = tuple(
        diagnostic.message
        for row in preview.accepted
        for diagnostic in row.diagnostics
        if diagnostic.code in {"MISSING_EVIDENCE_DEFAULTED", "MISSING_FEASIBILITY"}
    )
    warnings = [item.message for item in preview.diagnostics]
    warnings.extend(row_warnings)
    if preview.rejected:
        warnings.append(
            f"{len(preview.rejected)} source row(s) were refused and remain disclosed"
        )
    return ImportReport(
        source_path=os.fspath(path),
        source_fingerprint=preview.source_snapshot.content_hash,
        importer_id=INTAKE_IMPORTER_ID,
        importer_version=INTAKE_IMPORTER_VERSION,
        rows_read=preview.rows_read,
        accepted=tuple(item.realization_id for item in preview.accepted),
        rejected=rejected,
        field_mapping=field_mapping,
        coordinate_mapping=coordinate_mapping,
        quantity_mappings=quantity_mappings,
        unit_conversions=(
            "none applied; every mapped source unit must exactly equal its governed declared unit",
        ),
        dropped_fields=unknown,
        unsupported_fields=unknown,
        duplicate_handling="REJECT_EVERY_OCCURRENCE_AFTER_FIRST",
        identity_policy=(
            f"explicit field {profile.identity_field!r}; exact text or integer, non-empty, "
            "case-sensitive, unique after surrounding-whitespace removal"
        ),
        missing_evidence=missing_evidence,
        inferred_fields=(
            "none; all identity, coordinate, quantity, unit, direction, numeric, and evidence "
            "semantics are declared by the mapping profile",
        ),
        user_overrides=(f"mapping_profile_hash = {profile.profile_hash()}",),
        warnings=tuple(warnings),
        completeness_basis=preview.completeness_basis,
        claim_scope=ClaimScope.RELATIVE_EXPLICIT_FAMILY,
        canonical_output_hash=bundle.bundle_hash(),
        bundle_id=bundle.bundle_id,
    )


def materialize_registry_intake(
    path: Union[str, os.PathLike],
    *,
    profile: RegistryMappingProfile,
    provenance: SourceProvenance,
    expected_preview_hash: str,
    accept_partial: bool = False,
    registry: QuantityRegistry = DEFAULT_REGISTRY,
) -> Tuple[RealizationBundle, ImportReport, RegistryIntakePreview]:
    """Re-preview and materialize only the exact mapping/source a caller reviewed.

    This function creates in-memory records only; persistence remains the
    responsibility of a case-level caller.  Rejected rows block by default.
    ``accept_partial=True`` is an explicit acknowledgement, and the resulting
    completeness basis still names every refused row as an omission.
    """
    if not isinstance(expected_preview_hash, str) or not _HASH_RE.match(expected_preview_hash):
        raise IntakeMaterializationError("expected_preview_hash MUST be a sha256 content hash")
    if not isinstance(accept_partial, bool):
        raise IntakeMaterializationError("accept_partial MUST be a boolean")
    preview = preview_registry_intake(
        path, profile=profile, provenance=provenance, registry=registry
    )
    actual_hash = preview.preview_hash()
    if actual_hash != expected_preview_hash:
        raise StaleIntakePreviewError(
            "source or mapping differs from the reviewed canonical preview: "
            f"expected={expected_preview_hash}, actual={actual_hash}"
        )
    if not preview.accepted:
        raise IntakeMaterializationError(
            "the reviewed preview contains no accepted rows; an empty registry is not materialized"
        )
    if preview.rejected and not accept_partial:
        raise IntakeMaterializationError(
            f"the reviewed preview contains {len(preview.rejected)} rejected row(s); correct "
            "the source or explicitly acknowledge partial import"
        )
    bundle = _bundle_from_rows(
        profile,
        preview.source_snapshot,
        preview.accepted,
        preview.rejected,
        preview.completeness_basis,
        registry,
    )
    if bundle.bundle_hash() != preview.predicted_bundle_hash:
        raise IntakeMaterializationError(
            "internal preview/materialization disagreement; no registry may be persisted"
        )
    return bundle, _report_from_preview(path, preview, bundle), preview
