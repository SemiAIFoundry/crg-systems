"""Additional Registry Import Profile formats and importer dispatch.

This module closes the section 37.2/37.5 baseline beyond delimited text:
spreadsheet mapping, Parquet, compiler-graph output, and registered domain
exports.  It deliberately reuses :mod:`crg_io.import_profile`'s one exact,
fail-closed record pipeline so format choice cannot change CRG semantics.
"""
from __future__ import annotations

import json
import os
import re
import zipfile
from dataclasses import dataclass
from decimal import Decimal
from typing import Any, Callable, Dict, List, Mapping, Optional, Sequence, Tuple, Union
from xml.etree import ElementTree as ET

from crg_model.completeness import CompletenessBasis
from crg_model.records import Coordinate, CoordinateSchema, Direction

from .import_profile import (
    DIMENSIONLESS,
    IMPORTER_VERSION,
    ImportProfileError,
    ImportReport,
    _ID_KEYS,
    _import_records,
    _load_json_document,
    _mapping_objectives,
    file_fingerprint,
    import_json,
    import_mapping_export,
    import_tabular,
)

SPREADSHEET_IMPORTER_ID = "crg-io.spreadsheet"
PARQUET_IMPORTER_ID = "crg-io.parquet"
COMPILER_GRAPH_IMPORTER_ID = "crg-io.compiler-graph"
COMPILER_GRAPH_FORMATS = (
    "compiler-graph-output",
    "compiler-graph",
    "mlir-cost-graph",
)
MAX_SPREADSHEET_ROWS = 1_000_000
MAX_SPREADSHEET_CELLS = 20_000_000
MAX_PARQUET_ROWS = 10_000_000


@dataclass(frozen=True)
class _FormulaCell:
    expression: str

    def __str__(self) -> str:
        return f"spreadsheet formula {self.expression!r}; formulas are not source values"


def _mapping(
    schema: CoordinateSchema,
    coordinate_columns: Union[Mapping[str, str], Sequence[str]],
) -> Dict[str, str]:
    if isinstance(coordinate_columns, Mapping):
        result = {str(k): str(v) for k, v in coordinate_columns.items()}
    else:
        result = {str(name): str(name) for name in coordinate_columns}
    if set(result.values()) != set(schema.identifiers):
        missing = set(schema.identifiers) - set(result.values())
        extra = set(result.values()) - set(schema.identifiers)
        raise ImportProfileError(
            "coordinate mapping must cover the declared schema exactly; "
            f"missing={sorted(missing)}, undeclared={sorted(extra)}"
        )
    return result


def _records_from_rows(
    header: Sequence[str],
    rows: Sequence[Sequence[Any]],
    *,
    schema: CoordinateSchema,
    id_column: str,
    coordinate_columns: Union[Mapping[str, str], Sequence[str]],
    attribute_columns: Sequence[str],
) -> Tuple[List[Dict[str, Any]], Dict[str, str], Tuple[str, ...]]:
    if len(set(header)) != len(header):
        duplicate = sorted({name for name in header if header.count(name) > 1})
        raise ImportProfileError("duplicate header columns: " + ", ".join(duplicate))
    if id_column not in header:
        raise ImportProfileError(f"identity column {id_column!r} is absent")
    mapping = _mapping(schema, coordinate_columns)
    required = {id_column, *mapping.keys(), *attribute_columns}
    missing = required - set(header)
    if missing:
        raise ImportProfileError("mapped columns are absent: " + ", ".join(sorted(missing)))
    index = {name: position for position, name in enumerate(header)}
    records: List[Dict[str, Any]] = []
    for row in rows:
        def cell(column: str) -> Any:
            return row[index[column]] if index[column] < len(row) else None

        record: Dict[str, Any] = {
            "realization_id": cell(id_column),
            "signature": {identifier: cell(column) for column, identifier in mapping.items()},
        }
        attributes: Dict[str, Any] = {}
        for column in attribute_columns:
            value = cell(column)
            lowered = column.strip().lower()
            if lowered in {"legality", "feasibility", "feasibility_status"}:
                record["legality"] = value
            elif lowered in {"evidence", "evidence_class"}:
                record["evidence_class"] = value
            elif value not in (None, ""):
                attributes[column] = value
        if attributes:
            record["attributes"] = attributes
        records.append(record)
    return records, mapping, tuple(sorted(set(header) - required))


def _finish_tabular_report(
    report: ImportReport,
    mapping: Mapping[str, str],
    id_column: str,
    dropped: Sequence[str],
) -> None:
    by_identifier = dict(report.coordinate_mapping)
    report.coordinate_mapping = {
        column: by_identifier[identifier] for column, identifier in mapping.items()
    }
    report.field_mapping = {id_column: "realization_id"}
    report.field_mapping.update(
        {column: f"signature.{identifier}" for column, identifier in mapping.items()}
    )
    report.dropped_fields = tuple(dropped)
    report.unsupported_fields = tuple(dropped)
    if dropped:
        report.warnings = report.warnings + (
            "source columns present but not imported: " + ", ".join(dropped),
        )


def _column_index(reference: str) -> int:
    letters = re.match(r"[A-Za-z]+", reference)
    if not letters:
        raise ImportProfileError(f"invalid spreadsheet cell reference {reference!r}")
    result = 0
    for char in letters.group(0).upper():
        result = result * 26 + ord(char) - 64
    return result - 1


def _xlsx_rows(path: str, sheet_name: Optional[str]) -> Tuple[List[str], List[List[Any]]]:
    try:
        archive = zipfile.ZipFile(path)
    except (OSError, zipfile.BadZipFile) as exc:
        raise ImportProfileError(f"source is not a valid .xlsx workbook: {exc}") from exc
    with archive:
        names = set(archive.namelist())
        required = {"xl/workbook.xml", "xl/_rels/workbook.xml.rels"}
        if not required <= names:
            raise ImportProfileError("workbook is missing required OOXML parts")
        shared: List[str] = []
        if "xl/sharedStrings.xml" in names:
            root = ET.fromstring(archive.read("xl/sharedStrings.xml"))
            for item in root.findall("{*}si"):
                shared.append("".join(node.text or "" for node in item.findall(".//{*}t")))

        relations = ET.fromstring(archive.read("xl/_rels/workbook.xml.rels"))
        targets = {
            rel.attrib["Id"]: rel.attrib["Target"] for rel in relations.findall("{*}Relationship")
        }
        workbook = ET.fromstring(archive.read("xl/workbook.xml"))
        sheets: List[Tuple[str, str]] = []
        relationship_key = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"
        for sheet in workbook.findall(".//{*}sheet"):
            title = sheet.attrib.get("name", "")
            target = targets.get(sheet.attrib.get(relationship_key, ""))
            if target:
                normalized = target.lstrip("/")
                if not normalized.startswith("xl/"):
                    normalized = "xl/" + normalized
                sheets.append((title, os.path.normpath(normalized)))
        if not sheets:
            raise ImportProfileError("workbook declares no worksheets")
        selected = next((item for item in sheets if item[0] == sheet_name), None) if sheet_name else sheets[0]
        if selected is None:
            raise ImportProfileError(
                f"worksheet {sheet_name!r} is absent; available: " + ", ".join(s[0] for s in sheets)
            )
        if selected[1] not in names:
            raise ImportProfileError(f"worksheet part {selected[1]!r} is absent")
        root = ET.fromstring(archive.read(selected[1]))
        materialized: List[List[Any]] = []
        cells_seen = 0
        for row in root.findall(".//{*}sheetData/{*}row"):
            values: Dict[int, Any] = {}
            for cell in row.findall("{*}c"):
                cells_seen += 1
                if cells_seen > MAX_SPREADSHEET_CELLS:
                    raise ImportProfileError("spreadsheet exceeds the configured cell limit")
                position = _column_index(cell.attrib.get("r", ""))
                formula = cell.find("{*}f")
                if formula is not None:
                    values[position] = _FormulaCell(formula.text or "")
                    continue
                cell_type = cell.attrib.get("t")
                value_node = cell.find("{*}v")
                lexical = value_node.text if value_node is not None else None
                if cell_type == "inlineStr":
                    values[position] = "".join(
                        node.text or "" for node in cell.findall(".//{*}is/{*}t")
                    )
                elif cell_type == "s" and lexical is not None:
                    try:
                        values[position] = shared[int(lexical)]
                    except (ValueError, IndexError) as exc:
                        raise ImportProfileError("invalid shared-string index") from exc
                elif cell_type == "b" and lexical is not None:
                    values[position] = lexical == "1"
                elif cell_type == "e":
                    values[position] = None
                else:
                    # OOXML stores the decimal lexical representation.  Keep
                    # that text: parsing it through binary float would destroy
                    # precisely the identity section 14.2 requires.
                    values[position] = lexical
            width = max(values, default=-1) + 1
            materialized.append([values.get(i) for i in range(width)])
            if len(materialized) > MAX_SPREADSHEET_ROWS + 1:
                raise ImportProfileError("spreadsheet exceeds the configured row limit")
        if not materialized:
            raise ImportProfileError("worksheet contains no rows")
        header = ["" if value is None else str(value).strip() for value in materialized[0]]
        return header, materialized[1:]


def import_spreadsheet(
    path: Union[str, os.PathLike], *, schema: CoordinateSchema, id_column: str,
    coordinate_columns: Union[Mapping[str, str], Sequence[str]],
    attribute_columns: Sequence[str] = (), sheet_name: Optional[str] = None,
    completeness: Optional[CompletenessBasis] = None,
):
    """Import a mapped Office Open XML spreadsheet without float coercion."""
    source_path = os.fspath(path)
    with open(source_path, "rb") as handle:
        raw = handle.read()
    header, rows = _xlsx_rows(source_path, sheet_name)
    records, mapping, dropped = _records_from_rows(
        header, rows, schema=schema, id_column=id_column,
        coordinate_columns=coordinate_columns, attribute_columns=attribute_columns,
    )
    bundle, report = _import_records(
        records, schema=schema, source_path=source_path, fingerprint=file_fingerprint(raw),
        importer_id=SPREADSHEET_IMPORTER_ID, importer_version=IMPORTER_VERSION,
        format_label="OOXML spreadsheet importer", completeness=completeness,
        inferred_schema=False,
    )
    _finish_tabular_report(report, mapping, id_column, dropped)
    return bundle, report


def import_parquet(
    path: Union[str, os.PathLike], *, schema: CoordinateSchema, id_column: str,
    coordinate_columns: Union[Mapping[str, str], Sequence[str]],
    attribute_columns: Sequence[str] = (), completeness: Optional[CompletenessBasis] = None,
):
    """Import Apache Parquet through the pinned optional PyArrow provider.

    Integer, Decimal, and string coordinates preserve exact identity.  Binary
    floating columns remain Python floats and are refused per row by the shared
    exact parser; they are never rounded or stringified into acceptance.
    """
    try:
        import pyarrow.parquet as parquet  # type: ignore
    except ImportError as exc:
        raise ImportProfileError(
            "Parquet import requires the pinned 'crg-io[parquet]' extra (pyarrow==25.0.1)"
        ) from exc
    source_path = os.fspath(path)
    with open(source_path, "rb") as handle:
        raw = handle.read()
    table = parquet.read_table(source_path)
    if table.num_rows > MAX_PARQUET_ROWS:
        raise ImportProfileError("Parquet source exceeds the configured row limit")
    header = list(table.column_names)
    columns = [column.to_pylist() for column in table.columns]
    rows: List[List[Any]] = []
    for index in range(table.num_rows):
        row: List[Any] = []
        for column in columns:
            value = column[index]
            row.append(format(value, "f") if isinstance(value, Decimal) else value)
        rows.append(row)
    records, mapping, dropped = _records_from_rows(
        header, rows, schema=schema, id_column=id_column,
        coordinate_columns=coordinate_columns, attribute_columns=attribute_columns,
    )
    bundle, report = _import_records(
        records, schema=schema, source_path=source_path, fingerprint=file_fingerprint(raw),
        importer_id=PARQUET_IMPORTER_ID, importer_version=IMPORTER_VERSION,
        format_label="Apache Parquet importer", completeness=completeness,
        inferred_schema=False,
    )
    _finish_tabular_report(report, mapping, id_column, dropped)
    return bundle, report


def import_compiler_graph(
    path: Union[str, os.PathLike], *, schema: Optional[CoordinateSchema] = None,
    completeness: Optional[CompletenessBasis] = None,
):
    """Import the registered compiler-graph normal form from section 37.5.

    Nodes are alternatives, ``metrics``/``coordinates`` are their signatures,
    and input/dependency edges are preserved as realization attributes.
    """
    document, source_path, fingerprint = _load_json_document(path)
    if not isinstance(document, Mapping):
        raise ImportProfileError("a compiler graph is a JSON object with a 'nodes' list")
    declared_format = str(document.get("format", "compiler-graph-output")).lower()
    if declared_format not in COMPILER_GRAPH_FORMATS:
        raise ImportProfileError(
            f"unrecognised compiler graph format {declared_format!r}; expected one of "
            + ", ".join(COMPILER_GRAPH_FORMATS)
        )
    nodes = document.get("nodes")
    if not isinstance(nodes, (list, tuple)):
        raise ImportProfileError("a compiler graph must carry a 'nodes' list")
    valid_nodes = [node for node in nodes if isinstance(node, Mapping)]
    inferred = False
    metric_mapping: Dict[str, str] = {}
    if schema is None:
        objectives = document.get("objectives")
        if objectives:
            built = []
            for entry in objectives:
                metric = str(entry.get("metric", entry.get("coordinate")))
                coordinate_id = str(entry.get("coordinate", metric))
                built.append(Coordinate(
                    identifier=coordinate_id,
                    quantity=str(entry.get("quantity", metric)),
                    unit=str(entry.get("unit", DIMENSIONLESS)),
                    direction=str(entry.get("direction", Direction.MINIMIZE)),
                ))
                metric_mapping[metric] = coordinate_id
            schema = CoordinateSchema(coordinates=tuple(built))
        else:
            pseudo = []
            for node in valid_nodes:
                pseudo.append({"signature": node.get("coordinates") or node.get("metrics")})
            from .import_profile import _infer_schema_from_records
            schema = _infer_schema_from_records(pseudo)
            inferred = True
    edges: Dict[str, List[str]] = {}
    for edge in document.get("edges") or ():
        if isinstance(edge, Mapping) and edge.get("to") is not None and edge.get("from") is not None:
            edges.setdefault(str(edge["to"]), []).append(str(edge["from"]))
    records: List[Dict[str, Any]] = []
    for node in nodes:
        if not isinstance(node, Mapping):
            records.append({"__malformed__": repr(node)})
            continue
        identity = next((node[key] for key in ("node_id", *_ID_KEYS) if key in node), None)
        raw_signature = node.get("coordinates") or node.get("metrics") or node.get("costs")
        if metric_mapping and isinstance(raw_signature, Mapping):
            raw_signature = {
                metric_mapping.get(str(key), str(key)): value
                for key, value in raw_signature.items()
            }
        record: Dict[str, Any] = {
            "realization_id": identity,
            "signature": raw_signature,
        }
        attributes = dict(node.get("attributes") or {})
        for key in ("op", "kind", "target", "source_location"):
            if key in node and node[key] not in (None, ""):
                attributes[key] = node[key]
        if attributes:
            record["attributes"] = attributes
        dependencies = node.get("dependencies") or node.get("inputs") or edges.get(str(identity))
        if dependencies:
            record["dependencies"] = list(dependencies)
        for key in ("legality", "feasibility", "evidence_class", "source", "context", "uncertainty"):
            if key in node:
                record[key] = node[key]
        records.append(record)
    return _import_records(
        records, schema=schema, source_path=source_path, fingerprint=fingerprint,
        importer_id=COMPILER_GRAPH_IMPORTER_ID, importer_version=IMPORTER_VERSION,
        format_label=f"{declared_format} importer", completeness=completeness,
        inferred_schema=inferred,
    )


Importer = Callable[..., Tuple[Any, ImportReport]]
_DOMAIN_IMPORTERS: Dict[str, Importer] = {}


def register_domain_importer(name: str, importer: Importer, *, replace: bool = False) -> None:
    """Register a versioned domain export adapter by stable format name."""
    key = str(name).strip().lower()
    if not key or not callable(importer):
        raise ImportProfileError("an importer requires a non-empty name and callable adapter")
    if key in _DOMAIN_IMPORTERS and not replace:
        raise ImportProfileError(f"importer {key!r} is already registered")
    _DOMAIN_IMPORTERS[key] = importer


def available_importers() -> Tuple[str, ...]:
    return tuple(sorted(_DOMAIN_IMPORTERS))


def import_registered(name: str, path: Union[str, os.PathLike], **kwargs: Any):
    key = str(name).strip().lower()
    try:
        importer = _DOMAIN_IMPORTERS[key]
    except KeyError as exc:
        raise ImportProfileError(
            f"no importer is registered for {key!r}; available: " + ", ".join(available_importers())
        ) from exc
    return importer(path, **kwargs)


def import_registry(path: Union[str, os.PathLike], *, format_name: Optional[str] = None, **kwargs: Any):
    """Dispatch a registry source through a named or safely inferred importer."""
    source = os.fspath(path)
    if format_name:
        return import_registered(format_name, source, **kwargs)
    suffix = os.path.splitext(source)[1].lower()
    if suffix in {".csv", ".tsv"}:
        return import_tabular(source, **kwargs)
    if suffix in {".xlsx"}:
        return import_spreadsheet(source, **kwargs)
    if suffix in {".parquet", ".pq"}:
        return import_parquet(source, **kwargs)
    if suffix == ".json":
        with open(source, encoding="utf-8") as handle:
            try:
                document = json.load(handle)
            except json.JSONDecodeError as exc:
                raise ImportProfileError(f"source is not valid JSON: {exc}") from exc
        declared = str(document.get("format", "" )).lower() if isinstance(document, Mapping) else ""
        if declared in COMPILER_GRAPH_FORMATS:
            return import_compiler_graph(source, **kwargs)
        if declared in {"timeloop-mapping-export", "zigzag-mapping-export", "mapping-export"}:
            return import_mapping_export(source, **kwargs)
        return import_json(source, **kwargs)
    raise ImportProfileError(
        f"cannot infer registry format from suffix {suffix!r}; select one of: "
        + ", ".join(available_importers())
    )


for _name, _importer in (
    ("canonical-json", import_json),
    ("csv", import_tabular),
    ("tsv", import_tabular),
    ("xlsx", import_spreadsheet),
    ("parquet", import_parquet),
    ("compiler-graph", import_compiler_graph),
    ("timeloop", import_mapping_export),
    ("zigzag", import_mapping_export),
):
    register_domain_importer(_name, _importer)


__all__ = [
    "SPREADSHEET_IMPORTER_ID", "PARQUET_IMPORTER_ID", "COMPILER_GRAPH_IMPORTER_ID",
    "COMPILER_GRAPH_FORMATS", "import_spreadsheet", "import_parquet",
    "import_compiler_graph", "register_domain_importer", "available_importers",
    "import_registered", "import_registry",
]
