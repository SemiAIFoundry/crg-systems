"""crg-model: canonical records, numerics, hashing, and typed dependencies.

This package is the shared contract layer of CRG Systems.  Every other
module binds to the types defined here.  Reference implementation of the
CRG Operational Systems Master Specification v0.2.0.
"""
from .canonical import canonical_json, canonical_bytes, content_hash, CanonicalizationError
from .numeric import (
    Exact, Interval, DecisionValue, ArithmeticProfile, SolverTrustProfile, exact,
    BoundedInterval, OneSidedBound, FiniteScenarioSet, EmpiricalSampleSet,
    NamedDistribution, SymbolicExpression, SemialgebraicConstraint,
    BooleanCapabilityPredicate, decode_representation, REPRESENTATION_TYPES,
)
from .units import (
    Dimension, QuantityDefinition, UnitDefinition, QuantityRegistry, DEFAULT_REGISTRY,
    UnitRegistryError, UnknownQuantity, UnknownUnit, CrossQuantityConversion,
    UnitRedefinitionError, OffsetUnitError, validate_coordinate_units,
    units_compatible, guard_combination,
)
from .envelope import (
    EvidenceClass, ObjectStatus, CaseStatus, Envelope, CRGObject, new_object_id, utc_now,
)
from .case import (
    REQUIRED_CASE_FIELDS, new_case_record, refresh_case_metadata, validate_case_metadata,
)
from .completeness import (
    CompletenessBasisType, ClaimScope, CompletenessBasis, derive_claim_scope,
)
from .edges import Action, EdgeType, EDGE_SEMANTICS, DependencyEdge, DependencyGraph
from .records import (
    Direction, Coordinate, CoordinateSchema, Signature, RealizationRecord,
    RealizationBundle, Fiber, RRecord, GammaRecord, KRecord, GeometryEnvelope,
    ObservationLevel, DecisionScope, DerivationRecord, RegretWitness,
    PruningCertificate, ReplayBinding, CertificatePins, DecisionCertificate, DecisionOutcome,
    ChangeEvent, ChangeImpactPlan, DeltaCertificate,
)
from .contracts import (
    ContractError, ContractPort, ExecutionModel, ApproximationPolicy, AccountingRule,
    ComputationContract, ResourceContract, HierarchyLevel, HierarchyLocation,
    HierarchyInterface, PlacementRule, HierarchyContract, AdapterFidelity, AdapterManifest,
)
from .lifecycle import (
    CaseState, LifecycleError, PRINCIPAL_PATH, PREPARATION_STATES, AUXILIARY_STATES,
    TERMINAL_STATES, TRANSITIONS, is_legal_transition, legal_targets, check_transition,
    LifecycleTransition, CaseLifecycle, case_state, set_case_state,
)
from .provenance import (
    AIProvenanceError, Disposition, PROHIBITED_ACTS, assert_may_not_certify,
    AIContributionRecord, AI_CONTRIBUTIONS_KEY, attach_ai_contribution,
    case_ai_contributions,
)
from .schema import (
    SchemaError, SchemaValidationError, SchemaRegistry, DEFAULT_SCHEMA_REGISTRY,
    validate, validate_or_raise, schema_for, load_schema, SCHEMA_ROOT,
)
from .migration import (
    MIGRATION_CLASSES, IDENTITY_ALGORITHM, MigrationError, UnknownMigrationClass,
    MigrationTransformNotFound, MigrationTransformAmbiguous, MigrationClassMismatch,
    MigrationProofError, MigrationTransform, MigrationExecution, MigrationRegistry,
    DEFAULT_MIGRATION_REGISTRY, verify_classification_evidence,
)

__version__ = "1.0.0"
SPEC_VERSION = "0.2.0"
