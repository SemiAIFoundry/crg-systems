"""Continued validity and immutable lifecycle authorization records.

Roadmap workstream E requires one view over the reasons a decision remains
current or ceases to be current.  This module exposes those canonical states
directly; it never compresses them into a confidence, health, or readiness
score.  It also provides immutable approval, signature-verification,
withdrawal, and separation-of-duties records suitable for transition and
replacement workflows.

Normative basis: master specification sections 12, 14.5, 16--18, 32.4--32.5,
35.4, and 45, plus canonical product roadmap section 6.5.

Cryptography is intentionally outside this package.  A
``SignatureVerificationRecord`` names the verifier that checked a signature
and the exact payload hash it checked.  Authorization consumes that record;
it never consumes a caller-provided ``approved=True`` boolean.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional, Sequence, Tuple

from crg_model.canonical import content_hash, is_hash
from crg_model.edges import Action
from etq_evidence import TimeStatus, ValidityWindow, VerificationClock, evaluate_time

__all__ = [
    "CONTINUED_VALIDITY_PROFILE",
    "CONTINUED_VALIDITY_SCHEMA_VERSION",
    "LifecycleEvidenceError",
    "SignatureVerificationRecord",
    "ApprovalRecord",
    "ApprovalWithdrawal",
    "SeparationOfDutiesPolicy",
    "LifecycleAuthorization",
    "evaluate_lifecycle_authorization",
    "LifecycleDimensionName",
    "LifecycleDimension",
    "ReopenTrigger",
    "ContinuedValidityStatus",
    "ContinuedValidityView",
]

CONTINUED_VALIDITY_PROFILE = "crg.continued-validity"
CONTINUED_VALIDITY_SCHEMA_VERSION = "1.0.0"


class LifecycleEvidenceError(ValueError):
    """A lifecycle or authorization assertion is incomplete or inconsistent."""


# Module-local compatibility for callers that imported the implementation
# module directly during development.  The package exports the collision-
# resistant name because ``crg_model.lifecycle`` owns ``LifecycleError``.
LifecycleError = LifecycleEvidenceError


def _hash(value: str, field_name: str) -> str:
    value = str(value)
    if not is_hash(value):
        raise LifecycleError(f"{field_name} must be an algorithm-tagged SHA-256 hash")
    return value


@dataclass(frozen=True)
class SignatureVerificationRecord:
    """Evidence that a named verifier checked a signature over exact bytes."""

    verification_id: str
    signature_id: str
    signature_hash: str
    signed_content_hash: str
    key_id: str
    algorithm: str
    verifier_id: str
    verifier_version: str
    checked_at: str
    verified: bool
    failure_reason: str = ""

    def __post_init__(self) -> None:
        object.__setattr__(self, "signature_hash", _hash(self.signature_hash, "signature_hash"))
        object.__setattr__(
            self, "signed_content_hash", _hash(self.signed_content_hash, "signed_content_hash")
        )
        required = (
            self.verification_id,
            self.signature_id,
            self.key_id,
            self.algorithm,
            self.verifier_id,
            self.verifier_version,
            self.checked_at,
        )
        if not all(required):
            raise LifecycleError("signature verification evidence has an unnamed field")
        if not self.verified and not self.failure_reason:
            raise LifecycleError("a failed signature verification must state why it failed")

    def to_canonical(self) -> dict:
        record = {
            "record_type": "SignatureVerificationRecord",
            "profile": CONTINUED_VALIDITY_PROFILE,
            "schema_version": CONTINUED_VALIDITY_SCHEMA_VERSION,
            "verification_id": self.verification_id,
            "signature_id": self.signature_id,
            "signature_hash": self.signature_hash,
            "signed_content_hash": self.signed_content_hash,
            "key_id": self.key_id,
            "algorithm": self.algorithm,
            "verifier_id": self.verifier_id,
            "verifier_version": self.verifier_version,
            "checked_at": self.checked_at,
            "verified": self.verified,
        }
        if self.failure_reason:
            record["failure_reason"] = self.failure_reason
        return record

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())


@dataclass(frozen=True)
class ApprovalRecord:
    """Immutable signed approval of one action on one content hash."""

    approval_id: str
    artifact_hash: str
    action: str
    subject_id: str
    role: str
    organization: str
    signed_at: str
    validity: ValidityWindow
    signature_verification: SignatureVerificationRecord
    authority: str

    def __post_init__(self) -> None:
        object.__setattr__(self, "artifact_hash", _hash(self.artifact_hash, "artifact_hash"))
        if not all(
            (
                self.approval_id,
                self.action,
                self.subject_id,
                self.role,
                self.organization,
                self.signed_at,
                self.authority,
            )
        ):
            raise LifecycleError("approval identity, action, actor, role, time, and authority are required")
        expected = content_hash(self.payload())
        if self.signature_verification.signed_content_hash != expected:
            raise LifecycleError(
                "signature verification is not bound to this approval's exact payload"
            )
        if not self.signature_verification.verified:
            raise LifecycleError("a failed signature verification cannot create an approval")

    def payload(self) -> dict:
        return {
            "artifact_hash": self.artifact_hash,
            "action": self.action,
            "subject_id": self.subject_id,
            "role": self.role,
            "organization": self.organization,
            "signed_at": self.signed_at,
            "validity": self.validity.to_canonical(),
            "authority": self.authority,
        }

    def to_canonical(self) -> dict:
        return {
            "record_type": "ApprovalRecord",
            "profile": CONTINUED_VALIDITY_PROFILE,
            "schema_version": CONTINUED_VALIDITY_SCHEMA_VERSION,
            "approval_id": self.approval_id,
            "payload": self.payload(),
            "approval_payload_hash": content_hash(self.payload()),
            "signature_verification": self.signature_verification.to_canonical(),
        }

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())


@dataclass(frozen=True)
class ApprovalWithdrawal:
    """A separate immutable record; the original approval is never rewritten."""

    withdrawal_id: str
    approval_hash: str
    withdrawn_by: str
    reason: str
    occurred_at: str
    authority: str
    signature_verification: SignatureVerificationRecord

    def __post_init__(self) -> None:
        object.__setattr__(self, "approval_hash", _hash(self.approval_hash, "approval_hash"))
        if not all(
            (self.withdrawal_id, self.withdrawn_by, self.reason, self.occurred_at, self.authority)
        ):
            raise LifecycleError("an approval withdrawal requires actor, reason, time, and authority")
        expected = content_hash(self.payload())
        if self.signature_verification.signed_content_hash != expected:
            raise LifecycleError("withdrawal signature is not bound to this withdrawal payload")
        if not self.signature_verification.verified:
            raise LifecycleError("an unverified withdrawal signature cannot withdraw an approval")

    def payload(self) -> dict:
        return {
            "approval_hash": self.approval_hash,
            "withdrawn_by": self.withdrawn_by,
            "reason": self.reason,
            "occurred_at": self.occurred_at,
            "authority": self.authority,
        }

    def to_canonical(self) -> dict:
        return {
            "record_type": "ApprovalWithdrawal",
            "profile": CONTINUED_VALIDITY_PROFILE,
            "schema_version": CONTINUED_VALIDITY_SCHEMA_VERSION,
            "withdrawal_id": self.withdrawal_id,
            "payload": self.payload(),
            "withdrawal_payload_hash": content_hash(self.payload()),
            "signature_verification": self.signature_verification.to_canonical(),
        }

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())


@dataclass(frozen=True)
class SeparationOfDutiesPolicy:
    """Explicit approval roles and combinations one subject may not hold."""

    policy_id: str
    required_roles: Tuple[str, ...]
    incompatible_role_pairs: Tuple[Tuple[str, str], ...] = ()
    distinct_subjects_for_required_roles: bool = True
    authority: str = ""

    def __post_init__(self) -> None:
        roles = tuple(sorted(set(str(v) for v in self.required_roles if str(v))))
        if not roles:
            raise LifecycleError("a separation-of-duties policy requires at least one role")
        object.__setattr__(self, "required_roles", roles)
        normalized = []
        for left, right in self.incompatible_role_pairs:
            if not left or not right or left == right:
                raise LifecycleError("an incompatible role pair must name two distinct roles")
            normalized.append(tuple(sorted((str(left), str(right)))))
        if len(set(normalized)) != len(normalized):
            raise LifecycleError("separation-of-duties policy contains duplicate role pairs")
        object.__setattr__(self, "incompatible_role_pairs", tuple(sorted(normalized)))
        if not self.policy_id or not self.authority:
            raise LifecycleError("a separation-of-duties policy needs identity and authority")

    def to_canonical(self) -> dict:
        return {
            "policy_id": self.policy_id,
            "required_roles": list(self.required_roles),
            "incompatible_role_pairs": [list(pair) for pair in self.incompatible_role_pairs],
            "distinct_subjects_for_required_roles": self.distinct_subjects_for_required_roles,
            "authority": self.authority,
        }


@dataclass(frozen=True)
class LifecycleAuthorization:
    """Explainable authorization outcome derived from signed approval records."""

    artifact_hash: str
    action: str
    policy_id: str
    authorized: bool
    accepted_approval_hashes: Tuple[str, ...]
    rejected_approvals: Tuple[Tuple[str, str], ...]
    withdrawal_hashes: Tuple[str, ...]
    missing_roles: Tuple[str, ...]
    separation_failures: Tuple[str, ...]
    clock: dict

    def __post_init__(self) -> None:
        object.__setattr__(self, "artifact_hash", _hash(self.artifact_hash, "artifact_hash"))
        if self.authorized and (
            self.rejected_approvals or self.missing_roles or self.separation_failures
        ):
            raise LifecycleError("an authorized outcome cannot carry unresolved approval failures")

    def to_canonical(self) -> dict:
        return {
            "record_type": "LifecycleAuthorization",
            "profile": CONTINUED_VALIDITY_PROFILE,
            "schema_version": CONTINUED_VALIDITY_SCHEMA_VERSION,
            "artifact_hash": self.artifact_hash,
            "action": self.action,
            "policy_id": self.policy_id,
            "authorized": self.authorized,
            "accepted_approval_hashes": list(self.accepted_approval_hashes),
            "rejected_approvals": [
                {"approval_hash": item, "reason": reason}
                for item, reason in self.rejected_approvals
            ],
            "withdrawal_hashes": list(self.withdrawal_hashes),
            "missing_roles": list(self.missing_roles),
            "separation_failures": list(self.separation_failures),
            "clock": dict(self.clock),
        }

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())


def _has_distinct_required_role_assignment(
    required_roles: Sequence[str], approvals: Sequence[ApprovalRecord]
) -> bool:
    """Return whether required roles can be assigned to different subjects."""

    candidates = {
        role: tuple(sorted({
            approval.subject_id for approval in approvals if approval.role == role
        }))
        for role in required_roles
    }
    ordered = sorted(required_roles, key=lambda role: (len(candidates[role]), role))

    def assign(index: int, used: set[str]) -> bool:
        if index == len(ordered):
            return True
        role = ordered[index]
        return any(
            subject not in used and assign(index + 1, used | {subject})
            for subject in candidates[role]
        )

    return assign(0, set())


def evaluate_lifecycle_authorization(
    *,
    artifact_hash: str,
    action: str,
    approvals: Sequence[ApprovalRecord],
    withdrawals: Sequence[ApprovalWithdrawal],
    policy: SeparationOfDutiesPolicy,
    clock: VerificationClock,
) -> LifecycleAuthorization:
    """Evaluate signatures, withdrawal, time, role coverage, and SoD explicitly."""
    artifact_hash = _hash(artifact_hash, "artifact_hash")
    withdrawal_by_approval: Dict[str, ApprovalWithdrawal] = {}
    for withdrawal in withdrawals:
        if withdrawal.approval_hash in withdrawal_by_approval:
            raise LifecycleError("multiple withdrawal records target the same approval")
        withdrawal_by_approval[withdrawal.approval_hash] = withdrawal

    accepted = []
    rejected = []
    active: list[ApprovalRecord] = []
    for approval in approvals:
        approval_hash = approval.fingerprint()
        reason = None
        if approval.artifact_hash != artifact_hash:
            reason = "ARTIFACT_HASH_MISMATCH"
        elif approval.action != action:
            reason = "ACTION_MISMATCH"
        elif approval_hash in withdrawal_by_approval:
            reason = "APPROVAL_WITHDRAWN"
        else:
            judgment = evaluate_time(approval.validity, clock)
            if judgment.time_status != TimeStatus.CURRENT:
                reason = f"APPROVAL_TIME_{judgment.time_status}"
        if reason:
            rejected.append((approval_hash, reason))
        else:
            accepted.append(approval_hash)
            active.append(approval)

    present_roles = {approval.role for approval in active}
    missing = tuple(sorted(set(policy.required_roles) - present_roles))
    failures = []
    by_subject: Dict[str, set[str]] = {}
    for approval in active:
        by_subject.setdefault(approval.subject_id, set()).add(approval.role)
    if policy.distinct_subjects_for_required_roles:
        if not _has_distinct_required_role_assignment(policy.required_roles, active):
            failures.append("required roles are not held by distinct subjects")
    for subject, roles in sorted(by_subject.items()):
        for left, right in policy.incompatible_role_pairs:
            if {left, right}.issubset(roles):
                failures.append(f"subject {subject!r} holds incompatible roles {left!r}, {right!r}")
    authorized = not rejected and not missing and not failures
    return LifecycleAuthorization(
        artifact_hash=artifact_hash,
        action=action,
        policy_id=policy.policy_id,
        authorized=authorized,
        accepted_approval_hashes=tuple(sorted(accepted)),
        rejected_approvals=tuple(sorted(rejected)),
        withdrawal_hashes=tuple(sorted(w.fingerprint() for w in withdrawals)),
        missing_roles=missing,
        separation_failures=tuple(failures),
        clock=clock.to_canonical(),
    )


class LifecycleDimensionName:
    EVIDENCE_VALIDITY = "EVIDENCE_VALIDITY"
    VERIFIER_TIME = "VERIFIER_TIME"
    DEPENDENCY_STATUS = "DEPENDENCY_STATUS"
    CHANGE_EVENTS = "CHANGE_EVENTS"
    REVOCATION = "REVOCATION"
    REDACTION = "REDACTION"
    MIGRATION = "MIGRATION"
    BRANCH_STATE = "BRANCH_STATE"
    SUPERSESSION = "SUPERSESSION"
    APPROVALS = "APPROVALS"

    REQUIRED = (
        EVIDENCE_VALIDITY,
        VERIFIER_TIME,
        DEPENDENCY_STATUS,
        CHANGE_EVENTS,
        REVOCATION,
        REDACTION,
        MIGRATION,
        BRANCH_STATE,
        SUPERSESSION,
        APPROVALS,
    )

    ALLOWED = {
        EVIDENCE_VALIDITY: frozenset(
            {"CURRENT", "EXPIRED", "REVOKED", "REDACTED", "UNAVAILABLE", "INDETERMINATE"}
        ),
        VERIFIER_TIME: frozenset(
            {
                "CURRENT",
                "EXPIRED",
                "STALE",
                "NOT_YET_VALID",
                "TIME_INDETERMINATE",
                "CLOCK_POLICY_VIOLATION",
            }
        ),
        DEPENDENCY_STATUS: frozenset(
            {"CURRENT", "REVALIDATION_REQUIRED", "STALE", "BLOCKED", "INDETERMINATE"}
        ),
        CHANGE_EVENTS: frozenset(
            {
                "NONE",
                "REPRICE_REQUIRED",
                "RE_EMBED_REQUIRED",
                "REOPEN_REQUIRED",
                "REVALIDATION_REQUIRED",
                "BLOCKED",
            }
        ),
        REVOCATION: frozenset({"NOT_REVOKED", "REVOKED", "UNKNOWN"}),
        REDACTION: frozenset({"AVAILABLE", "REDACTED", "UNVERIFIABLE_REDACTED", "UNKNOWN"}),
        MIGRATION: frozenset(
            {
                "ORIGINAL",
                "SEMANTICALLY_EQUIVALENT_VERIFIED",
                "REVALIDATION_REQUIRED",
                "REOPEN_REQUIRED",
                "LOSSY",
                "UNVERIFIED",
            }
        ),
        BRANCH_STATE: frozenset(
            {
                "LINEAR_CURRENT",
                "BRANCHED_CURRENT",
                "PARENT_HISTORICAL",
                "MERGE_RECONCILIATION_REQUIRED",
                "MERGED_REVALIDATION_REQUIRED",
                "UNKNOWN",
            }
        ),
        SUPERSESSION: frozenset({"CURRENT", "SUPERSEDED", "UNKNOWN"}),
        APPROVALS: frozenset(
            {
                "CURRENT",
                "MISSING",
                "WITHDRAWN",
                "SIGNATURE_UNVERIFIED",
                "SEPARATION_OF_DUTIES_FAILED",
                "EXPIRED",
                "INDETERMINATE",
            }
        ),
    }


_CURRENT = {
    LifecycleDimensionName.EVIDENCE_VALIDITY: {"CURRENT"},
    LifecycleDimensionName.VERIFIER_TIME: {"CURRENT"},
    LifecycleDimensionName.DEPENDENCY_STATUS: {"CURRENT"},
    LifecycleDimensionName.CHANGE_EVENTS: {"NONE"},
    LifecycleDimensionName.REVOCATION: {"NOT_REVOKED"},
    LifecycleDimensionName.REDACTION: {"AVAILABLE"},
    LifecycleDimensionName.MIGRATION: {"ORIGINAL", "SEMANTICALLY_EQUIVALENT_VERIFIED"},
    LifecycleDimensionName.BRANCH_STATE: {"LINEAR_CURRENT", "BRANCHED_CURRENT"},
    LifecycleDimensionName.SUPERSESSION: {"CURRENT"},
    LifecycleDimensionName.APPROVALS: {"CURRENT"},
}

_INDETERMINATE_STATES = {
    "INDETERMINATE",
    "TIME_INDETERMINATE",
    "UNKNOWN",
    "UNVERIFIED",
}

_REOPEN_STATES = {
    "REVALIDATION_REQUIRED",
    "STALE",
    "REPRICE_REQUIRED",
    "RE_EMBED_REQUIRED",
    "REOPEN_REQUIRED",
    "PARENT_HISTORICAL",
    "MERGE_RECONCILIATION_REQUIRED",
    "MERGED_REVALIDATION_REQUIRED",
    "SUPERSEDED",
}


@dataclass(frozen=True)
class LifecycleDimension:
    """One direct canonical state in the continued-validity view."""

    name: str
    state: str
    source_hash: str
    detail: str

    def __post_init__(self) -> None:
        if self.name not in LifecycleDimensionName.ALLOWED:
            raise LifecycleError(f"unknown continued-validity dimension {self.name!r}")
        if self.state not in LifecycleDimensionName.ALLOWED[self.name]:
            raise LifecycleError(f"state {self.state!r} is invalid for dimension {self.name}")
        object.__setattr__(self, "source_hash", _hash(self.source_hash, "source_hash"))
        if not self.detail:
            raise LifecycleError("every lifecycle dimension must explain its direct state")

    @property
    def current(self) -> bool:
        return self.state in _CURRENT[self.name]

    def to_canonical(self) -> dict:
        return {
            "name": self.name,
            "state": self.state,
            "source_hash": self.source_hash,
            "detail": self.detail,
        }


@dataclass(frozen=True)
class ReopenTrigger:
    trigger_id: str
    condition: str
    source_hash: str
    action: str

    def __post_init__(self) -> None:
        object.__setattr__(self, "source_hash", _hash(self.source_hash, "source_hash"))
        if not self.trigger_id or not self.condition:
            raise LifecycleError("a reopen trigger requires identity and condition")
        if self.action not in Action.SEVERITY:
            raise LifecycleError(f"unknown reopen action {self.action!r}")
        if self.action == Action.NO_OPERATION:
            raise LifecycleError("a reopen trigger cannot declare NO_OPERATION")

    def to_canonical(self) -> dict:
        return {
            "trigger_id": self.trigger_id,
            "condition": self.condition,
            "source_hash": self.source_hash,
            "action": self.action,
        }


class ContinuedValidityStatus:
    CURRENT = "CURRENT"
    REOPEN_REQUIRED = "REOPEN_REQUIRED"
    INDETERMINATE = "INDETERMINATE"
    BLOCKED = "BLOCKED"


@dataclass(frozen=True)
class ContinuedValidityView:
    """Complete direct-state view of one decision artifact at a supplied time."""

    view_id: str
    case_id: str
    artifact_id: str
    artifact_hash: str
    evaluated_at: str
    verifier_clock: VerificationClock
    dimensions: Tuple[LifecycleDimension, ...]
    reopen_triggers: Tuple[ReopenTrigger, ...]
    dependency_hashes: Tuple[str, ...]
    schema_version: str = CONTINUED_VALIDITY_SCHEMA_VERSION

    def __post_init__(self) -> None:
        object.__setattr__(self, "artifact_hash", _hash(self.artifact_hash, "artifact_hash"))
        dependencies = tuple(_hash(v, "dependency_hash") for v in self.dependency_hashes)
        object.__setattr__(self, "dependency_hashes", dependencies)
        object.__setattr__(self, "dimensions", tuple(self.dimensions))
        object.__setattr__(self, "reopen_triggers", tuple(self.reopen_triggers))
        names = [dimension.name for dimension in self.dimensions]
        if len(set(names)) != len(names):
            raise LifecycleError("continued-validity view repeats a dimension")
        missing = sorted(set(LifecycleDimensionName.REQUIRED) - set(names))
        extra = sorted(set(names) - set(LifecycleDimensionName.REQUIRED))
        if missing or extra:
            raise LifecycleError(
                f"continued-validity view is incomplete: missing={missing}, extra={extra}"
            )
        if not all((self.view_id, self.case_id, self.artifact_id, self.evaluated_at)):
            raise LifecycleError("continued-validity identity and evaluation time are required")
        if self.verifier_clock.evaluation_time != self.evaluated_at:
            raise LifecycleError(
                "the displayed evaluation time must be the supplied verifier clock time"
            )

    @property
    def status(self) -> str:
        states = {dimension.state for dimension in self.dimensions if not dimension.current}
        if not states:
            return ContinuedValidityStatus.CURRENT
        # A known revocation, redaction, failed approval, expiry, or other
        # blocking state dominates uncertainty elsewhere.  Indeterminacy must
        # never soften an independently known block.
        blocking = states - _INDETERMINATE_STATES - _REOPEN_STATES
        if blocking:
            return ContinuedValidityStatus.BLOCKED
        if states.intersection(_INDETERMINATE_STATES):
            return ContinuedValidityStatus.INDETERMINATE
        if states.intersection(_REOPEN_STATES):
            return ContinuedValidityStatus.REOPEN_REQUIRED
        return ContinuedValidityStatus.BLOCKED  # pragma: no cover - exhaustive sets above

    @property
    def blocking_dimensions(self) -> Tuple[str, ...]:
        return tuple(sorted(d.name for d in self.dimensions if not d.current))

    def to_canonical(self) -> dict:
        return {
            "record_type": "ContinuedValidityView",
            "profile": CONTINUED_VALIDITY_PROFILE,
            "schema_version": self.schema_version,
            "view_id": self.view_id,
            "case_id": self.case_id,
            "artifact_id": self.artifact_id,
            "artifact_hash": self.artifact_hash,
            "evaluated_at": self.evaluated_at,
            "verifier_clock": self.verifier_clock.to_canonical(),
            "status": self.status,
            "dimensions": [
                dimension.to_canonical()
                for dimension in sorted(self.dimensions, key=lambda item: item.name)
            ],
            "blocking_dimensions": list(self.blocking_dimensions),
            "reopen_triggers": [trigger.to_canonical() for trigger in self.reopen_triggers],
            "dependency_hashes": list(self.dependency_hashes),
            "claim_boundary": (
                "direct lifecycle states only; no confidence, health, readiness, or other "
                "synthetic score"
            ),
        }

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())
