"""Transition authorization bound to certified CRG phase evidence.

``OperationalStateGuard`` is the preferred name for the legacy
``PhaseGuard`` telemetry gate.  That gate observes deployment labels such as
``STEADY``; it does not prove a mathematical CRG phase boundary.  A transition
that makes a CRG phase claim must use :func:`authorize_with_certified_phase`
and carry the separate shared binding defined by ``crg-model``.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from crg_model.canonical import content_hash
from crg_model.phase_binding import (
    CertifiedPhaseBinding,
    CertifiedPhaseBindingError,
    CertifiedPhaseConsumption,
    consume_certified_phase,
)

from .transition import (
    Approver,
    AuthorizationResult,
    PhaseGuard,
    TransitionPlan,
    authorize,
)

__all__ = [
    "OperationalStateGuard",
    "PhaseBoundTransitionAuthorization",
    "authorize_with_certified_phase",
]

# Backward-compatible semantic alias.  ``PhaseGuard`` remains available for
# v1.0.1 callers and retains its wire field; new integrations can name what it
# actually is without implying a certified mathematical boundary.
OperationalStateGuard = PhaseGuard


@dataclass(frozen=True)
class PhaseBoundTransitionAuthorization:
    """Authorization outcome plus the exact certified phase it consumed."""

    authorization: AuthorizationResult
    phase_consumption: CertifiedPhaseConsumption

    def to_canonical(self) -> dict:
        return {
            "record_type": "PhaseBoundTransitionAuthorization",
            "schema_version": "1.2.0",
            "authorization": self.authorization.to_canonical(),
            "authorization_root": content_hash(self.authorization.to_canonical()),
            "phase_consumption": self.phase_consumption.to_canonical(),
            "operational_state_guard_semantics": (
                "EXTERNAL_NON_CERTIFIED_OPERATIONAL_LABEL_ONLY"
            ),
            "claim_limitations": [
                "OPERATIONAL_STATE_LABELS_DO_NOT_PROVE_CRG_PHASE_BOUNDARIES",
                "CERTIFIED_PHASE_BINDING_DOES_NOT_REPLACE_RUNTIME_SAFETY_GATES",
            ],
        }

    def root_hash(self) -> str:
        return content_hash(self.to_canonical())


def authorize_with_certified_phase(
    plan: TransitionPlan,
    *,
    level: str,
    certified_phase: CertifiedPhaseBinding,
    expected_phase_analysis_root: str,
    expected_source_r_root: str,
    approver: Optional[Approver] = None,
) -> PhaseBoundTransitionAuthorization:
    """Authorize only after the caller and shared phase binding identities agree."""
    if not isinstance(certified_phase, CertifiedPhaseBinding):
        raise CertifiedPhaseBindingError(
            "transition authorization requires a verified CertifiedPhaseBinding"
        )
    # Check before ``authorize`` mutates the plan.  A mismatch therefore
    # cannot leave behind an authorization side effect.
    certified_phase.require_identity(expected_phase_analysis_root, expected_source_r_root)
    authorization = authorize(plan, level=level, approver=approver)
    authorization_root = content_hash(authorization.to_canonical())
    consumption = consume_certified_phase(
        certified_phase,
        consumer="TRANSITION_AUTHORIZATION",
        subject_root=authorization_root,
        expected_phase_analysis_root=expected_phase_analysis_root,
        expected_source_r_root=expected_source_r_root,
    )
    return PhaseBoundTransitionAuthorization(
        authorization=authorization,
        phase_consumption=consumption,
    )
