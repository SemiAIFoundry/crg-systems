"""Portable evidence for a real local-profile backup and empty-target restore.

This contract is intentionally narrower than a disaster-recovery claim.  It
binds independently extracted, canonical inventories from one source
``CaseStore``, the verified backup archive, and the restored empty target.
The contract says nothing about provider availability, point-in-time
recovery, failover, RPO, or RTO.

The administrative extractor lives in :mod:`crg_server.local_recovery`.
Keeping the canonical record here makes the evidence portable and allows the
stdlib-only :mod:`crg_verify` implementation to re-derive every root without
opening a server store.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Sequence, Tuple

from crg_model.canonical import canonical_json, content_hash, is_hash

from .resilience import LifecyclePortableSnapshot, LifecycleResilienceError, create_lifecycle_snapshot

__all__ = [
    "LOCAL_ADMIN_RECOVERY_PROFILE",
    "LOCAL_ADMIN_RECOVERY_SCHEMA_VERSION",
    "LOCAL_RECOVERY_INVENTORY_ROLES",
    "LOCAL_RECOVERY_TYPED_ROOT_FIELDS",
    "LocalRecoveryTypedInventory",
    "LocalAdminRecoveryEvidence",
    "create_local_recovery_inventory",
    "load_local_recovery_inventory",
    "record_local_admin_recovery",
    "create_local_recovery_lifecycle_snapshot",
]


LOCAL_ADMIN_RECOVERY_PROFILE = "crg.local-admin-recovery@1"
LOCAL_ADMIN_RECOVERY_SCHEMA_VERSION = "1.0.0"
LOCAL_RECOVERY_INVENTORY_ROLES = (
    "SOURCE",
    "BACKUP_ARCHIVE",
    "RESTORED_EMPTY_TARGET",
)
LOCAL_RECOVERY_TYPED_ROOT_FIELDS = (
    "case_root",
    "dependency_graph_root",
    "audit_chain_root",
    "active_certificate_root",
    "superseded_certificate_root",
    "other_certificate_root",
    "certificate_inventory_root",
    "object_inventory_root",
)

_AUDIT_GENESIS_HASH = content_hash({
    "record_type": "LocalRecoveryAuditChainGenesis",
    "profile": LOCAL_ADMIN_RECOVERY_PROFILE,
})
_LOCAL_RECOVERY_BOUNDARY = (
    "verified local-profile logical backup, archive extraction, typed inventory "
    "equality, and empty-target restore only; not provider disaster recovery, "
    "availability, point-in-time recovery, failover, RPO/RTO, transition "
    "execution, physical signoff, or generic physical safety"
)


def _copy(value: Any, where: str) -> Any:
    try:
        return json.loads(canonical_json(value))
    except (TypeError, ValueError) as error:
        raise LifecycleResilienceError(
            f"{where} is not canonical CRG JSON: {error}"
        ) from error


def _object(value: Any, where: str) -> Dict[str, Any]:
    if not isinstance(value, Mapping):
        raise LifecycleResilienceError(f"{where} must be a JSON object")
    return _copy(dict(value), where)


def _text(value: Any, where: str, *, allow_empty: bool = False) -> str:
    if not isinstance(value, str) or (not allow_empty and not value.strip()):
        qualifier = "a string" if allow_empty else "a non-empty string"
        raise LifecycleResilienceError(f"{where} must be {qualifier}")
    return value


def _hash(value: Any, where: str) -> str:
    if not is_hash(value):
        raise LifecycleResilienceError(
            f"{where} must be an algorithm-tagged SHA-256 hash"
        )
    return str(value)


def _exact(value: Mapping[str, Any], fields: Sequence[str], where: str) -> None:
    expected = set(fields)
    found = set(value)
    if found != expected:
        raise LifecycleResilienceError(
            f"{where} requires exactly {sorted(expected)}; found {sorted(found)}"
        )


def _positive_integer(value: Any, where: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise LifecycleResilienceError(f"{where} must be a positive integer")
    return value


def _nonnegative_integer(value: Any, where: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise LifecycleResilienceError(f"{where} must be a non-negative integer")
    return value


def _validate_cases(values: Sequence[Mapping[str, Any]]) -> Tuple[Dict[str, Any], ...]:
    fields = (
        "case_id", "case_version", "content_hash", "branch_id", "parent_version",
        "status", "created_at", "derived_from", "object_status", "payload",
    )
    result = []
    prior = None
    for offset, raw in enumerate(values):
        item = _object(raw, f"case_inventory[{offset}]")
        _exact(item, fields, f"case_inventory[{offset}]")
        key = (
            _text(item["case_id"], f"case_inventory[{offset}].case_id"),
            _positive_integer(
                item["case_version"], f"case_inventory[{offset}].case_version"
            ),
        )
        if prior is not None and key <= prior:
            raise LifecycleResilienceError(
                "case inventory identities must be unique and sorted"
            )
        prior = key
        _text(item["branch_id"], f"case_inventory[{offset}].branch_id")
        if item["parent_version"] is not None:
            _positive_integer(
                item["parent_version"], f"case_inventory[{offset}].parent_version"
            )
        _text(item["status"], f"case_inventory[{offset}].status")
        _text(item["created_at"], f"case_inventory[{offset}].created_at")
        if item["derived_from"] is not None and not isinstance(
            item["derived_from"], Mapping
        ):
            raise LifecycleResilienceError(
                f"case_inventory[{offset}].derived_from must be an object or null"
            )
        _text(item["object_status"], f"case_inventory[{offset}].object_status")
        payload = _object(item["payload"], f"case_inventory[{offset}].payload")
        declared = _hash(item["content_hash"], f"case_inventory[{offset}].content_hash")
        if declared != content_hash(payload):
            raise LifecycleResilienceError(
                f"case_inventory[{offset}] content hash does not match its payload"
            )
        result.append(item)
    if not result:
        raise LifecycleResilienceError(
            "a local recovery drill source must contain at least one case version"
        )
    return tuple(result)


def _validate_edges(values: Sequence[Mapping[str, Any]]) -> Tuple[Dict[str, Any], ...]:
    fields = (
        "edge_id", "case_id", "source", "target", "edge_type", "scope",
        "minimum_action", "recorded_at",
    )
    result = []
    prior = None
    for offset, raw in enumerate(values):
        item = _object(raw, f"dependency_graph[{offset}]")
        _exact(item, fields, f"dependency_graph[{offset}]")
        case_id = item["case_id"]
        if case_id is not None:
            case_id = _text(case_id, f"dependency_graph[{offset}].case_id")
        edge_id = _text(item["edge_id"], f"dependency_graph[{offset}].edge_id")
        key = (case_id or "", edge_id)
        if prior is not None and key <= prior:
            raise LifecycleResilienceError(
                "dependency edge identities must be unique and sorted"
            )
        prior = key
        for field in ("source", "target", "edge_type", "recorded_at"):
            _text(item[field], f"dependency_graph[{offset}].{field}")
        for field in ("scope", "minimum_action"):
            _text(
                item[field], f"dependency_graph[{offset}].{field}", allow_empty=True
            )
        result.append(item)
    return tuple(result)


def _audit_entry_hash(prior: str, record: Mapping[str, Any]) -> str:
    return content_hash({
        "profile": LOCAL_ADMIN_RECOVERY_PROFILE,
        "prior_entry_hash": prior,
        "record": record,
    })


def _validate_audit(values: Sequence[Mapping[str, Any]]) -> Tuple[Dict[str, Any], ...]:
    fields = (
        "seq", "recorded_at", "event", "prior_entry_hash", "entry_hash",
    )
    result = []
    prior_hash = _AUDIT_GENESIS_HASH
    prior_seq = 0
    for offset, raw in enumerate(values):
        item = _object(raw, f"audit_chain[{offset}]")
        _exact(item, fields, f"audit_chain[{offset}]")
        seq = _positive_integer(item["seq"], f"audit_chain[{offset}].seq")
        if seq <= prior_seq:
            raise LifecycleResilienceError("audit sequence must be strictly increasing")
        prior_seq = seq
        recorded_at = _text(
            item["recorded_at"], f"audit_chain[{offset}].recorded_at"
        )
        event = _object(item["event"], f"audit_chain[{offset}].event")
        if item["prior_entry_hash"] != prior_hash:
            raise LifecycleResilienceError(
                f"audit_chain[{offset}] breaks the prior-entry hash chain"
            )
        record = {"seq": seq, "recorded_at": recorded_at, "event": event}
        expected = _audit_entry_hash(prior_hash, record)
        if item["entry_hash"] != expected:
            raise LifecycleResilienceError(
                f"audit_chain[{offset}] has a stale or forged entry hash"
            )
        prior_hash = expected
        result.append(item)
    return tuple(result)


def _audit_root(values: Sequence[Mapping[str, Any]]) -> str:
    final_hash = values[-1]["entry_hash"] if values else _AUDIT_GENESIS_HASH
    return content_hash({
        "profile": LOCAL_ADMIN_RECOVERY_PROFILE,
        "genesis_hash": _AUDIT_GENESIS_HASH,
        "entry_hashes": [item["entry_hash"] for item in values],
        "final_entry_hash": final_hash,
    })


def _validate_certificate_list(
    values: Sequence[Mapping[str, Any]], role: str
) -> Tuple[Dict[str, Any], ...]:
    fields = (
        "case_id", "certificate_id", "content_hash", "job_id", "outcome",
        "affirmative", "registered_at", "status", "payload",
    )
    result = []
    prior = None
    for offset, raw in enumerate(values):
        where = f"certificate_inventory.{role}[{offset}]"
        item = _object(raw, where)
        _exact(item, fields, where)
        key = (
            _text(item["case_id"], f"{where}.case_id"),
            _text(item["certificate_id"], f"{where}.certificate_id"),
        )
        if prior is not None and key <= prior:
            raise LifecycleResilienceError(
                f"{role} certificate identities must be unique and sorted"
            )
        prior = key
        _text(item["job_id"], f"{where}.job_id")
        _text(item["outcome"], f"{where}.outcome", allow_empty=True)
        if not isinstance(item["affirmative"], bool):
            raise LifecycleResilienceError(f"{where}.affirmative must be boolean")
        _text(item["registered_at"], f"{where}.registered_at")
        status = _text(item["status"], f"{where}.status")
        expected = {"active": "ACTIVE", "superseded": "SUPERSEDED"}.get(role)
        if expected is not None and status != expected:
            raise LifecycleResilienceError(
                f"{where}.status must be {expected!r}"
            )
        if role == "other" and status in {"ACTIVE", "SUPERSEDED"}:
            raise LifecycleResilienceError(
                f"{where} carries an active/superseded certificate in the other partition"
            )
        payload = _object(item["payload"], f"{where}.payload")
        declared = _hash(item["content_hash"], f"{where}.content_hash")
        if declared != content_hash(payload):
            raise LifecycleResilienceError(
                f"{where} content hash does not match its certificate payload"
            )
        result.append(item)
    return tuple(result)


def _validate_certificates(
    value: Mapping[str, Sequence[Mapping[str, Any]]]
) -> Dict[str, Tuple[Dict[str, Any], ...]]:
    document = _object(value, "certificate_inventory")
    _exact(document, ("active", "superseded", "other"), "certificate_inventory")
    return {
        name: _validate_certificate_list(document[name], name)
        for name in ("active", "superseded", "other")
    }


def _validate_objects(values: Sequence[Mapping[str, Any]]) -> Tuple[Dict[str, Any], ...]:
    fields = (
        "object_id", "object_type", "status", "present", "byte_length",
        "content_hash", "payload", "tombstone",
    )
    result = []
    prior = None
    for offset, raw in enumerate(values):
        item = _object(raw, f"object_inventory[{offset}]")
        _exact(item, fields, f"object_inventory[{offset}]")
        object_id = _hash(item["object_id"], f"object_inventory[{offset}].object_id")
        declared = _hash(
            item["content_hash"], f"object_inventory[{offset}].content_hash"
        )
        if object_id != declared:
            raise LifecycleResilienceError(
                f"object_inventory[{offset}] identity and content hash differ"
            )
        if prior is not None and object_id <= prior:
            raise LifecycleResilienceError(
                "object inventory identities must be unique and sorted"
            )
        prior = object_id
        _text(item["object_type"], f"object_inventory[{offset}].object_type")
        _text(item["status"], f"object_inventory[{offset}].status")
        if not isinstance(item["present"], bool):
            raise LifecycleResilienceError(
                f"object_inventory[{offset}].present must be boolean"
            )
        _nonnegative_integer(
            item["byte_length"], f"object_inventory[{offset}].byte_length"
        )
        if item["present"]:
            payload = _copy(item["payload"], f"object_inventory[{offset}].payload")
            if item["tombstone"] is not None:
                raise LifecycleResilienceError(
                    f"object_inventory[{offset}] is present but carries a tombstone"
                )
            if content_hash(payload) != declared:
                raise LifecycleResilienceError(
                    f"object_inventory[{offset}] payload does not match its identity"
                )
        else:
            if item["payload"] is not None:
                raise LifecycleResilienceError(
                    f"object_inventory[{offset}] is absent but carries payload bytes"
                )
            tombstone = _object(
                item["tombstone"], f"object_inventory[{offset}].tombstone"
            )
            if tombstone.get("content_hash") != declared:
                raise LifecycleResilienceError(
                    f"object_inventory[{offset}] tombstone names a different object"
                )
        result.append(item)
    return tuple(result)


def _derived_roots(
    cases: Sequence[Mapping[str, Any]],
    edges: Sequence[Mapping[str, Any]],
    audit: Sequence[Mapping[str, Any]],
    certificates: Mapping[str, Sequence[Mapping[str, Any]]],
    objects: Sequence[Mapping[str, Any]],
) -> Dict[str, str]:
    active_root = content_hash(list(certificates["active"]))
    superseded_root = content_hash(list(certificates["superseded"]))
    other_root = content_hash(list(certificates["other"]))
    certificate_root = content_hash({
        "active_certificate_root": active_root,
        "superseded_certificate_root": superseded_root,
        "other_certificate_root": other_root,
    })
    return {
        "case_root": content_hash(list(cases)),
        "dependency_graph_root": content_hash(list(edges)),
        "audit_chain_root": _audit_root(audit),
        "active_certificate_root": active_root,
        "superseded_certificate_root": superseded_root,
        "other_certificate_root": other_root,
        "certificate_inventory_root": certificate_root,
        "object_inventory_root": content_hash(list(objects)),
    }


def _validate_cross_references(
    cases: Sequence[Mapping[str, Any]],
    certificates: Mapping[str, Sequence[Mapping[str, Any]]],
    objects: Sequence[Mapping[str, Any]],
) -> None:
    by_identity = {str(item["object_id"]): item for item in objects}
    for where, item, expected_type in (
        *(
            (f"case_inventory[{offset}]", item, "CRGCase")
            for offset, item in enumerate(cases)
        ),
        *(
            (f"certificate_inventory.{partition}[{offset}]", item, "DecisionCertificate")
            for partition in ("active", "superseded", "other")
            for offset, item in enumerate(certificates[partition])
        ),
    ):
        stored = by_identity.get(str(item["content_hash"]))
        if stored is None or stored.get("present") is not True:
            raise LifecycleResilienceError(
                f"{where} is absent from the present object inventory"
            )
        if stored.get("object_type") != expected_type:
            raise LifecycleResilienceError(
                f"{where} is stored under object type {stored.get('object_type')!r}, "
                f"not {expected_type!r}"
            )
        if stored.get("payload") != item.get("payload"):
            raise LifecycleResilienceError(
                f"{where} payload differs from the content-addressed object inventory"
            )
        if stored.get("status") != item.get("object_status", item.get("status")):
            raise LifecycleResilienceError(
                f"{where} lifecycle status differs from the object inventory"
            )


@dataclass(frozen=True)
class LocalRecoveryTypedInventory:
    inventory_id: str
    inventory_role: str
    case_inventory: Tuple[Mapping[str, Any], ...]
    dependency_graph: Tuple[Mapping[str, Any], ...]
    audit_chain: Tuple[Mapping[str, Any], ...]
    certificate_inventory: Mapping[str, Tuple[Mapping[str, Any], ...]]
    object_inventory: Tuple[Mapping[str, Any], ...]
    typed_roots: Mapping[str, str]
    inventory_root: str

    def __post_init__(self) -> None:
        _text(self.inventory_id, "inventory_id")
        if self.inventory_role not in LOCAL_RECOVERY_INVENTORY_ROLES:
            raise LifecycleResilienceError(
                f"unknown local recovery inventory role {self.inventory_role!r}"
            )
        cases = _validate_cases(self.case_inventory)
        edges = _validate_edges(self.dependency_graph)
        audit = _validate_audit(self.audit_chain)
        certificates = _validate_certificates(self.certificate_inventory)
        objects = _validate_objects(self.object_inventory)
        _validate_cross_references(cases, certificates, objects)
        roots = _object(self.typed_roots, "typed_roots")
        _exact(roots, LOCAL_RECOVERY_TYPED_ROOT_FIELDS, "typed_roots")
        for field, value in roots.items():
            _hash(value, f"typed_roots.{field}")
        derived = _derived_roots(cases, edges, audit, certificates, objects)
        if roots != derived:
            stale = sorted(name for name in derived if roots.get(name) != derived[name])
            raise LifecycleResilienceError(
                f"local recovery inventory carries stale typed roots {stale}"
            )
        expected_inventory_root = content_hash({
            "profile": LOCAL_ADMIN_RECOVERY_PROFILE,
            "typed_roots": derived,
        })
        if self.inventory_root != expected_inventory_root:
            raise LifecycleResilienceError(
                "local recovery inventory root does not bind its typed roots"
            )

    def to_canonical(self) -> Dict[str, Any]:
        certificates = {
            name: [_copy(item, f"certificate_inventory.{name}") for item in self.certificate_inventory[name]]
            for name in ("active", "superseded", "other")
        }
        return {
            "record_type": "LocalRecoveryTypedInventory",
            "profile": LOCAL_ADMIN_RECOVERY_PROFILE,
            "schema_version": LOCAL_ADMIN_RECOVERY_SCHEMA_VERSION,
            "inventory_id": self.inventory_id,
            "inventory_role": self.inventory_role,
            "case_inventory": [_copy(item, "case inventory item") for item in self.case_inventory],
            "dependency_graph": [_copy(item, "dependency edge") for item in self.dependency_graph],
            "audit_chain": [_copy(item, "audit chain entry") for item in self.audit_chain],
            "certificate_inventory": certificates,
            "object_inventory": [_copy(item, "object inventory item") for item in self.object_inventory],
            "typed_roots": _copy(self.typed_roots, "typed roots"),
            "inventory_root": self.inventory_root,
            "counts": {
                "cases": len(self.case_inventory),
                "dependency_edges": len(self.dependency_graph),
                "audit_entries": len(self.audit_chain),
                "active_certificates": len(certificates["active"]),
                "superseded_certificates": len(certificates["superseded"]),
                "other_certificates": len(certificates["other"]),
                "objects": len(self.object_inventory),
            },
        }


def create_local_recovery_inventory(
    inventory_id: str,
    inventory_role: str,
    *,
    cases: Sequence[Mapping[str, Any]],
    dependency_edges: Sequence[Mapping[str, Any]],
    audit_records: Sequence[Mapping[str, Any]],
    certificates: Mapping[str, Sequence[Mapping[str, Any]]],
    objects: Sequence[Mapping[str, Any]],
) -> LocalRecoveryTypedInventory:
    """Build one role-bound inventory and derive every typed root."""
    normalized_cases = _validate_cases(
        sorted((_object(item, "case inventory item") for item in cases),
               key=lambda item: (item["case_id"], item["case_version"]))
    )
    normalized_edges = _validate_edges(
        sorted((_object(item, "dependency edge") for item in dependency_edges),
               key=lambda item: (item.get("case_id") or "", item["edge_id"]))
    )
    audit_entries = []
    prior = _AUDIT_GENESIS_HASH
    for raw in sorted(
        (_object(item, "audit record") for item in audit_records),
        key=lambda item: item["seq"],
    ):
        _exact(raw, ("seq", "recorded_at", "event"), "audit record")
        record = {
            "seq": _positive_integer(raw["seq"], "audit record.seq"),
            "recorded_at": _text(raw["recorded_at"], "audit record.recorded_at"),
            "event": _object(raw["event"], "audit record.event"),
        }
        entry_hash = _audit_entry_hash(prior, record)
        audit_entries.append({
            **record,
            "prior_entry_hash": prior,
            "entry_hash": entry_hash,
        })
        prior = entry_hash
    normalized_audit = _validate_audit(audit_entries)
    normalized_certificates = _validate_certificates({
        name: sorted(
            (_object(item, f"certificate {name}") for item in certificates.get(name, ())),
            key=lambda item: (item["case_id"], item["certificate_id"]),
        )
        for name in ("active", "superseded", "other")
    })
    normalized_objects = _validate_objects(
        sorted((_object(item, "object inventory item") for item in objects),
               key=lambda item: item["object_id"])
    )
    roots = _derived_roots(
        normalized_cases, normalized_edges, normalized_audit,
        normalized_certificates, normalized_objects,
    )
    return LocalRecoveryTypedInventory(
        inventory_id=_text(inventory_id, "inventory_id"),
        inventory_role=inventory_role,
        case_inventory=normalized_cases,
        dependency_graph=normalized_edges,
        audit_chain=normalized_audit,
        certificate_inventory=normalized_certificates,
        object_inventory=normalized_objects,
        typed_roots=roots,
        inventory_root=content_hash({
            "profile": LOCAL_ADMIN_RECOVERY_PROFILE,
            "typed_roots": roots,
        }),
    )


def load_local_recovery_inventory(
    value: Any, *, expected_role: str | None = None
) -> LocalRecoveryTypedInventory:
    """Decode the closed portable inventory contract and reject stale roots."""
    if isinstance(value, LocalRecoveryTypedInventory):
        instance = value
        document = instance.to_canonical()
    else:
        document = _object(value, "local recovery inventory")
        _exact(document, (
            "record_type", "profile", "schema_version", "inventory_id",
            "inventory_role", "case_inventory", "dependency_graph", "audit_chain",
            "certificate_inventory", "object_inventory", "typed_roots",
            "inventory_root", "counts",
        ), "local recovery inventory")
        if document["record_type"] != "LocalRecoveryTypedInventory":
            raise LifecycleResilienceError("unsupported local recovery inventory type")
        if document["profile"] != LOCAL_ADMIN_RECOVERY_PROFILE:
            raise LifecycleResilienceError("unsupported local recovery inventory profile")
        if document["schema_version"] != LOCAL_ADMIN_RECOVERY_SCHEMA_VERSION:
            raise LifecycleResilienceError("unsupported local recovery inventory schema version")
        instance = LocalRecoveryTypedInventory(
            inventory_id=str(document["inventory_id"]),
            inventory_role=str(document["inventory_role"]),
            case_inventory=tuple(document["case_inventory"]),
            dependency_graph=tuple(document["dependency_graph"]),
            audit_chain=tuple(document["audit_chain"]),
            certificate_inventory={
                name: tuple(document["certificate_inventory"][name])
                for name in ("active", "superseded", "other")
            },
            object_inventory=tuple(document["object_inventory"]),
            typed_roots=dict(document["typed_roots"]),
            inventory_root=str(document["inventory_root"]),
        )
        if document != instance.to_canonical():
            raise LifecycleResilienceError(
                "local recovery inventory is not the canonical closed contract"
            )
    if expected_role is not None and instance.inventory_role != expected_role:
        raise LifecycleResilienceError(
            f"expected {expected_role!r} inventory, found {instance.inventory_role!r}"
        )
    return instance


@dataclass(frozen=True)
class LocalAdminRecoveryEvidence:
    recovery_id: str
    source_inventory_hash: str
    backup_inventory_hash: str
    restored_inventory_hash: str
    source_inventory_root: str
    backup_inventory_root: str
    restored_inventory_root: str
    typed_roots: Mapping[str, str]
    archive_sha256: str
    backup_manifest_hash: str
    authority: str

    def __post_init__(self) -> None:
        _text(self.recovery_id, "recovery_id")
        _text(self.authority, "recovery authority")
        for field in (
            "source_inventory_hash", "backup_inventory_hash",
            "restored_inventory_hash", "source_inventory_root",
            "backup_inventory_root", "restored_inventory_root", "archive_sha256",
            "backup_manifest_hash",
        ):
            _hash(getattr(self, field), field)
        roots = _object(self.typed_roots, "recovery typed_roots")
        _exact(roots, LOCAL_RECOVERY_TYPED_ROOT_FIELDS, "recovery typed_roots")
        for field, value in roots.items():
            _hash(value, f"recovery typed_roots.{field}")
        if len({
            self.source_inventory_root,
            self.backup_inventory_root,
            self.restored_inventory_root,
        }) != 1:
            raise LifecycleResilienceError(
                "recovery evidence inventory roots are not identical"
            )

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "record_type": "LocalAdminRecoveryEvidence",
            "profile": LOCAL_ADMIN_RECOVERY_PROFILE,
            "schema_version": LOCAL_ADMIN_RECOVERY_SCHEMA_VERSION,
            "recovery_id": self.recovery_id,
            "source_inventory_hash": self.source_inventory_hash,
            "backup_inventory_hash": self.backup_inventory_hash,
            "restored_inventory_hash": self.restored_inventory_hash,
            "source_inventory_root": self.source_inventory_root,
            "backup_inventory_root": self.backup_inventory_root,
            "restored_inventory_root": self.restored_inventory_root,
            "typed_roots": _copy(self.typed_roots, "recovery typed roots"),
            "matched_typed_roots": list(LOCAL_RECOVERY_TYPED_ROOT_FIELDS),
            "archive_sha256": self.archive_sha256,
            "backup_manifest_hash": self.backup_manifest_hash,
            "restore_target_precondition": "VERIFIED_ABSENT_OR_EMPTY",
            "integrity_status": "TYPED_CANONICAL_ROOTS_MATCH",
            "authority": self.authority,
            "claim_boundary": _LOCAL_RECOVERY_BOUNDARY,
        }


def record_local_admin_recovery(
    recovery_id: str,
    source_inventory: Any,
    backup_inventory: Any,
    restored_inventory: Any,
    *,
    archive_sha256: str,
    backup_manifest: Mapping[str, Any],
    destination_was_empty: bool,
    authority: str,
) -> LocalAdminRecoveryEvidence:
    """Bind a real source/archive/empty-target drill to exact typed roots."""
    source = load_local_recovery_inventory(
        source_inventory, expected_role="SOURCE"
    )
    backup = load_local_recovery_inventory(
        backup_inventory, expected_role="BACKUP_ARCHIVE"
    )
    restored = load_local_recovery_inventory(
        restored_inventory, expected_role="RESTORED_EMPTY_TARGET"
    )
    if destination_was_empty is not True:
        raise LifecycleResilienceError(
            "local recovery evidence requires a verified absent or empty restore target"
        )
    if not (
        source.typed_roots == backup.typed_roots == restored.typed_roots
        and source.inventory_root == backup.inventory_root == restored.inventory_root
    ):
        mismatches = sorted(
            name for name in LOCAL_RECOVERY_TYPED_ROOT_FIELDS
            if len({
                source.typed_roots[name], backup.typed_roots[name],
                restored.typed_roots[name],
            }) != 1
        )
        raise LifecycleResilienceError(
            f"source, archive, and restored typed roots differ for {mismatches}"
        )
    manifest = _object(backup_manifest, "backup manifest")
    if manifest.get("format") != "crg-local-backup-v1":
        raise LifecycleResilienceError("unsupported local backup manifest profile")
    return LocalAdminRecoveryEvidence(
        recovery_id=_text(recovery_id, "recovery_id"),
        source_inventory_hash=content_hash(source.to_canonical()),
        backup_inventory_hash=content_hash(backup.to_canonical()),
        restored_inventory_hash=content_hash(restored.to_canonical()),
        source_inventory_root=source.inventory_root,
        backup_inventory_root=backup.inventory_root,
        restored_inventory_root=restored.inventory_root,
        typed_roots=dict(source.typed_roots),
        archive_sha256=_hash(archive_sha256, "archive_sha256"),
        backup_manifest_hash=content_hash(manifest),
        authority=_text(authority, "recovery authority"),
    )


def create_local_recovery_lifecycle_snapshot(
    snapshot_id: str, inventory: Any
) -> LifecyclePortableSnapshot:
    """Project an independently extracted store inventory into lifecycle bytes.

    Present content-addressed objects retain their original hashes, so an
    existing ``BackupRestoreRecoveryRecord`` can prove that every deterministic
    replay record and verifier input traversed the actual admin backup path.
    The four required typed inventories are carried as additional protected
    objects rather than replaced by a single synthetic logical snapshot.
    """
    value = load_local_recovery_inventory(inventory)
    objects: Dict[str, Any] = {
        "local-recovery:audit-chain": {
            "record_type": "LocalRecoveryAuditChain",
            "profile": LOCAL_ADMIN_RECOVERY_PROFILE,
            "entries": list(value.audit_chain),
            "root": value.typed_roots["audit_chain_root"],
        },
        "local-recovery:case-inventory": {
            "record_type": "LocalRecoveryCaseInventory",
            "profile": LOCAL_ADMIN_RECOVERY_PROFILE,
            "cases": list(value.case_inventory),
            "root": value.typed_roots["case_root"],
        },
        "local-recovery:certificate-inventory": {
            "record_type": "LocalRecoveryCertificateInventory",
            "profile": LOCAL_ADMIN_RECOVERY_PROFILE,
            "certificates": {
                name: list(value.certificate_inventory[name])
                for name in ("active", "superseded", "other")
            },
            "active_root": value.typed_roots["active_certificate_root"],
            "superseded_root": value.typed_roots["superseded_certificate_root"],
            "other_root": value.typed_roots["other_certificate_root"],
            "root": value.typed_roots["certificate_inventory_root"],
        },
        "local-recovery:dependency-graph": {
            "record_type": "LocalRecoveryDependencyGraph",
            "profile": LOCAL_ADMIN_RECOVERY_PROFILE,
            "edges": list(value.dependency_graph),
            "root": value.typed_roots["dependency_graph_root"],
        },
        "local-recovery:typed-roots": {
            "record_type": "LocalRecoveryTypedRoots",
            "profile": LOCAL_ADMIN_RECOVERY_PROFILE,
            "typed_roots": dict(value.typed_roots),
            "inventory_root": value.inventory_root,
        },
    }
    for item in value.object_inventory:
        if item["present"]:
            objects[f"store-object:{item['object_id']}"] = item["payload"]
    return create_lifecycle_snapshot(snapshot_id, objects)
