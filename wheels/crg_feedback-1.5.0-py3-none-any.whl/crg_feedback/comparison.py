"""Portable cumulative comparative evidence for the complete v1.1-v1.4 journey.

The record is deliberately an evidence index, not a lifecycle authority.  It
embeds every required artifact and its verifier inputs, fixes the denominator
to a release-and-role matrix, and carries explicit per-artifact privacy
classification.  It does not declassify source material or infer performance,
economic, field, adoption, or transition claims.
"""
from __future__ import annotations

import copy
from dataclasses import dataclass
from typing import Any, Mapping, Sequence

from crg_model.canonical import content_hash

__all__ = [
    "CUMULATIVE_COMPARISON_AUTHORITY",
    "CUMULATIVE_COMPARISON_CLAIM_BOUNDARY",
    "CUMULATIVE_COMPARISON_FIRST_RELEASE",
    "CUMULATIVE_COMPARISON_PROFILE",
    "CUMULATIVE_COMPARISON_SCHEMA_VERSION",
    "CUMULATIVE_COMPARISON_ROLE_SPECS",
    "CumulativeComparisonError",
    "CumulativeLifecycleComparison",
    "build_cumulative_lifecycle_comparison",
]


CUMULATIVE_COMPARISON_SCHEMA_VERSION = "1.4.0"
CUMULATIVE_COMPARISON_PROFILE = "crg-cumulative-lifecycle-comparison/portable@1"
CUMULATIVE_COMPARISON_FIRST_RELEASE = "v1.4/UNIFIED_DECISION_LIFECYCLE"
CUMULATIVE_COMPARISON_AUTHORITY = "NON_AUTHORIZING"
CUMULATIVE_COMPARISON_CLAIM_BOUNDARY = (
    "Content-bound journey evidence only. This record does not authorize case state, "
    "declassify an input, establish field performance, infer business savings or ROI, "
    "rank methods, generalize beyond the declared scope, or replace any engineering "
    "workflow that produced the bound artifacts."
)

# (stage, role, record_type, portable lifecycle envelope)
CUMULATIVE_COMPARISON_ROLE_SPECS = (
    ("v1.1", "SCOPED_WORKFLOW_COMPARISON", "ComparativeWorkflowEvaluation", False),
    ("v1.2", "CERTIFIED_CHANGE_COMPARISON", "ComparativeChangeEvidence", False),
    ("v1.3", "ETQ_RESULT_INGESTION", "ResultIngestionRecord", True),
    ("v1.3", "QUALIFICATION_DISPOSITION", "QualificationDisposition", True),
    ("v1.3", "SELECTIVE_REVALIDATION", "SelectiveRevalidationRecord", True),
    ("v1.3", "REPLACEMENT", "ReplacementRecord", True),
    ("v1.4", "CONTINUED_VALIDITY", "ContinuedValidityView", True),
    ("v1.4", "LIFECYCLE_REPLAY", "LifecycleReplayRecord", True),
    ("v1.4", "BACKUP_RESTORE_RECOVERY", "BackupRestoreRecoveryRecord", True),
    ("v1.4", "MIGRATION_REVERIFICATION", "MigrationReverificationRecord", True),
)

_STAGES = ("v1.1", "v1.2", "v1.3", "v1.4")
_PRIVACY_CLASSIFICATIONS = frozenset(
    {"PUBLIC_REFERENCE", "LOCAL_PRIVATE", "REDACTED_PORTABLE"}
)
_PRIVACY_FIELDS = frozenset(
    {
        "classification",
        "classification_basis",
        "export_permitted",
        "redaction_applied",
        "field_observation",
        "input_class",
        "evidence_class",
    }
)


class CumulativeComparisonError(ValueError):
    """The proposed cumulative comparison is incomplete or non-portable."""


def _identity(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value.strip() or value != value.strip():
        raise CumulativeComparisonError(f"{field} must be a normalized non-empty string")
    return value


def _object(value: Any, field: str) -> dict:
    if not isinstance(value, Mapping):
        raise CumulativeComparisonError(f"{field} must be an object")
    result = copy.deepcopy(dict(value))
    try:
        content_hash(result)
    except Exception as error:
        raise CumulativeComparisonError(f"{field} is not portable canonical JSON: {error}") from error
    return result


def _sealed(value: Mapping[str, Any], key: str) -> dict:
    result = copy.deepcopy(dict(value))
    result.pop(key, None)
    result[key] = content_hash(result)
    return result


def _exact_count(value: int) -> dict:
    return {"exact": str(value)}


def _privacy(value: Any, artifact_id: str) -> dict:
    item = _object(value, f"privacy_controls.{artifact_id}")
    if set(item) != _PRIVACY_FIELDS:
        raise CumulativeComparisonError(
            f"privacy_controls.{artifact_id} has a missing or unsupported field set"
        )
    classification = _identity(item.get("classification"), "privacy classification")
    if classification not in _PRIVACY_CLASSIFICATIONS:
        raise CumulativeComparisonError(f"unsupported privacy classification {classification!r}")
    _identity(item.get("classification_basis"), "privacy classification basis")
    _identity(item.get("input_class"), "privacy input class")
    _identity(item.get("evidence_class"), "privacy evidence class")
    for field in ("export_permitted", "redaction_applied", "field_observation"):
        if not isinstance(item.get(field), bool):
            raise CumulativeComparisonError(f"privacy {field} must be boolean")
    if classification == "PUBLIC_REFERENCE":
        if (
            item["export_permitted"] is not True
            or item["redaction_applied"] is not False
            or item["field_observation"] is not False
            or item["input_class"] not in {"REFERENCE", "SYNTHETIC_REFERENCE"}
        ):
            raise CumulativeComparisonError(
                "PUBLIC_REFERENCE requires export permission, no redaction, no field "
                "observation, and a REFERENCE or SYNTHETIC_REFERENCE input class"
            )
    elif classification == "LOCAL_PRIVATE" and item["export_permitted"] is not False:
        raise CumulativeComparisonError("LOCAL_PRIVATE artifacts cannot be export-permitted")
    elif classification == "REDACTED_PORTABLE" and not (
        item["export_permitted"] is True and item["redaction_applied"] is True
    ):
        raise CumulativeComparisonError(
            "REDACTED_PORTABLE requires export permission and applied redaction"
        )
    return item


def _field_observation_paths(value: Any, path: str) -> list[str]:
    paths: list[str] = []
    if isinstance(value, Mapping):
        for key, item in value.items():
            child = f"{path}.{key}"
            if str(key).strip().lower().replace("-", "_") == "field_observation":
                if item is True:
                    paths.append(child)
            paths.extend(_field_observation_paths(item, child))
    elif isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            paths.extend(_field_observation_paths(item, f"{path}[{index}]"))
    return paths


def _nonreference_input_paths(value: Any, path: str) -> list[str]:
    paths: list[str] = []
    if isinstance(value, Mapping):
        for key, item in value.items():
            child = f"{path}.{key}"
            if str(key).strip().lower().replace("-", "_") == "input_class":
                # Registry import reports bind source-column names under
                # ``field_mapping``.  An ``input_class`` key there maps the
                # source column to a target field such as
                # ``attributes.input_class``; it is metadata, not a value.
                source_column_mapping = (
                    path.endswith(".field_mapping") and isinstance(item, str)
                )
                if (
                    not source_column_mapping
                    and item not in {"REFERENCE", "SYNTHETIC_REFERENCE"}
                ):
                    paths.append(child)
            paths.extend(_nonreference_input_paths(item, child))
    elif isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            paths.extend(_nonreference_input_paths(item, f"{path}[{index}]"))
    return paths


def _portable_artifact(value: Any, record_type: str, envelope: bool, field: str) -> dict:
    artifact = _object(value, field)
    if envelope:
        if set(artifact) != {"record", "verification_inputs"}:
            raise CumulativeComparisonError(
                f"{field} must embed exactly record and verification_inputs"
            )
        if not isinstance(artifact["record"], Mapping) or not isinstance(
            artifact["verification_inputs"], Mapping
        ):
            raise CumulativeComparisonError(f"{field} lifecycle envelope is malformed")
        actual_type = artifact["record"].get("record_type")
    else:
        actual_type = artifact.get("record_type")
    if actual_type != record_type:
        raise CumulativeComparisonError(
            f"{field} carries {actual_type!r}; expected {record_type!r}"
        )
    return artifact


def _scope(value: Any) -> dict:
    scope = _object(value, "scope")
    required = {
        "case_id",
        "technology_scope",
        "decision_scope",
        "evidence_scope",
        "change_scope",
        "journey_time_scope",
    }
    if set(scope) != required:
        raise CumulativeComparisonError("scope has a missing or unsupported field set")
    _identity(scope.get("case_id"), "scope.case_id")
    for field in sorted(required - {"case_id"}):
        if not isinstance(scope.get(field), Mapping):
            raise CumulativeComparisonError(f"scope.{field} must be an object")
    scope["release_stages"] = list(_STAGES)
    return _sealed(scope, "scope_hash")


def _entries(
    v1_1_comparison: Mapping[str, Any],
    v1_2_change_comparison: Mapping[str, Any],
    v1_3_envelopes: Mapping[str, Mapping[str, Any]],
    v1_4_envelopes: Mapping[str, Mapping[str, Any]],
    privacy_controls: Mapping[str, Mapping[str, Any]],
) -> list[dict]:
    v13 = _object(v1_3_envelopes, "v1_3_envelopes")
    v14 = _object(v1_4_envelopes, "v1_4_envelopes")
    sources: dict[tuple[str, str], Any] = {
        ("v1.1", "SCOPED_WORKFLOW_COMPARISON"): v1_1_comparison,
        ("v1.2", "CERTIFIED_CHANGE_COMPARISON"): v1_2_change_comparison,
        **{("v1.3", role): value for role, value in v13.items()},
        **{("v1.4", role): value for role, value in v14.items()},
    }
    expected = {(stage, role) for stage, role, _record_type, _envelope in CUMULATIVE_COMPARISON_ROLE_SPECS}
    if set(sources) != expected:
        missing = sorted(expected - set(sources))
        unknown = sorted(set(sources) - expected)
        raise CumulativeComparisonError(
            f"cumulative artifact roles are incomplete: missing={missing}, unknown={unknown}"
        )
    privacy_map = _object(privacy_controls, "privacy_controls")
    expected_ids = {f"{stage}:{role}" for stage, role in expected}
    if set(privacy_map) != expected_ids:
        raise CumulativeComparisonError(
            "privacy_controls must map one-to-one to the complete artifact denominator"
        )

    entries = []
    for stage, role, record_type, envelope in CUMULATIVE_COMPARISON_ROLE_SPECS:
        artifact_id = f"{stage}:{role}"
        artifact = _portable_artifact(
            sources[(stage, role)], record_type, envelope, artifact_id
        )
        privacy = _privacy(privacy_map[artifact_id], artifact_id)
        observed_paths = _field_observation_paths(artifact, artifact_id)
        if privacy["classification"] == "PUBLIC_REFERENCE":
            if observed_paths:
                raise CumulativeComparisonError(
                    f"{artifact_id} is PUBLIC_REFERENCE but explicitly carries field "
                    f"observation markers at {observed_paths}"
                )
            nonreference_paths = _nonreference_input_paths(artifact, artifact_id)
            if nonreference_paths:
                raise CumulativeComparisonError(
                    f"{artifact_id} is PUBLIC_REFERENCE but explicitly carries "
                    f"non-reference input classes at {nonreference_paths}"
                )
        entry = {
            "artifact_id": artifact_id,
            "stage": stage,
            "role": role,
            "record_type": record_type,
            "portable_lifecycle_envelope": envelope,
            "artifact": artifact,
            "artifact_hash": content_hash(artifact),
            "privacy": privacy,
        }
        entries.append(_sealed(entry, "entry_hash"))
    return entries


def _denominator(entries: Sequence[Mapping[str, Any]]) -> dict:
    members = [
        {
            "artifact_id": item["artifact_id"],
            "stage": item["stage"],
            "role": item["role"],
            "artifact_hash": item["artifact_hash"],
        }
        for item in entries
    ]
    stages = []
    for stage in _STAGES:
        stage_members = [item["artifact_id"] for item in entries if item["stage"] == stage]
        stages.append(
            {"stage": stage, "members": stage_members, "count": _exact_count(len(stage_members))}
        )
    return _sealed(
        {
            "profile": "crg-cumulative-journey-denominator/fixed-roles@1",
            "members": members,
            "count": _exact_count(len(members)),
            "stage_denominators": stages,
            "complete": True,
        },
        "denominator_hash",
    )


def _record_of(entry: Mapping[str, Any]) -> Mapping[str, Any]:
    artifact = entry["artifact"]
    return artifact["record"] if entry["portable_lifecycle_envelope"] else artifact


def _journey_facts(entries: Sequence[Mapping[str, Any]]) -> dict:
    by_role = {item["role"]: _record_of(item) for item in entries}
    v11 = by_role["SCOPED_WORKFLOW_COMPARISON"]
    v12 = by_role["CERTIFIED_CHANGE_COMPARISON"]
    v12_facts = v12.get("system_derived_facts") or {}
    return {
        "facts_profile": "crg-cumulative-journey-direct-fields@1",
        "v1.1": {
            "evaluation_id": v11.get("evaluation_id"),
            "scope_hash": (v11.get("scope") or {}).get("scope_hash"),
            "comparison_status": (v11.get("comparability") or {}).get("status"),
            "method_count": _exact_count(len(v11.get("methods") or [])),
            "case_count": _exact_count(len(v11.get("workload") or [])),
        },
        "v1.2": {
            "comparison_id": v12.get("comparison_id"),
            "scope_hash": (v12.get("scope") or {}).get("scope_hash"),
            "minimum_action": v12_facts.get("minimum_action"),
            "preserved_count": (v12_facts.get("preserved_work") or {}).get("count"),
            "recomputed_count": (v12_facts.get("recomputed_work") or {}).get("count"),
        },
        "v1.3": {
            "result_ingestion_evidence_class": by_role["ETQ_RESULT_INGESTION"].get(
                "evidence_class"
            ),
            "qualification_state": by_role["QUALIFICATION_DISPOSITION"].get("state"),
            "qualification_stopping_condition": by_role[
                "QUALIFICATION_DISPOSITION"
            ].get("stopping_condition"),
            "selective_revalidation_state": by_role["SELECTIVE_REVALIDATION"].get(
                "state"
            ),
            "replacement_action": by_role["REPLACEMENT"].get("action_completed"),
        },
        "v1.4": {
            "continued_validity_status": by_role["CONTINUED_VALIDITY"].get("status"),
            "continued_validity_blocking_count": _exact_count(
                len(by_role["CONTINUED_VALIDITY"].get("blocking_dimensions") or [])
            ),
            "replay_complete": by_role["LIFECYCLE_REPLAY"].get("replay_complete"),
            "replay_entry_count": _exact_count(
                len(by_role["LIFECYCLE_REPLAY"].get("entries") or [])
            ),
            "recovery_integrity_status": by_role["BACKUP_RESTORE_RECOVERY"].get(
                "integrity_status"
            ),
            "migration_disposition": by_role["MIGRATION_REVERIFICATION"].get(
                "disposition"
            ),
        },
        "conclusion": "NO_AGGREGATE_SCORE_OR_AUTHORIZING_CONCLUSION",
    }


def _privacy_summary(entries: Sequence[Mapping[str, Any]]) -> dict:
    counts = {name: 0 for name in sorted(_PRIVACY_CLASSIFICATIONS)}
    field_count = 0
    export_count = 0
    for item in entries:
        privacy = item["privacy"]
        counts[privacy["classification"]] += 1
        field_count += int(privacy["field_observation"])
        export_count += int(privacy["export_permitted"])
    return {
        "classification_counts": [
            {"classification": name, "count": _exact_count(counts[name])}
            for name in sorted(counts)
        ],
        "field_observation_count": _exact_count(field_count),
        "export_permitted_count": _exact_count(export_count),
        "classification_is_declared_not_inferred": True,
        "record_declassifies_source_material": False,
        "external_transmission_required": False,
    }


@dataclass(frozen=True)
class CumulativeLifecycleComparison:
    """Immutable convenience wrapper for the v1.4 cumulative artifact."""

    record: Mapping[str, Any]

    def to_canonical(self) -> dict:
        return copy.deepcopy(dict(self.record))


def build_cumulative_lifecycle_comparison(
    journey_id: str,
    *,
    scope: Mapping[str, Any],
    v1_1_comparison: Mapping[str, Any],
    v1_2_change_comparison: Mapping[str, Any],
    v1_3_envelopes: Mapping[str, Mapping[str, Any]],
    v1_4_envelopes: Mapping[str, Mapping[str, Any]],
    privacy_controls: Mapping[str, Mapping[str, Any]],
    limitations: Sequence[str],
) -> CumulativeLifecycleComparison:
    """Build a fixed-denominator portable comparison over the full 1.x journey."""

    identifier = _identity(journey_id, "journey_id")
    entries = _entries(
        v1_1_comparison,
        v1_2_change_comparison,
        v1_3_envelopes,
        v1_4_envelopes,
        privacy_controls,
    )
    if not isinstance(limitations, (list, tuple)):
        raise CumulativeComparisonError("limitations must be a list")
    limitation_records = sorted(_identity(item, "limitation") for item in limitations)
    if not limitation_records or len(limitation_records) != len(set(limitation_records)):
        raise CumulativeComparisonError("limitations must be non-empty and unique")
    record = {
        "record_type": "CumulativeLifecycleComparison",
        "schema_version": CUMULATIVE_COMPARISON_SCHEMA_VERSION,
        "profile": CUMULATIVE_COMPARISON_PROFILE,
        "first_release_attribution": CUMULATIVE_COMPARISON_FIRST_RELEASE,
        "journey_id": identifier,
        "authority": CUMULATIVE_COMPARISON_AUTHORITY,
        "authorizing": False,
        "semantic_effect": "NONE",
        "evidence_class": "NON_AUTHORIZING_CUMULATIVE_PRODUCT_EVIDENCE",
        "claim_boundary": CUMULATIVE_COMPARISON_CLAIM_BOUNDARY,
        "scope": _scope(scope),
        "artifacts": entries,
        "denominator": _denominator(entries),
        "journey_facts": _journey_facts(entries),
        "privacy_summary": _privacy_summary(entries),
        "limitations": limitation_records,
    }
    return CumulativeLifecycleComparison(_sealed(record, "record_hash"))
