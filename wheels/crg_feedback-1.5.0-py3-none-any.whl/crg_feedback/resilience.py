"""Portable replay, backup/restore, and migration re-verification evidence.

This module is the producer side of roadmap section 6.5's offline-resilience
boundary.  It only creates immutable, content-addressed records.  Acceptance
of those records belongs to the independent :mod:`crg_verify` implementation.

Three distinctions are structural here:

* deterministic replay means replaying the exact typed lifecycle record and
  its exact verifier-input envelope in a declared order;
* a backup/restore claim means byte-for-byte inventory recovery followed by
  that semantic replay, not availability, PITR, or disaster-recovery service
  levels; and
* migration re-verification is available only for a registered,
  independently classifiable semantically-equivalent transform.  It never
  inherits or reissues a substantive decision merely because fields look
  similar.

The records make no generic physical-safety claim and contain no synthetic
health, confidence, or readiness score.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Dict, Iterable, Mapping, Sequence, Tuple

from crg_model.canonical import canonical_json, content_hash, is_hash
from crg_model.migration import (
    DEFAULT_MIGRATION_REGISTRY,
    MigrationProofError,
    verify_classification_evidence,
)

__all__ = [
    "LIFECYCLE_RESILIENCE_PROFILE",
    "LIFECYCLE_RESILIENCE_SCHEMA_VERSION",
    "LIFECYCLE_REPLAY_PROFILE",
    "LIFECYCLE_FIRST_RELEASE_ATTRIBUTION",
    "LifecycleResilienceError",
    "LifecycleReplayEntry",
    "LifecycleReplayRecord",
    "LifecyclePortableSnapshot",
    "BackupRestoreRecoveryRecord",
    "MigrationReverificationRecord",
    "build_lifecycle_replay_record",
    "create_lifecycle_snapshot",
    "record_backup_restore_recovery",
    "record_migration_reverification",
    "resilience_verification_inputs",
]


LIFECYCLE_RESILIENCE_PROFILE = "crg.lifecycle-resilience"
LIFECYCLE_RESILIENCE_SCHEMA_VERSION = "1.0.0"
LIFECYCLE_REPLAY_PROFILE = "crg-lifecycle/independent-replay@1"

_V13 = "v1.3/ETQ_LIFECYCLE"
_V14 = "v1.4/DECISION_LIFECYCLE"

# This is deliberately duplicated by the independent verifier.  A producer
# and verifier that shared the same mutable lookup would not provide an
# independent first-release-attribution check.
LIFECYCLE_FIRST_RELEASE_ATTRIBUTION = {
    "ETQDecisionLoop": _V13,
    "ResultIngestionRecord": _V13,
    "SelectiveRevalidationRecord": _V13,
    "ReplacementRecord": _V13,
    "QualificationDisposition": _V13,
    "DecisionScopedConversion": _V14,
    "ConversionBindingImpact": _V14,
    "SignatureVerificationRecord": _V14,
    "ApprovalRecord": _V14,
    "ApprovalWithdrawal": _V14,
    "LifecycleAuthorization": _V14,
    "ContinuedValidityView": _V14,
    "LifecycleReplayRecord": _V14,
    "BackupRestoreRecoveryRecord": _V14,
    "MigrationReverificationRecord": _V14,
}

_LIFECYCLE_ENVELOPE_CONTRACTS = {
    "ETQDecisionLoop": ("verify_etq_decision_loop", frozenset()),
    "ResultIngestionRecord": (
        "verify_result_ingestion_record",
        frozenset({"result_record", "new_evidence", "prior_evidence"}),
    ),
    "SelectiveRevalidationRecord": (
        "verify_selective_revalidation_record",
        frozenset({"dependency_edges", "artifact_universe"}),
    ),
    "ReplacementRecord": (
        "verify_replacement_record",
        frozenset({
            "revalidation_record", "prior_artifact", "replacement_artifact",
            "dependency_edges", "artifact_universe",
        }),
    ),
    "QualificationDisposition": (
        "verify_qualification_disposition",
        frozenset({
            "qualification_result", "ingestions", "required_evidence_ids",
            "verification_basis", "minimum_evidence_status",
        }),
    ),
    "DecisionScopedConversion": (
        "verify_decision_scoped_conversion",
        frozenset({
            "conversion_record", "source_case", "target_case", "retained_geometry",
            "decision_scope", "decision_certificate", "semantic_verifications",
            "dependencies",
        }),
    ),
    "ConversionBindingImpact": (
        "verify_conversion_binding_impact",
        frozenset({
            "binding", "current_conversion_record", "current_retained_geometry",
            "current_decision_scope", "current_decision_certificate",
        }),
    ),
    "SignatureVerificationRecord": (
        "verify_signature_verification_record",
        frozenset({
            "signature_content", "trusted_record_root", "signed_content",
            "cryptography_replayed",
        }),
    ),
    "ApprovalRecord": (
        "verify_approval_record",
        frozenset({"trusted_signature_roots", "signature_content", "artifact"}),
    ),
    "ApprovalWithdrawal": (
        "verify_approval_withdrawal",
        frozenset({"trusted_signature_roots", "signature_content", "approval"}),
    ),
    "LifecycleAuthorization": (
        "verify_lifecycle_authorization",
        frozenset({
            "approvals", "withdrawals", "policy", "clock",
            "trusted_signature_roots", "artifact",
        }),
    ),
    "ContinuedValidityView": (
        "verify_continued_validity_view",
        frozenset({"artifact", "dimension_sources", "trigger_sources", "dependencies"}),
    ),
    "LifecycleReplayRecord": (
        "verify_lifecycle_replay_record",
        frozenset({"source_checkpoint", "records", "verification_inputs"}),
    ),
    "BackupRestoreRecoveryRecord": (
        "verify_backup_restore_recovery_record",
        frozenset({
            "source_snapshot", "backup_snapshot", "restored_snapshot", "replay_record",
            "replay_source_checkpoint", "replay_records", "replay_verification_inputs",
        }),
    ),
    "MigrationReverificationRecord": (
        "verify_migration_reverification_record",
        frozenset({
            "migration_record", "source_object", "transformed_object",
            "lifecycle_record", "lifecycle_verification_inputs",
        }),
    ),
}

# Authority-bearing records retain their legacy integrity-only envelope for
# backward compatibility and admit the additive v2 deployment-authority replay
# contract.  Replay records bind whichever exact contract was actually used.
_AUTHORITY_ENVELOPE_CONTRACTS = {
    "SignatureVerificationRecord": (
        "verify_signature_verification_record_v2",
        frozenset({"signature_content", "signed_content", "authority_snapshot"}),
    ),
    "ApprovalRecord": (
        "verify_approval_record_v2",
        frozenset({"signature_content", "artifact", "authority_snapshot", "principal"}),
    ),
    "ApprovalWithdrawal": (
        "verify_approval_withdrawal_v2",
        frozenset({"signature_content", "approval", "authority_snapshot", "principal"}),
    ),
    "LifecycleAuthorization": (
        "verify_lifecycle_authorization_v2",
        frozenset({
            "approvals", "withdrawals", "policy", "clock", "artifact",
            "authority_snapshot", "approval_signature_inputs",
            "withdrawal_signature_inputs",
        }),
    ),
    "ContinuedValidityView": (
        "verify_continued_validity_view_v2",
        frozenset({
            "artifact", "dimension_sources", "trigger_sources", "dependencies",
            "validity_source",
        }),
    ),
}

_REPLAYABLE_RECORD_TYPES = frozenset(LIFECYCLE_FIRST_RELEASE_ATTRIBUTION) - {
    "LifecycleReplayRecord",
    "BackupRestoreRecoveryRecord",
}

_REPLAY_BOUNDARY = (
    "deterministic replay of carried canonical lifecycle records only; not "
    "authorization, availability, point-in-time recovery, transition execution, "
    "physical signoff, or generic physical safety"
)
_RECOVERY_BOUNDARY = (
    "byte-exact portable logical backup/restore plus independent lifecycle replay "
    "only; not provider availability, PITR, failover, RPO/RTO, transition execution, "
    "physical signoff, or generic physical safety"
)
_MIGRATION_BOUNDARY = (
    "registered semantically-equivalent migration and independent replay of unchanged "
    "lifecycle bytes only; not certificate inheritance, substantive reissuance, "
    "authorization, transition execution, physical signoff, or generic physical safety"
)


class LifecycleResilienceError(ValueError):
    """Portable lifecycle resilience evidence is incomplete or inconsistent."""


def _copy(value: Any, where: str) -> Any:
    try:
        return json.loads(canonical_json(value))
    except (TypeError, ValueError) as error:
        raise LifecycleResilienceError(f"{where} is not canonical CRG JSON: {error}") from error


def _object(value: Any, where: str) -> Dict[str, Any]:
    if not isinstance(value, Mapping):
        raise LifecycleResilienceError(f"{where} must be a JSON object")
    return _copy(dict(value), where)


def _text(value: Any, where: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise LifecycleResilienceError(f"{where} must be a non-empty string")
    return value


def _hash(value: Any, where: str) -> str:
    if not is_hash(value):
        raise LifecycleResilienceError(f"{where} must be an algorithm-tagged SHA-256 hash")
    return str(value)


def _closed_envelope(
    record: Mapping[str, Any], verification_inputs: Mapping[str, Any]
) -> Tuple[Dict[str, Any], Dict[str, Any], str, str]:
    document = _object(record, "lifecycle record")
    envelope = _object(verification_inputs, "lifecycle verification inputs")
    required = {
        "verification_profile", "first_release_attribution", "verifier_operation",
        "record_type", "record_hash", "inputs",
    }
    if set(envelope) != required:
        raise LifecycleResilienceError(
            "lifecycle verification inputs must contain exactly "
            f"{sorted(required)}; found {sorted(envelope)}"
        )
    if envelope.get("verification_profile") != LIFECYCLE_REPLAY_PROFILE:
        raise LifecycleResilienceError("unsupported lifecycle verification profile")
    record_type = _text(document.get("record_type"), "lifecycle record.record_type")
    expected_release = LIFECYCLE_FIRST_RELEASE_ATTRIBUTION.get(record_type)
    if expected_release is None or record_type not in _REPLAYABLE_RECORD_TYPES:
        raise LifecycleResilienceError(
            f"record type {record_type!r} is not registered for nested deterministic replay"
        )
    if envelope.get("record_type") != record_type:
        raise LifecycleResilienceError("verification envelope names a different record type")
    if envelope.get("first_release_attribution") != expected_release:
        raise LifecycleResilienceError(
            f"{record_type} must retain first-release attribution {expected_release!r}"
        )
    operation, expected_inputs = _LIFECYCLE_ENVELOPE_CONTRACTS[record_type]
    authority_contract = _AUTHORITY_ENVELOPE_CONTRACTS.get(record_type)
    if authority_contract is not None and envelope.get("verifier_operation") == authority_contract[0]:
        operation, expected_inputs = authority_contract
    elif envelope.get("verifier_operation") != operation:
        raise LifecycleResilienceError(
            f"{record_type} requires verifier operation {operation!r}"
            + (
                f" or {authority_contract[0]!r}"
                if authority_contract is not None
                else ""
            )
        )
    record_root = content_hash(document)
    if envelope.get("record_hash") != record_root:
        raise LifecycleResilienceError("verification envelope is bound to different record bytes")
    if not isinstance(envelope.get("inputs"), Mapping):
        raise LifecycleResilienceError("verification envelope inputs must be an object")
    if set(envelope["inputs"]) != expected_inputs:
        raise LifecycleResilienceError(
            f"{operation} requires exact inputs {sorted(expected_inputs)}"
        )
    return document, envelope, record_type, record_root


def _step_state(
    sequence: int,
    prior_state_hash: str,
    record_type: str,
    record_hash: str,
    verification_input_hash: str,
    first_release_attribution: str,
) -> str:
    return content_hash(
        {
            "profile": "crg.lifecycle-replay-step@1",
            "sequence": sequence,
            "prior_state_hash": prior_state_hash,
            "record_type": record_type,
            "record_hash": record_hash,
            "verification_input_hash": verification_input_hash,
            "first_release_attribution": first_release_attribution,
        }
    )


@dataclass(frozen=True)
class LifecycleReplayEntry:
    sequence: int
    record_type: str
    record_hash: str
    verification_input_hash: str
    first_release_attribution: str
    prior_state_hash: str
    replayed_state_hash: str

    def __post_init__(self) -> None:
        if isinstance(self.sequence, bool) or not isinstance(self.sequence, int) or self.sequence < 1:
            raise LifecycleResilienceError("replay sequence must be a positive integer")
        _text(self.record_type, "replay entry.record_type")
        for field, value in (
            ("record_hash", self.record_hash),
            ("verification_input_hash", self.verification_input_hash),
            ("prior_state_hash", self.prior_state_hash),
            ("replayed_state_hash", self.replayed_state_hash),
        ):
            _hash(value, f"replay entry.{field}")
        expected = LIFECYCLE_FIRST_RELEASE_ATTRIBUTION.get(self.record_type)
        if expected != self.first_release_attribution:
            raise LifecycleResilienceError(
                f"replay entry for {self.record_type!r} must retain {expected!r} attribution"
            )
        derived = _step_state(
            self.sequence,
            self.prior_state_hash,
            self.record_type,
            self.record_hash,
            self.verification_input_hash,
            self.first_release_attribution,
        )
        if self.replayed_state_hash != derived:
            raise LifecycleResilienceError("replay entry state hash is not deterministically derived")

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "sequence": self.sequence,
            "record_type": self.record_type,
            "record_hash": self.record_hash,
            "verification_input_hash": self.verification_input_hash,
            "first_release_attribution": self.first_release_attribution,
            "prior_state_hash": self.prior_state_hash,
            "replayed_state_hash": self.replayed_state_hash,
        }


@dataclass(frozen=True)
class LifecycleReplayRecord:
    replay_id: str
    source_checkpoint_hash: str
    entries: Tuple[LifecycleReplayEntry, ...]
    final_state_hash: str

    def __post_init__(self) -> None:
        _text(self.replay_id, "replay_id")
        _hash(self.source_checkpoint_hash, "source_checkpoint_hash")
        if not self.entries:
            raise LifecycleResilienceError("deterministic replay requires at least one lifecycle record")
        prior = self.source_checkpoint_hash
        seen_records = set()
        for sequence, entry in enumerate(self.entries, start=1):
            if entry.sequence != sequence or entry.prior_state_hash != prior:
                raise LifecycleResilienceError("replay entries are reordered or break the state chain")
            identity = (entry.record_hash, entry.verification_input_hash)
            if identity in seen_records:
                raise LifecycleResilienceError("replay repeats a lifecycle record/input pair")
            seen_records.add(identity)
            prior = entry.replayed_state_hash
        if self.final_state_hash != prior:
            raise LifecycleResilienceError("final replay state does not match the ordered chain")

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "record_type": "LifecycleReplayRecord",
            "profile": LIFECYCLE_RESILIENCE_PROFILE,
            "schema_version": LIFECYCLE_RESILIENCE_SCHEMA_VERSION,
            "replay_id": self.replay_id,
            "source_checkpoint_hash": self.source_checkpoint_hash,
            "entries": [entry.to_canonical() for entry in self.entries],
            "final_state_hash": self.final_state_hash,
            "replay_complete": True,
            "claim_boundary": _REPLAY_BOUNDARY,
        }


def build_lifecycle_replay_record(
    replay_id: str,
    source_checkpoint: Any,
    records_and_inputs: Sequence[Tuple[Mapping[str, Any], Mapping[str, Any]]],
) -> LifecycleReplayRecord:
    """Build the deterministic hash chain for exact portable lifecycle pairs."""
    checkpoint = _copy(source_checkpoint, "source checkpoint")
    prior = content_hash(checkpoint)
    entries = []
    for sequence, pair in enumerate(tuple(records_and_inputs), start=1):
        if not isinstance(pair, (tuple, list)) or len(pair) != 2:
            raise LifecycleResilienceError("each replay item must be a (record, verification_inputs) pair")
        record, envelope, record_type, record_root = _closed_envelope(pair[0], pair[1])
        del record
        envelope_root = content_hash(envelope)
        release = LIFECYCLE_FIRST_RELEASE_ATTRIBUTION[record_type]
        state = _step_state(
            sequence, prior, record_type, record_root, envelope_root, release
        )
        entries.append(
            LifecycleReplayEntry(
                sequence, record_type, record_root, envelope_root, release, prior, state
            )
        )
        prior = state
    return LifecycleReplayRecord(
        replay_id=_text(replay_id, "replay_id"),
        source_checkpoint_hash=content_hash(checkpoint),
        entries=tuple(entries),
        final_state_hash=prior,
    )


@dataclass(frozen=True)
class LifecyclePortableSnapshot:
    snapshot_id: str
    objects: Tuple[Mapping[str, Any], ...]
    inventory_root: str

    def __post_init__(self) -> None:
        _text(self.snapshot_id, "snapshot_id")
        if not self.objects:
            raise LifecycleResilienceError("a lifecycle snapshot must contain at least one object")
        identifiers = []
        inventory = []
        prior = None
        for raw in self.objects:
            item = _object(raw, "snapshot object")
            if set(item) != {"object_id", "content_hash", "payload"}:
                raise LifecycleResilienceError(
                    "snapshot objects require exactly object_id, content_hash, and payload"
                )
            object_id = _text(item["object_id"], "snapshot object.object_id")
            if prior is not None and object_id <= prior:
                raise LifecycleResilienceError("snapshot object identities must be unique and sorted")
            prior = object_id
            identifiers.append(object_id)
            payload_root = content_hash(item["payload"])
            if item["content_hash"] != payload_root:
                raise LifecycleResilienceError(f"snapshot object {object_id!r} has a forged hash")
            inventory.append({"object_id": object_id, "content_hash": payload_root})
        if self.inventory_root != content_hash(inventory):
            raise LifecycleResilienceError("snapshot inventory root does not match its objects")

    @property
    def content_hashes(self) -> Tuple[str, ...]:
        return tuple(str(item["content_hash"]) for item in self.objects)

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "record_type": "LifecyclePortableSnapshot",
            "profile": LIFECYCLE_RESILIENCE_PROFILE,
            "schema_version": LIFECYCLE_RESILIENCE_SCHEMA_VERSION,
            "snapshot_id": self.snapshot_id,
            "objects": [_copy(item, "snapshot object") for item in self.objects],
            "inventory_root": self.inventory_root,
            "object_count": len(self.objects),
        }


def create_lifecycle_snapshot(
    snapshot_id: str, objects: Mapping[str, Any]
) -> LifecyclePortableSnapshot:
    """Create a canonical, internally hash-bound offline lifecycle snapshot."""
    if not isinstance(objects, Mapping) or not objects:
        raise LifecycleResilienceError("snapshot objects must be a non-empty object map")
    entries = []
    inventory = []
    for object_id, raw in sorted(objects.items(), key=lambda item: str(item[0])):
        identifier = _text(object_id, "snapshot object identity")
        payload = _copy(raw, f"snapshot object {identifier}")
        root = content_hash(payload)
        entries.append({"object_id": identifier, "content_hash": root, "payload": payload})
        inventory.append({"object_id": identifier, "content_hash": root})
    return LifecyclePortableSnapshot(
        _text(snapshot_id, "snapshot_id"), tuple(entries), content_hash(inventory)
    )


@dataclass(frozen=True)
class BackupRestoreRecoveryRecord:
    recovery_id: str
    source_snapshot_hash: str
    backup_snapshot_hash: str
    restored_snapshot_hash: str
    inventory_root: str
    protected_lifecycle_hashes: Tuple[str, ...]
    replay_record_hash: str
    authority: str

    def __post_init__(self) -> None:
        _text(self.recovery_id, "recovery_id")
        _text(self.authority, "recovery authority")
        for field, value in (
            ("source_snapshot_hash", self.source_snapshot_hash),
            ("backup_snapshot_hash", self.backup_snapshot_hash),
            ("restored_snapshot_hash", self.restored_snapshot_hash),
            ("inventory_root", self.inventory_root),
            ("replay_record_hash", self.replay_record_hash),
        ):
            _hash(value, field)
        if not self.protected_lifecycle_hashes:
            raise LifecycleResilienceError("recovery must protect lifecycle records and replay inputs")
        if self.protected_lifecycle_hashes != tuple(sorted(set(self.protected_lifecycle_hashes))):
            raise LifecycleResilienceError("protected lifecycle hashes must be unique and sorted")
        for value in self.protected_lifecycle_hashes:
            _hash(value, "protected lifecycle hash")

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "record_type": "BackupRestoreRecoveryRecord",
            "profile": LIFECYCLE_RESILIENCE_PROFILE,
            "schema_version": LIFECYCLE_RESILIENCE_SCHEMA_VERSION,
            "recovery_id": self.recovery_id,
            "backup_profile": "PORTABLE_CANONICAL_SNAPSHOT_V1",
            "source_snapshot_hash": self.source_snapshot_hash,
            "backup_snapshot_hash": self.backup_snapshot_hash,
            "restored_snapshot_hash": self.restored_snapshot_hash,
            "inventory_root": self.inventory_root,
            "protected_lifecycle_hashes": list(self.protected_lifecycle_hashes),
            "replay_record_hash": self.replay_record_hash,
            "integrity_status": "BYTE_EXACT_INVENTORY_MATCH",
            "semantic_replay_required": True,
            "authority": self.authority,
            "claim_boundary": _RECOVERY_BOUNDARY,
        }


def _snapshot(value: Any, where: str) -> Dict[str, Any]:
    if isinstance(value, LifecyclePortableSnapshot):
        value = value.to_canonical()
    document = _object(value, where)
    if document.get("record_type") != "LifecyclePortableSnapshot":
        raise LifecycleResilienceError(f"{where} has an unsupported record type")
    # Round-trip through the dataclass so producer-side evidence cannot carry
    # an internally inconsistent inventory.
    instance = LifecyclePortableSnapshot(
        str(document.get("snapshot_id") or ""),
        tuple(document.get("objects") or ()),
        str(document.get("inventory_root") or ""),
    )
    if document != instance.to_canonical():
        raise LifecycleResilienceError(f"{where} is not the canonical snapshot contract")
    return document


def record_backup_restore_recovery(
    recovery_id: str,
    source_snapshot: Any,
    backup_snapshot: Any,
    restored_snapshot: Any,
    replay_record: Any,
    *,
    authority: str,
) -> BackupRestoreRecoveryRecord:
    """Bind three exact inventories to a required deterministic replay record."""
    source = _snapshot(source_snapshot, "source snapshot")
    backup = _snapshot(backup_snapshot, "backup snapshot")
    restored = _snapshot(restored_snapshot, "restored snapshot")
    replay = _object(
        replay_record.to_canonical() if isinstance(replay_record, LifecycleReplayRecord) else replay_record,
        "lifecycle replay record",
    )
    if replay.get("record_type") != "LifecycleReplayRecord":
        raise LifecycleResilienceError("recovery requires a LifecycleReplayRecord")
    roots = {source.get("inventory_root"), backup.get("inventory_root"), restored.get("inventory_root")}
    if len(roots) != 1:
        raise LifecycleResilienceError("backup or restored inventory differs from the source")
    source_hashes = sorted(str(item["content_hash"]) for item in source["objects"])
    if source_hashes != sorted(str(item["content_hash"]) for item in backup["objects"]):
        raise LifecycleResilienceError("backup object bytes differ from the source inventory")
    if source_hashes != sorted(str(item["content_hash"]) for item in restored["objects"]):
        raise LifecycleResilienceError("restored object bytes differ from the source inventory")
    protected = sorted(
        {
            str(entry["record_hash"])
            for entry in replay.get("entries") or ()
        }
        | {
            str(entry["verification_input_hash"])
            for entry in replay.get("entries") or ()
        }
        | {
            content_hash(replay),
            _hash(replay.get("source_checkpoint_hash"), "replay source checkpoint hash"),
        }
    )
    missing = sorted(set(protected) - set(source_hashes))
    if missing:
        raise LifecycleResilienceError(
            f"source backup inventory omits replay records or inputs {missing}"
        )
    return BackupRestoreRecoveryRecord(
        recovery_id=_text(recovery_id, "recovery_id"),
        source_snapshot_hash=content_hash(source),
        backup_snapshot_hash=content_hash(backup),
        restored_snapshot_hash=content_hash(restored),
        inventory_root=str(source["inventory_root"]),
        protected_lifecycle_hashes=tuple(protected),
        replay_record_hash=content_hash(replay),
        authority=_text(authority, "recovery authority"),
    )


@dataclass(frozen=True)
class MigrationReverificationRecord:
    reverification_id: str
    migration_record_hash: str
    source_object_hash: str
    transformed_object_hash: str
    transform_id: str
    transform_hash: str
    migration_class: str
    lifecycle_record_type: str
    lifecycle_record_hash: str
    lifecycle_verification_input_hash: str
    authority: str

    def __post_init__(self) -> None:
        _text(self.reverification_id, "reverification_id")
        _text(self.transform_id, "transform_id")
        _text(self.lifecycle_record_type, "lifecycle_record_type")
        _text(self.authority, "reverification authority")
        for field, value in (
            ("migration_record_hash", self.migration_record_hash),
            ("source_object_hash", self.source_object_hash),
            ("transformed_object_hash", self.transformed_object_hash),
            ("transform_hash", self.transform_hash),
            ("lifecycle_record_hash", self.lifecycle_record_hash),
            ("lifecycle_verification_input_hash", self.lifecycle_verification_input_hash),
        ):
            _hash(value, field)
        if self.migration_class != "SEMANTICALLY_EQUIVALENT":
            raise LifecycleResilienceError(
                "re-verification without reissuance requires a semantically-equivalent migration"
            )
        if self.source_object_hash != self.transformed_object_hash:
            raise LifecycleResilienceError(
                "re-verification without reissuance requires byte-identical transformed content"
            )

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "record_type": "MigrationReverificationRecord",
            "profile": LIFECYCLE_RESILIENCE_PROFILE,
            "schema_version": LIFECYCLE_RESILIENCE_SCHEMA_VERSION,
            "reverification_id": self.reverification_id,
            "migration_record_hash": self.migration_record_hash,
            "source_object_hash": self.source_object_hash,
            "transformed_object_hash": self.transformed_object_hash,
            "transform_id": self.transform_id,
            "transform_hash": self.transform_hash,
            "migration_class": self.migration_class,
            "lifecycle_record_type": self.lifecycle_record_type,
            "lifecycle_record_hash": self.lifecycle_record_hash,
            "lifecycle_verification_input_hash": self.lifecycle_verification_input_hash,
            "differential_validation": "CANONICAL_CONTENT_HASH_EQUALITY",
            "disposition": "REVERIFIED_WITHOUT_REISSUANCE",
            "substantive_artifact_reissued": False,
            "authority": self.authority,
            "claim_boundary": _MIGRATION_BOUNDARY,
        }


def record_migration_reverification(
    reverification_id: str,
    migration_record: Mapping[str, Any],
    source_object: Any,
    transformed_object: Any,
    lifecycle_record: Mapping[str, Any],
    lifecycle_verification_inputs: Mapping[str, Any],
    *,
    authority: str,
) -> MigrationReverificationRecord:
    """Produce the only registered re-verification path supported in v1.4."""
    migration = _object(migration_record, "migration record")
    if migration.get("record_type") != "MigrationRecord":
        raise LifecycleResilienceError("migration re-verification requires a MigrationRecord")
    try:
        verify_classification_evidence(migration)
    except MigrationProofError as error:
        raise LifecycleResilienceError(f"migration classification evidence failed: {error}") from error
    descriptor = migration.get("transform_descriptor") or {}
    if (
        migration.get("transform_id") != descriptor.get("transform_id")
        or migration.get("migration_class") != descriptor.get("migration_class")
        or migration.get("source_schema_version") != descriptor.get("source_schema_version")
        or migration.get("target_schema_version") != descriptor.get("target_schema_version")
    ):
        raise LifecycleResilienceError(
            "migration record disagrees with its registered transform descriptor"
        )
    if (
        migration.get("migration_registry_version") != DEFAULT_MIGRATION_REGISTRY.version
        or dict(descriptor) not in DEFAULT_MIGRATION_REGISTRY.to_canonical()["transforms"]
    ):
        raise LifecycleResilienceError(
            "migration transform is not in the producer's pinned registry"
        )
    source = _copy(source_object, "migration source object")
    transformed = _copy(transformed_object, "migration transformed object")
    source_root = content_hash(source)
    transformed_root = content_hash(transformed)
    if migration.get("source_object_hash") != source_root:
        raise LifecycleResilienceError("migration source hash does not match the supplied source object")
    if migration.get("transform_input_hash") != source_root:
        raise LifecycleResilienceError("registered transform input is not the supplied source object")
    if migration.get("transform_output_hash") != transformed_root:
        raise LifecycleResilienceError("registered transform output is not the supplied transformed object")
    if migration.get("migration_class") != "SEMANTICALLY_EQUIVALENT":
        raise LifecycleResilienceError("non-equivalent migration requires revalidation or reissuance")
    if source_root != transformed_root:
        raise LifecycleResilienceError("equivalent identity migration changed canonical content")
    document, envelope, record_type, record_root = _closed_envelope(
        lifecycle_record, lifecycle_verification_inputs
    )
    if record_type == "MigrationReverificationRecord":
        raise LifecycleResilienceError(
            "migration re-verification must terminate at a substantive lifecycle record"
        )
    del document
    return MigrationReverificationRecord(
        reverification_id=_text(reverification_id, "reverification_id"),
        migration_record_hash=content_hash(migration),
        source_object_hash=source_root,
        transformed_object_hash=transformed_root,
        transform_id=_text(migration.get("transform_id"), "migration transform_id"),
        transform_hash=_hash(migration.get("transform_hash"), "migration transform_hash"),
        migration_class="SEMANTICALLY_EQUIVALENT",
        lifecycle_record_type=record_type,
        lifecycle_record_hash=record_root,
        lifecycle_verification_input_hash=content_hash(envelope),
        authority=_text(authority, "reverification authority"),
    )


def resilience_verification_inputs(
    record: Mapping[str, Any], **inputs: Any
) -> Dict[str, Any]:
    """Create an exact independent-replay envelope for a resilience record."""
    document = _object(record, "resilience record")
    record_type = _text(document.get("record_type"), "resilience record.record_type")
    if record_type not in {
        "LifecycleReplayRecord",
        "BackupRestoreRecoveryRecord",
        "MigrationReverificationRecord",
    }:
        raise LifecycleResilienceError(f"unsupported resilience record type {record_type!r}")
    operation, expected_inputs = _LIFECYCLE_ENVELOPE_CONTRACTS[record_type]
    if set(inputs) != expected_inputs:
        raise LifecycleResilienceError(
            f"{operation} requires exact inputs {sorted(expected_inputs)}"
        )
    return {
        "verification_profile": LIFECYCLE_REPLAY_PROFILE,
        "first_release_attribution": _V14,
        "verifier_operation": operation,
        "record_type": record_type,
        "record_hash": content_hash(document),
        "inputs": _copy(inputs, "resilience verification inputs"),
    }
