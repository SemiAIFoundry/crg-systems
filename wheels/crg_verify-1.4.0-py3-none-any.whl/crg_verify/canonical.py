"""Independent canonical JSON and content hashing for the CRG verifier.

Normative basis: master specification 14.3 (canonicalization) and 14.4
(hashing).

This module is a deliberate *second implementation* of RFC 8785 JSON
canonicalization.  ``crg-verify`` does not call the kernel's canonicalizer,
because a verifier that reuses the producer's serializer cannot detect a
canonicalization disagreement -- exactly the failure mode 25.5 asks the
independent implementation to expose.

Only the standard library is used.  Binary floating point is refused
outright (14.2): a float has no canonical decimal image, so admitting one
would make the content hash of a certificate depend on the writer's
formatting choices.
"""
from __future__ import annotations

import hashlib
import json
import re
from typing import Any

__all__ = [
    "CanonicalError",
    "HASH_PREFIX",
    "canonical_json",
    "canonical_bytes",
    "content_hash",
    "hash_without",
    "is_hash",
]

HASH_PREFIX = "sha256:"
_HASH_RE = re.compile(r"^sha256:[0-9a-f]{64}$")


class CanonicalError(TypeError):
    """A value has no admissible canonical encoding."""


def _member_key(key: str) -> tuple:
    # RFC 8785 orders object members by their UTF-16 code units.
    return tuple(key.encode("utf-16-be"))


def _text(value: str) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def _encode(value: Any) -> str:
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, str):
        return _text(value)
    if isinstance(value, float):
        raise CanonicalError(
            "binary floating point is inadmissible in canonical CRG content (spec 14.2); "
            "supply an integer, a decimal string, or a rational string"
        )
    if isinstance(value, int):
        return str(value)
    if isinstance(value, dict):
        members = []
        for key in sorted(value.keys(), key=_member_key):
            if not isinstance(key, str):
                raise CanonicalError(f"object keys MUST be strings, got {type(key)!r}")
            members.append(f"{_text(key)}:{_encode(value[key])}")
        return "{" + ",".join(members) + "}"
    if isinstance(value, (list, tuple)):
        return "[" + ",".join(_encode(item) for item in value) + "]"
    to_canonical = getattr(value, "to_canonical", None)
    if callable(to_canonical):
        # Producer-side convenience for emit_vir only.  Nothing on the
        # verification path ever reaches this branch: verify_vir and
        # verify_certificate operate on decoded JSON.
        return _encode(to_canonical())
    raise CanonicalError(f"no canonical encoding for {type(value)!r}")


def canonical_json(value: Any) -> str:
    """Canonical (RFC 8785) JSON text for ``value``."""
    return _encode(value)


def canonical_bytes(value: Any) -> bytes:
    return canonical_json(value).encode("utf-8")


def content_hash(value: Any) -> str:
    """``sha256:<hex>`` over the canonical encoding of ``value`` (spec 14.4)."""
    return HASH_PREFIX + hashlib.sha256(canonical_bytes(value)).hexdigest()


def hash_without(mapping: dict, *excluded: str) -> str:
    """Content hash of ``mapping`` with ``excluded`` keys removed.

    A self-describing record cannot contain its own hash in its own hash
    preimage; 14.3 requires the signature-excluded fields to be declared,
    and this is the verifier's side of that rule.
    """
    if not isinstance(mapping, dict):
        raise CanonicalError("hash_without expects a mapping")
    drop = set(excluded)
    return content_hash({k: v for k, v in mapping.items() if k not in drop})


def is_hash(value: Any) -> bool:
    return isinstance(value, str) and bool(_HASH_RE.match(value))


def decode(text: str) -> Any:
    """Decode JSON text, refusing binary floats at the boundary."""
    return json.loads(text, parse_float=_refuse_float)


def _refuse_float(token: str) -> Any:
    raise CanonicalError(
        f"decoded a non-integer JSON number {token!r}; CRG content MUST carry exact "
        "numerics as strings or rational objects (spec 14.2)"
    )
