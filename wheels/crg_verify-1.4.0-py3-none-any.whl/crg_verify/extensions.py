"""Verifier-owned registry for specialized proof checkers (§24.6).

Nothing is discovered or loaded from a VIR document.  A deployment creates a
registry, registers reviewed checker callables against complete immutable
declarations, and explicitly passes that registry to ``verify_vir``.  Doing so
expands the deployment's trusted computing base; it never changes the minimal
baseline verifier profile.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Dict, Mapping, Sequence, Tuple

from .canonical import content_hash

__all__ = [
    "ExtensionCheckerError", "ProofCheckerDeclaration", "ProofCheckerRegistry",
]


class ExtensionCheckerError(ValueError):
    """An extension declaration or checker result is inadmissible."""


TRUST_PROFILES = frozenset({
    "REVIEWED_IN_PROCESS_EXTENSION",
    "SANDBOXED_EXTENSION",
    "EXTERNAL_VERIFICATION_SERVICE",
})


@dataclass(frozen=True)
class ProofCheckerDeclaration:
    checker_id: str
    proof_format: str
    semantic_scope: str
    version: str
    implementation_identity: str
    sandbox_requirements: Mapping[str, Any]
    conformance_suite: Tuple[str, ...]
    trust_profile: str

    def __post_init__(self) -> None:
        for name in (
            "checker_id", "proof_format", "semantic_scope", "version",
            "implementation_identity", "trust_profile",
        ):
            if not str(getattr(self, name)).strip():
                raise ExtensionCheckerError(f"proof checker {name} must be non-empty (§24.6)")
        if self.trust_profile not in TRUST_PROFILES:
            raise ExtensionCheckerError(
                f"proof checker trust profile {self.trust_profile!r} is unsupported; "
                f"expected one of {sorted(TRUST_PROFILES)}"
            )
        if not isinstance(self.sandbox_requirements, Mapping) or not self.sandbox_requirements:
            raise ExtensionCheckerError("proof checker sandbox requirements must be declared")
        if not str(self.sandbox_requirements.get("execution_mode", "")).strip():
            raise ExtensionCheckerError(
                "proof checker sandbox requirements need an execution_mode"
            )
        if not self.conformance_suite or any(not str(item).strip() for item in self.conformance_suite):
            raise ExtensionCheckerError("proof checker conformance suite must be non-empty")

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "checker_id": self.checker_id,
            "proof_format": self.proof_format,
            "semantic_scope": self.semantic_scope,
            "version": self.version,
            "implementation_identity": self.implementation_identity,
            "sandbox_requirements": dict(self.sandbox_requirements),
            "conformance_suite": list(self.conformance_suite),
            "trust_profile": self.trust_profile,
        }

    def declaration_hash(self) -> str:
        return content_hash(self.to_canonical())

    @classmethod
    def from_canonical(cls, value: Mapping[str, Any]) -> "ProofCheckerDeclaration":
        if not isinstance(value, Mapping):
            raise ExtensionCheckerError("proof checker declaration must be an object")
        required = {
            "checker_id", "proof_format", "semantic_scope", "version",
            "implementation_identity", "sandbox_requirements", "conformance_suite",
            "trust_profile",
        }
        missing = sorted(required - set(value))
        unknown = sorted(set(value) - required)
        if missing or unknown:
            raise ExtensionCheckerError(
                f"proof checker declaration fields mismatch: missing={missing}, unknown={unknown}"
            )
        suite = value["conformance_suite"]
        if isinstance(suite, str) or not isinstance(suite, Sequence):
            raise ExtensionCheckerError("proof checker conformance_suite must be a list")
        return cls(
            checker_id=str(value["checker_id"]),
            proof_format=str(value["proof_format"]),
            semantic_scope=str(value["semantic_scope"]),
            version=str(value["version"]),
            implementation_identity=str(value["implementation_identity"]),
            sandbox_requirements=dict(value["sandbox_requirements"]),
            conformance_suite=tuple(str(item) for item in suite),
            trust_profile=str(value["trust_profile"]),
        )


@dataclass(frozen=True)
class _Registration:
    declaration: ProofCheckerDeclaration
    checker: Callable[[Any, Mapping[str, Any]], Any]
    execution_attestation: Mapping[str, Any]


class ProofCheckerRegistry:
    """An explicit allow-list of reviewed extension proof checkers."""

    def __init__(self) -> None:
        self._registrations: Dict[str, _Registration] = {}

    @property
    def checker_ids(self) -> Tuple[str, ...]:
        return tuple(sorted(self._registrations))

    def register(
        self,
        declaration: ProofCheckerDeclaration,
        checker: Callable[[Any, Mapping[str, Any]], Any],
        *,
        execution_attestation: Mapping[str, Any],
    ) -> None:
        if declaration.checker_id in self._registrations:
            raise ExtensionCheckerError(
                f"proof checker {declaration.checker_id!r} is already registered"
            )
        if not callable(checker):
            raise ExtensionCheckerError("proof checker implementation must be callable")
        if not isinstance(execution_attestation, Mapping) or not execution_attestation:
            raise ExtensionCheckerError(
                "registration requires verifier-owned execution attestation"
            )
        if str(execution_attestation.get("execution_mode", "")) != str(
            declaration.sandbox_requirements.get("execution_mode", "")
        ):
            raise ExtensionCheckerError(
                "execution attestation does not satisfy the declared execution_mode"
            )
        self._registrations[declaration.checker_id] = _Registration(
            declaration, checker, dict(execution_attestation)
        )

    def verify(
        self,
        operation: str,
        request: Mapping[str, Any],
        *,
        context: Mapping[str, Any],
    ) -> Tuple[bool, str, Dict[str, Any]]:
        if not isinstance(request, Mapping):
            return False, "extension checker request is not an object", {}
        checker_id = str(request.get("checker_id", ""))
        registration = self._registrations.get(checker_id)
        if registration is None:
            return False, f"proof checker {checker_id!r} is not verifier-registered", {}
        if str(request.get("operation", "")) != str(operation):
            return False, "extension checker request is bound to a different operation", {}
        try:
            carried = ProofCheckerDeclaration.from_canonical(request.get("declaration") or {})
        except ExtensionCheckerError as error:
            return False, str(error), {}
        expected = registration.declaration
        if carried.to_canonical() != expected.to_canonical():
            return False, "carried checker declaration differs from verifier registration", {}
        stated_hash = str(request.get("declaration_hash", ""))
        if stated_hash != expected.declaration_hash():
            return False, "carried checker declaration hash is absent or incorrect", {}
        if "proof" not in request:
            return False, "extension checker request carries no proof object", {}
        try:
            raw = registration.checker(request["proof"], dict(context))
        except Exception as error:  # checker failures are evidence, never verifier crashes
            return False, f"registered checker raised {type(error).__name__}: {error}", {}
        if isinstance(raw, bool):
            passed, detail, report = raw, "checker returned true" if raw else "checker returned false", {}
        elif isinstance(raw, Mapping):
            passed = raw.get("ok") is True
            detail = str(raw.get("detail") or ("checker passed" if passed else "checker refused"))
            report = dict(raw.get("report") or {})
        else:
            return False, "registered checker returned neither boolean nor result object", {}
        report.update({
            "operation": str(operation),
            "checker_id": checker_id,
            "declaration_hash": expected.declaration_hash(),
            "trust_profile": expected.trust_profile,
            "execution_attestation": dict(registration.execution_attestation),
        })
        return passed, detail, report
