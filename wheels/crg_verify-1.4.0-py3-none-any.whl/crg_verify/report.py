"""The ``VerificationReport`` renderer (spec 25.3).

Every field 25.3 lists is emitted, in a fixed order, including the ones that
are empty -- an absent "unsupported checks" line reads as "none were
skipped", and 50.3 forbids a presentation that could mislead the reader
about verification status.

The certificate renderer of 50.2 deliberately lives in ``crg-cli``, not
here: rendering a certificate for a human is a presentation concern, and
50.2 binds conforming *renderers*, not the trusted verification core.
"""
from __future__ import annotations

from typing import Any, Dict, List

from .certificate import VerificationResult

__all__ = ["render_report"]


def render_report(result: VerificationResult) -> str:
    """Render a ``VerificationReport`` in the order of specification 25.3."""
    report = result.report
    lines: List[str] = ["CRG VERIFICATION REPORT", "=" * 23]
    add = lines.append
    add(f"Bundle identity      : {report.get('bundle_identity')}")
    add(f"Verifier             : {report.get('verifier_identity')} "
        f"{report.get('verifier_version')} (spec {report.get('spec_version', '0.2.0')})")
    add(f"Level attempted      : {report.get('level_attempted')}")
    add(f"Level achieved       : {report.get('level_achieved')}")
    add("")

    passed = [(n, d) for n, p, d in result.checks if p]
    failed = [(n, d) for n, p, d in result.checks if not p]
    add(f"Checks passed        : {len(passed)}")
    for name, detail in passed:
        add(f"  [ok]   {name}: {detail}")
    add(f"Checks failed        : {len(failed)}")
    for name, detail in failed:
        add(f"  [FAIL] {name}: {detail}")
    unsupported = report.get("unsupported_checks") or []
    add(f"Unsupported checks   : {len(unsupported)}")
    for item in unsupported:
        add(f"  [--]   {item}")
    add(f"Missing objects      : {report.get('missing_objects') or 'none'}")
    add(f"Redacted dependencies: {report.get('redacted_dependencies') or 'none'}")
    add("")

    time_judgment: Dict[str, Any] = report.get("time_judgment") or {}
    add("Time judgment")
    for label, key in (
        ("issuer asserted issue ", "issuer_asserted_issue_time"),
        ("issuer asserted expiry", "issuer_asserted_expiry"),
        ("verifier evaluated at ", "verifier_evaluation_time"),
        ("verifier clock source ", "verifier_clock_source"),
        ("time status           ", "time_status"),
    ):
        add(f"  {label}: {time_judgment.get(key)}")
    add("")
    add(f"Signature judgment   : {report.get('signature_judgment', 'NOT_SIGNED')}")

    claim: Dict[str, Any] = report.get("claim_judgment") or {}
    add("Claim judgment")
    for label, key in (
        ("outcome               ", "outcome"),
        ("stated claim scope    ", "stated_claim_scope"),
        ("re-derived claim scope", "rederived_claim_scope"),
        ("selected              ", "selected"),
    ):
        add(f"  {label}: {claim.get(key)}")
    add("")
    for heading, items, mark in (("Warnings", result.warnings, "!"),
                                 ("Violations", result.violations, "X")):
        if items:
            add(heading)
            lines.extend(f"  {mark} {item}" for item in items)
            add("")
    add(f"FINAL STATUS         : {result.status}")
    return "\n".join(lines)
