"""Independent verifier for v1.2 comparative certified-change evidence.

Only the Python standard library and sibling verifier implementations are
used.  The embedded ``CertifiedDeltaRecord`` is replayed from its exact
before/after cases, dependency edges, replacements, and optional phase
evidence; no producer conclusion is trusted.
"""
from __future__ import annotations

import re
from typing import Any, Mapping

from .canonical import CanonicalError, content_hash, hash_without, is_hash
from .certificate import Status, VerificationResult
from .phase_delta import verify_certified_delta_record
from .lifecycle import verify_selective_revalidation_record

__all__ = ["verify_comparative_change_evidence"]


SCHEMA_VERSION = "1.2.0"
PROFILE = "crg-comparative-change/certified-delta@1"
FIRST_RELEASE = "v1.2/CERTIFIED_PHASE_AND_TYPED_CHANGE"
AUTHORITY = "NON_AUTHORIZING"
CLAIM_BOUNDARY = (
    "Scoped certified-change facts only. Artifact identity counts do not measure "
    "time, effort, cost, avoided work, business savings, ROI, superiority, or an "
    "unexecuted counterfactual, and this record cannot authorize case state."
)
QUALIFICATION_SCHEMA_VERSION = "1.3.0"
QUALIFICATION_PROFILE = (
    "crg-comparative-change/qualification-selective-revalidation@1"
)
QUALIFICATION_FIRST_RELEASE = "v1.3/QUALIFICATION_AND_SELECTIVE_REVALIDATION"
QUALIFICATION_CLAIM_BOUNDARY = (
    "Selective-revalidation facts are independently reconstructed from the stored "
    "typed dependency closure. Local operational observations remain non-evidentiary, "
    "user-declared counterfactuals remain unsupported, and no avoided work, avoided "
    "experiment, time, effort, cost, savings, ROI, superiority, or authorization is inferred."
)

_REQUIRED_INPUTS = frozenset(
    {"prior_case", "current_case", "dependency_edges", "replacements"}
)
_OPTIONAL_INPUTS = frozenset(
    {
        "prior_phase",
        "current_phase",
        "prior_phase_source_r",
        "current_phase_source_r",
    }
)
_TOP_LEVEL_FIELDS = frozenset(
    {
        "record_type",
        "schema_version",
        "profile",
        "first_release_attribution",
        "comparison_id",
        "authority",
        "authorizing",
        "semantic_effect",
        "evidence_class",
        "claim_boundary",
        "scope",
        "certified_delta_binding",
        "work_denominator",
        "system_derived_facts",
        "conclusion",
        "limitations",
        "record_hash",
    }
)
_QUALIFICATION_TOP_LEVEL_FIELD = "qualification_extension"
_BINDING_FIELDS = frozenset(
    {
        "certified_delta",
        "verification_inputs",
        "independent_verification",
        "certified_delta_hash",
        "verification_inputs_hash",
        "independent_verification_hash",
        "binding_hash",
    }
)
_SCOPE_FIELDS = frozenset(
    {
        "case_id",
        "event_id",
        "prior_case_root",
        "current_case_root",
        "decision_scope",
        "evidence_scope",
        "change_scope",
        "scope_hash",
    }
)
_FORBIDDEN_FACT_KEYS = frozenset(
    {
        "roi",
        "return_on_investment",
        "savings",
        "superiority",
        "generalization",
        "avoided_work",
        "avoided_recomputation",
        "avoided_effort",
        "cost_reduction",
        "time_reduction",
        "winner_method",
        "method_ranking",
    }
)

_QUALIFICATION_FIELDS = frozenset(
    {
        "extension_type",
        "schema_version",
        "profile",
        "first_release_attribution",
        "authority",
        "authorizing",
        "semantic_effect",
        "claim_boundary",
        "selective_revalidation_binding",
        "system_derived_revalidation_facts",
        "local_observation_status",
        "local_operational_observations",
        "counterfactual_status",
        "declared_counterfactuals",
        "conclusion",
        "extension_hash",
    }
)
_REVALIDATION_BINDING_FIELDS = frozenset(
    {
        "selective_revalidation_record",
        "verification_inputs",
        "independent_verification",
        "selective_revalidation_hash",
        "verification_inputs_hash",
        "independent_verification_hash",
        "binding_hash",
    }
)
_LIFECYCLE_INPUT_FIELDS = frozenset(
    {
        "verification_profile",
        "first_release_attribution",
        "verifier_operation",
        "record_type",
        "record_hash",
        "inputs",
    }
)
_REVALIDATION_REPLAY_FIELDS = frozenset({"dependency_edges", "artifact_universe"})
_REVALIDATION_ACTIONS = frozenset(
    {
        "NO_OPERATION",
        "REVALIDATE_ONLY",
        "RECOMPUTE_VALUE",
        "REPRICE",
        "RE_EMBED",
        "RE_EVALUATE",
        "REOPEN",
        "BLOCK",
    }
)
_QUALIFICATION_FACT_FIELDS = frozenset(
    {
        "facts_profile",
        "classification",
        "changed_source",
        "changed_properties",
        "affected",
        "preserved",
        "replacement_required",
        "state",
        "affected_count",
        "preserved_count",
        "replacement_required_count",
        "interpretation",
    }
)
_OPERATIONAL_REFERENCE_FIELDS = frozenset(
    {
        "reference_profile",
        "reference_version",
        "classification",
        "claim_status",
        "session_id",
        "session_content_hash",
        "event_content_hash",
        "event",
        "authorizing",
        "evidence_eligible",
        "semantic_effect",
        "reference_hash",
    }
)
_MEASUREMENT_PROFILE = "crg-operational-measurement/local-private@1"
_MEASUREMENT_EVENT_SCHEMA = (
    "https://crg.systems/schemas/operational-measurement/1.0.0/"
    "operational-measurement-event.schema.json"
)
_MEASUREMENT_EVENT_FIELDS = frozenset(
    {
        "record_type",
        "schema_id",
        "schema_version",
        "profile_id",
        "content_hash",
        "session_id",
        "sequence",
        "event_type",
        "observed_at",
        "monotonic_ns",
        "previous_event_hash",
        "authorizing",
        "evidence_eligible",
        "metric",
    }
)
_MEASUREMENT_METRIC_FIELDS = frozenset(
    {
        "measurement_class",
        "metric_code",
        "exact_value",
        "unit_code",
        "authorizing",
        "evidence_eligible",
        "claim_boundary",
    }
)
_COUNTERFACTUAL_METRIC_FIELDS = _MEASUREMENT_METRIC_FIELDS | {
    "basis_code",
    "counterfactual_status",
    "roi_inferred",
    "savings_inferred",
    "superiority_inferred",
}
_CODE = re.compile(r"^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$")
_PSEUDONYM = re.compile(r"^psn-[a-z0-9]+(?:-[a-z0-9]+)*$")
_MAX_OPERATIONAL_REFERENCES = 32


def _identity(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value.strip() or value != value.strip():
        raise ValueError(f"{field} must be a normalized non-empty string")
    return value


def _object(value: Any, field: str) -> dict:
    if not isinstance(value, Mapping):
        raise ValueError(f"{field} must be an object")
    return dict(value)


def _ids(value: Any, field: str) -> list[str]:
    if not isinstance(value, list):
        raise ValueError(f"{field} must be a list")
    result = [_identity(item, field) for item in value]
    if len(result) != len(set(result)) or result != sorted(result):
        raise ValueError(f"{field} must contain unique canonically ordered identities")
    return result


def _exact_count(value: int) -> dict:
    return {"exact": str(value)}


def _sealed(value: Mapping[str, Any], key: str) -> tuple[bool, str]:
    stated = value.get(key)
    if not is_hash(stated):
        return False, f"{key} is not a portable SHA-256 hash"
    try:
        actual = hash_without(dict(value), key)
    except (CanonicalError, TypeError, ValueError) as error:
        return False, f"{key} cannot be reconstructed: {error}"
    return stated == actual, f"stated {stated}; reconstructed {actual}"


def _forbidden_paths(value: Any, path: str) -> list[str]:
    failures: list[str] = []
    if isinstance(value, dict):
        for key, item in value.items():
            normalized = str(key).strip().lower().replace("-", "_")
            if normalized in _FORBIDDEN_FACT_KEYS:
                failures.append(f"{path}.{key}")
            failures.extend(_forbidden_paths(item, f"{path}.{key}"))
    elif isinstance(value, list):
        for index, item in enumerate(value):
            failures.extend(_forbidden_paths(item, f"{path}[{index}]"))
    return failures


def _expected_scope(delta: Mapping[str, Any], inputs: Mapping[str, Any], scope: Any) -> dict:
    stated = _object(scope, "scope")
    if set(stated) != _SCOPE_FIELDS:
        raise ValueError("scope has a missing or unsupported field set")
    ok, detail = _sealed(stated, "scope_hash")
    if not ok:
        raise ValueError(detail)
    prior = _object(inputs.get("prior_case"), "verification_inputs.prior_case")
    current = _object(inputs.get("current_case"), "verification_inputs.current_case")
    decision = stated.get("decision_scope")
    if not isinstance(decision, dict) or not isinstance(
        stated.get("evidence_scope"), dict
    ):
        raise ValueError("decision_scope and evidence_scope must be embedded objects")
    prior_case_id = prior.get("case_id")
    current_case_id = current.get("case_id")
    if prior_case_id is None and current_case_id is None:
        case_id = _identity(decision.get("case_id"), "decision_scope.case_id")
    elif prior_case_id is None or current_case_id is None:
        raise ValueError(
            "prior_case and current_case must either both carry case_id or both omit it"
        )
    else:
        case_id = _identity(prior_case_id, "prior_case.case_id")
        if _identity(current_case_id, "current_case.case_id") != case_id:
            raise ValueError("prior and current case identities differ")
    declared_case_id = decision.get("case_id")
    if declared_case_id is not None and (
        _identity(declared_case_id, "decision_scope.case_id") != case_id
    ):
        raise ValueError(
            "decision_scope.case_id differs from the replayed case identity"
        )
    event = _object(delta.get("change_event"), "certified delta change_event")
    changed = _ids(event.get("changed_properties"), "change_event.changed_properties")
    expected = {
        "case_id": case_id,
        "event_id": _identity(event.get("event_id"), "change_event.event_id"),
        "prior_case_root": _identity(delta.get("prior_root"), "delta.prior_root"),
        "current_case_root": _identity(delta.get("current_root"), "delta.current_root"),
        "decision_scope": decision,
        "evidence_scope": stated["evidence_scope"],
        "change_scope": {
            "changed_object": _identity(
                event.get("changed_object"), "change_event.changed_object"
            ),
            "changed_properties": changed,
            "declared_reason": _identity(
                event.get("declared_reason"), "change_event.declared_reason"
            ),
        },
    }
    expected["scope_hash"] = content_hash(expected)
    return expected


def _expected_work(delta: Mapping[str, Any], minimum_action: str) -> tuple[dict, dict]:
    preserved = _ids(delta.get("preserved"), "delta.preserved")
    invalidated = _ids(delta.get("invalidated"), "delta.invalidated")
    recomputed = _ids(delta.get("recomputed"), "delta.recomputed")
    if set(preserved) & set(invalidated):
        raise ValueError("preserved and invalidated work overlap")
    prior = sorted(set(preserved) | set(invalidated))
    denominator = {
        "prior_artifact_work": {
            "members": prior,
            "count": _exact_count(len(prior)),
            "unit": "artifact identities",
        },
        "replacement_output_work": {
            "members": recomputed,
            "count": _exact_count(len(recomputed)),
            "unit": "artifact identities",
        },
    }
    denominator["denominator_hash"] = content_hash(denominator)
    facts = {
        "facts_profile": "crg-certified-change-work/identity-counts@1",
        "minimum_action": minimum_action,
        "preserved_work": {
            "members": preserved,
            "count": _exact_count(len(preserved)),
            "unit": "artifact identities",
        },
        "invalidated_work": {
            "members": invalidated,
            "count": _exact_count(len(invalidated)),
            "unit": "artifact identities",
        },
        "recomputed_work": {
            "members": recomputed,
            "count": _exact_count(len(recomputed)),
            "unit": "artifact identities",
        },
        "prior_work_partition_complete": True,
        "interpretation": (
            "Exact artifact identities under the certified typed dependency closure; "
            "no effort, elapsed-time, cost, or counterfactual quantity is derived."
        ),
    }
    return denominator, facts


def _integer(
    value: Any, field: str, *, positive: bool = False, nonnegative: bool = True
) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"{field} must be an integer")
    if positive and value < 1:
        raise ValueError(f"{field} must be positive")
    if nonnegative and value < 0:
        raise ValueError(f"{field} must be non-negative")
    return value


def _code(value: Any, field: str) -> str:
    result = _identity(value, field)
    if len(result) > 64 or _CODE.fullmatch(result) is None:
        raise ValueError(f"{field} must be a bounded lower-kebab-case code")
    return result


def _measurement_event(value: Any, expected_class: str, field: str) -> dict:
    event = _object(value, field)
    if set(event) != _MEASUREMENT_EVENT_FIELDS:
        raise ValueError(f"{field} has an unsupported measurement-event field set")
    if (
        event.get("record_type") != "OperationalMeasurementEvent"
        or event.get("schema_id") != _MEASUREMENT_EVENT_SCHEMA
        or event.get("schema_version") != "1.0.0"
        or event.get("profile_id") != _MEASUREMENT_PROFILE
        or event.get("event_type") != "METRIC"
        or event.get("authorizing") is not False
        or event.get("evidence_eligible") is not False
    ):
        raise ValueError(f"{field} is not a non-authorizing v1 operational METRIC event")
    session_id = _identity(event.get("session_id"), f"{field}.session_id")
    if _PSEUDONYM.fullmatch(session_id) is None:
        raise ValueError(f"{field}.session_id is not pseudonymous")
    _integer(event.get("sequence"), f"{field}.sequence")
    _identity(event.get("observed_at"), f"{field}.observed_at")
    _integer(event.get("monotonic_ns"), f"{field}.monotonic_ns")
    if not is_hash(event.get("previous_event_hash")):
        raise ValueError(f"{field}.previous_event_hash is not a portable hash")
    stated_hash = event.get("content_hash")
    if not is_hash(stated_hash) or stated_hash != hash_without(event, "content_hash"):
        raise ValueError(f"{field}.content_hash does not bind the disclosed event")

    metric = _object(event.get("metric"), f"{field}.metric")
    expected_fields = (
        _COUNTERFACTUAL_METRIC_FIELDS
        if expected_class == "USER_DECLARED_COUNTERFACTUAL"
        else _MEASUREMENT_METRIC_FIELDS
    )
    if set(metric) != expected_fields:
        raise ValueError(f"{field}.metric has an unsupported field set")
    if (
        metric.get("measurement_class") != expected_class
        or metric.get("authorizing") is not False
        or metric.get("evidence_eligible") is not False
        or metric.get("claim_boundary") != "operational-measurement-only"
    ):
        raise ValueError(
            f"{field}.metric is not operational-only, non-evidentiary, and non-authorizing"
        )
    _code(metric.get("metric_code"), f"{field}.metric.metric_code")
    _code(metric.get("unit_code"), f"{field}.metric.unit_code")
    exact = _object(metric.get("exact_value"), f"{field}.metric.exact_value")
    if set(exact) != {"numerator", "denominator"}:
        raise ValueError(f"{field}.metric.exact_value must be a rational pair")
    _integer(
        exact.get("numerator"),
        f"{field}.metric.exact_value.numerator",
        nonnegative=False,
    )
    _integer(
        exact.get("denominator"),
        f"{field}.metric.exact_value.denominator",
        positive=True,
    )
    if expected_class == "USER_DECLARED_COUNTERFACTUAL":
        _code(metric.get("basis_code"), f"{field}.metric.basis_code")
        if (
            metric.get("counterfactual_status") != "USER_DECLARED_UNVERIFIED"
            or metric.get("roi_inferred") is not False
            or metric.get("savings_inferred") is not False
            or metric.get("superiority_inferred") is not False
        ):
            raise ValueError(
                f"{field}.metric counterfactual is not explicitly unsupported"
            )
    return event


def _expected_revalidation_facts(record: Mapping[str, Any]) -> dict:
    if (
        record.get("record_type") != "SelectiveRevalidationRecord"
        or record.get("profile") != "crg.etq-decision-loop"
        or record.get("schema_version") != "1.0.0"
    ):
        raise ValueError("qualification comparison has an unsupported revalidation record")
    _identity(record.get("record_id"), "selective_revalidation.record_id")
    changed = _ids(
        record.get("changed_properties"), "selective_revalidation.changed_properties"
    )
    raw_affected = record.get("affected")
    if not isinstance(raw_affected, list):
        raise ValueError("selective_revalidation.affected must be a list")
    affected: list[dict] = []
    for index, raw in enumerate(raw_affected):
        item = _object(raw, f"selective_revalidation.affected[{index}]")
        if set(item) != {"artifact_id", "minimum_action"}:
            raise ValueError("selective-revalidation affected facts are not closed")
        artifact_id = _identity(item.get("artifact_id"), "affected.artifact_id")
        action = _identity(item.get("minimum_action"), "affected.minimum_action")
        if action not in _REVALIDATION_ACTIONS:
            raise ValueError(f"unknown selective-revalidation action {action!r}")
        affected.append({"artifact_id": artifact_id, "minimum_action": action})
    if affected != sorted(affected, key=lambda item: (item["artifact_id"], item["minimum_action"])):
        raise ValueError("selective_revalidation.affected is not canonically ordered")
    if len({item["artifact_id"] for item in affected}) != len(affected):
        raise ValueError("selective_revalidation.affected repeats an artifact")
    preserved = _ids(record.get("preserved"), "selective_revalidation.preserved")
    replacement = _ids(
        record.get("replacement_required"),
        "selective_revalidation.replacement_required",
    )
    if record.get("state") not in {"PENDING_REVALIDATION", "REVALIDATION_COMPLETE"}:
        raise ValueError("selective_revalidation carries an unknown state")
    return {
        "facts_profile": "crg-selective-revalidation-facts/typed-closure@1",
        "classification": "SYSTEM_DERIVED_INDEPENDENTLY_RECONSTRUCTED",
        "changed_source": _identity(
            record.get("changed_source"), "selective_revalidation.changed_source"
        ),
        "changed_properties": changed,
        "affected": affected,
        "preserved": preserved,
        "replacement_required": replacement,
        "state": record["state"],
        "affected_count": _exact_count(len(affected)),
        "preserved_count": _exact_count(len(preserved)),
        "replacement_required_count": _exact_count(len(replacement)),
        "interpretation": (
            "Exact identities reconstructed from the stored complete typed dependency "
            "closure; no operational, economic, counterfactual, or authorization claim."
        ),
    }


def _operational_references(value: Any, *, counterfactual: bool) -> list[dict]:
    if not isinstance(value, list):
        raise ValueError("operational references must be a list")
    if len(value) > _MAX_OPERATIONAL_REFERENCES:
        raise ValueError("operational reference count exceeds the bounded profile")
    expected_class = (
        "USER_DECLARED_COUNTERFACTUAL" if counterfactual else "LOCAL_OBSERVATION"
    )
    result: list[dict] = []
    for index, raw in enumerate(value):
        item = _object(raw, f"operational_references[{index}]")
        if set(item) != _OPERATIONAL_REFERENCE_FIELDS:
            raise ValueError("operational reference has an unsupported field set")
        ok, detail = _sealed(item, "reference_hash")
        if not ok:
            raise ValueError(detail)
        event = _measurement_event(
            item.get("event"), expected_class, f"operational_references[{index}].event"
        )
        expected_profile = (
            "crg-local-operational-counterfactual-reference@1"
            if counterfactual
            else "crg-local-operational-observation-reference@1"
        )
        expected_classification = (
            "UNSUPPORTED_USER_DECLARED_COUNTERFACTUAL"
            if counterfactual
            else "LOCAL_OPERATIONAL_OBSERVATION_NON_EVIDENCE"
        )
        expected_status = (
            "PRESENT_USER_DECLARED_UNVERIFIED"
            if counterfactual
            else "PRESENT_LOCAL_NOT_INDEPENDENTLY_RECONSTRUCTED"
        )
        if (
            item.get("reference_profile") != expected_profile
            or item.get("reference_version") != QUALIFICATION_SCHEMA_VERSION
            or item.get("classification") != expected_classification
            or item.get("claim_status") != expected_status
            or item.get("session_id") != event["session_id"]
            or not is_hash(item.get("session_content_hash"))
            or item.get("event_content_hash") != event["content_hash"]
            or item.get("authorizing") is not False
            or item.get("evidence_eligible") is not False
            or item.get("semantic_effect") != "NONE"
        ):
            raise ValueError("operational reference classification or hash binding is invalid")
        result.append(item)
    expected_order = sorted(
        result, key=lambda item: (item["session_id"], item["event_content_hash"])
    )
    identities = [(item["session_id"], item["event_content_hash"]) for item in result]
    if result != expected_order or len(identities) != len(set(identities)):
        raise ValueError("operational references repeat or are not canonically ordered")
    return result


def _verify_qualification_extension(value: Any) -> tuple[list[tuple[str, bool, str]], dict]:
    checks: list[tuple[str, bool, str]] = []
    report: dict = {"qualification_extension": "PRESENT"}
    extension = _object(value, "qualification_extension")
    profile_ok = (
        set(extension) == _QUALIFICATION_FIELDS
        and extension.get("extension_type")
        == "QualificationSelectiveRevalidationComparison"
        and extension.get("schema_version") == QUALIFICATION_SCHEMA_VERSION
        and extension.get("profile") == QUALIFICATION_PROFILE
        and extension.get("first_release_attribution") == QUALIFICATION_FIRST_RELEASE
    )
    sealed_ok, sealed_detail = _sealed(extension, "extension_hash")
    checks.append((
        "qualification_comparison_profile_integrity",
        profile_ok and sealed_ok,
        sealed_detail if profile_ok else "qualification extension profile or field set is unsupported",
    ))
    boundary_ok = (
        extension.get("authority") == AUTHORITY
        and extension.get("authorizing") is False
        and extension.get("semantic_effect") == "NONE"
        and extension.get("claim_boundary") == QUALIFICATION_CLAIM_BOUNDARY
        and extension.get("conclusion")
        == "NO_INFERRED_COUNTERFACTUAL_OR_ECONOMIC_CONCLUSION"
    )
    checks.append((
        "qualification_comparison_non_authorizing_boundary",
        boundary_ok,
        "qualification facts, observations, counterfactuals, conclusion, and authority remain separated",
    ))

    replay_failures: list[str] = []
    record: dict = {}
    replay_result: VerificationResult | None = None
    try:
        binding = _object(
            extension.get("selective_revalidation_binding"),
            "selective_revalidation_binding",
        )
        if set(binding) != _REVALIDATION_BINDING_FIELDS:
            raise ValueError("selective-revalidation binding has an unsupported field set")
        binding_ok, binding_detail = _sealed(binding, "binding_hash")
        if not binding_ok:
            replay_failures.append(binding_detail)
        record = _object(
            binding.get("selective_revalidation_record"),
            "selective_revalidation_record",
        )
        inputs = _object(binding.get("verification_inputs"), "verification_inputs")
        if set(inputs) != _LIFECYCLE_INPUT_FIELDS:
            raise ValueError("lifecycle verification envelope has an unsupported field set")
        replay = _object(inputs.get("inputs"), "verification_inputs.inputs")
        if set(replay) != _REVALIDATION_REPLAY_FIELDS:
            raise ValueError("selective-revalidation replay inputs are not exact")
        record_hash = content_hash(record)
        if (
            inputs.get("verification_profile") != "crg-lifecycle/independent-replay@1"
            or inputs.get("first_release_attribution") != "v1.3/ETQ_LIFECYCLE"
            or inputs.get("verifier_operation")
            != "verify_selective_revalidation_record"
            or inputs.get("record_type") != "SelectiveRevalidationRecord"
            or inputs.get("record_hash") != record_hash
        ):
            raise ValueError("lifecycle replay envelope does not bind the revalidation record")
        expected_hashes = {
            "selective_revalidation_hash": record_hash,
            "verification_inputs_hash": content_hash(inputs),
            "independent_verification_hash": content_hash(
                binding.get("independent_verification")
            ),
        }
        for field, expected in expected_hashes.items():
            if binding.get(field) != expected:
                replay_failures.append(
                    f"{field} differs from independently reconstructed {expected}"
                )
        replay_result = verify_selective_revalidation_record(
            record,
            replay["dependency_edges"],
            replay["artifact_universe"],
        )
        if not replay_result.ok or replay_result.status != Status.VERIFIED:
            replay_failures.extend(
                replay_result.violations
                or [f"selective-revalidation replay returned {replay_result.status}"]
            )
        if binding.get("independent_verification") != replay_result.to_json():
            replay_failures.append(
                "bound revalidation result differs from fresh stdlib-only lifecycle replay"
            )
    except (CanonicalError, KeyError, TypeError, ValueError) as error:
        replay_failures.append(str(error))
    checks.append((
        "qualification_revalidation_independently_replayed",
        not replay_failures,
        "; ".join(replay_failures) if replay_failures else
        "stored SelectiveRevalidationRecord and exact lifecycle inputs independently replayed",
    ))

    fact_failures: list[str] = []
    try:
        facts = _object(
            extension.get("system_derived_revalidation_facts"),
            "system_derived_revalidation_facts",
        )
        if set(facts) != _QUALIFICATION_FACT_FIELDS:
            raise ValueError("system-derived revalidation facts have an unsupported field set")
        expected_facts = _expected_revalidation_facts(record)
        if facts != expected_facts:
            raise ValueError(
                "system-derived revalidation facts differ from independent reconstruction"
            )
        forbidden = _forbidden_paths(facts, "system_derived_revalidation_facts")
        if forbidden:
            raise ValueError(f"prohibited strengthened fact fields: {forbidden}")
    except (CanonicalError, TypeError, ValueError) as error:
        fact_failures.append(str(error))
    checks.append((
        "qualification_revalidation_facts_reconstructed",
        not fact_failures and replay_result is not None and replay_result.ok,
        "; ".join(fact_failures) if fact_failures else
        "affected, preserved, replacement-required, state, and exact counts reconstructed",
    ))

    observation_failures: list[str] = []
    counterfactual_failures: list[str] = []
    observations: list[dict] = []
    counterfactuals: list[dict] = []
    try:
        observations = _operational_references(
            extension.get("local_operational_observations"), counterfactual=False
        )
        expected_status = "PRESENT_LOCAL_NON_EVIDENTIARY" if observations else "ABSENT"
        if extension.get("local_observation_status") != expected_status:
            raise ValueError("local-observation absence/presence status is not explicit")
    except (CanonicalError, TypeError, ValueError) as error:
        observation_failures.append(str(error))
    checks.append((
        "qualification_local_observations_non_evidentiary",
        not observation_failures,
        "; ".join(observation_failures) if observation_failures else
        "local observations are bounded, hash-bound, disclosed, and explicitly not evidence",
    ))
    try:
        counterfactuals = _operational_references(
            extension.get("declared_counterfactuals"), counterfactual=True
        )
        expected_status = (
            "PRESENT_USER_DECLARED_UNSUPPORTED" if counterfactuals else "ABSENT"
        )
        if extension.get("counterfactual_status") != expected_status:
            raise ValueError("counterfactual absence/presence status is not explicit")
    except (CanonicalError, TypeError, ValueError) as error:
        counterfactual_failures.append(str(error))
    checks.append((
        "qualification_counterfactuals_declared_unsupported",
        not counterfactual_failures,
        "; ".join(counterfactual_failures) if counterfactual_failures else
        "counterfactuals are user-declared, unsupported, and carry no inferred claims",
    ))
    report.update({
        "qualification_status": (
            "VERIFIED" if all(passed for _name, passed, _detail in checks) else "FAILED"
        ),
        "qualification_profile": extension.get("profile"),
        "qualification_revalidation_record_id": record.get("record_id"),
        "qualification_affected_count": (
            len(record.get("affected") or []) if isinstance(record, dict) else 0
        ),
        "qualification_preserved_count": (
            len(record.get("preserved") or []) if isinstance(record, dict) else 0
        ),
        "qualification_replacement_required_count": (
            len(record.get("replacement_required") or [])
            if isinstance(record, dict) else 0
        ),
        "qualification_local_observation_count": len(observations),
        "qualification_declared_counterfactual_count": len(counterfactuals),
        "qualification_claim_boundary": QUALIFICATION_CLAIM_BOUNDARY,
    })
    return checks, report


def verify_comparative_change_evidence(record: Any) -> VerificationResult:
    """Reconstruct all v1.2 comparative-change facts and replay the delta."""

    result = VerificationResult(
        ok=False,
        status=Status.FAILED,
        report={
            "record_type": "ComparativeChangeEvidence",
            "level_attempted": "V3",
            "level_achieved": "NONE",
            "authority": AUTHORITY,
        },
    )
    if not isinstance(record, Mapping):
        result.record("comparative_change_shape", False, "record must be an object")
        return result.finish()
    artifact = dict(record)
    profile_ok = (
        artifact.get("record_type") == "ComparativeChangeEvidence"
        and artifact.get("schema_version") == SCHEMA_VERSION
        and artifact.get("profile") == PROFILE
        and artifact.get("first_release_attribution") == FIRST_RELEASE
    )
    result.record(
        "comparative_change_profile",
        profile_ok,
        f"registered profile is ComparativeChangeEvidence/{SCHEMA_VERSION}/{PROFILE}",
    )
    artifact_fields = set(artifact)
    shape_ok = (
        artifact_fields == set(_TOP_LEVEL_FIELDS)
        or artifact_fields
        == set(_TOP_LEVEL_FIELDS) | {_QUALIFICATION_TOP_LEVEL_FIELD}
    )
    if shape_ok:
        try:
            _identity(artifact.get("comparison_id"), "comparison_id")
        except ValueError:
            shape_ok = False
    result.record(
        "comparative_change_record_shape",
        shape_ok,
        "the profile permits only its complete canonical field set",
    )
    ok, detail = _sealed(artifact, "record_hash")
    result.record("comparative_change_integrity", ok, detail)
    boundary_ok = (
        artifact.get("authority") == AUTHORITY
        and artifact.get("authorizing") is False
        and artifact.get("semantic_effect") == "NONE"
        and artifact.get("evidence_class")
        == "SYSTEM_DERIVED_CERTIFIED_CHANGE_FACTS"
        and artifact.get("claim_boundary") == CLAIM_BOUNDARY
        and artifact.get("conclusion")
        == "NO_METHOD_RANKING_OR_ECONOMIC_CONCLUSION"
    )
    result.record(
        "comparative_change_non_authorizing_boundary",
        boundary_ok,
        "authority, semantic effect, evidence class, claim boundary, and conclusion are fixed",
    )

    binding_failures: list[str] = []
    independent: VerificationResult | None = None
    delta: dict = {}
    inputs: dict = {}
    binding: dict = {}
    try:
        binding = _object(
            artifact.get("certified_delta_binding"), "certified_delta_binding"
        )
        if set(binding) != _BINDING_FIELDS:
            raise ValueError("certified_delta_binding has a missing or unsupported field set")
        ok, detail = _sealed(binding, "binding_hash")
        if not ok:
            binding_failures.append(detail)
        delta = _object(binding.get("certified_delta"), "certified_delta")
        inputs = _object(binding.get("verification_inputs"), "verification_inputs")
        missing = sorted(_REQUIRED_INPUTS - set(inputs))
        unknown = sorted(set(inputs) - _REQUIRED_INPUTS - _OPTIONAL_INPUTS)
        if missing or unknown:
            raise ValueError(
                f"verification_inputs are not closed: missing={missing}, unknown={unknown}"
            )
        expected_hashes = {
            "certified_delta_hash": content_hash(delta),
            "verification_inputs_hash": content_hash(inputs),
            "independent_verification_hash": content_hash(
                binding.get("independent_verification")
            ),
        }
        for field, expected in expected_hashes.items():
            if binding.get(field) != expected:
                binding_failures.append(
                    f"{field} differs from independently reconstructed {expected}"
                )
        independent = verify_certified_delta_record(
            delta,
            inputs["prior_case"],
            inputs["current_case"],
            inputs["dependency_edges"],
            replacements=inputs["replacements"],
            prior_phase=inputs.get("prior_phase"),
            current_phase=inputs.get("current_phase"),
            prior_phase_source_r=inputs.get("prior_phase_source_r"),
            current_phase_source_r=inputs.get("current_phase_source_r"),
        )
        if not independent.ok or independent.status != Status.VERIFIED:
            binding_failures.extend(independent.violations or [
                f"embedded delta replay returned {independent.status}"
            ])
        if binding.get("independent_verification") != independent.to_json():
            binding_failures.append(
                "bound independent result differs from a fresh stdlib-only replay"
            )
    except (CanonicalError, KeyError, TypeError, ValueError) as error:
        binding_failures.append(str(error))
    result.record(
        "comparative_change_delta_independently_replayed",
        not binding_failures,
        "; ".join(binding_failures) if binding_failures else
        "the CertifiedDeltaRecord, exact replay inputs, and verifier result agree",
    )

    reconstruction_failures: list[str] = []
    minimum_action = None
    if independent is not None and independent.ok:
        minimum_action = independent.report.get("minimum_action")
        try:
            delta_body = _object(delta.get("delta"), "certified_delta.delta")
            expected_scope = _expected_scope(delta_body, inputs, artifact.get("scope"))
            if artifact.get("scope") != expected_scope:
                reconstruction_failures.append(
                    "scope does not bind the replayed case roots and change event"
                )
            expected_denominator, expected_facts = _expected_work(
                delta_body, _identity(minimum_action, "minimum action")
            )
            if artifact.get("work_denominator") != expected_denominator:
                reconstruction_failures.append(
                    "work denominator differs from the preserved/invalidated/recomputed identities"
                )
            if artifact.get("system_derived_facts") != expected_facts:
                reconstruction_failures.append(
                    "minimum action or exact work facts differ from independent reconstruction"
                )
        except (CanonicalError, TypeError, ValueError) as error:
            reconstruction_failures.append(str(error))
    else:
        reconstruction_failures.append("a successful independent delta replay is required")
    result.record(
        "comparative_change_facts_reconstructed",
        not reconstruction_failures,
        "; ".join(reconstruction_failures) if reconstruction_failures else
        "minimum action and exact preserved, invalidated, and recomputed identities reconstructed",
    )

    limitations = artifact.get("limitations")
    limitations_ok = (
        isinstance(limitations, list)
        and bool(limitations)
        and all(
            isinstance(item, str) and item and item == item.strip()
            for item in limitations
        )
        and limitations == sorted(limitations)
        and len(limitations) == len(set(limitations))
    )
    result.record(
        "comparative_change_limitations",
        limitations_ok,
        "at least one unique canonically ordered limitation is required",
    )
    forbidden = _forbidden_paths(
        artifact.get("system_derived_facts"), "system_derived_facts"
    )
    result.record(
        "comparative_change_no_strengthened_claim",
        not forbidden,
        f"prohibited conclusion fields: {forbidden}" if forbidden else
        "no ROI, savings, superiority, ranking, or avoided-work field is present",
    )
    if _QUALIFICATION_TOP_LEVEL_FIELD in artifact:
        try:
            qualification_checks, qualification_report = _verify_qualification_extension(
                artifact.get(_QUALIFICATION_TOP_LEVEL_FIELD)
            )
        except (CanonicalError, TypeError, ValueError) as error:
            qualification_checks = [(
                "qualification_comparison_decode",
                False,
                str(error),
            )]
            qualification_report = {"qualification_extension": "INVALID"}
        for name, passed, detail in qualification_checks:
            result.record(name, passed, detail)
        result.report.update(qualification_report)
    try:
        artifact_root = content_hash(artifact)
    except (CanonicalError, TypeError, ValueError):
        artifact_root = None
    result.report.update(
        {
            "artifact_root": artifact_root,
            "comparison_id": artifact.get("comparison_id"),
            "minimum_action": minimum_action,
            "preserved_count": len(
                (artifact.get("system_derived_facts") or {})
                .get("preserved_work", {})
                .get("members", [])
            ) if isinstance(artifact.get("system_derived_facts"), dict) else 0,
            "recomputed_count": len(
                (artifact.get("system_derived_facts") or {})
                .get("recomputed_work", {})
                .get("members", [])
            ) if isinstance(artifact.get("system_derived_facts"), dict) else 0,
            "claim_boundary": CLAIM_BOUNDARY,
        }
    )
    result.finish()
    if not profile_ok:
        result.status = Status.UNSUPPORTED_PROFILE
    elif result.ok:
        result.status = Status.VERIFIED_RELATIVE
        result.report["level_achieved"] = "V3"
    else:
        result.status = Status.FAILED
    return result
