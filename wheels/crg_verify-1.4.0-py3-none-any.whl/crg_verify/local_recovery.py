"""Independent verifier for local-profile admin recovery evidence.

Only the Python standard library and ``crg_verify``'s independently
implemented canonicalizer are used.  No producer, server, store, or CRG
kernel module is imported.
"""
from __future__ import annotations

import hashlib
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple

from .canonical import CanonicalError, content_hash, is_hash
from .certificate import Status, VerificationResult

__all__ = [
    "LOCAL_ADMIN_RECOVERY_PROFILE",
    "LOCAL_ADMIN_RECOVERY_SCHEMA_VERSION",
    "verify_local_admin_recovery_evidence",
]


LOCAL_ADMIN_RECOVERY_PROFILE = "crg.local-admin-recovery@1"
LOCAL_ADMIN_RECOVERY_SCHEMA_VERSION = "1.0.0"
_ROLES = ("SOURCE", "BACKUP_ARCHIVE", "RESTORED_EMPTY_TARGET")
_ROOT_FIELDS = (
    "case_root",
    "dependency_graph_root",
    "audit_chain_root",
    "active_certificate_root",
    "superseded_certificate_root",
    "other_certificate_root",
    "certificate_inventory_root",
    "object_inventory_root",
)
_AUDIT_GENESIS_HASH = content_hash({
    "record_type": "LocalRecoveryAuditChainGenesis",
    "profile": LOCAL_ADMIN_RECOVERY_PROFILE,
})
_CLAIM_BOUNDARY = (
    "verified local-profile logical backup, archive extraction, typed inventory "
    "equality, and empty-target restore only; not provider disaster recovery, "
    "availability, point-in-time recovery, failover, RPO/RTO, transition "
    "execution, physical signoff, or generic physical safety"
)


class _DecodeError(ValueError):
    pass


class _UnsupportedProfile(_DecodeError):
    pass


def _object(value: Any, where: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise _DecodeError(f"{where} must be an object")
    return value


def _array(value: Any, where: str) -> Sequence[Any]:
    if not isinstance(value, (list, tuple)):
        raise _DecodeError(f"{where} must be an array")
    return value


def _keys(value: Mapping[str, Any], fields: Iterable[str], where: str) -> None:
    expected = set(fields)
    found = set(value)
    if found != expected:
        raise _DecodeError(
            f"{where} requires exactly {sorted(expected)}; found {sorted(found)}"
        )


def _text(value: Any, where: str, *, allow_empty: bool = False) -> str:
    if not isinstance(value, str) or (not allow_empty and not value):
        raise _DecodeError(f"{where} must be a string")
    return value


def _hash(value: Any, where: str) -> str:
    if not is_hash(value):
        raise _DecodeError(f"{where} must be an algorithm-tagged SHA-256 hash")
    return str(value)


def _positive(value: Any, where: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise _DecodeError(f"{where} must be a positive integer")
    return value


def _nonnegative(value: Any, where: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise _DecodeError(f"{where} must be a non-negative integer")
    return value


def _preflight(value: Any, where: str) -> str:
    try:
        return content_hash(value)
    except (CanonicalError, TypeError, ValueError) as error:
        raise _DecodeError(f"{where} is not canonically hashable: {error}") from error


def _inventory_profile(document: Mapping[str, Any]) -> None:
    if document.get("record_type") != "LocalRecoveryTypedInventory":
        raise _DecodeError("unsupported local recovery inventory record type")
    if document.get("profile") != LOCAL_ADMIN_RECOVERY_PROFILE:
        raise _UnsupportedProfile(
            f"unregistered local recovery inventory profile {document.get('profile')!r}"
        )
    if document.get("schema_version") != LOCAL_ADMIN_RECOVERY_SCHEMA_VERSION:
        raise _UnsupportedProfile(
            "unsupported local recovery inventory schema version "
            f"{document.get('schema_version')!r}"
        )


def _case_root(value: Any) -> Tuple[str, int]:
    entries = _array(value, "case inventory")
    prior = None
    fields = (
        "case_id", "case_version", "content_hash", "branch_id", "parent_version",
        "status", "created_at", "derived_from", "object_status", "payload",
    )
    for offset, raw in enumerate(entries):
        item = _object(raw, f"case_inventory[{offset}]")
        _keys(item, fields, f"case_inventory[{offset}]")
        key = (
            _text(item.get("case_id"), f"case_inventory[{offset}].case_id"),
            _positive(item.get("case_version"), f"case_inventory[{offset}].case_version"),
        )
        if prior is not None and key <= prior:
            raise _DecodeError("case inventory identities repeat or are not sorted")
        prior = key
        _text(item.get("branch_id"), f"case_inventory[{offset}].branch_id")
        if item.get("parent_version") is not None:
            _positive(item.get("parent_version"), f"case_inventory[{offset}].parent_version")
        _text(item.get("status"), f"case_inventory[{offset}].status")
        _text(item.get("created_at"), f"case_inventory[{offset}].created_at")
        if item.get("derived_from") is not None:
            _object(item.get("derived_from"), f"case_inventory[{offset}].derived_from")
        _text(item.get("object_status"), f"case_inventory[{offset}].object_status")
        payload = _object(item.get("payload"), f"case_inventory[{offset}].payload")
        if item.get("content_hash") != _preflight(payload, f"case_inventory[{offset}].payload"):
            raise _DecodeError(f"case_inventory[{offset}] has a forged payload hash")
    if not entries:
        raise _DecodeError(
            "a local recovery drill source must contain at least one case version"
        )
    return _preflight(entries, "case inventory"), len(entries)


def _dependency_root(value: Any) -> Tuple[str, int]:
    entries = _array(value, "dependency graph")
    fields = (
        "edge_id", "case_id", "source", "target", "edge_type", "scope",
        "minimum_action", "recorded_at",
    )
    prior = None
    for offset, raw in enumerate(entries):
        item = _object(raw, f"dependency_graph[{offset}]")
        _keys(item, fields, f"dependency_graph[{offset}]")
        case_id = item.get("case_id")
        if case_id is not None:
            case_id = _text(case_id, f"dependency_graph[{offset}].case_id")
        edge_id = _text(item.get("edge_id"), f"dependency_graph[{offset}].edge_id")
        key = (case_id or "", edge_id)
        if prior is not None and key <= prior:
            raise _DecodeError("dependency edge identities repeat or are not sorted")
        prior = key
        for field in ("source", "target", "edge_type", "recorded_at"):
            _text(item.get(field), f"dependency_graph[{offset}].{field}")
        for field in ("scope", "minimum_action"):
            _text(
                item.get(field), f"dependency_graph[{offset}].{field}", allow_empty=True
            )
    return _preflight(entries, "dependency graph"), len(entries)


def _audit_root(value: Any) -> Tuple[str, int]:
    entries = _array(value, "audit chain")
    fields = ("seq", "recorded_at", "event", "prior_entry_hash", "entry_hash")
    prior_hash = _AUDIT_GENESIS_HASH
    prior_seq = 0
    hashes = []
    for offset, raw in enumerate(entries):
        item = _object(raw, f"audit_chain[{offset}]")
        _keys(item, fields, f"audit_chain[{offset}]")
        seq = _positive(item.get("seq"), f"audit_chain[{offset}].seq")
        if seq <= prior_seq:
            raise _DecodeError("audit sequence is reordered or repeated")
        prior_seq = seq
        recorded_at = _text(item.get("recorded_at"), f"audit_chain[{offset}].recorded_at")
        event = _object(item.get("event"), f"audit_chain[{offset}].event")
        if item.get("prior_entry_hash") != prior_hash:
            raise _DecodeError(f"audit_chain[{offset}] breaks the prior-entry chain")
        expected = _preflight({
            "profile": LOCAL_ADMIN_RECOVERY_PROFILE,
            "prior_entry_hash": prior_hash,
            "record": {"seq": seq, "recorded_at": recorded_at, "event": event},
        }, f"audit_chain[{offset}] derivation")
        if item.get("entry_hash") != expected:
            raise _DecodeError(f"audit_chain[{offset}] has a stale or forged hash")
        hashes.append(expected)
        prior_hash = expected
    return _preflight({
        "profile": LOCAL_ADMIN_RECOVERY_PROFILE,
        "genesis_hash": _AUDIT_GENESIS_HASH,
        "entry_hashes": hashes,
        "final_entry_hash": prior_hash,
    }, "audit chain root"), len(entries)


def _certificate_partition(value: Any, name: str) -> Tuple[str, int]:
    entries = _array(value, f"certificate inventory.{name}")
    fields = (
        "case_id", "certificate_id", "content_hash", "job_id", "outcome",
        "affirmative", "registered_at", "status", "payload",
    )
    prior = None
    for offset, raw in enumerate(entries):
        where = f"certificate_inventory.{name}[{offset}]"
        item = _object(raw, where)
        _keys(item, fields, where)
        key = (
            _text(item.get("case_id"), f"{where}.case_id"),
            _text(item.get("certificate_id"), f"{where}.certificate_id"),
        )
        if prior is not None and key <= prior:
            raise _DecodeError(f"{name} certificate identities repeat or are not sorted")
        prior = key
        _text(item.get("job_id"), f"{where}.job_id")
        _text(item.get("outcome"), f"{where}.outcome", allow_empty=True)
        if not isinstance(item.get("affirmative"), bool):
            raise _DecodeError(f"{where}.affirmative must be boolean")
        _text(item.get("registered_at"), f"{where}.registered_at")
        status = _text(item.get("status"), f"{where}.status")
        expected = {"active": "ACTIVE", "superseded": "SUPERSEDED"}.get(name)
        if expected is not None and status != expected:
            raise _DecodeError(f"{where}.status must be {expected!r}")
        if name == "other" and status in {"ACTIVE", "SUPERSEDED"}:
            raise _DecodeError(f"{where} belongs in a named certificate partition")
        payload = _object(item.get("payload"), f"{where}.payload")
        if item.get("content_hash") != _preflight(payload, f"{where}.payload"):
            raise _DecodeError(f"{where} has a forged payload hash")
    return _preflight(entries, f"certificate inventory.{name}"), len(entries)


def _certificate_roots(value: Any) -> Tuple[Dict[str, str], Dict[str, int]]:
    document = _object(value, "certificate inventory")
    _keys(document, ("active", "superseded", "other"), "certificate inventory")
    active, active_count = _certificate_partition(document["active"], "active")
    superseded, superseded_count = _certificate_partition(
        document["superseded"], "superseded"
    )
    other, other_count = _certificate_partition(document["other"], "other")
    return {
        "active_certificate_root": active,
        "superseded_certificate_root": superseded,
        "other_certificate_root": other,
        "certificate_inventory_root": _preflight({
            "active_certificate_root": active,
            "superseded_certificate_root": superseded,
            "other_certificate_root": other,
        }, "certificate inventory root"),
    }, {
        "active_certificates": active_count,
        "superseded_certificates": superseded_count,
        "other_certificates": other_count,
    }


def _object_root(value: Any) -> Tuple[str, int]:
    entries = _array(value, "object inventory")
    fields = (
        "object_id", "object_type", "status", "present", "byte_length",
        "content_hash", "payload", "tombstone",
    )
    prior = None
    for offset, raw in enumerate(entries):
        where = f"object_inventory[{offset}]"
        item = _object(raw, where)
        _keys(item, fields, where)
        object_id = _hash(item.get("object_id"), f"{where}.object_id")
        declared = _hash(item.get("content_hash"), f"{where}.content_hash")
        if object_id != declared:
            raise _DecodeError(f"{where} identity and declared hash differ")
        if prior is not None and object_id <= prior:
            raise _DecodeError("object inventory identities repeat or are not sorted")
        prior = object_id
        _text(item.get("object_type"), f"{where}.object_type")
        _text(item.get("status"), f"{where}.status")
        present = item.get("present")
        if not isinstance(present, bool):
            raise _DecodeError(f"{where}.present must be boolean")
        _nonnegative(item.get("byte_length"), f"{where}.byte_length")
        if present:
            if item.get("tombstone") is not None:
                raise _DecodeError(f"{where} is present but carries a tombstone")
            if declared != _preflight(item.get("payload"), f"{where}.payload"):
                raise _DecodeError(f"{where} payload does not match its identity")
        else:
            if item.get("payload") is not None:
                raise _DecodeError(f"{where} is absent but carries payload bytes")
            tombstone = _object(item.get("tombstone"), f"{where}.tombstone")
            if tombstone.get("content_hash") != declared:
                raise _DecodeError(f"{where} tombstone names a different object")
    return _preflight(entries, "object inventory"), len(entries)


def _cross_references(
    cases: Sequence[Any], certificates: Mapping[str, Any], objects: Sequence[Any]
) -> None:
    by_identity = {
        str(_object(item, "object inventory item").get("object_id")): _object(
            item, "object inventory item"
        )
        for item in objects
    }
    references = []
    references.extend(
        (f"case_inventory[{offset}]", _object(item, "case inventory item"), "CRGCase")
        for offset, item in enumerate(cases)
    )
    for partition in ("active", "superseded", "other"):
        references.extend(
            (
                f"certificate_inventory.{partition}[{offset}]",
                _object(item, "certificate inventory item"),
                "DecisionCertificate",
            )
            for offset, item in enumerate(_array(certificates[partition], partition))
        )
    for where, item, expected_type in references:
        stored = by_identity.get(str(item.get("content_hash")))
        if stored is None or stored.get("present") is not True:
            raise _DecodeError(f"{where} is absent from the present object inventory")
        if stored.get("object_type") != expected_type:
            raise _DecodeError(f"{where} has the wrong stored object type")
        if stored.get("payload") != item.get("payload"):
            raise _DecodeError(
                f"{where} payload differs from the content-addressed object inventory"
            )
        if stored.get("status") != item.get("object_status", item.get("status")):
            raise _DecodeError(f"{where} lifecycle status differs from object inventory")


def _decode_inventory(
    value: Any, expected_role: str
) -> Tuple[str, str, Dict[str, str], Dict[str, int]]:
    document = _object(value, f"{expected_role} inventory")
    _inventory_profile(document)
    _keys(document, (
        "record_type", "profile", "schema_version", "inventory_id",
        "inventory_role", "case_inventory", "dependency_graph", "audit_chain",
        "certificate_inventory", "object_inventory", "typed_roots",
        "inventory_root", "counts",
    ), f"{expected_role} inventory")
    _text(document.get("inventory_id"), f"{expected_role} inventory.inventory_id")
    if document.get("inventory_role") != expected_role:
        raise _DecodeError(
            f"expected inventory role {expected_role!r}, found {document.get('inventory_role')!r}"
        )
    case_root, case_count = _case_root(document.get("case_inventory"))
    dependency_root, dependency_count = _dependency_root(document.get("dependency_graph"))
    audit_root, audit_count = _audit_root(document.get("audit_chain"))
    certificate_roots, certificate_counts = _certificate_roots(
        document.get("certificate_inventory")
    )
    object_root, object_count = _object_root(document.get("object_inventory"))
    _cross_references(
        _array(document.get("case_inventory"), "case inventory"),
        _object(document.get("certificate_inventory"), "certificate inventory"),
        _array(document.get("object_inventory"), "object inventory"),
    )
    derived = {
        "case_root": case_root,
        "dependency_graph_root": dependency_root,
        "audit_chain_root": audit_root,
        **certificate_roots,
        "object_inventory_root": object_root,
    }
    roots = _object(document.get("typed_roots"), f"{expected_role} inventory.typed_roots")
    _keys(roots, _ROOT_FIELDS, f"{expected_role} inventory.typed_roots")
    for field in _ROOT_FIELDS:
        _hash(roots.get(field), f"{expected_role} inventory.typed_roots.{field}")
    if dict(roots) != derived:
        stale = sorted(name for name in _ROOT_FIELDS if roots.get(name) != derived[name])
        raise _DecodeError(f"{expected_role} inventory has stale typed roots {stale}")
    inventory_root = _preflight({
        "profile": LOCAL_ADMIN_RECOVERY_PROFILE,
        "typed_roots": derived,
    }, f"{expected_role} inventory root")
    if document.get("inventory_root") != inventory_root:
        raise _DecodeError(f"{expected_role} inventory root is stale")
    counts = {
        "cases": case_count,
        "dependency_edges": dependency_count,
        "audit_entries": audit_count,
        **certificate_counts,
        "objects": object_count,
    }
    counts_document = _object(document.get("counts"), f"{expected_role} inventory.counts")
    _keys(counts_document, counts, f"{expected_role} inventory.counts")
    if dict(counts_document) != counts:
        raise _DecodeError(f"{expected_role} inventory counts are stale")
    return _preflight(document, f"{expected_role} inventory"), inventory_root, derived, counts


def _archive_hash(archive_bytes: Any) -> str:
    if not isinstance(archive_bytes, (bytes, bytearray, memoryview)):
        raise _DecodeError("archive_bytes must contain the exact backup archive bytes")
    return "sha256:" + hashlib.sha256(bytes(archive_bytes)).hexdigest()


def verify_local_admin_recovery_evidence(
    record: Mapping[str, Any],
    source_inventory: Mapping[str, Any],
    backup_inventory: Mapping[str, Any],
    restored_inventory: Mapping[str, Any],
    backup_manifest: Mapping[str, Any],
    archive_bytes: bytes,
) -> VerificationResult:
    """Re-derive all typed roots and bind them to the actual archive bytes."""
    result = VerificationResult(ok=False, status=Status.FAILED)
    if not isinstance(record, Mapping):
        result.record(
            "local_recovery_wire", False,
            "LocalAdminRecoveryEvidence must be a JSON object",
        )
        return result.finish()
    try:
        if record.get("profile") != LOCAL_ADMIN_RECOVERY_PROFILE:
            raise _UnsupportedProfile(
                f"unregistered local recovery profile {record.get('profile')!r}"
            )
        if record.get("schema_version") != LOCAL_ADMIN_RECOVERY_SCHEMA_VERSION:
            raise _UnsupportedProfile(
                f"unsupported local recovery schema version {record.get('schema_version')!r}"
            )
        if record.get("record_type") != "LocalAdminRecoveryEvidence":
            raise _DecodeError("expected LocalAdminRecoveryEvidence")
        _keys(record, (
            "record_type", "profile", "schema_version", "recovery_id",
            "source_inventory_hash", "backup_inventory_hash", "restored_inventory_hash",
            "source_inventory_root", "backup_inventory_root", "restored_inventory_root",
            "typed_roots", "matched_typed_roots", "archive_sha256",
            "backup_manifest_hash", "restore_target_precondition", "integrity_status",
            "authority", "claim_boundary",
        ), "local admin recovery evidence")
        _text(record.get("recovery_id"), "recovery_id")
        _text(record.get("authority"), "authority")
        source_hash, source_root, source_roots, counts = _decode_inventory(
            source_inventory, "SOURCE"
        )
        backup_hash, backup_root, backup_roots, backup_counts = _decode_inventory(
            backup_inventory, "BACKUP_ARCHIVE"
        )
        restored_hash, restored_root, restored_roots, restored_counts = _decode_inventory(
            restored_inventory, "RESTORED_EMPTY_TARGET"
        )
        manifest = _object(backup_manifest, "backup manifest")
        if manifest.get("format") != "crg-local-backup-v1":
            raise _DecodeError("backup manifest uses an unsupported profile")
        actual_archive_hash = _archive_hash(archive_bytes)
        exact_bindings = (
            record.get("source_inventory_hash") == source_hash
            and record.get("backup_inventory_hash") == backup_hash
            and record.get("restored_inventory_hash") == restored_hash
            and record.get("source_inventory_root") == source_root
            and record.get("backup_inventory_root") == backup_root
            and record.get("restored_inventory_root") == restored_root
            and record.get("typed_roots") == source_roots
            and record.get("matched_typed_roots") == list(_ROOT_FIELDS)
            and record.get("archive_sha256") == actual_archive_hash
            and record.get("backup_manifest_hash") == _preflight(manifest, "backup manifest")
            and record.get("restore_target_precondition") == "VERIFIED_ABSENT_OR_EMPTY"
            and record.get("integrity_status") == "TYPED_CANONICAL_ROOTS_MATCH"
            and record.get("claim_boundary") == _CLAIM_BOUNDARY
        )
        typed_match = (
            source_roots == backup_roots == restored_roots
            and source_root == backup_root == restored_root
            and counts == backup_counts == restored_counts
        )
        artifact_root = _preflight(record, "local admin recovery evidence")
    except _UnsupportedProfile as error:
        result.status = Status.UNSUPPORTED_PROFILE
        result.record("local_recovery_profile", False, str(error))
        return result.finish()
    except (_DecodeError, CanonicalError, KeyError, TypeError, ValueError) as error:
        result.record("local_recovery_decode", False, str(error))
        return result.finish()
    result.record(
        "local_recovery_profile", True,
        f"{LOCAL_ADMIN_RECOVERY_PROFILE} schema {LOCAL_ADMIN_RECOVERY_SCHEMA_VERSION}",
    )
    result.record(
        "local_recovery_typed_roots", typed_match,
        "case, dependency, audit, active/superseded certificate, and object roots independently match",
    )
    result.record(
        "local_recovery_exact_bindings", exact_bindings,
        "evidence binds all three inventories, the manifest, archive bytes, and empty-target precondition",
    )
    no_overclaim = not (
        {"rpo", "rto", "pitr", "failover", "availability_slo", "provider_dr"}
        & set(record)
    )
    result.record(
        "local_recovery_claim_boundary", no_overclaim,
        "record is limited to the observed local logical recovery drill",
    )
    result.report.update({
        "record_type": "LocalAdminRecoveryEvidence",
        "claim_type": "LOCAL_LOGICAL_BACKUP_RESTORE_TYPED_ROOT_EQUALITY",
        "artifact_root": artifact_root,
        "typed_roots": dict(source_roots),
        "counts": counts,
        "claim_scope": "OBSERVED_LOCAL_ADMIN_DRILL_ONLY",
        "first_release_attribution": "v1.4/DECISION_LIFECYCLE",
    })
    if not result.violations:
        result.status = Status.VERIFIED
    return result.finish()
