"""Independent verification of portable non-mutating Decision Challenges.

This module is the standard-library-only verification zone for
``crg-decision-challenge/registered-preview@1``.  It imports no producer or
model package.  It validates the closed challenge-input registry, replays the
existing independent phase and certified-delta verifiers from their embedded
portable inputs, and reconstructs the displayed outcome.  A challenge never
authorizes or mutates a case; verification establishes only the integrity of
the non-authorizing preview or refusal record.
"""
from __future__ import annotations

from fractions import Fraction
from typing import Any, Dict, Mapping, Sequence, Set, Tuple

from .canonical import CanonicalError, content_hash, hash_without, is_hash
from .certificate import Status, VerificationResult
from .phase_delta import verify_certified_delta_record, verify_phase_analysis_record

__all__ = ["verify_decision_challenge_record"]

SCHEMA_VERSION = "1.2.0"
PROFILE = "crg-decision-challenge/registered-preview@1"
VERIFICATION_PROGRAM = "crg-verify.decision-challenge/v1"
AUTHORITY = "NON_AUTHORIZING"
CLAIM_BOUNDARY = (
    "A Decision Challenge is a non-mutating preview over registered inputs and "
    "independently replayable evidence. It cannot authorize, mutate, promote, "
    "supersede, or replace the active case."
)

_MUTATION_PROFILES: Dict[str, Tuple[str, Tuple[str, ...]]] = {
    "OBJECTIVE": ("crg-challenge-input/objective@1", ("objective",)),
    "PRICE": ("crg-challenge-input/price@1", ("value", "unit")),
    "TECHNOLOGY_COORDINATE": (
        "crg-challenge-input/technology-coordinate@1",
        ("coordinate_id", "value", "unit"),
    ),
    "EVIDENCE_VALUE": (
        "crg-challenge-input/evidence-value@1",
        ("evidence_id", "value", "evidence_class"),
    ),
    "EVIDENCE_VALIDITY": (
        "crg-challenge-input/evidence-validity@1",
        ("evidence_id", "validity"),
    ),
    "CAPABILITY": (
        "crg-challenge-input/capability@1",
        ("capability_id", "value"),
    ),
    "LEGALITY": (
        "crg-challenge-input/legality@1",
        ("realization_id", "legality"),
    ),
    "POLICY_TOLERANCE": (
        "crg-challenge-input/policy-tolerance@1",
        ("value",),
    ),
    "RETENTION_POLICY": (
        "crg-challenge-input/retention-policy@1",
        ("policy_id", "policy"),
    ),
    "PHYSICAL_CONSTRAINT": (
        "crg-challenge-input/physical-constraint@1",
        ("constraint_id", "value", "unit"),
    ),
}

_PREVIEWS = frozenset(
    {
        "BRANCH_PREVIEW",
        "PHASE_PREVIEW",
        "CHANGE_PREVIEW",
        "COMMITMENT_PREVIEW",
        "VERIFIER_REPLAY",
        "PHASE_AND_CHANGE_PREVIEW",
    }
)

_PROMOTIONS = frozenset(
    {
        "APPLY_CERTIFIED_CHANGE",
        "CREATE_GOVERNED_BRANCH",
        "SUBMIT_CHANGE_FOR_APPROVAL",
    }
)

_REFUSAL_REASONS = frozenset(
    {
        "UNREGISTERED_MUTATION",
        "MISSING_VERIFIER_EVIDENCE",
        "UNKNOWN_OR_INCOMPLETE_INPUT",
        "CHANGED_BASELINE_ROOT",
        "UNSUPPORTED_PROFILE",
        "VERIFICATION_FAILED",
        "UNKNOWN_CHANGE_SEMANTICS",
        "UNKNOWN_PROOF_SEMANTICS",
        "CALLER_DERIVED_FACTS_REFUSED",
    }
)

_EXACT_VALUE_MUTATIONS = frozenset(
    {
        "PRICE",
        "TECHNOLOGY_COORDINATE",
        "POLICY_TOLERANCE",
        "PHYSICAL_CONSTRAINT",
    }
)

_TOP_FIELDS = (
    "record_type",
    "schema_version",
    "profile",
    "challenge_id",
    "authority",
    "authorizing",
    "semantic_effect",
    "claim_boundary",
    "baseline",
    "operations",
    "evidence",
    "result",
    "refusal",
    "no_mutation_guarantee",
    "promotion_request",
    "verification_program",
    "record_hash",
)

_DELTA_INPUT_FIELDS = (
    "current_case",
    "dependency_edges",
    "replacements",
    "prior_phase",
    "current_phase",
    "prior_phase_source_r",
    "current_phase_source_r",
)


class _DecodeError(ValueError):
    pass


def _object(value: Any, field: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise _DecodeError(f"{field} must be an object")
    return value


def _array(value: Any, field: str) -> Sequence[Any]:
    if not isinstance(value, (list, tuple)):
        raise _DecodeError(f"{field} must be an array")
    return value


def _identity(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value or value != value.strip():
        raise _DecodeError(f"{field} must be a normalized non-empty string")
    return value


def _keys(value: Mapping[str, Any], expected: Sequence[str], field: str) -> None:
    expected_set = set(expected)
    missing = expected_set - set(value)
    unknown = set(value) - expected_set
    if missing:
        raise _DecodeError(f"{field} is missing fields {sorted(missing)}")
    if unknown:
        raise _DecodeError(f"{field} has unsupported fields {sorted(unknown)}")


def _sealed(value: Mapping[str, Any], field: str, where: str) -> None:
    stated = value.get(field)
    if not is_hash(stated):
        raise _DecodeError(f"{where}.{field} is not a portable SHA-256 hash")
    actual = hash_without(dict(value), field)
    if stated != actual:
        raise _DecodeError(f"{where}.{field} does not match independent canonical hashing")


def _exact(value: Any, field: str, *, nonnegative: bool = False) -> Fraction:
    if isinstance(value, Mapping):
        item = value
        if set(item) != {"exact"} or not isinstance(item.get("exact"), str):
            raise _DecodeError(
                f"{field} must be an integer, rational string, or exact-rational object"
            )
        text = item["exact"]
    elif isinstance(value, str):
        item = None
        text = value
    elif isinstance(value, int) and not isinstance(value, bool):
        item = None
        text = str(value)
    else:
        raise _DecodeError(
            f"{field} must be an integer, rational string, or exact-rational object"
        )
    try:
        result = Fraction(text)
    except (ValueError, ZeroDivisionError) as error:
        raise _DecodeError(f"{field} is not an exact rational") from error
    canonical = (
        str(result.numerator)
        if result.denominator == 1
        else f"{result.numerator}/{result.denominator}"
    )
    if text != canonical:
        raise _DecodeError(f"{field} is not a reduced canonical rational")
    if nonnegative and result < 0:
        raise _DecodeError(f"{field} must be nonnegative")
    return result


def _verification_result(value: Any, field: str, expected_status: str) -> Mapping[str, Any]:
    record = _object(value, field)
    _keys(record, ("ok", "status", "checks", "violations", "warnings", "report"), field)
    if record.get("ok") is not True or record.get("status") != expected_status:
        raise _DecodeError(f"{field} does not carry the required successful status")
    checks = _array(record.get("checks"), f"{field}.checks")
    if not checks:
        raise _DecodeError(f"{field}.checks is empty")
    for index, raw in enumerate(checks):
        check = _object(raw, f"{field}.checks[{index}]")
        _keys(check, ("check", "passed", "detail"), f"{field}.checks[{index}]")
        _identity(check.get("check"), f"{field}.checks[{index}].check")
        _identity(check.get("detail"), f"{field}.checks[{index}].detail")
        if check.get("passed") is not True:
            raise _DecodeError(f"{field} contains a failed check")
    if record.get("violations") != []:
        raise _DecodeError(f"{field} contains verifier violations")
    _array(record.get("warnings"), f"{field}.warnings")
    _object(record.get("report"), f"{field}.report")
    return record


def _payload(mutation_type: str, value: Any, field: str) -> Mapping[str, Any]:
    payload = _object(value, field)
    required = _MUTATION_PROFILES[mutation_type][1]
    _keys(payload, required, field)
    for name in required:
        if name in {"value", "objective"}:
            continue
        _identity(payload.get(name), f"{field}.{name}")
    if mutation_type in _EXACT_VALUE_MUTATIONS:
        _exact(
            payload.get("value"),
            f"{field}.value",
            nonnegative=mutation_type == "POLICY_TOLERANCE",
        )
    if mutation_type == "OBJECTIVE":
        _object(payload.get("objective"), f"{field}.objective")
    if mutation_type == "LEGALITY" and payload.get("legality") not in {"LEGAL", "ILLEGAL"}:
        raise _DecodeError(f"{field}.legality has unknown semantics")
    if mutation_type == "EVIDENCE_VALIDITY" and payload.get("validity") not in {
        "VALID", "INVALID", "EXPIRED", "REVOKED"
    }:
        raise _DecodeError(f"{field}.validity has unknown semantics")
    return payload


def _operations(value: Any) -> Tuple[list, Set[str]]:
    raw_operations = _array(value, "challenge.operations")
    if not raw_operations:
        raise _DecodeError("successful challenge has no registered operations")
    operations, identities, targets = [], set(), set()
    for index, raw in enumerate(raw_operations):
        operation = _object(raw, f"challenge.operations[{index}]")
        _keys(
            operation,
            (
                "operation_id",
                "sequence",
                "mutation_type",
                "input_profile",
                "preview_operation",
                "target_path",
                "input",
                "input_root",
                "authority",
                "authorizing",
                "semantic_effect",
                "mutation_performed",
                "operation_hash",
            ),
            f"challenge.operations[{index}]",
        )
        identifier = _identity(
            operation.get("operation_id"), f"challenge.operations[{index}].operation_id"
        )
        if identifier in identities:
            raise _DecodeError("challenge operation identities are not unique")
        identities.add(identifier)
        if operation.get("sequence") != index + 1:
            raise _DecodeError("challenge operations are not in canonical declared order")
        mutation_type = _identity(
            operation.get("mutation_type"), f"challenge.operations[{index}].mutation_type"
        )
        if mutation_type not in _MUTATION_PROFILES:
            raise _DecodeError(f"unregistered challenge mutation {mutation_type!r}")
        profile = _MUTATION_PROFILES[mutation_type][0]
        if operation.get("input_profile") != profile:
            raise _DecodeError(f"unregistered input profile for {mutation_type}")
        if operation.get("preview_operation") not in _PREVIEWS:
            raise _DecodeError("challenge uses an unregistered preview operation")
        target = _identity(
            operation.get("target_path"), f"challenge.operations[{index}].target_path"
        )
        if target in targets:
            raise _DecodeError("challenge target paths are not unique")
        targets.add(target)
        payload = _payload(mutation_type, operation.get("input"), f"operation {identifier}.input")
        if operation.get("input_root") != content_hash(payload):
            raise _DecodeError(f"operation {identifier!r} has a forged input root")
        if (
            operation.get("authority") != AUTHORITY
            or operation.get("authorizing") is not False
            or operation.get("semantic_effect") != "NONE"
            or operation.get("mutation_performed") is not False
        ):
            raise _DecodeError(f"operation {identifier!r} claims authority or mutation")
        _sealed(operation, "operation_hash", f"operation {identifier}")
        operations.append(dict(operation))
    return operations, targets


def _phase_evidence(value: Any) -> Tuple[dict, dict]:
    phase = _object(value, "challenge.evidence.phase")
    _keys(
        phase,
        (
            "artifact",
            "artifact_root",
            "source_r",
            "source_r_root",
            "verification_result",
            "verification_result_root",
        ),
        "challenge.evidence.phase",
    )
    artifact = _object(phase.get("artifact"), "challenge.evidence.phase.artifact")
    source = _object(phase.get("source_r"), "challenge.evidence.phase.source_r")
    if phase.get("artifact_root") != content_hash(artifact):
        raise _DecodeError("challenge phase artifact root does not match its content")
    if phase.get("source_r_root") != content_hash(source):
        raise _DecodeError("challenge phase source root does not match its content")
    submitted = _verification_result(
        phase.get("verification_result"),
        "challenge.evidence.phase.verification_result",
        Status.VERIFIED_RELATIVE,
    )
    if phase.get("verification_result_root") != content_hash(submitted):
        raise _DecodeError("challenge phase verifier-result root does not match its content")
    actual_result = verify_phase_analysis_record(artifact, source)
    actual = actual_result.to_json()
    if not actual_result.ok or actual_result.status != Status.VERIFIED_RELATIVE:
        raise _DecodeError(
            "challenge phase evidence fails independent replay: "
            + "; ".join(actual_result.violations)
        )
    if dict(submitted) != actual:
        raise _DecodeError("caller-supplied phase verifier facts differ from independent replay")
    return dict(phase), actual


def _delta_evidence(
    value: Any,
    baseline_case: Mapping[str, Any],
    phase: Mapping[str, Any],
) -> Tuple[dict, dict]:
    delta = _object(value, "challenge.evidence.delta")
    _keys(
        delta,
        (
            "artifact",
            "artifact_root",
            "verification_inputs",
            "verification_input_roots",
            "verification_result",
            "verification_result_root",
        ),
        "challenge.evidence.delta",
    )
    artifact = _object(delta.get("artifact"), "challenge.evidence.delta.artifact")
    if delta.get("artifact_root") != content_hash(artifact):
        raise _DecodeError("challenge delta artifact root does not match its content")
    inputs = _object(delta.get("verification_inputs"), "challenge.evidence.delta.verification_inputs")
    _keys(inputs, _DELTA_INPUT_FIELDS, "challenge.evidence.delta.verification_inputs")
    roots = _object(
        delta.get("verification_input_roots"),
        "challenge.evidence.delta.verification_input_roots",
    )
    _keys(roots, _DELTA_INPUT_FIELDS, "challenge.evidence.delta.verification_input_roots")
    for field in _DELTA_INPUT_FIELDS:
        if roots.get(field) != content_hash(inputs.get(field)):
            raise _DecodeError(f"delta verification input {field!r} has a forged root")
    current_case = _object(inputs.get("current_case"), "delta current_case")
    edges = _array(inputs.get("dependency_edges"), "delta dependency_edges")
    replacements = _object(inputs.get("replacements"), "delta replacements")
    current_phase = _object(inputs.get("current_phase"), "delta current_phase")
    current_source = _object(inputs.get("current_phase_source_r"), "delta current_phase_source_r")
    if current_phase != phase["artifact"] or current_source != phase["source_r"]:
        raise _DecodeError("challenge phase and delta do not share the same current phase evidence")
    prior_phase = inputs.get("prior_phase")
    prior_source = inputs.get("prior_phase_source_r")
    if (prior_phase is None) != (prior_source is None):
        raise _DecodeError("prior phase evidence and source must be present or absent together")
    if prior_phase is not None:
        _object(prior_phase, "delta prior_phase")
        _object(prior_source, "delta prior_phase_source_r")
    submitted = _verification_result(
        delta.get("verification_result"),
        "challenge.evidence.delta.verification_result",
        Status.VERIFIED,
    )
    if delta.get("verification_result_root") != content_hash(submitted):
        raise _DecodeError("challenge delta verifier-result root does not match its content")
    actual_result = verify_certified_delta_record(
        artifact,
        baseline_case,
        current_case,
        edges,
        replacements=replacements,
        prior_phase=prior_phase,
        current_phase=current_phase,
        prior_phase_source_r=prior_source,
        current_phase_source_r=current_source,
    )
    actual = actual_result.to_json()
    if not actual_result.ok or actual_result.status != Status.VERIFIED:
        raise _DecodeError(
            "challenge delta evidence fails independent replay: "
            + "; ".join(actual_result.violations)
        )
    if dict(submitted) != actual:
        raise _DecodeError("caller-supplied delta verifier facts differ from independent replay")
    return dict(delta), actual


def _path_value(document: Any, path: str) -> Any:
    tokens = []
    index = 0
    while index < len(path):
        if path[index] == ".":
            index += 1
            continue
        if path[index] == "[":
            closing = path.find("]", index + 1)
            if closing < 0 or not path[index + 1 : closing].isdigit():
                raise _DecodeError(f"challenge target path {path!r} is malformed")
            tokens.append(int(path[index + 1 : closing]))
            index = closing + 1
            continue
        closing = index
        while closing < len(path) and path[closing] not in ".[":
            closing += 1
        token = path[index:closing]
        if not token:
            raise _DecodeError(f"challenge target path {path!r} is malformed")
        tokens.append(token)
        index = closing
    current = document
    for token in tokens:
        if isinstance(token, int):
            if not isinstance(current, (list, tuple)) or token >= len(current):
                raise _DecodeError(f"challenge target path {path!r} is absent")
            current = current[token]
        else:
            if not isinstance(current, Mapping) or token not in current:
                raise _DecodeError(f"challenge target path {path!r} is absent")
            current = current[token]
    return current


def _covers(target: str, changed_path: str) -> bool:
    return (
        changed_path == target
        or changed_path.startswith(target + ".")
        or changed_path.startswith(target + "[")
    )


def _operation_bindings(
    operations: Sequence[Mapping[str, Any]],
    targets: Set[str],
    delta: Mapping[str, Any],
) -> None:
    artifact = _object(delta.get("artifact"), "challenge delta artifact")
    fields = _array(artifact.get("changed_fields"), "certified delta.changed_fields")
    if not fields:
        raise _DecodeError("certified delta has no changed-field evidence")
    by_path = {}
    for index, raw in enumerate(fields):
        field = _object(raw, f"certified delta.changed_fields[{index}]")
        path = _identity(field.get("path"), f"certified delta.changed_fields[{index}].path")
        if path in by_path:
            raise _DecodeError("certified delta repeats a changed field")
        by_path[path] = field
    for path in by_path:
        covering = [operation for operation in operations if _covers(operation["target_path"], path)]
        if len(covering) != 1:
            raise _DecodeError(
                "registered challenge targets must cover every independently checked diff field exactly once"
            )
    current_case = _object(
        _object(delta.get("verification_inputs"), "challenge delta verification inputs").get(
            "current_case"
        ),
        "challenge delta current case",
    )
    value_key = {
        "OBJECTIVE": "objective",
        "EVIDENCE_VALIDITY": "validity",
        "LEGALITY": "legality",
        "RETENTION_POLICY": "policy",
    }
    for operation in operations:
        if operation["target_path"] not in targets:
            raise _DecodeError("challenge operation target registry is internally inconsistent")
        if not any(_covers(operation["target_path"], path) for path in by_path):
            raise _DecodeError(
                f"operation {operation['operation_id']!r} covers no independently checked diff field"
            )
        proposed = operation["input"][value_key.get(operation["mutation_type"], "value")]
        if proposed != _path_value(current_case, operation["target_path"]):
            raise _DecodeError(
                f"operation {operation['operation_id']!r} is not bound to its checked diff value"
            )


def _expected_result(phase: Mapping[str, Any], delta: Mapping[str, Any]) -> dict:
    phase_artifact = _object(phase.get("artifact"), "challenge phase artifact")
    stability = _object(phase_artifact.get("stability"), "challenge phase stability")
    winner_ids = list(_array(stability.get("winner_ids"), "challenge phase winner_ids"))
    if (
        any(not isinstance(item, str) or not item for item in winner_ids)
        or winner_ids != sorted(set(winner_ids))
    ):
        raise _DecodeError("challenge phase winner identities are not canonical")
    delta_artifact = _object(delta.get("artifact"), "challenge delta artifact")
    raw_delta = _object(delta_artifact.get("delta"), "challenge delta artifact.delta")
    minimum = _object(
        delta_artifact.get("minimum_recomputation_claim"),
        "challenge minimum-recomputation claim",
    )
    return {
        "status": "VERIFIED_PREVIEW",
        "verification_status": {
            "challenge": "INDEPENDENT_CHALLENGE_REPLAY_REQUIRED",
            "phase": phase["verification_result"]["status"],
            "delta": delta["verification_result"]["status"],
        },
        "winner_ids": winner_ids,
        "phase": {
            "analysis_id": phase_artifact.get("analysis_id"),
            "artifact_root": phase.get("artifact_root"),
            "state": stability.get("state"),
            "nearest_boundary_ids": stability.get("nearest_boundary_ids"),
        },
        "change": {
            "evidence_id": delta_artifact.get("evidence_id"),
            "artifact_root": delta.get("artifact_root"),
            "preserved_ids": raw_delta.get("preserved"),
            "invalidated_ids": raw_delta.get("invalidated"),
            "replacement_roots": delta_artifact.get("replacement_roots"),
        },
        "proposed_minimum_action": {
            "action": minimum.get("action"),
            "basis": minimum.get("basis"),
            "authority": AUTHORITY,
            "authorizing": False,
            "semantic_effect": "NONE",
        },
        "regret": {"status": "NOT_PRESENT_IN_PHASE_DELTA_PROFILE", "witnesses": []},
        "claim_scope": phase_artifact.get("claim_scope"),
        "family_completeness": phase_artifact.get("family_completeness"),
    }


def _no_mutation(value: Any, baseline_root: str) -> None:
    record = _object(value, "challenge.no_mutation_guarantee")
    expected = {
        "baseline_case_root": baseline_root,
        "mutation_performed": False,
        "active_case_mutated": False,
        "active_case_superseded": False,
        "promotion_executed": False,
    }
    if dict(record) != expected:
        raise _DecodeError("challenge claims mutation, supersession, or executed promotion")


def _promotion(value: Any, challenge_id: str, baseline_root: str) -> None:
    if value is None:
        return
    record = _object(value, "challenge.promotion_request")
    _keys(
        record,
        (
            "record_type",
            "request_id",
            "challenge_id",
            "baseline_case_root",
            "governed_operation",
            "requested_by",
            "reason",
            "status",
            "execution_status",
            "authority",
            "authorizing",
            "semantic_effect",
            "mutation_performed",
            "requires_explicit_governed_operation",
            "request_hash",
        ),
        "challenge.promotion_request",
    )
    for field in ("request_id", "requested_by", "reason"):
        _identity(record.get(field), f"challenge.promotion_request.{field}")
    if (
        record.get("record_type") != "GovernedPromotionRequest"
        or record.get("challenge_id") != challenge_id
        or record.get("baseline_case_root") != baseline_root
        or record.get("governed_operation") not in _PROMOTIONS
        or record.get("status") != "PROPOSED"
        or record.get("execution_status") != "NOT_EXECUTED"
        or record.get("authority") != AUTHORITY
        or record.get("authorizing") is not False
        or record.get("semantic_effect") != "NONE"
        or record.get("mutation_performed") is not False
        or record.get("requires_explicit_governed_operation") is not True
    ):
        raise _DecodeError("promotion request is not a non-authorizing unexecuted proposal")
    _sealed(record, "request_hash", "challenge.promotion_request")


def _refused_result(status: str) -> dict:
    return {
        "status": status,
        "verification_status": {
            "challenge": "REFUSED_BEFORE_PREVIEW",
            "phase": "NOT_ATTEMPTED",
            "delta": "NOT_ATTEMPTED",
        },
        "winner_ids": None,
        "phase": None,
        "change": None,
        "proposed_minimum_action": {
            "action": "REOPEN",
            "basis": "UNKNOWN_OR_UNVERIFIED_CHALLENGE_INPUT_FAILS_CLOSED",
            "authority": AUTHORITY,
            "authorizing": False,
            "semantic_effect": "NONE",
        },
        "regret": {"status": "NOT_EVALUATED", "witnesses": []},
        "claim_scope": None,
        "family_completeness": None,
    }


def _refusal(record: Mapping[str, Any], result: VerificationResult, baseline_root: str) -> VerificationResult:
    refusal = _object(record.get("refusal"), "challenge.refusal")
    _keys(
        refusal,
        (
            "status",
            "reason_code",
            "detail",
            "attempted_input",
            "attempted_input_root",
            "disposition",
            "refusal_hash",
        ),
        "challenge.refusal",
    )
    status = refusal.get("status")
    if status not in {"REFUSED", "UNKNOWN"}:
        raise _DecodeError("challenge refusal has an unknown status")
    if refusal.get("reason_code") not in _REFUSAL_REASONS:
        raise _DecodeError("challenge refusal has an unregistered reason")
    _identity(refusal.get("detail"), "challenge.refusal.detail")
    if refusal.get("attempted_input_root") != content_hash(refusal.get("attempted_input")):
        raise _DecodeError("challenge refusal attempted-input root is forged")
    if refusal.get("disposition") != "NO_PREVIEW_NO_MUTATION_REOPEN_OR_REFUSE":
        raise _DecodeError("challenge refusal claims an unsupported disposition")
    _sealed(refusal, "refusal_hash", "challenge.refusal")
    if record.get("operations") != []:
        raise _DecodeError("refused challenge processed operations")
    if record.get("evidence") != {"phase": None, "delta": None}:
        raise _DecodeError("refused challenge carries purported phase/delta evidence")
    if record.get("result") != _refused_result(status):
        raise _DecodeError("refused challenge result was strengthened beyond refusal")
    if record.get("promotion_request") is not None:
        raise _DecodeError("refused challenge carries a promotion proposal")
    if refusal.get("reason_code") == "UNREGISTERED_MUTATION":
        attempt = refusal.get("attempted_input")
        mutation = attempt.get("mutation_type") if isinstance(attempt, Mapping) else None
        if not isinstance(mutation, str) or mutation in _MUTATION_PROFILES:
            raise _DecodeError("UNREGISTERED_MUTATION refusal does not name an unknown mutation")
    _no_mutation(record.get("no_mutation_guarantee"), baseline_root)
    result.record("challenge_refusal", True, f"typed {status} record is intact and non-mutating")
    result.record("challenge_no_mutation", True, "no preview, supersession, or promotion occurred")
    result.status = Status.INTEGRITY_ONLY
    result.report.update(
        {
            "challenge_id": record.get("challenge_id"),
            "challenge_result_status": status,
            "refusal_reason": refusal.get("reason_code"),
            "authority": AUTHORITY,
            "semantic_effect": "NONE",
        }
    )
    return result.finish()


def verify_decision_challenge_record(record: Mapping[str, Any]) -> VerificationResult:
    """Independently replay one Decision Challenge or typed refusal record."""

    result = VerificationResult(ok=False, status=Status.FAILED)
    if not isinstance(record, Mapping):
        result.record("challenge_wire", False, "Decision Challenge must be a JSON object")
        return result.finish()
    if record.get("schema_version") != SCHEMA_VERSION or record.get("profile") != PROFILE:
        result.status = Status.UNSUPPORTED_PROFILE
        result.record(
            "challenge_profile",
            False,
            f"unsupported Decision Challenge profile {record.get('profile')!r} "
            f"schema {record.get('schema_version')!r}",
        )
        return result.finish()
    if record.get("verification_program") != VERIFICATION_PROGRAM:
        result.status = Status.UNSUPPORTED_PROFILE
        result.record(
            "challenge_profile",
            False,
            f"unregistered challenge verifier {record.get('verification_program')!r}",
        )
        return result.finish()
    try:
        _keys(record, _TOP_FIELDS, "challenge")
        content_hash(record)
        _sealed(record, "record_hash", "challenge")
        challenge_id = _identity(record.get("challenge_id"), "challenge.challenge_id")
        if (
            record.get("record_type") != "DecisionChallengeRecord"
            or record.get("authority") != AUTHORITY
            or record.get("authorizing") is not False
            or record.get("semantic_effect") != "NONE"
            or record.get("claim_boundary") != CLAIM_BOUNDARY
        ):
            raise _DecodeError("Decision Challenge claims authority or has an unknown boundary")
        baseline = _object(record.get("baseline"), "challenge.baseline")
        _keys(baseline, ("case", "case_root"), "challenge.baseline")
        baseline_case = _object(baseline.get("case"), "challenge.baseline.case")
        baseline_root = content_hash(baseline_case)
        if baseline.get("case_root") != baseline_root:
            raise _DecodeError("challenge baseline root does not match the embedded active case")
        result.record("challenge_profile", True, f"{PROFILE} schema {SCHEMA_VERSION}")
        result.record("challenge_record_hash", True, "record independently canonicalized and resealed")
        result.record("challenge_authority", True, "authority is NON_AUTHORIZING; semantic effect is NONE")
        result.record("challenge_baseline", True, "active-case baseline root independently recomputed")

        if record.get("refusal") is not None:
            return _refusal(record, result, baseline_root)

        operations, targets = _operations(record.get("operations"))
        evidence = _object(record.get("evidence"), "challenge.evidence")
        _keys(evidence, ("phase", "delta"), "challenge.evidence")
        phase, phase_verification = _phase_evidence(evidence.get("phase"))
        delta, delta_verification = _delta_evidence(
            evidence.get("delta"), baseline_case, phase
        )
        _operation_bindings(operations, targets, delta)
        expected = _expected_result(phase, delta)
        if record.get("result") != expected:
            raise _DecodeError("challenge result differs from independent phase/delta reconstruction")
        _no_mutation(record.get("no_mutation_guarantee"), baseline_root)
        _promotion(record.get("promotion_request"), challenge_id, baseline_root)
    except (CanonicalError, _DecodeError, TypeError, ValueError) as error:
        result.record("challenge_decode", False, str(error))
        return result.finish()

    result.record(
        "challenge_operations",
        True,
        f"{len(operations)} ordered registered inputs exactly cover the canonical preview diff",
    )
    result.record(
        "challenge_phase_replay",
        True,
        f"phase evidence independently replayed as {phase_verification['status']}",
    )
    result.record(
        "challenge_delta_replay",
        True,
        f"delta evidence independently replayed as {delta_verification['status']}",
    )
    result.record(
        "challenge_outcome",
        True,
        "winner, phase state, affected lifecycle, scope, completeness, and minimum action reconstructed",
    )
    result.record(
        "challenge_no_mutation",
        True,
        "record cannot mutate or supersede the active case and any promotion remains unexecuted",
    )
    result.status = Status.VERIFIED_RELATIVE
    result.report.update(
        {
            "challenge_id": record.get("challenge_id"),
            "challenge_result_status": "VERIFIED_PREVIEW",
            "baseline_case_root": baseline_root,
            "operation_count": len(operations),
            "phase_artifact_root": phase["artifact_root"],
            "delta_artifact_root": delta["artifact_root"],
            "proposed_minimum_action": record["result"]["proposed_minimum_action"]["action"],
            "authority": AUTHORITY,
            "semantic_effect": "NONE",
        }
    )
    return result.finish()
