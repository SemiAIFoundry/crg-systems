"""Independent verification of portable lifecycle resilience records.

This module uses only the Python standard library and :mod:`crg_verify`
primitives.  It does not import the producer, migration registry, CLI,
server, SDK, or Studio.  Registered transform descriptors and replay
semantics are reconstructed from the carried bytes and a closed verifier
vocabulary.
"""
from __future__ import annotations

from typing import Any, Callable, Dict, Iterable, List, Mapping, Optional, Sequence, Set, Tuple

from .canonical import CanonicalError, content_hash, is_hash
from .certificate import Status, VerificationResult

__all__ = [
    "LIFECYCLE_RESILIENCE_PROFILE",
    "LIFECYCLE_RESILIENCE_SCHEMA_VERSION",
    "migration_evidence_failures",
    "verify_lifecycle_replay_record",
    "verify_backup_restore_recovery_record",
    "verify_migration_reverification_record",
]

LIFECYCLE_RESILIENCE_PROFILE = "crg.lifecycle-resilience"
LIFECYCLE_RESILIENCE_SCHEMA_VERSION = "1.0.0"

_FIRST_RELEASE = {
    "ETQDecisionLoop": "v1.3/ETQ_LIFECYCLE",
    "ResultIngestionRecord": "v1.3/ETQ_LIFECYCLE",
    "SelectiveRevalidationRecord": "v1.3/ETQ_LIFECYCLE",
    "ReplacementRecord": "v1.3/ETQ_LIFECYCLE",
    "QualificationDisposition": "v1.3/ETQ_LIFECYCLE",
    "DecisionScopedConversion": "v1.4/DECISION_LIFECYCLE",
    "ConversionBindingImpact": "v1.4/DECISION_LIFECYCLE",
    "SignatureVerificationRecord": "v1.4/DECISION_LIFECYCLE",
    "ApprovalRecord": "v1.4/DECISION_LIFECYCLE",
    "ApprovalWithdrawal": "v1.4/DECISION_LIFECYCLE",
    "LifecycleAuthorization": "v1.4/DECISION_LIFECYCLE",
    "ContinuedValidityView": "v1.4/DECISION_LIFECYCLE",
    "LifecycleReplayRecord": "v1.4/DECISION_LIFECYCLE",
    "BackupRestoreRecoveryRecord": "v1.4/DECISION_LIFECYCLE",
    "MigrationReverificationRecord": "v1.4/DECISION_LIFECYCLE",
}

_REPLAY_BOUNDARY = (
    "deterministic replay of carried canonical lifecycle records only; not "
    "authorization, availability, point-in-time recovery, transition execution, "
    "physical signoff, or generic physical safety"
)
_RECOVERY_BOUNDARY = (
    "byte-exact portable logical backup/restore plus independent lifecycle replay "
    "only; not provider availability, PITR, failover, RPO/RTO, transition execution, "
    "physical signoff, or generic physical safety"
)
_MIGRATION_BOUNDARY = (
    "registered semantically-equivalent migration and independent replay of unchanged "
    "lifecycle bytes only; not certificate inheritance, substantive reissuance, "
    "authorization, transition execution, physical signoff, or generic physical safety"
)

_MIGRATION_CLASSES = {
    "SEMANTICALLY_EQUIVALENT", "SEMANTICALLY_WIDENING",
    "SEMANTICALLY_NARROWING", "SEMANTIC_CHANGE", "LOSSY", "UNVERIFIED",
}
_MIGRATION_PROOF_TYPE = "CRG_MIGRATION_CLASSIFICATION_PROOF_V1"
_MIGRATION_PROOF_VERIFIER = "crg-model:migration-classification-v1"
_MIGRATION_IDENTITY_ALGORITHM = "CANONICAL_IDENTITY_V1"
_MIGRATION_IDENTITY_CHECKS = (
    "SOURCE_VERSION_EQUALS_TARGET_VERSION",
    "ALGORITHM_IS_CANONICAL_IDENTITY_V1",
    "CANONICAL_INPUT_HASH_EQUALS_OUTPUT_HASH",
)
_SUPPORTED_MIGRATION_TRANSFORMS = {
    "crg-schema-0.2.0-identity-v1": (
        "sha256:94a7eb8116798e598d15d60c31585c0c04793e68e6c42672072716d7630a94ea"
    ),
}
_SUPPORTED_MIGRATION_REGISTRY_VERSION = (
    "sha256:34646ece1dfa72122f8809994d34f4667eff91661b5c01c256b79519b81797df"
)


class _DecodeError(ValueError):
    pass


class _UnsupportedProfile(_DecodeError):
    pass


def _object(value: Any, where: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise _DecodeError(f"{where} must be an object")
    return value


def _array(value: Any, where: str) -> Sequence[Any]:
    if not isinstance(value, (list, tuple)):
        raise _DecodeError(f"{where} must be an array")
    return value


def _text(value: Any, where: str) -> str:
    if not isinstance(value, str) or not value:
        raise _DecodeError(f"{where} must be a non-empty string")
    return value


def _hash(value: Any, where: str) -> str:
    if not is_hash(value):
        raise _DecodeError(f"{where} must be an algorithm-tagged SHA-256 hash")
    return str(value)


def _boolean(value: Any, where: str) -> bool:
    if not isinstance(value, bool):
        raise _DecodeError(f"{where} must be a boolean")
    return value


def _keys(
    value: Mapping[str, Any], required: Iterable[str], optional: Iterable[str], where: str
) -> None:
    required_set = set(required)
    allowed = required_set | set(optional)
    missing = required_set - set(value)
    unknown = set(value) - allowed
    if missing:
        raise _DecodeError(f"{where} is missing fields {sorted(missing)}")
    if unknown:
        raise _DecodeError(f"{where} has unsupported fields {sorted(unknown)}")


def _preflight(value: Any, where: str) -> str:
    try:
        return content_hash(value)
    except (CanonicalError, TypeError, ValueError) as error:
        raise _DecodeError(f"{where} is not canonically hashable: {error}") from error


def _profile(record: Mapping[str, Any], record_type: str) -> None:
    if record.get("schema_version") != LIFECYCLE_RESILIENCE_SCHEMA_VERSION:
        raise _UnsupportedProfile(
            f"unsupported {record_type} schema version {record.get('schema_version')!r}"
        )
    if record.get("profile") != LIFECYCLE_RESILIENCE_PROFILE:
        raise _UnsupportedProfile(
            f"unregistered {record_type} profile {record.get('profile')!r}"
        )
    if record.get("record_type") != record_type:
        raise _DecodeError(
            f"expected record_type {record_type!r}, found {record.get('record_type')!r}"
        )


def _run(
    record: Mapping[str, Any],
    record_type: str,
    checker: Callable[[], Tuple[List[Tuple[str, bool, str]], Dict[str, Any]]],
) -> VerificationResult:
    result = VerificationResult(ok=False, status=Status.FAILED)
    if not isinstance(record, Mapping):
        result.record("resilience_wire", False, f"{record_type} must be a JSON object")
        return result.finish()
    try:
        _profile(record, record_type)
        root = _preflight(record, record_type)
        checks, report = checker()
    except _UnsupportedProfile as error:
        result.status = Status.UNSUPPORTED_PROFILE
        result.record("resilience_profile", False, str(error))
        return result.finish()
    except (_DecodeError, CanonicalError, KeyError, TypeError, ValueError) as error:
        result.record("resilience_decode", False, str(error))
        return result.finish()
    result.record(
        "resilience_profile", True,
        f"{LIFECYCLE_RESILIENCE_PROFILE} schema {LIFECYCLE_RESILIENCE_SCHEMA_VERSION}",
    )
    for name, passed, detail in checks:
        result.record(name, passed, detail)
    result.report.update(
        {
            "record_type": record_type,
            "claim_type": record_type,
            "artifact_root": root,
            "first_release_attribution": "v1.4/DECISION_LIFECYCLE",
            **report,
        }
    )
    if not result.violations:
        result.status = Status.VERIFIED
    return result.finish()


def _step_state(
    sequence: int,
    prior_state_hash: str,
    record_type: str,
    record_hash: str,
    verification_input_hash: str,
    first_release_attribution: str,
) -> str:
    return content_hash(
        {
            "profile": "crg.lifecycle-replay-step@1",
            "sequence": sequence,
            "prior_state_hash": prior_state_hash,
            "record_type": record_type,
            "record_hash": record_hash,
            "verification_input_hash": verification_input_hash,
            "first_release_attribution": first_release_attribution,
        }
    )


def verify_lifecycle_replay_record(
    record: Mapping[str, Any],
    source_checkpoint: Any,
    records: Sequence[Mapping[str, Any]],
    verification_inputs: Sequence[Mapping[str, Any]],
    *,
    lifecycle_verifier: Optional[
        Callable[[Mapping[str, Any], Mapping[str, Any]], VerificationResult]
    ] = None,
) -> VerificationResult:
    """Replay every carried lifecycle record and its exact verifier envelope."""

    def check() -> Tuple[List[Tuple[str, bool, str]], Dict[str, Any]]:
        _keys(
            record,
            (
                "record_type", "profile", "schema_version", "replay_id",
                "source_checkpoint_hash", "entries", "final_state_hash",
                "replay_complete", "claim_boundary",
            ),
            (),
            "lifecycle replay record",
        )
        _text(record.get("replay_id"), "lifecycle replay.replay_id")
        checkpoint_root = _preflight(source_checkpoint, "replay source checkpoint")
        if record.get("source_checkpoint_hash") != checkpoint_root:
            raise _DecodeError("replay source checkpoint hash does not match")
        carried_records = _array(records, "replay records")
        carried_inputs = _array(verification_inputs, "replay verification inputs")
        entries = _array(record.get("entries"), "lifecycle replay.entries")
        if not entries or len(entries) != len(carried_records) or len(entries) != len(carried_inputs):
            raise _DecodeError(
                "replay entries, lifecycle records, and verifier inputs must be non-empty and one-to-one"
            )
        verifier = lifecycle_verifier
        if verifier is None:
            # Delayed import avoids a module cycle: the portable dispatcher
            # imports this verifier in order to dispatch resilience records.
            from .portable_lifecycle import verify_lifecycle_replay_envelope
            verifier = verify_lifecycle_replay_envelope

        prior = checkpoint_root
        seen: Set[Tuple[str, str]] = set()
        semantic_checks: List[Tuple[str, bool, str]] = []
        for offset, (raw_entry, raw_record, raw_inputs) in enumerate(
            zip(entries, carried_records, carried_inputs)
        ):
            sequence = offset + 1
            entry = _object(raw_entry, f"lifecycle replay.entries[{offset}]")
            _keys(
                entry,
                (
                    "sequence", "record_type", "record_hash", "verification_input_hash",
                    "first_release_attribution", "prior_state_hash", "replayed_state_hash",
                ),
                (),
                f"lifecycle replay.entries[{offset}]",
            )
            if isinstance(entry.get("sequence"), bool) or entry.get("sequence") != sequence:
                raise _DecodeError(f"replay entry {sequence} is reordered")
            document = _object(raw_record, f"replay record {sequence}")
            envelope = _object(raw_inputs, f"replay verification inputs {sequence}")
            record_type = _text(document.get("record_type"), f"replay record {sequence}.record_type")
            if record_type in {"LifecycleReplayRecord", "BackupRestoreRecoveryRecord"}:
                raise _DecodeError(f"nested {record_type} would make replay recursive")
            release = _FIRST_RELEASE.get(record_type)
            if release is None:
                raise _DecodeError(f"unregistered lifecycle record type {record_type!r}")
            record_root = _preflight(document, f"replay record {sequence}")
            input_root = _preflight(envelope, f"replay verification inputs {sequence}")
            identity = (record_root, input_root)
            if identity in seen:
                raise _DecodeError("deterministic replay repeats a record/input pair")
            seen.add(identity)
            expected_state = _step_state(
                sequence, prior, record_type, record_root, input_root, release
            )
            exact = (
                entry.get("record_type") == record_type
                and entry.get("record_hash") == record_root
                and entry.get("verification_input_hash") == input_root
                and entry.get("first_release_attribution") == release
                and entry.get("prior_state_hash") == prior
                and entry.get("replayed_state_hash") == expected_state
            )
            if not exact:
                raise _DecodeError(f"replay entry {sequence} does not bind its exact lifecycle pair")
            sub = verifier(document, envelope)
            semantic_checks.append(
                (
                    f"replay_semantic_{sequence}",
                    bool(sub.ok),
                    f"{record_type} independently replayed" if sub.ok else "; ".join(sub.violations),
                )
            )
            prior = expected_state
        derived = (
            record.get("final_state_hash") == prior
            and record.get("replay_complete") is True
            and record.get("claim_boundary") == _REPLAY_BOUNDARY
        )
        return semantic_checks + [
            (
                "deterministic_replay_chain", derived,
                "ordered lifecycle bytes, exact verifier inputs, release attribution, and final state independently reconstructed",
            ),
            (
                "replay_no_synthetic_or_physical_claim",
                not ({"score", "confidence", "readiness", "health", "physical_safety"} & set(record)),
                "record carries the narrow offline replay boundary only",
            ),
        ], {
            "entry_count": len(entries),
            "derived_final_state_hash": prior,
            "claim_scope": "RELATIVE_TO_CARRIED_LIFECYCLE_RECORDS_INPUTS_AND_SOURCE_CHECKPOINT",
        }

    return _run(record, "LifecycleReplayRecord", check)


def _snapshot(value: Any, where: str) -> Tuple[str, str, Tuple[str, ...]]:
    document = _object(value, where)
    _profile(document, "LifecyclePortableSnapshot")
    _keys(
        document,
        (
            "record_type", "profile", "schema_version", "snapshot_id", "objects",
            "inventory_root", "object_count",
        ),
        (),
        where,
    )
    _text(document.get("snapshot_id"), f"{where}.snapshot_id")
    objects = _array(document.get("objects"), f"{where}.objects")
    if not objects:
        raise _DecodeError(f"{where} has no protected objects")
    inventory = []
    hashes = []
    prior: Optional[str] = None
    for offset, raw in enumerate(objects):
        item = _object(raw, f"{where}.objects[{offset}]")
        _keys(item, ("object_id", "content_hash", "payload"), (), f"{where}.objects[{offset}]")
        object_id = _text(item.get("object_id"), f"{where}.objects[{offset}].object_id")
        if prior is not None and object_id <= prior:
            raise _DecodeError(f"{where} object identities repeat or are not sorted")
        prior = object_id
        payload_root = _preflight(item.get("payload"), f"{where} object {object_id}")
        if item.get("content_hash") != payload_root:
            raise _DecodeError(f"{where} object {object_id!r} has a forged content hash")
        inventory.append({"object_id": object_id, "content_hash": payload_root})
        hashes.append(payload_root)
    if document.get("inventory_root") != content_hash(inventory):
        raise _DecodeError(f"{where} inventory root does not match")
    if document.get("object_count") != len(objects):
        raise _DecodeError(f"{where} object count does not match")
    return _preflight(document, where), str(document["inventory_root"]), tuple(hashes)


def verify_backup_restore_recovery_record(
    record: Mapping[str, Any],
    source_snapshot: Mapping[str, Any],
    backup_snapshot: Mapping[str, Any],
    restored_snapshot: Mapping[str, Any],
    replay_record: Mapping[str, Any],
    replay_source_checkpoint: Any,
    replay_records: Sequence[Mapping[str, Any]],
    replay_verification_inputs: Sequence[Mapping[str, Any]],
) -> VerificationResult:
    """Verify byte-exact backup/restore and the required post-restore replay."""

    def check() -> Tuple[List[Tuple[str, bool, str]], Dict[str, Any]]:
        _keys(
            record,
            (
                "record_type", "profile", "schema_version", "recovery_id",
                "backup_profile", "source_snapshot_hash", "backup_snapshot_hash",
                "restored_snapshot_hash", "inventory_root", "protected_lifecycle_hashes",
                "replay_record_hash", "integrity_status", "semantic_replay_required",
                "authority", "claim_boundary",
            ),
            (),
            "backup/restore recovery record",
        )
        _text(record.get("recovery_id"), "recovery.recovery_id")
        _text(record.get("authority"), "recovery.authority")
        source_root, source_inventory, source_hashes = _snapshot(source_snapshot, "source snapshot")
        backup_root, backup_inventory, backup_hashes = _snapshot(backup_snapshot, "backup snapshot")
        restored_root, restored_inventory, restored_hashes = _snapshot(restored_snapshot, "restored snapshot")
        replay_doc = _object(replay_record, "recovery replay record")
        replay_result = verify_lifecycle_replay_record(
            replay_doc,
            replay_source_checkpoint,
            replay_records,
            replay_verification_inputs,
        )
        entries = _array(replay_doc.get("entries"), "recovery replay entries")
        protected = sorted(
            {
                _hash(item.get("record_hash"), "replay entry.record_hash")
                for item in (_object(raw, "replay entry") for raw in entries)
            }
            | {
                _hash(item.get("verification_input_hash"), "replay entry.verification_input_hash")
                for item in (_object(raw, "replay entry") for raw in entries)
            }
            | {
                _preflight(replay_doc, "recovery replay record"),
                _preflight(replay_source_checkpoint, "recovery replay source checkpoint"),
            }
        )
        byte_exact = (
            source_inventory == backup_inventory == restored_inventory
            and sorted(source_hashes) == sorted(backup_hashes) == sorted(restored_hashes)
            and set(protected).issubset(set(source_hashes))
        )
        bindings = (
            record.get("backup_profile") == "PORTABLE_CANONICAL_SNAPSHOT_V1"
            and record.get("source_snapshot_hash") == source_root
            and record.get("backup_snapshot_hash") == backup_root
            and record.get("restored_snapshot_hash") == restored_root
            and record.get("inventory_root") == source_inventory
            and record.get("protected_lifecycle_hashes") == protected
            and record.get("replay_record_hash") == _preflight(replay_doc, "recovery replay record")
            and record.get("integrity_status") == "BYTE_EXACT_INVENTORY_MATCH"
            and record.get("semantic_replay_required") is True
            and record.get("claim_boundary") == _RECOVERY_BOUNDARY
        )
        return [
            (
                "backup_restore_byte_exact", byte_exact and bindings,
                "source, backup, and restored logical inventories and every replay dependency are hash-identical",
            ),
            (
                "post_restore_semantic_replay", replay_result.ok,
                "restored lifecycle records independently replay" if replay_result.ok else "; ".join(replay_result.violations),
            ),
            (
                "recovery_claim_boundary",
                not ({"score", "confidence", "readiness", "health", "physical_safety", "rpo", "rto"} & set(record)),
                "logical recovery does not claim provider DR or generic physical safety",
            ),
        ], {
            "protected_lifecycle_count": len(protected),
            "restored_object_count": len(restored_hashes),
            "claim_scope": "PORTABLE_LOGICAL_SNAPSHOT_AND_CARRIED_SEMANTIC_REPLAY_ONLY",
        }

    return _run(record, "BackupRestoreRecoveryRecord", check)


def migration_evidence_failures(migration: Mapping[str, Any]) -> List[str]:
    """Independently verify the only registered migration algorithm in v1.4."""
    migration_id = migration.get("migration_id")
    prefix = f"migration {migration_id!r}"
    failures: List[str] = []
    required = (
        "migration_id", "source_schema_version", "target_schema_version",
        "migration_class", "source_object_hash", "target_object_hash",
        "transform_id", "transform_descriptor", "transform_hash",
        "migration_registry_descriptor", "migration_registry_version",
        "classification_proof", "classification_proof_hash", "classification_verified",
        "transform_input_hash", "transform_output_hash", "actor", "authority",
    )
    missing = [name for name in required if migration.get(name) in (None, "")]
    if missing:
        failures.append(f"{prefix} omits {missing}")
    if migration.get("record_type") != "MigrationRecord":
        failures.append(f"{prefix} has unsupported record_type")
    if migration.get("migration_class") not in _MIGRATION_CLASSES:
        failures.append(f"{prefix} has unknown semantic class")
    for name in (
        "source_object_hash", "target_object_hash", "transform_hash",
        "migration_registry_version", "classification_proof_hash",
        "transform_input_hash", "transform_output_hash",
    ):
        if not is_hash(migration.get(name)):
            failures.append(f"{prefix} has invalid {name}")

    descriptor = migration.get("transform_descriptor")
    registry = migration.get("migration_registry_descriptor")
    proof = migration.get("classification_proof")
    if not isinstance(descriptor, Mapping) or not isinstance(registry, Mapping) or not isinstance(proof, Mapping):
        failures.append(f"{prefix} has no independently checkable registry/transform/proof objects")
        return failures
    try:
        descriptor_hash = content_hash(descriptor)
        registry_hash = content_hash(registry)
        proof_hash = content_hash(proof)
    except (CanonicalError, TypeError, ValueError) as error:
        failures.append(f"{prefix} has noncanonical classification evidence: {error}")
        return failures
    if migration.get("transform_hash") != descriptor_hash:
        failures.append(f"{prefix} transform descriptor hash does not match")
    registered_hash = _SUPPORTED_MIGRATION_TRANSFORMS.get(str(descriptor.get("transform_id") or ""))
    if registered_hash is None or registered_hash != descriptor_hash:
        failures.append(f"{prefix} transform is not registered by this verifier release")
    if migration.get("migration_registry_version") != registry_hash:
        failures.append(f"{prefix} migration registry descriptor hash does not match")
    if migration.get("migration_registry_version") != _SUPPORTED_MIGRATION_REGISTRY_VERSION:
        failures.append(f"{prefix} migration registry version is not supported")
    registered = registry.get("transforms")
    if not isinstance(registered, list) or dict(descriptor) not in registered:
        failures.append(f"{prefix} transform is absent from its registry descriptor")
    if migration.get("classification_proof_hash") != proof_hash:
        failures.append(f"{prefix} classification proof hash does not match")
    if migration.get("transform_id") != descriptor.get("transform_id"):
        failures.append(f"{prefix} record and descriptor name different transforms")
    if proof.get("proof_type") != _MIGRATION_PROOF_TYPE:
        failures.append(f"{prefix} uses an unsupported classification proof type")
    if proof.get("verifier_id") != _MIGRATION_PROOF_VERIFIER:
        failures.append(f"{prefix} uses an unsupported classification proof verifier")
    if proof.get("transform_id") != descriptor.get("transform_id"):
        failures.append(f"{prefix} proof names a different transform")
    if proof.get("transform_hash") != descriptor_hash:
        failures.append(f"{prefix} proof is not bound to its transform descriptor")
    if proof.get("migration_class") != descriptor.get("migration_class"):
        failures.append(f"{prefix} proof and descriptor disagree on semantic class")
    if migration.get("migration_class") != descriptor.get("migration_class"):
        failures.append(f"{prefix} record and descriptor disagree on semantic class")
    if proof.get("basis") != descriptor.get("classification_basis"):
        failures.append(f"{prefix} proof and descriptor disagree on classification basis")
    if descriptor.get("algorithm") != _MIGRATION_IDENTITY_ALGORITHM:
        failures.append(f"{prefix} uses an unsupported migration algorithm")
    if descriptor.get("transform_type") != "CRG_SCHEMA_MIGRATION_TRANSFORM_V1":
        failures.append(f"{prefix} uses an unsupported transform descriptor type")
    if descriptor.get("algorithm_version") != "1":
        failures.append(f"{prefix} uses an unsupported migration algorithm version")
    if descriptor.get("source_schema_version") != migration.get("source_schema_version"):
        failures.append(f"{prefix} descriptor disagrees on source schema version")
    if descriptor.get("target_schema_version") != migration.get("target_schema_version"):
        failures.append(f"{prefix} descriptor disagrees on target schema version")
    if descriptor.get("source_schema_version") != descriptor.get("target_schema_version"):
        failures.append(f"{prefix} identity transform changes schema version")
    if descriptor.get("migration_class") != "SEMANTICALLY_EQUIVALENT":
        failures.append(f"{prefix} identity transform is not classified equivalent")
    if tuple(proof.get("checks") or ()) != _MIGRATION_IDENTITY_CHECKS:
        failures.append(f"{prefix} identity proof has incomplete or reordered checks")
    if migration.get("transform_input_hash") != migration.get("transform_output_hash"):
        failures.append(f"{prefix} identity transform input/output hashes differ")
    if migration.get("source_object_hash") != migration.get("transform_input_hash"):
        failures.append(f"{prefix} transform is not bound to the stated source object")
    if migration.get("classification_verified") is not True:
        failures.append(f"{prefix} classification is not recorded as verified")
    return failures


def verify_migration_reverification_record(
    record: Mapping[str, Any],
    migration_record: Mapping[str, Any],
    source_object: Any,
    transformed_object: Any,
    lifecycle_record: Mapping[str, Any],
    lifecycle_verification_inputs: Mapping[str, Any],
) -> VerificationResult:
    """Verify registered identity migration and unchanged lifecycle replay."""

    def check() -> Tuple[List[Tuple[str, bool, str]], Dict[str, Any]]:
        _keys(
            record,
            (
                "record_type", "profile", "schema_version", "reverification_id",
                "migration_record_hash", "source_object_hash", "transformed_object_hash",
                "transform_id", "transform_hash", "migration_class",
                "lifecycle_record_type", "lifecycle_record_hash",
                "lifecycle_verification_input_hash", "differential_validation",
                "disposition", "substantive_artifact_reissued", "authority",
                "claim_boundary",
            ),
            (),
            "migration re-verification record",
        )
        _text(record.get("reverification_id"), "migration re-verification.reverification_id")
        _text(record.get("authority"), "migration re-verification.authority")
        migration = _object(migration_record, "migration record")
        failures = migration_evidence_failures(migration)
        if failures:
            raise _DecodeError("; ".join(failures))
        source_root = _preflight(source_object, "migration source object")
        transformed_root = _preflight(transformed_object, "migration transformed object")
        document = _object(lifecycle_record, "reverified lifecycle record")
        envelope = _object(lifecycle_verification_inputs, "reverified lifecycle inputs")
        if document.get("record_type") in {
            "LifecycleReplayRecord",
            "BackupRestoreRecoveryRecord",
            "MigrationReverificationRecord",
        }:
            raise _DecodeError(
                "migration re-verification must terminate at a substantive lifecycle record"
            )
        from .portable_lifecycle import verify_lifecycle_replay_envelope
        replay = verify_lifecycle_replay_envelope(document, envelope)
        registered_equivalence = (
            migration.get("migration_class") == "SEMANTICALLY_EQUIVALENT"
            and migration.get("source_object_hash") == source_root
            and migration.get("transform_input_hash") == source_root
            and migration.get("transform_output_hash") == transformed_root
            and source_root == transformed_root
        )
        exact = (
            record.get("migration_record_hash") == _preflight(migration, "migration record")
            and record.get("source_object_hash") == source_root
            and record.get("transformed_object_hash") == transformed_root
            and record.get("transform_id") == migration.get("transform_id")
            and record.get("transform_hash") == migration.get("transform_hash")
            and record.get("migration_class") == "SEMANTICALLY_EQUIVALENT"
            and record.get("lifecycle_record_type") == document.get("record_type")
            and record.get("lifecycle_record_hash") == _preflight(document, "reverified lifecycle record")
            and record.get("lifecycle_verification_input_hash") == _preflight(envelope, "reverified lifecycle inputs")
            and record.get("differential_validation") == "CANONICAL_CONTENT_HASH_EQUALITY"
            and record.get("disposition") == "REVERIFIED_WITHOUT_REISSUANCE"
            and record.get("substantive_artifact_reissued") is False
            and record.get("claim_boundary") == _MIGRATION_BOUNDARY
        )
        return [
            (
                "registered_migration_equivalence", registered_equivalence,
                "registered transform, classification proof, source bytes, and transformed bytes independently match",
            ),
            (
                "post_migration_lifecycle_replay", replay.ok,
                "unchanged lifecycle artifact independently replays" if replay.ok else "; ".join(replay.violations),
            ),
            (
                "reverification_without_reissuance", exact,
                "re-verification is bound to unchanged bytes and explicitly does not reissue the substantive artifact",
            ),
            (
                "migration_claim_boundary",
                not ({"score", "confidence", "readiness", "health", "physical_safety"} & set(record)),
                "migration evidence does not imply authorization or generic physical safety",
            ),
        ], {
            "registered_transform_id": migration.get("transform_id"),
            "reverified_lifecycle_record_type": document.get("record_type"),
            "claim_scope": "REGISTERED_IDENTITY_MIGRATION_AND_UNCHANGED_LIFECYCLE_BYTES_ONLY",
        }

    return _run(record, "MigrationReverificationRecord", check)
