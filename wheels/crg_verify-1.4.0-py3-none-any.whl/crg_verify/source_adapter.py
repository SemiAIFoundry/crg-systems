"""Independent verification for the portable source-adapter contract.

The verifier is standard-library-only and imports no producer, IO, model,
server, or Studio package.  It reconstructs content bindings from the
caller-supplied original and normalized bytes, checks every embedded source
record, re-parses normalized row identities, and enforces the fixed
non-authorizing/relative-family boundary.

A conformance report is intentionally verified only as internally complete
evidence.  Re-executing an adapter implementation is outside a portable
report, so a structurally valid report receives ``INTEGRITY_ONLY`` rather
than an authorizing or semantic verification status.
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import re
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple

from .canonical import CanonicalError, canonical_bytes, content_hash, is_hash
from .certificate import Status, VerificationResult
from .intake import verify_registry_mapping_profile

__all__ = [
    "verify_source_adapter_definition",
    "verify_source_adapter_output",
    "verify_source_adapter_conformance_report",
]

SCHEMA_VERSION = "1.0.0"
CONTRACT_ID = "crg.source-adapter"
AUTHORITY = "NON_AUTHORIZING_TRANSLATION"
REPORT_AUTHORITY = "NON_AUTHORIZING_CONFORMANCE_EVIDENCE"
COMPLETENESS = "EXPLICIT_IMPORTED_FAMILY"
CLAIM_SCOPE = "RELATIVE_EXPLICIT_FAMILY"
CLAIM = (
    "A passing report establishes only that the adapter was observed under the "
    "stated execution profile and obeyed the source-translation contract on this "
    "fixture suite. It does not establish source-data truth or authorize a decision."
)
SOURCE_CLASSES = frozenset(
    {"COMPILER", "OPTIMIZER", "EDA", "SIMULATOR", "DATABASE", "LABORATORY", "GENERIC"}
)
CATEGORIES = frozenset(
    {"POSITIVE", "NEGATIVE", "BOUNDARY", "MALFORMED", "IDENTITY_PRESERVATION", "MALICIOUS"}
)
REQUIREMENTS = frozenset(
    {
        "VALID_SOURCE",
        "UNSUPPORTED_MEDIA_REFUSAL",
        "EXACT_BOUNDARY",
        "MALFORMED_SOURCE_REFUSAL",
        "IDENTITY_PRESERVATION",
        "REJECTED_ROW_PRESERVATION",
        "REMOTE_DEPENDENCY_REFUSAL",
        "BINARY_FLOAT_REFUSAL",
        "UNIT_PRESERVATION",
        "EVIDENCE_PRESERVATION",
    }
)
_SEMVER = re.compile(r"^[0-9]+\.[0-9]+\.[0-9]+(?:[-+][0-9A-Za-z.-]+)?$")
_JSON_LOCATOR = re.compile(r"(?:\.([A-Za-z_][A-Za-z0-9_-]*))|(?:\[([0-9]+)\])")
_REMOTE_PREFIXES = ("http://", "https://", "ftp://", "s3://", "gs://")


class _DecodeError(ValueError):
    pass


class _Unsupported(_DecodeError):
    pass


def _keys(value: Mapping[str, Any], required: Iterable[str], optional: Iterable[str], where: str) -> None:
    required_set = set(required)
    allowed = required_set | set(optional)
    missing = required_set - set(value)
    unknown = set(value) - allowed
    if missing:
        raise _DecodeError(f"{where} is missing fields {sorted(missing)}")
    if unknown:
        raise _DecodeError(f"{where} has unsupported fields {sorted(unknown)}")


def _object(value: Any, where: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise _DecodeError(f"{where} must be an object")
    return value


def _array(value: Any, where: str, *, nonempty: bool = False) -> Sequence[Any]:
    if not isinstance(value, (list, tuple)):
        raise _DecodeError(f"{where} must be an array")
    if nonempty and not value:
        raise _DecodeError(f"{where} must not be empty")
    return value


def _string(value: Any, where: str) -> str:
    if not isinstance(value, str) or not value.strip() or value != value.strip() or "\x00" in value:
        raise _DecodeError(f"{where} must be a normalized non-empty string")
    return value


def _integer(value: Any, where: str, *, minimum: int = 0) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise _DecodeError(f"{where} must be an integer at least {minimum}")
    return value


def _digest_bytes(value: bytes) -> str:
    return "sha256:" + hashlib.sha256(value).hexdigest()


def _contains_remote(value: Any) -> bool:
    if isinstance(value, str):
        return value.strip().lower().startswith(_REMOTE_PREFIXES)
    if isinstance(value, Mapping):
        return any(_contains_remote(item) for item in value.values())
    if isinstance(value, (list, tuple)):
        return any(_contains_remote(item) for item in value)
    return False


def _result(record_type: str, operation, *, integrity_only: bool = False) -> VerificationResult:
    result = VerificationResult(ok=False)
    try:
        checks, report = operation()
    except _Unsupported as error:
        result.record("supported_profile", False, str(error))
        result.status = Status.UNSUPPORTED_PROFILE
        result.report.update({"record_type": record_type, "authorization_effect": "NONE"})
        return result.finish()
    except (_DecodeError, CanonicalError, TypeError, ValueError, UnicodeDecodeError, json.JSONDecodeError, csv.Error) as error:
        result.record("source_adapter_record", False, str(error))
        result.status = Status.FAILED
        result.report.update({"record_type": record_type, "authorization_effect": "NONE"})
        return result.finish()
    for name, passed, detail in checks:
        result.record(name, passed, detail)
    result.status = Status.INTEGRITY_ONLY if integrity_only and not result.violations else (
        Status.VERIFIED_RELATIVE if not result.violations else Status.FAILED
    )
    result.report.update(
        {
            "record_type": record_type,
            "authorization_effect": "NONE",
            "semantic_effect": "NONE",
            "claim_scope": CLAIM_SCOPE,
            **report,
        }
    )
    return result.finish()


_DEFINITION_FIELDS = {
    "record_type", "schema_version", "contract_id", "contract_version", "adapter_id",
    "adapter_version", "extension_type", "source_system_class", "implementation_identity",
    "input_media_types", "output_source_format", "execution_profile", "determinism_status",
    "failure_modes", "semantic_scope", "authority",
}


def _definition(record: Mapping[str, Any]) -> Tuple[Dict[str, Any], List[Tuple[str, bool, str]]]:
    _keys(record, _DEFINITION_FIELDS, set(), "source-adapter definition")
    if record.get("record_type") != "SourceAdapterDefinition":
        raise _DecodeError("definition record_type is unsupported")
    if record.get("schema_version") != SCHEMA_VERSION or record.get("contract_version") != SCHEMA_VERSION:
        raise _Unsupported("unsupported source-adapter definition version")
    if record.get("contract_id") != CONTRACT_ID:
        raise _Unsupported("unsupported source-adapter contract_id")
    if record.get("extension_type") != "SOURCE_ADAPTER":
        raise _DecodeError("definition extension_type must be SOURCE_ADAPTER")
    if record.get("authority") != AUTHORITY:
        raise _DecodeError("definition attempts to strengthen adapter authority")
    if record.get("determinism_status") != "DETERMINISTIC":
        raise _DecodeError("portable source adapters must declare DETERMINISTIC")
    if record.get("source_system_class") not in SOURCE_CLASSES:
        raise _DecodeError("definition source_system_class is unsupported")
    for name in ("adapter_id", "semantic_scope"):
        _string(record.get(name), f"definition {name}")
    version = _string(record.get("adapter_version"), "definition adapter_version")
    if not _SEMVER.fullmatch(version):
        raise _DecodeError("adapter_version is not semantic-version syntax")
    if not is_hash(record.get("implementation_identity")):
        raise _DecodeError("implementation_identity is not a SHA-256 content hash")
    media = [_string(item, "input_media_types item") for item in _array(record.get("input_media_types"), "input_media_types", nonempty=True)]
    failures = [_string(item, "failure_modes item") for item in _array(record.get("failure_modes"), "failure_modes", nonempty=True)]
    if len(media) != len(set(media)) or len(failures) != len(set(failures)):
        raise _DecodeError("definition media types or failure modes contain duplicates")
    if record.get("output_source_format") not in {"csv", "json"}:
        raise _DecodeError("definition output_source_format is unsupported")
    if record.get("execution_profile") not in {"REVIEWED_IN_PROCESS", "SANDBOXED_PROCESS"}:
        raise _DecodeError("definition execution_profile is unsupported")
    if _contains_remote(record):
        raise _DecodeError("definition contains an originating-server locator")
    return dict(record), [
        ("fixed_non_authorizing_contract", True, "definition uses the registered deterministic translation boundary"),
        ("content_addressed_implementation", True, "adapter implementation identity is content-addressed"),
        ("server_independence", True, "definition contains no originating-server locator"),
    ]


def verify_source_adapter_definition(record: Mapping[str, Any]) -> VerificationResult:
    def operation():
        decoded, checks = _definition(_object(record, "source-adapter definition"))
        return checks, {"definition_hash": content_hash(decoded)}
    return _result("SourceAdapterDefinition", operation)


def _decode_json_bytes(value: bytes, where: str) -> Any:
    def refuse_float(token: str) -> Any:
        raise _DecodeError(f"{where} contains bare JSON float {token!r}")
    return json.loads(value.decode("utf-8-sig"), parse_float=refuse_float,
                      parse_constant=lambda token: (_ for _ in ()).throw(_DecodeError(f"{where} contains {token}")))


def _resolve_json_locator(document: Any, locator: str) -> Any:
    if not locator.startswith("$"):
        raise _DecodeError(f"unsupported source locator {locator!r}")
    cursor = 1
    current = document
    while cursor < len(locator):
        match = _JSON_LOCATOR.match(locator, cursor)
        if match is None:
            raise _DecodeError(f"unsupported source locator {locator!r}")
        key, index = match.groups()
        if key is not None:
            if not isinstance(current, Mapping) or key not in current:
                raise _DecodeError(f"source locator {locator!r} does not resolve")
            current = current[key]
        else:
            item_index = int(index)
            if not isinstance(current, list) or item_index >= len(current):
                raise _DecodeError(f"source locator {locator!r} does not resolve")
            current = current[item_index]
        cursor = match.end()
    return current


def _mapping_rows(normalized: bytes, profile: Mapping[str, Any]) -> Dict[int, Any]:
    source_format = profile.get("source_format")
    identity_field = _string(profile.get("identity_field"), "mapping identity_field")
    if source_format == "csv":
        text = normalized.decode("utf-8-sig")
        rows = list(csv.reader(io.StringIO(text), strict=True))
        if not rows:
            raise _DecodeError("normalized CSV has no header")
        header = rows[0]
        if len(header) != len(set(header)) or identity_field not in header:
            raise _DecodeError("normalized CSV header is duplicate or lacks the identity field")
        identity_index = header.index(identity_field)
        result: Dict[int, Any] = {}
        for row_number, row in enumerate(rows[1:], start=2):
            if len(row) != len(header):
                result[row_number] = None
            else:
                identity = row[identity_index].strip()
                result[row_number] = identity or None
        return result
    if source_format != "json":
        raise _DecodeError("normalized source format is unsupported")
    document = _decode_json_bytes(normalized, "normalized JSON")
    path = profile.get("record_path")
    if path == "$":
        records = document
    else:
        records = document
        for segment in _string(path, "mapping record_path").split("."):
            if not isinstance(records, Mapping) or segment not in records:
                raise _DecodeError("normalized JSON record_path does not resolve")
            records = records[segment]
    if not isinstance(records, list):
        raise _DecodeError("normalized JSON record_path must resolve to a list")
    result = {}
    for row_number, row in enumerate(records, start=1):
        if not isinstance(row, Mapping):
            result[row_number] = None
            continue
        current: Any = row
        for segment in identity_field.split("."):
            if not isinstance(current, Mapping) or segment not in current:
                current = None
                break
            current = current[segment]
        if isinstance(current, bool) or not isinstance(current, (str, int)):
            result[row_number] = None
        else:
            identity = str(current).strip()
            result[row_number] = identity or None
    return result


def verify_source_adapter_output(
    record: Mapping[str, Any],
    definition: Mapping[str, Any],
    *,
    original_source: bytes,
    normalized_source: bytes,
) -> VerificationResult:
    """Reconstruct a portable adapter output from the exact bound bytes."""
    def operation():
        if not isinstance(original_source, bytes) or not isinstance(normalized_source, bytes):
            raise _DecodeError("original_source and normalized_source must be immutable bytes")
        decoded_definition, definition_checks = _definition(_object(definition, "source-adapter definition"))
        value = _object(record, "source-adapter output")
        required = {
            "record_type", "schema_version", "authority", "mutation_performed", "definition_hash",
            "input_snapshot", "input_snapshot_hash", "normalized_source", "mapping_profile",
            "mapping_profile_hash", "identity_bindings", "portable_references", "completeness_basis",
            "claim_scope",
        }
        _keys(value, required, set(), "source-adapter output")
        if value.get("record_type") != "SourceAdapterOutput":
            raise _DecodeError("output record_type is unsupported")
        if value.get("schema_version") != SCHEMA_VERSION:
            raise _Unsupported("unsupported SourceAdapterOutput schema_version")
        if value.get("authority") != AUTHORITY or value.get("mutation_performed") is not False:
            raise _DecodeError("output attempts to authorize or mutate a CRG case")
        if value.get("completeness_basis") != COMPLETENESS or value.get("claim_scope") != CLAIM_SCOPE:
            raise _DecodeError("output strengthens completeness or claim scope")
        if value.get("definition_hash") != content_hash(decoded_definition):
            raise _DecodeError("definition_hash does not bind the supplied definition")
        if _contains_remote(value):
            raise _DecodeError("output contains an originating-server locator")

        snapshot = _object(value.get("input_snapshot"), "input_snapshot")
        _keys(snapshot, {"provenance", "media_type", "content_hash", "byte_length"}, set(), "input_snapshot")
        provenance = _object(snapshot.get("provenance"), "input_snapshot provenance")
        _keys(provenance, {"source_id", "source_name", "origin"}, {"producer", "source_version"}, "input_snapshot provenance")
        for name, item in provenance.items():
            _string(item, f"input_snapshot provenance {name}")
        media_type = _string(snapshot.get("media_type"), "input_snapshot media_type")
        if media_type not in decoded_definition["input_media_types"]:
            raise _DecodeError("input media type is outside the adapter declaration")
        if snapshot.get("content_hash") != _digest_bytes(original_source):
            raise _DecodeError("input snapshot content hash does not bind original_source")
        if _integer(snapshot.get("byte_length"), "input snapshot byte_length") != len(original_source):
            raise _DecodeError("input snapshot byte length does not bind original_source")
        if value.get("input_snapshot_hash") != content_hash(dict(snapshot)):
            raise _DecodeError("input_snapshot_hash does not bind input_snapshot")

        normalized = _object(value.get("normalized_source"), "normalized_source")
        _keys(normalized, {"source_format", "content_hash", "byte_length"}, set(), "normalized_source")
        if normalized.get("source_format") != decoded_definition["output_source_format"]:
            raise _DecodeError("normalized source format differs from adapter declaration")
        if normalized.get("content_hash") != _digest_bytes(normalized_source):
            raise _DecodeError("normalized source hash does not bind normalized_source bytes")
        if _integer(normalized.get("byte_length"), "normalized source byte_length") != len(normalized_source):
            raise _DecodeError("normalized source byte length does not bind normalized_source")

        profile = _object(value.get("mapping_profile"), "mapping_profile")
        profile_result = verify_registry_mapping_profile(profile)
        if not profile_result.ok:
            raise _DecodeError("mapping_profile failed independent verification: " + "; ".join(profile_result.violations))
        if profile.get("source_format") != normalized.get("source_format"):
            raise _DecodeError("mapping profile and normalized source formats disagree")
        if profile.get("default_evidence_class") != "IMPORTED":
            raise _DecodeError("adapter default evidence class must remain IMPORTED")
        profile_hash = content_hash(dict(profile))
        if value.get("mapping_profile_hash") != profile_hash:
            raise _DecodeError("mapping_profile_hash does not bind mapping_profile")

        rows = _mapping_rows(normalized_source, profile)
        bindings = _array(value.get("identity_bindings"), "identity_bindings", nonempty=True)
        by_row: Dict[int, Mapping[str, Any]] = {}
        parsed_original = None
        if "json" in media_type.lower():
            parsed_original = _decode_json_bytes(original_source, "original source")
        for index, raw in enumerate(bindings):
            binding = _object(raw, f"identity_bindings[{index}]")
            _keys(binding, {"source_locator", "source_record", "source_record_hash", "normalized_row_number"}, {"normalized_identity"}, f"identity_bindings[{index}]")
            locator = _string(binding.get("source_locator"), f"identity_bindings[{index}].source_locator")
            row_number = _integer(binding.get("normalized_row_number"), f"identity_bindings[{index}].normalized_row_number", minimum=1)
            if row_number in by_row:
                raise _DecodeError("identity bindings contain duplicate normalized rows")
            if not is_hash(binding.get("source_record_hash")) or binding.get("source_record_hash") != content_hash(binding.get("source_record")):
                raise _DecodeError(f"identity binding row {row_number} has an invalid source-record hash")
            if parsed_original is not None and _resolve_json_locator(parsed_original, locator) != binding.get("source_record"):
                raise _DecodeError(f"identity binding row {row_number} does not match original source locator")
            stated_identity = binding.get("normalized_identity")
            if stated_identity is not None:
                _string(stated_identity, f"identity_bindings[{index}].normalized_identity")
            if rows.get(row_number) != stated_identity:
                raise _DecodeError(f"identity binding row {row_number} disagrees with normalized source")
            by_row[row_number] = binding
        if set(by_row) != set(rows):
            raise _DecodeError(
                f"identity bindings do not cover normalized rows: missing={sorted(set(rows)-set(by_row))}, "
                f"extra={sorted(set(by_row)-set(rows))}"
            )

        references = _array(value.get("portable_references"), "portable_references", nonempty=True)
        expected = {
            "ORIGINAL_SOURCE": (_digest_bytes(original_source), len(original_source)),
            "NORMALIZED_SOURCE": (_digest_bytes(normalized_source), len(normalized_source)),
            "MAPPING_PROFILE": (profile_hash, len(canonical_bytes(dict(profile)))),
        }
        seen_roles: Dict[str, str] = {}
        seen_ids = set()
        for index, raw in enumerate(references):
            reference = _object(raw, f"portable_references[{index}]")
            _keys(reference, {"reference_id", "role", "media_type", "content_hash", "byte_length", "availability"}, set(), f"portable_references[{index}]")
            identifier = _string(reference.get("reference_id"), f"portable_references[{index}].reference_id")
            role = reference.get("role")
            if identifier in seen_ids or role in seen_roles or role not in expected:
                raise _DecodeError("portable references have duplicate or unsupported roles/identities")
            seen_ids.add(identifier)
            seen_roles[str(role)] = identifier
            _string(reference.get("media_type"), f"portable_references[{index}].media_type")
            if reference.get("availability") not in {"CALLER_SUPPLIED_BYTES", "EMBEDDED_IN_EXPORT"}:
                raise _DecodeError("portable reference availability is unsupported")
            digest, length = expected[str(role)]
            if reference.get("content_hash") != digest or reference.get("byte_length") != length:
                raise _DecodeError(f"{role} portable reference does not bind its content")
        if set(seen_roles) != set(expected):
            raise _DecodeError("portable references do not cover original, normalized, and mapping content")

        checks = definition_checks + [
            ("source_bytes_binding", True, "original caller-supplied bytes match the embedded snapshot"),
            ("normalized_bytes_binding", True, "normalized bytes match the output and portable reference"),
            ("mapping_rederived", True, "mapping profile passed the independent intake-profile verifier"),
            ("source_record_bindings", True, "every embedded source record hash and normalized row identity was rederived"),
            ("portable_reference_closure", True, "all three required server-independent references are complete"),
        ]
        return checks, {
            "definition_hash": content_hash(decoded_definition),
            "input_snapshot_hash": content_hash(dict(snapshot)),
            "mapping_profile_hash": profile_hash,
            "source_record_count": len(bindings),
            "original_source_records_reconstructed": parsed_original is not None,
            "source_truth_established": False,
        }
    return _result("SourceAdapterOutput", operation)


def verify_source_adapter_conformance_report(record: Mapping[str, Any]) -> VerificationResult:
    """Verify report closure while explicitly declining to replay adapter code."""
    def operation():
        value = _object(record, "source-adapter conformance report")
        required = {
            "record_type", "schema_version", "authority", "definition", "definition_hash",
            "declared_execution_profile", "observed_execution_profile",
            "required_categories", "coverage", "required_requirements", "requirement_coverage",
            "cases", "passed", "violations", "claim",
        }
        _keys(value, required, set(), "source-adapter conformance report")
        if value.get("record_type") != "SourceAdapterConformanceReport":
            raise _DecodeError("conformance report record_type is unsupported")
        if value.get("schema_version") != SCHEMA_VERSION:
            raise _Unsupported("unsupported source-adapter conformance report version")
        if value.get("authority") != REPORT_AUTHORITY or value.get("claim") != CLAIM:
            raise _DecodeError("conformance report strengthens its authority or claim")
        definition, definition_checks = _definition(_object(value.get("definition"), "report definition"))
        if value.get("definition_hash") != content_hash(definition):
            raise _DecodeError("report definition_hash does not bind definition")
        declared_profile = value.get("declared_execution_profile")
        observed_profile = value.get("observed_execution_profile")
        if declared_profile != definition.get("execution_profile"):
            raise _DecodeError(
                "report declared_execution_profile does not match its definition"
            )
        if observed_profile not in {
            "REVIEWED_IN_PROCESS",
            "SANDBOXED_PROCESS",
            "NOT_EXECUTED",
        }:
            raise _DecodeError("report observed_execution_profile is unsupported")
        if observed_profile == "SANDBOXED_PROCESS":
            raise _Unsupported(
                "SANDBOXED_PROCESS conformance requires a registered isolation-evidence "
                "profile; this report schema carries no verifier-owned sandbox evidence"
            )
        if value.get("required_categories") != sorted(CATEGORIES):
            raise _DecodeError("report required_categories is not the complete registered set")
        if value.get("required_requirements") != sorted(REQUIREMENTS):
            raise _DecodeError("report required_requirements is not the complete registered set")
        coverage = _object(value.get("coverage"), "report coverage")
        requirement_coverage = _object(value.get("requirement_coverage"), "report requirement_coverage")
        if set(coverage) != CATEGORIES or set(requirement_coverage) != REQUIREMENTS:
            raise _DecodeError("report coverage keys are incomplete")
        actual_categories = {name: 0 for name in CATEGORIES}
        actual_requirements = {name: 0 for name in REQUIREMENTS}
        cases = _array(value.get("cases"), "report cases", nonempty=True)
        case_ids = set()
        all_passed = True
        for index, raw in enumerate(cases):
            case = _object(raw, f"cases[{index}]")
            required_case = {"fixture_id", "category", "requirements", "expected_status", "observed_status", "passed", "violations", "accepted_count", "rejected_count"}
            _keys(case, required_case, {"refusal_code", "output_hash", "preview_hash"}, f"cases[{index}]")
            fixture_id = _string(case.get("fixture_id"), f"cases[{index}].fixture_id")
            if fixture_id in case_ids:
                raise _DecodeError("report contains duplicate fixture identifiers")
            case_ids.add(fixture_id)
            category = case.get("category")
            if category not in CATEGORIES:
                raise _DecodeError("case category is unsupported")
            requirements = list(_array(case.get("requirements"), f"cases[{index}].requirements", nonempty=True))
            if len(requirements) != len(set(requirements)) or set(requirements) - REQUIREMENTS:
                raise _DecodeError("case requirements are duplicate or unsupported")
            expected_status = case.get("expected_status")
            observed_status = case.get("observed_status")
            if expected_status not in {"SUCCEEDED", "REFUSED"} or observed_status not in {"SUCCEEDED", "REFUSED", "FAILED", "NOT_RUN"}:
                raise _DecodeError("case status is unsupported")
            passed = case.get("passed")
            violations = _array(case.get("violations"), f"cases[{index}].violations")
            if not isinstance(passed, bool):
                raise _DecodeError("case passed must be boolean")
            for detail in violations:
                _string(detail, f"cases[{index}] violation")
            if passed != (not violations and expected_status == observed_status):
                raise _DecodeError("case passed flag disagrees with statuses/violations")
            for name in ("accepted_count", "rejected_count"):
                _integer(case.get(name), f"cases[{index}].{name}")
            for name in ("output_hash", "preview_hash"):
                if name in case and not is_hash(case.get(name)):
                    raise _DecodeError(f"cases[{index}].{name} is malformed")
            if "refusal_code" in case:
                _string(case.get("refusal_code"), f"cases[{index}].refusal_code")
            actual_categories[str(category)] += 1
            for requirement in requirements:
                actual_requirements[str(requirement)] += 1
            all_passed = all_passed and passed
        declared_coverage = {name: _integer(coverage.get(name), f"coverage.{name}") for name in CATEGORIES}
        declared_requirements = {name: _integer(requirement_coverage.get(name), f"requirement_coverage.{name}") for name in REQUIREMENTS}
        if declared_coverage != actual_categories or declared_requirements != actual_requirements:
            raise _DecodeError("report coverage counts do not match its cases")
        violations = _array(value.get("violations"), "report violations")
        for detail in violations:
            _string(detail, "report violation")
        expected_passed = (
            not violations
            and all_passed
            and all(declared_coverage.values())
            and all(declared_requirements.values())
            and observed_profile == declared_profile
            and observed_profile == "REVIEWED_IN_PROCESS"
        )
        if value.get("passed") is not expected_passed:
            raise _DecodeError("report passed flag disagrees with complete coverage and case results")
        if _contains_remote(value):
            raise _DecodeError("report contains an originating-server locator")
        checks = definition_checks + [
            ("fixture_category_coverage", True, "all six required fixture categories are counted from cases"),
            ("requirement_coverage", True, "all ten required adapter properties are counted from cases"),
            ("case_result_consistency", True, "case status, violations, and passed flags are internally consistent"),
            (
                "execution_profile_observed",
                True,
                "declared and observed profiles match the supported reviewed in-process runner",
            ),
            ("claim_boundary", True, "report remains non-authorizing and does not establish source truth"),
        ]
        return checks, {
            "definition_hash": content_hash(definition),
            "report_passed": bool(value.get("passed")),
            "declared_execution_profile": declared_profile,
            "observed_execution_profile": observed_profile,
            "fixture_execution_replayed": False,
            "source_truth_established": False,
            "integrity_only_reason": "adapter executable and fixture source bytes are not embedded in the report",
        }
    return _result("SourceAdapterConformanceReport", operation, integrity_only=True)
