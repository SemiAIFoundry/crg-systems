"""Portable lifecycle envelope dispatch and bundle semantic discovery.

The originating CLI/server is intentionally absent.  A bundle claim is
recognized from payload type, declared inventory type, or its registered
logical-id prefix, paired by the content hash inside the verifier envelope,
and independently replayed.  Removing ``record_type`` or renaming a logical
object therefore cannot turn malformed lifecycle evidence into inert bytes.
"""
from __future__ import annotations

from typing import Any, Dict, List, Mapping, Sequence, Tuple

from .canonical import CanonicalError, content_hash
from .certificate import Level, Status, VerificationResult
from .lifecycle import (
    verify_approval_record,
    verify_approval_withdrawal,
    verify_continued_validity_view,
    verify_conversion_binding_impact,
    verify_decision_scoped_conversion,
    verify_etq_decision_loop,
    verify_lifecycle_authorization,
    verify_qualification_disposition,
    verify_replacement_record,
    verify_result_ingestion_record,
    verify_selective_revalidation_record,
    verify_signature_verification_record,
)
from .resilience import (
    verify_backup_restore_recovery_record,
    verify_lifecycle_replay_record,
    verify_migration_reverification_record,
)

__all__ = [
    "LIFECYCLE_REPLAY_PROFILE",
    "LIFECYCLE_FIRST_RELEASE_ATTRIBUTION",
    "LIFECYCLE_RECORD_TYPES",
    "verify_lifecycle_replay_envelope",
    "portable_lifecycle_claims",
]

LIFECYCLE_REPLAY_PROFILE = "crg-lifecycle/independent-replay@1"
LIFECYCLE_FIRST_RELEASE_ATTRIBUTION = {
    "ETQDecisionLoop": "v1.3/ETQ_LIFECYCLE",
    "ResultIngestionRecord": "v1.3/ETQ_LIFECYCLE",
    "SelectiveRevalidationRecord": "v1.3/ETQ_LIFECYCLE",
    "ReplacementRecord": "v1.3/ETQ_LIFECYCLE",
    "QualificationDisposition": "v1.3/ETQ_LIFECYCLE",
    "DecisionScopedConversion": "v1.4/DECISION_LIFECYCLE",
    "ConversionBindingImpact": "v1.4/DECISION_LIFECYCLE",
    "SignatureVerificationRecord": "v1.4/DECISION_LIFECYCLE",
    "ApprovalRecord": "v1.4/DECISION_LIFECYCLE",
    "ApprovalWithdrawal": "v1.4/DECISION_LIFECYCLE",
    "LifecycleAuthorization": "v1.4/DECISION_LIFECYCLE",
    "ContinuedValidityView": "v1.4/DECISION_LIFECYCLE",
    "LifecycleReplayRecord": "v1.4/DECISION_LIFECYCLE",
    "BackupRestoreRecoveryRecord": "v1.4/DECISION_LIFECYCLE",
    "MigrationReverificationRecord": "v1.4/DECISION_LIFECYCLE",
}
LIFECYCLE_RECORD_TYPES = tuple(LIFECYCLE_FIRST_RELEASE_ATTRIBUTION)

_OPERATIONS = {
    "ETQDecisionLoop": ("verify_etq_decision_loop", frozenset()),
    "ResultIngestionRecord": (
        "verify_result_ingestion_record",
        frozenset({"result_record", "new_evidence", "prior_evidence"}),
    ),
    "SelectiveRevalidationRecord": (
        "verify_selective_revalidation_record",
        frozenset({"dependency_edges", "artifact_universe"}),
    ),
    "ReplacementRecord": (
        "verify_replacement_record",
        frozenset(
            {
                "revalidation_record", "prior_artifact", "replacement_artifact",
                "dependency_edges", "artifact_universe",
            }
        ),
    ),
    "QualificationDisposition": (
        "verify_qualification_disposition",
        frozenset(
            {
                "qualification_result", "ingestions", "required_evidence_ids",
                "verification_basis", "minimum_evidence_status",
            }
        ),
    ),
    "DecisionScopedConversion": (
        "verify_decision_scoped_conversion",
        frozenset(
            {
                "conversion_record", "source_case", "target_case", "retained_geometry",
                "decision_scope", "decision_certificate", "semantic_verifications",
                "dependencies",
            }
        ),
    ),
    "ConversionBindingImpact": (
        "verify_conversion_binding_impact",
        frozenset(
            {
                "binding", "current_conversion_record", "current_retained_geometry",
                "current_decision_scope", "current_decision_certificate",
            }
        ),
    ),
    "SignatureVerificationRecord": (
        "verify_signature_verification_record",
        frozenset(
            {
                "signature_content", "trusted_record_root", "signed_content",
                "cryptography_replayed",
            }
        ),
    ),
    "ApprovalRecord": (
        "verify_approval_record",
        frozenset({"trusted_signature_roots", "signature_content", "artifact"}),
    ),
    "ApprovalWithdrawal": (
        "verify_approval_withdrawal",
        frozenset(
            {"trusted_signature_roots", "signature_content", "approval"}
        ),
    ),
    "LifecycleAuthorization": (
        "verify_lifecycle_authorization",
        frozenset(
            {
                "approvals", "withdrawals", "policy", "clock",
                "trusted_signature_roots", "artifact",
            }
        ),
    ),
    "ContinuedValidityView": (
        "verify_continued_validity_view",
        frozenset({"artifact", "dimension_sources", "trigger_sources", "dependencies"}),
    ),
    "LifecycleReplayRecord": (
        "verify_lifecycle_replay_record",
        frozenset({"source_checkpoint", "records", "verification_inputs"}),
    ),
    "BackupRestoreRecoveryRecord": (
        "verify_backup_restore_recovery_record",
        frozenset(
            {
                "source_snapshot", "backup_snapshot", "restored_snapshot",
                "replay_record", "replay_source_checkpoint", "replay_records",
                "replay_verification_inputs",
            }
        ),
    ),
    "MigrationReverificationRecord": (
        "verify_migration_reverification_record",
        frozenset(
            {
                "migration_record", "source_object", "transformed_object",
                "lifecycle_record", "lifecycle_verification_inputs",
            }
        ),
    ),
}

_AUTHORITY_OPERATIONS = {
    "SignatureVerificationRecord": (
        "verify_signature_verification_record_v2",
        frozenset({"signature_content", "signed_content", "authority_snapshot"}),
    ),
    "ApprovalRecord": (
        "verify_approval_record_v2",
        frozenset({"signature_content", "artifact", "authority_snapshot", "principal"}),
    ),
    "ApprovalWithdrawal": (
        "verify_approval_withdrawal_v2",
        frozenset({"signature_content", "approval", "authority_snapshot", "principal"}),
    ),
    "LifecycleAuthorization": (
        "verify_lifecycle_authorization_v2",
        frozenset({
            "approvals", "withdrawals", "policy", "clock", "artifact",
            "authority_snapshot", "approval_signature_inputs",
            "withdrawal_signature_inputs",
        }),
    ),
    "ContinuedValidityView": (
        "verify_continued_validity_view_v2",
        frozenset({
            "artifact", "dimension_sources", "trigger_sources", "dependencies",
            "validity_source",
        }),
    ),
}


def _failed(check: str, detail: str, *, record_type: str) -> VerificationResult:
    result = VerificationResult(ok=False, status=Status.FAILED)
    result.record(check, False, detail)
    result.report.update(
        {
            "record_type": record_type,
            "claim_type": record_type,
            "claim_scope": "RELATIVE_TO_CARRIED_LIFECYCLE_RECORD_AND_REPLAY_INPUTS",
            "first_release_attribution": LIFECYCLE_FIRST_RELEASE_ATTRIBUTION.get(record_type),
            "level_attempted": Level.V2,
            "level_achieved": "NONE",
        }
    )
    return result.finish()


def _dispatch(
    record_type: str, record: Mapping[str, Any], inputs: Mapping[str, Any],
    operation: str,
) -> VerificationResult:
    if record_type == "ETQDecisionLoop":
        return verify_etq_decision_loop(record)
    if record_type == "ResultIngestionRecord":
        return verify_result_ingestion_record(
            record, inputs["result_record"], inputs["new_evidence"], inputs["prior_evidence"]
        )
    if record_type == "SelectiveRevalidationRecord":
        return verify_selective_revalidation_record(
            record, inputs["dependency_edges"], inputs["artifact_universe"]
        )
    if record_type == "ReplacementRecord":
        return verify_replacement_record(
            record,
            inputs["revalidation_record"],
            inputs["prior_artifact"],
            inputs["replacement_artifact"],
            inputs["dependency_edges"],
            inputs["artifact_universe"],
        )
    if record_type == "QualificationDisposition":
        return verify_qualification_disposition(
            record,
            inputs["qualification_result"],
            inputs["ingestions"],
            inputs["required_evidence_ids"],
            inputs["verification_basis"],
            minimum_evidence_status=inputs["minimum_evidence_status"],
        )
    if record_type == "DecisionScopedConversion":
        return verify_decision_scoped_conversion(
            record,
            inputs["conversion_record"],
            inputs["source_case"],
            inputs["target_case"],
            inputs["retained_geometry"],
            inputs["decision_scope"],
            inputs["decision_certificate"],
            inputs["semantic_verifications"],
            inputs["dependencies"],
        )
    if record_type == "ConversionBindingImpact":
        return verify_conversion_binding_impact(
            record,
            inputs["binding"],
            inputs["current_conversion_record"],
            inputs["current_retained_geometry"],
            inputs["current_decision_scope"],
            inputs["current_decision_certificate"],
        )
    if record_type == "SignatureVerificationRecord":
        if operation == "verify_signature_verification_record_v2":
            return verify_signature_verification_record(
                record,
                signature_content=inputs["signature_content"],
                signed_content=inputs["signed_content"],
                authority_snapshot=inputs["authority_snapshot"],
            )
        return verify_signature_verification_record(
            record,
            signature_content=inputs["signature_content"],
            trusted_record_root=inputs["trusted_record_root"],
        )
    if record_type == "ApprovalRecord":
        if operation == "verify_approval_record_v2":
            return verify_approval_record(
                record,
                signature_content=inputs["signature_content"],
                authority_snapshot=inputs["authority_snapshot"],
                principal=inputs["principal"],
            )
        return verify_approval_record(
            record,
            inputs["trusted_signature_roots"],
            signature_content=inputs["signature_content"],
        )
    if record_type == "ApprovalWithdrawal":
        if operation == "verify_approval_withdrawal_v2":
            return verify_approval_withdrawal(
                record,
                signature_content=inputs["signature_content"],
                authority_snapshot=inputs["authority_snapshot"],
                principal=inputs["principal"],
                approval=inputs["approval"],
            )
        return verify_approval_withdrawal(
            record,
            inputs["trusted_signature_roots"],
            signature_content=inputs["signature_content"],
        )
    if record_type == "LifecycleAuthorization":
        if operation == "verify_lifecycle_authorization_v2":
            return verify_lifecycle_authorization(
                record, inputs["approvals"], inputs["withdrawals"], inputs["policy"],
                inputs["clock"], authority_snapshot=inputs["authority_snapshot"],
                approval_signature_inputs=inputs["approval_signature_inputs"],
                withdrawal_signature_inputs=inputs["withdrawal_signature_inputs"],
            )
        return verify_lifecycle_authorization(
            record,
            inputs["approvals"],
            inputs["withdrawals"],
            inputs["policy"],
            inputs["clock"],
            inputs["trusted_signature_roots"],
        )
    if record_type == "ContinuedValidityView":
        if operation == "verify_continued_validity_view_v2":
            return verify_continued_validity_view(
                record, inputs["artifact"], inputs["dimension_sources"],
                inputs["trigger_sources"], inputs["dependencies"],
                validity_source=inputs["validity_source"],
            )
        return verify_continued_validity_view(
            record,
            inputs["artifact"],
            inputs["dimension_sources"],
            inputs["trigger_sources"],
            inputs["dependencies"],
        )
    if record_type == "LifecycleReplayRecord":
        return verify_lifecycle_replay_record(
            record,
            inputs["source_checkpoint"],
            inputs["records"],
            inputs["verification_inputs"],
        )
    if record_type == "BackupRestoreRecoveryRecord":
        return verify_backup_restore_recovery_record(
            record,
            inputs["source_snapshot"],
            inputs["backup_snapshot"],
            inputs["restored_snapshot"],
            inputs["replay_record"],
            inputs["replay_source_checkpoint"],
            inputs["replay_records"],
            inputs["replay_verification_inputs"],
        )
    if record_type == "MigrationReverificationRecord":
        return verify_migration_reverification_record(
            record,
            inputs["migration_record"],
            inputs["source_object"],
            inputs["transformed_object"],
            inputs["lifecycle_record"],
            inputs["lifecycle_verification_inputs"],
        )
    return _failed(
        "lifecycle_record_type", f"unregistered lifecycle record type {record_type!r}",
        record_type=record_type,
    )


def verify_lifecycle_replay_envelope(
    record: Mapping[str, Any], verification_inputs: Mapping[str, Any]
) -> VerificationResult:
    """Validate an exact portable replay envelope and dispatch independently."""
    if not isinstance(record, Mapping):
        return _failed("lifecycle_record_shape", "lifecycle record is not an object", record_type="UNKNOWN")
    record_type = str(record.get("record_type") or "UNKNOWN")
    if record_type not in _OPERATIONS:
        return _failed(
            "lifecycle_record_type", f"unregistered lifecycle record type {record_type!r}",
            record_type=record_type,
        )
    if not isinstance(verification_inputs, Mapping):
        return _failed(
            "lifecycle_envelope_shape", "lifecycle verification inputs are not an object",
            record_type=record_type,
        )
    required = {
        "verification_profile", "first_release_attribution", "verifier_operation",
        "record_type", "record_hash", "inputs",
    }
    if set(verification_inputs) != required:
        return _failed(
            "lifecycle_envelope_shape",
            f"replay envelope requires exactly {sorted(required)}; found {sorted(verification_inputs)}",
            record_type=record_type,
        )
    if verification_inputs.get("verification_profile") != LIFECYCLE_REPLAY_PROFILE:
        result = _failed(
            "lifecycle_envelope_profile",
            f"unsupported lifecycle replay profile {verification_inputs.get('verification_profile')!r}",
            record_type=record_type,
        )
        result.status = Status.UNSUPPORTED_PROFILE
        return result
    declared_operation = str(verification_inputs.get("verifier_operation") or "")
    candidates = [_OPERATIONS[record_type]]
    if record_type in _AUTHORITY_OPERATIONS:
        candidates.append(_AUTHORITY_OPERATIONS[record_type])
    selected = [candidate for candidate in candidates if candidate[0] == declared_operation]
    if len(selected) != 1:
        return _failed(
            "lifecycle_envelope_binding",
            f"unregistered verifier operation {declared_operation!r} for {record_type}",
            record_type=record_type,
        )
    operation, expected_fields = selected[0]
    expected_release = LIFECYCLE_FIRST_RELEASE_ATTRIBUTION[record_type]
    try:
        record_root = content_hash(record)
        envelope_root = content_hash(verification_inputs)
    except (CanonicalError, TypeError, ValueError) as error:
        return _failed(
            "lifecycle_canonical", f"lifecycle record/envelope is not canonical: {error}",
            record_type=record_type,
        )
    envelope_checks = (
        verification_inputs.get("record_type") == record_type
        and verification_inputs.get("record_hash") == record_root
        and verification_inputs.get("first_release_attribution") == expected_release
        and verification_inputs.get("verifier_operation") == operation
    )
    if not envelope_checks:
        return _failed(
            "lifecycle_envelope_binding",
            "record type, bytes, verifier operation, or first-release attribution does not match",
            record_type=record_type,
        )
    inputs = verification_inputs.get("inputs")
    if not isinstance(inputs, Mapping) or set(inputs) != expected_fields:
        return _failed(
            "lifecycle_replay_input_shape",
            f"{operation} requires exact fields {sorted(expected_fields)}; "
            f"found {sorted(inputs) if isinstance(inputs, Mapping) else 'non-object'}",
            record_type=record_type,
        )
    if record_type == "SignatureVerificationRecord" and operation == "verify_signature_verification_record":
        if inputs.get("cryptography_replayed") is not False:
            return _failed(
                "signature_claim_boundary",
                "signature-verification evidence must disclose cryptography_replayed=false",
                record_type=record_type,
            )
        try:
            signed_root = content_hash(inputs["signed_content"])
        except (CanonicalError, TypeError, ValueError) as error:
            return _failed("signature_signed_content", str(error), record_type=record_type)
        if signed_root != record.get("signed_content_hash"):
            return _failed(
                "signature_signed_content", "signed content does not match the attested hash",
                record_type=record_type,
            )
    portable_binding = True
    try:
        if record_type == "ApprovalRecord":
            portable_binding = content_hash(inputs["artifact"]) == (record.get("payload") or {}).get("artifact_hash")
        elif record_type == "ApprovalWithdrawal":
            portable_binding = content_hash(inputs["approval"]) == (record.get("payload") or {}).get("approval_hash")
        elif record_type == "LifecycleAuthorization":
            portable_binding = content_hash(inputs["artifact"]) == record.get("artifact_hash")
    except (CanonicalError, TypeError, ValueError):
        portable_binding = False
    if not portable_binding:
        return _failed(
            "lifecycle_source_binding",
            "portable source document does not match the producer-bound content root",
            record_type=record_type,
        )
    try:
        sub = _dispatch(record_type, record, inputs, operation)
    except Exception as error:
        return _failed(
            "lifecycle_verifier_completed",
            f"{record_type} replay raised {type(error).__name__}: {error}",
            record_type=record_type,
        )
    sub.report.update(
        {
            "record_type": record_type,
            "claim_type": record_type,
            "claim_scope": sub.report.get(
                "claim_scope", "RELATIVE_TO_CARRIED_LIFECYCLE_RECORD_AND_REPLAY_INPUTS"
            ),
            "first_release_attribution": expected_release,
            "verification_input_root": envelope_root,
            "semantic_replay": True,
            "level_attempted": Level.V2,
            "level_achieved": Level.V2 if sub.ok else "NONE",
        }
    )
    return sub


def _prefixed_type(object_id: str, prefix: str) -> str:
    if not object_id.startswith(prefix):
        return ""
    remainder = object_id[len(prefix):]
    return remainder.split(":", 1)[0]


def portable_lifecycle_claims(
    declarations: Sequence[Mapping[str, Any]], objects_by_id: Mapping[str, Any]
) -> List[Tuple[str, VerificationResult]]:
    """Discover and replay every lifecycle record/envelope pair in a bundle."""
    # Preserve declarations rather than de-duplicating by content hash.  Two
    # logical objects carrying identical bytes are still two semantic
    # declarations and must make the record/envelope pairing ambiguous.
    records: List[Tuple[str, str, Any, str]] = []
    envelopes: List[Tuple[str, Any]] = []
    for declaration in declarations:
        object_id = str(declaration.get("id") or "")
        if object_id not in objects_by_id:
            continue
        payload = objects_by_id[object_id]
        actual_type = payload.get("record_type") if isinstance(payload, Mapping) else None
        declared_type = declaration.get("object_type")
        id_record_type = _prefixed_type(object_id, "lifecycle:")
        candidate_type = str(actual_type or declared_type or id_record_type or "UNKNOWN")
        is_envelope = (
            object_id.startswith("lifecycle-verification-inputs:")
            or (
                isinstance(payload, Mapping)
                and str(payload.get("verification_profile") or "").startswith("crg-lifecycle/")
            )
        )
        if is_envelope:
            envelopes.append((object_id, payload))
            continue
        if (
            actual_type in LIFECYCLE_RECORD_TYPES
            or declared_type in LIFECYCLE_RECORD_TYPES
            or bool(id_record_type)
        ):
            digest = str(declaration.get("hash") or "")
            records.append((digest, object_id, payload, candidate_type))

    by_record_hash: Dict[str, List[Tuple[str, Any]]] = {}
    for object_id, envelope in envelopes:
        if isinstance(envelope, Mapping) and isinstance(envelope.get("record_hash"), str):
            by_record_hash.setdefault(str(envelope["record_hash"]), []).append((object_id, envelope))
    record_hash_counts: Dict[str, int] = {}
    for digest, _object_id, _record, _candidate_type in records:
        record_hash_counts[digest] = record_hash_counts.get(digest, 0) + 1

    claims: List[Tuple[str, VerificationResult]] = []
    consumed_envelopes = set()
    for digest, object_id, record, candidate_type in sorted(
        records, key=lambda item: item[1]
    ):
        matching = by_record_hash.get(digest, [])
        label = f"objects/{candidate_type}/{object_id}"
        if record_hash_counts[digest] != 1:
            result = _failed(
                "lifecycle_record_unique",
                f"lifecycle content hash {digest!r} is declared by "
                f"{record_hash_counts[digest]} logical records and cannot be uniquely paired",
                record_type=candidate_type,
            )
        elif len(matching) != 1:
            detail = (
                f"lifecycle record {object_id!r} has no hash-bound replay envelope"
                if not matching
                else f"lifecycle record {object_id!r} has {len(matching)} replay envelopes"
            )
            result = _failed(
                "lifecycle_replay_envelope_unique", detail, record_type=candidate_type
            )
        else:
            envelope_id, envelope = matching[0]
            consumed_envelopes.add(envelope_id)
            result = verify_lifecycle_replay_envelope(record, envelope)
        claims.append((label, result))

    for object_id, envelope in sorted(envelopes, key=lambda item: item[0]):
        if object_id in consumed_envelopes:
            continue
        record_type = (
            str(envelope.get("record_type") or "UNKNOWN")
            if isinstance(envelope, Mapping) else "UNKNOWN"
        )
        claims.append(
            (
                f"objects/LifecycleReplayEnvelope/{object_id}",
                _failed(
                    "lifecycle_record_present",
                    f"lifecycle replay envelope {object_id!r} has no matching inventoried record",
                    record_type=record_type,
                ),
            )
        )
    return claims
