"""CRG Verification Intermediate Representation (spec 24).

CRG-VIR is the restricted, deterministic carrier that brings
certificate-authorizing logic into the independent verifier without bringing
the producer's code with it (24.1).  A VIR document is *total*: it carries
the coordinate schema, the retained signatures, the claim, the derivation,
the tolerances, the generator sets a regret witness needs, and every hash
the claim references.  ``verify_vir`` therefore runs with no other file
present, no server, and no network -- the point of 25.1.

The verifier never executes producer code.  It decodes the document,
re-derives every asserted quantity from carried data, and evaluates only the
closed, typed, resource-bounded JSON AST in :mod:`vir_ast`.  24.4's
prohibitions are also enforced structurally: a document naming code, a plugin,
a URL, a filesystem path, an environment variable, a random source, or a wall
clock is rejected before any value is read from it.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional, Sequence

from .arith import ArithError, fmt, rational
from .canonical import CanonicalError, content_hash, hash_without, is_hash
from .certificate import Level, Status, VERIFIER_ID, VerificationResult, verify_certificate
from .extensions import ProofCheckerRegistry
from .vir_ast import AST_VERSION, VirProgramError, evaluate_program

__all__ = ["VIR_VERSION", "BASELINE_OPERATIONS", "BASELINE_TYPES", "PROHIBITED_KEYS",
           "emit_vir", "verify_vir"]

VIR_VERSION = "0.2.0"

#: The baseline CRG-VIR profile (24.3).  An operation outside this set needs
#: a registered extension checker, which 24.6 says is not automatically part
#: of the minimal trusted core.
BASELINE_OPERATIONS = frozenset(
    "add subtract multiply exact_divide integer_power sum minimum maximum dot_product "
    "absolute_value interval_construct interval_contains unit_convert equal not_equal "
    "less_than greater_than dominance member_of and or not implies for_all exists "
    "conditional bounded_reduce".split()
)
#: The declared types of 24.2.
BASELINE_TYPES = frozenset(
    "boolean integer rational decimal interval quantity vector matrix set map "
    "object_ref geometry_ref proof_ref".split()
)
#: 24.4.  Any of these as an object key makes the document inadmissible: it
#: would require the verifier to reach outside itself.
PROHIBITED_KEYS = frozenset(
    "code source_code eval exec import imports module entry_point callable plugin shell "
    "command url uri endpoint http https network socket filesystem file_path filepath env "
    "environment getenv random rng seed_source wall_clock now recursion while goto".split()
)

MAX_OPERATIONS = 1000000
REQUIRED_KEYS = ("vir_version", "program_id", "inputs", "output_claim_type", "operations",
                 "program", "limits", "coordinate_schema", "registry", "claim",
                 "tolerances", "hashes")
_EMITTED_OPERATIONS = sorted(
    "add subtract multiply sum minimum maximum dot_product interval_construct less_than "
    "dominance for_all exists conditional bounded_reduce and not equal".split()
)


# ---------------------------------------------------------------------------
# emission (producer side)
# ---------------------------------------------------------------------------
def _canon(value: Any) -> Any:
    """Project a kernel object to canonical JSON by duck typing only.

    ``emit_vir`` is the one producer-side function in this package.  It still
    imports nothing from the kernel: it calls ``to_canonical()`` when the
    object offers it and otherwise assumes plain JSON, so the verifier's
    dependency set stays empty while the kernel hands its objects over.
    """
    if value is None:
        return None
    to_canonical = getattr(value, "to_canonical", None)
    if callable(to_canonical):
        return to_canonical()
    if isinstance(value, dict):
        return {k: _canon(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_canon(v) for v in value]
    return value


def _generators(value: Any) -> Optional[List[list]]:
    """Extract a finite generator set as a list of canonical signatures."""
    if value is None:
        return None
    for attribute in ("frontier", "vertices", "signatures"):
        found = getattr(value, attribute, None)
        if found is not None:
            value = found
            break
    if isinstance(value, dict):
        for key in ("frontier", "vertices", "signatures", "points"):
            if key in value:
                value = value[key]
                break
        else:
            return None
    points: List[list] = []
    for point in value:
        canonical = _canon(point)
        if isinstance(canonical, dict):
            canonical = canonical.get("signature", canonical)
        points.append(list(canonical))
    return points


def _entries(bundle: dict, keep: Optional[Sequence[str]]) -> List[dict]:
    keep_set = set(keep) if keep is not None else None
    entries = []
    for realization in bundle.get("realizations", []):
        rid = str(realization.get("realization_id"))
        if keep_set is not None and rid not in keep_set:
            continue
        entry = {
            "realization_id": rid,
            "signature": realization.get("signature", []),
            "legality": realization.get("legality", "LEGAL"),
            "evidence_class": realization.get("evidence_class", "IMPORTED"),
        }
        if realization.get("attributes"):
            entry["attributes"] = realization["attributes"]
        entries.append(entry)
    return sorted(entries, key=lambda e: e["realization_id"])


def _retained_view(bundle: dict, keep: Sequence[str]) -> dict:
    """The retained sub-registry, in the canonical shape the kernel uses.

    Reconstructed rather than trusted, so the certificate's stated
    ``retained_registry_hash`` is checked against a registry the verifier
    built itself.  A reconstruction that does not hash to the stated value
    is reported as a missing dependency, which is the honest outcome.
    """
    keep_set = set(keep)
    return {
        **bundle,
        "bundle_id": f"{bundle.get('bundle_id')}::retained",
        "realizations": [r for r in bundle.get("realizations", [])
                         if str(r.get("realization_id")) in keep_set],
    }


def emit_vir(certificate: Any, geometry: Any = None, registry: Any = None) -> dict:
    """Produce a self-contained CRG-VIR document from kernel objects (24.5).

    ``certificate`` is a decision certificate (object or canonical mapping);
    ``geometry`` optionally carries the full and retained generator sets a
    regret witness is checked against; ``registry`` is the realization
    bundle, or a mapping ``{"bundle": ..., "retained": ..., "objects": ...}``.
    """
    claim = _canon(certificate)
    if not isinstance(claim, dict):
        raise CanonicalError("certificate does not project to a canonical mapping")
    claim = dict(claim)
    # A hash the certificate already carries is preserved, not replaced.
    # Recomputing it would launder a tampered record into a self-consistent
    # one and destroy the chain the verifier's first check walks.
    stated = claim.pop("certificate_hash", None)
    certificate_hash = stated or content_hash(claim)
    claim["certificate_hash"] = certificate_hash

    bundle_obj, retained_obj = registry, None
    supplied: Dict[str, Any] = {}
    heuristic: List[str] = []
    if isinstance(registry, dict) and not registry.get("realizations"):
        bundle_obj = registry.get("bundle") or registry.get("complete")
        retained_obj = registry.get("retained")
        supplied = dict(registry.get("objects") or {})
        heuristic = list(registry.get("heuristic_inputs") or [])
    bundle = _canon(bundle_obj) or {}
    if not isinstance(bundle, dict):
        raise CanonicalError("registry does not project to a canonical mapping")

    retained_ids = sorted((claim.get("objective_values") or {}).keys()) or None
    entries = _entries(bundle, retained_ids)
    objects: Dict[str, Any] = dict(supplied)
    if bundle:
        objects[content_hash(bundle)] = bundle
        if retained_ids is not None:
            view = _retained_view(bundle, retained_ids)
            objects[content_hash(view)] = view
    if retained_obj is not None:
        objects[content_hash(_canon(retained_obj))] = _canon(retained_obj)

    schema = (bundle.get("schema")
              or (claim.get("scope") or {}).get("coordinate_schema") or {})
    geo = geometry if isinstance(geometry, dict) else {"full": geometry}
    full = _generators(geo.get("full") or geo.get("full_frontier")
                       or geo.get("GAMMA") or geo.get("R"))
    retained = _generators(geo.get("retained") or geo.get("retained_frontier"))

    block: Dict[str, Any] = {
        "coordinate_schema_hash": content_hash(schema) if schema else None,
        "complete_registry_hash": claim.get("complete_registry_hash"),
        "retained_registry_hash": claim.get("retained_registry_hash"),
        "entries": entries,
        "objects": objects,
    }
    if full is not None:
        block["full_generators"] = full
    if retained is not None:
        block["retained_generators"] = retained
    if heuristic:
        block["heuristic_inputs"] = heuristic

    scope = claim.get("scope") or {}
    document: Dict[str, Any] = {
        "vir_version": VIR_VERSION,
        "spec_version": "0.2.0",
        "program_id": f"vir-{claim.get('certificate_id', 'certificate')}",
        "produced_by": f"{VERIFIER_ID}/emit_vir",
        "inputs": {
            "certificate_recomputed": "boolean",
            "claim_selected": "set",
            "evaluated_selected": "set",
            "claim_outcome": "object_ref",
            "evaluated_outcome": "object_ref",
        },
        "output_claim_type": "DECISION_CERTIFICATE_CLAIM",
        "operations": list(_EMITTED_OPERATIONS),
        "program": {
            "ast_version": AST_VERSION,
            "result_type": "boolean",
            "expression": {
                "op": "and",
                "args": [
                    {"op": "input", "name": "certificate_recomputed"},
                    {
                        "op": "equal",
                        "left": {"op": "input", "name": "claim_selected"},
                        "right": {"op": "input", "name": "evaluated_selected"},
                    },
                    {
                        "op": "equal",
                        "left": {"op": "input", "name": "claim_outcome"},
                        "right": {"op": "input", "name": "evaluated_outcome"},
                    },
                ],
            },
        },
        "limits": {
            "max_candidates": max(len(entries), 1),
            "max_dimension": len(schema.get("coordinates", []) or []) or 1,
            "max_generators": max(len(full or []), len(retained or []), 1),
            "max_operations": MAX_OPERATIONS,
            "max_collection": max(len(entries), len(claim.get("selected") or []), 1),
            "max_depth": 64,
        },
        "coordinate_schema": schema,
        "registry": block,
        "claim": claim,
        "derivation": claim.get("derivation") or {},
        "completeness": claim.get("completeness") or {},
        "tolerances": {
            "policy_tolerance": scope.get("tie_tolerance", {"exact": "0"}),
            "bounded_regret": (scope.get("objective_family") or {}).get("bounded_regret"),
        },
        "validity": {
            "issued_at": claim.get("issued_at"), "not_before": claim.get("not_before"),
            "expires_at": claim.get("expiry"),
            "issuer_clock_source": claim.get("issuer_clock_source", "issuer-asserted"),
        },
        "evaluation": {"deterministic": True, "result_claim": claim.get("outcome"),
                       "selected": list(claim.get("selected") or [])},
        "hashes": {"certificate_hash": certificate_hash},
    }
    document["hashes"]["program_hash"] = hash_without(document, "hashes")
    return document


# ---------------------------------------------------------------------------
# verification (24.4, 24.5)
# ---------------------------------------------------------------------------
def _scan_prohibited(value: Any, path: str = "$") -> List[str]:
    found: List[str] = []
    if isinstance(value, dict):
        for key, item in value.items():
            # §24.6 declarations must be able to *describe* their sandbox
            # requirements (for example network=false).  This block is inert
            # metadata and is matched byte-for-byte against a verifier-owned
            # registration before any checker runs.
            declaration_metadata = path.endswith(".declaration.sandbox_requirements")
            if not declaration_metadata and str(key).lower() in PROHIBITED_KEYS:
                found.append(f"{path}.{key}")
            found.extend(_scan_prohibited(item, f"{path}.{key}"))
    elif isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            found.extend(_scan_prohibited(item, f"{path}[{index}]"))
    return found


def _ast_operations(value: Any) -> set:
    found = set()
    if isinstance(value, dict):
        operation = value.get("op")
        if operation not in (None, "literal", "input"):
            found.add(str(operation))
        for item in value.values():
            found.update(_ast_operations(item))
    elif isinstance(value, (list, tuple)):
        for item in value:
            found.update(_ast_operations(item))
    return found


def verify_vir(
    vir: dict, *, clock: Optional[str] = None, clock_source: str = "none-supplied",
    extension_registry: Optional[ProofCheckerRegistry] = None,
) -> VerificationResult:
    """Verify a CRG-VIR document standalone (spec 24, 25).

    No file, server, solver, or network is consulted.  Everything the claim
    needs is either inside the document or the claim is not verifiable, and
    the second case is a failure, not a pass with a caveat (6.6).
    """
    result = VerificationResult(ok=False)
    if not isinstance(vir, dict):
        result.record("vir_structure", False, "CRG-VIR document is not a JSON object")
        result.status = Status.FAILED
        return result.finish()
    missing = [key for key in REQUIRED_KEYS if key not in vir]
    if not result.record("vir_structure", not missing,
                         f"missing required fields {missing}" if missing else
                         f"all {len(REQUIRED_KEYS)} required CRG-VIR fields present (24.5)"):
        result.status = Status.FAILED
        return result.finish()

    result.record("vir_version", str(vir.get("vir_version")) == VIR_VERSION,
                  f"document declares {vir.get('vir_version')!r}; this verifier implements "
                  f"{VIR_VERSION!r} (spec 24.5, 15.2)")

    # 24.5: content hash over the document, excluding the hash block itself.
    stated = (vir.get("hashes") or {}).get("program_hash")
    try:
        recomputed: Optional[str] = hash_without(vir, "hashes")
        result.record("vir_canonical_form", True, "document is canonically encodable")
    except CanonicalError as error:
        recomputed = None
        result.record("vir_canonical_form", False, str(error))
    result.record("vir_program_hash",
                  bool(stated) and is_hash(str(stated)) and recomputed == stated,
                  f"stated {stated}, recomputed {recomputed}")

    # 24.4: prohibited behavior.
    prohibited = _scan_prohibited(vir)
    result.record("vir_no_prohibited_constructs", not prohibited,
                  f"document names prohibited constructs at {prohibited} (24.4)" if prohibited
                  else "no code, plugin, URL, path, environment, randomness, or clock reference")

    # 24.2 / 24.3: declared types and the baseline operation profile.
    declared_types = {str(t) for t in (vir.get("inputs") or {}).values()}
    unknown = sorted(declared_types - BASELINE_TYPES)
    result.record("vir_declared_types", not unknown,
                  f"input types outside the CRG-VIR type set: {unknown} (24.2)" if unknown
                  else f"declared input types {sorted(declared_types)} are all baseline types")
    operations = {str(o) for o in (vir.get("operations") or [])}
    extensions = sorted(operations - BASELINE_OPERATIONS)
    undeclared = sorted(_ast_operations(vir.get("program")) - operations)
    extension_reports = []
    extension_failures = []
    requests = vir.get("extension_checkers") or []
    if extensions:
        if extension_registry is None:
            extension_failures.append(
                "no verifier-owned extension checker registry was supplied"
            )
        elif not isinstance(requests, list):
            extension_failures.append("extension_checkers is not a list")
        else:
            for operation in extensions:
                matching = [request for request in requests
                            if isinstance(request, dict)
                            and str(request.get("operation", "")) == operation]
                if len(matching) != 1:
                    extension_failures.append(
                        f"operation {operation!r} has {len(matching)} checker declarations, expected one"
                    )
                    continue
                passed, detail, report = extension_registry.verify(
                    operation, matching[0],
                    context={"vir_version": vir.get("vir_version"),
                             "program_id": vir.get("program_id"),
                             "claim": vir.get("claim")},
                )
                extension_reports.append({"passed": passed, "detail": detail, **report})
                if not passed:
                    extension_failures.append(f"{operation}: {detail}")
    result.record("vir_operation_profile", not undeclared and not extension_failures,
                  f"program uses undeclared operations {undeclared} (24.3, 24.5)" if undeclared
                  else "; ".join(extension_failures) if extension_failures
                  else f"{len(extensions)} specialized operation(s) passed explicitly registered "
                  "proof checkers outside the minimal trusted core (24.6)" if extensions
                  else f"{len(operations)} operations, all inside the baseline profile (24.3)")
    if extension_reports:
        result.report["extension_proof_checkers"] = extension_reports

    # 24.5: bounded resource limits, declared and respected.
    limits = vir.get("limits") or {}
    registry = vir.get("registry") or {}
    entries = registry.get("entries") or []
    schema = vir.get("coordinate_schema") or {}
    dimension = len(schema.get("coordinates") or [])
    required_limits = (
        "max_candidates", "max_dimension", "max_generators",
        "max_operations", "max_collection", "max_depth",
    )
    breaches = [f"{name} is not declared" for name in required_limits if name not in limits]
    parsed_limits = {}
    for name in required_limits:
        if name not in limits:
            continue
        try:
            parsed_limits[name] = int(limits[name])
        except (TypeError, ValueError, OverflowError):
            breaches.append(f"{name} is not an integer")
            continue
        if parsed_limits[name] <= 0:
            breaches.append(f"{name} is not positive")
    generators = max(len(registry.get("full_generators") or []),
                     len(registry.get("retained_generators") or []))
    for actual, name in ((len(entries), "max_candidates"), (dimension, "max_dimension"),
                         (generators, "max_generators")):
        if name in parsed_limits and actual > parsed_limits[name]:
            breaches.append(f"{actual} exceeds {name} {limits[name]}")
    result.record("vir_bounded_limits", not breaches, "; ".join(breaches) if breaches
                  else f"declared limits present and respected ({len(entries)} candidates, "
                       f"dimension {dimension})")

    # 24.1 / 25.1: the document is self-contained.
    external = vir.get("external_references") or []
    result.record("vir_self_contained", not external and bool(entries) and bool(schema),
                  f"document requires {len(external)} external references" if external
                  else "no coordinate schema is carried" if not schema
                  else "no retained registry is carried" if not entries
                  else "schema, registry, claim, tolerances, and hashes are all carried inline")
    result.record("vir_output_claim_type",
                  str(vir.get("output_claim_type")) == "DECISION_CERTIFICATE_CLAIM",
                  f"declared output claim type {vir.get('output_claim_type')!r}")

    # -- the claim itself -------------------------------------------------
    claim = vir.get("claim") or {}
    inner = verify_certificate(claim, registry={**registry, "schema": schema},
                               clock=clock, clock_source=clock_source)
    result.checks.extend(inner.checks)
    result.violations.extend(inner.violations)
    result.warnings.extend(inner.warnings)
    result.report.update(inner.report)
    result.report.update({"vir_program_id": vir.get("program_id"),
                          "vir_version": vir.get("vir_version")})

    # 24.5 requires a deterministic evaluation result.
    evaluation = vir.get("evaluation") or {}
    result.record("vir_deterministic_result",
                  bool(evaluation.get("deterministic"))
                  and str(evaluation.get("result_claim")) == str(claim.get("outcome")),
                  f"declared result {evaluation.get('result_claim')!r} against claim outcome "
                  f"{claim.get('outcome')!r}")

    # The tolerance the claim was decided under must be the tolerance the
    # document declares, or the carried program is not the program that
    # produced the claim.
    try:
        declared_tau = rational((vir.get("tolerances") or {}).get("policy_tolerance", 0))
        claim_tau = rational((claim.get("scope") or {}).get("tie_tolerance", 0))
        agree = declared_tau == claim_tau
        detail = (f"tolerance {fmt(declared_tau)} matches the claim scope" if agree else
                  f"CRG-VIR declares tolerance {fmt(declared_tau)} but the claim was decided "
                  f"at {fmt(claim_tau)}")
    except ArithError as error:
        agree, detail = False, f"tolerance is not exactly decodable: {error}"
    result.record("vir_tolerance_binding", agree, detail)

    # 24.1-24.5: execute the carried, typed value-language program.  The
    # certificate result is a verifier-owned input; the program cannot assert
    # its own success.  Its other bindings ensure the carried evaluation agrees
    # with the claim the independent verifier just recomputed.
    try:
        program_result = evaluate_program(
            vir.get("program") or {},
            {
                "certificate_recomputed": bool(inner.ok),
                "claim_selected": list(claim.get("selected") or []),
                "evaluated_selected": list(evaluation.get("selected") or []),
                "claim_outcome": str(claim.get("outcome") or "UNDECLARED"),
                "evaluated_outcome": str(evaluation.get("result_claim") or "UNDECLARED"),
            },
            vir.get("inputs") or {},
            limits,
        )
        program_ok = program_result is True
        program_detail = (
            "typed CRG-VIR program evaluated deterministically to true"
            if program_ok else
            f"typed CRG-VIR program evaluated to {program_result!r}, not true"
        )
    except VirProgramError as error:
        program_ok, program_detail = False, f"typed CRG-VIR program refused: {error}"
    result.record("vir_typed_program", program_ok, program_detail)

    result.finish()
    if inner.status == Status.UNVERIFIABLE_REDACTED:
        result.ok = False
    result.status = inner.status if result.ok or inner.status == Status.UNVERIFIABLE_REDACTED else (
        Status.EXPIRED if inner.status == Status.EXPIRED else Status.FAILED)
    result.report.update({"final_status": result.status, "level_attempted": Level.V3,
                          "level_achieved": (
                              Level.V2 if result.status == Status.REPLAY_BOUND else Level.V3
                          ) if result.ok else "NONE"})
    return result
