"""Independent verification of CRG v1.2 phase and delta evidence.

This module is the verification-zone implementation for the Workstream C
records.  It deliberately does not import ``crg_geometry``, ``crg_change``,
or ``crg_model``.  Canonical hashing, exact lower-envelope construction,
change classification, typed-edge traversal, certificate invalidation, and
minimum-action selection are reconstructed from portable JSON content.

The public functions return :class:`VerificationResult`, so unsupported
profiles and malformed evidence have explicit fail-closed statuses rather
than being confused with Python exceptions or best-effort validation.
"""
from __future__ import annotations

from fractions import Fraction
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Set, Tuple

from .arith import ArithError, rational
from .canonical import CanonicalError, canonical_json, content_hash, is_hash
from .certificate import Status, VerificationResult

__all__ = [
    "verify_phase_analysis_record",
    "verify_certified_delta_record",
]

PHASE_SCHEMA_VERSION = "1.2.0"
DELTA_SCHEMA_VERSION = "1.2.0"
PHASE_PROFILE = "TWO_COORDINATE_PRICE_SIMPLEX_V1"
PHASE_PROGRAM = "crg-geometry.phase.verify/v1"
DELTA_PROGRAM = "crg-change.certified-delta.verify/v1"


class _DecodeError(ValueError):
    pass


class _UnsupportedProfileError(_DecodeError):
    """The portable source does not satisfy the registered profile domain."""


def _object(value: Any, where: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise _DecodeError(f"{where} must be an object")
    return value


def _array(value: Any, where: str) -> Sequence[Any]:
    if not isinstance(value, (list, tuple)):
        raise _DecodeError(f"{where} must be an array")
    return value


def _string(value: Any, where: str, *, empty: bool = False) -> str:
    if not isinstance(value, str) or (not empty and not value):
        raise _DecodeError(f"{where} must be a non-empty string")
    return value


def _bool(value: Any, where: str) -> bool:
    if not isinstance(value, bool):
        raise _DecodeError(f"{where} must be a boolean")
    return value


def _keys(
    value: Mapping[str, Any],
    required: Iterable[str],
    optional: Iterable[str],
    where: str,
) -> None:
    expected = set(required)
    allowed = expected | set(optional)
    missing = expected - set(value)
    unknown = set(value) - allowed
    if missing:
        raise _DecodeError(f"{where} is missing fields {sorted(missing)}")
    if unknown:
        raise _DecodeError(f"{where} has unsupported fields {sorted(unknown)}")


def _exact(value: Any, where: str) -> Fraction:
    item = _object(value, where)
    if set(item) != {"exact"} or not isinstance(item.get("exact"), str):
        raise _DecodeError(f"{where} must be exactly {{'exact': '<rational>'}}")
    try:
        result = rational(item)
    except (ArithError, TypeError, ValueError, ZeroDivisionError) as error:
        raise _DecodeError(f"{where} is not an exact rational: {error}") from error
    if item["exact"] != _fraction_text(result):
        raise _DecodeError(f"{where} is not in canonical reduced rational form")
    return result


def _fraction_text(value: Fraction) -> str:
    if value.denominator == 1:
        return str(value.numerator)
    return f"{value.numerator}/{value.denominator}"


def _exact_json(value: Fraction) -> dict:
    return {"exact": _fraction_text(value)}


def _stable_id(prefix: str, payload: Any) -> str:
    return f"{prefix}-{content_hash(payload).split(':', 1)[1][:20]}"


def _ids(value: Any, where: str, *, sorted_unique: bool = True) -> Tuple[str, ...]:
    result = tuple(_string(item, f"{where}[]") for item in _array(value, where))
    if len(set(result)) != len(result):
        raise _DecodeError(f"{where} contains duplicate identifiers")
    if sorted_unique and result != tuple(sorted(result)):
        raise _DecodeError(f"{where} is not canonically sorted")
    return result


def _canonical_preflight(value: Any, where: str) -> str:
    try:
        return content_hash(value)
    except (CanonicalError, TypeError, ValueError) as error:
        raise _DecodeError(f"{where} is not canonically hashable: {error}") from error


# ---------------------------------------------------------------------------
# Phase analysis: independent exact lower-envelope reconstruction
# ---------------------------------------------------------------------------
def _phase_source(source: Mapping[str, Any]) -> Tuple[str, str, dict, List[dict]]:
    _keys(source, ("record_type", "schema", "fibers", "completeness"), (), "source R")
    if source.get("record_type") != "R":
        raise _DecodeError("source R has an unsupported record_type")
    schema = _object(source.get("schema"), "source R.schema")
    coordinates = _array(schema.get("coordinates"), "source R.schema.coordinates")
    if len(coordinates) != 2:
        raise _UnsupportedProfileError(f"{PHASE_PROFILE} requires exactly two coordinates")
    identifiers: Set[str] = set()
    for index, raw in enumerate(coordinates):
        coordinate = _object(raw, f"source R.schema.coordinates[{index}]")
        identifier = _string(
            coordinate.get("identifier"), f"source R.schema.coordinates[{index}].identifier"
        )
        if identifier in identifiers:
            raise _DecodeError("source R coordinate identifiers are not unique")
        identifiers.add(identifier)
        direction = _string(
            coordinate.get("direction"),
            f"source R.schema.coordinates[{index}].direction",
        )
        if direction != "MINIMIZE":
            raise _UnsupportedProfileError(
                f"{PHASE_PROFILE} requires both source coordinates to be declared MINIMIZE"
            )

    completeness = dict(_object(source.get("completeness"), "source R.completeness"))
    policies: List[dict] = []
    seen: Set[str] = set()
    for fiber_index, raw in enumerate(_array(source.get("fibers"), "source R.fibers")):
        fiber = _object(raw, f"source R.fibers[{fiber_index}]")
        _keys(fiber, ("signature", "realization_ids"), (), f"source R.fibers[{fiber_index}]")
        signature = _array(fiber.get("signature"), f"source R.fibers[{fiber_index}].signature")
        if len(signature) != 2:
            raise _DecodeError("source R contains a signature with the wrong dimension")
        x = _exact(signature[0], f"source R.fibers[{fiber_index}].signature[0]")
        y = _exact(signature[1], f"source R.fibers[{fiber_index}].signature[1]")
        fiber_ids = _ids(
            fiber.get("realization_ids"),
            f"source R.fibers[{fiber_index}].realization_ids",
        )
        if not fiber_ids:
            raise _DecodeError("source R contains an empty fiber")
        for identifier in fiber_ids:
            if identifier in seen:
                raise _DecodeError(f"source R repeats realization identifier {identifier!r}")
            seen.add(identifier)
            policies.append(
                {
                    "policy_id": identifier,
                    "coordinate_values": [_exact_json(x), _exact_json(y)],
                    "affine_value": {
                        "intercept": _exact_json(y),
                        "slope": _exact_json(x - y),
                    },
                }
            )
    if not policies:
        raise _DecodeError("source R contains no realizations")
    policies.sort(key=lambda item: item["policy_id"])
    return content_hash(source), content_hash(schema), completeness, policies


def _phase_expected(
    artifact: Mapping[str, Any], source_r: Mapping[str, Any]
) -> Tuple[dict, Dict[str, Any]]:
    top_required = (
        "record_type", "schema_version", "analysis_id", "profile", "source_r_root",
        "coordinate_schema_hash", "family_completeness", "claim_scope",
        "arithmetic_profile", "solver_trust_profile", "policies", "regions",
        "boundaries", "ties", "degeneracies", "verification_program",
        "claim_limitations",
    )
    _keys(artifact, top_required, ("stability",), "phase analysis")
    source_root, schema_root, completeness, policies = _phase_source(source_r)

    profile = _object(artifact.get("profile"), "phase analysis.profile")
    _keys(
        profile,
        (
            "profile_id", "profile_version", "objective", "parameter",
            "parameter_domain", "weight_map", "policy_tolerance",
        ),
        (),
        "phase analysis.profile",
    )
    tolerance = _exact(profile.get("policy_tolerance"), "phase analysis.profile.policy_tolerance")
    if tolerance < 0:
        raise _DecodeError("phase policy tolerance must be nonnegative")
    domain = _object(profile.get("parameter_domain"), "phase analysis.profile.parameter_domain")
    _keys(domain, ("lower", "upper", "lower_closed", "upper_closed"), (), "phase domain")
    if (
        _exact(domain.get("lower"), "phase domain.lower") != 0
        or _exact(domain.get("upper"), "phase domain.upper") != 1
        or _bool(domain.get("lower_closed"), "phase domain.lower_closed") is not True
        or _bool(domain.get("upper_closed"), "phase domain.upper_closed") is not True
    ):
        raise _DecodeError("registered phase domain must be the closed interval [0, 1]")

    coefficients: Dict[str, Tuple[Fraction, Fraction]] = {}
    for policy in policies:
        identifier = policy["policy_id"]
        affine = policy["affine_value"]
        coefficients[identifier] = (
            rational(affine["intercept"]),
            rational(affine["slope"]),
        )

    def value(identifier: str, theta: Fraction) -> Fraction:
        intercept, slope = coefficients[identifier]
        return intercept + slope * theta

    def winners(theta: Fraction) -> Tuple[str, ...]:
        values = {identifier: value(identifier, theta) for identifier in coefficients}
        optimum = min(values.values())
        return tuple(
            sorted(identifier for identifier, result in values.items() if result <= optimum + tolerance)
        )

    candidates = {Fraction(0), Fraction(1)}
    policy_ids = sorted(coefficients)
    for index, left_id in enumerate(policy_ids):
        left_intercept, left_slope = coefficients[left_id]
        for right_id in policy_ids[index + 1 :]:
            right_intercept, right_slope = coefficients[right_id]
            denominator = left_slope - right_slope
            if denominator == 0:
                continue
            for offset in (-tolerance, Fraction(0), tolerance):
                theta = (right_intercept - left_intercept + offset) / denominator
                if 0 <= theta <= 1:
                    candidates.add(theta)
    points = sorted(candidates)

    boundary_facts: List[Tuple[Fraction, Tuple[str, ...], Tuple[str, ...], Tuple[str, ...]]] = []
    boundaries: List[dict] = []
    for index, theta in enumerate(points):
        at = winners(theta)
        left = winners((points[index - 1] + theta) / 2) if index else ()
        right = winners((theta + points[index + 1]) / 2) if index + 1 < len(points) else ()
        changes = bool(
            (left and left != at)
            or (right and right != at)
            or (left and right and left != right)
        )
        if not changes or (theta not in (0, 1) and left == right):
            continue
        boundary_facts.append((theta, left, at, right))
        payload = {
            "parameter": _exact_json(theta),
            "left": list(left),
            "at": list(at),
            "right": list(right),
        }
        boundaries.append(
            {
                "boundary_id": _stable_id("phase-boundary", payload),
                "parameter": _exact_json(theta),
                "sidedness": "TWO_SIDED" if left and right else "ONE_SIDED",
                "left_winner_ids": list(left),
                "boundary_winner_ids": list(at),
                "right_winner_ids": list(right),
                "classification": "CERTIFIED_PHASE_BOUNDARY",
                "basis": "OPTIMAL_POLICY_SET_CHANGES",
            }
        )

    boundary_values = {item[0] for item in boundary_facts}
    cuts = sorted({Fraction(0), Fraction(1)} | boundary_values)
    region_facts: List[Tuple[Fraction, Fraction, bool, bool, Tuple[str, ...]]] = []
    regions: List[dict] = []
    for lower, upper in zip(cuts, cuts[1:]):
        if lower == upper:
            continue
        region_winners = winners((lower + upper) / 2)
        lower_closed = lower not in boundary_values and winners(lower) == region_winners
        upper_closed = upper not in boundary_values and winners(upper) == region_winners
        region_facts.append((lower, upper, lower_closed, upper_closed, region_winners))
        payload = {
            "lower": _exact_json(lower),
            "upper": _exact_json(upper),
            "lower_closed": lower_closed,
            "upper_closed": upper_closed,
            "winners": list(region_winners),
        }
        regions.append(
            {
                "region_id": _stable_id("phase-region", payload),
                "parameter_interval": {
                    "lower": _exact_json(lower),
                    "upper": _exact_json(upper),
                    "lower_closed": lower_closed,
                    "upper_closed": upper_closed,
                },
                "winner_ids": list(region_winners),
                "claim": "CERTIFIED_CONSTANT_OPTIMAL_POLICY_SET",
            }
        )

    ties: List[dict] = []
    for theta, _left, at, _right in boundary_facts:
        if len(at) < 2:
            continue
        outcome = (
            "CERTIFIED_WINNER_SET"
            if len({value(identifier, theta) for identifier in at}) == 1
            else "CERTIFIED_POLICY_TIE"
        )
        payload = {
            "kind": "POINT",
            "decision_outcome": outcome,
            "parameter": _exact_json(theta),
            "policies": list(at),
        }
        ties.append(
            {
                "tie_id": _stable_id("phase-tie", payload),
                "kind": "POINT",
                "decision_outcome": outcome,
                "parameter_interval": {
                    "lower": _exact_json(theta), "upper": _exact_json(theta),
                    "lower_closed": True, "upper_closed": True,
                },
                "policy_ids": list(at),
                "claim": (
                    "EXACT_OPTIMAL_VALUE_EQUALITY"
                    if outcome == "CERTIFIED_WINNER_SET"
                    else "WITHIN_DECLARED_POLICY_TOLERANCE"
                ),
            }
        )
    for lower, upper, lower_closed, upper_closed, region_winners in region_facts:
        if len(region_winners) < 2:
            continue
        outcome = (
            "CERTIFIED_WINNER_SET"
            if len({coefficients[identifier] for identifier in region_winners}) == 1
            else "CERTIFIED_POLICY_TIE"
        )
        payload = {
            "kind": "INTERVAL", "decision_outcome": outcome,
            "lower": _exact_json(lower), "upper": _exact_json(upper),
            "lower_closed": lower_closed, "upper_closed": upper_closed,
            "policies": list(region_winners),
        }
        ties.append(
            {
                "tie_id": _stable_id("phase-tie", payload),
                "kind": "INTERVAL",
                "decision_outcome": outcome,
                "parameter_interval": {
                    "lower": _exact_json(lower), "upper": _exact_json(upper),
                    "lower_closed": lower_closed, "upper_closed": upper_closed,
                },
                "policy_ids": list(region_winners),
                "claim": (
                    "EXACT_OPTIMAL_VALUE_EQUALITY"
                    if outcome == "CERTIFIED_WINNER_SET"
                    else "WITHIN_DECLARED_POLICY_TOLERANCE"
                ),
            }
        )
    ties.sort(
        key=lambda item: (
            rational(item["parameter_interval"]["lower"]),
            rational(item["parameter_interval"]["upper"]),
            item["tie_id"],
        )
    )

    degeneracies: List[dict] = []
    groups: Dict[Tuple[Fraction, Fraction], List[str]] = {}
    for identifier, coefficient in coefficients.items():
        groups.setdefault(coefficient, []).append(identifier)
    for coefficient in sorted(groups):
        group = tuple(sorted(groups[coefficient]))
        if len(group) < 2:
            continue
        payload = {"kind": "COINCIDENT_SCORE_FUNCTIONS", "policies": list(group)}
        degeneracies.append(
            {
                "degeneracy_id": _stable_id("phase-degeneracy", payload),
                "kind": "COINCIDENT_SCORE_FUNCTIONS",
                "policy_ids": list(group),
            }
        )
    for theta, _left, at, _right in boundary_facts:
        at_values = {identifier: value(identifier, theta) for identifier in at}
        optimum = min(at_values.values())
        exact_ids = tuple(sorted(identifier for identifier, result in at_values.items() if result == optimum))
        if len({coefficients[identifier] for identifier in exact_ids}) < 3:
            continue
        payload = {
            "kind": "MULTIWAY_OPTIMAL_BOUNDARY",
            "parameter": _exact_json(theta),
            "policies": list(exact_ids),
        }
        degeneracies.append(
            {
                "degeneracy_id": _stable_id("phase-degeneracy", payload),
                "kind": "MULTIWAY_OPTIMAL_BOUNDARY",
                "policy_ids": list(exact_ids),
                "parameter": _exact_json(theta),
            }
        )
    degeneracies.sort(key=lambda item: item["degeneracy_id"])

    stability = None
    stability_parameter = None
    if "stability" in artifact:
        supplied = _object(artifact.get("stability"), "phase analysis.stability")
        stability_parameter = _exact(supplied.get("parameter"), "phase analysis.stability.parameter")
        theta = stability_parameter
        if not 0 <= theta <= 1:
            raise _DecodeError("phase stability parameter lies outside [0, 1]")
        on_boundary = [item for item in boundaries if rational(item["parameter"]) == theta]
        if on_boundary:
            state = "ON_CERTIFIED_PHASE_BOUNDARY"
            lower = upper = theta
            lower_closed = upper_closed = True
            distance: Optional[Fraction] = Fraction(0)
            nearest = sorted(item["boundary_id"] for item in on_boundary)
        else:
            match = None
            for fact, record in zip(region_facts, regions):
                lower_value, upper_value, lc, uc, _winner_ids = fact
                if (theta > lower_value or (theta == lower_value and lc)) and (
                    theta < upper_value or (theta == upper_value and uc)
                ):
                    match = record
                    break
            if match is None:
                raise _DecodeError("phase stability parameter is not covered by the derived partition")
            interval = match["parameter_interval"]
            lower, upper = rational(interval["lower"]), rational(interval["upper"])
            lower_closed, upper_closed = interval["lower_closed"], interval["upper_closed"]
            if boundaries:
                distances = {
                    item["boundary_id"]: abs(theta - rational(item["parameter"]))
                    for item in boundaries
                }
                distance = min(distances.values())
                nearest = sorted(identifier for identifier, item in distances.items() if item == distance)
                state = "STABLE_WITHIN_CERTIFIED_REGION"
            else:
                distance = None
                nearest = []
                state = "NO_PHASE_BOUNDARY_IN_DECLARED_DOMAIN"
        stability = {
            "parameter": _exact_json(theta),
            "state": state,
            "winner_ids": list(winners(theta)),
            "stability_interval": {
                "lower": _exact_json(lower), "upper": _exact_json(upper),
                "lower_closed": lower_closed, "upper_closed": upper_closed,
            },
            "boundary_distance_metric": "ABSOLUTE_SCALAR_PARAMETER",
            "nearest_boundary_ids": nearest,
            "boundary_distance": _exact_json(distance) if distance is not None else None,
        }

    profile_expected = {
        "profile_id": PHASE_PROFILE,
        "profile_version": "1",
        "objective": "MINIMIZE",
        "parameter": "theta",
        "parameter_domain": {
            "lower": _exact_json(Fraction(0)), "upper": _exact_json(Fraction(1)),
            "lower_closed": True, "upper_closed": True,
        },
        "weight_map": ["theta", "1-theta"],
        "policy_tolerance": _exact_json(tolerance),
    }
    identity = {
        "schema_version": PHASE_SCHEMA_VERSION,
        "profile_id": PHASE_PROFILE,
        "source_r_root": source_root,
        "stability_parameter": _exact_json(stability_parameter) if stability_parameter is not None else None,
        "policy_tolerance": _exact_json(tolerance),
    }
    expected = {
        "record_type": "PhaseAnalysisRecord",
        "schema_version": PHASE_SCHEMA_VERSION,
        "analysis_id": _stable_id("phase-analysis", identity),
        "profile": profile_expected,
        "source_r_root": source_root,
        "coordinate_schema_hash": schema_root,
        "family_completeness": completeness,
        "claim_scope": "RELATIVE_TO_DECLARED_FAMILY",
        "arithmetic_profile": "EXACT_RATIONAL",
        "solver_trust_profile": "EXACT_RECOMPUTED",
        "policies": policies,
        "regions": regions,
        "boundaries": boundaries,
        "ties": ties,
        "degeneracies": degeneracies,
        "verification_program": PHASE_PROGRAM,
        "claim_limitations": [
            "REGISTERED_PROFILE_ONLY",
            "NO_PHASE_CLAIM_FROM_ACTIVE_COORDINATES_OR_BOTTLENECKS",
            "NO_CLAIM_BEYOND_DECLARED_FAMILY_COMPLETENESS",
        ],
    }
    if stability is not None:
        expected["stability"] = stability
    facts = {
        "source_root": source_root,
        "coordinate_schema_hash": schema_root,
        "policy_count": len(policies),
        "region_count": len(regions),
        "boundary_count": len(boundaries),
        "tie_count": len(ties),
    }
    return expected, facts


def verify_phase_analysis_record(
    artifact: Mapping[str, Any], source_r: Mapping[str, Any]
) -> VerificationResult:
    """Verify a canonical ``PhaseAnalysisRecord`` against its portable source R."""
    result = VerificationResult(ok=False, status=Status.FAILED)
    if not isinstance(artifact, Mapping):
        result.record("phase_wire", False, "phase analysis must be a JSON object")
        return result.finish()
    if artifact.get("schema_version") != PHASE_SCHEMA_VERSION:
        result.status = Status.UNSUPPORTED_PROFILE
        result.record(
            "phase_profile", False,
            f"unsupported phase schema version {artifact.get('schema_version')!r}",
        )
        return result.finish()
    profile = artifact.get("profile")
    profile_id = profile.get("profile_id") if isinstance(profile, Mapping) else None
    profile_version = profile.get("profile_version") if isinstance(profile, Mapping) else None
    if profile_id != PHASE_PROFILE or profile_version != "1":
        result.status = Status.UNSUPPORTED_PROFILE
        result.record(
            "phase_profile",
            False,
            f"unregistered phase profile/version {profile_id!r}@{profile_version!r}",
        )
        return result.finish()
    try:
        artifact_root = _canonical_preflight(artifact, "phase analysis")
        _canonical_preflight(source_r, "source R")
        expected, facts = _phase_expected(artifact, source_r)
    except _UnsupportedProfileError as error:
        result.status = Status.UNSUPPORTED_PROFILE
        result.record("phase_profile", False, str(error))
        return result.finish()
    except (_DecodeError, ArithError, CanonicalError, TypeError, ValueError) as error:
        result.record("phase_decode", False, str(error))
        return result.finish()

    result.record("phase_profile", True, f"{PHASE_PROFILE} schema {PHASE_SCHEMA_VERSION}")
    result.record(
        "phase_source_binding",
        artifact.get("source_r_root") == facts["source_root"]
        and artifact.get("coordinate_schema_hash") == facts["coordinate_schema_hash"],
        "source R and coordinate schema roots independently recomputed",
    )
    result.record(
        "phase_policy_derivation",
        artifact.get("policies") == expected["policies"],
        f"{facts['policy_count']} source realization policies rederived",
    )
    partition_ok = all(
        artifact.get(field) == expected[field]
        for field in ("regions", "boundaries", "ties", "degeneracies")
    )
    result.record(
        "phase_partition",
        partition_ok,
        (
            f"{facts['region_count']} exact cells, {facts['boundary_count']} true boundaries, "
            f"and {facts['tie_count']} ties independently reconstructed"
        ),
    )
    result.record(
        "phase_stability",
        artifact.get("stability") == expected.get("stability"),
        "winner set, cell, and nearest-boundary distance rederived",
    )
    result.record(
        "phase_identity",
        artifact.get("analysis_id") == expected["analysis_id"],
        "analysis identity independently resealed from source, profile, tolerance, and probe",
    )
    result.record(
        "phase_wire",
        dict(artifact) == expected,
        "entire canonical v1.2 record equals the independent reconstruction",
    )
    result.report.update({**facts, "artifact_root": artifact_root})
    if not result.violations:
        result.status = Status.VERIFIED_RELATIVE
    return result.finish()


# ---------------------------------------------------------------------------
# Certified delta: independent diff, classification and typed propagation
# ---------------------------------------------------------------------------
_ACTIONS = {
    "NO_OPERATION": 0,
    "REVALIDATE_ONLY": 1,
    "RECOMPUTE_VALUE": 2,
    "REPRICE": 3,
    "RE_EMBED": 4,
    "RE_EVALUATE": 5,
    "REOPEN": 6,
    "BLOCK": 7,
}

_EDGE = {
    "DERIVES_VALUE_FROM": ("RECOMPUTE_VALUE", True),
    "DEPENDS_ON_VALIDITY_OF": ("REVALIDATE_ONLY", True),
    "DEPENDS_ON_MEMBERSHIP_OF": ("REOPEN", True),
    "DEPENDS_ON_SCOPE_OF": ("REOPEN", True),
    "DEPENDS_ON_PRICE_OF": ("REPRICE", True),
    "DEPENDS_ON_EMBEDDING_OF": ("RE_EMBED", True),
    "DEPENDS_ON_CAPABILITY_OF": ("REOPEN", True),
    "DEPENDS_ON_RULE_VERSION": ("REVALIDATE_ONLY", True),
    "DEPENDS_ON_GENERATOR_VERSION": ("REOPEN", True),
    "DEPENDS_ON_TOOL_IDENTITY": ("RE_EVALUATE", True),
    "DEPENDS_ON_SIGNATURE": ("BLOCK", True),
    "DEPENDS_ON_CONTEXT_FINGERPRINT": ("REVALIDATE_ONLY", True),
    "DEPENDS_ON_CLOCK": ("BLOCK", True),
    "DEPENDS_ON_ACCESS": ("BLOCK", True),
    "DERIVED_FROM_VERSION": ("NO_OPERATION", False),
    "PROVES": ("BLOCK", True),
    "WITNESSES": ("RECOMPUTE_VALUE", True),
}

_VALIDITY = {
    "NO_OPERATION": "PRESERVE_TARGET",
    "REVALIDATE_ONLY": "REVALIDATE_TARGET",
    "BLOCK": "BLOCK_TARGET",
}

_KIND_ALIAS = {
    "PRICE": "PRICE_MODEL", "PRICE_MODEL": "PRICE_MODEL",
    "SERVICE_COEFFICIENTS": "PRICE_MODEL", "TARIFF": "PRICE_MODEL",
    "EMBEDDING": "EMBEDDING_MODEL", "EMBEDDING_MODEL": "EMBEDDING_MODEL",
    "PLACEMENT": "EMBEDDING_MODEL", "ROUTING": "EMBEDDING_MODEL",
    "CAPABILITY": "CAPABILITY_MODEL", "CAPABILITY_MODEL": "CAPABILITY_MODEL",
    "PRIMITIVE": "CAPABILITY_MODEL", "HIERARCHY": "CAPABILITY_MODEL",
    "LEGALITY_RULE": "CAPABILITY_MODEL", "TRANSFORMATION_RULE": "CAPABILITY_MODEL",
    "SEMANTICS": "COMPUTATION_SEMANTICS", "COMPUTATION": "COMPUTATION_SEMANTICS",
    "COMPUTATION_SEMANTICS": "COMPUTATION_SEMANTICS", "WORKLOAD": "WORKLOAD",
    "GENERATOR": "GENERATOR", "REGISTRY": "CANDIDATE_REGISTRY",
    "CANDIDATE_REGISTRY": "CANDIDATE_REGISTRY", "SCOPE": "DECISION_SCOPE",
    "DECISION_SCOPE": "DECISION_SCOPE", "EVIDENCE": "EVIDENCE_RECORD",
    "EVIDENCE_RECORD": "EVIDENCE_RECORD", "TECHNOLOGY_CONTRACT": "TECHNOLOGY_CONTRACT",
    "METADATA": "METADATA", "ANNOTATION": "METADATA", "UNKNOWN": "UNKNOWN",
}

_UNCONDITIONAL_KIND = {
    "CAPABILITY_MODEL": "REOPEN", "COMPUTATION_SEMANTICS": "REOPEN",
    "WORKLOAD": "REOPEN", "GENERATOR": "REOPEN",
    "CANDIDATE_REGISTRY": "REOPEN", "DECISION_SCOPE": "REOPEN",
}
_DEFAULT_CLASS = {"PRICE_MODEL": "PRICE", "EMBEDDING_MODEL": "EMBEDDING", "METADATA": "METADATA"}
_CLASS_ACTION = {
    "PRICE": "REPRICE", "EMBEDDING": "RE_EMBED", "CAPABILITY": "REOPEN",
    "REGISTRY": "REOPEN", "SEMANTICS": "REOPEN", "GENERATOR": "REOPEN",
    "WORKLOAD": "REOPEN", "SCOPE": "REOPEN", "VALIDITY": "REVALIDATE_ONLY",
    "METADATA": "NO_OPERATION", "UNKNOWN": "REOPEN",
}
_PROPERTY_TOKENS = {
    "PRICE": set("price prices pricing price_function price_model cost costs tariff rate rates fee fees charge coefficient coefficients service_coefficient service_coefficients service_function unit_price".split()),
    "EMBEDDING": set("embedding embeddings embedding_model embedding_constraint embedding_constraints placement placements routing route routes layout topology physical_model feasibility feasibility_function site sites floorplan wiring interconnect port_map".split()),
    "CAPABILITY": set("capability capabilities capability_gate capability_gates capability_predicate capability_predicates primitive primitives hierarchy hierarchies transformation transformations legality legality_rule legality_rules legal_transformations gate gates permitted_operations".split()),
    "REGISTRY": set("registry registries membership members candidates candidate_registry catalog catalogue roster".split()),
    "SEMANTICS": set("semantics computation computation_semantics algorithm correctness solver arithmetic arithmetic_profile rounding objective_semantics evaluation_semantics mapping_table_version".split()),
    "GENERATOR": set("generator generators generator_version generator_versions emitted_family".split()),
    "WORKLOAD": set("workload workloads validity_domain certified_validity operating_envelope operating_point duty_point".split()),
    "SCOPE": set("scope scopes scope_id decision_scope accounting_scope resource_scope computation_scope claim_scope".split()),
    "VALIDITY": set("validity valid_from valid_until expiry expires_at status evidence_status revocation revoked attestation integrity_signature signature_status signature_state key_id freshness clock_assertion".split()),
    "METADATA": set("title label labels description notes note comment comments tag tags owner display_name author annotation annotations documentation ui created_at created_by updated_at timestamp version case_version object_version content_hash parent_hashes lineage".split()),
}
_REASON_FLOOR = {
    "PRICE_UPDATE": "REPRICE", "SERVICE_COEFFICIENT_UPDATE": "REPRICE",
    "EMBEDDING_UPDATE": "RE_EMBED", "PLACEMENT_CHANGE": "RE_EMBED",
    "ROUTING_CHANGE": "RE_EMBED", "SIGNATURE_STATUS_CHANGE": "REVALIDATE_ONLY",
    "EVIDENCE_STATUS_CHANGE": "REVALIDATE_ONLY", "CAPABILITY_CHANGE": "REOPEN",
    "PRIMITIVE_ADDED": "REOPEN", "PRIMITIVE_REMOVED": "REOPEN",
    "LEGALITY_RULE_CHANGE": "REOPEN", "COMPUTATION_SEMANTICS_CHANGE": "REOPEN",
    "CORRECTNESS_FIX": "REOPEN", "WORKLOAD_OUTSIDE_CERTIFIED_VALIDITY": "REOPEN",
    "OUTSIDE_CERTIFIED_VALIDITY": "REOPEN", "GENERATOR_VERSION_CHANGE": "REOPEN",
    "REGISTRY_MEMBERSHIP_CHANGE": "REOPEN", "SCOPE_CHANGE": "REOPEN",
}


def _max_action(actions: Iterable[str]) -> str:
    best = "NO_OPERATION"
    for action in actions:
        resolved = action if action in _ACTIONS else "REOPEN"
        if _ACTIONS[resolved] > _ACTIONS[best]:
            best = resolved
    return best


def _segments(path: str) -> Tuple[str, ...]:
    normalized = path.strip().lower().replace("[", ".").replace("]", ".")
    return tuple(item for item in normalized.split(".") if item)


def _property_class(path: str) -> str:
    matches = [name for token in _segments(path) for name, values in _PROPERTY_TOKENS.items() if token in values]
    if not matches:
        return "UNKNOWN"
    return max(matches, key=lambda name: _ACTIONS[_CLASS_ACTION[name]])


def _reason_code(reason: Any) -> str:
    text = str(reason or "").upper()
    out = []
    previous_sep = False
    for char in text:
        if char.isalnum():
            out.append(char)
            previous_sep = False
        elif not previous_sep:
            out.append("_")
            previous_sep = True
    return "".join(out).strip("_")


def _object_kind(value: Any) -> str:
    if isinstance(value, str):
        raw = value
    elif isinstance(value, Mapping):
        raw = next((value[key] for key in ("object_kind", "kind", "object_type") if key in value), None)
    else:
        raw = None
    return _KIND_ALIAS.get(str(raw or "UNKNOWN").strip().upper(), "UNKNOWN")


def _classify(event: Mapping[str, Any], current_case: Mapping[str, Any]) -> str:
    objects = _object(current_case.get("objects") or {}, "current case.objects")
    changed_object = _string(event.get("changed_object"), "delta.change_event.changed_object")
    kind = _object_kind(objects.get(changed_object))
    floor = _REASON_FLOOR.get(_reason_code(event.get("declared_reason")), "NO_OPERATION")
    if kind in _UNCONDITIONAL_KIND:
        return _max_action((_UNCONDITIONAL_KIND[kind], floor))
    properties = _ids(event.get("changed_properties"), "delta.change_event.changed_properties")
    if not properties:
        return _max_action(("REOPEN", floor))
    actions = []
    for path in properties:
        classification = _property_class(path)
        if classification == "UNKNOWN" and kind in _DEFAULT_CLASS:
            classification = _DEFAULT_CLASS[kind]
        actions.append(_CLASS_ACTION[classification])
    actions.append(floor)
    return _max_action(actions)


def _canonically_equal(left: Any, right: Any) -> bool:
    return canonical_json(left) == canonical_json(right)


def _join(path: str, key: str) -> str:
    return f"{path}.{key}" if path else key


def _walk_diff(path: str, prior: Any, current: Any, out: Dict[str, dict]) -> None:
    if _canonically_equal(prior, current):
        return
    if isinstance(prior, Mapping) and isinstance(current, Mapping):
        for key in sorted(set(prior) | set(current)):
            child = _join(path, str(key))
            if key not in prior:
                out[child] = {"change": "ADDED", "prior": None, "current": current[key]}
            elif key not in current:
                out[child] = {"change": "REMOVED", "prior": prior[key], "current": None}
            else:
                _walk_diff(child, prior[key], current[key], out)
        return
    if isinstance(prior, (list, tuple)) and isinstance(current, (list, tuple)):
        for index in range(max(len(prior), len(current))):
            child = f"{path}[{index}]" if path else f"[{index}]"
            if index >= len(prior):
                out[child] = {"change": "ADDED", "prior": None, "current": current[index]}
            elif index >= len(current):
                out[child] = {"change": "REMOVED", "prior": prior[index], "current": None}
            else:
                _walk_diff(child, prior[index], current[index], out)
        return
    out[path or "$"] = {"change": "MODIFIED", "prior": prior, "current": current}


def _path_category(path: str) -> str:
    tokens = set(_segments(path))
    checks = (
        ("PHASE", {"phase", "phases", "boundary", "boundaries", "stability"}),
        ("CERTIFICATE", {"certificate", "certificates", "winner", "winners", "margin", "approvals"}),
        ("DEPENDENCY", {"dependency", "dependencies", "edge", "edges", "graph", "lineage"}),
        ("EVIDENCE", {"evidence", "uncertainty", "provenance", "applicability", "validity", "attestation"}),
        ("GEOMETRY", {"geometry", "gamma", "frontier", "vertices", "fiber", "fibers", "envelope"}),
        ("SIGNATURE", {"signature", "signatures", "coordinate", "coordinates", "schema"}),
        ("FAMILY", {"family", "registry", "realization", "realizations", "candidate", "candidates", "members", "completeness"}),
    )
    return next((name for name, vocabulary in checks if tokens & vocabulary), "OTHER")


_DELTA_CATEGORIES = ("FAMILY", "SIGNATURE", "GEOMETRY", "EVIDENCE", "DEPENDENCY", "CERTIFICATE", "PHASE", "OTHER")


def _field_deltas(prior: Any, current: Any) -> List[dict]:
    detail: Dict[str, dict] = {}
    _walk_diff("", prior, current, detail)
    return [
        {
            "path": path,
            "change": detail[path]["change"],
            "category": _path_category(path),
            "prior": detail[path]["prior"],
            "current": detail[path]["current"],
        }
        for path in sorted(detail)
    ]


def _strip_indices(path: str) -> str:
    result = []
    depth = 0
    for char in path:
        if char == "[":
            depth += 1
        elif char == "]":
            depth = max(0, depth - 1)
        elif depth == 0:
            result.append(char)
    return "".join(result)


def _property_closure(paths: Iterable[str]) -> Set[str]:
    closure: Set[str] = set()
    for raw in paths:
        if not raw:
            continue
        for variant in {raw, _strip_indices(raw)}:
            if not variant:
                continue
            closure.add(variant)
            parts = variant.split(".")
            for cut in range(1, len(parts)):
                closure.add(".".join(parts[:cut]))
    return closure


def _object_relative(paths: Iterable[str], object_id: str) -> Set[str]:
    result: Set[str] = set()
    for path in paths:
        result.add(path)
        parts = _strip_indices(path).split(".")
        if object_id in parts:
            remainder = ".".join(parts[parts.index(object_id) + 1 :])
            if remainder:
                result.add(remainder)
    return result


def _edges(raw_edges: Any) -> List[dict]:
    result: List[dict] = []
    identifiers: Set[str] = set()
    signatures: Set[Tuple[Any, ...]] = set()
    for index, raw in enumerate(_array(raw_edges, "dependency edges")):
        edge = _object(raw, f"dependency edges[{index}]")
        _keys(
            edge,
            (
                "edge_id", "source", "target", "edge_type", "minimum_action",
                "transitive", "validity_propagation_rule", "edge_version",
                "source_property", "scope", "invalidation_predicate",
            ),
            (),
            f"dependency edges[{index}]",
        )
        identifier = _string(edge.get("edge_id"), f"dependency edges[{index}].edge_id")
        if identifier in identifiers:
            raise _DecodeError(f"dependency graph repeats edge identifier {identifier!r}")
        identifiers.add(identifier)
        source = _string(edge.get("source"), f"dependency edges[{index}].source")
        target = _string(edge.get("target"), f"dependency edges[{index}].target")
        edge_type = _string(edge.get("edge_type"), f"dependency edges[{index}].edge_type")
        if edge_type not in _EDGE:
            raise _DecodeError(f"dependency edge {identifier!r} has unknown type {edge_type!r}")
        action, transitive = _EDGE[edge_type]
        if edge.get("minimum_action") != action or edge.get("transitive") is not transitive:
            raise _DecodeError(f"dependency edge {identifier!r} forges registered semantics")
        expected_validity = _VALIDITY.get(action, "MARK_TARGET_STALE")
        if edge.get("validity_propagation_rule") != expected_validity:
            raise _DecodeError(f"dependency edge {identifier!r} has a forged validity rule")
        if edge.get("edge_version") != "1":
            raise _DecodeError(f"dependency edge {identifier!r} has unsupported edge version")
        source_property = _string(edge.get("source_property"), f"dependency edges[{index}].source_property")
        scope = _string(edge.get("scope"), f"dependency edges[{index}].scope")
        predicate = _string(edge.get("invalidation_predicate"), f"dependency edges[{index}].invalidation_predicate")
        signature = (source, target, edge_type, source_property, scope, predicate)
        if signature in signatures:
            raise _DecodeError(f"dependency graph repeats the edge {signature!r}")
        signatures.add(signature)
        result.append(dict(edge))

    nodes = {edge["source"] for edge in result} | {edge["target"] for edge in result}
    indegree = {node: 0 for node in nodes}
    outgoing: Dict[str, List[str]] = {node: [] for node in nodes}
    for edge in result:
        indegree[edge["target"]] += 1
        outgoing[edge["source"]].append(edge["target"])
    queue = sorted(node for node, degree in indegree.items() if degree == 0)
    visited = 0
    while queue:
        node = queue.pop(0)
        visited += 1
        for target in sorted(outgoing[node]):
            indegree[target] -= 1
            if indegree[target] == 0:
                queue.append(target)
                queue.sort()
    if visited != len(nodes):
        raise _DecodeError("dependency graph contains a cycle")
    return result


def _trace(edges: Sequence[dict], changed_object: str, paths: Sequence[str]) -> List[dict]:
    outgoing: Dict[str, List[dict]] = {}
    for edge in edges:
        outgoing.setdefault(edge["source"], []).append(edge)
    initial = _property_closure(_object_relative(paths, changed_object)) or None
    frontier: List[Tuple[str, Optional[Set[str]]]] = [(changed_object, initial)]
    seen: Set[str] = set()
    traversed: List[dict] = []
    while frontier:
        node, properties = frontier.pop()
        for edge in sorted(outgoing.get(node, []), key=lambda item: item["edge_id"]):
            source_property = edge["source_property"]
            triggered = properties is None or source_property == "*" or source_property in properties
            if edge["edge_id"] in seen or not triggered:
                continue
            seen.add(edge["edge_id"])
            traversed.append(
                {
                    "edge_id": edge["edge_id"], "source": edge["source"],
                    "target": edge["target"], "edge_type": edge["edge_type"],
                    "source_property": edge["source_property"],
                    "minimum_action": edge["minimum_action"],
                    "transitive": edge["transitive"],
                }
            )
            if edge["transitive"] and edge["minimum_action"] != "NO_OPERATION":
                frontier.append((edge["target"], None))
    return sorted(traversed, key=lambda item: item["edge_id"])


def _case_parts(case: Mapping[str, Any], where: str) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    objects = _object(case.get("objects") or {}, f"{where}.objects")
    certificates = _object(case.get("certificates") or {}, f"{where}.certificates")
    return dict(objects), {str(identifier): artifact for identifier, artifact in certificates.items()}


def _certificate_dependencies(identifier: str, artifact: Any) -> Set[str]:
    result = {identifier}
    if artifact is None:
        return result
    if isinstance(artifact, (list, tuple)):
        result.update(str(value) for value in artifact)
        return result
    record = _object(artifact, f"certificate {identifier!r}")
    for key in ("dependencies", "evidence_roots", "objects"):
        values = record.get(key, ()) or ()
        result.update(str(value) for value in _array(values, f"certificate {identifier!r}.{key}"))
    for key in ("complete_registry_hash", "retained_registry_hash"):
        value = record.get(key)
        if value:
            result.add(str(value))
    return result


def _winners(certificates: Mapping[str, Any]) -> List[str]:
    result: Set[str] = set()
    for identifier, raw in certificates.items():
        record = _object(raw, f"certificate {identifier!r}")
        for key in ("selected", "ties"):
            result.update(str(value) for value in _array(record.get(key, ()) or (), f"certificate {identifier!r}.{key}"))
    return sorted(result)


def _margin(certificates: Mapping[str, Any]) -> Any:
    for identifier, raw in sorted(certificates.items()):
        record = _object(raw, f"certificate {identifier!r}")
        if record.get("margin") is not None:
            return record["margin"]
    return None


def _replacement_roots(replacements: Mapping[str, Any]) -> Dict[str, str]:
    roots = {}
    for identifier, artifact in sorted(replacements.items()):
        key = str(identifier)
        record = _object(artifact, f"replacement {key!r}")
        declared = record.get("certificate_id")
        if declared is not None and str(declared) != key:
            raise _DecodeError(f"replacement key {key!r} does not match certificate_id {declared!r}")
        roots[key] = content_hash(record)
    return roots


def _phase_binding(
    record: Optional[Mapping[str, Any]], source: Optional[Mapping[str, Any]], where: str
) -> Optional[str]:
    if record is None and source is None:
        return None
    if record is None or source is None:
        raise _DecodeError(f"{where} phase evidence and source R must be supplied together")
    result = verify_phase_analysis_record(record, source)
    if not result.ok:
        raise _DecodeError(f"{where} phase evidence failed semantic verification: {'; '.join(result.violations)}")
    return content_hash(record)


def _delta_expected(
    record: Mapping[str, Any],
    prior_case: Mapping[str, Any],
    current_case: Mapping[str, Any],
    dependency_edges: Sequence[Mapping[str, Any]],
    replacements: Mapping[str, Any],
    prior_phase: Optional[Mapping[str, Any]],
    current_phase: Optional[Mapping[str, Any]],
    prior_phase_source_r: Optional[Mapping[str, Any]],
    current_phase_source_r: Optional[Mapping[str, Any]],
) -> Dict[str, Any]:
    _keys(
        record,
        (
            "record_type", "schema_version", "evidence_id", "delta", "delta_root",
            "changed_fields", "category_changes", "traversed_edges",
            "edge_types_traversed", "completeness_changes",
            "minimum_recomputation_claim", "replacement_roots",
            "verification_status", "verification_program", "fail_closed_policy",
        ),
        ("phase_evidence",),
        "certified delta",
    )
    delta = _object(record.get("delta"), "certified delta.delta")
    _keys(
        delta,
        (
            "delta_id", "prior_root", "current_root", "change_event", "classification",
            "affected_paths", "preserved", "invalidated", "recomputed",
            "prior_winners", "current_winners",
        ),
        (
            "prior_margin", "current_margin", "residual_uncertainty", "approvals",
            "reopen_reason",
        ),
        "certified delta.delta",
    )
    event = _object(delta.get("change_event"), "certified delta.delta.change_event")
    _keys(
        event,
        ("event_id", "changed_object", "current_version", "declared_reason", "changed_properties"),
        ("previous_version", "timestamp", "authority"),
        "certified delta.delta.change_event",
    )
    for key in ("event_id", "changed_object", "current_version", "declared_reason"):
        _string(event.get(key), f"certified delta.delta.change_event.{key}")
    for key in ("previous_version", "timestamp", "authority"):
        if key in event:
            _string(event[key], f"certified delta.delta.change_event.{key}")

    prior_objects, prior_certificates = _case_parts(prior_case, "prior case")
    current_objects, current_certificates = _case_parts(current_case, "current case")
    fields = _field_deltas(prior_case, current_case)
    declared_paths = _ids(event.get("changed_properties"), "certified delta.delta.change_event.changed_properties")
    effective_paths = tuple(sorted(set(item["path"] for item in fields) | set(declared_paths)))
    expected_event = dict(event)
    expected_event["changed_properties"] = list(effective_paths)

    edges = _edges(dependency_edges)
    traversed = _trace(edges, event["changed_object"], effective_paths)
    classification = _classify(expected_event, current_case)
    affected: Dict[str, str] = {}
    if classification != "NO_OPERATION":
        affected[event["changed_object"]] = classification
    for edge in traversed:
        action = _max_action((classification, edge["minimum_action"]))
        if action != "NO_OPERATION":
            affected[edge["target"]] = _max_action((affected.get(edge["target"], "NO_OPERATION"), action))
    affected = dict(sorted(affected.items()))
    minimum = _max_action((classification, *affected.values()))

    affected_ids = set(affected)
    invalidated = sorted(
        identifier
        for identifier, artifact in current_certificates.items()
        if _certificate_dependencies(identifier, artifact) & affected_ids
    )
    preserved = set(identifier for identifier in current_certificates if identifier not in invalidated)
    preserved.update(identifier for identifier in current_objects if identifier not in affected_ids)
    replacement_roots = _replacement_roots(replacements)
    surviving = {
        identifier: artifact
        for identifier, artifact in current_certificates.items()
        if identifier not in set(invalidated)
    }
    surviving.update(replacements)

    category_changes = {
        category: sorted(item["path"] for item in fields if item["category"] == category)
        for category in _DELTA_CATEGORIES
    }
    completeness = [item["path"] for item in fields if "completeness" in item["path"].lower()]
    prior_phase_root = _phase_binding(prior_phase, prior_phase_source_r, "prior")
    current_phase_root = _phase_binding(current_phase, current_phase_source_r, "current")

    delta_root = content_hash(delta)
    identity = {
        "schema_version": DELTA_SCHEMA_VERSION,
        "delta_root": delta_root,
        "changed_fields": fields,
        "traversed_edges": traversed,
        "replacement_roots": replacement_roots,
        "prior_phase_root": prior_phase_root,
        "current_phase_root": current_phase_root,
    }
    facts = {
        "fields": fields,
        "category_changes": category_changes,
        "completeness": completeness,
        "event": expected_event,
        "edges": edges,
        "traversed": traversed,
        "classification": classification,
        "affected": affected,
        "minimum": minimum,
        "invalidated": invalidated,
        "preserved": sorted(preserved),
        "replacement_roots": replacement_roots,
        "prior_winners": _winners(prior_certificates),
        "current_winners": _winners(surviving),
        "prior_margin": _margin(prior_certificates),
        "current_margin": _margin(surviving),
        "prior_phase_root": prior_phase_root,
        "current_phase_root": current_phase_root,
        "delta_root": delta_root,
        "evidence_id": _stable_id("certified-delta", identity),
    }
    return facts


def verify_certified_delta_record(
    record: Mapping[str, Any],
    prior_case: Mapping[str, Any],
    current_case: Mapping[str, Any],
    dependency_edges: Sequence[Mapping[str, Any]],
    *,
    replacements: Optional[Mapping[str, Any]] = None,
    prior_phase: Optional[Mapping[str, Any]] = None,
    current_phase: Optional[Mapping[str, Any]] = None,
    prior_phase_source_r: Optional[Mapping[str, Any]] = None,
    current_phase_source_r: Optional[Mapping[str, Any]] = None,
) -> VerificationResult:
    """Verify a portable ``CertifiedDeltaRecord`` without producer imports."""
    result = VerificationResult(ok=False, status=Status.FAILED)
    if not isinstance(record, Mapping):
        result.record("delta_wire", False, "certified delta must be a JSON object")
        return result.finish()
    if record.get("schema_version") != DELTA_SCHEMA_VERSION:
        result.status = Status.UNSUPPORTED_PROFILE
        result.record(
            "delta_profile", False,
            f"unsupported certified-delta schema version {record.get('schema_version')!r}",
        )
        return result.finish()
    if record.get("verification_program") != DELTA_PROGRAM:
        result.status = Status.UNSUPPORTED_PROFILE
        result.record(
            "delta_profile", False,
            f"unregistered certified-delta verification program {record.get('verification_program')!r}",
        )
        return result.finish()
    replacements = replacements or {}
    try:
        artifact_root = _canonical_preflight(record, "certified delta")
        prior_root = _canonical_preflight(prior_case, "prior case")
        current_root = _canonical_preflight(current_case, "current case")
        facts = _delta_expected(
            record, prior_case, current_case, dependency_edges, replacements,
            prior_phase, current_phase, prior_phase_source_r, current_phase_source_r,
        )
    except (_DecodeError, ArithError, CanonicalError, TypeError, ValueError) as error:
        result.record("delta_decode", False, str(error))
        return result.finish()

    delta = _object(record.get("delta"), "certified delta.delta")
    result.record("delta_profile", True, f"CertifiedDeltaRecord schema {DELTA_SCHEMA_VERSION}")
    result.record(
        "delta_case_roots",
        delta.get("prior_root") == prior_root and delta.get("current_root") == current_root,
        "canonical before/after roots independently recomputed",
    )
    result.record(
        "delta_fields",
        record.get("changed_fields") == facts["fields"]
        and record.get("category_changes") == facts["category_changes"]
        and record.get("completeness_changes") == facts["completeness"],
        "canonical field, category, and completeness deltas independently reconstructed",
    )
    result.record(
        "delta_event",
        delta.get("change_event") == facts["event"],
        "declared paths include the authoritative canonical diff",
    )
    result.record(
        "delta_traversal",
        record.get("traversed_edges") == facts["traversed"]
        and record.get("edge_types_traversed") == sorted({edge["edge_type"] for edge in facts["traversed"]}),
        f"{len(facts['traversed'])} registered typed edges independently traversed",
    )
    result.record(
        "delta_minimum_action",
        delta.get("classification") == facts["minimum"]
        and record.get("minimum_recomputation_claim") == {
            "action": facts["minimum"],
            "basis": "CANONICAL_DIFF_PLUS_TYPED_REACHABLE_DEPENDENCY_CLOSURE",
        }
        and delta.get("affected_paths") == [
            f"{identifier}:{action}" for identifier, action in facts["affected"].items()
        ],
        f"minimum sufficient action independently derived as {facts['minimum']}",
    )
    result.record(
        "delta_lifecycle",
        delta.get("invalidated") == facts["invalidated"]
        and delta.get("preserved") == facts["preserved"]
        and delta.get("recomputed") == sorted(facts["replacement_roots"])
        and delta.get("prior_winners") == facts["prior_winners"]
        and delta.get("current_winners") == facts["current_winners"]
        and delta.get("prior_margin") == facts["prior_margin"]
        and delta.get("current_margin") == facts["current_margin"],
        "preservation, invalidation, replacements, winners, and margins independently derived",
    )
    result.record(
        "delta_replacements",
        record.get("replacement_roots") == facts["replacement_roots"],
        "every recomputed artifact has an independently hashed replacement",
    )
    phase_expected = None
    if facts["prior_phase_root"] is not None or facts["current_phase_root"] is not None:
        phase_expected = {}
        if facts["prior_phase_root"] is not None:
            phase_expected["prior_phase_root"] = facts["prior_phase_root"]
        if facts["current_phase_root"] is not None:
            phase_expected["current_phase_root"] = facts["current_phase_root"]
    result.record(
        "delta_phase_roots",
        record.get("phase_evidence") == phase_expected,
        "phase roots bind semantically verified phase records and their source R records",
    )
    reopen_ok = facts["minimum"] != "REOPEN" or bool(delta.get("reopen_reason"))
    result.record("delta_reopen_reason", reopen_ok, "REOPEN requires an explicit recorded reason")
    literal_ok = (
        record.get("record_type") == "CertifiedDeltaRecord"
        and record.get("verification_status") == "INDEPENDENTLY_VERIFIED"
        and record.get("fail_closed_policy") == {
            "unresolved_change_class": "REOPEN",
            "unknown_dependency_semantics": "REOPEN",
            "incomplete_dependency_closure": "REOPEN",
        }
    )
    result.record("delta_fail_closed_profile", literal_ok, "registered fail-closed policy is intact")
    result.record(
        "delta_identity",
        record.get("delta_root") == facts["delta_root"]
        and record.get("evidence_id") == facts["evidence_id"],
        "delta root and evidence identity independently resealed",
    )
    result.report.update(
        {
            "artifact_root": artifact_root,
            "prior_root": prior_root,
            "current_root": current_root,
            "changed_field_count": len(facts["fields"]),
            "traversed_edge_count": len(facts["traversed"]),
            "minimum_action": facts["minimum"],
        }
    )
    if not result.violations:
        result.status = Status.VERIFIED
    return result.finish()
