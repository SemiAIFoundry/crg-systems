"""End-to-end verification of a portable ``.crg`` bundle (spec 39, 25).

A bundle is a directory or a zip archive with the layout of 39.  This module
opens it with nothing but ``zipfile`` and ``json``, recomputes every
inventory hash from the bytes actually stored, and hands each carried
CRG-VIR program to :func:`crg_verify.verify_vir`.  It never asks the bundle
what its own contents hash to.
"""
from __future__ import annotations

import hashlib
import json
import os
import zipfile
from typing import Any, Callable, Dict, List, Mapping, Optional, Tuple

from .canonical import CanonicalError, content_hash, decode, is_hash
from .certificate import (
    VERIFIER_VERSION,
    Level,
    Status,
    VerificationResult,
    verify_certificate,
)
from .federation import verify_federation
from .vir import verify_vir
from .extensions import ProofCheckerRegistry
from .commitment import verify_safe_commitment
from .phase_delta import verify_certified_delta_record, verify_phase_analysis_record
from .comparison import verify_comparative_workflow_evaluation
from .comparative_change import verify_comparative_change_evidence
from .cumulative_comparison import verify_cumulative_lifecycle_comparison
from .challenge import verify_decision_challenge_record
from .intake import (
    verify_registry_intake_confirmation,
    verify_registry_intake_preview,
    verify_registry_mapping_profile,
    verify_registry_source_snapshot,
)
from .portable_lifecycle import portable_lifecycle_claims

__all__ = [
    "verify_bundle", "open_bundle", "MANIFEST_REQUIRED", "MANIFEST_DISCLOSURE",
    "LEVEL_REQUIREMENTS",
]

# Section 25.2 is cumulative in this implementation profile: achieving Vn
# means every lower level passed.  Keeping the requirement names public makes
# the profile auditable by another verifier rather than an implicit control
# flow convention.
LEVEL_REQUIREMENTS = {
    Level.V0: ("integrity", "manifest", "signatures", "object_presence"),
    Level.V1: ("schema", "units", "versions", "dependency_closure",
               "migration_validity", "graph_acyclicity"),
    Level.V2: ("objective_evaluation", "comparisons", "ties", "winner_sets",
               "retained_geometry", "claim_scope"),
    Level.V3: ("solver_proofs", "bound_certificates", "regret_witnesses",
               "geometry_equivalence", "completeness_arguments"),
    Level.V4: ("attestation", "nonce", "context", "authorization", "validity",
               "revocation", "release_policy"),
}

MANIFEST_NAME = "manifest.json"
#: Specification 39.1.  All seventeen fields are mandatory, including for a
#: partial bundle.  Section 39.4 permits omissions from the *payload*, not
#: omissions from the manifest that discloses their consequences.  Earlier
#: versions accepted five fields and warned about the rest; that made a
#: manifest pointing at a nonexistent case pass V0.
MANIFEST_REQUIRED = (
    ("bundle_format_version",),
    ("crg_spec_version",),
    ("root_case_object",),
    ("object_inventory",),
    ("artifact_inventory",),
    ("proof_inventory",),
    ("content_hashes",),
    ("external_references",), ("schemas", "schema_identities"),
    ("quantity_registry_version",), ("rule_table_version",), ("signatures",),
    ("encryption",), ("redaction_state",), ("export_authority",),
    ("creation_tool",), ("requested_verification_level",),
)
# Kept as an exported compatibility symbol.  There are no optional 39.1
# disclosures: a producer uses an empty list/object when a category is empty.
MANIFEST_DISCLOSURE: Tuple[Tuple[str, ...], ...] = ()

_REQUIRED_MEMBERS = (
    MANIFEST_NAME,
    "case.json",
    "schemas/referenced-schema-manifest.json",
    "audit/events.jsonl",
    "README.md",
)
_CONTENT_PREFIXES = ("objects/sha256/", "artifacts/sha256/", "proofs/sha256/")

_MIGRATION_CLASSES = {
    "SEMANTICALLY_EQUIVALENT", "SEMANTICALLY_WIDENING",
    "SEMANTICALLY_NARROWING", "SEMANTIC_CHANGE", "LOSSY", "UNVERIFIED",
}
_MIGRATION_PROOF_TYPE = "CRG_MIGRATION_CLASSIFICATION_PROOF_V1"
_MIGRATION_PROOF_VERIFIER = "crg-model:migration-classification-v1"
_MIGRATION_IDENTITY_ALGORITHM = "CANONICAL_IDENTITY_V1"
_MIGRATION_IDENTITY_CHECKS = (
    "SOURCE_VERSION_EQUALS_TARGET_VERSION",
    "ALGORITHM_IS_CANONICAL_IDENTITY_V1",
    "CANONICAL_INPUT_HASH_EQUALS_OUTPUT_HASH",
)
_SUPPORTED_MIGRATION_TRANSFORMS = {
    "crg-schema-0.2.0-identity-v1": (
        "sha256:94a7eb8116798e598d15d60c31585c0c04793e68e6c42672072716d7630a94ea"
    ),
}
_SUPPORTED_MIGRATION_REGISTRY_VERSION = (
    "sha256:34646ece1dfa72122f8809994d34f4667eff91661b5c01c256b79519b81797df"
)


def _migration_evidence_failures(migration: Mapping[str, Any]) -> List[str]:
    """Verify migration classification without importing the producing kernel.

    Version 0.2.0 intentionally recognizes only the canonical identity
    algorithm.  A later transform remains unsupported until this independent
    verifier learns its algorithm and classification rule as well.
    """
    migration_id = migration.get("migration_id")
    prefix = f"migration {migration_id!r}"
    failures: List[str] = []
    required = (
        "migration_id", "source_schema_version", "target_schema_version",
        "migration_class", "source_object_hash", "target_object_hash",
        "transform_id", "transform_descriptor", "transform_hash",
        "migration_registry_descriptor", "migration_registry_version",
        "classification_proof",
        "classification_proof_hash", "classification_verified",
        "transform_input_hash", "transform_output_hash", "actor", "authority",
    )
    missing = [name for name in required if migration.get(name) in (None, "")]
    if missing:
        failures.append(f"{prefix} omits {missing}")
    if migration.get("migration_class") not in _MIGRATION_CLASSES:
        failures.append(f"{prefix} has unknown semantic class")
    for name in (
        "source_object_hash", "target_object_hash", "transform_hash",
        "migration_registry_version", "classification_proof_hash",
        "transform_input_hash", "transform_output_hash",
    ):
        if not is_hash(migration.get(name)):
            failures.append(f"{prefix} has invalid {name}")

    descriptor = migration.get("transform_descriptor")
    registry_descriptor = migration.get("migration_registry_descriptor")
    proof = migration.get("classification_proof")
    if (not isinstance(descriptor, dict) or not isinstance(registry_descriptor, dict)
            or not isinstance(proof, dict)):
        failures.append(
            f"{prefix} has no independently checkable registry/transform/proof objects"
        )
        return failures
    try:
        descriptor_hash = content_hash(descriptor)
        registry_hash = content_hash(registry_descriptor)
        proof_hash = content_hash(proof)
    except CanonicalError as error:
        failures.append(f"{prefix} has noncanonical classification evidence: {error}")
        return failures
    if migration.get("transform_hash") != descriptor_hash:
        failures.append(f"{prefix} transform descriptor hash does not match")
    supported_transform_hash = _SUPPORTED_MIGRATION_TRANSFORMS.get(
        str(descriptor.get("transform_id") or "")
    )
    if supported_transform_hash is None or descriptor_hash != supported_transform_hash:
        failures.append(f"{prefix} transform is not registered by this verifier release")
    if migration.get("migration_registry_version") != registry_hash:
        failures.append(f"{prefix} migration registry descriptor hash does not match")
    registered = registry_descriptor.get("transforms")
    if not isinstance(registered, list) or descriptor not in registered:
        failures.append(f"{prefix} transform is absent from its registry descriptor")
    if migration.get("migration_registry_version") != _SUPPORTED_MIGRATION_REGISTRY_VERSION:
        failures.append(f"{prefix} migration registry version is not supported")
    if migration.get("classification_proof_hash") != proof_hash:
        failures.append(f"{prefix} classification proof hash does not match")
    if migration.get("transform_id") != descriptor.get("transform_id"):
        failures.append(f"{prefix} record and descriptor name different transforms")
    if proof.get("proof_type") != _MIGRATION_PROOF_TYPE:
        failures.append(f"{prefix} uses an unsupported classification proof type")
    if proof.get("verifier_id") != _MIGRATION_PROOF_VERIFIER:
        failures.append(f"{prefix} uses an unsupported classification proof verifier")
    if proof.get("transform_id") != descriptor.get("transform_id"):
        failures.append(f"{prefix} proof names a different transform")
    if proof.get("transform_hash") != descriptor_hash:
        failures.append(f"{prefix} proof is not bound to its transform descriptor")
    if proof.get("migration_class") != descriptor.get("migration_class"):
        failures.append(f"{prefix} proof and descriptor disagree on semantic class")
    if migration.get("migration_class") != descriptor.get("migration_class"):
        failures.append(f"{prefix} record and descriptor disagree on semantic class")
    if proof.get("basis") != descriptor.get("classification_basis"):
        failures.append(f"{prefix} proof and descriptor disagree on classification basis")
    if descriptor.get("algorithm") != _MIGRATION_IDENTITY_ALGORITHM:
        failures.append(f"{prefix} uses an unsupported migration algorithm")
    if descriptor.get("transform_type") != "CRG_SCHEMA_MIGRATION_TRANSFORM_V1":
        failures.append(f"{prefix} uses an unsupported transform descriptor type")
    if descriptor.get("algorithm_version") != "1":
        failures.append(f"{prefix} uses an unsupported migration algorithm version")
    if descriptor.get("source_schema_version") != migration.get("source_schema_version"):
        failures.append(f"{prefix} descriptor disagrees on source schema version")
    if descriptor.get("target_schema_version") != migration.get("target_schema_version"):
        failures.append(f"{prefix} descriptor disagrees on target schema version")
    if descriptor.get("source_schema_version") != descriptor.get("target_schema_version"):
        failures.append(f"{prefix} identity transform changes schema version")
    if descriptor.get("migration_class") != "SEMANTICALLY_EQUIVALENT":
        failures.append(f"{prefix} identity transform is not classified equivalent")
    if tuple(proof.get("checks") or ()) != _MIGRATION_IDENTITY_CHECKS:
        failures.append(f"{prefix} identity proof has incomplete or reordered checks")
    if migration.get("transform_input_hash") != migration.get("transform_output_hash"):
        failures.append(f"{prefix} identity transform input/output hashes differ")
    if migration.get("source_object_hash") != migration.get("transform_input_hash"):
        failures.append(f"{prefix} transform is not bound to the stated source object")
    if migration.get("classification_verified") is not True:
        failures.append(f"{prefix} classification is not recorded as verified")
    return failures


def _inventory(manifest: dict) -> List[dict]:
    """Normalize the object inventory across both 39.1 spellings."""
    entries = manifest.get("object_inventory")
    if entries is None:
        entries = manifest.get("objects") or []
    out: List[dict] = []
    for item in entries:
        if not isinstance(item, dict):
            out.append({"id": None, "hash": None, "path": None, "raw": item})
            continue
        out.append({
            "id": item.get("object_id", item.get("id")),
            "object_type": item.get("object_type"),
            "hash": item.get("content_hash", item.get("hash")),
            "path": item.get("path"),
            "byte_length": item.get("byte_length"),
        })
    return out


def _root_case(manifest: dict) -> Any:
    root = manifest.get("root_case_object", manifest.get("root_case"))
    if isinstance(root, dict):
        return root.get("object_id") or root.get("id")
    return root


class _Reader:
    """Uniform read access to a directory or a zip archive."""

    def __init__(self, path: str) -> None:
        self.path = path
        self._zip: Optional[zipfile.ZipFile] = None
        if os.path.isdir(path):
            self.names = sorted(
                os.path.relpath(os.path.join(root, name), path).replace(os.sep, "/")
                for root, _dirs, files in os.walk(path) for name in files)
        elif zipfile.is_zipfile(path):
            self._zip = zipfile.ZipFile(path)
            self.names = sorted(n for n in self._zip.namelist() if not n.endswith("/"))
        else:
            raise FileNotFoundError(f"{path!r} is neither a directory nor a zip archive")

    def read(self, name: str) -> bytes:
        if self._zip is not None:
            return self._zip.read(name)
        with open(os.path.join(self.path, name), "rb") as handle:
            return handle.read()

    def json(self, name: str) -> Any:
        return decode(self.read(name).decode("utf-8"))

    def close(self) -> None:
        if self._zip is not None:
            self._zip.close()

    def manifest_hash(self) -> Tuple[Optional[str], str]:
        """Return the manifest digest anchored outside ``manifest.json``.

        Zip bundles use the deterministic container comment defined by the
        portable-artifact profile.  An expanded directory uses a
        ``manifest.sha256`` sidecar with the same JSON object.  The sidecar is
        deliberately outside the manifest hash preimage.
        """
        raw: Optional[bytes]
        if self._zip is not None:
            raw = self._zip.comment
            source = "zip archive comment"
        else:
            sidecar = "manifest.sha256"
            raw = self.read(sidecar) if sidecar in self.names else None
            source = sidecar
        if not raw:
            return None, f"{source} is absent"
        try:
            metadata = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            return None, f"{source} is not valid JSON: {error}"
        if not isinstance(metadata, dict) or not is_hash(metadata.get("manifest_hash")):
            return None, f"{source} does not contain an algorithm-tagged manifest_hash"
        return str(metadata["manifest_hash"]), source


def open_bundle(path: str) -> _Reader:
    return _Reader(path)


_DELTA_INPUT_REQUIRED = frozenset(
    {"prior_case", "current_case", "dependency_edges", "replacements"}
)
_DELTA_INPUT_OPTIONAL = frozenset(
    {
        "prior_phase", "current_phase",
        "prior_phase_source_r", "current_phase_source_r",
    }
)


def _failed_portable_claim(
    check: str, detail: str, *, claim_type: str, claim_scope: str,
) -> VerificationResult:
    """Return a normal failed sub-result instead of throwing on bad evidence."""
    failure = VerificationResult(ok=False, status=Status.FAILED)
    failure.record(check, False, detail)
    failure.report.update(
        {
            "claim_type": claim_type,
            "claim_scope": claim_scope,
            "level_attempted": Level.V2,
            "level_achieved": "NONE",
        }
    )
    return failure.finish()


def _portable_phase_delta_claims(
    declarations: List[dict],
    objects: Mapping[str, Any],
    objects_by_id: Mapping[str, Any],
) -> List[Tuple[str, VerificationResult]]:
    """Independently reconstruct every carried v1.2 phase/change claim.

    Discovery deliberately uses all three portable signals: the payload's
    record type, the inventory's declared object type, and the registered
    logical-id prefix.  Consequently, changing or deleting ``record_type``
    cannot turn a malformed claim into an opaque object that this verifier
    silently ignores.  The producer packages are never imported here.
    """
    phase_scope = "RELATIVE_TO_CARRIED_SOURCE_R_AND_DECLARED_FAMILY"
    delta_scope = "RELATIVE_TO_CARRIED_PRIOR_CURRENT_CASES_AND_TYPED_DEPENDENCY_CLOSURE"
    phase_candidates: Dict[str, Tuple[str, Any]] = {}
    delta_candidates: Dict[str, Tuple[str, Any]] = {}

    for declaration in declarations:
        object_id = str(declaration.get("id") or "")
        digest = str(declaration.get("hash") or object_id)
        payload = objects_by_id.get(object_id)
        if payload is None:
            continue
        actual_type = payload.get("record_type") if isinstance(payload, Mapping) else None
        declared_type = declaration.get("object_type")
        if (
            actual_type == "PhaseAnalysisRecord"
            or declared_type == "PhaseAnalysisRecord"
            or object_id.startswith("phase-analysis-")
        ):
            phase_candidates.setdefault(digest, (object_id, payload))
        if (
            actual_type == "CertifiedDeltaRecord"
            or declared_type == "CertifiedDeltaRecord"
            or object_id.startswith("certified-delta-")
        ):
            delta_candidates.setdefault(digest, (object_id, payload))

    claims: List[Tuple[str, VerificationResult]] = []
    for _digest, (object_id, artifact) in sorted(
        phase_candidates.items(), key=lambda item: item[1][0]
    ):
        label_id = (
            str(artifact.get("analysis_id") or object_id)
            if isinstance(artifact, Mapping) else object_id
        )
        label = f"objects/PhaseAnalysisRecord/{label_id}"
        source_root = artifact.get("source_r_root") if isinstance(artifact, Mapping) else None
        source = objects.get(str(source_root)) if source_root is not None else None
        if source is None:
            sub = _failed_portable_claim(
                "phase_source_present",
                f"phase claim {label_id!r} has no inventoried source R at {source_root!r}",
                claim_type="PhaseAnalysisRecord",
                claim_scope=phase_scope,
            )
        else:
            # Malformed evidence must fail closed at the bundle boundary.
            try:
                sub = verify_phase_analysis_record(artifact, source)
            except Exception as error:
                sub = _failed_portable_claim(
                    "phase_verifier_completed",
                    f"phase claim {label_id!r} could not be decoded: "
                    f"{type(error).__name__}: {error}",
                    claim_type="PhaseAnalysisRecord",
                    claim_scope=phase_scope,
                )
            sub.report.update(
                {
                    "claim_type": "PhaseAnalysisRecord",
                    "claim_scope": phase_scope,
                    "authorization_effect": "NONE",
                    "source_r_root": source_root,
                    "level_attempted": Level.V2,
                    "level_achieved": Level.V2 if sub.ok else "NONE",
                }
            )
        claims.append((label, sub))

    referenced_input_ids = set()
    for _digest, (object_id, record) in sorted(
        delta_candidates.items(), key=lambda item: item[1][0]
    ):
        evidence_id = (
            str(record.get("evidence_id") or object_id)
            if isinstance(record, Mapping) else object_id
        )
        label = f"objects/CertifiedDeltaRecord/{evidence_id}"
        input_id = f"delta-inputs:{evidence_id}"
        referenced_input_ids.add(input_id)
        inputs = objects_by_id.get(input_id)
        if not isinstance(inputs, Mapping):
            sub = _failed_portable_claim(
                "delta_verification_input_present",
                f"certified delta {evidence_id!r} has no canonical object {input_id!r}",
                claim_type="CertifiedDeltaRecord",
                claim_scope=delta_scope,
            )
        else:
            fields = frozenset(inputs)
            missing = sorted(_DELTA_INPUT_REQUIRED - fields)
            unknown = sorted(fields - _DELTA_INPUT_REQUIRED - _DELTA_INPUT_OPTIONAL)
            shape_failures: List[str] = []
            if missing:
                shape_failures.append(f"missing fields {missing}")
            if unknown:
                shape_failures.append(f"unsupported fields {unknown}")
            if "prior_case" in inputs and not isinstance(inputs.get("prior_case"), Mapping):
                shape_failures.append("prior_case is not an object")
            if "current_case" in inputs and not isinstance(inputs.get("current_case"), Mapping):
                shape_failures.append("current_case is not an object")
            if (
                "dependency_edges" in inputs
                and not isinstance(inputs.get("dependency_edges"), list)
            ):
                shape_failures.append("dependency_edges is not an array")
            if "replacements" in inputs and not isinstance(inputs.get("replacements"), Mapping):
                shape_failures.append("replacements is not an object")
            if shape_failures:
                sub = _failed_portable_claim(
                    "delta_verification_input_shape",
                    f"{input_id!r} is not the registered verification input: "
                    + "; ".join(shape_failures),
                    claim_type="CertifiedDeltaRecord",
                    claim_scope=delta_scope,
                )
            else:
                try:
                    sub = verify_certified_delta_record(
                        record,
                        inputs["prior_case"],
                        inputs["current_case"],
                        inputs["dependency_edges"],
                        replacements=inputs.get("replacements") or {},
                        prior_phase=inputs.get("prior_phase"),
                        current_phase=inputs.get("current_phase"),
                        prior_phase_source_r=inputs.get("prior_phase_source_r"),
                        current_phase_source_r=inputs.get("current_phase_source_r"),
                    )
                except Exception as error:  # malformed evidence must be a result, never a crash
                    sub = _failed_portable_claim(
                        "delta_verifier_completed",
                        f"certified delta {evidence_id!r} could not be decoded: "
                        f"{type(error).__name__}: {error}",
                        claim_type="CertifiedDeltaRecord",
                        claim_scope=delta_scope,
                    )
                sub.report.update(
                    {
                        "claim_type": "CertifiedDeltaRecord",
                        "claim_scope": delta_scope,
                        "authorization_effect": "NONE",
                        "verification_input_id": input_id,
                        "verification_input_root": content_hash(inputs),
                        "level_attempted": Level.V2,
                        "level_achieved": Level.V2 if sub.ok else "NONE",
                    }
                )
        claims.append((label, sub))

    # An input bearing the reserved identity is semantic evidence, not an
    # inert payload.  Without its matching delta record it cannot establish a
    # claim and is reported explicitly instead of being silently ignored.
    for input_id in sorted(
        identifier for identifier in objects_by_id
        if identifier.startswith("delta-inputs:") and identifier not in referenced_input_ids
    ):
        evidence_id = input_id.split(":", 1)[1]
        claims.append(
            (
                f"objects/CertifiedDeltaInputs/{evidence_id}",
                _failed_portable_claim(
                    "delta_record_present",
                    f"verification input {input_id!r} has no matching CertifiedDeltaRecord",
                    claim_type="CertifiedDeltaRecord",
                    claim_scope=delta_scope,
                ),
            )
        )
    return claims


def _portable_comparison_claims(
    declarations: List[dict], objects_by_id: Mapping[str, Any],
) -> List[Tuple[str, VerificationResult]]:
    """Discover and independently reconstruct every carried ENH-03 record."""
    candidates: Dict[str, Tuple[str, Any]] = {}
    for declaration in declarations:
        object_id = str(declaration.get("id") or "")
        payload = objects_by_id.get(object_id)
        if payload is None:
            continue
        actual_type = payload.get("record_type") if isinstance(payload, Mapping) else None
        declared_type = declaration.get("object_type")
        if (
            actual_type == "ComparativeWorkflowEvaluation"
            or declared_type == "ComparativeWorkflowEvaluation"
            or object_id.startswith("comparative-evaluation:")
        ):
            candidates.setdefault(str(declaration.get("hash") or object_id), (object_id, payload))

    claims: List[Tuple[str, VerificationResult]] = []
    for _digest, (object_id, record) in sorted(
        candidates.items(), key=lambda item: item[1][0]
    ):
        evaluation_id = (
            str(record.get("evaluation_id") or object_id)
            if isinstance(record, Mapping) else object_id
        )
        try:
            result = verify_comparative_workflow_evaluation(record)
        except Exception as error:
            result = _failed_portable_claim(
                "comparative_verifier_completed",
                f"comparative evaluation {evaluation_id!r} could not be decoded: "
                f"{type(error).__name__}: {error}",
                claim_type="ComparativeWorkflowEvaluation",
                claim_scope="RELATIVE_TO_EMBEDDED_INPUTS_WORKLOAD_ORACLE_BUDGETS_AND_DENOMINATORS",
            )
        result.report.update(
            {
                "claim_type": "ComparativeWorkflowEvaluation",
                "claim_scope": (
                    "RELATIVE_TO_EMBEDDED_INPUTS_WORKLOAD_ORACLE_BUDGETS_AND_DENOMINATORS"
                ),
                "authorization_effect": "NONE",
                "semantic_effect": "NONE",
                "evaluation_id": evaluation_id,
            }
        )
        claims.append((f"objects/ComparativeWorkflowEvaluation/{evaluation_id}", result))
    return claims


def _portable_journey_comparison_claims(
    declarations: List[dict], objects_by_id: Mapping[str, Any],
) -> List[Tuple[str, VerificationResult]]:
    """Discover the v1.2 change and v1.4 cumulative comparison records.

    Both profiles embed every replay input needed by their independent
    verifier.  Inventory type and reserved logical-ID prefixes are treated as
    trust-boundary declarations: disguising or corrupting such an object must
    produce a failed claim instead of silently making the claim disappear.
    """

    profiles = {
        "ComparativeChangeEvidence": {
            "prefix": "comparative-change:",
            "identity": "comparison_id",
            "verify": verify_comparative_change_evidence,
            "scope": "RELATIVE_TO_ONE_CARRIED_CERTIFIED_DELTA_AND_ITS_EXACT_REPLAY_INPUTS",
        },
        "CumulativeLifecycleComparison": {
            "prefix": "cumulative-lifecycle-comparison:",
            "identity": "journey_id",
            "verify": verify_cumulative_lifecycle_comparison,
            "scope": "RELATIVE_TO_THE_FIXED_V1_1_THROUGH_V1_4_CARRIED_ARTIFACT_DENOMINATOR",
        },
    }
    candidates: List[Tuple[str, str, Any]] = []
    for declaration in declarations:
        object_id = str(declaration.get("id") or "")
        payload = objects_by_id.get(object_id)
        if payload is None:
            continue
        actual_type = payload.get("record_type") if isinstance(payload, Mapping) else None
        declared_type = declaration.get("object_type")
        for record_type, profile in profiles.items():
            if (
                actual_type == record_type
                or declared_type == record_type
                or object_id.startswith(str(profile["prefix"]))
            ):
                candidates.append((record_type, object_id, payload))
                break

    claims: List[Tuple[str, VerificationResult]] = []
    identities: Dict[Tuple[str, str], str] = {}
    for record_type, object_id, record in sorted(candidates, key=lambda item: item[:2]):
        profile = profiles[record_type]
        identity = (
            str(record.get(str(profile["identity"])) or object_id)
            if isinstance(record, Mapping) else object_id
        )
        key = (record_type, identity)
        if key in identities:
            result = _failed_portable_claim(
                "unique_comparison_identity",
                f"{record_type} identity {identity!r} is declared by both "
                f"{identities[key]!r} and {object_id!r}",
                claim_type=record_type,
                claim_scope=str(profile["scope"]),
            )
        else:
            identities[key] = object_id
            try:
                result = profile["verify"](record)
            except Exception as error:
                result = _failed_portable_claim(
                    "journey_comparison_verifier_completed",
                    f"{record_type} {identity!r} could not be decoded: "
                    f"{type(error).__name__}: {error}",
                    claim_type=record_type,
                    claim_scope=str(profile["scope"]),
                )
        result.report.update(
            {
                "claim_type": record_type,
                "claim_scope": str(profile["scope"]),
                "authorization_effect": "NONE",
                "semantic_effect": "NONE",
                str(profile["identity"]): identity,
            }
        )
        claims.append((f"objects/{record_type}/{identity}", result))
    return claims


def _portable_challenge_claims(
    declarations: List[dict], objects_by_id: Mapping[str, Any],
) -> List[Tuple[str, VerificationResult]]:
    """Discover every carried non-mutating Decision Challenge proof."""
    candidates: Dict[str, Tuple[str, Any]] = {}
    for declaration in declarations:
        object_id = str(declaration.get("id") or "")
        payload = objects_by_id.get(object_id)
        if payload is None:
            continue
        actual_type = payload.get("record_type") if isinstance(payload, Mapping) else None
        declared_type = declaration.get("object_type")
        if (
            actual_type == "DecisionChallengeRecord"
            or declared_type == "DecisionChallengeRecord"
            or object_id.startswith("decision-challenge:")
        ):
            candidates.setdefault(str(declaration.get("hash") or object_id), (object_id, payload))
    claims: List[Tuple[str, VerificationResult]] = []
    scope = "RELATIVE_NON_MUTATING_PREVIEW_OVER_CARRIED_BASELINE_PHASE_AND_DELTA_EVIDENCE"
    for _digest, (object_id, record) in sorted(candidates.items(), key=lambda item: item[1][0]):
        challenge_id = (
            str(record.get("challenge_id") or object_id)
            if isinstance(record, Mapping) else object_id
        )
        try:
            result = verify_decision_challenge_record(record)
        except Exception as error:
            result = _failed_portable_claim(
                "decision_challenge_verifier_completed",
                f"Decision Challenge {challenge_id!r} could not be decoded: "
                f"{type(error).__name__}: {error}",
                claim_type="DecisionChallengeRecord",
                claim_scope=scope,
            )
        result.report.update(
            {
                "claim_type": "DecisionChallengeRecord",
                "claim_scope": scope,
                "authorization_effect": "NONE",
                "semantic_effect": "NONE",
                "mutation_effect": "NONE",
                "challenge_id": challenge_id,
            }
        )
        claims.append((f"objects/DecisionChallengeRecord/{challenge_id}", result))
    return claims


_INTAKE_LEDGER_MAPS = {
    "mapping_profiles": "intake-profile:",
    "source_snapshots": "intake-source:",
    "previews": "intake-preview:",
    "confirmations": "intake-confirmation:",
    "materialized_registries": "intake-registry:",
    "import_reports": "intake-report:",
}
_INTAKE_LEDGER_POINTERS = {
    "latest_profile_hash": "mapping_profiles",
    "latest_source_snapshot_hash": "source_snapshots",
    "latest_preview_hash": "previews",
    "latest_confirmation_hash": "confirmations",
}


def _portable_intake_ledger_claim(
    ledger: Any, objects_by_id: Mapping[str, Any]
) -> VerificationResult:
    """Verify the closed, content-addressed root-case intake aggregate."""
    scope = "RELATIVE_TO_CARRIED_SOURCE_MAPPING_PREVIEW_AND_EXPLICIT_IMPORTED_FAMILY"
    findings: List[str] = []
    maps: Dict[str, Dict[str, Mapping[str, Any]]] = {
        name: {} for name in _INTAKE_LEDGER_MAPS
    }
    required = {
        "record_type", "schema_version", "authority", "mapping_profiles",
        "historical_output_binding_profile", "source_snapshots", "previews",
        "confirmations", "materialized_registries", "import_reports",
        "latest_profile_hash",
        "latest_source_snapshot_hash", "latest_producer_source_snapshot_hash",
        "latest_preview_hash", "latest_confirmation_hash",
    }
    optional: set[str] = set()
    if not isinstance(ledger, Mapping):
        findings.append("registry_intake is not an object")
        ledger = {}
    else:
        missing = sorted(required - set(ledger))
        unknown = sorted(set(ledger) - required - optional)
        if missing:
            findings.append(f"ledger is missing fields {missing}")
        if unknown:
            findings.append(f"ledger has unsupported fields {unknown}")
        if ledger.get("record_type") != "RegistryIntakeLedger":
            findings.append("ledger record_type is not RegistryIntakeLedger")
        if ledger.get("schema_version") != "1.0.0":
            findings.append("ledger schema_version is not 1.0.0")
        if ledger.get("authority") != "NON_AUTHORIZING_INTAKE":
            findings.append("ledger authority is not NON_AUTHORIZING_INTAKE")

    has_registries = "materialized_registries" in ledger
    has_reports = "import_reports" in ledger
    binding_profile = ledger.get("historical_output_binding_profile")
    if has_registries != has_reports:
        findings.append("historical companion maps must both be present or both absent")
    if has_registries != (binding_profile == "CONTENT_ADDRESSED_COMPANIONS_V1"):
        findings.append("historical companion maps disagree with their binding profile")

    for name, prefix in _INTAKE_LEDGER_MAPS.items():
        raw = ledger.get(name)
        if not isinstance(raw, Mapping):
            findings.append(f"ledger {name} is not an object")
            continue
        for digest, record in raw.items():
            if not is_hash(digest):
                findings.append(f"ledger {name} has invalid hash key {digest!r}")
                continue
            if not isinstance(record, Mapping):
                findings.append(f"ledger {name}[{digest!r}] is not an object")
                continue
            try:
                actual = content_hash(record)
            except (CanonicalError, TypeError, ValueError) as error:
                findings.append(f"ledger {name}[{digest!r}] cannot be hashed: {error}")
                continue
            if actual != digest:
                findings.append(
                    f"ledger {name}[{digest!r}] hashes to {actual}"
                )
            maps[name][str(digest)] = record
            expected_id = f"{prefix}{digest}"
            portable = objects_by_id.get(expected_id)
            if not isinstance(portable, Mapping) or dict(portable) != dict(record):
                findings.append(f"portable inventory does not mirror {expected_id}")

        # The mirror is exact: aliases and extraneous reserved identities are
        # not annotations and cannot be ignored.
        for object_id, portable in objects_by_id.items():
            if not object_id.startswith(prefix):
                continue
            digest = object_id[len(prefix):]
            ledger_record = maps[name].get(digest)
            if (
                ledger_record is None
                or not isinstance(portable, Mapping)
                or dict(portable) != dict(ledger_record)
            ):
                findings.append(f"portable inventory has extraneous alias {object_id}")

    for pointer, name in _INTAKE_LEDGER_POINTERS.items():
        digest = ledger.get(pointer)
        if digest not in maps[name]:
            findings.append(f"ledger {pointer} is dangling: {digest!r}")

    latest_source = maps["source_snapshots"].get(
        str(ledger.get("latest_source_snapshot_hash") or "")
    )
    if latest_source is not None and ledger.get(
        "latest_producer_source_snapshot_hash"
    ) != latest_source.get("producer_snapshot_hash"):
        findings.append(
            "latest producer source hash disagrees with the selected typed source"
        )
    latest_confirmation = maps["confirmations"].get(
        str(ledger.get("latest_confirmation_hash") or "")
    )
    if latest_confirmation is not None:
        if (
            latest_confirmation.get("profile_hash") != ledger.get("latest_profile_hash")
            or latest_confirmation.get("source_snapshot_record_hash")
            != ledger.get("latest_source_snapshot_hash")
            or latest_confirmation.get("actual_preview_hash")
            != ledger.get("latest_preview_hash")
            or latest_confirmation.get("expected_preview_hash")
            != ledger.get("latest_preview_hash")
            or latest_confirmation.get("source_snapshot_hash")
            != ledger.get("latest_producer_source_snapshot_hash")
        ):
            findings.append("latest pointers do not describe one confirmation head")

    for digest, confirmation in maps["confirmations"].items():
        for field, name in (
            ("profile_hash", "mapping_profiles"),
            ("source_snapshot_record_hash", "source_snapshots"),
            ("actual_preview_hash", "previews"),
        ):
            if confirmation.get(field) not in maps[name]:
                findings.append(f"confirmation {digest} has unresolved {field}")
        source = maps["source_snapshots"].get(
            str(confirmation.get("source_snapshot_record_hash") or "")
        )
        if source is not None and confirmation.get("source_snapshot_hash") != source.get(
            "producer_snapshot_hash"
        ):
            findings.append(f"confirmation {digest} source binding disagrees")
        if has_registries:
            registry_hash = confirmation.get("bundle_hash")
            report_hash = confirmation.get("import_report_hash")
            registry = maps["materialized_registries"].get(str(registry_hash or ""))
            report = maps["import_reports"].get(str(report_hash or ""))
            if registry is None:
                findings.append(f"confirmation {digest} has no historical registry")
            if report is None:
                findings.append(f"confirmation {digest} has no historical import report")
            if registry is not None and report is not None and (
                report.get("canonical_output_hash") != registry_hash
                or report.get("bundle_id") != registry.get("bundle_id")
                or report.get("source_fingerprint") != registry.get("source_fingerprint")
            ):
                findings.append(f"confirmation {digest} output companions disagree")

    result = VerificationResult(ok=False)
    result.record(
        "registry_intake_ledger_closure",
        not findings,
        "; ".join(findings)
        if findings
        else "all hash maps, heads, confirmation dependencies, and portable mirrors close",
    )
    result.status = Status.VERIFIED_RELATIVE if not findings else Status.FAILED
    result.report.update(
        {
            "claim_type": "RegistryIntakeLedger",
            "claim_scope": scope,
            "authorization_effect": "NONE",
            "semantic_effect": "NONE",
            "companion_maps_present": has_registries and has_reports,
            "confirmation_ids": sorted(
                f"intake-confirmation:{digest}" for digest in maps["confirmations"]
            ),
        }
    )
    return result.finish()


def _portable_intake_claims(
    declarations: List[dict],
    objects_by_id: Mapping[str, Any],
    root_case: Any,
) -> List[Tuple[str, VerificationResult]]:
    """Verify every portable ENH-01 record and exact historical binding.

    Every intake confirmation carries the registry and import report it
    confirmed under content-addressed logical identities.  Current root-case
    state is never substituted for that historical evidence, so a later case
    mutation cannot silently change the confirmation replay target.
    """
    kinds = {
        "RegistryMappingProfile": ("intake-profile:", verify_registry_mapping_profile),
        "RegistrySourceSnapshot": ("intake-source:", verify_registry_source_snapshot),
        "RegistryIntakePreview": ("intake-preview:", verify_registry_intake_preview),
    }
    companion_specs = {
        "MATERIALIZED_REGISTRY": ("intake-registry:", "bundle_hash", "registry"),
        "IMPORT_REPORT": ("intake-report:", "import_report_hash", "import_report"),
    }
    reserved_specs = {
        "PROFILE": "intake-profile:",
        "SOURCE": "intake-source:",
        "PREVIEW": "intake-preview:",
        "CONFIRMATION": "intake-confirmation:",
        "MATERIALIZED_REGISTRY": "intake-registry:",
        "IMPORT_REPORT": "intake-report:",
    }
    candidates: Dict[str, Dict[str, Tuple[str, Any]]] = {name: {} for name in kinds}
    confirmations: Dict[str, Tuple[str, Any]] = {}
    reserved: Dict[str, Dict[str, Any]] = {name: {} for name in reserved_specs}
    kind_for_record_type = {
        "RegistryMappingProfile": "PROFILE",
        "RegistrySourceSnapshot": "SOURCE",
        "RegistryIntakePreview": "PREVIEW",
        "RegistryIntakeConfirmation": "CONFIRMATION",
    }
    for declaration in declarations:
        object_id = str(declaration.get("id") or "")
        payload = objects_by_id.get(object_id)
        if payload is None:
            continue
        actual_type = payload.get("record_type") if isinstance(payload, Mapping) else None
        declared_type = declaration.get("object_type")
        for record_type, (prefix, _verifier) in kinds.items():
            if (
                actual_type == record_type
                or declared_type == record_type
                or object_id.startswith(prefix)
            ):
                candidates[record_type].setdefault(object_id, (object_id, payload))
        if (
            actual_type == "RegistryIntakeConfirmation"
            or declared_type == "RegistryIntakeConfirmation"
            or object_id.startswith("intake-confirmation:")
        ):
            confirmations.setdefault(object_id, (object_id, payload))
        # A record cannot escape the reserved-ID contract by carrying (or
        # declaring) an intake type under an unrelated logical identity.
        # Include typed aliases in the same binding inventory so exact prefix,
        # content hash, uniqueness, and ledger reachability are all enforced.
        for typed_record_type, reserved_kind in kind_for_record_type.items():
            if actual_type == typed_record_type or declared_type == typed_record_type:
                reserved[reserved_kind][object_id] = payload
        for reserved_kind, prefix in reserved_specs.items():
            if object_id.startswith(prefix):
                reserved[reserved_kind][object_id] = payload

    claims: List[Tuple[str, VerificationResult]] = []
    scope = "RELATIVE_TO_CARRIED_SOURCE_MAPPING_PREVIEW_AND_EXPLICIT_IMPORTED_FAMILY"
    for record_type, (_prefix, verifier) in kinds.items():
        for _identity, (object_id, record) in sorted(candidates[record_type].items()):
            try:
                result = verifier(record)
            except Exception as error:
                result = _failed_portable_claim(
                    "intake_verifier_completed",
                    f"{record_type} {object_id!r} could not be decoded: "
                    f"{type(error).__name__}: {error}",
                    claim_type=record_type,
                    claim_scope=scope,
                )
            result.report.update(
                {
                    "claim_type": record_type,
                    "claim_scope": scope,
                    "authorization_effect": "NONE",
                    "semantic_effect": "NONE",
                }
            )
            claims.append((f"objects/{record_type}/{object_id}", result))

    case = root_case if isinstance(root_case, Mapping) else {}
    ledger = case.get("registry_intake")
    ledger_confirmation_ids: set[str] = set()
    if ledger is not None:
        ledger_result = _portable_intake_ledger_claim(ledger, objects_by_id)
        claims.append(("case/RegistryIntakeLedger", ledger_result))
        if isinstance(ledger, Mapping):
            raw_confirmations = ledger.get("confirmations")
            if isinstance(raw_confirmations, Mapping):
                ledger_confirmation_ids = {
                    f"intake-confirmation:{digest}" for digest in raw_confirmations
                }
    elif any(reserved.values()):
        # ENH-01 has no released companionless representation.  Scanner-only
        # objects therefore cannot constitute a portable intake history: the
        # root ledger is the aggregate that closes identities, reachability,
        # exact historical outputs, and the selected head.
        ledger_result = _failed_portable_claim(
            "registry_intake_ledger_required",
            "portable intake objects are present but case.registry_intake is absent",
            claim_type="RegistryIntakeLedger",
            claim_scope=scope,
        )
        ledger_result.report.update(
            {
                "authorization_effect": "NONE",
                "semantic_effect": "NONE",
                "companion_maps_present": False,
                "confirmation_ids": [],
            }
        )
        claims.append(("case/RegistryIntakeLedger", ledger_result))

    referenced = {name: set() for name in reserved_specs}
    if ledger is not None:
        for _identity, (_object_id, confirmation) in confirmations.items():
            if not isinstance(confirmation, Mapping):
                continue
            for kind, prefix, field in (
                ("PROFILE", "intake-profile:", "profile_hash"),
                ("SOURCE", "intake-source:", "source_snapshot_record_hash"),
                ("PREVIEW", "intake-preview:", "actual_preview_hash"),
                ("MATERIALIZED_REGISTRY", "intake-registry:", "bundle_hash"),
                ("IMPORT_REPORT", "intake-report:", "import_report_hash"),
            ):
                digest = confirmation.get(field)
                if is_hash(digest):
                    referenced[kind].add(f"{prefix}{digest}")
        referenced["CONFIRMATION"] = ledger_confirmation_ids

    # Every reserved logical identity is content addressed, unique within its
    # kind, and reachable through the confirmation/ledger graph.  Semantic
    # record verification cannot mask a bad alias.
    for reserved_kind, prefix in reserved_specs.items():
        records = reserved[reserved_kind]
        by_content_hash: Dict[str, List[str]] = {}
        actual_hashes: Dict[str, Optional[str]] = {}
        for object_id, record in records.items():
            actual_hash: Optional[str] = None
            if isinstance(record, Mapping):
                try:
                    actual_hash = content_hash(record)
                except (CanonicalError, TypeError, ValueError):
                    actual_hash = None
            actual_hashes[object_id] = actual_hash
            if actual_hash is not None:
                by_content_hash.setdefault(actual_hash, []).append(object_id)
        duplicate_ids = {
            object_id
            for object_ids in by_content_hash.values()
            if len(object_ids) > 1
            for object_id in object_ids
        }
        for object_id, record in sorted(records.items()):
            has_registered_prefix = object_id.startswith(prefix)
            suffix = object_id[len(prefix):] if has_registered_prefix else ""
            actual_hash = actual_hashes[object_id]
            findings: List[str] = []
            if not isinstance(record, Mapping):
                findings.append("reserved intake payload is not an object")
            if not has_registered_prefix:
                findings.append(
                    f"typed intake object must use registered prefix {prefix!r}"
                )
            if not is_hash(suffix):
                findings.append("logical identity suffix is not an algorithm-tagged hash")
            if actual_hash is None:
                findings.append("payload cannot be canonically content-hashed")
            elif suffix != actual_hash:
                findings.append(
                    f"logical identity states {suffix!r}, payload hashes to {actual_hash}"
                )
            if object_id in duplicate_ids:
                findings.append("identical content has multiple reserved logical identities")
            if object_id not in referenced[reserved_kind]:
                findings.append("reserved intake object is not reachable from its ledger graph")
            claim_type = (
                "RegistryIntakeCompanion"
                if reserved_kind in companion_specs
                else "RegistryIntakeRecordBinding"
            )
            result = VerificationResult(ok=False)
            result.record(
                "reserved_intake_logical_identity",
                not findings,
                "; ".join(findings)
                if findings
                else f"{object_id} is exact, unique, and reachable",
            )
            result.status = Status.VERIFIED_RELATIVE if not findings else Status.FAILED
            result.report.update(
                {
                    "claim_type": claim_type,
                    "claim_scope": scope,
                    "authorization_effect": "NONE",
                    "semantic_effect": "NONE",
                    "reserved_kind": reserved_kind,
                    "object_id": object_id,
                    "content_hash": actual_hash,
                    "referenced": object_id in referenced[reserved_kind],
                }
            )
            claims.append((f"objects/{claim_type}/{object_id}", result.finish()))

    for _identity, (object_id, confirmation) in sorted(confirmations.items()):
        registry_binding_source: Optional[str] = None
        report_binding_source: Optional[str] = None
        if not isinstance(confirmation, Mapping):
            result = _failed_portable_claim(
                "intake_confirmation_shape",
                f"intake confirmation {object_id!r} is not an object",
                claim_type="RegistryIntakeConfirmation",
                claim_scope=scope,
            )
        else:
            profile_id = f"intake-profile:{confirmation.get('profile_hash')}"
            source_id = f"intake-source:{confirmation.get('source_snapshot_record_hash')}"
            preview_id = f"intake-preview:{confirmation.get('actual_preview_hash')}"
            profile = objects_by_id.get(profile_id)
            source = objects_by_id.get(source_id)
            preview = objects_by_id.get(preview_id)
            missing = [
                name for name, value in (
                    (profile_id, profile), (source_id, source), (preview_id, preview),
                )
                if not isinstance(value, Mapping)
            ]
            bound_outputs: Dict[str, Mapping[str, Any]] = {}
            binding_errors: List[str] = []
            binding_sources: Dict[str, str] = {}
            for companion_kind, (prefix, field, root_name) in companion_specs.items():
                expected_hash = confirmation.get(field)
                expected_id = f"{prefix}{expected_hash}"
                if not is_hash(expected_hash):
                    binding_errors.append(
                        f"confirmation {field} is not an algorithm-tagged SHA-256 hash"
                    )
                    continue
                if expected_id in objects_by_id:
                    carried = objects_by_id[expected_id]
                    if not isinstance(carried, Mapping):
                        binding_errors.append(f"{expected_id} is not an object")
                        continue
                    try:
                        actual_hash = content_hash(carried)
                    except (CanonicalError, TypeError, ValueError) as error:
                        binding_errors.append(
                            f"{expected_id} cannot be canonically content-hashed: {error}"
                        )
                        continue
                    if actual_hash != expected_hash:
                        binding_errors.append(
                            f"{expected_id} hashes to {actual_hash}, not {expected_hash}"
                        )
                        continue
                    bound_outputs[root_name] = carried
                    binding_sources[root_name] = "CONTENT_ADDRESSED_COMPANION"
                    continue

                binding_errors.append(
                    f"missing exact content-addressed companion {expected_id}"
                )

            registry_binding_source = binding_sources.get("registry")
            report_binding_source = binding_sources.get("import_report")
            if missing or binding_errors:
                result = _failed_portable_claim(
                    "intake_confirmation_dependencies_present",
                    f"intake confirmation {object_id!r} lacks {missing}; "
                    + "; ".join(binding_errors),
                    claim_type="RegistryIntakeConfirmation",
                    claim_scope=scope,
                )
            else:
                try:
                    result = verify_registry_intake_confirmation(
                        confirmation,
                        profile,
                        source,
                        preview,
                        registry=bound_outputs["registry"],
                        import_report=bound_outputs["import_report"],
                    )
                except Exception as error:
                    result = _failed_portable_claim(
                        "intake_confirmation_verifier_completed",
                        f"intake confirmation {object_id!r} could not be decoded: "
                        f"{type(error).__name__}: {error}",
                        claim_type="RegistryIntakeConfirmation",
                        claim_scope=scope,
                    )
        result.report.update(
            {
                "claim_type": "RegistryIntakeConfirmation",
                "claim_scope": scope,
                "authorization_effect": "NONE",
                "semantic_effect": "NONE",
                "registry_binding_source": registry_binding_source,
                "import_report_binding_source": report_binding_source,
                "historical_companions_checked": (
                    registry_binding_source == "CONTENT_ADDRESSED_COMPANION"
                    and report_binding_source == "CONTENT_ADDRESSED_COMPANION"
                ),
            }
        )
        claims.append((f"objects/RegistryIntakeConfirmation/{object_id}", result))
    return claims


def verify_bundle(
    path: str, *, clock: Optional[str] = None, clock_source: str = "none-supplied",
    level: str = Level.V3, federation_context: Optional[dict] = None,
    signature_verifier: Optional[Callable[[bytes, Mapping[str, Any]], Tuple[bool, str]]] = None,
    extension_registry: Optional[ProofCheckerRegistry] = None,
) -> VerificationResult:
    """Verify a ``.crg`` bundle end to end (spec 25.2, 39)."""
    result = VerificationResult(ok=False)
    result.report.update({"bundle_identity": os.path.basename(path),
                          "verifier_identity": "crg-verify", "verifier_version": VERIFIER_VERSION,
                          "level_attempted": level})
    try:
        reader = _Reader(path)
    except (FileNotFoundError, OSError) as error:
        result.record("bundle_readable", False, str(error))
        result.status = Status.FAILED
        return result.finish()
    try:
        _verify_open(
            result, reader, clock, clock_source, level, federation_context,
            signature_verifier, extension_registry,
        )
    finally:
        reader.close()
    return result


def _fail(result: VerificationResult, name: str, detail: str) -> None:
    result.record(name, False, detail)
    result.status = Status.FAILED
    result.finish()


def _verify_open(result: VerificationResult, reader: _Reader, clock: Optional[str],
                 clock_source: str, level: str,
                 federation_context: Optional[dict],
                 signature_verifier: Optional[
                     Callable[[bytes, Mapping[str, Any]], Tuple[bool, str]]
                 ],
                 extension_registry: Optional[ProofCheckerRegistry]) -> None:
    if level not in Level.ORDER:
        return _fail(result, "verification_level_supported",
                     f"unknown verification level {level!r}; expected one of {Level.ORDER}")

    # -- V0: manifest ---------------------------------------------------
    if MANIFEST_NAME not in reader.names:
        return _fail(result, "manifest_present", f"no {MANIFEST_NAME} in the bundle")
    try:
        manifest_bytes = reader.read(MANIFEST_NAME)
        manifest = decode(manifest_bytes.decode("utf-8"))
    except (ValueError, CanonicalError) as error:
        return _fail(result, "manifest_present", f"manifest is not canonical JSON: {error}")
    if not isinstance(manifest, dict):
        return _fail(result, "manifest_present", "manifest.json is not a JSON object")
    result.record("manifest_present", True, f"{MANIFEST_NAME} decoded")

    canonical_manifest_hash = content_hash(manifest)
    raw_manifest_hash = "sha256:" + hashlib.sha256(manifest_bytes).hexdigest()
    result.record(
        "manifest_canonical",
        canonical_manifest_hash == raw_manifest_hash,
        "manifest bytes are the independent canonical encoding"
        if canonical_manifest_hash == raw_manifest_hash
        else ("manifest bytes are not canonical: raw bytes hash to "
              f"{raw_manifest_hash}, canonical content hashes to {canonical_manifest_hash}"),
    )
    anchored_hash, anchor_detail = reader.manifest_hash()
    result.record(
        "manifest_integrity",
        anchored_hash == raw_manifest_hash,
        f"{anchor_detail} binds manifest.json to {raw_manifest_hash}"
        if anchored_hash == raw_manifest_hash
        else f"{anchor_detail}; expected {raw_manifest_hash}, found {anchored_hash!r}",
    )

    missing_fields = [names[0] for names in MANIFEST_REQUIRED
                      if not any(n in manifest for n in names)]
    result.record("manifest_fields", not missing_fields,
                  f"manifest omits required fields {missing_fields} (39.1)" if missing_fields
                  else f"all {len(MANIFEST_REQUIRED)} core manifest fields present")
    result.report["bundle_identity"] = _root_case(manifest) or result.report["bundle_identity"]

    missing_members = [name for name in _REQUIRED_MEMBERS if name not in reader.names]
    result.record(
        "required_members_present",
        not missing_members,
        f"required members missing: {missing_members}" if missing_members
        else f"all {len(_REQUIRED_MEMBERS)} portable-profile members are present",
    )

    duplicate_names: List[str] = []
    if reader._zip is not None:
        seen = set()
        for name in reader._zip.namelist():
            if name in seen and name not in duplicate_names:
                duplicate_names.append(name)
            seen.add(name)
    result.record(
        "unique_member_names", not duplicate_names,
        f"duplicate archive members are forbidden: {duplicate_names}" if duplicate_names
        else "archive member names are unique",
    )

    unsafe_names = [name for name in reader.names if not _safe_member_name(name)]
    result.record(
        "safe_member_paths", not unsafe_names,
        f"unsafe absolute or traversing member paths: {unsafe_names}" if unsafe_names
        else "all member paths are relative and traversal-free",
    )

    # -- V0: every declared stored byte --------------------------------
    content_entries: Dict[str, str] = {}
    hashes = manifest.get("content_hashes")
    hashes_ok = isinstance(hashes, dict)
    if hashes_ok:
        hashes_ok = hashes.get("algorithm") == "sha256"
        raw_entries = hashes.get("entries")
        hashes_ok = hashes_ok and isinstance(raw_entries, dict)
        if isinstance(raw_entries, dict):
            content_entries = {str(k): str(v) for k, v in raw_entries.items()}
    result.record(
        "content_hash_manifest",
        hashes_ok,
        f"{len(content_entries)} sha256 content entries declared" if hashes_ok
        else "content_hashes must declare algorithm 'sha256' and a mapping of entries",
    )
    content_failures: List[str] = []
    for name, stated in sorted(content_entries.items()):
        if not _safe_member_name(name):
            content_failures.append(f"unsafe declared path {name!r}")
        elif name not in reader.names:
            content_failures.append(f"missing declared member {name}")
        elif not is_hash(stated):
            content_failures.append(f"{name}: invalid digest {stated!r}")
        else:
            actual = _bytes_hash(reader.read(name))
            if actual != stated:
                content_failures.append(f"{name}: manifest states {stated}, bytes hash to {actual}")
    result.record(
        "declared_content_integrity", hashes_ok and not content_failures,
        "; ".join(content_failures) if content_failures
        else f"all {len(content_entries)} declared member hashes match",
    )
    unbound_members = sorted(
        name for name in reader.names
        if name not in {MANIFEST_NAME, "README.md", "manifest.sha256"}
        and not name.startswith("signatures/")
        and name not in content_entries
    )
    result.record(
        "all_payload_members_hash_bound", not unbound_members,
        f"payload members absent from content_hashes: {unbound_members}" if unbound_members
        else "every payload member is bound by content_hashes",
    )

    # -- V0: root case --------------------------------------------------
    root = manifest.get("root_case_object")
    root_failures: List[str] = []
    root_payload: Optional[Any] = None
    if not isinstance(root, dict):
        root_failures.append("root_case_object is not an object")
    else:
        root_id = root.get("object_id")
        root_path = str(root.get("path") or "")
        root_hash = root.get("content_hash")
        if not root_id:
            root_failures.append("root_case_object.object_id is missing")
        if not root_path or not _safe_member_name(root_path):
            root_failures.append("root_case_object.path is missing or unsafe")
        elif root_path not in reader.names:
            root_failures.append(f"root case member is missing: {root_path}")
        else:
            root_bytes = reader.read(root_path)
            actual = _bytes_hash(root_bytes)
            if not is_hash(root_hash) or actual != root_hash:
                root_failures.append(
                    f"root case hash mismatch: manifest states {root_hash!r}, bytes hash to {actual}"
                )
            if content_entries.get(root_path) != root_hash:
                root_failures.append("root case is not bound consistently by content_hashes")
            try:
                root_payload = decode(root_bytes.decode("utf-8"))
            except (UnicodeDecodeError, ValueError, CanonicalError) as error:
                root_failures.append(f"root case is not canonical JSON: {error}")
            else:
                if content_hash(root_payload) != actual:
                    root_failures.append("root case member bytes are not canonical JSON")
                if isinstance(root_payload, dict) and root_payload.get("case_id") != root_id:
                    root_failures.append(
                        "root case object_id does not match case.json case_id"
                    )
    result.record(
        "root_case_integrity", not root_failures,
        "; ".join(root_failures) if root_failures
        else "root case is present, canonical, identity-matched, and hash-bound",
    )

    # -- V0: object inventory integrity ---------------------------------
    objects: Dict[str, Any] = {}
    objects_by_id: Dict[str, Any] = {}
    valid_object_declarations: List[dict] = []
    failures: List[str] = []
    missing: List[str] = []
    for item in _inventory(manifest):
        if "raw" in item:
            failures.append(f"inventory entry {item['raw']!r} is not an object record")
            continue
        name, stated = str(item.get("path") or ""), str(item.get("hash") or "")
        if not _safe_member_name(name):
            failures.append(f"unsafe inventory path {name!r}")
            continue
        if name not in reader.names:
            missing.append(name or stated)
            continue
        try:
            payload = reader.json(name)
        except (ValueError, CanonicalError) as error:
            failures.append(f"{name}: {error}")
            continue
        recomputed = content_hash(payload)
        if not is_hash(stated) or recomputed != stated:
            failures.append(f"{name}: manifest states {stated}, content hashes to {recomputed}")
        elif content_entries.get(name) != stated:
            failures.append(f"{name}: object inventory and content_hashes disagree")
        elif name != f"objects/sha256/{stated.split(':', 1)[1]}.json":
            failures.append(f"{name}: object path is not derived from its content hash")
        elif item.get("byte_length") is not None and item["byte_length"] != len(reader.read(name)):
            failures.append(f"{name}: declared byte_length {item['byte_length']} is incorrect")
        else:
            objects[recomputed] = payload
            object_id = item.get("id")
            if object_id is not None:
                logical_id = str(object_id)
                if logical_id in objects_by_id:
                    failures.append(f"duplicate object_inventory identity {logical_id!r}")
                else:
                    objects_by_id[logical_id] = payload
                    valid_object_declarations.append(item)
    result.report["missing_objects"] = missing
    result.record("object_inventory_integrity", not failures and not missing,
                  "; ".join(failures + [f"missing {m}" for m in missing])
                  if (failures or missing)
                  else f"{len(objects)} inventoried objects present and hash-matched")
    partial = manifest.get("partial") or {}
    if missing and not (manifest.get("omitted_objects") or partial.get("omitted_objects")):  # 39.4
        result.record("partial_bundle_disclosure", False,
                      "objects are absent but the manifest declares no omissions, omission "
                      "reason, affected claims, or maximum achievable level (39.4)")

    inventory_paths = {str(item.get("path")) for item in _inventory(manifest)
                       if "raw" not in item and item.get("path")}
    undeclared_objects = sorted(
        name for name in reader.names
        if name.startswith("objects/sha256/") and name not in inventory_paths
    )
    result.record(
        "no_undeclared_objects", not undeclared_objects,
        f"stored objects absent from inventory: {undeclared_objects}" if undeclared_objects
        else "all stored objects are inventoried",
    )

    _verify_binary_inventory(
        result, reader, manifest.get("artifact_inventory"), content_entries,
        kind="artifact", prefix="artifacts/sha256/", id_field="artifact_id",
    )
    _verify_binary_inventory(
        result, reader, manifest.get("proof_inventory"), content_entries,
        kind="proof", prefix="proofs/sha256/", id_field="proof_id",
    )

    _verify_partial_disclosure(result, manifest, level)
    _verify_manifest_semantics(
        result, reader, manifest, manifest_bytes, level, signature_verifier,
    )
    result.report["level_profile"] = {
        "cumulative": True,
        "requirements": {name: list(LEVEL_REQUIREMENTS[name]) for name in Level.ORDER},
    }
    v0_passed = not result.violations

    if level == Level.V0:
        result.finish()
        result.status = Status.INTEGRITY_ONLY if result.ok else Status.FAILED
        result.report.update({"final_status": result.status,
                          "level_achieved": Level.V0 if result.ok else "NONE"})
        return

    # -- V1: structural closure --------------------------------------------
    _verify_structural(result, reader, manifest, objects, root_payload)
    result.finish()
    structural_passed = all(
        passed for name, passed, _detail in result.checks if name.startswith("v1_")
    )
    if level == Level.V1:
        result.status = Status.PARTIALLY_VERIFIED if result.ok else Status.FAILED
        v1_achieved = (Level.V1 if result.ok else
                       Level.V0 if v0_passed else "NONE")
        result.report.update({"final_status": result.status,
                              "level_achieved": v1_achieved})
        return
    # -- V2: the carried decision program or certificate -------------------
    programs = sorted(n for n in reader.names
                      if n.startswith("verification/programs/") and n.endswith(".json"))
    inner: List[Tuple[str, VerificationResult]] = []
    for name in programs:
        try:
            document = reader.json(name)
        except (ValueError, CanonicalError) as error:
            result.record(f"vir[{name}]", False, f"not canonical JSON: {error}")
            continue
        inner.append((name, verify_vir(
            document, clock=clock, clock_source=clock_source,
            extension_registry=extension_registry,
        )))

    # Safe-commitment records are proof-bearing portable objects in their own
    # right.  They do not need an originating certificate or CRG-VIR wrapper:
    # the independent checker reconstructs the retained set, geometry,
    # pruning obligations, regret witnesses, and registered bounds directly
    # from the inventoried object.
    commitments = [
        value for value in objects.values()
        if isinstance(value, dict) and value.get("record_type") == "SafeCommitmentArtifact"
    ]
    for artifact in sorted(commitments, key=lambda value: str(value.get("artifact_id") or "")):
        inner.append((
            f"objects/SafeCommitmentArtifact/{artifact.get('artifact_id')}",
            verify_safe_commitment(artifact),
        ))
    inner.extend(
        _portable_phase_delta_claims(valid_object_declarations, objects, objects_by_id)
    )
    inner.extend(_portable_comparison_claims(valid_object_declarations, objects_by_id))
    inner.extend(
        _portable_journey_comparison_claims(valid_object_declarations, objects_by_id)
    )
    inner.extend(_portable_challenge_claims(valid_object_declarations, objects_by_id))
    inner.extend(
        _portable_intake_claims(valid_object_declarations, objects_by_id, root_payload)
    )
    inner.extend(portable_lifecycle_claims(valid_object_declarations, objects_by_id))
    if not programs:
        # Fall back to certificate objects, with the bundle's own objects as
        # the dependency store.
        certificates = [p for p in objects.values()
                        if isinstance(p, dict) and "certificate_id" in p and "outcome" in p]
        if not certificates and not commitments and not inner:
            result.record("verification_program_present", False,
                          "the bundle carries no CRG-VIR program, decision certificate, or "
                          "registered portable semantic proof artifact, "
                          "so no claim can be verified (24.1, 39.1)")
        for certificate in certificates:
            inner.append((str(certificate.get("certificate_id")), verify_certificate(
                certificate, registry=_registry_from(objects, certificate),
                clock=clock, clock_source=clock_source)))

    for name, sub in inner:
        result.checks.extend((f"{name}::{c}", p, d) for c, p, d in sub.checks)
        result.violations.extend(f"{name}::{v}" for v in sub.violations)
        result.warnings.extend(f"{name}::{w}" for w in sub.warnings)
    result.report["claims"] = [
        {
            "program": n,
            "claim_type": s.report.get("claim_type", "DECISION_CLAIM"),
            "claim_scope": s.report.get("claim_scope"),
            "status": s.status,
            "ok": s.ok,
            "report": s.report,
        }
        for n, s in inner
    ]
    # 25.3 requires the report itself to carry time, claim, and signature
    # judgments.  A single-claim bundle surfaces them directly rather than
    # burying them a level down where a reader could miss them (50.3).
    if len(inner) == 1:
        for key in ("time_judgment", "claim_judgment", "unsupported_checks"):
            if key in inner[0][1].report:
                result.report[key] = inner[0][1].report[key]
    # Portable semantic evidence can make a bundle multi-claim without adding
    # another time-bearing decision.  Preserve the sole verifier-owned time
    # judgment at bundle level in that case; otherwise the added evidence would
    # incorrectly erase an indeterminate validity judgment from the report.
    time_judgments = [
        {"claim": name, **sub.report["time_judgment"]}
        for name, sub in inner
        if isinstance(sub.report.get("time_judgment"), dict)
    ]
    if len(time_judgments) == 1:
        result.report["time_judgment"] = {
            key: value for key, value in time_judgments[0].items() if key != "claim"
        }
    elif time_judgments:
        result.report["time_judgments"] = time_judgments
    result.report.setdefault("signature_judgment",
                             "NOT_SIGNED" if not (manifest.get("signatures") or [])
                             else "UNCHECKED_PROFILE")

    result.finish()
    statuses = {s.status for _n, s in inner}
    if Status.EXPIRED in statuses:
        result.status = Status.EXPIRED
    elif not result.ok:
        result.status = Status.FAILED
    elif Status.TIME_INDETERMINATE in statuses:
        # A timeless proof artifact does not cure an undated decision claim.
        # Conservatively retain the time limitation when all other claims pass.
        result.status = Status.TIME_INDETERMINATE
    elif len(statuses) == 1:
        result.status = statuses.pop()
    elif statuses:
        result.status = Status.PARTIALLY_VERIFIED
    else:
        result.status = Status.INTEGRITY_ONLY
    decision_passed = bool(inner) and all(sub.ok for _name, sub in inner)
    if not v0_passed:
        achieved = "NONE"
    elif not structural_passed:
        achieved = Level.V0
    elif decision_passed:
        achieved = Level.V2
    else:
        achieved = Level.V1

    # -- V3: proof program, not merely a recomputed decision ---------------
    if level in (Level.V3, Level.V4) and decision_passed and v0_passed and structural_passed:
        proof_programs = [
            name for name, sub in inner
            if (
                (sub.report.get("level_achieved") == Level.V3
                 and name.startswith("verification/programs/"))
                or (
                    sub.ok
                    and name.startswith("objects/SafeCommitmentArtifact/")
                    and sub.report.get("artifact_type") == "SafeCommitmentArtifact"
                )
            )
        ]
        result.record(
            "v3_proof_profile",
            bool(proof_programs),
            (f"{len(proof_programs)} self-contained CRG-VIR proof program(s) passed"
             if proof_programs else
             "decision recomputation passed, but no self-contained CRG-VIR program or "
             "registered safe-commitment proof artifact established the V3 proof checks"),
        )
        result.finish()
        proof_passed = bool(proof_programs)
        if proof_passed:
            achieved = Level.V3
        else:
            result.status = Status.PARTIALLY_VERIFIED

    # -- V4: verifier-owned federation trust inputs ------------------------
    if level == Level.V4 and achieved == Level.V3:
        envelopes = [
            value for value in objects.values()
            if (isinstance(value, dict) and value.get("envelope_id")
                and value.get("bounded_result") is not None
                and value.get("target_context_fingerprint"))
        ]
        v4_checks, v4_report, v4_status = verify_federation(
            envelopes,
            context=federation_context,
            clock=clock,
            clock_source=clock_source,
        )
        for name, passed, detail in v4_checks:
            result.record(name, passed, detail)
        result.report.update(v4_report)
        result.finish()
        if result.ok:
            achieved = Level.V4
            result.status = v4_status
        else:
            result.status = v4_status

    result.report.update({"final_status": result.status,
                          "level_achieved": achieved})


def _verify_structural(
    result: VerificationResult,
    reader: _Reader,
    manifest: dict,
    objects: Dict[str, Any],
    root_case: Any,
) -> None:
    """Cumulative V1 checks from section 25.2.

    This is intentionally schema-independent: the verifier does not import
    the kernel's validators.  It checks the portable schema identities and
    the closed structural invariants directly from bundle bytes.
    """
    schema_failures: List[str] = []
    try:
        schema_manifest = reader.json("schemas/referenced-schema-manifest.json")
    except (ValueError, CanonicalError, KeyError) as error:
        schema_manifest = {}
        schema_failures.append(f"schema manifest cannot be decoded: {error}")
    declared_schemas = manifest.get("schema_identities")
    carried_schemas = (
        schema_manifest.get("schema_identities")
        if isinstance(schema_manifest, dict) else None
    )
    if not isinstance(declared_schemas, list) or declared_schemas != carried_schemas:
        schema_failures.append(
            "manifest schema_identities do not exactly match the carried schema manifest"
        )
    for index, identity in enumerate(declared_schemas or []):
        if not isinstance(identity, dict) or not identity.get("schema_id"):
            schema_failures.append(f"schema identity {index} has no schema_id")
        elif not is_hash(identity.get("schema_hash")):
            schema_failures.append(f"schema identity {index} has no valid schema_hash")
    result.record(
        "v1_schema_identity",
        not schema_failures,
        "; ".join(schema_failures) if schema_failures
        else f"{len(declared_schemas or [])} schema identities are hash-bound and matched",
    )

    version_failures: List[str] = []
    if manifest.get("bundle_format_version") != "1.0.0":
        version_failures.append(
            f"unsupported bundle format {manifest.get('bundle_format_version')!r}"
        )
    if manifest.get("crg_spec_version") != "0.2.0":
        version_failures.append(
            f"unsupported CRG specification version {manifest.get('crg_spec_version')!r}"
        )
    for name in ("quantity_registry_version", "rule_table_version"):
        value = manifest.get(name)
        if not isinstance(value, str) or not value or value.lower() == "unset":
            version_failures.append(f"{name} is not pinned")
    result.record(
        "v1_versions_supported",
        not version_failures,
        "; ".join(version_failures) if version_failures
        else "bundle, spec, quantity-registry, and rule-table versions are pinned and supported",
    )

    unit_failures: List[str] = []
    schemas_seen = 0
    for object_hash, value in objects.items():
        if not isinstance(value, dict):
            continue
        schema = value.get("schema") or value.get("coordinate_schema")
        if not isinstance(schema, dict) or not isinstance(schema.get("coordinates"), list):
            continue
        coordinates = schema["coordinates"]
        schemas_seen += 1
        identifiers: List[str] = []
        for index, coordinate in enumerate(coordinates):
            if not isinstance(coordinate, dict):
                unit_failures.append(f"{object_hash}: coordinate {index} is not an object")
                continue
            missing = [name for name in ("identifier", "quantity", "unit", "direction")
                       if not coordinate.get(name)]
            if missing:
                unit_failures.append(
                    f"{object_hash}: coordinate {index} omits {missing}"
                )
            identifier = str(coordinate.get("identifier") or "")
            if identifier in identifiers:
                unit_failures.append(f"{object_hash}: duplicate coordinate {identifier!r}")
            identifiers.append(identifier)
            if coordinate.get("direction") not in ("MINIMIZE", "MAXIMIZE"):
                unit_failures.append(
                    f"{object_hash}: coordinate {identifier!r} has unsupported direction"
                )
        for record in value.get("realizations") or value.get("entries") or []:
            if not isinstance(record, dict):
                unit_failures.append(f"{object_hash}: realization is not an object")
                continue
            signature = record.get("signature")
            if not isinstance(signature, list) or len(signature) != len(coordinates):
                unit_failures.append(
                    f"{object_hash}: realization {record.get('realization_id')!r} has "
                    f"signature dimension {len(signature) if isinstance(signature, list) else 'invalid'}; "
                    f"schema dimension is {len(coordinates)}"
                )
    result.record(
        "v1_units_and_coordinate_schemas",
        schemas_seen > 0 and not unit_failures,
        "; ".join(unit_failures) if unit_failures
        else f"{schemas_seen} coordinate schema(s) have explicit quantities, units, and dimensions",
    )

    identities = set(objects)
    identities.update(str(item.get("id")) for item in _inventory(manifest) if item.get("id"))
    root = manifest.get("root_case_object") or {}
    if isinstance(root, dict):
        identities.update(str(root.get(name)) for name in ("object_id", "content_hash")
                          if root.get(name))
    external = manifest.get("external_references") or []
    external_ids = {
        str(reference.get("immutable_identity"))
        for reference in external if isinstance(reference, dict) and reference.get("immutable_identity")
    }
    edges: List[Tuple[str, str, str]] = []
    migrations: List[dict] = []
    for value in objects.values():
        if not isinstance(value, dict):
            continue
        candidates = [value]
        candidates.extend(item for item in (value.get("dependency_edges") or [])
                          if isinstance(item, dict))
        for item in candidates:
            if item.get("edge_id") and item.get("source") and item.get("target"):
                edges.append((str(item["source"]), str(item["target"]), str(item["edge_id"])))
        if value.get("record_type") == "MigrationRecord" or value.get("migration_id"):
            migrations.append(value)

    open_edges = [edge_id for source, target, edge_id in edges
                  if source not in identities | external_ids or target not in identities | external_ids]
    result.record(
        "v1_dependency_closure",
        not open_edges,
        f"dependency edges have unresolved endpoints: {open_edges}" if open_edges
        else f"all endpoints of {len(edges)} typed dependency edge(s) are bundle-closed",
    )
    cyclic = _cycle_nodes(edges)
    result.record(
        "v1_dependency_acyclic",
        not cyclic,
        f"dependency graph contains a cycle through {cyclic}" if cyclic
        else f"the {len(edges)}-edge dependency graph is acyclic",
    )

    migration_failures: List[str] = []
    for migration in migrations:
        migration_failures.extend(_migration_evidence_failures(migration))
    result.record(
        "v1_migration_records",
        not migration_failures,
        "; ".join(migration_failures) if migration_failures
        else (f"{len(migrations)} migration record(s) have independently verified "
              "registered transform and classification evidence"),
    )


def _cycle_nodes(edges: List[Tuple[str, str, str]]) -> List[str]:
    adjacency: Dict[str, List[str]] = {}
    for source, target, _edge_id in edges:
        adjacency.setdefault(source, []).append(target)
    for targets in adjacency.values():
        targets.sort()
    visited: set = set()
    for node in sorted(adjacency):
        if node in visited:
            continue
        path: List[str] = [node]
        active = {node}
        stack: List[Tuple[str, int]] = [(node, 0)]
        while stack:
            current, index = stack[-1]
            targets = adjacency.get(current, [])
            if index >= len(targets):
                stack.pop()
                path.pop()
                active.remove(current)
                visited.add(current)
                continue
            target = targets[index]
            stack[-1] = (current, index + 1)
            if target in active:
                start = path.index(target)
                return path[start:] + [target]
            if target in visited:
                continue
            path.append(target)
            active.add(target)
            stack.append((target, 0))
    return []


def _bytes_hash(data: bytes) -> str:
    return "sha256:" + hashlib.sha256(data).hexdigest()


def _safe_member_name(name: str) -> bool:
    if not isinstance(name, str) or not name or "\\" in name:
        return False
    if name.startswith("/") or name.startswith("../"):
        return False
    parts = name.split("/")
    return all(part not in ("", ".", "..") for part in parts)


def _verify_binary_inventory(
    result: VerificationResult, reader: _Reader, inventory: Any,
    content_entries: Dict[str, str], *, kind: str, prefix: str, id_field: str,
) -> None:
    failures: List[str] = []
    paths = set()
    if not isinstance(inventory, list):
        failures.append(f"{kind}_inventory is not an array")
        inventory = []
    for item in inventory:
        if not isinstance(item, dict):
            failures.append(f"malformed {kind} entry {item!r}")
            continue
        identity = item.get(id_field)
        path = str(item.get("path") or "")
        stated = item.get("content_hash")
        if not identity or not _safe_member_name(path) or not path.startswith(prefix):
            failures.append(f"{kind} entry lacks identity or has unsafe/noncanonical path {path!r}")
            continue
        paths.add(path)
        if path not in reader.names:
            failures.append(f"missing {kind} member {path}")
            continue
        actual = _bytes_hash(reader.read(path))
        if not is_hash(stated) or actual != stated:
            failures.append(f"{path}: inventory states {stated!r}, bytes hash to {actual}")
        if content_entries.get(path) != stated:
            failures.append(f"{path}: {kind} inventory and content_hashes disagree")
        expected = prefix + str(stated).split(":", 1)[-1]
        if path != expected:
            failures.append(f"{path}: content-addressed path must be {expected}")
        length = item.get("byte_length")
        if length is not None and length != len(reader.read(path)):
            failures.append(f"{path}: declared byte_length {length} is incorrect")
    extras = sorted(name for name in reader.names if name.startswith(prefix) and name not in paths)
    if extras:
        failures.append(f"stored {kind}s absent from inventory: {extras}")
    result.record(
        f"{kind}_inventory_integrity", not failures,
        "; ".join(failures) if failures else f"all {len(paths)} {kind}s are inventoried and hash-bound",
    )


def _verify_partial_disclosure(
    result: VerificationResult, manifest: dict, requested_level: str
) -> None:
    partial = manifest.get("partial")
    if partial is None:
        result.note("partial_bundle_disclosure", "bundle does not declare itself partial")
        return
    required = (
        "omitted_objects", "omission_reason", "affected_claims",
        "expected_external_dependencies", "maximum_verification_level",
    )
    missing = [name for name in required if not isinstance(partial, dict) or name not in partial]
    result.record(
        "partial_bundle_disclosure", not missing,
        f"partial disclosure omits {missing} (39.4)" if missing
        else "partial bundle declares omissions, reason, affected claims, dependencies, and ceiling",
    )
    if missing or not isinstance(partial, dict):
        return
    aliases = {
        "V0": Level.V0, "INTEGRITY_ONLY": Level.V0,
        "V1": Level.V1, "STRUCTURAL_ONLY": Level.V1,
        "V2": Level.V2, "DECISION_ONLY": Level.V2,
        "V3": Level.V3, "PROOF": Level.V3, "PROOF_ONLY": Level.V3,
        "V4": Level.V4, "FEDERATION": Level.V4,
    }
    stated = str(partial.get("maximum_verification_level") or "").upper()
    ceiling = aliases.get(stated)
    permitted = (
        ceiling is not None
        and Level.ORDER.index(requested_level) <= Level.ORDER.index(ceiling)
    )
    result.record(
        "partial_bundle_level_ceiling",
        permitted,
        (f"requested {requested_level} is within declared ceiling {ceiling}"
         if permitted else
         f"requested {requested_level} exceeds or cannot interpret declared ceiling {stated!r}"),
    )


def _verify_manifest_semantics(
    result: VerificationResult, reader: _Reader, manifest: dict, manifest_bytes: bytes,
    requested_level: str,
    signature_verifier: Optional[
        Callable[[bytes, Mapping[str, Any]], Tuple[bool, str]]
    ],
) -> None:
    failures: List[str] = []
    for field in (
        "object_inventory", "artifact_inventory", "proof_inventory",
        "external_references", "schema_identities", "signatures",
    ):
        if not isinstance(manifest.get(field), list):
            failures.append(f"{field} must be an array")
    for field in ("encryption", "redaction_state", "export_authority", "creation_tool"):
        if not isinstance(manifest.get(field), dict):
            failures.append(f"{field} must be an object")
    tool = manifest.get("creation_tool")
    if isinstance(tool, dict) and (not tool.get("name") or not tool.get("version")):
        failures.append("creation_tool must declare name and version")
    for field in (
        "bundle_format_version", "crg_spec_version", "quantity_registry_version",
        "rule_table_version", "requested_verification_level",
    ):
        if not isinstance(manifest.get(field), str) or not manifest.get(field):
            failures.append(f"{field} must be a nonempty string")
    result.record(
        "manifest_field_types", not failures,
        "; ".join(failures) if failures else "manifest field shapes are valid",
    )

    reference_failures: List[str] = []
    reference_fields = (
        "immutable_identity", "expected_content_hash", "retrieval_policy",
        "required_access", "validity", "offline_behavior", "unavailable_behavior",
    )
    references = manifest.get("external_references")
    if isinstance(references, list):
        for index, reference in enumerate(references):
            if not isinstance(reference, dict):
                reference_failures.append(f"reference {index} is not an object")
                continue
            missing = [field for field in reference_fields if field not in reference]
            if missing:
                reference_failures.append(f"reference {index} omits {missing}")
            digest = reference.get("expected_content_hash")
            if digest is not None and not is_hash(digest):
                reference_failures.append(f"reference {index} has invalid expected_content_hash")
    result.record(
        "external_reference_profiles", not reference_failures,
        "; ".join(reference_failures) if reference_failures
        else f"{len(references or [])} external references are immutable and policy-complete",
    )

    encryption = manifest.get("encryption")
    encryption_failures: List[str] = []
    if isinstance(encryption, dict):
        encrypted = encryption.get("encrypted_objects") or []
        if encrypted and not encryption.get("protected_content_present"):
            encryption_failures.append("encrypted objects are listed but protected_content_present is false")
        for field in (
            "encrypted_objects", "claims_depending_on_protected_content",
            "verifier_capabilities_required", "independently_checkable",
        ):
            if field not in encryption:
                encryption_failures.append(f"encryption metadata omits {field}")
        if encrypted and requested_level != Level.V0 and not encryption.get("independently_checkable"):
            encryption_failures.append(
                f"encrypted content is not independently checkable at requested level {requested_level}"
            )
    result.record(
        "encryption_disclosure", not encryption_failures,
        "; ".join(encryption_failures) if encryption_failures
        else "encryption consequences are explicitly disclosed",
    )

    signatures = manifest.get("signatures")
    if isinstance(signatures, list) and signatures:
        if "signatures/manifest.sig" not in reader.names:
            result.record(
                "signature_verification", False,
                "the manifest declares signatures but signatures/manifest.sig is absent",
            )
            result.report["signature_judgment"] = "MISSING"
        elif signature_verifier is None:
            result.record(
                "signature_verification", False,
                "the bundle declares signatures, but no supported signature verifier was "
                "supplied to the dependency-free core; authenticity is not established",
            )
            result.report["signature_judgment"] = "UNSUPPORTED_PROFILE"
        else:
            try:
                document = decode(reader.read("signatures/manifest.sig").decode("utf-8"))
                if not isinstance(document, dict):
                    raise ValueError("signature document is not a JSON object")
                verified, detail = signature_verifier(manifest_bytes, document)
            except Exception as error:  # fail closed at the optional trust-provider boundary
                verified, detail = False, f"signature verifier failed: {type(error).__name__}: {error}"
            result.record("signature_verification", bool(verified), str(detail))
            result.report["signature_judgment"] = "VERIFIED" if verified else "FAILED"
    else:
        stray = "signatures/manifest.sig" in reader.names
        result.record(
            "signature_verification", not stray,
            "signature member is present but the manifest declares no signature descriptor"
            if stray else "bundle declares no signatures; integrity only",
        )
        result.report["signature_judgment"] = "UNDECLARED" if stray else "NOT_SIGNED"


def _registry_from(objects: Dict[str, Any], certificate: dict) -> dict:
    """Assemble a verification registry from the bundle's own objects."""
    registry: Dict[str, Any] = {"objects": objects}
    bundle = objects.get(certificate.get("retained_registry_hash")) or objects.get(
        certificate.get("complete_registry_hash"))
    if isinstance(bundle, dict):
        registry["schema"] = bundle.get("schema") or {}
        registry["entries"] = [
            {"realization_id": r.get("realization_id"), "signature": r.get("signature", []),
             "legality": r.get("legality", "LEGAL"),
             "evidence_class": r.get("evidence_class", "IMPORTED"),
             "attributes": r.get("attributes") or {}}
            for r in bundle.get("realizations", [])]
    return registry
