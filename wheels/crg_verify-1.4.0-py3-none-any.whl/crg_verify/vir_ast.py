"""Typed, deterministic, resource-bounded CRG-VIR value language (§24).

This evaluator is intentionally dependency-free and has no extension or I/O
hooks.  Programs are JSON trees; every loop is over a carried finite value and
every evaluation consumes a verifier-owned operation budget.  Values are
decoded before use, so a binary float, an ill-typed branch, an inverted
interval, or a unit mismatch is a refusal rather than an implicit coercion.
"""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from .arith import ArithError, fmt, interval, rational

__all__ = [
    "AST_VERSION", "VirProgramError", "Quantity", "evaluate_program",
    "encode_value", "validate_value",
]

AST_VERSION = "0.2.0"
SCALAR_TYPES = frozenset({"integer", "rational", "decimal"})
REFERENCE_TYPES = frozenset({"object_ref", "geometry_ref", "proof_ref"})
COLLECTION_TYPES = frozenset({"vector", "matrix", "set", "map"})


class VirProgramError(ValueError):
    """The carried program is malformed, ill-typed, or exceeds its bounds."""


@dataclass(frozen=True)
class Quantity:
    value: Fraction
    unit: str


@dataclass
class _Budget:
    operations_left: int
    max_collection: int
    max_depth: int

    def spend(self, depth: int) -> None:
        if depth > self.max_depth:
            raise VirProgramError(
                f"program nesting depth {depth} exceeds max_depth {self.max_depth}"
            )
        self.operations_left -= 1
        if self.operations_left < 0:
            raise VirProgramError("program exceeded its max_operations budget")

    def collection(self, value: Sequence[Any]) -> None:
        if len(value) > self.max_collection:
            raise VirProgramError(
                f"finite collection has {len(value)} items, exceeding max_collection "
                f"{self.max_collection}"
            )


def _type_name(value: Any) -> str:
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, int) and not isinstance(value, bool):
        return "integer"
    if isinstance(value, Fraction):
        return "rational"
    if isinstance(value, Quantity):
        return "quantity"
    if isinstance(value, tuple):
        return "vector"
    if isinstance(value, frozenset):
        return "set"
    if isinstance(value, dict):
        return "map"
    if isinstance(value, str):
        return "reference"
    return type(value).__name__


def validate_value(value: Any, declared_type: str) -> Any:
    """Decode one external value according to a §24.2 type declaration."""
    kind = str(declared_type)
    try:
        if kind == "boolean":
            if not isinstance(value, bool):
                raise VirProgramError("boolean input is not a JSON boolean")
            return value
        if kind == "integer":
            decoded = rational(value)
            if decoded.denominator != 1:
                raise VirProgramError("integer input has a fractional value")
            return decoded.numerator
        if kind in {"rational", "decimal"}:
            return rational(value)
        if kind == "interval":
            return interval(value)
        if kind == "quantity":
            if not isinstance(value, Mapping) or not str(value.get("unit", "")):
                raise VirProgramError("quantity input requires value and non-empty unit")
            return Quantity(rational(value.get("value")), str(value["unit"]))
        if kind == "vector":
            if not isinstance(value, (list, tuple)):
                raise VirProgramError("vector input is not a finite sequence")
            return tuple(_decode_untyped(v) for v in value)
        if kind == "matrix":
            if not isinstance(value, (list, tuple)):
                raise VirProgramError("matrix input is not a finite row sequence")
            rows = tuple(validate_value(row, "vector") for row in value)
            if rows and any(len(row) != len(rows[0]) for row in rows):
                raise VirProgramError("matrix rows have different lengths")
            return rows
        if kind == "set":
            if not isinstance(value, (list, tuple, set, frozenset)):
                raise VirProgramError("set input is not a finite collection")
            decoded = tuple(_decode_untyped(v) for v in value)
            try:
                return frozenset(decoded)
            except TypeError as exc:
                raise VirProgramError("set elements must be scalar or reference values") from exc
        if kind == "map":
            if not isinstance(value, Mapping):
                raise VirProgramError("map input is not an object")
            return {str(k): _decode_untyped(v) for k, v in value.items()}
        if kind in REFERENCE_TYPES:
            if not isinstance(value, str) or not value:
                raise VirProgramError(f"{kind} input must be a non-empty string")
            return value
    except ArithError as exc:
        raise VirProgramError(str(exc)) from exc
    raise VirProgramError(f"unsupported CRG-VIR type {kind!r}")


def _decode_untyped(value: Any) -> Any:
    if isinstance(value, bool):
        return value
    if isinstance(value, int) and not isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value
    if isinstance(value, Mapping):
        if "exact" in value or {"numerator", "denominator"} <= set(value):
            return rational(value)
        if "lo" in value and "hi" in value:
            return interval(value)
        if "value" in value and "unit" in value:
            return Quantity(rational(value["value"]), str(value["unit"]))
        return {str(k): _decode_untyped(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return tuple(_decode_untyped(v) for v in value)
    if isinstance(value, float):
        raise VirProgramError("binary floating point is prohibited in CRG-VIR")
    if value is None:
        return None
    raise VirProgramError(f"unsupported literal value {type(value).__name__}")


def encode_value(value: Any) -> Any:
    """Return a canonical-JSON-compatible representation of an evaluated value."""
    if isinstance(value, Fraction):
        return {"exact": fmt(value)}
    if isinstance(value, Quantity):
        return {"value": {"exact": fmt(value.value)}, "unit": value.unit}
    if isinstance(value, tuple):
        return [encode_value(v) for v in value]
    if isinstance(value, frozenset):
        return sorted((encode_value(v) for v in value), key=repr)
    if isinstance(value, dict):
        return {k: encode_value(v) for k, v in sorted(value.items())}
    return value


def _numeric(value: Any) -> Fraction:
    if isinstance(value, bool):
        raise VirProgramError("boolean used as a number")
    if isinstance(value, int):
        return Fraction(value)
    if isinstance(value, Fraction):
        return value
    raise VirProgramError(f"{_type_name(value)} used as an exact scalar")


def _interval_value(value: Any) -> Tuple[Fraction, Fraction]:
    if isinstance(value, tuple) and len(value) == 2 and all(
        isinstance(v, Fraction) for v in value
    ):
        return value
    scalar = _numeric(value)
    return scalar, scalar


def _finite(value: Any, budget: _Budget) -> Tuple[Any, ...]:
    if isinstance(value, (tuple, frozenset)):
        result = tuple(value)
    elif isinstance(value, dict):
        result = tuple(value[k] for k in sorted(value))
    else:
        raise VirProgramError(f"{_type_name(value)} is not a finite collection")
    budget.collection(result)
    return result


def _same_quantity(a: Any, b: Any) -> Tuple[Quantity, Quantity]:
    if not isinstance(a, Quantity) or not isinstance(b, Quantity):
        raise VirProgramError("quantity arithmetic requires two quantities")
    if a.unit != b.unit:
        raise VirProgramError(f"quantity unit mismatch: {a.unit!r} versus {b.unit!r}")
    return a, b


def _arith(op: str, a: Any, b: Any) -> Any:
    if isinstance(a, Quantity) or isinstance(b, Quantity):
        qa, qb = _same_quantity(a, b)
        if op == "add":
            return Quantity(qa.value + qb.value, qa.unit)
        if op == "subtract":
            return Quantity(qa.value - qb.value, qa.unit)
        raise VirProgramError(f"{op} is not defined for two quantities")
    if isinstance(a, tuple) or isinstance(b, tuple):
        alo, ahi = _interval_value(a)
        blo, bhi = _interval_value(b)
        if op == "add":
            return alo + blo, ahi + bhi
        if op == "subtract":
            return alo - bhi, ahi - blo
        if op == "multiply":
            products = (alo * blo, alo * bhi, ahi * blo, ahi * bhi)
            return min(products), max(products)
        if op == "exact_divide":
            if blo <= 0 <= bhi:
                raise VirProgramError("interval divisor contains zero")
            reciprocals = (Fraction(1, 1) / blo, Fraction(1, 1) / bhi)
            return _arith("multiply", (alo, ahi), (min(reciprocals), max(reciprocals)))
    left, right = _numeric(a), _numeric(b)
    if op == "add":
        return left + right
    if op == "subtract":
        return left - right
    if op == "multiply":
        return left * right
    if right == 0:
        raise VirProgramError("exact division by zero")
    return left / right


def _eval(node: Any, env: Dict[str, Any], budget: _Budget, depth: int) -> Any:
    if not isinstance(node, Mapping):
        raise VirProgramError("every expression node must be an object")
    budget.spend(depth)
    op = str(node.get("op", ""))
    if op == "literal":
        return validate_value(node.get("value"), str(node.get("type", "")))
    if op == "input":
        name = str(node.get("name", ""))
        if name not in env:
            raise VirProgramError(f"program input {name!r} is not bound")
        return env[name]

    def one(key: str = "value") -> Any:
        return _eval(node.get(key), env, budget, depth + 1)

    def two() -> Tuple[Any, Any]:
        return one("left"), one("right")

    if op in {"add", "subtract", "multiply", "exact_divide"}:
        return _arith(op, *two())
    if op == "integer_power":
        base, exponent = two()
        power = _numeric(exponent)
        if power.denominator != 1:
            raise VirProgramError("integer_power exponent is not an integer")
        if isinstance(base, tuple):
            if power < 0:
                raise VirProgramError("negative interval powers are unsupported")
            lo, hi = _interval_value(base)
            candidates = [lo ** power.numerator, hi ** power.numerator]
            if lo <= 0 <= hi and power.numerator % 2 == 0:
                candidates.append(Fraction(0))
            return min(candidates), max(candidates)
        return _numeric(base) ** power.numerator
    if op in {"sum", "minimum", "maximum"}:
        values = _finite(one("collection"), budget)
        if not values and op != "sum":
            raise VirProgramError(f"{op} of an empty collection is undefined")
        if op == "sum":
            if not values:
                return Fraction(0)
            result: Any = values[0]
            for value in values[1:]:
                result = _arith("add", result, value)
            return result
        scalars = tuple(_numeric(v) for v in values)
        return min(scalars) if op == "minimum" else max(scalars)
    if op == "dot_product":
        left, right = two()
        a, b = _finite(left, budget), _finite(right, budget)
        if len(a) != len(b):
            raise VirProgramError("dot-product dimension mismatch")
        return sum((_numeric(x) * _numeric(y) for x, y in zip(a, b)), Fraction(0))
    if op == "absolute_value":
        value = one()
        if isinstance(value, tuple):
            lo, hi = _interval_value(value)
            candidates = (abs(lo), abs(hi))
            return (Fraction(0) if lo <= 0 <= hi else min(candidates), max(candidates))
        return abs(_numeric(value))
    if op == "interval_construct":
        lo, hi = two()
        lower, upper = _numeric(lo), _numeric(hi)
        if upper < lower:
            raise VirProgramError("interval upper bound is below lower bound")
        return lower, upper
    if op == "interval_contains":
        container, item = two()
        lo, hi = _interval_value(container)
        item_lo, item_hi = _interval_value(item)
        return lo <= item_lo and item_hi <= hi
    if op == "unit_convert":
        value = one()
        if not isinstance(value, Quantity):
            raise VirProgramError("unit_convert requires a quantity")
        source = str(node.get("from_unit", value.unit))
        target = str(node.get("to_unit", ""))
        if value.unit != source or not target:
            raise VirProgramError("unit conversion source/target does not match the quantity")
        return Quantity(value.value * rational(node.get("factor")), target)
    if op in {"equal", "not_equal"}:
        a, b = two()
        equal = a == b
        return equal if op == "equal" else not equal
    if op in {"less_than", "greater_than"}:
        a, b = two()
        comparison = _numeric(a) < _numeric(b)
        return comparison if op == "less_than" else _numeric(a) > _numeric(b)
    if op == "dominance":
        left, right = two()
        a, b = _finite(left, budget), _finite(right, budget)
        if len(a) != len(b):
            raise VirProgramError("dominance dimension mismatch")
        directions = tuple(str(v).upper() for v in node.get("directions", ()))
        if directions and len(directions) != len(a):
            raise VirProgramError("dominance directions dimension mismatch")
        directions = directions or ("MINIMIZE",) * len(a)
        weak, strict = True, False
        for x, y, direction in zip(a, b, directions):
            xv, yv = _numeric(x), _numeric(y)
            if direction == "MINIMIZE":
                weak, strict = weak and xv <= yv, strict or xv < yv
            elif direction == "MAXIMIZE":
                weak, strict = weak and xv >= yv, strict or xv > yv
            else:
                raise VirProgramError(f"unknown optimization direction {direction!r}")
        return weak and strict
    if op == "member_of":
        item, collection = two()
        return item in _finite(collection, budget)
    if op in {"and", "or"}:
        args = node.get("args")
        if not isinstance(args, list):
            raise VirProgramError(f"{op} requires an args list")
        budget.collection(args)
        values = [_eval(arg, env, budget, depth + 1) for arg in args]
        if any(not isinstance(v, bool) for v in values):
            raise VirProgramError(f"{op} operands must be boolean")
        return all(values) if op == "and" else any(values)
    if op == "not":
        value = one()
        if not isinstance(value, bool):
            raise VirProgramError("not operand must be boolean")
        return not value
    if op == "implies":
        premise, consequence = two()
        if not isinstance(premise, bool) or not isinstance(consequence, bool):
            raise VirProgramError("implication operands must be boolean")
        return (not premise) or consequence
    if op == "conditional":
        condition = one("condition")
        if not isinstance(condition, bool):
            raise VirProgramError("conditional test must be boolean")
        return one("then" if condition else "else")
    if op in {"for_all", "exists", "bounded_reduce"}:
        collection = _finite(one("collection"), budget)
        variable = str(node.get("var", ""))
        if not variable or variable in env:
            raise VirProgramError("bound variable is empty or shadows an existing input")
        values = []
        for item in collection:
            nested = dict(env)
            nested[variable] = item
            values.append(_eval(node.get("body"), nested, budget, depth + 1))
        if op in {"for_all", "exists"}:
            if any(not isinstance(v, bool) for v in values):
                raise VirProgramError(f"{op} body must return boolean")
            return all(values) if op == "for_all" else any(values)
        reducer = str(node.get("reducer", ""))
        if reducer not in {"add", "minimum", "maximum", "and", "or"}:
            raise VirProgramError(f"unsupported bounded reducer {reducer!r}")
        if not values:
            if "initial" not in node:
                raise VirProgramError("empty bounded reduction requires an initial value")
            return one("initial")
        result = values[0]
        for value in values[1:]:
            if reducer == "add":
                result = _arith("add", result, value)
            elif reducer == "minimum":
                result = min(_numeric(result), _numeric(value))
            elif reducer == "maximum":
                result = max(_numeric(result), _numeric(value))
            elif reducer == "and":
                if not isinstance(result, bool) or not isinstance(value, bool):
                    raise VirProgramError("and reduction requires booleans")
                result = result and value
            else:
                if not isinstance(result, bool) or not isinstance(value, bool):
                    raise VirProgramError("or reduction requires booleans")
                result = result or value
        return result
    raise VirProgramError(f"operation {op!r} is outside the executable baseline profile")


def evaluate_program(
    program: Mapping[str, Any],
    inputs: Mapping[str, Any],
    declared_inputs: Mapping[str, str],
    limits: Mapping[str, Any],
) -> Any:
    """Type-check and evaluate a CRG-VIR program under verifier-owned bounds."""
    if not isinstance(program, Mapping):
        raise VirProgramError("program is not an object")
    if str(program.get("ast_version", "")) != AST_VERSION:
        raise VirProgramError(
            f"program AST version {program.get('ast_version')!r} is not {AST_VERSION!r}"
        )
    if not isinstance(inputs, Mapping) or not isinstance(declared_inputs, Mapping):
        raise VirProgramError("program inputs and declarations must be maps")
    missing = sorted(set(declared_inputs) - set(inputs))
    extra = sorted(set(inputs) - set(declared_inputs))
    if missing or extra:
        raise VirProgramError(f"input binding mismatch: missing={missing}, extra={extra}")
    env = {
        str(name): validate_value(inputs[name], str(kind))
        for name, kind in declared_inputs.items()
    }
    try:
        max_operations = int(limits.get("max_operations", 0))
        max_collection = int(limits.get("max_collection", 0))
        max_depth = int(limits.get("max_depth", 0))
    except (TypeError, ValueError) as exc:
        raise VirProgramError("program resource limits are not integers") from exc
    if min(max_operations, max_collection, max_depth) <= 0:
        raise VirProgramError(
            "max_operations, max_collection, and max_depth must be positive"
        )
    result = _eval(
        program.get("expression"), env,
        _Budget(max_operations, max_collection, max_depth), 1,
    )
    declared_result = str(program.get("result_type", ""))
    # Validate the evaluator's output without accepting a coercion.
    if declared_result == "boolean" and not isinstance(result, bool):
        raise VirProgramError(
            f"program declared boolean but evaluated to {_type_name(result)}"
        )
    if declared_result != "boolean":
        validate_value(encode_value(result), declared_result)
    return result
