"""Independent stdlib-only checker for the shared certified-phase binding.

This verifier imports neither the model contract nor any producer/consumer
package.  It replays the carried ``PhaseAnalysisRecord`` using the existing
independent phase engine, reconstructs the exact binding wire image, and then
checks consumer receipts against that independently established identity.
"""
from __future__ import annotations

from typing import Any, Mapping

from .canonical import CanonicalError, content_hash, is_hash
from .certificate import Status, VerificationResult
from .phase_delta import verify_phase_analysis_record

__all__ = [
    "verify_certified_phase_binding",
    "verify_certified_phase_consumption",
]

_SCHEMA_VERSION = "1.2.0"
_BINDING_PROFILE = "CRG_CERTIFIED_PHASE_BINDING_V1"
_PHASE_PROFILE = "TWO_COORDINATE_PRICE_SIMPLEX_V1"
_PHASE_PROFILE_VERSION = "1"
_VERIFICATION_PROGRAM = "crg-verify.phase-analysis/v1"
_CONSUMERS = frozenset(
    {
        "CERTIFICATION",
        "CERTIFIED_CHANGE",
        "ETQ_DECISION_CONSEQUENCE",
        "TRANSITION_AUTHORIZATION",
    }
)
_REQUIRED_CHECKS = (
    "phase_profile",
    "phase_source_binding",
    "phase_policy_derivation",
    "phase_partition",
    "phase_stability",
    "phase_identity",
    "phase_wire",
)


class _DecodeError(ValueError):
    pass


def _object(value: Any, where: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise _DecodeError(f"{where} must be an object")
    return value


def _keys(value: Mapping[str, Any], required: set[str], where: str) -> None:
    missing = required - set(value)
    unknown = set(value) - required
    if missing:
        raise _DecodeError(f"{where} is missing fields {sorted(missing)}")
    if unknown:
        raise _DecodeError(f"{where} has unsupported fields {sorted(unknown)}")


def _stable_id(prefix: str, identity: Mapping[str, Any]) -> str:
    return f"{prefix}-{content_hash(dict(identity)).split(':', 1)[1][:20]}"


def _receipt(phase_result: VerificationResult, phase_root: str, source_root: str) -> dict:
    return {
        "verification_program": _VERIFICATION_PROGRAM,
        "status": "VERIFIED_RELATIVE",
        "phase_analysis_root": phase_root,
        "source_r_root": source_root,
        "checks_passed": list(_REQUIRED_CHECKS),
        "verification_result_hash": content_hash(phase_result.to_json()),
    }


def _expected_binding(binding: Mapping[str, Any]) -> tuple[dict, VerificationResult]:
    _keys(
        binding,
        {
            "record_type",
            "schema_version",
            "binding_profile",
            "binding_id",
            "phase_identity",
            "phase_analysis",
            "source_r",
            "verification",
            "claim_scope",
            "claim_limitations",
        },
        "certified-phase binding",
    )
    if binding.get("record_type") != "CertifiedPhaseBinding":
        raise _DecodeError("record_type is not CertifiedPhaseBinding")
    if binding.get("schema_version") != _SCHEMA_VERSION:
        raise _DecodeError(
            f"unsupported certified-phase binding version {binding.get('schema_version')!r}"
        )
    binding_profile = _object(binding.get("binding_profile"), "binding_profile")
    _keys(binding_profile, {"profile_id", "profile_version"}, "binding_profile")
    if binding_profile != {"profile_id": _BINDING_PROFILE, "profile_version": "1"}:
        raise _DecodeError("unregistered certified-phase binding profile")

    phase = _object(binding.get("phase_analysis"), "phase_analysis")
    source = _object(binding.get("source_r"), "source_r")
    phase_result = verify_phase_analysis_record(phase, source)
    if not phase_result.ok or phase_result.status != Status.VERIFIED_RELATIVE:
        raise _DecodeError(
            "carried phase evidence fails independent replay: "
            + "; ".join(phase_result.violations or [phase_result.status])
        )
    phase_root = content_hash(dict(phase))
    source_root = content_hash(dict(source))
    profile = _object(phase.get("profile"), "phase_analysis.profile")
    profile_id = profile.get("profile_id")
    profile_version = profile.get("profile_version")
    if profile_id != _PHASE_PROFILE or profile_version != _PHASE_PROFILE_VERSION:
        raise _DecodeError("phase analysis uses an unregistered profile/version")
    analysis_id = phase.get("analysis_id")
    if not isinstance(analysis_id, str) or not analysis_id:
        raise _DecodeError("phase analysis has no identity")
    identity = {
        "schema_version": _SCHEMA_VERSION,
        "analysis_id": analysis_id,
        "phase_analysis_root": phase_root,
        "source_r_root": source_root,
        "phase_profile_id": profile_id,
        "phase_profile_version": profile_version,
    }
    expected = {
        "record_type": "CertifiedPhaseBinding",
        "schema_version": _SCHEMA_VERSION,
        "binding_profile": {
            "profile_id": _BINDING_PROFILE,
            "profile_version": "1",
        },
        "binding_id": _stable_id("certified-phase-binding", identity),
        "phase_identity": {
            "analysis_id": analysis_id,
            "phase_analysis_root": phase_root,
            "source_r_root": source_root,
            "phase_profile_id": profile_id,
            "phase_profile_version": profile_version,
        },
        "phase_analysis": dict(phase),
        "source_r": dict(source),
        "verification": _receipt(phase_result, phase_root, source_root),
        "claim_scope": "RELATIVE_TO_CARRIED_SOURCE_R_AND_REGISTERED_PHASE_PROFILE",
        "claim_limitations": [
            "CERTIFIED_PHASE_BOUNDARY_LANGUAGE_REQUIRES_THIS_BINDING",
            "ACTIVE_COORDINATES_AND_BOTTLENECKS_ARE_NOT_PHASE_BOUNDARIES",
            "EXTERNAL_OPERATIONAL_STATE_LABELS_ARE_NOT_CRG_PHASE_EVIDENCE",
        ],
    }
    return expected, phase_result


def verify_certified_phase_binding(binding: Mapping[str, Any]) -> VerificationResult:
    """Independently replay the complete portable certified-phase binding."""
    result = VerificationResult(ok=False, status=Status.FAILED)
    if not isinstance(binding, Mapping):
        result.record("phase_binding_wire", False, "binding must be a JSON object")
        return result.finish()
    if binding.get("schema_version") != _SCHEMA_VERSION:
        result.status = Status.UNSUPPORTED_PROFILE
        result.record(
            "phase_binding_profile",
            False,
            f"unsupported binding version {binding.get('schema_version')!r}",
        )
        return result.finish()
    try:
        expected, phase_result = _expected_binding(binding)
        binding_root = content_hash(dict(binding))
    except (CanonicalError, _DecodeError, TypeError, ValueError) as error:
        detail = str(error)
        if "unregistered" in detail or "unsupported" in detail:
            result.status = Status.UNSUPPORTED_PROFILE
        result.record("phase_binding_decode", False, detail)
        return result.finish()

    identity = _object(binding.get("phase_identity"), "phase_identity")
    result.record(
        "phase_binding_phase_replay",
        phase_result.ok and phase_result.status == Status.VERIFIED_RELATIVE,
        "PhaseAnalysisRecord independently replayed relative to its carried source R",
    )
    result.record(
        "phase_binding_identity",
        identity == expected["phase_identity"],
        "analysis id, phase root, source-R root, and registered profile are exact",
    )
    result.record(
        "phase_binding_verification_receipt",
        binding.get("verification") == expected["verification"],
        "verification receipt is reconstructed from the independent phase result",
    )
    result.record(
        "phase_binding_wire",
        dict(binding) == expected,
        "entire versioned binding equals the independent reconstruction",
    )
    result.report.update(
        {
            "binding_root": binding_root,
            "phase_analysis_root": expected["phase_identity"]["phase_analysis_root"],
            "source_r_root": expected["phase_identity"]["source_r_root"],
            "analysis_id": expected["phase_identity"]["analysis_id"],
        }
    )
    if not result.violations:
        result.status = Status.VERIFIED_RELATIVE
    return result.finish()


def verify_certified_phase_consumption(
    consumption: Mapping[str, Any],
    binding: Mapping[str, Any],
) -> VerificationResult:
    """Verify that one consumer receipt names the exact shared phase identity."""
    result = VerificationResult(ok=False, status=Status.FAILED)
    binding_result = verify_certified_phase_binding(binding)
    if not binding_result.ok:
        result.record(
            "phase_consumption_binding",
            False,
            "certified-phase binding failed independent verification",
        )
        result.report["binding_violations"] = list(binding_result.violations)
        return result.finish()
    try:
        item = _object(consumption, "certified-phase consumption")
        _keys(
            item,
            {
                "record_type",
                "schema_version",
                "consumption_id",
                "consumer",
                "subject_root",
                "certified_phase_binding_root",
                "phase_analysis_root",
                "source_r_root",
                "analysis_id",
            },
            "certified-phase consumption",
        )
        if item.get("record_type") != "CertifiedPhaseConsumption":
            raise _DecodeError("record_type is not CertifiedPhaseConsumption")
        if item.get("schema_version") != _SCHEMA_VERSION:
            raise _DecodeError("unsupported certified-phase consumption version")
        consumer = item.get("consumer")
        if consumer not in _CONSUMERS:
            raise _DecodeError(f"unknown certified-phase consumer {consumer!r}")
        subject_root = item.get("subject_root")
        if not is_hash(subject_root):
            raise _DecodeError("consumer subject_root is not a SHA-256 root")
        phase_root = binding_result.report["phase_analysis_root"]
        source_root = binding_result.report["source_r_root"]
        binding_root = binding_result.report["binding_root"]
        analysis_id = binding_result.report["analysis_id"]
        identity = {
            "schema_version": _SCHEMA_VERSION,
            "consumer": consumer,
            "subject_root": subject_root,
            "certified_phase_binding_root": binding_root,
            "phase_analysis_root": phase_root,
            "source_r_root": source_root,
            "analysis_id": analysis_id,
        }
        expected = {
            "record_type": "CertifiedPhaseConsumption",
            "schema_version": _SCHEMA_VERSION,
            "consumption_id": _stable_id("certified-phase-consumption", identity),
            "consumer": consumer,
            "subject_root": subject_root,
            "certified_phase_binding_root": binding_root,
            "phase_analysis_root": phase_root,
            "source_r_root": source_root,
            "analysis_id": analysis_id,
        }
        consumption_root = content_hash(dict(item))
    except (CanonicalError, _DecodeError, TypeError, ValueError) as error:
        result.record("phase_consumption_decode", False, str(error))
        return result.finish()

    result.record(
        "phase_consumption_binding",
        True,
        "shared certified-phase binding independently verified",
    )
    result.record(
        "phase_consumption_identity",
        all(item.get(name) == expected[name] for name in (
            "certified_phase_binding_root",
            "phase_analysis_root",
            "source_r_root",
            "analysis_id",
        )),
        "consumer names the exact shared phase-analysis and source-R identities",
    )
    result.record(
        "phase_consumption_wire",
        dict(item) == expected,
        "entire versioned consumption receipt equals the independent reconstruction",
    )
    result.report.update(
        {
            "consumption_root": consumption_root,
            "consumer": expected["consumer"],
            "subject_root": expected["subject_root"],
            "binding_root": expected["certified_phase_binding_root"],
            "phase_analysis_root": expected["phase_analysis_root"],
            "source_r_root": expected["source_r_root"],
        }
    )
    if not result.violations:
        result.status = Status.VERIFIED_RELATIVE
    return result.finish()
