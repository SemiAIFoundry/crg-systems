"""Independent verifier for the v1.4 cumulative lifecycle comparison.

The verifier uses only the standard library and sibling independent verifier
modules.  It replays the v1.1 comparison, v1.2 change comparison, and every
v1.3/v1.4 lifecycle envelope, then reconstructs the fixed denominator,
direct-field summary, and privacy counts.
"""
from __future__ import annotations

from typing import Any, Mapping, Sequence

from .canonical import CanonicalError, content_hash, hash_without, is_hash
from .certificate import Status, VerificationResult
from .comparison import verify_comparative_workflow_evaluation
from .comparative_change import verify_comparative_change_evidence
from .portable_lifecycle import verify_lifecycle_replay_envelope

__all__ = ["verify_cumulative_lifecycle_comparison"]


SCHEMA_VERSION = "1.4.0"
PROFILE = "crg-cumulative-lifecycle-comparison/portable@1"
FIRST_RELEASE = "v1.4/UNIFIED_DECISION_LIFECYCLE"
AUTHORITY = "NON_AUTHORIZING"
CLAIM_BOUNDARY = (
    "Content-bound journey evidence only. This record does not authorize case state, "
    "declassify an input, establish field performance, infer business savings or ROI, "
    "rank methods, generalize beyond the declared scope, or replace any engineering "
    "workflow that produced the bound artifacts."
)

ROLE_SPECS = (
    ("v1.1", "SCOPED_WORKFLOW_COMPARISON", "ComparativeWorkflowEvaluation", False),
    ("v1.2", "CERTIFIED_CHANGE_COMPARISON", "ComparativeChangeEvidence", False),
    ("v1.3", "ETQ_RESULT_INGESTION", "ResultIngestionRecord", True),
    ("v1.3", "QUALIFICATION_DISPOSITION", "QualificationDisposition", True),
    ("v1.3", "SELECTIVE_REVALIDATION", "SelectiveRevalidationRecord", True),
    ("v1.3", "REPLACEMENT", "ReplacementRecord", True),
    ("v1.4", "CONTINUED_VALIDITY", "ContinuedValidityView", True),
    ("v1.4", "LIFECYCLE_REPLAY", "LifecycleReplayRecord", True),
    ("v1.4", "BACKUP_RESTORE_RECOVERY", "BackupRestoreRecoveryRecord", True),
    ("v1.4", "MIGRATION_REVERIFICATION", "MigrationReverificationRecord", True),
)
_STAGES = ("v1.1", "v1.2", "v1.3", "v1.4")
_TOP_FIELDS = frozenset(
    {
        "record_type",
        "schema_version",
        "profile",
        "first_release_attribution",
        "journey_id",
        "authority",
        "authorizing",
        "semantic_effect",
        "evidence_class",
        "claim_boundary",
        "scope",
        "artifacts",
        "denominator",
        "journey_facts",
        "privacy_summary",
        "limitations",
        "record_hash",
    }
)
_ENTRY_FIELDS = frozenset(
    {
        "artifact_id",
        "stage",
        "role",
        "record_type",
        "portable_lifecycle_envelope",
        "artifact",
        "artifact_hash",
        "privacy",
        "entry_hash",
    }
)
_SCOPE_FIELDS = frozenset(
    {
        "case_id",
        "technology_scope",
        "decision_scope",
        "evidence_scope",
        "change_scope",
        "journey_time_scope",
        "release_stages",
        "scope_hash",
    }
)
_PRIVACY_FIELDS = frozenset(
    {
        "classification",
        "classification_basis",
        "export_permitted",
        "redaction_applied",
        "field_observation",
        "input_class",
        "evidence_class",
    }
)
_PRIVACY_CLASSIFICATIONS = frozenset(
    {"PUBLIC_REFERENCE", "LOCAL_PRIVATE", "REDACTED_PORTABLE"}
)
_FORBIDDEN_KEYS = frozenset(
    {
        "roi",
        "return_on_investment",
        "savings",
        "superiority",
        "generalization",
        "method_ranking",
        "winner_method",
        "aggregate_score",
        "readiness_score",
        "confidence_score",
    }
)


def _identity(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value.strip() or value != value.strip():
        raise ValueError(f"{field} must be a normalized non-empty string")
    return value


def _object(value: Any, field: str) -> dict:
    if not isinstance(value, Mapping):
        raise ValueError(f"{field} must be an object")
    return dict(value)


def _exact_count(value: int) -> dict:
    return {"exact": str(value)}


def _sealed(value: Mapping[str, Any], key: str) -> tuple[bool, str]:
    stated = value.get(key)
    if not is_hash(stated):
        return False, f"{key} is not a portable SHA-256 hash"
    try:
        actual = hash_without(dict(value), key)
    except (CanonicalError, TypeError, ValueError) as error:
        return False, f"{key} cannot be reconstructed: {error}"
    return stated == actual, f"stated {stated}; reconstructed {actual}"


def _forbidden_paths(value: Any, path: str) -> list[str]:
    failures: list[str] = []
    if isinstance(value, dict):
        for key, item in value.items():
            normalized = str(key).strip().lower().replace("-", "_")
            if normalized in _FORBIDDEN_KEYS:
                failures.append(f"{path}.{key}")
            failures.extend(_forbidden_paths(item, f"{path}.{key}"))
    elif isinstance(value, list):
        for index, item in enumerate(value):
            failures.extend(_forbidden_paths(item, f"{path}[{index}]"))
    return failures


def _privacy_failures(value: Any, artifact_id: str) -> list[str]:
    failures: list[str] = []
    try:
        item = _object(value, f"{artifact_id}.privacy")
        if set(item) != _PRIVACY_FIELDS:
            raise ValueError("privacy has a missing or unsupported field set")
        classification = _identity(item.get("classification"), "privacy classification")
        if classification not in _PRIVACY_CLASSIFICATIONS:
            raise ValueError(f"unsupported privacy classification {classification!r}")
        for field in ("classification_basis", "input_class", "evidence_class"):
            _identity(item.get(field), f"privacy.{field}")
        for field in ("export_permitted", "redaction_applied", "field_observation"):
            if not isinstance(item.get(field), bool):
                raise ValueError(f"privacy.{field} must be boolean")
        if classification == "PUBLIC_REFERENCE" and not (
            item["export_permitted"] is True
            and item["redaction_applied"] is False
            and item["field_observation"] is False
            and item["input_class"] in {"REFERENCE", "SYNTHETIC_REFERENCE"}
        ):
            raise ValueError("PUBLIC_REFERENCE controls are inconsistent")
        if classification == "LOCAL_PRIVATE" and item["export_permitted"] is not False:
            raise ValueError("LOCAL_PRIVATE cannot be export-permitted")
        if classification == "REDACTED_PORTABLE" and not (
            item["export_permitted"] is True and item["redaction_applied"] is True
        ):
            raise ValueError("REDACTED_PORTABLE requires applied redaction and export permission")
    except (TypeError, ValueError) as error:
        failures.append(str(error))
    return failures


def _field_observation_paths(value: Any, path: str) -> list[str]:
    paths: list[str] = []
    if isinstance(value, dict):
        for key, item in value.items():
            child = f"{path}.{key}"
            if str(key).strip().lower().replace("-", "_") == "field_observation":
                if item is True:
                    paths.append(child)
            paths.extend(_field_observation_paths(item, child))
    elif isinstance(value, list):
        for index, item in enumerate(value):
            paths.extend(_field_observation_paths(item, f"{path}[{index}]"))
    return paths


def _nonreference_input_paths(value: Any, path: str) -> list[str]:
    paths: list[str] = []
    if isinstance(value, dict):
        for key, item in value.items():
            child = f"{path}.{key}"
            if str(key).strip().lower().replace("-", "_") == "input_class":
                source_column_mapping = (
                    path.endswith(".field_mapping") and isinstance(item, str)
                )
                if (
                    not source_column_mapping
                    and item not in {"REFERENCE", "SYNTHETIC_REFERENCE"}
                ):
                    paths.append(child)
            paths.extend(_nonreference_input_paths(item, child))
    elif isinstance(value, list):
        for index, item in enumerate(value):
            paths.extend(_nonreference_input_paths(item, f"{path}[{index}]"))
    return paths


def _record_of(entry: Mapping[str, Any]) -> Mapping[str, Any]:
    artifact = _object(entry.get("artifact"), f"{entry.get('artifact_id')}.artifact")
    if entry.get("portable_lifecycle_envelope"):
        return _object(artifact.get("record"), "portable lifecycle record")
    return artifact


def _read_entries(value: Any) -> tuple[list[dict], list[str], list[dict]]:
    entries: list[dict] = []
    failures: list[str] = []
    nested_results: list[dict] = []
    if not isinstance(value, list):
        return [], ["artifacts must be a list"], []
    if len(value) != len(ROLE_SPECS):
        failures.append(
            f"artifact denominator has {len(value)} entries; expected {len(ROLE_SPECS)}"
        )
    for index, spec in enumerate(ROLE_SPECS):
        if index >= len(value):
            break
        stage, role, record_type, envelope = spec
        try:
            item = _object(value[index], f"artifacts[{index}]")
            if set(item) != _ENTRY_FIELDS:
                raise ValueError("entry has a missing or unsupported field set")
            artifact_id = f"{stage}:{role}"
            if (
                item.get("artifact_id") != artifact_id
                or item.get("stage") != stage
                or item.get("role") != role
                or item.get("record_type") != record_type
                or item.get("portable_lifecycle_envelope") is not envelope
            ):
                raise ValueError("entry differs from the fixed release-and-role denominator")
            ok, detail = _sealed(item, "entry_hash")
            if not ok:
                failures.append(f"{artifact_id}: {detail}")
            artifact = _object(item.get("artifact"), f"{artifact_id}.artifact")
            actual_hash = content_hash(artifact)
            if item.get("artifact_hash") != actual_hash:
                failures.append(
                    f"{artifact_id}: artifact hash differs from reconstructed {actual_hash}"
                )
            if envelope:
                if set(artifact) != {"record", "verification_inputs"}:
                    raise ValueError("lifecycle artifact is not a closed portable envelope")
                record = _object(artifact.get("record"), f"{artifact_id}.record")
                verification_inputs = _object(
                    artifact.get("verification_inputs"),
                    f"{artifact_id}.verification_inputs",
                )
                if record.get("record_type") != record_type:
                    raise ValueError("lifecycle envelope has the wrong record type")
                nested = verify_lifecycle_replay_envelope(record, verification_inputs)
            else:
                if artifact.get("record_type") != record_type:
                    raise ValueError("direct artifact has the wrong record type")
                nested = (
                    verify_comparative_workflow_evaluation(artifact)
                    if stage == "v1.1"
                    else verify_comparative_change_evidence(artifact)
                )
            nested_results.append(
                {
                    "artifact_id": artifact_id,
                    "ok": nested.ok,
                    "status": nested.status,
                }
            )
            if not nested.ok:
                failures.append(
                    f"{artifact_id}: independent replay failed: {'; '.join(nested.violations)}"
                )
            failures.extend(
                f"{artifact_id}: {detail}"
                for detail in _privacy_failures(item.get("privacy"), artifact_id)
            )
            privacy = item.get("privacy")
            if (
                isinstance(privacy, Mapping)
                and privacy.get("classification") == "PUBLIC_REFERENCE"
            ):
                observed_paths = _field_observation_paths(artifact, artifact_id)
                if observed_paths:
                    failures.append(
                        f"{artifact_id}: PUBLIC_REFERENCE carries explicit field "
                        f"observation markers at {observed_paths}"
                    )
                nonreference_paths = _nonreference_input_paths(
                    artifact, artifact_id
                )
                if nonreference_paths:
                    failures.append(
                        f"{artifact_id}: PUBLIC_REFERENCE carries explicit "
                        f"non-reference input classes at {nonreference_paths}"
                    )
            entries.append(item)
        except (CanonicalError, KeyError, TypeError, ValueError) as error:
            failures.append(f"artifacts[{index}]: {error}")
    if len(value) > len(ROLE_SPECS):
        failures.append("artifacts contains roles outside the fixed denominator")
    return entries, failures, nested_results


def _denominator(entries: Sequence[Mapping[str, Any]]) -> dict:
    members = [
        {
            "artifact_id": item["artifact_id"],
            "stage": item["stage"],
            "role": item["role"],
            "artifact_hash": item["artifact_hash"],
        }
        for item in entries
    ]
    stages = []
    for stage in _STAGES:
        stage_members = [item["artifact_id"] for item in entries if item["stage"] == stage]
        stages.append(
            {"stage": stage, "members": stage_members, "count": _exact_count(len(stage_members))}
        )
    value = {
        "profile": "crg-cumulative-journey-denominator/fixed-roles@1",
        "members": members,
        "count": _exact_count(len(members)),
        "stage_denominators": stages,
        "complete": len(entries) == len(ROLE_SPECS),
    }
    value["denominator_hash"] = content_hash(value)
    return value


def _journey_facts(entries: Sequence[Mapping[str, Any]]) -> dict:
    by_role = {item["role"]: _record_of(item) for item in entries}
    required = {role for _stage, role, _type, _envelope in ROLE_SPECS}
    if set(by_role) != required:
        raise ValueError("journey facts require every fixed role exactly once")
    v11 = by_role["SCOPED_WORKFLOW_COMPARISON"]
    v12 = by_role["CERTIFIED_CHANGE_COMPARISON"]
    v12_facts = v12.get("system_derived_facts") or {}
    return {
        "facts_profile": "crg-cumulative-journey-direct-fields@1",
        "v1.1": {
            "evaluation_id": v11.get("evaluation_id"),
            "scope_hash": (v11.get("scope") or {}).get("scope_hash"),
            "comparison_status": (v11.get("comparability") or {}).get("status"),
            "method_count": _exact_count(len(v11.get("methods") or [])),
            "case_count": _exact_count(len(v11.get("workload") or [])),
        },
        "v1.2": {
            "comparison_id": v12.get("comparison_id"),
            "scope_hash": (v12.get("scope") or {}).get("scope_hash"),
            "minimum_action": v12_facts.get("minimum_action"),
            "preserved_count": (v12_facts.get("preserved_work") or {}).get("count"),
            "recomputed_count": (v12_facts.get("recomputed_work") or {}).get("count"),
        },
        "v1.3": {
            "result_ingestion_evidence_class": by_role["ETQ_RESULT_INGESTION"].get(
                "evidence_class"
            ),
            "qualification_state": by_role["QUALIFICATION_DISPOSITION"].get("state"),
            "qualification_stopping_condition": by_role[
                "QUALIFICATION_DISPOSITION"
            ].get("stopping_condition"),
            "selective_revalidation_state": by_role["SELECTIVE_REVALIDATION"].get(
                "state"
            ),
            "replacement_action": by_role["REPLACEMENT"].get("action_completed"),
        },
        "v1.4": {
            "continued_validity_status": by_role["CONTINUED_VALIDITY"].get("status"),
            "continued_validity_blocking_count": _exact_count(
                len(by_role["CONTINUED_VALIDITY"].get("blocking_dimensions") or [])
            ),
            "replay_complete": by_role["LIFECYCLE_REPLAY"].get("replay_complete"),
            "replay_entry_count": _exact_count(
                len(by_role["LIFECYCLE_REPLAY"].get("entries") or [])
            ),
            "recovery_integrity_status": by_role["BACKUP_RESTORE_RECOVERY"].get(
                "integrity_status"
            ),
            "migration_disposition": by_role["MIGRATION_REVERIFICATION"].get(
                "disposition"
            ),
        },
        "conclusion": "NO_AGGREGATE_SCORE_OR_AUTHORIZING_CONCLUSION",
    }


def _privacy_summary(entries: Sequence[Mapping[str, Any]]) -> dict:
    counts = {name: 0 for name in sorted(_PRIVACY_CLASSIFICATIONS)}
    fields = exports = 0
    for item in entries:
        privacy = item["privacy"]
        counts[privacy["classification"]] += 1
        fields += int(privacy["field_observation"])
        exports += int(privacy["export_permitted"])
    return {
        "classification_counts": [
            {"classification": name, "count": _exact_count(counts[name])}
            for name in sorted(counts)
        ],
        "field_observation_count": _exact_count(fields),
        "export_permitted_count": _exact_count(exports),
        "classification_is_declared_not_inferred": True,
        "record_declassifies_source_material": False,
        "external_transmission_required": False,
    }


def verify_cumulative_lifecycle_comparison(record: Any) -> VerificationResult:
    """Independently replay and reconstruct a complete v1.1-v1.4 comparison."""

    result = VerificationResult(
        ok=False,
        status=Status.FAILED,
        report={
            "record_type": "CumulativeLifecycleComparison",
            "level_attempted": "V3",
            "level_achieved": "NONE",
            "authority": AUTHORITY,
        },
    )
    if not isinstance(record, Mapping):
        result.record("cumulative_comparison_shape", False, "record must be an object")
        return result.finish()
    artifact = dict(record)
    profile_ok = (
        artifact.get("record_type") == "CumulativeLifecycleComparison"
        and artifact.get("schema_version") == SCHEMA_VERSION
        and artifact.get("profile") == PROFILE
        and artifact.get("first_release_attribution") == FIRST_RELEASE
    )
    result.record(
        "cumulative_comparison_profile",
        profile_ok,
        f"registered profile is CumulativeLifecycleComparison/{SCHEMA_VERSION}/{PROFILE}",
    )
    shape_ok = set(artifact) == _TOP_FIELDS
    if shape_ok:
        try:
            _identity(artifact.get("journey_id"), "journey_id")
        except ValueError:
            shape_ok = False
    result.record(
        "cumulative_comparison_record_shape",
        shape_ok,
        "the profile permits only its complete canonical field set",
    )
    ok, detail = _sealed(artifact, "record_hash")
    result.record("cumulative_comparison_integrity", ok, detail)
    boundary_ok = (
        artifact.get("authority") == AUTHORITY
        and artifact.get("authorizing") is False
        and artifact.get("semantic_effect") == "NONE"
        and artifact.get("evidence_class")
        == "NON_AUTHORIZING_CUMULATIVE_PRODUCT_EVIDENCE"
        and artifact.get("claim_boundary") == CLAIM_BOUNDARY
    )
    result.record(
        "cumulative_comparison_non_authorizing_boundary",
        boundary_ok,
        "authority, semantic effect, evidence class, and claim boundary are fixed",
    )

    scope_failures: list[str] = []
    try:
        scope = _object(artifact.get("scope"), "scope")
        if set(scope) != _SCOPE_FIELDS:
            raise ValueError("scope has a missing or unsupported field set")
        _identity(scope.get("case_id"), "scope.case_id")
        for field in (
            "technology_scope",
            "decision_scope",
            "evidence_scope",
            "change_scope",
            "journey_time_scope",
        ):
            _object(scope.get(field), f"scope.{field}")
        if scope.get("release_stages") != list(_STAGES):
            raise ValueError("scope does not cover the ordered v1.1-v1.4 release journey")
        ok, detail = _sealed(scope, "scope_hash")
        if not ok:
            raise ValueError(detail)
    except (TypeError, ValueError) as error:
        scope_failures.append(str(error))
    result.record(
        "cumulative_comparison_scope",
        not scope_failures,
        "; ".join(scope_failures) if scope_failures else
        "technology, decision, evidence, change, time, case, and release scope are bound",
    )

    entries, entry_failures, nested_results = _read_entries(artifact.get("artifacts"))
    result.record(
        "cumulative_comparison_nested_verification",
        not entry_failures,
        "; ".join(entry_failures) if entry_failures else
        "all ten fixed-role artifacts independently replay from embedded portable evidence",
    )

    reconstruction_failures: list[str] = []
    if len(entries) == len(ROLE_SPECS):
        try:
            expected_denominator = _denominator(entries)
            if artifact.get("denominator") != expected_denominator:
                reconstruction_failures.append(
                    "denominator is not the complete fixed release-and-role artifact set"
                )
            expected_facts = _journey_facts(entries)
            if artifact.get("journey_facts") != expected_facts:
                reconstruction_failures.append(
                    "journey facts differ from direct fields in the verified artifacts"
                )
            expected_privacy = _privacy_summary(entries)
            if artifact.get("privacy_summary") != expected_privacy:
                reconstruction_failures.append(
                    "privacy summary differs from the per-artifact classifications"
                )
        except (CanonicalError, KeyError, TypeError, ValueError) as error:
            reconstruction_failures.append(str(error))
    else:
        reconstruction_failures.append("all ten denominator members are required")
    result.record(
        "cumulative_comparison_denominator_and_facts",
        not reconstruction_failures,
        "; ".join(reconstruction_failures) if reconstruction_failures else
        "denominator, stage facts, and privacy counts were independently reconstructed",
    )

    limitations = artifact.get("limitations")
    limitations_ok = (
        isinstance(limitations, list)
        and bool(limitations)
        and all(
            isinstance(item, str) and item and item == item.strip()
            for item in limitations
        )
        and limitations == sorted(limitations)
        and len(limitations) == len(set(limitations))
    )
    result.record(
        "cumulative_comparison_limitations",
        limitations_ok,
        "at least one unique canonically ordered limitation is required",
    )
    forbidden = _forbidden_paths(artifact.get("journey_facts"), "journey_facts")
    result.record(
        "cumulative_comparison_no_strengthened_claim",
        not forbidden,
        f"prohibited conclusion fields: {forbidden}" if forbidden else
        "no aggregate score, ranking, superiority, ROI, savings, or generalization field is present",
    )
    try:
        artifact_root = content_hash(artifact)
    except (CanonicalError, TypeError, ValueError):
        artifact_root = None
    result.report.update(
        {
            "artifact_root": artifact_root,
            "journey_id": artifact.get("journey_id"),
            "artifact_count": len(entries),
            "stage_counts": {
                stage: sum(1 for item in entries if item.get("stage") == stage)
                for stage in _STAGES
            },
            "nested_results": nested_results,
            "claim_boundary": CLAIM_BOUNDARY,
        }
    )
    result.finish()
    if not profile_ok:
        result.status = Status.UNSUPPORTED_PROFILE
    elif result.ok:
        result.status = Status.VERIFIED_RELATIVE
        result.report["level_achieved"] = "V3"
    else:
        result.status = Status.FAILED
    return result
