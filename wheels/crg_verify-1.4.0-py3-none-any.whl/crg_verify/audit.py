"""Independent verifier for bounded CRG security-audit exports.

This module imports only the verifier's own canonicalizer and the standard
library.  In particular it does not import ``crg_security.audit``: an audit
producer cannot be the only implementation deciding whether its own hashes
and cursor metadata are valid (9.3, 44.7, 48.3).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Mapping, Optional, Tuple

from .canonical import content_hash

AUDIT_EXPORT_FORMAT_VERSION = "1.0.0"
GENESIS_HASH = "sha256:" + "0" * 64

__all__ = [
    "AUDIT_EXPORT_FORMAT_VERSION",
    "GENESIS_HASH",
    "AuditExportResult",
    "audit_export_hash",
    "verify_audit_export",
]


@dataclass(frozen=True)
class AuditExportResult:
    ok: bool
    entries_checked: int
    artifact_hash: str
    page_head_hash: str
    checkpoint_signature_status: str
    trust_established: bool
    violations: Tuple[str, ...]

    def __bool__(self) -> bool:
        return self.ok

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "ok": self.ok,
            "entries_checked": self.entries_checked,
            "artifact_hash": self.artifact_hash,
            "page_head_hash": self.page_head_hash,
            "checkpoint_signature_status": self.checkpoint_signature_status,
            "trust_established": self.trust_established,
            "violations": list(self.violations),
        }


def audit_export_hash(record: Mapping[str, Any]) -> str:
    """Canonical artifact hash, excluding the self-referential field."""
    return content_hash({str(key): value for key, value in record.items()
                         if str(key) != "artifact_hash"})


def _entry_body(entry: Mapping[str, Any]) -> Dict[str, Any]:
    return {
        "sequence": entry.get("sequence"),
        "timestamp": entry.get("timestamp"),
        "tenant_id": entry.get("tenant_id"),
        "actor": entry.get("actor"),
        "action": entry.get("action"),
        "resource": entry.get("resource"),
        "decision": entry.get("decision"),
        "outcome": entry.get("outcome"),
        "correlation_id": entry.get("correlation_id"),
        "rule_id": entry.get("rule_id"),
        "detail": entry.get("detail"),
        "previous_hash": entry.get("previous_hash"),
    }


def verify_audit_export(
    record: Mapping[str, Any], *,
    expected_tenant_id: Optional[str] = None,
    trusted_checkpoint: Optional[Mapping[str, Any]] = None,
    signature_verifier: Optional[
        Callable[[Mapping[str, Any], Mapping[str, Any]], Any]
    ] = None,
) -> AuditExportResult:
    """Recompute an export page, its cursor, and its checkpoint binding.

    ``signature_verifier`` is an explicit trust-provider seam. It receives the
    checkpoint without ``signature`` and the signature document, and returns a
    boolean or ``(boolean, reason)``. The audit document can never name or load
    code, keys, or a provider by itself.
    """
    violations: List[str] = []
    checked = 0
    tenant = str(record.get("tenant_id") or "")
    page_head = str(record.get("page_head_hash") or "")
    recomputed_artifact = audit_export_hash(record)
    if record.get("record_type") != "AuditExportRecord":
        violations.append("record_type is not AuditExportRecord")
    if record.get("format_version") != AUDIT_EXPORT_FORMAT_VERSION:
        violations.append("unsupported audit export format_version")
    if not tenant:
        violations.append("tenant_id is empty")
    if expected_tenant_id is not None and tenant != str(expected_tenant_id):
        violations.append("tenant_id does not match the verifier's expected tenant")
    if str(record.get("artifact_hash") or "") != recomputed_artifact:
        violations.append("artifact_hash does not match canonical export content")

    try:
        cursor = record.get("range")
        if not isinstance(cursor, Mapping):
            raise TypeError("range is not an object")
        after = cursor.get("after_sequence")
        count = cursor.get("entry_count")
        next_after = cursor.get("next_after_sequence")
        has_more = cursor.get("has_more")
        if isinstance(after, bool) or not isinstance(after, int) or after < -1:
            raise TypeError("range.after_sequence is not an integer >= -1")
        if isinstance(count, bool) or not isinstance(count, int) or count < 0:
            raise TypeError("range.entry_count is not a non-negative integer")
        if isinstance(next_after, bool) or not isinstance(next_after, int):
            raise TypeError("range.next_after_sequence is not an integer")
        if not isinstance(has_more, bool):
            raise TypeError("range.has_more is not a boolean")
        entries = record.get("entries")
        if not isinstance(entries, list):
            raise TypeError("entries is not an array")
        if count != len(entries):
            violations.append("range.entry_count does not equal entries length")
        previous = str(record.get("predecessor_hash") or "")
        if after == -1 and previous != GENESIS_HASH:
            violations.append("first page is not anchored to the fixed genesis hash")
        expected_sequence = after + 1
        parsed: List[Mapping[str, Any]] = []
        required = {
            "sequence", "timestamp", "tenant_id", "actor", "action", "resource",
            "decision", "outcome", "correlation_id", "rule_id", "detail",
            "previous_hash", "entry_hash",
        }
        for raw in entries:
            if not isinstance(raw, Mapping):
                raise TypeError("an entry is not an object")
            if set(raw) != required:
                violations.append("an entry has missing or undeclared fields")
                break
            parsed.append(raw)
            if raw.get("sequence") != expected_sequence:
                violations.append("entry sequence is not contiguous from the cursor")
                break
            if raw.get("tenant_id") != tenant:
                violations.append("an entry belongs to another tenant")
                break
            if raw.get("previous_hash") != previous:
                violations.append("an entry has a broken predecessor link")
                break
            if content_hash(_entry_body(raw)) != raw.get("entry_hash"):
                violations.append("an entry's content does not match entry_hash")
                break
            checked += 1
            expected_sequence += 1
            previous = str(raw.get("entry_hash"))
        if previous != page_head:
            violations.append("page_head_hash does not match the exported page")
        expected_start = parsed[0].get("sequence") if parsed else None
        expected_end = parsed[-1].get("sequence") if parsed else None
        if cursor.get("start_sequence") != expected_start:
            violations.append("range.start_sequence does not match entries")
        if cursor.get("end_sequence") != expected_end:
            violations.append("range.end_sequence does not match entries")
        if next_after != (expected_end if parsed else after):
            violations.append("range.next_after_sequence does not match page tail")
    except (TypeError, ValueError, KeyError) as error:
        violations.append(f"malformed range or entry: {error}")
        has_more = True

    checkpoint = record.get("checkpoint")
    signature_status = "NOT_PRESENT"
    trust_established = False
    if not isinstance(checkpoint, Mapping):
        violations.append("checkpoint is missing or not an object")
        checkpoint = {}
    else:
        expected_checkpoint = {
            "checkpoint_type": "audit-chain-head",
            "tenant_id": tenant,
            "entry_count": record.get("total_entry_count"),
            "head_hash": record.get("chain_head_hash"),
            "genesis_hash": GENESIS_HASH,
        }
        for key, expected in expected_checkpoint.items():
            if checkpoint.get(key) != expected:
                violations.append(f"checkpoint.{key} does not match the export")
        claimed = record.get("chain_verification")
        if not isinstance(claimed, Mapping) or claimed.get("chain_intact") is not True:
            violations.append("full-chain verification was not successful")
        elif (claimed.get("entries_checked") != record.get("total_entry_count")
              or claimed.get("head_hash") != record.get("chain_head_hash")):
            violations.append("full-chain verification disagrees with the checkpoint")
        if not has_more and page_head != str(record.get("chain_head_hash") or ""):
            violations.append("final page does not end at chain_head_hash")

        signature = checkpoint.get("signature")
        if signature is not None:
            signature_status = "UNVERIFIED"
            if signature_verifier is not None:
                payload = {key: value for key, value in checkpoint.items()
                           if key != "signature"}
                try:
                    answer = signature_verifier(payload, signature)
                    ok, reason = (
                        (bool(answer[0]), str(answer[1]))
                        if isinstance(answer, tuple) else (bool(answer), "")
                    )
                except Exception as error:  # external trust provider fails closed
                    ok, reason = False, f"provider raised {type(error).__name__}: {error}"
                signature_status = "VERIFIED" if ok else "FAILED"
                if ok:
                    trust_established = True
                else:
                    violations.append(f"checkpoint signature failed: {reason}")

    if trusted_checkpoint is not None:
        fields = ("checkpoint_type", "tenant_id", "entry_count", "head_hash", "genesis_hash")
        if all(trusted_checkpoint.get(key) == checkpoint.get(key) for key in fields):
            trust_established = True
            if signature_status in {"NOT_PRESENT", "UNVERIFIED"}:
                signature_status = "TRUSTED_CHECKPOINT_MATCH"
        else:
            violations.append("trusted checkpoint does not match the export")

    return AuditExportResult(
        ok=not violations,
        entries_checked=checked,
        artifact_hash=recomputed_artifact,
        page_head_hash=page_head,
        checkpoint_signature_status=signature_status,
        trust_established=trust_established,
        violations=tuple(violations),
    )
