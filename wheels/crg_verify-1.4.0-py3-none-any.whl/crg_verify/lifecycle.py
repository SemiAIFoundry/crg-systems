"""Independent verification for the CRG v1.3/v1.4 lifecycle records.

The producer packages deliberately do not appear in this module.  Every
checker consumes decoded, portable JSON and rebuilds the relevant ordering,
hash bindings, dependency closure, conversion invariants, authorization
decision, or continued-validity classification with the Python standard
library plus the independent :mod:`crg_verify` primitives.

Legacy record profiles describe evidence *about* signatures and remain
integrity-only.  The additive authority path instead consumes a closed,
versioned authority snapshot and signature bytes, performs Ed25519 itself,
and binds each signer to the authenticated principal snapshot that produced
the approval.  The deployment server separately pins the accepted trust root;
portable replay reports snapshot-relative cryptographic integrity without
pretending that carried bytes can prove their own deployment ownership.
"""
from __future__ import annotations

import datetime as _dt
from fractions import Fraction
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Set, Tuple

from .arith import ArithError, rational
from .canonical import CanonicalError, canonical_bytes, content_hash, is_hash
from .certificate import Status, VerificationResult

__all__ = [
    "verify_etq_decision_loop",
    "verify_result_ingestion_record",
    "verify_selective_revalidation_record",
    "verify_replacement_record",
    "verify_qualification_disposition",
    "verify_decision_scoped_conversion",
    "verify_conversion_binding_impact",
    "verify_signature_verification_record",
    "verify_approval_record",
    "verify_approval_withdrawal",
    "verify_lifecycle_authorization",
    "derive_continued_validity_dimensions",
    "verify_continued_validity_view",
]

SCHEMA_VERSION = "1.0.0"
ETQ_PROFILE = "crg.etq-decision-loop"
CONVERSION_PROFILE = "crg.decision-scoped-conversion"
VALIDITY_PROFILE = "crg.continued-validity"

_EVIDENCE_CLASSES = frozenset(
    {"EXACT", "CONSTRUCTIVE", "BOUNDED", "MEASURED", "MODELED", "IMPORTED", "DECLARED", "HEURISTIC"}
)
_AUTHORIZING_EVIDENCE = _EVIDENCE_CLASSES - {"HEURISTIC"}
_EVIDENCE_STATUS = {"DRAFT": 0, "PROVISIONAL": 1, "QUALIFIED": 2, "CERTIFIED": 3}
_STOPPING = frozenset(
    {
        "UNIQUE_GUARANTEED_WINNER", "CAPABILITY_ESTABLISHED", "CAPABILITY_RULED_OUT",
        "REGRET_BELOW_THRESHOLD", "UNCERTAINTY_BELOW_THRESHOLD", "BURDEN_LIMIT_REACHED",
        "NO_INFORMATIVE_EXPERIMENT_REMAINS", "MANUAL_ADJUDICATION_REQUIRED",
    }
)
_RESOLVING_STOPS = frozenset(
    {
        "UNIQUE_GUARANTEED_WINNER", "CAPABILITY_ESTABLISHED", "CAPABILITY_RULED_OUT",
        "REGRET_BELOW_THRESHOLD", "UNCERTAINTY_BELOW_THRESHOLD",
    }
)

_LOOP_STEPS = (
    "EVIDENCE_AUTHORED",
    "APPLICABILITY_EVALUATED",
    "UNCERTAINTY_PRESERVED",
    "CONFLICT_AND_VALIDITY_PRESERVED",
    "TECHNOLOGY_CONTRACT_ASSEMBLED",
    "DECISION_CONSEQUENCES_PROPAGATED",
    "DECISION_CHANGING_UNKNOWN_IDENTIFIED",
    "QUALIFICATION_TARGET_INVERTED",
    "EXPERIMENTS_RANKED",
    "REQUEST_AND_STOPPING_RULE_ISSUED",
    "RESULT_INGESTED_AS_EVIDENCE",
    "SELECTIVE_REVALIDATION_AND_REPLACEMENT",
)
_LOOP_OUTPUTS = {
    _LOOP_STEPS[0]: frozenset({"EvidenceRecord"}),
    _LOOP_STEPS[1]: frozenset({"ApplicabilityAssessment"}),
    _LOOP_STEPS[2]: frozenset({"UncertaintyComponentRecord"}),
    _LOOP_STEPS[3]: frozenset({"EvidenceDisposition"}),
    _LOOP_STEPS[4]: frozenset({"TechnologyContract"}),
    _LOOP_STEPS[5]: frozenset({"DecisionConsequence"}),
    _LOOP_STEPS[6]: frozenset({"DecisionChangingUnknown"}),
    _LOOP_STEPS[7]: frozenset({"QualificationTarget"}),
    _LOOP_STEPS[8]: frozenset({"ExperimentRanking"}),
    _LOOP_STEPS[9]: frozenset({"EvaluatorRequest", "ExperimentRequest"}),
    _LOOP_STEPS[10]: frozenset({"EvidenceRecord"}),
    _LOOP_STEPS[11]: frozenset({"SelectiveRevalidationRecord", "ReplacementRecord"}),
}

_ACTION_SEVERITY = {
    "NO_OPERATION": 0,
    "REVALIDATE_ONLY": 1,
    "RECOMPUTE_VALUE": 2,
    "REPRICE": 3,
    "RE_EMBED": 4,
    "RE_EVALUATE": 5,
    "REOPEN": 6,
    "BLOCK": 7,
}
_EDGE = {
    "DERIVES_VALUE_FROM": ("RECOMPUTE_VALUE", True),
    "DEPENDS_ON_VALIDITY_OF": ("REVALIDATE_ONLY", True),
    "DEPENDS_ON_MEMBERSHIP_OF": ("REOPEN", True),
    "DEPENDS_ON_SCOPE_OF": ("REOPEN", True),
    "DEPENDS_ON_PRICE_OF": ("REPRICE", True),
    "DEPENDS_ON_EMBEDDING_OF": ("RE_EMBED", True),
    "DEPENDS_ON_CAPABILITY_OF": ("REOPEN", True),
    "DEPENDS_ON_RULE_VERSION": ("REVALIDATE_ONLY", True),
    "DEPENDS_ON_GENERATOR_VERSION": ("REOPEN", True),
    "DEPENDS_ON_TOOL_IDENTITY": ("RE_EVALUATE", True),
    "DEPENDS_ON_SIGNATURE": ("BLOCK", True),
    "DEPENDS_ON_CONTEXT_FINGERPRINT": ("REVALIDATE_ONLY", True),
    "DEPENDS_ON_CLOCK": ("BLOCK", True),
    "DEPENDS_ON_ACCESS": ("BLOCK", True),
    "DERIVED_FROM_VERSION": ("NO_OPERATION", False),
    "PROVES": ("BLOCK", True),
    "WITNESSES": ("RECOMPUTE_VALUE", True),
}
_VALIDITY_RULE = {
    "NO_OPERATION": "PRESERVE_TARGET",
    "REVALIDATE_ONLY": "REVALIDATE_TARGET",
    "BLOCK": "BLOCK_TARGET",
}

_CONVERSION_PROGRAM = (
    "IDENTITY_LAYOUT_MOVES_ZERO",
    "TARGET_COVERAGE_COMPLETE",
    "SOURCE_MASS_CONSERVED",
    "NO_UNDECLARED_DUPLICATION",
    "ASSIGNMENT_IS_ONE_TO_ONE",
    "RETAINED_PLUS_MOVED_EQUALS_TOTAL",
    "RETENTION_MATCHES_ASSIGNMENT_WITNESS",
    "SECONDARY_PRESERVES_PRIMARY_OPTIMUM",
    "ARITHMETIC_IS_EXACT_RATIONAL",
)

_DIMENSIONS = (
    "EVIDENCE_VALIDITY", "VERIFIER_TIME", "DEPENDENCY_STATUS", "CHANGE_EVENTS",
    "REVOCATION", "REDACTION", "MIGRATION", "BRANCH_STATE", "SUPERSESSION", "APPROVALS",
)
_DIMENSION_STATES = {
    "EVIDENCE_VALIDITY": frozenset({"CURRENT", "EXPIRED", "REVOKED", "REDACTED", "UNAVAILABLE", "INDETERMINATE"}),
    "VERIFIER_TIME": frozenset({"CURRENT", "EXPIRED", "STALE", "NOT_YET_VALID", "TIME_INDETERMINATE", "CLOCK_POLICY_VIOLATION"}),
    "DEPENDENCY_STATUS": frozenset({"CURRENT", "REVALIDATION_REQUIRED", "STALE", "BLOCKED", "INDETERMINATE"}),
    "CHANGE_EVENTS": frozenset({"NONE", "REPRICE_REQUIRED", "RE_EMBED_REQUIRED", "REOPEN_REQUIRED", "REVALIDATION_REQUIRED", "BLOCKED"}),
    "REVOCATION": frozenset({"NOT_REVOKED", "REVOKED", "UNKNOWN"}),
    "REDACTION": frozenset({"AVAILABLE", "REDACTED", "UNVERIFIABLE_REDACTED", "UNKNOWN"}),
    "MIGRATION": frozenset({"ORIGINAL", "SEMANTICALLY_EQUIVALENT_VERIFIED", "REVALIDATION_REQUIRED", "REOPEN_REQUIRED", "LOSSY", "UNVERIFIED"}),
    "BRANCH_STATE": frozenset({"LINEAR_CURRENT", "BRANCHED_CURRENT", "PARENT_HISTORICAL", "MERGE_RECONCILIATION_REQUIRED", "MERGED_REVALIDATION_REQUIRED", "UNKNOWN"}),
    "SUPERSESSION": frozenset({"CURRENT", "SUPERSEDED", "UNKNOWN"}),
    "APPROVALS": frozenset({"CURRENT", "MISSING", "WITHDRAWN", "SIGNATURE_UNVERIFIED", "SEPARATION_OF_DUTIES_FAILED", "EXPIRED", "INDETERMINATE"}),
}
_CURRENT_STATES = {
    "EVIDENCE_VALIDITY": frozenset({"CURRENT"}),
    "VERIFIER_TIME": frozenset({"CURRENT"}),
    "DEPENDENCY_STATUS": frozenset({"CURRENT"}),
    "CHANGE_EVENTS": frozenset({"NONE"}),
    "REVOCATION": frozenset({"NOT_REVOKED"}),
    "REDACTION": frozenset({"AVAILABLE"}),
    "MIGRATION": frozenset({"ORIGINAL", "SEMANTICALLY_EQUIVALENT_VERIFIED"}),
    "BRANCH_STATE": frozenset({"LINEAR_CURRENT", "BRANCHED_CURRENT"}),
    "SUPERSESSION": frozenset({"CURRENT"}),
    "APPROVALS": frozenset({"CURRENT"}),
}
_INDETERMINATE_STATES = frozenset({"INDETERMINATE", "TIME_INDETERMINATE", "UNKNOWN", "UNVERIFIED"})
_REOPEN_STATES = frozenset(
    {"REVALIDATION_REQUIRED", "STALE", "REPRICE_REQUIRED", "RE_EMBED_REQUIRED", "REOPEN_REQUIRED",
     "PARENT_HISTORICAL", "MERGE_RECONCILIATION_REQUIRED", "MERGED_REVALIDATION_REQUIRED", "SUPERSEDED"}
)

_TRUST_PROFILE = "crg.lifecycle-trust-context"
_AUTHORITY_PROFILE = "crg.lifecycle-authority-snapshot"
_TRUST_SCHEMA_VERSION = "1.0.0"
_CLOCK_TRUST = {
    "NONE_SUPPLIED": 0,
    "LOCAL_DECLARED": 1,
    "SYNCHRONIZED": 2,
    "ATTESTED": 3,
}
_AUTHORITY_OPERATION_ROLES = {
    "RECORD_SIGNATURE_VERIFICATION": frozenset(
        {"Decision Approver", "Certificate Signer"}
    ),
    "ISSUE_APPROVAL": frozenset({"Decision Approver"}),
    "ISSUE_APPROVAL_WITHDRAWAL": frozenset({"Decision Approver"}),
    "EVALUATE_LIFECYCLE_AUTHORIZATION": frozenset({"Decision Approver"}),
    "BUILD_CONTINUED_VALIDITY": frozenset({"Decision Approver"}),
}


class _DecodeError(ValueError):
    pass


class _UnsupportedProfileError(_DecodeError):
    pass


def _object(value: Any, where: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise _DecodeError(f"{where} must be an object")
    return value


def _array(value: Any, where: str) -> Sequence[Any]:
    if not isinstance(value, (list, tuple)):
        raise _DecodeError(f"{where} must be an array")
    return value


def _string(value: Any, where: str, *, empty: bool = False) -> str:
    if not isinstance(value, str) or (not empty and not value):
        raise _DecodeError(f"{where} must be a {'string' if empty else 'non-empty string'}")
    return value


def _boolean(value: Any, where: str) -> bool:
    if not isinstance(value, bool):
        raise _DecodeError(f"{where} must be a boolean")
    return value


def _integer(value: Any, where: str, *, minimum: Optional[int] = None) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise _DecodeError(f"{where} must be an integer")
    if minimum is not None and value < minimum:
        raise _DecodeError(f"{where} must be at least {minimum}")
    return value


def _keys(value: Mapping[str, Any], required: Iterable[str], optional: Iterable[str], where: str) -> None:
    required_set, allowed = set(required), set(required) | set(optional)
    missing, unknown = required_set - set(value), set(value) - allowed
    if missing:
        raise _DecodeError(f"{where} is missing fields {sorted(missing)}")
    if unknown:
        raise _DecodeError(f"{where} has unsupported fields {sorted(unknown)}")


def _hash(value: Any, where: str) -> str:
    if not is_hash(value):
        raise _DecodeError(f"{where} must be an algorithm-tagged SHA-256 hash")
    return value


def _strings(value: Any, where: str, *, sorted_unique: bool = False, nonempty: bool = False) -> Tuple[str, ...]:
    result = tuple(_string(item, f"{where}[]") for item in _array(value, where))
    if nonempty and not result:
        raise _DecodeError(f"{where} must not be empty")
    if len(set(result)) != len(result):
        raise _DecodeError(f"{where} contains duplicates")
    if sorted_unique and result != tuple(sorted(result)):
        raise _DecodeError(f"{where} is not canonically sorted")
    return result


def _hashes(value: Any, where: str, *, sorted_unique: bool = False) -> Tuple[str, ...]:
    result = tuple(_hash(item, f"{where}[]") for item in _array(value, where))
    if len(set(result)) != len(result):
        raise _DecodeError(f"{where} contains duplicate hashes")
    if sorted_unique and result != tuple(sorted(result)):
        raise _DecodeError(f"{where} is not canonically sorted")
    return result


def _preflight(value: Any, where: str) -> str:
    try:
        return content_hash(value)
    except (CanonicalError, TypeError, ValueError) as error:
        raise _DecodeError(f"{where} is not canonically hashable: {error}") from error


def _authority_snapshot(value: Any) -> Mapping[str, Any]:
    """Independently validate a deployment-owned lifecycle authority snapshot."""

    snapshot = _object(value, "lifecycle authority snapshot")
    _keys(
        snapshot,
        (
            "profile", "schema_version", "trust_context", "trust_context_root",
            "policy_roots", "clock", "clock_root", "principal",
            "principal_binding_root",
        ),
        (),
        "lifecycle authority snapshot",
    )
    if snapshot.get("profile") != _AUTHORITY_PROFILE:
        raise _UnsupportedProfileError(
            f"unsupported lifecycle authority profile {snapshot.get('profile')!r}"
        )
    if snapshot.get("schema_version") != _TRUST_SCHEMA_VERSION:
        raise _UnsupportedProfileError(
            f"unsupported lifecycle authority schema {snapshot.get('schema_version')!r}"
        )
    context = _object(snapshot.get("trust_context"), "lifecycle trust context")
    _keys(
        context,
        (
            "profile", "schema_version", "context_id", "context_version",
            "organization", "trusted_keys", "subjects", "policies", "clock_policy",
        ),
        (),
        "lifecycle trust context",
    )
    if context.get("profile") != _TRUST_PROFILE:
        raise _UnsupportedProfileError(
            f"unsupported lifecycle trust profile {context.get('profile')!r}"
        )
    if context.get("schema_version") != _TRUST_SCHEMA_VERSION:
        raise _UnsupportedProfileError(
            f"unsupported lifecycle trust schema {context.get('schema_version')!r}"
        )
    for field in ("context_id", "context_version", "organization"):
        _string(context.get(field), f"lifecycle trust context.{field}")
    context_root = _preflight(context, "lifecycle trust context")
    if snapshot.get("trust_context_root") != context_root:
        raise _DecodeError("lifecycle trust-context root does not match its canonical bytes")

    keys = _object(context.get("trusted_keys"), "lifecycle trusted keys")
    subjects = _object(context.get("subjects"), "lifecycle subjects")
    if not keys or not subjects:
        raise _DecodeError("lifecycle authority requires keys and registered subjects")
    for key_id, raw in keys.items():
        _string(key_id, "lifecycle key id")
        key = _object(raw, f"lifecycle key {key_id!r}")
        _keys(
            key,
            ("profile", "algorithm", "public_key", "subject_id", "organization", "revoked"),
            (),
            f"lifecycle key {key_id!r}",
        )
        if key.get("profile") != "Ed25519" or key.get("algorithm") != "ed25519":
            raise _UnsupportedProfileError(
                f"lifecycle key {key_id!r} is not production Ed25519"
            )
        public = _string(key.get("public_key"), f"lifecycle key {key_id!r} public_key")
        try:
            public_bytes = bytes.fromhex(public)
        except ValueError as error:
            raise _DecodeError(f"lifecycle key {key_id!r} is not hexadecimal") from error
        if len(public_bytes) != 32:
            raise _DecodeError(f"lifecycle key {key_id!r} is not a 32-byte Ed25519 key")
        _string(key.get("subject_id"), f"lifecycle key {key_id!r} subject")
        if key.get("organization") != context.get("organization"):
            raise _DecodeError(f"lifecycle key {key_id!r} organization is outside the context")
        _boolean(key.get("revoked"), f"lifecycle key {key_id!r} revoked")
        if key.get("subject_id") not in subjects:
            raise _DecodeError(f"lifecycle key {key_id!r} names an unregistered subject")
    for subject_id, raw in subjects.items():
        _string(subject_id, "lifecycle subject id")
        subject = _object(raw, f"lifecycle subject {subject_id!r}")
        _keys(subject, ("organization", "approval_roles", "key_ids"), (), f"lifecycle subject {subject_id!r}")
        if subject.get("organization") != context.get("organization"):
            raise _DecodeError(f"lifecycle subject {subject_id!r} organization is outside the context")
        roles = _strings(subject.get("approval_roles"), f"lifecycle subject {subject_id!r} roles", sorted_unique=True, nonempty=True)
        del roles
        key_ids = _strings(subject.get("key_ids"), f"lifecycle subject {subject_id!r} keys", sorted_unique=True, nonempty=True)
        for key_id in key_ids:
            key = keys.get(key_id)
            if not isinstance(key, Mapping) or key.get("subject_id") != subject_id:
                raise _DecodeError(f"lifecycle subject {subject_id!r} has an invalid key binding")
    for key_id, key in keys.items():
        subject = subjects.get(key.get("subject_id"))
        if not isinstance(subject, Mapping) or key_id not in set(subject.get("key_ids") or ()):
            raise _DecodeError(
                f"lifecycle key {key_id!r} is not declared by its registered subject"
            )

    policies = _object(context.get("policies"), "lifecycle policies")
    policy_roots = _object(snapshot.get("policy_roots"), "lifecycle policy roots")
    expected_policy_roots: Dict[str, str] = {}
    action_owners: Set[str] = set()
    for policy_id, raw in policies.items():
        policy = _object(raw, f"lifecycle policy {policy_id!r}")
        _keys(
            policy,
            ("policy_id", "required_roles", "incompatible_role_pairs", "distinct_subjects_for_required_roles", "authority", "actions"),
            (),
            f"lifecycle policy {policy_id!r}",
        )
        if policy.get("policy_id") != policy_id:
            raise _DecodeError(f"lifecycle policy {policy_id!r} identity mismatch")
        required_roles = _strings(
            policy.get("required_roles"),
            f"lifecycle policy {policy_id!r} roles",
            sorted_unique=True,
            nonempty=True,
        )
        known_roles = {
            role
            for subject in subjects.values()
            for role in subject.get("approval_roles", ())
        }
        if set(required_roles) - known_roles:
            raise _DecodeError(
                f"lifecycle policy {policy_id!r} requires an unregistered approval role"
            )
        pairs = []
        for index, raw_pair in enumerate(
            _array(
                policy.get("incompatible_role_pairs"),
                f"lifecycle policy {policy_id!r} incompatible role pairs",
            )
        ):
            pair = _array(
                raw_pair,
                f"lifecycle policy {policy_id!r} incompatible_role_pairs[{index}]",
            )
            if len(pair) != 2:
                raise _DecodeError("a lifecycle incompatible-role pair must contain two roles")
            normalized = tuple(
                sorted(
                    (
                        _string(pair[0], "lifecycle incompatible role"),
                        _string(pair[1], "lifecycle incompatible role"),
                    )
                )
            )
            if normalized[0] == normalized[1] or list(normalized) != list(pair):
                raise _DecodeError(
                    "lifecycle incompatible-role pairs must be distinct and canonically sorted"
                )
            if set(normalized) - known_roles:
                raise _DecodeError(
                    f"lifecycle policy {policy_id!r} has an unregistered incompatible role"
                )
            pairs.append(normalized)
        if pairs != sorted(set(pairs)):
            raise _DecodeError(
                f"lifecycle policy {policy_id!r} incompatible-role pairs repeat or are unsorted"
            )
        actions = _strings(policy.get("actions"), f"lifecycle policy {policy_id!r} actions", sorted_unique=True, nonempty=True)
        if action_owners.intersection(actions):
            raise _DecodeError("a lifecycle action is assigned to multiple policies")
        action_owners.update(actions)
        _boolean(policy.get("distinct_subjects_for_required_roles"), "policy distinct subjects")
        _string(policy.get("authority"), "policy authority")
        expected_policy_roots[policy_id] = _preflight(policy, f"lifecycle policy {policy_id!r}")
    if dict(policy_roots) != expected_policy_roots:
        raise _DecodeError("lifecycle policy roots do not match deployment policy bytes")

    clock_policy = _object(context.get("clock_policy"), "lifecycle clock policy")
    _keys(clock_policy, ("policy_id", "allowed_sources", "minimum_trust", "authority"), (), "lifecycle clock policy")
    _string(clock_policy.get("policy_id"), "lifecycle clock policy_id")
    _string(clock_policy.get("authority"), "lifecycle clock policy authority")
    allowed_sources = _strings(clock_policy.get("allowed_sources"), "allowed clock sources", sorted_unique=True, nonempty=True)
    minimum = _string(clock_policy.get("minimum_trust"), "minimum clock trust")
    if minimum not in _CLOCK_TRUST or minimum == "NONE_SUPPLIED":
        raise _UnsupportedProfileError(f"unsupported lifecycle clock trust {minimum!r}")
    clock = _object(snapshot.get("clock"), "lifecycle authority clock")
    clock_doc, instant = _clock(clock, "lifecycle authority clock")
    if instant is None:
        raise _DecodeError("lifecycle authority clock has no evaluation time")
    if clock_doc.get("verifier_clock_source") not in allowed_sources:
        raise _DecodeError("lifecycle authority clock source is not deployment-approved")
    trust = clock_doc.get("verifier_clock_trust_level")
    if trust not in _CLOCK_TRUST or _CLOCK_TRUST[trust] < _CLOCK_TRUST[minimum]:
        raise _DecodeError("lifecycle authority clock is below deployment trust policy")
    if snapshot.get("clock_root") != _preflight(clock_doc, "lifecycle authority clock"):
        raise _DecodeError("lifecycle clock root does not match its canonical bytes")

    principal = _object(snapshot.get("principal"), "lifecycle authenticated principal")
    _keys(
        principal,
        ("subject_id", "tenant_id", "roles", "organization", "authentication_method"),
        (),
        "lifecycle authenticated principal",
    )
    subject_id = _string(principal.get("subject_id"), "principal subject_id")
    _string(principal.get("tenant_id"), "principal tenant_id")
    _strings(principal.get("roles"), "principal roles", sorted_unique=True, nonempty=True)
    _string(principal.get("authentication_method"), "principal authentication method")
    subject = _object(subjects.get(subject_id), "registered lifecycle subject")
    if principal.get("organization") != subject.get("organization"):
        raise _DecodeError("authenticated organization disagrees with registered subject")
    binding = {
        "principal": dict(principal),
        "registered_subject": dict(subject),
        "trust_context_root": context_root,
    }
    if snapshot.get("principal_binding_root") != _preflight(binding, "principal binding"):
        raise _DecodeError("principal-binding root does not match authenticated identity")
    return snapshot


def _selected_policy(authority: Mapping[str, Any], action: str) -> Mapping[str, Any]:
    policies = authority["trust_context"]["policies"]
    matches = [policy for policy in policies.values() if action in policy.get("actions", ())]
    if len(matches) != 1:
        raise _DecodeError(f"action {action!r} has no unique deployment lifecycle policy")
    selected = dict(matches[0])
    selected.pop("actions", None)
    return selected


def _authority_actor_permitted(
    authority: Mapping[str, Any], operation: str
) -> Tuple[bool, str]:
    allowed = _AUTHORITY_OPERATION_ROLES[operation]
    held = set(authority["principal"].get("roles") or ())
    permitted = bool(held.intersection(allowed))
    return permitted, (
        f"authenticated actor holds a deployment role registered for {operation}"
        if permitted
        else f"authenticated actor lacks the least-privilege role for {operation}"
    )


def _verify_lifecycle_crypto(
    signed_content: Any, signature: Any, authority: Mapping[str, Any]
) -> Tuple[bool, str, Mapping[str, Any]]:
    signature = _object(signature, "lifecycle signature material")
    required = ("profile", "algorithm", "key_id", "key_reference", "value", "payload_hash", "excluded_fields")
    _keys(signature, required, ("created_at",), "lifecycle signature material")
    if signature.get("profile") != "Ed25519" or signature.get("algorithm") != "ed25519":
        raise _UnsupportedProfileError("lifecycle authority requires production Ed25519")
    if list(signature.get("excluded_fields") or ()):
        raise _DecodeError("lifecycle approval signatures may not exclude payload fields")
    key_id = _string(signature.get("key_id"), "lifecycle signature key_id")
    keys = authority["trust_context"]["trusted_keys"]
    key = keys.get(key_id)
    if not isinstance(key, Mapping):
        return False, f"no deployment-trusted lifecycle key {key_id!r}", {}
    if key.get("revoked") is True:
        return False, f"deployment lifecycle key {key_id!r} is revoked", key
    expected_reference = f"ed25519-pub:{key.get('public_key')}"
    if signature.get("key_reference") != expected_reference:
        return False, "signature key reference does not match deployment key", key
    if signature.get("payload_hash") != _preflight(signed_content, "signed lifecycle content"):
        return False, "signature payload hash does not match lifecycle content", key
    value = _string(signature.get("value"), "lifecycle signature value")
    prefix, separator, encoded = value.partition(":")
    if prefix != "ed25519" or not separator:
        return False, "signature value is not algorithm-tagged Ed25519", key
    try:
        public_bytes = bytes.fromhex(str(key.get("public_key")))
        signature_bytes = bytes.fromhex(encoded)
    except ValueError:
        return False, "public key or signature is not hexadecimal", key
    if len(signature_bytes) != 64:
        return False, "Ed25519 signature is not exactly 64 bytes", key
    try:
        from cryptography.exceptions import InvalidSignature
        from cryptography.hazmat.primitives.asymmetric import ed25519
    except ImportError as error:
        raise _UnsupportedProfileError(
            "Ed25519 provider unavailable; install crg-verify[federation]"
        ) from error
    try:
        ed25519.Ed25519PublicKey.from_public_bytes(public_bytes).verify(
            signature_bytes, canonical_bytes(signed_content)
        )
    except (InvalidSignature, ValueError):
        return False, "Ed25519 signature does not verify over canonical lifecycle content", key
    return True, f"Ed25519 verified with deployment key {key_id!r}", key


def _principal_approval_binding(
    payload: Mapping[str, Any], signature_key: Mapping[str, Any], authority: Mapping[str, Any],
    principal_value: Any,
) -> Tuple[bool, str]:
    principal = _object(principal_value, "approval authenticated principal")
    subject_id = str(payload.get("subject_id") or payload.get("withdrawn_by") or "")
    registered = authority["trust_context"]["subjects"].get(subject_id)
    if not isinstance(registered, Mapping):
        return False, f"approval subject {subject_id!r} is not deployment-registered"
    role = payload.get("role")
    role_ok = role is None or role in registered.get("approval_roles", ())
    assertion_field = "signed_at" if role is not None else "occurred_at"
    try:
        assertion_time = _time(
            payload.get(assertion_field), f"lifecycle payload.{assertion_field}"
        )
        authority_time = _time(
            authority["clock"].get("verifier_evaluation_time"),
            "lifecycle authority evaluation time",
        )
        time_ok = assertion_time <= authority_time
    except _DecodeError:
        time_ok = False
    bound = (
        dict(principal) == dict(authority["principal"])
        and principal.get("subject_id") == subject_id
        and principal.get("organization") == registered.get("organization")
        and payload.get("organization", registered.get("organization")) == registered.get("organization")
        and signature_key.get("subject_id") == subject_id
        and signature_key.get("organization") == registered.get("organization")
        and signature_key.get("public_key") is not None
        and role_ok
        and time_ok
        and "Decision Approver" in set(principal.get("roles") or ())
    )
    return bound, (
        "authenticated principal, deployment subject/role, and signature key are identical"
        if bound else
        "approval identity, organization, role, platform permission, or signature key is not bound to the authenticated principal"
    )


def _profile(record: Mapping[str, Any], record_type: str, profile: str) -> None:
    if record.get("schema_version") != SCHEMA_VERSION:
        raise _UnsupportedProfileError(
            f"unsupported {record_type} schema version {record.get('schema_version')!r}"
        )
    if record.get("profile") != profile:
        raise _UnsupportedProfileError(
            f"unregistered {record_type} profile {record.get('profile')!r}"
        )
    if record.get("record_type") != record_type:
        raise _DecodeError(
            f"expected record_type {record_type!r}, found {record.get('record_type')!r}"
        )


def _run(
    record: Mapping[str, Any],
    record_type: str,
    profile: str,
    checker: Any,
) -> VerificationResult:
    result = VerificationResult(ok=False, status=Status.FAILED)
    if not isinstance(record, Mapping):
        result.record("lifecycle_wire", False, f"{record_type} must be a JSON object")
        return result.finish()
    try:
        _profile(record, record_type, profile)
        root = _preflight(record, record_type)
        checks, report = checker()
    except _UnsupportedProfileError as error:
        result.status = Status.UNSUPPORTED_PROFILE
        result.record("lifecycle_profile", False, str(error))
        return result.finish()
    except (_DecodeError, ArithError, CanonicalError, KeyError, TypeError, ValueError, ZeroDivisionError) as error:
        result.record("lifecycle_decode", False, str(error))
        return result.finish()
    result.record("lifecycle_profile", True, f"{profile} schema {SCHEMA_VERSION}")
    for name, passed, detail in checks:
        result.record(name, passed, detail)
    result.report.update({"record_type": record_type, "artifact_root": root, **report})
    if not result.violations:
        result.status = Status.VERIFIED
    return result.finish()


def _exact(value: Any, where: str) -> Fraction:
    item = _object(value, where)
    if set(item) != {"exact"} or not isinstance(item.get("exact"), str):
        raise _DecodeError(f"{where} must be exactly {{'exact': '<rational>'}}")
    try:
        result = rational(item)
    except (ArithError, TypeError, ValueError, ZeroDivisionError) as error:
        raise _DecodeError(f"{where} is not an exact rational: {error}") from error
    canonical = str(result.numerator) if result.denominator == 1 else f"{result.numerator}/{result.denominator}"
    if item["exact"] != canonical:
        raise _DecodeError(f"{where} is not in canonical reduced rational form")
    return result


def _time(value: Any, where: str, *, optional: bool = False) -> Optional[_dt.datetime]:
    if value is None and optional:
        return None
    text = _string(value, where)
    try:
        parsed = _dt.datetime.fromisoformat(text.strip().replace("Z", "+00:00"))
    except ValueError as error:
        raise _DecodeError(f"{where} is not an ISO-8601 instant") from error
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=_dt.timezone.utc)


# ---------------------------------------------------------------------------
# Workstream D: guided ETQ loop, ingestion, revalidation, and disposition
# ---------------------------------------------------------------------------
def verify_etq_decision_loop(record: Mapping[str, Any]) -> VerificationResult:
    """Verify the exact twelve-step order and immutable artifact chain."""

    def check() -> Tuple[List[Tuple[str, bool, str]], Dict[str, Any]]:
        _keys(
            record,
            ("record_type", "profile", "schema_version", "loop_id", "target_decision_id",
             "predicate_id", "target_context_hash", "declared_stopping_conditions", "steps",
             "complete", "refused", "next_step"),
            (),
            "ETQ decision loop",
        )
        for field in ("loop_id", "target_decision_id", "predicate_id"):
            _string(record.get(field), f"ETQ decision loop.{field}")
        _hash(record.get("target_context_hash"), "ETQ decision loop.target_context_hash")
        stopping = _strings(record.get("declared_stopping_conditions"), "declared stopping conditions", nonempty=True)
        unknown_stops = sorted(set(stopping) - _STOPPING)
        if unknown_stops:
            raise _DecodeError(f"unknown stopping conditions {unknown_stops}")

        steps = _array(record.get("steps"), "ETQ decision loop.steps")
        if len(steps) > len(_LOOP_STEPS):
            raise _DecodeError("ETQ decision loop contains more than twelve steps")
        seen_ids: Set[str] = set()
        seen_hashes: Set[str] = set()
        prior_outputs: Set[str] = set()
        refused_at: Optional[int] = None
        for offset, raw in enumerate(steps):
            index = offset + 1
            step = _object(raw, f"ETQ decision loop.steps[{offset}]")
            _keys(
                step,
                ("step_index", "step", "input_hashes", "outputs", "authority", "verification_basis"),
                ("refusal",),
                f"ETQ decision loop.steps[{offset}]",
            )
            if _integer(step.get("step_index"), f"step {index}.step_index") != index:
                raise _DecodeError(f"step {index} carries a forged step_index")
            name = _string(step.get("step"), f"step {index}.step")
            if name != _LOOP_STEPS[offset]:
                raise _DecodeError(f"ETQ loop skipped or reordered step {index}: found {name!r}")
            inputs = _hashes(step.get("input_hashes"), f"step {index}.input_hashes")
            authority = _string(step.get("authority"), f"step {index}.authority")
            basis = _strings(step.get("verification_basis"), f"step {index}.verification_basis", nonempty=True)
            del authority, basis
            refusal_raw = step.get("refusal")
            if refusal_raw is not None:
                refusal = _object(refusal_raw, f"step {index}.refusal")
                _keys(refusal, ("code", "detail"), (), f"step {index}.refusal")
                _string(refusal.get("code"), f"step {index}.refusal.code")
                _string(refusal.get("detail"), f"step {index}.refusal.detail")
                refused_at = index
            outputs = _array(step.get("outputs"), f"step {index}.outputs")
            if refusal_raw is not None and outputs:
                raise _DecodeError(f"refused step {index} also claims outputs")
            if refusal_raw is None and not outputs:
                raise _DecodeError(f"step {index} neither produced an artifact nor refused")
            if index == 1 and inputs:
                raise _DecodeError("the evidence-authoring step consumes undeclared prior output")
            if index > 1 and refusal_raw is None:
                if not inputs or not set(inputs).issubset(seen_hashes):
                    raise _DecodeError(f"step {index} consumes an unknown prior artifact")
                if not prior_outputs.intersection(inputs):
                    raise _DecodeError(f"step {index} does not consume the immediately preceding step")

            current_outputs: Set[str] = set()
            types: Set[str] = set()
            for item_index, raw_output in enumerate(outputs):
                output = _object(raw_output, f"step {index}.outputs[{item_index}]")
                _keys(
                    output,
                    ("artifact_id", "artifact_type", "content_hash", "parent_hashes", "status", "evidence_class"),
                    (),
                    f"step {index}.outputs[{item_index}]",
                )
                artifact_id = _string(output.get("artifact_id"), f"step {index} artifact_id")
                artifact_type = _string(output.get("artifact_type"), f"step {index} artifact_type")
                artifact_hash = _hash(output.get("content_hash"), f"step {index} content_hash")
                parents = _hashes(output.get("parent_hashes"), f"step {index} parent_hashes")
                _string(output.get("status"), f"step {index} status")
                evidence_class = _string(output.get("evidence_class"), f"step {index} evidence_class")
                if evidence_class not in _EVIDENCE_CLASSES:
                    raise _DecodeError(f"step {index} has unknown evidence class {evidence_class!r}")
                if artifact_type not in _LOOP_OUTPUTS[name]:
                    raise _DecodeError(f"step {index} produced unregistered type {artifact_type!r}")
                if artifact_hash in parents:
                    raise _DecodeError(f"step {index} artifact is its own parent")
                if set(parents) - seen_hashes:
                    raise _DecodeError(f"step {index} artifact cites an unknown parent")
                if artifact_id in seen_ids or artifact_hash in seen_hashes or artifact_hash in current_outputs:
                    raise _DecodeError(f"step {index} reuses an earlier artifact identity or content")
                seen_ids.add(artifact_id)
                seen_hashes.add(artifact_hash)
                current_outputs.add(artifact_hash)
                types.add(artifact_type)
            if index == 12 and refusal_raw is None and "SelectiveRevalidationRecord" not in types:
                raise _DecodeError("the final step lacks a SelectiveRevalidationRecord")
            prior_outputs = current_outputs
            if refused_at is not None and index != len(steps):
                raise _DecodeError("the ETQ loop continues after a fail-closed refusal")

        complete = len(steps) == len(_LOOP_STEPS) and refused_at is None
        refused = bool(steps and refused_at == len(steps))
        next_step = None if complete or refused else _LOOP_STEPS[len(steps)]
        derived = (
            record.get("complete") is complete
            and record.get("refused") is refused
            and record.get("next_step") == next_step
        )
        return [
            ("etq_step_chain", True, f"{len(steps)} ordered lifecycle steps independently checked"),
            ("etq_derived_state", derived, "complete, refused, and next_step rederived from the immutable prefix"),
        ], {"step_count": len(steps), "complete": complete, "refused": refused}

    return _run(record, "ETQDecisionLoop", ETQ_PROFILE, check)


def verify_result_ingestion_record(
    record: Mapping[str, Any],
    result_record: Mapping[str, Any],
    new_evidence: Mapping[str, Any],
    prior_evidence: Sequence[Mapping[str, Any]] = (),
) -> VerificationResult:
    """Rebuild result, evidence, provenance, and preserved-history bindings."""

    def check() -> Tuple[List[Tuple[str, bool, str]], Dict[str, Any]]:
        _keys(
            record,
            ("record_type", "profile", "schema_version", "ingestion_id", "plan_id", "experiment_id",
             "result_hash", "new_evidence_id", "new_evidence_hash", "evidence_class",
             "evidence_status", "prior_evidence_ids", "prior_evidence_hashes", "preserved_prior_records"),
            (),
            "result ingestion",
        )
        for field in ("ingestion_id", "plan_id", "experiment_id", "new_evidence_id"):
            _string(record.get(field), f"result ingestion.{field}")
        result_doc = _object(result_record, "returned result")
        evidence_doc = _object(new_evidence, "new evidence")
        result_root = _preflight(result_doc, "returned result")
        evidence_root = _preflight(evidence_doc, "new evidence")
        if result_doc.get("status") != "COMPLETED" or result_doc.get("observed") is None:
            raise _DecodeError("only a COMPLETED result with an observation may become evidence")
        if result_doc.get("context") is None:
            raise _DecodeError("returned result has no source context")
        if record.get("experiment_id") != result_doc.get("experiment_id"):
            raise _DecodeError("ingestion experiment_id differs from the returned result")
        if evidence_doc.get("record_type") != "etq.evidence_record":
            raise _DecodeError("new evidence has an unsupported record_type")
        method = _object(evidence_doc.get("M_method"), "new evidence.M_method")
        provenance = _object(evidence_doc.get("P_provenance"), "new evidence.P_provenance")
        chain = _hashes(provenance.get("chain"), "new evidence provenance chain")
        evidence_class = _string(method.get("evidence_class"), "new evidence evidence_class")
        evidence_status = _string(evidence_doc.get("evidence_status"), "new evidence evidence_status")
        if evidence_class not in _EVIDENCE_CLASSES or evidence_status not in _EVIDENCE_STATUS:
            raise _DecodeError("new evidence has an unknown class or status")
        if result_root not in chain:
            raise _DecodeError("new evidence provenance does not commit to the exact returned result")
        prior_docs = tuple(_object(item, "prior evidence") for item in prior_evidence)
        prior_ids = tuple(_string(item.get("evidence_id"), "prior evidence.evidence_id") for item in prior_docs)
        prior_roots = tuple(_preflight(item, "prior evidence") for item in prior_docs)
        if len(set(prior_ids)) != len(prior_ids) or len(set(prior_roots)) != len(prior_roots):
            raise _DecodeError("prior evidence lineage repeats a record")
        new_id = _string(evidence_doc.get("evidence_id"), "new evidence.evidence_id")
        if new_id in prior_ids or evidence_root in prior_roots:
            raise _DecodeError("result ingestion reuses prior evidence identity or bytes")
        bindings = (
            record.get("result_hash") == result_root
            and record.get("new_evidence_id") == new_id
            and record.get("new_evidence_hash") == evidence_root
            and record.get("evidence_class") == evidence_class
            and record.get("evidence_status") == evidence_status
            and tuple(record.get("prior_evidence_ids", ())) == prior_ids
            and tuple(record.get("prior_evidence_hashes", ())) == prior_roots
            and record.get("preserved_prior_records") is True
        )
        return [
            ("result_evidence_binding", bindings, "result, provenance, evidence maturity, and exact bytes independently bound"),
            ("prior_evidence_preserved", record.get("preserved_prior_records") is True, f"{len(prior_docs)} prior immutable records preserved"),
        ], {"result_root": result_root, "new_evidence_root": evidence_root, "prior_count": len(prior_docs)}

    return _run(record, "ResultIngestionRecord", ETQ_PROFILE, check)


def _dependency_edges(raw_edges: Sequence[Mapping[str, Any]]) -> List[dict]:
    result: List[dict] = []
    identifiers: Set[str] = set()
    signatures: Set[Tuple[Any, ...]] = set()
    for index, raw in enumerate(_array(raw_edges, "dependency edges")):
        edge = _object(raw, f"dependency edges[{index}]")
        _keys(
            edge,
            ("edge_id", "source", "target", "edge_type", "minimum_action", "transitive",
             "validity_propagation_rule", "edge_version", "source_property", "scope", "invalidation_predicate"),
            (),
            f"dependency edges[{index}]",
        )
        edge_id = _string(edge.get("edge_id"), f"dependency edges[{index}].edge_id")
        if edge_id != edge_id.strip():
            raise _DecodeError(f"dependency edge id {edge_id!r} is not normalized")
        if edge_id in identifiers:
            raise _DecodeError(f"duplicate dependency edge id {edge_id!r}")
        identifiers.add(edge_id)
        edge_type = _string(edge.get("edge_type"), f"dependency edges[{index}].edge_type")
        if edge_type not in _EDGE:
            raise _DecodeError(f"unknown dependency edge type {edge_type!r}")
        action, transitive = _EDGE[edge_type]
        if edge.get("minimum_action") != action or edge.get("transitive") is not transitive:
            raise _DecodeError(f"edge {edge_id!r} forges registered typed semantics")
        expected_rule = _VALIDITY_RULE.get(action, "MARK_TARGET_STALE")
        if edge.get("validity_propagation_rule") != expected_rule or edge.get("edge_version") != "1":
            raise _DecodeError(f"edge {edge_id!r} has an unsupported validity rule or version")
        source = _string(edge.get("source"), f"edge {edge_id}.source")
        target = _string(edge.get("target"), f"edge {edge_id}.target")
        if source != source.strip() or target != target.strip():
            raise _DecodeError(f"edge {edge_id!r} has a non-normalized endpoint identity")
        source_property = _string(edge.get("source_property"), f"edge {edge_id}.source_property")
        scope = _string(edge.get("scope"), f"edge {edge_id}.scope")
        predicate = _string(edge.get("invalidation_predicate"), f"edge {edge_id}.invalidation_predicate")
        signature = (source, target, edge_type, source_property, scope, predicate)
        if signature in signatures:
            raise _DecodeError(f"dependency graph repeats edge {signature!r}")
        signatures.add(signature)
        result.append(dict(edge))

    edge_order = [edge["edge_id"] for edge in result]
    if edge_order != sorted(edge_order):
        raise _DecodeError("dependency edge identities are not in canonical order")

    nodes = {edge["source"] for edge in result} | {edge["target"] for edge in result}
    indegree = {node: 0 for node in nodes}
    outgoing: Dict[str, List[str]] = {node: [] for node in nodes}
    for edge in result:
        indegree[edge["target"]] += 1
        outgoing[edge["source"]].append(edge["target"])
    queue = sorted(node for node, degree in indegree.items() if degree == 0)
    visited = 0
    while queue:
        node = queue.pop(0)
        visited += 1
        for target in sorted(outgoing[node]):
            indegree[target] -= 1
            if indegree[target] == 0:
                queue.append(target)
                queue.sort()
    if visited != len(nodes):
        raise _DecodeError("dependency graph contains a cycle")
    return result


def _revalidation_expected(
    record: Mapping[str, Any],
    dependency_edges: Sequence[Mapping[str, Any]],
    artifact_universe: Sequence[str],
) -> Tuple[List[dict], List[str], List[str], str]:
    edges = _dependency_edges(dependency_edges)
    universe = _strings(
        artifact_universe,
        "artifact universe",
        sorted_unique=True,
        nonempty=True,
    )
    if any(item != item.strip() for item in universe):
        raise _DecodeError("artifact universe contains a non-normalized identity")
    changed_source = _string(record.get("changed_source"), "selective revalidation.changed_source")
    changed = _strings(record.get("changed_properties"), "changed_properties", sorted_unique=True, nonempty=True)
    if changed_source not in universe:
        raise _DecodeError("changed source is absent from the complete artifact universe")
    nodes = {edge["source"] for edge in edges} | {edge["target"] for edge in edges}
    outside = sorted(nodes - set(universe))
    if outside:
        raise _DecodeError(f"dependency graph names artifacts outside the complete universe: {outside}")
    if changed_source not in nodes:
        raise _DecodeError("changed source is absent from the typed dependency graph")
    outgoing: Dict[str, List[dict]] = {}
    for edge in edges:
        outgoing.setdefault(edge["source"], []).append(edge)
    impact: Dict[str, str] = {}
    frontier: List[Tuple[str, Optional[Set[str]]]] = [(changed_source, set(changed))]
    seen: Set[str] = set()
    while frontier:
        node, properties = frontier.pop()
        for edge in outgoing.get(node, ()):
            if edge["edge_id"] in seen:
                continue
            source_property = edge["source_property"]
            if properties is not None and source_property != "*" and source_property not in properties:
                continue
            seen.add(edge["edge_id"])
            action = edge["minimum_action"]
            prior = impact.get(edge["target"], "NO_OPERATION")
            if _ACTION_SEVERITY[action] > _ACTION_SEVERITY[prior]:
                impact[edge["target"]] = action
            else:
                impact.setdefault(edge["target"], prior)
            if edge["transitive"] and action != "NO_OPERATION":
                frontier.append((edge["target"], None))
    affected = [
        {"artifact_id": identifier, "minimum_action": action}
        for identifier, action in sorted(impact.items())
    ]
    preserved = sorted(set(universe) - set(impact) - {changed_source})
    replacement = sorted(impact)
    graph_hash = content_hash([edge for edge in sorted(edges, key=lambda item: item["edge_id"])])
    return affected, preserved, replacement, graph_hash


def verify_selective_revalidation_record(
    record: Mapping[str, Any],
    dependency_edges: Sequence[Mapping[str, Any]],
    artifact_universe: Sequence[str],
) -> VerificationResult:
    """Replay a complete typed dependency closure and preservation claim."""

    def check() -> Tuple[List[Tuple[str, bool, str]], Dict[str, Any]]:
        _keys(
            record,
            ("record_type", "profile", "schema_version", "record_id", "changed_source",
             "changed_properties", "dependency_graph_hash", "dependency_completeness_basis",
             "affected", "preserved", "replacement_required", "state"),
            (),
            "selective revalidation",
        )
        _string(record.get("record_id"), "selective revalidation.record_id")
        _string(record.get("dependency_completeness_basis"), "dependency completeness basis")
        if record.get("state") not in {"PENDING_REVALIDATION", "REVALIDATION_COMPLETE"}:
            raise _DecodeError(f"unknown revalidation state {record.get('state')!r}")
        affected, preserved, replacement, graph_hash = _revalidation_expected(
            record, dependency_edges, artifact_universe
        )
        exact = (
            record.get("dependency_graph_hash") == graph_hash
            and record.get("affected") == affected
            and record.get("preserved") == preserved
            and record.get("replacement_required") == replacement
        )
        return [
            ("typed_dependency_closure", exact, "complete typed closure, minimum actions, and graph root independently reconstructed"),
            ("preservation_partition", not (set(preserved) & {item["artifact_id"] for item in affected}), "affected and preserved artifact sets are disjoint"),
        ], {"dependency_graph_hash": graph_hash, "affected_count": len(affected), "preserved_count": len(preserved)}

    return _run(record, "SelectiveRevalidationRecord", ETQ_PROFILE, check)


def verify_replacement_record(
    record: Mapping[str, Any],
    revalidation_record: Mapping[str, Any],
    prior_artifact: Mapping[str, Any],
    replacement_artifact: Mapping[str, Any],
    dependency_edges: Sequence[Mapping[str, Any]],
    artifact_universe: Sequence[str],
) -> VerificationResult:
    """Verify replacement lineage and prohibit replacing a preserved object."""

    def check() -> Tuple[List[Tuple[str, bool, str]], Dict[str, Any]]:
        _keys(
            record,
            ("record_type", "profile", "schema_version", "replacement_id", "revalidation_record_hash",
             "prior_artifact_id", "replacement_artifact_id", "prior_artifact_hash",
             "replacement_artifact_hash", "action_completed", "verification_basis"),
            (),
            "replacement record",
        )
        for field in ("replacement_id", "prior_artifact_id", "replacement_artifact_id"):
            _string(record.get(field), f"replacement record.{field}")
        _strings(record.get("verification_basis"), "replacement verification_basis", nonempty=True)
        revalidation = _object(revalidation_record, "revalidation record")
        revalidation_result = verify_selective_revalidation_record(
            revalidation, dependency_edges, artifact_universe
        )
        if not revalidation_result.ok:
            raise _DecodeError("the referenced selective-revalidation record does not independently verify")
        affected = {
            _string(item.get("artifact_id"), "affected.artifact_id"): _string(item.get("minimum_action"), "affected.minimum_action")
            for item in (_object(raw, "affected item") for raw in _array(revalidation.get("affected"), "affected"))
        }
        prior_id = record.get("prior_artifact_id")
        if prior_id in set(revalidation.get("preserved", ())):
            raise _DecodeError("a preserved artifact cannot be replaced")
        if prior_id not in affected or prior_id not in set(revalidation.get("replacement_required", ())):
            raise _DecodeError("replacement target was not affected and replacement-required")
        prior_root = _preflight(prior_artifact, "prior artifact")
        replacement_root = _preflight(replacement_artifact, "replacement artifact")
        if record.get("prior_artifact_id") == record.get("replacement_artifact_id") or prior_root == replacement_root:
            raise _DecodeError("replacement must have a new identity and new immutable bytes")
        exact = (
            record.get("revalidation_record_hash") == content_hash(revalidation)
            and record.get("prior_artifact_hash") == prior_root
            and record.get("replacement_artifact_hash") == replacement_root
            and record.get("action_completed") == affected[prior_id]
        )
        return [
            ("replacement_binding", exact, "revalidation, prior bytes, replacement bytes, and minimum action independently bound"),
            ("preserved_object_guard", prior_id not in set(revalidation.get("preserved", ())), "replacement target is not in the preserved partition"),
        ], {"prior_artifact_root": prior_root, "replacement_artifact_root": replacement_root}

    return _run(record, "ReplacementRecord", ETQ_PROFILE, check)


def _validate_ingestion_summary(record: Mapping[str, Any]) -> Tuple[str, str, str]:
    _profile(record, "ResultIngestionRecord", ETQ_PROFILE)
    _keys(
        record,
        ("record_type", "profile", "schema_version", "ingestion_id", "plan_id", "experiment_id",
         "result_hash", "new_evidence_id", "new_evidence_hash", "evidence_class",
         "evidence_status", "prior_evidence_ids", "prior_evidence_hashes", "preserved_prior_records"),
        (),
        "qualification result ingestion",
    )
    for field in ("ingestion_id", "plan_id", "experiment_id"):
        _string(record.get(field), f"ingestion.{field}")
    _hash(record.get("result_hash"), "ingestion.result_hash")
    evidence_id = _string(record.get("new_evidence_id"), "ingestion.new_evidence_id")
    evidence_hash = _hash(record.get("new_evidence_hash"), "ingestion.new_evidence_hash")
    evidence_class = _string(record.get("evidence_class"), "ingestion.evidence_class")
    evidence_status = _string(record.get("evidence_status"), "ingestion.evidence_status")
    if evidence_class not in _EVIDENCE_CLASSES or evidence_status not in _EVIDENCE_STATUS:
        raise _DecodeError("ingestion carries an unknown evidence class or maturity")
    prior_ids = _strings(record.get("prior_evidence_ids"), "ingestion.prior_evidence_ids")
    prior_hashes = _hashes(record.get("prior_evidence_hashes"), "ingestion.prior_evidence_hashes")
    if len(prior_ids) != len(prior_hashes):
        raise _DecodeError("ingestion prior evidence identities and hashes are not one-to-one")
    if evidence_id in prior_ids or evidence_hash in prior_hashes:
        raise _DecodeError("ingestion reuses a prior evidence identity or hash")
    if record.get("preserved_prior_records") is not True:
        raise _DecodeError("ingestion does not preserve prior evidence records")
    return evidence_id, evidence_hash, evidence_class


def verify_qualification_disposition(
    record: Mapping[str, Any],
    qualification_result: Mapping[str, Any],
    ingestions: Sequence[Mapping[str, Any]],
    required_evidence_ids: Sequence[str],
    verification_basis: Sequence[str],
    *,
    minimum_evidence_status: str = "QUALIFIED",
) -> VerificationResult:
    """Re-derive direct campaign disposition and its evidence floor."""

    def check() -> Tuple[List[Tuple[str, bool, str]], Dict[str, Any]]:
        _keys(
            record,
            ("record_type", "profile", "schema_version", "plan_id", "state", "stopping_condition",
             "outcome", "evidence_hashes", "verification_basis", "unmet_requirements"),
            (),
            "qualification disposition",
        )
        result_doc = _object(qualification_result, "qualification result")
        _preflight(result_doc, "qualification result")
        plan_id = _string(result_doc.get("plan_id"), "qualification result.plan_id")
        stopped = _boolean(result_doc.get("stopped"), "qualification result.stopped")
        reason = _string(result_doc.get("stopping_reason"), "qualification result.stopping_reason")
        detail = _string(result_doc.get("stopping_detail"), "qualification result.stopping_detail", empty=True)
        if minimum_evidence_status not in _EVIDENCE_STATUS:
            raise _UnsupportedProfileError(f"unknown minimum evidence status {minimum_evidence_status!r}")
        _preflight(list(verification_basis), "qualification verification basis")
        basis = tuple(_string(item, "verification_basis[]") for item in verification_basis if item)
        if len(set(basis)) != len(basis):
            raise _DecodeError("verification basis contains duplicates")
        required = set(_string(item, "required_evidence_ids[]") for item in required_evidence_ids)
        summaries = []
        for raw in ingestions:
            ingestion = _object(raw, "result ingestion")
            _preflight(ingestion, "result ingestion")
            evidence_id, evidence_hash, evidence_class = _validate_ingestion_summary(ingestion)
            summaries.append((evidence_id, evidence_hash, evidence_class, ingestion["evidence_status"]))
        ids = [item[0] for item in summaries]
        if len(set(ids)) != len(ids):
            raise _DecodeError("qualification ingestions repeat an evidence identity")
        evidence_hashes = [item[1] for item in summaries]
        unmet: List[str] = []
        if not stopped:
            state = "IN_PROGRESS"
            outcome = "the declared stopping rule has not fired"
        elif reason not in _RESOLVING_STOPS:
            if reason not in _STOPPING:
                raise _DecodeError(f"unknown stopping reason {reason!r}")
            state = "STOPPED_UNRESOLVED"
            outcome = detail
        else:
            missing = sorted(required - set(ids))
            if missing:
                unmet.append("missing required evidence: " + ", ".join(missing))
            weak = sorted(item[0] for item in summaries if _EVIDENCE_STATUS[item[3]] < _EVIDENCE_STATUS[minimum_evidence_status])
            if weak:
                unmet.append(f"evidence below {minimum_evidence_status}: " + ", ".join(weak))
            nonauthorizing = sorted(item[0] for item in summaries if item[2] not in _AUTHORIZING_EVIDENCE)
            if nonauthorizing:
                unmet.append("non-authorizing evidence class: " + ", ".join(nonauthorizing))
            if not basis:
                unmet.append("missing verification basis")
            if unmet:
                state = "EVIDENCE_REQUIREMENTS_UNSATISFIED"
                outcome = "the stopping condition fired but qualification evidence is incomplete"
            else:
                state = "QUALIFICATION_COMPLETE"
                outcome = detail
        expected = {
            "plan_id": plan_id,
            "state": state,
            "stopping_condition": reason,
            "outcome": outcome,
            "evidence_hashes": evidence_hashes,
            "verification_basis": list(basis),
            "unmet_requirements": unmet,
        }
        actual = {key: record.get(key) for key in expected}
        return [
            ("qualification_derivation", actual == expected, "stop class, evidence maturity/class, required identities, and verification basis independently rederived"),
            ("qualification_no_synthetic_score", not ({"score", "confidence", "readiness", "health"} & set(record)), "disposition contains direct states only"),
        ], {"derived_state": state, "evidence_count": len(summaries)}

    return _run(record, "QualificationDisposition", ETQ_PROFILE, check)


# ---------------------------------------------------------------------------
# Workstream E: conversion bindings
# ---------------------------------------------------------------------------
def _cell(raw: Any, where: str) -> Tuple[int, Tuple[Tuple[Fraction, Fraction], ...], Fraction]:
    item = _object(raw, where)
    _keys(item, ("index", "box", "measure"), ("owner",), where)
    index = _integer(item.get("index"), f"{where}.index", minimum=0)
    box = []
    measure = Fraction(1)
    for axis_index, raw_axis in enumerate(_array(item.get("box"), f"{where}.box")):
        axis = _array(raw_axis, f"{where}.box[{axis_index}]")
        if len(axis) != 2:
            raise _DecodeError(f"{where}.box[{axis_index}] must have two bounds")
        lower = _exact(axis[0], f"{where}.box[{axis_index}][0]")
        upper = _exact(axis[1], f"{where}.box[{axis_index}][1]")
        if upper <= lower:
            raise _DecodeError(f"{where} has an empty or reversed cell bound")
        box.append((lower, upper))
        measure *= upper - lower
    if not box or _exact(item.get("measure"), f"{where}.measure") != measure:
        raise _DecodeError(f"{where} has a forged cell measure")
    return index, tuple(box), measure


def _intersection(left: Sequence[Tuple[Fraction, Fraction]], right: Sequence[Tuple[Fraction, Fraction]]) -> Fraction:
    if len(left) != len(right):
        raise _DecodeError("source and target conversion cells have different dimensions")
    result = Fraction(1)
    for (a_lower, a_upper), (b_lower, b_upper) in zip(left, right):
        lower, upper = max(a_lower, b_lower), min(a_upper, b_upper)
        if upper <= lower:
            return Fraction(0)
        result *= upper - lower
    return result


def _conversion_invariants(record: Mapping[str, Any]) -> Dict[str, bool]:
    source_cells = [_cell(item, f"conversion.source_cells[{index}]") for index, item in enumerate(_array(record.get("source_cells"), "conversion.source_cells"))]
    target_cells = [_cell(item, f"conversion.target_cells[{index}]") for index, item in enumerate(_array(record.get("target_cells"), "conversion.target_cells"))]
    source = {item[0]: item for item in source_cells}
    target = {item[0]: item for item in target_cells}
    if len(source) != len(source_cells) or len(target) != len(target_cells):
        raise _DecodeError("conversion repeats a source or target cell index")
    for label, cells in (("source", source_cells), ("target", target_cells)):
        if sum((item[2] for item in cells), Fraction(0)) != 1:
            raise _DecodeError(f"conversion {label} cells do not partition unit measure")
        if any(
            _intersection(cells[left][1], cells[right][1]) > 0
            for left in range(len(cells))
            for right in range(left + 1, len(cells))
        ):
            raise _DecodeError(f"conversion {label} ownership cells overlap")
    retained_fraction = _exact(record.get("retained_fraction"), "conversion.retained_fraction")
    moved_fraction = _exact(record.get("moved_fraction"), "conversion.moved_fraction")
    solver = _object(record.get("solver_evidence"), "conversion.solver_evidence")
    assignment_raw = _array(record.get("assignment"), "conversion.assignment")
    assignment: List[Tuple[int, int]] = []
    for index, raw in enumerate(assignment_raw):
        pair = _array(raw, f"conversion.assignment[{index}]")
        if len(pair) != 2:
            raise _DecodeError("conversion assignment entry must be a pair")
        assignment.append((_integer(pair[0], "assignment source", minimum=0), _integer(pair[1], "assignment target", minimum=0)))
    if assignment != sorted(assignment):
        raise _DecodeError("conversion assignment is not canonically source-sorted")
    if any(i not in source or j not in target for i, j in assignment):
        raise _DecodeError("conversion assignment references an unknown cell")

    retained: List[Tuple[int, int, Fraction]] = []
    for index, raw in enumerate(_array(record.get("retained"), "conversion.retained")):
        item = _object(raw, f"conversion.retained[{index}]")
        _keys(item, ("source_cell", "target_cell", "measure"), ("elements", "bytes"), f"conversion.retained[{index}]")
        retained.append((
            _integer(item.get("source_cell"), "retained.source_cell", minimum=0),
            _integer(item.get("target_cell"), "retained.target_cell", minimum=0),
            _exact(item.get("measure"), "retained.measure"),
        ))
    residual: List[Tuple[int, int, int, Fraction]] = []
    for index, raw in enumerate(_array(record.get("residual"), "conversion.residual")):
        item = _object(raw, f"conversion.residual[{index}]")
        _keys(item, ("target_cell", "from_source_cell", "to_source_cell", "measure"), ("elements", "bytes"), f"conversion.residual[{index}]")
        residual.append((
            _integer(item.get("target_cell"), "residual.target_cell", minimum=0),
            _integer(item.get("from_source_cell"), "residual.from_source_cell", minimum=0),
            _integer(item.get("to_source_cell"), "residual.to_source_cell", minimum=0),
            _exact(item.get("measure"), "residual.measure"),
        ))
    for i, j, _ in retained:
        if i not in source or j not in target:
            raise _DecodeError("retained witness references an unknown cell")
    for j, i, _to, _ in residual:
        if i not in source or j not in target:
            raise _DecodeError("residual witness references an unknown cell")

    retained_total = sum((measure for _, _, measure in retained), Fraction(0))
    residual_total = sum((measure for _, _, _, measure in residual), Fraction(0))
    per_target = {identifier: Fraction(0) for identifier in target}
    per_source = {identifier: Fraction(0) for identifier in source}
    claimed: Dict[Tuple[int, int], Fraction] = {}
    for i, j, measure in retained:
        per_target[j] += measure
        per_source[i] += measure
        claimed[(i, j)] = claimed.get((i, j), Fraction(0)) + measure
    for j, i, _to, measure in residual:
        per_target[j] += measure
        per_source[i] += measure
        claimed[(i, j)] = claimed.get((i, j), Fraction(0)) + measure
    within_overlap = all(measure <= _intersection(source[i][1], target[j][1]) for (i, j), measure in claimed.items())
    retained_within = all(measure <= _intersection(source[i][1], target[j][1]) for i, j, measure in retained)
    duplication = _object(record.get("duplication"), "conversion.duplication")
    mode = _string(duplication.get("mode"), "conversion.duplication.mode")
    route_total = Fraction(0)
    for index, raw in enumerate(_array(record.get("route"), "conversion.route")):
        route = _object(raw, f"conversion.route[{index}]")
        route_total += _exact(route.get("measure"), f"conversion.route[{index}].measure")
    identity = _boolean(record.get("identity"), "conversion.identity")
    derived_identity = (
        len(source_cells) == len(target_cells)
        and [item[1] for item in sorted(source_cells)] == [item[1] for item in sorted(target_cells)]
    )
    if identity is not derived_identity:
        raise _DecodeError("conversion identity flag disagrees with the exact source and target cells")
    secondary_ok = True
    if record.get("secondary") is not None:
        secondary = _object(record.get("secondary"), "conversion.secondary")
        preserved = _boolean(secondary.get("retention_preserved"), "conversion.secondary.retention_preserved")
        permitted = _boolean(secondary.get("trade_permitted"), "conversion.secondary.trade_permitted")
        expected = preserved or bool(permitted and secondary.get("authorization"))
        if secondary.get("primary_respected") is not expected:
            raise _DecodeError("conversion secondary report forges primary_respected")
        secondary_ok = expected
    return {
        "ARITHMETIC_IS_EXACT_RATIONAL": solver.get("arithmetic_profile") == "EXACT_RATIONAL",
        "RETAINED_PLUS_MOVED_EQUALS_TOTAL": retained_fraction + moved_fraction == 1,
        "ASSIGNMENT_IS_ONE_TO_ONE": len({i for i, _ in assignment}) == len(assignment) and len({j for _, j in assignment}) == len(assignment),
        "RETENTION_MATCHES_ASSIGNMENT_WITNESS": retained_total == retained_fraction,
        "TARGET_COVERAGE_COMPLETE": all(per_target[index] == target[index][2] for index in target),
        "NO_UNDECLARED_DUPLICATION": within_overlap if mode == "NONE" else True,
        "RETAINED_WITHIN_OVERLAP": retained_within,
        "SOURCE_MASS_CONSERVED": all(per_source[index] == source[index][2] for index in source),
        "RESIDUAL_MATCHES_MOVED_FRACTION": residual_total == moved_fraction,
        "IDENTITY_LAYOUT_MOVES_ZERO": (moved_fraction == 0 and not record.get("route")) if identity else True,
        "SECONDARY_PRESERVES_PRIMARY_OPTIMUM": secondary_ok,
        "ROUTE_MATCHES_RESIDUAL": route_total == moved_fraction,
    }


def verify_decision_scoped_conversion(
    record: Mapping[str, Any],
    conversion_record: Mapping[str, Any],
    source_case: Any,
    target_case: Any,
    retained_geometry: Any,
    decision_scope: Any,
    decision_certificate: Any,
    semantic_verifications: Sequence[Any],
    dependencies: Sequence[Any] = (),
) -> VerificationResult:
    """Verify exact semantic inputs and independently replay conversion invariants."""

    def check() -> Tuple[List[Tuple[str, bool, str]], Dict[str, Any]]:
        _keys(
            record,
            ("record_type", "profile", "schema_version", "binding_id", "conversion_record_id",
             "conversion_record_hash", "source_case_root", "target_case_root", "retained_geometry_hash",
             "decision_scope_hash", "decision_certificate_hash", "retained_geometry_relation",
             "decision_scope_relation", "authority", "dependency_hashes", "semantic_verification_hashes",
             "invariant_checks", "verification_program", "ready_for_transition_planning", "claim_boundary"),
            (),
            "decision-scoped conversion",
        )
        for field in ("binding_id", "conversion_record_id", "retained_geometry_relation", "decision_scope_relation", "authority"):
            _string(record.get(field), f"decision-scoped conversion.{field}")
        conversion = _object(conversion_record, "conversion record")
        conversion_root = _preflight(conversion, "conversion record")
        source_root = _preflight(source_case, "source case")
        target_root = _preflight(target_case, "target case")
        geometry_root = _preflight(retained_geometry, "retained geometry")
        scope_root = _preflight(decision_scope, "decision scope")
        certificate_root = _preflight(decision_certificate, "decision certificate")
        semantic_roots = [_preflight(item, "semantic verification") for item in semantic_verifications]
        dependency_roots = [_preflight(item, "conversion dependency") for item in dependencies]
        if not semantic_roots or len(set(semantic_roots)) != len(semantic_roots):
            raise _DecodeError("conversion binding needs unique semantic verification evidence")
        if len(set(dependency_roots)) != len(dependency_roots):
            raise _DecodeError("conversion binding repeats a dependency")
        program = _strings(conversion.get("verification_program"), "conversion verification_program", nonempty=True)
        if program != _CONVERSION_PROGRAM:
            raise _UnsupportedProfileError(f"unregistered conversion verification program {program!r}")
        invariants = _conversion_invariants(conversion)
        expected_checks = [
            {"check": name, "passed": passed} for name, passed in sorted(invariants.items())
        ]
        input_bindings = (
            record.get("conversion_record_id") == conversion.get("record_id")
            and record.get("conversion_record_hash") == conversion_root
            and record.get("source_case_root") == source_root
            and record.get("target_case_root") == target_root
            and record.get("retained_geometry_hash") == geometry_root
            and record.get("decision_scope_hash") == scope_root
            and record.get("decision_certificate_hash") == certificate_root
            and record.get("semantic_verification_hashes") == semantic_roots
            and record.get("dependency_hashes") == dependency_roots
        )
        invariant_binding = (
            all(invariants.values())
            and record.get("invariant_checks") == expected_checks
            and record.get("verification_program") == list(program)
            and record.get("ready_for_transition_planning") is True
        )
        boundary = "record binding only; not transition authorization, execution evidence, physical signoff, or a continued-validity judgment"
        return [
            ("conversion_input_bindings", input_bindings, "conversion, case, geometry, scope, certificate, and evidence hashes independently recomputed"),
            ("conversion_invariants", invariant_binding, f"{len(invariants)} exact conversion invariants independently replayed"),
            ("conversion_claim_boundary", record.get("claim_boundary") == boundary, "binding remains non-authorizing transition-planning evidence"),
        ], {"conversion_record_hash": conversion_root, "invariants": invariants}

    return _run(record, "DecisionScopedConversion", CONVERSION_PROFILE, check)


def verify_conversion_binding_impact(
    record: Mapping[str, Any],
    binding: Mapping[str, Any],
    current_conversion_record: Any,
    current_retained_geometry: Any,
    current_decision_scope: Any,
    current_decision_certificate: Any,
) -> VerificationResult:
    """Re-derive impact and enforce the exact-input guard on ``CURRENT``."""

    def check() -> Tuple[List[Tuple[str, bool, str]], Dict[str, Any]]:
        _keys(
            record,
            ("record_type", "profile", "schema_version", "binding_hash", "status", "changed_inputs",
             "required_actions", "preserved_binding"),
            (),
            "conversion binding impact",
        )
        bound = _object(binding, "decision-scoped conversion binding")
        _profile(bound, "DecisionScopedConversion", CONVERSION_PROFILE)
        current = {
            "conversion_record_hash": _preflight(current_conversion_record, "current conversion record"),
            "retained_geometry_hash": _preflight(current_retained_geometry, "current retained geometry"),
            "decision_scope_hash": _preflight(current_decision_scope, "current decision scope"),
            "decision_certificate_hash": _preflight(current_decision_certificate, "current decision certificate"),
        }
        changed = [name for name, root in current.items() if root != bound.get(name)]
        if not changed:
            status, actions, preserved = "CURRENT", [], True
        elif {"conversion_record_hash", "retained_geometry_hash", "decision_scope_hash"}.intersection(changed):
            status = "REOPEN_REQUIRED"
            actions = ["RECOMPUTE_OR_VERIFY_CONVERSION", "ISSUE_NEW_DECISION_SCOPED_BINDING"]
            preserved = False
        else:
            status = "REVALIDATION_REQUIRED"
            actions = ["REVALIDATE_DECISION_CERTIFICATE", "ISSUE_NEW_DECISION_SCOPED_BINDING"]
            preserved = False
        expected = {
            "binding_hash": content_hash(bound),
            "status": status,
            "changed_inputs": changed,
            "required_actions": actions,
            "preserved_binding": preserved,
        }
        actual = {key: record.get(key) for key in expected}
        return [
            ("conversion_impact_derivation", actual == expected, "changed semantic input roots and required actions independently rederived"),
            ("conversion_current_guard", status != "CURRENT" or not changed, "CURRENT is admitted only when all four semantic input roots are exact matches"),
        ], {"derived_status": status, "changed_inputs": changed}

    return _run(record, "ConversionBindingImpact", CONVERSION_PROFILE, check)


# ---------------------------------------------------------------------------
# Workstream E: signatures, authorization, and continued validity
# ---------------------------------------------------------------------------
def _signature_record(
    record: Mapping[str, Any],
    *,
    signature_content: Any = None,
    trusted_record_root: Optional[str] = None,
) -> Tuple[str, List[Tuple[str, bool, str]]]:
    _profile(record, "SignatureVerificationRecord", VALIDITY_PROFILE)
    _keys(
        record,
        ("record_type", "profile", "schema_version", "verification_id", "signature_id", "signature_hash",
         "signed_content_hash", "key_id", "algorithm", "verifier_id", "verifier_version", "checked_at", "verified"),
        ("failure_reason",),
        "signature verification record",
    )
    for field in ("verification_id", "signature_id", "key_id", "algorithm", "verifier_id", "verifier_version"):
        _string(record.get(field), f"signature verification.{field}")
    _time(record.get("checked_at"), "signature verification.checked_at")
    _hash(record.get("signature_hash"), "signature verification.signature_hash")
    _hash(record.get("signed_content_hash"), "signature verification.signed_content_hash")
    verified = _boolean(record.get("verified"), "signature verification.verified")
    if not verified and not record.get("failure_reason"):
        raise _DecodeError("failed signature verification must state a failure reason")
    root = _preflight(record, "signature verification record")
    checks: List[Tuple[str, bool, str]] = []
    if signature_content is not None:
        checks.append((
            "signature_bytes_hash",
            record.get("signature_hash") == _preflight(signature_content, "signature content"),
            "signature content hash independently recomputed",
        ))
    if trusted_record_root is not None:
        _hash(trusted_record_root, "trusted signature-verification root")
        checks.append((
            "signature_attestation_anchor",
            root == trusted_record_root,
            "embedded signature-verification evidence matches the independently trusted root",
        ))
    return root, checks


def verify_signature_verification_record(
    record: Mapping[str, Any],
    *,
    signature_content: Any = None,
    trusted_record_root: Optional[str] = None,
    signed_content: Any = None,
    authority_snapshot: Any = None,
) -> VerificationResult:
    """Verify signature evidence.

    The legacy path is integrity-only.  Supplying ``authority_snapshot``
    selects the additive authority path, which independently performs
    Ed25519 verification under deployment-owned keys.
    """

    def check() -> Tuple[List[Tuple[str, bool, str]], Dict[str, Any]]:
        root, checks = _signature_record(
            record, signature_content=signature_content, trusted_record_root=trusted_record_root
        )
        if authority_snapshot is None:
            checks.insert(0, ("signature_record_structure", True, "identity, algorithm, hashes, clock, and result are explicit"))
            return checks, {
                "signature_verification_root": root,
                "cryptography_replayed": False,
                "claim_scope": "INTEGRITY_ONLY",
            }
        authority = _authority_snapshot(authority_snapshot)
        if signed_content is None:
            raise _DecodeError("authority replay requires the exact signed lifecycle content")
        crypto_ok, crypto_detail, key = _verify_lifecycle_crypto(
            signed_content, signature_content, authority
        )
        actor_ok, actor_detail = _authority_actor_permitted(
            authority, "RECORD_SIGNATURE_VERIFICATION"
        )
        signature = _object(signature_content, "lifecycle signature material")
        clock = authority["clock"]
        derived = (
            record.get("signature_hash") == _preflight(signature, "lifecycle signature material")
            and record.get("signed_content_hash") == _preflight(signed_content, "signed lifecycle content")
            and record.get("key_id") == signature.get("key_id")
            and record.get("algorithm") == "ed25519"
            and record.get("verifier_id") == "crg-security:Ed25519"
            and record.get("verifier_version") == authority["trust_context"]["context_version"]
            and record.get("checked_at") == clock.get("verifier_evaluation_time")
            and record.get("verified") is crypto_ok
            and (crypto_ok or record.get("failure_reason") == crypto_detail)
        )
        checks.extend([
            ("signature_authenticated_actor_permission", actor_ok, actor_detail),
            ("signature_cryptography_replayed", crypto_ok, crypto_detail),
            ("signature_authority_derivation", derived, "signature result, key, verifier identity, and deployment clock independently derived"),
            ("signature_key_subject_registered", bool(key), "verification key is deployment-owned and subject-bound"),
        ])
        return checks, {
            "signature_verification_root": root,
            "cryptography_replayed": True,
            "trust_context_root": authority["trust_context_root"],
            "clock_root": authority["clock_root"],
            "claim_scope": "AUTHORITY_SNAPSHOT_CRYPTO_REPLAY",
        }

    return _run(record, "SignatureVerificationRecord", VALIDITY_PROFILE, check)


def _validity(value: Any, where: str) -> Mapping[str, Any]:
    item = _object(value, where)
    _keys(item, ("issuer_clock_source",), ("issued_at", "not_before", "expires_at", "max_age_seconds", "revalidation_triggers"), where)
    _string(item.get("issuer_clock_source"), f"{where}.issuer_clock_source")
    for field in ("issued_at", "not_before", "expires_at"):
        if item.get(field) is not None:
            # Issuer timestamps are assertions.  An unparsable assertion is
            # retained here so authorization can derive
            # CLOCK_POLICY_VIOLATION, matching the normative clock table.
            _string(item.get(field), f"{where}.{field}")
    if item.get("max_age_seconds") is not None:
        _integer(item.get("max_age_seconds"), f"{where}.max_age_seconds", minimum=0)
    if item.get("revalidation_triggers") is not None:
        _strings(item.get("revalidation_triggers"), f"{where}.revalidation_triggers")
    return item


def _approval(
    record: Mapping[str, Any],
    trusted_signature_roots: Mapping[str, str],
    *,
    signature_content: Any = None,
) -> Tuple[str, Mapping[str, Any], List[Tuple[str, bool, str]]]:
    _profile(record, "ApprovalRecord", VALIDITY_PROFILE)
    _keys(record, ("record_type", "profile", "schema_version", "approval_id", "payload", "approval_payload_hash", "signature_verification"), (), "approval record")
    _string(record.get("approval_id"), "approval.approval_id")
    payload = _object(record.get("payload"), "approval.payload")
    _keys(payload, ("artifact_hash", "action", "subject_id", "role", "organization", "signed_at", "validity", "authority"), (), "approval.payload")
    _hash(payload.get("artifact_hash"), "approval.payload.artifact_hash")
    for field in ("action", "subject_id", "role", "organization", "authority"):
        _string(payload.get(field), f"approval.payload.{field}")
    _time(payload.get("signed_at"), "approval.payload.signed_at")
    _validity(payload.get("validity"), "approval.payload.validity")
    anchors = _object(trusted_signature_roots, "trusted signature-verification roots")
    signature = _object(record.get("signature_verification"), "approval.signature_verification")
    signature_id = _string(signature.get("verification_id"), "approval signature verification_id")
    trusted = anchors.get(signature_id)
    if trusted is None:
        raise _DecodeError(f"approval signature verification {signature_id!r} has no independent trust anchor")
    signature_root, signature_checks = _signature_record(
        signature, signature_content=signature_content, trusted_record_root=trusted
    )
    payload_root = content_hash(payload)
    binding = (
        record.get("approval_payload_hash") == payload_root
        and signature.get("signed_content_hash") == payload_root
        and signature.get("verified") is True
    )
    signature_checks.append(("approval_payload_binding", binding, "approval payload hash and trusted signature attestation bind the exact role/action bytes"))
    return content_hash(record), payload, signature_checks


def verify_approval_record(
    record: Mapping[str, Any],
    trusted_signature_roots: Optional[Mapping[str, str]] = None,
    *,
    signature_content: Any = None,
    authority_snapshot: Any = None,
    principal: Any = None,
) -> VerificationResult:
    """Verify a signed approval against an independently anchored attestation."""

    def check() -> Tuple[List[Tuple[str, bool, str]], Dict[str, Any]]:
        if authority_snapshot is None:
            root, payload, checks = _approval(
                record, trusted_signature_roots or {}, signature_content=signature_content
            )
            return checks, {
                "approval_root": root,
                "artifact_hash": payload["artifact_hash"],
                "role": payload["role"],
                "claim_scope": "INTEGRITY_ONLY",
            }
        authority = _authority_snapshot(authority_snapshot)
        signature_record = _object(record.get("signature_verification"), "approval signature verification")
        signature_material = _object(signature_content, "approval signature material")
        anchor = _preflight(signature_record, "approval signature verification")
        _approval(
            record,
            {str(signature_record.get("verification_id")): anchor},
            signature_content=signature_material,
        )
        payload = _object(record.get("payload"), "approval payload")
        crypto_ok, crypto_detail, key = _verify_lifecycle_crypto(
            payload, signature_material, authority
        )
        actor_ok, actor_detail = _authority_actor_permitted(
            authority, "ISSUE_APPROVAL"
        )
        identity_ok, identity_detail = _principal_approval_binding(
            payload, key, authority, principal
        )
        expected_signature = (
            signature_record.get("signature_hash") == _preflight(signature_material, "approval signature")
            and signature_record.get("signed_content_hash") == _preflight(payload, "approval payload")
            and signature_record.get("key_id") == signature_material.get("key_id")
            and signature_record.get("verified") is True
        )
        payload_ok = (
            record.get("approval_payload_hash") == _preflight(payload, "approval payload")
            and payload.get("artifact_hash") is not None
        )
        checks = [
            ("approval_authenticated_actor_permission", actor_ok, actor_detail),
            ("approval_cryptography_replayed", crypto_ok, crypto_detail),
            ("approval_authenticated_principal_binding", identity_ok, identity_detail),
            ("approval_signature_record_binding", expected_signature, "embedded signature evidence binds the exact approval payload and key"),
            ("approval_payload_binding", payload_ok, "approval payload hash independently recomputed"),
        ]
        return checks, {
            "approval_root": _preflight(record, "approval record"),
            "artifact_hash": payload.get("artifact_hash"),
            "role": payload.get("role"),
            "cryptography_replayed": True,
            "trust_context_root": authority["trust_context_root"],
            "principal_binding_root": authority["principal_binding_root"],
            "claim_scope": "AUTHORITY_SNAPSHOT_CRYPTO_REPLAY",
        }

    return _run(record, "ApprovalRecord", VALIDITY_PROFILE, check)


def _withdrawal(
    record: Mapping[str, Any],
    trusted_signature_roots: Mapping[str, str],
    *,
    signature_content: Any = None,
) -> Tuple[str, Mapping[str, Any], List[Tuple[str, bool, str]]]:
    _profile(record, "ApprovalWithdrawal", VALIDITY_PROFILE)
    _keys(record, ("record_type", "profile", "schema_version", "withdrawal_id", "payload", "withdrawal_payload_hash", "signature_verification"), (), "approval withdrawal")
    _string(record.get("withdrawal_id"), "withdrawal.withdrawal_id")
    payload = _object(record.get("payload"), "withdrawal.payload")
    _keys(payload, ("approval_hash", "withdrawn_by", "reason", "occurred_at", "authority"), (), "withdrawal.payload")
    _hash(payload.get("approval_hash"), "withdrawal.payload.approval_hash")
    for field in ("withdrawn_by", "reason", "authority"):
        _string(payload.get(field), f"withdrawal.payload.{field}")
    _time(payload.get("occurred_at"), "withdrawal.payload.occurred_at")
    anchors = _object(trusted_signature_roots, "trusted signature-verification roots")
    signature = _object(record.get("signature_verification"), "withdrawal.signature_verification")
    signature_id = _string(signature.get("verification_id"), "withdrawal signature verification_id")
    trusted = anchors.get(signature_id)
    if trusted is None:
        raise _DecodeError(f"withdrawal signature verification {signature_id!r} has no independent trust anchor")
    signature_root, signature_checks = _signature_record(
        signature, signature_content=signature_content, trusted_record_root=trusted
    )
    payload_root = content_hash(payload)
    binding = (
        record.get("withdrawal_payload_hash") == payload_root
        and signature.get("signed_content_hash") == payload_root
        and signature.get("verified") is True
    )
    signature_checks.append(("withdrawal_payload_binding", binding, "withdrawal payload and trusted signature evidence bind the exact approval root"))
    return content_hash(record), payload, signature_checks


def verify_approval_withdrawal(
    record: Mapping[str, Any],
    trusted_signature_roots: Optional[Mapping[str, str]] = None,
    *,
    signature_content: Any = None,
    authority_snapshot: Any = None,
    principal: Any = None,
    approval: Any = None,
) -> VerificationResult:
    """Verify a separate immutable approval-withdrawal record."""

    def check() -> Tuple[List[Tuple[str, bool, str]], Dict[str, Any]]:
        if authority_snapshot is None:
            root, payload, checks = _withdrawal(
                record, trusted_signature_roots or {}, signature_content=signature_content
            )
            return checks, {"withdrawal_root": root, "approval_hash": payload["approval_hash"], "claim_scope": "INTEGRITY_ONLY"}
        authority = _authority_snapshot(authority_snapshot)
        signature_record = _object(record.get("signature_verification"), "withdrawal signature verification")
        signature_material = _object(signature_content, "withdrawal signature material")
        anchor = _preflight(signature_record, "withdrawal signature verification")
        _withdrawal(
            record,
            {str(signature_record.get("verification_id")): anchor},
            signature_content=signature_material,
        )
        payload = _object(record.get("payload"), "withdrawal payload")
        crypto_ok, crypto_detail, key = _verify_lifecycle_crypto(payload, signature_material, authority)
        actor_ok, actor_detail = _authority_actor_permitted(
            authority, "ISSUE_APPROVAL_WITHDRAWAL"
        )
        identity_ok, identity_detail = _principal_approval_binding(payload, key, authority, principal)
        approval_doc = _object(approval, "withdrawn approval")
        approval_payload = _object(approval_doc.get("payload"), "withdrawn approval payload")
        target_ok = (
            payload.get("approval_hash") == _preflight(approval_doc, "withdrawn approval")
            and payload.get("withdrawn_by") == approval_payload.get("subject_id")
        )
        signature_ok = (
            signature_record.get("signature_hash") == _preflight(signature_material, "withdrawal signature")
            and signature_record.get("signed_content_hash") == _preflight(payload, "withdrawal payload")
            and signature_record.get("key_id") == signature_material.get("key_id")
            and signature_record.get("verified") is True
            and record.get("withdrawal_payload_hash") == _preflight(payload, "withdrawal payload")
        )
        checks = [
            ("withdrawal_authenticated_actor_permission", actor_ok, actor_detail),
            ("withdrawal_cryptography_replayed", crypto_ok, crypto_detail),
            ("withdrawal_authenticated_principal_binding", identity_ok, identity_detail),
            ("withdrawal_target_binding", target_ok, "withdrawal actor and exact approval root independently bound"),
            ("withdrawal_signature_record_binding", signature_ok, "embedded signature evidence binds the exact withdrawal payload and key"),
        ]
        return checks, {
            "withdrawal_root": _preflight(record, "approval withdrawal"),
            "approval_hash": payload.get("approval_hash"),
            "cryptography_replayed": True,
            "trust_context_root": authority["trust_context_root"],
            "claim_scope": "AUTHORITY_SNAPSHOT_CRYPTO_REPLAY",
        }

    return _run(record, "ApprovalWithdrawal", VALIDITY_PROFILE, check)


def _clock(value: Any, where: str) -> Tuple[Mapping[str, Any], Optional[_dt.datetime]]:
    item = _object(value, where)
    _keys(item, ("verifier_evaluation_time", "verifier_clock_source", "verifier_clock_trust_level"), (), where)
    source = _string(item.get("verifier_clock_source"), f"{where}.verifier_clock_source")
    del source
    trust = item.get("verifier_clock_trust_level")
    if trust not in {"NONE_SUPPLIED", "LOCAL_DECLARED", "SYNCHRONIZED", "ATTESTED"}:
        raise _DecodeError(f"{where} has unknown clock trust {trust!r}")
    instant = _time(item.get("verifier_evaluation_time"), f"{where}.verifier_evaluation_time", optional=True)
    if instant is None and trust != "NONE_SUPPLIED":
        raise _DecodeError(f"{where} declares clock trust without an evaluation time")
    return item, instant


def _time_status(validity: Mapping[str, Any], clock: Mapping[str, Any]) -> str:
    _, now = _clock(clock, "authorization clock")
    if now is None:
        return "TIME_INDETERMINATE"
    def issuer_time(field: str) -> Optional[_dt.datetime]:
        value = validity.get(field)
        if value is None:
            return None
        try:
            return _time(value, f"approval validity.{field}")
        except _DecodeError:
            return None

    start = issuer_time("not_before")
    end = issuer_time("expires_at")
    issued = issuer_time("issued_at")
    if validity.get("expires_at") is not None and end is None:
        return "CLOCK_POLICY_VIOLATION"
    if validity.get("not_before") is not None and start is None:
        return "CLOCK_POLICY_VIOLATION"
    if start is not None and now < start:
        return "NOT_YET_VALID"
    if end is not None and now > end:
        return "EXPIRED"
    maximum = validity.get("max_age_seconds")
    if maximum is not None:
        maximum = _integer(maximum, "approval validity.max_age_seconds", minimum=0)
        if issued is None:
            return "CLOCK_POLICY_VIOLATION"
        if (now - issued).total_seconds() > maximum:
            return "STALE"
    if end is None and maximum is None:
        return "TIME_INDETERMINATE"
    return "CURRENT"


def _policy(value: Any) -> Tuple[Mapping[str, Any], Tuple[str, ...], Tuple[Tuple[str, str], ...], bool]:
    policy = _object(value, "separation-of-duties policy")
    _keys(policy, ("policy_id", "required_roles", "incompatible_role_pairs", "distinct_subjects_for_required_roles", "authority"), (), "separation-of-duties policy")
    _string(policy.get("policy_id"), "policy.policy_id")
    _string(policy.get("authority"), "policy.authority")
    roles = _strings(policy.get("required_roles"), "policy.required_roles", sorted_unique=True, nonempty=True)
    pairs = []
    for index, raw in enumerate(_array(policy.get("incompatible_role_pairs"), "policy.incompatible_role_pairs")):
        pair = _array(raw, f"policy.incompatible_role_pairs[{index}]")
        if len(pair) != 2:
            raise _DecodeError("an incompatible role pair must contain two roles")
        normalized = tuple(sorted((_string(pair[0], "incompatible role"), _string(pair[1], "incompatible role"))))
        if normalized[0] == normalized[1] or list(normalized) != list(pair):
            raise _DecodeError("incompatible role pairs must be distinct and canonically sorted")
        pairs.append(normalized)
    if len(set(pairs)) != len(pairs) or pairs != sorted(pairs):
        raise _DecodeError("incompatible role pairs repeat or are not canonically sorted")
    distinct = _boolean(policy.get("distinct_subjects_for_required_roles"), "policy.distinct_subjects_for_required_roles")
    return policy, roles, tuple(pairs), distinct


def _has_distinct_required_role_assignment(
    required_roles: Sequence[str], active: Sequence[Mapping[str, Any]]
) -> bool:
    candidates = {
        role: tuple(sorted({
            str(payload["subject_id"])
            for payload in active
            if payload.get("role") == role
        }))
        for role in required_roles
    }
    ordered = sorted(required_roles, key=lambda role: (len(candidates[role]), role))

    def assign(index: int, used: Set[str]) -> bool:
        if index == len(ordered):
            return True
        role = ordered[index]
        return any(
            subject not in used and assign(index + 1, used | {subject})
            for subject in candidates[role]
        )

    return assign(0, set())


def verify_lifecycle_authorization(
    record: Mapping[str, Any],
    approvals: Sequence[Mapping[str, Any]],
    withdrawals: Sequence[Mapping[str, Any]],
    policy: Mapping[str, Any],
    clock: Mapping[str, Any],
    trusted_signature_roots: Optional[Mapping[str, str]] = None,
    *,
    authority_snapshot: Any = None,
    approval_signature_inputs: Optional[Mapping[str, Any]] = None,
    withdrawal_signature_inputs: Optional[Mapping[str, Any]] = None,
) -> VerificationResult:
    """Replay approval binding, time, withdrawal, role, and SoD decisions."""

    def check() -> Tuple[List[Tuple[str, bool, str]], Dict[str, Any]]:
        _keys(
            record,
            ("record_type", "profile", "schema_version", "artifact_hash", "action", "policy_id", "authorized",
             "accepted_approval_hashes", "rejected_approvals", "withdrawal_hashes", "missing_roles",
             "separation_failures", "clock"),
            (),
            "lifecycle authorization",
        )
        artifact_hash = _hash(record.get("artifact_hash"), "authorization.artifact_hash")
        action = _string(record.get("action"), "authorization.action")
        authority = None
        authority_checks: List[Tuple[str, bool, str]] = []
        roots = trusted_signature_roots or {}
        if authority_snapshot is not None:
            authority = _authority_snapshot(authority_snapshot)
            selected_policy = _selected_policy(authority, action)
            policy_matches = dict(policy) == dict(selected_policy)
            clock_matches = dict(clock) == dict(authority["clock"])
            actor_ok, actor_detail = _authority_actor_permitted(
                authority, "EVALUATE_LIFECYCLE_AUTHORIZATION"
            )
            authority_checks.extend([
                ("authorization_deployment_policy", policy_matches, "policy and policy identity are selected from the versioned deployment context"),
                ("authorization_deployment_clock", clock_matches, "clock and clock policy are supplied by the deployment"),
                ("authorization_authenticated_actor", actor_ok, actor_detail),
            ])
            # The legacy root map is forbidden on the authority path.  Each
            # signature is independently replayed below instead.
            if roots:
                raise _DecodeError("caller-supplied trusted_signature_roots are forbidden for authority replay")
        policy_doc, required_roles, incompatible_pairs, distinct = _policy(policy)
        clock_doc, _ = _clock(clock, "authorization clock")
        approval_facts = []
        approval_ids: Set[str] = set()
        approval_roots: Set[str] = set()
        nested_checks: List[Tuple[str, bool, str]] = []
        for raw in approvals:
            approval = _object(raw, "approval")
            identifier = _string(approval.get("approval_id"), "approval.approval_id")
            if authority is None:
                root, payload, checks = _approval(approval, roots)
            else:
                material_by_id = _object(
                    approval_signature_inputs or {}, "approval signature inputs"
                )
                material = _object(
                    material_by_id.get(identifier),
                    f"approval signature inputs[{identifier!r}]",
                )
                _keys(
                    material,
                    ("signature_content", "principal", "authority_snapshot"),
                    (),
                    "approval signature inputs",
                )
                approval_authority = _authority_snapshot(
                    material["authority_snapshot"]
                )
                authority_chain_ok = (
                    approval_authority["trust_context_root"]
                    == authority["trust_context_root"]
                    and approval_authority["policy_roots"]
                    == authority["policy_roots"]
                    and approval_authority["principal"] == material["principal"]
                )
                nested = verify_approval_record(
                    approval,
                    signature_content=material["signature_content"],
                    authority_snapshot=approval_authority,
                    principal=material["principal"],
                )
                checks = [
                    (f"approval_{name}", passed, detail)
                    for name, passed, detail in nested.checks
                    if name != "lifecycle_profile"
                ]
                checks.append((
                    "approval_authority_replay_result",
                    nested.ok,
                    "approval passes its complete independent authority replay",
                ))
                checks.append((
                    "approval_deployment_authority_chain",
                    authority_chain_ok,
                    "approval actor snapshot is principal-bound to the same deployment trust and policy roots",
                ))
                root = _preflight(approval, "approval")
                payload = _object(approval.get("payload"), "approval payload")
            if identifier in approval_ids or root in approval_roots:
                raise _DecodeError("authorization repeats an approval identity or record")
            approval_ids.add(identifier)
            approval_roots.add(root)
            nested_checks.extend(checks)
            approval_facts.append((root, payload))
        withdrawal_by_approval: Dict[str, Tuple[str, Mapping[str, Any]]] = {}
        withdrawal_roots = []
        for raw in withdrawals:
            withdrawal = _object(raw, "approval withdrawal")
            withdrawal_id = _string(withdrawal.get("withdrawal_id"), "withdrawal.withdrawal_id")
            if authority is None:
                root, payload, checks = _withdrawal(withdrawal, roots)
            else:
                material_by_id = _object(
                    withdrawal_signature_inputs or {}, "withdrawal signature inputs"
                )
                material = _object(
                    material_by_id.get(withdrawal_id),
                    f"withdrawal signature inputs[{withdrawal_id!r}]",
                )
                _keys(
                    material,
                    (
                        "signature_content", "principal", "approval",
                        "authority_snapshot",
                    ),
                    (),
                    "withdrawal signature inputs",
                )
                withdrawal_authority = _authority_snapshot(
                    material["authority_snapshot"]
                )
                authority_chain_ok = (
                    withdrawal_authority["trust_context_root"]
                    == authority["trust_context_root"]
                    and withdrawal_authority["policy_roots"]
                    == authority["policy_roots"]
                    and withdrawal_authority["principal"] == material["principal"]
                )
                nested = verify_approval_withdrawal(
                    withdrawal,
                    signature_content=material["signature_content"],
                    authority_snapshot=withdrawal_authority,
                    principal=material["principal"],
                    approval=material["approval"],
                )
                checks = [
                    (f"withdrawal_{name}", passed, detail)
                    for name, passed, detail in nested.checks
                    if name != "lifecycle_profile"
                ]
                checks.append((
                    "withdrawal_authority_replay_result",
                    nested.ok,
                    "withdrawal passes its complete independent authority replay",
                ))
                checks.append((
                    "withdrawal_deployment_authority_chain",
                    authority_chain_ok,
                    "withdrawal actor snapshot is principal-bound to the same deployment trust and policy roots",
                ))
                root = _preflight(withdrawal, "approval withdrawal")
                payload = _object(withdrawal.get("payload"), "withdrawal payload")
            target = payload["approval_hash"]
            if target in withdrawal_by_approval:
                raise _DecodeError("multiple withdrawals target the same approval")
            withdrawal_by_approval[target] = (root, payload)
            withdrawal_roots.append(root)
            nested_checks.extend(checks)

        accepted: List[str] = []
        rejected: List[Tuple[str, str]] = []
        active: List[Mapping[str, Any]] = []
        for root, payload in approval_facts:
            reason = None
            if payload.get("artifact_hash") != artifact_hash:
                reason = "ARTIFACT_HASH_MISMATCH"
            elif payload.get("action") != action:
                reason = "ACTION_MISMATCH"
            elif root in withdrawal_by_approval:
                reason = "APPROVAL_WITHDRAWN"
            else:
                status = _time_status(_validity(payload.get("validity"), "approval validity"), clock_doc)
                if status != "CURRENT":
                    reason = f"APPROVAL_TIME_{status}"
            if reason:
                rejected.append((root, reason))
            else:
                accepted.append(root)
                active.append(payload)
        present_roles = {payload["role"] for payload in active}
        missing = sorted(set(required_roles) - present_roles)
        failures: List[str] = []
        by_subject: Dict[str, Set[str]] = {}
        for payload in active:
            by_subject.setdefault(payload["subject_id"], set()).add(payload["role"])
        if distinct:
            if not _has_distinct_required_role_assignment(required_roles, active):
                failures.append("required roles are not held by distinct subjects")
        for subject, roles in sorted(by_subject.items()):
            for left, right in incompatible_pairs:
                if {left, right}.issubset(roles):
                    failures.append(f"subject {subject!r} holds incompatible roles {left!r}, {right!r}")
        rejected.sort()
        authorized = not rejected and not missing and not failures
        expected = {
            "policy_id": policy_doc["policy_id"],
            "authorized": authorized,
            "accepted_approval_hashes": sorted(accepted),
            "rejected_approvals": [{"approval_hash": root, "reason": reason} for root, reason in rejected],
            "withdrawal_hashes": sorted(withdrawal_roots),
            "missing_roles": missing,
            "separation_failures": failures,
            "clock": dict(clock_doc),
        }
        actual = {key: record.get(key) for key in expected}
        nested_ok = all(passed for _, passed, _ in nested_checks)
        return [
            *authority_checks,
            ("authorization_signature_evidence", nested_ok, "all approval and withdrawal signature attestations are independently anchored"),
            ("authorization_derivation", actual == expected, "artifact/action, withdrawal, expiry, roles, and separation of duties independently replayed"),
        ], {
            "derived_authorized": authorized,
            "accepted_count": len(accepted),
            "rejected_count": len(rejected),
            "cryptography_replayed": authority is not None,
            "trust_context_root": authority.get("trust_context_root") if authority else None,
            "policy_root": (
                authority["policy_roots"].get(policy_doc["policy_id"])
                if authority else None
            ),
            "clock_root": authority.get("clock_root") if authority else None,
            "claim_scope": (
                "AUTHORITY_SNAPSHOT_CRYPTO_REPLAY" if authority else "INTEGRITY_ONLY"
            ),
        }

    return _run(record, "LifecycleAuthorization", VALIDITY_PROFILE, check)


def _validity_source(value: Any) -> Mapping[str, Any]:
    """Validate the closed canonical evidence set consumed by all ten checkers."""

    source = _object(value, "continued-validity canonical source")
    _keys(
        source,
        (
            "profile", "schema_version", "case", "case_root", "artifact",
            "artifact_root", "artifact_status", "evidence_statuses",
            "dependency_edges", "dependency_statuses", "audit_events", "audit_root",
            "authorization_record", "authorization_inputs", "migration_records",
            "authority_snapshot",
        ),
        (),
        "continued-validity canonical source",
    )
    if source.get("profile") != "crg.continued-validity-source":
        raise _UnsupportedProfileError(
            f"unsupported continued-validity source profile {source.get('profile')!r}"
        )
    if source.get("schema_version") != "1.0.0":
        raise _UnsupportedProfileError(
            f"unsupported continued-validity source schema {source.get('schema_version')!r}"
        )
    case = _object(source.get("case"), "continued-validity case")
    artifact = _object(source.get("artifact"), "continued-validity artifact")
    if source.get("case_root") != _preflight(case, "continued-validity case"):
        raise _DecodeError("continued-validity case_root does not match canonical case bytes")
    if source.get("artifact_root") != _preflight(artifact, "continued-validity artifact"):
        raise _DecodeError("continued-validity artifact_root does not match canonical artifact bytes")
    _string(source.get("artifact_status"), "continued-validity artifact_status")
    evidence_statuses = _object(
        source.get("evidence_statuses"), "continued-validity evidence statuses"
    )
    for root, status in evidence_statuses.items():
        _hash(root, "continued-validity evidence root")
        _string(status, "continued-validity evidence status")
    dependency_statuses = _object(
        source.get("dependency_statuses"),
        "continued-validity dependency statuses",
    )
    for dependency_id, status in dependency_statuses.items():
        # Certificate dependencies are governed object/realization identities;
        # they are not restricted to content hashes.
        _string(dependency_id, "continued-validity dependency identity")
        _string(status, "continued-validity dependency status")
    _array(source.get("dependency_edges"), "continued-validity dependency edges")
    audit = _array(source.get("audit_events"), "continued-validity audit events")
    if source.get("audit_root") != _preflight(audit, "continued-validity audit events"):
        raise _DecodeError("continued-validity audit_root does not match canonical audit events")
    _array(source.get("migration_records"), "continued-validity migration records")
    _authority_snapshot(source.get("authority_snapshot"))
    if (source.get("authorization_record") is None) != (
        source.get("authorization_inputs") is None
    ):
        raise _DecodeError("authorization record and replay inputs must appear together")
    return source


def _dimension_source_root(name: str, source: Mapping[str, Any]) -> str:
    return _preflight(
        {"dimension": name, "canonical_validity_source": source},
        f"continued-validity {name} source",
    )


def _artifact_expiry(source: Mapping[str, Any]) -> Optional[_dt.datetime]:
    artifact = source["artifact"]
    value = artifact.get("expiry")
    if value is None and isinstance(artifact.get("validity"), Mapping):
        value = artifact["validity"].get("expires_at")
    return _time(value, "continued-validity artifact expiry", optional=True)


def _authority_now(source: Mapping[str, Any]) -> _dt.datetime:
    authority = _authority_snapshot(source["authority_snapshot"])
    _clock_doc, instant = _clock(authority["clock"], "continued-validity authority clock")
    if instant is None:
        raise _DecodeError("continued-validity authority clock is absent")
    return instant


def _derive_evidence_validity(source: Mapping[str, Any]) -> Tuple[str, str]:
    artifact = source["artifact"]
    roots = artifact.get("evidence_roots")
    if roots is None:
        return "INDETERMINATE", "artifact omits an explicit evidence-root inventory"
    # Existing certificates may bind the same root in more than one evidence
    # role.  Preserve that exact inventory while looking up its direct status;
    # duplicate role bindings are not missing evidence.
    roots = tuple(
        _hash(item, "artifact evidence_roots[]")
        for item in _array(roots, "artifact evidence_roots")
    )
    statuses = source["evidence_statuses"]
    missing = [root for root in roots if root not in statuses]
    if missing:
        return "UNAVAILABLE", f"evidence status is unavailable for {missing}"
    values = {statuses[root] for root in roots}
    if "REVOKED" in values:
        return "REVOKED", "at least one bound evidence object is revoked"
    if values.intersection({"REDACTED", "UNVERIFIABLE_REDACTED"}):
        return "REDACTED", "at least one bound evidence object is redacted"
    if values - {"ACTIVE"}:
        return "INDETERMINATE", f"evidence has non-current statuses {sorted(values - {'ACTIVE'})}"
    expiry = _artifact_expiry(source)
    if expiry is None:
        return "INDETERMINATE", "artifact has no verifier-evaluable expiry assertion"
    if _authority_now(source) > expiry:
        return "EXPIRED", "artifact expiry precedes the deployment verifier clock"
    return "CURRENT", f"all {len(roots)} explicit evidence roots are active and the artifact is unexpired"


def _derive_verifier_time(source: Mapping[str, Any]) -> Tuple[str, str]:
    authority = _authority_snapshot(source["authority_snapshot"])
    trust = authority["clock"].get("verifier_clock_trust_level")
    if trust not in {"SYNCHRONIZED", "ATTESTED"}:
        return "TIME_INDETERMINATE", "deployment clock is not synchronized or attested"
    expiry = _artifact_expiry(source)
    if expiry is None:
        return "TIME_INDETERMINATE", "artifact has no expiry for the verifier clock to judge"
    if _authority_now(source) > expiry:
        return "EXPIRED", "artifact is expired at the deployment verifier clock"
    return "CURRENT", "deployment-approved verifier clock places the artifact inside validity"


def _derive_dependency_status(source: Mapping[str, Any]) -> Tuple[str, str]:
    roots = source["artifact"].get("dependencies")
    if roots is None:
        return "INDETERMINATE", "artifact omits an explicit dependency inventory"
    roots = _strings(roots, "artifact dependencies")
    statuses = source["dependency_statuses"]
    missing = [root for root in roots if root not in statuses]
    if missing:
        return "INDETERMINATE", f"dependency status is absent for {missing}"
    values = {statuses[root] for root in roots}
    if values.intersection({"REVOKED", "REDACTED", "UNVERIFIABLE_REDACTED", "BLOCKED"}):
        return "BLOCKED", "a bound dependency is revoked, redacted, unavailable, or blocked"
    if values.intersection({"STALE", "SUPERSEDED"}):
        return "STALE", "a bound dependency is stale or superseded"
    if values - {"ACTIVE"}:
        return "INDETERMINATE", f"dependencies have unknown statuses {sorted(values - {'ACTIVE'})}"
    return "CURRENT", f"all {len(roots)} explicitly bound dependencies are active"


def _derive_change_events(source: Mapping[str, Any]) -> Tuple[str, str]:
    case = source["case"]
    if case.get("deltas") is None or case.get("history") is None:
        return "BLOCKED", "canonical case omits delta or history evidence"
    history_changed = bool(case.get("deltas")) or any(
        isinstance(item, Mapping)
        and str(item.get("operation") or "") in {
            "change", "merge", "migrate", "redact", "classify-change",
        }
        for item in case.get("history") or ()
    )
    audit_events = source.get("audit_events")
    if not isinstance(audit_events, (list, tuple)):
        return "BLOCKED", "canonical audit evidence is unavailable"
    audit_changed = any(
        isinstance(item, Mapping)
        and str(item.get("event") or "") in {
            "case.merged", "case.migrated", "case.redacted", "case.reopened",
            "change.classified", "certificate.stale", "evidence.expired",
            "evidence.retired", "object.redacted", "object.revoked",
        }
        for item in audit_events
    )
    if history_changed or audit_changed:
        return "REVALIDATION_REQUIRED", "canonical delta/history or audit evidence records a decision-relevant change"
    return "NONE", "canonical delta/history and audit evidence contain no decision-relevant change"


def _derive_revocation(source: Mapping[str, Any]) -> Tuple[str, str]:
    status = source["artifact_status"]
    if status == "REVOKED":
        return "REVOKED", "artifact object status is REVOKED"
    if status in {"ACTIVE", "STALE", "SUPERSEDED", "REDACTED", "UNVERIFIABLE_REDACTED"}:
        return "NOT_REVOKED", f"artifact status {status} is not revocation"
    return "UNKNOWN", f"revocation cannot be derived from status {status!r}"


def _derive_redaction(source: Mapping[str, Any]) -> Tuple[str, str]:
    status = source["artifact_status"]
    if status == "REDACTED":
        return "REDACTED", "artifact object status is REDACTED"
    if status == "UNVERIFIABLE_REDACTED":
        return "UNVERIFIABLE_REDACTED", "artifact support is redacted without sufficient proof"
    if status in {"ACTIVE", "STALE", "SUPERSEDED", "REVOKED"}:
        return "AVAILABLE", f"artifact bytes remain available with status {status}"
    return "UNKNOWN", f"availability cannot be derived from status {status!r}"


def _derive_migration(source: Mapping[str, Any]) -> Tuple[str, str]:
    related = [
        item for item in source["migration_records"]
        if isinstance(item, Mapping)
        and source["artifact_root"] in {
            item.get("source_object_hash"), item.get("transformed_object_hash"),
            item.get("lifecycle_record_hash"),
        }
    ]
    if not related:
        return "ORIGINAL", "canonical migration inventory contains no related migration"
    latest = related[-1]
    if (
        latest.get("migration_class") == "SEMANTICALLY_EQUIVALENT"
        and latest.get("disposition") == "UNCHANGED_LIFECYCLE_REVERIFIED"
        and latest.get("substantive_artifact_reissued") is False
    ):
        return "SEMANTICALLY_EQUIVALENT_VERIFIED", "registered equivalent migration and lifecycle replay are present"
    if latest.get("migration_class") in {"LOSSY", "SEMANTICALLY_DIFFERENT"}:
        return "LOSSY", "latest related migration is lossy or semantically different"
    return "UNVERIFIED", "related migration lacks registered equivalence and independent replay"


def _derive_branch_state(source: Mapping[str, Any]) -> Tuple[str, str]:
    case = source["case"]
    branch = case.get("branch_id")
    if not isinstance(branch, str) or not branch:
        return "UNKNOWN", "canonical case omits branch identity"
    unresolved = any(
        isinstance(item, Mapping) and item.get("automatic") is False
        for item in case.get("merge_decisions") or ()
    )
    if unresolved:
        return "MERGE_RECONCILIATION_REQUIRED", "canonical merge record has unresolved semantic conflict"
    if branch == "main" and not (case.get("parent_case_refs") or []):
        return "LINEAR_CURRENT", "case is the current linear main branch"
    return "BRANCHED_CURRENT", f"case is on explicit branch {branch!r} without unresolved conflict"


def _derive_supersession(source: Mapping[str, Any]) -> Tuple[str, str]:
    status = source["artifact_status"]
    if status == "SUPERSEDED":
        return "SUPERSEDED", "artifact object status is SUPERSEDED"
    if status in {"ACTIVE", "STALE", "REVOKED", "REDACTED", "UNVERIFIABLE_REDACTED"}:
        return "CURRENT", f"artifact has not been marked superseded (status {status})"
    return "UNKNOWN", f"supersession cannot be derived from status {status!r}"


def _derive_approvals(source: Mapping[str, Any]) -> Tuple[str, str]:
    record, envelope = source.get("authorization_record"), source.get("authorization_inputs")
    if record is None or envelope is None:
        return "INDETERMINATE", "no deployment-authority-bound lifecycle authorization is present"
    if not isinstance(record, Mapping) or not isinstance(envelope, Mapping):
        return "INDETERMINATE", "lifecycle authorization evidence is malformed"
    if envelope.get("record_hash") != _preflight(record, "continued-validity authorization"):
        return "SIGNATURE_UNVERIFIED", "authorization envelope is bound to different bytes"
    if envelope.get("verifier_operation") != "verify_lifecycle_authorization_v2":
        return "SIGNATURE_UNVERIFIED", "authorization was not produced by authority replay v2"
    inputs = envelope.get("inputs")
    expected = {
        "approvals", "withdrawals", "policy", "clock", "artifact",
        "authority_snapshot", "approval_signature_inputs", "withdrawal_signature_inputs",
    }
    if not isinstance(inputs, Mapping) or set(inputs) != expected:
        return "SIGNATURE_UNVERIFIED", "authorization replay inputs are not the closed v2 contract"
    if inputs.get("authority_snapshot") != source.get("authority_snapshot"):
        return "SIGNATURE_UNVERIFIED", "authorization uses another deployment authority snapshot"
    verification = verify_lifecycle_authorization(
        record, inputs["approvals"], inputs["withdrawals"], inputs["policy"], inputs["clock"],
        authority_snapshot=inputs["authority_snapshot"],
        approval_signature_inputs=inputs["approval_signature_inputs"],
        withdrawal_signature_inputs=inputs["withdrawal_signature_inputs"],
    )
    if not verification.ok:
        return "SIGNATURE_UNVERIFIED", "authorization fails independent cryptographic replay"
    if record.get("artifact_hash") != source.get("artifact_root"):
        return "MISSING", "authorization applies to a different artifact root"
    if record.get("authorized") is not True:
        reasons = list(record.get("rejected_approvals") or ())
        if any("EXPIRED" in str(item) for item in reasons):
            return "EXPIRED", "a required approval is expired"
        if any("WITHDRAWN" in str(item) for item in reasons):
            return "WITHDRAWN", "a required approval is withdrawn"
        if record.get("separation_failures"):
            return "SEPARATION_OF_DUTIES_FAILED", "authorization fails separation of duties"
        return "MISSING", "authorization lacks required active approvals"
    return "CURRENT", "deployment policy, authenticated principals, and cryptographic approvals authorize this artifact"


_VALIDITY_CHECKERS = {
    "EVIDENCE_VALIDITY": _derive_evidence_validity,
    "VERIFIER_TIME": _derive_verifier_time,
    "DEPENDENCY_STATUS": _derive_dependency_status,
    "CHANGE_EVENTS": _derive_change_events,
    "REVOCATION": _derive_revocation,
    "REDACTION": _derive_redaction,
    "MIGRATION": _derive_migration,
    "BRANCH_STATE": _derive_branch_state,
    "SUPERSESSION": _derive_supersession,
    "APPROVALS": _derive_approvals,
}


def derive_continued_validity_dimensions(value: Any) -> List[Dict[str, Any]]:
    """Run the closed first-party checker registry over canonical evidence."""

    source = _validity_source(value)
    if set(_VALIDITY_CHECKERS) != set(_DIMENSIONS):
        raise _UnsupportedProfileError(
            "continued-validity checker registry does not exactly cover all dimensions"
        )
    result = []
    for name in _DIMENSIONS:
        state, detail = _VALIDITY_CHECKERS[name](source)
        if state not in _DIMENSION_STATES[name]:
            raise _DecodeError(f"checker {name} produced unsupported state {state!r}")
        result.append({
            "name": name,
            "state": state,
            "source_hash": _dimension_source_root(name, source),
            "detail": detail,
        })
    return result


def verify_continued_validity_view(
    record: Mapping[str, Any],
    artifact: Any,
    dimension_sources: Mapping[str, Any],
    trigger_sources: Mapping[str, Any],
    dependencies: Sequence[Any],
    *,
    validity_source: Any = None,
) -> VerificationResult:
    """Verify all ten direct validity dimensions and reject synthetic scores."""

    def check() -> Tuple[List[Tuple[str, bool, str]], Dict[str, Any]]:
        _keys(
            record,
            ("record_type", "profile", "schema_version", "view_id", "case_id", "artifact_id", "artifact_hash",
             "evaluated_at", "verifier_clock", "status", "dimensions", "blocking_dimensions",
             "reopen_triggers", "dependency_hashes", "claim_boundary"),
            (),
            "continued validity view",
        )
        for field in ("view_id", "case_id", "artifact_id"):
            _string(record.get(field), f"continued validity.{field}")
        _time(record.get("evaluated_at"), "continued validity.evaluated_at")
        clock_doc, _ = _clock(record.get("verifier_clock"), "continued validity.verifier_clock")
        if clock_doc.get("verifier_evaluation_time") != record.get("evaluated_at"):
            raise _DecodeError("displayed evaluation time differs from the supplied verifier clock")
        artifact_root = _preflight(artifact, "continued-validity artifact")
        dimensions = _array(record.get("dimensions"), "continued validity.dimensions")
        if len(dimensions) != len(_DIMENSIONS):
            raise _DecodeError("continued-validity view must contain exactly ten dimensions")
        names: List[str] = []
        states: Dict[str, str] = {}
        sources_ok = True
        for index, raw in enumerate(dimensions):
            dimension = _object(raw, f"continued validity.dimensions[{index}]")
            _keys(dimension, ("name", "state", "source_hash", "detail"), (), f"continued validity.dimensions[{index}]")
            name = _string(dimension.get("name"), "dimension.name")
            state = _string(dimension.get("state"), "dimension.state")
            _string(dimension.get("detail"), "dimension.detail")
            if name not in _DIMENSION_STATES or state not in _DIMENSION_STATES[name]:
                raise _DecodeError(f"state {state!r} is not valid for dimension {name!r}")
            if name not in dimension_sources:
                raise _DecodeError(f"dimension {name!r} has no portable source evidence")
            sources_ok = sources_ok and dimension.get("source_hash") == _preflight(dimension_sources[name], f"dimension source {name}")
            names.append(name)
            states[name] = state
        if names != sorted(_DIMENSIONS) or set(names) != set(_DIMENSIONS):
            raise _DecodeError("continued-validity dimensions are incomplete, repeated, or not canonically sorted")
        noncurrent = {state for name, state in states.items() if state not in _CURRENT_STATES[name]}
        blocking = noncurrent - _INDETERMINATE_STATES - _REOPEN_STATES
        if not noncurrent:
            status = "CURRENT"
        elif blocking:
            status = "BLOCKED"
        elif noncurrent.intersection(_INDETERMINATE_STATES):
            status = "INDETERMINATE"
        elif noncurrent.intersection(_REOPEN_STATES):
            status = "REOPEN_REQUIRED"
        else:
            status = "BLOCKED"
        blocking_dimensions = sorted(name for name, state in states.items() if state not in _CURRENT_STATES[name])
        trigger_ids: Set[str] = set()
        trigger_sources_ok = True
        for index, raw in enumerate(_array(record.get("reopen_triggers"), "continued validity.reopen_triggers")):
            trigger = _object(raw, f"continued validity.reopen_triggers[{index}]")
            _keys(trigger, ("trigger_id", "condition", "source_hash", "action"), (), f"continued validity.reopen_triggers[{index}]")
            trigger_id = _string(trigger.get("trigger_id"), "reopen trigger.trigger_id")
            _string(trigger.get("condition"), "reopen trigger.condition")
            if trigger_id in trigger_ids:
                raise _DecodeError("continued-validity view repeats a reopen trigger")
            trigger_ids.add(trigger_id)
            if trigger.get("action") not in set(_ACTION_SEVERITY) - {"NO_OPERATION"}:
                raise _DecodeError(f"unknown or inert reopen trigger action {trigger.get('action')!r}")
            if trigger_id not in trigger_sources:
                raise _DecodeError(f"reopen trigger {trigger_id!r} has no portable source evidence")
            trigger_sources_ok = trigger_sources_ok and trigger.get("source_hash") == _preflight(trigger_sources[trigger_id], f"reopen trigger source {trigger_id}")
        dependency_roots = [_preflight(item, "continued-validity dependency") for item in dependencies]
        if len(set(dependency_roots)) != len(dependency_roots):
            raise _DecodeError("continued-validity dependencies repeat")
        boundary = "direct lifecycle states only; no confidence, health, readiness, or other synthetic score"
        direct = (
            record.get("artifact_hash") == artifact_root
            and sources_ok
            and trigger_sources_ok
            and record.get("dependency_hashes") == dependency_roots
        )
        derived = record.get("status") == status and record.get("blocking_dimensions") == blocking_dimensions
        checks = [
            ("continued_validity_sources", direct, "artifact, ten dimension sources, reopen triggers, and dependencies independently content-addressed"),
            ("continued_validity_derivation", derived, "status and blocking dimensions rederived from all ten direct states"),
            ("continued_validity_no_synthetic_score", record.get("claim_boundary") == boundary and not ({"score", "confidence", "readiness", "health"} & set(record)), "no synthetic summary score is admitted"),
        ]
        report = {
            "derived_status": status,
            "blocking_dimensions": blocking_dimensions,
            "dimension_count": len(dimensions),
        }
        if validity_source is None:
            # Old records remain structurally replayable, but their
            # caller-declared states cannot substantiate CURRENT.
            checks.append((
                "continued_validity_registered_checkers",
                status != "CURRENT",
                "legacy caller declarations are non-authorizing and cannot derive CURRENT",
            ))
            report["claim_scope"] = "LEGACY_DECLARATION_ONLY"
        else:
            source = _validity_source(validity_source)
            expected_dimensions = sorted(
                derive_continued_validity_dimensions(source), key=lambda item: item["name"]
            )
            exact = [
                (
                    item.get("name"), item.get("state"),
                    item.get("source_hash"), item.get("detail"),
                )
                for item in dimensions
            ] == [
                (item["name"], item["state"], item["source_hash"], item["detail"])
                for item in expected_dimensions
            ]
            source_artifact = (
                source.get("artifact") == artifact
                and source.get("artifact_root") == artifact_root
            )
            authority = _authority_snapshot(source["authority_snapshot"])
            actor_ok, actor_detail = _authority_actor_permitted(
                authority, "BUILD_CONTINUED_VALIDITY"
            )
            checks.extend([
                ("continued_validity_registered_checkers", exact, "all ten states, explanations, and roots are independently derived by registered per-dimension checkers"),
                ("continued_validity_canonical_source", source_artifact, "canonical case/certificate/audit/dependency/approval/migration/clock evidence binds the exact artifact"),
                ("continued_validity_deployment_authority", actor_ok, actor_detail),
            ])
            report.update({
                "registered_checker_count": len(_VALIDITY_CHECKERS),
                "trust_context_root": authority["trust_context_root"],
                "clock_root": authority["clock_root"],
                "case_root": source["case_root"],
                "audit_root": source["audit_root"],
                "claim_scope": "AUTHORITY_SNAPSHOT_CRYPTO_REPLAY",
            })
        return checks, report

    return _run(record, "ContinuedValidityView", VALIDITY_PROFILE, check)
