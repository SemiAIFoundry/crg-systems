"""Independent verifier for the CRG v1.1 safe-commitment artifact.

The checker is a standard-library-only reimplementation of the registered
finite/exact profile.  It never imports the producer, model, geometry, or
certification packages.  Retained sets, minimum required objects, regret
infima, accepted regret bounds, hashes, and internal authorization decisions
are reconstructed from the portable artifact.  Unknown semantics fail closed.
"""
from __future__ import annotations

from fractions import Fraction
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from .arith import ZERO, ArithError, fmt, minimum, positive_part_sup, rational
from .canonical import CanonicalError, content_hash, hash_without
from .certificate import (
    Level,
    Status,
    VerificationResult,
    derive_claim_scope,
    required_object_for,
)

__all__ = ["verify_safe_commitment"]

SCHEMA_VERSION = "1.1.0"
PROFILE = "crg-safe-commitment/finite-exact@1"
REGRET_PROFILE = "crg-regret/strict-separation-finite-exact@1"
BOUND_PROFILE = "crg-regret-bound/fixed-additive-finite-exact@1"

_POLICIES = frozenset(
    {
        "retain-all",
        "fiber-preserving",
        "retain-all-signatures",
        "universal-monotone",
        "additive-price-visible",
        "retain-all-winners",
        "argmin-hitting",
        "bounded-regret",
    }
)
_ADDITIVE = frozenset("weighted_sum linear additive additive_price dot price_vector".split())
_PRUNING_CONDITIONS = (
    "VALID_LOWER_OR_OUTER_BOUND",
    "FEASIBLE_INCUMBENT_OR_UPPER_WITNESS",
    "SCOPE_MATCH",
    "DERIVATION_PERMITS_COMPARISON",
    "INTERVAL_SAFE_COMPARISON",
    "TIE_POLICY_PRESERVED",
    "REQUIRED_GEOMETRY_PRESERVED",
    "COMPLETENESS_IMPLICATIONS_VALID",
    "DEPENDENCIES_VALID",
    "PRUNING_CERTIFICATE_EMITTED",
)


def _sealed(value: Mapping[str, Any], hash_key: str) -> Tuple[bool, str]:
    stated = value.get(hash_key)
    if not isinstance(stated, str):
        return False, f"{hash_key} is absent"
    try:
        actual = hash_without(dict(value), hash_key)
    except (CanonicalError, TypeError, ValueError) as error:
        return False, f"canonical hashing failed: {error}"
    return stated == actual, f"stated {stated}; recomputed {actual}"


def _points(raw: Any) -> List[Tuple[Fraction, ...]]:
    if not isinstance(raw, list):
        raise ArithError("a generator collection must be a list")
    result = []
    for point in raw:
        if not isinstance(point, list):
            raise ArithError("a signature must be a list")
        result.append(tuple(rational(item) for item in point))
    return result


def _entries(registry: Mapping[str, Any]) -> Dict[str, dict]:
    raw = registry.get("entries")
    if not isinstance(raw, list):
        raise ValueError("registry.entries must be a list")
    entries: Dict[str, dict] = {}
    dimension: Optional[int] = None
    for entry in raw:
        if not isinstance(entry, dict):
            raise ValueError("every registry entry must be an object")
        identifier = entry.get("realization_id")
        if not isinstance(identifier, str) or not identifier or identifier in entries:
            raise ValueError("registry realization identities must be unique non-empty strings")
        point = tuple(rational(item) for item in entry.get("signature", []))
        if not point:
            raise ValueError(f"registry entry {identifier!r} has an empty signature")
        if dimension is None:
            dimension = len(point)
        if len(point) != dimension:
            raise ValueError("registry signatures do not share one dimension")
        entries[identifier] = {**entry, "_point": point}
    if not entries:
        raise ValueError("safe commitment requires a non-empty represented family")
    return entries


def _registry_binding_failures(
    registry: Mapping[str, Any], entries: Mapping[str, dict]
) -> List[str]:
    """Bind the verifier-facing registry projection to the sealed bundle.

    ``registry.entries`` exists so an independent verifier need not understand
    every producer-side record convenience.  It is still only authoritative
    when it is an exact projection of ``registry.bundle.realizations``; a
    separately resealed projection must not be able to substitute a different
    represented family.
    """
    failures: List[str] = []
    bundle = registry.get("bundle")
    if not isinstance(bundle, dict):
        return ["registry.bundle must be an object"]
    if registry.get("bundle_id") != bundle.get("bundle_id"):
        failures.append("registry bundle identity differs from the sealed bundle")
    raw = bundle.get("realizations")
    if not isinstance(raw, list):
        return failures + ["sealed bundle realizations must be a list"]
    projected: Dict[str, dict] = {}
    try:
        for item in raw:
            if not isinstance(item, dict):
                raise ValueError("every sealed-bundle realization must be an object")
            identifier = item.get("realization_id")
            if not isinstance(identifier, str) or not identifier or identifier in projected:
                raise ValueError(
                    "sealed-bundle realization identities must be unique non-empty strings"
                )
            projected[identifier] = {
                "point": tuple(rational(value) for value in item.get("signature", [])),
                "legality": item.get("legality"),
                "attributes": item.get("attributes") or {},
                "evidence_class": item.get("evidence_class"),
            }
    except (ArithError, TypeError, ValueError) as error:
        return failures + [f"sealed bundle cannot be projected exactly: {error}"]
    if set(projected) != set(entries):
        failures.append("registry.entries identities differ from the sealed bundle")
        return failures
    for identifier in sorted(entries):
        entry = entries[identifier]
        source = projected[identifier]
        if entry["_point"] != source["point"]:
            failures.append(f"registry entry {identifier!r} signature differs from the sealed bundle")
        for field in ("legality", "evidence_class"):
            if entry.get(field) != source[field]:
                failures.append(
                    f"registry entry {identifier!r} {field} differs from the sealed bundle"
                )
        if (entry.get("attributes") or {}) != source["attributes"]:
            failures.append(f"registry entry {identifier!r} attributes differ from the sealed bundle")
    return failures


def _retained_bundle_hash(registry: Mapping[str, Any], retained: Iterable[str]) -> str:
    bundle = registry.get("bundle")
    if not isinstance(bundle, dict) or not isinstance(bundle.get("realizations"), list):
        raise ValueError("sealed bundle is unavailable for retained-family reconstruction")
    selected = set(retained)
    record = dict(bundle)
    record["bundle_id"] = f"{bundle.get('bundle_id')}::retained"
    record["realizations"] = [
        item
        for item in bundle["realizations"]
        if isinstance(item, dict) and item.get("realization_id") in selected
    ]
    return content_hash(record)


def _pareto(points: Iterable[Tuple[Fraction, ...]]) -> List[Tuple[Fraction, ...]]:
    unique = sorted(set(points))
    return [
        point
        for point in unique
        if not any(
            other != point
            and all(left <= right for left, right in zip(other, point))
            and any(left < right for left, right in zip(other, point))
            for other in unique
        )
    ]


def _cross(
    origin: Tuple[Fraction, ...],
    first: Tuple[Fraction, ...],
    second: Tuple[Fraction, ...],
) -> Fraction:
    return ((first[0] - origin[0]) * (second[1] - origin[1])
            - (first[1] - origin[1]) * (second[0] - origin[0]))


def _planar_k(points: Iterable[Tuple[Fraction, ...]]) -> List[Tuple[Fraction, ...]]:
    frontier = sorted(_pareto(points))
    if any(len(point) != 2 for point in frontier):
        raise ValueError("additive-price-visible verification supports planar geometry only")
    hull: List[Tuple[Fraction, ...]] = []
    for point in frontier:
        while len(hull) >= 2 and _cross(hull[-2], hull[-1], point) <= ZERO:
            hull.pop()
        hull.append(point)
    return hull


def _representatives(
    entries: Mapping[str, dict], points: Iterable[Tuple[Fraction, ...]]
) -> set:
    desired = set(points)
    result = set()
    seen = set()
    for identifier in sorted(entries):
        point = entries[identifier]["_point"]
        if point in desired and point not in seen:
            seen.add(point)
            result.add(identifier)
    return result


def _weight(value: Any) -> Fraction:
    """Only a fixed exact scalar belongs to the registered bound profile."""
    if isinstance(value, (list, tuple)):
        if len(value) != 2:
            raise ArithError("a price range must have exactly two endpoints")
        low, high = rational(value[0]), rational(value[1])
        if low != high:
            raise ArithError("a continuous/ranged price is outside the fixed-additive profile")
        result = low
    elif isinstance(value, dict) and "exact" not in value:
        low_raw = value.get("lo", value.get("low", value.get("min")))
        high_raw = value.get("hi", value.get("high", value.get("max")))
        if low_raw is None or high_raw is None:
            raise ArithError("a price mapping does not declare both endpoints")
        low, high = rational(low_raw), rational(high_raw)
        if low != high:
            raise ArithError("a continuous/ranged price is outside the fixed-additive profile")
        result = low
    else:
        result = rational(value)
    if result < ZERO:
        raise ArithError("an additive price must be nonnegative")
    return result


def _objective_value(
    point: Sequence[Fraction], objective: Mapping[str, Any], order: Sequence[str]
) -> Fraction:
    kind = str(objective.get("type", "")).strip().lower()
    weights = objective.get("weights") or {}
    if kind not in _ADDITIVE:
        raise ArithError(f"objective family {kind!r} is not fixed additive")
    if not isinstance(weights, dict):
        raise ArithError("weights must be an object")
    if len(point) != len(order):
        raise ArithError("objective coordinate order does not match signature dimension")
    total = ZERO
    for name, coordinate in zip(order, point):
        total += _weight(weights.get(name, 1)) * coordinate
    return total


def _scope_order(scope: Mapping[str, Any], registry: Mapping[str, Any]) -> List[str]:
    objective = scope.get("objective_family") or {}
    order = objective.get("coordinate_order")
    if isinstance(order, list) and order:
        return [str(item) for item in order]
    coordinates = (registry.get("schema") or {}).get("coordinates") or []
    result = []
    for coordinate in coordinates:
        identifier = coordinate.get("identifier") if isinstance(coordinate, dict) else None
        if not isinstance(identifier, str) or not identifier:
            raise ValueError("coordinate schema does not declare a canonical order")
        result.append(identifier)
    if not result:
        raise ValueError("coordinate schema does not declare a canonical order")
    return result


def _entry_feasible(entry: Mapping[str, Any], scope: Mapping[str, Any]) -> bool:
    if str(entry.get("legality", "LEGAL")) != "LEGAL":
        return False
    attributes = entry.get("attributes") or {}
    if not isinstance(attributes, dict):
        raise ValueError("registry entry attributes must be an object")
    declared = attributes.get("feasible", attributes.get("feasibility"))
    if declared is False or (isinstance(declared, str) and declared.upper() in {"INFEASIBLE", "UNKNOWN"}):
        return False
    domain = scope.get("technology_domain") or {}
    if not isinstance(domain, dict):
        raise ValueError("technology_domain must be an object")
    for key, bounds in domain.items():
        if key not in attributes or not isinstance(bounds, list) or len(bounds) != 2:
            continue
        observed = rational(attributes[key])
        if observed < rational(bounds[0]) or observed > rational(bounds[1]):
            return False
    return True


def _argmin_hitting(
    entries: Mapping[str, dict],
    family: Mapping[str, Any],
    registry: Mapping[str, Any],
    *,
    force_all_ties: bool = False,
) -> set:
    retained = set()
    found_ledger = False
    for decision in family.get("decisions") or []:
        scope = decision.get("scope") or {}
        objective = scope.get("objective_family") or {}
        if str(objective.get("type", "")).lower() not in {"finite_ledger", "case_ledger", "ledger"}:
            continue
        found_ledger = True
        order = _scope_order(scope, registry)
        cases = objective.get("cases") or []
        if not cases:
            raise ValueError("an argmin-hitting policy requires finite named cases")
        for case in cases:
            values = {
                identifier: _objective_value(entry["_point"], case, order)
                for identifier, entry in entries.items()
                if _entry_feasible(entry, scope)
            }
            if not values:
                raise ValueError("a finite-ledger case has no established feasible realization")
            optimum = min(values.values())
            argmins = sorted(identifier for identifier, value in values.items() if value == optimum)
            retain_all = force_all_ties or bool(scope.get("retain_all_ties", True))
            retained.update(argmins if retain_all else argmins[:1])
    if not found_ledger:
        raise ValueError("argmin-hitting is unsupported without a finite-ledger decision")
    return retained


def _protected(
    entries: Mapping[str, dict], declaration: Mapping[str, Any]
) -> set:
    protected = set(str(item) for item in declaration.get("protected_ids") or [])
    missing = protected - set(entries)
    if missing:
        raise ValueError(f"protected identities are absent: {sorted(missing)}")
    classes = declaration.get("protected_classes") or {}
    if not isinstance(classes, dict):
        raise ValueError("protected_classes must be an object")
    for field, values in classes.items():
        if not isinstance(values, list):
            raise ValueError("every protected class value set must be a list")
        for identifier, entry in entries.items():
            attributes = entry.get("attributes") or {}
            if isinstance(attributes, dict) and attributes.get(field) in values:
                protected.add(identifier)
    return protected


def _family_protected(entries: Mapping[str, dict], family: Mapping[str, Any]) -> set:
    protected = set()
    for decision in family.get("decisions") or []:
        objective = ((decision.get("scope") or {}).get("objective_family") or {})
        protected.update(str(item) for item in objective.get("protected_ids") or [])
        protected.update(str(item) for item in objective.get("required_retained_identities") or [])
    missing = protected - set(entries)
    if missing:
        raise ValueError(f"future decision family protects absent identities: {sorted(missing)}")
    return protected


def _expected_retained(
    entries: Mapping[str, dict],
    family: Mapping[str, Any],
    registry: Mapping[str, Any],
    declaration: Mapping[str, Any],
) -> set:
    policy = str(declaration.get("policy", ""))
    if policy not in _POLICIES:
        raise ValueError(f"unknown retention policy {policy!r}")
    points = [entry["_point"] for entry in entries.values()]
    parameters = declaration.get("parameters") or {}
    if not isinstance(parameters, dict):
        raise ValueError("policy parameters must be an object")
    proposed = parameters.get("retained_ids")
    if proposed is not None:
        if policy != "bounded-regret" or not isinstance(proposed, list) or not proposed:
            raise ValueError("retained_ids is registered only for non-empty bounded-regret proposals")
        retained = set(str(item) for item in proposed)
        missing = retained - set(entries)
        if missing:
            raise ValueError(f"retained identities are absent: {sorted(missing)}")
    elif policy in {"retain-all", "fiber-preserving"}:
        retained = set(entries)
    elif policy == "retain-all-signatures":
        retained = _representatives(entries, points)
    elif policy in {"universal-monotone", "bounded-regret"}:
        retained = _representatives(entries, _pareto(points))
    elif policy == "additive-price-visible":
        retained = _representatives(entries, _planar_k(points))
    elif policy in {"argmin-hitting", "retain-all-winners"}:
        retained = _argmin_hitting(
            entries,
            family,
            registry,
            force_all_ties=policy == "retain-all-winners",
        )
    else:  # pragma: no cover - exhaustive guard above
        raise ValueError(f"unsupported retention policy {policy!r}")
    return retained | _protected(entries, declaration) | _family_protected(entries, family)


def _preserved(
    required: str,
    entries: Mapping[str, dict],
    retained: set,
    decision: Mapping[str, Any],
    registry: Mapping[str, Any],
) -> Tuple[bool, str]:
    full_points = [entry["_point"] for entry in entries.values()]
    retained_points = [entries[identifier]["_point"] for identifier in sorted(retained)]
    if required == "REALIZATION_REGISTRY_AND_FIBERS":
        return retained == set(entries), "all realization identities and fibers"
    if required == "R":
        return set(full_points) == set(retained_points), "exact signature set R"
    if required == "GAMMA":
        return set(_pareto(full_points)) == set(_pareto(retained_points)), "Pareto frontier Gamma"
    if required == "K":
        return set(_planar_k(full_points)) == set(_planar_k(retained_points)), "planar additive-price body K"
    if required == "ARGMIN_HITTING_SET":
        expected = _argmin_hitting(entries, {"decisions": [decision]}, registry)
        return expected <= retained, "finite-ledger argmin-hitting set"
    if required == "BOUNDED_REGRET_REPRESENTATION":
        # Accepted only through a separately reconstructed typed fact.
        return True, "typed bounded-regret fact required"
    raise ValueError(f"unknown required retained object {required!r}")


def _point_json(point: Sequence[Fraction]) -> list:
    return [{"exact": fmt(value)} for value in point]


def _preview_failures(
    evaluation: Mapping[str, Any], entries: Mapping[str, dict], retained: set
) -> List[str]:
    failures: List[str] = []
    groups: Dict[Tuple[Fraction, ...], List[str]] = {}
    for identifier in sorted(retained):
        groups.setdefault(entries[identifier]["_point"], []).append(identifier)
    expected_fibers = [
        {"signature": _point_json(point), "realization_ids": identifiers}
        for point, identifiers in sorted(groups.items())
    ]
    if evaluation.get("retained_fibers") != expected_fibers:
        failures.append("retained-fiber preview differs from independent reconstruction")
    preview = evaluation.get("geometry_preview") or {}
    if not isinstance(preview, dict):
        return failures + ["geometry_preview must be an object"]
    points = sorted(set(entries[identifier]["_point"] for identifier in retained))
    if preview.get("R") != [_point_json(point) for point in points]:
        failures.append("R preview differs from the retained exact signature set")
    gamma = _pareto(points)
    if preview.get("GAMMA") != [_point_json(point) for point in gamma]:
        failures.append("Gamma preview differs from the retained Pareto frontier")
    k_preview = preview.get("K")
    if points and len(points[0]) == 2:
        expected_k = [_point_json(point) for point in _planar_k(points)]
        if k_preview != expected_k:
            failures.append("K preview differs from the retained planar additive-price body")
    elif not (
        isinstance(k_preview, dict)
        and k_preview.get("status") in {"UNSUPPORTED_PROFILE", "UNAVAILABLE"}
    ):
        failures.append("non-planar K preview must state an unsupported or unavailable profile")
    return failures


def _verify_regret(
    item: Mapping[str, Any],
    *,
    registry: Mapping[str, Any],
    entries: Mapping[str, dict],
    retained_ids: set,
    decision: Optional[Mapping[str, Any]],
) -> List[str]:
    failures: List[str] = []
    ok, detail = _sealed(item, "witness_hash")
    if not ok:
        failures.append(detail)
    if item.get("verification_program") != REGRET_PROFILE:
        failures.append("unknown regret verification program")
    objective = item.get("objective") or {}
    if objective.get("family") != "CONTINUOUS_STRICTLY_INCREASING_COERCIVE":
        failures.append("objective is outside the registered regret family")
    if objective.get("construction") != "STRICT_INCREASING_COERCIVE_SEPARATION":
        failures.append("regret objective uses an unknown constructive separation")
    membership = item.get("family_membership_proof") or {}
    if not (
        isinstance(membership, dict)
        and membership.get("profile") == REGRET_PROFILE
        and membership.get("epsilon_strictly_positive") is True
        and membership.get("construction")
        == "positive-part sup plus positive additive term"
    ):
        failures.append("regret family-membership proof is absent or outside the profile")
    if item.get("full_registry_hash") != registry.get("bundle_hash"):
        failures.append("regret full-family reference is not the sealed registry")
    try:
        expected_retained_hash = _retained_bundle_hash(registry, retained_ids)
    except (CanonicalError, TypeError, ValueError) as error:
        failures.append(f"retained-family reference cannot be reconstructed: {error}")
    else:
        if item.get("retained_registry_hash") != expected_retained_hash:
            failures.append("regret retained-family reference differs from the evaluated retention set")
    if decision is None:
        failures.append("regret evidence names no decision in the future family")
    else:
        scope = decision.get("scope") or {}
        if item.get("validity") != scope.get("validity"):
            failures.append("regret validity differs from the bound future decision")
    if item.get("completeness") != registry.get("completeness"):
        failures.append("regret completeness differs from the represented family")
    basis = (registry.get("completeness") or {}).get("basis_type")
    expected_scope = (
        "GLOBAL"
        if basis in {"EXHAUSTIVE_DECLARED_UNIVERSE", "GENERATOR_CLOSED"}
        else "RELATIVE"
    )
    if item.get("scope") != expected_scope:
        failures.append(f"regret scope must be {expected_scope} for completeness basis {basis!r}")
    if item.get("dependencies") != sorted(entries):
        failures.append("regret dependencies do not equal the represented family identities")
    if item.get("evidence_class") != "EXACT":
        failures.append("the finite exact regret profile requires EXACT evidence")
    try:
        full = _points(item.get("full_generators"))
        retained = _points(item.get("retained_generators"))
        lost = tuple(rational(value) for value in (item.get("lost_element") or {}).get("signature", []))
        anchor = tuple(rational(value) for value in objective.get("anchor", []))
        epsilon = rational(objective.get("epsilon"))
        stated_full = rational(item.get("full_infimum"))
        stated_retained = rational(item.get("retained_infimum"))
        stated_gap = rational(item.get("gap"))
    except (ArithError, TypeError, ValueError) as error:
        return failures + [f"regret evidence is not exactly decodable: {error}"]
    expected_full = _pareto(entry["_point"] for entry in entries.values())
    expected_retained = _pareto(entries[identifier]["_point"] for identifier in retained_ids)
    if full != expected_full:
        failures.append("regret full generators differ from the sealed family frontier")
    if retained != expected_retained:
        failures.append("regret retained generators differ from the evaluated retained frontier")
    if lost != anchor or lost not in full:
        failures.append("lost signature/anchor is not in the full generator set")
    if not retained:
        failures.append("retained generator set is empty")
        return failures
    if epsilon <= ZERO:
        failures.append("regret objective epsilon is not strictly positive")
        return failures
    separation = minimum(positive_part_sup(point, anchor) for point in retained)
    if separation is None or separation <= ZERO:
        failures.append("lost point remains inside the retained upper region")

    def phi(point: Sequence[Fraction]) -> Fraction:
        return positive_part_sup(point, anchor) + epsilon * sum(point, ZERO)

    full_infimum = minimum(phi(point) for point in full)
    retained_infimum = minimum(phi(point) for point in retained)
    if full_infimum is None or retained_infimum is None:
        failures.append("a regret infimum is undefined")
        return failures
    gap = retained_infimum - full_infimum
    if (full_infimum, retained_infimum, gap) != (stated_full, stated_retained, stated_gap):
        failures.append(
            "regret infima/gap do not match independent reconstruction "
            f"({fmt(full_infimum)}, {fmt(retained_infimum)}, {fmt(gap)})"
        )
    if gap <= ZERO:
        failures.append("reconstructed regret gap is not strictly positive")
    try:
        numeric = item.get("numeric_interval") or {}
        evidence = item.get("evidence_interval") or {}
        if rational(numeric.get("lo")) != gap or rational(numeric.get("hi")) != gap:
            failures.append("numeric interval does not equal the exact regret gap")
        if rational(evidence.get("lo")) != gap or rational(evidence.get("hi")) != gap:
            failures.append("evidence interval does not equal the exact regret gap")
    except (ArithError, AttributeError) as error:
        failures.append(f"regret intervals are not exactly decodable: {error}")
    return failures


def _verify_bound(
    item: Mapping[str, Any],
    *,
    registry: Mapping[str, Any],
    entries: Mapping[str, dict],
    retained_ids: set,
    decision: Optional[Mapping[str, Any]],
) -> List[str]:
    failures: List[str] = []
    ok, detail = _sealed(item, "fact_hash")
    if not ok:
        failures.append(detail)
    if item.get("proof_profile") != BOUND_PROFILE:
        failures.append("unknown bounded-regret proof profile")
    objective = item.get("objective_family") or {}
    order = item.get("coordinate_order") or []
    if decision is None:
        failures.append("bounded-regret fact names no decision in the future family")
        scope: Mapping[str, Any] = {}
    else:
        scope = decision.get("scope") or {}
    try:
        if str(objective.get("type", "")).lower() not in _ADDITIVE:
            raise ArithError("the bound objective is not additive")
        if str(objective.get("quantification", "EACH_OBJECTIVE")) != "EACH_OBJECTIVE":
            raise ArithError("coupled robust aggregate is outside the bound profile")
        raw_values = item.get("full_values") or []
        values = {}
        for entry in raw_values:
            identifier = str(entry["realization_id"])
            if identifier in values:
                raise ArithError("bound fact has duplicate realization identities")
            values[identifier] = tuple(rational(value) for value in entry["signature"])
        retained = set(str(value) for value in item.get("retained_ids") or [])
        if not values or not retained or not retained <= set(values):
            raise ArithError("bound fact has an empty or unknown retained set")
        full_minimum = min(_objective_value(point, objective, order) for point in values.values())
        retained_minimum = min(
            _objective_value(values[identifier], objective, order) for identifier in retained
        )
        computed = retained_minimum - full_minimum
        stated = rational(item.get("bound"))
        tolerance = rational(item.get("tolerance"))
    except (ArithError, KeyError, TypeError, ValueError) as error:
        return failures + [f"bounded-regret fact is not reconstructible: {error}"]
    expected_values = {identifier: entry["_point"] for identifier, entry in entries.items()}
    if values != expected_values:
        failures.append("bounded-regret full values differ from the sealed registry")
    if retained != retained_ids:
        failures.append("bounded-regret retained identities differ from the evaluated policy")
    try:
        expected_order = _scope_order(scope, registry)
    except (TypeError, ValueError) as error:
        failures.append(f"bound decision coordinate order is invalid: {error}")
        expected_order = []
    if list(order) != expected_order:
        failures.append("bounded-regret coordinate order differs from the bound decision")
    declared_objective = dict(scope.get("objective_family") or {})
    declared_objective["coordinate_order"] = expected_order
    if objective != declared_objective:
        failures.append("bounded-regret objective family differs from the bound future decision")
    declared_bound = (scope.get("objective_family") or {}).get("bounded_regret") or {}
    try:
        declared_tolerance = rational(declared_bound.get("tolerance"))
    except (ArithError, TypeError, ValueError) as error:
        failures.append(f"bound decision tolerance is not exact: {error}")
    else:
        if tolerance != declared_tolerance or declared_bound.get("accept_approximation") is not True:
            failures.append("bounded-regret tolerance/acceptance differs from the bound decision")
    if item.get("completeness") != registry.get("completeness"):
        failures.append("bounded-regret completeness differs from the represented family")
    if item.get("dependencies") != sorted(entries):
        failures.append("bounded-regret dependencies do not equal the represented family identities")
    if computed < ZERO:
        failures.append("retained family reports a negative regret")
    if computed != stated:
        failures.append(f"stated bound {fmt(stated)} differs from reconstructed {fmt(computed)}")
    if bool(item.get("accepted")) != (computed <= tolerance):
        failures.append("accepted flag does not equal bound <= tolerance")
    if str(item.get("evidence_class")) != "EXACT":
        failures.append("the fixed-additive exact proof profile requires EXACT evidence")
    return failures


def _verify_pruning_assessment(item: Mapping[str, Any]) -> List[str]:
    failures: List[str] = []
    conditions = item.get("conditions")
    if not isinstance(conditions, list) or len(conditions) != 10:
        return ["a pruning assessment must expose exactly ten conditions"]
    numbers = [condition.get("number") for condition in conditions if isinstance(condition, dict)]
    if numbers != list(range(1, 11)):
        failures.append("pruning condition numbers must be the ordered set 1..10")
    identifiers = [
        condition.get("identifier") for condition in conditions if isinstance(condition, dict)
    ]
    if identifiers != list(_PRUNING_CONDITIONS):
        failures.append("pruning condition identifiers differ from the §29.2 ordered contract")
    statuses = [condition.get("status") for condition in conditions if isinstance(condition, dict)]
    if any(status not in {"PASS", "FAIL", "NOT_REACHED"} for status in statuses):
        failures.append("a pruning condition uses an unknown status")
    authorized = bool(item.get("authorized"))
    if authorized != all(status == "PASS" for status in statuses):
        failures.append("pruning authorization does not equal all ten conditions passing")
    certificate = item.get("certificate")
    if authorized:
        if not isinstance(certificate, dict):
            failures.append("authorized pruning has no certificate")
        else:
            ok, detail = _sealed(certificate, "certificate_hash")
            if not ok:
                failures.append(detail)
            if certificate.get("pruned_id") != item.get("candidate_id"):
                failures.append("pruning certificate names a different candidate")
            for field in ("tie_policy_satisfied", "geometry_preserved", "dependencies_valid"):
                if certificate.get(field) is not True:
                    failures.append(f"authorized pruning certificate has {field}=false")
    elif certificate is not None:
        failures.append("unauthorized pruning carries a certificate")
    return failures


def verify_safe_commitment(artifact: Mapping[str, Any]) -> VerificationResult:
    """Verify one portable safe-commitment artifact, fail closed and total."""
    result = VerificationResult(ok=False, status=Status.FAILED)
    result.report.update(
        {
            "artifact_type": "SafeCommitmentArtifact",
            "profile": artifact.get("profile") if isinstance(artifact, Mapping) else None,
            "level_attempted": Level.V3,
            "level_achieved": "NONE",
        }
    )
    if not isinstance(artifact, Mapping):
        result.record("artifact_shape", False, "safe-commitment artifact must be an object")
        return result.finish()
    artifact = dict(artifact)
    result.record(
        "registered_profile",
        artifact.get("schema_version") == SCHEMA_VERSION and artifact.get("profile") == PROFILE,
        f"schema/profile must be {SCHEMA_VERSION}/{PROFILE}",
    )
    ok, detail = _sealed(artifact, "artifact_hash")
    result.record("artifact_integrity", ok, detail)

    family = artifact.get("family") or {}
    if isinstance(family, dict):
        ok, detail = _sealed(family, "family_hash")
        result.record("family_integrity", ok, detail)
    else:
        result.record("family_integrity", False, "family must be an object")
        family = {}
    decisions = family.get("decisions") or []
    decision_by_id: Dict[str, dict] = {}
    family_errors = []
    if not isinstance(decisions, list) or not decisions:
        family_errors.append("future decision family is empty")
    else:
        for decision in decisions:
            identifier = decision.get("decision_id") if isinstance(decision, dict) else None
            if not isinstance(identifier, str) or not identifier or identifier in decision_by_id:
                family_errors.append("future decision identities must be unique non-empty strings")
                continue
            scope = decision.get("scope") or {}
            derivation = decision.get("derivation") or {}
            objective = dict(scope.get("objective_family") or {})
            objective["quantification"] = objective.get(
                "quantification", scope.get("quantification", "EACH_OBJECTIVE")
            )
            if scope.get("observation_level") == "REALIZATION":
                objective["realization_sensitivity"] = True
            needed, _ = required_object_for(objective)
            if derivation.get("decision_class") != scope.get("observation_level"):
                family_errors.append(
                    f"decision {identifier!r} scope/derivation decision classes disagree"
                )
            if derivation.get("required_object") != needed:
                family_errors.append(
                    f"decision {identifier!r} derivation states {derivation.get('required_object')!r}; "
                    f"independent mapping requires {needed!r}"
                )
            decision_by_id[identifier] = decision
    result.record(
        "future_decision_family_sound",
        not family_errors,
        "; ".join(family_errors) if family_errors else
        f"{len(decision_by_id)} compiled future decisions have independently sufficient objects",
    )

    registry = artifact.get("registry") or {}
    try:
        entries = _entries(registry)
        bundle = registry.get("bundle")
        registry_ok = isinstance(bundle, dict) and content_hash(bundle) == registry.get("bundle_hash")
        if bundle and (bundle.get("schema") != registry.get("schema")
                       or bundle.get("completeness") != registry.get("completeness")):
            registry_ok = False
        binding_failures = _registry_binding_failures(registry, entries)
        registry_ok = registry_ok and not binding_failures
        registry_detail = (
            "; ".join(binding_failures)
            if binding_failures
            else f"{len(entries)} unique exact registry entries bound to the sealed bundle"
        )
    except (ArithError, CanonicalError, TypeError, ValueError) as error:
        entries = {}
        registry_ok = False
        registry_detail = str(error)
    result.record("registry_reconstructed", registry_ok, registry_detail)

    declarations = artifact.get("policies") or []
    evaluations = artifact.get("evaluations") or []
    declaration_by_id = {
        item.get("policy_id"): item
        for item in declarations
        if isinstance(item, dict) and isinstance(item.get("policy_id"), str)
    }
    evaluation_by_id = {
        item.get("policy_id"): item
        for item in evaluations
        if isinstance(item, dict) and isinstance(item.get("policy_id"), str)
    }
    structure_ok = (
        isinstance(declarations, list)
        and isinstance(evaluations, list)
        and len(declaration_by_id) == len(declarations)
        and len(evaluation_by_id) == len(evaluations)
        and set(declaration_by_id) == set(evaluation_by_id)
        and bool(declaration_by_id)
    )
    result.record(
        "policy_comparison_structure",
        structure_ok,
        "policy declarations and evaluations have a one-to-one identity mapping",
    )

    policy_failures: List[str] = []
    regret_count = bound_count = pruning_count = 0
    if entries and structure_ok:
        for identifier in sorted(declaration_by_id):
            declaration = declaration_by_id[identifier]
            evaluation = evaluation_by_id[identifier]
            status = evaluation.get("status")
            policy = declaration.get("policy")
            if status not in {"CERTIFIED", "CERTIFIED_BOUNDED", "REFUSED"}:
                policy_failures.append(f"{identifier}: unknown evaluation status {status!r}")
            if evaluation.get("family_id") != family.get("family_id"):
                policy_failures.append(f"{identifier}: evaluation is bound to a different family")
            if evaluation.get("policy") != policy:
                policy_failures.append(f"{identifier}: evaluation policy differs from its declaration")
            try:
                expected = _expected_retained(entries, family, registry, declaration)
                supported = True
            except (ArithError, TypeError, ValueError) as error:
                expected = set(entries)
                supported = False
                if status != "REFUSED":
                    policy_failures.append(f"{identifier}: unsupported policy was not refused: {error}")
            stated = set(str(item) for item in evaluation.get("retained_ids") or [])
            pruned = set(str(item) for item in evaluation.get("pruned_ids") or [])
            unknown_retained = stated - set(entries)
            if unknown_retained:
                policy_failures.append(
                    f"{identifier}: retained set names absent identities {sorted(unknown_retained)}"
                )
            known_stated = stated & set(entries)
            if supported and stated != expected:
                policy_failures.append(
                    f"{identifier}: retained set {sorted(stated)} != reconstructed {sorted(expected)}"
                )
            if not supported and stated != set(entries):
                policy_failures.append(
                    f"{identifier}: unsupported policy did not conservatively retain the full family"
                )
            if pruned != set(entries) - stated:
                policy_failures.append(f"{identifier}: pruned set is not the registry complement")
            for failure in _preview_failures(evaluation, entries, known_stated):
                policy_failures.append(f"{identifier}/preview: {failure}")
            if declaration.get("family_id") != family.get("family_id"):
                policy_failures.append(f"{identifier}: policy is bound to a different family")
            if status == "REFUSED" and not evaluation.get("refusals"):
                policy_failures.append(f"{identifier}: refusal has no stated reason")
            if status in {"CERTIFIED", "CERTIFIED_BOUNDED"} and evaluation.get("refusals"):
                policy_failures.append(f"{identifier}: certified policy carries unresolved refusals")
            results: Dict[str, dict] = {}
            raw_results = evaluation.get("decision_results") or []
            if not isinstance(raw_results, list):
                policy_failures.append(f"{identifier}: decision_results must be a list")
                raw_results = []
            for item in raw_results:
                decision_id = item.get("decision_id") if isinstance(item, dict) else None
                if not isinstance(decision_id, str) or not decision_id or decision_id in results:
                    policy_failures.append(
                        f"{identifier}: decision result identities must be unique non-empty strings"
                    )
                    continue
                results[decision_id] = item
            if supported:
                if set(results) != set(decision_by_id):
                    policy_failures.append(f"{identifier}: decision result coverage is incomplete")
                result_states = {item.get("status") for item in results.values()}
                expected_status = (
                    "REFUSED"
                    if result_states & {"BLOCKED_GEOMETRY_LOSS", "REFUSED"}
                    or bool(evaluation.get("refusals"))
                    else "CERTIFIED_BOUNDED"
                    if "PRESERVED_WITH_BOUNDED_REGRET" in result_states
                    else "CERTIFIED"
                )
                if status != expected_status:
                    policy_failures.append(
                        f"{identifier}: aggregate status {status!r} does not match "
                        f"decision results ({expected_status})"
                    )
                for decision_id, decision in decision_by_id.items():
                    required = str((decision.get("derivation") or {}).get("required_object", ""))
                    try:
                        preserved, basis = _preserved(
                            required, entries, known_stated, decision, registry
                        )
                    except (ArithError, TypeError, ValueError) as error:
                        policy_failures.append(f"{identifier}/{decision_id}: {error}")
                        continue
                    claimed = (results.get(decision_id) or {}).get("status")
                    if required == "BOUNDED_REGRET_REPRESENTATION":
                        # A typed fact, verified below, determines accepted approximation.
                        facts = [
                            item for item in evaluation.get("regret_bounds") or []
                            if item.get("decision_id") == decision_id
                        ]
                        accepted = len(facts) == 1 and bool(facts[0].get("accepted"))
                        if claimed == "PRESERVED_WITH_BOUNDED_REGRET" and not accepted:
                            policy_failures.append(
                                f"{identifier}/{decision_id}: bounded preservation has no accepted fact"
                            )
                        if claimed not in {
                            "PRESERVED", "PRESERVED_WITH_BOUNDED_REGRET", "BLOCKED_GEOMETRY_LOSS",
                            "REFUSED",
                        }:
                            policy_failures.append(
                                f"{identifier}/{decision_id}: unknown bounded-regret result {claimed!r}"
                            )
                    elif preserved and claimed != "PRESERVED":
                        policy_failures.append(
                            f"{identifier}/{decision_id}: {basis} is preserved but status is {claimed!r}"
                        )
                    elif not preserved and claimed != "BLOCKED_GEOMETRY_LOSS":
                        policy_failures.append(
                            f"{identifier}/{decision_id}: {basis} is lost but status is {claimed!r}"
                        )

            seen_witness_decisions = set()
            for witness in evaluation.get("regret_evidence") or []:
                regret_count += 1
                if not isinstance(witness, dict):
                    policy_failures.append(f"{identifier}/regret: witness must be an object")
                    continue
                decision_id = witness.get("decision_id")
                if decision_id in seen_witness_decisions:
                    policy_failures.append(
                        f"{identifier}/regret: duplicate witness for decision {decision_id!r}"
                    )
                seen_witness_decisions.add(decision_id)
                if (results.get(decision_id) or {}).get("status") != "BLOCKED_GEOMETRY_LOSS":
                    policy_failures.append(
                        f"{identifier}/regret: witness is not bound to a geometry-loss decision result"
                    )
                failures = _verify_regret(
                    witness,
                    registry=registry,
                    entries=entries,
                    retained_ids=known_stated,
                    decision=decision_by_id.get(decision_id),
                )
                policy_failures.extend(f"{identifier}/regret: {failure}" for failure in failures)
            seen_bound_decisions = set()
            for fact in evaluation.get("regret_bounds") or []:
                bound_count += 1
                if not isinstance(fact, dict):
                    policy_failures.append(f"{identifier}/bound: fact must be an object")
                    continue
                decision_id = fact.get("decision_id")
                if decision_id in seen_bound_decisions:
                    policy_failures.append(
                        f"{identifier}/bound: duplicate bound for decision {decision_id!r}"
                    )
                seen_bound_decisions.add(decision_id)
                if (results.get(decision_id) or {}).get("status") != "PRESERVED_WITH_BOUNDED_REGRET":
                    policy_failures.append(
                        f"{identifier}/bound: fact is not bound to a bounded-regret decision result"
                    )
                failures = _verify_bound(
                    fact,
                    registry=registry,
                    entries=entries,
                    retained_ids=known_stated,
                    decision=decision_by_id.get(decision_id),
                )
                policy_failures.extend(f"{identifier}/bound: {failure}" for failure in failures)
            assessment_pairs = set()
            for assessment in evaluation.get("pruning_assessments") or []:
                pruning_count += 1
                if not isinstance(assessment, dict):
                    policy_failures.append(f"{identifier}/pruning: assessment must be an object")
                    continue
                pair = (
                    assessment.get("candidate_id"),
                    assessment.get("decision_id"),
                )
                if pair in assessment_pairs:
                    policy_failures.append(f"{identifier}/pruning: duplicate assessment {pair!r}")
                assessment_pairs.add(pair)
                if pair[0] not in pruned or pair[1] not in decision_by_id:
                    policy_failures.append(
                        f"{identifier}/pruning: assessment is not bound to a pruned candidate/decision"
                    )
                failures = _verify_pruning_assessment(assessment)
                policy_failures.extend(f"{identifier}/pruning: {failure}" for failure in failures)
            expected_pairs = {
                (candidate_id, decision_id)
                for candidate_id in pruned
                for decision_id in decision_by_id
            }
            if assessment_pairs != expected_pairs:
                policy_failures.append(
                    f"{identifier}/pruning: assessments do not cover every pruned candidate/decision pair"
                )

    result.record(
        "retention_policies_reconstructed",
        not policy_failures,
        "; ".join(policy_failures) if policy_failures else
        f"{len(declaration_by_id)} policies reconstructed under one family/scenario scope",
    )
    result.record(
        "regret_evidence_reconstructed",
        not any("/regret:" in failure for failure in policy_failures),
        f"{regret_count} full regret witnesses independently recomputed",
    )
    result.record(
        "regret_bounds_reconstructed",
        not any("/bound:" in failure for failure in policy_failures),
        f"{bound_count} typed regret bounds independently recomputed",
    )
    result.record(
        "pruning_conditions_complete",
        not any("/pruning:" in failure for failure in policy_failures),
        f"{pruning_count} pruning assessments expose all ten §29.2 conditions",
    )

    result.finish()
    if artifact.get("schema_version") != SCHEMA_VERSION or artifact.get("profile") != PROFILE:
        result.status = Status.UNSUPPORTED_PROFILE
    elif result.ok:
        claim_scope = derive_claim_scope(registry.get("completeness") or {})
        result.status = (
            Status.VERIFIED
            if claim_scope in {"FULL_DECLARED_UNIVERSE", "GENERATOR_CLOSED_FAMILY"}
            else Status.VERIFIED_RELATIVE
        )
    else:
        result.status = Status.FAILED
    result.report.update(
        {
            "artifact_type": "SafeCommitmentArtifact",
            "profile": artifact.get("profile"),
            "level_attempted": Level.V3,
            "level_achieved": Level.V3 if result.ok else "NONE",
            "policy_count": len(declaration_by_id),
            "regret_witness_count": regret_count,
            "regret_bound_count": bound_count,
            "pruning_assessment_count": pruning_count,
            "profile_coverage": {
                "geometry": "FINITE_EXACT_R_GAMMA_AND_PLANAR_K",
                "regret_witness": REGRET_PROFILE,
                "regret_bound": BOUND_PROFILE,
                "unsupported": [
                    "NONPLANAR_K",
                    "CONTINUOUS_OR_RANGED_REGRET_BOUND",
                    "UNREGISTERED_RETENTION_POLICY",
                ],
            },
        }
    )
    return result
