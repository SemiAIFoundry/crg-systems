"""Independent V4 capability-envelope verification (spec 25.2, 35, 45).

The envelope is an assertion.  The values that can corroborate it therefore
come from the verifier: a public-key ring, expected context, authorization
policy, nonce ledger, revocation snapshot, requester, and clock.  No check in
this module treats an envelope's statement about itself as corroboration.

This module deliberately imports no CRG kernel package.  Ed25519 is loaded
only when a V4 signature is actually checked; a build without the optional
``cryptography`` provider fails the signature check rather than downgrading.
"""
from __future__ import annotations

import datetime as _dt
from typing import Any, Dict, Iterable, List, Mapping, MutableSet, Optional, Sequence, Tuple

from .canonical import canonical_bytes, content_hash, is_hash

__all__ = ["verify_federation"]


_REQUIRED = (
    "schema_version", "envelope_id", "bounded_result",
    "target_context_fingerprint", "rule_identity", "evidence_root", "issuer",
    "authorization", "validity", "nonce", "revocation", "release_policy",
    "clock_assertion", "verification_program",
)
_PROGRAM_CHECKS = frozenset({
    "signature", "attestation", "nonce", "context", "authorization", "validity",
    "revocation", "release_policy", "rule", "code_identity", "evidence",
    "uncertainty", "clock",
})
_RELEASE_ORDER = (
    "NO_RESULT", "BOOLEAN", "POSSIBLE_OR_GUARANTEED_STATE", "AMBIGUITY_RESULT",
    "QUANTIZED_MARGIN", "BOUNDED_INTERVAL",
)
_ATTESTATION_DISCLAIMER = "underlying evidence is scientifically accurate"


def _instant(value: Any) -> Optional[_dt.datetime]:
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        parsed = _dt.datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    except ValueError:
        return None
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=_dt.timezone.utc)


def _members(value: Any) -> Tuple[str, ...]:
    if isinstance(value, (list, tuple, set, frozenset)):
        return tuple(str(item) for item in value)
    return ()


def _requester_permitted(policy: Mapping[str, Any], requester: Any) -> bool:
    access = policy.get("access") if isinstance(policy.get("access"), Mapping) else None
    if access is None:
        access_ok = True
    elif str(access.get("classification") or "internal") == "public":
        access_ok = True
    elif not isinstance(requester, Mapping):
        access_ok = False
    else:
        subjects = set(_members(access.get("permitted_subjects")))
        roles = set(_members(access.get("permitted_roles")))
        access_ok = (
            str(requester.get("subject_id") or "") in subjects
            or bool(set(_members(requester.get("roles"))) & roles)
        )
    if not access_ok:
        return False
    subjects = set(_members(policy.get("permitted_subjects")))
    roles = set(_members(policy.get("permitted_roles")))
    if not subjects and not roles:
        return True
    if not isinstance(requester, Mapping):
        return False
    return (
        str(requester.get("subject_id") or "") in subjects
        or bool(set(_members(requester.get("roles"))) & roles)
    )


def _verification_key(context: Mapping[str, Any], key_id: str) -> Optional[Mapping[str, Any]]:
    keys = context.get("trusted_keys")
    if not isinstance(keys, Mapping):
        return None
    key = keys.get(key_id)
    return key if isinstance(key, Mapping) else None


def _verify_signature(
    payload: Mapping[str, Any], signature: Any, context: Mapping[str, Any]
) -> Tuple[bool, str]:
    if not isinstance(signature, Mapping):
        return False, "no signature binds the capability envelope"
    required = ("profile", "algorithm", "key_id", "key_reference", "value",
                "payload_hash", "excluded_fields")
    missing = [name for name in required if name not in signature]
    if missing:
        return False, f"signature omits {missing}"
    if tuple(signature.get("excluded_fields") or ()) != ("signature",):
        return False, "signature-excluded fields must be exactly ['signature']"
    profile = str(signature.get("profile"))
    if profile != "Ed25519":
        return False, f"V4 requires the production Ed25519 profile, found {profile!r}"
    if str(signature.get("algorithm")) != "ed25519":
        return False, "Ed25519 signature declares a different algorithm"
    key_id = str(signature.get("key_id"))
    key = _verification_key(context, key_id)
    if key is None:
        return False, f"no verifier-trusted public key {key_id!r}"
    if key.get("revoked") is True:
        return False, f"verification key {key_id!r} is revoked"
    if str(key.get("profile")) != profile:
        return False, "signature and verification-key profiles differ"
    public = str(key.get("public_key") or key.get("public_reference") or "")
    if public.startswith("ed25519-pub:"):
        public = public.split(":", 1)[1]
    expected_reference = f"ed25519-pub:{public}"
    if str(signature.get("key_reference")) != expected_reference:
        return False, "signature key reference does not match the trusted public key"
    signed_payload = {k: v for k, v in payload.items() if k != "signature"}
    payload_hash = content_hash(signed_payload)
    if signature.get("payload_hash") != payload_hash:
        return False, "signature payload hash does not match the canonical envelope"
    value = str(signature.get("value") or "")
    prefix, separator, encoded = value.partition(":")
    if prefix != "ed25519" or not separator:
        return False, "signature value is not algorithm-tagged Ed25519"
    try:
        public_bytes, signature_bytes = bytes.fromhex(public), bytes.fromhex(encoded)
    except ValueError:
        return False, "public key or signature is not hexadecimal"
    try:
        from cryptography.exceptions import InvalidSignature
        from cryptography.hazmat.primitives.asymmetric import ed25519
    except ImportError:
        return False, "Ed25519 provider unavailable; install the production crypto profile"
    try:
        ed25519.Ed25519PublicKey.from_public_bytes(public_bytes).verify(
            signature_bytes, canonical_bytes(signed_payload)
        )
    except (InvalidSignature, ValueError):
        return False, "Ed25519 signature does not verify over the canonical envelope"
    return True, f"Ed25519 signature verified with trusted key {key_id!r}"


def _revoked_subjects(context: Mapping[str, Any]) -> Optional[set]:
    revocations = context.get("revocations")
    if not isinstance(revocations, Mapping):
        return None
    values = revocations.get("subjects")
    if values is None:
        values = revocations.get("revoked_subjects")
    return set(_members(values))


def verify_federation(
    envelopes: Sequence[Mapping[str, Any]], *, context: Any,
    clock: Optional[str], clock_source: str,
) -> Tuple[List[Tuple[str, bool, str]], Dict[str, Any], str]:
    """Return V4 checks, report fields, and the most specific failure status.

    ``context`` is verifier-owned state.  Required keys are ``trusted_keys``,
    ``trusted_issuers``, ``expected_context``, ``authorized_rules``,
    ``requester``, ``nonce_ledger``, and ``revocations``.  Their absence is a
    failed check, never an assumption.
    """
    checks: List[Tuple[str, bool, str]] = []
    report: Dict[str, Any] = {"federation_envelopes": []}
    status = "FAILED"

    def add(name: str, passed: bool, detail: str) -> None:
        checks.append((name, bool(passed), detail))

    if not isinstance(context, Mapping):
        add("v4_verifier_context", False,
            "V4 requires verifier-owned trust inputs; no federation context was supplied")
        return checks, report, "UNSUPPORTED_PROFILE"
    required_context = (
        "trusted_keys", "trusted_issuers", "expected_context", "authorized_rules",
        "requester", "nonce_ledger", "revocations",
    )
    missing_context = [name for name in required_context if name not in context]
    add("v4_verifier_context", not missing_context,
        f"verifier context omits {missing_context}" if missing_context
        else "all verifier-owned federation trust inputs are present")
    if missing_context:
        return checks, report, "UNSUPPORTED_PROFILE"
    add("v4_capability_envelope_present", bool(envelopes),
        f"{len(envelopes)} capability envelope(s) carried" if envelopes
        else "the bundle carries no CapabilityEnvelope object")
    if not envelopes:
        return checks, report, status

    now = _instant(clock)
    add("v4_verifier_clock", now is not None and bool(clock_source),
        f"verifier clock {clock_source!r} evaluated at {clock}" if now is not None
        else "freshness-required V4 verification needs a valid verifier clock")
    trusted_issuers = set(_members(context.get("trusted_issuers")))
    expected_context = str(context.get("expected_context") or "")
    authorized_rules = set(_members(context.get("authorized_rules")))
    requester = context.get("requester")
    ledger = context.get("nonce_ledger")
    revoked = _revoked_subjects(context)
    revocations = context.get("revocations")
    pending_nonces: List[str] = []
    any_expired = any_revoked = any_time_indeterminate = False

    for index, envelope in enumerate(envelopes):
        prefix = f"v4_envelope[{index}]"
        entry: Dict[str, Any] = {"envelope_id": envelope.get("envelope_id")}
        report["federation_envelopes"].append(entry)
        missing = [name for name in _REQUIRED if name not in envelope]
        add(f"{prefix}.bindings", not missing,
            f"required bindings omitted: {missing}" if missing else "all section 35.2 bindings present")

        program = envelope.get("verification_program")
        program_failures: List[str] = []
        if not isinstance(program, Mapping):
            program_failures.append("verification_program is not an object")
        else:
            declared = set(_members(program.get("checks")))
            unknown = sorted(declared - _PROGRAM_CHECKS)
            if unknown:
                program_failures.append(f"unsupported declared checks {unknown}")
            preimage = {name: program.get(name) for name in ("program_id", "interpreter", "checks")}
            if program.get("program_hash") != content_hash(preimage):
                program_failures.append("program_hash does not bind id, interpreter, and checks")
        add(f"{prefix}.verification_program", not program_failures,
            "; ".join(program_failures) if program_failures else "verification program is supported and hash-bound")

        signature_ok, signature_detail = _verify_signature(envelope, envelope.get("signature"), context)
        add(f"{prefix}.signature", signature_ok, signature_detail)
        entry["signature_judgment"] = "VERIFIED" if signature_ok else "FAILED"

        issuer = str(envelope.get("issuer") or "")
        issuer_ok = bool(trusted_issuers) and issuer in trusted_issuers
        add(f"{prefix}.issuer", issuer_ok,
            f"issuer {issuer!r} is trusted" if issuer_ok else f"issuer {issuer!r} is not verifier-trusted")

        actual_context = str(envelope.get("target_context_fingerprint") or "")
        context_ok = bool(expected_context) and actual_context == expected_context
        add(f"{prefix}.context", context_ok,
            "target-context fingerprint matches verifier expectation" if context_ok
            else f"expected {expected_context!r}, envelope binds {actual_context!r}")

        rule = envelope.get("rule_identity") if isinstance(envelope.get("rule_identity"), Mapping) else {}
        rule_name = f"{rule.get('rule_id')}@{rule.get('rule_version')}"
        rule_ok = is_hash(rule.get("rule_hash")) and rule_name in authorized_rules
        rule_expiry = _instant(rule.get("expiration"))
        if rule_expiry is not None and now is not None and now > rule_expiry:
            rule_ok = False
        add(f"{prefix}.rule_authorization", rule_ok,
            f"rule {rule_name} is authorized and current" if rule_ok
            else f"rule {rule_name} is unauthorized, expired, or not hash-bound")

        validity = envelope.get("validity") if isinstance(envelope.get("validity"), Mapping) else {}
        issued = _instant(validity.get("issued_at"))
        not_before = _instant(validity.get("not_before"))
        expires = _instant(validity.get("expires_at"))
        time_ok = now is not None
        time_detail = "validity is current"
        if now is None:
            time_detail = "verifier time is indeterminate"
            any_time_indeterminate = True
        elif not_before is not None and now < not_before:
            time_ok, time_detail, any_expired = False, "envelope is not yet valid", True
        elif expires is not None and now > expires:
            time_ok, time_detail, any_expired = False, "envelope is expired", True
        elif validity.get("max_age_seconds") is not None:
            if issued is None:
                time_ok, time_detail, any_time_indeterminate = False, "max age declared without a valid issue time", True
            elif (now - issued).total_seconds() > int(validity["max_age_seconds"]):
                time_ok, time_detail, any_expired = False, "envelope freshness window has elapsed", True
        add(f"{prefix}.validity", time_ok, time_detail)
        entry["time_judgment"] = "CURRENT" if time_ok else (
            "TIME_INDETERMINATE" if any_time_indeterminate else "EXPIRED")

        nonce = str(envelope.get("nonce") or "")
        try:
            replayed = nonce in ledger
        except TypeError:
            replayed = True
            nonce = ""
        nonce_ok = bool(nonce) and not replayed and nonce not in pending_nonces
        add(f"{prefix}.nonce", nonce_ok,
            f"nonce {nonce!r} is fresh in the verifier ledger" if nonce_ok
            else f"nonce {nonce!r} is absent, reused, or the ledger is invalid")
        if nonce_ok:
            pending_nonces.append(nonce)

        revocation = envelope.get("revocation") if isinstance(envelope.get("revocation"), Mapping) else {}
        registry_id = str(revocation.get("registry_id") or "")
        live_registry_id = str(revocations.get("registry_id") or "") if isinstance(revocations, Mapping) else ""
        subjects = {str(envelope.get("envelope_id") or ""), str(envelope.get("evidence_root") or ""),
                    str((envelope.get("signature") or {}).get("key_id") or "")}
        revocation_ok = (
            revoked is not None and bool(registry_id) and registry_id == live_registry_id
            and revocation.get("state") == "ACTIVE" and not (subjects & revoked)
        )
        any_revoked = any_revoked or bool(subjects & (revoked or set())) or revocation.get("state") != "ACTIVE"
        add(f"{prefix}.revocation", revocation_ok,
            "live revocation snapshot matches and all bound subjects are active" if revocation_ok
            else "revocation state is absent, stale/mismatched, non-active, or contains a revoked subject")

        authorization = envelope.get("authorization")
        auth_ok = isinstance(authorization, Mapping) and _requester_permitted(authorization, requester)
        add(f"{prefix}.authorization", auth_ok,
            "requester satisfies the signed authorization" if auth_ok
            else "requester is not permitted by the signed authorization")

        policy = envelope.get("release_policy")
        policy_ok = isinstance(policy, Mapping) and _requester_permitted(policy, requester)
        policy_detail = "requester satisfies the minimum-disclosure release policy"
        if isinstance(policy, Mapping):
            kinds = _members(policy.get("authorized_kinds"))
            unknown_kinds = set(kinds) - set(_RELEASE_ORDER)
            expected_default = min(kinds, key=_RELEASE_ORDER.index) if kinds and not unknown_kinds else None
            requested_kind = str(context.get("requested_release_kind") or policy.get("default_kind") or "")
            policy_ok = policy_ok and not unknown_kinds and requested_kind in kinds
            policy_ok = policy_ok and policy.get("default_kind") == expected_default
            if policy.get("require_uncertainty", True):
                bounded = envelope.get("bounded_result")
                policy_ok = policy_ok and isinstance(bounded, Mapping) and bounded.get("uncertainty_declared") is True
            if not policy_ok:
                policy_detail = "release kind, minimum default, uncertainty, or requester violates policy"
        else:
            policy_detail = "release_policy is not an object"
        add(f"{prefix}.release_policy", policy_ok, policy_detail)

        attestation = envelope.get("attestation")
        require_attestation = bool(context.get("require_attestation"))
        attestation_ok = not require_attestation
        attestation_detail = "attestation not required by verifier policy"
        if isinstance(attestation, Mapping):
            disclaimers = " ".join(_members(attestation.get("does_not_prove"))).lower()
            expected_code = context.get("expected_code_identity")
            expected_input = context.get("expected_input_commitment")
            attestation_ok = (
                _ATTESTATION_DISCLAIMER in disclaimers
                and (expected_code is None or attestation.get("code_identity") == expected_code)
                and (expected_input is None or attestation.get("input_commitment") == expected_input)
            )
            if attestation_ok and attestation.get("signature") is not None:
                attestation_ok, attestation_detail = _verify_signature(
                    attestation, attestation.get("signature"), context
                )
            else:
                attestation_detail = (
                    "attestation scope and committed code/input are valid" if attestation_ok
                    else "attestation scope, code identity, or input commitment is invalid"
                )
        add(f"{prefix}.attestation", attestation_ok, attestation_detail)

    failed = [name for name, passed, _detail in checks if not passed]
    if not failed:
        if hasattr(ledger, "add"):
            for nonce in pending_nonces:
                ledger.add(nonce)
        else:
            add("v4_nonce_consumption", False,
                "nonce ledger is not mutable; acceptance cannot atomically consume a nonce")
            failed.append("v4_nonce_consumption")
    if not failed:
        status = "REPLAY_BOUND"
    elif any_revoked:
        status = "REVOKED"
    elif any_expired:
        status = "EXPIRED"
    elif any_time_indeterminate:
        status = "TIME_INDETERMINATE"
    report.update({
        "time_judgment": "CURRENT" if now is not None and not any_expired else status,
        "signature_judgment": "VERIFIED" if all(
            entry.get("signature_judgment") == "VERIFIED" for entry in report["federation_envelopes"]
        ) else "FAILED",
        "nonce_consumed": not failed,
    })
    return checks, report, status
