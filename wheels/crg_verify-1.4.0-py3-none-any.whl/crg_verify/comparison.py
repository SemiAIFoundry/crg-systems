"""Independent verifier for portable comparative workflow evaluations.

This is a standard-library-only reconstruction of the CRG-ENH-03
``finite-exact@1`` record.  It intentionally imports no producer, model,
geometry, certification, change, IO, server, or Studio code.  It checks the
portable input hashes and recomputes workload denominators, retention burden,
oracle misses, exact regret, affected/preserved/invalidated work, verification
counts, and design comparability from the embedded raw traces.

Verification of this record never authorizes a CRG decision.  A valid result
means only that the scoped non-authorizing record is internally reproducible.
"""
from __future__ import annotations

from fractions import Fraction
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple

from .arith import ArithError, rational
from .canonical import CanonicalError, content_hash, hash_without, is_hash
from .certificate import Status, VerificationResult

__all__ = ["verify_comparative_workflow_evaluation"]

SCHEMA_VERSION = "1.1.0"
PROFILE = "crg-comparative-workflow/finite-exact@1"
AUTHORITY = "NON_AUTHORIZING"
CLAIM_BOUNDARY = (
    "Scoped workflow evidence only; this record does not authorize a CRG state, "
    "rank a method, establish superiority, infer economic value, or generalize "
    "beyond the declared inputs, workload, oracle, budgets, and denominators."
)
ORACLE_PROFILE = "finite-exact-minimum@1"
FACTS_PROFILE = "finite-exact-operational-facts@1"
COMPARABLE = "COMPARABLE_DESIGN"
NON_COMPARABLE = "NON_COMPARABLE_DESIGN"
NO_CONCLUSION = "NO_METHOD_RANKING_OR_AUTHORIZING_CONCLUSION"

_SCOPE_FIELDS = (
    "technology_scope",
    "evidence_scope",
    "change_scope",
    "scenario_scope",
    "held_out_treatment",
)
_VERIFIER_STATUSES = frozenset(
    {
        "VERIFIED",
        "VERIFIED_RELATIVE",
        "VERIFIED_WITH_BOUNDED_REMAINDER",
        "INTEGRITY_ONLY",
        "REPLAY_BOUND",
        "PARTIALLY_VERIFIED",
        "FAILED",
        "EXPIRED",
        "REVOKED",
        "TIME_INDETERMINATE",
        "UNVERIFIABLE_REDACTED",
        "UNSUPPORTED_PROFILE",
    }
)
_VERIFIED_STATUSES = frozenset(
    {"VERIFIED", "VERIFIED_RELATIVE", "VERIFIED_WITH_BOUNDED_REMAINDER"}
)
_FORBIDDEN_RESULT_KEYS = frozenset(
    {
        "roi",
        "return_on_investment",
        "savings",
        "superiority",
        "generalization",
        "method_ranking",
        "best_method",
        "winner_method",
        "avoided_experiments",
        "avoided_redesigns",
    }
)
_TOP_LEVEL_FIELDS = frozenset(
    {
        "record_type",
        "schema_version",
        "profile",
        "evaluation_id",
        "authority",
        "authorizing",
        "semantic_effect",
        "evidence_class",
        "claim_boundary",
        "inputs",
        "scope",
        "workload",
        "oracle",
        "methods",
        "comparability",
        "results",
        "local_observations",
        "declared_counterfactuals",
        "limitations",
        "record_hash",
    }
)
_SCOPE_RECORD_FIELDS = frozenset(
    {
        "realization_family_input_id",
        "realization_family_hash",
        "completeness_basis",
        "decision_family_input_id",
        "decision_family_hash",
        *_SCOPE_FIELDS,
        "scope_hash",
    }
)


def _exact(value: Fraction | int) -> dict:
    number = value if isinstance(value, Fraction) else Fraction(value)
    text = (
        str(number.numerator)
        if number.denominator == 1
        else f"{number.numerator}/{number.denominator}"
    )
    return {"exact": text}


def _sealed(value: Mapping[str, Any], key: str) -> Tuple[bool, str]:
    stated = value.get(key)
    if not is_hash(stated):
        return False, f"{key} is not a portable SHA-256 content hash"
    try:
        actual = hash_without(dict(value), key)
    except (CanonicalError, TypeError, ValueError) as error:
        return False, f"canonical hashing failed: {error}"
    return stated == actual, f"stated {stated}; recomputed {actual}"


def _identity(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value.strip() or value != value.strip():
        raise ValueError(f"{field} must be a normalized non-empty string")
    return value


def _ids(value: Any, field: str, *, nonempty: bool = False) -> List[str]:
    if not isinstance(value, list):
        raise ValueError(f"{field} must be a list")
    result = [_identity(item, field) for item in value]
    if len(result) != len(set(result)):
        raise ValueError(f"{field} contains duplicate identities")
    if result != sorted(result):
        raise ValueError(f"{field} is not in canonical identity order")
    if nonempty and not result:
        raise ValueError(f"{field} must not be empty")
    return result


def _exact_field(value: Any, field: str, *, nonnegative: bool = False) -> Fraction:
    number = rational(value)
    if value != _exact(number):
        raise ValueError(f"{field} is not in the canonical exact-rational encoding")
    if nonnegative and number < 0:
        raise ValueError(f"{field} must be nonnegative")
    return number


def _bindings(value: Any, field: str) -> Dict[str, str]:
    if not isinstance(value, dict) or not value:
        raise ValueError(f"{field} must bind every named input")
    result = {}
    for name, digest in value.items():
        result[_identity(name, f"{field} input identity")] = digest
        if not is_hash(digest):
            raise ValueError(f"{field}.{name} is not a portable SHA-256 content hash")
    return result


def _forbidden_paths(value: Any, path: str) -> List[str]:
    failures: List[str] = []
    if isinstance(value, dict):
        for key, item in value.items():
            normalized = str(key).strip().lower().replace("-", "_")
            if normalized in _FORBIDDEN_RESULT_KEYS:
                failures.append(f"{path}.{key}")
            failures.extend(_forbidden_paths(item, f"{path}.{key}"))
    elif isinstance(value, list):
        for index, item in enumerate(value):
            failures.extend(_forbidden_paths(item, f"{path}[{index}]"))
    return failures


def _read_inputs(value: Any) -> Tuple[Dict[str, str], Dict[str, Any], List[str]]:
    failures: List[str] = []
    hashes: Dict[str, str] = {}
    contents: Dict[str, Any] = {}
    if not isinstance(value, list) or not value:
        return {}, {}, ["inputs must be a non-empty list"]
    prior = ""
    for index, item in enumerate(value):
        if not isinstance(item, dict):
            failures.append(f"inputs[{index}] must be an object")
            continue
        try:
            identifier = _identity(item.get("input_id"), f"inputs[{index}].input_id")
            if identifier in hashes:
                raise ValueError("input identities must be unique")
            if identifier < prior:
                raise ValueError("inputs are not in canonical identity order")
            prior = identifier
            stated = item.get("content_hash")
            if not is_hash(stated):
                raise ValueError("input content hash is malformed")
            actual = content_hash(item.get("content"))
            if stated != actual:
                raise ValueError(f"input hash {stated} does not match reconstructed {actual}")
            if set(item) != {"input_id", "content", "content_hash"}:
                raise ValueError("input record has an unsupported field set")
            hashes[identifier] = stated
            contents[identifier] = item["content"]
        except (CanonicalError, TypeError, ValueError) as error:
            failures.append(f"inputs[{index}]: {error}")
    return hashes, contents, failures


def _read_scope(
    value: Any, hashes: Mapping[str, str], contents: Mapping[str, Any]
) -> Tuple[dict, set, List[str]]:
    failures: List[str] = []
    legal: set = set()
    if not isinstance(value, dict):
        return {}, legal, ["scope must be an object"]
    if set(value) != _SCOPE_RECORD_FIELDS:
        failures.append("scope has a missing or unsupported field set")
    prohibited = _forbidden_paths(value, "scope")
    if prohibited:
        failures.append(f"scope contains prohibited conclusion fields: {prohibited}")
    ok, detail = _sealed(value, "scope_hash")
    if not ok:
        failures.append(detail)
    try:
        realization_id = _identity(
            value.get("realization_family_input_id"), "scope realization family input"
        )
        decision_id = _identity(
            value.get("decision_family_input_id"), "scope decision family input"
        )
        if realization_id not in contents or decision_id not in contents:
            raise ValueError("scope input identities do not resolve to embedded inputs")
        if value.get("realization_family_hash") != hashes[realization_id]:
            failures.append("scope realization-family hash differs from its embedded input")
        if value.get("decision_family_hash") != hashes[decision_id]:
            failures.append("scope decision-family hash differs from its embedded input")
        family = contents[realization_id]
        if not isinstance(family, dict):
            raise ValueError("realization-family input must be an object")
        represented = family.get("realizations")
        completeness = family.get("completeness")
        if not isinstance(represented, list) or not represented:
            raise ValueError("realization-family input has no represented realizations")
        if not isinstance(completeness, dict) or not completeness.get("basis_type"):
            raise ValueError("realization-family input has no completeness basis")
        if value.get("completeness_basis") != completeness:
            failures.append("scope completeness basis differs from the bound family")
        decision = contents[decision_id]
        if not isinstance(decision, dict):
            raise ValueError("decision-family input must be an object")
        is_future_family = (
            decision.get("record_type") == "FutureDecisionFamily"
            and isinstance(decision.get("decisions"), list)
            and bool(decision.get("decisions"))
        )
        is_decision = (
            isinstance(decision.get("scope_id"), str)
            and bool(decision.get("scope_id"))
            and isinstance(decision.get("observation_level"), str)
            and isinstance(decision.get("objective_family"), dict)
        )
        if not (is_future_family or is_decision):
            raise ValueError("decision input is neither DecisionScope nor FutureDecisionFamily")
        for index, item in enumerate(represented):
            if not isinstance(item, dict):
                raise ValueError(f"represented realization {index} is not an object")
            identifier = _identity(item.get("realization_id"), "realization identity")
            if identifier in legal:
                raise ValueError("realization identities are not unique")
            if item.get("legality") != "LEGAL":
                raise ValueError(f"realization {identifier!r} is not declared LEGAL")
            legal.add(identifier)
        for field in _SCOPE_FIELDS:
            if field not in value:
                failures.append(f"scope is missing {field}")
    except (TypeError, ValueError) as error:
        failures.append(str(error))
    return value, legal, failures


def _read_cases(value: Any, legal: set) -> Tuple[Dict[str, dict], List[str]]:
    failures: List[str] = []
    cases: Dict[str, dict] = {}
    if not isinstance(value, list) or not value:
        return {}, ["workload must contain a non-empty case list"]
    prior = ""
    for index, item in enumerate(value):
        if not isinstance(item, dict):
            failures.append(f"workload[{index}] must be an object")
            continue
        try:
            if set(item) != {"case_id", "eligible_ids", "work_item_ids"}:
                raise ValueError("workload case has an unsupported field set")
            identifier = _identity(item.get("case_id"), "workload case identity")
            if identifier in cases or identifier < prior:
                raise ValueError("workload cases must be uniquely and canonically ordered")
            prior = identifier
            eligible = _ids(item.get("eligible_ids"), "eligible_ids", nonempty=True)
            work = _ids(item.get("work_item_ids"), "work_item_ids", nonempty=True)
            unknown = set(eligible) - legal
            if unknown:
                raise ValueError(f"eligible IDs outside the legal family: {sorted(unknown)}")
            cases[identifier] = {
                "case_id": identifier,
                "eligible_ids": eligible,
                "work_item_ids": work,
            }
        except (TypeError, ValueError) as error:
            failures.append(f"workload[{index}]: {error}")
    return cases, failures


def _read_oracle(value: Any, cases: Mapping[str, dict]) -> Tuple[dict, Dict[str, dict], List[str]]:
    failures: List[str] = []
    answers: Dict[str, dict] = {}
    if not isinstance(value, dict):
        return {}, answers, ["oracle must be an object"]
    if set(value) != {
        "oracle_id", "name", "version", "profile", "direction", "input_bindings",
        "denominator", "answers", "oracle_hash",
    }:
        failures.append("oracle has a missing or unsupported field set")
    ok, detail = _sealed(value, "oracle_hash")
    if not ok:
        failures.append(detail)
    try:
        for field in ("oracle_id", "name", "version"):
            _identity(value.get(field), f"oracle.{field}")
        if value.get("profile") != ORACLE_PROFILE or value.get("direction") != "MINIMIZE":
            raise ValueError("oracle is outside finite-exact-minimum@1")
        _bindings(value.get("input_bindings"), "oracle.input_bindings")
        denominator = value.get("denominator")
        if not isinstance(denominator, dict):
            raise ValueError("oracle denominator must be an object")
        case_ids = _ids(denominator.get("case_ids"), "oracle denominator case_ids")
        count = _exact_field(denominator.get("count"), "oracle denominator count", nonnegative=True)
        if case_ids != sorted(cases) or count != len(cases):
            failures.append("oracle denominator does not equal the declared workload")
        raw_answers = value.get("answers")
        if not isinstance(raw_answers, list):
            raise ValueError("oracle.answers must be a list")
        prior = ""
        for index, answer in enumerate(raw_answers):
            if not isinstance(answer, dict):
                raise ValueError(f"oracle answer {index} must be an object")
            case_id = _identity(answer.get("case_id"), "oracle answer case_id")
            if case_id not in cases or case_id in answers or case_id < prior:
                raise ValueError("oracle answers are not a canonical one-to-one case mapping")
            prior = case_id
            winners = _ids(answer.get("winner_ids"), "oracle winner_ids", nonempty=True)
            if not set(winners) <= set(cases[case_id]["eligible_ids"]):
                raise ValueError(f"oracle answer {case_id!r} names an ineligible winner")
            optimum = _exact_field(answer.get("optimum"), "oracle optimum")
            answers[case_id] = {
                "case_id": case_id,
                "winner_ids": winners,
                "optimum": _exact(optimum),
            }
        if set(answers) != set(cases):
            failures.append("oracle answers do not cover every workload case exactly once")
    except (ArithError, TypeError, ValueError) as error:
        failures.append(str(error))
    return value, answers, failures


def _budget(value: Any, field: str) -> List[dict]:
    if not isinstance(value, list) or not value:
        raise ValueError(f"{field} must be a non-empty list")
    result, seen = [], set()
    for index, item in enumerate(value):
        if not isinstance(item, dict) or set(item) != {"metric", "unit", "limit"}:
            raise ValueError(f"{field}[{index}] has an unsupported shape")
        metric = _identity(item.get("metric"), f"{field}[{index}].metric")
        unit = _identity(item.get("unit"), f"{field}[{index}].unit")
        if metric in seen:
            raise ValueError(f"{field} repeats metric {metric!r}")
        seen.add(metric)
        limit = _exact_field(item.get("limit"), f"{field}[{index}].limit", nonnegative=True)
        result.append({"metric": metric, "unit": unit, "limit": _exact(limit)})
    if result != sorted(result, key=lambda item: item["metric"]):
        raise ValueError(f"{field} is not in canonical metric order")
    return result


def _read_trace(
    value: Any,
    method_id: str,
    cases: Mapping[str, dict],
    oracle: Mapping[str, dict],
) -> Tuple[List[dict], List[str]]:
    failures: List[str] = []
    trace: List[dict] = []
    seen = set()
    if not isinstance(value, list):
        return trace, [f"{method_id}: trace must be a list"]
    prior = ""
    for index, item in enumerate(value):
        try:
            if not isinstance(item, dict):
                raise ValueError("trace item must be an object")
            expected_fields = {
                "case_id", "selected_ids", "retained_ids", "achieved_value",
                "affected_ids", "preserved_ids", "invalidated_ids", "verifier_status",
            }
            if set(item) != expected_fields:
                raise ValueError("trace item has an unsupported field set")
            case_id = _identity(item.get("case_id"), "trace case identity")
            if case_id not in cases or case_id in seen or case_id < prior:
                raise ValueError("trace is not a canonical one-to-one workload mapping")
            seen.add(case_id)
            prior = case_id
            eligible = set(cases[case_id]["eligible_ids"])
            work = set(cases[case_id]["work_item_ids"])
            selected = _ids(item.get("selected_ids"), "selected_ids")
            retained = _ids(item.get("retained_ids"), "retained_ids")
            if not set(selected) <= set(retained) or not set(retained) <= eligible:
                raise ValueError("selections are not retained or retained IDs are ineligible")
            achieved = _exact_field(item.get("achieved_value"), "achieved_value")
            optimum = rational(oracle[case_id]["optimum"])
            if achieved < optimum:
                raise ValueError("achieved value is below the declared finite minimum")
            affected = _ids(item.get("affected_ids"), "affected_ids")
            preserved = _ids(item.get("preserved_ids"), "preserved_ids")
            invalidated = _ids(item.get("invalidated_ids"), "invalidated_ids")
            if not (set(affected) <= work and set(preserved) <= work and set(invalidated) <= work):
                raise ValueError("trace names work outside the declared case denominator")
            if set(preserved) & set(invalidated) or set(preserved) | set(invalidated) != set(affected):
                raise ValueError("preserved and invalidated work do not partition affected work")
            status = _identity(item.get("verifier_status"), "verifier_status")
            if status not in _VERIFIER_STATUSES:
                raise ValueError(f"unsupported verifier status {status!r}")
            trace.append(
                {
                    "case_id": case_id,
                    "selected_ids": selected,
                    "retained_ids": retained,
                    "achieved_value": _exact(achieved),
                    "affected_ids": affected,
                    "preserved_ids": preserved,
                    "invalidated_ids": invalidated,
                    "verifier_status": status,
                }
            )
        except (ArithError, KeyError, TypeError, ValueError) as error:
            failures.append(f"{method_id}/trace[{index}]: {error}")
    if seen != set(cases):
        failures.append(f"{method_id}: trace does not cover every workload case exactly once")
    return trace, failures


def _read_methods(
    value: Any, cases: Mapping[str, dict], oracle: Mapping[str, dict]
) -> Tuple[Dict[str, dict], List[str]]:
    failures: List[str] = []
    methods: Dict[str, dict] = {}
    if not isinstance(value, list) or len(value) < 2:
        return {}, ["comparison requires at least two method records"]
    prior = ""
    for index, item in enumerate(value):
        if not isinstance(item, dict):
            failures.append(f"methods[{index}] must be an object")
            continue
        identifier = item.get("method_id")
        try:
            if set(item) != {
                "method_id", "name", "version", "workflow", "input_bindings",
                "declared_budget", "trace", "method_hash",
            }:
                raise ValueError("method has a missing or unsupported field set")
            identifier = _identity(identifier, "method identity")
            if identifier in methods or identifier < prior:
                raise ValueError("methods must be uniquely and canonically ordered")
            prior = identifier
            for field in ("name", "version", "workflow"):
                _identity(item.get(field), f"{identifier}.{field}")
            ok, detail = _sealed(item, "method_hash")
            if not ok:
                failures.append(f"{identifier}: {detail}")
            bindings = _bindings(item.get("input_bindings"), f"{identifier}.input_bindings")
            budget = _budget(item.get("declared_budget"), f"{identifier}.declared_budget")
            trace, trace_failures = _read_trace(item.get("trace"), identifier, cases, oracle)
            failures.extend(trace_failures)
            methods[identifier] = {
                **item,
                "input_bindings": bindings,
                "declared_budget": budget,
                "trace": trace,
            }
        except (ArithError, TypeError, ValueError) as error:
            failures.append(f"methods[{index}]: {error}")
    return methods, failures


def _denominators(cases: Mapping[str, dict]) -> dict:
    case_ids = sorted(cases)
    eligible = [
        {"case_id": case_id, "item_id": item_id}
        for case_id in case_ids
        for item_id in cases[case_id]["eligible_ids"]
    ]
    work = [
        {"case_id": case_id, "item_id": item_id}
        for case_id in case_ids
        for item_id in cases[case_id]["work_item_ids"]
    ]
    return {
        "cases": {"members": case_ids, "value": _exact(len(case_ids)), "unit": "cases"},
        "eligible_memberships": {
            "members": eligible,
            "value": _exact(len(eligible)),
            "unit": "case-realization memberships",
        },
        "work_item_memberships": {
            "members": work,
            "value": _exact(len(work)),
            "unit": "case-work-item memberships",
        },
        "regret_evaluations": {
            "members": case_ids,
            "value": _exact(len(case_ids)),
            "unit": "case evaluations",
        },
        "verification_attempts": {
            "members": case_ids,
            "value": _exact(len(case_ids)),
            "unit": "verification attempts",
        },
    }


def _ratio(numerator: int | Fraction, denominator: int) -> dict:
    if denominator <= 0:
        raise ValueError("a registered denominator is zero")
    return _exact(Fraction(numerator, denominator))


def _facts(method: Mapping[str, Any], oracle: Mapping[str, dict], denominators: dict) -> dict:
    retained = misses = affected = preserved = invalidated = verified = 0
    regrets: List[Fraction] = []
    statuses: Dict[str, int] = {}
    for item in method["trace"]:
        answer = oracle[item["case_id"]]
        retained += len(item["retained_ids"])
        misses += int(not (set(item["selected_ids"]) & set(answer["winner_ids"])))
        regret = rational(item["achieved_value"]) - rational(answer["optimum"])
        regrets.append(regret)
        affected += len(item["affected_ids"])
        preserved += len(item["preserved_ids"])
        invalidated += len(item["invalidated_ids"])
        status = item["verifier_status"]
        statuses[status] = statuses.get(status, 0) + 1
        verified += int(status in _VERIFIED_STATUSES)
    case_count = len(method["trace"])
    eligible_count = len(denominators["eligible_memberships"]["members"])
    work_count = len(denominators["work_item_memberships"]["members"])
    regret_total = sum(regrets, Fraction(0))
    return {
        "facts_profile": FACTS_PROFILE,
        "retention_burden": {
            "retained_memberships": _exact(retained),
            "fraction": _ratio(retained, eligible_count),
        },
        "oracle_misses": {"count": _exact(misses), "fraction": _ratio(misses, case_count)},
        "regret": {
            "total": _exact(regret_total),
            "maximum": _exact(max(regrets)),
            "mean": _exact(regret_total / case_count),
        },
        "affected_work": {"count": _exact(affected), "fraction": _ratio(affected, work_count)},
        "preserved_work": {"count": _exact(preserved), "fraction": _ratio(preserved, work_count)},
        "invalidated_work": {
            "count": _exact(invalidated),
            "fraction": _ratio(invalidated, work_count),
        },
        "verification": {
            "verified_count": _exact(verified),
            "fraction": _ratio(verified, case_count),
            "status_counts": [
                {"status": status, "count": _exact(statuses[status])}
                for status in sorted(statuses)
            ],
        },
    }


def _comparability(
    expected: Mapping[str, str], oracle: Mapping[str, Any], methods: Mapping[str, dict]
) -> dict:
    reasons: List[str] = []
    if oracle.get("input_bindings") != expected:
        reasons.append("ORACLE_INPUT_BINDINGS_MISMATCH")
    first = methods[sorted(methods)[0]]["declared_budget"]
    for identifier in sorted(methods):
        method = methods[identifier]
        if method["input_bindings"] != expected:
            reasons.append(f"METHOD_INPUT_BINDINGS_MISMATCH:{identifier}")
        if method["declared_budget"] != first:
            reasons.append(f"METHOD_BUDGET_MISMATCH:{identifier}")
    return {
        "status": COMPARABLE if not reasons else NON_COMPARABLE,
        "reasons": sorted(reasons),
        "conclusion": NO_CONCLUSION,
    }


def _verify_local_observations(value: Any, methods: set) -> List[str]:
    failures: List[str] = []
    if not isinstance(value, list):
        return ["local_observations must be a separate list"]
    prior = ""
    seen = set()
    for index, item in enumerate(value):
        try:
            if not isinstance(item, dict):
                raise ValueError("observation must be an object")
            expected = {
                "observation_id", "classification", "method_id", "observer", "metric",
                "value", "unit", "context", "observation_hash",
            }
            if set(item) != expected:
                raise ValueError("observation has an unsupported field set")
            identifier = _identity(item.get("observation_id"), "observation identity")
            if identifier in seen or identifier < prior:
                raise ValueError("observations must be uniquely and canonically ordered")
            seen.add(identifier)
            prior = identifier
            if item.get("classification") != "LOCAL_OBSERVATION_NON_AUTHORIZING":
                raise ValueError("local observation is not explicitly non-authorizing")
            if item.get("method_id") not in methods:
                raise ValueError("local observation names an unknown method")
            for field in ("observer", "metric", "unit"):
                _identity(item.get(field), f"observation.{field}")
            _exact_field(item.get("value"), "local observation value")
            if not isinstance(item.get("context"), dict):
                raise ValueError("local observation context must be an object")
            ok, detail = _sealed(item, "observation_hash")
            if not ok:
                raise ValueError(detail)
            forbidden = _forbidden_paths(item, "local_observations")
            if forbidden:
                raise ValueError(f"prohibited conclusion fields: {forbidden}")
        except (ArithError, CanonicalError, TypeError, ValueError) as error:
            failures.append(f"local_observations[{index}]: {error}")
    return failures


def _verify_counterfactuals(value: Any) -> List[str]:
    failures: List[str] = []
    if not isinstance(value, list):
        return ["declared_counterfactuals must be a separate list"]
    prior = ""
    seen = set()
    for index, item in enumerate(value):
        try:
            if not isinstance(item, dict):
                raise ValueError("counterfactual must be an object")
            expected = {
                "assertion_id", "classification", "statement", "provenance", "assertion_hash"
            }
            if set(item) != expected:
                raise ValueError("counterfactual has an unsupported field set")
            identifier = _identity(item.get("assertion_id"), "counterfactual identity")
            if identifier in seen or identifier < prior:
                raise ValueError("counterfactuals must be uniquely and canonically ordered")
            seen.add(identifier)
            prior = identifier
            if item.get("classification") != "USER_DECLARED_COUNTERFACTUAL_NON_AUTHORIZING":
                raise ValueError("counterfactual is not labelled user-declared/non-authorizing")
            _identity(item.get("statement"), "counterfactual statement")
            _identity(item.get("provenance"), "counterfactual provenance")
            ok, detail = _sealed(item, "assertion_hash")
            if not ok:
                raise ValueError(detail)
            forbidden = _forbidden_paths(item, "declared_counterfactuals")
            if forbidden:
                raise ValueError(f"prohibited conclusion fields: {forbidden}")
        except (CanonicalError, TypeError, ValueError) as error:
            failures.append(f"declared_counterfactuals[{index}]: {error}")
    return failures


def verify_comparative_workflow_evaluation(record: Any) -> VerificationResult:
    """Independently reconstruct a non-authorizing comparative record."""

    result = VerificationResult(
        ok=False,
        status=Status.FAILED,
        report={
            "record_type": "ComparativeWorkflowEvaluation",
            "level_attempted": "V3",
            "level_achieved": "NONE",
            "authority": AUTHORITY,
        },
    )
    if not isinstance(record, Mapping):
        result.record("comparison_shape", False, "comparative evaluation must be an object")
        return result.finish()
    artifact = dict(record)
    profile_ok = (
        artifact.get("record_type") == "ComparativeWorkflowEvaluation"
        and artifact.get("schema_version") == SCHEMA_VERSION
        and artifact.get("profile") == PROFILE
    )
    result.record(
        "comparison_registered_profile",
        profile_ok,
        f"record/schema/profile must be ComparativeWorkflowEvaluation/{SCHEMA_VERSION}/{PROFILE}",
    )
    shape_ok = set(artifact) == _TOP_LEVEL_FIELDS
    if shape_ok:
        try:
            _identity(artifact.get("evaluation_id"), "evaluation_id")
        except ValueError:
            shape_ok = False
    result.record(
        "comparison_record_shape",
        shape_ok,
        "the registered profile permits only its complete canonical field set",
    )
    ok, detail = _sealed(artifact, "record_hash")
    result.record("comparison_record_integrity", ok, detail)

    boundary_ok = (
        artifact.get("authority") == AUTHORITY
        and artifact.get("authorizing") is False
        and artifact.get("semantic_effect") == "NONE"
        and artifact.get("evidence_class") == "NON_AUTHORIZING_COMPARATIVE_PRODUCT_EVIDENCE"
        and artifact.get("claim_boundary") == CLAIM_BOUNDARY
    )
    result.record(
        "comparison_non_authorizing_boundary",
        boundary_ok,
        "authority, semantic effect, evidence class, and claim boundary are fixed",
    )

    input_hashes, input_contents, input_failures = _read_inputs(artifact.get("inputs"))
    result.record(
        "comparison_inputs_bound",
        not input_failures,
        "; ".join(input_failures) if input_failures else
        f"{len(input_hashes)} embedded inputs have independently reconstructed hashes",
    )

    scope, legal_ids, scope_failures = _read_scope(
        artifact.get("scope"), input_hashes, input_contents
    )
    result.record(
        "comparison_scope_bound",
        not scope_failures,
        "; ".join(scope_failures) if scope_failures else
        f"scope binds one {len(legal_ids)}-member legal family and completeness basis",
    )

    cases, case_failures = _read_cases(artifact.get("workload"), legal_ids)
    result.record(
        "comparison_workload_sound",
        not case_failures,
        "; ".join(case_failures) if case_failures else f"{len(cases)} workload cases reconstructed",
    )

    oracle, answers, oracle_failures = _read_oracle(artifact.get("oracle"), cases)
    result.record(
        "comparison_oracle_sound",
        not oracle_failures,
        "; ".join(oracle_failures) if oracle_failures else
        f"{len(answers)} exact oracle answers and their denominator reconstructed",
    )

    methods, method_failures = _read_methods(artifact.get("methods"), cases, answers)
    result.record(
        "comparison_methods_sound",
        not method_failures,
        "; ".join(method_failures) if method_failures else
        f"{len(methods)} named/versioned workflows and exact traces reconstructed",
    )

    reconstruction_failures: List[str] = []
    expected_results: Dict[str, dict] = {}
    expected_comparability: dict | None = None
    if cases and answers and len(methods) >= 2:
        try:
            denominators = _denominators(cases)
            for identifier in sorted(methods):
                method = methods[identifier]
                reconstructed = {
                    "method_id": identifier,
                    "method_hash": method.get("method_hash"),
                    "result_scope": {
                        "scope_hash": scope.get("scope_hash"),
                        "case_ids": sorted(cases),
                        "input_bindings": dict(input_hashes),
                        "authority": AUTHORITY,
                    },
                    "denominators": denominators,
                    "system_derived_facts": _facts(method, answers, denominators),
                }
                expected_results[identifier] = {
                    **reconstructed,
                    "result_hash": content_hash(reconstructed),
                }
            expected_comparability = _comparability(input_hashes, oracle, methods)
        except (ArithError, CanonicalError, KeyError, TypeError, ValueError) as error:
            reconstruction_failures.append(str(error))
    else:
        reconstruction_failures.append("sound workload, oracle, and at least two methods are required")

    raw_results = artifact.get("results")
    stated_results: Dict[str, dict] = {}
    if not isinstance(raw_results, list):
        reconstruction_failures.append("results must be a list")
    else:
        prior = ""
        for index, item in enumerate(raw_results):
            if not isinstance(item, dict):
                reconstruction_failures.append(f"results[{index}] must be an object")
                continue
            identifier = item.get("method_id")
            if not isinstance(identifier, str) or not identifier or identifier in stated_results:
                reconstruction_failures.append("result method identities must be unique non-empty strings")
                continue
            if identifier < prior:
                reconstruction_failures.append("results are not in canonical method order")
            prior = identifier
            ok, detail = _sealed(item, "result_hash")
            if not ok:
                reconstruction_failures.append(f"{identifier}: {detail}")
            stated_results[identifier] = item
    if set(stated_results) != set(expected_results):
        reconstruction_failures.append("results do not map one-to-one to the named methods")
    for identifier in set(stated_results) & set(expected_results):
        if stated_results[identifier] != expected_results[identifier]:
            reconstruction_failures.append(
                f"{identifier}: scope, denominators, or system-derived facts differ from reconstruction"
            )
    result.record(
        "comparison_facts_reconstructed",
        not reconstruction_failures,
        "; ".join(reconstruction_failures) if reconstruction_failures else
        "every method result, scope, denominator, and exact fact was independently reconstructed",
    )

    stated_comparability = artifact.get("comparability")
    comparability_ok = expected_comparability is not None and stated_comparability == expected_comparability
    result.record(
        "comparison_design_classification",
        comparability_ok,
        "comparability is derived only from identical inputs and matched declared budgets",
    )

    observation_failures = _verify_local_observations(
        artifact.get("local_observations"), set(methods)
    )
    result.record(
        "comparison_local_observations_separate",
        not observation_failures,
        "; ".join(observation_failures) if observation_failures else
        "local observations are separately labelled, sealed, and absent from derived facts",
    )

    counterfactual_failures = _verify_counterfactuals(artifact.get("declared_counterfactuals"))
    result.record(
        "comparison_counterfactuals_declared_only",
        not counterfactual_failures,
        "; ".join(counterfactual_failures) if counterfactual_failures else
        "counterfactuals, if any, are user-declared and non-authorizing",
    )

    limitations = artifact.get("limitations")
    limitations_ok = (
        isinstance(limitations, list)
        and bool(limitations)
        and all(isinstance(item, str) and item and item == item.strip() for item in limitations)
        and len(limitations) == len(set(limitations))
        and limitations == sorted(limitations)
    )
    result.record(
        "comparison_limitations_stated",
        limitations_ok,
        "at least one unique, canonically ordered limitation is required",
    )

    forbidden = _forbidden_paths(
        {"comparability": stated_comparability, "results": raw_results}, "comparison"
    )
    result.record(
        "comparison_no_strengthened_claim",
        not forbidden,
        f"prohibited conclusion fields: {forbidden}" if forbidden else
        "record contains no method ranking, superiority, ROI, savings, or generalization field",
    )

    result.report.update(
        {
            "comparison_status": (
                stated_comparability.get("status")
                if isinstance(stated_comparability, dict)
                else "UNKNOWN"
            ),
            "method_count": len(methods),
            "case_count": len(cases),
            "result_count": len(stated_results),
            "system_fact_count": len(expected_results),
            "claim_boundary": CLAIM_BOUNDARY,
        }
    )
    result.finish()
    if not profile_ok:
        result.status = Status.UNSUPPORTED_PROFILE
    elif result.ok:
        result.status = Status.VERIFIED_RELATIVE
        result.report["level_achieved"] = "V3"
    else:
        result.status = Status.FAILED
    return result
