"""Exact rational and interval arithmetic for the independent verifier.

Normative basis: 14.2 (numeric representations), 22.1-22.3 (enclosure,
evidence, tolerance, strict winner), 24.3 (required CRG-VIR operations).

This is a small, independent re-implementation.  It is deliberately not
``crg_model.numeric``: the verifier must be able to contradict the kernel,
and it cannot contradict arithmetic it borrowed from the kernel.  The only
dependency is ``fractions.Fraction`` from the standard library, which gives
exact rational arithmetic with no rounding at all.

An interval here is a plain ``(lo, hi)`` pair of ``Fraction``.  Tuples are
used rather than a class so that every operation in this module is visibly
total and side-effect free.
"""
from __future__ import annotations

from fractions import Fraction
from typing import Any, Iterable, Optional, Sequence, Tuple

__all__ = [
    "ArithError",
    "ZERO",
    "Interval",
    "rational",
    "interval",
    "iadd",
    "imul",
    "isub",
    "strictly_below",
    "within_tolerance",
    "weakly_dominates",
    "dominates",
    "positive_part_sup",
    "minimum",
    "fmt",
    "as_exact_json",
    "as_interval_json",
]

Interval = Tuple[Fraction, Fraction]

ZERO = Fraction(0)
ONE = Fraction(1)


class ArithError(ValueError):
    """A value is not an admissible exact number or interval."""


# ---------------------------------------------------------------------------
# decoding
# ---------------------------------------------------------------------------
def rational(value: Any) -> Fraction:
    """Decode an exact rational from any canonical CRG numeric encoding.

    Accepted: ``Fraction``; ``int``; a decimal or ``n/d`` string; ``{"exact":
    ...}``; ``{"numerator": n, "denominator": d}``.  A binary float is
    refused (14.2): admitting one would let an unbounded rounding error into
    a certificate-authorizing comparison.
    """
    if isinstance(value, Fraction):
        return value
    if isinstance(value, bool):
        raise ArithError("a boolean is not an exact number")
    if isinstance(value, int):
        return Fraction(value)
    if isinstance(value, float):
        raise ArithError(
            "binary floating point cannot authorize a comparison (spec 14.2, 22.6)"
        )
    if isinstance(value, str):
        try:
            return Fraction(value.strip())
        except (ValueError, ZeroDivisionError) as error:
            raise ArithError(f"{value!r} is not an exact rational: {error}") from error
    if isinstance(value, dict):
        if "exact" in value:
            return rational(value["exact"])
        if "value" in value and len(value) == 1:
            return rational(value["value"])
        if "numerator" in value and "denominator" in value:
            return Fraction(int(value["numerator"]), int(value["denominator"]))
    raise ArithError(f"cannot read {type(value).__name__} as an exact number")


def interval(value: Any) -> Interval:
    """Decode a closed exact interval from any canonical encoding.

    A ``DecisionValue`` record (22.2) is accepted directly: its
    ``combined_interval`` is the conservative merge the specification
    requires at decision time, so that is the field read.
    """
    if isinstance(value, dict):
        for key in ("combined_interval", "interval"):
            if key in value:
                return interval(value[key])
        if "lo" in value and "hi" in value:
            lo, hi = rational(value["lo"]), rational(value["hi"])
        elif "numerical_interval" in value:
            return interval(value["numerical_interval"])
        else:
            lo = hi = rational(value)
    elif isinstance(value, (list, tuple)):
        if len(value) != 2:
            raise ArithError("an interval given as a sequence MUST have exactly two bounds")
        lo, hi = rational(value[0]), rational(value[1])
    else:
        lo = hi = rational(value)
    if hi < lo:
        raise ArithError(f"inverted interval [{lo}, {hi}]")
    return (lo, hi)


# ---------------------------------------------------------------------------
# operations (spec 24.3)
# ---------------------------------------------------------------------------
def iadd(a: Interval, b: Interval) -> Interval:
    return (a[0] + b[0], a[1] + b[1])


def isub(a: Interval, b: Interval) -> Interval:
    return (a[0] - b[1], a[1] - b[0])


def imul(a: Interval, b: Interval) -> Interval:
    products = (a[0] * b[0], a[0] * b[1], a[1] * b[0], a[1] * b[1])
    return (min(products), max(products))


def strictly_below(a: Interval, b: Interval, tau: Fraction = ZERO) -> bool:
    """Specification 22.3: ``U_a + tau < L_b``.  Nothing weaker is a win."""
    return (a[1] + tau) < b[0]


def within_tolerance(a: Interval, b: Interval, tau: Fraction) -> bool:
    """Every admissible difference between ``a`` and ``b`` lies inside tau."""
    return (b[1] - a[0]) <= tau and (a[1] - b[0]) <= tau


def weakly_dominates(x: Sequence[Fraction], y: Sequence[Fraction]) -> bool:
    """Weak dominance in the minimize convention: ``x <= y`` coordinatewise."""
    if len(x) != len(y):
        raise ArithError("dimension mismatch in dominance test")
    return all(a <= b for a, b in zip(x, y))


def dominates(x: Sequence[Fraction], y: Sequence[Fraction]) -> bool:
    """Strict Pareto dominance: ``<=`` everywhere and ``<`` somewhere."""
    return weakly_dominates(x, y) and any(a < b for a, b in zip(x, y))


def positive_part_sup(x: Sequence[Fraction], a: Sequence[Fraction]) -> Fraction:
    """``||(x - a)^+||_inf`` -- the largest coordinatewise excess of x over a.

    Zero exactly when ``x`` weakly dominates ``a``, which is the exact test
    for ``a`` lying in the upper region generated by ``x`` (19.3).
    """
    if len(x) != len(a):
        raise ArithError("dimension mismatch")
    worst = ZERO
    for xi, ai in zip(x, a):
        excess = xi - ai
        if excess > worst:
            worst = excess
    return worst


def minimum(values: Iterable[Fraction]) -> Optional[Fraction]:
    """Exact minimum over a finite collection, or None when it is empty."""
    best: Optional[Fraction] = None
    for value in values:
        if best is None or value < best:
            best = value
    return best


# ---------------------------------------------------------------------------
# encoding
# ---------------------------------------------------------------------------
def fmt(value: Fraction) -> str:
    return str(value.numerator) if value.denominator == 1 else f"{value.numerator}/{value.denominator}"


def as_exact_json(value: Fraction) -> dict:
    return {"exact": fmt(value)}


def as_interval_json(value: Interval) -> dict:
    return {"lo": as_exact_json(value[0]), "hi": as_exact_json(value[1])}
