"""Independent checks for portable registry-intake records.

This module imports no producer, model, IO, CLI, server, or Studio package.  It
reconstructs the fixed non-authorizing intake policies, exact coordinate
orientation, explicit-family completeness, predicted registry bundle, and the
confirmation bindings from decoded JSON alone.

Raw source bytes are deliberately not embedded in a portable case.  Their
digest and byte length are therefore *bindings*, not independently reproduced
facts.  The verification report says so explicitly; it never turns absence of
the source into an affirmative source-content claim.
"""
from __future__ import annotations

from fractions import Fraction
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from .arith import ArithError, rational
from .canonical import CanonicalError, content_hash, is_hash
from .certificate import Status, VerificationResult

__all__ = [
    "verify_registry_mapping_profile",
    "verify_registry_source_snapshot",
    "verify_registry_intake_preview",
    "verify_registry_intake_confirmation",
]

SCHEMA_VERSION = "1.0.0"
IMPORTER = "crg-io.registry-intake@1.1.0"
NUMERIC_PROFILE = "CRG_EXACT_RATIONAL"
AUTHORITY = "NON_AUTHORIZING_INTAKE"
PREVIEW_AUTHORITY = "NON_AUTHORIZING"
CLAIM_SCOPE = "RELATIVE_EXPLICIT_FAMILY"
COMPLETENESS = "EXPLICIT_IMPORTED_FAMILY"
_DIRECTIONS = frozenset({"MINIMIZE", "MAXIMIZE"})
_EVIDENCE = frozenset(
    {"EXACT", "CONSTRUCTIVE", "BOUNDED", "MEASURED", "MODELED", "IMPORTED", "DECLARED", "HEURISTIC"}
)
_LEGALITY = frozenset({"LEGAL", "INFEASIBLE", "UNEVALUATED"})
_POLICIES = {
    "completeness": COMPLETENESS,
    "duplicate_identity": "REJECT_EVERY_OCCURRENCE_AFTER_FIRST",
    "unknown_fields": "REPORT_UNSUPPORTED",
    "unit_conversion": "NONE",
    "missing_feasibility": "KEEP_UNEVALUATED",
    "authority": AUTHORITY,
}


class _DecodeError(ValueError):
    pass


class _UnsupportedProfile(_DecodeError):
    pass


def _object(value: Any, where: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise _DecodeError(f"{where} must be an object")
    return value


def _array(value: Any, where: str) -> Sequence[Any]:
    if not isinstance(value, (list, tuple)):
        raise _DecodeError(f"{where} must be an array")
    return value


def _string(value: Any, where: str) -> str:
    if not isinstance(value, str) or not value or value != value.strip() or "\x00" in value:
        raise _DecodeError(f"{where} must be a normalized non-empty string")
    return value


def _integer(value: Any, where: str, *, minimum: int = 0) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise _DecodeError(f"{where} must be an integer at least {minimum}")
    return value


def _boolean(value: Any, where: str) -> bool:
    if not isinstance(value, bool):
        raise _DecodeError(f"{where} must be a boolean")
    return value


def _keys(value: Mapping[str, Any], required: Iterable[str], optional: Iterable[str], where: str) -> None:
    required_set = set(required)
    allowed = required_set | set(optional)
    missing = required_set - set(value)
    unknown = set(value) - allowed
    if missing:
        raise _DecodeError(f"{where} is missing fields {sorted(missing)}")
    if unknown:
        raise _DecodeError(f"{where} has unsupported fields {sorted(unknown)}")


def _hash(value: Any, where: str) -> str:
    if not is_hash(value):
        raise _DecodeError(f"{where} must be an algorithm-tagged SHA-256 hash")
    return str(value)


def _exact(value: Any, where: str) -> Fraction:
    try:
        number = rational(value)
    except (ArithError, TypeError, ValueError, ZeroDivisionError) as error:
        raise _DecodeError(f"{where} must be a canonical exact rational") from error
    canonical = {
        "exact": str(number.numerator)
        if number.denominator == 1
        else f"{number.numerator}/{number.denominator}"
    }
    if value != canonical:
        raise _DecodeError(f"{where} is not in canonical exact-rational form")
    return number


def _hashable(value: Any, where: str) -> str:
    try:
        return content_hash(value)
    except (CanonicalError, TypeError, ValueError) as error:
        raise _DecodeError(f"{where} is not canonical hashable content: {error}") from error


def _result(record_type: str, operation) -> VerificationResult:
    result = VerificationResult(ok=False)
    try:
        checks, report = operation()
    except _UnsupportedProfile as error:
        result.record("supported_profile", False, str(error))
        result.status = Status.UNSUPPORTED_PROFILE
        result.report.update({"record_type": record_type, "authorization_effect": "NONE"})
        return result.finish()
    except (_DecodeError, CanonicalError, ArithError, TypeError, ValueError) as error:
        result.record("portable_intake_record", False, str(error))
        result.status = Status.FAILED
        result.report.update({"record_type": record_type, "authorization_effect": "NONE"})
        return result.finish()
    for name, passed, detail in checks:
        result.record(name, passed, detail)
    result.status = Status.VERIFIED_RELATIVE if not result.violations else Status.FAILED
    result.report.update(
        {
            "record_type": record_type,
            "claim_scope": CLAIM_SCOPE,
            "authorization_effect": "NONE",
            "semantic_effect": "NONE",
            **report,
        }
    )
    return result.finish()


def _profile(record: Mapping[str, Any]) -> Tuple[dict, List[Tuple[str, bool, str]]]:
    required = {
        "record_type", "schema_version", "profile_id", "profile_version",
        "source_format", "record_path", "identity_field", "coordinates",
        "attributes", "quantity_registry_version", "default_evidence_class", "policies",
    }
    optional = {"evidence_field", "feasibility_field"}
    _keys(record, required, optional, "mapping profile")
    if record.get("record_type") != "RegistryMappingProfile":
        raise _DecodeError("mapping profile record_type is unsupported")
    if record.get("schema_version") != SCHEMA_VERSION:
        raise _UnsupportedProfile(
            f"unsupported RegistryMappingProfile schema {record.get('schema_version')!r}"
        )
    for name in ("profile_id", "profile_version", "identity_field"):
        _string(record.get(name), f"mapping profile {name}")
    source_format = record.get("source_format")
    if source_format not in {"csv", "json"}:
        raise _DecodeError("mapping profile source_format must be csv or json")
    path = _string(record.get("record_path"), "mapping profile record_path")
    if source_format == "csv" and path != "$rows":
        raise _DecodeError("CSV mapping profile record_path must be '$rows'")
    _hash(record.get("quantity_registry_version"), "quantity_registry_version")
    if record.get("default_evidence_class") not in _EVIDENCE:
        raise _DecodeError("default_evidence_class is unsupported")
    if record.get("policies") != _POLICIES:
        raise _DecodeError("mapping profile safety policies differ from the registered profile")
    for optional_name in ("evidence_field", "feasibility_field"):
        if optional_name in record:
            _string(record[optional_name], f"mapping profile {optional_name}")

    coordinates = _array(record.get("coordinates"), "mapping profile coordinates")
    if not coordinates:
        raise _DecodeError("mapping profile must declare at least one coordinate")
    coordinate_ids: List[str] = []
    value_fields: List[str] = []
    normalized_coordinates: List[dict] = []
    for index, raw in enumerate(coordinates):
        item = _object(raw, f"coordinates[{index}]")
        required_coordinate = {
            "source_field", "coordinate_id", "quantity", "unit", "direction", "numeric_profile"
        }
        _keys(item, required_coordinate, {"unit_field", "evidence_field"}, f"coordinates[{index}]")
        for name in ("source_field", "coordinate_id", "quantity", "unit"):
            _string(item.get(name), f"coordinates[{index}].{name}")
        if item.get("direction") not in _DIRECTIONS:
            raise _DecodeError(f"coordinates[{index}] has an unsupported direction")
        if item.get("numeric_profile") != NUMERIC_PROFILE:
            raise _UnsupportedProfile(
                f"coordinates[{index}] uses unsupported numeric profile {item.get('numeric_profile')!r}"
            )
        for name in ("unit_field", "evidence_field"):
            if name in item:
                _string(item[name], f"coordinates[{index}].{name}")
        coordinate_ids.append(str(item["coordinate_id"]))
        value_fields.append(str(item["source_field"]))
        normalized_coordinates.append(dict(item))
    if len(set(coordinate_ids)) != len(coordinate_ids):
        raise _DecodeError("mapping profile repeats a coordinate identity")
    if len(set(value_fields)) != len(value_fields):
        raise _DecodeError("mapping profile repeats a coordinate source field")

    attributes = _array(record.get("attributes"), "mapping profile attributes")
    attribute_ids: List[str] = []
    attribute_fields: List[str] = []
    for index, raw in enumerate(attributes):
        item = _object(raw, f"attributes[{index}]")
        _keys(item, {"source_field", "attribute_id", "required"}, set(), f"attributes[{index}]")
        attribute_fields.append(_string(item.get("source_field"), f"attributes[{index}].source_field"))
        attribute_ids.append(_string(item.get("attribute_id"), f"attributes[{index}].attribute_id"))
        _boolean(item.get("required"), f"attributes[{index}].required")
    if len(set(attribute_ids)) != len(attribute_ids) or len(set(attribute_fields)) != len(attribute_fields):
        raise _DecodeError("mapping profile repeats an attribute identity or source field")
    semantic_fields = [str(record["identity_field"]), *value_fields, *attribute_fields]
    if len(set(semantic_fields)) != len(semantic_fields):
        raise _DecodeError("identity, coordinate, and attribute source fields are not disjoint")

    checks = [
        ("fixed_intake_policies", True, "completeness, duplicate, unknown-field, unit, and authority policies are fixed"),
        ("mapping_field_separation", True, "identity, coordinate, and attribute value fields are explicit and disjoint"),
        ("quantity_registry_binding", True, "mapping profile carries a governed quantity-registry content hash"),
    ]
    return dict(record), checks


def verify_registry_mapping_profile(record: Mapping[str, Any]) -> VerificationResult:
    """Verify a portable mapping declaration without importing ``crg_io``."""
    def operation():
        profile, checks = _profile(_object(record, "mapping profile"))
        return checks, {"profile_hash": _hashable(profile, "mapping profile")}

    return _result("RegistryMappingProfile", operation)


_SNAPSHOT_PAYLOAD = {
    "provenance", "source_format", "media_type", "content_hash",
    "byte_length", "record_count", "source_fields",
}


def _snapshot_payload(record: Mapping[str, Any], *, wrapped: bool) -> Tuple[dict, List[Tuple[str, bool, str]]]:
    if wrapped:
        _keys(
            record,
            _SNAPSHOT_PAYLOAD | {"record_type", "schema_version", "authority", "producer_snapshot_hash"},
            set(),
            "source snapshot record",
        )
        if record.get("record_type") != "RegistrySourceSnapshot":
            raise _DecodeError("source snapshot record_type is unsupported")
        if record.get("schema_version") != SCHEMA_VERSION:
            raise _UnsupportedProfile(
                f"unsupported RegistrySourceSnapshot schema {record.get('schema_version')!r}"
            )
        if record.get("authority") != AUTHORITY:
            raise _DecodeError("source snapshot authority is not NON_AUTHORIZING_INTAKE")
    else:
        _keys(record, _SNAPSHOT_PAYLOAD, set(), "preview source snapshot")
    provenance = _object(record.get("provenance"), "source snapshot provenance")
    _keys(provenance, {"source_id", "source_name", "origin"}, {"producer", "source_version"}, "source provenance")
    for name, value in provenance.items():
        _string(value, f"source provenance {name}")
    source_format = record.get("source_format")
    if source_format not in {"csv", "json"}:
        raise _DecodeError("source snapshot format must be csv or json")
    expected_media = "text/csv" if source_format == "csv" else "application/json"
    if record.get("media_type") != expected_media:
        raise _DecodeError("source snapshot media type disagrees with its format")
    _hash(record.get("content_hash"), "source snapshot content hash")
    _integer(record.get("byte_length"), "source snapshot byte_length")
    _integer(record.get("record_count"), "source snapshot record_count")
    fields = [_string(value, "source snapshot field") for value in _array(record.get("source_fields"), "source fields")]
    if len(fields) != len(set(fields)):
        raise _DecodeError("source snapshot repeats a source field")
    payload = {name: record[name] for name in _SNAPSHOT_PAYLOAD}
    payload_hash = _hashable(payload, "source snapshot payload")
    checks = [
        ("source_snapshot_structure", True, "source identity, media type, fingerprint, byte count, row count, and fields are explicit"),
    ]
    if wrapped:
        stated = _hash(record.get("producer_snapshot_hash"), "producer_snapshot_hash")
        checks.append(("producer_snapshot_hash", stated == payload_hash, f"stated {stated}; recomputed {payload_hash}"))
    return payload, checks


def verify_registry_source_snapshot(record: Mapping[str, Any]) -> VerificationResult:
    """Verify the typed wrapper while disclosing that source bytes are absent."""
    def operation():
        payload, checks = _snapshot_payload(_object(record, "source snapshot record"), wrapped=True)
        checks.append((
            "source_bytes_not_claimed",
            True,
            "the portable record binds source bytes by digest and length; it does not claim they were carried or re-read",
        ))
        return checks, {
            "producer_snapshot_hash": _hashable(payload, "source snapshot payload"),
            "source_content_recomputed": False,
        }

    return _result("RegistrySourceSnapshot", operation)


def _diagnostics(value: Any, where: str, *, accepted: bool) -> None:
    for index, raw in enumerate(_array(value, where)):
        item = _object(raw, f"{where}[{index}]")
        _keys(item, {"code", "severity", "message"}, {"field", "coordinate_id"}, f"{where}[{index}]")
        _string(item.get("code"), f"{where}[{index}].code")
        _string(item.get("message"), f"{where}[{index}].message")
        severity = item.get("severity")
        if severity not in {"ERROR", "WARNING", "INFO"}:
            raise _DecodeError(f"{where}[{index}] has unsupported diagnostic severity")
        if accepted and severity == "ERROR":
            raise _DecodeError(f"{where}[{index}] marks an accepted row with an error")


def _preview(record: Mapping[str, Any]) -> Tuple[dict, dict, List[Tuple[str, bool, str]]]:
    required = {
        "record_type", "schema_version", "authority", "mutation_performed",
        "profile", "profile_hash", "source_snapshot", "source_snapshot_hash",
        "rows_read", "accepted", "rejected", "diagnostics", "completeness_basis",
        "claim_scope", "ready_to_materialize", "predicted_bundle_hash",
    }
    _keys(record, required, set(), "registry intake preview")
    if record.get("record_type") != "RegistryIntakePreview":
        raise _DecodeError("registry intake preview record_type is unsupported")
    if record.get("schema_version") != SCHEMA_VERSION:
        raise _UnsupportedProfile(
            f"unsupported RegistryIntakePreview schema {record.get('schema_version')!r}"
        )
    if record.get("authority") != PREVIEW_AUTHORITY or record.get("mutation_performed") is not False:
        raise _DecodeError("intake preview must be non-authorizing and non-mutating")
    profile, profile_checks = _profile(_object(record.get("profile"), "preview profile"))
    profile_hash = _hashable(profile, "preview profile")
    stated_profile_hash = _hash(record.get("profile_hash"), "preview profile_hash")
    snapshot, snapshot_checks = _snapshot_payload(
        _object(record.get("source_snapshot"), "preview source snapshot"), wrapped=False
    )
    snapshot_hash = _hashable(snapshot, "preview source snapshot")
    stated_snapshot_hash = _hash(record.get("source_snapshot_hash"), "preview source_snapshot_hash")
    rows_read = _integer(record.get("rows_read"), "preview rows_read")
    if rows_read != snapshot["record_count"]:
        raise _DecodeError("preview row count differs from its source snapshot")

    mappings = list(profile["coordinates"])
    accepted = _array(record.get("accepted"), "preview accepted")
    rejected = _array(record.get("rejected"), "preview rejected")
    row_numbers: List[int] = []
    realization_ids: List[str] = []
    canonical_rows: List[dict] = []
    for index, raw in enumerate(accepted):
        row = _object(raw, f"accepted[{index}]")
        _keys(
            row,
            {"source_row_number", "realization_id", "coordinates", "legality", "evidence_class", "attributes", "diagnostics"},
            set(),
            f"accepted[{index}]",
        )
        row_numbers.append(_integer(row.get("source_row_number"), f"accepted[{index}].source_row_number", minimum=1))
        realization_ids.append(_string(row.get("realization_id"), f"accepted[{index}].realization_id"))
        if row.get("legality") not in _LEGALITY or row.get("evidence_class") not in _EVIDENCE:
            raise _DecodeError(f"accepted[{index}] has unsupported legality or evidence")
        attributes = _object(row.get("attributes"), f"accepted[{index}].attributes")
        coordinates = _array(row.get("coordinates"), f"accepted[{index}].coordinates")
        if len(coordinates) != len(mappings):
            raise _DecodeError(f"accepted[{index}] coordinate count differs from the mapping")
        values: List[dict] = []
        coordinate_evidence: Dict[str, str] = {}
        evidence_values = set()
        for coordinate_index, (raw_coordinate, mapping) in enumerate(zip(coordinates, mappings)):
            coordinate = _object(raw_coordinate, f"accepted[{index}].coordinates[{coordinate_index}]")
            _keys(
                coordinate,
                {"coordinate_id", "source_field", "quantity", "unit", "direction", "source_value", "canonical_minimize_value", "orientation", "evidence_class"},
                set(),
                f"accepted[{index}].coordinates[{coordinate_index}]",
            )
            for name in ("coordinate_id", "source_field", "quantity", "unit", "direction"):
                if coordinate.get(name) != mapping.get(name):
                    raise _DecodeError(
                        f"accepted[{index}].coordinates[{coordinate_index}] disagrees with mapping field {name}"
                    )
            source = _exact(coordinate.get("source_value"), "source coordinate value")
            canonical = _exact(coordinate.get("canonical_minimize_value"), "canonical coordinate value")
            expected = -source if mapping["direction"] == "MAXIMIZE" else source
            expected_orientation = (
                "NEGATED_INTO_MINIMIZE_CONVENTION"
                if mapping["direction"] == "MAXIMIZE" else "AS_DECLARED"
            )
            if canonical != expected or coordinate.get("orientation") != expected_orientation:
                raise _DecodeError("coordinate orientation is not the registered minimize normalization")
            evidence = coordinate.get("evidence_class")
            if evidence not in _EVIDENCE:
                raise _DecodeError("coordinate evidence class is unsupported")
            evidence_values.add(evidence)
            coordinate_evidence[str(mapping["coordinate_id"])] = str(evidence)
            values.append(dict(coordinate["canonical_minimize_value"]))
        expected_row_evidence = next(iter(evidence_values)) if len(evidence_values) == 1 else "IMPORTED"
        if row.get("evidence_class") != expected_row_evidence:
            raise _DecodeError("accepted row evidence class is inconsistent with coordinate evidence")
        _diagnostics(row.get("diagnostics"), f"accepted[{index}].diagnostics", accepted=True)
        enriched_attributes = dict(attributes)
        enriched_attributes["source_provenance"] = {
            **dict(snapshot["provenance"]),
            "source_fingerprint": snapshot["content_hash"],
            "source_row_number": row["source_row_number"],
            "mapping_profile_hash": profile_hash,
        }
        enriched_attributes["coordinate_evidence_classes"] = coordinate_evidence
        realization = {
            "realization_id": row["realization_id"],
            "signature": values,
            "legality": row["legality"],
            "evidence_class": row["evidence_class"],
            "generator": IMPORTER,
        }
        if enriched_attributes:
            realization["attributes"] = enriched_attributes
        canonical_rows.append(realization)
    if len(realization_ids) != len(set(realization_ids)):
        raise _DecodeError("preview repeats an accepted realization identity")

    rejected_rows: List[dict] = []
    for index, raw in enumerate(rejected):
        row = _object(raw, f"rejected[{index}]")
        _keys(row, {"source_row_number", "diagnostics"}, {"realization_id"}, f"rejected[{index}]")
        row_numbers.append(_integer(row.get("source_row_number"), f"rejected[{index}].source_row_number", minimum=1))
        if "realization_id" in row:
            _string(row["realization_id"], f"rejected[{index}].realization_id")
        _diagnostics(row.get("diagnostics"), f"rejected[{index}].diagnostics", accepted=False)
        if not any(item.get("severity") == "ERROR" for item in row["diagnostics"] if isinstance(item, Mapping)):
            raise _DecodeError(f"rejected[{index}] has no error diagnostic")
        rejected_rows.append(dict(row))
    if len(row_numbers) != len(set(row_numbers)) or len(row_numbers) != rows_read:
        raise _DecodeError("accepted/rejected row accounting does not cover each source record exactly once")
    _diagnostics(record.get("diagnostics"), "preview diagnostics", accepted=True)

    completeness = _object(record.get("completeness_basis"), "preview completeness basis")
    if completeness.get("basis_type") != COMPLETENESS:
        raise _DecodeError("intake preview attempts to strengthen imported-family completeness")
    if completeness.get("source_or_generator_hash") != snapshot["content_hash"]:
        raise _DecodeError("completeness basis is not bound to the source fingerprint")
    versions = completeness.get("generator_versions")
    if not isinstance(versions, list) or IMPORTER not in versions or f"mapping-profile:{profile_hash}" not in versions:
        raise _DecodeError("completeness basis omits importer or mapping-profile identity")
    if record.get("claim_scope") != CLAIM_SCOPE:
        raise _DecodeError("intake preview claim scope is not relative to the explicit family")
    ready = bool(accepted) and not rejected
    if record.get("ready_to_materialize") is not ready:
        raise _DecodeError("ready_to_materialize disagrees with accepted/rejected rows")

    binding_hash = _hashable(
        {"source_fingerprint": snapshot["content_hash"], "mapping_profile_hash": profile_hash},
        "intake binding",
    )
    bundle = {
        "bundle_id": "registry-" + binding_hash.split(":", 1)[1][:20],
        "schema": {
            "coordinates": [
                {
                    "identifier": mapping["coordinate_id"],
                    "quantity": mapping["quantity"],
                    "unit": mapping["unit"],
                    "direction": mapping["direction"],
                }
                for mapping in mappings
            ]
        },
        "realizations": sorted(canonical_rows, key=lambda item: item["realization_id"]),
        "completeness": dict(completeness),
        "source_fingerprint": snapshot["content_hash"],
    }
    if rejected_rows:
        bundle["rejected"] = rejected_rows
    bundle_hash = _hashable(bundle, "previewed registry bundle")
    stated_bundle_hash = _hash(record.get("predicted_bundle_hash"), "predicted_bundle_hash")
    checks = [
        *profile_checks,
        *snapshot_checks,
        ("profile_hash", stated_profile_hash == profile_hash, f"stated {stated_profile_hash}; recomputed {profile_hash}"),
        ("source_snapshot_hash", stated_snapshot_hash == snapshot_hash, f"stated {stated_snapshot_hash}; recomputed {snapshot_hash}"),
        ("exact_orientation", True, "every accepted coordinate is exact and normalized from its declared direction"),
        ("row_accounting", True, f"{len(accepted)} accepted + {len(rejected)} rejected = {rows_read} source records"),
        ("explicit_family_only", True, "completeness and claim scope remain relative to the supplied accepted rows"),
        ("predicted_registry_hash", stated_bundle_hash == bundle_hash, f"stated {stated_bundle_hash}; reconstructed {bundle_hash}"),
    ]
    return dict(record), bundle, checks


def verify_registry_intake_preview(record: Mapping[str, Any]) -> VerificationResult:
    """Reconstruct a preview and its predicted exact registry."""
    def operation():
        preview, bundle, checks = _preview(_object(record, "registry intake preview"))
        return checks, {
            "preview_hash": _hashable(preview, "registry intake preview"),
            "predicted_bundle_hash": _hashable(bundle, "previewed registry bundle"),
            "source_content_recomputed": False,
        }

    return _result("RegistryIntakePreview", operation)


def _expected_import_report(
    profile: Mapping[str, Any],
    preview: Mapping[str, Any],
    registry: Mapping[str, Any],
) -> dict:
    """Reconstruct the registered intake report from portable source facts."""
    profile_hash = content_hash(profile)
    snapshot = _object(preview.get("source_snapshot"), "report source snapshot")
    provenance = _object(snapshot.get("provenance"), "report source provenance")
    field_mapping: Dict[str, str] = {
        str(profile["identity_field"]): "realization_id"
    }
    coordinate_mapping: Dict[str, dict] = {}
    quantity_mappings: Dict[str, str] = {}
    for raw in profile["coordinates"]:
        mapping = _object(raw, "report coordinate mapping")
        source_field = str(mapping["source_field"])
        coordinate_id = str(mapping["coordinate_id"])
        direction = str(mapping["direction"])
        field_mapping[source_field] = f"signature.{coordinate_id}"
        coordinate_mapping[source_field] = {
            "coordinate": coordinate_id,
            "quantity": mapping["quantity"],
            "unit": mapping["unit"],
            "direction": direction,
            "orientation": (
                "NEGATED_INTO_MINIMIZE_CONVENTION"
                if direction == "MAXIMIZE"
                else "AS_DECLARED"
            ),
            "numeric_profile": mapping["numeric_profile"],
        }
        quantity_mappings[coordinate_id] = (
            f"{mapping['quantity']} [{mapping['unit']}]"
        )
        if mapping.get("unit_field") is not None:
            field_mapping[str(mapping["unit_field"])] = f"unit.{coordinate_id}"
        if mapping.get("evidence_field") is not None:
            field_mapping[str(mapping["evidence_field"])] = (
                f"evidence.{coordinate_id}"
            )
    if profile.get("evidence_field") is not None:
        field_mapping[str(profile["evidence_field"])] = "evidence.*"
    if profile.get("feasibility_field") is not None:
        field_mapping[str(profile["feasibility_field"])] = "legality"
    for raw in profile["attributes"]:
        mapping = _object(raw, "report attribute mapping")
        field_mapping[str(mapping["source_field"])] = (
            f"attributes.{mapping['attribute_id']}"
        )

    global_diagnostics = list(preview["diagnostics"])
    unknown = [
        str(item["field"])
        for item in global_diagnostics
        if isinstance(item, Mapping)
        and item.get("code") == "UNKNOWN_FIELD"
        and item.get("field") is not None
    ]
    rejected = []
    for raw in preview["rejected"]:
        row = _object(raw, "report rejected row")
        diagnostics = list(row["diagnostics"])
        record = {
            "row_number": row["source_row_number"],
            "reason": "; ".join(str(item["message"]) for item in diagnostics),
        }
        if row.get("realization_id"):
            record["realization_id"] = row["realization_id"]
        column = next(
            (
                item.get("field")
                for item in diagnostics
                if isinstance(item, Mapping) and item.get("field")
            ),
            None,
        )
        if column is not None:
            record["column"] = column
        rejected.append(record)

    row_diagnostics = [
        item
        for row in preview["accepted"]
        for item in row["diagnostics"]
    ]
    warnings = [str(item["message"]) for item in global_diagnostics]
    warnings.extend(str(item["message"]) for item in row_diagnostics)
    if rejected:
        warnings.append(
            f"{len(rejected)} source row(s) were refused and remain disclosed"
        )
    missing_evidence = [
        str(item["message"])
        for item in row_diagnostics
        if item.get("code") in {"MISSING_EVIDENCE_DEFAULTED", "MISSING_FEASIBILITY"}
    ]
    return {
        "source_path": provenance["source_name"],
        "source_fingerprint": snapshot["content_hash"],
        "importer": {"id": "crg-io.registry-intake", "version": "1.1.0"},
        "rows_read": preview["rows_read"],
        "accepted": [row["realization_id"] for row in preview["accepted"]],
        "rejected": rejected,
        "field_mapping": field_mapping,
        "coordinate_mapping": coordinate_mapping,
        "quantity_mappings": quantity_mappings,
        "unit_conversions": [
            "none applied; every mapped source unit must exactly equal its governed declared unit"
        ],
        "dropped_fields": unknown,
        "unsupported_fields": unknown,
        "duplicate_handling": "REJECT_EVERY_OCCURRENCE_AFTER_FIRST",
        "identity_policy": (
            f"explicit field {profile['identity_field']!r}; exact text or integer, "
            "non-empty, case-sensitive, unique after surrounding-whitespace removal"
        ),
        "missing_evidence": missing_evidence,
        "inferred_fields": [
            "none; all identity, coordinate, quantity, unit, direction, numeric, and "
            "evidence semantics are declared by the mapping profile"
        ],
        "user_overrides": [f"mapping_profile_hash = {profile_hash}"],
        "warnings": warnings,
        "completeness_basis": dict(preview["completeness_basis"]),
        "claim_scope": CLAIM_SCOPE,
        "canonical_output_hash": content_hash(registry),
        "bundle_id": registry["bundle_id"],
    }


def verify_registry_intake_confirmation(
    confirmation: Mapping[str, Any],
    profile: Mapping[str, Any],
    source_snapshot_record: Mapping[str, Any],
    preview: Mapping[str, Any],
    *,
    registry: Optional[Mapping[str, Any]] = None,
    import_report: Optional[Mapping[str, Any]] = None,
) -> VerificationResult:
    """Verify confirmation lineage and, when carried, registry/report outputs."""
    def operation():
        record = _object(confirmation, "registry intake confirmation")
        _keys(
            record,
            {
                "record_type", "schema_version", "authority", "mutation_performed",
                "expected_preview_hash", "actual_preview_hash", "profile_hash",
                "source_snapshot_hash", "source_snapshot_record_hash", "source_fingerprint",
                "bundle_id", "bundle_hash", "import_report_hash", "accepted_rows",
                "rejected_rows", "partial_import_acknowledged", "completeness_basis", "claim_scope",
            },
            set(),
            "registry intake confirmation",
        )
        if record.get("record_type") != "RegistryIntakeConfirmation":
            raise _DecodeError("registry intake confirmation record_type is unsupported")
        if record.get("schema_version") != SCHEMA_VERSION:
            raise _UnsupportedProfile(
                f"unsupported RegistryIntakeConfirmation schema {record.get('schema_version')!r}"
            )
        if record.get("authority") != AUTHORITY or record.get("mutation_performed") is not True:
            raise _DecodeError("confirmation must record mutation without acquiring decision authority")
        parsed_profile, profile_checks = _profile(_object(profile, "confirmation mapping profile"))
        snapshot_payload, snapshot_checks = _snapshot_payload(
            _object(source_snapshot_record, "confirmation source snapshot"), wrapped=True
        )
        parsed_preview, predicted_registry, preview_checks = _preview(
            _object(preview, "confirmation preview")
        )
        profile_hash = _hashable(parsed_profile, "confirmation mapping profile")
        snapshot_hash = _hashable(snapshot_payload, "confirmation producer snapshot")
        snapshot_record_hash = _hashable(source_snapshot_record, "confirmation source snapshot record")
        preview_hash = _hashable(parsed_preview, "confirmation preview")
        accepted = len(parsed_preview["accepted"])
        rejected = len(parsed_preview["rejected"])
        checks = [
            *profile_checks,
            *snapshot_checks,
            *preview_checks,
            ("preview_review_binding", record.get("expected_preview_hash") == preview_hash == record.get("actual_preview_hash"), "expected, actual, and reconstructed preview hashes agree"),
            ("profile_record_binding", record.get("profile_hash") == profile_hash == parsed_preview.get("profile_hash"), "profile record, preview, and confirmation agree"),
            ("source_snapshot_binding", record.get("source_snapshot_hash") == snapshot_hash == parsed_preview.get("source_snapshot_hash"), "producer snapshot, preview, and confirmation agree"),
            ("typed_source_snapshot_binding", record.get("source_snapshot_record_hash") == snapshot_record_hash, "confirmation binds the typed portable source snapshot"),
            ("source_fingerprint_binding", record.get("source_fingerprint") == snapshot_payload.get("content_hash"), "confirmation binds the declared source fingerprint"),
            ("row_count_binding", record.get("accepted_rows") == accepted and record.get("rejected_rows") == rejected, "confirmation row counts agree with preview dispositions"),
            ("completeness_binding", record.get("completeness_basis") == parsed_preview.get("completeness_basis") and record.get("claim_scope") == CLAIM_SCOPE, "confirmation preserves explicit-family completeness and relative scope"),
            ("partial_import_acknowledgement", rejected == 0 or record.get("partial_import_acknowledged") is True, "every persisted rejected row is explicitly acknowledged"),
            ("bundle_identity_binding", record.get("bundle_id") == predicted_registry.get("bundle_id"), "confirmation bundle identity is reconstructed from source and mapping"),
            ("bundle_hash_binding", record.get("bundle_hash") == _hashable(predicted_registry, "predicted registry"), "confirmation bundle hash matches reconstructed preview output"),
        ]
        if registry is None:
            checks.append((
                "materialized_registry_not_carried",
                True,
                "the confirmation is internally reconstructed, but no materialized registry object was supplied for byte-level comparison",
            ))
            registry_checked = False
        else:
            actual_registry = _object(registry, "materialized registry")
            actual_hash = _hashable(actual_registry, "materialized registry")
            checks.append(("materialized_registry", actual_registry == predicted_registry and record.get("bundle_hash") == actual_hash, f"materialized registry hashes to {actual_hash}"))
            registry_checked = True
        if import_report is None:
            checks.append((
                "import_report_not_carried",
                True,
                "the confirmation binds an import-report hash, but no report object was supplied for reconstruction",
            ))
            report_checked = False
        else:
            actual_report = _object(import_report, "import report")
            actual_report_hash = _hashable(actual_report, "import report")
            expected_report = _expected_import_report(
                parsed_profile, parsed_preview, predicted_registry
            )
            checks.extend(
                (
                    (
                        "import_report",
                        record.get("import_report_hash") == actual_report_hash,
                        f"materialized report hashes to {actual_report_hash}",
                    ),
                    (
                        "import_report_semantics",
                        dict(actual_report) == expected_report,
                        "the exact report is reconstructed from mapping, preview, and registry",
                    ),
                )
            )
            report_checked = True
        return checks, {
            "confirmation_hash": _hashable(record, "registry intake confirmation"),
            "preview_hash": preview_hash,
            "materialized_registry_checked": registry_checked,
            "import_report_checked": report_checked,
            "source_content_recomputed": False,
        }

    return _result("RegistryIntakeConfirmation", operation)
