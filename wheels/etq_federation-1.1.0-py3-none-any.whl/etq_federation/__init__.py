"""etq-federation: selective revalidation and confidential proof (OID-ETQ-003).

Reference implementation of master specification section 35, resting on
:mod:`crg_model` (exact numerics, canonical hashing, the typed dependency
graph of section 18) and :mod:`etq_evidence` (bounded coordinates,
applicability rules, and the clock discipline of section 45).

This is the module that lets an organization answer a question about its
technology without disclosing the technology.  Four refusals define it.

**The default release is the minimum authorized (35.3).**  Six output forms
are permitted -- Boolean, bounded interval, quantized margin, possible-or-
guaranteed state, ambiguity result, and no result -- and a policy that
authorizes several and names no default gets the least disclosing one.
That default *is* the security property, so the ordering it depends on is
declared explicitly as :data:`ReleaseKind.INFORMATION_ORDER` rather than
left to intuition, and combining an issuer's policy with a verifier's can
only narrow disclosure, never widen it.

**Failure is closed and specific (35.4).**  All nine conditions the
specification lists deny an affirmative result, and each carries its own
reason code, because a stale nonce, an expired rule, and a forged signature
have three different remedies.  A denied evaluation returns ``NO_RESULT``
with every value field empty -- never ``False``, which a recipient could
misread as a refutation.  Replayed nonces are caught; a verifier with no
nonce ledger reports ``replay_checked=False`` rather than implying it
checked.

**Attestation says only what it proves (35.4).**  An attestation proves
that identified code processed committed inputs.  It does not prove that
the underlying evidence is scientifically accurate.  That limit is carried
as data on :class:`AttestationRecord` and on every
:class:`PrivateEvaluationResult`, and the record refuses to be constructed
with the disclaimer removed, so a consumer holding only the result object
still cannot read more into it than the specification permits.

**Revalidation is selective (35.1).**  A changed evidence record
invalidates only reachable descendants whose typed edge semantics indicate
dependence on the changed property.  Certificates outside the affected
subgraph are listed as *preserved*, by name, because that list is the whole
point: a correction on one branch must not force a partner to re-verify an
unrelated one.

.. warning::

   The signature backend is a clearly-labelled test profile,
   ``SIGNATURE_PROFILE = "HMAC-SHA256-TEST"``.  It is a symmetric MAC, so a
   verifier holding the key can forge envelopes, and it cannot support the
   cross-organizational verification this module exists for.  Specification
   14.5 requires Ed25519 over canonical manifests for the baseline portable
   profile; see :mod:`etq_federation.signing` for what a production
   deployment must replace.
"""
from .signing import (
    ATTESTATION_DOES_NOT_PROVE,
    ATTESTATION_PROVES,
    ATTESTATION_SCOPE_STATEMENT,
    PRODUCTION_PROFILE_WARNING,
    PRODUCTION_SIGNATURE_PROFILE,
    REQUIRED_ATTESTATION_DISCLAIMER,
    SIGNATURE_ALGORITHM,
    SIGNATURE_PROFILE,
    AttestationRecord,
    EnvelopeSignature,
    KeyRing,
    SigningError,
    SigningKey,
    sign_payload,
    verify_payload,
)
from .policy import PolicyError, ReleaseKind, ReleasePolicy
from .revocation import (
    RevocationBinding,
    RevocationEntry,
    RevocationError,
    RevocationRegistry,
    RevocationState,
    revoke,
)
from .envelope import (
    ENVELOPE_REQUIRED_ITEMS,
    SIGNATURE_EXCLUDED_FIELDS,
    Authorization,
    BoundedResult,
    CapabilityEnvelope,
    ClockAssertion,
    EnvelopeError,
    RuleIdentity,
    VerificationProgram,
    evidence_root_commitment,
    issue_envelope,
)
from .verify import (
    CHECK_ORDER,
    IMPLEMENTED_CHECKS,
    CheckName,
    CheckStatus,
    Denial,
    DenialReason,
    NonceLedger,
    VerificationOutcome,
    VerifierExpectations,
    verify_envelope,
)
from .evaluate import (
    BOOLEAN_SEMANTICS,
    CapabilityQuery,
    CapabilityState,
    EvaluationError,
    PrivateEvaluationResult,
    evaluate_private,
)
from .revalidation import (
    RevalidationError,
    RevalidationReport,
    selective_revalidation,
)

__version__ = "1.1.0"
SPEC_VERSION = "0.2.0"

__all__ = [
    # signing and attestation (14.5, 35.4)
    "ATTESTATION_DOES_NOT_PROVE",
    "ATTESTATION_PROVES",
    "ATTESTATION_SCOPE_STATEMENT",
    "PRODUCTION_PROFILE_WARNING",
    "PRODUCTION_SIGNATURE_PROFILE",
    "REQUIRED_ATTESTATION_DISCLAIMER",
    "SIGNATURE_ALGORITHM",
    "SIGNATURE_PROFILE",
    "AttestationRecord",
    "EnvelopeSignature",
    "KeyRing",
    "SigningError",
    "SigningKey",
    "sign_payload",
    "verify_payload",
    # release policy (35.3)
    "PolicyError",
    "ReleaseKind",
    "ReleasePolicy",
    # revocation (35.2, 35.4)
    "RevocationBinding",
    "RevocationEntry",
    "RevocationError",
    "RevocationRegistry",
    "RevocationState",
    "revoke",
    # capability envelope (35.2)
    "ENVELOPE_REQUIRED_ITEMS",
    "SIGNATURE_EXCLUDED_FIELDS",
    "Authorization",
    "BoundedResult",
    "CapabilityEnvelope",
    "ClockAssertion",
    "EnvelopeError",
    "RuleIdentity",
    "VerificationProgram",
    "evidence_root_commitment",
    "issue_envelope",
    # verification (35.4, 45.3)
    "CHECK_ORDER",
    "IMPLEMENTED_CHECKS",
    "CheckName",
    "CheckStatus",
    "Denial",
    "DenialReason",
    "NonceLedger",
    "VerificationOutcome",
    "VerifierExpectations",
    "verify_envelope",
    # confidential evaluation (35.3)
    "BOOLEAN_SEMANTICS",
    "CapabilityQuery",
    "CapabilityState",
    "EvaluationError",
    "PrivateEvaluationResult",
    "evaluate_private",
    # selective revalidation (35.1)
    "RevalidationError",
    "RevalidationReport",
    "selective_revalidation",
]
