"""Portable binding between certified CRG phase evidence and its consumers.

``PhaseAnalysisRecord`` is the only artifact in the 1.x line that may make a
CRG phase-boundary claim.  This module gives that artifact one shared identity
contract so certification, change, ETQ, and transition control cannot each
invent a subtly different meaning for "the current phase".

The binding carries the complete phase analysis and its source ``R``.  It is
created only after a caller-supplied independent verifier has accepted those
two records.  Dependency inversion is deliberate: ``crg-model`` does not
depend on ``crg-verify``, while a product assembly can pass
``crg_verify.verify_phase_analysis_record`` at the trust boundary.

External runtime labels such as ``STEADY`` or ``DRAINING`` are operational
states, not CRG phase boundaries.  They never satisfy this contract.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Callable, Mapping

from .canonical import canonical_json, content_hash, is_hash

__all__ = [
    "CERTIFIED_PHASE_BINDING_PROFILE",
    "CERTIFIED_PHASE_BINDING_SCHEMA_VERSION",
    "CERTIFIED_PHASE_CONSUMERS",
    "CertifiedPhaseBindingError",
    "CertifiedPhaseBinding",
    "CertifiedPhaseConsumption",
    "build_certified_phase_binding",
    "certified_phase_binding_from_canonical",
    "consume_certified_phase",
]

CERTIFIED_PHASE_BINDING_SCHEMA_VERSION = "1.2.0"
CERTIFIED_PHASE_BINDING_PROFILE = "CRG_CERTIFIED_PHASE_BINDING_V1"
CERTIFIED_PHASE_ANALYSIS_PROFILE = "TWO_COORDINATE_PRICE_SIMPLEX_V1"
CERTIFIED_PHASE_ANALYSIS_PROFILE_VERSION = "1"
CERTIFIED_PHASE_VERIFICATION_PROGRAM = "crg-verify.phase-analysis/v1"

CERTIFIED_PHASE_CONSUMERS = (
    "CERTIFICATION",
    "CERTIFIED_CHANGE",
    "ETQ_DECISION_CONSEQUENCE",
    "TRANSITION_AUTHORIZATION",
)

_REQUIRED_PHASE_CHECKS = (
    "phase_profile",
    "phase_source_binding",
    "phase_policy_derivation",
    "phase_partition",
    "phase_stability",
    "phase_identity",
    "phase_wire",
)
_CONSTRUCTION_TOKEN = object()


class CertifiedPhaseBindingError(ValueError):
    """Certified phase evidence is absent, unsupported, or identity-mismatched."""


def _document(value: Any, field_name: str) -> dict:
    if hasattr(value, "to_canonical") and callable(value.to_canonical):
        value = value.to_canonical()
    if not isinstance(value, Mapping):
        raise CertifiedPhaseBindingError(f"{field_name} must be a canonical JSON object")
    try:
        # A canonical encode/decode both detaches the carried record from caller
        # mutation and refuses binary floating point at this boundary.
        return json.loads(canonical_json(dict(value)))
    except (TypeError, ValueError) as error:
        raise CertifiedPhaseBindingError(
            f"{field_name} is not canonical CRG content: {error}"
        ) from error


def _verification_document(value: Any) -> dict:
    if hasattr(value, "to_json") and callable(value.to_json):
        value = value.to_json()
    return _document(value, "phase verification result")


def _stable_id(prefix: str, identity: Mapping[str, Any]) -> str:
    return f"{prefix}-{content_hash(dict(identity)).split(':', 1)[1][:20]}"


def _verification_receipt(
    result: Any,
    *,
    phase_analysis_root: str,
    source_r_root: str,
) -> dict:
    document = _verification_document(result)
    if document.get("ok") is not True or document.get("status") != "VERIFIED_RELATIVE":
        raise CertifiedPhaseBindingError(
            "phase evidence was not independently VERIFIED_RELATIVE"
        )
    if document.get("violations") not in ([], ()):
        raise CertifiedPhaseBindingError(
            "phase verification carries unresolved violations"
        )
    checks = document.get("checks")
    if not isinstance(checks, list):
        raise CertifiedPhaseBindingError("phase verification checks must be an array")
    by_name = {}
    for item in checks:
        if not isinstance(item, Mapping):
            raise CertifiedPhaseBindingError("phase verification check is not an object")
        name = item.get("check")
        if not isinstance(name, str) or name in by_name:
            raise CertifiedPhaseBindingError(
                "phase verification checks require unique named identities"
            )
        by_name[name] = item.get("passed") is True
    missing_or_failed = [name for name in _REQUIRED_PHASE_CHECKS if by_name.get(name) is not True]
    if missing_or_failed:
        raise CertifiedPhaseBindingError(
            "phase verification did not pass every required check: "
            f"{missing_or_failed}"
        )
    report = document.get("report")
    if not isinstance(report, Mapping):
        raise CertifiedPhaseBindingError("phase verification report must be an object")
    if report.get("artifact_root") != phase_analysis_root:
        raise CertifiedPhaseBindingError(
            "phase verifier artifact root does not match the carried PhaseAnalysisRecord"
        )
    if report.get("source_root") != source_r_root:
        raise CertifiedPhaseBindingError(
            "phase verifier source root does not match the carried source R"
        )
    return {
        "verification_program": CERTIFIED_PHASE_VERIFICATION_PROGRAM,
        "status": "VERIFIED_RELATIVE",
        "phase_analysis_root": phase_analysis_root,
        "source_r_root": source_r_root,
        "checks_passed": list(_REQUIRED_PHASE_CHECKS),
        "verification_result_hash": content_hash(document),
    }


@dataclass(frozen=True)
class CertifiedPhaseBinding:
    """Complete, independently admitted identity for one certified CRG phase."""

    binding_id: str
    analysis_id: str
    phase_analysis_root: str
    source_r_root: str
    phase_profile_id: str
    phase_profile_version: str
    phase_analysis: dict
    source_r: dict
    verification: dict
    schema_version: str = CERTIFIED_PHASE_BINDING_SCHEMA_VERSION
    _token: object = None

    def __post_init__(self) -> None:
        if self._token is not _CONSTRUCTION_TOKEN:
            raise CertifiedPhaseBindingError(
                "CertifiedPhaseBinding must be constructed by "
                "build_certified_phase_binding() with an independent verifier"
            )
        if self.schema_version != CERTIFIED_PHASE_BINDING_SCHEMA_VERSION:
            raise CertifiedPhaseBindingError(
                f"unsupported certified-phase binding version {self.schema_version!r}"
            )
        if self.phase_profile_id != CERTIFIED_PHASE_ANALYSIS_PROFILE or (
            self.phase_profile_version != CERTIFIED_PHASE_ANALYSIS_PROFILE_VERSION
        ):
            raise CertifiedPhaseBindingError(
                "certified-phase binding names an unregistered phase profile"
            )
        if not is_hash(self.phase_analysis_root) or not is_hash(self.source_r_root):
            raise CertifiedPhaseBindingError("phase and source identities must be SHA-256 roots")

    def to_canonical(self) -> dict:
        return {
            "record_type": "CertifiedPhaseBinding",
            "schema_version": self.schema_version,
            "binding_profile": {
                "profile_id": CERTIFIED_PHASE_BINDING_PROFILE,
                "profile_version": "1",
            },
            "binding_id": self.binding_id,
            "phase_identity": {
                "analysis_id": self.analysis_id,
                "phase_analysis_root": self.phase_analysis_root,
                "source_r_root": self.source_r_root,
                "phase_profile_id": self.phase_profile_id,
                "phase_profile_version": self.phase_profile_version,
            },
            "phase_analysis": self.phase_analysis,
            "source_r": self.source_r,
            "verification": self.verification,
            "claim_scope": "RELATIVE_TO_CARRIED_SOURCE_R_AND_REGISTERED_PHASE_PROFILE",
            "claim_limitations": [
                "CERTIFIED_PHASE_BOUNDARY_LANGUAGE_REQUIRES_THIS_BINDING",
                "ACTIVE_COORDINATES_AND_BOTTLENECKS_ARE_NOT_PHASE_BOUNDARIES",
                "EXTERNAL_OPERATIONAL_STATE_LABELS_ARE_NOT_CRG_PHASE_EVIDENCE",
            ],
        }

    def root_hash(self) -> str:
        return content_hash(self.to_canonical())

    def require_identity(self, phase_analysis_root: str, source_r_root: str) -> None:
        """Fail closed unless a consumer names both exact carried identities."""
        if phase_analysis_root != self.phase_analysis_root:
            raise CertifiedPhaseBindingError(
                "consumer phase-analysis root does not match the certified phase binding"
            )
        if source_r_root != self.source_r_root:
            raise CertifiedPhaseBindingError(
                "consumer source-R root does not match the certified phase binding"
            )


@dataclass(frozen=True)
class CertifiedPhaseConsumption:
    """Portable receipt proving which shared phase identity a consumer used."""

    consumption_id: str
    consumer: str
    subject_root: str
    certified_phase_binding_root: str
    phase_analysis_root: str
    source_r_root: str
    analysis_id: str
    schema_version: str = CERTIFIED_PHASE_BINDING_SCHEMA_VERSION
    _token: object = None

    def __post_init__(self) -> None:
        if self._token is not _CONSTRUCTION_TOKEN:
            raise CertifiedPhaseBindingError(
                "CertifiedPhaseConsumption must be constructed by consume_certified_phase()"
            )
        if self.consumer not in CERTIFIED_PHASE_CONSUMERS:
            raise CertifiedPhaseBindingError(f"unknown certified-phase consumer {self.consumer!r}")
        for name in (
            "subject_root",
            "certified_phase_binding_root",
            "phase_analysis_root",
            "source_r_root",
        ):
            if not is_hash(getattr(self, name)):
                raise CertifiedPhaseBindingError(f"{name} must be an algorithm-tagged SHA-256 hash")

    def to_canonical(self) -> dict:
        return {
            "record_type": "CertifiedPhaseConsumption",
            "schema_version": self.schema_version,
            "consumption_id": self.consumption_id,
            "consumer": self.consumer,
            "subject_root": self.subject_root,
            "certified_phase_binding_root": self.certified_phase_binding_root,
            "phase_analysis_root": self.phase_analysis_root,
            "source_r_root": self.source_r_root,
            "analysis_id": self.analysis_id,
        }

    def root_hash(self) -> str:
        return content_hash(self.to_canonical())


def build_certified_phase_binding(
    phase_analysis: Any,
    source_r: Any,
    *,
    verifier: Callable[[Mapping[str, Any], Mapping[str, Any]], Any],
) -> CertifiedPhaseBinding:
    """Verify and bind a PhaseAnalysisRecord to the exact portable source R."""
    if not callable(verifier):
        raise CertifiedPhaseBindingError("an independent phase verifier callable is required")
    phase_document = _document(phase_analysis, "phase_analysis")
    source_document = _document(source_r, "source_r")
    if phase_document.get("record_type") != "PhaseAnalysisRecord":
        raise CertifiedPhaseBindingError("phase_analysis is not a PhaseAnalysisRecord")
    if phase_document.get("schema_version") != CERTIFIED_PHASE_BINDING_SCHEMA_VERSION:
        raise CertifiedPhaseBindingError("phase_analysis uses an unsupported schema version")
    if source_document.get("record_type") != "R":
        raise CertifiedPhaseBindingError("source_r is not a canonical R record")
    profile = phase_document.get("profile")
    if not isinstance(profile, Mapping):
        raise CertifiedPhaseBindingError("phase_analysis.profile is missing")
    profile_id = profile.get("profile_id")
    profile_version = profile.get("profile_version")
    if profile_id != CERTIFIED_PHASE_ANALYSIS_PROFILE or (
        profile_version != CERTIFIED_PHASE_ANALYSIS_PROFILE_VERSION
    ):
        raise CertifiedPhaseBindingError(
            f"unregistered phase profile/version {profile_id!r}@{profile_version!r}"
        )
    phase_root = content_hash(phase_document)
    source_root = content_hash(source_document)
    if phase_document.get("source_r_root") != source_root:
        raise CertifiedPhaseBindingError(
            "PhaseAnalysisRecord source_r_root does not match the carried source R"
        )
    analysis_id = phase_document.get("analysis_id")
    if not isinstance(analysis_id, str) or not analysis_id:
        raise CertifiedPhaseBindingError("PhaseAnalysisRecord has no analysis identity")
    result = verifier(phase_document, source_document)
    receipt = _verification_receipt(
        result,
        phase_analysis_root=phase_root,
        source_r_root=source_root,
    )
    identity = {
        "schema_version": CERTIFIED_PHASE_BINDING_SCHEMA_VERSION,
        "analysis_id": analysis_id,
        "phase_analysis_root": phase_root,
        "source_r_root": source_root,
        "phase_profile_id": profile_id,
        "phase_profile_version": profile_version,
    }
    return CertifiedPhaseBinding(
        binding_id=_stable_id("certified-phase-binding", identity),
        analysis_id=analysis_id,
        phase_analysis_root=phase_root,
        source_r_root=source_root,
        phase_profile_id=profile_id,
        phase_profile_version=profile_version,
        phase_analysis=phase_document,
        source_r=source_document,
        verification=receipt,
        _token=_CONSTRUCTION_TOKEN,
    )


def certified_phase_binding_from_canonical(
    document: Mapping[str, Any],
    *,
    verifier: Callable[[Mapping[str, Any], Mapping[str, Any]], Any],
) -> CertifiedPhaseBinding:
    """Decode a binding by independently replaying its carried phase evidence."""
    supplied = _document(document, "certified_phase_binding")
    binding = build_certified_phase_binding(
        supplied.get("phase_analysis"),
        supplied.get("source_r"),
        verifier=verifier,
    )
    if supplied != binding.to_canonical():
        raise CertifiedPhaseBindingError(
            "certified-phase binding differs from the independently reconstructed contract"
        )
    return binding


def consume_certified_phase(
    binding: CertifiedPhaseBinding,
    *,
    consumer: str,
    subject_root: str,
    expected_phase_analysis_root: str,
    expected_source_r_root: str,
) -> CertifiedPhaseConsumption:
    """Bind one registered consumer to the exact shared phase and source roots."""
    if not isinstance(binding, CertifiedPhaseBinding):
        raise CertifiedPhaseBindingError(
            "consumer requires a verified CertifiedPhaseBinding object; raw or unverified "
            "phase evidence is refused"
        )
    if consumer not in CERTIFIED_PHASE_CONSUMERS:
        raise CertifiedPhaseBindingError(f"unknown certified-phase consumer {consumer!r}")
    if not is_hash(subject_root):
        raise CertifiedPhaseBindingError("consumer subject_root must be a SHA-256 root")
    binding.require_identity(expected_phase_analysis_root, expected_source_r_root)
    identity = {
        "schema_version": CERTIFIED_PHASE_BINDING_SCHEMA_VERSION,
        "consumer": consumer,
        "subject_root": subject_root,
        "certified_phase_binding_root": binding.root_hash(),
        "phase_analysis_root": binding.phase_analysis_root,
        "source_r_root": binding.source_r_root,
        "analysis_id": binding.analysis_id,
    }
    return CertifiedPhaseConsumption(
        consumption_id=_stable_id("certified-phase-consumption", identity),
        consumer=consumer,
        subject_root=subject_root,
        certified_phase_binding_root=binding.root_hash(),
        phase_analysis_root=binding.phase_analysis_root,
        source_r_root=binding.source_r_root,
        analysis_id=binding.analysis_id,
        _token=_CONSTRUCTION_TOKEN,
    )
