"""A1.2 commitment-event and semantic-assessment records.

These records compose the existing assessment, lifecycle-authorization, and
transition authorities.  They do not replace any of them: a commitment event
is a proposal, a validation assessment is semantic evidence, a
``LifecycleAuthorization`` remains the host decision, and a
``TransitionRecord`` remains the action/postcondition/rollback evidence.
"""
from __future__ import annotations

import copy
import re
from typing import Any, Mapping, Sequence

from .canonical import content_hash
from .schema import schema_for, validate_or_raise

__all__ = [
    "AssessmentRecordError",
    "COMMITMENT_EVENT_PROFILE",
    "VALIDATION_ASSESSMENT_PROFILE",
    "build_commitment_event",
    "build_validation_assessment",
    "validate_commitment_event",
    "validate_validation_assessment",
]

COMMITMENT_EVENT_PROFILE = "crg-commitment-event/v1"
VALIDATION_ASSESSMENT_PROFILE = "crg-validation-assessment/v1"
SCHEMA_VERSION = "1.0.0"
_HASH = re.compile(r"sha256:[0-9a-f]{64}")
_INPUT_FIELDS = {
    "record_type", "profile", "artifact_hash", "verification_status",
    "evidence_classes", "verifier",
}
_FAILURE_STATUSES = {
    "FAILED", "EXPIRED", "REVOKED", "TIME_INDETERMINATE",
    "UNVERIFIABLE_REDACTED", "UNSUPPORTED_PROFILE",
}


class AssessmentRecordError(ValueError):
    """An A1.2 record is malformed, inconsistent, or authority-bearing."""


def _mapping(value: Any, label: str) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise AssessmentRecordError(f"{label} must be an object")
    return copy.deepcopy(dict(value))


def _closed(value: Any, fields: set[str], label: str) -> dict[str, Any]:
    item = _mapping(value, label)
    if set(item) != fields:
        raise AssessmentRecordError(f"{label} fields differ")
    return item


def _text(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value:
        raise AssessmentRecordError(f"{label} must be a non-empty string")
    return value


def _hash(value: Any, label: str) -> str:
    if not isinstance(value, str) or _HASH.fullmatch(value) is None:
        raise AssessmentRecordError(f"{label} must be an algorithm-tagged SHA-256 hash")
    return value


def _sorted_strings(value: Any, label: str, *, nonempty: bool = False) -> list[str]:
    if not isinstance(value, (list, tuple)) or (nonempty and not value):
        raise AssessmentRecordError(f"{label} must be a{' non-empty' if nonempty else ''} array")
    result = list(value)
    if any(not isinstance(item, str) or not item for item in result):
        raise AssessmentRecordError(f"{label} contains an invalid identifier")
    if result != sorted(set(result)):
        raise AssessmentRecordError(f"{label} must be sorted and unique")
    return result


def _identity_hash(record: Mapping[str, Any], field: str) -> str:
    return content_hash({key: value for key, value in record.items() if key != field})


def validate_commitment_event(value: Any) -> dict[str, Any]:
    record = _mapping(value, "commitment event")
    try:
        validate_or_raise(record, schema_for("CommitmentEventRecord"))
    except Exception as error:
        raise AssessmentRecordError(f"commitment event schema validation failed: {error}") from error
    if record["event_hash"] != _identity_hash(record, "event_hash"):
        raise AssessmentRecordError("commitment event hash differs from canonical content")
    if record["target"]["current_hash"] == record["target"]["proposed_hash"]:
        raise AssessmentRecordError("commitment event does not propose a changed target")
    requirement = record["assessment_requirement"]
    _sorted_strings(requirement["required_statuses"], "required_statuses", nonempty=True)
    _sorted_strings(requirement["required_evidence"], "required_evidence", nonempty=True)
    if record["case_id"] is None and record["branch_id"] is not None:
        raise AssessmentRecordError("a branch cannot be named without a case")
    return record


def build_commitment_event(
    *,
    event_id: str,
    proposal_id: str,
    actor_id: str,
    actor_kind: str,
    target: Mapping[str, Any],
    resolved_requirement: Mapping[str, Any],
    created_at: str,
) -> dict[str, Any]:
    """Bind an A1.1 resolution to a proposed action without authorizing it."""

    resolved = _mapping(resolved_requirement, "resolved action requirement")
    if resolved.get("status") != "ASSESSMENT_REQUIRED":
        raise AssessmentRecordError("a commitment event requires a supported A1.1 resolution")
    if resolved.get("authority") != "NON_AUTHORIZING" or resolved.get("execution_authorized") is not False:
        raise AssessmentRecordError("the action mapping resolution exceeds its non-authorizing boundary")
    subject = _mapping(resolved.get("subject"), "resolved subject")
    if actor_kind not in subject.get("allowed_actor_kinds", ()):
        raise AssessmentRecordError("the proposed actor kind is outside the resolved action mapping")
    context = _mapping(resolved.get("target"), "resolved target context")
    proposal_target = _closed(
        target, {"object_type", "object_id", "current_hash", "proposed_hash"},
        "commitment target",
    )
    if proposal_target["current_hash"] is not None:
        _hash(proposal_target["current_hash"], "target.current_hash")
    _hash(proposal_target["proposed_hash"], "target.proposed_hash")
    record = {
        "record_type": "CommitmentEventRecord",
        "schema_version": SCHEMA_VERSION,
        "profile": COMMITMENT_EVENT_PROFILE,
        "event_id": _text(event_id, "event_id"),
        "action_class": _text(resolved.get("action_class"), "action_class"),
        "action_mapping_profile_hash": _hash(resolved.get("profile_hash"), "profile_hash"),
        "mapping_hash": _hash(resolved.get("mapping_hash"), "mapping_hash"),
        "case_id": context.get("case_id"),
        "branch_id": context.get("branch_id"),
        "proposal_id": _text(proposal_id, "proposal_id"),
        "causal_parent_id": context.get("causal_parent_id"),
        "actor": {
            "actor_id": _text(actor_id, "actor_id"),
            "actor_kind": _text(actor_kind, "actor_kind"),
        },
        "target": proposal_target,
        "assessment_requirement": _mapping(resolved.get("assessment"), "assessment requirement"),
        "authority": "NON_AUTHORIZING_PROPOSAL",
        "execution_authorized": False,
        "action_occurred": False,
        "created_at": _text(created_at, "created_at"),
    }
    record["event_hash"] = content_hash(record)
    return validate_commitment_event(record)


def _validate_semantic_inputs(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, (list, tuple)) or not value:
        raise AssessmentRecordError("semantic_inputs must be a non-empty array")
    inputs = [_closed(item, _INPUT_FIELDS, "semantic input") for item in value]
    for item in inputs:
        _text(item["record_type"], "semantic input record_type")
        _text(item["profile"], "semantic input profile")
        _hash(item["artifact_hash"], "semantic input artifact_hash")
        _text(item["verification_status"], "semantic input verification_status")
        _sorted_strings(item["evidence_classes"], "semantic input evidence_classes", nonempty=True)
        verifier = _closed(item["verifier"], {"program", "profile"}, "semantic input verifier")
        _text(verifier["program"], "semantic input verifier program")
        _text(verifier["profile"], "semantic input verifier profile")
    inputs.sort(key=lambda item: (item["record_type"], item["artifact_hash"]))
    identities = [(item["record_type"], item["artifact_hash"]) for item in inputs]
    if len(identities) != len(set(identities)):
        raise AssessmentRecordError("semantic_inputs repeat an artifact identity")
    return inputs


def _derived_semantic_result(
    event: Mapping[str, Any],
    inputs: Sequence[Mapping[str, Any]],
    validity: Mapping[str, Any],
    disagreement: Mapping[str, Any],
) -> dict[str, Any]:
    requirement = event["assessment_requirement"]
    required_evidence = set(requirement["required_evidence"])
    matched = [
        item for item in inputs
        if item["record_type"] == requirement["record_type"]
        and item["profile"] == requirement["profile"]
        and item["verification_status"] in requirement["required_statuses"]
        and item["verifier"] == requirement["verifier"]
        and required_evidence.issubset(set(item["evidence_classes"]))
    ]
    requirement_satisfied = bool(matched) and not any(
        item["verification_status"] in _FAILURE_STATUSES for item in inputs
    )
    if validity["status"] == "INDETERMINATE" or disagreement["status"] != "NONE":
        status = "INDETERMINATE"
    elif requirement_satisfied and validity["status"] == "CURRENT":
        status = "ESTABLISHED"
    else:
        status = "NOT_ESTABLISHED"
    return {"status": status, "requirement_satisfied": requirement_satisfied}


def validate_validation_assessment(
    value: Any, *, commitment_event: Mapping[str, Any]
) -> dict[str, Any]:
    event = validate_commitment_event(commitment_event)
    record = _mapping(value, "validation assessment")
    try:
        validate_or_raise(record, schema_for("ValidationAssessmentRecord"))
    except Exception as error:
        raise AssessmentRecordError(f"validation assessment schema validation failed: {error}") from error
    if record["assessment_hash"] != _identity_hash(record, "assessment_hash"):
        raise AssessmentRecordError("validation assessment hash differs from canonical content")
    if record["commitment_event_hash"] != event["event_hash"]:
        raise AssessmentRecordError("validation assessment names a different commitment event")
    context = _mapping(record["context_roots"], "assessment context roots")
    try:
        validate_or_raise(context, schema_for("AssessmentContextRoots"))
    except Exception as error:
        raise AssessmentRecordError(f"assessment context roots schema failed: {error}") from error
    if context["context_hash"] != _identity_hash(context, "context_hash"):
        raise AssessmentRecordError("assessment context hash differs from canonical content")
    if context["inputs"]["action_mapping_profile_hash"] != event["action_mapping_profile_hash"]:
        raise AssessmentRecordError("assessment context names a different action-mapping profile")
    if context["host_policy_action_mapping_root"] != content_hash({
        "action_mapping_profile_hash": context["inputs"]["action_mapping_profile_hash"],
        "host_policy_snapshot_hash": context["inputs"]["host_policy_snapshot_hash"],
    }):
        raise AssessmentRecordError("host-policy/action-mapping root differs")
    if context["execution_deployment_root"] != content_hash({
        "execution_profile_hash": context["inputs"]["execution_profile_hash"],
        "deployment_profile_hash": context["inputs"]["deployment_profile_hash"],
    }):
        raise AssessmentRecordError("execution/deployment root differs")
    inputs = _validate_semantic_inputs(record["semantic_inputs"])
    if inputs != record["semantic_inputs"]:
        raise AssessmentRecordError("semantic_inputs must be sorted and unique")
    validity = record["validity"]
    if (validity["status"] == "REVOKED") != (validity["revocation_record_hash"] is not None):
        raise AssessmentRecordError("revocation identity must be present exactly for REVOKED validity")
    disagreement = record["disagreement"]
    details = _sorted_strings(disagreement["details"], "disagreement details")
    if (disagreement["status"] == "NONE") != (details == []):
        raise AssessmentRecordError("disagreement details must be empty exactly when status is NONE")
    _sorted_strings(record["limitations"], "limitations")
    expected = _derived_semantic_result(event, inputs, validity, disagreement)
    if record["semantic_result"] != expected:
        raise AssessmentRecordError("semantic result differs from the mapped evidence reconstruction")
    return record


def build_validation_assessment(
    *,
    assessment_id: str,
    commitment_event: Mapping[str, Any],
    semantic_inputs: Sequence[Mapping[str, Any]],
    context_roots: Mapping[str, Any],
    validity: Mapping[str, Any],
    disagreement: Mapping[str, Any],
    limitations: Sequence[str] = (),
) -> dict[str, Any]:
    """Derive a semantic assessment; no host permission or action is decided here."""

    event = validate_commitment_event(commitment_event)
    inputs = _validate_semantic_inputs(semantic_inputs)
    validity_record = _closed(
        validity, {"status", "evaluated_at", "expires_at", "revocation_record_hash"},
        "validity",
    )
    disagreement_record = _closed(disagreement, {"status", "details"}, "disagreement")
    disagreement_record["details"] = _sorted_strings(
        disagreement_record["details"], "disagreement details"
    )
    limitation_list = _sorted_strings(list(limitations), "limitations")
    context_record = _mapping(context_roots, "assessment context roots")
    record = {
        "record_type": "ValidationAssessmentRecord",
        "schema_version": SCHEMA_VERSION,
        "profile": VALIDATION_ASSESSMENT_PROFILE,
        "assessment_id": _text(assessment_id, "assessment_id"),
        "commitment_event_hash": event["event_hash"],
        "context_roots": context_record,
        "semantic_inputs": inputs,
        "semantic_result": _derived_semantic_result(
            event, inputs, validity_record, disagreement_record
        ),
        "validity": validity_record,
        "disagreement": disagreement_record,
        "limitations": limitation_list,
        "separation_contract": {
            "host_disposition_record_type": "LifecycleAuthorization",
            "action_record_type": "TransitionRecord",
            "host_disposition_embedded": False,
            "action_receipt_embedded": False,
        },
        "authority": "SEMANTIC_ASSESSMENT_ONLY",
        "authorizing": False,
        "execution_authorized": False,
    }
    record["assessment_hash"] = content_hash(record)
    return validate_validation_assessment(record, commitment_event=event)
