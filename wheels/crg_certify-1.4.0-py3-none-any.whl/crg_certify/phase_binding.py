"""Certification surface for the shared certified-phase identity contract."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Optional, Sequence

from crg_model.canonical import content_hash
from crg_model.numeric import Exact
from crg_model.phase_binding import (
    CertifiedPhaseBinding,
    CertifiedPhaseBindingError,
    CertifiedPhaseConsumption,
    consume_certified_phase,
)
from crg_model.records import (
    DecisionCertificate,
    DecisionScope,
    DerivationRecord,
    Fiber,
    RRecord,
    RealizationBundle,
)

from .certify import certify

__all__ = ["PhaseBoundCertification", "certify_with_certified_phase"]


def _source_r_root(bundle: RealizationBundle) -> str:
    """Reconstruct the exact R consumed by phase analysis from the decision bundle."""
    groups = {}
    for realization in sorted(bundle.realizations, key=lambda item: item.realization_id):
        groups.setdefault(realization.signature, []).append(realization.realization_id)
    fibers = tuple(
        Fiber(signature=signature, realization_ids=tuple(identifiers))
        for signature, identifiers in sorted(
            groups.items(), key=lambda item: item[0].sort_key()
        )
    )
    return RRecord(
        schema=bundle.schema,
        fibers=fibers,
        completeness=bundle.completeness,
    ).root_hash()


def _registered_phase_parameter(
    bundle: RealizationBundle,
    scope: DecisionScope,
    binding: CertifiedPhaseBinding,
) -> Exact:
    """Map a fixed two-coordinate additive price to registered ``theta``."""
    family = scope.objective_family
    if str(family.get("type")) not in {
        "weighted_sum",
        "linear",
        "additive",
        "additive_price",
        "dot",
        "price_vector",
    }:
        raise CertifiedPhaseBindingError(
            "the registered phase profile applies only to a fixed additive price; "
            "other decision classes cannot consume it"
        )
    identifiers = tuple(bundle.schema.identifiers)
    if len(identifiers) != 2:
        raise CertifiedPhaseBindingError(
            "the registered phase profile requires exactly two decision coordinates"
        )
    declared = family.get("weights") or {}
    if declared and set(declared) != set(identifiers):
        raise CertifiedPhaseBindingError(
            "phase-bound certification requires one fixed weight for each coordinate"
        )
    weights = []
    for identifier in identifiers:
        value = declared.get(identifier, 1)
        if isinstance(value, (list, tuple)):
            if len(value) != 2 or value[0] != value[1]:
                raise CertifiedPhaseBindingError(
                    "a non-degenerate weight interval is not one point in the "
                    "registered phase profile"
                )
            value = value[0]
        elif isinstance(value, Mapping):
            lower = value.get("lo")
            upper = value.get("hi")
            if lower is None or lower != upper:
                raise CertifiedPhaseBindingError(
                    "a weight set is not one point in the registered phase profile"
                )
            value = lower
        weight = Exact(value)
        if weight < Exact(0):
            raise CertifiedPhaseBindingError(
                "registered phase-profile weights must be nonnegative"
            )
        weights.append(weight)
    total = weights[0] + weights[1]
    if total == Exact(0):
        raise CertifiedPhaseBindingError(
            "an all-zero price vector has no registered phase parameter"
        )
    theta = weights[0] / total
    phase_profile = binding.phase_analysis.get("profile") or {}
    tolerance = Exact.from_canonical(phase_profile.get("policy_tolerance") or {})
    if tolerance != scope.tie_tolerance:
        raise CertifiedPhaseBindingError(
            "certification tie tolerance differs from the certified phase profile"
        )
    stability = binding.phase_analysis.get("stability")
    if not isinstance(stability, dict):
        raise CertifiedPhaseBindingError(
            "phase-bound certification requires a verified stability probe at its price"
        )
    parameter = Exact.from_canonical(stability.get("parameter") or {})
    if parameter != theta:
        raise CertifiedPhaseBindingError(
            "certification price does not match the certified phase stability parameter"
        )
    return theta


@dataclass(frozen=True)
class PhaseBoundCertification:
    """Decision certificate plus proof of the exact phase identity it consumed."""

    certificate: DecisionCertificate
    phase_consumption: CertifiedPhaseConsumption
    phase_parameter: Exact

    def to_canonical(self) -> dict:
        return {
            "record_type": "PhaseBoundCertification",
            "schema_version": "1.2.0",
            "certificate": self.certificate.to_canonical(),
            "certificate_root": self.certificate.certificate_hash(),
            "phase_consumption": self.phase_consumption.to_canonical(),
            "phase_parameter": self.phase_parameter.to_canonical(),
            "claim_limitations": [
                "CERTIFICATION_IS_RELATIVE_TO_THE_CARRIED_PHASE_SOURCE_R",
                "ACTIVE_BOTTLENECKS_DO_NOT_ESTABLISH_A_PHASE_BOUNDARY",
            ],
        }

    def root_hash(self) -> str:
        return content_hash(self.to_canonical())


def certify_with_certified_phase(
    bundle: RealizationBundle,
    scope: DecisionScope,
    derivation: DerivationRecord,
    *,
    certified_phase: CertifiedPhaseBinding,
    expected_phase_analysis_root: str,
    expected_source_r_root: str,
    geometry: Any = None,
    retained: Optional[Sequence[str]] = None,
) -> PhaseBoundCertification:
    """Run normal certification and bind its result to verified phase evidence.

    Existing :func:`certify` behavior is unchanged.  Callers choosing the
    certified-phase path must state both expected roots; a mismatch refuses
    before a phase-bound result can be created.
    """
    if not isinstance(certified_phase, CertifiedPhaseBinding):
        raise CertifiedPhaseBindingError(
            "certification requires a verified CertifiedPhaseBinding"
        )
    certified_phase.require_identity(
        expected_phase_analysis_root,
        expected_source_r_root,
    )
    if _source_r_root(bundle) != certified_phase.source_r_root:
        raise CertifiedPhaseBindingError(
            "certification bundle does not reconstruct the source R carried by the "
            "certified phase binding"
        )
    phase_parameter = _registered_phase_parameter(bundle, scope, certified_phase)
    certificate = certify(
        bundle,
        scope,
        derivation,
        geometry=geometry,
        retained=retained,
    )
    consumption = consume_certified_phase(
        certified_phase,
        consumer="CERTIFICATION",
        subject_root=certificate.certificate_hash(),
        expected_phase_analysis_root=expected_phase_analysis_root,
        expected_source_r_root=expected_source_r_root,
    )
    phase_winners = set(certified_phase.phase_analysis["stability"]["winner_ids"])
    certificate_winners = set(certificate.selected) | set(certificate.ties)
    if certificate_winners and certificate_winners != phase_winners:
        raise CertifiedPhaseBindingError(
            "certification winner identities disagree with the certified phase stability probe"
        )
    return PhaseBoundCertification(
        certificate=certificate,
        phase_consumption=consumption,
        phase_parameter=phase_parameter,
    )
