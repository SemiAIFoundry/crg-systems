"""Portable, non-authorizing comparative workflow evaluation records.

This module implements the finite/exact foundation admitted as CRG-ENH-03.
It compares *workflows as observed over one declared workload* without
authorizing a CRG decision and without issuing a superiority, ROI, savings,
or generalization claim.  The portable record embeds and content-binds the
inputs, oracle, named methods, declared budgets, raw per-case traces, result
scope, denominators, limitations, and separately labelled local observations.

Only deterministic arithmetic over exact rationals is derived here.  A
budget or input-binding mismatch produces an explicit NON_COMPARABLE design;
missing or unsupported structure is refused.  A second implementation in
``crg_verify.comparison`` reconstructs every system-derived fact without
importing this package.
"""
from __future__ import annotations

import copy
from dataclasses import dataclass
from fractions import Fraction
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple

from crg_model.canonical import content_hash
from crg_model.numeric import Exact

__all__ = [
    "COMPARISON_SCHEMA_VERSION",
    "COMPARISON_PROFILE",
    "COMPARISON_AUTHORITY",
    "COMPARISON_CLAIM_BOUNDARY",
    "ComparisonDesignError",
    "ComparativeWorkflowEvaluation",
    "build_comparative_workflow_evaluation",
]

COMPARISON_SCHEMA_VERSION = "1.1.0"
COMPARISON_PROFILE = "crg-comparative-workflow/finite-exact@1"
COMPARISON_AUTHORITY = "NON_AUTHORIZING"
COMPARISON_CLAIM_BOUNDARY = (
    "Scoped workflow evidence only; this record does not authorize a CRG state, "
    "rank a method, establish superiority, infer economic value, or generalize "
    "beyond the declared inputs, workload, oracle, budgets, and denominators."
)
ORACLE_PROFILE = "finite-exact-minimum@1"
FACTS_PROFILE = "finite-exact-operational-facts@1"

COMPARABLE = "COMPARABLE_DESIGN"
NON_COMPARABLE = "NON_COMPARABLE_DESIGN"
NO_CONCLUSION = "NO_METHOD_RANKING_OR_AUTHORIZING_CONCLUSION"

_VERIFIER_STATUSES = frozenset(
    {
        "VERIFIED",
        "VERIFIED_RELATIVE",
        "VERIFIED_WITH_BOUNDED_REMAINDER",
        "INTEGRITY_ONLY",
        "REPLAY_BOUND",
        "PARTIALLY_VERIFIED",
        "FAILED",
        "EXPIRED",
        "REVOKED",
        "TIME_INDETERMINATE",
        "UNVERIFIABLE_REDACTED",
        "UNSUPPORTED_PROFILE",
    }
)
_VERIFIED_STATUSES = frozenset(
    {"VERIFIED", "VERIFIED_RELATIVE", "VERIFIED_WITH_BOUNDED_REMAINDER"}
)
_SCOPE_FIELDS = (
    "technology_scope",
    "evidence_scope",
    "change_scope",
    "scenario_scope",
    "held_out_treatment",
)
_FORBIDDEN_RESULT_KEYS = frozenset(
    {
        "roi",
        "return_on_investment",
        "savings",
        "superiority",
        "generalization",
        "method_ranking",
        "best_method",
        "winner_method",
        "avoided_experiments",
        "avoided_redesigns",
    }
)


class ComparisonDesignError(ValueError):
    """The proposed record cannot support the registered comparison profile."""


def _canonical(value: Any) -> Any:
    if isinstance(value, Exact):
        return value.to_canonical()
    method = getattr(value, "to_canonical", None)
    if callable(method):
        return _canonical(method())
    if isinstance(value, Mapping):
        return {str(key): _canonical(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_canonical(item) for item in value]
    if isinstance(value, float):
        raise ComparisonDesignError("binary floating point is outside the finite/exact profile")
    if value is None or isinstance(value, (str, int, bool)):
        return value
    if isinstance(value, Fraction):
        return Exact(value).to_canonical()
    raise ComparisonDesignError(f"{type(value).__name__} has no portable canonical encoding")


def _fraction(value: Any, field: str, *, nonnegative: bool = False) -> Fraction:
    try:
        if isinstance(value, Exact):
            result = value.value
        elif isinstance(value, Fraction):
            result = value
        elif isinstance(value, Mapping) and "exact" in value:
            result = Fraction(str(value["exact"]))
        elif isinstance(value, Mapping) and {"numerator", "denominator"} <= set(value):
            result = Fraction(int(value["numerator"]), int(value["denominator"]))
        elif isinstance(value, bool) or isinstance(value, float):
            raise TypeError
        else:
            result = Fraction(value)
    except (TypeError, ValueError, ZeroDivisionError) as error:
        raise ComparisonDesignError(f"{field} must be an exact rational") from error
    if nonnegative and result < 0:
        raise ComparisonDesignError(f"{field} must be nonnegative")
    return result


def _exact(value: Fraction | int) -> dict:
    return Exact(value).to_canonical()


def _identity(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ComparisonDesignError(f"{field} must be a non-empty string")
    return value.strip()


def _identities(value: Any, field: str, *, nonempty: bool = False) -> List[str]:
    if not isinstance(value, (list, tuple)):
        raise ComparisonDesignError(f"{field} must be a list")
    result = [_identity(item, field) for item in value]
    if len(result) != len(set(result)):
        raise ComparisonDesignError(f"{field} contains duplicate identities")
    if nonempty and not result:
        raise ComparisonDesignError(f"{field} must not be empty")
    return sorted(result)


def _assert_no_forbidden_keys(value: Any, path: str) -> None:
    if isinstance(value, Mapping):
        for key, item in value.items():
            normalized = str(key).strip().lower().replace("-", "_")
            if normalized in _FORBIDDEN_RESULT_KEYS:
                raise ComparisonDesignError(
                    f"{path}.{key} is a prohibited comparative or economic conclusion"
                )
            _assert_no_forbidden_keys(item, f"{path}.{key}")
    elif isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            _assert_no_forbidden_keys(item, f"{path}[{index}]")


def _sealed(record: Mapping[str, Any], key: str) -> dict:
    result = dict(record)
    result.pop(key, None)
    result[key] = content_hash(result)
    return result


def _normalize_bindings(value: Any, field: str) -> Dict[str, str]:
    if not isinstance(value, Mapping) or not value:
        raise ComparisonDesignError(f"{field} must bind every named input")
    result: Dict[str, str] = {}
    for raw_name, raw_hash in value.items():
        name = _identity(raw_name, f"{field} input identity")
        digest = _identity(raw_hash, f"{field}.{name}")
        if not (digest.startswith("sha256:") and len(digest) == 71):
            raise ComparisonDesignError(f"{field}.{name} is not a portable SHA-256 content hash")
        result[name] = digest
    return {name: result[name] for name in sorted(result)}


def _normalize_budget(value: Any, field: str) -> List[dict]:
    if not isinstance(value, (list, tuple)) or not value:
        raise ComparisonDesignError(f"{field} must declare at least one budget component")
    result = []
    seen = set()
    for index, raw in enumerate(value):
        if not isinstance(raw, Mapping):
            raise ComparisonDesignError(f"{field}[{index}] must be an object")
        metric = _identity(raw.get("metric"), f"{field}[{index}].metric")
        unit = _identity(raw.get("unit"), f"{field}[{index}].unit")
        if metric in seen:
            raise ComparisonDesignError(f"{field} repeats metric {metric!r}")
        seen.add(metric)
        limit = _fraction(raw.get("limit"), f"{field}[{index}].limit", nonnegative=True)
        result.append({"metric": metric, "unit": unit, "limit": _exact(limit)})
    return sorted(result, key=lambda item: item["metric"])


def _input_records(inputs: Mapping[str, Any]) -> Tuple[List[dict], Dict[str, str], Dict[str, Any]]:
    if not isinstance(inputs, Mapping) or not inputs:
        raise ComparisonDesignError("inputs must contain portable comparison documents")
    records, hashes, contents = [], {}, {}
    identifiers = [_identity(raw_identifier, "input identity") for raw_identifier in inputs]
    if len(identifiers) != len(set(identifiers)):
        raise ComparisonDesignError("input identities must be unique after normalization")
    for identifier in sorted(identifiers):
        content = _canonical(inputs[identifier])
        digest = content_hash(content)
        records.append({"input_id": identifier, "content": content, "content_hash": digest})
        hashes[identifier] = digest
        contents[identifier] = content
    return records, hashes, contents


def _family_scope(
    contents: Mapping[str, Any],
    hashes: Mapping[str, str],
    realization_family_input_id: str,
    decision_family_input_id: str,
    scope_fields: Mapping[str, Any],
) -> dict:
    realization_id = _identity(realization_family_input_id, "realization_family_input_id")
    decision_id = _identity(decision_family_input_id, "decision_family_input_id")
    if realization_id not in contents or decision_id not in contents:
        raise ComparisonDesignError("scope input identities must refer to embedded inputs")
    family = contents[realization_id]
    if not isinstance(family, Mapping):
        raise ComparisonDesignError("the realization-family input must be an object")
    realizations = family.get("realizations")
    completeness = family.get("completeness")
    if not isinstance(realizations, list) or not realizations:
        raise ComparisonDesignError("the realization-family input has no represented realizations")
    if not isinstance(completeness, Mapping) or not completeness.get("basis_type"):
        raise ComparisonDesignError("the realization-family input has no completeness basis")
    decision = contents[decision_id]
    if not isinstance(decision, Mapping):
        raise ComparisonDesignError("the decision-family input must be an object")
    is_future_family = (
        decision.get("record_type") == "FutureDecisionFamily"
        and isinstance(decision.get("decisions"), list)
        and bool(decision.get("decisions"))
    )
    is_decision = (
        isinstance(decision.get("scope_id"), str)
        and bool(decision.get("scope_id"))
        and isinstance(decision.get("observation_level"), str)
        and isinstance(decision.get("objective_family"), Mapping)
    )
    if not (is_future_family or is_decision):
        raise ComparisonDesignError(
            "the decision input must be one DecisionScope or FutureDecisionFamily"
        )
    seen = set()
    for item in realizations:
        if not isinstance(item, Mapping):
            raise ComparisonDesignError("every represented realization must be an object")
        identifier = _identity(item.get("realization_id"), "realization identity")
        if identifier in seen:
            raise ComparisonDesignError("realization identities must be unique")
        seen.add(identifier)
        if item.get("legality") != "LEGAL":
            raise ComparisonDesignError(
                f"realization {identifier!r} is not in the declared legal family"
            )
    fields = {}
    for name in _SCOPE_FIELDS:
        if name not in scope_fields:
            raise ComparisonDesignError(f"scope is missing {name}")
        fields[name] = _canonical(scope_fields[name])
    _assert_no_forbidden_keys(fields, "scope")
    scope = {
        "realization_family_input_id": realization_id,
        "realization_family_hash": hashes[realization_id],
        "completeness_basis": _canonical(completeness),
        "decision_family_input_id": decision_id,
        "decision_family_hash": hashes[decision_id],
        **fields,
    }
    return _sealed(scope, "scope_hash")


def _workload_cases(value: Any, legal_ids: Iterable[str]) -> Tuple[List[dict], Dict[str, dict]]:
    if not isinstance(value, (list, tuple)) or not value:
        raise ComparisonDesignError("workload must contain at least one case")
    legal = set(legal_ids)
    records: List[dict] = []
    by_id: Dict[str, dict] = {}
    for index, raw in enumerate(value):
        if not isinstance(raw, Mapping):
            raise ComparisonDesignError(f"workload[{index}] must be an object")
        case_id = _identity(raw.get("case_id"), f"workload[{index}].case_id")
        if case_id in by_id:
            raise ComparisonDesignError("workload case identities must be unique")
        eligible = _identities(
            raw.get("eligible_ids"), f"workload[{index}].eligible_ids", nonempty=True
        )
        unknown = set(eligible) - legal
        if unknown:
            raise ComparisonDesignError(
                f"workload case {case_id!r} names realizations outside the legal family: "
                f"{sorted(unknown)}"
            )
        work_items = _identities(
            raw.get("work_item_ids"), f"workload[{index}].work_item_ids", nonempty=True
        )
        record = {
            "case_id": case_id,
            "eligible_ids": eligible,
            "work_item_ids": work_items,
        }
        records.append(record)
        by_id[case_id] = record
    records.sort(key=lambda item: item["case_id"])
    return records, by_id


def _oracle(
    raw: Any,
    cases: Mapping[str, dict],
) -> Tuple[dict, Dict[str, dict]]:
    if not isinstance(raw, Mapping):
        raise ComparisonDesignError("oracle must be an object")
    profile = raw.get("profile")
    if profile != ORACLE_PROFILE:
        raise ComparisonDesignError(
            f"unsupported oracle profile {profile!r}; expected {ORACLE_PROFILE!r}"
        )
    bindings = _normalize_bindings(raw.get("input_bindings"), "oracle.input_bindings")
    answers_raw = raw.get("answers")
    if not isinstance(answers_raw, (list, tuple)):
        raise ComparisonDesignError("oracle.answers must be a list")
    answers, by_id = [], {}
    for index, item in enumerate(answers_raw):
        if not isinstance(item, Mapping):
            raise ComparisonDesignError(f"oracle.answers[{index}] must be an object")
        case_id = _identity(item.get("case_id"), f"oracle.answers[{index}].case_id")
        if case_id not in cases or case_id in by_id:
            raise ComparisonDesignError("oracle answers must map one-to-one to workload cases")
        winners = _identities(
            item.get("winner_ids"), f"oracle.answers[{index}].winner_ids", nonempty=True
        )
        if not set(winners) <= set(cases[case_id]["eligible_ids"]):
            raise ComparisonDesignError(f"oracle answer {case_id!r} names an ineligible winner")
        optimum = _fraction(item.get("optimum"), f"oracle.answers[{index}].optimum")
        answer = {"case_id": case_id, "winner_ids": winners, "optimum": _exact(optimum)}
        answers.append(answer)
        by_id[case_id] = answer
    if set(by_id) != set(cases):
        raise ComparisonDesignError("oracle answers must cover every workload case exactly once")
    oracle = {
        "oracle_id": _identity(raw.get("oracle_id"), "oracle.oracle_id"),
        "name": _identity(raw.get("name"), "oracle.name"),
        "version": _identity(raw.get("version"), "oracle.version"),
        "profile": ORACLE_PROFILE,
        "direction": "MINIMIZE",
        "input_bindings": bindings,
        "denominator": {"case_ids": sorted(cases), "count": _exact(len(cases))},
        "answers": sorted(answers, key=lambda item: item["case_id"]),
    }
    return _sealed(oracle, "oracle_hash"), by_id


def _trace(raw: Any, cases: Mapping[str, dict], oracle: Mapping[str, dict], field: str) -> List[dict]:
    if not isinstance(raw, (list, tuple)):
        raise ComparisonDesignError(f"{field} must be a list")
    traces, seen = [], set()
    for index, item in enumerate(raw):
        if not isinstance(item, Mapping):
            raise ComparisonDesignError(f"{field}[{index}] must be an object")
        case_id = _identity(item.get("case_id"), f"{field}[{index}].case_id")
        if case_id not in cases or case_id in seen:
            raise ComparisonDesignError(f"{field} must map one-to-one to workload cases")
        seen.add(case_id)
        eligible = set(cases[case_id]["eligible_ids"])
        work = set(cases[case_id]["work_item_ids"])
        selected = _identities(item.get("selected_ids"), f"{field}[{index}].selected_ids")
        retained = _identities(item.get("retained_ids"), f"{field}[{index}].retained_ids")
        if not set(selected) <= set(retained) or not set(retained) <= eligible:
            raise ComparisonDesignError(
                f"{field}[{index}] selections must be retained and retained IDs must be eligible"
            )
        achieved = _fraction(item.get("achieved_value"), f"{field}[{index}].achieved_value")
        optimum = _fraction(oracle[case_id]["optimum"], "oracle optimum")
        if achieved < optimum:
            raise ComparisonDesignError(
                f"{field}[{index}] is below the declared finite minimum oracle"
            )
        affected = _identities(item.get("affected_ids"), f"{field}[{index}].affected_ids")
        preserved = _identities(item.get("preserved_ids"), f"{field}[{index}].preserved_ids")
        invalidated = _identities(item.get("invalidated_ids"), f"{field}[{index}].invalidated_ids")
        if not (set(affected) <= work and set(preserved) <= work and set(invalidated) <= work):
            raise ComparisonDesignError(f"{field}[{index}] names work outside the case denominator")
        if set(preserved) & set(invalidated) or set(preserved) | set(invalidated) != set(affected):
            raise ComparisonDesignError(
                f"{field}[{index}] preserved and invalidated work must partition affected work"
            )
        status = _identity(item.get("verifier_status"), f"{field}[{index}].verifier_status")
        if status not in _VERIFIER_STATUSES:
            raise ComparisonDesignError(f"{field}[{index}] has unsupported verifier status {status!r}")
        traces.append(
            {
                "case_id": case_id,
                "selected_ids": selected,
                "retained_ids": retained,
                "achieved_value": _exact(achieved),
                "affected_ids": affected,
                "preserved_ids": preserved,
                "invalidated_ids": invalidated,
                "verifier_status": status,
            }
        )
    if seen != set(cases):
        raise ComparisonDesignError(f"{field} must cover every workload case exactly once")
    return sorted(traces, key=lambda item: item["case_id"])


def _methods(
    value: Any,
    cases: Mapping[str, dict],
    oracle: Mapping[str, dict],
) -> List[dict]:
    if not isinstance(value, (list, tuple)) or len(value) < 2:
        raise ComparisonDesignError("a comparative evaluation requires at least two methods")
    methods, seen = [], set()
    for index, raw in enumerate(value):
        if not isinstance(raw, Mapping):
            raise ComparisonDesignError(f"methods[{index}] must be an object")
        method_id = _identity(raw.get("method_id"), f"methods[{index}].method_id")
        if method_id in seen:
            raise ComparisonDesignError("method identities must be unique")
        seen.add(method_id)
        method = {
            "method_id": method_id,
            "name": _identity(raw.get("name"), f"methods[{index}].name"),
            "version": _identity(raw.get("version"), f"methods[{index}].version"),
            "workflow": _identity(raw.get("workflow"), f"methods[{index}].workflow"),
            "input_bindings": _normalize_bindings(
                raw.get("input_bindings"), f"methods[{index}].input_bindings"
            ),
            "declared_budget": _normalize_budget(
                raw.get("declared_budget"), f"methods[{index}].declared_budget"
            ),
            "trace": _trace(raw.get("trace"), cases, oracle, f"methods[{index}].trace"),
        }
        methods.append(_sealed(method, "method_hash"))
    return sorted(methods, key=lambda item: item["method_id"])


def _denominators(cases: Mapping[str, dict]) -> dict:
    case_ids = sorted(cases)
    eligible = [
        {"case_id": case_id, "item_id": item_id}
        for case_id in case_ids
        for item_id in cases[case_id]["eligible_ids"]
    ]
    work = [
        {"case_id": case_id, "item_id": item_id}
        for case_id in case_ids
        for item_id in cases[case_id]["work_item_ids"]
    ]
    return {
        "cases": {"members": case_ids, "value": _exact(len(case_ids)), "unit": "cases"},
        "eligible_memberships": {
            "members": eligible,
            "value": _exact(len(eligible)),
            "unit": "case-realization memberships",
        },
        "work_item_memberships": {
            "members": work,
            "value": _exact(len(work)),
            "unit": "case-work-item memberships",
        },
        "regret_evaluations": {
            "members": case_ids,
            "value": _exact(len(case_ids)),
            "unit": "case evaluations",
        },
        "verification_attempts": {
            "members": case_ids,
            "value": _exact(len(case_ids)),
            "unit": "verification attempts",
        },
    }


def _ratio(numerator: int | Fraction, denominator: int) -> dict:
    if denominator <= 0:
        raise ComparisonDesignError("registered denominator must be positive")
    return _exact(Fraction(numerator, denominator))


def _facts(method: Mapping[str, Any], oracle: Mapping[str, dict], denominators: dict) -> dict:
    retained = misses = affected = preserved = invalidated = verified = 0
    regrets: List[Fraction] = []
    status_counts: Dict[str, int] = {}
    for trace in method["trace"]:
        answer = oracle[trace["case_id"]]
        retained += len(trace["retained_ids"])
        misses += int(not (set(trace["selected_ids"]) & set(answer["winner_ids"])))
        regret = _fraction(trace["achieved_value"], "achieved_value") - _fraction(
            answer["optimum"], "oracle optimum"
        )
        regrets.append(regret)
        affected += len(trace["affected_ids"])
        preserved += len(trace["preserved_ids"])
        invalidated += len(trace["invalidated_ids"])
        status = trace["verifier_status"]
        status_counts[status] = status_counts.get(status, 0) + 1
        verified += int(status in _VERIFIED_STATUSES)
    cases = len(method["trace"])
    eligible_denominator = len(denominators["eligible_memberships"]["members"])
    work_denominator = len(denominators["work_item_memberships"]["members"])
    total_regret = sum(regrets, Fraction(0))
    return {
        "facts_profile": FACTS_PROFILE,
        "retention_burden": {
            "retained_memberships": _exact(retained),
            "fraction": _ratio(retained, eligible_denominator),
        },
        "oracle_misses": {"count": _exact(misses), "fraction": _ratio(misses, cases)},
        "regret": {
            "total": _exact(total_regret),
            "maximum": _exact(max(regrets)),
            "mean": _exact(total_regret / cases),
        },
        "affected_work": {"count": _exact(affected), "fraction": _ratio(affected, work_denominator)},
        "preserved_work": {"count": _exact(preserved), "fraction": _ratio(preserved, work_denominator)},
        "invalidated_work": {
            "count": _exact(invalidated),
            "fraction": _ratio(invalidated, work_denominator),
        },
        "verification": {
            "verified_count": _exact(verified),
            "fraction": _ratio(verified, cases),
            "status_counts": [
                {"status": status, "count": _exact(status_counts[status])}
                for status in sorted(status_counts)
            ],
        },
    }


def _comparability(expected: Mapping[str, str], oracle: Mapping[str, Any], methods: Sequence[dict]) -> dict:
    reasons: List[str] = []
    if oracle["input_bindings"] != expected:
        reasons.append("ORACLE_INPUT_BINDINGS_MISMATCH")
    baseline = methods[0]["declared_budget"]
    for method in methods:
        if method["input_bindings"] != expected:
            reasons.append(f"METHOD_INPUT_BINDINGS_MISMATCH:{method['method_id']}")
        if method["declared_budget"] != baseline:
            reasons.append(f"METHOD_BUDGET_MISMATCH:{method['method_id']}")
    return {
        "status": COMPARABLE if not reasons else NON_COMPARABLE,
        "reasons": sorted(reasons),
        "conclusion": NO_CONCLUSION,
    }


def _local_observations(value: Any, method_ids: set) -> List[dict]:
    if value is None:
        return []
    if not isinstance(value, (list, tuple)):
        raise ComparisonDesignError("local_observations must be a list")
    result, seen = [], set()
    for index, raw in enumerate(value):
        if not isinstance(raw, Mapping):
            raise ComparisonDesignError(f"local_observations[{index}] must be an object")
        identifier = _identity(raw.get("observation_id"), "local observation identity")
        if identifier in seen:
            raise ComparisonDesignError("local observation identities must be unique")
        seen.add(identifier)
        method_id = _identity(raw.get("method_id"), "local observation method identity")
        if method_id not in method_ids:
            raise ComparisonDesignError("a local observation names an unknown method")
        record = {
            "observation_id": identifier,
            "classification": "LOCAL_OBSERVATION_NON_AUTHORIZING",
            "method_id": method_id,
            "observer": _identity(raw.get("observer"), "local observation observer"),
            "metric": _identity(raw.get("metric"), "local observation metric"),
            "value": _exact(_fraction(raw.get("value"), "local observation value")),
            "unit": _identity(raw.get("unit"), "local observation unit"),
            "context": _canonical(raw.get("context", {})),
        }
        _assert_no_forbidden_keys(record, "local_observations")
        result.append(_sealed(record, "observation_hash"))
    return sorted(result, key=lambda item: item["observation_id"])


def _counterfactuals(value: Any) -> List[dict]:
    if value is None:
        return []
    if not isinstance(value, (list, tuple)):
        raise ComparisonDesignError("declared_counterfactuals must be a list")
    result, seen = [], set()
    for index, raw in enumerate(value):
        if not isinstance(raw, Mapping):
            raise ComparisonDesignError(f"declared_counterfactuals[{index}] must be an object")
        identifier = _identity(raw.get("assertion_id"), "counterfactual identity")
        if identifier in seen:
            raise ComparisonDesignError("counterfactual identities must be unique")
        seen.add(identifier)
        record = {
            "assertion_id": identifier,
            "classification": "USER_DECLARED_COUNTERFACTUAL_NON_AUTHORIZING",
            "statement": _identity(raw.get("statement"), "counterfactual statement"),
            "provenance": _identity(raw.get("provenance"), "counterfactual provenance"),
        }
        _assert_no_forbidden_keys(raw, "declared_counterfactuals")
        result.append(_sealed(record, "assertion_hash"))
    return sorted(result, key=lambda item: item["assertion_id"])


@dataclass(frozen=True)
class ComparativeWorkflowEvaluation:
    """Immutable convenience wrapper around the portable canonical record."""

    record: Mapping[str, Any]

    def to_canonical(self) -> dict:
        return copy.deepcopy(dict(self.record))


def build_comparative_workflow_evaluation(
    evaluation_id: str,
    *,
    inputs: Mapping[str, Any],
    realization_family_input_id: str,
    decision_family_input_id: str,
    technology_scope: Any,
    evidence_scope: Any,
    change_scope: Any,
    scenario_scope: Any,
    held_out_treatment: Any,
    workload: Sequence[Mapping[str, Any]],
    oracle: Mapping[str, Any],
    methods: Sequence[Mapping[str, Any]],
    limitations: Sequence[str],
    local_observations: Sequence[Mapping[str, Any]] = (),
    declared_counterfactuals: Sequence[Mapping[str, Any]] = (),
) -> ComparativeWorkflowEvaluation:
    """Build one exact, portable, strictly non-authorizing evaluation.

    ``methods`` remain individually described; this function computes no
    between-method delta, ordering, winner, or economic interpretation.
    ``comparability`` states only whether the declared experimental design
    held shared inputs and budgets constant.
    """

    identifier = _identity(evaluation_id, "evaluation_id")
    input_records, expected_bindings, contents = _input_records(inputs)
    scope = _family_scope(
        contents,
        expected_bindings,
        realization_family_input_id,
        decision_family_input_id,
        {
            "technology_scope": technology_scope,
            "evidence_scope": evidence_scope,
            "change_scope": change_scope,
            "scenario_scope": scenario_scope,
            "held_out_treatment": held_out_treatment,
        },
    )
    family = contents[scope["realization_family_input_id"]]
    legal_ids = [item["realization_id"] for item in family["realizations"]]
    workload_records, cases = _workload_cases(workload, legal_ids)
    oracle_record, oracle_answers = _oracle(oracle, cases)
    method_records = _methods(methods, cases, oracle_answers)
    denominators = _denominators(cases)
    results = []
    for method in method_records:
        result = {
            "method_id": method["method_id"],
            "method_hash": method["method_hash"],
            "result_scope": {
                "scope_hash": scope["scope_hash"],
                "case_ids": sorted(cases),
                "input_bindings": dict(expected_bindings),
                "authority": COMPARISON_AUTHORITY,
            },
            "denominators": copy.deepcopy(denominators),
            "system_derived_facts": _facts(method, oracle_answers, denominators),
        }
        _assert_no_forbidden_keys(result, f"results.{method['method_id']}")
        results.append(_sealed(result, "result_hash"))
    limitation_records = [_identity(item, "limitation") for item in limitations]
    if not limitation_records:
        raise ComparisonDesignError("a comparative evaluation must state its limitations")
    if len(set(limitation_records)) != len(limitation_records):
        raise ComparisonDesignError("limitations must not contain duplicates")
    method_ids = {item["method_id"] for item in method_records}
    record = {
        "record_type": "ComparativeWorkflowEvaluation",
        "schema_version": COMPARISON_SCHEMA_VERSION,
        "profile": COMPARISON_PROFILE,
        "evaluation_id": identifier,
        "authority": COMPARISON_AUTHORITY,
        "authorizing": False,
        "semantic_effect": "NONE",
        "evidence_class": "NON_AUTHORIZING_COMPARATIVE_PRODUCT_EVIDENCE",
        "claim_boundary": COMPARISON_CLAIM_BOUNDARY,
        "inputs": input_records,
        "scope": scope,
        "workload": workload_records,
        "oracle": oracle_record,
        "methods": method_records,
        "comparability": _comparability(expected_bindings, oracle_record, method_records),
        "results": results,
        "local_observations": _local_observations(local_observations, method_ids),
        "declared_counterfactuals": _counterfactuals(declared_counterfactuals),
        "limitations": sorted(limitation_records),
    }
    _assert_no_forbidden_keys(record["comparability"], "comparability")
    return ComparativeWorkflowEvaluation(_sealed(record, "record_hash"))
