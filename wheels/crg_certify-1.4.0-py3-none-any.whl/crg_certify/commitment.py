"""First-class safe-commitment planning and evidence artifacts.

This module is the additive v1.1 profile for Master Specification sections
20, 26, 27, and 29 and Canonical Product Roadmap workstream B.  It does not
change the v1.0.1 query or certificate formats.  Instead it packages the
already-authoritative objects into a portable record that makes a future
decision family, its retention policies, every pruning obligation, and any
regret evidence directly inspectable and independently reconstructible.

Only registered finite/exact profiles are authorized.  Unknown policies,
unregistered objective families, continuous approximation claims without a
registered proof profile, and missing geometry are represented as explicit
refusals.  They are never interpreted optimistically.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from crg_model.canonical import content_hash
from crg_model.completeness import CompletenessBasisType
from crg_model.envelope import EvidenceClass
from crg_model.numeric import Exact, Interval
from crg_model.records import (
    DecisionScope,
    DerivationRecord,
    ObservationLevel,
    RealizationBundle,
    Signature,
)

from .certify import (
    Comparison,
    CertifyError,
    GeometryUnavailable,
    ObjectiveError,
    _build_candidate,
    _declared_regret_bound,
    _fiber_closure,
    _fiber_representatives,
    _frontier,
    _preservation,
    _require_geometry,
    _sub_bundle,
    bind_schema,
    compare_candidates,
    evaluate_objective,
    retention_set,
)
from .query import ADDITIVE_TYPES, LEDGER_TYPES, RetentionPolicy
from .regret import REGRET_OBJECTIVE_FAMILY, build_regret_witness

__all__ = [
    "SAFE_COMMITMENT_SCHEMA_VERSION",
    "SAFE_COMMITMENT_PROFILE",
    "ConditionStatus",
    "PolicyStatus",
    "FutureDecision",
    "FutureDecisionFamily",
    "RetentionPolicyDeclaration",
    "PruningCondition",
    "PruningAssessment",
    "RegretEvidence",
    "RegretBoundFact",
    "RetentionEvaluation",
    "SafeCommitmentArtifact",
    "assess_pruning",
    "compare_retention_policies",
]

SAFE_COMMITMENT_SCHEMA_VERSION = "1.1.0"
SAFE_COMMITMENT_PROFILE = "crg-safe-commitment/finite-exact@1"
REGRET_PROOF_PROFILE = "crg-regret/strict-separation-finite-exact@1"
BOUND_PROOF_PROFILE = "crg-regret-bound/fixed-additive-finite-exact@1"


class ConditionStatus:
    PASS = "PASS"
    FAIL = "FAIL"
    NOT_REACHED = "NOT_REACHED"


class PolicyStatus:
    CERTIFIED = "CERTIFIED"
    CERTIFIED_BOUNDED = "CERTIFIED_BOUNDED"
    REFUSED = "REFUSED"


_REGISTERED_POLICIES = frozenset(
    {
        RetentionPolicy.RETAIN_ALL,
        RetentionPolicy.FIBER_PRESERVING,
        RetentionPolicy.RETAIN_ALL_SIGNATURES,
        RetentionPolicy.UNIVERSAL_MONOTONE,
        RetentionPolicy.ADDITIVE_PRICE_VISIBLE,
        RetentionPolicy.RETAIN_ALL_WINNERS,
        RetentionPolicy.ARGMIN_HITTING,
        RetentionPolicy.BOUNDED_REGRET,
    }
)


def _canonical(value: Any) -> Any:
    if value is None:
        return None
    method = getattr(value, "to_canonical", None)
    if callable(method):
        return method()
    if isinstance(value, Mapping):
        return {str(key): _canonical(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_canonical(item) for item in value]
    return value


def _normal_policy(value: str) -> str:
    text = str(value).strip()
    return RetentionPolicy.ALIASES.get(text.upper(), text.lower())


def _point_key(point: Signature) -> Tuple[Any, ...]:
    return point.sort_key()


def _signature_groups(bundle: RealizationBundle, keep: Iterable[str]) -> List[dict]:
    selected = set(keep)
    groups: Dict[Signature, List[str]] = {}
    for realization in sorted(bundle.realizations, key=lambda item: item.realization_id):
        if realization.realization_id in selected:
            groups.setdefault(realization.signature, []).append(realization.realization_id)
    return [
        {"signature": point.to_canonical(), "realization_ids": identifiers}
        for point, identifiers in sorted(groups.items(), key=lambda item: _point_key(item[0]))
    ]


@dataclass(frozen=True)
class FutureDecision:
    """One compiled member of a future decision family (spec 26.5)."""

    decision_id: str
    scope: DecisionScope
    derivation: DerivationRecord

    def __post_init__(self) -> None:
        if not self.decision_id:
            raise CertifyError("a future decision requires a non-empty identity")
        expected = ObservationLevel.REQUIRED_OBJECT.get(self.scope.observation_level)
        if self.derivation.decision_class != self.scope.observation_level:
            raise CertifyError(
                f"future decision {self.decision_id!r} has a scope/derivation class mismatch"
            )
        if self.derivation.required_object != expected:
            raise CertifyError(
                f"future decision {self.decision_id!r} requires {expected!r}, but its "
                f"derivation declares {self.derivation.required_object!r}"
            )

    def to_canonical(self) -> dict:
        return {
            "decision_id": self.decision_id,
            "scope": self.scope.to_canonical(),
            "derivation": self.derivation.to_canonical(),
        }


@dataclass(frozen=True)
class FutureDecisionFamily:
    """A named set of decisions that must remain valid together."""

    family_id: str
    decisions: Sequence[FutureDecision]
    scenario_scope: Mapping[str, Any] = field(default_factory=dict)
    authority: Optional[str] = None
    validity: Optional[str] = None

    def __post_init__(self) -> None:
        if not self.family_id:
            raise CertifyError("a future decision family requires a non-empty identity")
        if not self.decisions:
            raise CertifyError("a future decision family must contain at least one decision")
        identifiers = [decision.decision_id for decision in self.decisions]
        if len(set(identifiers)) != len(identifiers):
            raise CertifyError("future decision identifiers must be unique within a family")

    def to_canonical(self) -> dict:
        record = {
            "record_type": "FutureDecisionFamily",
            "family_id": self.family_id,
            "decisions": [decision.to_canonical() for decision in self.decisions],
            "scenario_scope": _canonical(self.scenario_scope),
        }
        if self.authority:
            record["authority"] = self.authority
        if self.validity:
            record["validity"] = self.validity
        record["family_hash"] = content_hash(record)
        return record


@dataclass(frozen=True)
class RetentionPolicyDeclaration:
    """A policy proposal bound to exactly one future decision family."""

    policy_id: str
    family_id: str
    policy: str
    parameters: Mapping[str, Any] = field(default_factory=dict)
    protected_ids: Sequence[str] = ()
    protected_classes: Mapping[str, Sequence[Any]] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.policy_id or not self.family_id:
            raise CertifyError("a retention declaration requires policy and family identities")

    @property
    def normalized_policy(self) -> str:
        return _normal_policy(self.policy)

    def to_canonical(self) -> dict:
        return {
            "record_type": "RetentionPolicyDeclaration",
            "policy_id": self.policy_id,
            "family_id": self.family_id,
            "policy": self.normalized_policy,
            "parameters": _canonical(self.parameters),
            "protected_ids": sorted(set(str(item) for item in self.protected_ids)),
            "protected_classes": _canonical(self.protected_classes),
        }


@dataclass(frozen=True)
class PruningCondition:
    number: int
    identifier: str
    status: str
    detail: str
    evidence: Sequence[str] = ()

    def to_canonical(self) -> dict:
        return {
            "number": self.number,
            "identifier": self.identifier,
            "status": self.status,
            "detail": self.detail,
            "evidence": list(self.evidence),
        }


@dataclass(frozen=True)
class PruningAssessment:
    candidate_id: str
    decision_id: str
    conditions: Sequence[PruningCondition]
    authorized: bool
    certificate: Optional[dict] = None

    def to_canonical(self) -> dict:
        record = {
            "record_type": "PruningAssessment",
            "candidate_id": self.candidate_id,
            "decision_id": self.decision_id,
            "conditions": [condition.to_canonical() for condition in self.conditions],
            "authorized": self.authorized,
        }
        if self.certificate is not None:
            record["certificate"] = self.certificate
        return record


@dataclass(frozen=True)
class RegretEvidence:
    witness_id: str
    decision_id: str
    full_registry_hash: str
    retained_registry_hash: str
    lost_element: Mapping[str, Any]
    objective: Mapping[str, Any]
    family_membership_proof: Mapping[str, Any]
    full_infimum: Exact
    retained_infimum: Exact
    gap: Exact
    numeric_interval: Interval
    evidence_interval: Interval
    completeness: Mapping[str, Any]
    scope: str
    full_generators: Sequence[Signature]
    retained_generators: Sequence[Signature]
    dependencies: Sequence[str]
    validity: Optional[str] = None
    evidence_class: str = "EXACT"
    verification_program: str = REGRET_PROOF_PROFILE

    def to_canonical(self) -> dict:
        record = {
            "record_type": "RegretEvidence",
            "witness_id": self.witness_id,
            "decision_id": self.decision_id,
            "full_registry_hash": self.full_registry_hash,
            "retained_registry_hash": self.retained_registry_hash,
            "lost_element": _canonical(self.lost_element),
            "objective": _canonical(self.objective),
            "family_membership_proof": _canonical(self.family_membership_proof),
            "full_infimum": self.full_infimum.to_canonical(),
            "retained_infimum": self.retained_infimum.to_canonical(),
            "gap": self.gap.to_canonical(),
            "numeric_interval": self.numeric_interval.to_canonical(),
            "evidence_interval": self.evidence_interval.to_canonical(),
            "completeness": _canonical(self.completeness),
            "scope": self.scope,
            "full_generators": [point.to_canonical() for point in self.full_generators],
            "retained_generators": [point.to_canonical() for point in self.retained_generators],
            "dependencies": sorted(set(self.dependencies)),
            "evidence_class": self.evidence_class,
            "verification_program": self.verification_program,
        }
        if self.validity:
            record["validity"] = self.validity
        record["witness_hash"] = content_hash(record)
        return record


@dataclass(frozen=True)
class RegretBoundFact:
    fact_id: str
    decision_id: str
    objective_family: Mapping[str, Any]
    coordinate_order: Sequence[str]
    full_values: Mapping[str, Signature]
    retained_ids: Sequence[str]
    bound: Exact
    tolerance: Exact
    accepted: bool
    completeness: Mapping[str, Any]
    dependencies: Sequence[str]
    proof_profile: str = BOUND_PROOF_PROFILE
    evidence_class: str = "EXACT"

    def to_canonical(self) -> dict:
        record = {
            "record_type": "RegretBoundFact",
            "fact_id": self.fact_id,
            "decision_id": self.decision_id,
            "objective_family": _canonical(self.objective_family),
            "coordinate_order": list(self.coordinate_order),
            "full_values": [
                {"realization_id": rid, "signature": point.to_canonical()}
                for rid, point in sorted(self.full_values.items())
            ],
            "retained_ids": sorted(set(self.retained_ids)),
            "bound": self.bound.to_canonical(),
            "tolerance": self.tolerance.to_canonical(),
            "accepted": self.accepted,
            "completeness": _canonical(self.completeness),
            "dependencies": sorted(set(self.dependencies)),
            "proof_profile": self.proof_profile,
            "evidence_class": self.evidence_class,
        }
        record["fact_hash"] = content_hash(record)
        return record


@dataclass(frozen=True)
class RetentionEvaluation:
    policy_id: str
    family_id: str
    policy: str
    status: str
    retained_ids: Sequence[str]
    pruned_ids: Sequence[str]
    retained_fibers: Sequence[Mapping[str, Any]]
    geometry_preview: Mapping[str, Any]
    decision_results: Sequence[Mapping[str, Any]]
    pruning_assessments: Sequence[PruningAssessment] = ()
    regret_evidence: Sequence[RegretEvidence] = ()
    regret_bounds: Sequence[RegretBoundFact] = ()
    refusals: Sequence[str] = ()

    def to_canonical(self) -> dict:
        return {
            "record_type": "RetentionEvaluation",
            "policy_id": self.policy_id,
            "family_id": self.family_id,
            "policy": self.policy,
            "status": self.status,
            "retained_ids": sorted(set(self.retained_ids)),
            "pruned_ids": sorted(set(self.pruned_ids)),
            "retained_fibers": _canonical(self.retained_fibers),
            "geometry_preview": _canonical(self.geometry_preview),
            "decision_results": _canonical(self.decision_results),
            "pruning_assessments": [item.to_canonical() for item in self.pruning_assessments],
            "regret_evidence": [item.to_canonical() for item in self.regret_evidence],
            "regret_bounds": [item.to_canonical() for item in self.regret_bounds],
            "refusals": list(self.refusals),
        }


@dataclass(frozen=True)
class SafeCommitmentArtifact:
    artifact_id: str
    family: FutureDecisionFamily
    registry: Mapping[str, Any]
    policies: Sequence[RetentionPolicyDeclaration]
    evaluations: Sequence[RetentionEvaluation]
    schema_version: str = SAFE_COMMITMENT_SCHEMA_VERSION
    profile: str = SAFE_COMMITMENT_PROFILE

    def to_canonical(self) -> dict:
        record = {
            "record_type": "SafeCommitmentArtifact",
            "schema_version": self.schema_version,
            "profile": self.profile,
            "artifact_id": self.artifact_id,
            "family": self.family.to_canonical(),
            "registry": _canonical(self.registry),
            "policies": [policy.to_canonical() for policy in self.policies],
            "evaluations": [evaluation.to_canonical() for evaluation in self.evaluations],
        }
        record["artifact_hash"] = content_hash(record)
        return record


def _condition(number: int, identifier: str, passed: bool, detail: str, *evidence: str) -> PruningCondition:
    return PruningCondition(
        number=number,
        identifier=identifier,
        status=ConditionStatus.PASS if passed else ConditionStatus.FAIL,
        detail=detail,
        evidence=tuple(item for item in evidence if item),
    )


def assess_pruning(
    bundle: RealizationBundle,
    decision: FutureDecision,
    candidates: Sequence[str],
    *,
    geometry: Any = None,
) -> Tuple[PruningAssessment, ...]:
    """Expose all ten §29.2 pruning conditions for every proposed deletion.

    Geometry is assessed jointly over the whole proposed deletion, as it is in
    :func:`certified_pruning`; candidate-local numerical conditions are then
    recorded individually.  Failed conditions remain in the result instead of
    disappearing with the absent certificate.
    """
    by_id = {item.realization_id: item for item in bundle.realizations}
    requested = tuple(sorted(set(str(item) for item in candidates)))
    unknown = [item for item in requested if item not in by_id]
    if unknown:
        raise CertifyError(f"pruning candidates absent from the bundle: {unknown}")
    survivors = tuple(sorted(set(by_id) - set(requested)))
    bound_scope = bind_schema(decision.scope, bundle.schema)
    required = decision.derivation.required_object

    preservation = None
    preservation_error = None
    if survivors:
        try:
            preservation = _preservation(bundle, survivors, required, bound_scope, geometry)
        except (GeometryUnavailable, ObjectiveError, CertifyError) as error:
            preservation_error = str(error)

    incumbents = []
    for identifier in survivors:
        try:
            value = _build_candidate(by_id[identifier], bound_scope, bundle.schema)
        except (ObjectiveError, CertifyError):
            continue
        if value.feasibility == "FEASIBLE":
            incumbents.append(value)

    assessments: List[PruningAssessment] = []
    for identifier in requested:
        realization = by_id[identifier]
        try:
            pruned = _build_candidate(realization, bound_scope, bundle.schema)
            bound_valid = EvidenceClass.may_authorize(realization.evidence_class)
            bound_detail = (
                "an interval-safe candidate lower bound is exactly evaluable"
                if bound_valid else
                f"evidence class {realization.evidence_class!r} may not authorize deletion"
            )
        except (ObjectiveError, CertifyError) as error:
            pruned = None
            bound_valid = False
            bound_detail = f"candidate lower bound is unavailable: {error}"

        scope_value = realization.attributes.get("scope")
        scope_match = scope_value is None or str(scope_value) == decision.scope.scope_id
        derivation_permits = (
            decision.derivation.required_object
            == ObservationLevel.REQUIRED_OBJECT.get(decision.scope.observation_level)
            and decision.scope.observation_level != ObservationLevel.REALIZATION
        )
        dependencies_valid = bool(realization.attributes.get("dependencies_valid", True)) and (
            EvidenceClass.may_authorize(realization.evidence_class)
        )
        completeness_valid = bundle.completeness.basis_type != CompletenessBasisType.UNKNOWN
        geometry_valid = bool(preservation and preservation.preserved)

        best = None
        if pruned is not None:
            for incumbent in incumbents:
                if compare_candidates(incumbent, pruned, bound_scope) == Comparison.STRICTLY_BETTER:
                    best = incumbent
                    break
        comparison_valid = best is not None
        tie_valid = comparison_valid
        incumbent_valid = bool(incumbents)

        conditions = [
            _condition(1, "VALID_LOWER_OR_OUTER_BOUND", bound_valid, bound_detail),
            _condition(
                2,
                "FEASIBLE_INCUMBENT_OR_UPPER_WITNESS",
                incumbent_valid,
                "a feasible retained incumbent is available" if incumbent_valid else
                "no feasible retained incumbent is available",
            ),
            _condition(
                3,
                "SCOPE_MATCH",
                scope_match,
                "candidate and decision scopes match" if scope_match else
                f"candidate scope {scope_value!r} differs from {decision.scope.scope_id!r}",
            ),
            _condition(
                4,
                "DERIVATION_PERMITS_COMPARISON",
                derivation_permits,
                f"compiled requirement {required!r} permits deletion comparison" if derivation_permits
                else "compiled decision is realization-sensitive or internally inconsistent",
                decision.derivation.query_hash,
            ),
            _condition(
                5,
                "INTERVAL_SAFE_COMPARISON",
                comparison_valid,
                f"incumbent {best.realization_id!r} is strictly better" if best else
                "no retained incumbent is interval-safely strictly better",
            ),
            _condition(
                6,
                "TIE_POLICY_PRESERVED",
                tie_valid,
                "strict comparison remains beyond policy tolerance" if tie_valid else
                "the declared tie policy does not authorize deletion",
            ),
            _condition(
                7,
                "REQUIRED_GEOMETRY_PRESERVED",
                geometry_valid,
                preservation.detail if preservation else
                (preservation_error or "no survivor registry is available"),
            ),
            _condition(
                8,
                "COMPLETENESS_IMPLICATIONS_VALID",
                completeness_valid,
                f"completeness basis is {bundle.completeness.basis_type!r}" if completeness_valid
                else "UNKNOWN completeness cannot authorize pruning",
            ),
            _condition(
                9,
                "DEPENDENCIES_VALID",
                dependencies_valid,
                "dependencies and evidence may authorize" if dependencies_valid else
                "a dependency or evidence class may not authorize deletion",
            ),
        ]
        authorized_before_emit = all(item.status == ConditionStatus.PASS for item in conditions)
        certificate = None
        if authorized_before_emit and pruned is not None and best is not None:
            certificate = {
                "pruned_id": identifier,
                "lower_bound": Interval(pruned.interval.lo, pruned.interval.lo).to_canonical(),
                "incumbent_id": best.realization_id,
                "incumbent_upper": Interval(best.interval.hi, best.interval.hi).to_canonical(),
                "scope_id": decision.scope.scope_id,
                "tie_policy_satisfied": True,
                "geometry_preserved": True,
                "dependencies_valid": True,
            }
            certificate["certificate_hash"] = content_hash(certificate)
        conditions.append(
            _condition(
                10,
                "PRUNING_CERTIFICATE_EMITTED",
                certificate is not None,
                "a canonical pruning certificate was emitted" if certificate else
                "certificate withheld because at least one prerequisite failed",
            )
        )
        assessments.append(
            PruningAssessment(
                candidate_id=identifier,
                decision_id=decision.decision_id,
                conditions=tuple(conditions),
                authorized=certificate is not None,
                certificate=certificate,
            )
        )
    return tuple(assessments)


def _protected_ids(bundle: RealizationBundle, declaration: RetentionPolicyDeclaration) -> set:
    by_id = {item.realization_id: item for item in bundle.realizations}
    protected = set(str(item) for item in declaration.protected_ids)
    unknown = protected - set(by_id)
    if unknown:
        raise CertifyError(f"protected realization identities are absent: {sorted(unknown)}")
    for field_name, allowed_values in declaration.protected_classes.items():
        allowed = set(allowed_values)
        for realization in bundle.realizations:
            if realization.attributes.get(field_name) in allowed:
                protected.add(realization.realization_id)
    return protected


def _family_protected_ids(bundle: RealizationBundle, family: FutureDecisionFamily) -> set:
    protected = set()
    for decision in family.decisions:
        objective = decision.scope.objective_family or {}
        protected.update(str(item) for item in objective.get("protected_ids", ()))
        protected.update(str(item) for item in objective.get("required_retained_identities", ()))
    unknown = protected - {item.realization_id for item in bundle.realizations}
    if unknown:
        raise CertifyError(f"future decision family protects absent identities: {sorted(unknown)}")
    return protected


def _retained_ids(
    bundle: RealizationBundle,
    family: FutureDecisionFamily,
    declaration: RetentionPolicyDeclaration,
    geometry: Any,
) -> Tuple[str, ...]:
    policy = declaration.normalized_policy
    if policy in RetentionPolicy.DECLARED_UNSUPPORTED:
        raise CertifyError(
            f"retention policy {policy!r} is established by specification 29.3, but the "
            "finite/exact safe-commitment profile has no registered constructive and "
            "independent verification semantics for it; reduction is refused"
        )
    if policy not in _REGISTERED_POLICIES:
        raise CertifyError(f"unknown retention policy {policy!r}; reduction is refused")
    if policy == RetentionPolicy.ADDITIVE_PRICE_VISIBLE and bundle.schema.dimension != 2:
        raise CertifyError(
            "the independently reconstructible additive-price-visible artifact profile is "
            "registered for exact planar finite geometry only"
        )
    proposed = declaration.parameters.get("retained_ids")
    if proposed is not None:
        if policy != RetentionPolicy.BOUNDED_REGRET:
            raise CertifyError(
                "an explicit retained_ids approximation is registered only for bounded-regret"
            )
        identifiers = set(str(item) for item in proposed)
        unknown = identifiers - {item.realization_id for item in bundle.realizations}
        if unknown:
            raise CertifyError(f"retained identities are absent: {sorted(unknown)}")
        if not identifiers:
            raise CertifyError("empty retained families have unbounded regret and are refused")
        return tuple(
            sorted(
                identifiers
                | _protected_ids(bundle, declaration)
                | _family_protected_ids(bundle, family)
            )
        )

    # Exact policies use the existing sound kernel.  Geometry is injected
    # explicitly; no hidden server or process-global provider is required.
    scopes = [decision.scope for decision in family.decisions]
    if policy in {RetentionPolicy.ARGMIN_HITTING, RetentionPolicy.RETAIN_ALL_WINNERS}:
        scopes = [
            scope
            for scope in scopes
            if str(scope.objective_family.get("type")) in LEDGER_TYPES
        ]
        if not scopes:
            raise CertifyError(
                f"retention policy {policy!r} requires a finite named decision ledger"
            )
    retained = set(retention_set(bundle, scopes, policy, geometry=geometry))
    retained.update(_protected_ids(bundle, declaration))
    retained.update(_family_protected_ids(bundle, family))
    return tuple(sorted(retained))


def _geometry_preview(bundle: RealizationBundle, retained: Sequence[str], geometry: Any) -> dict:
    retained_bundle = _sub_bundle(bundle, retained)
    signatures = sorted(set(item.signature for item in retained_bundle.realizations), key=_point_key)
    record: Dict[str, Any] = {
        "R": [point.to_canonical() for point in signatures],
        "fibers": _signature_groups(bundle, retained),
    }
    if geometry is None or not signatures:
        record["GAMMA"] = {"status": "UNAVAILABLE"}
        record["K"] = {"status": "UNAVAILABLE"}
        return record
    frontier = _frontier(geometry, signatures)
    record["GAMMA"] = [point.to_canonical() for point in frontier]
    try:
        vertices = geometry.build_K(geometry.build_R(retained_bundle)).vertices
        record["K"] = [point.to_canonical() for point in vertices]
    except (NotImplementedError, ValueError) as error:
        record["K"] = {"status": "UNSUPPORTED_PROFILE", "detail": str(error)}
    return record


def _scope_kind(bundle: RealizationBundle) -> str:
    return (
        "GLOBAL"
        if bundle.completeness.basis_type
        in {
            CompletenessBasisType.EXHAUSTIVE_DECLARED_UNIVERSE,
            CompletenessBasisType.GENERATOR_CLOSED,
        }
        else "RELATIVE"
    )


def _regret_evidence(
    bundle: RealizationBundle,
    retained: Sequence[str],
    decision: FutureDecision,
    full_frontier: Sequence[Signature],
    retained_frontier: Sequence[Signature],
) -> Optional[RegretEvidence]:
    witness = build_regret_witness(full_frontier, retained_frontier, bundle.schema)
    if witness is None:
        return None
    retained_bundle = _sub_bundle(bundle, retained)
    base = {
        "decision_id": decision.decision_id,
        "full_registry_hash": bundle.bundle_hash(),
        "retained_registry_hash": retained_bundle.bundle_hash(),
        "lost_point": witness.lost_point.to_canonical(),
        "gap": witness.gap.to_canonical(),
    }
    return RegretEvidence(
        witness_id="regret-" + content_hash(base).split(":", 1)[1][:24],
        decision_id=decision.decision_id,
        full_registry_hash=bundle.bundle_hash(),
        retained_registry_hash=retained_bundle.bundle_hash(),
        lost_element={"kind": "SIGNATURE", "signature": witness.lost_point.to_canonical()},
        objective={
            "family": REGRET_OBJECTIVE_FAMILY,
            "construction": witness.construction,
            "anchor": witness.lost_point.to_canonical(),
            "epsilon": witness.epsilon.to_canonical(),
        },
        family_membership_proof={
            "profile": REGRET_PROOF_PROFILE,
            "epsilon_strictly_positive": True,
            "construction": "positive-part sup plus positive additive term",
        },
        full_infimum=witness.full_infimum,
        retained_infimum=witness.retained_infimum,
        gap=witness.gap,
        numeric_interval=Interval(witness.gap, witness.gap),
        evidence_interval=Interval(witness.gap, witness.gap),
        completeness=bundle.completeness.to_canonical(),
        scope=_scope_kind(bundle),
        full_generators=tuple(full_frontier),
        retained_generators=tuple(retained_frontier),
        dependencies=tuple(sorted(item.realization_id for item in bundle.realizations)),
        validity=decision.scope.validity,
    )


def _regret_bound_fact(
    bundle: RealizationBundle,
    retained: Sequence[str],
    decision: FutureDecision,
) -> RegretBoundFact:
    scope = bind_schema(decision.scope, bundle.schema)
    family = scope.objective_family
    if str(family.get("type")) not in ADDITIVE_TYPES:
        raise ObjectiveError("bounded-regret fact profile supports fixed additive objectives only")
    if str(family.get("quantification", "EACH_OBJECTIVE")) != "EACH_OBJECTIVE":
        raise ObjectiveError("coupled robust aggregates are outside the fixed-additive proof profile")
    bounded = family.get("bounded_regret") or {}
    if not bounded.get("accept_approximation") or bounded.get("tolerance") is None:
        raise ObjectiveError("bounded-regret acceptance and a tolerance must both be declared")
    retained_bundle = _sub_bundle(bundle, retained)
    bound = _declared_regret_bound(bundle, retained_bundle, scope)
    if bound is None:
        raise ObjectiveError(
            "the declared objective is not an exactly reconstructible fixed price vector; "
            "continuous approximation semantics are refused"
        )
    tolerance = Exact(bounded["tolerance"])
    order = tuple(family.get("coordinate_order") or ())
    fact_seed = {
        "decision_id": decision.decision_id,
        "retained_ids": sorted(retained),
        "bound": bound.to_canonical(),
    }
    return RegretBoundFact(
        fact_id="bound-" + content_hash(fact_seed).split(":", 1)[1][:24],
        decision_id=decision.decision_id,
        objective_family=family,
        coordinate_order=order,
        full_values={item.realization_id: item.signature for item in bundle.realizations},
        retained_ids=tuple(retained),
        bound=bound,
        tolerance=tolerance,
        accepted=bound <= tolerance,
        completeness=bundle.completeness.to_canonical(),
        dependencies=tuple(sorted(item.realization_id for item in bundle.realizations)),
    )


def _evaluate_policy(
    bundle: RealizationBundle,
    family: FutureDecisionFamily,
    declaration: RetentionPolicyDeclaration,
    geometry: Any,
) -> RetentionEvaluation:
    all_ids = tuple(sorted(item.realization_id for item in bundle.realizations))
    policy = declaration.normalized_policy
    refusals: List[str] = []
    try:
        if declaration.family_id != family.family_id:
            raise CertifyError(
                f"policy family {declaration.family_id!r} does not match {family.family_id!r}"
            )
        retained = _retained_ids(bundle, family, declaration, geometry)
    except (CertifyError, GeometryUnavailable, ObjectiveError, ValueError) as error:
        refusals.append(str(error))
        return RetentionEvaluation(
            policy_id=declaration.policy_id,
            family_id=family.family_id,
            policy=policy,
            status=PolicyStatus.REFUSED,
            retained_ids=all_ids,
            pruned_ids=(),
            retained_fibers=_signature_groups(bundle, all_ids),
            geometry_preview=_geometry_preview(bundle, all_ids, geometry),
            decision_results=(),
            refusals=tuple(refusals),
        )

    pruned = tuple(sorted(set(all_ids) - set(retained)))
    decisions: List[dict] = []
    witnesses: List[RegretEvidence] = []
    bounds: List[RegretBoundFact] = []
    assessments: List[PruningAssessment] = []
    any_bounded = False
    any_blocked = False
    for decision in family.decisions:
        bound_scope = bind_schema(decision.scope, bundle.schema)
        try:
            result = _preservation(
                bundle,
                retained,
                decision.derivation.required_object,
                bound_scope,
                geometry,
            )
            status = "PRESERVED"
            if result.approximate:
                status = "PRESERVED_WITH_BOUNDED_REGRET"
                any_bounded = True
            elif not result.preserved:
                status = "BLOCKED_GEOMETRY_LOSS"
                any_blocked = True
            decisions.append(
                {
                    "decision_id": decision.decision_id,
                    "status": status,
                    "required_object": decision.derivation.required_object,
                    "soundness_derivation": decision.derivation.to_canonical(),
                    "detail": result.detail,
                    "claim_consequence": (
                        "APPROXIMATE_ONLY" if result.approximate else
                        "PRESERVED" if result.preserved else "REFUSED"
                    ),
                }
            )
            if result.approximate:
                try:
                    bounds.append(_regret_bound_fact(bundle, retained, decision))
                except ObjectiveError as error:
                    any_blocked = True
                    refusals.append(f"{decision.decision_id}: {error}")
            if not result.preserved and result.full_frontier and result.retained_frontier:
                evidence = _regret_evidence(
                    bundle, retained, decision, result.full_frontier, result.retained_frontier
                )
                if evidence is not None:
                    witnesses.append(evidence)
        except (GeometryUnavailable, ObjectiveError, CertifyError, ValueError) as error:
            any_blocked = True
            refusals.append(f"{decision.decision_id}: {error}")
            decisions.append(
                {
                    "decision_id": decision.decision_id,
                    "status": "REFUSED",
                    "required_object": decision.derivation.required_object,
                    "soundness_derivation": decision.derivation.to_canonical(),
                    "detail": str(error),
                    "claim_consequence": "REFUSED",
                }
            )
        if pruned:
            assessments.extend(assess_pruning(bundle, decision, pruned, geometry=geometry))

    status = (
        PolicyStatus.REFUSED if any_blocked else
        PolicyStatus.CERTIFIED_BOUNDED if any_bounded else
        PolicyStatus.CERTIFIED
    )
    if any_blocked and not refusals:
        refusals.append("one or more future decisions lose their minimum sufficient object")
    return RetentionEvaluation(
        policy_id=declaration.policy_id,
        family_id=family.family_id,
        policy=policy,
        status=status,
        retained_ids=retained,
        pruned_ids=pruned,
        retained_fibers=_signature_groups(bundle, retained),
        geometry_preview=_geometry_preview(bundle, retained, geometry),
        decision_results=tuple(decisions),
        pruning_assessments=tuple(assessments),
        regret_evidence=tuple(witnesses),
        regret_bounds=tuple(bounds),
        refusals=tuple(refusals),
    )


def _registry_block(bundle: RealizationBundle) -> dict:
    return {
        "bundle_id": bundle.bundle_id,
        "bundle_hash": bundle.bundle_hash(),
        "bundle": bundle.to_canonical(),
        "schema": bundle.schema.to_canonical(),
        "completeness": bundle.completeness.to_canonical(),
        "entries": [
            {
                "realization_id": item.realization_id,
                "signature": item.signature.to_canonical(),
                "legality": item.legality,
                "attributes": _canonical(item.attributes),
                "evidence_class": item.evidence_class,
            }
            for item in sorted(bundle.realizations, key=lambda value: value.realization_id)
        ],
    }


def compare_retention_policies(
    bundle: RealizationBundle,
    family: FutureDecisionFamily,
    policies: Sequence[RetentionPolicyDeclaration],
    *,
    geometry: Any = None,
    artifact_id: Optional[str] = None,
) -> SafeCommitmentArtifact:
    """Evaluate policies under one identical family and scenario scope.

    The returned artifact is complete enough for the independent verifier to
    rederive registered policy sets, exact regret gaps and accepted fixed-price
    regret bounds without access to this package or the originating service.
    """
    if not policies:
        raise CertifyError("at least one retention policy must be declared for comparison")
    evaluations = tuple(
        _evaluate_policy(bundle, family, declaration, geometry) for declaration in policies
    )
    if artifact_id is None:
        seed = {
            "bundle_hash": bundle.bundle_hash(),
            "family_hash": family.to_canonical()["family_hash"],
            "policies": [item.to_canonical() for item in policies],
        }
        artifact_id = "safe-commitment-" + content_hash(seed).split(":", 1)[1][:24]
    return SafeCommitmentArtifact(
        artifact_id=artifact_id,
        family=family,
        registry=_registry_block(bundle),
        policies=tuple(policies),
        evaluations=evaluations,
    )
