"""Safe commitment, interval-safe decision, and certified pruning.

Normative basis: master specification section 29 (OID-CRG-002 safe
commitment and certified pruning), section 22 (numeric, uncertainty, tie,
and ambiguity semantics), section 21 (completeness basis and certificate
claim scope), and section 26 (the compiled decision scope this module
executes against).

This is the module that decides, so it is the module that must fail closed.
Four disciplines are enforced structurally rather than by convention:

1. **Interval safety (22.3-22.5).**  A strict winner exists only when
   ``U_p + tau < L_q`` for every competing feasible ``q``.  Overlap beyond
   tolerance never becomes a midpoint winner: it becomes a
   ``POSSIBLE_WINNER_SET`` or ``AMBIGUOUS``.
2. **Separated uncertainty (22.1-22.2).**  Numerical enclosure, evidence
   uncertainty, and policy tolerance are three different things and stay in
   three different fields of :class:`~crg_model.numeric.DecisionValue`.  The
   only merge is the explicit conservative one, and tolerance is applied only
   at decision time.
3. **Claim-scope gating (21.5).**  A ``PARTIAL_FAMILY`` claim scope can never
   emit a globally phrased winner.
4. **Geometry preservation (29.2, 27).**  When retention drops something the
   declared decision class needed, the answer is a block plus a regret
   witness, never a quietly different winner.

All arithmetic is exact rational or exact-interval.  No binary floating point
occurs on any certifying path.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from crg_model.canonical import content_hash
from crg_model.completeness import ClaimScope, CompletenessBasisType, derive_claim_scope
from crg_model.envelope import EvidenceClass
from crg_model.numeric import ArithmeticProfile, DecisionValue, Exact, Interval
from crg_model.units import DEFAULT_REGISTRY
from crg_model.records import (
    CertificatePins,
    DecisionCertificate,
    DecisionOutcome,
    DecisionScope,
    DerivationRecord,
    ObservationLevel,
    PruningCertificate,
    RealizationBundle,
    RealizationRecord,
    Signature,
)

from .query import (
    ADDITIVE_TYPES,
    ATTAINABILITY_TYPES,
    LEDGER_TYPES,
    MAPPING_TABLE_VERSION,
    MONOTONE_NONADDITIVE_TYPES,
    Quantification,
    RetentionPolicy,
    bind_schema,
    ledger_case_scopes,
    mapping_table_digest,
)
from .regret import build_regret_witness

__all__ = [
    "ENGINE_VERSION",
    "CertifyError",
    "ObjectiveError",
    "GeometryUnavailable",
    "Comparison",
    "Feasibility",
    "set_default_geometry",
    "evaluate_objective",
    "compare_candidates",
    "certify",
    "retention_set",
    "certified_pruning",
    "render_claim",
]

ENGINE_VERSION = "crg-certify@0.2.0"
VIR_PROGRAM = "crg-vir/decision-check@1"

_ZERO = Exact(0)


class CertifyError(ValueError):
    """Raised when certification input is structurally inadmissible."""


class ObjectiveError(CertifyError):
    """Raised when a declared objective family cannot be evaluated exactly."""


class GeometryUnavailable(CertifyError):
    """Raised when a geometry-dependent obligation cannot be discharged."""


class Comparison:
    """Pairwise verdicts under specification 22.3-22.5."""

    STRICTLY_BETTER = "STRICTLY_BETTER"
    STRICTLY_WORSE = "STRICTLY_WORSE"
    EXACTLY_EQUAL = "EXACTLY_EQUAL"
    WITHIN_TOLERANCE = "WITHIN_TOLERANCE"
    UNRESOLVED = "UNRESOLVED"


class Feasibility:
    FEASIBLE = "FEASIBLE"
    INFEASIBLE = "INFEASIBLE"
    UNKNOWN = "UNKNOWN"


# ---------------------------------------------------------------------------
# geometry binding
# ---------------------------------------------------------------------------
_DEFAULT_GEOMETRY: Any = None


def set_default_geometry(module: Any) -> None:
    """Bind the geometry provider used when no explicit module is passed.

    ``crg-certify`` depends on ``crg-geometry`` only through the published
    surface ``build_R``, ``build_gamma``, ``build_K``, ``pareto_minimal``,
    ``support_value``, and ``dominates_region``.
    """
    global _DEFAULT_GEOMETRY
    _DEFAULT_GEOMETRY = module


def _resolve_geometry(explicit: Any = None) -> Any:
    if explicit is not None:
        return explicit
    if _DEFAULT_GEOMETRY is not None:
        return _DEFAULT_GEOMETRY
    try:  # pragma: no cover - exercised only in a full installation
        import crg_geometry  # type: ignore

        return crg_geometry
    except ImportError:
        return None


def _require_geometry(explicit: Any, obligation: str) -> Any:
    geometry = _resolve_geometry(explicit)
    if geometry is None:
        raise GeometryUnavailable(
            f"{obligation} requires the geometry provider; refusing to proceed (spec 6.6 fail closed)"
        )
    return geometry


def _frontier(geometry: Any, signatures: Sequence[Signature]) -> Tuple[Signature, ...]:
    return tuple(geometry.pareto_minimal(tuple(signatures)))


# ---------------------------------------------------------------------------
# objective evaluation (spec 22.2, 26.3)
# ---------------------------------------------------------------------------
def _coordinate_order(scope: DecisionScope) -> Tuple[str, ...]:
    order = scope.objective_family.get("coordinate_order")
    if not order:
        raise ObjectiveError(
            "the decision scope has no bound coordinate order; call bind_schema(scope, schema) "
            "so weights cannot be silently transposed (spec 19.1)"
        )
    return tuple(order)


def _weight_intervals(scope: DecisionScope) -> Tuple[Interval, ...]:
    order = _coordinate_order(scope)
    weights = scope.objective_family.get("weights")
    if not weights:
        # An unweighted additive or max family is the all-ones price vector.
        return tuple(Interval(1, 1) for _ in order)
    missing = [c for c in order if c not in weights]
    if missing:
        raise ObjectiveError(
            f"objective family declares no weight for coordinates {missing}; an omitted "
            "weight is not the same as a zero weight and will not be assumed"
        )
    return tuple(Interval(weights[c][0], weights[c][1]) for c in order)


def _is_additive(scope: DecisionScope) -> bool:
    return str(scope.objective_family.get("type")) in ADDITIVE_TYPES


def _is_max_family(scope: DecisionScope) -> bool:
    kind = str(scope.objective_family.get("type"))
    return kind in {"max", "weighted_max", "bottleneck", "min_max", "minmax", "makespan"}


def _quantification(scope: DecisionScope) -> str:
    return str(scope.objective_family.get("quantification", Quantification.EACH_OBJECTIVE))


def evaluate_objective(signature: Signature, scope: DecisionScope) -> Interval:
    """Exact interval enclosure of the objective family at ``signature``.

    Specification 22.2 (decision-value record) and 26.3 (objective
    quantification).  The returned interval is the *numerical enclosure* only:
    evidence uncertainty and policy tolerance are carried separately and are
    never folded in here.

    Semantics by family:

    * additive with ``EACH_OBJECTIVE`` -- the enclosure of
      ``{w . x : w in W}`` over the declared nonnegative price box.  Degenerate
      when the price vector is fixed.
    * additive with ``ROBUST_AGGREGATE`` -- ``sup_{w in W} w . x``, an exact
      value.  This is a coupled robust objective (26.3) and is a supremum of
      linear forms, not an additive price.
    * max / weighted max / bottleneck -- ``max_i w_i x_i``.  Because the price
      box is a product set and the maximum is nondecreasing in each argument,
      the coordinatewise enclosure is exact.

    Families that are not evaluable from a signature alone (attainability
    queries, realization-attribute objectives, finite ledgers, abstract
    monotone families) raise :class:`ObjectiveError` rather than return a
    guess.
    """
    kind = str(scope.objective_family.get("type"))
    order = _coordinate_order(scope)
    if len(signature) != len(order):
        raise ObjectiveError(
            f"signature of length {len(signature)} does not match the bound coordinate order "
            f"of length {len(order)}"
        )
    if kind in LEDGER_TYPES:
        raise ObjectiveError(
            "a finite ledger has no single objective value; evaluate each scope from "
            "ledger_case_scopes(scope) (spec 26.4)"
        )
    if kind in ATTAINABILITY_TYPES:
        raise ObjectiveError(
            "an exact-attainability query is not an objective; it is answered against exact R "
            "(spec 26.4)"
        )

    weights = _weight_intervals(scope)
    if _is_additive(scope):
        if _quantification(scope) == Quantification.ROBUST_AGGREGATE:
            total = _ZERO
            for weight, value in zip(weights, signature.values):
                total = total + (weight.hi * value if value >= _ZERO else weight.lo * value)
            return Interval(total, total)
        total_interval = Interval(0, 0)
        for weight, value in zip(weights, signature.values):
            total_interval = total_interval + weight * Interval(value, value)
        return total_interval
    if _is_max_family(scope) or kind in {"chebyshev", "weighted_chebyshev"}:
        terms = [weight * Interval(value, value) for weight, value in zip(weights, signature.values)]
        lo = max((t.lo for t in terms), key=lambda e: e.value)
        hi = max((t.hi for t in terms), key=lambda e: e.value)
        return Interval(lo, hi)
    if kind in MONOTONE_NONADDITIVE_TYPES:
        raise ObjectiveError(
            f"objective family {kind!r} is declared monotone but has no evaluable member in "
            "this engine; supply a concrete family or certify against Gamma directly"
        )
    raise ObjectiveError(f"objective family {kind!r} cannot be evaluated from a signature alone")


def _active_bottlenecks(signature: Signature, scope: DecisionScope) -> Tuple[str, ...]:
    """Coordinates attaining the maximum for a bottleneck family (spec 29.4)."""
    if not (_is_max_family(scope) or str(scope.objective_family.get("type")) in {"chebyshev", "weighted_chebyshev"}):
        return ()
    order = _coordinate_order(scope)
    weights = _weight_intervals(scope)
    terms = [weight * Interval(value, value) for weight, value in zip(weights, signature.values)]
    best = max((t.hi for t in terms), key=lambda e: e.value)
    return tuple(name for name, term in zip(order, terms) if term.hi == best)


def _paired_margin(p: Signature, q: Signature, scope: DecisionScope) -> Interval:
    """Exact enclosure of ``{f(q) - f(p) : f in family}`` for an additive family.

    The price domain is a product of independent coordinate ranges, so the
    minimum and maximum of ``sum_i w_i (q_i - p_i)`` over the box are attained
    coordinatewise and the enclosure is exact, not merely conservative.

    This is the *same-objective* comparison the ``EACH_OBJECTIVE``
    quantification actually asks for, and it is strictly sharper than
    comparing two independently computed value enclosures.  For a fixed price
    vector it reduces exactly to specification 22.3.
    """
    weights = _weight_intervals(scope)
    lo = _ZERO
    hi = _ZERO
    for weight, pi, qi in zip(weights, p.values, q.values):
        difference = qi - pi
        products = (weight.lo * difference, weight.hi * difference)
        lo = lo + min(products, key=lambda e: e.value)
        hi = hi + max(products, key=lambda e: e.value)
    return Interval(lo, hi)


def _fixed_price(scope: DecisionScope) -> Optional[Tuple[Exact, ...]]:
    """The single price vector if the weight box is degenerate, else ``None``.

    A non-degenerate weight range describes a continuum of prices; the exact
    worst-case regret over a continuum is not computed here, so this returns
    ``None`` and the caller fails closed (spec 20.5, 6.6).
    """
    weights = _weight_intervals(scope)
    if all(w.is_degenerate for w in weights):
        return tuple(w.lo for w in weights)
    return None


def _declared_regret_bound(
    bundle: RealizationBundle, retained_bundle: RealizationBundle, scope: DecisionScope
) -> Optional[Exact]:
    """Exact worst-case regret of the *declared* additive objective (spec 20.5).

    Regret at a fixed price ``w`` is ``v_retained(w) - v_full(w)`` where ``v``
    is the minimum objective value over a set.  Because the retained set is a
    subset of the full set, this is nonnegative, and for an additive family at
    a fixed price it is exactly computable.  Returns ``None`` -- i.e. not
    boundable here, so the caller must fail closed -- when the price is not a
    single evaluable vector or the family is not additive.
    """
    if not _is_additive(scope) or _quantification(scope) == Quantification.ROBUST_AGGREGATE:
        return None
    price = _fixed_price(scope)
    if price is None:
        return None

    def value_at(signatures: Sequence[Signature]) -> Optional[Exact]:
        best: Optional[Exact] = None
        for signature in signatures:
            total = _ZERO
            for weight, coordinate in zip(price, signature.values):
                total = total + weight * coordinate
            if best is None or total < best:
                best = total
        return best

    full = value_at([r.signature for r in bundle.realizations])
    retained = value_at([r.signature for r in retained_bundle.realizations])
    if full is None or retained is None:
        return None
    regret = retained - full
    return regret if regret >= _ZERO else _ZERO


# ---------------------------------------------------------------------------
# candidates
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class _Candidate:
    realization_id: str
    signature: Signature
    value: DecisionValue
    feasibility: str
    reason: Optional[str] = None

    @property
    def interval(self) -> Interval:
        return self.value.combined()

    @property
    def has_evidence(self) -> bool:
        return self.value.evidence is not None


def _evidence_interval(realization: RealizationRecord) -> Optional[Interval]:
    """Evidence uncertainty declared on a realization (spec 22.1 concept 2)."""
    raw = realization.attributes.get("objective_evidence")
    if raw is None:
        return None
    if isinstance(raw, Mapping):
        lo = raw.get("lo", raw.get("min"))
        hi = raw.get("hi", raw.get("max"))
        if lo is None or hi is None:
            raise CertifyError(
                f"realization {realization.realization_id!r} declares an evidence interval "
                "without both bounds"
            )
        return Interval(lo, hi)
    if isinstance(raw, (list, tuple)) and len(raw) == 2:
        return Interval(raw[0], raw[1])
    return Interval(raw, raw)


def _declared_value(realization: RealizationRecord) -> Optional[Interval]:
    raw = realization.attributes.get("objective_value")
    if raw is None:
        return None
    if isinstance(raw, Mapping):
        return Interval(raw.get("lo", raw.get("min")), raw.get("hi", raw.get("max")))
    if isinstance(raw, (list, tuple)) and len(raw) == 2:
        return Interval(raw[0], raw[1])
    return Interval(raw, raw)


def _objective_unit(scope: DecisionScope, schema: Any) -> str:
    declared = scope.objective_family.get("unit")
    if declared:
        return str(declared)
    units = {c.unit for c in schema.coordinates}
    weights = scope.objective_family.get("weights")
    if len(units) == 1 and not weights:
        return next(iter(units))
    return "DECLARED_OBJECTIVE_UNIT"


def _feasibility(realization: RealizationRecord, scope: DecisionScope) -> Tuple[str, Optional[str]]:
    """Feasibility status and reason (spec 22.7 keeps this distinct from value)."""
    if realization.legality != "LEGAL":
        return Feasibility.INFEASIBLE, f"legality={realization.legality}"
    declared = realization.attributes.get("feasible", realization.attributes.get("feasibility"))
    if declared is False or (isinstance(declared, str) and declared.upper() == "INFEASIBLE"):
        reason = str(realization.attributes.get("infeasible_reason", "declared infeasible"))
        return Feasibility.INFEASIBLE, reason
    if isinstance(declared, str) and declared.upper() == "UNKNOWN":
        return Feasibility.UNKNOWN, "feasibility declared UNKNOWN"
    for key, domain in (scope.technology_domain or {}).items():
        if key not in realization.attributes:
            continue
        if not isinstance(domain, (list, tuple)) or len(domain) != 2:
            continue
        observed = Exact(realization.attributes[key])
        if observed < Exact(domain[0]) or observed > Exact(domain[1]):
            return (
                Feasibility.INFEASIBLE,
                f"attribute {key}={observed} outside declared technology domain "
                f"[{domain[0]}, {domain[1]}]",
            )
    return Feasibility.FEASIBLE, None


def _build_candidate(
    realization: RealizationRecord, scope: DecisionScope, schema: Any
) -> _Candidate:
    numerical = _declared_value(realization)
    if numerical is None:
        numerical = evaluate_objective(realization.signature, scope)
    evidence = _evidence_interval(realization)
    profile = (
        ArithmeticProfile.EXACT_RATIONAL
        if numerical.is_degenerate
        else ArithmeticProfile.INTERVAL_ENCLOSED
    )
    value = DecisionValue(
        coordinate=f"objective::{scope.scope_id}",
        unit=_objective_unit(scope, schema),
        numerical=numerical,
        evidence=evidence,
        exact_value=numerical.lo if numerical.is_degenerate else None,
        arithmetic_profile=profile,
        solver_trust_profile="EXACT_RECOMPUTED",
        policy_tolerance=scope.tie_tolerance,
        scope=scope.scope_id,
        dependencies=(realization.realization_id,),
    )
    status, reason = _feasibility(realization, scope)
    return _Candidate(
        realization_id=realization.realization_id,
        signature=realization.signature,
        value=value,
        feasibility=status,
        reason=reason,
    )


# ---------------------------------------------------------------------------
# interval-safe comparison (spec 22.3-22.5)
# ---------------------------------------------------------------------------
def _use_paired_margin(p: _Candidate, q: _Candidate, scope: DecisionScope) -> bool:
    """The sharp same-objective route applies only to a clean additive case."""
    return (
        _is_additive(scope)
        and _quantification(scope) == Quantification.EACH_OBJECTIVE
        and not p.has_evidence
        and not q.has_evidence
        and p.value.arithmetic_profile in ArithmeticProfile.CERTIFYING
        and q.value.arithmetic_profile in ArithmeticProfile.CERTIFYING
        and scope.objective_family.get("weights") is not None
    )


def compare_candidates(p: _Candidate, q: _Candidate, scope: DecisionScope) -> str:
    """Interval-safe verdict for ``p`` against ``q`` (spec 22.3-22.5).

    ``STRICTLY_BETTER`` requires ``U_p + tau < L_q``; nothing weaker is ever
    promoted to a win.  ``WITHIN_TOLERANCE`` requires that *every* admissible
    difference is inside the declared tolerance, so an overlap wider than
    tolerance stays ``UNRESOLVED`` instead of collapsing into a tie.

    The relation is a strict partial order: ``STRICTLY_BETTER`` is transitive
    both on the interval route (``U_p + tau < L_q <= U_q < L_r - tau``) and on
    the paired-margin route (the minimum over a box is superadditive), which
    is what makes the maximal set below a sound possible-winner set.
    """
    tau = scope.tie_tolerance
    if tau < _ZERO:
        raise CertifyError("policy tolerance must be nonnegative (spec 22.3)")

    if _use_paired_margin(p, q, scope):
        margin = _paired_margin(p.signature, q.signature, scope)
        if margin.lo > tau:
            return Comparison.STRICTLY_BETTER
        if margin.hi < -tau:
            return Comparison.STRICTLY_WORSE
        if margin.lo == _ZERO and margin.hi == _ZERO:
            return Comparison.EXACTLY_EQUAL
        if margin.lo >= -tau and margin.hi <= tau:
            return Comparison.WITHIN_TOLERANCE
        return Comparison.UNRESOLVED

    ip = p.interval
    iq = q.interval
    if ip.strictly_below(iq, tau):
        return Comparison.STRICTLY_BETTER
    if iq.strictly_below(ip, tau):
        return Comparison.STRICTLY_WORSE
    if ip.is_degenerate and iq.is_degenerate and ip.lo == iq.lo:
        return Comparison.EXACTLY_EQUAL
    # Every admissible difference q - p lies in [Lq - Up, Uq - Lp].
    if (iq.hi - ip.lo) <= tau and (ip.hi - iq.lo) <= tau:
        return Comparison.WITHIN_TOLERANCE
    return Comparison.UNRESOLVED


def _maximal_set(candidates: Sequence[_Candidate], scope: DecisionScope) -> List[_Candidate]:
    """Candidates not strictly beaten by any other candidate."""
    survivors: List[_Candidate] = []
    for candidate in candidates:
        beaten = any(
            compare_candidates(other, candidate, scope) == Comparison.STRICTLY_BETTER
            for other in candidates
            if other.realization_id != candidate.realization_id
        )
        if not beaten:
            survivors.append(candidate)
    return survivors


# ---------------------------------------------------------------------------
# geometry preservation (spec 29.2 condition 7)
# ---------------------------------------------------------------------------
def _sub_bundle(bundle: RealizationBundle, ids: Sequence[str]) -> RealizationBundle:
    keep = set(ids)
    return RealizationBundle(
        bundle_id=f"{bundle.bundle_id}::retained",
        schema=bundle.schema,
        realizations=[r for r in bundle.realizations if r.realization_id in keep],
        completeness=bundle.completeness,
        rejected=list(bundle.rejected),
        source_fingerprint=bundle.source_fingerprint,
    )


@dataclass(frozen=True)
class _Preservation:
    preserved: bool
    detail: str
    full_frontier: Tuple[Signature, ...] = ()
    retained_frontier: Tuple[Signature, ...] = ()
    approximate: bool = False
    regret: Optional[Exact] = None


def _preservation(
    bundle: RealizationBundle,
    retained_ids: Sequence[str],
    required_object: str,
    scope: DecisionScope,
    geometry: Any,
) -> _Preservation:
    """Does the retained registry still determine the required object?"""
    all_ids = {r.realization_id for r in bundle.realizations}
    kept = set(retained_ids)
    unknown = kept - all_ids
    if unknown:
        raise CertifyError(f"retained ids absent from the bundle: {sorted(unknown)}")
    if kept == all_ids:
        return _Preservation(True, "nothing was removed")

    retained_bundle = _sub_bundle(bundle, sorted(kept))
    full_signatures = tuple(r.signature for r in bundle.realizations)
    retained_signatures = tuple(r.signature for r in retained_bundle.realizations)

    if required_object == "REALIZATION_REGISTRY_AND_FIBERS":
        return _Preservation(
            False,
            "the decision class is realization sensitive, so every realization identity and "
            "fiber must be retained (spec 19.6, 26.4)",
        )
    if required_object == "R":
        if set(full_signatures) == set(retained_signatures):
            return _Preservation(
                True, "the exact signature set is unchanged; only duplicate fiber members were removed"
            )
        return _Preservation(
            False,
            "exact R changed: at least one signature is no longer represented (spec 19.2)",
        )

    if required_object in ("GAMMA", "BOUNDED_REGRET_REPRESENTATION"):
        geometry = _require_geometry(geometry, "Gamma preservation")
        full_frontier = _frontier(geometry, full_signatures)
        retained_frontier = _frontier(geometry, retained_signatures)
        if set(full_frontier) == set(retained_frontier):
            return _Preservation(
                True, "the Pareto-minimal antichain is unchanged", full_frontier, retained_frontier
            )
        if required_object == "BOUNDED_REGRET_REPRESENTATION":
            # Bounded-regret certification MUST bound the regret of the
            # *declared* objective, in that objective's units (spec 20.5,
            # 26.4).  An earlier revision compared the gap of the adversarial
            # witness objective Phi (spec 27) against the tolerance -- but Phi
            # is constructed to *prove unsafety* and its gap is in Phi's units,
            # so using it as a safety bound was a soundness hole (it certified
            # winners with unbounded true regret).  Here we compute the exact
            # worst-case declared-objective regret over a finite evaluable
            # price set and refuse a continuous price range (fail closed).
            tolerance = Exact(
                (scope.objective_family.get("bounded_regret") or {}).get("tolerance", 0)
            )
            bound = _declared_regret_bound(bundle, retained_bundle, scope)
            if bound is not None and bound <= tolerance:
                return _Preservation(
                    True,
                    f"the frontier changed, but the exact worst-case regret {bound} of the "
                    f"declared objective is within the declared tolerance {tolerance} over the "
                    f"evaluated price set (spec 20.5, 26.4); this is an APPROXIMATE result",
                    full_frontier,
                    retained_frontier,
                    approximate=True,
                    regret=bound,
                )
            # bound is None (continuum, or not exactly evaluable) or exceeds
            # tolerance: fall through to the geometry-loss block below.
        return _Preservation(
            False,
            "Gamma changed: a Pareto-minimal signature is no longer in the retained upper "
            "region (spec 19.3)",
            full_frontier,
            retained_frontier,
        )

    if required_object == "K":
        geometry = _require_geometry(geometry, "K preservation")
        full_k = geometry.build_K(geometry.build_R(bundle))
        retained_k = geometry.build_K(geometry.build_R(retained_bundle))
        full_frontier = _frontier(geometry, full_signatures)
        retained_frontier = _frontier(geometry, retained_signatures)
        if set(full_k.vertices) == set(retained_k.vertices):
            return _Preservation(
                True,
                "the irredundant extreme-vertex set of K is unchanged, so every nonnegative "
                "additive price sees the same support value (spec 19.4)",
                full_frontier,
                retained_frontier,
            )
        return _Preservation(
            False,
            "K changed: an extreme vertex is no longer represented, so some nonnegative "
            "additive price sees a different support value (spec 19.4)",
            full_frontier,
            retained_frontier,
        )

    if required_object == "ARGMIN_HITTING_SET":
        for case_scope in ledger_case_scopes(bind_schema(scope, bundle.schema)):
            full_best = _case_optimum(bundle.realizations, case_scope, bundle.schema)
            retained_best = _case_optimum(retained_bundle.realizations, case_scope, bundle.schema)
            if retained_best is None or full_best is None or retained_best != full_best:
                return _Preservation(
                    False,
                    f"ledger case {case_scope.scope_id!r} lost its argmin: the retained set no "
                    "longer hits every declared case (spec 26.4, 29.3)",
                )
        return _Preservation(True, "the retained set still hits the argmin of every ledger case")

    raise CertifyError(f"unknown required object {required_object!r}")


def _exact_case_value(signature: Signature, case_scope: DecisionScope) -> Exact:
    """Exact value of one ledger case; a price range makes argmin ill-defined."""
    enclosure = evaluate_objective(signature, case_scope)
    if not enclosure.is_degenerate:
        raise ObjectiveError(
            f"ledger case {case_scope.scope_id!r} declares a price range; an argmin-hitting "
            "set is defined only for exactly evaluated cases (spec 26.4)"
        )
    return enclosure.lo


def _case_optimum(
    realizations: Sequence[RealizationRecord], case_scope: DecisionScope, schema: Any
) -> Optional[Exact]:
    values = []
    for realization in realizations:
        status, _ = _feasibility(realization, case_scope)
        if status != Feasibility.FEASIBLE:
            continue
        values.append(_exact_case_value(realization.signature, case_scope))
    if not values:
        return None
    return min(values, key=lambda e: e.value)


# ---------------------------------------------------------------------------
# certification (spec 29)
# ---------------------------------------------------------------------------
def _remainder_closes(basis: Any) -> bool:
    """Spec 21.6: a bound only closes the remainder with a recorded proof."""
    return (
        basis.basis_type == CompletenessBasisType.BOUNDED_UNENUMERATED_FAMILY
        and bool(basis.remainder_bound)
        and bool(basis.closure_proof)
    )


def _certificate_id(
    bundle: RealizationBundle,
    scope: DecisionScope,
    derivation: DerivationRecord,
    retained: Optional[Sequence[str]],
) -> str:
    """Deterministic, content-derived identity (spec 6.5 deterministic authority)."""
    digest = content_hash(
        {
            "bundle": bundle.bundle_hash(),
            "scope": scope.to_canonical(),
            "derivation": derivation.to_canonical(),
            "retained": sorted(retained) if retained is not None else None,
            "engine": ENGINE_VERSION,
        }
    )
    return "cert-" + digest.split(":", 1)[1][:32]


def _blocked(
    outcome: str,
    *,
    bundle: RealizationBundle,
    scope: DecisionScope,
    derivation: DerivationRecord,
    claim_scope: str,
    retained_hash: str,
    reason: str,
    geometry_preserved: bool = True,
    regret_witness: Any = None,
    objective_values: Optional[Dict[str, Any]] = None,
    infeasible: Optional[Dict[str, str]] = None,
    retained: Optional[Sequence[str]] = None,
) -> DecisionCertificate:
    return DecisionCertificate(
        certificate_id=_certificate_id(bundle, scope, derivation, retained),
        outcome=outcome,
        scope=scope,
        derivation=derivation,
        claim_scope=claim_scope,
        completeness=bundle.completeness,
        complete_registry_hash=bundle.bundle_hash(),
        retained_registry_hash=retained_hash,
        semantic_pins=_semantic_pins(),
        selected=(),
        ties=(),
        objective_values=objective_values or {},
        infeasible=infeasible or {},
        geometry_preserved=geometry_preserved,
        regret_witness=regret_witness,
        evidence_roots=(bundle.bundle_hash(),),
        dependencies=tuple(sorted(r.realization_id for r in bundle.realizations)),
        expiry=scope.validity,
        reopen_conditions=(reason,),
        engine_versions=_engine_versions(),
    )


def _engine_versions() -> Dict[str, str]:
    import crg_model

    return {
        "crg-certify": ENGINE_VERSION,
        "crg-model": crg_model.__version__,
        "mapping_table": MAPPING_TABLE_VERSION,
        "specification": crg_model.SPEC_VERSION,
        "verification_program": VIR_PROGRAM,
    }


def _semantic_pins() -> CertificatePins:
    """The complete §15.2 baseline pin set for a core-profile certificate."""
    import crg_model

    return CertificatePins(
        schema_versions={"crg-core": crg_model.SPEC_VERSION},
        quantity_registry_version=DEFAULT_REGISTRY.version(),
        normative_rule_table_version=mapping_table_digest(),
        crg_vir_version="0.2.0",
        domain_pack_versions={},
        proof_checker_versions={"crg-verify": "0.2.0", "crg-verify-js": "0.2.0"},
    )


def certify(
    bundle: RealizationBundle,
    scope: DecisionScope,
    derivation: DerivationRecord,
    *,
    geometry: Any = None,
    retained: Optional[Sequence[str]] = None,
) -> DecisionCertificate:
    """Issue a decision certificate for ``scope`` over ``bundle`` (spec 29).

    ``retained`` names the realizations that survive a proposed or already
    executed retention.  When it is given, the certificate first discharges
    the geometry-preservation obligation of specification 29.2 condition 7:
    if the retained registry no longer determines the object the compiled
    derivation requires, the outcome is ``BLOCKED_GEOMETRY_LOSS`` and a
    constructive regret witness (spec 27) is attached whenever one exists.

    Gate order is deliberate and is itself a safety property:

    1. scope/derivation agreement -- ``BLOCKED_SCOPE_MISMATCH``;
    2. objective evaluability -- ``BLOCKED_INCOMPLETE_EVIDENCE``;
    3. geometry preservation -- ``BLOCKED_GEOMETRY_LOSS`` (+ regret witness);
    4. feasibility -- ``ALL_INFEASIBLE``, which stays distinct and is never
       replaced by a least-infeasible "winner" (22.7);
    5. interval-safe comparison -- winner, winner set, policy tie, possible
       winner set, or ambiguous (22.3-22.5);
    6. claim-scope gating -- a ``PARTIAL_FAMILY`` scope can never emit a
       globally phrased winner (21.5).

    Geometry preservation is checked *before* feasibility precisely because a
    retention that dropped the only feasible realization would otherwise be
    reported as ``ALL_INFEASIBLE``.
    """
    claim_scope = derive_claim_scope(bundle.completeness, _remainder_closes(bundle.completeness))
    all_ids = tuple(sorted(r.realization_id for r in bundle.realizations))
    retained_ids = tuple(sorted(retained)) if retained is not None else all_ids
    retained_bundle = _sub_bundle(bundle, retained_ids) if retained is not None else bundle
    retained_hash = retained_bundle.bundle_hash()

    # -- gate 1: the certificate may only execute the scope it was compiled for
    expected_object = ObservationLevel.REQUIRED_OBJECT.get(scope.observation_level)
    if derivation.decision_class != scope.observation_level or (
        derivation.required_object != expected_object
    ):
        return _blocked(
            DecisionOutcome.BLOCKED_SCOPE_MISMATCH,
            bundle=bundle,
            scope=scope,
            derivation=derivation,
            claim_scope=claim_scope,
            retained_hash=retained_hash,
            reason=(
                "derivation record does not match the decision scope "
                f"({derivation.decision_class}/{derivation.required_object} vs "
                f"{scope.observation_level}/{expected_object}); recompile the query (spec 26.5)"
            ),
            retained=retained,
        )
    if derivation.mapping_table_version != MAPPING_TABLE_VERSION:
        return _blocked(
            DecisionOutcome.BLOCKED_SCOPE_MISMATCH,
            bundle=bundle,
            scope=scope,
            derivation=derivation,
            claim_scope=claim_scope,
            retained_hash=retained_hash,
            reason=(
                f"derivation was produced by mapping table version "
                f"{derivation.mapping_table_version!r}; this engine implements "
                f"{MAPPING_TABLE_VERSION!r} (spec 15.2 certificate pinning)"
            ),
            retained=retained,
        )

    bound_scope = bind_schema(scope, bundle.schema)

    # -- gate 3 (prepared before evaluation so a lossy retention cannot be
    #    reported as a feasibility fact): geometry preservation
    geometry_detail = "no retention was applied"
    preservation = _Preservation(True, geometry_detail)
    if retained is not None:
        try:
            preservation = _preservation(
                bundle, retained_ids, derivation.required_object, bound_scope, geometry
            )
        except GeometryUnavailable as error:
            return _blocked(
                DecisionOutcome.BLOCKED_INCOMPLETE_EVIDENCE,
                bundle=bundle,
                scope=scope,
                derivation=derivation,
                claim_scope=claim_scope,
                retained_hash=retained_hash,
                reason=str(error),
                geometry_preserved=False,
                retained=retained,
            )
        except ObjectiveError as error:
            return _blocked(
                DecisionOutcome.BLOCKED_INCOMPLETE_EVIDENCE,
                bundle=bundle,
                scope=scope,
                derivation=derivation,
                claim_scope=claim_scope,
                retained_hash=retained_hash,
                reason=str(error),
                retained=retained,
            )
        if not preservation.preserved:
            witness = None
            if preservation.full_frontier and preservation.retained_frontier:
                witness = build_regret_witness(
                    preservation.full_frontier, preservation.retained_frontier, bundle.schema
                )
            return _blocked(
                DecisionOutcome.BLOCKED_GEOMETRY_LOSS,
                bundle=bundle,
                scope=scope,
                derivation=derivation,
                claim_scope=claim_scope,
                retained_hash=retained_hash,
                reason=preservation.detail,
                geometry_preserved=False,
                regret_witness=witness,
                retained=retained,
            )

    # -- a finite-ledger scope certifies a retained set, not a single winner,
    #    and has no single objective value to enclose
    if scope.observation_level == ObservationLevel.FINITE_LEDGER:
        try:
            return _certify_ledger(
                bundle,
                bound_scope,
                scope,
                derivation,
                claim_scope,
                retained_hash,
                retained,
                retained_bundle,
            )
        except (ObjectiveError, CertifyError) as error:
            return _blocked(
                DecisionOutcome.BLOCKED_INCOMPLETE_EVIDENCE,
                bundle=bundle,
                scope=scope,
                derivation=derivation,
                claim_scope=claim_scope,
                retained_hash=retained_hash,
                reason=str(error),
                retained=retained,
            )

    # -- gate 2: every candidate must have an exactly evaluable objective
    try:
        candidates = [
            _build_candidate(realization, bound_scope, bundle.schema)
            for realization in retained_bundle.realizations
        ]
    except (ObjectiveError, CertifyError) as error:
        return _blocked(
            DecisionOutcome.BLOCKED_INCOMPLETE_EVIDENCE,
            bundle=bundle,
            scope=scope,
            derivation=derivation,
            claim_scope=claim_scope,
            retained_hash=retained_hash,
            reason=str(error),
            retained=retained,
        )

    candidates.sort(key=lambda c: c.realization_id)
    objective_values = {c.realization_id: c.value.to_canonical() for c in candidates}
    infeasible = {
        c.realization_id: c.reason or "declared infeasible"
        for c in candidates
        if c.feasibility == Feasibility.INFEASIBLE
    }
    feasible = [c for c in candidates if c.feasibility == Feasibility.FEASIBLE]
    unknown_feasibility = [c for c in candidates if c.feasibility == Feasibility.UNKNOWN]

    # -- gate 4: ALL_INFEASIBLE stays a distinct outcome (spec 22.7)
    if not feasible:
        if unknown_feasibility:
            return _blocked(
                DecisionOutcome.AMBIGUOUS,
                bundle=bundle,
                scope=scope,
                derivation=derivation,
                claim_scope=claim_scope,
                retained_hash=retained_hash,
                reason=(
                    "no candidate is established feasible and some feasibility is UNKNOWN; "
                    "resolve feasibility evidence before deciding (spec 22.5)"
                ),
                objective_values=objective_values,
                infeasible=infeasible,
                retained=retained,
            )
        return _blocked(
            DecisionOutcome.ALL_INFEASIBLE,
            bundle=bundle,
            scope=scope,
            derivation=derivation,
            claim_scope=claim_scope,
            retained_hash=retained_hash,
            reason=(
                "every represented candidate is infeasible; a least-infeasible candidate MUST "
                "NOT be reported as a winner without an explicitly requested relaxation "
                "decision (spec 22.7)"
            ),
            objective_values=objective_values,
            infeasible=infeasible,
            retained=retained,
        )

    # -- gate 5: interval-safe comparison (spec 22.3-22.5)
    outcome, selected, ties, runner_up, margin = _decide(feasible, bound_scope, unknown_feasibility)

    # -- gate 6: claim-scope gating (spec 21.5)
    reopen: List[str] = []
    if not preservation.preserved:  # pragma: no cover - handled above
        reopen.append(preservation.detail)
    if retained is not None:
        reopen.append(f"geometry preservation basis: {preservation.detail}")
    if preservation.approximate:
        reopen.append(
            f"APPROXIMATE result: the retention is lossless only up to the declared "
            f"bounded-regret tolerance; the exact worst-case declared-objective regret is "
            f"{preservation.regret} (spec 20.5).  Tightening the tolerance to zero reopens it."
        )

    winner_like = {
        DecisionOutcome.CERTIFIED_WINNER,
        DecisionOutcome.CERTIFIED_WINNER_SET,
        DecisionOutcome.CERTIFIED_POLICY_TIE,
    }
    if claim_scope in ClaimScope.NO_WINNER_CLAIM and outcome in winner_like:
        policy = str(scope.objective_family.get("partial_family_policy", "BLOCK")).upper()
        if policy == "HEURISTIC_INCUMBENT":
            outcome = DecisionOutcome.HEURISTIC_ONLY
            ties = ()
            reopen.append(
                "the claim scope is PARTIAL_FAMILY: this is a heuristic incumbent, not a "
                "certified winner, and it MUST NOT be phrased globally (spec 21.5, 5.3)"
            )
        else:
            outcome = DecisionOutcome.BLOCKED_COVERAGE
            selected = ()
            ties = ()
            runner_up = None
            margin = None
            reopen.append(
                "the claim scope is PARTIAL_FAMILY: complete the declared family, or supply a "
                "certified remainder bound proving the unenumerated region cannot change this "
                "decision, before any winner may be claimed (spec 21.5, 21.6)"
            )
    elif claim_scope == ClaimScope.RELATIVE_EXPLICIT_FAMILY and outcome in winner_like:
        reopen.append(
            "this result is certified only relative to the explicitly imported family; "
            "importing a further candidate reopens it (spec 21.4, 21.5)"
        )

    if outcome == DecisionOutcome.POSSIBLE_WINNER_SET:
        reopen.append(
            "tighten the numerical enclosure or the evidence intervals to resolve the "
            "possible-winner set (spec 22.5)"
        )

    bottlenecks: Tuple[str, ...] = ()
    if selected:
        first = next(c for c in feasible if c.realization_id == selected[0])
        bottlenecks = _active_bottlenecks(first.signature, bound_scope)

    return DecisionCertificate(
        certificate_id=_certificate_id(bundle, scope, derivation, retained),
        outcome=outcome,
        scope=scope,
        derivation=derivation,
        claim_scope=claim_scope,
        completeness=bundle.completeness,
        complete_registry_hash=bundle.bundle_hash(),
        retained_registry_hash=retained_hash,
        semantic_pins=_semantic_pins(),
        selected=selected,
        ties=ties,
        runner_up=runner_up,
        objective_values=objective_values,
        margin=margin,
        active_bottlenecks=bottlenecks,
        infeasible=infeasible,
        pruning_certificates=(),
        geometry_preserved=preservation.preserved,
        regret_witness=None,
        evidence_roots=(bundle.bundle_hash(), retained_hash),
        dependencies=tuple(c.realization_id for c in candidates),
        expiry=scope.validity,
        reopen_conditions=tuple(reopen),
        engine_versions=_engine_versions(),
    )


def _decide(
    feasible: Sequence[_Candidate],
    scope: DecisionScope,
    unknown_feasibility: Sequence[_Candidate],
) -> Tuple[str, Tuple[str, ...], Tuple[str, ...], Optional[str], Optional[Interval]]:
    """Outcome, selected set, tie set, runner-up, and margin (spec 22.3-22.5).

    ``selected`` always carries the reported candidate set: one identifier for
    a strict winner, every member for a certified winner set, a certified
    policy tie, or a possible-winner set.  ``ties`` is populated only for the
    two *certified* set outcomes, because a possible-winner set is unresolved
    uncertainty and is not a tie (22.5).
    """
    survivors = _maximal_set(feasible, scope)
    survivor_ids = tuple(c.realization_id for c in survivors)

    # A non-certifying arithmetic profile, or unresolved feasibility, means the
    # possible-winner set itself cannot be delimited.
    non_certifying = [c for c in feasible if not c.value.can_authorize_certificate]
    if non_certifying or unknown_feasibility:
        return (
            DecisionOutcome.AMBIGUOUS,
            survivor_ids,
            (),
            None,
            None,
        )

    if len(survivors) == 1:
        winner = survivors[0]
        others = [c for c in feasible if c.realization_id != winner.realization_id]
        if all(
            compare_candidates(winner, other, scope) == Comparison.STRICTLY_BETTER
            for other in others
        ):
            runner_up, margin = _runner_up(winner, others, scope)
            return (
                DecisionOutcome.CERTIFIED_WINNER,
                (winner.realization_id,),
                (),
                runner_up,
                margin,
            )
        # Defensive: the strict relation is transitive, so this is unreachable
        # by construction.  If it ever fires, report uncertainty, not a winner.
        return DecisionOutcome.POSSIBLE_WINNER_SET, survivor_ids, (), None, None

    verdicts = {
        compare_candidates(a, b, scope)
        for a in survivors
        for b in survivors
        if a.realization_id != b.realization_id
    }
    # Spec 22.4(a): no candidate outside the set can beat the set.  Maximality
    # under a transitive strict order already guarantees this, but a certified
    # tie is exactly the claim that must not rest on an argument, so it is
    # checked here: to beat the set an outsider would have to be better than
    # every member, and being strictly beaten by one member forbids that.
    outsiders = [c for c in feasible if c.realization_id not in set(survivor_ids)]
    set_is_closed = all(
        any(
            compare_candidates(member, outsider, scope) == Comparison.STRICTLY_BETTER
            for member in survivors
        )
        for outsider in outsiders
    )
    if set_is_closed and verdicts <= {Comparison.EXACTLY_EQUAL}:
        return DecisionOutcome.CERTIFIED_WINNER_SET, survivor_ids, survivor_ids, None, None
    if set_is_closed and verdicts <= {Comparison.EXACTLY_EQUAL, Comparison.WITHIN_TOLERANCE}:
        return DecisionOutcome.CERTIFIED_POLICY_TIE, survivor_ids, survivor_ids, None, None
    return DecisionOutcome.POSSIBLE_WINNER_SET, survivor_ids, (), None, None


def _runner_up(
    winner: _Candidate, others: Sequence[_Candidate], scope: DecisionScope
) -> Tuple[Optional[str], Optional[Interval]]:
    """Closest competitor and the exact margin enclosure against it."""
    if not others:
        return None, None
    margins: List[Tuple[Interval, str]] = []
    for other in others:
        if _use_paired_margin(winner, other, scope):
            margin = _paired_margin(winner.signature, other.signature, scope)
        else:
            margin = Interval(
                other.interval.lo - winner.interval.hi, other.interval.hi - winner.interval.lo
            )
        margins.append((margin, other.realization_id))
    margins.sort(key=lambda item: (item[0].lo.value, item[1]))
    margin, identifier = margins[0]
    return identifier, margin


def _certify_ledger(
    bundle: RealizationBundle,
    bound_scope: DecisionScope,
    scope: DecisionScope,
    derivation: DerivationRecord,
    claim_scope: str,
    retained_hash: str,
    retained: Optional[Sequence[str]],
    retained_bundle: RealizationBundle,
) -> DecisionCertificate:
    """Certify the argmin-hitting retained set of a finite ledger (26.4, 29.3).

    A ledger scope has no single objective value, so it certifies retention:
    the selected set hits an exact argmin of every declared case.  Per-case
    winners are obtained by certifying each scope from ``ledger_case_scopes``.
    """
    statuses = {
        r.realization_id: _feasibility(r, bound_scope) for r in retained_bundle.realizations
    }
    infeasible = {
        identifier: reason or "declared infeasible"
        for identifier, (status, reason) in statuses.items()
        if status == Feasibility.INFEASIBLE
    }
    feasible_ids = {
        identifier
        for identifier, (status, _) in statuses.items()
        if status == Feasibility.FEASIBLE
    }
    objective_values: Dict[str, Any] = {}
    if not feasible_ids:
        return _blocked(
            DecisionOutcome.ALL_INFEASIBLE,
            bundle=bundle,
            scope=scope,
            derivation=derivation,
            claim_scope=claim_scope,
            retained_hash=retained_hash,
            reason="every represented candidate is infeasible for every ledger case (spec 22.7)",
            objective_values=objective_values,
            infeasible=infeasible,
            retained=retained,
        )
    by_id = {r.realization_id: r for r in bundle.realizations}
    hitting: List[str] = []
    values: Dict[str, Any] = {}
    for case_scope in ledger_case_scopes(bound_scope):
        best: Optional[Exact] = None
        argmins: List[str] = []
        for identifier in sorted(feasible_ids):
            value = _exact_case_value(by_id[identifier].signature, case_scope)
            values[f"{case_scope.scope_id}::{identifier}"] = value.to_canonical()
            if best is None or value < best:
                best = value
                argmins = [identifier]
            elif value == best:
                argmins.append(identifier)
        hitting.extend(argmins if scope.retain_all_ties else argmins[:1])
    selected = tuple(sorted(set(hitting)))
    return DecisionCertificate(
        certificate_id=_certificate_id(bundle, scope, derivation, retained),
        outcome=DecisionOutcome.CERTIFIED_RETENTION,
        scope=scope,
        derivation=derivation,
        claim_scope=claim_scope,
        completeness=bundle.completeness,
        complete_registry_hash=bundle.bundle_hash(),
        retained_registry_hash=retained_hash,
        semantic_pins=_semantic_pins(),
        selected=selected,
        ties=(),
        objective_values={**objective_values, **values},
        infeasible=infeasible,
        geometry_preserved=True,
        evidence_roots=(bundle.bundle_hash(), retained_hash),
        dependencies=tuple(sorted(statuses)),
        expiry=scope.validity,
        reopen_conditions=(
            "an argmin-hitting set is sufficient only while the declared ledger of technology "
            "and objective cases stays closed; adding a case reopens this retention "
            "(spec 26.4, 30)",
        ),
        engine_versions=_engine_versions(),
    )


# ---------------------------------------------------------------------------
# retention (spec 29.3)
# ---------------------------------------------------------------------------
def _fiber_representatives(
    realizations: Sequence[RealizationRecord], keep_signatures: Iterable[Signature]
) -> List[str]:
    """One canonical realization per retained signature (lowest identifier)."""
    wanted = set(keep_signatures)
    chosen: Dict[Signature, str] = {}
    for realization in sorted(realizations, key=lambda r: r.realization_id):
        if realization.signature in wanted and realization.signature not in chosen:
            chosen[realization.signature] = realization.realization_id
    return list(chosen.values())


def _fiber_closure(
    realizations: Sequence[RealizationRecord], keep_signatures: Iterable[Signature]
) -> List[str]:
    wanted = set(keep_signatures)
    return [r.realization_id for r in realizations if r.signature in wanted]


def retention_set(
    bundle: RealizationBundle,
    scopes: Sequence[DecisionScope],
    policy: Optional[str] = None,
    *,
    geometry: Any = None,
) -> Tuple[str, ...]:
    """Realizations that MUST be retained for every scope (spec 29.3).

    ``policy`` overrides the retention policy of every scope; when it is
    ``None`` each scope uses the policy its query compiled to.  The result is
    the *union* over scopes, because retention must satisfy every declared
    future decision simultaneously, and it always includes user-protected and
    explicitly required identities.

    Geometry-dependent policies raise :class:`GeometryUnavailable` rather than
    fall back to a weaker set: silently retaining a different set than the one
    named would corrupt exactly what this function exists to guarantee.
    """
    realizations = sorted(bundle.realizations, key=lambda r: r.realization_id)
    all_ids = [r.realization_id for r in realizations]
    signatures = tuple(r.signature for r in realizations)
    keep: set = set()

    for scope in scopes:
        effective = policy or scope.retention_policy
        effective = RetentionPolicy.ALIASES.get(str(effective).upper(), str(effective).lower())
        family = scope.objective_family or {}
        keep.update(str(i) for i in family.get("protected_ids", ()))
        keep.update(str(i) for i in family.get("required_retained_identities", ()))

        if effective in (RetentionPolicy.RETAIN_ALL, RetentionPolicy.FIBER_PRESERVING):
            keep.update(all_ids)
            continue
        if effective == RetentionPolicy.RETAIN_ALL_SIGNATURES:
            keep.update(_fiber_representatives(realizations, signatures))
            continue
        if effective in (RetentionPolicy.UNIVERSAL_MONOTONE, RetentionPolicy.BOUNDED_REGRET):
            provider = _require_geometry(geometry, f"retention policy {effective!r}")
            frontier = _frontier(provider, signatures)
            keep.update(_fiber_representatives(realizations, frontier))
            continue
        if effective == RetentionPolicy.ADDITIVE_PRICE_VISIBLE:
            provider = _require_geometry(geometry, f"retention policy {effective!r}")
            vertices = provider.build_K(provider.build_R(bundle)).vertices
            keep.update(_fiber_representatives(realizations, vertices))
            continue
        if effective in (RetentionPolicy.ARGMIN_HITTING, RetentionPolicy.RETAIN_ALL_WINNERS):
            bound = bind_schema(scope, bundle.schema)
            for case_scope in ledger_case_scopes(bound):
                best: Optional[Exact] = None
                argmins: List[str] = []
                for realization in realizations:
                    status, _ = _feasibility(realization, case_scope)
                    if status != Feasibility.FEASIBLE:
                        continue
                    value = _exact_case_value(realization.signature, case_scope)
                    if best is None or value < best:
                        best = value
                        argmins = [realization.realization_id]
                    elif value == best:
                        argmins.append(realization.realization_id)
                keep.update(
                    argmins
                    if effective == RetentionPolicy.RETAIN_ALL_WINNERS or scope.retain_all_ties
                    else argmins[:1]
                )
            continue
        raise CertifyError(f"unknown retention policy {effective!r} (spec 29.3)")

    return tuple(sorted(keep))


# ---------------------------------------------------------------------------
# certified pruning (spec 29.2)
# ---------------------------------------------------------------------------
def certified_pruning(
    bundle: RealizationBundle,
    scope: DecisionScope,
    candidates: Sequence[str],
    *,
    geometry: Any = None,
) -> List[PruningCertificate]:
    """Emit a pruning certificate for each candidate that may be deleted.

    Specification 29.2 requires all ten conditions; a candidate that fails any
    of them yields no certificate at all, because an emitted certificate is an
    assertion that every condition held.  The geometry obligation is evaluated
    against the *joint* post-pruning registry, so a set of individually
    harmless deletions cannot combine into a harmful one.

    A learned model may propose ``candidates``; only this function may
    authorize the deletion (29.2).
    """
    by_id = {r.realization_id: r for r in bundle.realizations}
    unknown = [c for c in candidates if c not in by_id]
    if unknown:
        raise CertifyError(f"pruning candidates absent from the bundle: {sorted(unknown)}")

    bound_scope = bind_schema(scope, bundle.schema)
    required_object = ObservationLevel.REQUIRED_OBJECT[scope.observation_level]
    survivors = [i for i in sorted(by_id) if i not in set(candidates)]
    if not survivors:
        return []

    # Condition 7, evaluated jointly for the whole proposed deletion.
    try:
        preservation = _preservation(bundle, survivors, required_object, bound_scope, geometry)
    except (GeometryUnavailable, ObjectiveError):
        return []
    if not preservation.preserved:
        return []

    # Condition 8: completeness implications.
    if bundle.completeness.basis_type == CompletenessBasisType.UNKNOWN:
        return []

    incumbents = []
    for identifier in survivors:
        candidate = _build_candidate(by_id[identifier], bound_scope, bundle.schema)
        if candidate.feasibility == Feasibility.FEASIBLE:
            incumbents.append(candidate)
    if not incumbents:
        return []

    certificates: List[PruningCertificate] = []
    for identifier in sorted(set(candidates)):
        realization = by_id[identifier]
        pruned = _build_candidate(realization, bound_scope, bundle.schema)

        # Condition 3: scopes match.
        declared_scope = realization.attributes.get("scope")
        if declared_scope is not None and str(declared_scope) != scope.scope_id:
            continue
        # Condition 4: the derivation must permit the comparison at all.
        if scope.observation_level == ObservationLevel.REALIZATION:
            continue
        # Condition 9: dependencies and evidence must authorize.
        dependencies_valid = bool(
            realization.attributes.get("dependencies_valid", True)
        ) and EvidenceClass.may_authorize(realization.evidence_class)
        if not dependencies_valid:
            continue

        # Conditions 1, 2, 5, 6: a valid lower bound on the pruned class, a
        # feasible incumbent upper witness, an interval-safe strict comparison,
        # and a tie policy that survives it.
        best: Optional[Tuple[_Candidate, Interval]] = None
        for incumbent in incumbents:
            if compare_candidates(incumbent, pruned, bound_scope) != Comparison.STRICTLY_BETTER:
                continue
            if _use_paired_margin(incumbent, pruned, bound_scope):
                margin = _paired_margin(incumbent.signature, pruned.signature, bound_scope)
            else:
                margin = Interval(
                    pruned.interval.lo - incumbent.interval.hi,
                    pruned.interval.hi - incumbent.interval.lo,
                )
            if best is None or margin.lo > best[1].lo:
                best = (incumbent, margin)
        if best is None:
            continue
        incumbent, _margin = best
        certificates.append(
            PruningCertificate(
                pruned_id=identifier,
                lower_bound=Interval(pruned.interval.lo, pruned.interval.lo),
                incumbent_id=incumbent.realization_id,
                incumbent_upper=Interval(incumbent.interval.hi, incumbent.interval.hi),
                scope_id=scope.scope_id,
                tie_policy_satisfied=True,
                geometry_preserved=True,
                dependencies_valid=True,
            )
        )
    return certificates


# ---------------------------------------------------------------------------
# human rendering (spec 29.5)
# ---------------------------------------------------------------------------
_OUTCOME_PHRASE = {
    DecisionOutcome.CERTIFIED_WINNER: "Certified winner",
    DecisionOutcome.CERTIFIED_WINNER_SET: "Certified winner set",
    DecisionOutcome.CERTIFIED_POLICY_TIE: "Certified policy tie",
    DecisionOutcome.POSSIBLE_WINNER_SET: "Possible winner set",
    DecisionOutcome.CERTIFIED_RETENTION: "Certified retention",
    DecisionOutcome.AMBIGUOUS: "Ambiguous; no decision certified",
    DecisionOutcome.ALL_INFEASIBLE: "All candidates infeasible",
    DecisionOutcome.BLOCKED_SCOPE_MISMATCH: "Blocked: scope mismatch",
    DecisionOutcome.BLOCKED_INCOMPLETE_EVIDENCE: "Blocked: incomplete evidence",
    DecisionOutcome.BLOCKED_GEOMETRY_LOSS: "Blocked: required geometry not preserved",
    DecisionOutcome.BLOCKED_COVERAGE: "Blocked: incomplete family coverage",
    DecisionOutcome.HEURISTIC_ONLY: "Heuristic incumbent only, not certified",
    DecisionOutcome.STALE: "Stale",
}

_SCOPE_PHRASE = {
    ClaimScope.FULL_DECLARED_UNIVERSE: "over the complete declared universe",
    ClaimScope.GENERATOR_CLOSED_FAMILY: "over the closure of the declared generator set",
    ClaimScope.BOUNDED_REMAINDER_GLOBAL: "globally, with the unenumerated remainder bounded",
    ClaimScope.RELATIVE_EXPLICIT_FAMILY: "relative to the explicitly imported family",
    ClaimScope.PARTIAL_FAMILY: "over an incomplete family; no global claim is made",
}


def render_claim(certificate: DecisionCertificate) -> str:
    """Human rendering that combines outcome with claim scope (spec 29.5).

    The specification forbids shortening "certified winner relative to the
    explicitly imported family" to "certified winner", so the two parts are
    never rendered apart.
    """
    outcome = _OUTCOME_PHRASE.get(certificate.outcome, certificate.outcome)
    scope_phrase = _SCOPE_PHRASE.get(certificate.claim_scope, certificate.claim_scope)
    subject = ", ".join(certificate.selected) if certificate.selected else None
    if subject:
        return f"{outcome}: {subject}, {scope_phrase}."
    return f"{outcome}, {scope_phrase}."
