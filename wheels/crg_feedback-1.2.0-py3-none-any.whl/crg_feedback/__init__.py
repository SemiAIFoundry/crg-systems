"""crg-feedback: physical feedback and transition control (OID-CRG-005).

Reference implementation of master specification section 32, with section
45 (clock and time discipline), 5.3 (evidence classes), 6.6 (fail closed)
and 28.6 (distinct legality states) applied throughout.

This is the module where CRG touches the physical world, in both
directions: results come back from external evaluators, and configuration
changes go out to a running system.  Both directions are governed by
prohibitions on collapsing a distinction, and this package's whole shape
follows from four of them.

**A tool failure MUST NOT be interpreted as physical infeasibility
(32.1).**  ``TOOL_FAILURE``, ``CONVERGENCE_FAILURE``, and
``PHYSICAL_INFEASIBILITY`` are three responses with three effects.
:data:`~crg_feedback.protocol.ResponseKind.ESTABLISHES_INFEASIBILITY` has
exactly one member.  A failure returns ``UNEVALUATED`` -- the absence of
knowledge a crashed solver actually produces -- and it writes nothing to
the realization record in either direction.  :func:`submit` converts every
transport-level fault into ``TOOL_FAILURE``, because the alternative an
integrator reaches for is ``except Exception: mark_infeasible``.
Challenger generation refuses to run on the failure kinds for the same
reason: a crashed tool has not told us the design is wrong.

**A compact-model success MUST NOT be represented as physical signoff
(32.1).**  ``MODELED_RESULT`` admits evidence class ``MODELED`` and nothing
else; ``MEASURED_RESULT`` admits ``MEASURED`` and nothing else; those two
single-element sets are the prohibition made structural.
:func:`promote_evidence_class` refuses ``MODELED -> MEASURED`` by name,
:func:`signoff_status` grants ``PHYSICAL_SIGNOFF`` only to measurement, and
:func:`register_witness` writes the response's own class into the bundle so
it survives the trip.

**The four maturity levels of 32.4 are four different permissions.**  L0
returns ``RECOMMEND_ONLY`` and :func:`execute` refuses it by name.  L1
requires a named operator holding an unexpired capability, not a boolean.
L2 tests membership in a previously certified envelope -- the configuration
pair *and* every bounded parameter -- and refuses outside it.  L3 requires
domain-specific safety controls declared present and verified.  Because
32.4 says the initial production release SHOULD target L0 and L1, L2 and
L3 are present but closed: they need an explicit :class:`SafetyCase`
opt-in naming the level, and refuse without one.

**Fail closed, on a supplied clock (32.5, 45).**  Stale telemetry, invalid
certificate, context mismatch, failed postcondition, expired capability,
missing rollback, and unresolved clock status are seven distinct refusal
reasons because they have seven distinct remedies.  No wall-clock call
appears anywhere in this package -- a standing test greps the sources for
one.  Freshness and dwell are counted in monotonic ticks (45.6), so no
wall-clock adjustment can extend a freshness window, and a clock with no
monotonic reading yields ``UNRESOLVED_CLOCK_STATUS`` rather than a guess.

A transition plan carries all fourteen items of 32.5 or it is not a plan.
Missing items are never defaulted: a synthesized phase guard or rollback
would present an omission as a decision, so :class:`TransitionPlan` raises
:class:`IncompletePlan` naming every absent item.  A failed postcondition
rolls back to the checkpoint and the rollback is *verified* -- the record
reports ``ROLLED_BACK`` only when the executor confirms the source
configuration is active again.

Everything numeric on these paths is an exact rational.  A margin
comparison that a float would decide by rounding is precisely the
comparison that decides whether a running system is reconfigured.
"""
from .protocol import (
    ADMISSIBLE_EVIDENCE_CLASSES,
    DEFAULT_EVIDENCE_CLASS,
    FEASIBILITY_EFFECT,
    REQUEST_REQUIRED_ITEMS,
    EvaluatorRefusal,
    EvaluatorRequest,
    EvaluatorResponse,
    FeasibilityEffect,
    FeasibilityUpdate,
    ProtocolError,
    ResponseKind,
    SignoffStatus,
    WitnessRecord,
    apply_feasibility,
    feasibility_update,
    meets_requested_evidence_level,
    promote_evidence_class,
    register_witness,
    signoff_status,
    submit,
)
from .refine import (
    ChallengerAxis,
    ChallengerContext,
    ChallengerProposal,
    EvaluationCandidate,
    ExpectedReduction,
    RankedEvaluation,
    RankingBasis,
    RankingTier,
    ReductionDimension,
    RefinementError,
    prioritize_evaluations,
    propose_challengers,
    revealed_bottlenecks,
)
from .transition import (
    AUTHORIZE_TRANSITION,
    FAIL_CLOSED_CONDITIONS,
    TRANSITION_PLAN_REQUIRED_ITEMS,
    Approver,
    AuditEntry,
    AuditSpec,
    AuthorizationResult,
    Capability,
    CertifiedEnvelope,
    Checkpoint,
    Configuration,
    DwellRequirement,
    EnvelopeMembership,
    ExpectedBenefit,
    GateReport,
    Hysteresis,
    IncompletePlan,
    Margin,
    MaturityLevel,
    PermittedAction,
    PhaseGuard,
    Postcondition,
    PostconditionResult,
    QuiescencePlan,
    RefusalReason,
    Refusal,
    RollbackPlan,
    SafetyCase,
    StateConversionPlan,
    TelemetryAuthentication,
    TelemetryFreshness,
    TelemetrySample,
    TransitionCertificate,
    TransitionClock,
    TransitionCost,
    TransitionError,
    TransitionExecutor,
    TransitionPlan,
    TransitionRecord,
    TransitionRefused,
    TransitionRequirements,
    TransitionStatus,
    TransitionStep,
    authorize,
    context_fingerprint_of,
    execute,
    plan_transition,
    rollback,
)
from .reference_executor import ReferenceTransitionExecutor
from .phase_binding import (
    OperationalStateGuard,
    PhaseBoundTransitionAuthorization,
    authorize_with_certified_phase,
)

__version__ = "1.2.0"
SPEC_VERSION = "0.2.0"

__all__ = [
    # protocol (32.1)
    "ADMISSIBLE_EVIDENCE_CLASSES",
    "DEFAULT_EVIDENCE_CLASS",
    "FEASIBILITY_EFFECT",
    "REQUEST_REQUIRED_ITEMS",
    "EvaluatorRefusal",
    "EvaluatorRequest",
    "EvaluatorResponse",
    "FeasibilityEffect",
    "FeasibilityUpdate",
    "ProtocolError",
    "ResponseKind",
    "SignoffStatus",
    "WitnessRecord",
    "apply_feasibility",
    "feasibility_update",
    "meets_requested_evidence_level",
    "promote_evidence_class",
    "register_witness",
    "signoff_status",
    "submit",
    # refinement and challengers (32.2, 32.3)
    "ChallengerAxis",
    "ChallengerContext",
    "ChallengerProposal",
    "EvaluationCandidate",
    "ExpectedReduction",
    "RankedEvaluation",
    "RankingBasis",
    "RankingTier",
    "ReductionDimension",
    "RefinementError",
    "prioritize_evaluations",
    "propose_challengers",
    "revealed_bottlenecks",
    # transition control (32.4, 32.5)
    "AUTHORIZE_TRANSITION",
    "FAIL_CLOSED_CONDITIONS",
    "TRANSITION_PLAN_REQUIRED_ITEMS",
    "Approver",
    "AuditEntry",
    "AuditSpec",
    "AuthorizationResult",
    "Capability",
    "CertifiedEnvelope",
    "Checkpoint",
    "Configuration",
    "DwellRequirement",
    "EnvelopeMembership",
    "ExpectedBenefit",
    "GateReport",
    "Hysteresis",
    "IncompletePlan",
    "Margin",
    "MaturityLevel",
    "PermittedAction",
    "PhaseGuard",
    "Postcondition",
    "PostconditionResult",
    "QuiescencePlan",
    "Refusal",
    "RefusalReason",
    "RollbackPlan",
    "SafetyCase",
    "StateConversionPlan",
    "TelemetryAuthentication",
    "TelemetryFreshness",
    "TelemetrySample",
    "TransitionCertificate",
    "TransitionClock",
    "TransitionCost",
    "TransitionError",
    "TransitionExecutor",
    "TransitionPlan",
    "TransitionRecord",
    "TransitionRefused",
    "TransitionRequirements",
    "TransitionStatus",
    "TransitionStep",
    "authorize",
    "context_fingerprint_of",
    "execute",
    "plan_transition",
    "rollback",
    "ReferenceTransitionExecutor",
    "OperationalStateGuard",
    "PhaseBoundTransitionAuthorization",
    "authorize_with_certified_phase",
]
