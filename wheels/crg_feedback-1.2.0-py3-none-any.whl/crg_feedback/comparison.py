"""v1.2 comparative-change compatibility boundary for feedback callers.

The portable comparative record is owned by :mod:`crg_change.comparative`,
because its facts must be derived from one independently verified
``CertifiedDeltaRecord``.  Feedback code historically imports adjacent
decision-evolution helpers from ``crg_feedback``; this module gives those
callers a narrow facade without copying the producer or inventing a second
semantics.

Only the v1.2 record is exposed here.  It is non-authorizing, reports exact
artifact-identity counts, and cannot turn evaluator feedback into a decision
or case-state mutation.
"""
from crg_change.comparative import (
    COMPARATIVE_CHANGE_AUTHORITY,
    COMPARATIVE_CHANGE_CLAIM_BOUNDARY,
    COMPARATIVE_CHANGE_FIRST_RELEASE,
    COMPARATIVE_CHANGE_PROFILE,
    COMPARATIVE_CHANGE_SCHEMA_VERSION,
    ComparativeChangeError,
    ComparativeChangeEvidence,
    build_comparative_change_evidence,
)

__all__ = [
    "COMPARATIVE_CHANGE_AUTHORITY",
    "COMPARATIVE_CHANGE_CLAIM_BOUNDARY",
    "COMPARATIVE_CHANGE_FIRST_RELEASE",
    "COMPARATIVE_CHANGE_PROFILE",
    "COMPARATIVE_CHANGE_SCHEMA_VERSION",
    "ComparativeChangeError",
    "ComparativeChangeEvidence",
    "build_comparative_change_evidence",
]
