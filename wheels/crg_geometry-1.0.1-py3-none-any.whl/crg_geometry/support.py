"""Support values, region membership, and certified geometry envelopes.

Normative basis: master specification sections 19.3 and 19.4 (the regions
and their recession cone), 19.5 (support samples are an approximation
unless proved determining), and 20 (certified geometry approximations,
value-function error).

Both canonical regions are upper sets with the nonnegative orthant as
recession cone, so for a nonnegative price w the infimum of <w, x> is
attained on the finite generator set:

    Gamma = union over frontier points g of (g + R^d_{>=0})
    K     = conv(vertices) + R^d_{>=0}

For K that is the standard fact that a linear functional attains its
infimum over a polyhedron's convex hull at a generator; for Gamma it is
immediate.  Membership, however, differs sharply: Gamma is a union of
orthants and is *not* convex, so its membership test is coordinatewise
dominance, while K's is an exact rational LP.  Conflating the two is the
error that silently upgrades a monotone claim into an additive-price
claim (spec 29.2 observation levels).
"""
from __future__ import annotations

from fractions import Fraction
from itertools import product
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from crg_model.envelope import EvidenceClass
from crg_model.numeric import Exact
from crg_model.records import GammaRecord, GeometryEnvelope, KRecord, RRecord, Signature

from .exact_lp import convex_combination_below
from .pareto import signature_values

__all__ = [
    "NegativePriceError",
    "EmptyRegionError",
    "region_generators",
    "region_dimension",
    "support_value",
    "dominates_region",
    "region_included",
    "default_price_samples",
    "support_error_bound",
    "certified_envelope",
]

#: Regions whose membership test is convexity-aware rather than dominance.
_CONVEX_REGIONS = (KRecord,)


class NegativePriceError(ValueError):
    """Raised when a price vector leaves the declared nonnegative domain.

    With any w_i < 0 the infimum over an upper set with orthant recession
    cone is -infinity, so the support value does not exist; spec 20.3
    declares the price domain nonnegative for exactly this reason.
    """


class EmptyRegionError(ValueError):
    """Raised when a support value is requested for an empty region."""


def region_generators(region: Any) -> Tuple[Signature, ...]:
    """The finite generating points of a canonical region."""
    if isinstance(region, GammaRecord):
        return region.frontier
    if isinstance(region, KRecord):
        return region.vertices
    if isinstance(region, RRecord):
        # R + orthant and Gamma + orthant coincide; accepting R lets callers
        # cross-check the frontier reduction without rebuilding Gamma.
        return region.signatures
    raise TypeError(f"not a canonical geometry region: {type(region)!r}")


def region_dimension(region: Any) -> int:
    return region.schema.dimension


def _price_vector(w: Sequence[Exact], dimension: int) -> Tuple[Fraction, ...]:
    if len(w) != dimension:
        raise ValueError(
            f"price vector has {len(w)} entries; the declared schema has {dimension}"
        )
    values: List[Fraction] = []
    for index, component in enumerate(w):
        exact_component = component if isinstance(component, Exact) else Exact(component)
        if exact_component < 0:
            raise NegativePriceError(
                f"price component {index} is {exact_component}; the declared price "
                "domain is nonnegative (spec 20.3) and a negative component makes "
                "the infimum over the recession cone unbounded below"
            )
        values.append(exact_component.value)
    return tuple(values)


def support_value(region: Any, w: Sequence[Exact]) -> Exact:
    """v_G(w) = inf over the region of <w, x>, for a nonnegative price w (spec 20.3)."""
    generators = region_generators(region)
    if not generators:
        raise EmptyRegionError("support value is undefined for an empty region")
    price = _price_vector(w, region_dimension(region))

    best: Optional[Fraction] = None
    for generator in generators:
        total = Fraction(0)
        for component, coordinate in zip(price, signature_values(generator)):
            if component:
                total += component * coordinate
        if best is None or total < best:
            best = total
    return Exact(best)


def dominates_region(point: Signature, region: Any) -> bool:
    """Whether ``point`` lies in the upper region (i.e. the region reaches it).

    For Gamma this asks whether some frontier point weakly dominates the
    point; for K it asks the exact rational question whether the point lies
    in conv(vertices) + R^d_{>=0}.
    """
    dimension = region_dimension(region)
    if len(point) != dimension:
        raise ValueError(
            f"point has {len(point)} coordinates; the declared schema has {dimension}"
        )
    generators = region_generators(region)
    if not generators:
        return False

    if isinstance(region, _CONVEX_REGIONS):
        coordinates = [signature_values(g) for g in generators]
        return convex_combination_below(signature_values(point), coordinates) is not None
    return any(generator.weakly_dominates(point) for generator in generators)


def region_included(inner: Any, outer: Any) -> bool:
    """Whether every generator of ``inner`` lies in ``outer``.

    That is sufficient for inclusion of the whole upper sets: both regions
    carry the same orthant recession cone and ``outer`` absorbs it, so
    containing the generators contains their upper sets.  A convex inner
    region additionally needs its hull covered, which only a convex outer
    region guarantees -- Gamma is a union of orthants and is not convex, so
    that combination is refused rather than answered unsoundly.
    """
    if region_dimension(inner) != region_dimension(outer):
        raise ValueError("inner and outer regions have different declared dimensions")
    if isinstance(inner, _CONVEX_REGIONS) and not isinstance(outer, _CONVEX_REGIONS):
        raise ValueError(
            "cannot certify a convex inner region inside a non-convex outer region "
            "from generators alone; supply a convex outer region"
        )
    return all(dominates_region(generator, outer) for generator in region_generators(inner))


def default_price_samples(dimension: int) -> Tuple[Tuple[Exact, ...], ...]:
    """A deterministic nonnegative price grid for cross-checks (spec 19.5).

    These samples are a *check*, never a proof: 19.5 is explicit that a
    finite support sample is an approximation unless accompanied by a proof
    that it determines the relevant geometry.  The set is fixed rather than
    random so that any verifier recomputes exactly the same values.
    """
    if dimension <= 0:
        return ()

    samples: List[Tuple[Exact, ...]] = []
    seen: set[Tuple[Fraction, ...]] = set()

    def add(components: Iterable[Exact]) -> None:
        vector = tuple(components)
        key = tuple(c.value for c in vector)
        if all(value == 0 for value in key) or key in seen:
            return
        seen.add(key)
        samples.append(vector)

    for axis in range(dimension):
        add(Exact(1) if i == axis else Exact(0) for i in range(dimension))
    add(Exact(1) for _ in range(dimension))

    if dimension <= 6:
        # Every nonzero 0/1 price exercises each coordinate subset.
        for mask in product((0, 1), repeat=dimension):
            add(Exact(bit) for bit in mask)

    # Graded and reciprocal weights break the symmetry of the 0/1 grid and
    # force genuinely rational arithmetic through the support computation.
    add(Exact(i + 1) for i in range(dimension))
    add(Exact(dimension - i) for i in range(dimension))
    add(Exact(1) / Exact(i + 1) for i in range(dimension))
    add(Exact(2 * i + 1) / Exact(i + 3) for i in range(dimension))
    return tuple(samples)


def support_error_bound(
    inner: Any,
    outer: Any,
    price_samples: Sequence[Sequence[Exact]],
) -> Exact:
    """The tightest epsilon with v_inner(w) - v_outer(w) <= epsilon on the samples.

    Spec 20.3: given G_inner subset G subset G_outer, v_outer(w) <= v_G(w)
    <= v_inner(w) for every nonnegative w, so this difference bounds the
    value-function error of using either surrogate in place of G.  The
    returned bound is only over the *declared* sample set; per 20.2/20.5 a
    certificate carrying it must also declare the price domain W, and it may
    not be reported as an exact-geometry claim.
    """
    if not price_samples:
        raise ValueError("a support-value error bound requires a declared price domain")

    worst: Optional[Exact] = None
    for w in price_samples:
        gap = support_value(inner, w) - support_value(outer, w)
        if worst is None or gap > worst:
            worst = gap
    return worst


def certified_envelope(
    inner: Any,
    outer: Any,
    price_samples: Optional[Sequence[Sequence[Exact]]] = None,
    inner_evidence_class: str = EvidenceClass.EXACT,
    outer_evidence_class: str = EvidenceClass.EXACT,
) -> GeometryEnvelope:
    """Build a GeometryEnvelope with a checked inclusion and support bound (spec 20).

    The inclusion G_inner subset G_outer is *verified* here rather than
    asserted, because 20.1 makes the containment the governing form of the
    whole approximation; an unchecked containment would let 20.5's
    prohibition on silent exact-geometry claims be violated by accident.
    """
    if price_samples is None:
        price_samples = default_price_samples(region_dimension(inner))
    if not region_included(inner, outer):
        raise ValueError(
            "declared inner region is not contained in the outer region; "
            "the envelope of spec 20.1 does not hold"
        )

    epsilon = support_error_bound(inner, outer, price_samples)
    error_semantics: Dict[str, Any] = {
        "support_value_error": {
            "epsilon": epsilon.to_canonical(),
            "price_domain": "DECLARED_NONNEGATIVE_SAMPLES",
            "sample_count": len(price_samples),
            "samples": [[c.to_canonical() for c in w] for w in price_samples],
        },
        "exact_region_inclusion": True,
        "claim_limit": "APPROXIMATE_NOT_EXACT_GEOMETRY",
    }
    return GeometryEnvelope(
        inner=inner,
        outer=outer,
        inner_evidence_class=inner_evidence_class,
        outer_evidence_class=outer_evidence_class,
        error_semantics=error_semantics,
    )
