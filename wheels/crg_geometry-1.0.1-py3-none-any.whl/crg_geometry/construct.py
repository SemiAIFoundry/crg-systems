"""Construction of the canonical R, Gamma, and K records.

Normative basis: master specification sections 19.2 (exact finite R),
19.3 (canonical finite Gamma), 19.4 (canonical finite K), and 19.6
(realization fibers).

The three records form a strict information ladder.  R keeps every
realization identity grouped into fibers; Gamma keeps the Pareto-minimal
antichain and forgets which realizations produced it; K keeps only the
extreme vertices of the convex relaxation and forgets the Pareto points
that are convex combinations of them.  Nothing here ever climbs back up
the ladder, and each step records what it dropped.
"""
from __future__ import annotations

from typing import Dict, List

from crg_model.records import (
    Fiber,
    GammaRecord,
    KRecord,
    RealizationBundle,
    RRecord,
    Signature,
)

from .exact_lp import convex_combination_below
from .pareto import pareto_minimal, signature_values, sort_signatures

__all__ = ["build_R", "build_gamma", "build_K", "LEGAL"]

#: Only realizations carrying this legality result enter R; rejected
#: candidates live in ``RealizationBundle.rejected`` (spec 28, 12).
LEGAL = "LEGAL"


def build_R(bundle: RealizationBundle) -> RRecord:
    """Canonical exact finite R for a realization bundle (spec 19.2).

    Realizations are grouped into fibers by exact signature; fibers are
    sorted lexicographically by signature and realization identifiers are
    sorted within each fiber.  Two realizations sharing a signature remain
    separately represented -- that is the hard invariant of 19.2/19.6, and
    it is what keeps topology, schedule, ownership, and provenance
    recoverable after the signature-level geometry has been built.
    """
    dimension = bundle.schema.dimension
    grouped: Dict[Signature, List[str]] = {}
    seen_ids: set[str] = set()

    for realization in bundle.realizations:
        if realization.legality != LEGAL:
            # Non-legal candidates are registry members but not members of
            # R = {rho(p) : p in P}; they stay visible in the bundle.
            continue
        if len(realization.signature) != dimension:
            raise ValueError(
                f"realization {realization.realization_id!r} has "
                f"{len(realization.signature)} coordinates; schema declares {dimension}"
            )
        if realization.realization_id in seen_ids:
            raise ValueError(
                f"duplicate realization identifier {realization.realization_id!r}"
            )
        seen_ids.add(realization.realization_id)
        grouped.setdefault(realization.signature, []).append(realization.realization_id)

    fibers = tuple(
        Fiber(signature=signature, realization_ids=tuple(sorted(grouped[signature])))
        for signature in sort_signatures(grouped)
    )
    return RRecord(schema=bundle.schema, fibers=fibers, completeness=bundle.completeness)


def build_gamma(r: RRecord) -> GammaRecord:
    """Canonical finite Gamma = cl(R + R^d_{>=0}) (spec 19.3).

    ``dominated_available`` is true because the record this is derived from
    retains every fiber, so dominated points remain recoverable for
    realization-sensitive decisions (19.3, 19.6).
    """
    frontier = pareto_minimal(r.signatures)
    return GammaRecord(
        schema=r.schema,
        frontier=frontier,
        completeness=r.completeness,
        recession_cone="NONNEGATIVE_ORTHANT",
        dominated_available=True,
    )


def build_K(r: RRecord) -> KRecord:
    """Canonical finite K = conv(R) + R^d_{>=0}, as irredundant vertices (spec 19.4).

    Only Pareto-minimal points can be extreme: if u dominates v then v is
    the midpoint of u and u + 2(v - u), both in K, so v is not a vertex.
    Among the Pareto points, v is extreme exactly when it is *not* in
    conv(others) + R^d_{>=0}; that membership question is decided exactly by
    the rational LP in :mod:`crg_geometry.exact_lp`, never by approximation.
    """
    candidates = pareto_minimal(r.signatures)
    coordinates = [signature_values(point) for point in candidates]

    vertices: List[Signature] = []
    for index, point in enumerate(candidates):
        others = [coordinates[j] for j in range(len(candidates)) if j != index]
        if convex_combination_below(coordinates[index], others) is None:
            vertices.append(point)

    return KRecord(
        schema=r.schema,
        vertices=sort_signatures(vertices),
        completeness=r.completeness,
        recession_cone="NONNEGATIVE_ORTHANT",
    )
