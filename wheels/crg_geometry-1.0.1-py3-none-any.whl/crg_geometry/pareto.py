"""Pareto-minimal antichains and canonical signature ordering.

Normative basis: master specification section 19.1 (coordinate order is
part of canonicalization) and 19.3 (canonical finite Gamma is the
Pareto-minimal antichain of R sorted under the declared coordinate order).

Every coordinate handled here is already in the MINIMIZE orientation --
:class:`crg_model.records.Signature` normalises to that convention and the
schema keeps the declared direction only for reporting -- so dominance is
uniformly "<= everywhere, < somewhere".
"""
from __future__ import annotations

from fractions import Fraction
from typing import Dict, Iterable, Sequence, Tuple

from crg_model.records import Signature

__all__ = [
    "signature_values",
    "signature_sort_key",
    "sort_signatures",
    "pareto_minimal",
    "dominated_by_any",
]


def signature_values(signature: Signature) -> Tuple[Fraction, ...]:
    """The exact rational coordinates of a signature, in declared order."""
    return tuple(v.value for v in signature.values)


def signature_sort_key(signature: Signature) -> Tuple[Fraction, ...]:
    """Canonical lexicographic sort key under the declared coordinate order.

    This deliberately keys on ``Fraction`` values rather than on
    ``Signature.sort_key()``: the latter emits (numerator, denominator)
    pairs, which order 1/2 before 1/3 and therefore do not realise the
    lexicographic *value* order that 19.2 and 19.3 require.
    """
    return tuple(v.value for v in signature.values)


def sort_signatures(signatures: Iterable[Signature]) -> Tuple[Signature, ...]:
    return tuple(sorted(signatures, key=signature_sort_key))


def pareto_minimal(signatures: Sequence[Signature]) -> Tuple[Signature, ...]:
    """The Pareto-minimal antichain of ``signatures``, canonically sorted.

    Duplicated signatures collapse to one frontier point: the frontier is a
    set of points in signature space.  Their realizations are not lost --
    fiber preservation lives in the ``RRecord`` (spec 19.6), which is why
    ``GammaRecord.dominated_available`` stays true.
    """
    unique: Dict[Signature, None] = {}
    for signature in signatures:
        unique.setdefault(signature, None)
    points = list(unique)

    frontier = [
        point
        for point in points
        if not any(other.dominates(point) for other in points if other is not point)
    ]
    return sort_signatures(frontier)


def dominated_by_any(point: Signature, candidates: Sequence[Signature]) -> bool:
    """Whether some candidate weakly dominates ``point`` (candidate <= point)."""
    return any(candidate.weakly_dominates(point) for candidate in candidates)
