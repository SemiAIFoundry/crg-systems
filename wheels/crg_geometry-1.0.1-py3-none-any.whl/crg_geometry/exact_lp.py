"""Exact rational linear programming used to decide vertex irredundancy.

Normative basis: master specification section 19.4 (canonical finite K).
19.4 requires the *irredundant* set of extreme vertices of
conv(R) + R^d_{>=0} under exact rational normalization.  Deciding whether
a candidate point is redundant is a rational LP feasibility question:

    v is redundant  <=>  exists lambda >= 0, sum(lambda) = 1 over the other
                         generators, with sum_i lambda_i x_i <= v componentwise.

Binary floating point cannot answer that question soundly -- a point that
lies exactly on a facet and a point a rational hair below it are the
difference between a vertex and a redundant one -- so the whole solver runs
over ``fractions.Fraction``.  Bland's pivoting rule is used because it is
the rule with a proof of termination under degeneracy, and degeneracy is
the normal case here (many candidate points share coordinate values).
"""
from __future__ import annotations

from fractions import Fraction
from typing import Optional, Sequence, Tuple

__all__ = [
    "LinearProgramError",
    "solve_feasibility",
    "convex_combination_below",
]


class LinearProgramError(RuntimeError):
    """Raised when the exact solver reaches a state it cannot certify."""


def solve_feasibility(
    rows: Sequence[Sequence[Fraction]],
    rhs: Sequence[Fraction],
) -> Optional[Tuple[Fraction, ...]]:
    """Return an exact ``x >= 0`` with ``A x = b``, or ``None`` if none exists.

    Implemented as a Phase-I simplex over exact rationals: artificial
    variables are appended, their sum is minimised, and the original system
    is feasible exactly when that minimum is zero.
    """
    m = len(rows)
    if m == 0:
        return ()
    n = len(rows[0])
    if any(len(row) != n for row in rows):
        raise LinearProgramError("constraint matrix is ragged")
    if len(rhs) != m:
        raise LinearProgramError("right-hand side length does not match row count")

    # Tableau columns: n structural, m artificial, then the right-hand side.
    rhs_col = n + m
    tableau: list[list[Fraction]] = []
    for i in range(m):
        b_i = Fraction(rhs[i])
        # Artificials must enter at a nonnegative level, so flip rows with b < 0.
        sign = Fraction(-1) if b_i < 0 else Fraction(1)
        row = [sign * Fraction(value) for value in rows[i]]
        row.extend(Fraction(1) if k == i else Fraction(0) for k in range(m))
        row.append(sign * b_i)
        tableau.append(row)

    basis = list(range(n, n + m))
    # Phase-I cost: 0 on structural columns, 1 on artificial columns.
    cost = [Fraction(0)] * n + [Fraction(1)] * m

    while True:
        basic_cost = [cost[basis[i]] for i in range(m)]
        entering = -1
        for j in range(n + m):
            if j in basis:
                continue
            z_j = Fraction(0)
            for i in range(m):
                if basic_cost[i]:
                    z_j += basic_cost[i] * tableau[i][j]
            # Bland's rule: first index with a strictly negative reduced cost.
            if cost[j] - z_j < 0:
                entering = j
                break
        if entering < 0:
            break

        leaving = -1
        best_ratio: Optional[Fraction] = None
        for i in range(m):
            pivot_value = tableau[i][entering]
            if pivot_value <= 0:
                continue
            ratio = tableau[i][rhs_col] / pivot_value
            if (
                best_ratio is None
                or ratio < best_ratio
                # Bland's tie-break: smallest leaving variable index.
                or (ratio == best_ratio and basis[i] < basis[leaving])
            ):
                best_ratio = ratio
                leaving = i
        if leaving < 0:
            # The Phase-I objective is a sum of nonnegative variables and so is
            # bounded below by zero; an unbounded ray here means a solver bug.
            raise LinearProgramError("phase-I objective reported unbounded")

        _pivot(tableau, leaving, entering)
        basis[leaving] = entering

    objective = Fraction(0)
    for i in range(m):
        if basis[i] >= n:
            objective += tableau[i][rhs_col]
    if objective > 0:
        return None

    solution = [Fraction(0)] * n
    for i in range(m):
        if basis[i] < n:
            solution[basis[i]] = tableau[i][rhs_col]
    return tuple(solution)


def _pivot(tableau: list[list[Fraction]], row: int, col: int) -> None:
    pivot_value = tableau[row][col]
    width = len(tableau[row])
    tableau[row] = [value / pivot_value for value in tableau[row]]
    for i in range(len(tableau)):
        if i == row:
            continue
        factor = tableau[i][col]
        if factor == 0:
            continue
        source = tableau[row]
        target = tableau[i]
        for j in range(width):
            target[j] -= factor * source[j]


def convex_combination_below(
    point: Sequence[Fraction],
    generators: Sequence[Sequence[Fraction]],
) -> Optional[Tuple[Fraction, ...]]:
    """Decide ``point in conv(generators) + R^d_{>=0}`` exactly.

    Returns the convex weights witnessing membership, or ``None``.  The
    witness is returned rather than a bare boolean so that callers can emit
    a checkable proof object (spec 19.4: V/H equivalence SHOULD be
    accompanied by a checkable proof or recomputation record).
    """
    n = len(generators)
    if n == 0:
        # conv(empty) is empty, so nothing lies above it.
        return None
    d = len(point)
    if any(len(g) != d for g in generators):
        raise LinearProgramError("generator dimension does not match the point")

    # Variables: lambda_1..lambda_n, then one slack per coordinate.
    # Row 0:      sum lambda_i                       = 1
    # Row j+1:    sum_i x_ij lambda_i + slack_j      = point_j   (slack_j >= 0)
    rows: list[list[Fraction]] = [[Fraction(1)] * n + [Fraction(0)] * d]
    rhs: list[Fraction] = [Fraction(1)]
    for j in range(d):
        row = [Fraction(generators[i][j]) for i in range(n)]
        row.extend(Fraction(1) if k == j else Fraction(0) for k in range(d))
        rows.append(row)
        rhs.append(Fraction(point[j]))

    solution = solve_feasibility(rows, rhs)
    if solution is None:
        return None
    return tuple(solution[:n])
