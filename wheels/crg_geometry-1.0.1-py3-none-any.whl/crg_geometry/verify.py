"""Independent consistency checking of an R / Gamma / K triple.

Normative basis: master specification section 19 (canonical geometry) and
section 20.3 (value-function error), read against section 16's requirement
that verification be independently auditable.

Nothing here calls the constructors in :mod:`crg_geometry.construct`.  The
checks are stated directly against the definitions in 19.2-19.4 so that a
verifier re-deriving the invariants cannot inherit a builder's bug: a
builder that dropped a fiber, mis-sorted a frontier, or admitted a
redundant vertex is caught by a rule, not by agreeing with itself.
"""
from __future__ import annotations

from typing import Any, List, Sequence

from crg_model.records import GammaRecord, KRecord, RRecord, Signature

from .exact_lp import convex_combination_below
from .pareto import signature_sort_key, signature_values
from .support import default_price_samples, dominates_region, support_value

__all__ = ["verify_geometry", "verify_R", "verify_gamma", "verify_K"]


def verify_geometry(r: RRecord, gamma: GammaRecord, k: KRecord) -> List[str]:
    """Return every geometry violation found; an empty list means consistent."""
    violations: List[str] = []
    violations.extend(verify_R(r))
    violations.extend(verify_gamma(r, gamma))
    violations.extend(verify_K(gamma, k))
    violations.extend(_verify_support_agreement(r, gamma, k))
    return violations


def verify_R(r: RRecord) -> List[str]:
    """Spec 19.2: sorted distinct signatures, sorted fibers, fibers preserved."""
    violations: List[str] = []
    dimension = r.schema.dimension

    keys = [signature_sort_key(fiber.signature) for fiber in r.fibers]
    if keys != sorted(keys):
        violations.append("R: fibers are not sorted lexicographically by signature")
    if len(set(keys)) != len(keys):
        violations.append("R: duplicate signatures across fibers; each signature needs one fiber")

    all_ids: List[str] = []
    for fiber in r.fibers:
        if len(fiber.signature) != dimension:
            violations.append(
                f"R: fiber signature {_show(fiber.signature)} has "
                f"{len(fiber.signature)} coordinates; schema declares {dimension}"
            )
        if not fiber.realization_ids:
            violations.append(f"R: fiber {_show(fiber.signature)} retains no realization")
        if list(fiber.realization_ids) != sorted(fiber.realization_ids):
            violations.append(
                f"R: realization identifiers in fiber {_show(fiber.signature)} are not sorted"
            )
        if len(set(fiber.realization_ids)) != len(fiber.realization_ids):
            violations.append(
                f"R: fiber {_show(fiber.signature)} repeats a realization identifier"
            )
        all_ids.extend(fiber.realization_ids)

    if len(set(all_ids)) != len(all_ids):
        violations.append("R: a realization identifier appears in more than one fiber")

    try:
        r.root_hash()
    except Exception as error:  # a non-canonicalizable body cannot be certified
        violations.append(f"R: root hash is not computable ({error})")
    return violations


def verify_gamma(r: RRecord, gamma: GammaRecord) -> List[str]:
    """Spec 19.3: Pareto-minimal antichain of R, sorted, orthant recession cone."""
    violations: List[str] = []

    if gamma.schema != r.schema:
        violations.append("Gamma: coordinate schema differs from R")
    if gamma.recession_cone != "NONNEGATIVE_ORTHANT":
        violations.append(
            f"Gamma: recession cone is {gamma.recession_cone!r}; 19.3 fixes the "
            "nonnegative orthant"
        )
    if r.fibers and not gamma.dominated_available:
        violations.append(
            "Gamma: dominated_available is false while R still retains fibers; "
            "19.3 requires dominated realizations to stay available"
        )

    keys = [signature_sort_key(point) for point in gamma.frontier]
    if keys != sorted(keys):
        violations.append("Gamma: frontier is not sorted under the declared coordinate order")
    if len(set(keys)) != len(keys):
        violations.append("Gamma: frontier repeats a point")

    signatures = set(r.signatures)
    for point in gamma.frontier:
        if point not in signatures:
            violations.append(f"Gamma: frontier point {_show(point)} is not a signature of R")

    for i, point in enumerate(gamma.frontier):
        for j, other in enumerate(gamma.frontier):
            if i != j and other.dominates(point):
                violations.append(
                    f"Gamma: frontier point {_show(other)} dominates "
                    f"{_show(point)}; the frontier must be an antichain"
                )

    # Completeness of the reduction: dropping dominated points must not shrink
    # the upper set, so every signature of R must be reachable from the frontier.
    for signature in r.signatures:
        if not any(point.weakly_dominates(signature) for point in gamma.frontier):
            violations.append(
                f"Gamma: signature {_show(signature)} of R is not dominated by any "
                "frontier point; the frontier omits part of R + orthant"
            )

    try:
        gamma.root_hash()
    except Exception as error:
        violations.append(f"Gamma: root hash is not computable ({error})")
    return violations


def verify_K(gamma: GammaRecord, k: KRecord) -> List[str]:
    """Spec 19.4: irredundant extreme vertices of conv(R) + orthant."""
    violations: List[str] = []

    if k.schema != gamma.schema:
        violations.append("K: coordinate schema differs from Gamma")
    if k.recession_cone != "NONNEGATIVE_ORTHANT":
        violations.append(
            f"K: recession cone is {k.recession_cone!r}; 19.4 fixes the nonnegative orthant"
        )

    keys = [signature_sort_key(vertex) for vertex in k.vertices]
    if keys != sorted(keys):
        violations.append("K: vertices are not in canonical order")
    if len(set(keys)) != len(keys):
        violations.append("K: vertex list repeats a point")

    frontier = set(gamma.frontier)
    for vertex in k.vertices:
        if vertex not in frontier:
            violations.append(
                f"K: vertex {_show(vertex)} is not a Gamma frontier point; a "
                "dominated point can never be extreme in conv(R) + orthant"
            )

    well_formed = all(len(vertex) == k.schema.dimension for vertex in k.vertices)
    if not well_formed:
        violations.append(
            f"K: a vertex does not carry the {k.schema.dimension} declared coordinates"
        )

    # Irredundancy: no vertex may lie in the hull of the others plus the orthant.
    coordinates = [signature_values(vertex) for vertex in k.vertices]
    if well_formed:
        for index, vertex in enumerate(k.vertices):
            others = [coordinates[j] for j in range(len(k.vertices)) if j != index]
            if convex_combination_below(coordinates[index], others) is not None:
                violations.append(
                    f"K: vertex {_show(vertex)} lies in the hull of the remaining "
                    "vertices plus the orthant and is therefore redundant"
                )

    # Sufficiency: K must still cover every Pareto point of Gamma.
    if k.vertices and well_formed and k.schema.dimension == gamma.schema.dimension:
        for point in gamma.frontier:
            if not dominates_region(point, k):
                violations.append(
                    f"K: Gamma frontier point {_show(point)} is outside "
                    "conv(vertices) + orthant; the vertex set is incomplete"
                )
    elif gamma.frontier:
        violations.append("K: vertex set is empty while Gamma has a nonempty frontier")

    try:
        k.root_hash()
    except Exception as error:
        violations.append(f"K: root hash is not computable ({error})")
    return violations


def _verify_support_agreement(r: RRecord, gamma: GammaRecord, k: KRecord) -> List[str]:
    """Spec 20.3: for w >= 0 the three records must share one value function.

    Passing infima over conv(R) equal infima over R for nonnegative prices,
    so any disagreement is a construction fault, not an approximation.  This
    is a sampled check and 19.5 forbids reading it as a proof of geometric
    equality; it is reported as a violation detector only.
    """
    violations: List[str] = []
    if not r.fibers or not gamma.frontier or not k.vertices:
        return violations
    if len({r.schema.dimension, gamma.schema.dimension, k.schema.dimension}) != 1:
        return violations

    for w in default_price_samples(r.schema.dimension):
        v_r = support_value(r, w)
        v_gamma = support_value(gamma, w)
        v_k = support_value(k, w)
        if v_gamma != v_r:
            violations.append(
                f"support: v_Gamma{_show_price(w)} = {v_gamma} but v_R{_show_price(w)} = {v_r}"
            )
        if v_k != v_gamma:
            violations.append(
                f"support: v_K{_show_price(w)} = {v_k} but v_Gamma{_show_price(w)} = {v_gamma}"
            )
    return violations


def _show(signature: Signature) -> str:
    return "(" + ", ".join(str(value) for value in signature_values(signature)) + ")"


def _show_price(w: Sequence[Any]) -> str:
    return "(" + ", ".join(str(component) for component in w) + ")"
