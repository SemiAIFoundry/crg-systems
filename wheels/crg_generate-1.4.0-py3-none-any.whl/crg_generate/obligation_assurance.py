"""First-party assurance for the legality effect of pack obligations.

The registry evaluates legality at step 5 and extracts obligations at step 8.
Consequently the seven current reference packs use obligations as typed,
post-legality reporting coordinates: none of those obligation values can admit
or reject a realization.  This module makes that fact an explicit policy and
tests it by rebuilding every reference family with extractors that refuse.

The policy also reserves the stronger ``LEGALITY_AFFECTING_CHECKER_REQUIRED``
class.  If a future first-party generator is intentionally allowed to make an
obligation legality-affecting, it must name a proof checker declared by the
same first-party pack.  An unclassified generator, a missing checker, or a
change in bundle/legality output when extraction is disabled refuses the whole
assurance report.
"""
from __future__ import annotations

import copy
from dataclasses import dataclass, replace
import re
from typing import Any, Dict, List, Mapping, Tuple

from crg_model.canonical import content_hash

from .packs import DomainPack, SecurityClassification, validate_pack
from .reference_packs import ALL_PACKS, build_pack_registry

__all__ = [
    "FIRST_PARTY_PACK_ASSURANCE_VERSION",
    "ObligationLegalityEffect",
    "FirstPartyObligationPolicy",
    "FirstPartyPackAssuranceEntry",
    "FirstPartyPackAssuranceReport",
    "FIRST_PARTY_OBLIGATION_POLICIES",
    "build_first_party_pack_assurance_report",
]


FIRST_PARTY_PACK_ASSURANCE_VERSION = "1.0.0"


class ObligationLegalityEffect:
    POST_LEGALITY_REPORTING_ONLY = "POST_LEGALITY_REPORTING_ONLY"
    LEGALITY_AFFECTING_CHECKER_REQUIRED = "LEGALITY_AFFECTING_CHECKER_REQUIRED"
    ALL = frozenset(
        {POST_LEGALITY_REPORTING_ONLY, LEGALITY_AFFECTING_CHECKER_REQUIRED}
    )


@dataclass(frozen=True)
class FirstPartyObligationPolicy:
    pack_identity: str
    generator_id: str
    legality_effect: str
    checker_ids: Tuple[str, ...]
    rationale: str

    def to_canonical(self) -> dict:
        return {
            "pack_identity": self.pack_identity,
            "generator_id": self.generator_id,
            "legality_effect": self.legality_effect,
            "checker_ids": list(self.checker_ids),
            "rationale": self.rationale,
        }


_REPORTING_RATIONALE = (
    "the registry assigns legality before step 8 obligation extraction; this generator's "
    "obligations are retained as typed reporting evidence and are not inputs to a legality "
    "predicate"
)


# Exact coverage is intentional.  A new first-party pack, a new extracting
# generator, or a generator version change is unclassified until this registry
# is consciously updated and the executable independence check passes.
FIRST_PARTY_OBLIGATION_POLICIES: Tuple[FirstPartyObligationPolicy, ...] = (
    FirstPartyObligationPolicy(
        "crg-generate.reference.generic-finite-realization",
        "crg-generate.finite-transformation@0.2.0",
        ObligationLegalityEffect.POST_LEGALITY_REPORTING_ONLY,
        (),
        _REPORTING_RATIONALE,
    ),
    FirstPartyObligationPolicy(
        "crg-generate.reference.compiler-graph",
        "crg-generate.reference.compiler-graph@0.2.0",
        ObligationLegalityEffect.POST_LEGALITY_REPORTING_ONLY,
        (),
        _REPORTING_RATIONALE,
    ),
    FirstPartyObligationPolicy(
        "crg-generate.reference.distributed-computation",
        "crg-generate.distributed-placement@0.2.0",
        ObligationLegalityEffect.POST_LEGALITY_REPORTING_ONLY,
        (),
        _REPORTING_RATIONALE,
    ),
    FirstPartyObligationPolicy(
        "crg-generate.reference.ai-system-realization",
        "crg-generate.reference.ai-system-realization@0.2.0",
        ObligationLegalityEffect.POST_LEGALITY_REPORTING_ONLY,
        (),
        _REPORTING_RATIONALE,
    ),
    FirstPartyObligationPolicy(
        "crg-generate.reference.advanced-packaging",
        "crg-generate.reference.advanced-packaging@0.2.0",
        ObligationLegalityEffect.POST_LEGALITY_REPORTING_ONLY,
        (),
        _REPORTING_RATIONALE,
    ),
    FirstPartyObligationPolicy(
        "crg-generate.reference.materials-process-evidence",
        "crg-generate.reference.materials-process-evidence@0.2.0",
        ObligationLegalityEffect.POST_LEGALITY_REPORTING_ONLY,
        (),
        _REPORTING_RATIONALE,
    ),
    FirstPartyObligationPolicy(
        "crg-generate.reference.layout-conversion",
        "crg-generate.reference.layout-conversion@0.2.0",
        ObligationLegalityEffect.POST_LEGALITY_REPORTING_ONLY,
        (),
        _REPORTING_RATIONALE,
    ),
)


@dataclass(frozen=True)
class FirstPartyPackAssuranceEntry:
    pack_name: str
    pack_identity: str
    manifest_hash: str
    pack_hash: str
    generator_policies: Tuple[FirstPartyObligationPolicy, ...]
    registered_checker_ids: Tuple[str, ...]
    observed_obligations: Tuple[Mapping[str, Any], ...]
    original_bundle_hash: str
    extractor_refusal_bundle_hash: str
    obligation_legality_independent: bool
    legality_affecting_extractor_count: int
    violations: Tuple[str, ...]

    @property
    def assured(self) -> bool:
        return not self.violations

    def to_canonical(self) -> dict:
        return {
            "pack_name": self.pack_name,
            "pack_identity": self.pack_identity,
            "manifest_hash": self.manifest_hash,
            "pack_hash": self.pack_hash,
            "generator_policies": [p.to_canonical() for p in self.generator_policies],
            "registered_checker_ids": list(self.registered_checker_ids),
            "observed_obligations": [dict(item) for item in self.observed_obligations],
            "executable_independence_check": {
                "method": "REBUILD_WITH_EVERY_OBLIGATION_EXTRACTOR_REFUSING",
                "original_bundle_hash": self.original_bundle_hash,
                "extractor_refusal_bundle_hash": self.extractor_refusal_bundle_hash,
                "obligation_legality_independent": self.obligation_legality_independent,
            },
            "legality_affecting_extractor_count": (
                self.legality_affecting_extractor_count
            ),
            "violations": list(self.violations),
            "assured": self.assured,
        }


@dataclass(frozen=True)
class FirstPartyPackAssuranceReport:
    packs: Tuple[FirstPartyPackAssuranceEntry, ...]
    violations: Tuple[str, ...]
    report_version: str = FIRST_PARTY_PACK_ASSURANCE_VERSION
    authority: str = "FIRST_PARTY_PACK_OBLIGATION_ASSURANCE"

    @property
    def assured(self) -> bool:
        return not self.violations and all(pack.assured for pack in self.packs)

    @property
    def disposition(self) -> str:
        return "ASSURED" if self.assured else "REFUSED"

    def to_canonical(self) -> dict:
        return {
            "record_type": "CRGFirstPartyPackAssuranceReport",
            "report_version": self.report_version,
            "authority": self.authority,
            "claim_boundary": (
                "proves classification coverage, checker registration for any explicitly "
                "legality-affecting obligation, and bundle-level independence of current "
                "reporting-only extractors; it does not verify external plugins"
            ),
            "disposition": self.disposition,
            "reference_pack_count": len(self.packs),
            "legality_affecting_extractor_count": sum(
                pack.legality_affecting_extractor_count for pack in self.packs
            ),
            "registered_first_party_checker_count": sum(
                len(pack.registered_checker_ids) for pack in self.packs
            ),
            "packs": [pack.to_canonical() for pack in self.packs],
            "violations": list(self.violations),
        }

    def report_hash(self) -> str:
        return content_hash(self.to_canonical())


def _refusing_extractor(*_args: Any, **_kwargs: Any) -> Any:
    raise RuntimeError("assurance probe: obligation extractor deliberately refused")


def _pack_with_refusing_extractors(pack: DomainPack) -> DomainPack:
    generators = []
    for generator in pack.generators:
        cloned = copy.copy(generator)
        definition = generator.definition
        if definition.obligation_extractor is not None:
            cloned.definition = replace(
                definition, obligation_extractor=_refusing_extractor
            )
            # Callable identity is intentionally absent from the canonical
            # definition.  Both definitions still declare extraction=True and
            # therefore retain the same definition hash.
            if cloned.definition.definition_hash() != definition.definition_hash():
                raise AssertionError("assurance probe changed a generator definition hash")
        generators.append(cloned)
    return replace(pack, generators=tuple(generators))


def _observed_obligation_summary(report: Any) -> Tuple[Mapping[str, Any], ...]:
    grouped: Dict[Tuple[str, str, str], int] = {}
    for obligation in report.obligations:
        key = (obligation.source, obligation.obligation_type, obligation.name)
        grouped[key] = grouped.get(key, 0) + 1
    return tuple(
        {
            # ``Obligation.source`` is evidence provenance.  Most reference
            # packs use the generator id, while the materials pack correctly
            # uses campaign/model/declaration provenance instead.
            "source": generator_id,
            "obligation_type": obligation_type,
            "name": name,
            "count": count,
        }
        for (generator_id, obligation_type, name), count in sorted(grouped.items())
    )


def _assess_pack(
    pack_name: str,
    pack: DomainPack,
    policies: Tuple[FirstPartyObligationPolicy, ...],
) -> FirstPartyPackAssuranceEntry:
    violations: List[str] = []
    identity = pack.manifest.identity
    if pack.manifest.security_classification != SecurityClassification.TRUSTED_FIRST_PARTY:
        violations.append(
            f"{identity}: reference pack is not classified TRUSTED_FIRST_PARTY"
        )
    for violation in validate_pack(pack):
        violations.append(f"{identity}: pack validation: {violation}")

    pack_policies = tuple(
        sorted(
            (policy for policy in policies if policy.pack_identity == identity),
            key=lambda policy: policy.generator_id,
        )
    )
    extracting = {
        generator.definition.qualified_id
        for generator in pack.generators
        if generator.definition.obligation_extractor is not None
    }
    classified = {policy.generator_id for policy in pack_policies}
    for generator_id in sorted(extracting - classified):
        violations.append(
            f"{identity}: extracting generator {generator_id!r} has no explicit legality-"
            "effect classification"
        )
    for generator_id in sorted(classified - extracting):
        violations.append(
            f"{identity}: policy names absent or non-extracting generator {generator_id!r}"
        )
    if len(classified) != len(pack_policies):
        violations.append(f"{identity}: a generator legality-effect policy is duplicated")

    checker_ids = tuple(
        sorted(str(checker.get("checker_id", "")) for checker in pack.proof_checkers)
    )
    checker_set = set(checker_ids)
    checker_by_id = {
        str(checker.get("checker_id", "")): checker for checker in pack.proof_checkers
    }
    legality_affecting = 0
    for policy in pack_policies:
        if policy.legality_effect not in ObligationLegalityEffect.ALL:
            violations.append(
                f"{identity}: generator {policy.generator_id!r} has unknown legality effect "
                f"{policy.legality_effect!r}"
            )
            continue
        if not policy.rationale.strip():
            violations.append(
                f"{identity}: generator {policy.generator_id!r} has no classification rationale"
            )
        if (
            policy.legality_effect
            == ObligationLegalityEffect.POST_LEGALITY_REPORTING_ONLY
        ):
            if policy.checker_ids:
                violations.append(
                    f"{identity}: reporting-only generator {policy.generator_id!r} "
                    "must not imply a proof-checker authority"
                )
        else:
            legality_affecting += 1
            if not policy.checker_ids:
                violations.append(
                    f"{identity}: legality-affecting generator {policy.generator_id!r} "
                    "declares no required first-party checker"
                )
            for checker_id in sorted(set(policy.checker_ids) - checker_set):
                violations.append(
                    f"{identity}: legality-affecting generator {policy.generator_id!r} "
                    f"requires unregistered checker {checker_id!r}"
                )
            for checker_id in sorted(set(policy.checker_ids) & checker_set):
                declaration = checker_by_id[checker_id]
                trust_profile = str(declaration.get("trust_profile", ""))
                if trust_profile not in {"FIRST_PARTY_PINNED", "TRUSTED_FIRST_PARTY"}:
                    violations.append(
                        f"{identity}: required checker {checker_id!r} is not pinned by a "
                        f"first-party trust profile"
                    )
                implementation = str(declaration.get("implementation_identity", ""))
                if not re.fullmatch(r"sha256:[0-9a-f]{64}", implementation):
                    violations.append(
                        f"{identity}: required checker {checker_id!r} has no canonical "
                        "sha256 implementation identity"
                    )

    original_bundle_hash = ""
    refused_bundle_hash = ""
    independent = False
    observed: Tuple[Mapping[str, Any], ...] = ()
    try:
        original_bundle, original_report = build_pack_registry(pack)
        refusing_pack = _pack_with_refusing_extractors(pack)
        refused_bundle, refused_report = build_pack_registry(refusing_pack)
        original_bundle_hash = original_bundle.bundle_hash()
        refused_bundle_hash = refused_bundle.bundle_hash()
        observed = _observed_obligation_summary(original_report)
        independent = (
            original_bundle_hash == refused_bundle_hash
            and original_report.legality_tally == refused_report.legality_tally
            and original_report.claim_scope == refused_report.claim_scope
            and not refused_report.obligations
        )
        if not independent:
            violations.append(
                f"{identity}: obligation extractor refusal changed bundle, legality tally, "
                "claim scope, or still emitted obligations"
            )
    except Exception as error:  # noqa: BLE001 - the gate records all refusal causes
        violations.append(
            f"{identity}: executable obligation-independence check failed: "
            f"{type(error).__name__}: {error}"
        )

    return FirstPartyPackAssuranceEntry(
        pack_name=pack_name,
        pack_identity=identity,
        manifest_hash=pack.manifest.manifest_hash(),
        pack_hash=pack.pack_hash(),
        generator_policies=pack_policies,
        registered_checker_ids=checker_ids,
        observed_obligations=observed,
        original_bundle_hash=original_bundle_hash,
        extractor_refusal_bundle_hash=refused_bundle_hash,
        obligation_legality_independent=independent,
        legality_affecting_extractor_count=legality_affecting,
        violations=tuple(sorted(set(violations))),
    )


def build_first_party_pack_assurance_report() -> FirstPartyPackAssuranceReport:
    """Assess the complete, immutable first-party registry and fail closed.

    The function accepts no caller-supplied pack or policy list.  This prevents
    an integration gate from accidentally assessing a convenient subset.
    """

    entries: List[FirstPartyPackAssuranceEntry] = []
    global_violations: List[str] = []
    registered_identities = {entry.identity for entry in ALL_PACKS}
    policy_identities = {
        policy.pack_identity for policy in FIRST_PARTY_OBLIGATION_POLICIES
    }
    for identity in sorted(registered_identities - policy_identities):
        global_violations.append(
            f"first-party reference pack {identity!r} has no obligation policy"
        )
    for identity in sorted(policy_identities - registered_identities):
        global_violations.append(
            f"obligation policy names non-reference pack {identity!r}"
        )

    for entry in ALL_PACKS:
        assessed = _assess_pack(
            entry.name, entry.load(), FIRST_PARTY_OBLIGATION_POLICIES
        )
        entries.append(assessed)
        global_violations.extend(assessed.violations)

    if len(entries) != 7:
        global_violations.append(
            f"the first-party distribution must contain all seven reference packs, got "
            f"{len(entries)}"
        )
    return FirstPartyPackAssuranceReport(
        packs=tuple(entries),
        violations=tuple(sorted(set(global_violations))),
    )
