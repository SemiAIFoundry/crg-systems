"""Kernel-enforced OCI execution for untrusted CRG plugins.

The Python sandbox in :mod:`crg_generate.sandbox` is useful defence in depth,
but it is not a security boundary against native code.  This module builds and
drives a Docker- or Podman-compatible OCI invocation whose *kernel* enforces
the filesystem, network, process, privilege, and resource envelope required by
specification 36.3.

It deliberately does not discover a runtime or image implicitly.  Production
operators must name an absolute runtime executable and a digest-pinned image;
missing or unverifiable controls fail closed before plugin code runs.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import secrets
import shutil
import signal
import subprocess
import tempfile
from dataclasses import dataclass
from fractions import Fraction
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

__all__ = [
    "OCI_REPLY_PATH",
    "OciSandboxError",
    "OciSandboxConfig",
    "OciRuntimeEvidence",
    "OciProcessResult",
]

OCI_REPLY_PATH = "/crg-output/reply.json"
_IMAGE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._/:\-]*@sha256:[0-9a-f]{64}$")
_RUNTIME_KINDS = frozenset({"docker", "podman"})
_FORBIDDEN_TARGET_TREES = (
    "/bin", "/boot", "/dev", "/etc", "/lib", "/lib64", "/proc",
    "/run", "/sbin", "/sys", "/usr", "/opt/crg", "/crg-output",
    "/crg-scratch",
)
_FORBIDDEN_TARGETS_EXACT = frozenset({"/", "/tmp", "/var"})


class OciSandboxError(ValueError):
    """A production OCI policy cannot be proven or executed safely."""


def _canonical_json(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(",", ":")).encode(
        "utf-8"
    )


def _sha256(data: bytes) -> str:
    return "sha256:" + hashlib.sha256(data).hexdigest()


def _inside(path: str, root: str) -> bool:
    return path == root or path.startswith(root.rstrip("/") + "/")


def _bounded_text(data: bytes, maximum: int) -> str:
    if len(data) <= maximum:
        return data.decode("utf-8", "replace")
    suffix = f"\n[truncated: {len(data) - maximum} byte(s)]"
    return data[:maximum].decode("utf-8", "replace") + suffix


def _json_object(data: bytes, label: str, maximum: int) -> Mapping[str, Any]:
    if len(data) > maximum:
        raise OciSandboxError(f"{label} exceeded the {maximum}-byte response limit")
    try:
        value = json.loads(data.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as exc:
        raise OciSandboxError(f"{label} was not a JSON object: {exc}") from exc
    if not isinstance(value, dict):
        raise OciSandboxError(f"{label} was not a JSON object")
    return value


def _all_strings(value: Any) -> Tuple[str, ...]:
    found = []
    if isinstance(value, str):
        found.append(value.lower())
    elif isinstance(value, Mapping):
        for key, child in value.items():
            found.append(str(key).lower())
            found.extend(_all_strings(child))
    elif isinstance(value, (list, tuple)):
        for child in value:
            found.extend(_all_strings(child))
    return tuple(found)


@dataclass(frozen=True)
class OciRuntimeEvidence:
    runtime_kind: str
    runtime_path: str
    runtime_version: str
    server_platform: str
    security_options: Tuple[str, ...]
    seccomp_enabled: bool
    rootless: bool
    image: str
    observed: bool = True

    def to_canonical(self) -> dict:
        return {
            "profile": "OCI_KERNEL",
            "kernel_enforced": bool(self.observed and self.seccomp_enabled),
            "runtime_kind": self.runtime_kind,
            "runtime_path": self.runtime_path,
            "runtime_version": self.runtime_version,
            "server_platform": self.server_platform,
            "security_options": list(self.security_options),
            "seccomp_enabled": self.seccomp_enabled,
            "rootless": self.rootless,
            "image": self.image,
            "observed": self.observed,
        }


@dataclass(frozen=True)
class OciProcessResult:
    reply: bytes
    stdout: str
    stderr: str
    exit_status: Optional[int]
    timed_out: bool
    terminating_signal: str
    evidence: OciRuntimeEvidence
    command_hash: str
    notes: Tuple[str, ...] = ()


@dataclass(frozen=True)
class OciSandboxConfig:
    """A deny-by-default OCI runtime profile.

    ``runtime_path`` is absolute so PATH replacement cannot select another
    executable. ``image`` must be a registry name plus sha256 digest; mutable
    tags and implicit pulls are refused.  The runtime is probed for a Linux
    server and seccomp before every invocation (runtime calls are cheap beside
    untrusted plugin execution, and stale startup evidence is not evidence).
    """

    runtime_kind: str
    runtime_path: str
    image: str
    run_as_uid: int = 65532
    run_as_gid: int = 65532
    require_seccomp: bool = True
    require_rootless: bool = False
    cpu_count: Fraction = Fraction(1)
    tmpfs_bytes: int = 16 * 1024 * 1024
    max_runtime_response_bytes: int = 512 * 1024
    max_reply_bytes: int = 8 * 1024 * 1024
    max_output_bytes: int = 1024 * 1024
    probe_timeout_seconds: int = 10

    def __post_init__(self) -> None:
        object.__setattr__(self, "runtime_kind", str(self.runtime_kind).lower())
        object.__setattr__(self, "cpu_count", Fraction(self.cpu_count))

    def violations(self) -> Tuple[str, ...]:
        found = []
        if self.runtime_kind not in _RUNTIME_KINDS:
            found.append(f"runtime_kind must be one of {sorted(_RUNTIME_KINDS)}")
        if not os.path.isabs(self.runtime_path):
            found.append("runtime_path must be absolute")
        if not _IMAGE.fullmatch(self.image):
            found.append("image must be registry/repository@sha256:<64 lowercase hex digits>")
        if self.run_as_uid <= 0 or self.run_as_gid <= 0:
            found.append("the container must run as a non-root numeric uid and gid")
        if self.cpu_count <= 0:
            found.append("cpu_count must be positive")
        for name in (
            "tmpfs_bytes", "max_runtime_response_bytes", "max_reply_bytes",
            "max_output_bytes", "probe_timeout_seconds",
        ):
            if not isinstance(getattr(self, name), int) or getattr(self, name) <= 0:
                found.append(f"{name} must be a positive integer")
        return tuple(found)

    def to_canonical(self) -> dict:
        return {
            "runtime_kind": self.runtime_kind,
            "runtime_path": self.runtime_path,
            "image": self.image,
            "run_as_uid": self.run_as_uid,
            "run_as_gid": self.run_as_gid,
            "require_seccomp": self.require_seccomp,
            "require_rootless": self.require_rootless,
            "cpu_count": {
                "exact": str(self.cpu_count.numerator)
                if self.cpu_count.denominator == 1
                else f"{self.cpu_count.numerator}/{self.cpu_count.denominator}"
            },
            "tmpfs_bytes": self.tmpfs_bytes,
            "max_runtime_response_bytes": self.max_runtime_response_bytes,
            "max_reply_bytes": self.max_reply_bytes,
            "max_output_bytes": self.max_output_bytes,
            "probe_timeout_seconds": self.probe_timeout_seconds,
        }

    def _run_probe(self, argv: Sequence[str]) -> Mapping[str, Any]:
        try:
            completed = subprocess.run(
                list(argv), input=b"", stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                timeout=self.probe_timeout_seconds, check=False,
                env={"PATH": "/usr/bin:/bin", "LANG": "C", "LC_ALL": "C"},
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise OciSandboxError(
                f"OCI runtime probe could not execute {argv[0]!r}: {type(exc).__name__}: {exc}"
            ) from exc
        if completed.returncode != 0:
            detail = _bounded_text(completed.stderr, 2000).strip()
            raise OciSandboxError(
                f"OCI runtime probe {list(argv[1:])!r} exited {completed.returncode}: {detail}"
            )
        return _json_object(
            completed.stdout, "OCI runtime probe", self.max_runtime_response_bytes
        )

    def probe(self) -> OciRuntimeEvidence:
        violations = self.violations()
        if violations:
            raise OciSandboxError("; ".join(violations))
        if not os.path.isfile(self.runtime_path) or not os.access(self.runtime_path, os.X_OK):
            raise OciSandboxError(
                f"OCI runtime {self.runtime_path!r} is absent or not executable"
            )
        mode = os.stat(self.runtime_path).st_mode
        if mode & 0o022:
            raise OciSandboxError(
                "OCI runtime executable is group- or world-writable; runtime attestation "
                "cannot be trusted"
            )
        if self.runtime_kind == "docker":
            version = self._run_probe(
                (self.runtime_path, "version", "--format", "{{json .Server}}")
            )
            info = self._run_probe(
                (self.runtime_path, "info", "--format", "{{json .}}")
            )
            platform_name = str(version.get("Os", version.get("Platform", {}).get("Name", "")))
            version_name = str(version.get("Version", ""))
            raw_security = info.get("SecurityOptions", ()) or ()
            security = tuple(sorted(str(item) for item in raw_security))
            tokens = _all_strings(raw_security)
            rootless = any("rootless" in token for token in tokens)
            seccomp = any("seccomp" in token for token in tokens)
        else:
            version = self._run_probe((self.runtime_path, "version", "--format", "json"))
            info = self._run_probe((self.runtime_path, "info", "--format", "json"))
            platform_name = str(
                info.get("host", {}).get("os", "")
                if isinstance(info.get("host"), Mapping) else ""
            )
            client = version.get("Client", version.get("client", version))
            version_name = str(client.get("Version", client.get("version", ""))) if isinstance(client, Mapping) else ""
            tokens = _all_strings(info)
            rootless = any(token in {"rootless", "true"} for token in tokens) and "rootless" in tokens
            seccomp = any("seccomp" in token for token in tokens) and not any(
                token in {"seccompenabled:false", "seccomp:false"} for token in tokens
            )
            security = tuple(sorted({token for token in tokens if "seccomp" in token or "rootless" in token}))
        if platform_name.lower() != "linux":
            raise OciSandboxError(
                f"OCI server platform must be linux, observed {platform_name!r}"
            )
        if not version_name:
            raise OciSandboxError("OCI runtime did not report a server version")
        if self.require_seccomp and not seccomp:
            raise OciSandboxError("OCI runtime did not prove that seccomp is enabled")
        if self.require_rootless and not rootless:
            raise OciSandboxError("OCI runtime did not prove rootless operation")
        return OciRuntimeEvidence(
            runtime_kind=self.runtime_kind,
            runtime_path=self.runtime_path,
            runtime_version=version_name,
            server_platform="linux",
            security_options=security,
            seccomp_enabled=seccomp,
            rootless=rootless,
            image=self.image,
        )

    @staticmethod
    def _validate_mounts(paths: Sequence[str], *, writable: bool) -> Tuple[str, ...]:
        resolved = []
        for raw in paths:
            if not os.path.isabs(raw):
                raise OciSandboxError(f"bind mount source must be absolute: {raw!r}")
            lexical = os.path.normpath(raw)
            if any(character in raw for character in (",", "\n", "\x00")):
                raise OciSandboxError(
                    f"bind mount path contains a character unsafe for OCI --mount: {raw!r}"
                )
            path = os.path.realpath(raw)
            if not os.path.exists(path):
                raise OciSandboxError(f"bind mount source does not exist: {path!r}")
            if (
                lexical in _FORBIDDEN_TARGETS_EXACT
                or path in _FORBIDDEN_TARGETS_EXACT
                or any(
                    _inside(candidate, root)
                    for candidate in (lexical, path)
                    for root in _FORBIDDEN_TARGET_TREES
                )
            ):
                mode = "writable" if writable else "readable"
                raise OciSandboxError(
                    f"{mode} bind target {path!r} overlaps a container control path"
                )
            resolved.append(path)
        return tuple(sorted(set(resolved)))

    def command(
        self, *, container_name: str, reply_path: str, environment_path: str,
        readable_paths: Sequence[str], writable_paths: Sequence[str],
        network: bool, memory_bytes: int, max_processes: int,
    ) -> Tuple[str, ...]:
        if not re.fullmatch(r"crg-plugin-[a-zA-Z0-9][a-zA-Z0-9_.-]{0,62}", container_name):
            raise OciSandboxError("container_name is outside the CRG invocation namespace")
        for label, path in (("reply_path", reply_path), ("environment_path", environment_path)):
            if not os.path.isabs(path) or any(c in path for c in (",", "\n", "\x00")):
                raise OciSandboxError(f"{label} must be an absolute OCI-safe path")
        if memory_bytes <= 0 or max_processes < 0:
            raise OciSandboxError("memory_bytes must be positive and max_processes non-negative")
        readable = self._validate_mounts(readable_paths, writable=False)
        writable = self._validate_mounts(writable_paths, writable=True)
        if set(readable) & set(writable):
            raise OciSandboxError("a bind mount may not be declared both readable and writable")
        argv = [
            self.runtime_path, "run", "--rm", "--interactive", "--pull", "never",
            "--name", container_name, "--read-only", "--cap-drop", "ALL",
            "--security-opt", "no-new-privileges", "--user",
            f"{self.run_as_uid}:{self.run_as_gid}", "--ipc", "none",
            "--network", "bridge" if network else "none",
            "--pids-limit", str(max(1, max_processes + 1)),
            "--memory", str(memory_bytes), "--memory-swap", str(memory_bytes),
            "--cpus", format(float(self.cpu_count), ".6g"),
            "--workdir", "/crg-scratch",
            "--tmpfs", f"/tmp:rw,noexec,nosuid,nodev,size={self.tmpfs_bytes}",
            "--tmpfs", f"/crg-scratch:rw,noexec,nosuid,nodev,size={self.tmpfs_bytes}",
            "--env-file", environment_path,
            "--mount", f"type=bind,src={reply_path},dst={OCI_REPLY_PATH}",
        ]
        for path in readable:
            argv.extend(("--mount", f"type=bind,src={path},dst={path},readonly"))
        for path in writable:
            argv.extend(("--mount", f"type=bind,src={path},dst={path}"))
        argv.append(self.image)
        return tuple(argv)

    def run(
        self, request: bytes, *, environment: Mapping[str, str],
        readable_paths: Sequence[str], writable_paths: Sequence[str], network: bool,
        memory_bytes: int, max_processes: int, wall_clock_seconds: Fraction,
    ) -> OciProcessResult:
        evidence = self.probe()
        channel = tempfile.mkdtemp(prefix="crg-oci-channel-")
        reply_path = os.path.join(channel, "reply.json")
        environment_path = os.path.join(channel, "environment.list")
        container_name = "crg-plugin-" + secrets.token_hex(12)
        notes = []
        process: Optional[subprocess.Popen[bytes]] = None
        timed_out = False
        stdout = b""
        stderr = b""
        try:
            with open(reply_path, "xb"):
                pass
            os.chmod(reply_path, 0o666)
            with open(environment_path, "x", encoding="utf-8", newline="\n") as handle:
                for name, value in sorted(environment.items()):
                    if not name or any(c not in "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_" for c in name):
                        raise OciSandboxError(f"invalid environment variable name {name!r}")
                    if "\n" in value or "\x00" in value:
                        raise OciSandboxError(f"environment variable {name!r} is not line-safe")
                    handle.write(f"{name}={value}\n")
            os.chmod(environment_path, 0o600)
            argv = self.command(
                container_name=container_name, reply_path=reply_path,
                environment_path=environment_path, readable_paths=readable_paths,
                writable_paths=writable_paths, network=network,
                memory_bytes=memory_bytes, max_processes=max_processes,
            )
            command_hash = _sha256(_canonical_json(list(argv)))
            process = subprocess.Popen(
                list(argv), stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                stderr=subprocess.PIPE, close_fds=True, start_new_session=True,
                env={"PATH": "/usr/bin:/bin", "LANG": "C", "LC_ALL": "C"},
            )
            try:
                stdout, stderr = process.communicate(
                    input=request, timeout=float(Fraction(wall_clock_seconds))
                )
            except subprocess.TimeoutExpired:
                timed_out = True
                try:
                    subprocess.run(
                        [self.runtime_path, "kill", container_name],
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                        timeout=self.probe_timeout_seconds, check=False,
                        env={"PATH": "/usr/bin:/bin", "LANG": "C", "LC_ALL": "C"},
                    )
                except (OSError, subprocess.TimeoutExpired) as exc:
                    notes.append(
                        f"runtime kill command failed: {type(exc).__name__}: {exc}"
                    )
                try:
                    os.killpg(os.getpgid(process.pid), signal.SIGKILL)
                except (OSError, ProcessLookupError):
                    process.kill()
                try:
                    stdout, stderr = process.communicate(timeout=10)
                except subprocess.TimeoutExpired:
                    notes.append("runtime CLI survived process-group kill; killed directly")
                    process.kill()
                    stdout, stderr = process.communicate(timeout=10)
            with open(reply_path, "rb") as handle:
                reply = handle.read(self.max_reply_bytes + 1)
            if len(reply) > self.max_reply_bytes:
                notes.append(f"reply exceeded {self.max_reply_bytes} bytes and was refused")
                reply = b""
            status = process.returncode
            terminating = ""
            if status is not None and status < 0:
                try:
                    terminating = signal.Signals(-status).name
                except ValueError:
                    terminating = f"SIG{-status}"
            return OciProcessResult(
                reply=reply, stdout=_bounded_text(stdout, self.max_output_bytes),
                stderr=_bounded_text(stderr, self.max_output_bytes),
                exit_status=status, timed_out=timed_out,
                terminating_signal=terminating, evidence=evidence,
                command_hash=command_hash, notes=tuple(notes),
            )
        finally:
            shutil.rmtree(channel, ignore_errors=True)
