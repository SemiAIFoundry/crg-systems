"""Realization-registry construction: the required workflow of section 28.3.

Normative basis: master specification section 28 (OID-CRG-001 legal-realization
representation), with section 21 (completeness basis and claim scope), section
6.5 (deterministic authority), 6.11 (no silent truncation), 18 (typed
dependency graph), and 19.6 (realization fibers).

Specification 28.3 fixes thirteen steps.  :func:`build_registry` executes them
in order, and each step is marked in the code with its number so the workflow
can be audited against the specification rather than inferred from behaviour.

Four properties of this module are safety properties:

1. **The completeness basis is derived, never declared** (21.3, 28.3 step 10).
   ``GENERATOR_CLOSED`` is emitted only when the closure actually reached a
   fixpoint, under generators that are all reproducible and all declare that
   they close the family, with no unentered region.  A depth or size limit
   that stopped the expansion yields ``TRUNCATED_BY_DECLARED_RULE`` carrying
   the rule that stopped it (6.11).  Seeds with no generation yield
   ``EXPLICIT_IMPORTED_FAMILY`` (28.5).  A finite declared universe that was
   fully enumerated yields ``EXHAUSTIVE_DECLARED_UNIVERSE`` with the count as
   its closure proof.  A caller's ``completeness_hint`` may *weaken* the
   derived basis and may never strengthen it.

2. **Ungenerated is not infeasible** (28.4).  A region no generator entered --
   because a capability gate was closed, a permission was absent, the source
   type was not accepted, or an invocation failed -- is recorded as an
   :class:`UngeneratedRegion` with legality ``UNGENERATED``.  It never becomes
   a realization record, it never becomes ``INFEASIBLE``, and its presence
   removes the right to claim ``GENERATOR_CLOSED``.

3. **Fibers are preserved** (19.6, 28.6).  Deduplication is by content-derived
   *identity*, which includes the parent and the transformation; it is never
   by signature.  Two derivation paths that reach the same signature stay two
   records and ``crg_geometry.build_R`` places them in one fiber.

4. **Determinism** (6.5).  Frontier and generator iteration are both sorted,
   identities are content-derived, and no clock, counter, or ``uuid4`` enters
   any canonical field.  Building the same registry twice yields the same
   ``bundle_hash()``.
"""
from __future__ import annotations

import textwrap
from dataclasses import dataclass, field, replace
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple, Union

from crg_model.canonical import content_hash
from crg_model.completeness import (
    ClaimScope,
    CompletenessBasis,
    CompletenessBasisType,
    derive_claim_scope,
)
from crg_model.edges import DependencyEdge, DependencyGraph, EdgeType
from crg_model.records import (
    CoordinateSchema,
    RealizationBundle,
    RealizationRecord,
)

from .generator import (
    ATTR_DEPTH,
    ATTR_GENERATOR_HASH,
    ATTR_PATH,
    ATTR_TRANSFORMATION,
    DeterminismStatus,
    FailureSemantics,
    GenerationContext,
    Generator,
    GeneratorDefinition,
    Obligation,
    WitnessMethod,
    as_seed,
    derive_realization_id,
    record_depth,
)
from .legality import (
    LegalityPredicate,
    LegalityResult,
    LegalityStatus,
    evaluate_legality,
)

__all__ = [
    "ENGINE_ID",
    "ENGINE_VERSION",
    "DEFAULT_DEPTH_LIMIT",
    "DEFAULT_SIZE_LIMIT",
    "GenerationError",
    "ReasonCode",
    "GenerationSource",
    "UngeneratedRegion",
    "GeneratorInvocation",
    "GeneratorFailure",
    "RejectedCandidate",
    "ClosureReport",
    "GenerationReport",
    "closure",
    "build_registry",
    "derive_completeness_basis",
    "BASIS_STRENGTH",
]

ENGINE_ID = "crg-generate"
ENGINE_VERSION = "crg-generate@0.2.0"

#: Engine safety limits.  They are *declared rules*: hitting one is a
#: truncation and is reported as such, never as a completed closure (6.11).
DEFAULT_DEPTH_LIMIT = 64
DEFAULT_SIZE_LIMIT = 4096


class GenerationError(ValueError):
    """Raised when generation input or a generator emission is inadmissible."""


class ReasonCode:
    """Why a region of the family was never entered (spec 28.4)."""

    CAPABILITY_GATE_CLOSED = "CAPABILITY_GATE_CLOSED"
    PERMISSION_ABSENT = "PERMISSION_ABSENT"
    SOURCE_TYPE_NOT_ACCEPTED = "SOURCE_TYPE_NOT_ACCEPTED"
    GENERATOR_FAILED = "GENERATOR_FAILED"
    EMISSION_REFUSED = "EMISSION_REFUSED"
    CLOSURE_TRUNCATED = "CLOSURE_TRUNCATED"
    DECLARED_BY_GENERATOR = "DECLARED_BY_GENERATOR"


# ---------------------------------------------------------------------------
# source (spec 28.3 steps 1-3)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class GenerationSource:
    """The source a registry is built from (spec 28.3 step 1, 11).

    ``seeds`` are the realizations received rather than produced: an imported
    registry (28.5), a hand-written starting point, or the roots a generator
    expands.  ``computation_contract``, ``resource_contract``, and
    ``hierarchy_contract`` are the contracts steps 2 and 3 validate.

    ``universe_key`` and ``declared_universe_size`` describe an explicitly
    finite declared universe: ``universe_key`` names the record attribute whose
    distinct values enumerate that universe.  When the closure reaches a
    fixpoint and the distinct values exactly exhaust the declared count, the
    derived basis is ``EXHAUSTIVE_DECLARED_UNIVERSE`` and the count itself is
    recorded as the closure proof (21.2, 21.3).
    """

    source_id: str
    source_type: str
    seeds: Tuple[RealizationRecord, ...] = ()
    computation_contract: Mapping[str, Any] = field(default_factory=dict)
    resource_contract: Mapping[str, Any] = field(default_factory=dict)
    hierarchy_contract: Mapping[str, Any] = field(default_factory=dict)
    declared_universe: Optional[str] = None
    universe_key: Optional[str] = None
    declared_universe_size: Optional[int] = None
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.source_id:
            raise GenerationError("a generation source MUST have an identity (spec 14.1)")
        if not self.source_type:
            raise GenerationError(
                "a generation source MUST declare its type so a generator's accepted source "
                "types can be checked (spec 28.4)"
            )
        if self.declared_universe_size is not None and self.declared_universe_size < 0:
            raise GenerationError("a declared universe size cannot be negative")

    def to_canonical(self) -> dict:
        record: dict = {
            "source_id": self.source_id,
            "source_type": self.source_type,
            "seeds": [r.to_canonical() for r in sorted(self.seeds, key=lambda r: r.realization_id)],
            "computation_contract": dict(self.computation_contract),
            "resource_contract": dict(self.resource_contract),
            "hierarchy_contract": dict(self.hierarchy_contract),
            "metadata": dict(self.metadata),
        }
        for key, value in (
            ("declared_universe", self.declared_universe),
            ("universe_key", self.universe_key),
            ("declared_universe_size", self.declared_universe_size),
        ):
            if value is not None:
                record[key] = value
        return record

    def fingerprint(self) -> str:
        """``sha256:<hex>`` over the canonical source (spec 28.3 step 1)."""
        return content_hash(self.to_canonical())


SourceLike = Union[GenerationSource, RealizationBundle, Sequence[RealizationRecord]]


def _coerce_source(source: SourceLike) -> GenerationSource:
    """Read ``source`` as a :class:`GenerationSource` without inventing content."""
    if isinstance(source, GenerationSource):
        return source
    if isinstance(source, RealizationBundle):
        # Bring-your-own-registry (28.5): the imported bundle is the source and
        # its own completeness basis is carried into the metadata rather than
        # adopted, because what this build establishes is decided in step 10.
        return GenerationSource(
            source_id=source.bundle_id,
            source_type="REALIZATION_BUNDLE",
            seeds=tuple(source.realizations),
            metadata={
                "imported_completeness_basis": source.completeness.basis_type,
                "imported_bundle_hash": source.bundle_hash(),
            },
        )
    if isinstance(source, (list, tuple)):
        records = tuple(source)
        for record in records:
            if not isinstance(record, RealizationRecord):
                raise GenerationError(
                    f"a sequence source must contain RealizationRecord, got "
                    f"{type(record).__name__}"
                )
        return GenerationSource(
            source_id="seeds-" + content_hash(
                [r.to_canonical() for r in sorted(records, key=lambda r: r.realization_id)]
            ).split(":", 1)[1][:16],
            source_type="EXPLICIT_RECORDS",
            seeds=records,
        )
    raise GenerationError(
        f"cannot read a generation source from {type(source).__name__}; supply a "
        "GenerationSource, a RealizationBundle, or a sequence of RealizationRecord"
    )


def _validate_contract(name: str, contract: Mapping[str, Any], required: bool) -> List[str]:
    """Steps 2 and 3: a contract must identify and version itself."""
    violations: List[str] = []
    if not contract:
        if required:
            violations.append(
                f"the {name} is absent; specification 28.3 step 2 requires it to be validated "
                "before any generator runs, and an absent contract cannot be validated"
            )
        return violations
    for key in ("contract_id", "version"):
        if not contract.get(key):
            violations.append(
                f"the {name} declares no {key}; without it no dependency edge can pin the "
                "contract a realization was generated under (spec 18.2, 28.6)"
            )
    return violations


# ---------------------------------------------------------------------------
# invocation records (spec 36.3 complete invocation logs)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class UngeneratedRegion:
    """A region of the family no generator entered (spec 28.4).

    This is the record that keeps the software honest.  The legality of an
    unentered region is ``UNGENERATED`` and nothing else: it is not illegal, it
    is not infeasible, it is not unevaluated, and it is certainly not empty.
    Its presence is what removes the right to claim ``GENERATOR_CLOSED``.
    """

    generator: str
    transformations: Tuple[str, ...]
    reason_code: str
    reason: str
    legality: str = LegalityStatus.UNGENERATED

    def __post_init__(self) -> None:
        if self.legality != LegalityStatus.UNGENERATED:
            raise GenerationError(
                "an unentered region is UNGENERATED; representing it as "
                f"{self.legality!r} would report an absence of evidence as evidence "
                "(spec 28.4)"
            )

    def to_canonical(self) -> dict:
        return {
            "generator": self.generator,
            "transformations": list(self.transformations),
            "legality": self.legality,
            "reason_code": self.reason_code,
            "reason": self.reason,
        }

    def to_dict(self) -> dict:
        return self.to_canonical()


@dataclass(frozen=True)
class GeneratorInvocation:
    """One call of one generator on one parent (spec 36.3 invocation logs).

    Every invocation carries the generator's definition hash, so the exact
    declaration under which a record was produced survives export, re-import,
    and a later version bump of the generator (28.6 traceability).
    """

    generator: str
    definition_hash: str
    parent_id: str
    depth: int
    proposed: Tuple[str, ...] = ()
    accepted: Tuple[str, ...] = ()
    refused: Tuple[str, ...] = ()
    outcome: str = "OK"

    def to_canonical(self) -> dict:
        record: dict = {
            "generator": self.generator,
            "definition_hash": self.definition_hash,
            "parent_id": self.parent_id,
            "depth": self.depth,
            "proposed": list(self.proposed),
            "outcome": self.outcome,
        }
        if self.accepted:
            record["accepted"] = list(self.accepted)
        if self.refused:
            record["refused"] = list(self.refused)
        return record


@dataclass(frozen=True)
class GeneratorFailure:
    """A generator invocation or emission that was refused (28.4 failure semantics)."""

    generator: str
    definition_hash: str
    parent_id: str
    reason: str
    failure_semantics: str

    def to_canonical(self) -> dict:
        return {
            "generator": self.generator,
            "definition_hash": self.definition_hash,
            "parent_id": self.parent_id,
            "reason": self.reason,
            "failure_semantics": self.failure_semantics,
        }


@dataclass(frozen=True)
class RejectedCandidate:
    """A generated candidate that legality evaluation did not admit (step 6)."""

    realization_id: str
    legality: str
    reason: str
    generator: Optional[str] = None
    transformation: Optional[str] = None
    parent: Optional[str] = None

    def to_canonical(self) -> dict:
        record: dict = {
            "realization_id": self.realization_id,
            "legality": self.legality,
            "reason": self.reason,
        }
        for key, value in (
            ("generator", self.generator),
            ("transformation", self.transformation),
            ("parent", self.parent),
        ):
            if value:
                record[key] = value
        return record

    def to_dict(self) -> dict:
        return self.to_canonical()


# ---------------------------------------------------------------------------
# closure (spec 28.3 step 4)
# ---------------------------------------------------------------------------


@dataclass
class ClosureReport:
    """What the closure actually did -- the evidence step 10 reasons from."""

    reached_fixpoint: bool
    truncated: bool
    depth_reached: int
    size: int
    generator_set_hash: str
    generator_versions: Tuple[str, ...] = ()
    definition_hashes: Dict[str, str] = field(default_factory=dict)
    closure_procedure: str = ""
    truncation_rule: Optional[str] = None
    declared_max_depth: Optional[int] = None
    declared_max_size: Optional[int] = None
    effective_max_depth: int = DEFAULT_DEPTH_LIMIT
    effective_max_size: int = DEFAULT_SIZE_LIMIT
    unexpanded: Tuple[str, ...] = ()
    invocations: Tuple[GeneratorInvocation, ...] = ()
    failures: Tuple[GeneratorFailure, ...] = ()
    ungenerated: Tuple[UngeneratedRegion, ...] = ()
    warnings: Tuple[str, ...] = ()

    @property
    def generators_ran(self) -> bool:
        return bool(self.invocations)

    def to_canonical(self) -> dict:
        record: dict = {
            "reached_fixpoint": self.reached_fixpoint,
            "truncated": self.truncated,
            "depth_reached": self.depth_reached,
            "size": self.size,
            "generator_set_hash": self.generator_set_hash,
            "generator_versions": list(self.generator_versions),
            "definition_hashes": dict(self.definition_hashes),
            "closure_procedure": self.closure_procedure,
            "effective_max_depth": self.effective_max_depth,
            "effective_max_size": self.effective_max_size,
            "invocations": [i.to_canonical() for i in self.invocations],
            "failures": [f.to_canonical() for f in self.failures],
            "ungenerated": [u.to_canonical() for u in self.ungenerated],
            "warnings": list(self.warnings),
        }
        for key, value in (
            ("truncation_rule", self.truncation_rule),
            ("declared_max_depth", self.declared_max_depth),
            ("declared_max_size", self.declared_max_size),
        ):
            if value is not None:
                record[key] = value
        if self.unexpanded:
            record["unexpanded"] = list(self.unexpanded)
        return record


CLOSURE_PROCEDURE = (
    "breadth-first fixpoint of the declared generator set: the frontier is expanded in "
    "ascending realization-identifier order, generators are applied in ascending "
    "identity@version order, every child identity is derived from (parent, generator, "
    "transformation, exact signature, attributes), and expansion stops when one full "
    "sweep produces no identity that is not already present"
)


def _generator_set_hash(generators: Sequence[Generator]) -> str:
    return content_hash(
        sorted(g.definition.definition_hash() for g in generators)
    )


def _sorted_generators(generators: Sequence[Generator]) -> List[Generator]:
    """Canonical generator order (spec 6.5): identity@version, ascending."""
    seen: Dict[str, str] = {}
    for generator in generators:
        definition = getattr(generator, "definition", None)
        if not isinstance(definition, GeneratorDefinition):
            raise GenerationError(
                f"{type(generator).__name__} does not expose a GeneratorDefinition; it does "
                "not satisfy the generator contract of specification 28.4"
            )
        if definition.qualified_id in seen:
            raise GenerationError(
                f"generator {definition.qualified_id} is registered twice; a duplicated "
                "generator would be applied twice and its closure would not be a fixpoint "
                "of a well-defined set (spec 6.5)"
            )
        seen[definition.qualified_id] = definition.definition_hash()
    return sorted(generators, key=lambda g: g.definition.qualified_id)


def _check_emission(
    child: Any,
    parent: RealizationRecord,
    definition: GeneratorDefinition,
    schema: CoordinateSchema,
) -> Optional[str]:
    """Return a refusal reason for ``child``, or ``None`` when it is admissible.

    Every check here defends an invariant the definition merely *claimed*.  The
    legality check is the one that matters most: a generator physically cannot
    hand back a record labelled ``INFEASIBLE``, so it cannot represent a
    candidate it did not evaluate -- or did not even construct -- as infeasible
    (spec 28.4).
    """
    if not isinstance(child, RealizationRecord):
        return (
            f"proposed {type(child).__name__} rather than a RealizationRecord; a generator "
            "emits realization records only (spec 12.1)"
        )
    if child.legality != LegalityStatus.UNEVALUATED:
        detail = (
            "an INFEASIBLE label asserts that this candidate was constructed and evaluated "
            "and found unrealizable; a generator MUST NOT make that claim about a candidate "
            "it merely proposed, and MUST NOT represent an ungenerated candidate as "
            "infeasible (spec 28.4)"
            if child.legality
            in (LegalityStatus.INFEASIBLE, LegalityStatus.UNGENERATED)
            else "a generator proposes and legality predicates decide; a self-declared "
            "legality would let a generator certify its own output (spec 28.3 step 5)"
        )
        return (
            f"emitted record {child.realization_id!r} with legality {child.legality!r}; "
            f"a proposed record MUST be {LegalityStatus.UNEVALUATED}. {detail}"
        )
    transformation = child.attributes.get(ATTR_TRANSFORMATION)
    if transformation not in definition.transformations:
        return (
            f"emitted record {child.realization_id!r} under transformation "
            f"{transformation!r}, which the generator did not declare; declared "
            f"transformations are {sorted(definition.transformations)} (spec 28.4)"
        )
    if child.generator != definition.qualified_id:
        return (
            f"emitted record {child.realization_id!r} attributed to generator "
            f"{child.generator!r} rather than {definition.qualified_id!r} (spec 28.6 "
            "traceability)"
        )
    if child.parent != parent.realization_id:
        return (
            f"emitted record {child.realization_id!r} with parent {child.parent!r} while "
            f"expanding {parent.realization_id!r}; the parent-child relation must be the "
            "one that was actually taken (spec 28.4)"
        )
    if len(child.signature) != schema.dimension:
        return (
            f"emitted record {child.realization_id!r} with {len(child.signature)} coordinates "
            f"while the declared schema has {schema.dimension}; a signature has no optional "
            "components (spec 19.1)"
        )
    expected = derive_realization_id(
        parent_id=parent.realization_id,
        generator=definition.qualified_id,
        transformation=str(transformation),
        signature=child.signature,
        attributes=child.attributes,
    )
    if child.realization_id != expected:
        return (
            f"emitted record {child.realization_id!r} whose identity is not derived from its "
            f"content (expected {expected!r}); a counter- or clock-derived identity would "
            "make regeneration produce a different canonical bundle (spec 6.5, 14.1). Use "
            "crg_generate.propose_record."
        )
    if child.attributes.get(ATTR_GENERATOR_HASH) != definition.definition_hash():
        return (
            f"emitted record {child.realization_id!r} without the definition hash of the "
            "generator that produced it; provenance must survive the record (spec 36.3)"
        )
    return None


def closure(
    seed_realizations: Sequence[RealizationRecord],
    generators: Sequence[Generator],
    context: GenerationContext,
    *,
    max_depth: Optional[int] = None,
    max_size: Optional[int] = None,
) -> Tuple[List[RealizationRecord], ClosureReport]:
    """Expand ``seed_realizations`` under ``generators`` to a fixpoint.

    Returns the records in deterministic discovery order together with a
    :class:`ClosureReport` recording *what the expansion actually did* -- which
    is the only admissible evidence for the completeness basis (21.3).

    Termination and truncation:

    * expansion stops when a full sweep of the frontier produces no identity
      that is not already present; that is the fixpoint, and only then may
      ``reached_fixpoint`` be true;
    * ``max_depth`` and ``max_size`` are declared truncation rules; hitting one
      sets ``truncated`` and records the rule verbatim, because a truncation
      that is not reported is a silent one (6.11);
    * with no declared limits the engine's own :data:`DEFAULT_DEPTH_LIMIT` and
      :data:`DEFAULT_SIZE_LIMIT` apply and are reported the same way.  An
      engine limit is still a declared rule, and a family that hit one has not
      been closed.

    Deduplication is by content-derived identity.  It is never by signature:
    two paths reaching the same point in signature space are two realizations
    (19.6), and merging them would erase exactly the fiber structure that
    realization-sensitive decisions need.
    """
    ordered = _sorted_generators(generators)
    definitions = {g.definition.qualified_id: g.definition for g in ordered}
    schema = context.schema

    effective_depth = DEFAULT_DEPTH_LIMIT if max_depth is None else max_depth
    effective_size = DEFAULT_SIZE_LIMIT if max_size is None else max_size
    if effective_depth < 0 or effective_size < 0:
        raise GenerationError("closure limits must be nonnegative")

    records: List[RealizationRecord] = []
    by_id: Dict[str, RealizationRecord] = {}
    invocations: List[GeneratorInvocation] = []
    failures: List[GeneratorFailure] = []
    ungenerated: List[UngeneratedRegion] = []
    warnings: List[str] = []

    for seed in sorted(seed_realizations, key=lambda r: r.realization_id):
        stamped = as_seed(seed)
        if stamped.realization_id in by_id:
            raise GenerationError(
                f"duplicate seed identity {stamped.realization_id!r}; identity is unique "
                "within a family (spec 14.1)"
            )
        by_id[stamped.realization_id] = stamped
        records.append(stamped)

    # A generator whose gate is closed, or whose permissions are absent, does
    # not run.  Not running is reported as an unentered region, never as a
    # finding about the candidates it would have produced (28.4).
    runnable: List[Generator] = []
    for generator in ordered:
        definition = generator.definition
        closed = definition.gates_closed_in(context)
        missing = definition.missing_permissions(context)
        if closed:
            ungenerated.append(
                UngeneratedRegion(
                    generator=definition.qualified_id,
                    transformations=tuple(definition.transformations),
                    reason_code=ReasonCode.CAPABILITY_GATE_CLOSED,
                    reason=(
                        "capability gate(s) "
                        + ", ".join(sorted(g.capability for g in closed))
                        + " are not open in this context, so this generator proposed nothing. "
                        "The candidates it would have produced are UNGENERATED: nothing was "
                        "looked at, so nothing is illegal, infeasible, or absent (spec 28.4)"
                    ),
                )
            )
            continue
        if missing:
            ungenerated.append(
                UngeneratedRegion(
                    generator=definition.qualified_id,
                    transformations=tuple(definition.transformations),
                    reason_code=ReasonCode.PERMISSION_ABSENT,
                    reason=(
                        "the generation context does not grant the declared permission(s) "
                        + ", ".join(missing)
                        + "; the generator was not invoked and its region is UNGENERATED "
                        "(spec 36.2, 36.3)"
                    ),
                )
            )
            continue
        if definition.determinism_status == DeterminismStatus.NONDETERMINISTIC:
            warnings.append(
                f"generator {definition.qualified_id} declares NONDETERMINISTIC; its output "
                "cannot support a GENERATOR_CLOSED basis and regeneration is not guaranteed "
                "to reproduce this bundle (spec 6.5, 21.6)"
            )
        for omission in definition.completeness_implications.known_omissions:
            ungenerated.append(
                UngeneratedRegion(
                    generator=definition.qualified_id,
                    transformations=tuple(definition.transformations),
                    reason_code=ReasonCode.DECLARED_BY_GENERATOR,
                    reason=f"declared known omission: {omission}",
                )
            )
        runnable.append(generator)

    frontier: List[RealizationRecord] = sorted(records, key=lambda r: r.realization_id)
    depth = 0
    truncated = False
    truncation_rule: Optional[str] = None
    unexpanded: List[str] = []
    reached_fixpoint = not runnable or not frontier

    while frontier and runnable:
        if depth >= effective_depth:
            truncated = True
            declared = "caller-declared" if max_depth is not None else "engine default"
            truncation_rule = (
                f"MAX_DEPTH={effective_depth} ({declared}): breadth-first expansion was "
                f"stopped at depth {depth} with {len(frontier)} unexpanded parent(s); the "
                "family below that depth was never generated and is UNGENERATED, not empty "
                "(spec 6.11, 21.2 TRUNCATED_BY_DECLARED_RULE)"
            )
            unexpanded = [r.realization_id for r in frontier]
            break

        next_frontier: List[RealizationRecord] = []
        for parent in frontier:
            for generator in runnable:
                definition = generator.definition
                invocation_proposed: List[str] = []
                invocation_accepted: List[str] = []
                invocation_refused: List[str] = []
                outcome = "OK"
                try:
                    children = list(generator.propose(parent, context))
                except Exception as error:  # noqa: BLE001 - failure semantics decide
                    reason = (
                        f"propose() raised {type(error).__name__}: {error}"
                    )
                    failures.append(
                        GeneratorFailure(
                            generator=definition.qualified_id,
                            definition_hash=definition.definition_hash(),
                            parent_id=parent.realization_id,
                            reason=reason,
                            failure_semantics=definition.failure_semantics,
                        )
                    )
                    if definition.failure_semantics == FailureSemantics.FAIL_CLOSED:
                        raise GenerationError(
                            f"generator {definition.qualified_id} failed on parent "
                            f"{parent.realization_id!r} and declares FAIL_CLOSED semantics: "
                            f"{reason} (spec 28.4, 6.6)"
                        ) from error
                    ungenerated.append(
                        UngeneratedRegion(
                            generator=definition.qualified_id,
                            transformations=tuple(definition.transformations),
                            reason_code=ReasonCode.GENERATOR_FAILED,
                            reason=(
                                f"invocation on {parent.realization_id!r} failed ({reason}); "
                                "the children it would have produced are UNGENERATED"
                            ),
                        )
                    )
                    invocations.append(
                        GeneratorInvocation(
                            generator=definition.qualified_id,
                            definition_hash=definition.definition_hash(),
                            parent_id=parent.realization_id,
                            depth=depth,
                            outcome="FAILED",
                        )
                    )
                    continue

                for child in children:
                    refusal = _check_emission(child, parent, definition, schema)
                    identifier = getattr(child, "realization_id", "(unnamed)")
                    invocation_proposed.append(str(identifier))
                    if refusal is not None:
                        outcome = "REFUSED"
                        invocation_refused.append(str(identifier))
                        failures.append(
                            GeneratorFailure(
                                generator=definition.qualified_id,
                                definition_hash=definition.definition_hash(),
                                parent_id=parent.realization_id,
                                reason=refusal,
                                failure_semantics=definition.failure_semantics,
                            )
                        )
                        if definition.failure_semantics == FailureSemantics.FAIL_CLOSED:
                            raise GenerationError(
                                f"generator {definition.qualified_id} violated the generator "
                                f"contract and declares FAIL_CLOSED semantics: {refusal}"
                            )
                        ungenerated.append(
                            UngeneratedRegion(
                                generator=definition.qualified_id,
                                transformations=tuple(definition.transformations),
                                reason_code=ReasonCode.EMISSION_REFUSED,
                                reason=(
                                    f"an emission from {parent.realization_id!r} was refused "
                                    f"({refusal}); that candidate is UNGENERATED"
                                ),
                            )
                        )
                        continue
                    if child.realization_id in by_id:
                        # Same parent, same transformation, same signature: the
                        # same realization, re-derived.  This is the fixpoint
                        # condition, not a signature-level merge.
                        continue
                    if len(by_id) >= effective_size:
                        truncated = True
                        declared = "caller-declared" if max_size is not None else "engine default"
                        truncation_rule = (
                            f"MAX_SIZE={effective_size} ({declared}): expansion was stopped "
                            f"after {len(by_id)} realizations while children of "
                            f"{parent.realization_id!r} were still being produced; the "
                            "remainder was never generated and is UNGENERATED, not empty "
                            "(spec 6.11, 21.2 TRUNCATED_BY_DECLARED_RULE)"
                        )
                        unexpanded = [parent.realization_id] + [
                            r.realization_id for r in next_frontier
                        ]
                        break
                    by_id[child.realization_id] = child
                    records.append(child)
                    next_frontier.append(child)
                    invocation_accepted.append(child.realization_id)

                invocations.append(
                    GeneratorInvocation(
                        generator=definition.qualified_id,
                        definition_hash=definition.definition_hash(),
                        parent_id=parent.realization_id,
                        depth=depth,
                        proposed=tuple(invocation_proposed),
                        accepted=tuple(invocation_accepted),
                        refused=tuple(invocation_refused),
                        outcome=outcome,
                    )
                )
                if truncated:
                    break
            if truncated:
                break

        if truncated:
            break
        depth += 1
        if not next_frontier:
            reached_fixpoint = True
            break
        frontier = sorted(next_frontier, key=lambda r: r.realization_id)

    if truncated:
        reached_fixpoint = False
        ungenerated.append(
            UngeneratedRegion(
                generator=",".join(sorted(definitions)) or "(none)",
                transformations=tuple(
                    sorted({t for d in definitions.values() for t in d.transformations})
                ),
                reason_code=ReasonCode.CLOSURE_TRUNCATED,
                reason=truncation_rule or "closure truncated",
            )
        )

    report = ClosureReport(
        reached_fixpoint=reached_fixpoint,
        truncated=truncated,
        depth_reached=depth,
        size=len(records),
        generator_set_hash=_generator_set_hash(ordered),
        generator_versions=tuple(sorted(definitions)),
        definition_hashes={k: v.definition_hash() for k, v in sorted(definitions.items())},
        closure_procedure=CLOSURE_PROCEDURE,
        truncation_rule=truncation_rule,
        declared_max_depth=max_depth,
        declared_max_size=max_size,
        effective_max_depth=effective_depth,
        effective_max_size=effective_size,
        unexpanded=tuple(unexpanded),
        invocations=tuple(invocations),
        failures=tuple(failures),
        ungenerated=tuple(ungenerated),
        warnings=tuple(warnings),
    )
    return records, report


# ---------------------------------------------------------------------------
# completeness derivation (spec 28.3 step 10, 21.2, 21.3)
# ---------------------------------------------------------------------------

#: Ordered by the strength of the claim the basis licenses (21.4, 21.5).  A
#: caller's hint may move *down* this ladder and never up.
BASIS_STRENGTH: Dict[str, int] = {
    CompletenessBasisType.EXHAUSTIVE_DECLARED_UNIVERSE: 6,
    CompletenessBasisType.GENERATOR_CLOSED: 5,
    CompletenessBasisType.BOUNDED_UNENUMERATED_FAMILY: 4,
    CompletenessBasisType.EXPLICIT_IMPORTED_FAMILY: 3,
    CompletenessBasisType.TRUNCATED_BY_DECLARED_RULE: 2,
    CompletenessBasisType.KNOWN_INCOMPLETE: 1,
    CompletenessBasisType.UNKNOWN: 0,
}


def derive_completeness_basis(
    *,
    source: GenerationSource,
    context: GenerationContext,
    generators: Sequence[Generator],
    closure_report: ClosureReport,
    ungenerated: Sequence[UngeneratedRegion],
    accepted: Sequence[RealizationRecord],
) -> Tuple[CompletenessBasis, Tuple[str, ...]]:
    """Derive the completeness basis from what generation actually did.

    Specification 21.3 lists the fields a basis must carry; specification 21.6
    forbids treating a generator-defined family as exhaustively evaluated
    "merely because a search terminated".  This function is the enforcement of
    that sentence: every basis type below is reached by a fact about the run,
    and the strongest available fact is the one used.

    ``(basis, rationale)`` -- the rationale lines are carried into the
    generation report so a reader can see which fact produced which basis.
    """
    rationale: List[str] = []
    declared_universe = (
        source.declared_universe or context.declared_universe
    )
    generator_versions = tuple(closure_report.generator_versions)
    omissions: List[str] = [
        f"{region.generator}: {region.reason}" for region in ungenerated
    ]

    # (a) nothing generated: the family is exactly what was received (28.5).
    if not closure_report.generators_ran:
        rationale.append(
            "no generator was invoked, so the family is exactly the received seeds; "
            "importing a registry proves what the registry contains and nothing about the "
            "universe of legal realizations (spec 28.5, 21.2)"
        )
        return (
            CompletenessBasis(
                basis_type=CompletenessBasisType.EXPLICIT_IMPORTED_FAMILY,
                declared_universe=declared_universe
                or f"the explicitly received candidates of {source.source_id}",
                source_or_generator_hash=source.fingerprint(),
                generator_versions=generator_versions,
                closure_procedure=(
                    "no generation: the family is the seed set of the received source "
                    "(spec 28.5)"
                ),
                known_omissions=tuple(
                    omissions
                    + [
                        "candidates absent from the received source are not represented and "
                        "are not claimed"
                    ]
                ),
                validity=context.validity,
                dependencies=tuple(generator_versions) + (context.fingerprint(),),
            ),
            tuple(rationale),
        )

    # (b) a declared rule stopped the expansion (6.11, 21.2).
    if closure_report.truncated:
        rationale.append(
            "the closure did not reach a fixpoint: a declared limit stopped it, so the "
            "unexpanded remainder was never generated (spec 6.11, 21.2)"
        )
        return (
            CompletenessBasis(
                basis_type=CompletenessBasisType.TRUNCATED_BY_DECLARED_RULE,
                declared_universe=declared_universe,
                source_or_generator_hash=closure_report.generator_set_hash,
                generator_versions=generator_versions,
                closure_procedure=closure_report.closure_procedure,
                truncation_rule=closure_report.truncation_rule,
                known_omissions=tuple(
                    omissions
                    + [
                        "the unexpanded frontier ("
                        + ", ".join(closure_report.unexpanded[:8])
                        + (", ..." if len(closure_report.unexpanded) > 8 else "")
                        + ") and everything below it is UNGENERATED"
                    ]
                    if closure_report.unexpanded
                    else omissions
                ),
                validity=context.validity,
                dependencies=tuple(generator_versions) + (context.fingerprint(),),
            ),
            tuple(rationale),
        )

    # (c) the closure reached a fixpoint.  What may be claimed about it?
    blockers: List[str] = []
    for generator in generators:
        definition = generator.definition
        if definition.determinism_status not in DeterminismStatus.MAY_CLOSE_A_FAMILY:
            blockers.append(
                f"generator {definition.qualified_id} declares "
                f"{definition.determinism_status}; a family produced by a search that may "
                "return something else on the next run is not closed (spec 6.5, 21.6)"
            )
        if not definition.completeness_implications.closes_family:
            blockers.append(
                f"generator {definition.qualified_id} declares that it does not close the "
                f"family: {definition.completeness_implications.rationale}"
            )
    for region in ungenerated:
        blockers.append(f"{region.generator}: {region.reason}")

    # (c1) a finite declared universe that was exhausted (21.2).
    if source.declared_universe_size is not None and not blockers:
        if source.universe_key:
            members = {
                str(r.attributes.get(source.universe_key))
                for r in accepted
                if source.universe_key in r.attributes
            }
        else:
            members = {r.realization_id for r in accepted}
        enumerated = len(members)
        if enumerated == source.declared_universe_size:
            rationale.append(
                f"the closure reached a fixpoint and enumerated {enumerated} distinct member(s) "
                f"of the declared finite universe, exactly matching its declared size "
                f"{source.declared_universe_size} (spec 21.2 EXHAUSTIVE_DECLARED_UNIVERSE)"
            )
            return (
                CompletenessBasis(
                    basis_type=CompletenessBasisType.EXHAUSTIVE_DECLARED_UNIVERSE,
                    declared_universe=declared_universe
                    or f"the {source.declared_universe_size} members of the declared universe",
                    source_or_generator_hash=closure_report.generator_set_hash,
                    generator_versions=generator_versions,
                    closure_procedure=closure_report.closure_procedure,
                    closure_proof=(
                        f"enumeration count: the generator closure reached a fixpoint and "
                        f"produced {enumerated} distinct value(s) of the declared universe key "
                        f"{source.universe_key!r}, equal to the declared universe size "
                        f"{source.declared_universe_size}; every member is represented by at "
                        "least one realization record"
                    ),
                    known_omissions=(),
                    validity=context.validity,
                    dependencies=tuple(generator_versions) + (context.fingerprint(),),
                ),
                tuple(rationale),
            )
        rationale.append(
            f"the source declares a universe of {source.declared_universe_size} member(s) but "
            f"the closure enumerated {enumerated}; the declared universe was NOT exhausted, so "
            "EXHAUSTIVE_DECLARED_UNIVERSE is refused (spec 21.6)"
        )
        blockers.append(
            f"the declared universe of {source.declared_universe_size} member(s) is only "
            f"{enumerated}-enumerated"
        )

    # (c2) a real fixpoint under closing, reproducible generators (21.2).
    if not blockers:
        rationale.append(
            "the closure reached a fixpoint with no declared limit hit, every generator is "
            "reproducible and declares that it closes the family, and no region was left "
            "unentered (spec 21.2 GENERATOR_CLOSED)"
        )
        return (
            CompletenessBasis(
                basis_type=CompletenessBasisType.GENERATOR_CLOSED,
                declared_universe=declared_universe,
                source_or_generator_hash=closure_report.generator_set_hash,
                generator_versions=generator_versions,
                closure_procedure=closure_report.closure_procedure,
                closure_proof=(
                    "fixpoint: one full sweep of the frontier under every declared generator "
                    f"produced no realization identity that was not already present, at depth "
                    f"{closure_report.depth_reached} over {closure_report.size} realization(s), "
                    f"under generator set {closure_report.generator_set_hash}"
                ),
                known_omissions=(),
                validity=context.validity,
                dependencies=tuple(generator_versions) + (context.fingerprint(),),
            ),
            tuple(rationale),
        )

    # (c3) a fixpoint was reached but something is knowingly missing (21.2).
    rationale.append(
        "the closure reached a fixpoint, but at least one region was never entered or one "
        "generator declines to close the family, so the represented family is knowingly "
        "incomplete (spec 21.2 KNOWN_INCOMPLETE)"
    )
    return (
        CompletenessBasis(
            basis_type=CompletenessBasisType.KNOWN_INCOMPLETE,
            declared_universe=declared_universe,
            source_or_generator_hash=closure_report.generator_set_hash,
            generator_versions=generator_versions,
            closure_procedure=closure_report.closure_procedure,
            known_omissions=tuple(blockers),
            validity=context.validity,
            dependencies=tuple(generator_versions) + (context.fingerprint(),),
        ),
        tuple(rationale),
    )


def _apply_hint(
    derived: CompletenessBasis, hint: Optional[CompletenessBasis]
) -> Tuple[CompletenessBasis, List[str]]:
    """A caller may weaken the derived basis; a caller may never strengthen it."""
    if hint is None:
        return derived, []
    derived_strength = BASIS_STRENGTH[derived.basis_type]
    hint_strength = BASIS_STRENGTH[hint.basis_type]
    if hint_strength <= derived_strength:
        merged = replace(
            hint,
            source_or_generator_hash=hint.source_or_generator_hash
            or derived.source_or_generator_hash,
            generator_versions=hint.generator_versions or derived.generator_versions,
            closure_procedure=hint.closure_procedure or derived.closure_procedure,
            known_omissions=tuple(hint.known_omissions) + tuple(derived.known_omissions),
            dependencies=tuple(hint.dependencies) or tuple(derived.dependencies),
        )
        if hint_strength < derived_strength:
            return merged, [
                f"the caller weakened the derived completeness basis from "
                f"{derived.basis_type} to {hint.basis_type}; a weaker claim than the evidence "
                "supports is always admissible (spec 21.3)"
            ]
        return merged, []
    if (
        hint.basis_type == CompletenessBasisType.BOUNDED_UNENUMERATED_FAMILY
        and hint.remainder_bound
        and hint.closure_proof
    ):
        # Spec 21.6(1): an external bound provider may cover the unenumerated
        # region.  That evidence is the caller's, not this engine's, and it is
        # recorded as such.
        return replace(
            hint,
            generator_versions=hint.generator_versions or derived.generator_versions,
            known_omissions=tuple(hint.known_omissions) + tuple(derived.known_omissions),
        ), [
            f"the caller supplied a BOUNDED_UNENUMERATED_FAMILY basis over this engine's "
            f"derived {derived.basis_type}, carrying a remainder bound and a proof that the "
            "unenumerated region cannot change the declared decision; the evidence for that "
            "claim is the caller's, not this generator run's (spec 21.6)"
        ]
    raise GenerationError(
        f"refusing the completeness hint {hint.basis_type}: this generation run establishes "
        f"{derived.basis_type}, and a completeness basis is derived from what generation did, "
        "not declared by its caller. "
        + (derived.truncation_rule or derived.closure_proof or derived.closure_procedure or "")
        + " Supply a weaker basis, or a BOUNDED_UNENUMERATED_FAMILY basis carrying both a "
        "remainder bound and a closure proof (spec 21.3, 21.6)."
    )


# ---------------------------------------------------------------------------
# the report (spec 28.6 traceability, 36.3 invocation logs)
# ---------------------------------------------------------------------------


@dataclass
class GenerationReport:
    """Everything a reader needs to audit a generated registry."""

    source_id: str
    source_type: str
    source_fingerprint: str
    context_fingerprint: str
    engine_id: str = ENGINE_ID
    engine_version: str = ENGINE_VERSION
    generators: Tuple[str, ...] = ()
    generator_definition_hashes: Dict[str, str] = field(default_factory=dict)
    contract_violations: Tuple[str, ...] = ()
    accepted: Tuple[str, ...] = ()
    rejected: Tuple[RejectedCandidate, ...] = ()
    legality_tally: Dict[str, int] = field(default_factory=dict)
    ungenerated: Tuple[UngeneratedRegion, ...] = ()
    obligations: Tuple[Obligation, ...] = ()
    fibers: Dict[str, Tuple[str, ...]] = field(default_factory=dict)
    dependency_edges: Tuple[DependencyEdge, ...] = ()
    closure_report: Optional[ClosureReport] = None
    completeness_basis: Optional[CompletenessBasis] = None
    completeness_rationale: Tuple[str, ...] = ()
    claim_scope: str = ClaimScope.PARTIAL_FAMILY
    warnings: Tuple[str, ...] = ()
    bundle_id: str = ""
    canonical_output_hash: Optional[str] = None

    @property
    def accepted_count(self) -> int:
        return len(self.accepted)

    @property
    def rejected_count(self) -> int:
        return len(self.rejected)

    @property
    def has_ungenerated_regions(self) -> bool:
        return bool(self.ungenerated)

    def invocations(self) -> Tuple[GeneratorInvocation, ...]:
        return self.closure_report.invocations if self.closure_report else ()

    def legality_of(self, status: str) -> int:
        return self.legality_tally.get(status, 0)

    def to_canonical(self) -> dict:
        record: dict = {
            "source": {
                "source_id": self.source_id,
                "source_type": self.source_type,
                "fingerprint": self.source_fingerprint,
            },
            "context_fingerprint": self.context_fingerprint,
            "engine": {"id": self.engine_id, "version": self.engine_version},
            "generators": list(self.generators),
            "generator_definition_hashes": dict(self.generator_definition_hashes),
            "contract_violations": list(self.contract_violations),
            "accepted": list(self.accepted),
            "rejected": [r.to_canonical() for r in self.rejected],
            "legality_tally": dict(self.legality_tally),
            "ungenerated": [u.to_canonical() for u in self.ungenerated],
            "obligations": [o.to_canonical() for o in self.obligations],
            "fibers": {k: list(v) for k, v in self.fibers.items()},
            "dependency_edges": [e.to_canonical() for e in self.dependency_edges],
            "completeness_rationale": list(self.completeness_rationale),
            "claim_scope": self.claim_scope,
            "warnings": list(self.warnings),
        }
        if self.closure_report is not None:
            record["closure"] = self.closure_report.to_canonical()
        if self.completeness_basis is not None:
            record["completeness_basis"] = self.completeness_basis.to_canonical()
        if self.bundle_id:
            record["bundle_id"] = self.bundle_id
        if self.canonical_output_hash:
            record["canonical_output_hash"] = self.canonical_output_hash
        return record

    # -- rendering ------------------------------------------------------
    def render(self, width: int = 88) -> str:
        """Deterministic plain-ASCII generation report.

        Ordered so the epistemics come first: what was claimed about the family
        and why, then what was never looked at, then the records themselves.  A
        reader who stops after two sections has still seen the limits.
        """
        lines: List[str] = ["=" * width, "CRG REALIZATION GENERATION REPORT (spec 28.3)", "=" * width]
        lines += _kv("source", f"{self.source_id} [{self.source_type}]", width)
        lines += _kv("source fingerprint", self.source_fingerprint, width)
        lines += _kv("context fingerprint", self.context_fingerprint, width)
        lines += _kv("engine", self.engine_version, width)
        lines += _kv("bundle id", self.bundle_id or "(unset)", width)
        lines += _kv("canonical output hash", self.canonical_output_hash or "(unset)", width)
        lines.append("")

        lines.append(_head(1, "COMPLETENESS BASIS (DERIVED, NOT DECLARED)", width))
        basis = self.completeness_basis
        if basis is not None:
            lines += _kv("basis type", basis.basis_type, width)
            lines += _kv("declared universe", basis.declared_universe, width)
            lines += _kv("generator set hash", basis.source_or_generator_hash, width)
            lines += _kv("closure procedure", basis.closure_procedure, width)
            lines += _kv("closure proof", basis.closure_proof, width)
            lines += _kv("truncation rule", basis.truncation_rule, width)
        lines += _kv("derived claim scope", self.claim_scope, width)
        for line in self.completeness_rationale:
            lines += _wrap(f"- {line}", width, 2)
        lines.append("")

        lines.append(_head(2, "UNGENERATED REGIONS (looked at nothing, claim nothing)", width))
        if self.ungenerated:
            for region in self.ungenerated:
                lines += _wrap(
                    f"- [{region.legality}] {region.generator} ({region.reason_code}): "
                    f"{region.reason}",
                    width,
                    2,
                )
        else:
            lines.append("  (none: every declared generator was invoked)")
        lines.append("")

        lines.append(_head(3, "LEGALITY DISPOSITION (five states, never merged)", width))
        for status in sorted(LegalityStatus.ALL):
            lines += _kv(status, str(self.legality_tally.get(status, 0)), width)
        for rejected in self.rejected:
            lines += _wrap(
                f"- {rejected.realization_id} [{rejected.legality}]: {rejected.reason}", width, 2
            )
        lines.append("")

        lines.append(_head(4, "GENERATORS AND INVOCATIONS", width))
        for generator in self.generators:
            lines += _kv(generator, self.generator_definition_hashes.get(generator, ""), width)
        lines += _kv("invocations", str(len(self.invocations())), width)
        closure_report = self.closure_report
        if closure_report is not None:
            lines += _kv("reached fixpoint", _yesno(closure_report.reached_fixpoint), width)
            lines += _kv("truncated", _yesno(closure_report.truncated), width)
            lines += _kv("depth reached", str(closure_report.depth_reached), width)
            for failure in closure_report.failures:
                lines += _wrap(f"! {failure.generator}: {failure.reason}", width, 2)
        lines.append("")

        lines.append(_head(5, "FIBERS (equal signatures do not erase identity)", width))
        multi = {k: v for k, v in self.fibers.items() if len(v) > 1}
        lines += _kv("distinct signatures", str(len(self.fibers)), width)
        lines += _kv("non-trivial fibers", str(len(multi)), width)
        for key in sorted(multi):
            lines += _wrap(f"- {key}: {', '.join(multi[key])}", width, 2)
        lines.append("")

        lines.append(_head(6, "TYPED OBLIGATIONS", width))
        if self.obligations:
            for obligation in self.obligations:
                lines += _wrap(
                    f"- [{obligation.obligation_type}] {obligation.realization_id}: "
                    f"{obligation.name}"
                    + (f" = {obligation.value} {obligation.unit or ''}".rstrip()
                       if obligation.value is not None else ""),
                    width,
                    2,
                )
        else:
            lines.append("  (none extracted)")
        lines.append("")

        lines.append(_head(7, "CONTRACT VIOLATIONS AND WARNINGS", width))
        for violation in self.contract_violations:
            lines += _wrap(f"x {violation}", width, 2)
        for warning in self.warnings:
            lines += _wrap(f"! {warning}", width, 2)
        if not self.contract_violations and not self.warnings:
            lines.append("  (none)")
        lines.append("=" * width)
        return "\n".join(lines) + "\n"

    def __str__(self) -> str:  # pragma: no cover - display only
        return self.render()


def _head(number: int, title: str, width: int) -> str:
    head = f"{number}. {title} "
    return head + "-" * max(4, width - len(head))


def _wrap(text: str, width: int, indent: int = 0) -> List[str]:
    body = " ".join(str(text).split())
    if not body:
        return [""]
    return textwrap.wrap(
        body,
        width=max(24, width),
        initial_indent=" " * indent,
        subsequent_indent=" " * (indent + 2),
        break_long_words=False,
        break_on_hyphens=False,
    ) or [""]


def _kv(label: str, value: Any, width: int, indent: int = 2) -> List[str]:
    text = "(none)" if value is None or value == "" else str(value)
    head = f"{' ' * indent}{label:<26}: "
    chunks = textwrap.wrap(
        " ".join(text.split()),
        width=max(24, width - len(head)),
        break_long_words=False,
        break_on_hyphens=False,
    ) or [""]
    return [head + chunks[0]] + [" " * len(head) + chunk for chunk in chunks[1:]]


def _yesno(value: Any) -> str:
    return "yes" if value else "no"


# ---------------------------------------------------------------------------
# build_registry: the workflow of 28.3
# ---------------------------------------------------------------------------


def build_registry(
    source: SourceLike,
    *,
    generators: Sequence[Generator] = (),
    schema: CoordinateSchema,
    context: GenerationContext,
    completeness_hint: Optional[CompletenessBasis] = None,
    predicates: Sequence[LegalityPredicate] = (),
    max_depth: Optional[int] = None,
    max_size: Optional[int] = None,
    require_contracts: bool = False,
) -> Tuple[RealizationBundle, GenerationReport]:
    """Execute the required workflow of specification 28.3.

    The thirteen steps are executed and marked in order:

    1. receive and fingerprint the source;
    2. validate the computation contract;
    3. validate the resource and hierarchy contracts;
    4. invoke registered generators or import user-supplied realizations;
    5. evaluate legality predicates;
    6. record accepted and rejected candidates;
    7. canonicalize realization identity;
    8. extract typed obligations;
    9. preserve realization fibers;
    10. determine the completeness basis;
    11. attach witnesses, bounds, dependencies, and validity;
    12. freeze canonical hashes;
    13. emit a ``RealizationBundle``.

    ``generators=()`` is the bring-your-own-registry mode of 28.5: the seeds
    are evaluated and emitted with an ``EXPLICIT_IMPORTED_FAMILY`` basis, and
    no generator is required before the user gets a certificate.

    ``completeness_hint`` may weaken the derived basis and may not strengthen
    it; see :func:`derive_completeness_basis` and :func:`_apply_hint`.

    ``predicates`` are registry-wide legality predicates evaluated in addition
    to those each generator declares.  A record's predicates are the union of
    the registry-wide set and the declaring generator's set, so a candidate is
    judged by every rule that claims to apply to it (28.3 step 5).
    """
    # -- step 1: receive and fingerprint the source
    generation_source = _coerce_source(source)
    source_fingerprint = generation_source.fingerprint()

    if context.schema != schema:
        raise GenerationError(
            "the coordinate schema passed to build_registry differs from the one the "
            "generation context declares; a realization generated against one schema and "
            "recorded against another has an unattributable signature (spec 19.1)"
        )

    warnings: List[str] = []

    # -- steps 2 and 3: validate the contracts
    violations: List[str] = []
    violations += _validate_contract(
        "computation contract", generation_source.computation_contract, require_contracts
    )
    violations += _validate_contract(
        "resource contract", generation_source.resource_contract, require_contracts
    )
    violations += _validate_contract(
        "hierarchy contract", generation_source.hierarchy_contract, False
    )
    if violations and require_contracts:
        raise GenerationError(
            "contract validation failed and this build requires valid contracts "
            "(spec 28.3 steps 2-3, 6.6): " + "; ".join(violations)
        )
    warnings.extend(violations)

    # -- step 4: invoke registered generators, or import the supplied family
    ordered = _sorted_generators(generators)
    eligible: List[Generator] = []
    ungenerated: List[UngeneratedRegion] = []
    for generator in ordered:
        definition = generator.definition
        if generation_source.source_type not in definition.accepted_source_types:
            ungenerated.append(
                UngeneratedRegion(
                    generator=definition.qualified_id,
                    transformations=tuple(definition.transformations),
                    reason_code=ReasonCode.SOURCE_TYPE_NOT_ACCEPTED,
                    reason=(
                        f"the source type {generation_source.source_type!r} is not among the "
                        f"generator's accepted source types "
                        f"{sorted(definition.accepted_source_types)}; it was not invoked and "
                        "the region it covers is UNGENERATED (spec 28.4)"
                    ),
                )
            )
            continue
        eligible.append(generator)

    records, closure_report = closure(
        generation_source.seeds,
        eligible,
        context,
        max_depth=max_depth,
        max_size=max_size,
    )
    ungenerated.extend(closure_report.ungenerated)
    warnings.extend(closure_report.warnings)

    # -- step 5: evaluate legality predicates
    definitions = {g.definition.qualified_id: g.definition for g in eligible}
    legality_context = context.as_mapping()

    def _predicates_for(record: RealizationRecord) -> List[LegalityPredicate]:
        """Every legality predicate in force for ``record`` (28.3 step 5).

        A generated record is judged by the registry-wide predicates plus those
        its own generator declared.  A *seed* has no generator of its own, so
        it is judged by the registry-wide predicates plus those of every
        eligible generator: a seed is a member of the same family its children
        are, and exempting it would let an inadmissible starting point enter
        the geometry unexamined.  A record no predicate speaks to stays
        ``UNEVALUATED``, which is not ``LEGAL`` and never reaches ``R``.
        """
        applicable: List[LegalityPredicate] = list(predicates)
        seen_ids = {p.qualified_id for p in applicable}
        owning = definitions.get(record.generator or "")
        sources = [owning] if owning is not None else list(definitions.values())
        for definition in sources:
            for predicate in definition.legality_predicates:
                if predicate.qualified_id not in seen_ids:
                    applicable.append(predicate)
                    seen_ids.add(predicate.qualified_id)
        return applicable

    evaluated: List[Tuple[RealizationRecord, LegalityResult]] = []
    for record in records:
        result = evaluate_legality(record, _predicates_for(record), legality_context)
        evaluated.append((record, result))

    # -- steps 6 and 7: record accepted and rejected, canonicalize identity
    # Accepted *and* rejected candidates stay in the registry: 28.3 step 6
    # requires recording both, and a rejected candidate that vanished could
    # neither be audited nor re-evaluated after a legality rule changed.  Only
    # LEGAL members enter R (19.2), which ``crg_geometry.build_R`` enforces by
    # reading the legality field rather than by membership.
    registry_records: List[RealizationRecord] = []
    rejected: List[RejectedCandidate] = []
    tally: Dict[str, int] = {status: 0 for status in sorted(LegalityStatus.ALL)}
    tally[LegalityStatus.UNGENERATED] = len(ungenerated)
    for record, result in evaluated:
        tally[result.status] = tally.get(result.status, 0) + 1
        decided = replace(record, legality=result.status)
        registry_records.append(decided)
        if not result.admits_to_geometry:
            rejected.append(
                RejectedCandidate(
                    realization_id=decided.realization_id,
                    legality=result.status,
                    reason=result.reason,
                    generator=decided.generator,
                    transformation=str(decided.attributes.get(ATTR_TRANSFORMATION, "")),
                    parent=decided.parent,
                )
            )

    registry_records.sort(key=lambda r: r.realization_id)
    identities = [r.realization_id for r in registry_records]
    if len(set(identities)) != len(identities):
        raise GenerationError(
            "canonicalization produced duplicate realization identities; identity is unique "
            "within a family (spec 14.1, 28.3 step 7)"
        )

    # -- step 8: extract typed obligations
    obligations: List[Obligation] = []
    for record in registry_records:
        definition = definitions.get(record.generator or "")
        if definition is None or definition.obligation_extractor is None:
            continue
        try:
            extracted = list(definition.obligation_extractor(record, context))
        except Exception as error:  # noqa: BLE001 - extraction failure is recorded
            warnings.append(
                f"obligation extraction for {record.realization_id} raised "
                f"{type(error).__name__}: {error}; the obligations of that record are missing "
                "rather than assumed empty (spec 37.3)"
            )
            continue
        for obligation in extracted:
            if obligation.obligation_type not in definition.obligation_types:
                warnings.append(
                    f"generator {definition.qualified_id} extracted an obligation of "
                    f"undeclared type {obligation.obligation_type}; it is recorded but the "
                    "declaration is incomplete (spec 28.4)"
                )
            obligations.append(obligation)
    obligations.sort(key=lambda o: (o.realization_id, o.obligation_type, o.name))

    # -- step 9: preserve realization fibers
    fibers: Dict[str, List[str]] = {}
    for record in registry_records:
        if record.legality != LegalityStatus.LEGAL:
            continue
        key = content_hash(record.signature.to_canonical())
        fibers.setdefault(key, []).append(record.realization_id)
    fiber_index = {k: tuple(sorted(v)) for k, v in sorted(fibers.items())}
    for key, members in fiber_index.items():
        if len(members) > 1:
            warnings.append(
                f"{len(members)} realizations share one signature and are retained as one "
                f"fiber ({', '.join(members)}); equal signatures do not erase realization "
                "identity (spec 19.6, 28.6)"
            )

    # -- step 10: determine the completeness basis
    legal_records = [r for r in registry_records if r.legality == LegalityStatus.LEGAL]
    derived, rationale = derive_completeness_basis(
        source=generation_source,
        context=context,
        generators=eligible,
        closure_report=closure_report,
        ungenerated=tuple(ungenerated),
        accepted=legal_records,
    )
    basis, hint_notes = _apply_hint(derived, completeness_hint)
    warnings.extend(hint_notes)

    # -- step 11: attach witnesses, bounds, dependencies, and validity
    bundle_id = "reg-" + content_hash(
        {
            "source": source_fingerprint,
            "context": context.fingerprint(),
            "generators": sorted(definitions),
            "generator_set": closure_report.generator_set_hash,
            "engine": ENGINE_VERSION,
        }
    ).split(":", 1)[1][:24]

    graph = DependencyGraph()
    edges: List[DependencyEdge] = []

    def _add(source_node: str, target_node: str, edge_type: str, prop: Optional[str] = None) -> None:
        edge = DependencyEdge(
            edge_id="edge-"
            + content_hash(
                {"s": source_node, "t": target_node, "type": edge_type, "p": prop}
            ).split(":", 1)[1][:16],
            source=source_node,
            target=target_node,
            edge_type=edge_type,
            source_property=prop,
        )
        graph.add_edge(edge)
        edges.append(edge)

    for qualified_id in sorted(definitions):
        _add(qualified_id, bundle_id, EdgeType.DEPENDS_ON_GENERATOR_VERSION, "definition_hash")
    _add(context.fingerprint(), bundle_id, EdgeType.DEPENDS_ON_CONTEXT_FINGERPRINT)
    _add(source_fingerprint, bundle_id, EdgeType.DERIVED_FROM_VERSION)
    for record in registry_records:
        if record.parent:
            _add(record.parent, record.realization_id, EdgeType.DERIVES_VALUE_FROM)
    edges.sort(key=lambda e: e.edge_id)

    for record in registry_records:
        if record.witness is None and record.generator is not None:
            warnings.append(
                f"generated record {record.realization_id} carries no witness; its generator "
                "declared a witness method but produced none (spec 28.4)"
            )
        definition = definitions.get(record.generator or "")
        if definition is not None and definition.witness_method == WitnessMethod.DECLARED_ONLY:
            warnings.append(
                f"record {record.realization_id} is witnessed by declaration only; a declared "
                "witness is evidence class DECLARED and cannot support a constructive claim "
                "(spec 5.3, 28.4)"
            )

    # -- step 12: freeze canonical hashes; step 13: emit the bundle
    bundle = RealizationBundle(
        bundle_id=bundle_id,
        schema=schema,
        realizations=registry_records,
        completeness=basis,
        rejected=[r.to_dict() for r in rejected] + [u.to_dict() for u in ungenerated],
        source_fingerprint=source_fingerprint,
    )

    report = GenerationReport(
        source_id=generation_source.source_id,
        source_type=generation_source.source_type,
        source_fingerprint=source_fingerprint,
        context_fingerprint=context.fingerprint(),
        generators=tuple(sorted(definitions)),
        generator_definition_hashes={
            k: v.definition_hash() for k, v in sorted(definitions.items())
        },
        contract_violations=tuple(violations),
        accepted=tuple(r.realization_id for r in legal_records),
        rejected=tuple(rejected),
        legality_tally=tally,
        ungenerated=tuple(ungenerated),
        obligations=tuple(obligations),
        fibers=fiber_index,
        dependency_edges=tuple(edges),
        closure_report=closure_report,
        completeness_basis=basis,
        completeness_rationale=tuple(rationale),
        claim_scope=derive_claim_scope(basis),
        warnings=tuple(warnings),
        bundle_id=bundle_id,
        canonical_output_hash=bundle.bundle_hash(),
    )
    return bundle, report
