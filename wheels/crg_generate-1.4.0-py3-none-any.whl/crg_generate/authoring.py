"""Deterministic, fail-closed authoring reports for portable pack manifests.

This module is deliberately narrower than :func:`crg_generate.load_pack`.
``load_pack`` also accepts live Python extension objects supplied by a trusted
host; a JSON authoring artefact cannot contain such objects.  The authoring
path therefore validates declaration-only JSON, records every refusal in a
portable report, and never imports or executes pack code.

The report is evidence about manifest shape and the semantic checks implemented
by :func:`crg_generate.validate_pack`.  It is not a signature, a conformance
test result, or permission to execute a plugin.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple, Union

from crg_model.canonical import CanonicalizationError, content_hash
from crg_model import SPEC_VERSION as CORE_SPEC_VERSION

from .packs import (
    MANIFEST_REQUIRED_FIELDS,
    PROOF_CHECKER_REQUIRED_FIELDS,
    PackError,
    Permission,
    load_pack,
    validate_pack,
)

__all__ = [
    "PACK_AUTHORING_REPORT_VERSION",
    "PACK_AUTHORING_PROFILE",
    "AuthoringDisposition",
    "DiagnosticStatus",
    "PackAuthoringDiagnostic",
    "PackAuthoringReport",
    "validate_pack_manifest_json",
    "validate_pack_manifest_file",
]


PACK_AUTHORING_REPORT_VERSION = "1.0.0"
PACK_AUTHORING_PROFILE = "CRG_DOMAIN_PACK_JSON_AUTHORING_STRICT_V1"


class AuthoringDisposition:
    ACCEPTED = "ACCEPTED"
    REFUSED = "REFUSED"


class DiagnosticStatus:
    ACCEPTED = "ACCEPTED"
    REFUSED = "REFUSED"


@dataclass(frozen=True)
class PackAuthoringDiagnostic:
    """One portable authoring check outcome.

    ``path`` uses JSONPath-like notation only for presentation; callers must
    use ``code`` as the stable machine identifier.
    """

    code: str
    category: str
    status: str
    path: str
    message: str

    def to_canonical(self) -> dict:
        return {
            "code": self.code,
            "category": self.category,
            "status": self.status,
            "path": self.path,
            "message": self.message,
        }


@dataclass(frozen=True)
class PackAuthoringReport:
    """Versioned result of validating one exact JSON source byte sequence."""

    source_hash: str
    source_size_bytes: int
    spec_version: str
    disposition: str
    diagnostics: Tuple[PackAuthoringDiagnostic, ...]
    schema_violations: Tuple[str, ...] = ()
    semantic_violations: Tuple[str, ...] = ()
    manifest_identity: str = ""
    manifest_version: str = ""
    manifest_hash: str = ""
    pack_hash: str = ""
    declared_permissions: Tuple[str, ...] = ()
    in_process_permissions: Tuple[str, ...] = ()
    isolation_required_permissions: Tuple[str, ...] = ()
    unknown_permissions: Tuple[str, ...] = ()
    determinism_status: str = ""
    proof_checker_declarations: Tuple[Mapping[str, Any], ...] = ()
    report_version: str = PACK_AUTHORING_REPORT_VERSION
    validation_profile: str = PACK_AUTHORING_PROFILE
    authority: str = "AUTHORING_VALIDATION_ONLY"

    @property
    def accepted(self) -> bool:
        return self.disposition == AuthoringDisposition.ACCEPTED

    def to_canonical(self) -> dict:
        return {
            "record_type": "CRGPackAuthoringReport",
            "report_version": self.report_version,
            "validation_profile": self.validation_profile,
            "spec_version": self.spec_version,
            "authority": self.authority,
            "claim_boundary": (
                "validates declaration-only JSON shape and pack semantics; does not execute "
                "extensions, replay conformance tests, verify package signatures, or grant "
                "permissions"
            ),
            "source_hash": self.source_hash,
            "source_size_bytes": self.source_size_bytes,
            "disposition": self.disposition,
            "manifest_identity": self.manifest_identity,
            "manifest_version": self.manifest_version,
            "manifest_hash": self.manifest_hash,
            "pack_hash": self.pack_hash,
            "schema_violations": list(self.schema_violations),
            "semantic_violations": list(self.semantic_violations),
            "declarations": {
                "permissions": list(self.declared_permissions),
                "in_process_permissions": list(self.in_process_permissions),
                "isolation_required_permissions": list(
                    self.isolation_required_permissions
                ),
                "unknown_permissions": list(self.unknown_permissions),
                "determinism_status": self.determinism_status,
                "proof_checkers": [
                    dict(checker) for checker in self.proof_checker_declarations
                ],
            },
            "diagnostics": [item.to_canonical() for item in self.diagnostics],
        }

    def report_hash(self) -> str:
        return content_hash(self.to_canonical())

    def require_accepted(self) -> "PackAuthoringReport":
        if not self.accepted:
            messages = list(self.schema_violations) + list(self.semantic_violations)
            raise PackError(
                "portable pack manifest was refused:\n  - "
                + "\n  - ".join(messages or ["see authoring diagnostics"])
            )
        return self


class _DuplicateKey(ValueError):
    pass


class _InexactJsonNumber(ValueError):
    pass


_STRING_FIELDS = frozenset(
    {
        "identity",
        "version",
        "publisher",
        "determinism_status",
        "license",
        "security_classification",
    }
)
_LIST_STRING_FIELDS = frozenset(MANIFEST_REQUIRED_FIELDS) - _STRING_FIELDS - {
    "resource_requirements",
    "provenance",
}
_MAPPING_FIELDS = frozenset({"resource_requirements", "provenance"})
_CONTENT_MAPPING_FIELDS = frozenset(
    {"terminology", "quantities", "contracts", "accounting_rules"}
)
_CONTENT_LIST_FIELDS = frozenset(
    {
        "transformations",
        "obligation_coordinates",
        "technology_coordinates",
        "evaluators",
        "qualification_methods",
        "ui_extensions",
        "example_cases",
        "conformance_fixtures",
    }
)
_CONTENT_FIELDS = _CONTENT_MAPPING_FIELDS | _CONTENT_LIST_FIELDS | {"proof_checkers"}


def _strict_object(pairs: Sequence[Tuple[str, Any]]) -> Dict[str, Any]:
    result: Dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise _DuplicateKey(f"duplicate JSON object member {key!r}")
        result[key] = value
    return result


def _reject_float(token: str) -> float:
    raise _InexactJsonNumber(
        f"JSON number {token!r} is not an exact portable CRG value; use an integer "
        "or an exact decimal/rational string"
    )


def _reject_constant(token: str) -> None:
    raise _InexactJsonNumber(f"non-finite JSON constant {token!r} is not admissible")


def _is_string_list(value: Any) -> bool:
    return isinstance(value, list) and all(isinstance(item, str) for item in value)


def _is_sha256(value: Any) -> bool:
    return (
        isinstance(value, str)
        and value.startswith("sha256:")
        and len(value) == 71
        and all(character in "0123456789abcdef" for character in value[7:])
    )


def _schema_violations(document: Any) -> List[str]:
    violations: List[str] = []
    if not isinstance(document, Mapping):
        return [f"$: expected a JSON object, got {type(document).__name__}"]

    allowed = set(MANIFEST_REQUIRED_FIELDS) | {"contents", "extensions"}
    for name in sorted(set(document) - allowed):
        violations.append(f"$.{name}: unknown manifest field; refused fail-closed")

    for name in MANIFEST_REQUIRED_FIELDS:
        if name not in document:
            # Missing required fields are semantic violations too, but authoring
            # schema reports them here so a publisher can locate the omission.
            violations.append(f"$.{name}: required manifest field is absent")
            continue
        value = document[name]
        if name in _STRING_FIELDS and not isinstance(value, str):
            violations.append(f"$.{name}: expected string, got {type(value).__name__}")
        elif name in _LIST_STRING_FIELDS and not _is_string_list(value):
            violations.append(f"$.{name}: expected an array of strings")
        elif name in _MAPPING_FIELDS and not isinstance(value, Mapping):
            violations.append(f"$.{name}: expected object, got {type(value).__name__}")

    contents = document.get("contents", {})
    if not isinstance(contents, Mapping):
        violations.append("$.contents: expected object")
    else:
        for name in sorted(set(contents) - _CONTENT_FIELDS):
            violations.append(f"$.contents.{name}: unknown pack content; refused fail-closed")
        for name in sorted(_CONTENT_MAPPING_FIELDS & set(contents)):
            if not isinstance(contents[name], Mapping):
                violations.append(f"$.contents.{name}: expected object")
        for name in sorted(_CONTENT_LIST_FIELDS & set(contents)):
            if not _is_string_list(contents[name]):
                violations.append(f"$.contents.{name}: expected an array of strings")

        checkers = contents.get("proof_checkers", [])
        if not isinstance(checkers, list):
            violations.append("$.contents.proof_checkers: expected an array of objects")
        else:
            required = set(PROOF_CHECKER_REQUIRED_FIELDS)
            for index, checker in enumerate(checkers):
                path = f"$.contents.proof_checkers[{index}]"
                if not isinstance(checker, Mapping):
                    violations.append(f"{path}: expected object")
                    continue
                missing = sorted(required - set(checker))
                unknown = sorted(set(checker) - required)
                if missing:
                    violations.append(f"{path}: missing declaration fields {missing}")
                if unknown:
                    violations.append(
                        f"{path}: unknown declaration fields {unknown}; refused fail-closed"
                    )
                for field in (
                    "checker_id",
                    "proof_format",
                    "semantic_scope",
                    "version",
                    "implementation_identity",
                    "trust_profile",
                ):
                    if field in checker and not isinstance(checker[field], str):
                        violations.append(f"{path}.{field}: expected string")
                if (
                    isinstance(checker.get("implementation_identity"), str)
                    and not _is_sha256(checker["implementation_identity"])
                ):
                    violations.append(
                        f"{path}.implementation_identity: expected a content-addressed "
                        "sha256:<64 lowercase hexadecimal digits> identity"
                    )
                if "sandbox_requirements" in checker and not isinstance(
                    checker["sandbox_requirements"], Mapping
                ):
                    violations.append(f"{path}.sandbox_requirements: expected object")
                if "conformance_suite" in checker and not _is_string_list(
                    checker["conformance_suite"]
                ):
                    violations.append(f"{path}.conformance_suite: expected array of strings")

    extensions = document.get("extensions", {})
    if not isinstance(extensions, Mapping):
        violations.append("$.extensions: expected object")
    elif extensions:
        # A JSON string naming Python code is not a callable binding and must not
        # turn into code execution through authoring validation.
        violations.append(
            "$.extensions: portable JSON authoring accepts declaration-only manifests; "
            "live generators, predicates, and typed bindings must be supplied separately "
            "by an execution host"
        )
    return sorted(set(violations))


def _diagnostic(
    code: str, category: str, accepted: bool, message: str, path: str = "$"
) -> PackAuthoringDiagnostic:
    return PackAuthoringDiagnostic(
        code=code,
        category=category,
        status=(DiagnosticStatus.ACCEPTED if accepted else DiagnosticStatus.REFUSED),
        path=path,
        message=message,
    )


def validate_pack_manifest_json(
    source: Union[bytes, bytearray, str], *, spec_version: Optional[str] = None
) -> PackAuthoringReport:
    """Validate exact JSON source and return a deterministic portable report.

    No extension is imported or executed.  Unknown and duplicate fields,
    binary floating-point JSON numbers, and non-empty ``extensions`` are
    refused rather than ignored.
    """

    if isinstance(source, str):
        source_bytes = source.encode("utf-8")
    elif isinstance(source, (bytes, bytearray)):
        source_bytes = bytes(source)
    else:
        raise TypeError("pack manifest JSON source must be bytes or str")

    target_spec_version = spec_version or CORE_SPEC_VERSION
    if not isinstance(target_spec_version, str) or not target_spec_version:
        raise ValueError("spec_version must be a non-empty string")
    source_hash = "sha256:" + hashlib.sha256(source_bytes).hexdigest()
    diagnostics: List[PackAuthoringDiagnostic] = []
    schema: List[str] = []
    semantic: List[str] = []
    document: Mapping[str, Any] = {}
    pack = None

    try:
        text = source_bytes.decode("utf-8")
        if text.startswith("\ufeff"):
            raise UnicodeError("a UTF-8 BOM is not part of the portable JSON profile")
        diagnostics.append(
            _diagnostic("SOURCE_UTF8", "SOURCE", True, "source is strict UTF-8")
        )
    except UnicodeError as error:
        schema.append(f"$: source is not strict UTF-8: {error}")
        diagnostics.append(
            _diagnostic("SOURCE_UTF8", "SOURCE", False, schema[-1])
        )
        text = ""

    if not schema:
        try:
            parsed = json.loads(
                text,
                object_pairs_hook=_strict_object,
                parse_float=_reject_float,
                parse_constant=_reject_constant,
            )
            diagnostics.append(
                _diagnostic("JSON_PARSE", "SCHEMA", True, "source is strict JSON")
            )
            if isinstance(parsed, Mapping):
                document = parsed
        except (ValueError, RecursionError) as error:
            schema.append(f"$: JSON refused: {error}")
            diagnostics.append(
                _diagnostic("JSON_PARSE", "SCHEMA", False, schema[-1])
            )
    else:
        diagnostics.append(
            _diagnostic(
                "JSON_PARSE", "SCHEMA", False, "JSON parsing blocked by source refusal"
            )
        )

    if not schema:
        schema.extend(_schema_violations(parsed))
        diagnostics.append(
            _diagnostic(
                "MANIFEST_SCHEMA",
                "SCHEMA",
                not schema,
                "manifest fields and portable value types are admitted"
                if not schema
                else f"manifest schema refused with {len(schema)} violation(s)",
            )
        )
    else:
        diagnostics.append(
            _diagnostic(
                "MANIFEST_SCHEMA",
                "SCHEMA",
                False,
                "manifest schema evaluation blocked by prior refusal",
            )
        )

    manifest_hash = ""
    pack_hash = ""
    if not schema:
        try:
            # This proves every accepted value has CRG canonical form before
            # the loader is allowed to normalize the declaration.
            content_hash(document)
            diagnostics.append(
                _diagnostic(
                    "CANONICALIZABLE", "SCHEMA", True, "manifest is canonically hashable"
                )
            )
        except CanonicalizationError as error:
            schema.append(f"$: manifest is not canonically hashable: {error}")
            diagnostics.append(
                _diagnostic("CANONICALIZABLE", "SCHEMA", False, schema[-1])
            )
    else:
        diagnostics.append(
            _diagnostic(
                "CANONICALIZABLE",
                "SCHEMA",
                False,
                "canonicalization blocked by schema refusal",
            )
        )

    if not schema:
        try:
            pack = load_pack(document)
            manifest_hash = pack.manifest.manifest_hash()
            pack_hash = pack.pack_hash()
            diagnostics.append(
                _diagnostic("PACK_LOAD", "SEMANTIC", True, "manifest loaded fail-closed")
            )
        except (PackError, TypeError, ValueError) as error:
            schema.append(f"$: loader refused manifest: {error}")
            diagnostics.append(_diagnostic("PACK_LOAD", "SEMANTIC", False, schema[-1]))
    else:
        diagnostics.append(
            _diagnostic(
                "PACK_LOAD", "SEMANTIC", False, "pack loading blocked by schema refusal"
            )
        )

    if pack is not None:
        semantic.extend(validate_pack(pack, spec_version=target_spec_version))
        diagnostics.append(
            _diagnostic(
                "PACK_SEMANTICS",
                "SEMANTIC",
                not semantic,
                "pack semantic declarations are admissible"
                if not semantic
                else f"pack semantics refused with {len(semantic)} violation(s)",
            )
        )
    else:
        diagnostics.append(
            _diagnostic(
                "PACK_SEMANTICS",
                "SEMANTIC",
                False,
                "semantic validation blocked because the pack did not load",
            )
        )

    raw_permissions = document.get("permissions", []) if document else []
    declared = tuple(sorted(raw_permissions)) if _is_string_list(raw_permissions) else ()
    in_process = tuple(sorted(set(declared) & Permission.IN_PROCESS_GRANTABLE))
    isolated = tuple(sorted(set(declared) & Permission.REQUIRES_ISOLATION))
    unknown = tuple(sorted(set(declared) - Permission.ALL))
    contents = document.get("contents", {}) if document else {}
    raw_checkers = contents.get("proof_checkers", []) if isinstance(contents, Mapping) else []
    checker_declarations: Tuple[Mapping[str, Any], ...] = ()
    if isinstance(raw_checkers, list) and all(isinstance(v, Mapping) for v in raw_checkers):
        checker_declarations = tuple(
            dict(checker)
            for checker in sorted(
                raw_checkers,
                key=lambda item: (
                    str(item.get("checker_id", "")),
                    str(item.get("version", "")),
                ),
            )
        )

    disposition = (
        AuthoringDisposition.ACCEPTED
        if not schema and not semantic and pack is not None
        else AuthoringDisposition.REFUSED
    )
    return PackAuthoringReport(
        source_hash=source_hash,
        source_size_bytes=len(source_bytes),
        spec_version=target_spec_version,
        disposition=disposition,
        diagnostics=tuple(diagnostics),
        schema_violations=tuple(sorted(set(schema))),
        semantic_violations=tuple(sorted(set(semantic))),
        manifest_identity=(
            str(document.get("identity", ""))
            if isinstance(document.get("identity", ""), str)
            else ""
        ),
        manifest_version=(
            str(document.get("version", ""))
            if isinstance(document.get("version", ""), str)
            else ""
        ),
        manifest_hash=manifest_hash,
        pack_hash=pack_hash,
        declared_permissions=declared,
        in_process_permissions=in_process,
        isolation_required_permissions=isolated,
        unknown_permissions=unknown,
        determinism_status=(
            str(document.get("determinism_status", ""))
            if isinstance(document.get("determinism_status", ""), str)
            else ""
        ),
        proof_checker_declarations=checker_declarations,
    )


def validate_pack_manifest_file(
    path: Union[str, Path], *, spec_version: Optional[str] = None
) -> PackAuthoringReport:
    """Read one file as bytes and validate the exact stored representation."""

    return validate_pack_manifest_json(Path(path).read_bytes(), spec_version=spec_version)
