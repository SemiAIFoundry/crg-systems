"""Reference domain pack 3 of specification 36.5: the distributed-computation pack.

Normative basis: master specification 36.5 ("a distributed-computation pack"),
36.2 (plugin manifest), 36.4 (domain-pack contents), 28.4 (generator contract),
19.6 (realization fibers).

Like pack 1, this module adds no generator.
:class:`crg_generate.reference.PlacementGenerator` already exists, and its
behaviour, its identity ``crg-generate.distributed-placement``, and its
definition hash are untouched here.  What this module adds is the manifest of
36.2, so that the distributed-computation pack loads, validates, and
enumerates through the same registry as the six others.

What the pack models
--------------------
A realization is one *placement* of declared tasks onto declared compute
nodes.  The single declared transformation ``move-task-to-later-node`` moves
one task to a node appearing later in the declared node order.  Makespan is
the maximum over nodes of that node's total work divided by its rate, and cost
is the sum over nodes of busy time times price -- both exact rationals, so two
placements differing by a thousandth of a percent still compare exactly.

There is no semiconductor in this pack, and no compiler.  That is the point:
together with pack 1 and pack 2 it demonstrates rather than asserts the domain
neutrality of 3.3, because all three ride the same unmodified core.

Termination
-----------
A task moves only to a node *later* in the declared node order, which makes
the move relation a strict partial order on a finite product space.  The
closure therefore reaches a fixpoint, and from the all-first-node seed that
fixpoint contains every placement (spec 21.2).

The worked example and the fiber
--------------------------------
Two tasks on two nodes give four placements and five realization records: the
all-second-node placement is reached both by moving the first task and then
the second, and by moving them in the other order.  The two records carry the
same exact signature and different identities, and both survive -- which is
19.6's requirement that a decision able to see the difference between two
derivations is still able to see it after the geometry is built.
"""
from __future__ import annotations

from typing import Any, Dict

from ..generator import GenerationContext
from ..reference import (
    PLACEMENT_MODEL_KEY,
    placement_generator,
    placement_seed,
    placement_universe_size,
)
from ..registry import GenerationSource
from crg_model.records import Coordinate, CoordinateSchema, Direction

from ._common import GENERATOR_PERMISSIONS, WorkedExample, manifest_fields

__all__ = [
    "PACK_NAME",
    "SPEC_INDEX",
    "SCHEMA",
    "REFERENCE_PLACEMENT_MODEL",
    "distributed_generator",
    "distributed_seed",
    "manifest_data",
    "worked_example",
]

PACK_NAME = "distributed-computation"
SPEC_INDEX = 3
PACK_IDENTITY = "crg-generate.reference.distributed-computation"

COORDINATE_MAKESPAN = "makespan"
COORDINATE_COST = "node_cost"

SCHEMA = CoordinateSchema(
    coordinates=(
        Coordinate(
            identifier=COORDINATE_MAKESPAN,
            quantity="distributed.makespan",
            unit="second",
            direction=Direction.MINIMIZE,
            accounting_scope="per-job",
        ),
        Coordinate(
            identifier=COORDINATE_COST,
            quantity="distributed.node_cost",
            unit="currency-unit",
            direction=Direction.MINIMIZE,
            accounting_scope="per-job",
        ),
    ),
    technology_context="a declared set of heterogeneous compute nodes with declared rates "
    "and prices",
)

#: Two tasks, two nodes: the smallest model that produces a real fiber.
REFERENCE_PLACEMENT_MODEL: Dict[str, Any] = {
    "tasks": {"ingest": {"work": "2"}, "reduce": {"work": "3"}},
    "nodes": {
        "node_a": {"rate": "1", "price": "2"},
        "node_b": {"rate": "2", "price": "5"},
    },
    "coordinates": {"time": COORDINATE_MAKESPAN, "cost": COORDINATE_COST},
}


def distributed_generator(**kwargs: Any):
    """The unchanged reference placement generator, wrapped by this pack."""
    return placement_generator(**kwargs)


def distributed_seed(context: GenerationContext):
    """The seed realization: every task on the first declared node."""
    return placement_seed(
        {"ingest": "node_a", "reduce": "node_a"},
        context,
        source_id="distributed-computation-seed",
    )


TERMINOLOGY: Dict[str, str] = {
    "task": "an indivisible piece of declared work with a declared work measure",
    "node": "one compute node with a declared rate and a declared price per unit of busy "
    "time",
    "placement": "an assignment of every declared task to a declared node",
    "makespan": "the maximum over nodes of that node's total work divided by its rate",
    "busy time": "one node's total work divided by its rate",
    "node order": "the declared order of the nodes; a task moves only to a later node, "
    "which is what makes the move relation a strict partial order",
}


def manifest_data() -> Dict[str, Any]:
    fields = manifest_fields(
        identity=PACK_IDENTITY,
        external_dependencies=(
            "crg-model (exact rationals, records, canonicalization)",
            "crg-generate (the unchanged PlacementGenerator of crg_generate.reference)",
        ),
        resource_requirements={
            "memory_mb": 16,
            "wall_clock_seconds": 1,
            "processes": 1,
            "network": "none: the pack reasons about placements, it does not perform them",
        },
        failure_modes=(
            "SKIP_AND_RECORD: a parent carrying no placement attribute yields no child and "
            "is recorded as an UNGENERATED region, never as an infeasible one (spec 28.4)",
            "GeneratorError: a placement naming an undeclared node or task is refused rather "
            "than silently dropped, because a silently dropped candidate would shrink the "
            "family without shrinking the claim (spec 6.6)",
            "ILLEGAL: a placement whose signature carries a negative coordinate is refused "
            "by the nonnegative-signature predicate",
        ),
        quantity_registry_additions=(
            "distributed.makespan",
            "distributed.node_cost",
            "distributed.node_busy_time",
        ),
        proof_implications=(
            "a task moves only to a later node in the declared node order, so the move "
            "relation is a strict partial order on a finite product space and a fixpoint "
            "supports a GENERATOR_CLOSED completeness basis (spec 21.2)",
            "the declared universe has exactly |nodes| ** |tasks| members, so a source "
            "declaring that size and a universe key over the placement attribute derives "
            "EXHAUSTIVE_DECLARED_UNIVERSE rather than GENERATOR_CLOSED (spec 21.2)",
            "two derivation orders reaching one placement stay two records, so the fibers of "
            "19.6 survive into the geometry",
        ),
        conformance_tests=(
            "test_every_reference_pack_loads_and_validates",
            "test_every_reference_pack_reaches_a_generator_closed_basis",
            "test_every_reference_pack_worked_example_matches_its_generator",
        ),
        provenance={
            "repository": "CRGsys",
            "module": "crg_generate.reference_packs.distributed",
            "wraps": "crg_generate.reference.PlacementGenerator",
            "specification": "36.5 initial reference pack 3 (distributed computation)",
            "derivation": "manifest only; the wrapped generator's identity, behaviour, and "
            "definition hash are unchanged",
        },
    )
    fields["contents"] = {
        "terminology": TERMINOLOGY,
        "quantities": {
            "distributed.makespan": "second",
            "distributed.node_cost": "currency-unit",
            "distributed.node_busy_time": "second",
        },
        "contracts": {
            "computation_contract": "the declared task set with each task's declared work",
            "resource_contract": "the declared node set with each node's rate and price",
        },
        "accounting_rules": {
            "makespan": "max over nodes of (node load / node rate)",
            "node_cost": "sum over nodes of (node busy time * node price)",
            "node_busy_time": "one CAPABILITY obligation per node carrying a non-zero load",
        },
        "transformations": ["move-task-to-later-node"],
        "obligation_coordinates": [COORDINATE_MAKESPAN, COORDINATE_COST, "node_busy_time"],
        "technology_coordinates": ["heterogeneous-node-rates", "per-node-pricing"],
        "evaluators": ["crg_generate.reference.placement_signature"],
        "qualification_methods": [
            "exact recomputation of makespan and cost from the recorded placement attribute"
        ],
        "proof_checkers": [],
        "ui_extensions": [],
        "example_cases": ["two-tasks-on-two-nodes"],
        "conformance_fixtures": [
            "fixture: the four placements have exact signatures (5, 10), (3, 11), "
            "(2, 23/2), (5/2, 25/2)",
            "fixture: the family is five records over four signatures; the all-second-node "
            "placement is reached by two derivations and both records survive (spec 19.6)",
            "fixture: the declared universe has |nodes| ** |tasks| = 4 members, which "
            "crg_generate.reference.placement_universe_size reports",
        ],
    }
    fields["extensions"] = {"generators": [distributed_generator()]}
    return fields


def worked_example() -> WorkedExample:
    context = GenerationContext(
        schema=SCHEMA,
        capabilities={},
        parameters={PLACEMENT_MODEL_KEY: REFERENCE_PLACEMENT_MODEL},
        permissions=tuple(GENERATOR_PERMISSIONS),
        declared_universe="every placement of the declared tasks onto the declared nodes",
        validity="the declared node rates and prices",
    )
    seed = distributed_seed(context)
    source = GenerationSource(
        source_id="distributed-computation-reference-model",
        source_type="PLACEMENT",
        seeds=(seed,),
        computation_contract={"contract_id": "distributed.task-set", "version": "1"},
        resource_contract={"contract_id": "distributed.node-set", "version": "1"},
        declared_universe="every placement of the declared tasks onto the declared nodes",
    )
    return WorkedExample(
        name="two-tasks-on-two-nodes",
        description=(
            "Two tasks of work 2 and 3 on two nodes of rate 1 price 2 and rate 2 price 5. "
            "Four placements, five realization records, and one two-member fiber."
        ),
        schema=SCHEMA,
        source=source,
        context=context,
        expected_realization_count=5,
        expected_legal_count=5,
        expected_signatures=(
            ("2", "23/2"),
            ("3", "11"),
            ("5", "10"),
            ("5/2", "25/2"),
        ),
        decision_query={
            "id": "distributed-placement-choice",
            "objective_family": {
                "type": "weighted_sum",
                "weights": {COORDINATE_MAKESPAN: "3", COORDINATE_COST: "1"},
            },
            "quantification": "EACH_OBJECTIVE",
            "ties": {"policy_tolerance": "0", "retain_all": True},
        },
        notes=(
            f"the declared universe has {placement_universe_size.__name__}(context) = "
            "|nodes| ** |tasks| = 4 members",
            "23/2 and 25/2 are exact rationals produced by rational division",
        ),
    )
