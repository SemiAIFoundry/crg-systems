"""Reference domain pack 4 of specification 36.5: the AI-system realization pack.

Normative basis: master specification 36.5 ("an AI-system realization pack"),
36.4 (domain-pack contents), 36.2 (plugin manifest), 28.4 (generator contract),
21 (completeness basis), and 3.3 (domain neutrality: core carries none of the
vocabulary in this file).

What the pack models
--------------------
A realization is one *training-step realization*: a choice of how the model is
partitioned across devices, crossed with a choice of whether the intermediate
activations of the forward pass are **stored** for the backward pass or
**recomputed** in it.  Those are the two decisions specification 36.5 has in
mind when it asks for an AI-system pack, and the pack exercises both:

``advance-tensor-pipeline-partition``
    Move to the next declared partition of the model over the declared device
    count.  A partition declares a tensor-shard count and a pipeline-stage
    count; sharding divides per-device parameter memory and adds an all-reduce
    per step, staging divides per-device activation memory and adds a pipeline
    bubble.
``select-activation-recomputation``
    Replace *store the activations* with *recompute them in the backward
    pass*.  Per-device memory falls, because only the declared checkpoint
    boundary survives the forward pass; compute cost rises, because the
    forward pass runs a second time.  This is storage-versus-recomputation,
    and the pack test suite asserts that the two coordinates actually move in
    opposite directions.

The exact cost model, stated once
---------------------------------
With ``t`` tensor shards, ``p`` pipeline stages, ``A`` activation words held
across the step, ``P`` parameter words, ``C`` forward-and-backward
instructions, and ``R`` recomputation instructions::

    memory_words_per_device   = A / (t * p) + P / t
    compute_communication_cost = (C + R_used) / (t * p)
                               + all_reduce_cost * (t - 1)
                               + pipeline_bubble_cost * (p - 1)

where ``A`` is the full activation footprint when activations are stored and
the smaller declared checkpoint footprint when they are recomputed, and
``R_used`` is ``R`` only in the recomputing variant.  Every division here is
rational division: at two tensor shards the recomputing variant costs
``273/2``, which no binary float represents (spec 14.2, 22.6).

Termination
-----------
The closure is finite by a strict partial order on the pair ``(partition
index, stage)``:

1. ``advance-tensor-pipeline-partition`` strictly increases the partition
   index and is bounded above by the number of declared partitions;
2. ``select-activation-recomputation`` moves ``stage`` from
   ``PARTITION_OPEN`` to ``CHECKPOINT_FIXED`` and never back, and the
   partition rule requires ``PARTITION_OPEN``.

So a path is a sequence of partition advances followed by at most one
recomputation choice, and the number of such paths is exactly twice the number
of declared partitions.  The order is declared rather than incidental: a real
system fixes its partition before it decides its checkpointing policy, because
the checkpoint boundary is a property of the partitioned graph.

Determinism
-----------
Partitions are read in declared order, layers in sorted order, and no
dictionary iteration order reaches a signature or an identifier (spec 6.5).
"""
from __future__ import annotations

from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple

from crg_model.envelope import EvidenceClass
from crg_model.numeric import Exact
from crg_model.records import (
    Coordinate,
    CoordinateSchema,
    Direction,
    RealizationRecord,
    Signature,
)

from ..generator import (
    CompletenessImplication,
    DeterminismStatus,
    FailureSemantics,
    GenerationContext,
    GeneratorDefinition,
    GeneratorError,
    Obligation,
    ObligationType,
    ParentChildRelation,
    SemanticRule,
    WitnessMethod,
    propose_record,
    seed_record,
)
from ..legality import LegalityPredicate, LegalityStatus
from ..reference import nonnegative_signature_predicate
from ..registry import GenerationSource
from ._common import (
    GENERATOR_PERMISSIONS,
    PACK_VERSION,
    WorkedExample,
    as_flag,
    carried_attributes,
    manifest_fields,
    read_model,
)

__all__ = [
    "PACK_NAME",
    "SPEC_INDEX",
    "AI_SYSTEM_MODEL_KEY",
    "ATTR_PARTITION",
    "ATTR_CHECKPOINT_POLICY",
    "ATTR_STAGE",
    "POLICY_STORE",
    "POLICY_RECOMPUTE",
    "SCHEMA",
    "REFERENCE_SYSTEM",
    "AiSystemGenerator",
    "ai_system_generator",
    "ai_system_seed",
    "realization_signature",
    "device_budget_predicate",
    "manifest_data",
    "worked_example",
]

PACK_NAME = "ai-system-realization"
SPEC_INDEX = 4
PACK_IDENTITY = "crg-generate.reference.ai-system-realization"

AI_SYSTEM_MODEL_KEY = "ai_system_model"

ATTR_PARTITION = "partition"
ATTR_CHECKPOINT_POLICY = "checkpoint_policy"
ATTR_STAGE = "realization_stage"

POLICY_STORE = "store-activations"
POLICY_RECOMPUTE = "recompute-activations"

STAGE_PARTITION_OPEN = "PARTITION_OPEN"
STAGE_CHECKPOINT_FIXED = "CHECKPOINT_FIXED"

TRANSFORMATION_PARTITION = "advance-tensor-pipeline-partition"
TRANSFORMATION_RECOMPUTE = "select-activation-recomputation"

COORDINATE_MEMORY = "memory_words_per_device"
COORDINATE_COST = "compute_communication_cost"

SCHEMA = CoordinateSchema(
    coordinates=(
        Coordinate(
            identifier=COORDINATE_MEMORY,
            quantity="ai_system.memory_words_per_device",
            unit="word",
            direction=Direction.MINIMIZE,
            accounting_scope="per-device-per-step",
        ),
        Coordinate(
            identifier=COORDINATE_COST,
            quantity="ai_system.compute_communication_cost",
            unit="instruction-equivalent",
            direction=Direction.MINIMIZE,
            accounting_scope="per-step",
        ),
    ),
    technology_context="a homogeneous device group with a declared device count",
)

#: The reference system.  Two devices, three declared partitions, four layers.
REFERENCE_SYSTEM: Dict[str, Any] = {
    "layers": {
        "block_0": {"activation_words": "60", "checkpoint_words": "15"},
        "block_1": {"activation_words": "60", "checkpoint_words": "15"},
        "block_2": {"activation_words": "60", "checkpoint_words": "15"},
        "block_3": {"activation_words": "60", "checkpoint_words": "15"},
    },
    "parameter_words": "96",
    "forward_backward_instructions": "180",
    "recomputation_instructions": "45",
    "all_reduce_cost_per_extra_shard": "24",
    "pipeline_bubble_cost_per_extra_stage": "15",
    "device_count": 2,
    "partitions": [
        {"name": "replicated", "tensor_shards": 1, "pipeline_stages": 1},
        {"name": "tensor-sharded-2", "tensor_shards": 2, "pipeline_stages": 1},
        {"name": "pipeline-staged-2", "tensor_shards": 1, "pipeline_stages": 2},
    ],
}


# ---------------------------------------------------------------------------
# the declared system, read exactly
# ---------------------------------------------------------------------------


class _AiSystem:
    """The declared system model, read once into exact rationals."""

    def __init__(self, raw: Mapping[str, Any]) -> None:
        layers = raw.get("layers")
        partitions = raw.get("partitions")
        if not layers or not partitions:
            raise GeneratorError(
                f"{AI_SYSTEM_MODEL_KEY} MUST declare both 'layers' and 'partitions'; an empty "
                "declaration would make an empty family look like a closed one (spec 6.6)"
            )
        self.stored_activation_words = Exact(0)
        self.checkpoint_words = Exact(0)
        for name in sorted(layers):
            body = layers[name]
            self.stored_activation_words = self.stored_activation_words + Exact(
                body["activation_words"]
            )
            self.checkpoint_words = self.checkpoint_words + Exact(body["checkpoint_words"])
        self.layer_names: Tuple[str, ...] = tuple(sorted(layers))
        self.parameter_words = Exact(raw["parameter_words"])
        self.forward_backward = Exact(raw["forward_backward_instructions"])
        self.recomputation = Exact(raw["recomputation_instructions"])
        self.all_reduce = Exact(raw["all_reduce_cost_per_extra_shard"])
        self.bubble = Exact(raw["pipeline_bubble_cost_per_extra_stage"])
        self.device_count = int(raw["device_count"])
        self.partition_names: Tuple[str, ...] = tuple(
            str(p["name"]) for p in partitions
        )
        if len(set(self.partition_names)) != len(self.partition_names):
            raise GeneratorError("a partition name is declared twice")
        self.tensor_shards: Dict[str, int] = {
            str(p["name"]): int(p["tensor_shards"]) for p in partitions
        }
        self.pipeline_stages: Dict[str, int] = {
            str(p["name"]): int(p["pipeline_stages"]) for p in partitions
        }

    def index_of(self, partition: str) -> int:
        if partition not in self.partition_names:
            raise GeneratorError(
                f"partition {partition!r} is not in the declared partition list "
                f"{list(self.partition_names)}"
            )
        return self.partition_names.index(partition)

    def devices_required(self, partition: str) -> int:
        return self.tensor_shards[partition] * self.pipeline_stages[partition]

    @property
    def universe_note(self) -> str:
        return (
            f"the closure of the declared partition and activation-recomputation "
            f"transformations over {len(self.partition_names)} declared partition(s) of the "
            f"declared model on {self.device_count} device(s)"
        )


def _system(context: GenerationContext) -> _AiSystem:
    return _AiSystem(read_model(context, AI_SYSTEM_MODEL_KEY))


# ---------------------------------------------------------------------------
# the exact cost model
# ---------------------------------------------------------------------------


def realization_signature(
    partition: str,
    policy: str,
    system: _AiSystem,
    schema: CoordinateSchema,
) -> Signature:
    """Exact per-device memory and exact compute-plus-communication cost."""
    if policy not in (POLICY_STORE, POLICY_RECOMPUTE):
        raise GeneratorError(
            f"unknown activation policy {policy!r}; declare one of "
            f"{[POLICY_STORE, POLICY_RECOMPUTE]}"
        )
    shards = Exact(system.tensor_shards[partition])
    stages = Exact(system.pipeline_stages[partition])
    devices = shards * stages

    held = (
        system.stored_activation_words
        if policy == POLICY_STORE
        else system.checkpoint_words
    )
    compute = system.forward_backward + (
        system.recomputation if policy == POLICY_RECOMPUTE else Exact(0)
    )

    memory = held / devices + system.parameter_words / shards
    cost = (
        compute / devices
        + system.all_reduce * (shards - Exact(1))
        + system.bubble * (stages - Exact(1))
    )
    values = {COORDINATE_MEMORY: memory, COORDINATE_COST: cost}
    missing = [i for i in schema.identifiers if i not in values]
    if missing:
        raise GeneratorError(
            f"the declared schema has coordinates {missing} this pack does not produce; a "
            "signature has no optional components (spec 19.1)"
        )
    return Signature([values[identifier] for identifier in schema.identifiers])


# ---------------------------------------------------------------------------
# legality (spec 28.6)
# ---------------------------------------------------------------------------


def device_budget_predicate(version: str = "1") -> LegalityPredicate:
    """Refuse a partition needing more devices than the context declares.

    ``INFEASIBLE``, not ``ILLEGAL``: a four-way partition is a perfectly legal
    realization of the model; it simply cannot run on two devices.  On four
    devices it can, and 28.6 requires that difference to remain visible.
    """

    def evaluate(realization: RealizationRecord, context: Mapping[str, Any]) -> Any:
        model = context.get("parameters", {}).get(AI_SYSTEM_MODEL_KEY)
        if not isinstance(model, Mapping) or model.get("device_count") is None:
            return (
                LegalityStatus.UNSUPPORTED,
                f"the declared {AI_SYSTEM_MODEL_KEY!r} carries no 'device_count'; this "
                "predicate applies but cannot decide",
            )
        system = _AiSystem(model)
        partition = as_flag(realization.attributes.get(ATTR_PARTITION, ""))
        if partition not in system.partition_names:
            return (
                LegalityStatus.UNSUPPORTED,
                f"the realization declares partition {partition!r}, which is not in the "
                "declared partition list; this predicate cannot decide it",
            )
        required = system.devices_required(partition)
        if required > system.device_count:
            return (
                LegalityStatus.INFEASIBLE,
                f"partition {partition!r} requires {required} device(s) and the context "
                f"declares {system.device_count}; the realization is constructible but not "
                "realizable on this device group",
            )
        return True

    return LegalityPredicate(
        predicate_id="crg-generate.reference.ai-system.device-budget",
        version=version,
        description="the partition fits the declared device count",
        evaluate=evaluate,
        required_context=("parameters",),
        false_status=LegalityStatus.INFEASIBLE,
        evidence_class=EvidenceClass.EXACT,
    )


# ---------------------------------------------------------------------------
# the generator (spec 28.4)
# ---------------------------------------------------------------------------


class AiSystemGenerator:
    """Partition choices crossed with the activation store-versus-recompute choice."""

    def __init__(
        self,
        *,
        identity: str = PACK_IDENTITY,
        version: str = PACK_VERSION,
        failure_semantics: str = FailureSemantics.SKIP_AND_RECORD,
    ) -> None:
        self.definition = GeneratorDefinition(
            identity=identity,
            version=version,
            accepted_source_types=("AI_SYSTEM_MODEL", "EXPLICIT_RECORDS"),
            transformations=(TRANSFORMATION_PARTITION, TRANSFORMATION_RECOMPUTE),
            semantic_rule=SemanticRule.SEMANTICS_PRESERVING,
            semantic_rule_detail=(
                "partitioning changes which device holds which shard of the same computation, "
                "and recomputing an activation reproduces exactly the value that would have "
                "been stored; the arithmetic the step performs, and therefore the update it "
                "produces, is an invariant of both transformations"
            ),
            determinism_status=DeterminismStatus.DETERMINISTIC,
            failure_semantics=failure_semantics,
            completeness_implications=CompletenessImplication(
                closes_family=True,
                rationale=(
                    "a partition advance strictly increases the declared partition index and "
                    "is bounded by the number of declared partitions; the recomputation choice "
                    "moves the stage from PARTITION_OPEN to CHECKPOINT_FIXED and never back, "
                    "and no rule applies after it except none. The closure is therefore a "
                    "finite set of paths -- one per (partition, policy) pair -- and its "
                    "fixpoint enumerates every realization the declared transformations reach"
                ),
            ),
            conformance_tests=(
                "test_every_reference_pack_reaches_a_generator_closed_basis",
                "test_ai_system_exercises_storage_versus_recomputation_and_partitioning",
            ),
            legality_predicates=(
                nonnegative_signature_predicate(),
                device_budget_predicate(),
            ),
            capability_gates=(),
            obligation_types=(ObligationType.RESOURCE, ObligationType.CAPABILITY),
            obligation_extractor=self._obligations,
            parent_child_relation=ParentChildRelation.CHILD_ALTERNATIVE_TO_PARENT,
            dependencies=(f"context:{AI_SYSTEM_MODEL_KEY}",),
            witness_method=WitnessMethod.CONSTRUCTIVE_TRANSFORMATION,
            required_permissions=GENERATOR_PERMISSIONS,
        )

    def propose(
        self, parent: RealizationRecord, context: GenerationContext
    ) -> Iterable[RealizationRecord]:
        system = _system(context)
        partition = as_flag(parent.attributes.get(ATTR_PARTITION, ""))
        if not partition:
            return []
        policy = as_flag(parent.attributes.get(ATTR_CHECKPOINT_POLICY, POLICY_STORE))
        stage = as_flag(parent.attributes.get(ATTR_STAGE, STAGE_PARTITION_OPEN))
        children: List[RealizationRecord] = []
        if stage != STAGE_PARTITION_OPEN:
            return []

        index = system.index_of(partition)
        if index + 1 < len(system.partition_names):
            attributes = carried_attributes(parent)
            attributes[ATTR_PARTITION] = system.partition_names[index + 1]
            children.append(
                self._child(parent, context, system, TRANSFORMATION_PARTITION, attributes)
            )
        if policy == POLICY_STORE:
            attributes = carried_attributes(parent)
            attributes[ATTR_CHECKPOINT_POLICY] = POLICY_RECOMPUTE
            attributes[ATTR_STAGE] = STAGE_CHECKPOINT_FIXED
            children.append(
                self._child(parent, context, system, TRANSFORMATION_RECOMPUTE, attributes)
            )
        return children

    def _child(
        self,
        parent: RealizationRecord,
        context: GenerationContext,
        system: _AiSystem,
        transformation: str,
        attributes: Dict[str, Any],
    ) -> RealizationRecord:
        signature = realization_signature(
            as_flag(attributes[ATTR_PARTITION]),
            as_flag(attributes.get(ATTR_CHECKPOINT_POLICY, POLICY_STORE)),
            system,
            context.schema,
        )
        return propose_record(
            parent=parent,
            definition=self.definition,
            transformation=transformation,
            signature=signature,
            attributes=attributes,
            evidence_class=EvidenceClass.CONSTRUCTIVE,
        )

    def _obligations(
        self, record: RealizationRecord, context: GenerationContext
    ) -> Sequence[Obligation]:
        system = _system(context)
        partition = as_flag(record.attributes.get(ATTR_PARTITION, ""))
        obligations: List[Obligation] = []
        for coordinate, value in zip(context.schema.coordinates, record.signature.values):
            obligations.append(
                Obligation(
                    obligation_type=ObligationType.RESOURCE,
                    realization_id=record.realization_id,
                    name=coordinate.identifier,
                    value=value,
                    unit=coordinate.unit,
                    scope=coordinate.accounting_scope,
                    evidence_class=EvidenceClass.EXACT,
                    source=self.definition.qualified_id,
                )
            )
        obligations.append(
            Obligation(
                obligation_type=ObligationType.CAPABILITY,
                realization_id=record.realization_id,
                name=f"devices_required:{partition}",
                value=Exact(system.devices_required(partition)),
                unit="device",
                scope="per-step",
                evidence_class=EvidenceClass.EXACT,
                source=self.definition.qualified_id,
            )
        )
        return obligations


def ai_system_generator(**kwargs: Any) -> AiSystemGenerator:
    """The reference AI-system realization generator (spec 36.5 pack 4)."""
    return AiSystemGenerator(**kwargs)


def ai_system_seed(
    context: GenerationContext, *, source_id: str = "ai-system-seed"
) -> RealizationRecord:
    """The seed realization: the first declared partition, activations stored."""
    system = _system(context)
    partition = system.partition_names[0]
    return seed_record(
        source_id=source_id,
        signature=realization_signature(partition, POLICY_STORE, system, context.schema),
        attributes={
            ATTR_PARTITION: partition,
            ATTR_CHECKPOINT_POLICY: POLICY_STORE,
            ATTR_STAGE: STAGE_PARTITION_OPEN,
        },
        evidence_class=EvidenceClass.CONSTRUCTIVE,
    )


# ---------------------------------------------------------------------------
# manifest (36.2) and pack contents (36.4)
# ---------------------------------------------------------------------------

TERMINOLOGY: Dict[str, str] = {
    "tensor shard": "one of the declared pieces a layer's parameters and its matching "
    "activation slice are split into across devices",
    "pipeline stage": "one of the declared consecutive groups of layers a device owns "
    "end to end",
    "stored activation": "an intermediate of the forward pass retained in device memory "
    "until the backward pass consumes it",
    "recomputed activation": "an intermediate the backward pass reproduces by rerunning "
    "the forward computation from the nearest declared checkpoint boundary",
    "checkpoint boundary": "the declared subset of intermediates retained even under "
    "recomputation",
    "all-reduce": "the collective a tensor-sharded step performs once per step, priced "
    "per extra shard",
    "pipeline bubble": "the idle cost a staged step pays, priced per extra stage",
}


def manifest_data() -> Dict[str, Any]:
    fields = manifest_fields(
        identity=PACK_IDENTITY,
        external_dependencies=(
            "crg-model (exact rationals, records, canonicalization)",
            "crg-generate (generator contract, legality, registry)",
        ),
        resource_requirements={
            "memory_mb": 32,
            "wall_clock_seconds": 1,
            "processes": 1,
            "network": "none",
        },
        failure_modes=(
            "SKIP_AND_RECORD: a parent carrying no partition attribute yields no child and "
            "is recorded as an UNGENERATED region, never as an infeasible one (spec 28.4)",
            "INFEASIBLE: a partition requiring more devices than the context declares is "
            "refused by a legality predicate, not by the generator",
            "UNSUPPORTED: a context declaring no device count leaves the device-budget "
            "predicate undecided rather than permissive",
        ),
        quantity_registry_additions=(
            "ai_system.memory_words_per_device",
            "ai_system.compute_communication_cost",
            "ai_system.devices_required",
        ),
        proof_implications=(
            "the closure is a finite set of paths -- partition advances followed by at most "
            "one recomputation choice -- so a fixpoint of this generator supports a "
            "GENERATOR_CLOSED completeness basis (spec 21.2)",
            "storage and recomputation move memory and cost in opposite directions at every "
            "declared partition, so no realization of this family dominates the others on "
            "both coordinates and the frontier is genuinely multi-point (spec 20)",
            "every coordinate and obligation is an exact rational; the recomputing "
            "tensor-sharded variant costs 273/2, a value no binary float represents "
            "(spec 14.2)",
        ),
        conformance_tests=(
            "test_every_reference_pack_loads_and_validates",
            "test_every_reference_pack_reaches_a_generator_closed_basis",
            "test_ai_system_exercises_storage_versus_recomputation_and_partitioning",
        ),
        provenance={
            "repository": "CRGsys",
            "module": "crg_generate.reference_packs.ai_system",
            "specification": "36.5 initial reference pack 4 (AI-system realization)",
            "derivation": "first-party reference implementation; no imported registry",
        },
    )
    fields["contents"] = {
        "terminology": TERMINOLOGY,
        "quantities": {
            "ai_system.memory_words_per_device": "word",
            "ai_system.compute_communication_cost": "instruction-equivalent",
            "ai_system.devices_required": "device",
        },
        "contracts": {
            "computation_contract": "the declared layer set with its per-layer activation "
            "and checkpoint word counts and the model's parameter word count",
            "resource_contract": "a homogeneous device group of the declared device count",
            "hierarchy_contract": "a partition is a (tensor shard count, pipeline stage "
            "count) pair whose product is the device count it occupies",
        },
        "accounting_rules": {
            "memory_words_per_device": "held activations divided by the device product, "
            "plus parameters divided by the tensor shard count",
            "compute_communication_cost": "compute divided by the device product, plus one "
            "all-reduce per extra shard, plus one bubble per extra stage",
            "recomputation": "the recomputing variant holds only the declared checkpoint "
            "words and pays the declared recomputation instructions once per step",
        },
        "transformations": [TRANSFORMATION_PARTITION, TRANSFORMATION_RECOMPUTE],
        "obligation_coordinates": [
            COORDINATE_MEMORY,
            COORDINATE_COST,
            "devices_required",
        ],
        "technology_coordinates": [
            "homogeneous-device-group",
            "declared-device-count",
            "collective-priced-per-extra-shard",
        ],
        "evaluators": ["crg_generate.reference_packs.ai_system.realization_signature"],
        "qualification_methods": [
            "exact re-evaluation of the declared cost model from the recorded partition and "
            "activation policy"
        ],
        "proof_checkers": [],
        "ui_extensions": [],
        "example_cases": ["three-partitions-crossed-with-two-activation-policies"],
        "conformance_fixtures": [
            "fixture: the replicated stored realization is (336, 180) and the replicated "
            "recomputing realization is (156, 225) -- memory falls, cost rises",
            "fixture: the tensor-sharded recomputing realization costs 273/2, an exact "
            "rational no binary float represents",
            "fixture: the family contains both activation policies and all three declared "
            "partitions, six realizations in total",
        ],
    }
    fields["extensions"] = {"generators": [ai_system_generator()]}
    return fields


def worked_example() -> WorkedExample:
    context = GenerationContext(
        schema=SCHEMA,
        capabilities={},
        parameters={AI_SYSTEM_MODEL_KEY: REFERENCE_SYSTEM},
        permissions=tuple(GENERATOR_PERMISSIONS),
        declared_universe=_AiSystem(REFERENCE_SYSTEM).universe_note,
        validity="the declared model, device count, and collective cost model",
    )
    seed = ai_system_seed(context)
    source = GenerationSource(
        source_id="ai-system-reference-model",
        source_type="AI_SYSTEM_MODEL",
        seeds=(seed,),
        computation_contract={"contract_id": "ai-system.layers", "version": "1"},
        resource_contract={"contract_id": "ai-system.device-group", "version": "1"},
        hierarchy_contract={"contract_id": "ai-system.partitions", "version": "1"},
        declared_universe=_AiSystem(REFERENCE_SYSTEM).universe_note,
    )
    return WorkedExample(
        name="three-partitions-crossed-with-two-activation-policies",
        description=(
            "Four blocks of 60 activation words each, 15 of which are checkpoint "
            "boundaries; 96 parameter words; 180 forward-and-backward instructions and 45 "
            "recomputation instructions; two devices. Three declared partitions crossed "
            "with the store/recompute choice give six realizations."
        ),
        schema=SCHEMA,
        source=source,
        context=context,
        expected_realization_count=6,
        expected_legal_count=6,
        expected_signatures=(
            ("126", "255/2"),
            ("156", "225"),
            ("168", "114"),
            ("216", "105"),
            ("336", "180"),
            ("78", "273/2"),
        ),
        decision_query={
            "id": "ai-system-realization-choice",
            "objective_family": {
                "type": "weighted_sum",
                "weights": {COORDINATE_MEMORY: "1", COORDINATE_COST: "2"},
            },
            "quantification": "EACH_OBJECTIVE",
            "ties": {"policy_tolerance": "0", "retain_all": True},
        },
        notes=(
            "at each declared partition the recomputing variant has strictly smaller memory "
            "and strictly larger cost than the storing variant",
            "273/2 and 255/2 are exact rationals produced by rational division, not decimals",
        ),
    )
