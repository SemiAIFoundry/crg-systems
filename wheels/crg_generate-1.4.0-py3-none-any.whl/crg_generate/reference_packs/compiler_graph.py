"""Reference domain pack 2 of specification 36.5: the compiler-graph pack.

Normative basis: master specification 36.5 ("a compiler-graph pack"), 36.4
(domain-pack contents), 36.2 (plugin manifest), 28.4 (generator contract), and
3.3 (domain neutrality: nothing in this file is known to ``crg-generate``
core, and core carries none of its vocabulary).

What the pack models
--------------------
A realization is one *schedule and fusion decision* over a declared operator
DAG.  The DAG is data in the generation context, never in this module: an
operator declares its instruction count, its output size in words, and the
operators it consumes.  Three declared transformations generate the family:

``fuse-adjacent-operators``
    Fuse a producer with an adjacent consumer.  Fusion removes a share of the
    consumer's loop overhead -- declared as ``fusion_saving_share`` -- and pins
    the two operators together, which is why a fused schedule may no longer be
    reordered.
``inline-fused-intermediate``
    Choose *inline* over *materialize* for the intermediate the fused pair
    produces.  An inlined value never occupies memory between steps, but any
    consumer outside the fused region must recompute it.  This is the
    store-versus-recompute trade at the level of a compiler's value
    materialization policy, and it moves peak live memory and instruction
    count in opposite directions.
``reorder-independent-operators``
    Swap an adjacent pair of operators neither of which depends on the other.
    Reordering changes nothing about what is computed; it changes which live
    ranges overlap, hence peak live memory.

Obligations
-----------
Every realization carries two exact obligations -- ``peak_live_memory`` in
words and ``instruction_count`` in instructions -- and one exact accounting
obligation counting the intermediates that remain materialized.  Both cost
coordinates are exact rationals: with ``fusion_saving_share = 1/2`` the fused
variants land on ``13`` and ``27/2`` instructions, and ``27/2`` is not a
number a binary float represents (spec 14.2, 22.6).

The cost model, stated once
---------------------------
For a schedule ``s`` (a topological order of the operators):

* a value produced by a *non-terminal* operator occupies memory from the step
  that produces it through the step of its last consumer;
* a value produced by a *terminal* operator (a result) occupies memory only
  during the step that produces it -- results are written out at once;
* an *inlined* value occupies no memory at any step;
* ``peak_live_memory(s)`` is the maximum over steps of the total occupancy;
* ``instruction_count(s)`` is the sum of the operators' instruction counts,
  less the fusion saving when a pair is fused, plus one recomputation of the
  inlined producer for every consumer of it outside the fused pair.

Termination
-----------
The closure is finite, and the argument is a strict partial order on the
triple ``(fused, inlined, reorderings)``:

1. ``fuse-adjacent-operators`` requires ``fused_pair`` to be empty and leaves
   it non-empty, so it fires at most once on any path;
2. ``inline-fused-intermediate`` requires ``fused_pair`` non-empty and
   ``inlined_value`` empty, and leaves ``inlined_value`` non-empty, so it also
   fires at most once and only after a fusion;
3. ``reorder-independent-operators`` requires ``fused_pair`` empty and
   advances the bounded counter ``reorderings`` towards the model's declared
   ``max_reorderings``.

No rule ever decreases any of the three, and each is bounded above, so no path
can be infinite and the breadth-first closure reaches a fixpoint.  That is what
makes ``GENERATOR_CLOSED`` available at all (spec 21.2, 21.6, 6.11).

Determinism
-----------
Operators are read in sorted key order, schedule positions are scanned left to
right, and the transformations are applied in declared order.  No dictionary
iteration order reaches a signature, an attribute, or an identifier (6.5).
"""
from __future__ import annotations

from typing import Any, Dict, Iterable, List, Mapping, Sequence, Set, Tuple

from crg_model.envelope import EvidenceClass
from crg_model.numeric import Exact
from crg_model.records import (
    Coordinate,
    CoordinateSchema,
    Direction,
    RealizationRecord,
    Signature,
)

from ..generator import (
    CompletenessImplication,
    DeterminismStatus,
    FailureSemantics,
    GenerationContext,
    GeneratorDefinition,
    GeneratorError,
    Obligation,
    ObligationType,
    ParentChildRelation,
    SemanticRule,
    WitnessMethod,
    propose_record,
    seed_record,
)
from ..legality import LegalityPredicate, LegalityStatus
from ..reference import nonnegative_signature_predicate
from ..registry import GenerationSource
from ._common import (
    GENERATOR_PERMISSIONS,
    PACK_VERSION,
    WorkedExample,
    as_index,
    as_flag,
    carried_attributes,
    manifest_fields,
    read_model,
)

__all__ = [
    "PACK_NAME",
    "SPEC_INDEX",
    "OPERATOR_DAG_KEY",
    "ATTR_SCHEDULE",
    "ATTR_FUSED_PAIR",
    "ATTR_INLINED_VALUE",
    "ATTR_REORDERINGS",
    "SCHEMA",
    "REFERENCE_DAG",
    "OperatorDagGenerator",
    "compiler_graph_generator",
    "compiler_graph_seed",
    "schedule_signature",
    "memory_capacity_predicate",
    "manifest_data",
    "worked_example",
]

PACK_NAME = "compiler-graph"
SPEC_INDEX = 2
PACK_IDENTITY = "crg-generate.reference.compiler-graph"

OPERATOR_DAG_KEY = "operator_dag"

ATTR_SCHEDULE = "schedule"
ATTR_FUSED_PAIR = "fused_pair"
ATTR_INLINED_VALUE = "inlined_value"
ATTR_REORDERINGS = "reorderings"

TRANSFORMATION_FUSE = "fuse-adjacent-operators"
TRANSFORMATION_INLINE = "inline-fused-intermediate"
TRANSFORMATION_REORDER = "reorder-independent-operators"

COORDINATE_PEAK_MEMORY = "peak_live_memory"
COORDINATE_INSTRUCTIONS = "instruction_count"

SCHEMA = CoordinateSchema(
    coordinates=(
        Coordinate(
            identifier=COORDINATE_PEAK_MEMORY,
            quantity="compiler.peak_live_memory",
            unit="word",
            direction=Direction.MINIMIZE,
            accounting_scope="per-invocation",
        ),
        Coordinate(
            identifier=COORDINATE_INSTRUCTIONS,
            quantity="compiler.instruction_count",
            unit="instruction",
            direction=Direction.MINIMIZE,
            accounting_scope="per-invocation",
        ),
    ),
    technology_context="an abstract single-address-space machine with no memory hierarchy",
)

#: The reference operator DAG.  ``load_input`` feeds both ``scale`` and
#: ``bias``, which is what makes inlining it a genuine trade rather than a free
#: win: the consumer outside the fused pair must recompute it.
REFERENCE_DAG: Dict[str, Any] = {
    "operators": {
        "load_input": {"instructions": "6", "output_words": "8", "consumes": []},
        "scale": {"instructions": "4", "output_words": "2", "consumes": ["load_input"]},
        "const_bias": {"instructions": "2", "output_words": "6", "consumes": []},
        "bias": {
            "instructions": "3",
            "output_words": "1",
            "consumes": ["const_bias", "load_input"],
        },
    },
    "declared_order": ["load_input", "scale", "const_bias", "bias"],
    "max_reorderings": 1,
    "fusion_saving_share": "1/2",
    "memory_capacity_words": "24",
}


# ---------------------------------------------------------------------------
# the declared DAG, read exactly
# ---------------------------------------------------------------------------


class _OperatorDag:
    """The declared DAG, read once and held in sorted, exact form."""

    def __init__(self, raw: Mapping[str, Any]) -> None:
        operators = raw.get("operators")
        order = raw.get("declared_order")
        if not operators or not order:
            raise GeneratorError(
                f"{OPERATOR_DAG_KEY} MUST declare both 'operators' and 'declared_order'; an "
                "empty declaration would make an empty family look like a closed one "
                "(spec 6.6)"
            )
        self.names: Tuple[str, ...] = tuple(str(name) for name in order)
        if sorted(self.names) != sorted(str(k) for k in operators):
            raise GeneratorError(
                "the declared order and the operator set disagree; a schedule over operators "
                "the DAG does not declare has no meaning (spec 19.1)"
            )
        self.instructions: Dict[str, Exact] = {}
        self.output_words: Dict[str, Exact] = {}
        self.consumes: Dict[str, Tuple[str, ...]] = {}
        for name in sorted(self.names):
            body = operators[name]
            self.instructions[name] = Exact(body["instructions"])
            self.output_words[name] = Exact(body["output_words"])
            self.consumes[name] = tuple(sorted(str(c) for c in body.get("consumes", ())))
        for name in sorted(self.names):
            for producer in self.consumes[name]:
                if producer not in self.instructions:
                    raise GeneratorError(
                        f"operator {name!r} consumes undeclared operator {producer!r}"
                    )
        self.consumers: Dict[str, Tuple[str, ...]] = {
            name: tuple(
                sorted(other for other in self.names if name in self.consumes[other])
            )
            for name in sorted(self.names)
        }
        self.max_reorderings = as_index(raw.get("max_reorderings", 0))
        self.fusion_saving_share = Exact(raw.get("fusion_saving_share", "0"))
        capacity = raw.get("memory_capacity_words")
        self.memory_capacity = None if capacity is None else Exact(capacity)
        self.declared_index = {name: i for i, name in enumerate(self.names)}

    def depends_on(self, later: str, earlier: str) -> bool:
        """True when ``later`` transitively consumes ``earlier``."""
        frontier: List[str] = list(self.consumes[later])
        seen: Set[str] = set()
        while frontier:
            current = frontier.pop()
            if current in seen:
                continue
            seen.add(current)
            if current == earlier:
                return True
            frontier.extend(self.consumes[current])
        return False

    def independent(self, first: str, second: str) -> bool:
        return not self.depends_on(first, second) and not self.depends_on(second, first)

    @property
    def universe_note(self) -> str:
        return (
            f"the closure of the declared schedule, fusion, and materialization "
            f"transformations over the {len(self.names)}-operator declared DAG"
        )


def _dag(context: GenerationContext) -> _OperatorDag:
    return _OperatorDag(read_model(context, OPERATOR_DAG_KEY))


def encode_schedule(schedule: Sequence[str]) -> str:
    """Canonical schedule text: operator identifiers, ``,``-joined, in order."""
    return ",".join(str(name) for name in schedule)


def decode_schedule(text: str) -> Tuple[str, ...]:
    return tuple(part for part in str(text).split(",") if part)


# ---------------------------------------------------------------------------
# the exact cost model
# ---------------------------------------------------------------------------


def schedule_signature(
    schedule: Sequence[str],
    fused_pair: str,
    inlined_value: str,
    dag: _OperatorDag,
    schema: CoordinateSchema,
) -> Signature:
    """Exact peak live memory and exact instruction count of one realization.

    Both coordinates are exact rationals.  Peak live memory is a maximum over
    steps of a sum of declared word counts; the instruction count is a sum of
    declared integers less a *rational* share of the fused consumer's overhead,
    so ``27/2`` is a value this model actually produces and a float would only
    approximate.
    """
    positions = {name: index for index, name in enumerate(schedule)}
    if sorted(positions) != sorted(dag.names):
        raise GeneratorError(
            f"schedule {encode_schedule(schedule)!r} is not a permutation of the declared "
            "operator set"
        )

    # -- peak live memory
    occupancy: List[Exact] = [Exact(0) for _ in schedule]
    for name in sorted(dag.names):
        if name == inlined_value:
            continue  # an inlined value never occupies memory between steps
        start = positions[name]
        consumers = dag.consumers[name]
        if consumers:
            end = max(positions[c] for c in consumers)
        else:
            end = start  # a result is written out at the step that produces it
        size = dag.output_words[name]
        for step in range(start, end + 1):
            occupancy[step] = occupancy[step] + size
    peak = occupancy[0]
    for value in occupancy[1:]:
        if value > peak:
            peak = value

    # -- instruction count
    instructions = Exact(0)
    for name in sorted(dag.names):
        instructions = instructions + dag.instructions[name]
    if fused_pair:
        producer, consumer = decode_pair(fused_pair)
        instructions = instructions - dag.fusion_saving_share * dag.instructions[consumer]
        if inlined_value:
            outside = [c for c in dag.consumers[inlined_value] if c != consumer]
            for _ in outside:
                instructions = instructions + dag.instructions[inlined_value]
    return _signature(schema, {COORDINATE_PEAK_MEMORY: peak, COORDINATE_INSTRUCTIONS: instructions})


def _signature(schema: CoordinateSchema, values: Mapping[str, Exact]) -> Signature:
    missing = [i for i in schema.identifiers if i not in values]
    if missing:
        raise GeneratorError(
            f"the declared schema has coordinates {missing} this pack does not produce; a "
            "signature has no optional components (spec 19.1)"
        )
    return Signature([values[identifier] for identifier in schema.identifiers])


def encode_pair(producer: str, consumer: str) -> str:
    return f"{producer}>{consumer}"


def decode_pair(text: str) -> Tuple[str, str]:
    producer, _, consumer = str(text).partition(">")
    if not producer or not consumer:
        raise GeneratorError(f"malformed fused pair {text!r}")
    return producer, consumer


# ---------------------------------------------------------------------------
# legality (spec 28.6: a resource refusal is INFEASIBLE, never ILLEGAL)
# ---------------------------------------------------------------------------


def memory_capacity_predicate(version: str = "1") -> LegalityPredicate:
    """Refuse a schedule whose peak live memory exceeds the declared capacity.

    The verdict is ``INFEASIBLE``, not ``ILLEGAL``: the schedule is a perfectly
    well-formed program, it simply does not fit in this machine.  It might fit
    in another one, and 28.6 requires that difference to stay visible.  When
    the model declares no capacity the verdict is ``UNSUPPORTED`` -- the
    predicate applies, and it cannot decide.
    """

    def evaluate(realization: RealizationRecord, context: Mapping[str, Any]) -> Any:
        model = context.get("parameters", {}).get(OPERATOR_DAG_KEY)
        if not isinstance(model, Mapping) or model.get("memory_capacity_words") is None:
            return (
                LegalityStatus.UNSUPPORTED,
                f"the declared {OPERATOR_DAG_KEY!r} carries no 'memory_capacity_words'; this "
                "predicate applies but cannot decide",
            )
        capacity = Exact(model["memory_capacity_words"])
        identifiers = [c["identifier"] for c in context.get("schema", {}).get("coordinates", ())]
        index = identifiers.index(COORDINATE_PEAK_MEMORY)
        peak = realization.signature[index]
        if peak > capacity:
            return (
                LegalityStatus.INFEASIBLE,
                f"peak live memory {peak} words exceeds the declared capacity {capacity} "
                "words; the schedule is constructible but not realizable on this machine",
            )
        return True

    return LegalityPredicate(
        predicate_id="crg-generate.reference.compiler-graph.memory-capacity",
        version=version,
        description="peak live memory fits the declared memory capacity",
        evaluate=evaluate,
        required_context=("parameters",),
        false_status=LegalityStatus.INFEASIBLE,
        evidence_class=EvidenceClass.EXACT,
    )


# ---------------------------------------------------------------------------
# the generator (spec 28.4)
# ---------------------------------------------------------------------------


class OperatorDagGenerator:
    """Alternative schedules and fusions of a declared operator DAG.

    Satisfies :class:`crg_generate.generator.Generator` structurally: it
    exposes a :class:`GeneratorDefinition` and a ``propose``.  Core knows
    nothing about it, which is exactly specification 6.7's requirement that a
    third party add a generator without editing ``crg-core``.
    """

    def __init__(
        self,
        *,
        identity: str = PACK_IDENTITY,
        version: str = PACK_VERSION,
        failure_semantics: str = FailureSemantics.SKIP_AND_RECORD,
    ) -> None:
        self.definition = GeneratorDefinition(
            identity=identity,
            version=version,
            accepted_source_types=("OPERATOR_DAG", "EXPLICIT_RECORDS"),
            transformations=(
                TRANSFORMATION_FUSE,
                TRANSFORMATION_INLINE,
                TRANSFORMATION_REORDER,
            ),
            semantic_rule=SemanticRule.SEMANTICS_PRESERVING,
            semantic_rule_detail=(
                "fusing, inlining, and reordering change where and when a value is computed "
                "and held, never which value is computed; the operator set, the dependency "
                "relation, and every operator's declared result are invariants of all three "
                "transformations"
            ),
            determinism_status=DeterminismStatus.DETERMINISTIC,
            failure_semantics=failure_semantics,
            completeness_implications=CompletenessImplication(
                closes_family=True,
                rationale=(
                    "fusion fires at most once per path, inlining fires at most once and only "
                    "after a fusion, and reordering advances a bounded counter towards the "
                    "declared max_reorderings; the triple (fused, inlined, reorderings) never "
                    "decreases and is bounded above, so the transitive closure of the declared "
                    "transformation set is finite and its fixpoint enumerates every schedule "
                    "these transformations can reach from the declared seed"
                ),
            ),
            conformance_tests=(
                "test_every_reference_pack_reaches_a_generator_closed_basis",
                "test_every_reference_pack_worked_example_matches_its_generator",
                "test_compiler_graph_trades_live_memory_against_instructions",
            ),
            legality_predicates=(
                nonnegative_signature_predicate(),
                memory_capacity_predicate(),
            ),
            capability_gates=(),
            obligation_types=(ObligationType.RESOURCE, ObligationType.ACCOUNTING),
            obligation_extractor=self._obligations,
            parent_child_relation=ParentChildRelation.CHILD_ALTERNATIVE_TO_PARENT,
            dependencies=(f"context:{OPERATOR_DAG_KEY}",),
            witness_method=WitnessMethod.CONSTRUCTIVE_TRANSFORMATION,
            required_permissions=GENERATOR_PERMISSIONS,
        )

    # -- the generator contract ----------------------------------------
    def propose(
        self, parent: RealizationRecord, context: GenerationContext
    ) -> Iterable[RealizationRecord]:
        dag = _dag(context)
        schedule = decode_schedule(parent.attributes.get(ATTR_SCHEDULE, ""))
        if not schedule:
            return []
        fused = as_flag(parent.attributes.get(ATTR_FUSED_PAIR, ""))
        inlined = as_flag(parent.attributes.get(ATTR_INLINED_VALUE, ""))
        reorderings = as_index(parent.attributes.get(ATTR_REORDERINGS, 0))
        children: List[RealizationRecord] = []

        # (1) fuse an adjacent producer/consumer pair -- at most one fusion.
        if not fused:
            for position in range(len(schedule) - 1):
                producer, consumer = schedule[position], schedule[position + 1]
                if producer not in dag.consumes[consumer]:
                    continue
                attributes = carried_attributes(parent)
                attributes[ATTR_FUSED_PAIR] = encode_pair(producer, consumer)
                children.append(
                    self._child(
                        parent, context, dag, TRANSFORMATION_FUSE, schedule, attributes
                    )
                )

        # (2) inline the fused intermediate -- store versus recompute.
        if fused and not inlined:
            producer, _consumer = decode_pair(fused)
            attributes = carried_attributes(parent)
            attributes[ATTR_INLINED_VALUE] = producer
            children.append(
                self._child(
                    parent, context, dag, TRANSFORMATION_INLINE, schedule, attributes
                )
            )

        # (3) reorder an adjacent independent pair -- bounded, one direction.
        if not fused and reorderings < dag.max_reorderings:
            for position in range(len(schedule) - 1):
                left, right = schedule[position], schedule[position + 1]
                if not dag.independent(left, right):
                    continue
                if dag.declared_index[left] >= dag.declared_index[right]:
                    # Only a swap that increases the inversion count relative to
                    # the declared order is admissible; that makes the reorder
                    # relation a strict partial order and the closure finite.
                    continue
                reordered = list(schedule)
                reordered[position], reordered[position + 1] = right, left
                attributes = carried_attributes(parent)
                attributes[ATTR_REORDERINGS] = reorderings + 1
                children.append(
                    self._child(
                        parent,
                        context,
                        dag,
                        TRANSFORMATION_REORDER,
                        tuple(reordered),
                        attributes,
                    )
                )
        return children

    def _child(
        self,
        parent: RealizationRecord,
        context: GenerationContext,
        dag: _OperatorDag,
        transformation: str,
        schedule: Sequence[str],
        attributes: Dict[str, Any],
    ) -> RealizationRecord:
        attributes[ATTR_SCHEDULE] = encode_schedule(schedule)
        signature = schedule_signature(
            schedule,
            as_flag(attributes.get(ATTR_FUSED_PAIR, "")),
            as_flag(attributes.get(ATTR_INLINED_VALUE, "")),
            dag,
            context.schema,
        )
        return propose_record(
            parent=parent,
            definition=self.definition,
            transformation=transformation,
            signature=signature,
            attributes=attributes,
            evidence_class=EvidenceClass.CONSTRUCTIVE,
        )

    # -- obligation extraction (spec 28.3 step 8) ------------------------
    def _obligations(
        self, record: RealizationRecord, context: GenerationContext
    ) -> Sequence[Obligation]:
        dag = _dag(context)
        inlined = as_flag(record.attributes.get(ATTR_INLINED_VALUE, ""))
        materialized = [
            name
            for name in sorted(dag.names)
            if dag.consumers[name] and name != inlined
        ]
        obligations: List[Obligation] = []
        for coordinate, value in zip(context.schema.coordinates, record.signature.values):
            obligations.append(
                Obligation(
                    obligation_type=ObligationType.RESOURCE,
                    realization_id=record.realization_id,
                    name=coordinate.identifier,
                    value=value,
                    unit=coordinate.unit,
                    scope=coordinate.accounting_scope,
                    evidence_class=EvidenceClass.EXACT,
                    source=self.definition.qualified_id,
                )
            )
        obligations.append(
            Obligation(
                obligation_type=ObligationType.ACCOUNTING,
                realization_id=record.realization_id,
                name="materialized_intermediates",
                value=Exact(len(materialized)),
                unit="value",
                scope="per-invocation",
                evidence_class=EvidenceClass.EXACT,
                source=self.definition.qualified_id,
            )
        )
        return obligations


def compiler_graph_generator(**kwargs: Any) -> OperatorDagGenerator:
    """The reference compiler-graph generator (spec 36.5 pack 2)."""
    return OperatorDagGenerator(**kwargs)


def compiler_graph_seed(
    context: GenerationContext, *, source_id: str = "compiler-graph-seed"
) -> RealizationRecord:
    """The seed realization: the declared order, unfused, everything materialized."""
    dag = _dag(context)
    schedule = dag.names
    return seed_record(
        source_id=source_id,
        signature=schedule_signature(schedule, "", "", dag, context.schema),
        attributes={
            ATTR_SCHEDULE: encode_schedule(schedule),
            ATTR_FUSED_PAIR: "",
            ATTR_INLINED_VALUE: "",
            ATTR_REORDERINGS: 0,
        },
        evidence_class=EvidenceClass.CONSTRUCTIVE,
    )


# ---------------------------------------------------------------------------
# manifest (spec 36.2) and pack contents (spec 36.4)
# ---------------------------------------------------------------------------

TERMINOLOGY: Dict[str, str] = {
    "operator": "one node of the declared computation DAG, with an instruction count and "
    "an output size in words",
    "schedule": "a topological order of the operators; the order in which the machine runs "
    "them",
    "fusion": "running a producer and its consumer as one loop nest, removing a declared "
    "share of the consumer's loop overhead",
    "materialized intermediate": "a value written to memory between the step that produces "
    "it and the step that consumes it",
    "inlined intermediate": "a value never written to memory; every consumer outside the "
    "fused region recomputes it",
    "peak live memory": "the maximum over steps of the total size of the values occupying "
    "memory at that step",
}


def manifest_data() -> Dict[str, Any]:
    """The pack as a manifest mapping, loadable by :func:`crg_generate.load_pack`."""
    fields = manifest_fields(
        identity=PACK_IDENTITY,
        external_dependencies=(
            "crg-model (exact rationals, records, canonicalization)",
            "crg-generate (generator contract, legality, registry)",
        ),
        resource_requirements={
            "memory_mb": 32,
            "wall_clock_seconds": 1,
            "processes": 1,
            "network": "none",
        },
        failure_modes=(
            "SKIP_AND_RECORD: a parent whose schedule attribute is absent or malformed "
            "yields no child and is recorded as an UNGENERATED region, never as an "
            "infeasible one (spec 28.4)",
            "INFEASIBLE: a schedule whose exact peak live memory exceeds the declared "
            "memory capacity is refused by a legality predicate, not by the generator",
            "UNSUPPORTED: a context declaring no memory capacity leaves the capacity "
            "predicate undecided rather than permissive",
        ),
        quantity_registry_additions=(
            "compiler.peak_live_memory",
            "compiler.instruction_count",
            "compiler.materialized_intermediates",
        ),
        proof_implications=(
            "the closure of the three declared transformations is finite by a strict partial "
            "order on (fused, inlined, reorderings), so a fixpoint of this generator supports "
            "a GENERATOR_CLOSED completeness basis (spec 21.2)",
            "every coordinate and every obligation is an exact rational, so a decision over "
            "this family never rests on a floating-point comparison (spec 14.2, 22.6)",
            "this pack adds no proof checker and weakens no core certificate semantics "
            "(spec 36.4)",
        ),
        conformance_tests=(
            "test_every_reference_pack_loads_and_validates",
            "test_every_reference_pack_reaches_a_generator_closed_basis",
            "test_every_reference_pack_worked_example_matches_its_generator",
            "test_compiler_graph_trades_live_memory_against_instructions",
        ),
        provenance={
            "repository": "CRGsys",
            "module": "crg_generate.reference_packs.compiler_graph",
            "specification": "36.5 initial reference pack 2 (compiler-graph)",
            "derivation": "first-party reference implementation; no imported registry",
        },
    )
    fields["contents"] = {
        "terminology": TERMINOLOGY,
        "quantities": {
            "compiler.peak_live_memory": "word",
            "compiler.instruction_count": "instruction",
            "compiler.materialized_intermediates": "value",
        },
        "contracts": {
            "computation_contract": "the declared operator DAG: operators, instruction "
            "counts, output word counts, and the consumes relation",
            "resource_contract": "a single flat address space of declared "
            "memory_capacity_words words",
        },
        "accounting_rules": {
            "peak_live_memory": "maximum over steps of the sum of occupancies; a result is "
            "written out at its producing step, an inlined value never occupies memory",
            "instruction_count": "sum of declared instruction counts, less "
            "fusion_saving_share of the fused consumer's instructions, plus one "
            "recomputation of an inlined producer per consumer outside the fused pair",
        },
        "transformations": [
            TRANSFORMATION_FUSE,
            TRANSFORMATION_INLINE,
            TRANSFORMATION_REORDER,
        ],
        "obligation_coordinates": [
            COORDINATE_PEAK_MEMORY,
            COORDINATE_INSTRUCTIONS,
            "materialized_intermediates",
        ],
        "technology_coordinates": [
            "flat-address-space",
            "no-memory-hierarchy",
            "single-issue",
        ],
        "evaluators": ["crg_generate.reference_packs.compiler_graph.schedule_signature"],
        "qualification_methods": [
            "exact re-evaluation of the declared cost model from the recorded schedule, "
            "fusion, and materialization attributes"
        ],
        "proof_checkers": [],
        "ui_extensions": [],
        "example_cases": ["four-operator-dag-with-one-shared-producer"],
        "conformance_fixtures": [
            "fixture: the seed schedule load_input,scale,const_bias,bias with everything "
            "materialized has signature (15, 15)",
            "fixture: fusing load_input>scale and inlining load_input yields (7, 19) -- "
            "peak memory falls and instructions rise, in opposite directions",
            "fixture: fusing const_bias>bias yields the exact rational instruction count "
            "27/2, which no binary float represents",
        ],
    }
    fields["extensions"] = {"generators": [compiler_graph_generator()]}
    return fields


def worked_example() -> WorkedExample:
    """The pack's worked example: seed, context, and the result it claims."""
    context = GenerationContext(
        schema=SCHEMA,
        capabilities={},
        parameters={OPERATOR_DAG_KEY: REFERENCE_DAG},
        permissions=tuple(GENERATOR_PERMISSIONS),
        declared_universe=_OperatorDag(REFERENCE_DAG).universe_note,
        validity="the declared operator DAG and its declared memory capacity",
    )
    seed = compiler_graph_seed(context)
    source = GenerationSource(
        source_id="compiler-graph-reference-dag",
        source_type="OPERATOR_DAG",
        seeds=(seed,),
        computation_contract={"contract_id": "compiler-graph.dag", "version": "1"},
        resource_contract={"contract_id": "compiler-graph.flat-memory", "version": "1"},
        declared_universe=_OperatorDag(REFERENCE_DAG).universe_note,
    )
    return WorkedExample(
        name="four-operator-dag-with-one-shared-producer",
        description=(
            "load_input feeds both scale and bias; const_bias feeds bias. Fusing "
            "load_input>scale and then inlining load_input removes 8 words of live memory "
            "and adds one recomputation of load_input for bias, which is the "
            "store-versus-recompute trade made visible in two coordinates."
        ),
        schema=SCHEMA,
        source=source,
        context=context,
        expected_realization_count=6,
        expected_legal_count=6,
        expected_signatures=(
            ("10", "27/2"),
            ("15", "13"),
            ("15", "15"),
            ("15", "27/2"),
            ("16", "15"),
            ("7", "19"),
        ),
        decision_query={
            "id": "compiler-graph-schedule-choice",
            "objective_family": {
                "type": "weighted_sum",
                "weights": {COORDINATE_PEAK_MEMORY: "1", COORDINATE_INSTRUCTIONS: "1"},
            },
            "quantification": "EACH_OBJECTIVE",
            "ties": {"policy_tolerance": "0", "retain_all": True},
        },
        notes=(
            "the six realizations are the seed, one reordering, two fusions, and the "
            "inlined variant of each fusion",
            "instruction counts 13 and 27/2 are exact rationals produced by a "
            "fusion_saving_share of 1/2",
        ),
    )
