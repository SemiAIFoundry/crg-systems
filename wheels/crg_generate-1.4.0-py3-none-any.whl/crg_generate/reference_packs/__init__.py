"""The seven initial reference domain packs of specification 36.5.

Normative basis: master specification 36.5 ("the initial distribution SHOULD
include ... a generic finite-realization pack; a compiler-graph pack; a
distributed-computation pack; an AI-system realization pack; an
advanced-packaging pack; a materials and process-evidence pack; and a
layout-conversion pack"), read against 36.2 (plugin manifest), 36.4
(domain-pack contents), 6.7 (extensibility without core modification), 3.3
(domain neutrality), and 21 (completeness basis).

All seven are here, all seven carry a complete 36.2 manifest, and all seven
load through the same :func:`crg_generate.packs.load_pack`.  Two of them --
the generic finite-realization pack and the distributed-computation pack --
wrap generators that already existed in :mod:`crg_generate.reference`; their
identities, their behaviour, and their definition hashes are unchanged, and
what those two modules add is the manifest without which a generator is not a
*pack*.

What "uniformly loadable" buys
------------------------------
A host can enumerate the reference packs, load any of them from its manifest
data, validate it, and build its registry without knowing which one it has::

    for name in reference_pack_names():
        pack = load_reference_pack(name)
        assert validate_pack(pack) == []
        bundle, report = build_pack_registry(pack)
        assert report.completeness_basis.basis_type == "GENERATOR_CLOSED"

That loop is the whole content of 6.7's promise: seven generators over seven
unrelated domains, none of them known to :mod:`crg_generate.generator`,
:mod:`crg_generate.legality`, :mod:`crg_generate.registry`, or
:mod:`crg_generate.packs`, and core carrying no word of any of their
vocabularies.

The seven packs, and what each one demonstrates
-----------------------------------------------
======  ==============================  ===============================================
36.5    pack name                        what it is the falsifier for
======  ==============================  ===============================================
1       generic-finite-realization       rules stated over coordinate identifiers only
2       compiler-graph                   store-versus-recompute inside one process
3       distributed-computation          the same core with no compiler and no silicon
4       ai-system-realization            partitioning crossed with recomputation
5       advanced-packaging               three realization classes that trade three ways
6       materials-process-evidence       the evidence classes of 5.3 doing real work
7       layout-conversion                exact retained and residual measures (31.2)
======  ==============================  ===============================================

Every pack is deterministic, exact-rational throughout, and carries a stated
termination argument in its module docstring, because a generator whose
closure is infinite can never be ``GENERATOR_CLOSED``.
"""
from __future__ import annotations

from dataclasses import dataclass
from types import ModuleType
from typing import Any, Dict, List, Tuple, Union

from crg_model.records import RealizationBundle

from ..packs import DomainPack, PackError, load_pack
from ..registry import GenerationReport, build_registry
from . import (
    advanced_packaging,
    ai_system,
    compiler_graph,
    distributed,
    generic_finite,
    layout_conversion,
    materials_process,
)
from ._common import (
    GENERATOR_PERMISSIONS,
    PACK_PERMISSIONS,
    PACK_VERSION,
    WorkedExample,
    signature_strings,
)

__all__ = [
    "ReferencePackEntry",
    "ALL_PACKS",
    "REFERENCE_PACK_MODULES",
    "reference_pack_names",
    "reference_pack_entry",
    "reference_pack_manifest",
    "load_reference_pack",
    "load_all_reference_packs",
    "reference_pack_example",
    "build_pack_registry",
    "WorkedExample",
    "PACK_PERMISSIONS",
    "GENERATOR_PERMISSIONS",
    "PACK_VERSION",
    "signature_strings",
]


@dataclass(frozen=True)
class ReferencePackEntry:
    """One row of the reference-pack registry.

    ``spec_index`` is the pack's number in the enumeration of 36.5, kept
    explicitly so that the mapping from specification text to shipped artefact
    is checkable rather than inferred from the order of a list.
    """

    spec_index: int
    name: str
    module: ModuleType

    @property
    def identity(self) -> str:
        return str(self.module.PACK_IDENTITY)

    def manifest_data(self) -> Dict[str, Any]:
        """The pack's manifest mapping, freshly built (spec 36.2)."""
        return self.module.manifest_data()

    def load(self) -> DomainPack:
        """Load the pack from its manifest data (spec 36.2, 36.4)."""
        return load_pack(self.manifest_data())

    def worked_example(self) -> WorkedExample:
        """The pack's worked example (spec 36.4 "example cases")."""
        return self.module.worked_example()


#: The seven packs of 36.5, in the specification's own order.
ALL_PACKS: Tuple[ReferencePackEntry, ...] = (
    ReferencePackEntry(1, generic_finite.PACK_NAME, generic_finite),
    ReferencePackEntry(2, compiler_graph.PACK_NAME, compiler_graph),
    ReferencePackEntry(3, distributed.PACK_NAME, distributed),
    ReferencePackEntry(4, ai_system.PACK_NAME, ai_system),
    ReferencePackEntry(5, advanced_packaging.PACK_NAME, advanced_packaging),
    ReferencePackEntry(6, materials_process.PACK_NAME, materials_process),
    ReferencePackEntry(7, layout_conversion.PACK_NAME, layout_conversion),
)

REFERENCE_PACK_MODULES: Tuple[ModuleType, ...] = tuple(e.module for e in ALL_PACKS)

_BY_NAME: Dict[str, ReferencePackEntry] = {e.name: e for e in ALL_PACKS}
_BY_IDENTITY: Dict[str, ReferencePackEntry] = {e.identity: e for e in ALL_PACKS}


def reference_pack_names() -> Tuple[str, ...]:
    """The seven pack names, in the order of specification 36.5."""
    return tuple(entry.name for entry in ALL_PACKS)


def reference_pack_entry(
    pack: Union[str, ReferencePackEntry, DomainPack]
) -> ReferencePackEntry:
    """Resolve a pack name, entry, or loaded pack to its registry row."""
    if isinstance(pack, ReferencePackEntry):
        return pack
    if isinstance(pack, DomainPack):
        entry = _BY_IDENTITY.get(pack.manifest.identity)
        if entry is None:
            raise PackError(
                f"domain pack {pack.qualified_id} is not one of the reference packs of "
                f"specification 36.5; the reference identities are {sorted(_BY_IDENTITY)}"
            )
        return entry
    name = str(pack)
    if name in _BY_NAME:
        return _BY_NAME[name]
    if name in _BY_IDENTITY:
        return _BY_IDENTITY[name]
    raise PackError(
        f"unknown reference pack {name!r}; the seven packs of specification 36.5 are "
        f"{list(reference_pack_names())}"
    )


def reference_pack_manifest(pack: Union[str, ReferencePackEntry]) -> Dict[str, Any]:
    """The manifest mapping of one reference pack (spec 36.2)."""
    return reference_pack_entry(pack).manifest_data()


def load_reference_pack(pack: Union[str, ReferencePackEntry]) -> DomainPack:
    """Load one reference pack from its manifest data.

    The pack is built by :func:`crg_generate.packs.load_pack` from a mapping,
    exactly as a third-party pack read from a file would be, so the round trip
    through the manifest is the loading path and not a shortcut around it.
    """
    return reference_pack_entry(pack).load()


def load_all_reference_packs(*, require_valid: bool = False) -> Tuple[DomainPack, ...]:
    """Load all seven packs; optionally fail closed on the first inadmissible one."""
    packs: List[DomainPack] = []
    for entry in ALL_PACKS:
        loaded = entry.load()
        if require_valid:
            loaded.require_valid()
        packs.append(loaded)
    return tuple(packs)


def reference_pack_example(
    pack: Union[str, ReferencePackEntry, DomainPack]
) -> WorkedExample:
    """The worked example of one reference pack (spec 36.4)."""
    return reference_pack_entry(pack).worked_example()


def build_pack_registry(
    pack: Union[str, ReferencePackEntry, DomainPack],
    **kwargs: Any,
) -> Tuple[RealizationBundle, GenerationReport]:
    """Build the realization registry of one reference pack's worked example.

    The generators are the pack's own -- the ones its manifest declared under
    ``extensions`` -- and the schema, seeds, and generation context are its
    worked example's.  Nothing here is special-cased per pack: this function is
    the demonstration that one host loop drives all seven (spec 6.7).

    The completeness basis is *derived* by :func:`crg_generate.build_registry`
    from what generation actually did, and this function neither passes nor
    accepts a hint that could strengthen it (spec 21.3, 28.3 step 10).
    """
    entry = reference_pack_entry(pack)
    loaded = pack if isinstance(pack, DomainPack) else entry.load()
    example = entry.worked_example()
    return build_registry(
        example.source,
        generators=list(loaded.generators),
        schema=example.schema,
        context=example.context,
        **kwargs,
    )
