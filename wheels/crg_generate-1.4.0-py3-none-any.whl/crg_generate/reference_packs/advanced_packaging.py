"""Reference domain pack 5 of specification 36.5: the advanced-packaging pack.

Normative basis: master specification 36.5 ("an advanced-packaging pack"),
36.4 (domain-pack contents), 36.2 (plugin manifest), 28.4 (generator contract),
and 3.3 (domain neutrality).

**This pack is a reference application, not a dependency of CRG Core.**  That
sentence is the specification's own, and it is the point of the pack: 36.5
closes with it precisely so that nobody reads the presence of a
semiconductor-packaging example as evidence that the core is a semiconductor
tool.  Nothing in :mod:`crg_generate.generator`, :mod:`crg_generate.legality`,
:mod:`crg_generate.registry`, or :mod:`crg_generate.packs` imports this module,
mentions any word in it, or would behave differently if it were deleted.  The
pack test suite asserts that by grepping core for this pack's vocabulary.

What the pack models
--------------------
A realization is one *packaging arrangement* of a fixed amount of active
silicon, in the three classes the specification's realization vocabulary
names:

``FUSED``
    One monolithic die carrying the whole design.  Smallest interconnect
    energy, because no signal leaves the die.  Worst yield-driven cost,
    because the whole area must be defect-free at once.
``SPLIT``
    The design cut into chiplets placed side by side on an interposer (a 2.5D
    arrangement).  Yield per die improves as the square of the shrinking area,
    so cost falls; footprint grows by a keep-out margin per die and
    interconnect energy grows with the long lateral links.
``VERTICAL``
    The same chiplets stacked (a 3D arrangement).  Footprint collapses to one
    die's area plus a single margin, and interconnect energy collapses because
    the vertical links are two orders of magnitude shorter than lateral ones;
    the bonding and stacked-test cost rises to pay for it.

Three transformations generate the family:
``split-into-chiplets`` (FUSED to SPLIT), ``refine-chiplet-partition`` (a
bounded advance along the declared partition-count list), and
``stack-vertically`` (SPLIT to VERTICAL).

The exact cost model, stated once
---------------------------------
With total active area ``A``, defect density ``d``, and ``n`` dies of area
``A/n`` each, the yield model is the Bose-Einstein (Seeds) form::

    Y(n) = 1 / (1 + (A/n) * d) ** 2

which is an exact rational for rational ``A`` and ``d``.  At ``A = 100`` and
``d = 1/100`` it gives ``1/4``, ``4/9``, and ``16/25`` for one, two, and four
dies.  Known-good-die cost is ``A / Y(n)``, so the four-die cost is ``625/4``
currency units -- an exact rational a binary float cannot hold.  Footprint,
interconnect energy, and assembled cost then follow the declared per-class
rules recorded in the pack's ``accounting_rules``.

Termination
-----------
The closure is finite by a strict partial order on ``(arrangement,
refinements)``:

1. ``split-into-chiplets`` requires ``FUSED`` and leaves ``SPLIT``;
2. ``refine-chiplet-partition`` requires ``SPLIT`` and strictly advances the
   bounded ``refinements`` counter towards the model's declared
   ``max_refinements``;
3. ``stack-vertically`` requires ``SPLIT`` and leaves ``VERTICAL``, which no
   rule accepts.

The arrangement therefore moves only forwards through FUSED, SPLIT, VERTICAL
and the refinement counter only upwards, so no path is infinite (spec 21.2,
6.11).
"""
from __future__ import annotations

from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple

from crg_model.envelope import EvidenceClass
from crg_model.numeric import Exact
from crg_model.records import (
    Coordinate,
    CoordinateSchema,
    Direction,
    RealizationRecord,
    Signature,
)

from ..generator import (
    CompletenessImplication,
    DeterminismStatus,
    FailureSemantics,
    GenerationContext,
    GeneratorDefinition,
    GeneratorError,
    Obligation,
    ObligationType,
    ParentChildRelation,
    SemanticRule,
    WitnessMethod,
    propose_record,
    seed_record,
)
from ..legality import LegalityPredicate, LegalityStatus
from ..reference import nonnegative_signature_predicate
from ..registry import GenerationSource
from ._common import (
    GENERATOR_PERMISSIONS,
    PACK_VERSION,
    WorkedExample,
    as_flag,
    as_index,
    carried_attributes,
    manifest_fields,
    read_model,
)

__all__ = [
    "PACK_NAME",
    "SPEC_INDEX",
    "PACKAGING_MODEL_KEY",
    "ATTR_ARRANGEMENT",
    "ATTR_PARTITION_COUNT",
    "ATTR_REFINEMENTS",
    "ARRANGEMENT_FUSED",
    "ARRANGEMENT_SPLIT",
    "ARRANGEMENT_VERTICAL",
    "SCHEMA",
    "REFERENCE_PACKAGE",
    "AdvancedPackagingGenerator",
    "advanced_packaging_generator",
    "advanced_packaging_seed",
    "arrangement_signature",
    "known_good_die_yield",
    "yield_floor_predicate",
    "manifest_data",
    "worked_example",
]

PACK_NAME = "advanced-packaging"
SPEC_INDEX = 5
PACK_IDENTITY = "crg-generate.reference.advanced-packaging"

PACKAGING_MODEL_KEY = "packaging_model"

ATTR_ARRANGEMENT = "arrangement"
ATTR_PARTITION_COUNT = "partition_count"
ATTR_REFINEMENTS = "refinements"

#: The three realization classes 36.5's packaging example is about.
ARRANGEMENT_FUSED = "FUSED"
ARRANGEMENT_SPLIT = "SPLIT"
ARRANGEMENT_VERTICAL = "VERTICAL"

TRANSFORMATION_SPLIT = "split-into-chiplets"
TRANSFORMATION_REFINE = "refine-chiplet-partition"
TRANSFORMATION_STACK = "stack-vertically"

COORDINATE_AREA = "footprint_area"
COORDINATE_ENERGY = "interconnect_energy"
COORDINATE_COST = "assembled_cost"

SCHEMA = CoordinateSchema(
    coordinates=(
        Coordinate(
            identifier=COORDINATE_AREA,
            quantity="packaging.footprint_area",
            unit="mm2",
            direction=Direction.MINIMIZE,
            accounting_scope="per-package",
        ),
        Coordinate(
            identifier=COORDINATE_ENERGY,
            quantity="packaging.interconnect_energy",
            unit="pJ-per-transfer",
            direction=Direction.MINIMIZE,
            accounting_scope="per-package",
        ),
        Coordinate(
            identifier=COORDINATE_COST,
            quantity="packaging.assembled_cost",
            unit="currency-unit",
            direction=Direction.MINIMIZE,
            accounting_scope="per-package",
        ),
    ),
    technology_context="a declared defect density with a declared lateral and vertical link "
    "length",
)

REFERENCE_PACKAGE: Dict[str, Any] = {
    "active_area_mm2": "100",
    "defect_density_per_mm2": "1/100",
    "partition_counts": [1, 2, 4],
    "max_refinements": 1,
    "keep_out_margin_mm2": "6",
    "interposer_base_cost": "20",
    "attach_cost_per_die": "5",
    "stack_bond_cost_per_interface": "20",
    "stack_test_cost_per_die": "12",
    "intra_die_energy_pj": "4",
    "energy_per_mm_pj": "3",
    "lateral_link_length_mm": "5",
    "vertical_link_length_mm": "1/10",
    "yield_floor": "1/5",
}


# ---------------------------------------------------------------------------
# the declared package model, read exactly
# ---------------------------------------------------------------------------


class _PackagingModel:
    def __init__(self, raw: Mapping[str, Any]) -> None:
        counts = raw.get("partition_counts")
        if not counts:
            raise GeneratorError(
                f"{PACKAGING_MODEL_KEY} MUST declare 'partition_counts'; an empty declaration "
                "would make an empty family look like a closed one (spec 6.6)"
            )
        self.partition_counts: Tuple[int, ...] = tuple(int(c) for c in counts)
        if sorted(self.partition_counts) != list(self.partition_counts):
            raise GeneratorError(
                "'partition_counts' MUST be declared in ascending order; the refinement rule "
                "advances along it and a non-monotone list would not bound the closure"
            )
        self.active_area = Exact(raw["active_area_mm2"])
        self.defect_density = Exact(raw["defect_density_per_mm2"])
        self.max_refinements = as_index(raw.get("max_refinements", 0))
        self.keep_out_margin = Exact(raw["keep_out_margin_mm2"])
        self.interposer_base_cost = Exact(raw["interposer_base_cost"])
        self.attach_cost_per_die = Exact(raw["attach_cost_per_die"])
        self.stack_bond_cost = Exact(raw["stack_bond_cost_per_interface"])
        self.stack_test_cost = Exact(raw["stack_test_cost_per_die"])
        self.intra_die_energy = Exact(raw["intra_die_energy_pj"])
        self.energy_per_mm = Exact(raw["energy_per_mm_pj"])
        self.lateral_length = Exact(raw["lateral_link_length_mm"])
        self.vertical_length = Exact(raw["vertical_link_length_mm"])
        floor = raw.get("yield_floor")
        self.yield_floor = None if floor is None else Exact(floor)

    def next_partition_count(self, count: int) -> int:
        index = self.partition_counts.index(count)
        if index + 1 >= len(self.partition_counts):
            raise GeneratorError("no further declared partition count")
        return self.partition_counts[index + 1]

    def has_next_partition_count(self, count: int) -> bool:
        return count in self.partition_counts and self.partition_counts.index(count) + 1 < len(
            self.partition_counts
        )

    @property
    def universe_note(self) -> str:
        return (
            "the closure of the declared split, refine, and stack transformations over the "
            f"declared partition counts {list(self.partition_counts)} of a single declared "
            "active-silicon area"
        )


def _model(context: GenerationContext) -> _PackagingModel:
    return _PackagingModel(read_model(context, PACKAGING_MODEL_KEY))


# ---------------------------------------------------------------------------
# the exact cost model
# ---------------------------------------------------------------------------


def known_good_die_yield(partition_count: int, model: _PackagingModel) -> Exact:
    """Exact Bose-Einstein yield of one die of area ``A / n``.

    ``Y = 1 / (1 + (A/n) d) ** 2``.  For rational ``A`` and ``d`` this is a
    rational, and it is computed as one: at ``A = 100``, ``d = 1/100`` the
    four-die yield is exactly ``16/25``, not ``0.64`` (spec 14.2).
    """
    if partition_count < 1:
        raise GeneratorError("a partition count below one is not a package")
    die_area = model.active_area / Exact(partition_count)
    base = Exact(1) + die_area * model.defect_density
    return Exact(1) / (base * base)


def arrangement_signature(
    arrangement: str,
    partition_count: int,
    model: _PackagingModel,
    schema: CoordinateSchema,
) -> Signature:
    """Exact footprint area, interconnect energy, and assembled cost."""
    if arrangement not in (ARRANGEMENT_FUSED, ARRANGEMENT_SPLIT, ARRANGEMENT_VERTICAL):
        raise GeneratorError(
            f"unknown arrangement {arrangement!r}; declare one of "
            f"{[ARRANGEMENT_FUSED, ARRANGEMENT_SPLIT, ARRANGEMENT_VERTICAL]}"
        )
    count = Exact(partition_count)
    die_cost = model.active_area / known_good_die_yield(partition_count, model)
    crossings = count - Exact(1)

    if arrangement == ARRANGEMENT_FUSED:
        area = model.active_area
        energy = model.intra_die_energy
        assembly = Exact(0)
    elif arrangement == ARRANGEMENT_SPLIT:
        area = model.active_area + model.keep_out_margin * count
        energy = (
            model.intra_die_energy
            + crossings * model.lateral_length * model.energy_per_mm
        )
        assembly = model.interposer_base_cost + model.attach_cost_per_die * count
    else:
        area = model.active_area / count + model.keep_out_margin
        energy = (
            model.intra_die_energy
            + crossings * model.vertical_length * model.energy_per_mm
        )
        assembly = model.stack_bond_cost * crossings + model.stack_test_cost * count

    values = {
        COORDINATE_AREA: area,
        COORDINATE_ENERGY: energy,
        COORDINATE_COST: die_cost + assembly,
    }
    missing = [i for i in schema.identifiers if i not in values]
    if missing:
        raise GeneratorError(
            f"the declared schema has coordinates {missing} this pack does not produce; a "
            "signature has no optional components (spec 19.1)"
        )
    return Signature([values[identifier] for identifier in schema.identifiers])


# ---------------------------------------------------------------------------
# legality (spec 28.6)
# ---------------------------------------------------------------------------


def yield_floor_predicate(version: str = "1") -> LegalityPredicate:
    """Refuse an arrangement whose per-die yield is below the declared floor.

    ``INFEASIBLE``: the arrangement is constructible and its yield is known
    exactly; it simply cannot be manufactured economically under this declared
    defect density.  A different declared density admits it, so the verdict is
    context-relative and must not be reported as ``ILLEGAL`` (spec 28.6).
    """

    def evaluate(realization: RealizationRecord, context: Mapping[str, Any]) -> Any:
        raw = context.get("parameters", {}).get(PACKAGING_MODEL_KEY)
        if not isinstance(raw, Mapping) or raw.get("yield_floor") is None:
            return (
                LegalityStatus.UNSUPPORTED,
                f"the declared {PACKAGING_MODEL_KEY!r} carries no 'yield_floor'; this "
                "predicate applies but cannot decide",
            )
        model = _PackagingModel(raw)
        count = as_index(realization.attributes.get(ATTR_PARTITION_COUNT, 0))
        if count < 1:
            return (
                LegalityStatus.UNSUPPORTED,
                "the realization declares no partition count; this predicate cannot decide it",
            )
        value = known_good_die_yield(count, model)
        if value < model.yield_floor:
            return (
                LegalityStatus.INFEASIBLE,
                f"the per-die yield of a {count}-way arrangement is {value}, below the "
                f"declared floor {model.yield_floor}; the arrangement is constructible but "
                "not manufacturable at this declared defect density",
            )
        return True

    return LegalityPredicate(
        predicate_id="crg-generate.reference.advanced-packaging.yield-floor",
        version=version,
        description="the exact per-die yield meets the declared floor",
        evaluate=evaluate,
        required_context=("parameters",),
        false_status=LegalityStatus.INFEASIBLE,
        evidence_class=EvidenceClass.EXACT,
    )


# ---------------------------------------------------------------------------
# the generator (spec 28.4)
# ---------------------------------------------------------------------------


class AdvancedPackagingGenerator:
    """FUSED, SPLIT, and VERTICAL arrangements of one declared active area."""

    def __init__(
        self,
        *,
        identity: str = PACK_IDENTITY,
        version: str = PACK_VERSION,
        failure_semantics: str = FailureSemantics.SKIP_AND_RECORD,
    ) -> None:
        self.definition = GeneratorDefinition(
            identity=identity,
            version=version,
            accepted_source_types=("PACKAGING_MODEL", "EXPLICIT_RECORDS"),
            transformations=(
                TRANSFORMATION_SPLIT,
                TRANSFORMATION_REFINE,
                TRANSFORMATION_STACK,
            ),
            semantic_rule=SemanticRule.SEMANTICS_PRESERVING,
            semantic_rule_detail=(
                "splitting, refining, and stacking rearrange where the same declared active "
                "silicon sits and how its pieces are connected; the logical design, its "
                "active area, and the set of signals crossing between its pieces are "
                "invariants of all three transformations"
            ),
            determinism_status=DeterminismStatus.DETERMINISTIC,
            failure_semantics=failure_semantics,
            completeness_implications=CompletenessImplication(
                closes_family=True,
                rationale=(
                    "the arrangement moves only forwards through FUSED, SPLIT, VERTICAL and "
                    "the refinement counter only upwards towards the declared "
                    "max_refinements; the pair (arrangement, refinements) is therefore a "
                    "strict partial order on a finite set, the closure reaches a fixpoint, "
                    "and that fixpoint is every arrangement the declared transformations reach"
                ),
            ),
            conformance_tests=(
                "test_every_reference_pack_reaches_a_generator_closed_basis",
                "test_advanced_packaging_produces_three_distinguishable_classes",
            ),
            legality_predicates=(
                nonnegative_signature_predicate(),
                yield_floor_predicate(),
            ),
            capability_gates=(),
            obligation_types=(
                ObligationType.RESOURCE,
                ObligationType.ACCOUNTING,
                ObligationType.QUALIFICATION,
            ),
            obligation_extractor=self._obligations,
            parent_child_relation=ParentChildRelation.CHILD_ALTERNATIVE_TO_PARENT,
            dependencies=(f"context:{PACKAGING_MODEL_KEY}",),
            witness_method=WitnessMethod.CONSTRUCTIVE_TRANSFORMATION,
            required_permissions=GENERATOR_PERMISSIONS,
        )

    def propose(
        self, parent: RealizationRecord, context: GenerationContext
    ) -> Iterable[RealizationRecord]:
        model = _model(context)
        arrangement = as_flag(parent.attributes.get(ATTR_ARRANGEMENT, ""))
        if not arrangement:
            return []
        count = as_index(parent.attributes.get(ATTR_PARTITION_COUNT, 0))
        refinements = as_index(parent.attributes.get(ATTR_REFINEMENTS, 0))
        children: List[RealizationRecord] = []

        if arrangement == ARRANGEMENT_FUSED and model.has_next_partition_count(count):
            attributes = carried_attributes(parent)
            attributes[ATTR_ARRANGEMENT] = ARRANGEMENT_SPLIT
            attributes[ATTR_PARTITION_COUNT] = model.next_partition_count(count)
            children.append(
                self._child(parent, context, model, TRANSFORMATION_SPLIT, attributes)
            )

        if arrangement == ARRANGEMENT_SPLIT:
            if refinements < model.max_refinements and model.has_next_partition_count(count):
                attributes = carried_attributes(parent)
                attributes[ATTR_PARTITION_COUNT] = model.next_partition_count(count)
                attributes[ATTR_REFINEMENTS] = refinements + 1
                children.append(
                    self._child(parent, context, model, TRANSFORMATION_REFINE, attributes)
                )
            attributes = carried_attributes(parent)
            attributes[ATTR_ARRANGEMENT] = ARRANGEMENT_VERTICAL
            children.append(
                self._child(parent, context, model, TRANSFORMATION_STACK, attributes)
            )
        return children

    def _child(
        self,
        parent: RealizationRecord,
        context: GenerationContext,
        model: _PackagingModel,
        transformation: str,
        attributes: Dict[str, Any],
    ) -> RealizationRecord:
        signature = arrangement_signature(
            as_flag(attributes[ATTR_ARRANGEMENT]),
            as_index(attributes[ATTR_PARTITION_COUNT]),
            model,
            context.schema,
        )
        return propose_record(
            parent=parent,
            definition=self.definition,
            transformation=transformation,
            signature=signature,
            attributes=attributes,
            evidence_class=EvidenceClass.CONSTRUCTIVE,
        )

    def _obligations(
        self, record: RealizationRecord, context: GenerationContext
    ) -> Sequence[Obligation]:
        model = _model(context)
        count = as_index(record.attributes.get(ATTR_PARTITION_COUNT, 1))
        obligations: List[Obligation] = []
        types = {
            COORDINATE_AREA: ObligationType.RESOURCE,
            COORDINATE_ENERGY: ObligationType.RESOURCE,
            COORDINATE_COST: ObligationType.ACCOUNTING,
        }
        for coordinate, value in zip(context.schema.coordinates, record.signature.values):
            obligations.append(
                Obligation(
                    obligation_type=types[coordinate.identifier],
                    realization_id=record.realization_id,
                    name=coordinate.identifier,
                    value=value,
                    unit=coordinate.unit,
                    scope=coordinate.accounting_scope,
                    evidence_class=EvidenceClass.EXACT,
                    source=self.definition.qualified_id,
                )
            )
        obligations.append(
            Obligation(
                obligation_type=ObligationType.QUALIFICATION,
                realization_id=record.realization_id,
                name="known_good_die_yield",
                value=known_good_die_yield(count, model),
                unit="fraction",
                scope="per-die",
                evidence_class=EvidenceClass.MODELED,
                source=self.definition.qualified_id,
            )
        )
        return obligations


def advanced_packaging_generator(**kwargs: Any) -> AdvancedPackagingGenerator:
    """The reference advanced-packaging generator (spec 36.5 pack 5)."""
    return AdvancedPackagingGenerator(**kwargs)


def advanced_packaging_seed(
    context: GenerationContext, *, source_id: str = "advanced-packaging-seed"
) -> RealizationRecord:
    """The seed realization: one monolithic die (the FUSED class)."""
    model = _model(context)
    count = model.partition_counts[0]
    return seed_record(
        source_id=source_id,
        signature=arrangement_signature(ARRANGEMENT_FUSED, count, model, context.schema),
        attributes={
            ATTR_ARRANGEMENT: ARRANGEMENT_FUSED,
            ATTR_PARTITION_COUNT: count,
            ATTR_REFINEMENTS: 0,
        },
        evidence_class=EvidenceClass.CONSTRUCTIVE,
    )


# ---------------------------------------------------------------------------
# manifest (36.2) and pack contents (36.4)
# ---------------------------------------------------------------------------

TERMINOLOGY: Dict[str, str] = {
    "monolithic die": "the whole design on one piece of silicon; the FUSED realization class",
    "chiplet": "one piece of a design cut into separately manufactured dies",
    "interposer": "the substrate carrying lateral links between chiplets placed side by side",
    "stack": "chiplets bonded face to face so that links run vertically; the VERTICAL class",
    "known-good-die yield": "the exact probability that one die of the declared area carries "
    "no defect, under the declared defect density",
    "keep-out margin": "the footprint area a die needs beyond its own active silicon",
}


def manifest_data() -> Dict[str, Any]:
    fields = manifest_fields(
        identity=PACK_IDENTITY,
        external_dependencies=(
            "crg-model (exact rationals, records, canonicalization)",
            "crg-generate (generator contract, legality, registry)",
        ),
        resource_requirements={
            "memory_mb": 32,
            "wall_clock_seconds": 1,
            "processes": 1,
            "network": "none",
        },
        failure_modes=(
            "SKIP_AND_RECORD: a parent carrying no arrangement attribute yields no child and "
            "is recorded as an UNGENERATED region, never as an infeasible one (spec 28.4)",
            "INFEASIBLE: an arrangement whose exact per-die yield falls below the declared "
            "floor is refused by a legality predicate, not by the generator",
            "UNSUPPORTED: a context declaring no yield floor leaves the yield predicate "
            "undecided rather than permissive",
        ),
        quantity_registry_additions=(
            "packaging.footprint_area",
            "packaging.interconnect_energy",
            "packaging.assembled_cost",
            "packaging.known_good_die_yield",
        ),
        proof_implications=(
            "the arrangement moves only forwards through FUSED, SPLIT, VERTICAL and the "
            "refinement counter only upwards, so the closure is finite and a fixpoint of this "
            "generator supports a GENERATOR_CLOSED completeness basis (spec 21.2)",
            "the yield obligation is evidence class MODELED, not EXACT: the arithmetic is "
            "exact but the Bose-Einstein form is a model of a physical process, and 5.3 "
            "forbids presenting a modelled quantity as a measured or exact one",
            "this pack is a reference application and no part of CRG Core depends on it "
            "(spec 36.5)",
        ),
        conformance_tests=(
            "test_every_reference_pack_loads_and_validates",
            "test_every_reference_pack_reaches_a_generator_closed_basis",
            "test_advanced_packaging_produces_three_distinguishable_classes",
        ),
        provenance={
            "repository": "CRGsys",
            "module": "crg_generate.reference_packs.advanced_packaging",
            "specification": "36.5 initial reference pack 5 (advanced packaging); a reference "
            "application, not a dependency of CRG Core",
            "derivation": "first-party reference implementation; no imported registry",
        },
    )
    fields["contents"] = {
        "terminology": TERMINOLOGY,
        "quantities": {
            "packaging.footprint_area": "mm2",
            "packaging.interconnect_energy": "pJ-per-transfer",
            "packaging.assembled_cost": "currency-unit",
            "packaging.known_good_die_yield": "fraction",
        },
        "contracts": {
            "computation_contract": "one declared design of fixed active silicon area whose "
            "logical content is invariant under every transformation of this pack",
            "resource_contract": "a declared defect density, a declared keep-out margin, and "
            "declared per-class assembly prices",
            "hierarchy_contract": "an arrangement is (realization class, die count); the "
            "class ladder FUSED, SPLIT, VERTICAL is one-directional",
        },
        "accounting_rules": {
            "known_good_die_yield": "Bose-Einstein: 1 / (1 + (A/n) d)^2, computed exactly",
            "assembled_cost": "A / Y(n) for the dies, plus the per-class assembly price: "
            "nothing for FUSED, interposer base plus attach per die for SPLIT, bond per "
            "interface plus test per die for VERTICAL",
            "footprint_area": "A for FUSED, A + margin*n for SPLIT, A/n + margin for VERTICAL",
            "interconnect_energy": "intra-die energy plus (n-1) crossings at the lateral "
            "link length for SPLIT and at the vertical link length for VERTICAL",
        },
        "transformations": [
            TRANSFORMATION_SPLIT,
            TRANSFORMATION_REFINE,
            TRANSFORMATION_STACK,
        ],
        "obligation_coordinates": [
            COORDINATE_AREA,
            COORDINATE_ENERGY,
            COORDINATE_COST,
            "known_good_die_yield",
        ],
        "technology_coordinates": [
            "declared-defect-density",
            "lateral-link-length",
            "vertical-link-length",
        ],
        "evaluators": [
            "crg_generate.reference_packs.advanced_packaging.arrangement_signature",
            "crg_generate.reference_packs.advanced_packaging.known_good_die_yield",
        ],
        "qualification_methods": [
            "exact recomputation of the declared yield model from the recorded die count",
            "declared-density sensitivity: re-evaluate the family at a second declared "
            "defect density and compare the retained frontier",
        ],
        "proof_checkers": [],
        "ui_extensions": [],
        "example_cases": ["one-hundred-square-millimetres-at-one-defect-per-hundred"],
        "conformance_fixtures": [
            "fixture: the FUSED realization is (100, 4, 400); the SPLIT two-die realization "
            "is (112, 19, 255); the VERTICAL two-die realization is (56, 43/10, 269)",
            "fixture: the four-die yield is exactly 16/25 and the four-die cost is exactly "
            "785/4 for SPLIT and 1057/4 for VERTICAL",
            "fixture: no two of the five realizations share a signature, and none of the "
            "three realization classes is Pareto-identical to another",
        ],
    }
    fields["extensions"] = {"generators": [advanced_packaging_generator()]}
    return fields


def worked_example() -> WorkedExample:
    context = GenerationContext(
        schema=SCHEMA,
        capabilities={},
        parameters={PACKAGING_MODEL_KEY: REFERENCE_PACKAGE},
        permissions=tuple(GENERATOR_PERMISSIONS),
        declared_universe=_PackagingModel(REFERENCE_PACKAGE).universe_note,
        validity="the declared defect density, link lengths, and assembly prices",
    )
    seed = advanced_packaging_seed(context)
    source = GenerationSource(
        source_id="advanced-packaging-reference-design",
        source_type="PACKAGING_MODEL",
        seeds=(seed,),
        computation_contract={"contract_id": "packaging.design", "version": "1"},
        resource_contract={"contract_id": "packaging.process", "version": "1"},
        hierarchy_contract={"contract_id": "packaging.arrangement", "version": "1"},
        declared_universe=_PackagingModel(REFERENCE_PACKAGE).universe_note,
    )
    return WorkedExample(
        name="one-hundred-square-millimetres-at-one-defect-per-hundred",
        description=(
            "100 mm2 of active silicon at a defect density of 1/100 per mm2. The monolithic "
            "die yields 1/4 and costs 400; cutting it in two raises the per-die yield to 4/9 "
            "and cutting it in four to 16/25. Stacking collapses footprint and interconnect "
            "energy and pays for it in bonding and stacked test."
        ),
        schema=SCHEMA,
        source=source,
        context=context,
        expected_realization_count=5,
        expected_legal_count=5,
        expected_signatures=(
            ("100", "4", "400"),
            ("112", "19", "255"),
            ("124", "49", "785/4"),
            ("31", "49/10", "1057/4"),
            ("56", "43/10", "269"),
        ),
        decision_query={
            "id": "advanced-packaging-arrangement-choice",
            "objective_family": {
                "type": "weighted_sum",
                "weights": {
                    COORDINATE_AREA: "1",
                    COORDINATE_ENERGY: "1",
                    COORDINATE_COST: "1",
                },
            },
            "quantification": "EACH_OBJECTIVE",
            "ties": {"policy_tolerance": "0", "retain_all": True},
        },
        notes=(
            "the five realizations are FUSED(1), SPLIT(2), SPLIT(4), VERTICAL(2), VERTICAL(4)",
            "785/4, 1057/4, 43/10, and 49/10 are exact rationals produced by the exact yield "
            "and link-length models",
        ),
    )
