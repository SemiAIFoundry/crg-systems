"""Reference domain pack 1 of specification 36.5: the generic finite-realization pack.

Normative basis: master specification 36.5 ("a generic finite-realization
pack"), 36.2 (plugin manifest), 36.4 (domain-pack contents), 3.3 (domain
neutrality).

This module adds no generator.  The generator already exists --
:class:`crg_generate.reference.FiniteTransformationGenerator`, built by
:func:`crg_generate.reference.finite_transformation_generator` -- and its
behaviour, its identity ``crg-generate.finite-transformation``, and its
definition hash are untouched here.  What this module adds is the thing 36.2
requires and the generator alone cannot carry: a **manifest**, so that the
generic pack is loadable, validatable, and enumerable through the same
registry as the six others.

Why the pack is worth shipping
------------------------------
It is the falsifier for the domain-neutrality claim of 3.3.  Its rules --
``store-vs-recompute``, ``fuse-vs-split``, ``replicate`` -- are stated over two
coordinate *identifiers* supplied by the caller.  Nothing in the pack knows
whether ``primary`` and ``secondary`` are latency and energy, wall-clock and
dollars, or mass and volume.  A pack that cannot name its own units is a pack
that cannot smuggle a domain into core.

Termination
-----------
Inherited from the generator, unchanged: each declared rule either moves a
declared attribute from a required value to a different one -- so it fires at
most once on any path -- or advances a bounded counter.
:class:`crg_generate.reference.TransformationRule` refuses at construction any
rule with neither, because a rule with no progress measure would make the
closure infinite and every family built from it permanently
``TRUNCATED_BY_DECLARED_RULE`` (spec 21.2, 6.11).

The worked example
------------------
The example seeds an already-split unit of work with one replica available, so
the family is five realizations over four distinct signatures -- small enough
to state exhaustively in a conformance fixture, and large enough to contain a
non-trivial fiber: applying ``store-vs-recompute`` then ``replicate`` and
applying them in the other order reach the same exact signature by two
different derivations, and both records survive (spec 19.6).  The unchanged
generator seeded from a *fused* unit of work reaches sixteen realizations over
thirteen signatures; that count is recorded in the pack's fixtures too.
"""
from __future__ import annotations

from typing import Any, Dict

from crg_model.envelope import EvidenceClass
from crg_model.numeric import Exact
from crg_model.records import (
    Coordinate,
    CoordinateSchema,
    Direction,
    RealizationRecord,
    Signature,
)

from ..generator import GenerationContext, seed_record
from ..reference import (
    ATTR_GRANULARITY,
    ATTR_POLICY,
    ATTR_REPLICAS,
    finite_transformation_generator,
)
from ..registry import GenerationSource
from ._common import GENERATOR_PERMISSIONS, WorkedExample, manifest_fields

__all__ = [
    "PACK_NAME",
    "SPEC_INDEX",
    "SCHEMA",
    "PRIMARY",
    "SECONDARY",
    "REPLICA_LIMIT",
    "generic_finite_generator",
    "generic_finite_seed",
    "manifest_data",
    "worked_example",
]

PACK_NAME = "generic-finite-realization"
SPEC_INDEX = 1
PACK_IDENTITY = "crg-generate.reference.generic-finite-realization"

#: The two coordinate identifiers this worked example happens to use.  The
#: generator is stated over identifiers, not over quantities, and would behave
#: identically over any other two.
PRIMARY = "primary"
SECONDARY = "secondary"
REPLICA_LIMIT = 1

SCHEMA = CoordinateSchema(
    coordinates=(
        Coordinate(
            identifier=PRIMARY,
            quantity="generic.primary_cost",
            unit="1",
            direction=Direction.MINIMIZE,
            accounting_scope="per-unit-of-work",
        ),
        Coordinate(
            identifier=SECONDARY,
            quantity="generic.secondary_cost",
            unit="1",
            direction=Direction.MINIMIZE,
            accounting_scope="per-unit-of-work",
        ),
    ),
    technology_context="none: the coordinates are abstract and dimensionless by design",
)


def generic_finite_generator(**kwargs: Any):
    """The unchanged reference finite generator, wrapped by this pack."""
    return finite_transformation_generator(
        primary=PRIMARY, secondary=SECONDARY, replica_limit=REPLICA_LIMIT, **kwargs
    )


def generic_finite_seed(
    *,
    primary: str = "100",
    secondary: str = "100",
    granularity: str = "split",
    policy: str = "store",
    source_id: str = "generic-finite-seed",
) -> RealizationRecord:
    """The seed realization of the pack's worked example."""
    return seed_record(
        source_id=source_id,
        signature=Signature([Exact(primary), Exact(secondary)]),
        attributes={
            ATTR_POLICY: policy,
            ATTR_GRANULARITY: granularity,
            ATTR_REPLICAS: 0,
        },
        evidence_class=EvidenceClass.CONSTRUCTIVE,
    )


TERMINOLOGY: Dict[str, str] = {
    "unit of work": "an indivisible piece of a computation; the thing a realization "
    "realizes",
    "policy": "whether an intermediate is stored or recomputed",
    "granularity": "whether a unit of work is fused or split into independently placed "
    "pieces",
    "replica": "one additional copy of the unit of work",
    "primary coordinate": "the caller's first declared coordinate; this pack does not know "
    "what it measures",
    "secondary coordinate": "the caller's second declared coordinate; this pack does not "
    "know what it measures either",
}


def manifest_data() -> Dict[str, Any]:
    fields = manifest_fields(
        identity=PACK_IDENTITY,
        external_dependencies=(
            "crg-model (exact rationals, records, canonicalization)",
            "crg-generate (the unchanged FiniteTransformationGenerator of "
            "crg_generate.reference)",
        ),
        resource_requirements={
            "memory_mb": 16,
            "wall_clock_seconds": 1,
            "processes": 1,
            "network": "none",
        },
        failure_modes=(
            "SKIP_AND_RECORD: a parent no declared rule applies to yields no child, which is "
            "a statement about the rules and not about the legality of anything (spec 28.4)",
            "GeneratorError at construction: a transformation rule with no progress measure "
            "is refused outright, because its closure would never reach a fixpoint",
            "ILLEGAL: a transformation that drives a coordinate below zero is refused by the "
            "nonnegative-signature predicate, as a fact about the construction rather than "
            "about resources (spec 28.6)",
        ),
        quantity_registry_additions=(
            "generic.primary_cost",
            "generic.secondary_cost",
        ),
        proof_implications=(
            "each declared rule flips one declared attribute or advances one bounded counter, "
            "so the transitive closure of the rule set is finite and a fixpoint supports a "
            "GENERATOR_CLOSED completeness basis (spec 21.2)",
            "the pack states its rules over coordinate identifiers and never over quantities "
            "or units, which is the falsifiable form of the domain-neutrality claim of 3.3",
            "this pack adds no generator, no proof checker, and no core semantics; it adds "
            "the manifest 36.2 requires of the generator that already exists",
        ),
        conformance_tests=(
            "test_every_reference_pack_loads_and_validates",
            "test_every_reference_pack_reaches_a_generator_closed_basis",
            "test_every_reference_pack_worked_example_matches_its_generator",
        ),
        provenance={
            "repository": "CRGsys",
            "module": "crg_generate.reference_packs.generic_finite",
            "wraps": "crg_generate.reference.FiniteTransformationGenerator",
            "specification": "36.5 initial reference pack 1 (generic finite realization)",
            "derivation": "manifest only; the wrapped generator's identity, behaviour, and "
            "definition hash are unchanged",
        },
    )
    fields["contents"] = {
        "terminology": TERMINOLOGY,
        "quantities": {"generic.primary_cost": "1", "generic.secondary_cost": "1"},
        "contracts": {
            "computation_contract": "one declared unit of work with two abstract coordinates",
            "resource_contract": "none declared: the coordinates are dimensionless",
        },
        "accounting_rules": {
            "store-vs-recompute": "primary times 3/2, secondary times 1/2",
            "fuse-vs-split": "primary times 4/5, secondary plus 1",
            "replicate": "primary times 9/10, secondary times 6/5, up to the declared "
            "replica limit",
        },
        "transformations": ["store-vs-recompute", "fuse-vs-split", "replicate"],
        "obligation_coordinates": [PRIMARY, SECONDARY],
        "technology_coordinates": [],
        "evaluators": [
            "crg_generate.reference.TransformationRule.child_signature",
        ],
        "qualification_methods": [
            "exact replay of the declared rule sequence recorded on the derivation path"
        ],
        "proof_checkers": [],
        "ui_extensions": [],
        "example_cases": ["already-split-unit-of-work-with-one-replica"],
        "conformance_fixtures": [
            "fixture: from the seed (100, 100) already split, the family is five "
            "realizations over the four signatures (100,100), (150,50), (90,120), (135,60)",
            "fixture: two derivation orders reach (135, 60) and both records survive as one "
            "fiber; equal signatures do not erase realization identity (spec 19.6)",
            "fixture: the same unchanged generator seeded from a fused unit of work reaches "
            "sixteen realizations over thirteen distinct signatures",
        ],
    }
    fields["extensions"] = {"generators": [generic_finite_generator()]}
    return fields


def worked_example() -> WorkedExample:
    context = GenerationContext(
        schema=SCHEMA,
        capabilities={},
        parameters={},
        permissions=tuple(GENERATOR_PERMISSIONS),
        declared_universe="the closure of the declared finite transformation rules",
        validity="the declared rule set and its declared replica limit",
    )
    source = GenerationSource(
        source_id="generic-finite-reference-seed",
        source_type="EXPLICIT_RECORDS",
        seeds=(generic_finite_seed(),),
        computation_contract={"contract_id": "generic.unit-of-work", "version": "1"},
        resource_contract={"contract_id": "generic.dimensionless", "version": "1"},
        declared_universe="the closure of the declared finite transformation rules",
    )
    return WorkedExample(
        name="already-split-unit-of-work-with-one-replica",
        description=(
            "A unit of work at (100, 100) that is already split, so only "
            "store-vs-recompute and replicate apply. Five realizations over four "
            "signatures, one of which is reached by two derivations."
        ),
        schema=SCHEMA,
        source=source,
        context=context,
        expected_realization_count=5,
        expected_legal_count=5,
        expected_signatures=(
            ("100", "100"),
            ("135", "60"),
            ("150", "50"),
            ("90", "120"),
        ),
        decision_query={
            "id": "generic-finite-realization-choice",
            "objective_family": {
                "type": "weighted_sum",
                "weights": {PRIMARY: "1", SECONDARY: "1"},
            },
            "quantification": "EACH_OBJECTIVE",
            "ties": {"policy_tolerance": "0", "retain_all": True},
        },
        notes=(
            "five records over four signatures: (135, 60) is a two-member fiber",
            "the generator, its identity, and its definition hash are unchanged by this pack",
        ),
    )
