"""Reference domain pack 6 of specification 36.5: materials and process evidence.

Normative basis: master specification 36.5 ("a materials and process-evidence
pack"), 36.4 (domain-pack contents), 36.2 (plugin manifest), 28.4 (generator
contract), 28.6 (the legality states stay distinct), and above all 5.3
(evidence classes).

What the pack models
--------------------
A realization is one *process route*: a declared material crossed with a
declared consolidation step.  Two transformations generate the family:

``substitute-material``
    Advance to the next declared material, while the route is still open.
``substitute-consolidation-step``
    Advance to the next declared consolidation step, and fix the material.
    A consolidation step is qualified against the material it runs on, so once
    a route has committed to a step the material is no longer free.

Why the evidence classes do real work here
------------------------------------------
Every route in this pack carries a declared evidence class, and the three that
matter are genuinely different epistemic situations (spec 5.3):

``MEASURED``
    The route has been run and the resulting parts destructively tested.  The
    obligation is a report of an observation.
``MODELED``
    The route has been simulated from a physical model calibrated on a
    neighbouring route.  The obligation is a report of a computation about the
    world, not of the world.
``DECLARED``
    The route's numbers come from a supplier datasheet.  Nothing in this
    system observed or computed them.

The pack does not merely *label* the difference; it acts on it.  The
``evidence-admissibility`` legality predicate refuses a ``DECLARED`` route as
``UNSUPPORTED`` unless the generation context explicitly declares that
supplier declarations are accepted for this decision -- and ``UNSUPPORTED``,
not ``INFEASIBLE``: the route may well be perfectly feasible, and what is
missing is the evidence, not the possibility.  Collapsing those two would be
exactly the failure 28.6 forbids.  A ``HEURISTIC`` route is refused outright
as ``ILLEGAL``, because 5.3 says a heuristic may rank or propose and may never
authorize.

Each realization's obligations carry the route's evidence class rather than
the pack's, so a downstream envelope sees a measured porosity and a declared
porosity as the different things they are.

Termination
-----------
The closure is finite by a strict partial order on ``(material index,
consolidation index)``:

1. ``substitute-material`` requires ``route_stage == MATERIAL_OPEN`` and
   strictly increases the material index, bounded by the declared material
   list;
2. ``substitute-consolidation-step`` strictly increases the consolidation
   index, bounded by the declared step list, and sets ``route_stage`` to
   ``MATERIAL_FIXED``, after which rule 1 no longer applies.

Neither index ever decreases, so no path is infinite (spec 21.2, 6.11).
"""
from __future__ import annotations

from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple

from crg_model.envelope import EvidenceClass
from crg_model.numeric import Exact
from crg_model.records import (
    Coordinate,
    CoordinateSchema,
    Direction,
    RealizationRecord,
    Signature,
)

from ..generator import (
    CompletenessImplication,
    DeterminismStatus,
    FailureSemantics,
    GenerationContext,
    GeneratorDefinition,
    GeneratorError,
    Obligation,
    ObligationType,
    ParentChildRelation,
    SemanticRule,
    WitnessMethod,
    propose_record,
    seed_record,
)
from ..legality import LegalityPredicate, LegalityStatus
from ..reference import nonnegative_signature_predicate
from ..registry import GenerationSource
from ._common import (
    GENERATOR_PERMISSIONS,
    PACK_VERSION,
    WorkedExample,
    as_flag,
    carried_attributes,
    manifest_fields,
    read_model,
)

__all__ = [
    "PACK_NAME",
    "SPEC_INDEX",
    "PROCESS_ROUTE_MODEL_KEY",
    "ACCEPT_DECLARED_EVIDENCE_KEY",
    "ATTR_MATERIAL",
    "ATTR_CONSOLIDATION",
    "ATTR_ROUTE_STAGE",
    "SCHEMA",
    "REFERENCE_ROUTES",
    "ProcessRouteGenerator",
    "materials_process_generator",
    "materials_process_seed",
    "route_signature",
    "route_evidence",
    "porosity_limit_predicate",
    "evidence_admissibility_predicate",
    "manifest_data",
    "worked_example",
]

PACK_NAME = "materials-process-evidence"
SPEC_INDEX = 6
PACK_IDENTITY = "crg-generate.reference.materials-process-evidence"

PROCESS_ROUTE_MODEL_KEY = "process_route_model"
ACCEPT_DECLARED_EVIDENCE_KEY = "accept_supplier_declarations"

ATTR_MATERIAL = "material"
ATTR_CONSOLIDATION = "consolidation_step"
ATTR_ROUTE_STAGE = "route_stage"

STAGE_MATERIAL_OPEN = "MATERIAL_OPEN"
STAGE_MATERIAL_FIXED = "MATERIAL_FIXED"

TRANSFORMATION_MATERIAL = "substitute-material"
TRANSFORMATION_CONSOLIDATION = "substitute-consolidation-step"

COORDINATE_ENERGY = "process_energy"
COORDINATE_POROSITY = "residual_porosity"

SCHEMA = CoordinateSchema(
    coordinates=(
        Coordinate(
            identifier=COORDINATE_ENERGY,
            quantity="materials.process_energy",
            unit="MJ-per-part",
            direction=Direction.MINIMIZE,
            accounting_scope="per-part",
        ),
        Coordinate(
            identifier=COORDINATE_POROSITY,
            quantity="materials.residual_porosity",
            unit="volume-fraction",
            direction=Direction.MINIMIZE,
            accounting_scope="per-part",
        ),
    ),
    technology_context="a declared powder-consolidation process window",
)

REFERENCE_ROUTES: Dict[str, Any] = {
    "materials": [
        {"name": "alloy-ta6v", "base_energy_mj": "40", "base_porosity": "3/100"},
        {"name": "alloy-alsi10mg", "base_energy_mj": "25", "base_porosity": "5/100"},
    ],
    "consolidation_steps": [
        {"name": "sinter", "energy_multiplier": "1", "porosity_factor": "1"},
        {
            "name": "hot-isostatic-press",
            "energy_multiplier": "7/5",
            "porosity_factor": "1/5",
        },
        {"name": "anneal", "energy_multiplier": "6/5", "porosity_factor": "3/5"},
    ],
    "evidence_matrix": {
        "alloy-ta6v|sinter": {
            "evidence": EvidenceClass.MEASURED,
            "qualification_method": "thirty destructive coupons, archimedes density, "
            "reported with the measurement campaign identifier",
        },
        "alloy-ta6v|hot-isostatic-press": {
            "evidence": EvidenceClass.MEASURED,
            "qualification_method": "thirty destructive coupons, computed-tomography "
            "porosity, reported with the measurement campaign identifier",
        },
        "alloy-ta6v|anneal": {
            "evidence": EvidenceClass.MODELED,
            "qualification_method": "diffusion model calibrated on the sintered coupons of "
            "the same material; no anneal coupon has been cut",
        },
        "alloy-alsi10mg|sinter": {
            "evidence": EvidenceClass.MODELED,
            "qualification_method": "densification model transferred from the neighbouring "
            "alloy; no coupon of this material has been cut",
        },
        "alloy-alsi10mg|hot-isostatic-press": {
            "evidence": EvidenceClass.DECLARED,
            "qualification_method": "supplier datasheet; nothing in this system observed or "
            "computed the value",
        },
        "alloy-alsi10mg|anneal": {
            "evidence": EvidenceClass.DECLARED,
            "qualification_method": "supplier datasheet; nothing in this system observed or "
            "computed the value",
        },
    },
    "porosity_limit": "1/20",
}


# ---------------------------------------------------------------------------
# the declared route model, read exactly
# ---------------------------------------------------------------------------


class _RouteModel:
    def __init__(self, raw: Mapping[str, Any]) -> None:
        materials = raw.get("materials")
        steps = raw.get("consolidation_steps")
        if not materials or not steps:
            raise GeneratorError(
                f"{PROCESS_ROUTE_MODEL_KEY} MUST declare both 'materials' and "
                "'consolidation_steps'; an empty declaration would make an empty family look "
                "like a closed one (spec 6.6)"
            )
        self.material_names: Tuple[str, ...] = tuple(str(m["name"]) for m in materials)
        self.step_names: Tuple[str, ...] = tuple(str(s["name"]) for s in steps)
        self.base_energy: Dict[str, Exact] = {
            str(m["name"]): Exact(m["base_energy_mj"]) for m in materials
        }
        self.base_porosity: Dict[str, Exact] = {
            str(m["name"]): Exact(m["base_porosity"]) for m in materials
        }
        self.energy_multiplier: Dict[str, Exact] = {
            str(s["name"]): Exact(s["energy_multiplier"]) for s in steps
        }
        self.porosity_factor: Dict[str, Exact] = {
            str(s["name"]): Exact(s["porosity_factor"]) for s in steps
        }
        self.evidence_matrix: Mapping[str, Any] = raw.get("evidence_matrix", {})
        limit = raw.get("porosity_limit")
        self.porosity_limit = None if limit is None else Exact(limit)

    def route_key(self, material: str, step: str) -> str:
        return f"{material}|{step}"

    def evidence(self, material: str, step: str) -> Tuple[str, str]:
        """The declared evidence class and qualification method of one route.

        A route the matrix does not cover is ``DECLARED`` with an explicit
        statement that nothing established it.  It is emphatically not assumed
        to be measured: an unstated provenance is the weakest one, never the
        strongest (spec 5.3, 6.6).
        """
        entry = self.evidence_matrix.get(self.route_key(material, step))
        if not isinstance(entry, Mapping):
            return (
                EvidenceClass.DECLARED,
                "no evidence is declared for this route; the value is carried forward as a "
                "declaration and nothing in this system observed or computed it",
            )
        evidence = str(entry.get("evidence", EvidenceClass.DECLARED))
        if evidence not in EvidenceClass.ALL:
            raise GeneratorError(
                f"route {self.route_key(material, step)!r} declares unknown evidence class "
                f"{evidence!r} (spec 5.3)"
            )
        return evidence, str(entry.get("qualification_method", ""))

    @property
    def universe_note(self) -> str:
        return (
            f"the closure of the declared substitution transformations over "
            f"{len(self.material_names)} declared material(s) and "
            f"{len(self.step_names)} declared consolidation step(s)"
        )


def _routes(context: GenerationContext) -> _RouteModel:
    return _RouteModel(read_model(context, PROCESS_ROUTE_MODEL_KEY))


def route_evidence(material: str, step: str, model: _RouteModel) -> Tuple[str, str]:
    """Public reader for a route's declared evidence class and method."""
    return model.evidence(material, step)


# ---------------------------------------------------------------------------
# the exact process model
# ---------------------------------------------------------------------------


def route_signature(
    material: str,
    step: str,
    model: _RouteModel,
    schema: CoordinateSchema,
) -> Signature:
    """Exact process energy and exact residual porosity of one route."""
    if material not in model.base_energy:
        raise GeneratorError(f"material {material!r} is not declared")
    if step not in model.energy_multiplier:
        raise GeneratorError(f"consolidation step {step!r} is not declared")
    energy = model.base_energy[material] * model.energy_multiplier[step]
    porosity = model.base_porosity[material] * model.porosity_factor[step]
    values = {COORDINATE_ENERGY: energy, COORDINATE_POROSITY: porosity}
    missing = [i for i in schema.identifiers if i not in values]
    if missing:
        raise GeneratorError(
            f"the declared schema has coordinates {missing} this pack does not produce; a "
            "signature has no optional components (spec 19.1)"
        )
    return Signature([values[identifier] for identifier in schema.identifiers])


# ---------------------------------------------------------------------------
# legality (spec 28.6, 5.3)
# ---------------------------------------------------------------------------


def porosity_limit_predicate(version: str = "1") -> LegalityPredicate:
    """Refuse a route whose exact residual porosity exceeds the declared limit."""

    def evaluate(realization: RealizationRecord, context: Mapping[str, Any]) -> Any:
        raw = context.get("parameters", {}).get(PROCESS_ROUTE_MODEL_KEY)
        if not isinstance(raw, Mapping) or raw.get("porosity_limit") is None:
            return (
                LegalityStatus.UNSUPPORTED,
                f"the declared {PROCESS_ROUTE_MODEL_KEY!r} carries no 'porosity_limit'; this "
                "predicate applies but cannot decide",
            )
        limit = Exact(raw["porosity_limit"])
        identifiers = [
            c["identifier"] for c in context.get("schema", {}).get("coordinates", ())
        ]
        index = identifiers.index(COORDINATE_POROSITY)
        porosity = realization.signature[index]
        if porosity > limit:
            return (
                LegalityStatus.INFEASIBLE,
                f"residual porosity {porosity} exceeds the declared limit {limit}; the route "
                "is runnable but its parts do not meet the declared process window",
            )
        return True

    return LegalityPredicate(
        predicate_id="crg-generate.reference.materials.porosity-limit",
        version=version,
        description="the exact residual porosity meets the declared process window",
        evaluate=evaluate,
        required_context=("parameters",),
        false_status=LegalityStatus.INFEASIBLE,
        evidence_class=EvidenceClass.EXACT,
    )


def evidence_admissibility_predicate(version: str = "1") -> LegalityPredicate:
    """Decide a route by the *class of evidence* behind it (spec 5.3, 28.6).

    * ``HEURISTIC`` is ``ILLEGAL``.  A heuristic may rank or propose and may
      never authorize, so a route whose numbers came from one is not a legal
      member of a family a certificate will be issued over.  That is a fact
      about the route in every context, which is what makes it ``ILLEGAL``
      rather than ``INFEASIBLE``.
    * ``DECLARED`` is ``UNSUPPORTED`` unless the context explicitly accepts
      supplier declarations.  ``UNSUPPORTED`` and not ``INFEASIBLE``: nothing
      here says the route fails, only that this system has no evidence that it
      succeeds.  Reporting missing evidence as a negative finding is precisely
      the collapse 28.6 forbids.
    * ``MEASURED`` and ``MODELED`` are admitted, and the difference between
      them is preserved in the obligations rather than erased here.
    """

    def evaluate(realization: RealizationRecord, context: Mapping[str, Any]) -> Any:
        raw = context.get("parameters", {}).get(PROCESS_ROUTE_MODEL_KEY)
        if not isinstance(raw, Mapping):
            return (
                LegalityStatus.UNSUPPORTED,
                f"the context declares no {PROCESS_ROUTE_MODEL_KEY!r}; this predicate applies "
                "but cannot decide",
            )
        model = _RouteModel(raw)
        material = as_flag(realization.attributes.get(ATTR_MATERIAL, ""))
        step = as_flag(realization.attributes.get(ATTR_CONSOLIDATION, ""))
        if material not in model.material_names or step not in model.step_names:
            return (
                LegalityStatus.UNSUPPORTED,
                "the realization does not name a declared route; this predicate cannot "
                "decide it",
            )
        evidence, method = model.evidence(material, step)
        if evidence == EvidenceClass.HEURISTIC:
            return (
                LegalityStatus.ILLEGAL,
                f"route {material}|{step} rests on heuristic evidence ({method}); a heuristic "
                "may rank or propose and may never authorize (spec 5.3)",
            )
        if evidence == EvidenceClass.DECLARED and not bool(
            context.get("parameters", {}).get(ACCEPT_DECLARED_EVIDENCE_KEY, False)
        ):
            return (
                LegalityStatus.UNSUPPORTED,
                f"route {material}|{step} rests on a supplier declaration ({method}) and this "
                f"context does not set {ACCEPT_DECLARED_EVIDENCE_KEY!r}. The route is not "
                "refused -- nothing here says it fails -- the evidence for it is simply "
                "absent, and an absence of evidence is not a negative finding (spec 5.3, "
                "28.6)",
            )
        return True

    return LegalityPredicate(
        predicate_id="crg-generate.reference.materials.evidence-admissibility",
        version=version,
        description="the route's evidence class is admissible for this decision",
        evaluate=evaluate,
        required_context=("parameters",),
        # A bare ``False`` from this predicate means "the evidence behind this
        # route may never authorize", which is ILLEGAL. The *absent*-evidence
        # case is returned explicitly as UNSUPPORTED above, because
        # ``false_status`` may only ever be a refusal: a predicate that could
        # declare UNSUPPORTED as its refusal state would be merging an absence
        # of evidence with a negative finding (spec 28.6).
        false_status=LegalityStatus.ILLEGAL,
        evidence_class=EvidenceClass.DECLARED,
    )


# ---------------------------------------------------------------------------
# the generator (spec 28.4)
# ---------------------------------------------------------------------------


class ProcessRouteGenerator:
    """Alternative material and consolidation routes, each carrying its evidence."""

    def __init__(
        self,
        *,
        identity: str = PACK_IDENTITY,
        version: str = PACK_VERSION,
        failure_semantics: str = FailureSemantics.SKIP_AND_RECORD,
    ) -> None:
        self.definition = GeneratorDefinition(
            identity=identity,
            version=version,
            accepted_source_types=("PROCESS_ROUTE_MODEL", "EXPLICIT_RECORDS"),
            transformations=(TRANSFORMATION_MATERIAL, TRANSFORMATION_CONSOLIDATION),
            semantic_rule=SemanticRule.APPROXIMATING,
            semantic_rule_detail=(
                "a substituted material or consolidation step produces a part meeting the "
                "same declared functional specification, but it is not the same part: the "
                "microstructure differs, and the pack therefore declares APPROXIMATING rather "
                "than SEMANTICS_PRESERVING. What is preserved is the declared function; what "
                "is not preserved is everything the declared function does not fix"
            ),
            determinism_status=DeterminismStatus.DETERMINISTIC,
            failure_semantics=failure_semantics,
            completeness_implications=CompletenessImplication(
                closes_family=True,
                rationale=(
                    "the material index and the consolidation index each only increase and "
                    "each is bounded by its declared list, and fixing the consolidation step "
                    "closes the material rule; the closure is therefore a finite set of "
                    "paths, one per declared route, and its fixpoint enumerates every route "
                    "the declared substitutions reach"
                ),
            ),
            conformance_tests=(
                "test_every_reference_pack_reaches_a_generator_closed_basis",
                "test_materials_pack_makes_the_evidence_classes_do_work",
            ),
            legality_predicates=(
                nonnegative_signature_predicate(),
                porosity_limit_predicate(),
                evidence_admissibility_predicate(),
            ),
            capability_gates=(),
            obligation_types=(
                ObligationType.RESOURCE,
                ObligationType.QUALIFICATION,
                ObligationType.VERIFICATION,
            ),
            obligation_extractor=self._obligations,
            parent_child_relation=ParentChildRelation.CHILD_ALTERNATIVE_TO_PARENT,
            dependencies=(f"context:{PROCESS_ROUTE_MODEL_KEY}",),
            witness_method=WitnessMethod.CONSTRUCTIVE_TRANSFORMATION,
            required_permissions=GENERATOR_PERMISSIONS,
        )

    def propose(
        self, parent: RealizationRecord, context: GenerationContext
    ) -> Iterable[RealizationRecord]:
        model = _routes(context)
        material = as_flag(parent.attributes.get(ATTR_MATERIAL, ""))
        step = as_flag(parent.attributes.get(ATTR_CONSOLIDATION, ""))
        if material not in model.material_names or step not in model.step_names:
            return []
        stage = as_flag(parent.attributes.get(ATTR_ROUTE_STAGE, STAGE_MATERIAL_OPEN))
        children: List[RealizationRecord] = []

        material_index = model.material_names.index(material)
        step_index = model.step_names.index(step)

        if stage == STAGE_MATERIAL_OPEN and material_index + 1 < len(model.material_names):
            attributes = carried_attributes(parent)
            attributes[ATTR_MATERIAL] = model.material_names[material_index + 1]
            children.append(
                self._child(parent, context, model, TRANSFORMATION_MATERIAL, attributes)
            )
        if step_index + 1 < len(model.step_names):
            attributes = carried_attributes(parent)
            attributes[ATTR_CONSOLIDATION] = model.step_names[step_index + 1]
            attributes[ATTR_ROUTE_STAGE] = STAGE_MATERIAL_FIXED
            children.append(
                self._child(parent, context, model, TRANSFORMATION_CONSOLIDATION, attributes)
            )
        return children

    def _child(
        self,
        parent: RealizationRecord,
        context: GenerationContext,
        model: _RouteModel,
        transformation: str,
        attributes: Dict[str, Any],
    ) -> RealizationRecord:
        material = as_flag(attributes[ATTR_MATERIAL])
        step = as_flag(attributes[ATTR_CONSOLIDATION])
        evidence, _method = model.evidence(material, step)
        return propose_record(
            parent=parent,
            definition=self.definition,
            transformation=transformation,
            signature=route_signature(material, step, model, context.schema),
            attributes=attributes,
            evidence_class=evidence,
        )

    def _obligations(
        self, record: RealizationRecord, context: GenerationContext
    ) -> Sequence[Obligation]:
        model = _routes(context)
        material = as_flag(record.attributes.get(ATTR_MATERIAL, ""))
        step = as_flag(record.attributes.get(ATTR_CONSOLIDATION, ""))
        evidence, method = model.evidence(material, step)
        energy, porosity = record.signature.values[0], record.signature.values[1]
        return [
            Obligation(
                obligation_type=ObligationType.RESOURCE,
                realization_id=record.realization_id,
                name=COORDINATE_ENERGY,
                value=energy,
                unit="MJ-per-part",
                scope="per-part",
                evidence_class=evidence,
                source=self.definition.qualified_id,
            ),
            Obligation(
                obligation_type=ObligationType.QUALIFICATION,
                realization_id=record.realization_id,
                name=COORDINATE_POROSITY,
                value=porosity,
                unit="volume-fraction",
                scope="per-part",
                evidence_class=evidence,
                source=self.definition.qualified_id,
            ),
            Obligation(
                obligation_type=ObligationType.VERIFICATION,
                realization_id=record.realization_id,
                name=f"qualification_method:{material}|{step}",
                value=None,
                unit=None,
                scope="per-route",
                evidence_class=evidence,
                source=method or self.definition.qualified_id,
            ),
        ]


def materials_process_generator(**kwargs: Any) -> ProcessRouteGenerator:
    """The reference materials and process-evidence generator (spec 36.5 pack 6)."""
    return ProcessRouteGenerator(**kwargs)


def materials_process_seed(
    context: GenerationContext, *, source_id: str = "materials-process-seed"
) -> RealizationRecord:
    """The seed realization: the first declared material and consolidation step."""
    model = _routes(context)
    material = model.material_names[0]
    step = model.step_names[0]
    evidence, _method = model.evidence(material, step)
    return seed_record(
        source_id=source_id,
        signature=route_signature(material, step, model, context.schema),
        attributes={
            ATTR_MATERIAL: material,
            ATTR_CONSOLIDATION: step,
            ATTR_ROUTE_STAGE: STAGE_MATERIAL_OPEN,
        },
        evidence_class=evidence,
    )


# ---------------------------------------------------------------------------
# manifest (36.2) and pack contents (36.4)
# ---------------------------------------------------------------------------

TERMINOLOGY: Dict[str, str] = {
    "process route": "a declared material crossed with a declared consolidation step",
    "consolidation step": "the thermal or thermomechanical step that densifies the part",
    "residual porosity": "the volume fraction of the part that remains void after "
    "consolidation",
    "process window": "the declared band of process outcomes a part must fall inside",
    "coupon": "a witness specimen run with the part and destructively tested",
    "supplier declaration": "a value taken from a datasheet; nothing in this system "
    "observed or computed it",
}


def manifest_data() -> Dict[str, Any]:
    fields = manifest_fields(
        identity=PACK_IDENTITY,
        external_dependencies=(
            "crg-model (exact rationals, evidence classes, records)",
            "crg-generate (generator contract, legality, registry)",
        ),
        resource_requirements={
            "memory_mb": 32,
            "wall_clock_seconds": 1,
            "processes": 1,
            "network": "none",
        },
        failure_modes=(
            "SKIP_AND_RECORD: a parent that does not name a declared route yields no child "
            "and is recorded as an UNGENERATED region, never as an infeasible one",
            "INFEASIBLE: a route whose exact residual porosity exceeds the declared limit is "
            "refused by a legality predicate",
            "UNSUPPORTED: a route resting on a supplier declaration is left undecided unless "
            "the context accepts supplier declarations; missing evidence is not a negative "
            "finding (spec 5.3, 28.6)",
            "ILLEGAL: a route resting on heuristic evidence is refused outright; a heuristic "
            "may never authorize (spec 5.3)",
        ),
        quantity_registry_additions=(
            "materials.process_energy",
            "materials.residual_porosity",
            "materials.qualification_method",
        ),
        proof_implications=(
            "both route indices only increase and each is bounded by its declared list, so "
            "the closure is finite and a fixpoint supports a GENERATOR_CLOSED completeness "
            "basis (spec 21.2)",
            "every obligation carries the evidence class of the route it came from, so a "
            "measured porosity and a declared porosity never merge downstream (spec 5.3)",
            "an absent supplier declaration produces UNSUPPORTED, never INFEASIBLE; this pack "
            "therefore cannot be used to report missing evidence as a negative finding "
            "(spec 28.6)",
        ),
        conformance_tests=(
            "test_every_reference_pack_loads_and_validates",
            "test_every_reference_pack_reaches_a_generator_closed_basis",
            "test_materials_pack_makes_the_evidence_classes_do_work",
        ),
        provenance={
            "repository": "CRGsys",
            "module": "crg_generate.reference_packs.materials_process",
            "specification": "36.5 initial reference pack 6 (materials and process evidence)",
            "derivation": "first-party reference implementation; the declared evidence matrix "
            "is illustrative and carries no real campaign data",
        },
    )
    fields["contents"] = {
        "terminology": TERMINOLOGY,
        "quantities": {
            "materials.process_energy": "MJ-per-part",
            "materials.residual_porosity": "volume-fraction",
        },
        "contracts": {
            "computation_contract": "one declared part specification whose declared function "
            "every route must meet",
            "resource_contract": "the declared process window, including the porosity limit",
        },
        "accounting_rules": {
            "process_energy": "the material's base energy times the step's energy multiplier",
            "residual_porosity": "the material's base porosity times the step's porosity "
            "factor",
            "evidence": "an obligation carries the evidence class of the route that produced "
            "it, never the pack's own",
        },
        "transformations": [TRANSFORMATION_MATERIAL, TRANSFORMATION_CONSOLIDATION],
        "obligation_coordinates": [
            COORDINATE_ENERGY,
            COORDINATE_POROSITY,
            "qualification_method",
        ],
        "technology_coordinates": [
            "powder-consolidation",
            "declared-process-window",
            "declared-evidence-matrix",
        ],
        "evaluators": ["crg_generate.reference_packs.materials_process.route_signature"],
        "qualification_methods": [
            "destructive coupon testing with archimedes density",
            "computed-tomography porosity on destructive coupons",
            "calibrated densification model transferred from a neighbouring route",
            "supplier declaration",
        ],
        "proof_checkers": [],
        "ui_extensions": [],
        "example_cases": ["two-materials-crossed-with-three-consolidation-steps"],
        "conformance_fixtures": [
            "fixture: the six routes have exact signatures (40, 3/100), (56, 3/500), "
            "(48, 9/500), (25, 1/20), (35, 1/100), (30, 3/100)",
            "fixture: with supplier declarations accepted all six routes are LEGAL; with "
            "them not accepted the two DECLARED routes are UNSUPPORTED and neither is "
            "INFEASIBLE",
            "fixture: every obligation carries the evidence class of its own route, so the "
            "family contains MEASURED, MODELED and DECLARED obligations at once",
        ],
    }
    fields["extensions"] = {"generators": [materials_process_generator()]}
    return fields


def _context(*, accept_declared: bool) -> GenerationContext:
    parameters: Dict[str, Any] = {PROCESS_ROUTE_MODEL_KEY: REFERENCE_ROUTES}
    if accept_declared:
        parameters[ACCEPT_DECLARED_EVIDENCE_KEY] = True
    return GenerationContext(
        schema=SCHEMA,
        capabilities={},
        parameters=parameters,
        permissions=tuple(GENERATOR_PERMISSIONS),
        declared_universe=_RouteModel(REFERENCE_ROUTES).universe_note,
        validity="the declared process window and the declared evidence matrix",
    )


def strict_evidence_context() -> GenerationContext:
    """The conformance fixture: a context that does *not* accept declarations."""
    return _context(accept_declared=False)


def worked_example() -> WorkedExample:
    context = _context(accept_declared=True)
    seed = materials_process_seed(context)
    source = GenerationSource(
        source_id="materials-process-reference-routes",
        source_type="PROCESS_ROUTE_MODEL",
        seeds=(seed,),
        computation_contract={"contract_id": "materials.part-specification", "version": "1"},
        resource_contract={"contract_id": "materials.process-window", "version": "1"},
        declared_universe=_RouteModel(REFERENCE_ROUTES).universe_note,
    )
    return WorkedExample(
        name="two-materials-crossed-with-three-consolidation-steps",
        description=(
            "Two declared materials and three declared consolidation steps give six routes. "
            "Two are MEASURED, two MODELED, and two rest on supplier declarations; this "
            "context accepts declarations, so all six are LEGAL and the evidence class rides "
            "on the obligations rather than on the verdict."
        ),
        schema=SCHEMA,
        source=source,
        context=context,
        expected_realization_count=6,
        expected_legal_count=6,
        expected_signatures=(
            ("25", "1/20"),
            ("30", "3/100"),
            ("35", "1/100"),
            ("40", "3/100"),
            ("48", "9/500"),
            ("56", "3/500"),
        ),
        decision_query={
            "id": "materials-process-route-choice",
            "objective_family": {
                "type": "weighted_sum",
                "weights": {COORDINATE_ENERGY: "1", COORDINATE_POROSITY: "100"},
            },
            "quantification": "EACH_OBJECTIVE",
            "ties": {"policy_tolerance": "0", "retain_all": True},
        },
        notes=(
            "the same family under strict_evidence_context() leaves the two DECLARED routes "
            "UNSUPPORTED rather than INFEASIBLE",
            "3/500, 9/500 and 1/100 are exact rationals; a decimal porosity would round two "
            "of these routes onto each other",
        ),
    )
