"""Reference domain pack 7 of specification 36.5: the layout-conversion pack.

Normative basis: master specification 36.5 ("a layout-conversion pack"), 36.4
(domain-pack contents), 36.2 (plugin manifest), 28.4 (generator contract), and
section 31 (OID-CRG-004, minimum-movement ownership and layout conversion),
whose vocabulary this pack borrows: a normalized *logical space* partitioned
into *cells*, a *source layout*, a *target layout*, the *retained fraction*
``r*``, the *moved fraction* ``mu* = 1 - r*``, *residual regions*, and a
*duplication policy*.

This pack does **not** import :mod:`crg_convert`.  It restates the part of
31.2 it needs -- the maximum-weight bipartite assignment over equal-capacity
partitions -- so that ``crg-generate`` gains no package dependency from
shipping a reference pack, which is the whole point of 6.7.  The arithmetic is
the same arithmetic: exact rationals, and the optimum found by search rather
than by the nested closed form, because 31.2's closed form
``r* = min(C,C')/max(C,C')`` holds only when one cell count divides the other
and is simply wrong elsewhere.

What the pack models
--------------------
A realization is one *ownership and layout assignment*: a declared target
layout crossed with a declared duplication policy.  The logical space is
divided into equal atoms; the source layout and every candidate target layout
assign those atoms to equal-capacity cells.  For each candidate the pack
computes, exactly:

* ``r*``, the maximum over bijections of the total measure a target cell
  already owns -- the *retained region measure*;
* ``mu* = 1 - r*``, the *residual movement*: the measure that must be routed;
* the number of source-cell to target-cell *route steps* the optimal
  assignment leaves with a non-zero residual.

Two transformations generate the family:

``retarget-ownership-layout``
    Advance to the next declared target layout, while the target is still open.
``replicate-boundary-regions``
    Replace single ownership with boundary replication: a declared share of the
    residual is served by duplicating rather than moving. Movement falls; the
    duplicated share is stored twice, so storage overhead rises by the same
    amount. That is the trade the pack exists to make visible.

Termination
-----------
The closure is finite by a strict partial order on ``(target index, stage)``:
``retarget-ownership-layout`` requires ``conversion_stage == TARGET_OPEN`` and
strictly increases the bounded target index, and
``replicate-boundary-regions`` moves the stage to ``TARGET_FIXED`` and never
back.  A path is therefore a sequence of retargetings followed by at most one
replication choice, and there are exactly twice as many paths as declared
target layouts (spec 21.2, 6.11).

Determinism
-----------
Bijections are enumerated in lexicographic order and the optimum is broken
towards the lexicographically first permutation, so the chosen assignment --
and therefore the route-step count -- is a deterministic function of the
declared layouts (spec 6.5).
"""
from __future__ import annotations

from itertools import permutations
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple

from crg_model.envelope import EvidenceClass
from crg_model.numeric import Exact
from crg_model.records import (
    Coordinate,
    CoordinateSchema,
    Direction,
    RealizationRecord,
    Signature,
)

from ..generator import (
    CompletenessImplication,
    DeterminismStatus,
    FailureSemantics,
    GenerationContext,
    GeneratorDefinition,
    GeneratorError,
    Obligation,
    ObligationType,
    ParentChildRelation,
    SemanticRule,
    WitnessMethod,
    propose_record,
    seed_record,
)
from ..legality import LegalityPredicate, LegalityStatus
from ..reference import nonnegative_signature_predicate
from ..registry import GenerationSource
from ._common import (
    GENERATOR_PERMISSIONS,
    PACK_VERSION,
    WorkedExample,
    as_flag,
    carried_attributes,
    manifest_fields,
    read_model,
)

__all__ = [
    "PACK_NAME",
    "SPEC_INDEX",
    "CONVERSION_MODEL_KEY",
    "ATTR_TARGET_LAYOUT",
    "ATTR_DUPLICATION_POLICY",
    "ATTR_CONVERSION_STAGE",
    "POLICY_SINGLE_OWNER",
    "POLICY_REPLICATED_BOUNDARY",
    "SCHEMA",
    "REFERENCE_CONVERSION",
    "LayoutConversionGenerator",
    "layout_conversion_generator",
    "layout_conversion_seed",
    "conversion_signature",
    "max_retention",
    "movement_budget_predicate",
    "manifest_data",
    "worked_example",
]

PACK_NAME = "layout-conversion"
SPEC_INDEX = 7
PACK_IDENTITY = "crg-generate.reference.layout-conversion"

CONVERSION_MODEL_KEY = "layout_conversion_model"

ATTR_TARGET_LAYOUT = "target_layout"
ATTR_DUPLICATION_POLICY = "duplication_policy"
ATTR_CONVERSION_STAGE = "conversion_stage"

POLICY_SINGLE_OWNER = "SINGLE_OWNER"
POLICY_REPLICATED_BOUNDARY = "REPLICATED_BOUNDARY"

STAGE_TARGET_OPEN = "TARGET_OPEN"
STAGE_TARGET_FIXED = "TARGET_FIXED"

TRANSFORMATION_RETARGET = "retarget-ownership-layout"
TRANSFORMATION_REPLICATE = "replicate-boundary-regions"

COORDINATE_MOVEMENT = "residual_movement"
COORDINATE_OVERHEAD = "duplicate_storage"

SCHEMA = CoordinateSchema(
    coordinates=(
        Coordinate(
            identifier=COORDINATE_MOVEMENT,
            quantity="conversion.residual_movement",
            unit="fraction-of-logical-space",
            direction=Direction.MINIMIZE,
            accounting_scope="per-conversion-epoch",
        ),
        Coordinate(
            identifier=COORDINATE_OVERHEAD,
            quantity="conversion.duplicate_storage",
            unit="fraction-of-logical-space",
            direction=Direction.MINIMIZE,
            accounting_scope="per-conversion-epoch",
        ),
    ),
    technology_context="a normalized logical space of equal atoms under equal-capacity "
    "cell partitions",
)

#: Twelve atoms, four equal cells of three atoms each.  The source owns
#: consecutive triples; the three declared targets disturb that ownership by
#: increasing amounts.
REFERENCE_CONVERSION: Dict[str, Any] = {
    "atom_count": 12,
    "source_layout": {
        "name": "consecutive-triples",
        "cells": [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9, 10, 11]],
    },
    "target_layouts": [
        {
            "name": "partial-regroup",
            "kind": "OWNERSHIP_CHANGE",
            "cells": [[0, 1, 2], [3, 4, 6], [5, 7, 8], [9, 10, 11]],
        },
        {
            "name": "shift-by-one-atom",
            "kind": "LAYOUT_CHANGE",
            "cells": [[1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 0]],
        },
        {
            "name": "interleaved-round-robin",
            "kind": "LAYOUT_AND_OWNERSHIP_CHANGE",
            "cells": [[0, 4, 8], [1, 5, 9], [2, 6, 10], [3, 7, 11]],
        },
    ],
    "replication_share": "1/2",
    "movement_budget": "1",
}


# ---------------------------------------------------------------------------
# the declared conversion model, read exactly
# ---------------------------------------------------------------------------


def _cells(raw: Mapping[str, Any], atom_count: int) -> Tuple[Tuple[int, ...], ...]:
    cells = tuple(tuple(sorted(int(a) for a in cell)) for cell in raw["cells"])
    seen: List[int] = []
    for cell in cells:
        seen.extend(cell)
    if sorted(seen) != list(range(atom_count)):
        raise GeneratorError(
            f"layout {raw.get('name')!r} is not a partition of the {atom_count} declared "
            "atoms; a conversion between partitions of different spaces has no meaning "
            "(spec 31.2)"
        )
    sizes = {len(cell) for cell in cells}
    if len(sizes) != 1:
        raise GeneratorError(
            f"layout {raw.get('name')!r} is not equal-capacity; the assignment law of 31.2 "
            "is stated for equal-capacity partitions and this pack refuses to apply it "
            "elsewhere"
        )
    return cells


class _ConversionModel:
    def __init__(self, raw: Mapping[str, Any]) -> None:
        targets = raw.get("target_layouts")
        source = raw.get("source_layout")
        if not targets or not source:
            raise GeneratorError(
                f"{CONVERSION_MODEL_KEY} MUST declare both 'source_layout' and "
                "'target_layouts'; an empty declaration would make an empty family look like "
                "a closed one (spec 6.6)"
            )
        self.atom_count = int(raw["atom_count"])
        self.source_name = str(source["name"])
        self.source_cells = _cells(source, self.atom_count)
        self.target_names: Tuple[str, ...] = tuple(str(t["name"]) for t in targets)
        if len(set(self.target_names)) != len(self.target_names):
            raise GeneratorError("a target layout name is declared twice")
        self.target_cells: Dict[str, Tuple[Tuple[int, ...], ...]] = {
            str(t["name"]): _cells(t, self.atom_count) for t in targets
        }
        self.target_kind: Dict[str, str] = {
            str(t["name"]): str(t.get("kind", "LAYOUT_CHANGE")) for t in targets
        }
        self.replication_share = Exact(raw["replication_share"])
        budget = raw.get("movement_budget")
        self.movement_budget = None if budget is None else Exact(budget)

    @property
    def universe_note(self) -> str:
        return (
            "the closure of the declared retargeting and boundary-replication "
            f"transformations over {len(self.target_names)} declared target layout(s) of the "
            f"declared {self.atom_count}-atom logical space"
        )


def _model(context: GenerationContext) -> _ConversionModel:
    return _ConversionModel(read_model(context, CONVERSION_MODEL_KEY))


# ---------------------------------------------------------------------------
# the exact retention law (spec 31.2, restated)
# ---------------------------------------------------------------------------


def max_retention(
    source_cells: Sequence[Sequence[int]],
    target_cells: Sequence[Sequence[int]],
    atom_count: int,
) -> Tuple[Exact, Tuple[int, ...], int]:
    """Exact ``r*`` and the assignment that attains it (spec 31.2).

    Returns ``(retained_fraction, assignment, route_steps)``.  ``assignment[i]``
    is the target cell assigned to source cell ``i``; ``route_steps`` counts the
    ordered source-to-target pairs carrying a non-zero residual under that
    assignment -- the number of transfers the conversion plan must schedule.

    The optimum is found by enumerating the bijections rather than by applying
    ``min(C,C')/max(C,C')``.  Section 31.2 licenses that closed form only when
    one cell count divides the other; the module that owns this law refuses to
    use it elsewhere, and so does this pack.  Ties are broken towards the
    lexicographically first permutation, so the chosen assignment is a
    deterministic function of the declared layouts (spec 6.5).
    """
    if len(source_cells) != len(target_cells):
        raise GeneratorError(
            "the source and target partitions have different cell counts; this pack "
            "implements only the equal-capacity bijective case of 31.2"
        )
    count = len(source_cells)
    source_sets = [set(int(a) for a in cell) for cell in source_cells]
    target_sets = [set(int(a) for a in cell) for cell in target_cells]
    overlap = [
        [len(source_sets[i] & target_sets[j]) for j in range(count)] for i in range(count)
    ]

    best_value = -1
    best_assignment: Tuple[int, ...] = tuple(range(count))
    for candidate in permutations(range(count)):
        value = sum(overlap[i][candidate[i]] for i in range(count))
        if value > best_value:
            best_value = value
            best_assignment = candidate

    retained = Exact(best_value) / Exact(atom_count)
    steps = 0
    for i in range(count):
        for j in range(count):
            if j == best_assignment[i]:
                continue
            if overlap[i][j] > 0:
                steps += 1
    return retained, best_assignment, steps


def conversion_signature(
    target: str,
    policy: str,
    model: _ConversionModel,
    schema: CoordinateSchema,
) -> Signature:
    """Exact residual movement and exact duplicate-storage overhead."""
    if policy not in (POLICY_SINGLE_OWNER, POLICY_REPLICATED_BOUNDARY):
        raise GeneratorError(
            f"unknown duplication policy {policy!r}; declare one of "
            f"{[POLICY_SINGLE_OWNER, POLICY_REPLICATED_BOUNDARY]}"
        )
    if target not in model.target_cells:
        raise GeneratorError(f"target layout {target!r} is not declared")
    retained, _assignment, _steps = max_retention(
        model.source_cells, model.target_cells[target], model.atom_count
    )
    moved = Exact(1) - retained
    if policy == POLICY_SINGLE_OWNER:
        movement = moved
        overhead = Exact(0)
    else:
        duplicated = moved * model.replication_share
        movement = moved - duplicated
        overhead = duplicated
    values = {COORDINATE_MOVEMENT: movement, COORDINATE_OVERHEAD: overhead}
    missing = [i for i in schema.identifiers if i not in values]
    if missing:
        raise GeneratorError(
            f"the declared schema has coordinates {missing} this pack does not produce; a "
            "signature has no optional components (spec 19.1)"
        )
    return Signature([values[identifier] for identifier in schema.identifiers])


# ---------------------------------------------------------------------------
# legality (spec 28.6)
# ---------------------------------------------------------------------------


def movement_budget_predicate(version: str = "1") -> LegalityPredicate:
    """Refuse a conversion whose residual movement exceeds the declared budget.

    ``INFEASIBLE``: the conversion is perfectly well-formed and its plan is
    constructible; it simply moves more than this epoch's declared bandwidth
    budget allows.  A longer epoch admits it (spec 28.6, 31.4).
    """

    def evaluate(realization: RealizationRecord, context: Mapping[str, Any]) -> Any:
        raw = context.get("parameters", {}).get(CONVERSION_MODEL_KEY)
        if not isinstance(raw, Mapping) or raw.get("movement_budget") is None:
            return (
                LegalityStatus.UNSUPPORTED,
                f"the declared {CONVERSION_MODEL_KEY!r} carries no 'movement_budget'; this "
                "predicate applies but cannot decide",
            )
        budget = Exact(raw["movement_budget"])
        identifiers = [
            c["identifier"] for c in context.get("schema", {}).get("coordinates", ())
        ]
        index = identifiers.index(COORDINATE_MOVEMENT)
        movement = realization.signature[index]
        if movement > budget:
            return (
                LegalityStatus.INFEASIBLE,
                f"residual movement {movement} exceeds the declared epoch budget {budget}; "
                "the conversion plan is constructible but does not fit this epoch",
            )
        return True

    return LegalityPredicate(
        predicate_id="crg-generate.reference.layout-conversion.movement-budget",
        version=version,
        description="residual movement fits the declared conversion-epoch budget",
        evaluate=evaluate,
        required_context=("parameters",),
        false_status=LegalityStatus.INFEASIBLE,
        evidence_class=EvidenceClass.EXACT,
    )


# ---------------------------------------------------------------------------
# the generator (spec 28.4)
# ---------------------------------------------------------------------------


class LayoutConversionGenerator:
    """Alternative ownership and layout assignments of one logical space."""

    def __init__(
        self,
        *,
        identity: str = PACK_IDENTITY,
        version: str = PACK_VERSION,
        failure_semantics: str = FailureSemantics.SKIP_AND_RECORD,
    ) -> None:
        self.definition = GeneratorDefinition(
            identity=identity,
            version=version,
            accepted_source_types=("CONVERSION_MODEL", "EXPLICIT_RECORDS"),
            transformations=(TRANSFORMATION_RETARGET, TRANSFORMATION_REPLICATE),
            semantic_rule=SemanticRule.SEMANTICS_PRESERVING,
            semantic_rule_detail=(
                "retargeting and replication change which cell owns which atom of the same "
                "logical space, never the contents of the space; the atom set and every "
                "atom's value are invariants of both transformations, which is exactly what "
                "makes a conversion a conversion (spec 31.1)"
            ),
            determinism_status=DeterminismStatus.DETERMINISTIC,
            failure_semantics=failure_semantics,
            completeness_implications=CompletenessImplication(
                closes_family=True,
                rationale=(
                    "retargeting strictly increases a target index bounded by the declared "
                    "target list and requires the conversion stage to be open; replication "
                    "closes that stage and never reopens it. The closure is therefore a "
                    "finite set of paths -- one per (target, duplication policy) pair -- and "
                    "its fixpoint enumerates every assignment the declared transformations "
                    "reach"
                ),
            ),
            conformance_tests=(
                "test_every_reference_pack_reaches_a_generator_closed_basis",
                "test_layout_conversion_reports_residual_and_retained_measures",
            ),
            legality_predicates=(
                nonnegative_signature_predicate(),
                movement_budget_predicate(),
            ),
            capability_gates=(),
            obligation_types=(
                ObligationType.RESOURCE,
                ObligationType.ACCOUNTING,
                ObligationType.CAPABILITY,
            ),
            obligation_extractor=self._obligations,
            parent_child_relation=ParentChildRelation.CHILD_ALTERNATIVE_TO_PARENT,
            dependencies=(f"context:{CONVERSION_MODEL_KEY}",),
            witness_method=WitnessMethod.CONSTRUCTIVE_TRANSFORMATION,
            required_permissions=GENERATOR_PERMISSIONS,
        )

    def propose(
        self, parent: RealizationRecord, context: GenerationContext
    ) -> Iterable[RealizationRecord]:
        model = _model(context)
        target = as_flag(parent.attributes.get(ATTR_TARGET_LAYOUT, ""))
        if target not in model.target_names:
            return []
        policy = as_flag(
            parent.attributes.get(ATTR_DUPLICATION_POLICY, POLICY_SINGLE_OWNER)
        )
        stage = as_flag(parent.attributes.get(ATTR_CONVERSION_STAGE, STAGE_TARGET_OPEN))
        if stage != STAGE_TARGET_OPEN:
            return []
        children: List[RealizationRecord] = []

        index = model.target_names.index(target)
        if index + 1 < len(model.target_names):
            attributes = carried_attributes(parent)
            attributes[ATTR_TARGET_LAYOUT] = model.target_names[index + 1]
            children.append(
                self._child(parent, context, model, TRANSFORMATION_RETARGET, attributes)
            )
        if policy == POLICY_SINGLE_OWNER:
            attributes = carried_attributes(parent)
            attributes[ATTR_DUPLICATION_POLICY] = POLICY_REPLICATED_BOUNDARY
            attributes[ATTR_CONVERSION_STAGE] = STAGE_TARGET_FIXED
            children.append(
                self._child(parent, context, model, TRANSFORMATION_REPLICATE, attributes)
            )
        return children

    def _child(
        self,
        parent: RealizationRecord,
        context: GenerationContext,
        model: _ConversionModel,
        transformation: str,
        attributes: Dict[str, Any],
    ) -> RealizationRecord:
        signature = conversion_signature(
            as_flag(attributes[ATTR_TARGET_LAYOUT]),
            as_flag(attributes.get(ATTR_DUPLICATION_POLICY, POLICY_SINGLE_OWNER)),
            model,
            context.schema,
        )
        return propose_record(
            parent=parent,
            definition=self.definition,
            transformation=transformation,
            signature=signature,
            attributes=attributes,
            evidence_class=EvidenceClass.CONSTRUCTIVE,
        )

    def _obligations(
        self, record: RealizationRecord, context: GenerationContext
    ) -> Sequence[Obligation]:
        model = _model(context)
        target = as_flag(record.attributes.get(ATTR_TARGET_LAYOUT, ""))
        policy = as_flag(
            record.attributes.get(ATTR_DUPLICATION_POLICY, POLICY_SINGLE_OWNER)
        )
        retained, _assignment, steps = max_retention(
            model.source_cells, model.target_cells[target], model.atom_count
        )
        movement, overhead = record.signature.values[0], record.signature.values[1]
        held = retained + overhead if policy == POLICY_REPLICATED_BOUNDARY else retained
        return [
            Obligation(
                obligation_type=ObligationType.RESOURCE,
                realization_id=record.realization_id,
                name="residual_movement_measure",
                value=movement,
                unit="fraction-of-logical-space",
                scope="per-conversion-epoch",
                evidence_class=EvidenceClass.EXACT,
                source=self.definition.qualified_id,
            ),
            Obligation(
                obligation_type=ObligationType.ACCOUNTING,
                realization_id=record.realization_id,
                name="retained_region_measure",
                value=held,
                unit="fraction-of-logical-space",
                scope="per-conversion-epoch",
                evidence_class=EvidenceClass.EXACT,
                source=self.definition.qualified_id,
            ),
            Obligation(
                obligation_type=ObligationType.RESOURCE,
                realization_id=record.realization_id,
                name="duplicate_storage_measure",
                value=overhead,
                unit="fraction-of-logical-space",
                scope="per-conversion-epoch",
                evidence_class=EvidenceClass.EXACT,
                source=self.definition.qualified_id,
            ),
            Obligation(
                obligation_type=ObligationType.CAPABILITY,
                realization_id=record.realization_id,
                name=f"route_steps:{target}",
                value=Exact(steps),
                unit="route-step",
                scope="per-conversion-epoch",
                evidence_class=EvidenceClass.EXACT,
                source=self.definition.qualified_id,
            ),
        ]


def layout_conversion_generator(**kwargs: Any) -> LayoutConversionGenerator:
    """The reference layout-conversion generator (spec 36.5 pack 7)."""
    return LayoutConversionGenerator(**kwargs)


def layout_conversion_seed(
    context: GenerationContext, *, source_id: str = "layout-conversion-seed"
) -> RealizationRecord:
    """The seed realization: the first declared target, single ownership."""
    model = _model(context)
    target = model.target_names[0]
    return seed_record(
        source_id=source_id,
        signature=conversion_signature(target, POLICY_SINGLE_OWNER, model, context.schema),
        attributes={
            ATTR_TARGET_LAYOUT: target,
            ATTR_DUPLICATION_POLICY: POLICY_SINGLE_OWNER,
            ATTR_CONVERSION_STAGE: STAGE_TARGET_OPEN,
        },
        evidence_class=EvidenceClass.CONSTRUCTIVE,
    )


# ---------------------------------------------------------------------------
# manifest (36.2) and pack contents (36.4)
# ---------------------------------------------------------------------------

TERMINOLOGY: Dict[str, str] = {
    "logical space": "the normalized space of atoms a conversion redistributes; its "
    "contents are invariant under every transformation of this pack (spec 31.1)",
    "cell": "one equal-capacity part of a layout; the unit of ownership",
    "retained region": "the measure a target cell already owns under the chosen "
    "assignment and therefore need not receive",
    "residual region": "the measure a target cell must receive from elsewhere",
    "residual movement": "the total measure that must be routed, mu* = 1 - r*",
    "duplication policy": "whether a boundary region is moved once or held by both the "
    "source and the target owner",
    "route step": "one ordered source-cell to target-cell transfer the conversion plan "
    "must schedule",
}


def manifest_data() -> Dict[str, Any]:
    fields = manifest_fields(
        identity=PACK_IDENTITY,
        external_dependencies=(
            "crg-model (exact rationals, records, canonicalization)",
            "crg-generate (generator contract, legality, registry)",
            "none: this pack restates the assignment law of specification 31.2 rather than "
            "importing crg-convert, so crg-generate gains no package dependency",
        ),
        resource_requirements={
            "memory_mb": 32,
            "wall_clock_seconds": 1,
            "processes": 1,
            "network": "none",
            "note": "the assignment search is factorial in the cell count and is intended "
            "for the small declared partitions of a reference pack",
        },
        failure_modes=(
            "SKIP_AND_RECORD: a parent that does not name a declared target layout yields no "
            "child and is recorded as an UNGENERATED region, never as an infeasible one",
            "INFEASIBLE: a conversion whose residual movement exceeds the declared epoch "
            "budget is refused by a legality predicate",
            "FAIL_CLOSED at read time: a declared layout that is not an equal-capacity "
            "partition of the declared atoms is refused outright rather than approximated, "
            "because 31.2's assignment law is stated only for that case",
        ),
        quantity_registry_additions=(
            "conversion.residual_movement",
            "conversion.duplicate_storage",
            "conversion.retained_region_measure",
            "conversion.route_steps",
        ),
        proof_implications=(
            "the target index only increases and the duplication stage closes once, so the "
            "closure is finite and a fixpoint supports a GENERATOR_CLOSED completeness basis "
            "(spec 21.2)",
            "the retained fraction is the optimum of an enumerated bijection search, not the "
            "nested closed form; the closed form is licensed by 31.2 only when one cell "
            "count divides the other",
            "every measure is an exact rational over the declared atom count, so two "
            "conversions differing by one atom compare exactly (spec 14.2, 31.2)",
        ),
        conformance_tests=(
            "test_every_reference_pack_loads_and_validates",
            "test_every_reference_pack_reaches_a_generator_closed_basis",
            "test_layout_conversion_reports_residual_and_retained_measures",
        ),
        provenance={
            "repository": "CRGsys",
            "module": "crg_generate.reference_packs.layout_conversion",
            "specification": "36.5 initial reference pack 7 (layout conversion); vocabulary "
            "from section 31 (OID-CRG-004)",
            "derivation": "first-party reference implementation; restates 31.2 rather than "
            "importing crg-convert",
        },
    )
    fields["contents"] = {
        "terminology": TERMINOLOGY,
        "quantities": {
            "conversion.residual_movement": "fraction-of-logical-space",
            "conversion.duplicate_storage": "fraction-of-logical-space",
            "conversion.retained_region_measure": "fraction-of-logical-space",
            "conversion.route_steps": "route-step",
        },
        "contracts": {
            "computation_contract": "one declared logical space of equal atoms whose "
            "contents are invariant under conversion",
            "resource_contract": "a declared per-epoch movement budget",
            "hierarchy_contract": "an equal-capacity cell partition; the source layout and "
            "every target layout partition the same atoms into the same number of cells",
        },
        "accounting_rules": {
            "retained_region_measure": "max over bijections of the total overlap, divided by "
            "the atom count (spec 31.2)",
            "residual_movement": "1 - r* under single ownership; (1 - r*)(1 - replication "
            "share) under boundary replication",
            "duplicate_storage": "zero under single ownership; (1 - r*) times the replication "
            "share under boundary replication",
            "route_steps": "the count of ordered source-to-target pairs with a non-zero "
            "residual under the chosen assignment",
        },
        "transformations": [TRANSFORMATION_RETARGET, TRANSFORMATION_REPLICATE],
        "obligation_coordinates": [
            "residual_movement_measure",
            "retained_region_measure",
            "duplicate_storage_measure",
            "route_steps",
        ],
        "technology_coordinates": [
            "equal-capacity-partition",
            "declared-atom-count",
            "single-consistency-epoch",
        ],
        "evaluators": [
            "crg_generate.reference_packs.layout_conversion.max_retention",
            "crg_generate.reference_packs.layout_conversion.conversion_signature",
        ],
        "qualification_methods": [
            "re-enumerate the bijections and confirm the recorded retained fraction is the "
            "optimum",
            "confirm that retained plus residual equals the whole logical space for every "
            "realization",
        ],
        "proof_checkers": [],
        "ui_extensions": [],
        "example_cases": ["twelve-atoms-four-cells-three-declared-targets"],
        "conformance_fixtures": [
            "fixture: partial-regroup retains 5/6, shift-by-one-atom retains 2/3, and "
            "interleaved-round-robin retains 1/3",
            "fixture: under single ownership the six realizations are (1/6, 0), (1/3, 0), "
            "(2/3, 0) and under boundary replication (1/12, 1/12), (1/6, 1/6), (1/3, 1/3)",
            "fixture: for every realization the retained-region obligation and the "
            "residual-movement obligation sum to the whole logical space",
        ],
    }
    fields["extensions"] = {"generators": [layout_conversion_generator()]}
    return fields


def worked_example() -> WorkedExample:
    context = GenerationContext(
        schema=SCHEMA,
        capabilities={},
        parameters={CONVERSION_MODEL_KEY: REFERENCE_CONVERSION},
        permissions=tuple(GENERATOR_PERMISSIONS),
        declared_universe=_ConversionModel(REFERENCE_CONVERSION).universe_note,
        validity="the declared logical space, its declared layouts, and one conversion epoch",
    )
    seed = layout_conversion_seed(context)
    source = GenerationSource(
        source_id="layout-conversion-reference-space",
        source_type="CONVERSION_MODEL",
        seeds=(seed,),
        computation_contract={"contract_id": "conversion.logical-space", "version": "1"},
        resource_contract={"contract_id": "conversion.epoch-budget", "version": "1"},
        hierarchy_contract={"contract_id": "conversion.cell-partition", "version": "1"},
        declared_universe=_ConversionModel(REFERENCE_CONVERSION).universe_note,
    )
    return WorkedExample(
        name="twelve-atoms-four-cells-three-declared-targets",
        description=(
            "Twelve atoms in four equal cells. Three declared target layouts disturb the "
            "source ownership by increasing amounts, and each may be served either by moving "
            "the whole residual or by replicating half of it at the boundary."
        ),
        schema=SCHEMA,
        source=source,
        context=context,
        expected_realization_count=6,
        expected_legal_count=6,
        expected_signatures=(
            ("1/12", "1/12"),
            ("1/3", "0"),
            ("1/3", "1/3"),
            ("1/6", "0"),
            ("1/6", "1/6"),
            ("2/3", "0"),
        ),
        decision_query={
            "id": "layout-conversion-assignment-choice",
            "objective_family": {
                "type": "weighted_sum",
                "weights": {COORDINATE_MOVEMENT: "2", COORDINATE_OVERHEAD: "1"},
            },
            "quantification": "EACH_OBJECTIVE",
            "ties": {"policy_tolerance": "0", "retain_all": True},
        },
        notes=(
            "boundary replication halves residual movement and pays for it in duplicate "
            "storage; the two coordinates move in opposite directions",
            "every measure is an exact twelfth of the logical space",
        ),
    )
