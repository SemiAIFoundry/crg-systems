"""Shared scaffolding for the seven reference domain packs of section 36.5.

Normative basis: master specification section 36.2 (plugin manifest), 36.4
(domain-pack contents), and 36.5 (initial reference packs), read against
section 3.3 (domain neutrality), 6.5 (deterministic authority), and 6.7
(extensibility without core modification).

Nothing in this module is domain knowledge.  It carries the parts of a
manifest that are the *same* for every first-party reference pack -- the
publisher, the licence, the supported specification version, the permission
list this in-process loader can actually grant -- so that each pack module
contains only the thing that makes it that pack.

Two conventions are load-bearing and are enforced by the pack test suite:

* **Exact rationals only.**  Every quantity a pack computes is a
  :class:`crg_model.numeric.Exact`.  ``Exact`` refuses a binary float at
  construction, so a pack that tried to slip one in fails at the boundary
  rather than at the certificate (spec 14.2, 22.6).
* **Declared termination.**  Every pack's generator advances a bounded
  counter or flips a declared attribute one way, so the transitive closure of
  its transformation set is finite.  A generator whose closure is infinite can
  never reach a fixpoint, and a family that never reaches a fixpoint can only
  ever be ``TRUNCATED_BY_DECLARED_RULE`` (spec 21.2, 6.11).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Mapping, Sequence, Tuple

from crg_model.numeric import Exact
from crg_model.records import CoordinateSchema, RealizationRecord

from ..generator import (
    ATTR_DEPTH,
    ATTR_GENERATOR_HASH,
    ATTR_PATH,
    ATTR_TRANSFORMATION,
    DeterminismStatus,
    GenerationContext,
    GeneratorError,
)
from ..packs import Permission, SecurityClassification
from ..registry import GenerationSource

__all__ = [
    "PACK_VERSION",
    "PACK_PUBLISHER",
    "PACK_LICENSE",
    "SUPPORTED_SPEC_VERSIONS",
    "PACK_PERMISSIONS",
    "GENERATOR_PERMISSIONS",
    "RESERVED_ATTRIBUTES",
    "RECORD_SCHEMA",
    "WorkedExample",
    "manifest_fields",
    "carried_attributes",
    "read_model",
    "as_index",
    "as_flag",
    "signature_strings",
]

#: Every reference pack ships at the version of the specification it targets.
PACK_VERSION = "0.2.0"
PACK_PUBLISHER = (
    "semiAIfoundry Research, a research group within Semi AI Foundry, LLC"
)
PACK_LICENSE = "LicenseRef-CRG-Research-Noncommercial-1.0"
SUPPORTED_SPEC_VERSIONS: Tuple[str, ...] = ("0.2.0",)

RECORD_SCHEMA = "crg.realization-record@0.2.0"

#: The permissions a reference pack declares.  Every one of them is in
#: :data:`crg_generate.packs.Permission.IN_PROCESS_GRANTABLE`: a reference pack
#: reads the source and the context, proposes realizations, evaluates legality,
#: extracts obligations, and registers quantities.  None of them is in
#: ``Permission.REQUIRES_ISOLATION`` -- a first-party pack that asked for the
#: network or the filesystem would be asking this loader for a boundary it does
#: not have, and 36.3 says such a request must be refused, not granted
#: unenforced.
PACK_PERMISSIONS: Tuple[str, ...] = (
    Permission.READ_SOURCE,
    Permission.READ_CONTEXT,
    Permission.GENERATE_REALIZATIONS,
    Permission.EVALUATE_LEGALITY,
    Permission.EXTRACT_OBLIGATIONS,
    Permission.REGISTER_QUANTITIES,
)

#: What each pack's generator itself requires from the generation context.  The
#: registry refuses to invoke a generator whose declared permissions the
#: context does not carry, and records the region it would have covered as
#: ``UNGENERATED`` rather than as anything else (spec 36.2, 36.3, 28.4).
GENERATOR_PERMISSIONS: Tuple[str, ...] = (
    Permission.GENERATE_REALIZATIONS,
    Permission.EVALUATE_LEGALITY,
    Permission.EXTRACT_OBLIGATIONS,
)

#: Bookkeeping keys the registry owns; a transformation never copies them.
RESERVED_ATTRIBUTES = frozenset(
    {ATTR_TRANSFORMATION, ATTR_GENERATOR_HASH, ATTR_PATH, ATTR_DEPTH}
)


def manifest_fields(
    *,
    identity: str,
    external_dependencies: Sequence[str],
    resource_requirements: Mapping[str, Any],
    failure_modes: Sequence[str],
    quantity_registry_additions: Sequence[str],
    proof_implications: Sequence[str],
    conformance_tests: Sequence[str],
    provenance: Mapping[str, Any],
    input_schemas: Sequence[str] = (RECORD_SCHEMA,),
    output_schemas: Sequence[str] = (RECORD_SCHEMA,),
    permissions: Sequence[str] = PACK_PERMISSIONS,
    determinism_status: str = DeterminismStatus.DETERMINISTIC,
    security_classification: str = SecurityClassification.TRUSTED_FIRST_PARTY,
) -> Dict[str, Any]:
    """Every field specification 36.2 makes a MUST, filled with a real value.

    Nothing here defaults to a plausible value: a manifest that omitted its
    determinism status would have to read as *omitted*, and
    :func:`crg_generate.packs.validate_pack` would refuse it.  The reference
    packs therefore state all seventeen fields explicitly, and the pack test
    suite asserts that ``validate_pack`` returns an empty list for each.
    """
    return {
        "identity": identity,
        "version": PACK_VERSION,
        "publisher": PACK_PUBLISHER,
        "supported_spec_versions": list(SUPPORTED_SPEC_VERSIONS),
        "permissions": list(permissions),
        "input_schemas": list(input_schemas),
        "output_schemas": list(output_schemas),
        "determinism_status": determinism_status,
        "external_dependencies": list(external_dependencies),
        "resource_requirements": dict(resource_requirements),
        "failure_modes": list(failure_modes),
        "license": PACK_LICENSE,
        "provenance": dict(provenance),
        "security_classification": security_classification,
        "quantity_registry_additions": list(quantity_registry_additions),
        "proof_implications": list(proof_implications),
        "conformance_tests": list(conformance_tests),
    }


@dataclass(frozen=True)
class WorkedExample:
    """One worked example of specification 36.4 ("example cases").

    A worked example is not documentation: it carries the seed, the generation
    context, and the result the pack's author claims the generator produces.
    The pack test suite runs it and compares, so a pack whose stated example
    stopped matching its generator fails rather than drifts.
    """

    name: str
    description: str
    schema: CoordinateSchema
    source: GenerationSource
    context: GenerationContext
    expected_realization_count: int
    expected_legal_count: int
    expected_signatures: Tuple[Tuple[str, ...], ...]
    decision_query: Mapping[str, Any] = field(default_factory=dict)
    notes: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if self.expected_realization_count < 1:
            raise GeneratorError(
                f"worked example {self.name!r} expects no realization at all; an example that "
                "predicts an empty family cannot demonstrate anything (spec 36.4)"
            )
        if not self.expected_signatures:
            raise GeneratorError(
                f"worked example {self.name!r} states no expected signature; an example whose "
                "expected result is unstated cannot be checked (spec 36.2 conformance tests)"
            )


def carried_attributes(record: RealizationRecord) -> Dict[str, Any]:
    """The parent's own attributes, without the registry's bookkeeping keys."""
    return {
        key: value
        for key, value in record.attributes.items()
        if key not in RESERVED_ATTRIBUTES
    }


def read_model(context: GenerationContext, key: str) -> Mapping[str, Any]:
    """Read a declared domain model out of the generation context.

    ``context.require`` refuses a missing key rather than defaulting it: an
    absent parameter MUST remain absent rather than become a value (spec 6.6,
    37.3), because a model silently defaulted to zero would produce a family
    of realizations of nothing.
    """
    model = context.require(key)
    if not isinstance(model, Mapping):
        raise GeneratorError(
            f"the generation context parameter {key!r} must be a mapping, got "
            f"{type(model).__name__}"
        )
    return model


def as_index(value: Any) -> int:
    """Read a declared integer index; a non-integer cannot bound a closure."""
    if isinstance(value, bool):
        raise GeneratorError("a boolean is not an index")
    if isinstance(value, int):
        return value
    if isinstance(value, str) and value.strip().lstrip("-").isdigit():
        return int(value.strip())
    raise GeneratorError(
        f"expected an integer index attribute, got {value!r}; an index that is not an "
        "integer cannot bound a transformation closure (spec 21.2)"
    )


def as_flag(value: Any) -> str:
    """Read a declared string-valued attribute in a canonical form."""
    return "" if value is None else str(value)


def signature_strings(record: RealizationRecord) -> Tuple[str, ...]:
    """The record's exact signature as canonical rational strings."""
    return tuple(str(Exact(v)) for v in record.signature.values)
