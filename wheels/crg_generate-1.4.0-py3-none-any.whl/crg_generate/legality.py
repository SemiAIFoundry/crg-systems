"""Legality predicates and the six distinct legality states.

Normative basis: master specification section 28 (OID-CRG-001 legal-realization
representation), in particular 28.4 (generator contract) and 28.6 (acceptance
criteria), with section 5.3 (evidence classes) and section 6.6 (fail closed).

Specification 28.6 requires that *illegal, infeasible, ungenerated,
unevaluated, and unsupported states remain distinct*.  They are five different
epistemic situations and collapsing any two of them makes the software lie
about the legal family:

``LEGAL``
    Every applicable predicate ran and admitted the candidate.  This is the
    only state that enters ``R`` (spec 19.2, ``crg_geometry.build_R``).
``ILLEGAL``
    A predicate ran and *refused* the candidate: the construction violates a
    declared rule.  A determinate negative fact about the candidate.
``INFEASIBLE``
    A predicate ran and found no admissible assignment for the candidate under
    the declared context: constructible, but not realizable here.  Also a
    determinate negative fact, and a *different* one -- an illegal candidate is
    never legal anywhere, an infeasible candidate may be feasible elsewhere.
``UNGENERATED``
    Nothing was ever proposed.  No predicate ran because there was nothing to
    run one on.  This is the absence of a fact, not a fact.
``UNEVALUATED``
    A candidate exists but no applicable predicate ran on it (no predicate was
    registered, or every registered predicate declared itself inapplicable).
``UNSUPPORTED``
    A predicate exists and applies, but cannot decide this candidate in this
    context -- missing context, missing evidence, or an author-declared
    inability.  The question is in scope and the answer is unavailable.

The single most important rule of the module lives here and in
:mod:`crg_generate.registry`:

    *A generator MUST NOT represent an ungenerated candidate as infeasible*
    (spec 28.4).

``UNGENERATED`` is therefore not a verdict any predicate may return.  A
predicate that returns it is misusing the vocabulary -- it is claiming to have
evaluated something that by definition was never produced -- and
:func:`evaluate_legality` raises :class:`LegalityError` rather than accept it.
``UNGENERATED`` is produced only by :mod:`crg_generate.registry`, only for
regions no generator was able or permitted to enter, and it never becomes a
realization record.

Resolution is fail-closed (spec 6.6): a determinate refusal outranks an
indeterminate one, and any indeterminacy outranks ``LEGAL``.
"""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from typing import Any, Callable, Dict, List, Mapping, Optional, Sequence, Tuple

from crg_model.canonical import content_hash
from crg_model.envelope import EvidenceClass
from crg_model.numeric import Exact
from crg_model.records import RealizationRecord

__all__ = [
    "LegalityStatus",
    "LegalityError",
    "LegalityPredicate",
    "LegalityVerdict",
    "LegalityResult",
    "evaluate_legality",
    "context_fingerprint",
    "describe_status",
]


class LegalityStatus:
    """The six states of specification 28.6, which MUST remain distinct."""

    LEGAL = "LEGAL"
    ILLEGAL = "ILLEGAL"
    INFEASIBLE = "INFEASIBLE"
    UNGENERATED = "UNGENERATED"
    UNEVALUATED = "UNEVALUATED"
    UNSUPPORTED = "UNSUPPORTED"

    ALL = frozenset({LEGAL, ILLEGAL, INFEASIBLE, UNGENERATED, UNEVALUATED, UNSUPPORTED})

    #: Verdicts a legality predicate may return.  ``UNGENERATED`` is absent by
    #: construction: a predicate that ran had something to run on (spec 28.4).
    PREDICATE_VERDICTS = frozenset({LEGAL, ILLEGAL, INFEASIBLE, UNSUPPORTED, UNEVALUATED})

    #: Determinate negative facts established by evaluation.
    DETERMINATE_NEGATIVE = frozenset({ILLEGAL, INFEASIBLE})

    #: States that record an absence of knowledge rather than knowledge.
    INDETERMINATE = frozenset({UNGENERATED, UNEVALUATED, UNSUPPORTED})

    #: Only this state admits a realization into R (spec 19.2, 28.6).
    ADMITS_TO_GEOMETRY = frozenset({LEGAL})

    #: Fail-closed resolution order: the first state present wins.  A refusal
    #: outranks an indeterminacy; every indeterminacy outranks LEGAL.
    RESOLUTION_ORDER = (ILLEGAL, INFEASIBLE, UNSUPPORTED, UNEVALUATED, LEGAL)


STATUS_MEANING: Dict[str, str] = {
    LegalityStatus.LEGAL: (
        "every applicable legality predicate ran and admitted this candidate"
    ),
    LegalityStatus.ILLEGAL: (
        "a legality predicate ran and refused this candidate: the construction violates a "
        "declared rule and is not legal in any context of this contract"
    ),
    LegalityStatus.INFEASIBLE: (
        "a legality predicate ran and found no admissible assignment under the declared "
        "context: the candidate is constructible but not realizable here"
    ),
    LegalityStatus.UNGENERATED: (
        "no generator proposed this candidate; nothing is known about it and nothing is "
        "claimed about it (spec 28.4: an ungenerated candidate MUST NOT be reported as "
        "infeasible)"
    ),
    LegalityStatus.UNEVALUATED: (
        "the candidate exists but no applicable legality predicate ran on it"
    ),
    LegalityStatus.UNSUPPORTED: (
        "an applicable legality predicate could not decide this candidate in this context: "
        "the question is in scope and the answer is unavailable"
    ),
}


def describe_status(status: str) -> str:
    """Return the normative meaning of ``status`` (spec 28.6)."""
    if status not in LegalityStatus.ALL:
        raise LegalityError(f"unknown legality status {status!r}")
    return STATUS_MEANING[status]


class LegalityError(ValueError):
    """Raised when the legality vocabulary itself is misused."""


# ---------------------------------------------------------------------------
# context canonicalization
# ---------------------------------------------------------------------------


def _as_mapping(context: Any) -> Mapping[str, Any]:
    """Read ``context`` as a mapping without inventing content."""
    if context is None:
        return {}
    if isinstance(context, Mapping):
        return context
    for attribute in ("as_mapping", "to_mapping", "to_canonical"):
        reader = getattr(context, attribute, None)
        if callable(reader):
            value = reader()
            if isinstance(value, Mapping):
                return value
    raise LegalityError(
        f"cannot read a legality context from {type(context).__name__}; supply a mapping "
        "or an object exposing as_mapping()"
    )


def _canonicalizable(value: Any) -> Any:
    """Reduce ``value`` to canonical JSON content, refusing binary floats.

    An object with no canonical encoding becomes an opaque type tag rather than
    a guessed serialization: the fingerprint then records *that* the context
    carried something opaque, which is honest, instead of pretending it did not.
    """
    if isinstance(value, float):
        raise LegalityError(
            "binary floating point is not admissible in a legality context; supply an "
            "exact representation (spec 14.2)"
        )
    if value is None or isinstance(value, (bool, int, str)):
        return value
    if isinstance(value, (Exact, Fraction)):
        return Exact(value).to_canonical()
    if isinstance(value, Mapping):
        return {str(k): _canonicalizable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_canonicalizable(v) for v in value]
    to_canonical = getattr(value, "to_canonical", None)
    if callable(to_canonical):
        return _canonicalizable(to_canonical())
    return {"opaque": type(value).__name__}


def context_fingerprint(context: Any) -> str:
    """``sha256:<hex>`` over the canonical content of a legality context.

    The fingerprint is part of every :class:`LegalityResult` because a legality
    verdict is a statement *about a context* (spec 18.3
    ``DEPENDS_ON_CONTEXT_FINGERPRINT``): the same candidate may be legal under
    one declared context and infeasible under another, and a verdict that did
    not name its context could not be invalidated when the context changed.
    """
    return content_hash(_canonicalizable(_as_mapping(context)))


# ---------------------------------------------------------------------------
# predicates (spec 28.4 "legality predicates")
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class LegalityPredicate:
    """One declared legality predicate.

    ``evaluate`` receives ``(realization, context)`` and returns any of:

    * ``True`` / ``False`` -- admitted, or refused with :attr:`false_status`;
    * a status string from :attr:`LegalityStatus.PREDICATE_VERDICTS`;
    * ``(status, reason)``.

    ``False`` is deliberately *not* hardwired to ``ILLEGAL``: a feasibility
    predicate declares ``false_status=INFEASIBLE`` so that the two determinate
    negatives are chosen by the predicate's author rather than assumed by this
    module (spec 28.6).

    Returning ``None`` is not a verdict; it resolves to ``UNSUPPORTED``, which
    fails closed rather than reading silence as consent (spec 6.6).
    """

    predicate_id: str
    version: str
    description: str
    evaluate: Callable[[RealizationRecord, Mapping[str, Any]], Any]
    applies_to: Optional[Callable[[RealizationRecord, Mapping[str, Any]], bool]] = None
    required_context: Tuple[str, ...] = ()
    false_status: str = LegalityStatus.ILLEGAL
    evidence_class: str = EvidenceClass.CONSTRUCTIVE
    #: Status assigned when ``evaluate`` raises.  It MUST be indeterminate: an
    #: exception is a failure to decide, never a decision (spec 6.6, 28.4).
    failure_status: str = LegalityStatus.UNSUPPORTED

    def __post_init__(self) -> None:
        if not self.predicate_id:
            raise LegalityError("a legality predicate MUST declare an identity (spec 28.4)")
        if not self.version:
            raise LegalityError(
                f"legality predicate {self.predicate_id!r} MUST declare a version (spec 28.4)"
            )
        if not callable(self.evaluate):
            raise LegalityError(f"legality predicate {self.predicate_id!r} is not callable")
        if self.false_status not in LegalityStatus.DETERMINATE_NEGATIVE:
            raise LegalityError(
                f"legality predicate {self.predicate_id!r} declares false_status="
                f"{self.false_status!r}; a refusal is ILLEGAL or INFEASIBLE, and the two "
                "MUST NOT be merged (spec 28.6)"
            )
        if self.failure_status not in {
            LegalityStatus.UNSUPPORTED,
            LegalityStatus.UNEVALUATED,
        }:
            raise LegalityError(
                f"legality predicate {self.predicate_id!r} declares failure_status="
                f"{self.failure_status!r}; a predicate that raised did not decide anything, "
                "so its failure MUST remain indeterminate (spec 6.6)"
            )
        if self.evidence_class not in EvidenceClass.ALL:
            raise LegalityError(
                f"legality predicate {self.predicate_id!r} declares unknown evidence class "
                f"{self.evidence_class!r} (spec 5.3)"
            )

    @property
    def qualified_id(self) -> str:
        return f"{self.predicate_id}@{self.version}"

    def to_canonical(self) -> dict:
        """Canonical declaration.  The callable is identity, not content."""
        return {
            "predicate_id": self.predicate_id,
            "version": self.version,
            "description": self.description,
            "required_context": list(self.required_context),
            "false_status": self.false_status,
            "evidence_class": self.evidence_class,
            "failure_status": self.failure_status,
        }

    def definition_hash(self) -> str:
        return content_hash(self.to_canonical())


@dataclass(frozen=True)
class LegalityVerdict:
    """What one predicate concluded about one candidate."""

    predicate_id: str
    predicate_version: str
    status: str
    reason: str
    evidence_class: str = EvidenceClass.CONSTRUCTIVE

    def to_canonical(self) -> dict:
        return {
            "predicate_id": self.predicate_id,
            "predicate_version": self.predicate_version,
            "status": self.status,
            "reason": self.reason,
            "evidence_class": self.evidence_class,
        }


@dataclass(frozen=True)
class LegalityResult:
    """The resolved legality of one candidate, with every verdict retained.

    The resolved :attr:`status` never erases the individual verdicts: a
    candidate that is ``ILLEGAL`` by one predicate and ``UNSUPPORTED`` by
    another has recorded both, so a later change to either predicate can be
    attributed exactly (spec 28.6 traceability).
    """

    status: str
    reason: str
    verdicts: Tuple[LegalityVerdict, ...] = ()
    evaluated: Tuple[str, ...] = ()
    inapplicable: Tuple[str, ...] = ()
    context_fingerprint: str = ""

    def __post_init__(self) -> None:
        if self.status not in LegalityStatus.ALL:
            raise LegalityError(f"unknown legality status {self.status!r}")

    @property
    def is_legal(self) -> bool:
        return self.status == LegalityStatus.LEGAL

    @property
    def admits_to_geometry(self) -> bool:
        """Spec 19.2/28.6: only a LEGAL realization is a member of R."""
        return self.status in LegalityStatus.ADMITS_TO_GEOMETRY

    @property
    def is_determinate(self) -> bool:
        """True when evaluation established a fact, negative or positive."""
        return self.status not in LegalityStatus.INDETERMINATE

    def statuses(self) -> Tuple[str, ...]:
        return tuple(v.status for v in self.verdicts)

    def to_canonical(self) -> dict:
        record: dict = {
            "status": self.status,
            "reason": self.reason,
            "verdicts": [v.to_canonical() for v in self.verdicts],
        }
        if self.evaluated:
            record["evaluated"] = list(self.evaluated)
        if self.inapplicable:
            record["inapplicable"] = list(self.inapplicable)
        if self.context_fingerprint:
            record["context_fingerprint"] = self.context_fingerprint
        return record


# ---------------------------------------------------------------------------
# evaluation (spec 28.3 step 5)
# ---------------------------------------------------------------------------


def _normalize(
    predicate: LegalityPredicate, outcome: Any
) -> Tuple[str, str]:
    """Read a predicate's return value as ``(status, reason)``.

    ``UNGENERATED`` is refused here, not translated: a predicate that ran had a
    candidate to run on, so claiming the candidate was never generated is a
    contradiction, and silently rewriting it would hide the author's error
    behind a plausible state (spec 28.4).
    """
    reason = ""
    status: Any = outcome
    if isinstance(outcome, tuple):
        if len(outcome) != 2:
            raise LegalityError(
                f"legality predicate {predicate.qualified_id} returned a {len(outcome)}-tuple; "
                "expected (status, reason)"
            )
        status, reason = outcome[0], str(outcome[1])
    if status is True:
        return LegalityStatus.LEGAL, reason or f"admitted by {predicate.qualified_id}"
    if status is False:
        return (
            predicate.false_status,
            reason or f"refused by {predicate.qualified_id}",
        )
    if status is None:
        return (
            LegalityStatus.UNSUPPORTED,
            reason
            or (
                f"legality predicate {predicate.qualified_id} returned no verdict; silence is "
                "not consent (spec 6.6)"
            ),
        )
    if not isinstance(status, str):
        raise LegalityError(
            f"legality predicate {predicate.qualified_id} returned {type(status).__name__}; "
            "expected a bool, a legality status, or (status, reason)"
        )
    if status == LegalityStatus.UNGENERATED:
        raise LegalityError(
            f"legality predicate {predicate.qualified_id} returned UNGENERATED. A predicate "
            "that ran had a candidate to run on, so UNGENERATED is not one of its verdicts: "
            "an ungenerated candidate is one no generator proposed, and it MUST NOT be "
            "represented as evaluated, illegal, or infeasible (spec 28.4, 28.6)."
        )
    if status not in LegalityStatus.PREDICATE_VERDICTS:
        raise LegalityError(
            f"legality predicate {predicate.qualified_id} returned unknown status {status!r}; "
            f"admissible verdicts are {sorted(LegalityStatus.PREDICATE_VERDICTS)}"
        )
    return status, reason or f"{status} per {predicate.qualified_id}"


def evaluate_legality(
    realization: RealizationRecord,
    predicates: Sequence[LegalityPredicate],
    context: Any = None,
) -> LegalityResult:
    """Evaluate ``predicates`` against ``realization`` (spec 28.3 step 5).

    Evaluation is total and fail-closed:

    * a predicate whose ``applies_to`` says no is recorded as inapplicable and
      contributes no verdict;
    * a predicate whose ``required_context`` keys are absent yields
      ``UNSUPPORTED`` -- it is not skipped, because the question it asks is
      still open (spec 6.6 "missing evidence applicability");
    * a predicate that raises yields its declared ``failure_status``, which is
      indeterminate by construction, and the exception text is retained;
    * with no applicable predicate at all the result is ``UNEVALUATED``, which
      is not ``LEGAL`` and is not ``INFEASIBLE``.

    The resolved status is the first of
    ``ILLEGAL, INFEASIBLE, UNSUPPORTED, UNEVALUATED, LEGAL`` that appears among
    the verdicts, so a determinate refusal is never softened by an
    indeterminate verdict and an indeterminate verdict is never rounded up to
    ``LEGAL``.
    """
    mapping = _as_mapping(context)
    fingerprint = context_fingerprint(mapping)
    verdicts: List[LegalityVerdict] = []
    evaluated: List[str] = []
    inapplicable: List[str] = []

    seen: Dict[str, str] = {}
    for predicate in predicates:
        if predicate.qualified_id in seen:
            raise LegalityError(
                f"legality predicate {predicate.qualified_id} is registered twice; a verdict "
                "counted twice is not a verdict (spec 28.4)"
            )
        seen[predicate.qualified_id] = predicate.definition_hash()

        if predicate.applies_to is not None:
            try:
                applies = bool(predicate.applies_to(realization, mapping))
            except Exception as error:  # noqa: BLE001 - applicability failure is indeterminate
                verdicts.append(
                    LegalityVerdict(
                        predicate_id=predicate.predicate_id,
                        predicate_version=predicate.version,
                        status=LegalityStatus.UNSUPPORTED,
                        reason=(
                            "applicability rule raised "
                            f"{type(error).__name__}: {error}; applicability is undecided, so "
                            "the candidate is not admitted (spec 6.6)"
                        ),
                        evidence_class=predicate.evidence_class,
                    )
                )
                evaluated.append(predicate.qualified_id)
                continue
            if not applies:
                inapplicable.append(predicate.qualified_id)
                continue

        missing = [key for key in predicate.required_context if key not in mapping]
        if missing:
            verdicts.append(
                LegalityVerdict(
                    predicate_id=predicate.predicate_id,
                    predicate_version=predicate.version,
                    status=LegalityStatus.UNSUPPORTED,
                    reason=(
                        "required context absent: "
                        + ", ".join(sorted(missing))
                        + "; the predicate applies but cannot decide, which is UNSUPPORTED "
                        "and never INFEASIBLE (spec 28.6)"
                    ),
                    evidence_class=predicate.evidence_class,
                )
            )
            evaluated.append(predicate.qualified_id)
            continue

        try:
            outcome = predicate.evaluate(realization, mapping)
        except LegalityError:
            raise
        except Exception as error:  # noqa: BLE001 - a failure to decide, not a decision
            verdicts.append(
                LegalityVerdict(
                    predicate_id=predicate.predicate_id,
                    predicate_version=predicate.version,
                    status=predicate.failure_status,
                    reason=(
                        f"predicate raised {type(error).__name__}: {error}; per its declared "
                        f"failure semantics this is {predicate.failure_status}, not a refusal"
                    ),
                    evidence_class=predicate.evidence_class,
                )
            )
            evaluated.append(predicate.qualified_id)
            continue

        status, reason = _normalize(predicate, outcome)
        verdicts.append(
            LegalityVerdict(
                predicate_id=predicate.predicate_id,
                predicate_version=predicate.version,
                status=status,
                reason=reason,
                evidence_class=predicate.evidence_class,
            )
        )
        evaluated.append(predicate.qualified_id)

    if not verdicts:
        return LegalityResult(
            status=LegalityStatus.UNEVALUATED,
            reason=(
                "no applicable legality predicate ran on this candidate; UNEVALUATED is not "
                "LEGAL and is not INFEASIBLE (spec 28.6)"
                if predicates
                else "no legality predicate was registered; the candidate is UNEVALUATED "
                "(spec 28.6), and an unevaluated candidate MUST NOT be certified (spec 6.6)"
            ),
            verdicts=(),
            evaluated=tuple(evaluated),
            inapplicable=tuple(inapplicable),
            context_fingerprint=fingerprint,
        )

    present = {v.status for v in verdicts}
    resolved = next(
        status for status in LegalityStatus.RESOLUTION_ORDER if status in present
    )
    deciding = [v for v in verdicts if v.status == resolved]
    if resolved == LegalityStatus.LEGAL:
        reason = (
            f"admitted by {len(deciding)} applicable legality predicate(s): "
            + ", ".join(v.predicate_id for v in deciding)
        )
    else:
        reason = "; ".join(f"{v.predicate_id}: {v.reason}" for v in deciding)
    return LegalityResult(
        status=resolved,
        reason=reason,
        verdicts=tuple(verdicts),
        evaluated=tuple(evaluated),
        inapplicable=tuple(inapplicable),
        context_fingerprint=fingerprint,
    )
