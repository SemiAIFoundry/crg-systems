"""Typed extension contracts for every SDK extension category in §36.1.

This module does not discover code.  A host explicitly binds a reviewed
callable to a complete immutable definition, grants permissions, and invokes it
through one registry that hashes inputs/outputs and records failures.  Isolation
remains the responsibility of the selected execution path (§36.3).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Mapping, Optional, Sequence, Tuple

from crg_model.canonical import content_hash

__all__ = [
    "ExtensionError", "ExtensionType", "ExtensionDefinition", "ExtensionBinding",
    "ExtensionInvocation", "ExtensionRegistry",
]


class ExtensionError(ValueError):
    """An extension is undeclared, unauthorized, incompatible, or failed."""


class ExtensionType:
    SOURCE_ADAPTER = "SOURCE_ADAPTER"
    REGISTRY_IMPORTER = "REGISTRY_IMPORTER"
    SEMANTIC_NORMALIZER = "SEMANTIC_NORMALIZER"
    REALIZATION_GENERATOR = "REALIZATION_GENERATOR"
    LEGALITY_PREDICATE = "LEGALITY_PREDICATE"
    OBLIGATION_EXTRACTOR = "OBLIGATION_EXTRACTOR"
    BOUND_PROVIDER = "BOUND_PROVIDER"
    WITNESS_GENERATOR = "WITNESS_GENERATOR"
    GEOMETRY_BACKEND = "GEOMETRY_BACKEND"
    OBJECTIVE_FUNCTION = "OBJECTIVE_FUNCTION"
    PHYSICAL_EVALUATOR = "PHYSICAL_EVALUATOR"
    EVIDENCE_IMPORTER = "EVIDENCE_IMPORTER"
    APPLICABILITY_RULE = "APPLICABILITY_RULE"
    UNCERTAINTY_FUSION_RULE = "UNCERTAINTY_FUSION_RULE"
    EXPERIMENT_TEMPLATE = "EXPERIMENT_TEMPLATE"
    RUNTIME_TRANSITION_ADAPTER = "RUNTIME_TRANSITION_ADAPTER"
    PROOF_CHECKER = "PROOF_CHECKER"
    CERTIFICATE_RENDERER = "CERTIFICATE_RENDERER"

    ALL = frozenset({
        SOURCE_ADAPTER, REGISTRY_IMPORTER, SEMANTIC_NORMALIZER,
        REALIZATION_GENERATOR, LEGALITY_PREDICATE, OBLIGATION_EXTRACTOR,
        BOUND_PROVIDER, WITNESS_GENERATOR, GEOMETRY_BACKEND,
        OBJECTIVE_FUNCTION, PHYSICAL_EVALUATOR, EVIDENCE_IMPORTER,
        APPLICABILITY_RULE, UNCERTAINTY_FUSION_RULE, EXPERIMENT_TEMPLATE,
        RUNTIME_TRANSITION_ADAPTER, PROOF_CHECKER, CERTIFICATE_RENDERER,
    })


@dataclass(frozen=True)
class ExtensionDefinition:
    extension_id: str
    extension_type: str
    version: str
    input_schema: str
    output_schema: str
    determinism_status: str
    implementation_identity: str
    required_permissions: Tuple[str, ...] = ()
    failure_modes: Tuple[str, ...] = ()
    conformance_tests: Tuple[str, ...] = ()
    semantic_scope: str = ""

    def __post_init__(self) -> None:
        for name in (
            "extension_id", "extension_type", "version", "input_schema",
            "output_schema", "determinism_status", "implementation_identity",
            "semantic_scope",
        ):
            if not str(getattr(self, name)).strip():
                raise ExtensionError(f"extension definition omits {name!r} (§36.1, §36.2)")
        if self.extension_type not in ExtensionType.ALL:
            raise ExtensionError(
                f"unknown extension type {self.extension_type!r}; expected "
                f"one of {sorted(ExtensionType.ALL)}"
            )
        if not self.failure_modes:
            raise ExtensionError("extension definition requires declared failure modes")
        if not self.conformance_tests:
            raise ExtensionError("extension definition requires conformance tests")
        if len(set(self.required_permissions)) != len(self.required_permissions):
            raise ExtensionError("extension required_permissions contains duplicates")

    @property
    def qualified_id(self) -> str:
        return f"{self.extension_id}@{self.version}"

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "extension_id": self.extension_id,
            "extension_type": self.extension_type,
            "version": self.version,
            "input_schema": self.input_schema,
            "output_schema": self.output_schema,
            "determinism_status": self.determinism_status,
            "implementation_identity": self.implementation_identity,
            "required_permissions": sorted(self.required_permissions),
            "failure_modes": list(self.failure_modes),
            "conformance_tests": list(self.conformance_tests),
            "semantic_scope": self.semantic_scope,
        }

    def definition_hash(self) -> str:
        return content_hash(self.to_canonical())


@dataclass(frozen=True)
class ExtensionBinding:
    definition: ExtensionDefinition
    handler: Callable[[Mapping[str, Any], Mapping[str, Any]], Mapping[str, Any]]

    def __post_init__(self) -> None:
        if not callable(self.handler):
            raise ExtensionError("extension handler must be callable")


@dataclass(frozen=True)
class ExtensionInvocation:
    sequence: int
    extension_id: str
    extension_type: str
    definition_hash: str
    actor: str
    input_hash: str
    output_hash: Optional[str]
    status: str
    failure: str = ""
    replay_hash: Optional[str] = None
    granted_permissions: Tuple[str, ...] = ()

    def to_canonical(self) -> Dict[str, Any]:
        return {
            "sequence": self.sequence,
            "extension_id": self.extension_id,
            "extension_type": self.extension_type,
            "definition_hash": self.definition_hash,
            "actor": self.actor,
            "input_hash": self.input_hash,
            "output_hash": self.output_hash,
            "status": self.status,
            "failure": self.failure,
            "replay_hash": self.replay_hash,
            "granted_permissions": list(self.granted_permissions),
        }


class ExtensionRegistry:
    """Explicit extension bindings with deny-by-default invocation."""

    def __init__(self) -> None:
        self._bindings: Dict[str, ExtensionBinding] = {}
        self._invocations: List[ExtensionInvocation] = []

    @property
    def extension_ids(self) -> Tuple[str, ...]:
        return tuple(sorted(self._bindings))

    @property
    def invocations(self) -> Tuple[ExtensionInvocation, ...]:
        return tuple(self._invocations)

    def register(self, binding: ExtensionBinding) -> None:
        name = binding.definition.extension_id
        if name in self._bindings:
            raise ExtensionError(f"extension {name!r} is already registered")
        self._bindings[name] = binding

    def definitions(self, extension_type: Optional[str] = None) -> Tuple[ExtensionDefinition, ...]:
        values = [binding.definition for binding in self._bindings.values()]
        if extension_type is not None:
            if extension_type not in ExtensionType.ALL:
                raise ExtensionError(f"unknown extension type {extension_type!r}")
            values = [value for value in values if value.extension_type == extension_type]
        return tuple(sorted(values, key=lambda value: value.extension_id))

    def invoke(
        self,
        extension_id: str,
        payload: Mapping[str, Any],
        *,
        actor: str,
        granted_permissions: Sequence[str] = (),
        context: Optional[Mapping[str, Any]] = None,
        expected_type: Optional[str] = None,
        verify_determinism: bool = True,
    ) -> Mapping[str, Any]:
        binding = self._bindings.get(str(extension_id))
        if binding is None:
            raise ExtensionError(f"extension {extension_id!r} is not registered")
        definition = binding.definition
        if expected_type is not None and definition.extension_type != expected_type:
            raise ExtensionError(
                f"extension {extension_id!r} is {definition.extension_type}, not {expected_type}"
            )
        if not isinstance(payload, Mapping):
            raise ExtensionError("extension input must be a mapping")
        if not str(actor).strip():
            raise ExtensionError("extension invocation requires an attributable actor")
        grants = tuple(sorted(set(str(value) for value in granted_permissions)))
        missing = sorted(set(definition.required_permissions) - set(grants))
        input_hash = content_hash(dict(payload))
        if missing:
            self._record(definition, actor, input_hash, None, "REFUSED",
                         f"missing permissions {missing}", None, grants)
            raise ExtensionError(
                f"extension {extension_id!r} requires ungranted permissions {missing}"
            )
        invocation_context = dict(context or {})
        invocation_context.update({
            "actor": str(actor),
            "extension_id": definition.extension_id,
            "extension_type": definition.extension_type,
            "definition_hash": definition.definition_hash(),
            "granted_permissions": list(grants),
        })
        try:
            first = binding.handler(dict(payload), dict(invocation_context))
            if not isinstance(first, Mapping):
                raise ExtensionError("extension handler returned a non-mapping output")
            first = dict(first)
            output_hash = content_hash(first)
            replay_hash = None
            if verify_determinism and definition.determinism_status == "DETERMINISTIC":
                replay = binding.handler(dict(payload), dict(invocation_context))
                if not isinstance(replay, Mapping):
                    raise ExtensionError("determinism replay returned a non-mapping output")
                replay_hash = content_hash(dict(replay))
                if replay_hash != output_hash:
                    raise ExtensionError(
                        f"determinism replay disagreed: {output_hash} versus {replay_hash}"
                    )
        except Exception as error:
            self._record(definition, actor, input_hash, None, "FAILED",
                         f"{type(error).__name__}: {error}", None, grants)
            if isinstance(error, ExtensionError):
                raise
            raise ExtensionError(
                f"extension {extension_id!r} failed: {type(error).__name__}: {error}"
            ) from error
        self._record(definition, actor, input_hash, output_hash, "SUCCEEDED", "",
                     replay_hash, grants)
        return first

    def _record(
        self, definition: ExtensionDefinition, actor: str, input_hash: str,
        output_hash: Optional[str], status: str, failure: str,
        replay_hash: Optional[str], grants: Tuple[str, ...],
    ) -> None:
        self._invocations.append(ExtensionInvocation(
            sequence=len(self._invocations) + 1,
            extension_id=definition.extension_id,
            extension_type=definition.extension_type,
            definition_hash=definition.definition_hash(),
            actor=str(actor), input_hash=input_hash, output_hash=output_hash,
            status=status, failure=failure, replay_hash=replay_hash,
            granted_permissions=grants,
        ))
