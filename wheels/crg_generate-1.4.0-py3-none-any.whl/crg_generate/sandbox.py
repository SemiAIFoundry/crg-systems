"""Real plugin isolation: the confined path a pack may take (spec 36.3).

Normative basis: master specification 36.3 (plugin isolation), with 36.2 (the
plugin manifest and its permission list), 6.6 (fail closed), 14.2--14.4
(canonicalization and hashing), 14.5 (signature profiles), and 28.4 (the
generator contract an isolated generator still has to satisfy).

:mod:`crg_generate.packs` says, correctly, that an in-process loader can
provide none of the first five bullets of 36.3: once a pack's code runs in this
interpreter it can do whatever this interpreter can do.  That statement is a
fact about *in-process loading*, not about the specification, and this module
is the other half of the answer.  It gives a pack a second, confined path --
:func:`run_sandboxed`, reached from :func:`crg_generate.packs.load_sandboxed_pack`
-- under which the permissions ``FILESYSTEM_READ``, ``FILESYSTEM_WRITE``,
``NETWORK``, ``SUBPROCESS``, and ``SECRETS`` become *grantable and enforced*
rather than refused.  The in-process path is unchanged and still refuses them:
a host that has not asked for isolation does not get it, and must not be told
it did.

Each bullet of 36.3, and what this module actually does about it:

* **Isolated process.**  The plugin runs in a separate CPython process started
  from :mod:`crg_generate._sandbox_child`, talking to the host over pipes in
  canonical JSON.  ``pickle`` never appears: a pickle stream is code execution
  by another name, and a host that unpickles an untrusted plugin's reply has
  isolated nothing.  The host never imports plugin source.
* **Restricted filesystem access.**  The policy declares readable and writable
  path roots; the child rebinds ``open``, ``os.open``, and the ``os`` path
  entry points to check every path against them after ``realpath``.  The host
  additionally runs the child with its working directory set to a scratch
  directory the host created and destroys.
* **Restricted network access.**  Without ``NETWORK`` the child rebinds
  ``socket.socket``, ``_socket.socket``, and their neighbours to raise, and the
  import gate refuses the networking modules by name.
* **Resource quotas.**  ``RLIMIT_CPU``, ``RLIMIT_AS``, ``RLIMIT_NOFILE``,
  ``RLIMIT_FSIZE``, and -- when ``SUBPROCESS`` is not granted --
  ``RLIMIT_NPROC``, applied by the child to itself, plus a host-side wall-clock
  timeout that kills the child's whole process group.
* **Signed-package verification.**  :func:`verify_package` checks a detached
  signature over the canonical manifest *and* the module source bytes against a
  declared trusted-key set **before** the child is spawned.  A bad, absent, or
  unknown-key signature means no process is created at all.
* **Explicit secret access.**  The child's environment is rebuilt from a
  minimal allow-list; a secret reaches it only when the policy declares its
  name and the ``SECRETS`` permission was granted.  The child independently
  refuses an environment carrying anything undeclared.
* **Complete invocation logs.**  :class:`InvocationRecord` carries plugin
  identity and version, manifest hash, package digest, signature status,
  granted permissions, canonical input and output hashes, start and end,
  exit status, resource usage, every violation, and the failure category.  Each
  record is content-hashed, and :class:`SandboxLog` folds the record hashes
  into a chain so a deleted record is visible as a broken chain.
* **Reproducible environment manifests.**  :class:`EnvironmentManifest` carries
  the Python version and implementation, the platform, the interpreter
  arguments and flags, the hash seed, the module allow-list, and the rlimits
  actually in force.  It contains no path, no pid, and no clock reading, so two
  invocations under one policy produce one manifest hash.

.. note::

   **Package trust uses the production portable profile.**
   :data:`SANDBOX_SIGNATURE_PROFILE` is ``"Ed25519"``. Publishers retain a
   32-byte private seed in :class:`PackageSigningKey`; hosts pin only the
   derived public key in :class:`TrustedKey`. The detached signature covers
   the canonical manifest, module identity, entry point, and source digest.
   The pinned ``cryptography`` provider is loaded only at the package boundary;
   if it is absent, verification fails closed before plugin bytecode runs.

.. warning::

   **The dependency-light process profile is not a production boundary.**
   ``PROCESS_REFERENCE`` runs the child as the host uid without seccomp,
   namespaces, chroot, or a capability drop. Consequently:

   * native code -- ``ctypes``, a C extension, anything reaching a raw syscall
     -- bypasses every Python-level gate.  The module allow-list is what keeps
     those out of reach, and an import allow-list is a policy gate, not a
     kernel one;
   * on a stock Linux the child can read much of ``/proc`` and, unless
     ``ptrace_scope`` is restricted, attach to same-uid processes;
   * the path allow-list is checked with ``realpath`` and then the real call is
     made, so a symlink swapped in between the two wins the race;
   * ``sys.modules`` still holds the real modules whose attributes were
     rebound, so a plugin holding a reference captured by other means can reach
     an original; and
   * ``RLIMIT_AS`` bounds address space on Linux and raises ``MemoryError``
     inside the child; on macOS it is accepted but weaker on a 64-bit process,
     so a memory hog there may be caught by the wall-clock timeout instead.
     Both are typed failures and both keep the host alive, and
     :class:`EnvironmentManifest` records which limits were actually applied.

   The profile is therefore available to capability-bearing plugins only when
   ``allow_same_uid_reference=True`` explicitly discloses that test/reference
   choice. ``AUTO`` selects ``OCI_KERNEL`` for every permission that requires
   isolation and fails closed when a digest-pinned Docker/Podman policy cannot
   be proven. The OCI path applies a read-only root, private network/IPC,
   non-root uid, cgroup limits, dropped capabilities, no-new-privileges,
   seccomp attestation, explicit bind mounts, and a fixed reply channel. See
   :mod:`crg_generate.oci` and ``docs/PLUGIN_SANDBOX.md``.
"""
from __future__ import annotations

import hashlib
import base64
import json
import os
import platform as _platform
import shutil
import signal
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from fractions import Fraction
from typing import Any, Callable, Dict, List, Mapping, Optional, Sequence, Tuple

from crg_model.canonical import CanonicalizationError, canonical_bytes, content_hash
from crg_model.records import RealizationRecord, Signature

from ._sandbox_child import (
    DEFAULT_MODULE_ALLOW_LIST,
    NETWORK_MODULES,
    NEVER_IMPORTABLE,
    PROCESS_MODULES,
    PROTOCOL_VERSION,
    RESULT_FD_ENV,
    RESULT_PATH_ENV,
    FailureCategory,
)
from .oci import OCI_REPLY_PATH, OciSandboxConfig, OciSandboxError
from .generator import (
    DeterminismStatus,
    GenerationContext,
    GeneratorDefinition,
    GeneratorError,
    propose_record,
)
from .legality import _canonicalizable
from .packs import DomainPackManifest, Permission

try:  # pragma: no cover - the repository targets POSIX
    import resource as _resource
except ImportError:  # pragma: no cover
    _resource = None  # type: ignore[assignment]

__all__ = [
    "SandboxError",
    "FailureCategory",
    "SandboxViolation",
    "SANDBOX_SIGNATURE_PROFILE",
    "SANDBOX_SIGNATURE_ALGORITHM",
    "PRODUCTION_SIGNATURE_PROFILE",
    "PRODUCTION_PROFILE_WARNING",
    "SignatureStatus",
    "TrustedKey",
    "PackageSigningKey",
    "TrustedKeySet",
    "PluginPackage",
    "PackageSignature",
    "sign_package",
    "verify_package",
    "ResourceQuota",
    "SandboxPolicy",
    "EnvironmentManifest",
    "InvocationRecord",
    "SandboxLog",
    "SandboxResult",
    "run_sandboxed",
    "SandboxedGenerator",
    "DEFAULT_MODULE_ALLOW_LIST",
    "PROTOCOL_VERSION",
    "ISOLATION_GRANTABLE",
    "IsolationProfile",
    "OciSandboxConfig",
    "INTERPRETER_ARGUMENTS",
]


class SandboxError(ValueError):
    """Raised when a sandbox declaration is malformed beyond interpretation.

    Reserved for the things a *host* got wrong while building the sandbox -- a
    key with no identity, a package with no source -- because those are
    programming errors in the embedding application, not plugin behaviour.
    Everything a *plugin* does wrong becomes a :class:`SandboxViolation` and a
    :class:`FailureCategory` instead, never an exception: 6.6 asks for a
    fail-closed result, and a traceback escaping into a host's request handler
    is not a result.
    """


#: The permissions of 36.2 that :mod:`crg_generate.packs` refuses in process
#: and this module grants under confinement.  Nothing outside this set changes
#: meaning between the two paths.
ISOLATION_GRANTABLE = Permission.REQUIRES_ISOLATION


class IsolationProfile:
    """Closed vocabulary for the boundary that actually executes a plugin."""

    AUTO = "AUTO"
    PROCESS_REFERENCE = "PROCESS_REFERENCE"
    OCI_KERNEL = "OCI_KERNEL"
    ALL = frozenset({AUTO, PROCESS_REFERENCE, OCI_KERNEL})

#: The production asymmetric profile required by 14.5 and 36.3.
SANDBOX_SIGNATURE_PROFILE = "Ed25519"
SANDBOX_SIGNATURE_ALGORITHM = "ed25519"

#: The profile specification 14.5 makes the baseline for portable artifacts.
PRODUCTION_SIGNATURE_PROFILE = "Ed25519"

PRODUCTION_PROFILE_WARNING = (
    "Plugin packages use Ed25519 over the canonical package declaration. The host stores "
    "public verification keys only; publishers retain private signing keys. If the pinned "
    "cryptography provider is unavailable, verification fails closed before execution "
    "(specifications 14.5 and 36.3)."
)

#: Arguments the host passes to the child interpreter.
#:
#: ``-s`` drops the user site directory and ``-B`` stops bytecode being written
#: beside the child module.  ``-E`` and ``-I`` are deliberately *not* used:
#: both make CPython ignore ``PYTHONHASHSEED``, and a fixed hash seed is what
#: makes two runs of a plugin declaring ``DETERMINISTIC`` comparable at all
#: (6.5).  The host rebuilds the child's environment from nothing, so ignoring
#: the inherited environment would buy no isolation it does not already have.
INTERPRETER_ARGUMENTS: Tuple[str, ...] = ("-s", "-B")

_CHILD_MODULE_PATH = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "_sandbox_child.py"
)

#: Environment variables the child is allowed to see before secrets are added.
#: Everything else the host process holds is scrubbed, which is 36.3's
#: "explicit secret access" read in the only direction that is safe: a variable
#: is absent unless something declared it.
_BASE_CHILD_ENVIRONMENT: Tuple[Tuple[str, str], ...] = (
    ("PATH", "/usr/bin:/bin"),
    ("LANG", "C.UTF-8"),
    ("LC_ALL", "C.UTF-8"),
    ("PYTHONHASHSEED", "0"),
    ("PYTHONDONTWRITEBYTECODE", "1"),
    ("PYTHONNOUSERSITE", "1"),
    ("PYTHONIOENCODING", "utf-8"),
)


class SignatureStatus:
    """What :func:`verify_package` concluded about a detached signature."""

    VERIFIED = "VERIFIED"
    ABSENT = "ABSENT"
    INVALID = "INVALID"
    UNKNOWN_KEY = "UNKNOWN_KEY"
    PROFILE_UNKNOWN = "PROFILE_UNKNOWN"

    ALL = frozenset({VERIFIED, ABSENT, INVALID, UNKNOWN_KEY, PROFILE_UNKNOWN})


@dataclass(frozen=True)
class SandboxViolation:
    """One refused action or one failed precondition, with its category.

    A violation is *data*, not an exception.  It travels back to the host
    inside a :class:`SandboxResult` and is recorded verbatim in the invocation
    log, because 36.3 asks for a complete log of what a plugin did and an
    attempt that was refused is part of what it did.
    """

    category: str
    detail: str
    target: str = ""

    def __post_init__(self) -> None:
        if self.category not in FailureCategory.ALL:
            raise SandboxError(
                f"unknown sandbox failure category {self.category!r}; the vocabulary is "
                f"{sorted(FailureCategory.ALL)}"
            )

    def to_canonical(self) -> dict:
        record: Dict[str, Any] = {"category": self.category, "detail": self.detail}
        if self.target:
            record["target"] = self.target
        return record


# ---------------------------------------------------------------------------
# signed packages (spec 36.3 "signed-package verification", 14.5)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class TrustedKey:
    """An Ed25519 public verification key; never private signing material."""

    key_id: str
    public_key: bytes
    profile: str = SANDBOX_SIGNATURE_PROFILE
    algorithm: str = SANDBOX_SIGNATURE_ALGORITHM
    holder: str = ""

    def __post_init__(self) -> None:
        if not str(self.key_id).strip():
            raise SandboxError("a trusted key requires an identity (spec 14.1)")
        key = self.public_key
        if not isinstance(key, (bytes, bytearray)) or len(key) != 32:
            raise SandboxError("an Ed25519 trusted public key must be exactly 32 bytes")
        if self.profile != SANDBOX_SIGNATURE_PROFILE or self.algorithm != SANDBOX_SIGNATURE_ALGORITHM:
            raise SandboxError("the plugin trust store accepts the Ed25519 production profile only")
        object.__setattr__(self, "public_key", bytes(key))

    def to_canonical(self) -> dict:
        """The key's *public* description.  The secret is never canonicalized."""
        record: Dict[str, Any] = {
            "key_id": self.key_id,
            "profile": self.profile,
            "algorithm": self.algorithm,
        }
        if self.holder:
            record["holder"] = self.holder
        return record


@dataclass(frozen=True)
class PackageSigningKey:
    """Publisher-held Ed25519 private seed, separate from the host trust set."""

    key_id: str
    private_key: bytes
    profile: str = SANDBOX_SIGNATURE_PROFILE
    algorithm: str = SANDBOX_SIGNATURE_ALGORITHM

    def __post_init__(self) -> None:
        if not str(self.key_id).strip():
            raise SandboxError("a signing key requires an identity")
        if not isinstance(self.private_key, (bytes, bytearray)) or len(self.private_key) != 32:
            raise SandboxError("an Ed25519 private signing seed must be exactly 32 bytes")
        if self.profile != SANDBOX_SIGNATURE_PROFILE or self.algorithm != SANDBOX_SIGNATURE_ALGORITHM:
            raise SandboxError("package signing supports the Ed25519 production profile only")
        object.__setattr__(self, "private_key", bytes(self.private_key))

    def trusted_key(self, *, holder: str = "") -> TrustedKey:
        try:
            from cryptography.hazmat.primitives import serialization
            from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
        except ImportError as error:
            raise SandboxError("Ed25519 requires the pinned cryptography provider") from error
        public = Ed25519PrivateKey.from_private_bytes(self.private_key).public_key().public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )
        return TrustedKey(key_id=self.key_id, public_key=public, holder=holder)


@dataclass(frozen=True)
class TrustedKeySet:
    """The declared set of keys whose signatures this host will accept.

    An empty set is meaningful and is not an error: it says *no package may
    run*, which is the correct default for a host that has not decided whom it
    trusts.  Every unsigned or unknown-key package then fails closed (6.6).
    """

    keys: Tuple[TrustedKey, ...] = ()

    def __post_init__(self) -> None:
        seen = [key.key_id for key in self.keys]
        duplicates = sorted({k for k in seen if seen.count(k) > 1})
        if duplicates:
            raise SandboxError(
                f"trusted key identity/identities {duplicates} appear more than once; "
                "a key identity that resolves to two secrets resolves to neither"
            )

    @property
    def key_ids(self) -> Tuple[str, ...]:
        return tuple(sorted(key.key_id for key in self.keys))

    def get(self, key_id: str) -> Optional[TrustedKey]:
        for key in self.keys:
            if key.key_id == key_id:
                return key
        return None

    def to_canonical(self) -> dict:
        return {"keys": [key.to_canonical() for key in sorted(self.keys, key=lambda k: k.key_id)]}


@dataclass(frozen=True)
class PluginPackage:
    """A plugin as a signable artifact: a manifest plus module source bytes.

    The signature of 36.3 has to cover *both* halves.  A signature over the
    manifest alone would let anyone swap the code while keeping the declared
    permissions; a signature over the code alone would let anyone widen the
    permission list.  :meth:`package_digest` therefore hashes the canonical
    manifest, the module name, the entry-point name, and the digest of the
    source bytes together, and the tests tamper with each half separately to
    show that either one breaks verification.
    """

    manifest: DomainPackManifest
    module_source: str
    entry_point: str = "propose"
    module_name: str = "crg_sandboxed_plugin"

    def __post_init__(self) -> None:
        if not isinstance(self.module_source, str):
            raise SandboxError("a plugin package's module source must be text")
        if not self.entry_point.isidentifier():
            raise SandboxError(
                f"entry point {self.entry_point!r} is not a Python identifier; the "
                "manifest must name the callable the host will invoke (spec 36.2)"
            )
        if not self.module_name.isidentifier():
            raise SandboxError(f"module name {self.module_name!r} is not an identifier")

    @property
    def qualified_id(self) -> str:
        return self.manifest.qualified_id

    def source_digest(self) -> str:
        """``sha256:<hex>`` over the module source bytes, UTF-8 encoded."""
        return "sha256:" + hashlib.sha256(self.module_source.encode("utf-8")).hexdigest()

    def to_canonical(self) -> dict:
        return {
            "manifest": self.manifest.to_canonical(),
            "module_name": self.module_name,
            "entry_point": self.entry_point,
            "module_source_digest": self.source_digest(),
        }

    def package_digest(self) -> str:
        return content_hash(self.to_canonical())


@dataclass(frozen=True)
class PackageSignature:
    """A detached signature over a :class:`PluginPackage` (spec 14.5, 36.3)."""

    key_id: str
    package_digest: str
    signature: str
    profile: str = SANDBOX_SIGNATURE_PROFILE
    algorithm: str = SANDBOX_SIGNATURE_ALGORITHM

    def signed_content(self) -> dict:
        """Exactly what the MAC covers.  The MAC itself is excluded (14.3)."""
        return {
            "key_id": self.key_id,
            "package_digest": self.package_digest,
            "profile": self.profile,
            "algorithm": self.algorithm,
        }

    def to_canonical(self) -> dict:
        record = self.signed_content()
        record["signature"] = self.signature
        return record


def sign_package(package: PluginPackage, key: PackageSigningKey) -> PackageSignature:
    """Sign a canonical plugin package with a publisher-held Ed25519 key."""
    if key.profile != SANDBOX_SIGNATURE_PROFILE:
        raise SandboxError(
            f"key {key.key_id!r} declares profile {key.profile!r}; this module implements "
            f"only {SANDBOX_SIGNATURE_PROFILE!r}"
        )
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    except ImportError as error:
        raise SandboxError("Ed25519 signing requires the pinned cryptography provider") from error
    digest = package.package_digest()
    unsigned = PackageSignature(key_id=key.key_id, package_digest=digest, signature="")
    raw = Ed25519PrivateKey.from_private_bytes(key.private_key).sign(
        canonical_bytes(unsigned.signed_content())
    )
    return PackageSignature(
        key_id=key.key_id,
        package_digest=digest,
        signature=base64.b64encode(raw).decode("ascii"),
    )


def verify_package(
    package: PluginPackage,
    signature: Optional[PackageSignature],
    trusted_keys: TrustedKeySet,
) -> Tuple[str, Optional[SandboxViolation]]:
    """Verify a detached signature *before* anything is executed (spec 36.3).

    Returns the :class:`SignatureStatus` and, when it is not ``VERIFIED``, the
    violation to record.  The five outcomes are kept apart deliberately: an
    absent signature, a signature from a key this host never trusted, and a
    signature that does not match are three different findings about three
    different parties, and a log that reports all three as "signature failed"
    cannot tell an operator which one to go and fix.

    Verification uses the public key only. It never imports, executes, or even
    ``compile``\\ s the module source: the source is bytes to this function.
    """
    if signature is None:
        return (
            SignatureStatus.ABSENT,
            SandboxViolation(
                FailureCategory.SIGNATURE_ABSENT,
                "the plugin package carries no signature; specification 36.3 requires "
                "signed-package verification before an untrusted plugin executes, so an "
                "unsigned package is refused rather than run on trust (spec 6.6)",
                target=package.qualified_id,
            ),
        )
    if signature.profile != SANDBOX_SIGNATURE_PROFILE:
        return (
            SignatureStatus.PROFILE_UNKNOWN,
            SandboxViolation(
                FailureCategory.SIGNATURE_PROFILE_UNKNOWN,
                f"the signature declares profile {signature.profile!r}; this host "
                f"implements only {SANDBOX_SIGNATURE_PROFILE!r}, and a profile it cannot "
                "check is a profile it must not accept (spec 14.5, 6.6)",
                target=signature.profile,
            ),
        )
    key = trusted_keys.get(signature.key_id)
    if key is None:
        return (
            SignatureStatus.UNKNOWN_KEY,
            SandboxViolation(
                FailureCategory.UNKNOWN_SIGNING_KEY,
                f"the signature names key {signature.key_id!r}, which is not in this "
                f"host's declared trusted-key set {list(trusted_keys.key_ids)!r}; a valid "
                "signature from an untrusted key proves control of a key nobody vouched "
                "for (spec 14.5, 36.3)",
                target=signature.key_id,
            ),
        )
    recomputed = package.package_digest()
    if recomputed != signature.package_digest:
        return (
            SignatureStatus.INVALID,
            SandboxViolation(
                FailureCategory.SIGNATURE_INVALID,
                "the package digest does not match the one the signature covers: the "
                f"manifest or the module source has changed since signing (signed "
                f"{signature.package_digest}, computed {recomputed})",
                target=package.qualified_id,
            ),
        )
    try:
        raw_signature = base64.b64decode(signature.signature, validate=True)
        from cryptography.exceptions import InvalidSignature
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
        Ed25519PublicKey.from_public_bytes(key.public_key).verify(
            raw_signature, canonical_bytes(signature.signed_content())
        )
    except ImportError:
        return (
            SignatureStatus.PROFILE_UNKNOWN,
            SandboxViolation(
                FailureCategory.SIGNATURE_PROFILE_UNKNOWN,
                "Ed25519 verification is unavailable because the pinned cryptography provider "
                "is not installed; the package is refused before execution",
                target=signature.profile,
            ),
        )
    except (ValueError, InvalidSignature):
        return (
            SignatureStatus.INVALID,
            SandboxViolation(
                FailureCategory.SIGNATURE_INVALID,
                f"the signature over package {package.qualified_id} does not verify under "
                f"key {signature.key_id!r}",
                target=package.qualified_id,
            ),
        )
    return SignatureStatus.VERIFIED, None


# ---------------------------------------------------------------------------
# quotas and policy (spec 36.3 "resource quotas")
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ResourceQuota:
    """The declared resource envelope of one invocation (spec 36.2, 36.3).

    Every field is an exact integer of the unit named in its name; nothing here
    is a float, because a quota is a declared contract and a binary float is
    not canonically encodable (14.2).  ``wall_clock_seconds`` is an exact
    :class:`~fractions.Fraction` for the same reason -- it is converted to a
    float exactly once, at the operating-system boundary where
    :meth:`subprocess.Popen.communicate` demands one, and never enters a hash.

    The defaults are chosen to be *usable* rather than generous: a generator
    proposing children from one parent should not need two seconds of CPU or
    half a gibibyte, and a plugin that does has an accounting problem its host
    should hear about as a quota breach rather than as a slow day.
    """

    cpu_seconds: int = 2
    address_space_bytes: int = 512 * 1024 * 1024
    open_files: int = 64
    file_size_bytes: int = 4 * 1024 * 1024
    max_processes: int = 0
    wall_clock_seconds: Fraction = Fraction(20)

    def __post_init__(self) -> None:
        for name in ("cpu_seconds", "address_space_bytes", "open_files", "file_size_bytes"):
            value = getattr(self, name)
            if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
                raise SandboxError(f"quota {name!r} must be a positive integer, got {value!r}")
        if isinstance(self.wall_clock_seconds, float):
            raise SandboxError(
                "wall_clock_seconds must be an exact Fraction or int; binary floating "
                "point is not admissible in a declared contract (spec 14.2)"
            )
        object.__setattr__(self, "wall_clock_seconds", Fraction(self.wall_clock_seconds))
        if self.wall_clock_seconds <= 0:
            raise SandboxError("wall_clock_seconds must be positive")
        if self.max_processes < 0:
            raise SandboxError("max_processes may not be negative")

    def rlimit_spec(self, *, subprocess_granted: bool) -> Dict[str, int]:
        """The ``resource`` limits the child will apply to itself.

        ``RLIMIT_NPROC`` appears only when ``SUBPROCESS`` was *not* granted.
        Applying it to a plugin that legitimately spawns processes would be a
        quota the manifest never agreed to; omitting it for one that does not
        would leave a fork bomb bounded only by the process gate, and 36.3 asks
        for quotas as well as for refusals.
        """
        spec = {
            "RLIMIT_CPU": self.cpu_seconds,
            "RLIMIT_AS": self.address_space_bytes,
            "RLIMIT_NOFILE": self.open_files,
            "RLIMIT_FSIZE": self.file_size_bytes,
        }
        if not subprocess_granted:
            spec["RLIMIT_NPROC"] = self.max_processes
        return spec

    def to_canonical(self) -> dict:
        return {
            "cpu_seconds": self.cpu_seconds,
            "address_space_bytes": self.address_space_bytes,
            "open_files": self.open_files,
            "file_size_bytes": self.file_size_bytes,
            "max_processes": self.max_processes,
            "wall_clock_seconds": {
                "exact": (
                    str(self.wall_clock_seconds.numerator)
                    if self.wall_clock_seconds.denominator == 1
                    else f"{self.wall_clock_seconds.numerator}/"
                    f"{self.wall_clock_seconds.denominator}"
                )
            },
        }


@dataclass(frozen=True)
class SandboxPolicy:
    """What one plugin is permitted to do, declared before it runs (36.2, 36.3).

    A policy is the host's side of the permission list.  The manifest *asks*;
    the policy *grants*; and :meth:`violations` refuses the combinations that
    do not cohere -- a readable path declared without ``FILESYSTEM_READ``, a
    secret named without ``SECRETS``, a permission token outside the
    vocabulary.  None of those raise: each becomes a
    :class:`SandboxViolation` so that a host sees every problem at once and the
    invocation log records why nothing ran, exactly as
    :func:`crg_generate.packs.validate_pack` reports rather than raises.

    ``determinism_replay`` runs the plugin twice and compares canonical output
    hashes.  It is defaulted from the pack's declared determinism status by
    :func:`crg_generate.packs.sandbox_policy_for_pack`, because a plugin
    declaring ``DETERMINISTIC`` has made a claim the host is entitled to check
    and a certificate resting on an unchecked claim is the failure 6.5 exists
    to prevent.
    """

    granted_permissions: Tuple[str, ...] = ()
    readable_paths: Tuple[str, ...] = ()
    writable_paths: Tuple[str, ...] = ()
    declared_secrets: Tuple[str, ...] = ()
    module_allow_list: Tuple[str, ...] = DEFAULT_MODULE_ALLOW_LIST
    trusted_keys: TrustedKeySet = field(default_factory=TrustedKeySet)
    quota: ResourceQuota = field(default_factory=ResourceQuota)
    determinism_replay: bool = False
    isolation_profile: str = IsolationProfile.AUTO
    oci: Optional[OciSandboxConfig] = None
    allow_same_uid_reference: bool = False

    def __post_init__(self) -> None:
        object.__setattr__(
            self, "granted_permissions", tuple(sorted(set(self.granted_permissions)))
        )
        object.__setattr__(
            self,
            "readable_paths",
            tuple(sorted({os.path.realpath(p) for p in self.readable_paths})),
        )
        object.__setattr__(
            self,
            "writable_paths",
            tuple(sorted({os.path.realpath(p) for p in self.writable_paths})),
        )
        object.__setattr__(self, "declared_secrets", tuple(sorted(set(self.declared_secrets))))
        object.__setattr__(self, "module_allow_list", tuple(sorted(set(self.module_allow_list))))

    @property
    def effective_isolation_profile(self) -> str:
        if self.isolation_profile != IsolationProfile.AUTO:
            return self.isolation_profile
        if set(self.granted_permissions) & set(ISOLATION_GRANTABLE):
            return IsolationProfile.OCI_KERNEL
        return IsolationProfile.PROCESS_REFERENCE

    # -- what the permission list means -------------------------------------
    @property
    def network_granted(self) -> bool:
        return Permission.NETWORK in self.granted_permissions

    @property
    def subprocess_granted(self) -> bool:
        return Permission.SUBPROCESS in self.granted_permissions

    @property
    def filesystem_read_granted(self) -> bool:
        return Permission.FILESYSTEM_READ in self.granted_permissions

    @property
    def filesystem_write_granted(self) -> bool:
        return Permission.FILESYSTEM_WRITE in self.granted_permissions

    @property
    def secrets_granted(self) -> bool:
        return Permission.SECRETS in self.granted_permissions

    def violations(self) -> Tuple[SandboxViolation, ...]:
        """Every reason this policy may not be enforced as declared."""
        found: List[SandboxViolation] = []
        if self.isolation_profile not in IsolationProfile.ALL:
            found.append(
                SandboxViolation(
                    FailureCategory.POLICY_ERROR,
                    f"unknown isolation profile {self.isolation_profile!r}; expected one "
                    f"of {sorted(IsolationProfile.ALL)}",
                    target="isolation_profile",
                )
            )
        effective_profile = self.effective_isolation_profile
        capability_bearing = bool(set(self.granted_permissions) & set(ISOLATION_GRANTABLE))
        if (
            effective_profile == IsolationProfile.PROCESS_REFERENCE
            and capability_bearing
            and not self.allow_same_uid_reference
        ):
            found.append(
                SandboxViolation(
                    FailureCategory.POLICY_ERROR,
                    "a capability-bearing plugin requires the OCI_KERNEL profile; the "
                    "same-UID Python process is available only through the explicit "
                    "allow_same_uid_reference test/reference opt-in and is not a production "
                    "security boundary (spec 6.6, 36.3)",
                    target="isolation_profile",
                )
            )
        if effective_profile == IsolationProfile.OCI_KERNEL:
            if self.oci is None:
                found.append(
                    SandboxViolation(
                        FailureCategory.POLICY_ERROR,
                        "OCI_KERNEL isolation was selected but no digest-pinned OCI runtime "
                        "configuration was supplied; execution is refused rather than "
                        "degraded to the same-UID process (spec 6.6, 36.3)",
                        target="oci",
                    )
                )
            else:
                for detail in self.oci.violations():
                    found.append(
                        SandboxViolation(
                            FailureCategory.POLICY_ERROR,
                            f"invalid OCI sandbox configuration: {detail}",
                            target="oci",
                        )
                    )
        for token in self.granted_permissions:
            if token not in Permission.ALL:
                found.append(
                    SandboxViolation(
                        FailureCategory.UNKNOWN_PERMISSION,
                        f"the policy grants unknown permission {token!r}; the declared "
                        f"vocabulary is {sorted(Permission.ALL)} (spec 36.2).  A "
                        "permission this host cannot interpret is refused rather than "
                        "assumed harmless (spec 6.6)",
                        target=token,
                    )
                )
        if self.readable_paths and not self.filesystem_read_granted:
            found.append(
                SandboxViolation(
                    FailureCategory.PERMISSION_NOT_DECLARED,
                    f"the policy declares readable paths {list(self.readable_paths)!r} "
                    f"without granting {Permission.FILESYSTEM_READ}; a capability that "
                    "does not appear in the permission list is not granted (spec 36.2)",
                    target=Permission.FILESYSTEM_READ,
                )
            )
        if self.writable_paths and not self.filesystem_write_granted:
            found.append(
                SandboxViolation(
                    FailureCategory.PERMISSION_NOT_DECLARED,
                    f"the policy declares writable paths {list(self.writable_paths)!r} "
                    f"without granting {Permission.FILESYSTEM_WRITE} (spec 36.2)",
                    target=Permission.FILESYSTEM_WRITE,
                )
            )
        if self.declared_secrets and not self.secrets_granted:
            found.append(
                SandboxViolation(
                    FailureCategory.PERMISSION_NOT_DECLARED,
                    f"the policy names secrets {list(self.declared_secrets)!r} without "
                    f"granting {Permission.SECRETS} (spec 36.2, 36.3)",
                    target=Permission.SECRETS,
                )
            )
        forbidden = sorted(set(self.module_allow_list) & NEVER_IMPORTABLE)
        if forbidden:
            found.append(
                SandboxViolation(
                    FailureCategory.POLICY_ERROR,
                    f"the module allow-list contains {forbidden!r}; those modules reach "
                    "past the interpreter into raw memory, raw syscalls, or the sandbox's "
                    "own machinery, and allowing one of them would silently disable every "
                    "other control in this policy (spec 36.3)",
                    target=",".join(forbidden),
                )
            )
        if not self.network_granted:
            reachable = sorted(set(self.module_allow_list) & NETWORK_MODULES)
            if reachable:
                found.append(
                    SandboxViolation(
                        FailureCategory.POLICY_ERROR,
                        f"the module allow-list contains networking module(s) "
                        f"{reachable!r} while {Permission.NETWORK} is not granted",
                        target=",".join(reachable),
                    )
                )
        if not self.subprocess_granted:
            reachable = sorted(set(self.module_allow_list) & PROCESS_MODULES)
            if reachable:
                found.append(
                    SandboxViolation(
                        FailureCategory.POLICY_ERROR,
                        f"the module allow-list contains process-creating module(s) "
                        f"{reachable!r} while {Permission.SUBPROCESS} is not granted",
                        target=",".join(reachable),
                    )
                )
        return tuple(found)

    # -- what the child is handed -------------------------------------------
    def child_environment(self, scratch_dir: str, result_fd: int) -> Dict[str, str]:
        """The child's entire environment, rebuilt from an allow-list.

        A declared secret is copied from this process's environment only if it
        is actually set here; an undeclared one is absent by construction
        rather than by removal, which is the difference between an allow-list
        and a scrubber.  ``HOME`` and ``TMPDIR`` point at the scratch directory
        so that a library reaching for either lands somewhere the filesystem
        gate already permits.
        """
        environment = dict(_BASE_CHILD_ENVIRONMENT)
        environment["HOME"] = scratch_dir
        environment["TMPDIR"] = scratch_dir
        environment[RESULT_FD_ENV] = str(result_fd)
        if self.secrets_granted:
            for name in self.declared_secrets:
                value = os.environ.get(name)
                if value is not None:
                    environment[name] = value
        return environment

    def to_canonical(self) -> dict:
        return {
            "granted_permissions": list(self.granted_permissions),
            "readable_paths": list(self.readable_paths),
            "writable_paths": list(self.writable_paths),
            "declared_secrets": list(self.declared_secrets),
            "module_allow_list": list(self.module_allow_list),
            "trusted_keys": self.trusted_keys.to_canonical(),
            "quota": self.quota.to_canonical(),
            "determinism_replay": self.determinism_replay,
            "isolation_profile": self.isolation_profile,
            "effective_isolation_profile": self.effective_isolation_profile,
            "oci": self.oci.to_canonical() if self.oci is not None else None,
            "allow_same_uid_reference": self.allow_same_uid_reference,
        }

    def policy_hash(self) -> str:
        return content_hash(self.to_canonical())


# ---------------------------------------------------------------------------
# environment manifest (spec 36.3 last bullet)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class EnvironmentManifest:
    """The environment an invocation ran in, reproducibly (spec 36.3).

    "Reproducible" is a property of the *content*: no path, no pid, no clock
    reading, no scratch directory.  Two invocations under one policy on one
    machine produce one :meth:`manifest_hash`, which is what makes the manifest
    usable as a comparison key -- a host can say "this certificate rests on a
    run under environment ``sha256:...``" and mean something checkable.

    ``rlimits`` records what the child's :func:`resource.setrlimit` calls
    actually achieved, not what the policy asked for.  A limit the platform
    does not have appears as ``UNAVAILABLE`` with a reason, which is how the
    macOS/Linux difference in ``RLIMIT_AS`` behaviour becomes visible in the
    artifact instead of being discovered by a surprised operator.
    """

    protocol: str
    python_version: str
    python_implementation: str
    platform_system: str
    platform_machine: str
    sys_platform: str
    interpreter_arguments: Tuple[str, ...]
    interpreter_flags: Mapping[str, int]
    hash_seed: str
    module_allow_list: Tuple[str, ...]
    never_importable: Tuple[str, ...]
    unavailable_modules: Mapping[str, str]
    rlimits: Mapping[str, Mapping[str, Any]]
    observed: bool
    isolation: Mapping[str, Any] = field(default_factory=dict)

    def to_canonical(self) -> dict:
        return {
            "protocol": self.protocol,
            "python_version": self.python_version,
            "python_implementation": self.python_implementation,
            "platform_system": self.platform_system,
            "platform_machine": self.platform_machine,
            "sys_platform": self.sys_platform,
            "interpreter_arguments": list(self.interpreter_arguments),
            "interpreter_flags": {k: int(v) for k, v in sorted(self.interpreter_flags.items())},
            "hash_seed": self.hash_seed,
            "module_allow_list": list(self.module_allow_list),
            "never_importable": list(self.never_importable),
            "unavailable_modules": dict(sorted(self.unavailable_modules.items())),
            "rlimits": {
                name: dict(sorted(entry.items()))
                for name, entry in sorted(self.rlimits.items())
            },
            "observed": self.observed,
            "isolation": dict(sorted(self.isolation.items())),
        }

    def manifest_hash(self) -> str:
        return content_hash(self.to_canonical())

    def applied_limits(self) -> Tuple[str, ...]:
        """The limit names actually in force, sorted."""
        return tuple(
            sorted(
                name
                for name, entry in self.rlimits.items()
                if entry.get("status") == "APPLIED"
            )
        )

    def degraded_limits(self) -> Mapping[str, str]:
        """Limits that were asked for and are *not* in force, with the reason.

        A test on a platform where a limit is unavailable asserts against this
        mapping rather than skipping: the documented degradation is part of the
        contract, and a silently skipped test would hide the day a limit stops
        being applied on a platform where it used to be.
        """
        return {
            name: str(entry.get("detail", entry.get("status", "")))
            for name, entry in sorted(self.rlimits.items())
            if entry.get("status") != "APPLIED"
        }


def declared_environment(policy: SandboxPolicy) -> EnvironmentManifest:
    """The environment manifest the host expects, built without running anything.

    Used when a run is refused before the child is spawned -- an unsigned
    package, an unknown permission -- so that even a refused invocation carries
    an environment manifest and the log has no holes.  ``observed`` is
    ``False``, which is the honest marker: nothing was measured, this is what
    would have been asked for.
    """
    return EnvironmentManifest(
        protocol=PROTOCOL_VERSION,
        python_version=_platform.python_version(),
        python_implementation=_platform.python_implementation(),
        platform_system=_platform.system(),
        platform_machine=_platform.machine(),
        sys_platform=sys.platform,
        interpreter_arguments=INTERPRETER_ARGUMENTS,
        interpreter_flags={},
        hash_seed="0",
        module_allow_list=policy.module_allow_list,
        never_importable=tuple(sorted(NEVER_IMPORTABLE)),
        unavailable_modules={},
        rlimits={
            name: {"status": "REQUESTED", "requested": value}
            for name, value in policy.quota.rlimit_spec(
                subprocess_granted=policy.subprocess_granted
            ).items()
        },
        observed=False,
        isolation={
            "profile": policy.effective_isolation_profile,
            "kernel_enforced": False,
            "observed": False,
            "image": policy.oci.image if policy.oci is not None else "",
        },
    )


def _observed_environment(
    reported: Mapping[str, Any], isolation: Optional[Mapping[str, Any]] = None
) -> EnvironmentManifest:
    """Read the child's own account of its environment."""
    return EnvironmentManifest(
        protocol=str(reported.get("protocol", "")),
        python_version=str(reported.get("python_version", "")),
        python_implementation=str(reported.get("python_implementation", "")),
        platform_system=str(reported.get("platform_system", "")),
        platform_machine=str(reported.get("platform_machine", "")),
        sys_platform=str(reported.get("sys_platform", "")),
        interpreter_arguments=INTERPRETER_ARGUMENTS,
        interpreter_flags=dict(reported.get("interpreter_flags", {}) or {}),
        hash_seed=str(reported.get("hash_seed", "")),
        module_allow_list=tuple(reported.get("module_allow_list", ()) or ()),
        never_importable=tuple(reported.get("never_importable", ()) or ()),
        unavailable_modules=dict(reported.get("unavailable_modules", {}) or {}),
        rlimits={
            str(name): dict(entry)
            for name, entry in (reported.get("rlimits", {}) or {}).items()
        },
        observed=True,
        isolation=dict(isolation or {}),
    )


# ---------------------------------------------------------------------------
# invocation log (spec 36.3 "complete invocation logs")
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class InvocationRecord:
    """One sandboxed invocation, complete enough to be evidence (spec 36.3).

    Every bullet 36.3 asks for is a field, and every field is present on a
    *failed* invocation too.  A log that records only successes cannot answer
    the question an auditor actually asks -- what did this plugin try to do --
    and 6.6's fail-closed conditions are precisely the entries that must
    survive.
    """

    plugin_identity: str
    plugin_version: str
    manifest_hash: str
    package_digest: str
    module_source_digest: str
    signature_status: str
    signing_key_id: str
    signature_profile: str
    granted_permissions: Tuple[str, ...]
    input_hash: str
    output_hash: str
    started_at: str
    ended_at: str
    duration_nanoseconds: int
    exit_status: Optional[int]
    terminating_signal: str
    timed_out: bool
    resource_usage: Mapping[str, Any]
    failure_category: str
    violations: Tuple[SandboxViolation, ...]
    environment_hash: str
    policy_hash: str
    replays: int
    notes: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if self.failure_category not in FailureCategory.ALL:
            raise SandboxError(
                f"unknown failure category {self.failure_category!r} in an invocation record"
            )

    @property
    def ok(self) -> bool:
        return self.failure_category == FailureCategory.OK

    def to_canonical(self) -> dict:
        return {
            "plugin_identity": self.plugin_identity,
            "plugin_version": self.plugin_version,
            "manifest_hash": self.manifest_hash,
            "package_digest": self.package_digest,
            "module_source_digest": self.module_source_digest,
            "signature_status": self.signature_status,
            "signing_key_id": self.signing_key_id,
            "signature_profile": self.signature_profile,
            "granted_permissions": list(self.granted_permissions),
            "input_hash": self.input_hash,
            "output_hash": self.output_hash,
            "started_at": self.started_at,
            "ended_at": self.ended_at,
            "duration_nanoseconds": self.duration_nanoseconds,
            "exit_status": self.exit_status,
            "terminating_signal": self.terminating_signal,
            "timed_out": self.timed_out,
            "resource_usage": dict(sorted(self.resource_usage.items())),
            "failure_category": self.failure_category,
            "violations": [v.to_canonical() for v in self.violations],
            "environment_hash": self.environment_hash,
            "policy_hash": self.policy_hash,
            "replays": self.replays,
            "notes": list(self.notes),
        }

    def record_hash(self) -> str:
        """``sha256:<hex>`` over the record's own canonical content (14.4)."""
        return content_hash(self.to_canonical())


@dataclass
class SandboxLog:
    """An append-only, hash-chained log of sandboxed invocations (spec 36.3).

    Each record is content-hashed on its own, and :meth:`chain_hash` folds the
    record hashes in order.  The chain is what makes a *deletion* visible: a
    list of independently hashed records tells an auditor that each surviving
    record is intact and nothing at all about the ones that are gone, which is
    the failure mode 44's audit requirements care about most.
    """

    records: List[InvocationRecord] = field(default_factory=list)

    def append(self, record: InvocationRecord) -> InvocationRecord:
        self.records.append(record)
        return record

    def __len__(self) -> int:
        return len(self.records)

    def __iter__(self):
        return iter(self.records)

    def record_hashes(self) -> Tuple[str, ...]:
        return tuple(record.record_hash() for record in self.records)

    def chain_hash(self) -> str:
        """Fold every record hash in order; an empty log has a defined hash."""
        digest = hashlib.sha256(b"crg-sandbox-log/1")
        for record_hash in self.record_hashes():
            digest.update(record_hash.encode("ascii"))
        return "sha256:" + digest.hexdigest()

    def to_canonical(self) -> dict:
        return {
            "records": [record.to_canonical() for record in self.records],
            "record_hashes": list(self.record_hashes()),
            "chain_hash": self.chain_hash(),
        }


@dataclass(frozen=True)
class SandboxResult:
    """What a host gets back from :func:`run_sandboxed`: never an exception."""

    ok: bool
    failure_category: str
    violations: Tuple[SandboxViolation, ...]
    payload: Optional[Mapping[str, Any]]
    record: InvocationRecord
    environment: EnvironmentManifest
    stdout: str
    stderr: str

    @property
    def detail(self) -> str:
        return self.violations[0].detail if self.violations else ""

    def has_category(self, category: str) -> bool:
        return self.failure_category == category or any(
            v.category == category for v in self.violations
        )


# ---------------------------------------------------------------------------
# running the child
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class _ChildRun:
    """Everything one spawn produced.  Internal; never crosses the API."""

    reply: Optional[Mapping[str, Any]]
    exit_status: Optional[int]
    terminating_signal: str
    timed_out: bool
    stdout: str
    stderr: str
    resource_usage: Mapping[str, Any]
    notes: Tuple[str, ...]
    isolation: Mapping[str, Any] = field(default_factory=dict)


def _iso(nanoseconds: int) -> str:
    """UTC timestamp to the microsecond, ``Z``-suffixed (spec 14.3)."""
    moment = datetime.fromtimestamp(nanoseconds // 1_000_000_000, tz=timezone.utc)
    return moment.strftime("%Y-%m-%dT%H:%M:%S") + ".%06dZ" % (
        (nanoseconds % 1_000_000_000) // 1000
    )


def _signal_name(status: Optional[int]) -> str:
    if status is None or status >= 0:
        return ""
    try:
        return signal.Signals(-status).name
    except ValueError:  # pragma: no cover - an unnamed signal number
        return f"SIG{-status}"


def _rusage_snapshot() -> Optional[Any]:
    if _resource is None:  # pragma: no cover - POSIX-only repository
        return None
    return _resource.getrusage(_resource.RUSAGE_CHILDREN)


def _rusage_delta(before: Optional[Any], after: Optional[Any]) -> Dict[str, Any]:
    """Child resource usage, as exact decimal strings (spec 14.2).

    ``RUSAGE_CHILDREN`` aggregates every child this process has waited for, so
    the CPU figures are *deltas* across this invocation and are attributable to
    it only when no other child was reaped concurrently.  ``ru_maxrss`` is a
    high-water mark rather than a running total, so no delta of it would be
    meaningful; the post-invocation value is reported as what it is.  Saying
    which of these numbers is exact and which is an attribution is part of the
    log's honesty, not a footnote to it.
    """
    if before is None or after is None:  # pragma: no cover - POSIX-only repository
        return {"unavailable": "this interpreter has no 'resource' module"}
    max_rss = int(after.ru_maxrss)
    return {
        "user_cpu_seconds": "%.6f" % (after.ru_utime - before.ru_utime),
        "system_cpu_seconds": "%.6f" % (after.ru_stime - before.ru_stime),
        "max_rss_kib_high_water": max_rss // 1024 if sys.platform == "darwin" else max_rss,
        "voluntary_context_switches": int(after.ru_nvcsw - before.ru_nvcsw),
        "involuntary_context_switches": int(after.ru_nivcsw - before.ru_nivcsw),
        "attribution": "RUSAGE_CHILDREN deltas; attributable to this invocation only "
        "when no other child process was reaped concurrently",
    }


def _terminate_group(process: "subprocess.Popen[bytes]") -> Tuple[str, ...]:
    """Kill the child's whole process group, and say what happened.

    The child is started with ``start_new_session=True`` precisely so that this
    is possible: killing the process alone would leave a plugin's grandchildren
    running and holding the pipes, and a host that "timed out" while the work
    continues has enforced nothing.
    """
    notes: List[str] = []
    try:
        os.killpg(os.getpgid(process.pid), signal.SIGKILL)
    except (ProcessLookupError, PermissionError, OSError) as exc:
        notes.append(
            f"could not signal the child's process group ({type(exc).__name__}: {exc}); "
            "falling back to killing the child alone"
        )
        try:
            process.kill()
        except OSError as inner:  # pragma: no cover - the child is already gone
            notes.append(f"could not kill the child either: {type(inner).__name__}: {inner}")
    return tuple(notes)


def _run_child(
    package: PluginPackage, payload: Mapping[str, Any], policy: SandboxPolicy
) -> _ChildRun:
    """Spawn one child, hand it one request, and collect one reply.

    Two temporary directories are created, and the distinction matters.  The
    *scratch* directory is the child's working directory and is on its writable
    allow-list.  The *channel* directory holds the reply file and is on neither
    allow-list, so a plugin cannot truncate its own invocation record by path.
    It can still write to the inherited descriptor if it goes looking for it,
    which is why an unparseable reply is a typed failure rather than an
    assertion (see the module docstring).
    """
    notes: List[str] = []
    scratch = tempfile.mkdtemp(prefix="crg-sandbox-scratch-")
    channel = tempfile.mkdtemp(prefix="crg-sandbox-channel-")
    reply_path = os.path.join(channel, "reply.json")
    reply_fd = os.open(reply_path, os.O_RDWR | os.O_CREAT | os.O_EXCL, 0o600)
    before = _rusage_snapshot()
    process: Optional["subprocess.Popen[bytes]"] = None
    timed_out = False
    stdout_bytes = b""
    stderr_bytes = b""

    request = {
        "protocol": PROTOCOL_VERSION,
        "module_name": package.module_name,
        "module_source": package.module_source,
        "entry_point": package.entry_point,
        "payload": payload,
        "policy": {
            "readable_paths": list(policy.readable_paths) + [scratch],
            "writable_paths": list(policy.writable_paths) + [scratch],
            "network": policy.network_granted,
            "subprocess": policy.subprocess_granted,
            "module_allow_list": list(policy.module_allow_list),
            "rlimits": policy.quota.rlimit_spec(
                subprocess_granted=policy.subprocess_granted
            ),
            "environment_allow_list": sorted(policy.child_environment(scratch, reply_fd)),
        },
    }
    request_bytes = json.dumps(request, ensure_ascii=True, sort_keys=True).encode("utf-8")

    try:
        process = subprocess.Popen(  # noqa: S603 - the argv is entirely host-built
            [sys.executable, *INTERPRETER_ARGUMENTS, _CHILD_MODULE_PATH],
            cwd=scratch,
            env=policy.child_environment(scratch, reply_fd),
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            pass_fds=(reply_fd,),
            close_fds=True,
            start_new_session=True,
        )
        # ``communicate`` drains both pipes concurrently, so a plugin that
        # writes megabytes to stdout cannot deadlock the host while the
        # wall-clock timeout is still running.
        try:
            stdout_bytes, stderr_bytes = process.communicate(
                input=request_bytes, timeout=float(policy.quota.wall_clock_seconds)
            )
        except subprocess.TimeoutExpired:
            timed_out = True
            notes.extend(_terminate_group(process))
            try:
                stdout_bytes, stderr_bytes = process.communicate(timeout=10)
            except subprocess.TimeoutExpired:  # pragma: no cover - group kill failed
                notes.append(
                    "the child's pipes were still open ten seconds after the process "
                    "group was killed; the reply is treated as absent"
                )
                process.kill()
                stdout_bytes, stderr_bytes = b"", b""
        raw_reply = _read_all(reply_fd)
    except OSError as exc:
        notes.append(f"the child could not be started or driven: {type(exc).__name__}: {exc}")
        raw_reply = b""
    finally:
        try:
            os.close(reply_fd)
        except OSError as exc:  # pragma: no cover - a descriptor already closed
            notes.append(f"could not close the reply descriptor: {exc}")
        for directory in (scratch, channel):
            try:
                shutil.rmtree(directory)
            except OSError as exc:
                notes.append(f"could not remove {directory!r}: {type(exc).__name__}: {exc}")

    after = _rusage_snapshot()
    exit_status = process.returncode if process is not None else None
    reply: Optional[Mapping[str, Any]] = None
    if raw_reply:
        try:
            decoded = json.loads(raw_reply.decode("utf-8"))
        except (ValueError, UnicodeDecodeError) as exc:
            notes.append(f"the child's reply was not canonical JSON: {exc}")
        else:
            if isinstance(decoded, dict) and decoded.get("protocol") == PROTOCOL_VERSION:
                reply = decoded
            else:
                notes.append(
                    "the child's reply did not carry protocol "
                    f"{PROTOCOL_VERSION!r}; it is treated as absent"
                )

    return _ChildRun(
        reply=reply,
        exit_status=exit_status,
        terminating_signal=_signal_name(exit_status),
        timed_out=timed_out,
        stdout=stdout_bytes.decode("utf-8", "replace"),
        stderr=stderr_bytes.decode("utf-8", "replace"),
        resource_usage=_rusage_delta(before, after),
        notes=tuple(notes),
        isolation={
            "profile": IsolationProfile.PROCESS_REFERENCE,
            "kernel_enforced": False,
            "observed": True,
            "warning": "same-UID Python confinement; not a production security boundary",
        },
    )


def _oci_environment(policy: SandboxPolicy) -> Dict[str, str]:
    """The complete, allow-listed environment passed through the OCI runtime."""
    environment = dict(_BASE_CHILD_ENVIRONMENT)
    environment["HOME"] = "/crg-scratch"
    environment["TMPDIR"] = "/crg-scratch"
    environment[RESULT_PATH_ENV] = OCI_REPLY_PATH
    if policy.secrets_granted:
        for name in policy.declared_secrets:
            value = os.environ.get(name)
            if value is not None:
                environment[name] = value
    return environment


def _run_child_oci(
    package: PluginPackage, payload: Mapping[str, Any], policy: SandboxPolicy
) -> _ChildRun:
    """Run one invocation in the digest-pinned, kernel-enforced OCI profile."""
    if policy.oci is None:  # guarded by policy.violations; defence in depth
        raise OciSandboxError("OCI_KERNEL profile has no OCI configuration")
    environment = _oci_environment(policy)
    request = {
        "protocol": PROTOCOL_VERSION,
        "module_name": package.module_name,
        "module_source": package.module_source,
        "entry_point": package.entry_point,
        "payload": payload,
        "policy": {
            "readable_paths": list(policy.readable_paths) + ["/crg-scratch"],
            "writable_paths": list(policy.writable_paths) + ["/crg-scratch"],
            "network": policy.network_granted,
            "subprocess": policy.subprocess_granted,
            "module_allow_list": list(policy.module_allow_list),
            "rlimits": policy.quota.rlimit_spec(
                subprocess_granted=policy.subprocess_granted
            ),
            "environment_allow_list": sorted(environment),
        },
    }
    request_bytes = json.dumps(request, ensure_ascii=True, sort_keys=True).encode("utf-8")
    run = policy.oci.run(
        request_bytes,
        environment=environment,
        readable_paths=policy.readable_paths,
        writable_paths=policy.writable_paths,
        network=policy.network_granted,
        memory_bytes=policy.quota.address_space_bytes,
        max_processes=policy.quota.max_processes,
        wall_clock_seconds=policy.quota.wall_clock_seconds,
    )
    reply: Optional[Mapping[str, Any]] = None
    notes = list(run.notes)
    if run.reply:
        try:
            decoded = json.loads(run.reply.decode("utf-8"))
        except (ValueError, UnicodeDecodeError) as exc:
            notes.append(f"the OCI child's reply was not canonical JSON: {exc}")
        else:
            if isinstance(decoded, dict) and decoded.get("protocol") == PROTOCOL_VERSION:
                reply = decoded
            else:
                notes.append(
                    f"the OCI child's reply did not carry protocol {PROTOCOL_VERSION!r}"
                )
    usage = dict(reply.get("rusage", {}) or {}) if reply is not None else {}
    usage.update(
        {
            "attribution": "resource use reported by the isolated container child",
            "oci_command_hash": run.command_hash,
            "oci_stdout_hash": "sha256:" + hashlib.sha256(
                run.stdout.encode("utf-8")
            ).hexdigest(),
            "oci_stdout_bytes": len(run.stdout.encode("utf-8")),
            "oci_stderr_hash": "sha256:" + hashlib.sha256(
                run.stderr.encode("utf-8")
            ).hexdigest(),
            "oci_stderr_bytes": len(run.stderr.encode("utf-8")),
        }
    )
    isolation = run.evidence.to_canonical()
    isolation["command_hash"] = run.command_hash
    isolation["network_mode"] = "bridge" if policy.network_granted else "none"
    isolation["root_filesystem"] = "read-only"
    isolation["capabilities"] = "all-dropped"
    isolation["no_new_privileges"] = True
    return _ChildRun(
        reply=reply,
        exit_status=run.exit_status,
        terminating_signal=run.terminating_signal,
        timed_out=run.timed_out,
        stdout=run.stdout,
        stderr=run.stderr,
        resource_usage=usage,
        notes=tuple(notes),
        isolation=isolation,
    )


def _invoke_child(
    package: PluginPackage, payload: Mapping[str, Any], policy: SandboxPolicy
) -> _ChildRun:
    if policy.effective_isolation_profile == IsolationProfile.OCI_KERNEL:
        return _run_child_oci(package, payload, policy)
    return _run_child(package, payload, policy)


def _read_all(fd: int) -> bytes:
    os.lseek(fd, 0, os.SEEK_SET)
    chunks: List[bytes] = []
    while True:
        chunk = os.read(fd, 65536)
        if not chunk:
            return b"".join(chunks)
        chunks.append(chunk)


def _categorize_silent_child(
    run: _ChildRun, policy: SandboxPolicy
) -> Tuple[str, SandboxViolation]:
    """Name the failure of a child that produced no reply.

    The distinctions here are the ones an operator acts on.  A wall-clock
    timeout means the plugin was still running; ``SIGXCPU`` means it burned its
    declared CPU; a bare ``SIGKILL`` after roughly the CPU quota means the hard
    limit fired because the plugin ignored the soft one; anything else is a
    crash whose reason is in the child's stderr, which is carried through
    verbatim rather than summarised away.
    """
    if run.timed_out:
        return (
            FailureCategory.WALL_CLOCK_TIMEOUT,
            SandboxViolation(
                FailureCategory.WALL_CLOCK_TIMEOUT,
                f"the plugin did not finish within the declared wall-clock quota of "
                f"{policy.quota.wall_clock_seconds} second(s); its process group was "
                "killed and the host survived (spec 36.3 resource quotas)",
                target="wall_clock_seconds",
            ),
        )
    status = run.exit_status
    if status is not None and status < 0:
        name = _signal_name(status)
        if name == "SIGXCPU":
            category = FailureCategory.CPU_QUOTA_EXCEEDED
        elif name == "SIGXFSZ":
            category = FailureCategory.FILESIZE_QUOTA_EXCEEDED
        elif name == "SIGKILL" and _burned_its_cpu_quota(run, policy):
            category = FailureCategory.CPU_QUOTA_EXCEEDED
        else:
            category = FailureCategory.CHILD_CRASHED
        return (
            category,
            SandboxViolation(
                category,
                f"the child was terminated by {name or status} before it could report; "
                f"child stderr: {run.stderr.strip()[:2000]!r}",
                target=name,
            ),
        )
    if status not in (0, None):
        return (
            FailureCategory.CHILD_CRASHED,
            SandboxViolation(
                FailureCategory.CHILD_CRASHED,
                f"the child exited with status {status} and wrote no reply; child stderr: "
                f"{run.stderr.strip()[:2000]!r}",
                target=str(status),
            ),
        )
    return (
        FailureCategory.MALFORMED_CHILD_OUTPUT,
        SandboxViolation(
            FailureCategory.MALFORMED_CHILD_OUTPUT,
            "the child exited cleanly without a well-formed reply; an invocation with no "
            "readable result is a failed invocation, never a silent success (spec 6.6). "
            + ("; ".join(run.notes) if run.notes else ""),
            target="reply",
        ),
    )


def _burned_its_cpu_quota(run: _ChildRun, policy: SandboxPolicy) -> bool:
    """Did this child use approximately its whole declared CPU quota?

    A ``SIGKILL`` with no other explanation is ambiguous: it could be the hard
    ``RLIMIT_CPU`` firing, or an out-of-memory killer, or a stray signal.  The
    measured CPU time disambiguates it, and the comparison is done in exact
    rationals -- the decimal string from ``getrusage`` parsed as a
    :class:`~fractions.Fraction` -- rather than in floats.
    """
    text = run.resource_usage.get("user_cpu_seconds")
    if not isinstance(text, str):
        return False
    try:
        used = Fraction(text)
    except (ValueError, ZeroDivisionError):  # pragma: no cover - malformed rusage
        return False
    return used >= Fraction(policy.quota.cpu_seconds)


def _canonical(payload: Any) -> Any:
    """Reduce to canonical JSON content, refusing binary floats (14.2, 14.3)."""
    return _canonicalizable(payload)


def run_sandboxed(
    package: PluginPackage,
    payload: Mapping[str, Any],
    *,
    policy: SandboxPolicy,
    signature: Optional[PackageSignature] = None,
    log: Optional[SandboxLog] = None,
    output_validator: Optional[
        Callable[[Mapping[str, Any]], Optional[SandboxViolation]]
    ] = None,
) -> SandboxResult:
    """Run one plugin invocation under isolation, and always return a result.

    The order is the security argument and it is not negotiable:

    1. the policy is checked for coherence -- an unknown permission token, a
       path declared without the permission that covers it -- and a bad policy
       stops here, because a control this host cannot interpret is a control it
       does not have (6.6);
    2. the package signature is verified against the declared trusted-key set.
       A bad, absent, or unknown-key signature stops here too, **before any
       process exists**, which is what lets a test assert that a tampered
       plugin's side effects did not happen;
    3. the input is canonicalized and hashed, so the log records what was asked
       independently of what the plugin says it received;
    4. the child is spawned, once, or twice when the policy asks for a
       determinism replay; and
    5. the outcome, whatever it is, becomes an :class:`InvocationRecord` that
       is content-hashed and appended to ``log``.

    Nothing in this function raises on plugin behaviour.  A host calling it in
    a request handler gets a :class:`SandboxResult` for a fork bomb, a bad
    signature, a segfault, and a correct answer alike, and reads
    :attr:`SandboxResult.failure_category` to tell them apart.
    """
    started_ns = time.time_ns()
    monotonic_start = time.monotonic_ns()
    violations: List[SandboxViolation] = list(policy.violations())
    signature_status, signature_violation = verify_package(
        package, signature, policy.trusted_keys
    )
    if signature_violation is not None:
        violations.append(signature_violation)

    canonical_payload: Any
    input_hash = ""
    try:
        canonical_payload = _canonical(payload)
        input_hash = content_hash(canonical_payload)
    except (CanonicalizationError, TypeError, ValueError) as exc:
        canonical_payload = None
        violations.append(
            SandboxViolation(
                FailureCategory.POLICY_ERROR,
                f"the invocation input is not canonically encodable, so it cannot be "
                f"hashed for the invocation log: {type(exc).__name__}: {exc} "
                "(spec 14.2, 14.3, 36.3)",
                target="payload",
            )
        )

    def finish(
        *,
        category: str,
        payload_out: Optional[Mapping[str, Any]],
        environment: EnvironmentManifest,
        run: Optional[_ChildRun],
        replays: int,
        output_hash: str = "",
        extra_notes: Sequence[str] = (),
    ) -> SandboxResult:
        ended_ns = time.time_ns()
        record = InvocationRecord(
            plugin_identity=package.manifest.identity,
            plugin_version=package.manifest.version,
            manifest_hash=package.manifest.manifest_hash(),
            package_digest=package.package_digest(),
            module_source_digest=package.source_digest(),
            signature_status=signature_status,
            signing_key_id=signature.key_id if signature is not None else "",
            signature_profile=(
                signature.profile if signature is not None else SANDBOX_SIGNATURE_PROFILE
            ),
            granted_permissions=policy.granted_permissions,
            input_hash=input_hash,
            output_hash=output_hash,
            started_at=_iso(started_ns),
            ended_at=_iso(ended_ns),
            duration_nanoseconds=time.monotonic_ns() - monotonic_start,
            exit_status=run.exit_status if run is not None else None,
            terminating_signal=run.terminating_signal if run is not None else "",
            timed_out=bool(run.timed_out) if run is not None else False,
            resource_usage=(
                dict(run.resource_usage) if run is not None else {"not_started": "true"}
            ),
            failure_category=category,
            violations=tuple(violations),
            environment_hash=environment.manifest_hash(),
            policy_hash=policy.policy_hash(),
            replays=replays,
            notes=tuple(run.notes if run is not None else ()) + tuple(extra_notes),
        )
        if log is not None:
            log.append(record)
        return SandboxResult(
            ok=category == FailureCategory.OK,
            failure_category=category,
            violations=tuple(violations),
            payload=payload_out,
            record=record,
            environment=environment,
            stdout=run.stdout if run is not None else "",
            stderr=run.stderr if run is not None else "",
        )

    if violations:
        return finish(
            category=violations[0].category,
            payload_out=None,
            environment=declared_environment(policy),
            run=None,
            replays=0,
        )

    try:
        first = _invoke_child(package, canonical_payload, policy)
    except Exception as exc:  # noqa: BLE001 - a host failure is still a typed result
        violations.append(
            SandboxViolation(
                FailureCategory.HOST_ERROR,
                f"the host could not run the plugin: {type(exc).__name__}: {exc}",
                target=type(exc).__name__,
            )
        )
        return finish(
            category=FailureCategory.HOST_ERROR,
            payload_out=None,
            environment=declared_environment(policy),
            run=None,
            replays=0,
        )

    environment = (
        _observed_environment(
            first.reply.get("environment", {}) or {}, isolation=first.isolation
        )
        if first.reply is not None and first.reply.get("environment")
        else declared_environment(policy)
    )

    if first.reply is None:
        category, violation = _categorize_silent_child(first, policy)
        violations.append(violation)
        return finish(
            category=category,
            payload_out=None,
            environment=environment,
            run=first,
            replays=1,
        )

    for entry in first.reply.get("violations", ()) or ():
        violations.append(
            SandboxViolation(
                category=str(entry.get("category", FailureCategory.PLUGIN_ERROR)),
                detail=str(entry.get("detail", "")),
                target=str(entry.get("target", "")),
            )
        )
    category = str(first.reply.get("failure_category", FailureCategory.MALFORMED_CHILD_OUTPUT))
    if category not in FailureCategory.ALL:
        violations.append(
            SandboxViolation(
                FailureCategory.MALFORMED_CHILD_OUTPUT,
                f"the child reported failure category {category!r}, which is outside the "
                "declared vocabulary; an uninterpretable outcome is a failure (spec 6.6)",
                target=category,
            )
        )
        category = FailureCategory.MALFORMED_CHILD_OUTPUT
    if first.timed_out:
        # A reply that arrived from a process we had to kill describes a run
        # that did not finish.  The timeout outranks whatever it says.
        replaced, violation = _categorize_silent_child(first, policy)
        violations.append(violation)
        category = replaced

    if category != FailureCategory.OK:
        # The child's own summary is appended when it says something the ledger
        # entries do not -- most importantly when the plugin caught its own
        # refusal and returned a plausible answer, which is a finding about the
        # plugin's intent that the bare refusal does not carry.
        summary = str(first.reply.get("detail", ""))
        if summary and summary not in {entry.detail for entry in violations}:
            violations.append(SandboxViolation(category, summary))
        if not violations:
            violations.append(
                SandboxViolation(category, "the plugin failed without detail")
            )
        return finish(
            category=category,
            payload_out=None,
            environment=environment,
            run=first,
            replays=1,
        )

    result_payload = first.reply.get("payload")
    if not isinstance(result_payload, dict):
        violations.append(
            SandboxViolation(
                FailureCategory.MALFORMED_CHILD_OUTPUT,
                "the child reported success but returned no object payload; a successful "
                "invocation with no result is not a success (spec 6.6)",
                target="payload",
            )
        )
        return finish(
            category=FailureCategory.MALFORMED_CHILD_OUTPUT,
            payload_out=None,
            environment=environment,
            run=first,
            replays=1,
        )

    if output_validator is not None:
        validation = output_validator(result_payload)
        if validation is not None:
            violations.append(validation)
            return finish(
                category=validation.category,
                payload_out=None,
                environment=environment,
                run=first,
                replays=1,
            )

    try:
        output_hash = content_hash(_canonical(result_payload))
    except (CanonicalizationError, TypeError, ValueError) as exc:
        violations.append(
            SandboxViolation(
                FailureCategory.MALFORMED_CHILD_OUTPUT,
                f"the plugin's output is not canonically encodable: "
                f"{type(exc).__name__}: {exc} (spec 14.2, 14.3)",
                target="payload",
            )
        )
        return finish(
            category=FailureCategory.MALFORMED_CHILD_OUTPUT,
            payload_out=None,
            environment=environment,
            run=first,
            replays=1,
        )

    replays = 1
    notes: List[str] = []
    if policy.determinism_replay:
        replays = 2
        second = _invoke_child(package, canonical_payload, policy)
        second_payload = (
            second.reply.get("payload") if second.reply is not None else None
        )
        second_hash = ""
        if isinstance(second_payload, dict):
            try:
                second_hash = content_hash(_canonical(second_payload))
            except (CanonicalizationError, TypeError, ValueError) as exc:  # pragma: no cover
                notes.append(f"the replay's output could not be canonicalized: {exc}")
        if second_hash != output_hash:
            violations.append(
                SandboxViolation(
                    FailureCategory.NONDETERMINISTIC_OUTPUT,
                    "the plugin's manifest declares "
                    f"{DeterminismStatus.DETERMINISTIC}, but two invocations on identical "
                    f"input produced different canonical output ({output_hash} then "
                    f"{second_hash or '(no output)'}).  A generator that may return a "
                    "different family on the next run closes nothing, so the run is "
                    "refused rather than certified (spec 6.5, 21.6, 36.2)",
                    target="determinism_status",
                )
            )
            return finish(
                category=FailureCategory.NONDETERMINISTIC_OUTPUT,
                payload_out=None,
                environment=environment,
                run=first,
                replays=replays,
                output_hash=output_hash,
                extra_notes=notes,
            )
        notes.append(
            "the declared DETERMINISTIC status was checked by replay: two invocations on "
            "identical input produced identical canonical output"
        )

    return finish(
        category=FailureCategory.OK,
        payload_out=result_payload,
        environment=environment,
        run=first,
        replays=replays,
        output_hash=output_hash,
        extra_notes=notes,
    )


# ---------------------------------------------------------------------------
# a generator that lives on the other side of the boundary (spec 28.4, 36.3)
# ---------------------------------------------------------------------------

#: The key a sandboxed generator's reply carries its proposals under.  The
#: shape is deliberately minimal: a transformation name, an exact signature,
#: and attributes.  A plugin cannot propose an identity, a legality state, a
#: parent, a witness, or a provenance stamp, because :func:`propose_record`
#: derives all of those on the host side from the *declared* definition.  That
#: is the isolation boundary expressed as a data schema rather than as a
#: promise: untrusted code contributes arithmetic, and the host contributes
#: every claim a certificate later rests on.
PROPOSAL_KEY = "proposals"


@dataclass
class SandboxedGenerator:
    """A generator whose code runs in another process (spec 28.4, 36.3).

    It satisfies the :class:`crg_generate.generator.Generator` protocol, so
    :func:`crg_generate.registry.closure` drives it exactly as it drives a
    first-party generator and knows nothing about the boundary.  The
    :class:`~crg_generate.generator.GeneratorDefinition` is the *host's*
    declaration of what the plugin is, not the plugin's; a package whose
    manifest and definition disagree about identity is refused at construction,
    because a definition hash stamped onto a record must describe the code that
    produced it (28.4, 36.3).

    Failure follows the definition's declared failure semantics (28.4).  Under
    ``SKIP_AND_RECORD`` a refused invocation yields no children and the region
    the generator would have covered becomes ``UNGENERATED`` in the registry --
    never ``INFEASIBLE``, because a plugin that was killed for burning its CPU
    quota has told us nothing whatever about feasibility (28.4, 28.6).  Under
    ``FAIL_CLOSED`` it raises :class:`~crg_generate.generator.GeneratorError`,
    which is the registry's own contract for aborting a build.
    """

    definition: GeneratorDefinition
    package: PluginPackage
    policy: SandboxPolicy
    signature: Optional[PackageSignature] = None
    log: SandboxLog = field(default_factory=SandboxLog)

    def __post_init__(self) -> None:
        if self.package.manifest.identity and self.package.manifest.version:
            expected = self.package.manifest.qualified_id
            if expected != self.definition.qualified_id:
                raise SandboxError(
                    f"the package manifest identifies {expected!r} while the generator "
                    f"definition identifies {self.definition.qualified_id!r}; the "
                    "definition hash stamped onto every produced record must describe "
                    "the code that produced it (spec 28.4, 36.3)"
                )

    @property
    def last_record(self) -> Optional[InvocationRecord]:
        return self.log.records[-1] if self.log.records else None

    def propose(
        self, parent: RealizationRecord, context: GenerationContext
    ) -> Tuple[RealizationRecord, ...]:
        payload = {
            "parent": parent.to_canonical(),
            "context": context.to_canonical(),
            "declared_transformations": list(self.definition.transformations),
        }
        result = run_sandboxed(
            self.package,
            payload,
            policy=self.policy,
            signature=self.signature,
            log=self.log,
            output_validator=_validate_proposals,
        )
        if not result.ok:
            if self.definition.failure_semantics == "FAIL_CLOSED":
                raise GeneratorError(
                    f"sandboxed generator {self.definition.qualified_id} failed with "
                    f"{result.failure_category}: {result.detail} "
                    "(declared failure semantics FAIL_CLOSED, spec 28.4)"
                )
            return ()
        if result.payload is None:  # pragma: no cover - run_sandboxed guarantees this
            raise GeneratorError(
                f"sandboxed generator {self.definition.qualified_id} reported success "
                "with no payload; the sandbox is not honouring its own contract"
            )
        return self._records_from(result.payload, parent)

    def _records_from(
        self, payload: Mapping[str, Any], parent: RealizationRecord
    ) -> Tuple[RealizationRecord, ...]:
        """Turn validated proposals into records, on the trusted side.

        Every claim a certificate could rest on is added here:
        :func:`propose_record` derives the content identity, stamps the
        generator definition hash, extends the derivation path, increments the
        depth, and leaves legality ``UNEVALUATED``.  A plugin that wanted to
        mark its own output ``LEGAL`` has no field in which to say so.
        """
        records: List[RealizationRecord] = []
        for proposal in payload[PROPOSAL_KEY]:
            signature = Signature([str(value) for value in proposal["signature"]])
            records.append(
                propose_record(
                    parent=parent,
                    definition=self.definition,
                    transformation=str(proposal["transformation"]),
                    signature=signature,
                    attributes=dict(proposal.get("attributes", {})),
                )
            )
        return tuple(records)


def _validate_proposals(payload: Mapping[str, Any]) -> Optional[SandboxViolation]:
    """Check a sandboxed generator's reply against its declared output schema.

    The host validates before it constructs, because 36.2 makes the output
    schema a declaration and 6.6 makes an uninterpretable answer a failure
    rather than a partial success.  A proposal list that is half well-formed
    produces no records at all: half a family is a completeness claim nobody
    made.
    """
    proposals = payload.get(PROPOSAL_KEY)
    if not isinstance(proposals, list):
        return SandboxViolation(
            FailureCategory.MALFORMED_CHILD_OUTPUT,
            f"the plugin's reply carries no {PROPOSAL_KEY!r} list; the declared output "
            "schema of a sandboxed generator is "
            f"{{{PROPOSAL_KEY!r}: [{{'transformation': str, 'signature': [exact], "
            "'attributes': object}}]}} (spec 36.2)",
            target=PROPOSAL_KEY,
        )
    for index, proposal in enumerate(proposals):
        where = f"{PROPOSAL_KEY}[{index}]"
        if not isinstance(proposal, dict):
            return SandboxViolation(
                FailureCategory.MALFORMED_CHILD_OUTPUT,
                f"{where} is a {type(proposal).__name__}, not an object",
                target=where,
            )
        if not isinstance(proposal.get("transformation"), str):
            return SandboxViolation(
                FailureCategory.MALFORMED_CHILD_OUTPUT,
                f"{where} declares no transformation name (spec 28.4)",
                target=where,
            )
        values = proposal.get("signature")
        if not isinstance(values, list) or not values:
            return SandboxViolation(
                FailureCategory.MALFORMED_CHILD_OUTPUT,
                f"{where} carries no signature coordinates (spec 19.1)",
                target=where,
            )
        for position, value in enumerate(values):
            if isinstance(value, bool) or not isinstance(value, (int, str)):
                return SandboxViolation(
                    FailureCategory.MALFORMED_CHILD_OUTPUT,
                    f"{where}.signature[{position}] is a "
                    f"{type(value).__name__}; a coordinate must be an exact integer or "
                    "an exact rational string such as '3/4' (spec 14.2)",
                    target=where,
                )
            try:
                Fraction(value)
            except (ValueError, ZeroDivisionError, TypeError):
                return SandboxViolation(
                    FailureCategory.MALFORMED_CHILD_OUTPUT,
                    f"{where}.signature[{position}] is {value!r}, which is not an exact "
                    "rational (spec 14.2)",
                    target=where,
                )
        attributes = proposal.get("attributes", {})
        if not isinstance(attributes, dict):
            return SandboxViolation(
                FailureCategory.MALFORMED_CHILD_OUTPUT,
                f"{where}.attributes is a {type(attributes).__name__}, not an object",
                target=where,
            )
    return None
