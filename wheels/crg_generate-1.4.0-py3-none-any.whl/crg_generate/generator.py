"""The generator contract: what a realization generator MUST declare.

Normative basis: master specification section 28.4 (generator contract), with
section 6.5 (deterministic authority), section 6.7 (extensibility without core
modification), section 18 (typed dependencies), and section 21 (completeness
basis).

Specification 28.4 enumerates fourteen declarations a generator MUST make.
``identity and version`` is one bullet describing two independent facts, so
:class:`GeneratorDefinition` carries fifteen fields; :data:`DECLARED_ITEMS`
maps each spec bullet to the field or fields that discharge it, and
``__post_init__`` refuses a definition that leaves any of them empty.  A
generator that has not declared its completeness implications cannot be used
to derive a completeness basis, so the declaration is a precondition, not
documentation.

Two rules of this module are structural rather than advisory:

1. **A generator MUST NOT represent an ungenerated candidate as infeasible**
   (28.4).  The mechanism that makes this possible to obey is
   :class:`CapabilityGate`: when a generator cannot enter a region because a
   declared capability is absent, it says so by *not proposing*, and the
   registry records the region as ``UNGENERATED``.  It never emits a record
   claiming the region was explored and found infeasible.
2. **Identity is content, not sequence** (6.5).  :func:`derive_realization_id`
   hashes the parent, the generator, the transformation, the signature, and
   the salient attributes.  No counter and no ``uuid4`` appears anywhere in
   this package, so regenerating a family reproduces the same identifiers and
   therefore the same canonical bundle hash.  Because the parent and the
   transformation are inside the hash, two paths that arrive at the same
   signature receive *different* identities and both survive as separate
   records -- which is what preserves the realization fibers of 19.6.
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import (
    Any,
    Callable,
    Dict,
    Iterable,
    Mapping,
    Optional,
    Protocol,
    Sequence,
    Tuple,
    runtime_checkable,
)

from crg_model.canonical import content_hash
from crg_model.envelope import EvidenceClass
from crg_model.numeric import Exact
from crg_model.records import CoordinateSchema, RealizationRecord, Signature

from .legality import LegalityPredicate, LegalityStatus, _canonicalizable

__all__ = [
    "ENGINE_ID",
    "ENGINE_VERSION",
    "GeneratorError",
    "DeterminismStatus",
    "SemanticRule",
    "WitnessMethod",
    "ParentChildRelation",
    "FailureSemantics",
    "ObligationType",
    "CapabilityGate",
    "CompletenessImplication",
    "Obligation",
    "GenerationContext",
    "GeneratorDefinition",
    "Generator",
    "DECLARED_ITEMS",
    "derive_realization_id",
    "propose_record",
    "record_depth",
    "record_path",
    "seed_record",
    "as_seed",
    "SEED_TRANSFORMATION",
    "ATTR_TRANSFORMATION",
    "ATTR_GENERATOR_HASH",
    "ATTR_PATH",
    "ATTR_DEPTH",
]

ENGINE_ID = "crg-generate"
ENGINE_VERSION = "crg-generate@0.2.0"

#: Attribute keys the registry writes onto every generated record.  They are
#: part of the canonical record, so provenance survives export and re-import.
ATTR_TRANSFORMATION = "crg_transformation"
ATTR_GENERATOR_HASH = "crg_generator_definition_hash"
ATTR_PATH = "crg_derivation_path"
ATTR_DEPTH = "crg_depth"

#: The transformation label of a seed: it was received, not produced.
SEED_TRANSFORMATION = "SEED"


class GeneratorError(ValueError):
    """Raised when a generator declaration or emission violates 28.4."""


class DeterminismStatus:
    """Specification 28.4 "determinism status", read against 6.5."""

    DETERMINISTIC = "DETERMINISTIC"
    SEEDED_DETERMINISTIC = "SEEDED_DETERMINISTIC"
    NONDETERMINISTIC = "NONDETERMINISTIC"

    ALL = frozenset({DETERMINISTIC, SEEDED_DETERMINISTIC, NONDETERMINISTIC})

    #: Only these may support a ``GENERATOR_CLOSED`` completeness basis: a
    #: search that may return a different family on the next run has not
    #: closed anything (spec 6.5, 21.6).
    MAY_CLOSE_A_FAMILY = frozenset({DETERMINISTIC, SEEDED_DETERMINISTIC})


class SemanticRule:
    """Specification 28.4 "semantic-preservation or approximation rule"."""

    SEMANTICS_PRESERVING = "SEMANTICS_PRESERVING"
    REFINING = "REFINING"
    APPROXIMATING = "APPROXIMATING"
    RELAXING = "RELAXING"

    ALL = frozenset({SEMANTICS_PRESERVING, REFINING, APPROXIMATING, RELAXING})


class WitnessMethod:
    """Specification 28.4 "witness method"."""

    CONSTRUCTIVE_TRANSFORMATION = "CONSTRUCTIVE_TRANSFORMATION"
    EXPLICIT_ARTIFACT = "EXPLICIT_ARTIFACT"
    EXTERNAL_TOOL_REPLAY = "EXTERNAL_TOOL_REPLAY"
    DECLARED_ONLY = "DECLARED_ONLY"

    ALL = frozenset(
        {
            CONSTRUCTIVE_TRANSFORMATION,
            EXPLICIT_ARTIFACT,
            EXTERNAL_TOOL_REPLAY,
            DECLARED_ONLY,
        }
    )


class ParentChildRelation:
    """Specification 28.4 "parent-child relation"."""

    CHILD_REFINES_PARENT = "CHILD_REFINES_PARENT"
    CHILD_REPLACES_PARENT = "CHILD_REPLACES_PARENT"
    CHILD_ALTERNATIVE_TO_PARENT = "CHILD_ALTERNATIVE_TO_PARENT"
    SEED_ONLY = "SEED_ONLY"

    ALL = frozenset(
        {
            CHILD_REFINES_PARENT,
            CHILD_REPLACES_PARENT,
            CHILD_ALTERNATIVE_TO_PARENT,
            SEED_ONLY,
        }
    )


class FailureSemantics:
    """Specification 28.4 "failure semantics"."""

    #: The whole registry build aborts; nothing partial is emitted.
    FAIL_CLOSED = "FAIL_CLOSED"
    #: The failing invocation yields nothing, is recorded, and the region it
    #: would have covered becomes UNGENERATED -- never INFEASIBLE.
    SKIP_AND_RECORD = "SKIP_AND_RECORD"

    ALL = frozenset({FAIL_CLOSED, SKIP_AND_RECORD})


class ObligationType:
    """Typed obligation coordinates (spec 28.3 step 8, 36.4)."""

    RESOURCE = "RESOURCE"
    CAPABILITY = "CAPABILITY"
    INTERFACE = "INTERFACE"
    ACCOUNTING = "ACCOUNTING"
    VERIFICATION = "VERIFICATION"
    QUALIFICATION = "QUALIFICATION"

    ALL = frozenset({RESOURCE, CAPABILITY, INTERFACE, ACCOUNTING, VERIFICATION, QUALIFICATION})


@dataclass(frozen=True)
class CapabilityGate:
    """A declared capability a generator requires before it may propose.

    Specification 28.4 "capability gates".  A closed gate is the honest way to
    say *I did not look here*: the generator proposes nothing, the registry
    records an ``UNGENERATED`` region citing this gate, and the completeness
    basis loses the right to claim ``GENERATOR_CLOSED``.  The forbidden
    alternative -- emitting the unexplored region as ``INFEASIBLE`` -- would
    convert an absence of evidence into evidence of absence.
    """

    capability: str
    description: str
    required: bool = True

    def __post_init__(self) -> None:
        if not self.capability:
            raise GeneratorError("a capability gate MUST name a capability (spec 28.4)")

    def is_open(self, context: "GenerationContext") -> bool:
        value = context.capabilities.get(self.capability)
        if value is None:
            return not self.required
        return bool(value)

    def to_canonical(self) -> dict:
        return {
            "capability": self.capability,
            "description": self.description,
            "required": self.required,
        }


@dataclass(frozen=True)
class CompletenessImplication:
    """Specification 28.4 "completeness implications".

    ``closes_family`` is the generator author's declaration that reaching a
    fixpoint of this generator enumerates every candidate the generator's
    declared transformations can reach, with nothing knowingly omitted.  It is
    a claim about the generator, and :mod:`crg_generate.registry` will only
    ever *weaken* it -- a generator saying "I close the family" does not make
    the family closed if the closure was truncated or the generator is
    nondeterministic.
    """

    closes_family: bool
    rationale: str
    known_omissions: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not self.rationale:
            raise GeneratorError(
                "completeness implications MUST carry a rationale; an undefended closure "
                "claim is not evidence (spec 21.3, 28.4)"
            )
        if self.closes_family and self.known_omissions:
            raise GeneratorError(
                "a generator declaring known omissions cannot also declare that it closes "
                "the family (spec 21.2 KNOWN_INCOMPLETE)"
            )

    def to_canonical(self) -> dict:
        return {
            "closes_family": self.closes_family,
            "rationale": self.rationale,
            "known_omissions": list(self.known_omissions),
        }


@dataclass(frozen=True)
class Obligation:
    """One typed obligation extracted from a realization (spec 28.3 step 8)."""

    obligation_type: str
    realization_id: str
    name: str
    value: Optional[Exact] = None
    unit: Optional[str] = None
    scope: Optional[str] = None
    evidence_class: str = EvidenceClass.CONSTRUCTIVE
    source: str = ""

    def __post_init__(self) -> None:
        if self.obligation_type not in ObligationType.ALL:
            raise GeneratorError(
                f"unknown obligation type {self.obligation_type!r}; declare one of "
                f"{sorted(ObligationType.ALL)} (spec 28.3 step 8)"
            )
        if not self.name:
            raise GeneratorError("an obligation MUST be named (spec 18.2, 28.3)")
        if self.evidence_class not in EvidenceClass.ALL:
            raise GeneratorError(f"unknown evidence class {self.evidence_class!r} (spec 5.3)")

    @property
    def obligation_id(self) -> str:
        return "obl-" + content_hash(self.to_canonical()).split(":", 1)[1][:24]

    def to_canonical(self) -> dict:
        record: dict = {
            "obligation_type": self.obligation_type,
            "realization_id": self.realization_id,
            "name": self.name,
            "evidence_class": self.evidence_class,
        }
        if self.value is not None:
            record["value"] = self.value.to_canonical()
        for key, value in (("unit", self.unit), ("scope", self.scope), ("source", self.source)):
            if value:
                record[key] = value
        return record


# ---------------------------------------------------------------------------
# generation context
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class GenerationContext:
    """Everything a generator may read, and nothing it may not.

    The context is canonicalizable by construction (:meth:`fingerprint` refuses
    binary floats through :mod:`crg_generate.legality`), because every legality
    verdict and every generated record is a statement *relative to this
    context*: specification 18.3's ``DEPENDS_ON_CONTEXT_FINGERPRINT`` edge is
    what lets a context change invalidate exactly the records that depended on
    it, and an unfingerprintable context could not carry that edge.

    ``permissions`` is the declared permission list of section 36.3.  This SDK
    cannot sandbox a plugin in-process, so the permission list is enforced
    where it can be: a generator is invoked only when the permissions its pack
    declared are present here, and every invocation is logged with the
    generator's definition hash.
    """

    schema: CoordinateSchema
    capabilities: Mapping[str, Any] = field(default_factory=dict)
    parameters: Mapping[str, Any] = field(default_factory=dict)
    permissions: Tuple[str, ...] = ()
    declared_universe: str = "the closure of the declared generator set"
    validity: Optional[str] = None

    def get(self, key: str, default: Any = None) -> Any:
        """Read a declared parameter.  Absent is absent, never zero (37.3)."""
        return self.parameters.get(key, default)

    def require(self, key: str) -> Any:
        if key not in self.parameters:
            raise GeneratorError(
                f"the generation context declares no parameter {key!r}; a missing parameter "
                "MUST remain missing rather than default to a value (spec 6.6, 37.3)"
            )
        return self.parameters[key]

    def has_permission(self, permission: str) -> bool:
        return permission in self.permissions

    def as_mapping(self) -> Dict[str, Any]:
        return {
            "schema": self.schema.to_canonical(),
            "capabilities": dict(self.capabilities),
            "parameters": dict(self.parameters),
            "permissions": list(self.permissions),
            "declared_universe": self.declared_universe,
            "validity": self.validity,
        }

    def to_canonical(self) -> dict:
        return _canonicalizable(self.as_mapping())

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())


# ---------------------------------------------------------------------------
# the generator contract (spec 28.4)
# ---------------------------------------------------------------------------

#: Each bullet of specification 28.4 mapped to the field(s) that discharge it.
DECLARED_ITEMS: Tuple[Tuple[str, Tuple[str, ...]], ...] = (
    ("identity and version", ("identity", "version")),
    ("accepted source types", ("accepted_source_types",)),
    ("transformations produced", ("transformations",)),
    ("semantic-preservation or approximation rule", ("semantic_rule",)),
    ("legality predicates", ("legality_predicates",)),
    ("capability gates", ("capability_gates",)),
    ("obligation extraction", ("obligation_types", "obligation_extractor")),
    ("parent-child relation", ("parent_child_relation",)),
    ("dependencies", ("dependencies",)),
    ("witness method", ("witness_method",)),
    ("determinism status", ("determinism_status",)),
    ("failure semantics", ("failure_semantics",)),
    ("completeness implications", ("completeness_implications",)),
    ("conformance tests", ("conformance_tests",)),
)


@dataclass(frozen=True)
class GeneratorDefinition:
    """Every declaration specification 28.4 requires of a generator.

    The fields are in the order of the specification's bullets.  Anything a
    generator did not declare is a hole in the provenance of every record it
    produces, so ``__post_init__`` refuses an incomplete definition instead of
    substituting a default: an assumed determinism status or an assumed
    completeness implication would be exactly the kind of invisible claim
    section 21 exists to prevent.
    """

    # 28.4 (1) identity and version
    identity: str
    version: str
    # 28.4 (2) accepted source types
    accepted_source_types: Tuple[str, ...]
    # 28.4 (3) transformations produced
    transformations: Tuple[str, ...]
    # 28.4 (4) semantic-preservation or approximation rule
    semantic_rule: str
    # 28.4 (11) determinism status
    determinism_status: str
    # 28.4 (12) failure semantics
    failure_semantics: str
    # 28.4 (13) completeness implications
    completeness_implications: CompletenessImplication
    # 28.4 (14) conformance tests
    conformance_tests: Tuple[str, ...]
    # 28.4 (5) legality predicates
    legality_predicates: Tuple[LegalityPredicate, ...] = ()
    # 28.4 (6) capability gates
    capability_gates: Tuple[CapabilityGate, ...] = ()
    # 28.4 (7) obligation extraction
    obligation_types: Tuple[str, ...] = ()
    obligation_extractor: Optional[
        Callable[[RealizationRecord, GenerationContext], Sequence[Obligation]]
    ] = None
    # 28.4 (8) parent-child relation
    parent_child_relation: str = ParentChildRelation.CHILD_ALTERNATIVE_TO_PARENT
    # 28.4 (9) dependencies
    dependencies: Tuple[str, ...] = ()
    # 28.4 (10) witness method
    witness_method: str = WitnessMethod.CONSTRUCTIVE_TRANSFORMATION
    #: Free-text detail for the semantic rule; not a substitute for it.
    semantic_rule_detail: str = ""
    #: Declared permissions this generator needs from its pack (spec 36.2).
    required_permissions: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not self.identity:
            raise GeneratorError("a generator MUST declare an identity (spec 28.4)")
        if not self.version:
            raise GeneratorError(
                f"generator {self.identity!r} MUST declare a version (spec 28.4, 15.1)"
            )
        if not self.accepted_source_types:
            raise GeneratorError(
                f"generator {self.qualified_id} MUST declare its accepted source types "
                "(spec 28.4); a generator that accepts anything has validated nothing"
            )
        if not self.transformations:
            raise GeneratorError(
                f"generator {self.qualified_id} MUST declare the transformations it produces "
                "(spec 28.4)"
            )
        if self.semantic_rule not in SemanticRule.ALL:
            raise GeneratorError(
                f"generator {self.qualified_id} declares semantic rule "
                f"{self.semantic_rule!r}; expected one of {sorted(SemanticRule.ALL)} (spec 28.4)"
            )
        if self.determinism_status not in DeterminismStatus.ALL:
            raise GeneratorError(
                f"generator {self.qualified_id} declares determinism status "
                f"{self.determinism_status!r}; expected one of "
                f"{sorted(DeterminismStatus.ALL)} (spec 28.4, 6.5)"
            )
        if self.failure_semantics not in FailureSemantics.ALL:
            raise GeneratorError(
                f"generator {self.qualified_id} declares failure semantics "
                f"{self.failure_semantics!r}; expected one of "
                f"{sorted(FailureSemantics.ALL)} (spec 28.4)"
            )
        if self.parent_child_relation not in ParentChildRelation.ALL:
            raise GeneratorError(
                f"generator {self.qualified_id} declares parent-child relation "
                f"{self.parent_child_relation!r} (spec 28.4)"
            )
        if self.witness_method not in WitnessMethod.ALL:
            raise GeneratorError(
                f"generator {self.qualified_id} declares witness method "
                f"{self.witness_method!r} (spec 28.4)"
            )
        if not isinstance(self.completeness_implications, CompletenessImplication):
            raise GeneratorError(
                f"generator {self.qualified_id} MUST declare completeness implications as a "
                "CompletenessImplication (spec 28.4, 21.3)"
            )
        if not self.conformance_tests:
            raise GeneratorError(
                f"generator {self.qualified_id} MUST declare its conformance tests "
                "(spec 28.4, 36.2); an unconformance-tested generator cannot be accepted "
                "from a third party"
            )
        unknown = [t for t in self.obligation_types if t not in ObligationType.ALL]
        if unknown:
            raise GeneratorError(
                f"generator {self.qualified_id} declares unknown obligation types {unknown} "
                "(spec 28.3 step 8)"
            )
        if self.obligation_extractor is not None and not self.obligation_types:
            raise GeneratorError(
                f"generator {self.qualified_id} supplies an obligation extractor but declares "
                "no obligation types; an untyped obligation is not extractable (spec 18.1)"
            )
        seen = set()
        for predicate in self.legality_predicates:
            if predicate.qualified_id in seen:
                raise GeneratorError(
                    f"generator {self.qualified_id} registers legality predicate "
                    f"{predicate.qualified_id} twice"
                )
            seen.add(predicate.qualified_id)

    @property
    def qualified_id(self) -> str:
        return f"{self.identity}@{self.version}"

    @property
    def may_close_a_family(self) -> bool:
        """Spec 6.5, 21.6: closure requires reproducibility plus the claim."""
        return (
            self.determinism_status in DeterminismStatus.MAY_CLOSE_A_FAMILY
            and self.completeness_implications.closes_family
        )

    def gates_closed_in(self, context: GenerationContext) -> Tuple[CapabilityGate, ...]:
        """Gates this context does not open (spec 28.4 capability gates)."""
        return tuple(gate for gate in self.capability_gates if not gate.is_open(context))

    def missing_permissions(self, context: GenerationContext) -> Tuple[str, ...]:
        return tuple(
            sorted(p for p in self.required_permissions if not context.has_permission(p))
        )

    def to_canonical(self) -> dict:
        return {
            "identity": self.identity,
            "version": self.version,
            "accepted_source_types": list(self.accepted_source_types),
            "transformations": list(self.transformations),
            "semantic_rule": self.semantic_rule,
            "semantic_rule_detail": self.semantic_rule_detail,
            "legality_predicates": [p.to_canonical() for p in self.legality_predicates],
            "capability_gates": [g.to_canonical() for g in self.capability_gates],
            "obligation_types": list(self.obligation_types),
            "obligation_extraction": self.obligation_extractor is not None,
            "parent_child_relation": self.parent_child_relation,
            "dependencies": list(self.dependencies),
            "witness_method": self.witness_method,
            "determinism_status": self.determinism_status,
            "failure_semantics": self.failure_semantics,
            "completeness_implications": self.completeness_implications.to_canonical(),
            "conformance_tests": list(self.conformance_tests),
            "required_permissions": list(self.required_permissions),
        }

    def definition_hash(self) -> str:
        """Content hash of the declaration (spec 36.3 complete invocation logs)."""
        return content_hash(self.to_canonical())


@runtime_checkable
class Generator(Protocol):
    """A realization generator (spec 28.2 "generators", 6.7).

    ``propose`` receives one parent realization and the generation context and
    returns the children reachable from it by this generator's *declared*
    transformations.  It returns an iterable, possibly empty; an empty result
    means "no declared transformation applies to this parent", which is a
    statement about the transformations, not about the legality of anything.

    A generator MUST NOT:

    * return a record for a candidate it did not construct;
    * label any candidate ``INFEASIBLE`` that it did not evaluate (28.4);
    * use a transformation it did not declare;
    * depend on iteration order, wall-clock time, or a random source when it
      declares ``DETERMINISTIC`` (6.5).

    The registry checks each of these against the definition and refuses the
    emission rather than trusting the declaration.
    """

    definition: GeneratorDefinition

    def propose(
        self, parent: RealizationRecord, context: GenerationContext
    ) -> Iterable[RealizationRecord]:
        ...


# ---------------------------------------------------------------------------
# content-derived identity (spec 6.5, 14.1, 19.6)
# ---------------------------------------------------------------------------


def derive_realization_id(
    *,
    parent_id: Optional[str],
    generator: str,
    transformation: str,
    signature: Signature,
    attributes: Optional[Mapping[str, Any]] = None,
    prefix: str = "rz",
) -> str:
    """Deterministic content-derived realization identity (spec 6.5, 14.1).

    The digest covers the parent, the generator, the transformation, the exact
    signature, and the record's own attributes.  Two consequences are both
    load-bearing:

    * regenerating the same family from the same inputs yields the same
      identifiers, hence the same canonical bundle hash (6.5); and
    * two different derivation paths that land on the same signature yield two
      *different* identifiers, so both records survive and ``build_R`` places
      them in one fiber rather than one of them silently replacing the other
      (19.6, 28.6 "equal signatures do not erase realization identity").
    """
    digest = content_hash(
        {
            "parent": parent_id,
            "generator": generator,
            "transformation": transformation,
            "signature": signature.to_canonical(),
            "attributes": _canonicalizable(dict(attributes or {})),
        }
    )
    return f"{prefix}-{digest.split(':', 1)[1][:24]}"


def record_depth(record: RealizationRecord) -> int:
    """Closure depth recorded on a record; seeds are at depth zero."""
    value = record.attributes.get(ATTR_DEPTH, 0)
    return int(value) if isinstance(value, int) else 0


def record_path(record: RealizationRecord) -> str:
    """The ``>``-joined derivation path recorded on a record."""
    return str(record.attributes.get(ATTR_PATH, SEED_TRANSFORMATION))


def propose_record(
    *,
    parent: RealizationRecord,
    definition: GeneratorDefinition,
    transformation: str,
    signature: Signature,
    attributes: Optional[Mapping[str, Any]] = None,
    witness: Optional[str] = None,
    evidence_class: str = EvidenceClass.CONSTRUCTIVE,
) -> RealizationRecord:
    """Build a child record with derived identity and full provenance.

    Generator authors should use this rather than constructing a
    :class:`~crg_model.records.RealizationRecord` directly: it stamps the
    transformation, the generator definition hash, the derivation path, and
    the depth onto the record, and it derives the identity from content.

    The child's legality is left ``UNEVALUATED``.  A generator proposes; only
    :func:`crg_generate.legality.evaluate_legality` decides, and a generator
    that pre-labelled its own output ``LEGAL`` would be certifying itself.
    """
    if transformation not in definition.transformations:
        raise GeneratorError(
            f"generator {definition.qualified_id} emitted undeclared transformation "
            f"{transformation!r}; declared transformations are "
            f"{sorted(definition.transformations)} (spec 28.4)"
        )
    body: Dict[str, Any] = dict(attributes or {})
    body[ATTR_TRANSFORMATION] = transformation
    body[ATTR_GENERATOR_HASH] = definition.definition_hash()
    body[ATTR_PATH] = f"{record_path(parent)}>{transformation}"
    body[ATTR_DEPTH] = record_depth(parent) + 1
    identifier = derive_realization_id(
        parent_id=parent.realization_id,
        generator=definition.qualified_id,
        transformation=transformation,
        signature=signature,
        attributes=body,
    )
    return RealizationRecord(
        realization_id=identifier,
        signature=signature,
        attributes=body,
        legality=LegalityStatus.UNEVALUATED,
        witness=witness
        if witness is not None
        else f"{definition.witness_method}:{definition.qualified_id}:{transformation}",
        parent=parent.realization_id,
        generator=definition.qualified_id,
        evidence_class=evidence_class,
    )


def seed_record(
    *,
    source_id: str,
    signature: Signature,
    attributes: Optional[Mapping[str, Any]] = None,
    evidence_class: str = EvidenceClass.IMPORTED,
    realization_id: Optional[str] = None,
) -> RealizationRecord:
    """Build a seed record: received, not produced (spec 28.5).

    A seed carries no generator and no parent.  Its identity may be supplied
    by the source -- an imported registry has its own identifiers and they must
    survive (37.3) -- and is otherwise derived from content like any other.
    """
    body: Dict[str, Any] = dict(attributes or {})
    body[ATTR_TRANSFORMATION] = SEED_TRANSFORMATION
    body[ATTR_PATH] = SEED_TRANSFORMATION
    body[ATTR_DEPTH] = 0
    identifier = realization_id or derive_realization_id(
        parent_id=None,
        generator=source_id,
        transformation=SEED_TRANSFORMATION,
        signature=signature,
        attributes=body,
        prefix="seed",
    )
    return RealizationRecord(
        realization_id=identifier,
        signature=signature,
        attributes=body,
        legality=LegalityStatus.UNEVALUATED,
        witness=None,
        parent=None,
        generator=None,
        evidence_class=evidence_class,
    )


def as_seed(record: RealizationRecord) -> RealizationRecord:
    """Stamp closure bookkeeping onto a caller-supplied seed record."""
    attributes = dict(record.attributes)
    attributes.setdefault(ATTR_TRANSFORMATION, SEED_TRANSFORMATION)
    attributes.setdefault(ATTR_PATH, SEED_TRANSFORMATION)
    attributes.setdefault(ATTR_DEPTH, 0)
    return replace(record, attributes=attributes)
