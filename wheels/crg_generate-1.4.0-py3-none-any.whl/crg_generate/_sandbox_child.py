"""The confined child process: the only place untrusted plugin code runs.

Normative basis: master specification 36.3 (plugin isolation), read against
6.6 (fail closed) and 36.2 (the declared permission list).

This module is deliberately **standalone**.  It imports nothing from
``crg_generate`` and nothing outside the Python standard library, because it is
executed as a script by :mod:`crg_generate.sandbox` in a fresh interpreter that
has no CRG package on its path.  Every canonicalization and every content hash
in the invocation log is computed by the *host* from what this child returns;
the child's job is narrower and more dangerous, and keeping the two jobs in two
processes is the entire point of 36.3.

The order of operations in :func:`main` is the security argument, so it is
stated once here and then obeyed literally:

1. read the request (the host writes it to this process's stdin);
2. pre-import every module on the declared allow-list, so that later
   allow-listed imports resolve out of :data:`sys.modules` without the import
   machinery needing private names the gate would have to refuse;
3. install the filesystem, network, and process-creation gates by rebinding the
   standard-library entry points a plugin would reach for;
4. apply :func:`resource.setrlimit` quotas and the ``SIGXCPU``/``SIGXFSZ``
   handlers that turn a quota breach into a typed report rather than a
   signal-death;
5. seal ``builtins.__import__`` against everything not on the allow-list; and
6. only then ``exec`` the plugin source and call its declared entry point.

Nothing in steps 1--5 runs plugin code, so a plugin cannot observe or interfere
with its own confinement being installed.

**What this is, honestly.**  This is a same-user subprocess with rebound Python
entry points.  It is not a container and it is not a jail:

* there is no seccomp filter, no namespace, and no capability drop, so native
  code -- ``ctypes``, a third-party C extension, anything that reaches a raw
  syscall -- bypasses every gate below.  The import allow-list is what keeps
  ``ctypes`` out of reach, and an import allow-list is a *policy* gate, not a
  kernel one;
* the child runs as the same uid as the host, so on a stock Linux it can read
  much of ``/proc``, and unless ``ptrace_scope`` is restricted it can attach to
  sibling processes of the same uid;
* :data:`sys.modules` still holds the real modules whose attributes were
  rebound.  Each gate therefore rebinds the *module attribute* as well as
  refusing the import, but a plugin holding a pre-existing reference (a default
  argument captured before sealing, a frame walk, ``object.__subclasses__``)
  can still reach the original object.  This is a real limit and it is not
  closed here;
* the reply is written to an inherited file descriptor.  A plugin that
  enumerates its own descriptors can write to that descriptor too, so a
  determined plugin can corrupt its own reply.  The host treats an unparseable
  reply as :data:`FailureCategory.MALFORMED_CHILD_OUTPUT` and fails closed,
  which bounds the damage to *this plugin's* invocation; and
* the path allow-list is checked with :func:`os.path.realpath` and then the
  real call is made, so a symlink swapped in between the two wins the race.
  Closing that hole needs ``openat``-relative resolution the Python level does
  not offer.

What *is* enforced by the operating system rather than by convention is the
process boundary itself, the ``resource`` limits, the scrubbed environment, and
the working directory.  Everything else on this list is best-effort
defence-in-depth, and the module docstring of :mod:`crg_generate.sandbox` says
so in the same words.
"""
from __future__ import annotations

import builtins
import errno
import json
import os
import signal
import sys
import traceback
from typing import Any, Dict, List, Optional, Sequence, Tuple

# Bound at module import, which happens long before the import gate is sealed.
# The child needs ``resource`` to apply its own quotas and to report its own
# usage, and it needs ``platform`` for the environment manifest of 36.3.  A
# plugin may not import either of them (see :data:`NEVER_IMPORTABLE`); holding
# the module objects here is how the child keeps a capability it denies its
# guest.
try:
    import resource as _resource
except ImportError:  # pragma: no cover - no POSIX resource module on this platform
    _resource = None  # type: ignore[assignment]
import platform as _platform

#: Wire-protocol identity.  The host refuses a reply that does not carry it,
#: because a reply from an unknown protocol is an unparseable reply (6.6).
PROTOCOL_VERSION = "crg-sandbox/1"

#: Environment variable naming the inherited descriptor the reply is written
#: to.  It is removed from ``os.environ`` before plugin code runs, which is
#: tidiness rather than protection (see the module docstring).
RESULT_FD_ENV = "CRG_SANDBOX_RESULT_FD"

#: OCI containers cannot inherit a host descriptor through the runtime daemon.
#: The production image therefore receives one pre-created bind-mounted file
#: at this fixed path.  No caller-selected path is accepted: allowing the host
#: to point this variable elsewhere would turn the reply channel into a write
#: capability inside the otherwise read-only container.
RESULT_PATH_ENV = "CRG_SANDBOX_RESULT_PATH"
OCI_RESULT_PATH = "/crg-output/reply.json"


class FailureCategory:
    """Every way a sandboxed invocation can end, as a closed vocabulary.

    Specification 6.6 requires that none of these produce affirmative
    certification, and a category is what lets a host *distinguish* them: a
    plugin that ran out of CPU and a plugin whose package signature did not
    verify are both failures, but they are not the same failure and a log that
    collapses them has lost the finding.

    The vocabulary lives in the child rather than in the host because the child
    observes most of these first-hand, and one definition read by both sides is
    one definition that cannot drift.
    """

    OK = "OK"

    # -- refused before any plugin code ran --
    SIGNATURE_ABSENT = "SIGNATURE_ABSENT"
    SIGNATURE_INVALID = "SIGNATURE_INVALID"
    SIGNATURE_PROFILE_UNKNOWN = "SIGNATURE_PROFILE_UNKNOWN"
    UNKNOWN_SIGNING_KEY = "UNKNOWN_SIGNING_KEY"
    UNKNOWN_PERMISSION = "UNKNOWN_PERMISSION"
    PERMISSION_NOT_DECLARED = "PERMISSION_NOT_DECLARED"
    POLICY_ERROR = "POLICY_ERROR"

    # -- refused while the plugin ran (36.3 restricted filesystem and network) --
    FILESYSTEM_VIOLATION = "FILESYSTEM_VIOLATION"
    NETWORK_VIOLATION = "NETWORK_VIOLATION"
    SUBPROCESS_VIOLATION = "SUBPROCESS_VIOLATION"
    SECRET_VIOLATION = "SECRET_VIOLATION"
    MODULE_NOT_ALLOWED = "MODULE_NOT_ALLOWED"

    # -- quotas (36.3 resource quotas) --
    CPU_QUOTA_EXCEEDED = "CPU_QUOTA_EXCEEDED"
    MEMORY_QUOTA_EXCEEDED = "MEMORY_QUOTA_EXCEEDED"
    FILESIZE_QUOTA_EXCEEDED = "FILESIZE_QUOTA_EXCEEDED"
    PROCESS_QUOTA_EXCEEDED = "PROCESS_QUOTA_EXCEEDED"
    WALL_CLOCK_TIMEOUT = "WALL_CLOCK_TIMEOUT"

    # -- the plugin itself, or the channel to it, failed --
    PLUGIN_ERROR = "PLUGIN_ERROR"
    CHILD_CRASHED = "CHILD_CRASHED"
    MALFORMED_CHILD_OUTPUT = "MALFORMED_CHILD_OUTPUT"
    NONDETERMINISTIC_OUTPUT = "NONDETERMINISTIC_OUTPUT"
    ENVIRONMENT_MISMATCH = "ENVIRONMENT_MISMATCH"
    HOST_ERROR = "HOST_ERROR"

    ALL = frozenset(
        {
            OK,
            SIGNATURE_ABSENT,
            SIGNATURE_INVALID,
            SIGNATURE_PROFILE_UNKNOWN,
            UNKNOWN_SIGNING_KEY,
            UNKNOWN_PERMISSION,
            PERMISSION_NOT_DECLARED,
            POLICY_ERROR,
            FILESYSTEM_VIOLATION,
            NETWORK_VIOLATION,
            SUBPROCESS_VIOLATION,
            SECRET_VIOLATION,
            MODULE_NOT_ALLOWED,
            CPU_QUOTA_EXCEEDED,
            MEMORY_QUOTA_EXCEEDED,
            FILESIZE_QUOTA_EXCEEDED,
            PROCESS_QUOTA_EXCEEDED,
            WALL_CLOCK_TIMEOUT,
            PLUGIN_ERROR,
            CHILD_CRASHED,
            MALFORMED_CHILD_OUTPUT,
            NONDETERMINISTIC_OUTPUT,
            ENVIRONMENT_MISMATCH,
            HOST_ERROR,
        }
    )

    #: Categories that mean *the plugin never got to run*.  A test asserting
    #: that a side effect did not happen asserts against this set, and so does
    #: a host deciding whether a retry could possibly help.
    REFUSED_BEFORE_EXECUTION = frozenset(
        {
            SIGNATURE_ABSENT,
            SIGNATURE_INVALID,
            SIGNATURE_PROFILE_UNKNOWN,
            UNKNOWN_SIGNING_KEY,
            UNKNOWN_PERMISSION,
            PERMISSION_NOT_DECLARED,
        }
    )


#: Modules whose import is a network request in disguise.  Refusing them by
#: name is how the ``NETWORK`` permission of 36.2 becomes a decision rather
#: than a hope.
NETWORK_MODULES = frozenset(
    {
        "socket",
        "_socket",
        "ssl",
        "_ssl",
        "select",
        "selectors",
        "asyncio",
        "http",
        "urllib",
        "ftplib",
        "smtplib",
        "poplib",
        "imaplib",
        "telnetlib",
        "xmlrpc",
        "socketserver",
        "webbrowser",
    }
)

#: Modules that turn one process into two.  ``SUBPROCESS`` gates all of them.
PROCESS_MODULES = frozenset(
    {
        "subprocess",
        "_posixsubprocess",
        "multiprocessing",
        "concurrent",
        "pty",
        "tty",
    }
)

#: Modules that reach past the interpreter into raw memory or raw syscalls, or
#: that hand back the machinery the gates are built from.  They are refused
#: even when a caller puts one on the allow-list: a policy that allows
#: ``ctypes`` is not a stricter policy with one exception, it is no policy,
#: because ``ctypes`` reaches every gate in this module and unbinds it.
NEVER_IMPORTABLE = frozenset(
    {
        "ctypes",
        "_ctypes",
        "mmap",
        "signal",
        "resource",
        "gc",
        "importlib",
        "imp",
        "runpy",
        "pdb",
        "bdb",
        "inspect",
        "sysconfig",
        "site",
        "shutil",
        "tempfile",
        "pickle",
        "shelve",
        "marshal",
        "code",
        "codeop",
        "compileall",
        "py_compile",
        "atexit",
        "threading",
        "_thread",
        "faulthandler",
        "tracemalloc",
        "builtins",
    }
)

#: The default declared module allow-list: enough to compute exactly, and
#: nothing that reaches the world.  ``fractions`` and ``decimal`` are on it on
#: purpose -- a plugin proposing a signature coordinate must be able to compute
#: an exact rational, because 14.2 refuses binary floating point at the
#: canonical boundary and both this child and the host enforce that refusal.
DEFAULT_MODULE_ALLOW_LIST: Tuple[str, ...] = (
    "abc",
    "array",
    "base64",
    "binascii",
    "bisect",
    "calendar",
    "cmath",
    "collections",
    "copy",
    "csv",
    "dataclasses",
    "datetime",
    "decimal",
    "difflib",
    "enum",
    "fnmatch",
    "fractions",
    "functools",
    "genericpath",
    "hashlib",
    "heapq",
    "hmac",
    "io",
    "itertools",
    "json",
    "keyword",
    "math",
    "ntpath",
    "numbers",
    "operator",
    "os",
    "pathlib",
    "posixpath",
    "pprint",
    "random",
    "re",
    "reprlib",
    "statistics",
    "string",
    "struct",
    "textwrap",
    "time",
    "types",
    "typing",
    "unicodedata",
    "warnings",
    "weakref",
    "zlib",
)


class SandboxViolationError(BaseException):
    """A refused action, raised at the point of refusal.

    It derives from :class:`BaseException` rather than :class:`Exception` so
    that a plugin's ``except Exception`` cannot swallow its own confinement.
    That is defence in depth rather than the mechanism: the refusal is recorded
    in :data:`_LEDGER` *before* it is raised, and :func:`main` reports a
    non-empty ledger as a failure whatever the plugin did with the exception.
    A plugin that catches this and returns a plausible answer still fails
    closed, and its answer is discarded (6.6).
    """

    def __init__(self, category: str, detail: str, target: str = "") -> None:
        super().__init__(detail)
        self.category = category
        self.detail = detail
        self.target = target


class _CpuQuotaExceeded(BaseException):
    """Raised from the ``SIGXCPU`` handler; see :func:`_install_quota_signals`."""


class _FileSizeQuotaExceeded(BaseException):
    """Raised from the ``SIGXFSZ`` handler; see :func:`_install_quota_signals`."""


#: Every refusal observed in this process, in the order observed.  The ledger
#: is the record of what the plugin *attempted*, which 36.3's "complete
#: invocation logs" needs and which a caught-and-discarded exception would lose.
_LEDGER: List[Dict[str, str]] = []

#: Allow-listed modules that this interpreter could not supply.  Reported in
#: the environment manifest rather than as a refusal, because the fact belongs
#: to the environment and not to the plugin.
_UNAVAILABLE_MODULES: Dict[str, str] = {}


def _violate(category: str, detail: str, target: str = "") -> SandboxViolationError:
    """Record a refusal and build the exception that carries it."""
    _LEDGER.append({"category": category, "detail": detail, "target": target})
    return SandboxViolationError(category, detail, target)


# ---------------------------------------------------------------------------
# filesystem gate (spec 36.3 "restricted filesystem access")
# ---------------------------------------------------------------------------

_READABLE: Tuple[str, ...] = ()
_WRITABLE: Tuple[str, ...] = ()

#: Flags that make an :func:`os.open` a write, whatever the caller believes it
#: is doing.  ``O_CREAT`` is included because creating an empty file outside
#: the allow-list is already an escape.
_WRITE_FLAGS = 0
for _flag_name in ("O_WRONLY", "O_RDWR", "O_CREAT", "O_TRUNC", "O_APPEND", "O_EXCL"):
    _WRITE_FLAGS |= getattr(os, _flag_name, 0)


def _resolve(path: Any) -> str:
    """Resolve to an absolute real path, following symlinks.

    Symlink resolution is not optional: an allow-list checked against the
    *given* path would be defeated by a symlink inside the scratch directory
    pointing at ``/etc``.
    """
    if isinstance(path, int):
        # A bare descriptor: the allow-list has nothing to check, so it refuses.
        raise _violate(
            FailureCategory.FILESYSTEM_VIOLATION,
            "a file descriptor was supplied where the sandbox requires a path; an "
            "allow-list cannot be checked against a descriptor (spec 36.3)",
            target=str(path),
        )
    return os.path.realpath(os.fsdecode(os.fspath(path)))


def _within(resolved: str, roots: Sequence[str]) -> bool:
    for root in roots:
        if resolved == root or resolved.startswith(root + os.sep):
            return True
    return False


def _check_path(path: Any, *, write: bool, operation: str) -> Any:
    """Refuse ``path`` unless the declared allow-list covers it.

    A writable root is implicitly readable; a readable root is not implicitly
    writable.  That asymmetry is the whole content of the permission pair
    ``FILESYSTEM_READ``/``FILESYSTEM_WRITE`` in 36.2.
    """
    resolved = _resolve(path)
    roots = _WRITABLE if write else tuple(sorted(set(_READABLE) | set(_WRITABLE)))
    if not _within(resolved, roots):
        kind = "writable" if write else "readable"
        raise _violate(
            FailureCategory.FILESYSTEM_VIOLATION,
            f"{operation} refused: {resolved!r} is outside the declared {kind} "
            f"allow-list {list(roots)!r}; a plugin reaches only the paths its policy "
            "declared (spec 36.2, 36.3)",
            target=resolved,
        )
    return path


def _mode_is_write(mode: Any) -> bool:
    text = str(mode)
    return any(character in text for character in ("w", "a", "x", "+"))


def _read_guard(name: str, original: Any) -> Any:
    def guarded(path=".", *args, **kwargs):  # type: ignore[no-untyped-def]
        _check_path(path, write=False, operation=f"os.{name}")
        return original(path, *args, **kwargs)

    return guarded


def _write_guard(name: str, original: Any) -> Any:
    def guarded(path, *args, **kwargs):  # type: ignore[no-untyped-def]
        _check_path(path, write=True, operation=f"os.{name}")
        return original(path, *args, **kwargs)

    return guarded


def _two_path_write_guard(name: str, original: Any) -> Any:
    def guarded(first, second, *args, **kwargs):  # type: ignore[no-untyped-def]
        # Both ends are checked as writes.  For ``symlink`` that is stricter
        # than the syscall requires and deliberately so: a link whose target is
        # outside the allow-list is precisely the escape ``realpath`` exists to
        # defeat.
        _check_path(first, write=True, operation=f"os.{name}")
        _check_path(second, write=True, operation=f"os.{name}")
        return original(first, second, *args, **kwargs)

    return guarded


def _install_filesystem_gate(readable: Sequence[str], writable: Sequence[str]) -> None:
    """Rebind every path-taking entry point a plugin is likely to reach.

    The list is long and it is still not exhaustive; ``os`` grows entry points,
    and the import machinery opens files through ``_io`` directly, below this
    layer.  The honest claim is: a plugin that opens a path with the ordinary
    Python vocabulary is confined, and a plugin that goes around that
    vocabulary is not.  The module allow-list is what keeps the ways around it
    out of reach.
    """
    global _READABLE, _WRITABLE
    _READABLE = tuple(sorted({os.path.realpath(p) for p in readable}))
    _WRITABLE = tuple(sorted({os.path.realpath(p) for p in writable}))

    import io

    real_open = builtins.open

    def guarded_open(file, mode="r", *args, **kwargs):  # type: ignore[no-untyped-def]
        _check_path(file, write=_mode_is_write(mode), operation=f"open(mode={mode!r})")
        return real_open(file, mode, *args, **kwargs)

    builtins.open = guarded_open
    io.open = guarded_open

    real_os_open = os.open

    def guarded_os_open(path, flags, *args, **kwargs):  # type: ignore[no-untyped-def]
        _check_path(path, write=bool(flags & _WRITE_FLAGS), operation="os.open")
        return real_os_open(path, flags, *args, **kwargs)

    os.__dict__["open"] = guarded_os_open

    # ``stat``, ``lstat``, and ``readlink`` are deliberately *not* gated.
    # ``os.path.realpath`` -- the resolver every check above depends on -- is
    # built out of them, so gating them would make :func:`_check_path` call
    # itself.  Gating them beneath the resolver would mean reimplementing
    # symlink resolution inside the sandbox, and the trade is not worth it:
    # metadata is not content, and a plugin that can learn a file's size but
    # not read it has learned very little.  This is a stated limit, not an
    # oversight.
    for name in ("listdir", "scandir"):
        original = getattr(os, name, None)
        if original is not None:
            os.__dict__[name] = _read_guard(name, original)

    for name in (
        "remove",
        "unlink",
        "rmdir",
        "mkdir",
        "makedirs",
        "removedirs",
        "chmod",
        "chown",
        "truncate",
        "utime",
        "mkfifo",
    ):
        original = getattr(os, name, None)
        if original is not None:
            os.__dict__[name] = _write_guard(name, original)

    for name in ("rename", "replace", "link", "symlink"):
        original = getattr(os, name, None)
        if original is not None:
            os.__dict__[name] = _two_path_write_guard(name, original)

    _repoint_pathlib()


def _repoint_pathlib() -> None:
    """Re-point :mod:`pathlib`'s captured accessor at the gated entry points.

    This is the "pre-existing reference" hazard from the module docstring,
    caught in the act.  On Python 3.10 ``pathlib`` binds ``io.open``,
    ``os.listdir``, and friends onto ``_NormalAccessor`` *at import time*, so
    rebinding ``io.open`` afterwards leaves ``Path.read_text`` running the
    original -- and a plugin that says ``pathlib.Path('/etc/passwd')
    .read_text()`` walks straight past the gate.  Later versions call the
    module attributes at call time and need nothing here, so the whole function
    is conditional on the accessor existing.

    ``staticmethod`` is not decoration: ``io.open`` is a builtin and does not
    bind as a method, while the guarded replacement is an ordinary Python
    function and would receive the accessor instance as its first argument.

    The general lesson is the one the docstring states: rebinding module
    attributes is defence in depth, not a boundary, and every library that
    captured a reference before the gate went up is a hole that has to be
    found and named individually.
    """
    pathlib_module = sys.modules.get("pathlib")
    accessor = getattr(pathlib_module, "_NormalAccessor", None)
    if accessor is None:
        return
    import io

    for name in list(vars(accessor)):
        if name.startswith("_"):
            continue
        if name == "open":
            setattr(accessor, name, staticmethod(io.open))
        elif hasattr(os, name):
            setattr(accessor, name, staticmethod(getattr(os, name)))


# ---------------------------------------------------------------------------
# network gate (spec 36.3 "restricted network access")
# ---------------------------------------------------------------------------


def _install_network_gate() -> None:
    """Make socket creation raise, in every module that offers one.

    Both ``socket`` and its accelerator ``_socket`` are rebound, because
    ``socket.socket`` is a thin wrapper over ``_socket.socket`` and a plugin
    reaching the accelerator directly would otherwise be unconfined.  This runs
    before any plugin code, so a plugin cannot capture the originals.
    """
    import socket as socket_module
    import _socket as raw_socket_module

    def refuse(*_args: Any, **_kwargs: Any) -> Any:
        raise _violate(
            FailureCategory.NETWORK_VIOLATION,
            "network access refused: the policy does not grant the NETWORK "
            "permission, so no socket may be created (spec 36.2, 36.3)",
        )

    for module in (socket_module, raw_socket_module):
        for name in (
            "socket",
            "socketpair",
            "create_connection",
            "create_server",
            "getaddrinfo",
            "gethostbyname",
            "gethostbyname_ex",
            "gethostbyaddr",
            "dup",
            "fromfd",
        ):
            if hasattr(module, name):
                module.__dict__[name] = refuse


# ---------------------------------------------------------------------------
# process-creation gate (spec 36.2 SUBPROCESS)
# ---------------------------------------------------------------------------


def _install_process_gate() -> None:
    """Refuse every way of turning one process into two.

    A fork bomb is the cheapest denial of service a plugin can mount, and
    ``RLIMIT_NPROC`` alone does not *refuse* it -- it merely makes it fail
    eventually, once the uid's process table is full, and it is silently
    ineffective for a privileged uid.  Refusing at the Python entry point makes
    the refusal reportable, which is what 36.3's invocation log needs;
    ``RLIMIT_NPROC`` stays underneath as the backstop for a fork this layer did
    not name.

    ``os.kill`` and ``os.killpg`` are refused here too.  They create no
    process, but the child runs as the same uid as its host, so they are the
    shortest path from "untrusted plugin" to "the host is gone".
    """

    def refuse(*_args: Any, **_kwargs: Any) -> Any:
        raise _violate(
            FailureCategory.SUBPROCESS_VIOLATION,
            "process control refused: the policy does not grant the SUBPROCESS "
            "permission (spec 36.2, 36.3)",
        )

    for name in (
        "fork",
        "forkpty",
        "posix_spawn",
        "posix_spawnp",
        "system",
        "popen",
        "execv",
        "execve",
        "execvp",
        "execvpe",
        "execl",
        "execle",
        "execlp",
        "spawnv",
        "spawnve",
        "spawnl",
        "spawnle",
        "kill",
        "killpg",
    ):
        if hasattr(os, name):
            os.__dict__[name] = refuse


# ---------------------------------------------------------------------------
# resource quotas (spec 36.3 "resource quotas")
# ---------------------------------------------------------------------------


def _apply_rlimits(spec: Dict[str, int]) -> Dict[str, Any]:
    """Apply the declared limits and report exactly what the platform did.

    Every entry of the returned mapping is one of three honest outcomes:
    ``APPLIED`` with the soft and hard values now in force, ``UNAVAILABLE``
    when the platform has no such limit, or ``REFUSED`` with the operating
    system's reason.  Nothing is silently dropped: a quota the platform would
    not accept is a quota the host must know it does not have, and 6.6 makes
    the difference between "limited" and "we asked" a difference that must
    survive into the log.

    ``RLIMIT_AS`` is the limit that behaves differently across the platforms
    this repository is developed and tested on.  On Linux it bounds the address
    space, and an over-large allocation raises :class:`MemoryError` inside the
    child, which this module reports as :data:`FailureCategory.
    MEMORY_QUOTA_EXCEEDED`.  On macOS the limit is accepted but its effect on a
    64-bit process is weaker and less predictable; a macOS host may therefore
    see a memory hog terminated by the wall-clock timeout instead.  Both
    outcomes are typed failures, both keep the host alive, and the difference
    is recorded here rather than papered over.
    """
    applied: Dict[str, Any] = {}
    if _resource is None:  # pragma: no cover - POSIX-only repository
        return {
            name: {
                "status": "UNAVAILABLE",
                "requested": int(value),
                "detail": "this interpreter has no 'resource' module, so no quota of "
                "specification 36.3 can be applied; the host-side wall-clock "
                "timeout is the only bound in force",
            }
            for name, value in sorted(spec.items())
        }
    for name in sorted(spec):
        requested = int(spec[name])
        constant = getattr(_resource, name, None)
        if constant is None:
            applied[name] = {
                "status": "UNAVAILABLE",
                "requested": requested,
                "detail": f"{name} does not exist on {sys.platform}",
            }
            continue
        try:
            current_soft, current_hard = _resource.getrlimit(constant)
        except (ValueError, OSError) as exc:
            applied[name] = {
                "status": "REFUSED",
                "requested": requested,
                "detail": f"getrlimit failed: {type(exc).__name__}: {exc}",
            }
            continue

        # CPU gets one second of grace between the soft limit (``SIGXCPU``,
        # which this child turns into a typed report) and the hard limit
        # (``SIGKILL``, which it cannot).  Everything else is set soft and hard
        # alike.  The hard limit is only ever lowered: raising it is not
        # permitted to an unprivileged process, and lowering it is irreversible.
        if name == "RLIMIT_CPU":
            soft, hard = requested, requested + 1
        else:
            soft = hard = requested
        if current_hard != _resource.RLIM_INFINITY:
            soft = min(soft, current_hard)
            hard = min(hard, current_hard)
        try:
            _resource.setrlimit(constant, (soft, hard))
        except (ValueError, OSError) as exc:
            applied[name] = {
                "status": "REFUSED",
                "requested": requested,
                "detail": f"setrlimit failed: {type(exc).__name__}: {exc}",
            }
            continue
        applied[name] = {
            "status": "APPLIED",
            "requested": requested,
            "soft": soft,
            "hard": hard,
        }
    return applied


def _install_quota_signals() -> None:
    """Turn the two quota signals into typed Python exceptions.

    Without a handler, ``SIGXCPU`` and ``SIGXFSZ`` terminate the process and
    the host can only infer what happened from an exit status.  With one, the
    child gets to write a complete invocation record naming the quota it broke
    -- the difference between a log entry reading ``CHILD_CRASHED`` and one
    reading ``CPU_QUOTA_EXCEEDED``.  The hard limit set by
    :func:`_apply_rlimits` remains as the backstop for a plugin that contrives
    to ignore the exception.
    """
    for signal_name, handler in (("SIGXCPU", _on_cpu), ("SIGXFSZ", _on_fsize)):
        number = getattr(signal, signal_name, None)
        if number is None:  # pragma: no cover - platform dependent
            continue
        try:
            signal.signal(number, handler)
        except (ValueError, OSError) as exc:  # pragma: no cover - platform dependent
            _LEDGER.append(
                {
                    "category": FailureCategory.POLICY_ERROR,
                    "detail": f"could not install a handler for {signal_name}: "
                    f"{type(exc).__name__}: {exc}; a breach of that quota will appear "
                    "as a signal death rather than as a typed report",
                    "target": signal_name,
                }
            )


#: Kernel error numbers that are a quota breach reported as an error return
#: rather than as a signal.  Without this mapping a plugin that hits
#: ``RLIMIT_FSIZE`` inside a buffered write, or ``RLIMIT_NPROC`` inside a fork
#: the process gate did not name, would be logged as a generic plugin error and
#: the host would never learn that its own quota was the cause.
_QUOTA_ERRNOS: Dict[int, str] = {
    errno.EFBIG: FailureCategory.FILESIZE_QUOTA_EXCEEDED,
    errno.ENOMEM: FailureCategory.MEMORY_QUOTA_EXCEEDED,
    errno.EAGAIN: FailureCategory.PROCESS_QUOTA_EXCEEDED,
}


def _category_for_os_error(exc: OSError) -> str:
    """Name the quota an :class:`OSError` from a plugin actually reports."""
    return _QUOTA_ERRNOS.get(exc.errno or 0, FailureCategory.PLUGIN_ERROR)


def _on_cpu(_signum: int, _frame: Any) -> None:
    _LEDGER.append(
        {
            "category": FailureCategory.CPU_QUOTA_EXCEEDED,
            "detail": "SIGXCPU: the declared RLIMIT_CPU quota was exhausted "
            "(spec 36.3 resource quotas)",
            "target": "RLIMIT_CPU",
        }
    )
    raise _CpuQuotaExceeded()


def _on_fsize(_signum: int, _frame: Any) -> None:
    _LEDGER.append(
        {
            "category": FailureCategory.FILESIZE_QUOTA_EXCEEDED,
            "detail": "SIGXFSZ: the declared RLIMIT_FSIZE quota was exhausted "
            "(spec 36.3 resource quotas)",
            "target": "RLIMIT_FSIZE",
        }
    )
    raise _FileSizeQuotaExceeded()


# ---------------------------------------------------------------------------
# import gate (spec 36.3, and the mechanism every other gate rests on)
# ---------------------------------------------------------------------------


def _effective_allow_list(
    allow_list: Sequence[str], network: bool, subprocess_ok: bool
) -> Tuple[str, ...]:
    """The declared allow-list widened by the capabilities actually granted.

    :data:`NETWORK_MODULES` and :data:`PROCESS_MODULES` are refused by name
    when the matching permission is absent, and admitted when it is present.
    The permission is the decision; the module list is how it is expressed.
    """
    allowed = set(allow_list)
    if network:
        allowed |= NETWORK_MODULES
    if subprocess_ok:
        allowed |= PROCESS_MODULES
    return tuple(sorted(allowed - NEVER_IMPORTABLE))


def _preimport(allow_list: Sequence[str]) -> None:
    """Import the allow-list before sealing, and note what did not import.

    Pre-importing is what makes a *top-level* allow-list workable.  ``json``
    imports ``json.decoder`` which imports ``_json``; if the gate saw those
    imports it would have to allow-list private accelerator names, and an
    allow-list nobody can read is an allow-list nobody audits.  After this
    function the allow-listed modules are in :data:`sys.modules`, so a plugin's
    ``import json`` resolves without the machinery asking for anything else.
    """
    for name in sorted(set(allow_list) - NEVER_IMPORTABLE):
        try:
            __import__(name)
        except Exception as exc:  # noqa: BLE001 - the reason is reported, not hidden
            _UNAVAILABLE_MODULES[name] = f"{type(exc).__name__}: {exc}"


def _seal_imports(allow_list: Sequence[str], *, network: bool, subprocess_ok: bool) -> None:
    """Refuse every import outside the declared allow-list.

    The gate gives a *typed* refusal rather than one blanket category, because
    "this plugin tried to import ``socket``" and "this plugin tried to import
    ``csv``" are different findings, and 36.3's invocation log should be able to
    tell a host which one happened.
    """
    allowed = set(allow_list)
    if network:
        allowed |= NETWORK_MODULES
    if subprocess_ok:
        allowed |= PROCESS_MODULES
    allowed -= NEVER_IMPORTABLE
    allowed -= set(_UNAVAILABLE_MODULES)
    real_import = builtins.__import__

    def guarded_import(name, globals=None, locals=None, fromlist=(), level=0):  # type: ignore[no-untyped-def]
        root = str(name).split(".", 1)[0]
        if root in NEVER_IMPORTABLE:
            raise _violate(
                FailureCategory.MODULE_NOT_ALLOWED,
                f"import of {name!r} refused unconditionally: {root!r} reaches past the "
                "interpreter into raw memory, raw syscalls, or the sandbox's own "
                "machinery, and no permission of specification 36.2 grants it",
                target=root,
            )
        if root in allowed:
            return real_import(name, globals, locals, fromlist, level)
        if root in NETWORK_MODULES:
            raise _violate(
                FailureCategory.NETWORK_VIOLATION,
                f"import of {name!r} refused: the policy does not grant NETWORK "
                "(spec 36.2, 36.3)",
                target=root,
            )
        if root in PROCESS_MODULES:
            raise _violate(
                FailureCategory.SUBPROCESS_VIOLATION,
                f"import of {name!r} refused: the policy does not grant SUBPROCESS "
                "(spec 36.2, 36.3)",
                target=root,
            )
        raise _violate(
            FailureCategory.MODULE_NOT_ALLOWED,
            f"import of {name!r} refused: {root!r} is not on the declared module "
            f"allow-list (spec 36.3 reproducible environment manifests -- an "
            "undeclared import is an undeclared dependency)",
            target=root,
        )

    builtins.__import__ = guarded_import


# ---------------------------------------------------------------------------
# environment (spec 36.3 "explicit secret access", "reproducible environment")
# ---------------------------------------------------------------------------

# macOS inserts this non-secret locale hint after ``posix_spawn`` even when
# the parent supplies a fully replaced ``env`` mapping.  It is not inherited
# application state and cannot be prevented by the host.  Remove it before
# plugin bytecode runs; all other undeclared variables remain a violation.
_PLATFORM_INJECTED_ENV = frozenset({"__CF_USER_TEXT_ENCODING"})


def _check_environment(allowed_names: Sequence[str]) -> None:
    """Fail closed if the host handed this child a variable it did not declare.

    The host scrubs the environment; this is the child checking the host's
    work.  A secret that reaches an untrusted plugin because the host forgot to
    scrub it is exactly the failure 36.3's "explicit secret access" bullet
    names, and the plugin has no reason to report it.
    """
    injected = set(os.environ) & _PLATFORM_INJECTED_ENV
    leaked = sorted(set(os.environ) - set(allowed_names) - injected)
    for name in injected:
        os.environ.pop(name, None)
    if leaked:
        _LEDGER.append(
            {
                "category": FailureCategory.SECRET_VIOLATION,
                "detail": "the child environment carries variable(s) the policy never "
                f"declared: {leaked!r}; a secret is passed only when it is declared "
                "(spec 36.3)",
                "target": ",".join(leaked),
            }
        )


def _observed_environment(
    allow_list: Sequence[str], applied_rlimits: Dict[str, Any]
) -> Dict[str, Any]:
    """The environment manifest as this child actually observes it (36.3).

    Only facts that are constant for a given interpreter and policy appear
    here.  No path, no pid, no clock reading: a manifest that changed between
    two runs of one policy would be a manifest of the *run* rather than of the
    environment, and 36.3 asks for the latter.  That is also what makes it
    testable -- two invocations under one policy must produce one manifest
    hash.
    """
    flags = sys.flags
    return {
        "protocol": PROTOCOL_VERSION,
        "python_version": _platform.python_version(),
        "python_implementation": _platform.python_implementation(),
        "platform_system": _platform.system(),
        "platform_machine": _platform.machine(),
        "sys_platform": sys.platform,
        "max_unicode": sys.maxunicode,
        "interpreter_flags": {
            "dont_write_bytecode": int(flags.dont_write_bytecode),
            "hash_randomization": int(flags.hash_randomization),
            "ignore_environment": int(flags.ignore_environment),
            "isolated": int(flags.isolated),
            "no_site": int(flags.no_site),
            "no_user_site": int(flags.no_user_site),
            "optimize": int(flags.optimize),
            "verbose": int(flags.verbose),
        },
        "hash_seed": os.environ.get("PYTHONHASHSEED", "(unset)"),
        "module_allow_list": sorted(allow_list),
        "never_importable": sorted(NEVER_IMPORTABLE),
        "unavailable_modules": dict(sorted(_UNAVAILABLE_MODULES.items())),
        "rlimits": {name: dict(entry) for name, entry in sorted(applied_rlimits.items())},
    }


def _self_rusage() -> Dict[str, Any]:
    """This child's own resource usage, in exact decimal strings.

    ``getrusage`` reports CPU time as a binary float.  Specification 14.2
    refuses binary floating point at the canonical boundary, so the value is
    rendered to the microsecond -- the resolution the operating system actually
    provides -- and carried as a decimal string that
    ``crg_model.numeric.Exact`` parses exactly.  The rounding discards the
    float's trailing bits deliberately: those bits were never measurement, and
    a canonical log must not pretend otherwise.

    ``ru_maxrss`` is bytes on Darwin and kibibytes on Linux.  It is normalized
    to kibibytes here, and the field is named for its unit, because an
    unlabelled resource number that means two things on two platforms is a
    units error waiting to be reported as a finding (spec 8).
    """
    if _resource is None:  # pragma: no cover - POSIX-only repository
        return {"unavailable": "this interpreter has no 'resource' module"}
    usage = _resource.getrusage(_resource.RUSAGE_SELF)
    max_rss = int(usage.ru_maxrss)
    return {
        "user_cpu_seconds": "%.6f" % usage.ru_utime,
        "system_cpu_seconds": "%.6f" % usage.ru_stime,
        "max_rss_kib": max_rss // 1024 if sys.platform == "darwin" else max_rss,
        "voluntary_context_switches": int(usage.ru_nvcsw),
        "involuntary_context_switches": int(usage.ru_nivcsw),
    }


def _rusage_or_reason() -> Dict[str, Any]:
    try:
        return _self_rusage()
    except (OSError, ValueError, AttributeError) as exc:  # pragma: no cover
        return {"unavailable": f"{type(exc).__name__}: {exc}"}


# ---------------------------------------------------------------------------
# output discipline
# ---------------------------------------------------------------------------


def _reject_floats(value: Any, path: str = "$") -> Any:
    """Refuse binary floating point anywhere in a plugin's answer (spec 14.2).

    This runs in the child so that the refusal is attributed to the plugin that
    caused it, at the coordinate that caused it, rather than surfacing in the
    host as an opaque canonicalization error two layers later.
    """
    if isinstance(value, float):
        raise _violate(
            FailureCategory.MALFORMED_CHILD_OUTPUT,
            f"the plugin returned a binary float at {path}; an exact representation "
            "is required (integer, decimal string, or 'n/d'), because binary floating "
            "point is not canonically encodable (spec 14.2, 14.3)",
            target=path,
        )
    if value is None or isinstance(value, (bool, int, str)):
        return value
    if isinstance(value, dict):
        return {str(k): _reject_floats(v, f"{path}.{k}") for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_reject_floats(v, f"{path}[{i}]") for i, v in enumerate(value)]
    raise _violate(
        FailureCategory.MALFORMED_CHILD_OUTPUT,
        f"the plugin returned {type(value).__name__} at {path}, which has no canonical "
        "JSON encoding (spec 14.3)",
        target=path,
    )


def _write_result(fd: int, payload: Dict[str, Any]) -> None:
    """Write the reply to the inherited descriptor, or say why it could not."""
    try:
        data = json.dumps(payload, ensure_ascii=True, sort_keys=True).encode("utf-8")
    except (TypeError, ValueError) as exc:
        data = json.dumps(
            {
                "protocol": PROTOCOL_VERSION,
                "status": "FAILED",
                "failure_category": FailureCategory.MALFORMED_CHILD_OUTPUT,
                "detail": f"the child could not encode its own reply: "
                f"{type(exc).__name__}: {exc}",
                "violations": [],
                "payload": None,
                "environment": {},
                "rlimits": {},
                "rusage": {},
            }
        ).encode("utf-8")
    written = 0
    while written < len(data):
        written += os.write(fd, data[written:])


# ---------------------------------------------------------------------------
# entry point
# ---------------------------------------------------------------------------


def main(argv: Optional[Sequence[str]] = None) -> int:
    """Run one plugin invocation under one policy, and always reply.

    The contract with the host is that this function writes exactly one JSON
    object to the reply descriptor and exits zero, *including* when the plugin
    failed.  An exit without a reply is itself a finding -- the host reports it
    as :data:`FailureCategory.CHILD_CRASHED` -- so the broad ``except
    BaseException`` below is not a swallowed error; it is the last place a
    reason can be attached to a failure before the process disappears.
    """
    del argv  # the request arrives on stdin, not on the command line

    # The script's own directory is on ``sys.path[0]`` because CPython puts it
    # there.  It is the crg_generate package directory, and a plugin has no
    # business importing from it.  The import gate would refuse those names
    # anyway; removing the entry means the refusal never has to be relied on.
    here = os.path.dirname(os.path.abspath(__file__))
    if sys.path and os.path.abspath(sys.path[0]) == here:
        sys.path.pop(0)

    result_fd_text = os.environ.get(RESULT_FD_ENV, "")
    result_path = os.environ.get(RESULT_PATH_ENV, "")
    close_result_fd = False
    if result_fd_text.isdigit() and not result_path:
        result_fd = int(result_fd_text)
    elif not result_fd_text and result_path == OCI_RESULT_PATH:
        try:
            result_fd = os.open(result_path, os.O_WRONLY | os.O_TRUNC)
        except OSError as exc:
            sys.stderr.write(f"crg sandbox child: cannot open OCI reply channel: {exc}\n")
            return 2
        close_result_fd = True
    else:
        sys.stderr.write(
            "crg sandbox child: exactly one valid reply channel is required; the host "
            "did not supply an inherited descriptor or the fixed OCI result path\n"
        )
        return 2

    environment: Dict[str, Any] = {}
    applied_rlimits: Dict[str, Any] = {}
    allow_list: Tuple[str, ...] = ()
    payload: Optional[Any] = None
    category = FailureCategory.OK
    detail = ""

    try:
        request = json.loads(sys.stdin.buffer.read().decode("utf-8"))
        if request.get("protocol") != PROTOCOL_VERSION:
            raise _violate(
                FailureCategory.POLICY_ERROR,
                f"request protocol {request.get('protocol')!r} is not "
                f"{PROTOCOL_VERSION!r}",
            )
        policy = request["policy"]
        allow_list = tuple(policy["module_allow_list"])
        network = bool(policy["network"])
        subprocess_ok = bool(policy["subprocess"])

        # 1. environment discipline: it costs nothing, and it checks the host
        #    before the host's mistakes can matter.
        _check_environment(policy["environment_allow_list"])

        # 2. pre-import, so the allow-list can be a list of top-level names.
        #    The granted capability sets are pre-imported too: a plugin holding
        #    SUBPROCESS whose ``import subprocess`` then pulled in ``signal``
        #    would be refused by the gate for a module it never named, which
        #    would make the permission unusable rather than confined.
        _preimport(_effective_allow_list(allow_list, network, subprocess_ok))

        # 3. gates, installed before any plugin bytecode exists in this process.
        _install_filesystem_gate(policy["readable_paths"], policy["writable_paths"])
        if not network:
            _install_network_gate()
        if not subprocess_ok:
            _install_process_gate()

        # 4. quotas, and the handlers that make a breach reportable.
        _install_quota_signals()
        applied_rlimits = _apply_rlimits(dict(policy["rlimits"]))
        environment = _observed_environment(allow_list, applied_rlimits)

        # 5. seal.  Nothing below this line may import anything new.
        os.environ.pop(RESULT_FD_ENV, None)
        os.environ.pop(RESULT_PATH_ENV, None)
        _seal_imports(allow_list, network=network, subprocess_ok=subprocess_ok)

        # 6. and only now, the plugin.  Its own exceptions are converted here
        #    rather than in the outer handlers, because a ``ValueError`` raised
        #    by a plugin and a ``ValueError`` raised while reading the host's
        #    request are different findings: the first is PLUGIN_ERROR, the
        #    second is POLICY_ERROR, and a log that confuses them sends an
        #    operator to the wrong file.
        module_globals: Dict[str, Any] = {
            "__name__": str(request["module_name"]),
            "__builtins__": builtins,
            "__file__": "<crg-sandboxed-plugin>",
            "__package__": None,
            "__doc__": None,
        }
        source = request["module_source"]
        entry_name = str(request["entry_point"])
        plugin_payload = request["payload"]
        try:
            code = compile(source, "<crg-sandboxed-plugin>", "exec")
            exec(code, module_globals)  # noqa: S102 - running this is the point of the module
            entry = module_globals.get(entry_name)
            if not callable(entry):
                raise _violate(
                    FailureCategory.PLUGIN_ERROR,
                    f"the package declares entry point {entry_name!r}, but the module "
                    "source defines no callable of that name (spec 36.2 input and output "
                    "schemas)",
                    target=entry_name,
                )
            payload = _reject_floats(entry(plugin_payload))
        except (SandboxViolationError, _CpuQuotaExceeded, _FileSizeQuotaExceeded, MemoryError):
            raise
        except OSError as exc:
            raise _violate(
                _category_for_os_error(exc),
                "".join(traceback.format_exception_only(type(exc), exc)).strip(),
                target=entry_name,
            ) from exc
        except BaseException as exc:  # noqa: BLE001 - reported with its type, never hidden
            raise _violate(
                FailureCategory.PLUGIN_ERROR,
                "".join(traceback.format_exception_only(type(exc), exc)).strip(),
                target=entry_name,
            ) from exc
        if not isinstance(payload, dict):
            raise _violate(
                FailureCategory.MALFORMED_CHILD_OUTPUT,
                f"the entry point returned {type(payload).__name__}; the declared output "
                "schema is a JSON object (spec 36.2)",
            )
    except SandboxViolationError as violation:
        category, detail, payload = violation.category, violation.detail, None
    except _CpuQuotaExceeded:
        category = FailureCategory.CPU_QUOTA_EXCEEDED
        detail = "the plugin exhausted its declared RLIMIT_CPU quota (spec 36.3)"
        payload = None
    except _FileSizeQuotaExceeded:
        category = FailureCategory.FILESIZE_QUOTA_EXCEEDED
        detail = "the plugin exhausted its declared RLIMIT_FSIZE quota (spec 36.3)"
        payload = None
    except MemoryError:
        category = FailureCategory.MEMORY_QUOTA_EXCEEDED
        detail = (
            "the plugin exhausted its declared RLIMIT_AS quota; the allocation failed "
            "inside the child rather than on the host (spec 36.3)"
        )
        payload = None
        _LEDGER.append({"category": category, "detail": detail, "target": "RLIMIT_AS"})
    except KeyError as exc:
        category = FailureCategory.POLICY_ERROR
        detail = f"the request omitted a required field: {exc}"
        payload = None
    except (ValueError, TypeError, UnicodeDecodeError) as exc:
        category = FailureCategory.POLICY_ERROR
        detail = f"the request could not be read: {type(exc).__name__}: {exc}"
        payload = None
    except BaseException as exc:  # noqa: BLE001 - reported with its type, never hidden
        category = FailureCategory.PLUGIN_ERROR
        detail = "".join(traceback.format_exception_only(type(exc), exc)).strip()
        payload = None
        _LEDGER.append({"category": category, "detail": detail, "target": ""})

    # A ledger entry outranks an apparent success.  A plugin that caught its own
    # refusal and returned a plausible answer must still fail closed, and the
    # answer it returned is discarded rather than reported (6.6).
    if _LEDGER:
        payload = None
        if category == FailureCategory.OK:
            category = _LEDGER[0]["category"]
            detail = (
                _LEDGER[0]["detail"]
                + " -- the plugin suppressed this refusal and returned a value anyway; "
                "the value is discarded"
            )

    _write_result(
        result_fd,
        {
            "protocol": PROTOCOL_VERSION,
            "status": "OK" if category == FailureCategory.OK else "FAILED",
            "failure_category": category,
            "detail": detail,
            "violations": list(_LEDGER),
            "payload": payload,
            "environment": environment,
            "rlimits": applied_rlimits,
            "rusage": _rusage_or_reason(),
        },
    )
    if close_result_fd:
        try:
            os.close(result_fd)
        except OSError:
            return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
