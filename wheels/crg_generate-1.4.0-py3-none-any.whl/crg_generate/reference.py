"""Two reference generators, in two unrelated domains.

Normative basis: master specification section 36.5 (initial reference packs) --
"a generic finite-realization pack" and "a distributed-computation pack" -- read
against section 3.3 (domain neutrality) and section 28.4 (generator contract).

The point of shipping two is falsifiability.  A single reference generator can
always be read as *the* thing the SDK is for; two generators in unrelated
domains, built on the same contract, with no domain vocabulary anywhere in
:mod:`crg_generate.generator`, :mod:`crg_generate.legality`, or
:mod:`crg_generate.registry`, demonstrate the claim of 3.3 rather than assert
it.  Neither generator here is imported by core, and neither knows anything
about the other.

* :class:`FiniteTransformationGenerator` is domain-agnostic: it applies
  declared exact transformation rules -- store-versus-recompute,
  fuse-versus-split, replicate -- to abstract records whose coordinates are
  whatever the caller's schema says they are.  It contains no unit, no
  technology, and no assumption about what the coordinates mean.
* :class:`PlacementGenerator` is a distributed-computation generator: it moves
  tasks between compute nodes and computes an exact makespan and an exact cost
  from a declared model.  There is no semiconductor in it.

Both are exact-rational throughout.  Both are deterministic: rules and rule
applications are iterated in declared order, tasks and nodes in sorted order,
and no dictionary iteration order reaches a signature or an identifier.

Termination is a design obligation, not an accident.  A generator whose
transitive closure is infinite cannot reach a fixpoint, and a family that never
reaches a fixpoint can only ever be ``TRUNCATED_BY_DECLARED_RULE``.  The finite
generator terminates because each rule either flips a declared attribute one
way or advances a bounded counter; the placement generator terminates because a
task may only move to a node *later* in the declared node order, which makes
the move relation a strict partial order.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from crg_model.envelope import EvidenceClass
from crg_model.numeric import Exact
from crg_model.records import CoordinateSchema, RealizationRecord, Signature

from .generator import (
    ATTR_DEPTH,
    ATTR_GENERATOR_HASH,
    ATTR_PATH,
    ATTR_TRANSFORMATION,
    CapabilityGate,
    CompletenessImplication,
    DeterminismStatus,
    FailureSemantics,
    GenerationContext,
    GeneratorDefinition,
    GeneratorError,
    Obligation,
    ObligationType,
    ParentChildRelation,
    SemanticRule,
    WitnessMethod,
    propose_record,
    seed_record,
)
from .legality import LegalityPredicate, LegalityStatus

__all__ = [
    "TransformationRule",
    "FiniteTransformationGenerator",
    "default_finite_rules",
    "finite_transformation_generator",
    "PlacementGenerator",
    "placement_generator",
    "placement_seed",
    "placement_signature",
    "placement_universe_size",
    "encode_placement",
    "decode_placement",
    "nonnegative_signature_predicate",
    "budget_predicate",
    "PLACEMENT_MODEL_KEY",
    "ATTR_PLACEMENT",
    "ATTR_POLICY",
    "ATTR_GRANULARITY",
    "ATTR_REPLICAS",
]

#: Bookkeeping keys the registry owns; a rule never copies them forward.
_RESERVED = frozenset({ATTR_TRANSFORMATION, ATTR_GENERATOR_HASH, ATTR_PATH, ATTR_DEPTH})


# ---------------------------------------------------------------------------
# shared legality predicates (domain-neutral)
# ---------------------------------------------------------------------------


def nonnegative_signature_predicate(
    version: str = "1",
) -> LegalityPredicate:
    """Refuse a signature with a negative coordinate as ``ILLEGAL``.

    Domain-neutral and structural: a transformation that drives a coordinate
    below zero has produced something the declared schema cannot mean, which is
    a fact about the construction, not about resources.  Hence ``ILLEGAL``
    rather than ``INFEASIBLE`` -- the two are different claims and 28.6
    requires them to stay different.
    """

    def evaluate(realization: RealizationRecord, context: Mapping[str, Any]) -> Any:
        for index, value in enumerate(realization.signature.values):
            if value < Exact(0):
                return (
                    LegalityStatus.ILLEGAL,
                    f"coordinate {index} is {value}; a signature coordinate below zero is not "
                    "a point the declared schema can represent (spec 19.1)",
                )
        return True

    return LegalityPredicate(
        predicate_id="crg-generate.nonnegative-signature",
        version=version,
        description="every signature coordinate is nonnegative",
        evaluate=evaluate,
        false_status=LegalityStatus.ILLEGAL,
        evidence_class=EvidenceClass.EXACT,
    )


def budget_predicate(
    coordinate: str,
    *,
    limit_key: str = "budget",
    version: str = "1",
) -> LegalityPredicate:
    """Refuse a candidate exceeding a declared budget as ``INFEASIBLE``.

    The budget lives in the generation context, so the predicate declares
    ``required_context``.  When the context does not carry it the verdict is
    ``UNSUPPORTED``: the predicate applies, the question is open, and the
    answer is unavailable.  It is emphatically not ``INFEASIBLE`` -- refusing
    to answer is not a refusal of the candidate (28.6).
    """

    def evaluate(realization: RealizationRecord, context: Mapping[str, Any]) -> Any:
        budgets = context.get("parameters", {}).get(limit_key, {})
        if coordinate not in budgets:
            return (
                LegalityStatus.UNSUPPORTED,
                f"the declared {limit_key!r} carries no entry for coordinate "
                f"{coordinate!r}; this predicate applies but cannot decide",
            )
        index = _coordinate_index(context, coordinate)
        limit = Exact(budgets[coordinate])
        value = realization.signature[index]
        if value > limit:
            return (
                LegalityStatus.INFEASIBLE,
                f"coordinate {coordinate}={value} exceeds the declared budget {limit}; the "
                "candidate is constructible but not realizable under this context",
            )
        return True

    return LegalityPredicate(
        predicate_id=f"crg-generate.budget.{coordinate}",
        version=version,
        description=f"coordinate {coordinate} is within the declared {limit_key}",
        evaluate=evaluate,
        required_context=("parameters",),
        false_status=LegalityStatus.INFEASIBLE,
        evidence_class=EvidenceClass.EXACT,
    )


def _coordinate_index(context: Mapping[str, Any], identifier: str) -> int:
    schema = context.get("schema", {})
    identifiers = [c["identifier"] for c in schema.get("coordinates", ())]
    if identifier not in identifiers:
        raise GeneratorError(
            f"coordinate {identifier!r} is not in the declared schema {identifiers}"
        )
    return identifiers.index(identifier)


# ---------------------------------------------------------------------------
# (a) generic finite-transformation generator (spec 36.5 pack 1)
# ---------------------------------------------------------------------------

ATTR_POLICY = "policy"
ATTR_GRANULARITY = "granularity"
ATTR_REPLICAS = "replicas"


@dataclass(frozen=True)
class TransformationRule:
    """One declared, exact, terminating transformation.

    ``scale`` and ``offset`` are exact rationals keyed by coordinate
    identifier: the child's coordinate is ``parent * scale + offset``.  No
    binary floating point can enter, because :class:`~crg_model.numeric.Exact`
    refuses it at construction.

    Termination is carried by the rule itself.  Either ``requires``/``sets``
    move a declared attribute from one value to another (so the rule cannot
    fire twice on one path), or ``counter``/``counter_limit`` advance a bounded
    integer.  A rule with neither is refused: it would make the closure
    infinite and every family built from it permanently truncated.
    """

    transformation_id: str
    description: str
    scale: Mapping[str, Exact] = field(default_factory=dict)
    offset: Mapping[str, Exact] = field(default_factory=dict)
    requires: Mapping[str, str] = field(default_factory=dict)
    sets: Mapping[str, str] = field(default_factory=dict)
    counter: Optional[str] = None
    counter_limit: int = 0

    def __post_init__(self) -> None:
        if not self.transformation_id:
            raise GeneratorError("a transformation rule MUST be named (spec 28.4)")
        progresses = bool(self.sets and self.requires) or bool(
            self.counter and self.counter_limit > 0
        )
        if not progresses:
            raise GeneratorError(
                f"transformation rule {self.transformation_id!r} declares no progress "
                "measure: it must either move a declared attribute from a required value to "
                "a different one, or advance a bounded counter. Without one the closure "
                "never reaches a fixpoint and the family can only ever be "
                "TRUNCATED_BY_DECLARED_RULE (spec 21.2, 6.11)"
            )
        for key, value in self.requires.items():
            if self.sets.get(key) == value:
                raise GeneratorError(
                    f"transformation rule {self.transformation_id!r} requires "
                    f"{key}={value!r} and sets it to the same value; the rule would fire "
                    "forever"
                )

    def applies(self, record: RealizationRecord) -> bool:
        for key, value in self.requires.items():
            if str(record.attributes.get(key)) != str(value):
                return False
        if self.counter is not None:
            if _as_int(record.attributes.get(self.counter, 0)) >= self.counter_limit:
                return False
        return True

    def child_attributes(self, record: RealizationRecord) -> Dict[str, Any]:
        attributes = {
            key: value
            for key, value in record.attributes.items()
            if key not in _RESERVED
        }
        attributes.update({key: str(value) for key, value in self.sets.items()})
        if self.counter is not None:
            attributes[self.counter] = _as_int(record.attributes.get(self.counter, 0)) + 1
        return attributes

    def child_signature(
        self, record: RealizationRecord, schema: CoordinateSchema
    ) -> Signature:
        values: List[Exact] = []
        for identifier, value in zip(schema.identifiers, record.signature.values):
            if identifier in self.scale:
                value = value * Exact(self.scale[identifier])
            if identifier in self.offset:
                value = value + Exact(self.offset[identifier])
            values.append(value)
        return Signature(values)

    def to_canonical(self) -> dict:
        return {
            "transformation_id": self.transformation_id,
            "description": self.description,
            "scale": {k: Exact(v).to_canonical() for k, v in sorted(self.scale.items())},
            "offset": {k: Exact(v).to_canonical() for k, v in sorted(self.offset.items())},
            "requires": {k: str(v) for k, v in sorted(self.requires.items())},
            "sets": {k: str(v) for k, v in sorted(self.sets.items())},
            "counter": self.counter,
            "counter_limit": self.counter_limit,
        }


def _as_int(value: Any) -> int:
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, str) and value.strip().lstrip("-").isdigit():
        return int(value.strip())
    raise GeneratorError(
        f"expected an integer attribute value, got {value!r}; a counter that is not an "
        "integer cannot bound a closure"
    )


def default_finite_rules(
    *, primary: str, secondary: str, replica_limit: int = 2
) -> Tuple[TransformationRule, ...]:
    """The three canonical finite transformations, over two named coordinates.

    ``primary`` and ``secondary`` are *coordinate identifiers of the caller's
    schema*.  Nothing here knows what they measure: the rule set is the same
    whether they are latency and energy, wall-clock and dollars, or mass and
    volume.  That is the whole content of the domain-neutrality claim (3.3).

    * ``store-vs-recompute`` trades secondary for primary (recomputing costs
      more of the first coordinate and less of the second);
    * ``fuse-vs-split`` reduces primary multiplicatively and adds a fixed
      overhead to secondary;
    * ``replicate`` scales both, up to ``replica_limit`` applications.
    """
    return (
        TransformationRule(
            transformation_id="store-vs-recompute",
            description="recompute a stored intermediate instead of retaining it",
            scale={primary: Exact("3/2"), secondary: Exact("1/2")},
            requires={ATTR_POLICY: "store"},
            sets={ATTR_POLICY: "recompute"},
        ),
        TransformationRule(
            transformation_id="fuse-vs-split",
            description="split a fused unit of work into two independently placed units",
            scale={primary: Exact("4/5")},
            offset={secondary: Exact(1)},
            requires={ATTR_GRANULARITY: "fused"},
            sets={ATTR_GRANULARITY: "split"},
        ),
        TransformationRule(
            transformation_id="replicate",
            description="add one replica of the unit of work",
            scale={primary: Exact("9/10"), secondary: Exact("6/5")},
            counter=ATTR_REPLICAS,
            counter_limit=replica_limit,
        ),
    )


class FiniteTransformationGenerator:
    """A generator over a declared finite set of exact transformation rules.

    It satisfies :class:`crg_generate.generator.Generator` structurally: it
    exposes a :class:`GeneratorDefinition` and a ``propose``.  Nothing in this
    class is registered with, subclassed from, or otherwise known to core --
    which is specification 6.7's requirement that a third party add a generator
    without editing ``crg-core``.
    """

    def __init__(
        self,
        rules: Sequence[TransformationRule],
        *,
        identity: str = "crg-generate.finite-transformation",
        version: str = "0.2.0",
        accepted_source_types: Sequence[str] = ("EXPLICIT_RECORDS", "REALIZATION_BUNDLE"),
        capability_gates: Sequence[CapabilityGate] = (),
        legality_predicates: Optional[Sequence[LegalityPredicate]] = None,
        determinism_status: str = DeterminismStatus.DETERMINISTIC,
        failure_semantics: str = FailureSemantics.SKIP_AND_RECORD,
        closes_family: bool = True,
    ) -> None:
        if not rules:
            raise GeneratorError(
                "a finite-transformation generator with no rules produces nothing and would "
                "silently report a one-element family as closed (spec 28.4)"
            )
        seen = set()
        for rule in rules:
            if rule.transformation_id in seen:
                raise GeneratorError(
                    f"transformation {rule.transformation_id!r} is declared twice"
                )
            seen.add(rule.transformation_id)
        self.rules: Tuple[TransformationRule, ...] = tuple(rules)
        predicates = (
            tuple(legality_predicates)
            if legality_predicates is not None
            else (nonnegative_signature_predicate(),)
        )
        self.definition = GeneratorDefinition(
            identity=identity,
            version=version,
            accepted_source_types=tuple(accepted_source_types),
            transformations=tuple(rule.transformation_id for rule in self.rules),
            semantic_rule=SemanticRule.SEMANTICS_PRESERVING,
            semantic_rule_detail=(
                "each rule is an exact rational reparametrization of the parent signature "
                "under a declared attribute change; the computation the record realizes is "
                "unchanged, only the realization of it differs"
            ),
            determinism_status=determinism_status,
            failure_semantics=failure_semantics,
            completeness_implications=CompletenessImplication(
                closes_family=closes_family,
                rationale=(
                    "every declared rule either flips one declared attribute or advances one "
                    "bounded counter, so the transitive closure of the rule set is finite and "
                    "a fixpoint enumerates every realization these transformations can reach "
                    "from the given seeds"
                )
                if closes_family
                else "this instance declines to claim closure",
            ),
            conformance_tests=(
                "test_closure_to_fixpoint_is_generator_closed",
                "test_regenerating_the_same_registry_is_bit_identical",
                "test_depth_limit_is_truncation_not_closure",
            ),
            legality_predicates=predicates,
            capability_gates=tuple(capability_gates),
            obligation_types=(ObligationType.RESOURCE,),
            obligation_extractor=self._obligations,
            parent_child_relation=ParentChildRelation.CHILD_ALTERNATIVE_TO_PARENT,
            dependencies=("crg-generate.finite-transformation.rules",),
            witness_method=WitnessMethod.CONSTRUCTIVE_TRANSFORMATION,
            required_permissions=(),
        )

    # -- the generator contract ----------------------------------------
    def propose(
        self, parent: RealizationRecord, context: GenerationContext
    ) -> Iterable[RealizationRecord]:
        """Children of ``parent`` under every applicable declared rule.

        Rules are applied in declared order and each produces at most one
        child, so the emitted sequence is a deterministic function of the
        parent and the rule set (spec 6.5).
        """
        children: List[RealizationRecord] = []
        for rule in self.rules:
            if not rule.applies(parent):
                continue
            children.append(
                propose_record(
                    parent=parent,
                    definition=self.definition,
                    transformation=rule.transformation_id,
                    signature=rule.child_signature(parent, context.schema),
                    attributes=rule.child_attributes(parent),
                    evidence_class=EvidenceClass.CONSTRUCTIVE,
                )
            )
        return children

    # -- obligation extraction (spec 28.3 step 8) ------------------------
    def _obligations(
        self, record: RealizationRecord, context: GenerationContext
    ) -> Sequence[Obligation]:
        obligations: List[Obligation] = []
        for coordinate, value in zip(context.schema.coordinates, record.signature.values):
            obligations.append(
                Obligation(
                    obligation_type=ObligationType.RESOURCE,
                    realization_id=record.realization_id,
                    name=coordinate.identifier,
                    value=value,
                    unit=coordinate.unit,
                    scope=coordinate.accounting_scope,
                    evidence_class=EvidenceClass.CONSTRUCTIVE,
                    source=self.definition.qualified_id,
                )
            )
        return obligations


def finite_transformation_generator(
    *, primary: str, secondary: str, replica_limit: int = 2, **kwargs: Any
) -> FiniteTransformationGenerator:
    """The reference finite generator over two named coordinates (36.5 pack 1)."""
    return FiniteTransformationGenerator(
        default_finite_rules(
            primary=primary, secondary=secondary, replica_limit=replica_limit
        ),
        **kwargs,
    )


# ---------------------------------------------------------------------------
# (b) distributed-computation placement generator (spec 36.5 pack 3)
# ---------------------------------------------------------------------------

PLACEMENT_MODEL_KEY = "placement_model"
ATTR_PLACEMENT = "placement"


def encode_placement(placement: Mapping[str, str]) -> str:
    """Canonical placement text: ``task=node`` pairs, sorted, ``;``-joined."""
    return ";".join(f"{task}={placement[task]}" for task in sorted(placement))


def decode_placement(text: str) -> Dict[str, str]:
    placement: Dict[str, str] = {}
    for item in str(text).split(";"):
        if not item:
            continue
        task, _, node = item.partition("=")
        if not task or not node:
            raise GeneratorError(f"malformed placement entry {item!r}")
        placement[task] = node
    return placement


@dataclass(frozen=True)
class _PlacementModel:
    tasks: Tuple[Tuple[str, Exact], ...]
    nodes: Tuple[Tuple[str, Exact, Exact], ...]
    time_coordinate: str
    cost_coordinate: str

    @property
    def node_order(self) -> Tuple[str, ...]:
        return tuple(name for name, _rate, _price in self.nodes)

    def rate(self, node: str) -> Exact:
        for name, rate, _price in self.nodes:
            if name == node:
                return rate
        raise GeneratorError(f"node {node!r} is not in the declared placement model")

    def price(self, node: str) -> Exact:
        for name, _rate, price in self.nodes:
            if name == node:
                return price
        raise GeneratorError(f"node {node!r} is not in the declared placement model")

    def work(self, task: str) -> Exact:
        for name, work in self.tasks:
            if name == task:
                return work
        raise GeneratorError(f"task {task!r} is not in the declared placement model")

    @property
    def universe_size(self) -> int:
        return len(self.nodes) ** len(self.tasks)


def _read_model(context: GenerationContext) -> _PlacementModel:
    raw = context.require(PLACEMENT_MODEL_KEY)
    if not isinstance(raw, Mapping):
        raise GeneratorError(f"{PLACEMENT_MODEL_KEY} must be a mapping")
    tasks = raw.get("tasks")
    nodes = raw.get("nodes")
    coordinates = raw.get("coordinates", {})
    if not tasks or not nodes:
        raise GeneratorError(
            f"{PLACEMENT_MODEL_KEY} MUST declare both tasks and nodes; an empty declaration "
            "would make an empty family look like a closed one (spec 6.6)"
        )
    time_coordinate = coordinates.get("time")
    cost_coordinate = coordinates.get("cost")
    if not time_coordinate or not cost_coordinate:
        raise GeneratorError(
            f"{PLACEMENT_MODEL_KEY} MUST map the roles 'time' and 'cost' onto declared "
            "coordinate identifiers; a signature component may never be guessed (spec 19.1)"
        )
    return _PlacementModel(
        tasks=tuple((name, Exact(tasks[name]["work"])) for name in sorted(tasks)),
        nodes=tuple(
            (name, Exact(nodes[name]["rate"]), Exact(nodes[name]["price"]))
            for name in sorted(nodes)
        ),
        time_coordinate=str(time_coordinate),
        cost_coordinate=str(cost_coordinate),
    )


def placement_signature(
    placement: Mapping[str, str], model: Any, schema: CoordinateSchema
) -> Signature:
    """Exact makespan and exact cost of one placement.

    ``time`` is the maximum over nodes of that node's total work divided by its
    rate; ``cost`` is the sum over nodes of that node's busy time multiplied by
    its price.  Both are exact rationals: division here is rational division,
    not floating point, so two placements that differ by one part in a
    thousandth of a percent still compare exactly (spec 14.2, 22.6).
    """
    if not isinstance(model, _PlacementModel):
        model = _read_model(model)
    loads: Dict[str, Exact] = {node: Exact(0) for node in model.node_order}
    for task, node in placement.items():
        if node not in loads:
            raise GeneratorError(f"task {task!r} is placed on undeclared node {node!r}")
        loads[node] = loads[node] + model.work(task)
    busy = {node: loads[node] / model.rate(node) for node in model.node_order}
    makespan = max((busy[node] for node in model.node_order), key=lambda e: e.value)
    cost = Exact(0)
    for node in model.node_order:
        cost = cost + busy[node] * model.price(node)
    by_identifier = {model.time_coordinate: makespan, model.cost_coordinate: cost}
    missing = [i for i in schema.identifiers if i not in by_identifier]
    if missing:
        raise GeneratorError(
            f"the declared schema has coordinates {missing} that the placement model does "
            "not produce; a signature has no optional components (spec 19.1)"
        )
    return Signature([by_identifier[identifier] for identifier in schema.identifiers])


def placement_seed(
    placement: Mapping[str, str],
    context: GenerationContext,
    *,
    source_id: str = "placement-seed",
) -> RealizationRecord:
    """The seed record for an initial placement."""
    model = _read_model(context)
    return seed_record(
        source_id=source_id,
        signature=placement_signature(placement, model, context.schema),
        attributes={ATTR_PLACEMENT: encode_placement(placement)},
        evidence_class=EvidenceClass.CONSTRUCTIVE,
    )


class PlacementGenerator:
    """Move one task to a later node (spec 36.5 pack 3: distributed computation).

    The generated family is the set of placements of tasks onto compute nodes.
    A task may only move to a node that appears *later* in the declared node
    order, which makes the move relation a strict partial order and the closure
    finite while still reaching every placement from the all-first-node seed.

    Two different orders of the same set of moves reach the same placement, and
    therefore the same exact signature, by different derivation paths.  Both
    records are kept: they are two different realizations of the same point in
    signature space, and 19.6 is the requirement that a decision able to see
    the difference is still able to see it after the geometry is built.
    """

    TRANSFORMATION = "move-task-to-later-node"

    def __init__(
        self,
        *,
        identity: str = "crg-generate.distributed-placement",
        version: str = "0.2.0",
        capability_gates: Sequence[CapabilityGate] = (),
        legality_predicates: Optional[Sequence[LegalityPredicate]] = None,
        failure_semantics: str = FailureSemantics.SKIP_AND_RECORD,
    ) -> None:
        predicates = (
            tuple(legality_predicates)
            if legality_predicates is not None
            else (nonnegative_signature_predicate(),)
        )
        self.definition = GeneratorDefinition(
            identity=identity,
            version=version,
            accepted_source_types=("PLACEMENT", "EXPLICIT_RECORDS"),
            transformations=(self.TRANSFORMATION,),
            semantic_rule=SemanticRule.SEMANTICS_PRESERVING,
            semantic_rule_detail=(
                "moving a task between nodes changes where the work runs, never what is "
                "computed; the task set and the work of each task are invariants of the "
                "transformation"
            ),
            determinism_status=DeterminismStatus.DETERMINISTIC,
            failure_semantics=failure_semantics,
            completeness_implications=CompletenessImplication(
                closes_family=True,
                rationale=(
                    "a task moves only to a later node in the declared node order, so the "
                    "move relation is a strict partial order on a finite product space; the "
                    "fixpoint therefore contains every placement reachable from the seeds, "
                    "and from the all-first-node seed that is every placement"
                ),
            ),
            conformance_tests=(
                "test_two_paths_to_one_signature_stay_two_records",
                "test_exhaustive_declared_universe_when_the_universe_is_enumerated",
            ),
            legality_predicates=predicates,
            capability_gates=tuple(capability_gates),
            obligation_types=(ObligationType.CAPABILITY,),
            obligation_extractor=self._obligations,
            parent_child_relation=ParentChildRelation.CHILD_ALTERNATIVE_TO_PARENT,
            dependencies=(f"context:{PLACEMENT_MODEL_KEY}",),
            witness_method=WitnessMethod.CONSTRUCTIVE_TRANSFORMATION,
            required_permissions=(),
        )

    def propose(
        self, parent: RealizationRecord, context: GenerationContext
    ) -> Iterable[RealizationRecord]:
        model = _read_model(context)
        placement = decode_placement(parent.attributes.get(ATTR_PLACEMENT, ""))
        if not placement:
            return []
        order = model.node_order
        children: List[RealizationRecord] = []
        for task in sorted(placement):
            current = placement[task]
            if current not in order:
                raise GeneratorError(
                    f"task {task!r} sits on undeclared node {current!r}"
                )
            start = order.index(current)
            for node in order[start + 1:]:
                moved = dict(placement)
                moved[task] = node
                attributes = {
                    key: value
                    for key, value in parent.attributes.items()
                    if key not in _RESERVED
                }
                attributes[ATTR_PLACEMENT] = encode_placement(moved)
                children.append(
                    propose_record(
                        parent=parent,
                        definition=self.definition,
                        transformation=self.TRANSFORMATION,
                        signature=placement_signature(moved, model, context.schema),
                        attributes=attributes,
                        evidence_class=EvidenceClass.CONSTRUCTIVE,
                    )
                )
        return children

    def _obligations(
        self, record: RealizationRecord, context: GenerationContext
    ) -> Sequence[Obligation]:
        model = _read_model(context)
        placement = decode_placement(record.attributes.get(ATTR_PLACEMENT, ""))
        loads: Dict[str, Exact] = {node: Exact(0) for node in model.node_order}
        for task, node in placement.items():
            loads[node] = loads[node] + model.work(task)
        return [
            Obligation(
                obligation_type=ObligationType.CAPABILITY,
                realization_id=record.realization_id,
                name=f"node:{node}",
                value=loads[node] / model.rate(node),
                unit="node-busy-time",
                evidence_class=EvidenceClass.CONSTRUCTIVE,
                source=self.definition.qualified_id,
            )
            for node in model.node_order
            if loads[node] > Exact(0)
        ]


def placement_generator(**kwargs: Any) -> PlacementGenerator:
    """The reference distributed-computation generator (36.5 pack 3)."""
    return PlacementGenerator(**kwargs)


def placement_universe_size(context: GenerationContext) -> int:
    """``|nodes| ** |tasks|``: the declared finite universe of placements."""
    return _read_model(context).universe_size
