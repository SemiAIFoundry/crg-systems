"""Domain packs and the plugin manifest.

Normative basis: master specification section 36 (extension and domain-pack
architecture), with section 6.7 (extensibility without core modification),
section 15 (schema evolution), and section 21 (a pack may not change what a
certificate claims).

Specification 36.3 says untrusted plugins *should* execute in isolated
processes with restricted filesystem and network access, resource quotas,
signed-package verification, explicit secret access, complete invocation logs,
and reproducible environment manifests.  A pure-Python SDK loading a pack in
its own interpreter can provide none of the first five: once a pack's code
runs in this process it can do anything this process can do, and no validation
function changes that.

This module therefore does what an in-process loader honestly can, and says so:

* it **enforces the declared permission list** as a contract -- a capability a
  pack did not declare is not granted to it by the generation context, and a
  pack declaring a permission this SDK cannot confine (network, subprocess,
  secrets, filesystem writes) is *rejected* rather than quietly trusted;
* it **refuses an under-declared manifest** -- a pack missing identity,
  version, supported specification versions, determinism status, or
  conformance tests cannot be validated at all, and 36.2 makes each of those a
  MUST;
* it **keeps complete invocation logs** -- every generator a pack supplies is
  invoked through :mod:`crg_generate.registry`, which records the invocation
  with the generator's definition hash (36.3); and
* it **refuses semantic override** -- 36.4 forbids a domain pack from
  overriding core certificate semantics, so a pack redefining a claim scope, a
  completeness basis type, or a legality state is rejected.

:func:`validate_pack` returns violations rather than raising, so a host can
show a pack author every problem at once; :meth:`DomainPack.require_valid`
raises when the host wants a fail-closed load.

The paragraph above remains exactly true of the in-process path, and that path
is unchanged.  Since :mod:`crg_generate.sandbox` there is a **second** path:
:func:`load_sandboxed_pack` pairs a pack with a
:class:`crg_generate.sandbox.SandboxPolicy` and runs its code in a separate,
confined interpreter, where the five permissions of
:data:`Permission.REQUIRES_ISOLATION` become grantable because something
actually enforces them.  A host must ask for that path by name.  Calling
``load_pack`` still yields a loader that refuses those permissions, and it must
keep doing so: a host that has not chosen isolation has not got it, and telling
it otherwise would be the exact failure 36.3 is about.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Mapping, Optional, Tuple

from crg_model.canonical import content_hash
from crg_model.completeness import ClaimScope, CompletenessBasisType

from .generator import (
    DeterminismStatus,
    Generator,
    GeneratorDefinition,
)
from .legality import LegalityPredicate, LegalityStatus
from .extensions import ExtensionBinding

__all__ = [
    "PackError",
    "Permission",
    "SecurityClassification",
    "CORE_RESERVED_NAMES",
    "MANIFEST_REQUIRED_FIELDS",
    "PROOF_CHECKER_REQUIRED_FIELDS",
    "DomainPackManifest",
    "DomainPack",
    "load_pack",
    "validate_pack",
    "pack_permissions",
    # the second, confined path of 36.3
    "SandboxedPack",
    "load_sandboxed_pack",
    "sandbox_policy_for_pack",
    "validate_pack_for_sandbox",
]


class PackError(ValueError):
    """Raised when a pack manifest cannot be read at all."""


class Permission:
    """The declared permission vocabulary of specification 36.2/36.3."""

    #: Grantable in-process: these are read-only capabilities over data the
    #: host already handed to the pack.
    READ_SOURCE = "READ_SOURCE"
    READ_CONTEXT = "READ_CONTEXT"
    GENERATE_REALIZATIONS = "GENERATE_REALIZATIONS"
    EVALUATE_LEGALITY = "EVALUATE_LEGALITY"
    EXTRACT_OBLIGATIONS = "EXTRACT_OBLIGATIONS"
    REGISTER_QUANTITIES = "REGISTER_QUANTITIES"
    PROVIDE_BOUNDS = "PROVIDE_BOUNDS"
    RENDER_CERTIFICATE = "RENDER_CERTIFICATE"

    #: Not grantable by this loader.  Each requires an isolation boundary this
    #: SDK does not have; declaring one is a request this loader must refuse
    #: rather than silently ignore (36.3).
    FILESYSTEM_READ = "FILESYSTEM_READ"
    FILESYSTEM_WRITE = "FILESYSTEM_WRITE"
    NETWORK = "NETWORK"
    SUBPROCESS = "SUBPROCESS"
    SECRETS = "SECRETS"

    IN_PROCESS_GRANTABLE = frozenset(
        {
            READ_SOURCE,
            READ_CONTEXT,
            GENERATE_REALIZATIONS,
            EVALUATE_LEGALITY,
            EXTRACT_OBLIGATIONS,
            REGISTER_QUANTITIES,
            PROVIDE_BOUNDS,
            RENDER_CERTIFICATE,
        }
    )
    REQUIRES_ISOLATION = frozenset(
        {FILESYSTEM_READ, FILESYSTEM_WRITE, NETWORK, SUBPROCESS, SECRETS}
    )
    ALL = IN_PROCESS_GRANTABLE | REQUIRES_ISOLATION


class SecurityClassification:
    """Specification 36.2 "security classification"."""

    TRUSTED_FIRST_PARTY = "TRUSTED_FIRST_PARTY"
    REVIEWED_THIRD_PARTY = "REVIEWED_THIRD_PARTY"
    UNTRUSTED = "UNTRUSTED"

    ALL = frozenset({TRUSTED_FIRST_PARTY, REVIEWED_THIRD_PARTY, UNTRUSTED})


#: Names a domain pack MUST NOT redefine (36.4: "a domain pack MUST NOT
#: override core certificate semantics").  A pack that renames
#: ``RELATIVE_EXPLICIT_FAMILY`` or redefines ``INFEASIBLE`` in its terminology
#: would change what every certificate over its cases means.
CORE_RESERVED_NAMES: frozenset = (
    frozenset(CompletenessBasisType.ALL)
    | frozenset(LegalityStatus.ALL)
    | frozenset(
        {
            ClaimScope.FULL_DECLARED_UNIVERSE,
            ClaimScope.GENERATOR_CLOSED_FAMILY,
            ClaimScope.BOUNDED_REMAINDER_GLOBAL,
            ClaimScope.RELATIVE_EXPLICIT_FAMILY,
            ClaimScope.PARTIAL_FAMILY,
        }
    )
    | frozenset(
        {
            "claim_scope",
            "completeness_basis",
            "decision_certificate",
            "pruning_certificate",
            "regret_witness",
            "evidence_class",
        }
    )
)

#: The fields 36.2 makes a MUST.  ``load_pack`` accepts a manifest missing any
#: of them so that ``validate_pack`` can report *all* of them; a host that
#: wants to fail on the first one calls ``DomainPack.require_valid()``.
MANIFEST_REQUIRED_FIELDS: Tuple[str, ...] = (
    "identity",
    "version",
    "publisher",
    "supported_spec_versions",
    "permissions",
    "input_schemas",
    "output_schemas",
    "determinism_status",
    "external_dependencies",
    "resource_requirements",
    "failure_modes",
    "license",
    "provenance",
    "security_classification",
    "quantity_registry_additions",
    "proof_implications",
    "conformance_tests",
)

#: A pack that omits any of these cannot be validated at all: without an
#: identity there is nothing to attribute, without a version nothing to pin
#: (15.1), without a supported specification version nothing to check
#: compatibility against (15.6), without a determinism status no certificate
#: may rest on its output (6.5), and without conformance tests no third party
#: can establish that it does what it declares (36.2).
MANIFEST_FATAL_FIELDS: Tuple[str, ...] = (
    "identity",
    "version",
    "supported_spec_versions",
    "determinism_status",
    "conformance_tests",
)

PROOF_CHECKER_REQUIRED_FIELDS: Tuple[str, ...] = (
    "checker_id", "proof_format", "semantic_scope", "version",
    "implementation_identity", "sandbox_requirements", "conformance_suite",
    "trust_profile",
)


@dataclass
class DomainPackManifest:
    """The plugin manifest of specification 36.2.

    Every field is a MUST in the specification, so every field defaults to an
    empty value rather than to a plausible one: an omitted determinism status
    must read as *omitted*, never as ``DETERMINISTIC``.
    """

    identity: str = ""
    version: str = ""
    publisher: str = ""
    supported_spec_versions: Tuple[str, ...] = ()
    permissions: Tuple[str, ...] = ()
    input_schemas: Tuple[str, ...] = ()
    output_schemas: Tuple[str, ...] = ()
    determinism_status: str = ""
    external_dependencies: Tuple[str, ...] = ()
    resource_requirements: Mapping[str, Any] = field(default_factory=dict)
    failure_modes: Tuple[str, ...] = ()
    license: str = ""
    provenance: Mapping[str, Any] = field(default_factory=dict)
    security_classification: str = ""
    quantity_registry_additions: Tuple[str, ...] = ()
    proof_implications: Tuple[str, ...] = ()
    conformance_tests: Tuple[str, ...] = ()

    @property
    def qualified_id(self) -> str:
        return f"{self.identity}@{self.version}" if self.identity else "(unidentified pack)"

    def missing_fields(self) -> Tuple[str, ...]:
        missing: List[str] = []
        for name in MANIFEST_REQUIRED_FIELDS:
            value = getattr(self, name)
            if value in ("", (), {}, None):
                missing.append(name)
        return tuple(missing)

    def to_canonical(self) -> dict:
        return {
            "identity": self.identity,
            "version": self.version,
            "publisher": self.publisher,
            "supported_spec_versions": list(self.supported_spec_versions),
            "permissions": sorted(self.permissions),
            "input_schemas": list(self.input_schemas),
            "output_schemas": list(self.output_schemas),
            "determinism_status": self.determinism_status,
            "external_dependencies": list(self.external_dependencies),
            "resource_requirements": dict(self.resource_requirements),
            "failure_modes": list(self.failure_modes),
            "license": self.license,
            "provenance": dict(self.provenance),
            "security_classification": self.security_classification,
            "quantity_registry_additions": list(self.quantity_registry_additions),
            "proof_implications": list(self.proof_implications),
            "conformance_tests": list(self.conformance_tests),
        }

    def manifest_hash(self) -> str:
        return content_hash(self.to_canonical())


@dataclass
class DomainPack:
    """A domain pack: a manifest plus the extensions of 36.4.

    Nothing in a pack reaches core.  A pack contributes generators, legality
    predicates, terminology, and fixtures; :mod:`crg_generate.registry` and
    :mod:`crg_generate.legality` consume them through the same contracts a
    first-party generator uses, which is what 6.7 requires: a third party adds
    a generator without editing ``crg-core``.
    """

    manifest: DomainPackManifest
    generators: Tuple[Generator, ...] = ()
    legality_predicates: Tuple[LegalityPredicate, ...] = ()
    typed_extensions: Tuple[ExtensionBinding, ...] = ()
    # 36.4 domain-pack contents
    terminology: Mapping[str, str] = field(default_factory=dict)
    quantities: Mapping[str, Any] = field(default_factory=dict)
    contracts: Mapping[str, Any] = field(default_factory=dict)
    transformations: Tuple[str, ...] = ()
    obligation_coordinates: Tuple[str, ...] = ()
    accounting_rules: Mapping[str, Any] = field(default_factory=dict)
    technology_coordinates: Tuple[str, ...] = ()
    evaluators: Tuple[str, ...] = ()
    qualification_methods: Tuple[str, ...] = ()
    proof_checkers: Tuple[Mapping[str, Any], ...] = ()
    ui_extensions: Tuple[str, ...] = ()
    example_cases: Tuple[str, ...] = ()
    conformance_fixtures: Tuple[str, ...] = ()

    @property
    def qualified_id(self) -> str:
        return self.manifest.qualified_id

    def generator_definitions(self) -> Tuple[GeneratorDefinition, ...]:
        return tuple(g.definition for g in self.generators)

    def granted_permissions(self) -> Tuple[str, ...]:
        """The permissions a host may pass to a generation context."""
        return tuple(
            sorted(
                p
                for p in self.manifest.permissions
                if p in Permission.IN_PROCESS_GRANTABLE
            )
        )

    def to_canonical(self) -> dict:
        return {
            "manifest": self.manifest.to_canonical(),
            "generators": [g.definition.to_canonical() for g in self.generators],
            "legality_predicates": [p.to_canonical() for p in self.legality_predicates],
            "typed_extensions": [
                binding.definition.to_canonical() for binding in self.typed_extensions
            ],
            "terminology": dict(self.terminology),
            "quantities": dict(self.quantities),
            "contracts": dict(self.contracts),
            "transformations": list(self.transformations),
            "obligation_coordinates": list(self.obligation_coordinates),
            "accounting_rules": dict(self.accounting_rules),
            "technology_coordinates": list(self.technology_coordinates),
            "evaluators": list(self.evaluators),
            "qualification_methods": list(self.qualification_methods),
            "proof_checkers": [dict(checker) for checker in self.proof_checkers],
            "ui_extensions": list(self.ui_extensions),
            "example_cases": list(self.example_cases),
            "conformance_fixtures": list(self.conformance_fixtures),
        }

    def pack_hash(self) -> str:
        return content_hash(self.to_canonical())

    def require_valid(self, spec_version: Optional[str] = None) -> "DomainPack":
        """Fail closed: raise unless the pack validates cleanly (spec 6.6)."""
        violations = validate_pack(self, spec_version=spec_version)
        if violations:
            raise PackError(
                f"domain pack {self.qualified_id} is not admissible:\n  - "
                + "\n  - ".join(violations)
            )
        return self


# ---------------------------------------------------------------------------
# loading
# ---------------------------------------------------------------------------

_TUPLE_FIELDS = frozenset(
    {
        "supported_spec_versions",
        "permissions",
        "input_schemas",
        "output_schemas",
        "external_dependencies",
        "failure_modes",
        "quantity_registry_additions",
        "proof_implications",
        "conformance_tests",
    }
)

_PACK_TUPLE_FIELDS = frozenset(
    {
        "transformations",
        "obligation_coordinates",
        "technology_coordinates",
        "evaluators",
        "qualification_methods",
        "ui_extensions",
        "example_cases",
        "conformance_fixtures",
    }
)


def load_pack(manifest_dict: Mapping[str, Any]) -> DomainPack:
    """Read a domain pack from its declared manifest (spec 36.2, 36.4).

    ``manifest_dict`` carries the manifest fields at the top level and the
    optional pack contents of 36.4 under ``contents``.  Live extensions --
    generator instances, legality predicates -- are passed under ``extensions``
    because they are objects, not data; a manifest read from a file carries
    none and the resulting pack is a pure declaration.

    Loading is deliberately permissive about *missing* fields and strict about
    *unknown* ones.  A missing field must survive to :func:`validate_pack` so
    the author sees every omission at once.  An unknown field is refused: this
    loader cannot tell whether ``sandbox: false`` is a typo or a request it
    does not understand, and a manifest key silently ignored is exactly how a
    permission boundary gets crossed (36.3, 6.6).
    """
    if not isinstance(manifest_dict, Mapping):
        raise PackError(
            f"a domain pack manifest is a mapping, got {type(manifest_dict).__name__}"
        )
    contents = manifest_dict.get("contents", {})
    extensions = manifest_dict.get("extensions", {})
    if not isinstance(contents, Mapping) or not isinstance(extensions, Mapping):
        raise PackError("'contents' and 'extensions' must be mappings")

    known = set(MANIFEST_REQUIRED_FIELDS) | {"contents", "extensions"}
    unknown = sorted(set(manifest_dict) - known)
    if unknown:
        raise PackError(
            "unknown manifest field(s): "
            + ", ".join(unknown)
            + ". This loader refuses a manifest key it does not understand rather than "
            "ignore it, because an ignored key may be a permission or an isolation request "
            "(spec 36.2, 36.3, 6.6)."
        )

    values: Dict[str, Any] = {}
    for name in MANIFEST_REQUIRED_FIELDS:
        if name not in manifest_dict:
            continue
        value = manifest_dict[name]
        if name in _TUPLE_FIELDS:
            if isinstance(value, str):
                raise PackError(
                    f"manifest field {name!r} is a list of strings; a bare string would read "
                    "as a list of its characters"
                )
            values[name] = tuple(str(v) for v in value)
        elif name in ("resource_requirements", "provenance"):
            if not isinstance(value, Mapping):
                raise PackError(f"manifest field {name!r} must be a mapping")
            values[name] = dict(value)
        else:
            values[name] = str(value)

    manifest = DomainPackManifest(**values)

    pack_values: Dict[str, Any] = {}
    known_contents = {
        "terminology",
        "quantities",
        "contracts",
        "accounting_rules",
        "proof_checkers",
    } | _PACK_TUPLE_FIELDS
    unknown_contents = sorted(set(contents) - known_contents)
    if unknown_contents:
        raise PackError(
            "unknown pack content(s): " + ", ".join(unknown_contents) + " (spec 36.4)"
        )
    for name, value in contents.items():
        if name == "proof_checkers":
            if isinstance(value, str) or not isinstance(value, (list, tuple)):
                raise PackError("pack content 'proof_checkers' must be a list of declarations")
            declarations = []
            for index, declaration in enumerate(value):
                if not isinstance(declaration, Mapping):
                    raise PackError(
                        f"proof_checkers[{index}] must be a declaration object, not "
                        f"{type(declaration).__name__}"
                    )
                declarations.append(dict(declaration))
            pack_values[name] = tuple(declarations)
        elif name in _PACK_TUPLE_FIELDS:
            pack_values[name] = tuple(str(v) for v in value)
        else:
            if not isinstance(value, Mapping):
                raise PackError(f"pack content {name!r} must be a mapping")
            pack_values[name] = dict(value)

    generators = tuple(extensions.get("generators", ()))
    predicates = tuple(extensions.get("legality_predicates", ()))
    typed_extensions = tuple(extensions.get("typed", ()))
    if any(not isinstance(binding, ExtensionBinding) for binding in typed_extensions):
        raise PackError("extensions.typed must contain ExtensionBinding instances")
    unknown_extensions = sorted(set(extensions) - {"generators", "legality_predicates", "typed"})
    if unknown_extensions:
        raise PackError(
            "unknown extension(s): " + ", ".join(unknown_extensions) + " (spec 36.1)"
        )

    return DomainPack(
        manifest=manifest,
        generators=generators,
        legality_predicates=predicates,
        typed_extensions=typed_extensions,
        **pack_values,
    )


# ---------------------------------------------------------------------------
# validation (spec 36.2, 36.3, 36.4)
# ---------------------------------------------------------------------------


def pack_permissions(pack: DomainPack) -> Tuple[str, ...]:
    """Permissions the pack's own extensions actually require."""
    required = set()
    if pack.generators:
        required.add(Permission.GENERATE_REALIZATIONS)
    if pack.legality_predicates or any(
        g.definition.legality_predicates for g in pack.generators
    ):
        required.add(Permission.EVALUATE_LEGALITY)
    if any(g.definition.obligation_extractor is not None for g in pack.generators):
        required.add(Permission.EXTRACT_OBLIGATIONS)
    if pack.manifest.quantity_registry_additions:
        required.add(Permission.REGISTER_QUANTITIES)
    for generator in pack.generators:
        required.update(generator.definition.required_permissions)
    for binding in pack.typed_extensions:
        required.update(binding.definition.required_permissions)
    return tuple(sorted(required))


def _in_process_isolation_refusal(token: str) -> str:
    """The exact refusal :func:`validate_pack` reports for an isolated permission.

    It is a function rather than an inline string because two callers need the
    identical text: :func:`validate_pack`, which emits it, and
    :func:`validate_pack_for_sandbox`, which lifts it when a real isolation
    boundary exists.  Two copies of a message that must match exactly is how a
    permission quietly stops being refused, so there is one copy.
    """
    return (
        f"manifest declares permission {token!r}, which requires the process, "
        "filesystem, and network isolation of specification 36.3. This SDK loads packs "
        "in its own interpreter and cannot confine it, so the permission is refused "
        "rather than granted unenforced"
    )


def _in_process_unverifiable_dependency_refusal() -> str:
    """The exact refusal reported for an UNTRUSTED pack with dependencies.

    Lifted by :func:`validate_pack_for_sandbox` only when the host has declared
    a trusted-key set, because that is precisely the condition under which the
    sentence stops being true: with :func:`crg_generate.sandbox.verify_package`
    and :class:`crg_generate.sandbox.EnvironmentManifest`, this loader *can*
    verify both.
    """
    return (
        "an UNTRUSTED pack declares external dependencies; specification 36.3 requires "
        "signed-package verification and a reproducible environment manifest before such "
        "a pack may run, and this loader can verify neither"
    )


def validate_pack(
    pack: DomainPack, *, spec_version: Optional[str] = None
) -> List[str]:
    """Return every reason ``pack`` is not admissible, or an empty list.

    The checks, in order of what they defend:

    1. **Manifest completeness** (36.2).  The five fields of
       :data:`MANIFEST_FATAL_FIELDS` -- identity, version, supported
       specification versions, determinism status, conformance tests -- make
       validation possible at all; the remaining MUST fields of 36.2 are
       reported individually.
    2. **Permission discipline** (36.3).  Unknown permission tokens are
       refused; a permission this in-process loader cannot confine is refused;
       and a capability the pack actually exercises but did not declare is
       refused, because a permission list that does not cover the code is not
       a permission list.
    3. **Specification compatibility** (15.6).  A pack that does not name the
       specification version in force cannot be pinned by a certificate.
    4. **Determinism agreement** (6.5).  A generator that declares itself more
       reproducible than its own pack is claiming a guarantee the pack does
       not make.
    5. **No semantic override** (36.4).  A pack redefining a completeness
       basis type, a claim scope, a legality state, or another core
       certificate term is refused outright.
    """
    from crg_model import SPEC_VERSION  # local import: core version, not a dependency

    violations: List[str] = []
    manifest = pack.manifest
    target_spec = spec_version or SPEC_VERSION

    # 1. manifest completeness
    for name in MANIFEST_FATAL_FIELDS:
        value = getattr(manifest, name)
        if value in ("", (), {}, None):
            violations.append(
                f"manifest omits {name!r}, which specification 36.2 makes a MUST; a pack "
                "without it cannot be identified, pinned, checked for compatibility, or "
                "relied on for a certificate"
            )
    for name in manifest.missing_fields():
        if name in MANIFEST_FATAL_FIELDS:
            continue
        violations.append(f"manifest omits {name!r} (spec 36.2 requires every listed field)")

    # 2. permissions
    declared = set(manifest.permissions)
    unknown = sorted(declared - Permission.ALL)
    for token in unknown:
        violations.append(
            f"manifest declares unknown permission {token!r}; the declared vocabulary is "
            f"{sorted(Permission.ALL)} (spec 36.2)"
        )
    needs_isolation = sorted(declared & Permission.REQUIRES_ISOLATION)
    for token in needs_isolation:
        violations.append(_in_process_isolation_refusal(token))
    for token in sorted(set(pack_permissions(pack)) - declared):
        violations.append(
            f"the pack exercises {token!r} but does not declare it; every capability a pack "
            "uses MUST appear in its declared permission list (spec 36.2, 36.3)"
        )

    # 3. specification compatibility
    if manifest.supported_spec_versions and target_spec not in manifest.supported_spec_versions:
        violations.append(
            f"the pack supports specification version(s) "
            f"{sorted(manifest.supported_spec_versions)} but this core implements "
            f"{target_spec}; a pack that has not been checked against the specification in "
            "force MUST NOT be loaded (spec 15.6, 36.2)"
        )

    # 4. determinism agreement
    if manifest.determinism_status and manifest.determinism_status not in DeterminismStatus.ALL:
        violations.append(
            f"manifest declares determinism status {manifest.determinism_status!r}; expected "
            f"one of {sorted(DeterminismStatus.ALL)} (spec 6.5, 36.2)"
        )
    pack_may_close = manifest.determinism_status in DeterminismStatus.MAY_CLOSE_A_FAMILY
    for generator in pack.generators:
        definition = generator.definition
        generator_may_close = (
            definition.determinism_status in DeterminismStatus.MAY_CLOSE_A_FAMILY
        )
        if generator_may_close and not pack_may_close:
            violations.append(
                f"generator {definition.qualified_id} declares "
                f"{definition.determinism_status} while its pack declares "
                f"{manifest.determinism_status or '(nothing)'}; a generator cannot promise "
                "more reproducibility than the pack that ships it (spec 6.5)"
            )
        if definition.completeness_implications.closes_family and not generator_may_close:
            violations.append(
                f"generator {definition.qualified_id} declares that it closes the family "
                f"while declaring {definition.determinism_status}; a search that may return "
                "a different family on the next run closes nothing (spec 6.5, 21.6)"
            )
        if not definition.conformance_tests:
            violations.append(
                f"generator {definition.qualified_id} declares no conformance tests "
                "(spec 28.4, 36.2)"
            )

    # 5. no override of core certificate semantics (36.4)
    for name in sorted(
        set(manifest.quantity_registry_additions)
        | set(manifest.proof_implications)
        | set(pack.terminology)
        | set(pack.obligation_coordinates)
    ):
        if name in CORE_RESERVED_NAMES:
            violations.append(
                f"the pack defines {name!r}, which is core certificate vocabulary; a domain "
                "pack MUST NOT override core certificate semantics (spec 36.4)"
            )

    seen_extensions = set()
    for binding in pack.typed_extensions:
        definition = binding.definition
        if definition.extension_id in seen_extensions:
            violations.append(
                f"typed extension {definition.extension_id!r} is declared more than once"
            )
        seen_extensions.add(definition.extension_id)
        for permission in definition.required_permissions:
            if permission not in Permission.ALL:
                violations.append(
                    f"typed extension {definition.extension_id!r} requires unknown "
                    f"permission {permission!r}"
                )

    # 24.6 / 36.4: a proof checker is a typed declaration, not a bare plugin
    # name.  The verifier independently matches this declaration to its own
    # registry before a checker can run.
    seen_checkers = set()
    for index, checker in enumerate(pack.proof_checkers):
        missing = sorted(set(PROOF_CHECKER_REQUIRED_FIELDS) - set(checker))
        unknown = sorted(set(checker) - set(PROOF_CHECKER_REQUIRED_FIELDS))
        if missing or unknown:
            violations.append(
                f"proof checker {index} declaration fields mismatch: "
                f"missing={missing}, unknown={unknown} (spec 24.6, 36.4)"
            )
            continue
        checker_id = str(checker.get("checker_id", ""))
        if not checker_id:
            violations.append(f"proof checker {index} has no checker_id (spec 24.6)")
        elif checker_id in seen_checkers:
            violations.append(f"proof checker {checker_id!r} is declared more than once")
        seen_checkers.add(checker_id)
        for name in (
            "proof_format", "semantic_scope", "version", "implementation_identity",
            "trust_profile",
        ):
            if not str(checker.get(name, "")).strip():
                violations.append(
                    f"proof checker {checker_id or index!r} omits {name} (spec 24.6)"
                )
        sandbox = checker.get("sandbox_requirements")
        if not isinstance(sandbox, Mapping) or not str(sandbox.get("execution_mode", "")):
            violations.append(
                f"proof checker {checker_id or index!r} lacks sandbox execution_mode (spec 24.6)"
            )
        suite = checker.get("conformance_suite")
        if isinstance(suite, str) or not isinstance(suite, (list, tuple)) or not suite:
            violations.append(
                f"proof checker {checker_id or index!r} lacks a conformance suite (spec 24.6)"
            )

    if (
        manifest.security_classification
        and manifest.security_classification not in SecurityClassification.ALL
    ):
        violations.append(
            f"manifest declares security classification "
            f"{manifest.security_classification!r}; expected one of "
            f"{sorted(SecurityClassification.ALL)} (spec 36.2)"
        )
    if (
        manifest.security_classification == SecurityClassification.UNTRUSTED
        and manifest.external_dependencies
    ):
        violations.append(_in_process_unverifiable_dependency_refusal())

    return sorted(set(violations))


# ---------------------------------------------------------------------------
# the second, confined path (spec 36.3)
# ---------------------------------------------------------------------------
#
# Everything above this line describes what an in-process loader can honestly
# do, and it is unchanged.  Everything below it is the other path: a pack whose
# code will run inside :mod:`crg_generate.sandbox`, where the five permissions
# of :data:`Permission.REQUIRES_ISOLATION` become grantable because something
# actually confines them.
#
# The two paths are deliberately separate functions rather than one function
# with a flag.  A host must *choose* isolation, and a reader of a call site must
# be able to see which choice was made without tracing a boolean; a
# ``validate_pack(pack, sandboxed=True)`` would let the strict default drift
# into the permissive one by way of a keyword nobody notices (6.6).


@dataclass(frozen=True)
class SandboxedPack:
    """A pack admitted for confined execution, with the policy that confines it.

    A :class:`DomainPack` is a declaration; a :class:`SandboxedPack` is that
    declaration paired with the host's grant.  Both halves are needed to say
    anything true about what the pack may do: the manifest's permission list is
    a request, the policy is the answer, and 36.2's discipline is that neither
    alone is a capability.

    ``violations`` reports every remaining reason the pack is inadmissible
    *even under isolation* -- an incomplete manifest, an unsupported
    specification version, a semantic override, a policy that grants more than
    the manifest asked for.  It never contains the isolation refusals of
    :func:`validate_pack`, because those have been discharged by the sandbox
    rather than waived.
    """

    pack: DomainPack
    policy: Any
    violations: Tuple[str, ...] = ()

    @property
    def qualified_id(self) -> str:
        return self.pack.qualified_id

    @property
    def is_admissible(self) -> bool:
        return not self.violations

    def granted_permissions(self) -> Tuple[str, ...]:
        """Every permission this pack holds: in-process ones plus confined ones.

        The union is the honest answer and the reason this method exists
        alongside :meth:`DomainPack.granted_permissions`, which returns only
        the in-process half and must keep doing so.
        """
        return tuple(
            sorted(
                set(self.pack.granted_permissions())
                | set(self.policy.granted_permissions)
            )
        )

    def to_canonical(self) -> dict:
        return {
            "pack": self.pack.to_canonical(),
            "policy": self.policy.to_canonical(),
            "violations": list(self.violations),
        }

    def require_valid(self) -> "SandboxedPack":
        """Fail closed: raise unless the pack is admissible under this policy (6.6)."""
        if self.violations:
            raise PackError(
                f"domain pack {self.qualified_id} is not admissible for sandboxed "
                "execution:\n  - " + "\n  - ".join(self.violations)
            )
        return self


def sandbox_policy_for_pack(
    pack: DomainPack,
    *,
    trusted_keys: Any,
    readable_paths: Tuple[str, ...] = (),
    writable_paths: Tuple[str, ...] = (),
    secrets: Tuple[str, ...] = (),
    module_allow_list: Optional[Tuple[str, ...]] = None,
    quota: Any = None,
    determinism_replay: Optional[bool] = None,
    isolation_profile: str = "AUTO",
    oci: Any = None,
    allow_same_uid_reference: bool = False,
) -> Any:
    """Build the policy that grants exactly what this manifest asked for (36.2).

    The grant is the *intersection* of what the manifest declared with the
    isolation-requiring vocabulary: a host cannot accidentally hand a pack a
    capability its manifest never requested, because there is no argument here
    with which to do so.  Widening is possible only by editing the manifest,
    which changes the manifest hash, which changes the package digest, which
    invalidates the package signature -- the chain 36.3 exists to create.

    ``determinism_replay`` defaults from the manifest: a pack declaring
    ``DETERMINISTIC`` has made a claim, and a host granting it isolation is in
    a position to check the claim by running the plugin twice and comparing
    canonical output.  A pack that declares ``NONDETERMINISTIC`` is taken at
    its word and not replayed, because there would be nothing to conclude from
    a disagreement it already warned about (6.5).
    """
    from .sandbox import ResourceQuota, SandboxPolicy  # local: avoids a cycle

    granted = tuple(
        sorted(set(pack.manifest.permissions) & Permission.REQUIRES_ISOLATION)
    )
    if determinism_replay is None:
        determinism_replay = (
            pack.manifest.determinism_status == DeterminismStatus.DETERMINISTIC
        )
    policy_arguments: Dict[str, Any] = {
        "granted_permissions": granted,
        "readable_paths": tuple(readable_paths),
        "writable_paths": tuple(writable_paths),
        "declared_secrets": tuple(secrets),
        "trusted_keys": trusted_keys,
        "quota": quota if quota is not None else ResourceQuota(),
        "determinism_replay": bool(determinism_replay),
        "isolation_profile": isolation_profile,
        "oci": oci,
        "allow_same_uid_reference": bool(allow_same_uid_reference),
    }
    if module_allow_list is not None:
        policy_arguments["module_allow_list"] = tuple(module_allow_list)
    return SandboxPolicy(**policy_arguments)


def validate_pack_for_sandbox(
    pack: DomainPack, *, policy: Any, spec_version: Optional[str] = None
) -> List[str]:
    """Validate a pack against a real isolation boundary (spec 36.2, 36.3).

    Every check of :func:`validate_pack` still applies; this function calls it
    and then discharges exactly two of its findings, and adds four of its own.

    Discharged, because the sandbox makes the sentence false:

    1. the refusal of each :data:`Permission.REQUIRES_ISOLATION` token the
       policy actually grants -- the permission is now confined rather than
       merely declared; and
    2. the refusal of an ``UNTRUSTED`` pack with external dependencies, when
       the policy carries a non-empty trusted-key set -- signed-package
       verification and a reproducible environment manifest both exist now.

    Nothing else is lifted.  In particular an isolation permission the manifest
    declares but the policy does *not* grant stays refused, which is what makes
    a partial grant safe to write.

    Added, because a policy is a new thing that can be wrong:

    3. every :meth:`crg_generate.sandbox.SandboxPolicy.violations` finding --
       an unknown permission token, a path declared without the permission that
       covers it, a module allow-list that would disable the sandbox;
    4. a policy granting an isolation permission the manifest never declared,
       which is a host handing out a capability nobody asked for;
    5. an empty trusted-key set, because 36.3 requires signed-package
       verification and a host that trusts no key can verify nothing, so
       nothing may run; and
    6. a drift check: if the policy grants a token and this function cannot
       find the corresponding refusal in :func:`validate_pack`'s output, the
       two functions have stopped agreeing about the message and the
       discharge is refused rather than guessed at.
    """
    base = validate_pack(pack, spec_version=spec_version)
    granted = set(policy.granted_permissions) & Permission.REQUIRES_ISOLATION
    discharged = {_in_process_isolation_refusal(token) for token in sorted(granted)}
    missing = sorted(
        token
        for token in granted
        if token in set(pack.manifest.permissions)
        and _in_process_isolation_refusal(token) not in base
    )
    if missing:
        raise PackError(
            "internal consistency failure: validate_pack did not report the expected "
            f"in-process refusal for {missing}, so validate_pack_for_sandbox cannot tell "
            "which finding it is discharging. Refusing to guess (spec 6.6)."
        )
    if policy.trusted_keys.key_ids:
        discharged.add(_in_process_unverifiable_dependency_refusal())

    violations = [entry for entry in base if entry not in discharged]

    for violation in policy.violations():
        violations.append(
            f"the sandbox policy is not enforceable as declared: {violation.detail} "
            f"[{violation.category}]"
        )
    for token in sorted(granted - set(pack.manifest.permissions)):
        violations.append(
            f"the sandbox policy grants {token!r}, which the manifest never declared; a "
            "host may confine a capability a pack asked for, but granting one it did not "
            "ask for makes the declared permission list of specification 36.2 mean "
            "nothing"
        )
    if not policy.trusted_keys.key_ids:
        violations.append(
            "the sandbox policy declares no trusted signing keys; specification 36.3 "
            "requires signed-package verification before an untrusted plugin executes, "
            "and a host that trusts no key can verify no package, so no package may run "
            "(spec 6.6)"
        )
    return sorted(set(violations))


def load_sandboxed_pack(
    manifest_dict: Mapping[str, Any],
    *,
    trusted_keys: Any,
    readable_paths: Tuple[str, ...] = (),
    writable_paths: Tuple[str, ...] = (),
    secrets: Tuple[str, ...] = (),
    module_allow_list: Optional[Tuple[str, ...]] = None,
    quota: Any = None,
    determinism_replay: Optional[bool] = None,
    isolation_profile: str = "AUTO",
    oci: Any = None,
    allow_same_uid_reference: bool = False,
    spec_version: Optional[str] = None,
) -> SandboxedPack:
    """Load a pack for *confined* execution (spec 36.2, 36.3, 6.6).

    The reading of the manifest is :func:`load_pack`, unchanged and shared: a
    manifest that is malformed for the in-process path is malformed for this
    one too, and an unknown manifest key is still refused rather than ignored.
    What differs is the answer to the permission question.  ``load_pack``
    followed by ``validate_pack`` refuses a pack that asks for the filesystem,
    the network, a subprocess, or a secret.  This function pairs the pack with
    a :class:`crg_generate.sandbox.SandboxPolicy` that confines exactly those
    requests, and reports what remains wrong.

    Like :func:`validate_pack`, it reports rather than raises, so a pack author
    sees every problem at once; :meth:`SandboxedPack.require_valid` is the
    fail-closed door.  The returned pack is *not* thereby trusted: its module
    source has still to pass :func:`crg_generate.sandbox.verify_package`
    against the declared keys at every single invocation, and this function
    deliberately does not hold that source -- admitting a declaration and
    running code are two decisions, and 36.3 wants both made explicitly.
    """
    pack = load_pack(manifest_dict)
    policy = sandbox_policy_for_pack(
        pack,
        trusted_keys=trusted_keys,
        readable_paths=readable_paths,
        writable_paths=writable_paths,
        secrets=secrets,
        module_allow_list=module_allow_list,
        quota=quota,
        determinism_replay=determinism_replay,
        isolation_profile=isolation_profile,
        oci=oci,
        allow_same_uid_reference=allow_same_uid_reference,
    )
    return SandboxedPack(
        pack=pack,
        policy=policy,
        violations=tuple(
            validate_pack_for_sandbox(pack, policy=policy, spec_version=spec_version)
        ),
    )
