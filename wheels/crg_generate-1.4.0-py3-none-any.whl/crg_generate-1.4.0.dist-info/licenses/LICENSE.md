# CRG Systems Research and Noncommercial License 1.0

CRG Systems is licensed under the PolyForm Noncommercial License 1.0.0 below,
together with the CRG Attribution Condition at the end of this file. Both are
part of the license terms.

Research and noncommercial use do not require a separate commercial license.
Commercial use requires a separate written commercial license from Semi AI
Foundry, LLC. CRG Systems is developed by semiAIfoundry Research, a research
group within Semi AI Foundry, LLC.

The licensor and copyright owner for CRG Systems is Semi AI Foundry, LLC.
References to semiAIfoundry Research identify the internal research group that
develops the product; they do not identify a separate legal entity or licensor.

## Base terms: PolyForm Noncommercial License 1.0.0

https://polyformproject.org/licenses/noncommercial/1.0.0

## Acceptance

In order to get any license under these terms, you must agree to them as both
strict obligations and conditions to all your licenses.

## Copyright License

The licensor grants you a copyright license for the software to do everything
you might do with the software that would otherwise infringe the licensor's
copyright in it for any permitted purpose. However, you may only distribute the
software according to Distribution License and make changes or new works based
on the software according to Changes and New Works License.

## Distribution License

The licensor grants you an additional copyright license to distribute copies of
the software. Your license to distribute covers distributing the software with
changes and new works permitted by Changes and New Works License.

## Notices

You must ensure that anyone who gets a copy of any part of the software from you
also gets a copy of these terms or the URL for them above, as well as copies of
any plain-text lines beginning with `Required Notice:` that the licensor
provided with the software. For example:

> Required Notice: Copyright Yoyodyne, Inc. (http://example.com)

## Changes and New Works License

The licensor grants you an additional copyright license to make changes and new
works based on the software for any permitted purpose.

## Patent License

The licensor grants you a patent license for the software that covers patent
claims the licensor can license, or becomes able to license, that you would
infringe by using the software.

## Noncommercial Purposes

Any noncommercial purpose is a permitted purpose.

## Personal Uses

Personal use for research, experiment, and testing for the benefit of public
knowledge, personal study, private entertainment, hobby projects, amateur
pursuits, or religious observance, without any anticipated commercial
application, is use for a permitted purpose.

## Noncommercial Organizations

Use by any charitable organization, educational institution, public research
organization, public safety or health organization, environmental protection
organization, or government institution is use for a permitted purpose
regardless of the source of funding or obligations resulting from the funding.

## Fair Use

You may have "fair use" rights for the software under the law. These terms do
not limit them.

## No Other Rights

These terms do not allow you to sublicense or transfer any of your licenses to
anyone else, or prevent the licensor from granting licenses to anyone else.
These terms do not imply any other licenses.

## Patent Defense

If you make any written claim that the software infringes or contributes to
infringement of any patent, your patent license for the software granted under
these terms ends immediately. If your company makes such a claim, your patent
license ends immediately for work on behalf of your company.

## Violations

The first time you are notified in writing that you have violated any of these
terms, or done anything with the software not covered by your licenses, your
licenses can nonetheless continue if you come into full compliance with these
terms, and take practical steps to correct past violations, within 32 days of
receiving notice. Otherwise, all your licenses end immediately.

## No Liability

As far as the law allows, the software comes as is, without any warranty or
condition, and the licensor will not be liable to you for any damages arising
out of these terms or the use or nature of the software, under any kind of legal
claim.

## Definitions

The licensor is the individual or entity offering these terms, and the software
is the software the licensor makes available under these terms.

You refers to the individual or entity agreeing to these terms.

Your company is any legal entity, sole proprietorship, or other kind of
organization that you work for, plus all organizations that have control over,
are under the control of, or are under common control with that organization.
Control means ownership of substantially all the assets of an entity, or the
power to direct its management and policies by vote, contract, or otherwise.
Control can be direct or indirect.

Your licenses are all the licenses granted to you for the software.

Use means anything you do with the software requiring one of your licenses.

© PolyForm Project Inc.

## CRG Attribution Condition

As a condition of every permission granted for CRG Systems:

1. Every copy, substantial portion, modified version, or redistribution of the
   software must retain this license and the `Required Notice:` line supplied
   in `NOTICE`.
2. Every public research paper, report, presentation, benchmark, dataset, or
   software release that materially uses CRG Systems must identify
   **CRG Systems 1.4.0, developed by semiAIfoundry Research, a research group
   within Semi AI Foundry, LLC** and include
   <https://semiaifoundry.com/> or the release repository URL.
3. Attribution must not suggest endorsement by Semi AI Foundry, LLC or
   semiAIfoundry Research.

No permission is granted for commercial use. A separate written commercial
license from Semi AI Foundry, LLC is required before any commercial use
begins. See
`COMMERCIAL_LICENSE.md`.
