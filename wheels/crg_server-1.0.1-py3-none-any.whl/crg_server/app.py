"""The headless integration surface: routing, idempotency, and fail-closed status.

Normative basis: 38 in full (integration specification), 6.6 (fail closed),
10.1 (external systems interact through typed requests and responses and
shall not directly mutate canonical CRG objects), 42.4 (job semantics), 44.2
and 44.3 (identity, authorization, minimum roles), 44.7 (audit).

Standard library only: ``http.server`` and ``json``.  Specification 43 names
FastAPI as a *recommended* stack and says in the same breath that "the
specification boundary shall remain language-neutral"; what 38.2 actually
requires is REST with OpenAPI 3.1, asynchronous job APIs, event streaming,
and webhooks.  Those are properties of the surface, and they are met here
without a dependency that a verifier, an air-gapped deployment (45.5), or an
independent reimplementation (48.3) would have to acquire.

Four behaviours are worth reading the code for.

**Long-running actions return a job identifier (38.3).**  Every endpoint
marked ``long_running`` answers ``202`` with a job id and links, never the
computed result.  The reference deployment runs a local worker (42.2) that
may finish the work before the response is written; the response is still the
identifier, because the contract is what an integrator codes against.

**Idempotency keys resolve to the existing result (38.4).**  An
``Idempotency-Key`` header replays the recorded response for an identical
canonical request and refuses -- ``409`` -- a *different* request under the
same key.  Separately, endpoints marked ``content_addressed`` resolve
identical canonical requests to the existing content-addressed result even
without a key; for case-scoped endpoints the fingerprint includes the current
case version, so "identical" means identical *including the state it was
computed against*, which is what 38.4's "when valid" is protecting.

**No 200 ever carries a blocked outcome.**  ``GET /jobs/{id}/result`` is the
only place a computed decision leaves this process, and it returns ``422``
for a blocked outcome and ``409`` for a failed or cancelled job.  A client
that reads only the status line cannot mistake a refusal for a certification.

**Nothing here mutates a canonical object.**  Handlers read cases, hand typed
objects to the kernel, and write *successor* versions through
:class:`~crg_server.store.CaseStore`, which exposes no in-place writer.  10.1
is therefore a property of the type surface rather than a rule the handlers
are trusted to follow.
"""
from __future__ import annotations

import json
import inspect
import re
import sys
import threading
import time
from datetime import datetime, timezone
from dataclasses import dataclass, field, replace
from fractions import Fraction
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Callable, Dict, List, Mapping, Optional, Sequence, Tuple
from urllib.parse import parse_qs, urlsplit

from crg_model.canonical import canonical_json, content_hash
from crg_model.envelope import new_object_id, utc_now
from crg_model.lifecycle import CaseState, LifecycleError, set_case_state

from . import operations as ops
from .branch import MergeRule, create_branch, merge_policy
from .bundleio import export_bundle, import_bundle_bytes, verify_bundle_bytes
from .errors import (
    BlockedOutcome,
    ConflictError,
    ForbiddenError,
    MethodNotAllowedError,
    NotFoundError,
    PayloadTooLargeError,
    RedactedError,
    ServiceUnavailableError,
    ScopeMismatchError,
    ServerError,
    UnauthorizedError,
    UnsupportedMediaTypeError,
    UsageError,
    error_body,
    from_security_error,
)
from .events import EventBus
from .jobs import JobContext, JobQueue, JobResult, JobStatus
from .retention import RetentionPolicy, retention_engine_for_store
from .store import CaseError, CaseStore, new_case
from .webhooks import WebhookDispatcher

__all__ = [
    "Endpoint",
    "ENDPOINTS",
    "ROLE_REQUIREMENTS",
    "NO_AUTHENTICATION_CONFIGURED",
    "Request",
    "Response",
    "Application",
    "make_app",
    "make_handler",
    "serve",
]

SPEC_VERSION = "0.2.0"
SERVER_VERSION = "1.0.1"
DEFAULT_MAX_REQUEST_BYTES = 64 * 1024 * 1024


def _job_import_bundle(context: JobContext) -> JobResult:
    """Replayable bundle-import body used by fresh and recovered workers."""
    payload = import_bundle_bytes(
        context.store, context.inputs["request"], created_by=context.actor
    )
    context.log(f"imported case {payload['case_id']}")
    return JobResult(
        outputs=payload,
        events=[{"event": "registry.imported",
                 "detail": {"case_id": payload["case_id"],
                            "objects": payload["objects_imported"]}}],
    )


JOB_BODIES: Dict[str, Callable[[JobContext], JobResult]] = {
    "importRegistry": ops.op_import,
    "generateFamily": ops.op_generate,
    "evaluateFamily": ops.op_evaluate,
    "buildGeometry": ops.op_geometry,
    "certifyCase": ops.op_certify,
    "classifyChange": ops.op_change,
    "recomputeCase": ops.op_recompute,
    "planConversion": ops.op_convert,
    "planQualification": ops.op_qualification_plan,
    "migrateCase": ops.op_migrate,
    "assembleTechnologyContract": ops.op_technology_contract,
    "importBundle": _job_import_bundle,
}

#: What this server says about itself when no security gate is configured
#: (44.2, 51, 60).  Quoted here rather than imported from ``crg-security``:
#: this package depends on the standard library and ``crg-model`` only (9.2),
#: and the ability to disclose that authentication is absent must not itself
#: depend on the optional package that would have provided authentication.
#: ``crg_security.gate.NO_AUTHENTICATION_CONFIGURED`` carries the same text and
#: the security suite asserts the two are identical, so the duplication cannot
#: drift silently.
NO_AUTHENTICATION_CONFIGURED = (
    "NO AUTHENTICATION CONFIGURED.  This server is accepting the X-CRG-Actor "
    "header as an unverified assertion of identity and is enforcing no "
    "authentication, no tenant separation, and no attribute-based policy.  "
    "Specification 44.2 requires the enterprise profile to support local "
    "accounts, OIDC, SAML where required, and service identities; none of them "
    "is active.  Operation-level role checks apply only if a static role table "
    "was supplied.  Do not expose this deployment to an untrusted network."
)


# ---------------------------------------------------------------------------
# the endpoint table (38.3) -- data, so that OpenAPI is generated and not typed
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class Endpoint:
    """One row of specification 38.3, plus what the surface must say about it."""

    method: str
    path: str
    operation_id: str
    summary: str
    spec: str
    long_running: bool = False
    success_status: int = 200
    content_addressed: bool = False
    case_scoped: bool = False
    request_fields: Tuple[str, ...] = ()
    failure_statuses: Tuple[int, ...] = ()
    produces: str = "application/json"
    #: Extra documented query parameters, ``(name, description)``.  Declared
    #: on the row rather than inferred, because a generated client can only
    #: offer a parameter the description names (38.2, 6.12).
    query_parameters: Tuple[Tuple[str, str], ...] = ()
    #: Extra documented request headers, ``(name, description)``.
    header_parameters: Tuple[Tuple[str, str], ...] = ()
    #: A response that is delivered as a stream of framed chunks rather than
    #: as one body (38.2).  The OpenAPI description says so, so a generated
    #: client knows to iterate rather than to read.
    streaming: bool = False

    @property
    def parameters(self) -> Tuple[str, ...]:
        return tuple(re.findall(r"\{([^}]+)\}", self.path))


#: What a subscriber may say to an SSE endpoint (38.2).  ``event`` is checked
#: against the closed vocabulary of 38.5 and a name outside it is a 400, so
#: these are not free-text filters.
_STREAM_QUERY_PARAMETERS: Tuple[Tuple[str, str], ...] = (
    ("event", "Comma-separated event names from the 38.5 vocabulary.  A name "
              "outside the vocabulary is refused (6.6)."),
    ("case_id", "Restrict the stream to one case."),
    ("branch_id", "Restrict the stream to one branch (16.2)."),
    ("since", "Resume from this event ordinal.  Last-Event-ID takes precedence."),
    ("follow", "'false' returns the framed backlog and closes; the default holds "
               "the connection open."),
)

#: The scoped stream takes its case from the route, so it does not accept a
#: ``case_id`` query parameter: a scope that a query string could widen is a
#: scope the deployment's authorization table never saw (44.3).
_SCOPED_STREAM_QUERY_PARAMETERS: Tuple[Tuple[str, str], ...] = tuple(
    row for row in _STREAM_QUERY_PARAMETERS if row[0] != "case_id"
)

_STREAM_HEADER_PARAMETERS: Tuple[Tuple[str, str], ...] = (
    ("Last-Event-ID", "38.2 resumption.  The ordinal of the last record received; "
                      "the server replays exactly what was missed, with no gap "
                      "and no duplicate."),
)


#: Specification 38.3 verbatim, in its own order, plus the job, event, and
#: description endpoints 38.2 requires an asynchronous, machine-readable
#: surface to have.
ENDPOINTS: Tuple[Endpoint, ...] = (
    Endpoint("GET", "/health/live", "healthLive", "Process liveness probe",
             "42, 44", failure_statuses=()),
    Endpoint("GET", "/health/ready", "healthReady", "Dependency readiness probe",
             "42, 44", failure_statuses=(503,)),
    Endpoint("GET", "/metrics", "getMetrics", "Prometheus operational metrics",
             "42, 47", produces="text/plain", failure_statuses=()),
    Endpoint("POST", "/cases", "createCase", "Create a case", "11, 38.3",
             success_status=201, content_addressed=True,
             request_fields=("case_id", "title", "owner", "contract"),
             failure_statuses=(400, 401, 403, 409)),
    Endpoint("GET", "/cases/{case_id}", "getCase", "Read a case version",
             "11.2, 38.3", case_scoped=True, failure_statuses=(404, 410)),
    Endpoint("POST", "/cases/{case_id}/validate", "validateCase",
             "Validate a case structurally", "11.1, 38.3", case_scoped=True,
             content_addressed=True, failure_statuses=(400, 404, 422)),
    Endpoint("POST", "/cases/{case_id}/branches", "createBranch",
             "Branch a case", "16.2, 38.3", success_status=201, case_scoped=True,
             request_fields=("name", "purpose", "creator", "access_policy",
                             "intended_decision_scope", "expected_reconciliation"),
             failure_statuses=(400, 404, 409)),
    Endpoint("POST", "/cases/{case_id}/merge", "mergeCase",
             "Request a merge; semantic objects are never merged automatically",
             "16.3, 16.4, 38.3", case_scoped=True,
             request_fields=("source_case_id", "registered_rules"),
             failure_statuses=(400, 404, 409)),
    Endpoint("POST", "/cases/{case_id}/import", "importRegistry",
             "Import a candidate registry", "37, 38.3", long_running=True,
             success_status=202, case_scoped=True,
             request_fields=("rows", "source_path", "mapping", "completeness_basis"),
             failure_statuses=(400, 404, 409)),
    Endpoint("POST", "/cases/{case_id}/generate", "generateFamily",
             "Generate a legal realization family", "28, 38.3", long_running=True,
             success_status=202, case_scoped=True,
             request_fields=("generator", "seeds", "schema", "parameters", "max_depth",
                             "max_size"),
             failure_statuses=(400, 404, 409, 422)),
    Endpoint("POST", "/cases/{case_id}/evaluate", "evaluateFamily",
             "Evaluate the compiled objective over the family", "22.2, 38.3",
             long_running=True, success_status=202, case_scoped=True,
             failure_statuses=(400, 404, 409)),
    Endpoint("POST", "/cases/{case_id}/geometry", "buildGeometry",
             "Build canonical exact R, Gamma, and K", "19, 38.3", long_running=True,
             success_status=202, case_scoped=True, request_fields=("objects",),
             failure_statuses=(400, 404, 409)),
    Endpoint("POST", "/cases/{case_id}/queries/compile", "compileQuery",
             "Compile a decision query to its minimum sufficient object",
             "26, 38.3", case_scoped=True, request_fields=("query",),
             failure_statuses=(400, 404, 422)),
    Endpoint("POST", "/cases/{case_id}/certify", "certifyCase",
             "Issue a decision certificate", "29, 38.3", long_running=True,
             success_status=202, case_scoped=True, request_fields=("retained",),
             failure_statuses=(400, 404, 409, 422)),
    Endpoint("POST", "/cases/{case_id}/changes", "classifyChange",
             "Classify a change and recompute the minimum valid amount",
             "30, 38.3", long_running=True, success_status=202, case_scoped=True,
             request_fields=("set", "weight", "reason", "authority", "approvals"),
             failure_statuses=(400, 404, 409)),
    Endpoint("POST", "/cases/{case_id}/recompute", "recomputeCase",
             "Recompute the certificates of a case", "30.3, 38.3", long_running=True,
             success_status=202, case_scoped=True, failure_statuses=(400, 404, 409)),
    Endpoint("POST", "/cases/{case_id}/convert", "planConversion",
             "Plan an ownership or layout conversion", "31, 38.3", long_running=True,
             success_status=202, case_scoped=True, request_fields=("source", "target"),
             failure_statuses=(400, 404, 409)),
    Endpoint("POST", "/cases/{case_id}/qualification-plans", "planQualification",
             "Rank the experiments that would resolve a qualification", "34, 38.3",
             long_running=True, success_status=202, case_scoped=True,
             request_fields=("experiments", "burden_weights"),
             failure_statuses=(400, 404, 409)),
    Endpoint("POST", "/cases/{case_id}/evaluator-requests", "createEvaluatorRequest",
             "Record a physical-evaluator request", "32.1, 38.3", success_status=201,
             case_scoped=True, request_fields=("evaluator_request",),
             failure_statuses=(400, 404)),
    Endpoint("GET", "/cases/{case_id}/dependencies", "getDependencies",
             "Read the typed dependency graph", "18, 38.3", case_scoped=True,
             failure_statuses=(404,)),
    Endpoint("GET", "/cases/{case_id}/certificates", "listCertificates",
             "List the certificates of a case with their 17.1 statuses",
             "29.4, 17.1, 38.3", case_scoped=True, failure_statuses=(404,)),
    Endpoint("POST", "/cases/{case_id}/migrate", "migrateCase",
             "Migrate a case to a target schema version", "15.3, 38.3",
             long_running=True, success_status=202, case_scoped=True,
             request_fields=("target_schema_version", "transform_id", "migration_class",
                             "authority"),
             failure_statuses=(400, 404, 409)),
    Endpoint("POST", "/cases/{case_id}/redact", "redactObject",
             "Remove content and leave a tombstone", "17.2, 17.3, 38.3",
             case_scoped=True, request_fields=("object_hash", "reason", "authority"),
             failure_statuses=(400, 404, 409)),
    Endpoint("POST", "/retention/policies", "createRetentionPolicy",
             "Register an immutable operational retention policy",
             "17, 42.1, 44.5", success_status=201,
             request_fields=("policy_id", "version", "object_types",
                             "minimum_age_seconds", "action", "reason",
                             "effective_at", "enabled", "eligible_statuses",
                             "predecessor_hash", "permitted_disclosure", "authority"),
             failure_statuses=(400, 401, 403, 404, 409)),
    Endpoint("GET", "/retention/policies", "listRetentionPolicies",
             "List retention policies and their lifecycle state", "17, 44.5",
             failure_statuses=(401, 403)),
    Endpoint("POST", "/retention/evaluate", "evaluateRetention",
             "Run and durably record a bounded retention dry run", "17, 42.1, 44.5",
             request_fields=("policy_hash", "authority", "limit", "after_hash"),
             failure_statuses=(400, 401, 403, 404, 409)),
    Endpoint("POST", "/retention/enforce", "enforceRetention",
             "Enforce one bounded, resumable retention batch", "17, 42.1, 44.5",
             request_fields=("policy_hash", "authority", "limit", "after_hash"),
             failure_statuses=(400, 401, 403, 404, 409)),
    Endpoint("POST", "/objects/{object_hash}/legal-hold", "setObjectLegalHold",
             "Place or release an audited legal hold", "17.5, 42.3, 44.5",
             request_fields=("held", "authority"),
             failure_statuses=(400, 401, 403, 404, 409)),
    Endpoint("POST", "/evidence", "registerEvidence", "Register an evidence record",
             "33.2, 38.3", success_status=201, content_addressed=True,
             request_fields=("evidence", "clock"), failure_statuses=(400, 401, 403)),
    Endpoint("POST", "/technology-contracts/assemble", "assembleTechnologyContract",
             "Assemble a technology contract", "33.6, 38.3", long_running=True,
             success_status=202, content_addressed=True,
             request_fields=("evidence", "rules", "target_context", "coordinates", "clock"),
             failure_statuses=(400, 401, 403)),
    Endpoint("POST", "/capability-envelopes", "issueCapabilityEnvelope",
             "Issue a capability envelope", "35.2, 38.3", success_status=201,
             request_fields=("bounded_result", "target_context", "rule", "key", "validity",
                             "nonce", "release_policy"),
             failure_statuses=(400, 401, 403)),
    Endpoint("POST", "/capability-envelopes/{subject_id}/revoke",
             "revokeCapability", "Revoke a capability envelope, evidence root, or key",
             "35.4, 38.3, 44.7", request_fields=("reason",),
             failure_statuses=(400, 401, 403, 409)),
    Endpoint("POST", "/private-evaluations", "evaluatePrivately",
             "Evaluate a capability predicate confidentially", "35.3, 38.3",
             request_fields=("typed_envelope", "predicate", "keys", "release_policy"),
             failure_statuses=(400, 401, 403)),
    Endpoint("POST", "/transitions/{plan_id}/execute", "executeTransition",
             "Execute an authorized runtime transition through a domain adapter",
             "32.4, 32.5, 38.5", request_fields=("executor_id", "clock", "case_id", "branch_id"),
             failure_statuses=(400, 401, 403, 409, 422)),
    Endpoint("POST", "/bundles/import", "importBundle", "Import a portable .crg bundle",
             "39, 38.3", long_running=True, success_status=202,
             request_fields=("bundle_base64", "case_id"),
             failure_statuses=(400, 401, 409, 413)),
    Endpoint("POST", "/bundles/verify", "verifyBundle",
             "Verify a portable bundle with the independent verifier", "25, 39, 38.3",
             request_fields=("bundle_base64", "level", "clock", "clock_source"),
             failure_statuses=(400, 413, 422)),
    Endpoint("GET", "/bundles/{bundle_id}/export", "exportBundle",
             "Export a case as a portable .crg bundle", "39, 38.3",
             produces="application/zip", failure_statuses=(400, 404),
             query_parameters=(
                 ("version", "Case version ordinal or content hash to export."),
                 ("authority", "Authority identifier recorded in the bundle manifest."),
             )),
    # -- asynchronous job API and event stream (38.2) ----------------------
    Endpoint("GET", "/jobs/{job_id}", "getJob", "Read a job record", "42.4, 38.2",
             failure_statuses=(404,)),
    Endpoint("GET", "/jobs/{job_id}/result", "getJobResult",
             "Read a job result; blocked outcomes are 422 and failures are 409",
             "42.4, 6.6", failure_statuses=(404, 409, 422)),
    Endpoint("POST", "/jobs/{job_id}/cancel", "cancelJob",
             "Cancel queued work or safely interrupt an isolated running job",
             "42.4", failure_statuses=(404, 409)),
    Endpoint("POST", "/jobs/{job_id}/retry", "retryJob", "Retry a terminal job",
             "42.4", success_status=202, failure_statuses=(404, 409)),
    Endpoint("GET", "/events", "listEvents", "Read the emitted event log",
             "38.5", failure_statuses=(),
             query_parameters=(("since", "Return events after this zero-based ordinal."),)),
    Endpoint("GET", "/audit/export", "exportAudit",
             "Export a bounded tenant security-audit artifact",
             "42.3, 44.5, 44.7", failure_statuses=(400, 401, 403, 503),
             query_parameters=(
                 ("after_sequence", "Exclusive zero-based cursor; use -1 for the first page."),
                 ("limit", "Maximum entries in this page; an integer from 1 through 1000."),
                 ("authority", "Named records authority accountable for this export."),
             )),
    Endpoint("GET", "/events/stream", "streamEvents",
             "Subscribe to the event stream (Server-Sent Events)", "38.2, 38.5",
             produces="text/event-stream", streaming=True,
             failure_statuses=(400,),
             query_parameters=_STREAM_QUERY_PARAMETERS,
             header_parameters=_STREAM_HEADER_PARAMETERS),
    Endpoint("GET", "/cases/{case_id}/events/stream", "streamCaseEvents",
             "Subscribe to one case's event stream (Server-Sent Events)",
             "38.2, 38.5", produces="text/event-stream", streaming=True,
             failure_statuses=(400, 404),
             query_parameters=_SCOPED_STREAM_QUERY_PARAMETERS,
             header_parameters=_STREAM_HEADER_PARAMETERS),
    Endpoint("POST", "/webhooks/subscriptions", "createWebhookSubscription",
             "Register a signed webhook subscription", "38.2, 38.5, 44.4",
             success_status=201,
             request_fields=("endpoint", "secret", "events", "subscription_id",
                             "max_attempts", "base_delay_seconds",
                             "backoff_factor", "max_delay_seconds", "enabled"),
             failure_statuses=(400, 401, 403, 409)),
    Endpoint("GET", "/webhooks/subscriptions", "listWebhookSubscriptions",
             "List webhook subscriptions without secret material", "38.2, 44.4",
             failure_statuses=(401, 403)),
    Endpoint("DELETE", "/webhooks/subscriptions/{subscription_id}",
             "deleteWebhookSubscription", "Delete a webhook subscription",
             "38.2, 44.4, 44.7", failure_statuses=(401, 403, 404)),
    Endpoint("GET", "/openapi.json", "getOpenApi", "The OpenAPI 3.1 description",
             "38.2", failure_statuses=()),
)

#: Specification 44.3's minimum roles, mapped onto the operations they gate.
#: Enforced only when the deployment supplies a role table; a deployment that
#: supplies none is single-tenant and identified-only, which 44.2 permits for
#: the standalone profile while requiring the enterprise profile to do more.
ROLE_REQUIREMENTS: Dict[str, Tuple[str, ...]] = {
    "createCase": ("Contributor", "System Administrator"),
    "importRegistry": ("Registry Importer", "Contributor"),
    "generateFamily": ("Generator Author", "Contributor"),
    "certifyCase": ("Decision Approver", "Contributor"),
    "recomputeCase": ("Decision Approver", "Contributor"),
    "classifyChange": ("Contributor",),
    "redactObject": ("Security Administrator", "System Administrator"),
    "createRetentionPolicy": ("Security Administrator", "System Administrator"),
    "listRetentionPolicies": ("Security Administrator", "System Administrator"),
    "evaluateRetention": ("Security Administrator", "System Administrator"),
    "enforceRetention": ("Security Administrator",),
    "setObjectLegalHold": ("Security Administrator",),
    "migrateCase": ("System Administrator",),
    "registerEvidence": ("Evidence Steward", "Contributor"),
    "assembleTechnologyContract": ("Evidence Steward", "Contributor"),
    "issueCapabilityEnvelope": ("Federation Operator", "Certificate Signer"),
    "evaluatePrivately": ("Federation Operator", "Viewer"),
    "revokeCapability": ("Federation Operator", "Security Administrator"),
    "planQualification": ("Qualification Author", "Contributor"),
    "importBundle": ("Contributor", "System Administrator"),
    "createWebhookSubscription": ("System Administrator",),
    "listWebhookSubscriptions": ("System Administrator",),
    "deleteWebhookSubscription": ("System Administrator",),
    "executeTransition": ("System Administrator",),
    "exportAudit": ("Auditor",),
}


# ---------------------------------------------------------------------------
# request and response
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class Request:
    """A decoded request at the integration boundary (spec 10.1)."""

    method: str
    path: str
    query: Mapping[str, str] = field(default_factory=dict)
    headers: Mapping[str, str] = field(default_factory=dict)
    body: Any = None
    actor: str = ""
    correlation_id: str = ""
    idempotency_key: Optional[str] = None

    def json_body(self) -> Dict[str, Any]:
        if self.body is None:
            return {}
        if not isinstance(self.body, Mapping):
            raise UsageError(
                "the request body must be a JSON object",
                remedy="every typed request in 38.3 is an object, not an array or a scalar",
            )
        return dict(self.body)


@dataclass
class Response:
    """A response, JSON unless an endpoint declares otherwise."""

    status: int
    body: Any = None
    headers: Dict[str, str] = field(default_factory=dict)
    raw: Optional[bytes] = None
    content_type: str = "application/json"
    #: An optional iterable of already-framed byte chunks (38.2 event
    #: streaming).  Additive and defaulted, so every existing construction of
    #: a ``Response`` and every existing reader of ``payload()`` behaves
    #: exactly as before: a caller that ignores this field sees the framed
    #: snapshot in ``raw`` and a complete, well-formed body.  A transport
    #: that knows about it -- :func:`make_handler`, and the WSGI adapter --
    #: writes and flushes each chunk as it arrives instead.
    stream: Optional[Any] = None

    def payload(self) -> bytes:
        if self.raw is not None:
            return self.raw
        if self.body is None:
            return b""
        return canonical_json(self.body).encode("utf-8")

    @property
    def ok(self) -> bool:
        return 200 <= self.status < 300


# ---------------------------------------------------------------------------
# the application
# ---------------------------------------------------------------------------
class Application:
    """The routed integration surface.

    Callable two ways: :meth:`dispatch` for an in-process client (which is how
    the tests drive it, so no socket is required to test the semantics), and
    ``__call__`` as a WSGI application for a deployment that already has a
    server.  :func:`make_handler` adapts the same object to
    :mod:`http.server`.
    """

    def __init__(
        self,
        store: CaseStore,
        queue: JobQueue,
        *,
        events: Optional[EventBus] = None,
        roles: Optional[Mapping[str, Sequence[str]]] = None,
        default_actor: Optional[str] = None,
        security: Optional[Any] = None,
        federation_verifier_context: Optional[Any] = None,
        extension_checker_registry: Optional[Any] = None,
        webhooks: Optional[WebhookDispatcher] = None,
        transition_executor: Optional[Callable[..., Any]] = None,
        telemetry: Optional[Any] = None,
        max_request_bytes: int = DEFAULT_MAX_REQUEST_BYTES,
    ) -> None:
        self.store = store
        self.queue = queue
        self.events = events or getattr(queue, "events", None) or EventBus(store)
        if getattr(queue, "events", None) is None:
            queue.events = self.events
        self.roles = {k: tuple(v) for k, v in (roles or {}).items()}
        self.default_actor = default_actor
        #: An optional, duck-typed security gate (44.2).  ``None`` -- the
        #: default -- is the behaviour this server had before ``crg-security``
        #: existed: the ``X-CRG-Actor`` header is an unverified assertion and
        #: the only authorization is the static role table above.  A gate is
        #: anything exposing ``authenticate(request)``, ``authorize(...)``, and
        #: ``disclosure()``; :class:`crg_security.gate.ServerSecurityGate` is
        #: one, and so is whatever a deployment writes instead.  Typed as
        #: ``Any`` on purpose: importing the security package to name the type
        #: would make an optional dependency a real one.
        self.security = security
        # Verifier-owned V4 trust state.  This may be a mapping or a callable
        # returning one for a request.  It is deliberately deployment-owned:
        # accepting keys, revocations, or a nonce ledger from the request body
        # would let the envelope choose the authority that verifies it.
        self.federation_verifier_context = federation_verifier_context
        # Optional §24.6 registry configured by the verifier deployment.  A
        # request can select only a checker already present here; it cannot
        # load code or alter the registered declaration.
        self.extension_checker_registry = extension_checker_registry
        # Domain-neutral runtime control owns the safety logic in
        # ``crg-feedback``; applying a physical configuration necessarily
        # belongs to a deployment adapter.  The adapter returns the canonical
        # TransitionRecord, which this boundary validates, stores and emits.
        self.transition_executor = transition_executor
        # The REST subscription control plane and the event fan-out share one
        # dispatcher.  Registration secrets remain in dispatcher memory and
        # are never written to the audit log or returned by the API (44.4).
        # Production deployments that need restart-safe delivery additionally
        # run DurableWebhookPump over environment-backed subscriptions.
        self.webhooks = webhooks or WebhookDispatcher()
        self._unsubscribe_webhooks = self.webhooks.subscribe_to(self.events)
        if telemetry is None:
            from .telemetry import OtlpTelemetry
            telemetry = OtlpTelemetry()
        self.telemetry = telemetry
        self._draining = False
        self.max_request_bytes = int(max_request_bytes)
        if self.max_request_bytes <= 0:
            raise ValueError("max_request_bytes must be positive")
        for kind, body in JOB_BODIES.items():
            self.queue.register(kind, body)
        if self.queue.autorun:
            self.queue.start_worker()
        self._routes: List[Tuple[Endpoint, re.Pattern]] = [
            (endpoint, self._compile(endpoint.path)) for endpoint in ENDPOINTS
        ]
        self._metrics_lock = threading.Lock()
        self._request_counts: Dict[Tuple[str, int], int] = {}
        self._request_seconds: Dict[str, float] = {}

    @property
    def draining(self) -> bool:
        """Whether this process has closed mutation admission for shutdown."""
        return bool(self._draining or getattr(self.queue, "draining", False))

    def begin_drain(self) -> Dict[str, Any]:
        """Make readiness fail and atomically close new job admission.

        Reads, health/liveness, metrics, job inspection, and cancellation stay
        available while acknowledged work finishes.  Other mutations receive
        a typed 503, which is safer than accepting work after the orchestrator
        has committed to removing this instance.
        """
        self._draining = True
        snapshot = self.queue.begin_drain()
        snapshot["service"] = "crg-server"
        snapshot["status"] = "DRAINING"
        return snapshot

    def _external_worker_health(self) -> Tuple[bool, int, Optional[float]]:
        if str(getattr(self.queue, "execution_mode", "")) != "external":
            return True, 1 if self.queue.worker_alive else 0, None
        maximum = float(getattr(self.queue, "worker_heartbeat_max_age_seconds", 120))
        latest: Dict[str, float] = {}
        try:
            records = self.store.audit_records()
        except Exception:
            return False, 0, None
        for row in records:
            event = row.get("event") or {}
            if event.get("record_type") != "WorkerHeartbeat":
                continue
            worker_id = str(event.get("worker_id") or "")
            timestamp = str(event.get("timestamp") or row.get("recorded_at") or "")
            try:
                instant = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
                seconds = instant.astimezone(timezone.utc).timestamp()
            except (ValueError, TypeError):
                continue
            if worker_id:
                latest[worker_id] = max(seconds, latest.get(worker_id, seconds))
        now = time.time()
        ages = [max(0.0, now - value) for value in latest.values()]
        active = [age for age in ages if age <= maximum]
        return bool(active), len(active), min(ages) if ages else None

    # -- routing -----------------------------------------------------------
    @staticmethod
    def _compile(path: str) -> "re.Pattern":
        pattern = re.sub(r"\{([^}]+)\}", lambda m: f"(?P<{m.group(1)}>[^/]+)", path)
        return re.compile(f"^{pattern}$")

    def resolve(self, method: str, path: str) -> Tuple[Endpoint, Dict[str, str]]:
        allowed: List[str] = []
        for endpoint, pattern in self._routes:
            match = pattern.match(path)
            if not match:
                continue
            if endpoint.method != method:
                allowed.append(endpoint.method)
                continue
            return endpoint, {k: v for k, v in match.groupdict().items()}
        if allowed:
            raise MethodNotAllowedError(
                f"{method} is not defined on {path}",
                remedy=f"this route accepts {sorted(set(allowed))}",
            )
        raise NotFoundError(
            f"no endpoint {method} {path}",
            remedy="GET /openapi.json lists every endpoint this server implements (38.2)",
        )

    # -- entry point --------------------------------------------------------
    def dispatch(self, request: Request) -> Response:
        started = time.monotonic()
        supplied_correlation = str(request.correlation_id or "")
        correlation_id = (
            supplied_correlation
            if len(supplied_correlation) <= 128
            and re.fullmatch(r"[A-Za-z0-9._:-]+", supplied_correlation)
            else new_object_id("corr")
        )
        if request.correlation_id != correlation_id:
            request = replace(request, correlation_id=correlation_id)
        try:
            traced_endpoint = self.resolve(request.method, request.path)[0]
            operation = traced_endpoint.operation_id
            route_template = traced_endpoint.path
        except ServerError:
            operation = "unresolved"
            route_template = "unresolved"
        span = self.telemetry.start(
            name=f"{request.method} {operation}",
            traceparent=request.headers.get("traceparent", ""),
        )
        response = self._dispatch(request)
        elapsed = time.monotonic() - started
        response.headers.setdefault("X-CRG-Correlation-Id", correlation_id)
        response.headers.setdefault("X-CRG-Spec-Version", SPEC_VERSION)
        response.headers.setdefault(
            "X-CRG-Authentication", self._authentication_header()
        )
        response.headers.setdefault("traceparent", span.traceparent)
        self.telemetry.finish(span, {
            "http.request.method": request.method,
            "http.route": route_template,
            "http.response.status_code": response.status,
            "crg.operation": operation,
            "crg.correlation_id": response.headers.get("X-CRG-Correlation-Id", ""),
        })
        with self._metrics_lock:
            key = (operation, response.status)
            self._request_counts[key] = self._request_counts.get(key, 0) + 1
            self._request_seconds[operation] = self._request_seconds.get(operation, 0.0) + elapsed
        return response

    def _dispatch(self, request: Request) -> Response:
        correlation_id = request.correlation_id or new_object_id("corr")
        try:
            endpoint, parameters = self.resolve(request.method, request.path)
        except ServerError as error:
            return Response(error.status, error_body(error))

        actor = request.actor or self.default_actor or ""
        principal = None
        try:
            if self.security is not None:
                # A configured gate establishes identity *before* the header is
                # consulted, and the identity it establishes replaces the
                # header rather than supplementing it: an authenticated caller
                # must not be able to attribute their actions to somebody else
                # by also sending X-CRG-Actor (44.7).
                principal = self._gate_authenticate(request)
                if principal is not None:
                    actor = str(getattr(principal, "subject_id", "") or actor)
                    store_tenant = str(getattr(self.store, "tenant_id", "") or "")
                    principal_tenant = str(getattr(principal, "tenant_id", "") or "")
                    if store_tenant and principal_tenant != store_tenant:
                        raise ForbiddenError(
                            f"principal authenticated into tenant {principal_tenant!r} "
                            f"cannot access storage bound to {store_tenant!r}",
                            remedy=(
                                "44.5: route the credential to its tenant deployment; "
                                "a request cannot select or widen the storage partition"
                            ),
                            detail={"principal_tenant": principal_tenant,
                                    "storage_tenant": store_tenant},
                        )
            if request.method in {"POST", "PUT", "PATCH", "DELETE"} and not actor:
                raise UnauthorizedError(
                    "this request carried no actor identity",
                    remedy="send X-CRG-Actor; 44.7 requires every mutating operation to be "
                           "attributable to an identity",
                )
            self._authorize(endpoint, actor)
            self._gate_authorize(endpoint, principal, request, parameters)
            replay = self._idempotent_replay(endpoint, request, parameters)
            if replay is not None:
                return replay
            if (
                self.draining
                and request.method in {"POST", "PUT", "PATCH", "DELETE"}
                and endpoint.operation_id != "cancelJob"
            ):
                raise ServiceUnavailableError(
                    "this CRG instance is draining and refuses new mutations",
                    remedy="retry against an instance whose /health/ready status is READY",
                    detail={"operation": endpoint.operation_id, "draining": True},
                )
            handler = getattr(self, f"_op_{endpoint.operation_id}")
            response = handler(
                request=request,
                parameters=parameters,
                endpoint=endpoint,
                actor=actor,
                principal=principal,
                correlation_id=correlation_id,
            )
            self._record_idempotent(endpoint, request, parameters, response)
            response.headers.setdefault("X-CRG-Correlation-Id", correlation_id)
            response.headers.setdefault("X-CRG-Spec-Version", SPEC_VERSION)
            response.headers.setdefault(
                "X-CRG-Authentication", self._authentication_header()
            )
            return response
        except ServerError as error:
            self.store.append_audit(
                {
                    "event": "request.refused",
                    "operation": endpoint.operation_id,
                    "status": error.status,
                    "category": error.category,
                    "actor": actor,
                    "correlation_id": correlation_id,
                    "message": error.message,
                    "recorded_at": utc_now(),
                }
            )
            return Response(
                error.status,
                error_body(error),
                headers={
                    "X-CRG-Correlation-Id": correlation_id,
                    "X-CRG-Authentication": self._authentication_header(),
                },
            )
        except CaseError as error:
            failure = UsageError(str(error))
            return Response(failure.status, error_body(failure))
        except (ValueError, KeyError, TypeError) as error:
            failure = UsageError(f"{type(error).__name__}: {error}")
            return Response(failure.status, error_body(failure))

    def __call__(self, environ: Mapping[str, Any], start_response: Callable) -> List[bytes]:
        """WSGI adapter (spec 38.2)."""
        length = int(environ.get("CONTENT_LENGTH") or 0)
        if length > self.max_request_bytes:
            error = PayloadTooLargeError(
                f"request body is {length} bytes; limit is {self.max_request_bytes}",
                remedy="send a smaller typed request or use an authorized bounded artifact channel",
            )
            response = Response(error.status, error_body(error))
            payload = response.payload()
            start_response(
                f"{response.status} {_reason(response.status)}",
                [("Content-Type", response.content_type),
                 ("Content-Length", str(len(payload)))],
            )
            return [payload]
        raw = environ["wsgi.input"].read(length) if length else b""
        headers = {
            key[5:].replace("_", "-").title(): str(value)
            for key, value in environ.items()
            if key.startswith("HTTP_")
        }
        if environ.get("CONTENT_TYPE"):
            headers["Content-Type"] = str(environ["CONTENT_TYPE"])
        request = build_request(
            environ.get("REQUEST_METHOD", "GET"),
            environ.get("PATH_INFO", "/") + (
                "?" + environ["QUERY_STRING"] if environ.get("QUERY_STRING") else ""
            ),
            raw,
            headers,
        )
        response = self.dispatch(request)
        if response.stream is not None:
            # 38.2: a stream has no length to declare and must not be
            # buffered into one.  The WSGI server writes each framed chunk
            # as the iterable produces it.
            header_list = [("Content-Type", response.content_type)]
            header_list.extend(response.headers.items())
            start_response(f"{response.status} {_reason(response.status)}", header_list)
            return response.stream
        payload = response.payload()
        header_list = [("Content-Type", response.content_type),
                       ("Content-Length", str(len(payload)))]
        header_list.extend(response.headers.items())
        start_response(f"{response.status} {_reason(response.status)}", header_list)
        return [payload]

    # -- optional security gate (44.2, 44.5, 44.7) -------------------------
    def _gate_authenticate(self, request: Request) -> Any:
        """Ask the configured gate who this is.  Any refusal becomes a 401/403.

        Wrapped so that a gate raising its own exception type -- which it will,
        since it is not required to import this package -- still leaves the
        boundary as a typed response rather than a traceback.  See
        :func:`crg_server.errors.from_security_error` for why an exception with
        no ``status`` becomes a 500 instead of a denial.
        """
        try:
            return self.security.authenticate(request)
        except Exception as error:  # noqa: BLE001 - adapted, never swallowed
            raise from_security_error(error) from error

    def _gate_authorize(
        self,
        endpoint: Endpoint,
        principal: Any,
        request: Request,
        parameters: Mapping[str, str],
    ) -> None:
        """Ask the configured gate whether this operation may proceed (44.2)."""
        if self.security is None:
            return
        try:
            self.security.authorize(
                operation_id=endpoint.operation_id,
                principal=principal,
                parameters=dict(parameters),
                request=request,
            )
        except Exception as error:  # noqa: BLE001 - adapted, never swallowed
            raise from_security_error(error) from error

    def _authentication_header(self) -> str:
        """The one-token summary carried on every response (51, 60).

        ``none-configured`` is a disclosure, not a detail.  A deployment that
        believes it enabled authentication and did not can see the truth in any
        response it looks at, which is the cheapest possible place to find out.
        """
        if self.security is None:
            return "none-configured"
        return "configured" if getattr(self.security, "enabled", True) else "none-configured"

    def security_disclosure(self) -> Dict[str, Any]:
        """What this deployment actually enforces (44.2, 44.5, 44.7, 51, 60).

        Deliberately a method rather than an endpoint: adding a path would
        change the OpenAPI document and therefore the surface every client and
        conformance profile is written against, and a disclosure is not an
        operation.  A deployment that wants to publish it can embed the result
        in whatever it already publishes.
        """
        if self.security is None:
            return {
                "authentication_configured": False,
                "disclosure": NO_AUTHENTICATION_CONFIGURED,
                "spec": "44.2, 44.5, 44.7",
                "actor_source": "X-CRG-Actor header, unverified",
                "authorization": (
                    "static role table"
                    if self.roles
                    else "none (no role table supplied)"
                ),
                "role_table_entries": len(self.roles),
                "tenant_separation": "none (single tenant, unenforced)",
            }
        try:
            record = dict(self.security.disclosure())
        except Exception as error:  # noqa: BLE001 - a gate that cannot describe itself
            return {
                "authentication_configured": True,
                "disclosure": (
                    "the configured security gate raised "
                    f"{type(error).__name__} when asked to describe itself; treat its "
                    "posture as unknown rather than as configured (6.6)"
                ),
            }
        record.setdefault("authentication_configured", True)
        record["static_role_table_entries"] = len(self.roles)
        store_tenant = str(getattr(self.store, "tenant_id", "") or "")
        record["storage_tenant_binding"] = (
            "enforced-single-tenant" if store_tenant else "unbound-embedding"
        )
        return record

    # -- authorization (44.2, 44.3) ----------------------------------------
    def _authorize(self, endpoint: Endpoint, actor: str) -> None:
        if not self.roles:
            return
        required = ROLE_REQUIREMENTS.get(endpoint.operation_id)
        if not required:
            return
        held = set(self.roles.get(actor, ()))
        # 44.2/44.3: System Administrator is not a role hierarchy root and
        # explicitly does not own audit:export.  Preserve that separation even
        # in the standalone static-role profile whose older operations retain
        # the compatibility administrator override below.
        if endpoint.operation_id == "exportAudit":
            if "Auditor" in held:
                return
            raise ForbiddenError(
                f"actor {actor!r} holds no role authorizing exportAudit",
                remedy="44.3: audit export requires the Auditor role",
                detail={"held_roles": sorted(held), "required_roles": ["Auditor"]},
            )
        if held & set(required) or "System Administrator" in held:
            return
        raise ForbiddenError(
            f"actor {actor!r} holds no role authorizing {endpoint.operation_id}",
            remedy=f"44.3: this operation requires one of {list(required)}",
            detail={"held_roles": sorted(held), "required_roles": list(required)},
        )

    # -- idempotency (38.4) -------------------------------------------------
    def _fingerprints(
        self, endpoint: Endpoint, request: Request, parameters: Mapping[str, str]
    ) -> Tuple[str, str]:
        """``(key_fingerprint, canonical_fingerprint)``.

        The *key* fingerprint covers the request alone: an idempotency key
        means "this is a retry of that request", and it must match on a retry
        even though the world moved on.  The *canonical* fingerprint also
        covers the case version the request would be computed against, so an
        unkeyed content-addressed replay is a hit only when nothing that would
        change the answer has changed -- 38.4's "when valid".
        """
        base = {
            "method": request.method,
            "path": request.path,
            "body": ops.redact_secrets(request.body),
        }
        key_fingerprint = content_hash(base)
        state: Optional[str] = None
        if endpoint.case_scoped and parameters.get("case_id"):
            versions = self.store.list_versions(str(parameters["case_id"]))
            state = versions[-1] if versions else None
        canonical_fingerprint = content_hash({**base, "case_state": state})
        return key_fingerprint, canonical_fingerprint

    def _idempotent_replay(
        self, endpoint: Endpoint, request: Request, parameters: Mapping[str, str]
    ) -> Optional[Response]:
        if request.method != "POST":
            return None
        key_fingerprint, canonical_fingerprint = self._fingerprints(
            endpoint, request, parameters
        )
        if request.idempotency_key:
            recorded = self.store.idempotent_lookup(request.idempotency_key)
            if recorded is not None:
                if str(recorded["request_hash"]) != key_fingerprint:
                    raise ConflictError(
                        "this idempotency key was used for a different request",
                        remedy="38.4: a key identifies one canonical request; use a new key",
                        detail={"idempotency_key": request.idempotency_key},
                    )
                return Response(
                    int(recorded["status"]),
                    json.loads(str(recorded["response_json"])),
                    headers={"Idempotency-Replayed": "true"},
                )
        if endpoint.content_addressed:
            recorded = self.store.canonical_lookup(canonical_fingerprint)
            if recorded is not None:
                return Response(
                    int(recorded["status"]),
                    json.loads(str(recorded["response_json"])),
                    headers={"CRG-Content-Addressed-Replay": "true"},
                )
        return None

    def _record_idempotent(
        self,
        endpoint: Endpoint,
        request: Request,
        parameters: Mapping[str, str],
        response: Response,
    ) -> None:
        if request.method != "POST" or not response.ok or response.raw is not None:
            return
        key_fingerprint, canonical_fingerprint = self._fingerprints(
            endpoint, request, parameters
        )
        if request.idempotency_key:
            self.store.idempotent_record(
                request.idempotency_key, key_fingerprint, response.body, response.status
            )
        if endpoint.content_addressed:
            self.store.canonical_record(
                canonical_fingerprint, response.body, response.status
            )

    # -- helpers ------------------------------------------------------------
    def _case(self, parameters: Mapping[str, str], request: Optional[Request] = None) -> Dict[str, Any]:
        case_id = str(parameters.get("case_id") or "")
        version = (request.query.get("version") if request else None)
        return self.store.get_case(case_id, version)

    def _emit(
        self,
        name: str,
        *,
        actor: str,
        correlation_id: str,
        case_id: Optional[str] = None,
        branch_id: Optional[str] = None,
        object_hashes: Sequence[str] = (),
        detail: Optional[Mapping[str, Any]] = None,
    ) -> None:
        self.events.emit(
            name,
            actor=actor,
            correlation_id=correlation_id,
            case_id=case_id,
            branch_id=branch_id,
            object_hashes=object_hashes,
            detail=detail,
        )

    def _submit(
        self,
        endpoint: Endpoint,
        body: Callable,
        *,
        request: Request,
        parameters: Mapping[str, str],
        actor: str,
        correlation_id: str,
        inputs: Optional[Mapping[str, Any]] = None,
        case: Optional[Mapping[str, Any]] = None,
    ) -> Response:
        """Enqueue work and answer with its identifier (spec 38.3)."""
        case_id = str(parameters.get("case_id") or (case or {}).get("case_id") or "") or None
        request_body = request.json_body()
        safe_request = ops.redact_secrets(request_body)
        if safe_request != request_body:
            raise UsageError(
                "a durable local job request contains secret-bearing fields",
                remedy="use an encrypted external-worker profile or replace secrets with "
                       "authorized key references; plaintext secrets are not persisted",
            )
        canonical_inputs: Dict[str, Any] = {
            "operation": endpoint.operation_id,
            "request": safe_request,
        }
        if inputs:
            canonical_inputs.update({k: ops.redact_secrets(v) for k, v in inputs.items()})
        payload: Dict[str, Any] = dict(canonical_inputs)
        payload["request"] = request_body
        if case is not None:
            payload["case"] = dict(case)
            payload["expected_parent_version"] = self.store.head_version(str(case["case_id"]))
        record = self.queue.submit(
            endpoint.operation_id,
            body,
            canonical_inputs=canonical_inputs,
            actor=actor,
            correlation_id=correlation_id,
            case_id=case_id,
            branch_id=str((case or {}).get("branch_id") or "") or None,
            _payload=payload,
        )
        return Response(
            202,
            {
                "job_id": record.job_id,
                "kind": record.kind,
                "status": record.status,
                "case_id": record.case_id,
                "input_hash": record.input_hash,
                "links": {
                    "job": f"/jobs/{record.job_id}",
                    "result": f"/jobs/{record.job_id}/result",
                },
                "note": "38.3: a long-running action returns a job identifier, not a result",
            },
        )

    # -- case endpoints -----------------------------------------------------
    def _op_createCase(self, *, request: Request, actor: str, correlation_id: str,
                       **_kwargs: Any) -> Response:
        body = request.json_body()
        case_id = str(body.get("case_id") or "")
        if not case_id:
            raise UsageError(
                "a case must be created with a case_id (11.1)",
                remedy="POST {'case_id': '...'}",
            )
        if self.store.case_exists(case_id):
            raise ConflictError(
                f"case {case_id!r} already exists",
                remedy="branch it (POST /cases/{case_id}/branches) or choose another identifier",
            )
        case = new_case(case_id, dict(body.get("contract") or {}))
        case["created_at"] = utc_now()
        case["created_by"] = actor
        case["branch_id"] = str(body.get("branch_id") or "main")
        case["title"] = str(body.get("title") or case_id)
        case["owner"] = str(body.get("owner") or actor)
        case["access_policy"] = str(body.get("access_policy") or "private")
        digest = self.store.put_case(case, created_by=actor)
        self._emit("case.created", actor=actor, correlation_id=correlation_id,
                   case_id=case_id, branch_id=case["branch_id"], object_hashes=[digest])
        return Response(
            201,
            {"case_id": case_id, "case_version": 1, "content_hash": digest,
             "status": case["status"], "branch_id": case["branch_id"]},
            headers={"Location": f"/cases/{case_id}"},
        )

    def _op_getCase(self, *, request: Request, parameters: Mapping[str, str],
                    **_kwargs: Any) -> Response:
        case_id = str(parameters["case_id"])
        case = self._case(parameters, request)
        return Response(
            200,
            {
                "case": case,
                "versions": self.store.list_versions(case_id),
                "head_version": self.store.head_version(case_id),
                "index": self.store.case_index(case_id),
            },
        )

    def _op_validateCase(self, *, parameters: Mapping[str, str], actor: str,
                         correlation_id: str, **_kwargs: Any) -> Response:
        case = self._case(parameters)
        report = ops.op_validate(case)
        if not report["valid"]:
            raise ScopeMismatchError(
                "this case is not structurally valid",
                remedy="every listed problem must be resolved before certification (6.6)",
                detail=report,
            )
        self._emit("case.validated", actor=actor, correlation_id=correlation_id,
                   case_id=str(parameters["case_id"]),
                   branch_id=str(case.get("branch_id") or "main"))
        return Response(200, report)

    def _op_createBranch(self, *, request: Request, parameters: Mapping[str, str],
                         actor: str, correlation_id: str, **_kwargs: Any) -> Response:
        body = request.json_body()
        case_id = str(parameters["case_id"])
        branch_case_id = create_branch(
            self.store,
            case_id,
            name=str(body.get("name") or ""),
            purpose=str(body.get("purpose") or ""),
            creator=str(body.get("creator") or actor),
            access_policy=str(body.get("access_policy") or "inherited"),
            intended_decision_scope=str(body.get("intended_decision_scope") or ""),
            expected_reconciliation=str(
                body.get("expected_reconciliation") or "MANUAL_RECONCILIATION"
            ),
            version=body.get("version"),
        )
        branch_case = self.store.get_case(branch_case_id)
        self._emit("case.branched", actor=actor, correlation_id=correlation_id,
                   case_id=branch_case_id, branch_id=str(branch_case.get("branch_id")),
                   detail={"parent_case": case_id})
        return Response(
            201,
            {
                "case_id": branch_case_id,
                "branch_id": branch_case.get("branch_id"),
                "derived_from": branch_case.get("derived_from"),
                "branch_record": branch_case.get("branch_record"),
                "active_certificates": sorted(branch_case.get("certificates") or {}),
                "inherited_certificates": sorted(
                    branch_case.get("inherited_certificates") or {}
                ),
                "note": "16.5: parent certificates are historical evidence on a branch",
            },
            headers={"Location": f"/cases/{branch_case_id}"},
        )

    def _op_mergeCase(self, *, request: Request, parameters: Mapping[str, str],
                      actor: str, correlation_id: str, **_kwargs: Any) -> Response:
        body = request.json_body()
        target = self._case(parameters)
        source_id = str(body.get("source_case_id") or "")
        if not source_id:
            raise UsageError("a merge must name its source case (16.4)")
        source = self.store.get_case(source_id)
        base = None
        explicit_base_id = str(body.get("base_case_id") or "")
        if explicit_base_id:
            base = self.store.get_case(explicit_base_id, body.get("base_version"))
        else:
            source_branch = source.get("branch_record") or {}
            target_branch = target.get("branch_record") or {}
            source_parent = str(source_branch.get("parent_case") or "")
            target_parent = str(target_branch.get("parent_case") or "")
            source_point = str(source_branch.get("branch_point") or "")
            target_point = str(target_branch.get("branch_point") or "")
            if (source_parent and source_parent == target_parent
                    and source_point and source_point == target_point):
                base = self.store.get_case(source_parent, source_point)
            elif source_parent == str(target.get("case_id") or "") and source_point:
                base = self.store.get_case(source_parent, source_point)
            elif target_parent == str(source.get("case_id") or "") and target_point:
                base = self.store.get_case(target_parent, target_point)
        rules = tuple(
            MergeRule(
                rule_id=str(r.get("rule_id") or ""),
                fields=tuple(str(f) for f in (r.get("fields") or ())),
                strategy=str(r.get("strategy") or "PREFER_SOURCE"),
                registered_by=str(r.get("registered_by") or ""),
            )
            for r in (body.get("registered_rules") or ())
        )
        decision = merge_policy(source, target, base_case=base, registered_rules=rules)
        record = decision.to_canonical()
        self.store.put_object(record, object_type="MergeDecisionRecord", created_by=actor)
        if not decision.automatic:
            raise ConflictError(
                decision.rationale,
                remedy="16.4: reconcile explicitly; this server will not merge semantics for you",
                detail=record,
            )
        merged_hash = None
        if decision.decision == "AUTOMATIC_METADATA":
            merged_case = dict(target)
            merged_case.update(dict(decision.merged_metadata))
            merged_case.setdefault("merge_decisions", []).append(record)
            merged_case.setdefault("history", []).append({
                "operation": "merge",
                "source_case": source_id,
                "decision": decision.decision,
                "recorded_at": utc_now(),
            })
            target_id = str(target.get("case_id") or parameters["case_id"])
            merged_hash = self.store.put_case(
                merged_case,
                expected_parent_version=self.store.head_version(target_id),
                created_by=actor,
            )
        self._emit("case.merged", actor=actor, correlation_id=correlation_id,
                   case_id=str(parameters["case_id"]), detail={"decision": decision.decision})
        return Response(200, {
            "merge_decision": record,
            "merged_case_hash": merged_hash,
            "case_version": self.store.head_version(str(parameters["case_id"])),
        })

    def _op_importRegistry(self, **kwargs: Any) -> Response:
        return self._submit(kwargs["endpoint"], ops.op_import, request=kwargs["request"],
                            parameters=kwargs["parameters"], actor=kwargs["actor"],
                            correlation_id=kwargs["correlation_id"],
                            case=self._case(kwargs["parameters"]))

    def _op_generateFamily(self, **kwargs: Any) -> Response:
        return self._submit(kwargs["endpoint"], ops.op_generate, request=kwargs["request"],
                            parameters=kwargs["parameters"], actor=kwargs["actor"],
                            correlation_id=kwargs["correlation_id"],
                            case=self._case(kwargs["parameters"]))

    def _op_evaluateFamily(self, **kwargs: Any) -> Response:
        return self._submit(kwargs["endpoint"], ops.op_evaluate, request=kwargs["request"],
                            parameters=kwargs["parameters"], actor=kwargs["actor"],
                            correlation_id=kwargs["correlation_id"],
                            case=self._case(kwargs["parameters"]))

    def _op_buildGeometry(self, **kwargs: Any) -> Response:
        return self._submit(kwargs["endpoint"], ops.op_geometry, request=kwargs["request"],
                            parameters=kwargs["parameters"], actor=kwargs["actor"],
                            correlation_id=kwargs["correlation_id"],
                            case=self._case(kwargs["parameters"]))

    def _op_compileQuery(self, *, request: Request, parameters: Mapping[str, str],
                         actor: str, correlation_id: str, **_kwargs: Any) -> Response:
        body = request.json_body()
        case = self._case(parameters)
        document = body.get("query", body)
        case, payload = ops.op_compile(case, document)
        digest = self.store.put_case(case, created_by=actor)
        self._emit("query.compiled", actor=actor, correlation_id=correlation_id,
                   case_id=str(parameters["case_id"]),
                   branch_id=str(case.get("branch_id") or "main"),
                   object_hashes=[digest], detail={"scope_id": payload["scope_id"]})
        return Response(200, payload)

    def _op_certifyCase(self, **kwargs: Any) -> Response:
        return self._submit(kwargs["endpoint"], ops.op_certify, request=kwargs["request"],
                            parameters=kwargs["parameters"], actor=kwargs["actor"],
                            correlation_id=kwargs["correlation_id"],
                            case=self._case(kwargs["parameters"]))

    def _op_classifyChange(self, **kwargs: Any) -> Response:
        return self._submit(kwargs["endpoint"], ops.op_change, request=kwargs["request"],
                            parameters=kwargs["parameters"], actor=kwargs["actor"],
                            correlation_id=kwargs["correlation_id"],
                            case=self._case(kwargs["parameters"]))

    def _op_recomputeCase(self, **kwargs: Any) -> Response:
        return self._submit(kwargs["endpoint"], ops.op_recompute, request=kwargs["request"],
                            parameters=kwargs["parameters"], actor=kwargs["actor"],
                            correlation_id=kwargs["correlation_id"],
                            case=self._case(kwargs["parameters"]))

    def _op_planConversion(self, **kwargs: Any) -> Response:
        return self._submit(kwargs["endpoint"], ops.op_convert, request=kwargs["request"],
                            parameters=kwargs["parameters"], actor=kwargs["actor"],
                            correlation_id=kwargs["correlation_id"],
                            case=self._case(kwargs["parameters"]))

    def _op_planQualification(self, **kwargs: Any) -> Response:
        return self._submit(kwargs["endpoint"], ops.op_qualification_plan,
                            request=kwargs["request"], parameters=kwargs["parameters"],
                            actor=kwargs["actor"], correlation_id=kwargs["correlation_id"],
                            case=self._case(kwargs["parameters"]))

    def _op_migrateCase(self, **kwargs: Any) -> Response:
        return self._submit(kwargs["endpoint"], ops.op_migrate, request=kwargs["request"],
                            parameters=kwargs["parameters"], actor=kwargs["actor"],
                            correlation_id=kwargs["correlation_id"],
                            case=self._case(kwargs["parameters"]))

    def _op_createEvaluatorRequest(self, *, request: Request, parameters: Mapping[str, str],
                                   actor: str, **_kwargs: Any) -> Response:
        case = self._case(parameters)
        payload = ops.op_evaluator_request(case, request.json_body())
        self.store.put_object(payload["evaluator_request"], object_type="EvaluatorRequest",
                              created_by=actor)
        return Response(201, payload)

    def _op_getDependencies(self, *, parameters: Mapping[str, str], **_kwargs: Any) -> Response:
        case = self._case(parameters)
        return Response(200, ops.dependency_view(self.store, case))

    def _op_listCertificates(self, *, parameters: Mapping[str, str],
                             **_kwargs: Any) -> Response:
        case_id = str(parameters["case_id"])
        case = self._case(parameters)
        registered = self.store.list_certificates(case_id)
        return Response(
            200,
            {
                "case_id": case_id,
                "certificates": registered,
                "active": [c for c in registered if c["status"] == "ACTIVE"],
                "unverifiable_redacted": [
                    c for c in registered if c["status"] == "UNVERIFIABLE_REDACTED"
                ],
                "blocked": [c for c in registered if not c["affirmative"]],
                "superseded": sorted(case.get("superseded_certificates") or {}),
                "note": (
                    "17.3: a certificate whose supporting content was removed is "
                    "UNVERIFIABLE_REDACTED and MUST NOT be reported as valid"
                ),
            },
        )

    def _op_redactObject(self, *, request: Request, parameters: Mapping[str, str],
                         actor: str, correlation_id: str, **_kwargs: Any) -> Response:
        body = request.json_body()
        case_id = str(parameters["case_id"])
        digest = str(body.get("object_hash") or "")
        if not digest:
            raise UsageError("redaction names the object hash to remove (17.2)")
        tombstone = self.store.redact(
            digest,
            reason=str(body.get("reason") or ""),
            authority=str(body.get("authority") or ""),
        )
        case = self.store.get_case(case_id)
        case = dict(case)
        case.setdefault("redaction_state", {}).setdefault("redacted_objects", []).append(digest)
        case.setdefault("tombstones", []).append(tombstone.to_canonical())
        # 11.2 lists PARTIALLY_REDACTED among the states a case MAY become.
        # It is reached through the lifecycle machine like every other state,
        # so the transition is recorded and a redaction of an archived or
        # revoked case is refused rather than silently applied (17.5, 6.4).
        try:
            set_case_state(
                case,
                CaseState.PARTIALLY_REDACTED,
                reason=f"object {digest} redacted: {tombstone.reason or 'no reason declared'}",
                actor=actor,
            )
        except LifecycleError as error:
            raise ConflictError(
                f"case {case_id!r} cannot become PARTIALLY_REDACTED from {error.current}: "
                f"{error}",
                remedy="11.2 declares the case lifecycle; a terminal case cannot be modified",
                detail={"from_state": error.current, "to_state": error.target},
            ) from None
        self.store.put_case(case, created_by=actor)
        self._emit("case.redacted", actor=actor, correlation_id=correlation_id,
                   case_id=case_id, object_hashes=[digest],
                   detail={"reason": tombstone.reason, "authority": tombstone.authority})
        certificates = self.store.list_certificates(case_id)
        return Response(
            200,
            {
                "tombstone": tombstone.to_canonical(),
                "affected_certificates": [
                    c["certificate_id"] for c in certificates
                    if c["status"] == "UNVERIFIABLE_REDACTED"
                ],
                "certificates": certificates,
            },
        )

    # -- governed retention and legal hold (17, Gate 7) -------------------
    def _retention_engine(self):
        return retention_engine_for_store(self.store)

    @staticmethod
    def _retention_batch(body: Mapping[str, Any]) -> Tuple[int, str]:
        limit = body.get("limit", 100)
        if isinstance(limit, bool) or not isinstance(limit, int):
            raise UsageError("retention limit must be a JSON integer from 1 through 1000")
        if not 1 <= limit <= 1000:
            raise UsageError("retention limit must be from 1 through 1000")
        after_hash = str(body.get("after_hash") or "")
        if after_hash and not re.fullmatch(r"sha256:[0-9a-f]{64}", after_hash):
            raise UsageError("after_hash must be a lowercase sha256 content address")
        return limit, after_hash

    def _op_createRetentionPolicy(
        self, *, request: Request, actor: str, **_kwargs: Any
    ) -> Response:
        body = request.json_body()
        authority = str(body.get("authority") or "").strip()
        # Creation time and creator are deployment-owned. A caller may choose
        # when the policy becomes effective, never rewrite who registered it
        # or backdate the immutable record.
        supplied = dict(body)
        supplied.pop("authority", None)
        supplied.pop("created_at", None)
        supplied.pop("created_by", None)
        policy = RetentionPolicy.from_mapping(
            supplied, created_by=actor, created_at=utc_now()
        )
        engine = self._retention_engine()
        digest = engine.register(policy, authority=authority)
        return Response(
            201,
            {"policy_hash": digest, "policy": policy.to_canonical(),
             "status": engine.store.object_status(digest)},
            headers={"Location": f"/retention/policies#{digest}"},
        )

    def _op_listRetentionPolicies(self, **_kwargs: Any) -> Response:
        policies = self._retention_engine().policies()
        return Response(200, {"policies": policies, "count": len(policies)})

    def _retention_run(self, *, request: Request, actor: str, dry_run: bool) -> Response:
        body = request.json_body()
        policy_hash = str(body.get("policy_hash") or "")
        if not policy_hash:
            raise UsageError("a retention run requires policy_hash")
        authority = str(body.get("authority") or "").strip()
        limit, after_hash = self._retention_batch(body)
        result = self._retention_engine().run(
            policy_hash,
            authority=authority,
            actor=actor,
            dry_run=dry_run,
            # Server-owned clock: a request cannot future-date a deletion.
            as_of=utc_now(),
            limit=limit,
            after_hash=after_hash,
        )
        return Response(200, result)

    def _op_evaluateRetention(
        self, *, request: Request, actor: str, **_kwargs: Any
    ) -> Response:
        return self._retention_run(request=request, actor=actor, dry_run=True)

    def _op_enforceRetention(
        self, *, request: Request, actor: str, **_kwargs: Any
    ) -> Response:
        return self._retention_run(request=request, actor=actor, dry_run=False)

    def _op_setObjectLegalHold(
        self, *, request: Request, parameters: Mapping[str, str], actor: str,
        **_kwargs: Any
    ) -> Response:
        body = request.json_body()
        held = body.get("held")
        if not isinstance(held, bool):
            raise UsageError("held must be a JSON boolean")
        authority = str(body.get("authority") or "").strip()
        if not authority:
            raise UsageError("placing or releasing a legal hold requires a named authority")
        digest = str(parameters.get("object_hash") or "")
        engine = self._retention_engine()
        # The object-store contract deliberately permits a hold to precede
        # content arrival, so this is not a 404 when the hash is not yet here.
        engine.store.set_legal_hold(digest, held, authority=authority)
        engine.store.append_audit({
            "event": "retention.legal_hold.changed",
            "content_hash": digest,
            "held": held,
            "actor": actor,
            "authority": authority,
        })
        return Response(200, {
            "content_hash": digest,
            "legal_hold": bool(engine.store.objects.legal_hold(digest)),
            "authority": authority,
        })

    # -- ETQ endpoints ------------------------------------------------------
    def _op_registerEvidence(self, *, request: Request, actor: str,
                             correlation_id: str, **_kwargs: Any) -> Response:
        payload = ops.op_evidence(request.json_body())
        digest = self.store.put_object(payload["evidence"], object_type="EvidenceRecord",
                                       created_by=actor)
        self._emit("evidence.registered", actor=actor, correlation_id=correlation_id,
                   object_hashes=[digest], detail={"evidence_id": payload["evidence_id"]})
        if str(payload["time_status"]) == "EXPIRED":
            self._emit("evidence.expired", actor=actor, correlation_id=correlation_id,
                       object_hashes=[digest],
                       detail={"evidence_id": payload["evidence_id"]})
        return Response(201, {**payload, "stored_hash": digest})

    def _op_assembleTechnologyContract(self, **kwargs: Any) -> Response:
        return self._submit(kwargs["endpoint"], ops.op_technology_contract,
                            request=kwargs["request"], parameters=kwargs["parameters"],
                            actor=kwargs["actor"], correlation_id=kwargs["correlation_id"])

    def _op_issueCapabilityEnvelope(self, *, request: Request, actor: str,
                                    correlation_id: str, **_kwargs: Any) -> Response:
        payload = ops.op_capability_envelope(request.json_body())
        digest = self.store.put_object(payload["envelope"], object_type="CapabilityEnvelope",
                                       created_by=actor)
        return Response(201, {**payload, "stored_hash": digest})

    def _op_evaluatePrivately(self, *, request: Request, **_kwargs: Any) -> Response:
        payload = ops.op_private_evaluation(request.json_body())
        return Response(200, payload)

    def _op_executeTransition(
        self, *, request: Request, parameters: Mapping[str, str], actor: str,
        principal: Any, correlation_id: str, **_kwargs: Any,
    ) -> Response:
        if not callable(self.transition_executor):
            raise ConflictError(
                "this deployment has no runtime transition executor adapter",
                remedy=(
                    "32.4/32.5: configure a domain adapter that executes only an "
                    "authorized crg-feedback TransitionPlan and returns its TransitionRecord"
                ),
            )
        body = request.json_body()
        plan_id = str(parameters["plan_id"])
        try:
            signature = inspect.signature(self.transition_executor)
            kwargs: Dict[str, Any] = {}
            if "principal" in signature.parameters:
                kwargs["principal"] = principal
            if "actor" in signature.parameters:
                kwargs["actor"] = actor
            produced = self.transition_executor(plan_id, body, **kwargs)
            to_canonical = getattr(produced, "to_canonical", None)
            record = to_canonical() if callable(to_canonical) else produced
        except ServerError:
            raise
        except Exception as error:  # noqa: BLE001 - domain adapter is untrusted
            raise ConflictError(
                f"runtime transition adapter refused or failed: {type(error).__name__}: {error}",
                remedy="inspect the adapter refusal and the transition plan's guards/rollback",
            ) from error
        if not isinstance(record, Mapping):
            raise ScopeMismatchError(
                "runtime transition adapter did not return a TransitionRecord mapping",
                remedy="return crg_feedback.TransitionRecord or its canonical form",
            )
        canonical = dict(record)
        required = {
            "record_id", "plan_id", "status", "source_config_id", "target_config_id",
            "final_config_id", "checkpoint", "rollback_plan", "steps",
            "postcondition_results", "refusals", "audit",
        }
        missing = sorted(required - set(canonical))
        if missing or str(canonical.get("plan_id")) != plan_id:
            raise ScopeMismatchError(
                "runtime transition adapter returned an incomplete or mismatched record",
                remedy="return the complete 32.5 TransitionRecord for the requested plan",
                detail={"missing": missing, "requested_plan_id": plan_id,
                        "returned_plan_id": canonical.get("plan_id")},
            )
        status = str(canonical.get("status") or "")
        if status not in {"COMPLETED", "ROLLED_BACK", "ROLLBACK_FAILED", "REFUSED"}:
            raise ScopeMismatchError(
                f"runtime transition adapter returned unknown status {status!r}",
                remedy="return a status from crg_feedback.TransitionStatus",
            )
        digest = self.store.put_object(
            canonical, object_type="TransitionRecord", created_by=actor
        )
        case_id = str(body.get("case_id") or "") or None
        branch_id = str(body.get("branch_id") or "") or None
        if status == "COMPLETED":
            self._emit(
                "transition.executed", actor=actor, correlation_id=correlation_id,
                case_id=case_id, branch_id=branch_id, object_hashes=[digest],
                detail={"plan_id": plan_id, "record_id": canonical["record_id"],
                        "final_config_id": canonical["final_config_id"]},
            )
            return Response(200, {"transition": canonical, "stored_hash": digest})
        if status == "ROLLED_BACK":
            self._emit(
                "transition.rolled_back", actor=actor, correlation_id=correlation_id,
                case_id=case_id, branch_id=branch_id, object_hashes=[digest],
                detail={"plan_id": plan_id, "record_id": canonical["record_id"],
                        "final_config_id": canonical["final_config_id"]},
            )
            return Response(200, {"transition": canonical, "stored_hash": digest})
        raise BlockedOutcome(
            f"runtime transition ended in {status}", outcome=status,
            remedy="32.5: inspect refusals and rollback evidence before retrying",
            detail={"transition": canonical, "stored_hash": digest},
        )

    def _op_revokeCapability(
        self, *, request: Request, parameters: Mapping[str, str], actor: str,
        correlation_id: str, **_kwargs: Any,
    ) -> Response:
        body = request.json_body()
        subject = str(parameters["subject_id"]).strip()
        reason = str(body.get("reason") or "").strip()
        if not reason:
            raise UsageError(
                "capability revocation requires a nonempty reason",
                remedy="35.4/44.7: record why this capability, evidence root, or key is denied",
            )
        state = self.federation_verifier_context
        revoke = getattr(state, "revoke", None)
        if not callable(revoke):
            raise ConflictError(
                "this deployment has no persistent federation revocation registry",
                remedy="configure federation verifier state before accepting revocations",
            )
        revoke(subject, reason=reason)
        disclosure = getattr(state, "disclosure", lambda: {})()
        self._emit(
            "capability.revoked", actor=actor, correlation_id=correlation_id,
            detail={
                "subject": subject,
                "reason": reason,
                "revocation_registry_id": disclosure.get("revocation_registry_id"),
            },
        )
        return Response(200, {
            "subject": subject,
            "status": "REVOKED",
            "reason": reason,
            "revocation_registry_id": disclosure.get("revocation_registry_id"),
        })

    # -- bundles ------------------------------------------------------------
    def _op_importBundle(self, **kwargs: Any) -> Response:
        return self._submit(kwargs["endpoint"], _job_import_bundle,
                            request=kwargs["request"],
                            parameters=kwargs["parameters"], actor=kwargs["actor"],
                            correlation_id=kwargs["correlation_id"])

    def _op_verifyBundle(
        self, *, request: Request, actor: str, correlation_id: str, **_kwargs: Any
    ) -> Response:
        from .bundleio import _archive_bytes

        body = request.json_body()
        data = _archive_bytes(body)
        federation_context = self.federation_verifier_context
        if callable(federation_context):
            signature = inspect.signature(federation_context)
            if "principal" in signature.parameters or len(signature.parameters) >= 2:
                federation_context = federation_context(
                    request, principal=_kwargs.get("principal")
                )
            else:
                federation_context = federation_context(request)
        result = verify_bundle_bytes(
            data,
            level=str(body.get("level") or "V3"),
            clock=body.get("clock"),
            clock_source=str(body.get("clock_source") or "none-supplied"),
            federation_context=federation_context,
            extension_registry=self.extension_checker_registry,
        )
        report = result.to_json()
        if not result.ok:
            raise ScopeMismatchError(
                "the bundle did not verify",
                remedy="25.3: the report names every failed check",
                detail=report,
            )
        self._emit(
            "certificate.verified", actor=actor or "anonymous-verifier",
            correlation_id=correlation_id,
            detail={
                "status": result.status,
                "level_achieved": report.get("level_achieved"),
                "requested_level": str(body.get("level") or "V3"),
            },
        )
        return Response(200, report)

    def _op_exportBundle(self, *, request: Request, parameters: Mapping[str, str],
                         **_kwargs: Any) -> Response:
        case_id = str(parameters["bundle_id"])
        case = self.store.get_case(case_id, request.query.get("version"))
        data, manifest = export_bundle(
            self.store, case, authority=str(request.query.get("authority") or "")
        )
        return Response(
            200,
            None,
            raw=data,
            content_type="application/zip",
            headers={
                "Content-Disposition": f'attachment; filename="{case_id}.crg"',
                "CRG-Manifest-Hash": content_hash(manifest),
                "CRG-Object-Count": str(len(manifest["object_inventory"])),
            },
        )

    # -- jobs and events ----------------------------------------------------
    def _op_getJob(self, *, parameters: Mapping[str, str], **_kwargs: Any) -> Response:
        record = self.queue.get(str(parameters["job_id"]))
        return Response(200, {"job": record.to_canonical()})

    def _op_getJobResult(self, *, parameters: Mapping[str, str], **_kwargs: Any) -> Response:
        record = self.queue.get(str(parameters["job_id"]))
        if record.status in {JobStatus.QUEUED, JobStatus.RUNNING}:
            return Response(
                202,
                {"job_id": record.job_id, "status": record.status,
                 "note": "the job has not completed"},
            )
        if record.status == JobStatus.CANCELLED:
            raise ConflictError(
                f"job {record.job_id} was cancelled and produced no result",
                remedy="submit the work again",
                detail={"cancellation": record.cancellation},
            )
        if record.status == JobStatus.FAILED:
            raise ConflictError(
                f"job {record.job_id} failed and produced no result",
                remedy="42.4: a failed job produces no valid certificate; read the logs",
                detail={
                    "failure_category": record.failure_category,
                    "failure_detail": record.failure_detail,
                    "certificates": record.certificate_ids,
                },
            )
        if not record.affirmative:
            raise BlockedOutcome(
                f"the computation completed and refused: {record.blocked_outcome}",
                outcome=str(record.blocked_outcome or "BLOCKED"),
                remedy="6.6: a blocked outcome is never reported behind a 200",
                detail={"outputs": record.outputs, "job_id": record.job_id},
            )
        return Response(200, {"job_id": record.job_id, "status": record.status,
                              "outputs": record.outputs})

    def _op_cancelJob(self, *, request: Request, parameters: Mapping[str, str],
                      actor: str, **_kwargs: Any) -> Response:
        body = request.json_body()
        record = self.queue.cancel(
            str(parameters["job_id"]),
            reason=str(body.get("reason") or "cancelled by request"),
            actor=actor,
        )
        return Response(200, {"job": record.to_canonical()})

    def _op_retryJob(self, *, parameters: Mapping[str, str], actor: str,
                     **_kwargs: Any) -> Response:
        record = self.queue.retry(str(parameters["job_id"]), actor=actor)
        return Response(202, {"job_id": record.job_id, "status": record.status,
                              "retry_history": record.retry_history})

    def _op_listEvents(self, *, request: Request, **_kwargs: Any) -> Response:
        since = int(request.query.get("since") or 0)
        events = self.events.since(since)
        return Response(
            200,
            {
                "since": since,
                "count": len(events),
                "events": [e.to_canonical() for e in events],
            },
        )

    def _op_exportAudit(
        self, *, request: Request, principal: Any, correlation_id: str,
        **_kwargs: Any,
    ) -> Response:
        if self.security is None or principal is None:
            raise UnauthorizedError(
                "governed audit export requires an authenticated security principal",
                remedy=(
                    "configure the production security gate and authenticate as an Auditor; "
                    "the unverified X-CRG-Actor development header cannot export this chain"
                ),
            )
        exporter = getattr(self.security, "export_audit", None)
        if not callable(exporter):
            raise ServiceUnavailableError(
                "the configured security gate does not provide governed audit export",
                remedy="configure a gate exposing export_audit over its tenant-bound chain",
            )
        authority = str(request.query.get("authority") or "").strip()
        if not authority or len(authority) > 256 or any(ord(ch) < 32 for ch in authority):
            raise UsageError(
                "authority must be a non-empty, printable identifier of at most 256 characters",
                remedy="name the records authority accountable for receiving this export",
            )
        try:
            after_sequence = int(request.query.get("after_sequence") or -1)
            limit = int(request.query.get("limit") or 100)
        except (TypeError, ValueError) as error:
            raise UsageError(
                "after_sequence and limit must be base-10 integers",
                remedy="use after_sequence=-1 for the first page and limit from 1 through 1000",
            ) from error
        if after_sequence < -1 or limit < 1 or limit > 1000:
            raise UsageError(
                "audit export cursor or limit is outside the declared bounds",
                remedy="use after_sequence=-1 or a returned cursor, and limit from 1 through 1000",
                detail={"after_sequence": after_sequence, "limit": limit},
            )
        try:
            artifact = exporter(
                principal=principal,
                authority=authority,
                after_sequence=after_sequence,
                limit=limit,
                correlation_id=correlation_id,
            )
        except ValueError as error:
            raise UsageError(
                str(error),
                remedy="restart from after_sequence=-1 or use exactly the cursor returned by this tenant chain",
            ) from error
        except Exception as error:  # noqa: BLE001 - duck-typed security boundary
            raise from_security_error(error) from error
        tenant = re.sub(r"[^A-Za-z0-9._-]+", "-", str(artifact.get("tenant_id") or "tenant"))
        return Response(
            200,
            artifact,
            headers={
                "Content-Disposition": f'attachment; filename="crg-audit-{tenant}.json"',
                "Cache-Control": "no-store",
            },
        )

    def _op_streamEvents(self, *, request: Request, **_kwargs: Any) -> Response:
        return self._stream_response(request, case_id=None)

    def _op_streamCaseEvents(self, *, request: Request, parameters: Mapping[str, str],
                             **_kwargs: Any) -> Response:
        case_id = str(parameters["case_id"])
        if not self.store.case_exists(case_id):
            raise NotFoundError(
                f"no case {case_id!r} to stream",
                remedy="create or import the case before subscribing to its events",
            )
        return self._stream_response(request, case_id=case_id)

    # -- webhook subscription control plane (38.2) -----------------------
    def _op_createWebhookSubscription(
        self, *, request: Request, actor: str, correlation_id: str, **_kwargs: Any
    ) -> Response:
        body = request.json_body()
        endpoint = str(body.get("endpoint") or "").strip()
        split = urlsplit(endpoint)
        if split.scheme.lower() != "https" or not split.netloc or split.username:
            raise UsageError(
                "a webhook endpoint must be an absolute HTTPS URL without userinfo",
                remedy="38.2/44.4: register an https:// host/path endpoint; credentials "
                       "belong in the signed delivery, not in the URL",
            )
        secret_text = body.get("secret")
        if not isinstance(secret_text, str) or len(secret_text.encode("utf-8")) < 32:
            raise UsageError(
                "a webhook secret must be a UTF-8 string of at least 32 bytes",
                remedy="provide the shared secret once over the authenticated TLS control plane",
            )
        events = body.get("events") or ()
        if not isinstance(events, list) or not all(isinstance(name, str) for name in events):
            raise UsageError("events must be an array of event names from the 38.5 vocabulary")
        try:
            subscription = self.webhooks.register(
                endpoint,
                secret=secret_text.encode("utf-8"),
                events=tuple(events),
                subscription_id=(str(body["subscription_id"])
                                 if body.get("subscription_id") else None),
                max_attempts=int(body.get("max_attempts") or 5),
                base_delay=Fraction(str(body.get("base_delay_seconds") or "1")),
                backoff_factor=Fraction(str(body.get("backoff_factor") or "2")),
                max_delay=Fraction(str(body.get("max_delay_seconds") or "60")),
                created_by=actor,
                enabled=bool(body.get("enabled", True)),
            )
        except UsageError as error:
            if "already registered" in error.message:
                raise ConflictError(error.message, remedy=error.remedy, detail=error.detail) from None
            raise
        description = subscription.describe()
        self.store.append_audit({
            "event": "webhook.subscription.created",
            "subscription": description,
            "actor": actor,
            "correlation_id": correlation_id,
            "recorded_at": utc_now(),
        })
        return Response(201, {"subscription": description})

    def _op_listWebhookSubscriptions(self, **_kwargs: Any) -> Response:
        rows = [subscription.describe() for subscription in self.webhooks.subscriptions()]
        return Response(200, {"count": len(rows), "subscriptions": rows})

    def _op_deleteWebhookSubscription(
        self, *, parameters: Mapping[str, str], actor: str, correlation_id: str,
        **_kwargs: Any,
    ) -> Response:
        subscription_id = str(parameters["subscription_id"])
        known = {row.subscription_id for row in self.webhooks.subscriptions()}
        if subscription_id not in known:
            raise NotFoundError(
                f"no webhook subscription {subscription_id!r}",
                remedy="list the registered subscriptions before deleting one",
            )
        removed = self.webhooks.delete(subscription_id)
        description = removed.describe()
        self.store.append_audit({
            "event": "webhook.subscription.deleted",
            "subscription": description,
            "actor": actor,
            "correlation_id": correlation_id,
            "recorded_at": utc_now(),
        })
        return Response(200, {"subscription": description, "deleted": True})

    def _stream_response(self, request: Request, *, case_id: Optional[str]) -> Response:
        """One Server-Sent Events subscription (38.2).

        The body of the response is the *framed snapshot* -- everything the
        subscriber missed, already in SSE wire form -- so an in-process
        caller holding no socket still receives well-formed bytes.  The live
        iterator travels beside it in ``Response.stream``; ``make_handler``
        flushes its chunks as they arrive.  Both start from the same
        ``Last-Event-ID``, so the prefix a socket sees is the prefix
        ``dispatch`` returns.
        """
        from .streaming import SSE_CONTENT_TYPE, SSE_HEADERS, build_event_stream

        stream = build_event_stream(
            self.events,
            query=request.query,
            headers=request.headers,
            case_id=case_id,
        )
        headers = dict(SSE_HEADERS)
        headers["CRG-Stream-Transport"] = "server-sent-events"
        return Response(
            200,
            None,
            raw=stream.snapshot(),
            content_type=SSE_CONTENT_TYPE,
            headers=headers,
            stream=stream,
        )

    def _op_getOpenApi(self, **_kwargs: Any) -> Response:
        from .openapi import openapi_document

        authenticated = self.security is not None and getattr(self.security, "enabled", True)
        return Response(200, openapi_document(authenticated=authenticated))

    def _op_healthLive(self, **_kwargs: Any) -> Response:
        return Response(200, {"status": "LIVE", "service": "crg-server",
                              "version": SERVER_VERSION})

    def _op_healthReady(self, **_kwargs: Any) -> Response:
        failures: List[str] = []
        if self.draining:
            failures.append("service: graceful drain in progress")
        try:
            self.store.list_jobs()
        except Exception as error:  # noqa: BLE001 - readiness reports dependency failure
            failures.append(f"metadata-store: {type(error).__name__}: {error}")
        if self.queue.autorun and not self.queue.worker_alive:
            failures.append("local-worker: not running")
        external_up, active_workers, heartbeat_age = self._external_worker_health()
        if str(getattr(self.queue, "execution_mode", "")) == "external" and not external_up:
            failures.append(
                "external-worker: no durable heartbeat within "
                f"{getattr(self.queue, 'worker_heartbeat_max_age_seconds', 120)} seconds"
            )
        if self.security is not None:
            try:
                configuration = getattr(self.security, "configuration", None)
                audit_log = getattr(configuration, "audit_log", None)
                if audit_log is not None:
                    audit_log.require_intact()
            except Exception as error:  # noqa: BLE001
                failures.append(f"security-audit: {type(error).__name__}: {error}")
        if failures:
            return Response(503, {"status": "NOT_READY", "failures": failures})
        return Response(200, {
            "status": "READY",
            "service": "crg-server",
            "authentication": self._authentication_header(),
            "worker": (
                "running" if self.queue.autorun
                else str(getattr(self.queue, "execution_mode", "embedded-manual"))
            ),
            "active_external_workers": active_workers,
            "newest_worker_heartbeat_age_seconds": heartbeat_age,
        })

    def _op_getMetrics(self, **_kwargs: Any) -> Response:
        with self._metrics_lock:
            counts = dict(self._request_counts)
            durations = dict(self._request_seconds)
        lines = [
            "# HELP crg_http_requests_total HTTP requests by operation and status.",
            "# TYPE crg_http_requests_total counter",
        ]
        for (operation, status), value in sorted(counts.items()):
            lines.append(
                f'crg_http_requests_total{{operation="{operation}",status="{status}"}} {value}'
            )
        lines.extend([
            "# HELP crg_http_request_duration_seconds_total Cumulative request duration.",
            "# TYPE crg_http_request_duration_seconds_total counter",
        ])
        for operation, value in sorted(durations.items()):
            lines.append(
                f'crg_http_request_duration_seconds_total{{operation="{operation}"}} {value:.9f}'
            )
        worker_up, active_workers, heartbeat_age = self._external_worker_health()
        lines.append(f"crg_jobs_pending {len(self.queue.pending)}")
        lines.append(f"crg_service_draining {1 if self.draining else 0}")
        lines.append(f"crg_worker_up {1 if worker_up else 0}")
        lines.append(f"crg_external_workers_active {active_workers}")
        if heartbeat_age is not None:
            lines.append(f"crg_worker_heartbeat_age_seconds {heartbeat_age:.6f}")
        telemetry = self.telemetry.metrics()
        lines.append(f"crg_trace_exporter_enabled {telemetry['enabled']}")
        lines.append(f"crg_trace_export_queue_depth {telemetry['pending']}")
        lines.append(f"crg_trace_spans_exported_total {telemetry['exported']}")
        lines.append(f"crg_trace_export_failures_total {telemetry['failures']}")
        lines.append(f"crg_trace_spans_dropped_total {telemetry['dropped']}")
        return Response(200, None, raw=("\n".join(lines) + "\n").encode("utf-8"),
                        content_type="text/plain; version=0.0.4")


# ---------------------------------------------------------------------------
# construction and transport
# ---------------------------------------------------------------------------
def make_app(
    store: CaseStore,
    queue: JobQueue,
    *,
    events: Optional[EventBus] = None,
    roles: Optional[Mapping[str, Sequence[str]]] = None,
    default_actor: Optional[str] = None,
    security: Optional[Any] = None,
    federation_verifier_context: Optional[Any] = None,
    extension_checker_registry: Optional[Any] = None,
    webhooks: Optional[WebhookDispatcher] = None,
    transition_executor: Optional[Callable[..., Any]] = None,
    telemetry: Optional[Any] = None,
    max_request_bytes: int = DEFAULT_MAX_REQUEST_BYTES,
) -> Application:
    """Build the routed integration surface over ``store`` and ``queue``.

    ``security`` is opt-in and defaults to ``None``, which is exactly the
    behaviour every existing caller already has: unverified ``X-CRG-Actor``
    identity and the static role table, with
    :data:`NO_AUTHENTICATION_CONFIGURED` disclosed on every response.  Passing
    a gate -- :class:`crg_security.gate.ServerSecurityGate` or a deployment's
    own -- turns on 44.2 authentication, 44.2/44.3 authorization, 44.5 tenant
    checks, and the 44.7 hash-chained audit log.
    """
    return Application(
        store,
        queue,
        events=events,
        roles=roles,
        default_actor=default_actor,
        security=security,
        federation_verifier_context=federation_verifier_context,
        extension_checker_registry=extension_checker_registry,
        webhooks=webhooks,
        transition_executor=transition_executor,
        telemetry=telemetry,
        max_request_bytes=max_request_bytes,
    )


def build_request(
    method: str, target: str, raw: bytes, headers: Mapping[str, str]
) -> Request:
    """Decode a wire request.  JSON only (38.2)."""
    split = urlsplit(target)
    query = {k: v[0] for k, v in parse_qs(split.query).items()}
    normalized = {str(k).lower(): str(v) for k, v in headers.items()}
    body: Any = None
    if raw:
        content_type = normalized.get("content-type", "application/json")
        if "json" not in content_type:
            raise UnsupportedMediaTypeError(
                f"content type {content_type!r} is not supported",
                remedy="38.2: this surface is JSON over REST",
            )
        try:
            body = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise UsageError(f"the request body is not valid JSON: {error}") from None
    return Request(
        method=method.upper(),
        path=split.path or "/",
        query=query,
        headers=normalized,
        body=body,
        actor=normalized.get("x-crg-actor", ""),
        correlation_id=normalized.get("x-crg-correlation-id", ""),
        idempotency_key=normalized.get("idempotency-key"),
    )


_REASONS = {
    200: "OK", 201: "Created", 202: "Accepted", 400: "Bad Request",
    401: "Unauthorized", 403: "Forbidden", 404: "Not Found",
    405: "Method Not Allowed", 409: "Conflict", 410: "Gone",
    413: "Payload Too Large", 415: "Unsupported Media Type",
    422: "Unprocessable Content", 503: "Service Unavailable",
    500: "Internal Server Error",
}


def _reason(status: int) -> str:
    return _REASONS.get(status, "Status")


def make_handler(app: Application) -> type:
    """Adapt an :class:`Application` to :mod:`http.server` (spec 38.2, 43)."""

    class Handler(BaseHTTPRequestHandler):
        server_version = f"crg-server/{SERVER_VERSION}"
        protocol_version = "HTTP/1.1"
        application = app

        def log_message(self, *_args: Any) -> None:  # pragma: no cover - handled below
            return

        def _run(self, method: str) -> None:
            length = int(self.headers.get("Content-Length") or 0)
            if length > self.application.max_request_bytes:
                error = PayloadTooLargeError(
                    f"request body is {length} bytes; limit is "
                    f"{self.application.max_request_bytes}",
                    remedy="send a smaller typed request or use an authorized bounded artifact channel",
                )
                self._write(Response(error.status, error_body(error)))
                return
            raw = self.rfile.read(length) if length else b""
            headers = {k: v for k, v in self.headers.items()}
            try:
                request = build_request(method, self.path, raw, headers)
            except ServerError as error:
                self._write(Response(error.status, error_body(error)))
                return
            response = self.application.dispatch(request)
            self._write(response)
            print(canonical_json({
                "event": "http.access",
                "method": method,
                "path": urlsplit(self.path).path,
                "status": response.status,
                "client": self.client_address[0] if self.client_address else "",
                "correlation_id": response.headers.get("X-CRG-Correlation-Id", ""),
                "recorded_at": utc_now(),
            }), file=sys.stderr, flush=True)

        def _write(self, response: Response) -> None:
            if response.stream is not None:
                self._write_stream(response)
                return
            payload = response.payload()
            self.send_response(response.status)
            self.send_header("Content-Type", response.content_type)
            self.send_header("Content-Length", str(len(payload)))
            for name, value in response.headers.items():
                self.send_header(name, value)
            self.end_headers()
            if payload:
                self.wfile.write(payload)

        def _write_stream(self, response: Response) -> None:
            """Flush framed chunks as they arrive (spec 38.2).

            No ``Content-Length``: the length of an open stream is not known
            and must not be guessed.  The response is delimited by closing
            the connection, which is why ``close_connection`` is set before
            the first byte goes out -- a keep-alive response with no length
            would leave the client waiting for a body it already has.

            A subscriber that walks away mid-stream closes its socket, and
            the write raises.  That is the normal end of a subscription, not
            a server fault, so it ends the loop and is not re-raised into
            :mod:`http.server`'s error handler.
            """
            self.send_response(response.status)
            self.send_header("Content-Type", response.content_type)
            for name, value in response.headers.items():
                self.send_header(name, value)
            self.send_header("Connection", "close")
            self.close_connection = True
            self.end_headers()
            try:
                for chunk in response.stream:
                    if not chunk:
                        continue
                    self.wfile.write(chunk)
                    self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError):
                return

        def do_GET(self) -> None:  # noqa: N802 - http.server naming
            self._run("GET")

        def do_POST(self) -> None:  # noqa: N802
            self._run("POST")

        def do_PUT(self) -> None:  # noqa: N802
            self._run("PUT")

        def do_DELETE(self) -> None:  # noqa: N802
            self._run("DELETE")

    return Handler


def serve(host: str, port: int, store: CaseStore, queue: JobQueue, **kwargs: Any) -> None:
    """Serve forever on ``(host, port)`` (spec 38.2, 42.2).

    Blocking by design.  A deployment that wants a background server owns the
    thread; this function exists so that "run the reference server" is one
    call with no framework behind it.
    """
    server = make_server(host, port, store, queue, **kwargs)
    try:
        server.serve_forever()
    finally:  # pragma: no cover - only reached on shutdown
        server.server_close()


def make_server(
    host: str, port: int, store: CaseStore, queue: JobQueue, **kwargs: Any
) -> ThreadingHTTPServer:
    """Bind a threading HTTP server without starting it.

    Separated from :func:`serve` so a test can bind port 0, read the assigned
    port, and drive the surface over a real socket without racing a
    ``serve_forever`` that has not bound yet.
    """
    app = kwargs.pop("app", None) or make_app(store, queue, **kwargs)
    server = ThreadingHTTPServer((host, port), make_handler(app))
    # Lifecycle ownership belongs to the process embedding the transport.  A
    # named handle avoids reaching through the generated handler class when a
    # SIGTERM path needs to close admission before stopping the socket.
    server.crg_application = app  # type: ignore[attr-defined]
    return server
