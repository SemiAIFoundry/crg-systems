"""Static asset routing for CRG Studio (spec 41).

Normative basis: 41 in full (CRG Studio shall be an optional interface over
the same public APIs), 41.1 (required workspaces), 41.2 (UX principles),
38.2 (the REST surface Studio consumes), 44.4 (transport), 47.7 (WCAG 2.2
AA), 6.12 (anti-lock-in).

Three properties of this module carry the specification's weight.

**Studio reaches the kernel only through the documented API.**  Nothing here
imports ``crg_model``, ``crg_certify``, ``crg_geometry``, or any other kernel
package, and nothing here reads the case store.  The Python side of Studio
serves bytes; every fact the browser displays it fetched from an endpoint
listed in ``crg_server.openapi.openapi_document()``.  That is the whole point
of 41's first sentence: an interface that cannot cheat is a proof that the
public surface is sufficient, and the test suite asserts the property
directly by matching every request path in the JavaScript against the
OpenAPI document.

**Mounting does not modify the server.**  :func:`mount_studio` installs an
instance-level ``dispatch`` in front of :meth:`crg_server.app.Application.dispatch`.
Both transports the server offers -- the WSGI ``__call__`` and the
``http.server`` handler built by ``make_handler`` -- read ``dispatch``
through the instance, so one wrapper covers both and ``crg_server`` needs no
hook, no route table entry, and no import of this package.  A deployment that
does not want Studio simply never calls :func:`mount_studio`, which is what
"optional" in 41 has to mean operationally.

**The served set is an allowlist, not a filesystem walk per request.**
:data:`ASSETS` is computed once from the shipped tree; a request path that is
not a key is a 404 before any path arithmetic happens, so ``..`` and absolute
paths are not special cases to get right, they are simply absent.
"""
from __future__ import annotations

import posixpath
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Tuple

from crg_server.app import Response

__all__ = [
    "ASSET_EXTENSIONS",
    "ASSETS",
    "CONTENT_SECURITY_POLICY",
    "CONTENT_TYPES",
    "STATIC_ROOT",
    "STUDIO_PREFIX",
    "asset_bytes",
    "asset_names",
    "content_type_for",
    "mount_studio",
    "serve_studio",
    "studio_response",
]

STATIC_ROOT = Path(__file__).resolve().parent / "static"

#: Every Studio URL lives under this prefix so that mounting can never shadow
#: an endpoint of 38.3.  The server owns ``/``; Studio owns ``/studio``.
STUDIO_PREFIX = "/studio"

#: Extensions the shipped tree may contain.  A file with any other suffix is
#: not served even if someone drops it into ``static/``; there is no build
#: step, so there is nothing legitimate to serve that is not one of these.
ASSET_EXTENSIONS: Dict[str, str] = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".json": "application/json",
    ".svg": "image/svg+xml",
}

CONTENT_TYPES = dict(ASSET_EXTENSIONS)

#: 44.4 and 6.12.  Studio has no external JavaScript, no CDN, and no
#: analytics; saying so in a header makes the claim enforceable by the
#: browser rather than merely documented, and makes a regression that
#: introduced a dependency fail loudly in every deployment.
CONTENT_SECURITY_POLICY = (
    "default-src 'self'; script-src 'self'; style-src 'self'; "
    "img-src 'self' data:; connect-src 'self'; font-src 'self'; "
    "object-src 'none'; base-uri 'none'; form-action 'none'; "
    "frame-ancestors 'none'"
)


def _scan(root: Path) -> Dict[str, Path]:
    found: Dict[str, Path] = {}
    if not root.is_dir():  # pragma: no cover - the tree ships with the package
        return found
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        if path.suffix not in ASSET_EXTENSIONS:
            continue
        if any(part.startswith((".", "__")) for part in path.relative_to(root).parts):
            continue
        found[path.relative_to(root).as_posix()] = path
    return found


#: name -> absolute path, computed at import.
ASSETS: Dict[str, Path] = _scan(STATIC_ROOT)


def asset_names() -> List[str]:
    """Every asset this deployment will serve, in stable order."""
    return sorted(ASSETS)


def content_type_for(name: str) -> str:
    """The content type for ``name``.

    ES modules must arrive with a JavaScript media type or the browser
    refuses to evaluate them, so this is load-bearing rather than cosmetic.
    """
    return ASSET_EXTENSIONS[posixpath.splitext(name)[1]]


def asset_bytes(name: str) -> bytes:
    """Read a shipped asset.  ``KeyError`` when it is not one."""
    return ASSETS[name].read_bytes()


def _resolve(path: str) -> Optional[str]:
    """Map a request path to an asset name, or ``None`` when it is not ours."""
    if path in (STUDIO_PREFIX, STUDIO_PREFIX + "/"):
        return "index.html"
    if not path.startswith(STUDIO_PREFIX + "/"):
        return None
    name = path[len(STUDIO_PREFIX) + 1:]
    return name if name in ASSETS else ""


def studio_response(method: str, path: str) -> Optional[Response]:
    """Answer a Studio request, or ``None`` when ``path`` is not Studio's.

    ``None`` and a 404 are different answers on purpose: ``None`` means "this
    belongs to the API, pass it on", and a 404 means "this is a Studio URL
    naming an asset that does not exist".  Conflating them would let a
    mis-typed asset name fall through to the API router and come back with a
    message about ``/openapi.json``, which is 6.6's failure mode in
    miniature -- a refusal that describes the wrong thing.
    """
    name = _resolve(path)
    if name is None:
        return None
    if method not in ("GET", "HEAD"):
        return Response(
            405,
            {
                "error": {
                    "category": "usage",
                    "status": 405,
                    "message": f"{method} is not defined on {path}",
                    "remedy": "Studio assets are read-only; state changes go to the API of 38.3",
                }
            },
            headers={"Allow": "GET, HEAD"},
        )
    if not name:
        return Response(
            404,
            {
                "error": {
                    "category": "not_found",
                    "status": 404,
                    "message": f"no Studio asset {path!r}",
                    "remedy": "GET /studio serves the application shell",
                }
            },
        )
    payload = asset_bytes(name)
    return Response(
        200,
        None,
        raw=b"" if method == "HEAD" else payload,
        content_type=content_type_for(name),
        headers={
            "Cache-Control": "no-cache",
            "X-Content-Type-Options": "nosniff",
            "Content-Security-Policy": CONTENT_SECURITY_POLICY,
            "Referrer-Policy": "no-referrer",
            "X-CRG-Studio-Asset": name,
        },
    )


def mount_studio(app: Any) -> Any:
    """Serve Studio from ``app`` without modifying ``crg_server`` (spec 41).

    Returns ``app`` so the call composes:
    ``mount_studio(make_app(store, queue))``.  Mounting twice is a no-op
    rather than a double wrap.
    """
    if getattr(app, "crg_studio_mounted", False):
        return app
    inner = app.dispatch

    def dispatch(request: Any) -> Response:
        response = studio_response(str(request.method).upper(), str(request.path))
        if response is not None:
            return response
        return inner(request)

    app.dispatch = dispatch
    app.crg_studio_mounted = True
    return app


def serve_studio(
    host: str = "127.0.0.1",
    port: int = 8731,
    *,
    root: str = ".crg-server",
    default_actor: Optional[str] = None,
    store: Any = None,
    queue: Any = None,
    **kwargs: Any,
) -> Tuple[Any, Any]:
    """Bind a server that carries both the API of 38.3 and Studio.

    Returns ``(server, application)`` unstarted, mirroring
    :func:`crg_server.app.make_server`, so a caller owns the thread and a
    test can bind port 0 without racing ``serve_forever``.
    """
    from crg_server.app import make_app, make_handler
    from crg_server.jobs import JobQueue
    from crg_server.store import CaseStore
    from http.server import ThreadingHTTPServer

    store = store if store is not None else CaseStore(root)
    queue = queue if queue is not None else JobQueue(store)
    app = mount_studio(make_app(store, queue, default_actor=default_actor, **kwargs))
    return ThreadingHTTPServer((host, port), make_handler(app)), app


def studio_index_url(host: str, port: int) -> str:
    """The URL a human opens.  Used by the entry point's banner."""
    return f"http://{host}:{port}{STUDIO_PREFIX}"


def describe() -> Mapping[str, Any]:
    """A machine-readable summary of what this mount serves."""
    return {
        "prefix": STUDIO_PREFIX,
        "assets": asset_names(),
        "content_types": {n: content_type_for(n) for n in asset_names()},
        "content_security_policy": CONTENT_SECURITY_POLICY,
    }
