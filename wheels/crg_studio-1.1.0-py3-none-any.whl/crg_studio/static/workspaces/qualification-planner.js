/**
 * Qualification Planner (spec 41.1): desired state, thresholds, experiments,
 * burden, and stopping.
 *
 * This workspace answers 41.2's seventh principle directly: expose the
 * evidence or experiment most capable of resolving uncertainty.  The ranking
 * is the server's (34.4) and not Studio's, and Studio shows the tier before
 * the score, because 34.4 tiers before it scores: an experiment whose
 * declared reduction is not strictly positive ranks below every informative
 * one however cheap it is.  Rendering the score first would let cheapness
 * appear to buy rank that information did not earn.
 */

import {
  absent, definitionList, disclosure, emptyState, esc, evidenceBadge, join, panel, quantity,
  table,
} from '../render.js';
import { action, field, notYet, shell } from '../workspace.js';

const meta = {
  id: 'qualification-planner',
  title: 'Qualification Planner',
  purpose: 'Desired state, thresholds, experiments, burden, and stopping.',
  endpoints: ['planQualification', 'getJobResult', 'createEvaluatorRequest'],
};

const TIERS = {
  INFORMATIVE: ['Would reduce the uncertainty', 'good'],
  UNINFORMATIVE: ['Would not reduce the uncertainty', 'caution'],
  BLOCKED: ['Cannot be run as declared', 'blocked'],
};

function rankingTable(ranked) {
  if (!ranked.length) {
    return emptyState('No experiments have been ranked yet.');
  }
  return table('Experiments, ranked by how much uncertainty each would remove', [
    { label: 'Rank' },
    { label: 'Experiment' },
    { label: 'Would it help?', hint: '34.4 tiers by informativeness before it scores by burden.' },
    { label: 'Uncertainty it would remove' },
    { label: 'Burden' },
    { label: 'Score' },
    { label: 'Evidence class it would produce' },
  ], ranked.map((experiment, index) => {
    const [label, tone] = TIERS[experiment.tier] || TIERS[experiment.rank_tier]
      || ['Tier not declared', 'caution'];
    return {
      attributes: ` data-tier="${esc(experiment.tier || experiment.rank_tier || '')}"`,
      cells: [
        `<span>${esc(String(index + 1))}</span>`,
        experiment.experiment_id
          ? `<code class="crg-code">${esc(experiment.experiment_id)}</code>` : absent(),
        `<span class="crg-tier crg-tier--${esc(tone)}">${esc(label)}</span>`,
        experiment.expected_reduction === undefined || experiment.expected_reduction === null
          ? absent('UNSUPPORTED')
          : quantity(experiment.expected_reduction, { unit: experiment.unit || '' }),
        experiment.burden === undefined || experiment.burden === null
          ? absent('UNSUPPORTED') : quantity(experiment.burden),
        experiment.score === undefined || experiment.score === null
          ? absent('UNSUPPORTED') : quantity(experiment.score),
        evidenceBadge(experiment.evidence_class || 'MEASURED'),
      ],
    };
  }));
}

function topRecommendation(ranked) {
  const best = ranked.find((e) => (e.tier || e.rank_tier) === 'INFORMATIVE') || ranked[0];
  if (!best) return '';
  const informative = (best.tier || best.rank_tier) === 'INFORMATIVE';
  return panel('The experiment most capable of resolving this', join([
    informative
      ? `<p class="crg-prose crg-prose--lead">Run <code class="crg-code">`
        + `${esc(best.experiment_id || '')}</code> next.</p>`
      : `<p class="crg-prose crg-prose--lead">Nothing on this list would reduce the `
        + `uncertainty as declared. The highest-ranked entry is shown, but running it will `
        + `not move the decision.</p>`,
    definitionList([
      ['Why it ranks first', best.rationale ? esc(best.rationale)
        : '<span class="crg-prose">It removes the most uncertainty per unit of declared '
          + 'burden, among the experiments that remove any at all.</span>'],
      ['Uncertainty it would remove', best.expected_reduction === undefined
        ? absent('UNSUPPORTED')
        : quantity(best.expected_reduction, { unit: best.unit || '' })],
      ['What it would settle', (best.resolves || []).length
        ? `<ul class="crg-list">${(best.resolves || [])
          .map((r) => `<li>${esc(r)}</li>`).join('')}</ul>`
        : absent('UNSUPPORTED')],
    ]),
    `<div class="crg-actions">${action('request-evaluation', 'Request this evaluation', {
      operation: 'createEvaluatorRequest',
    })}</div>`,
  ]), { tone: informative ? 'neutral' : 'warn', principle: 'resolving-evidence' });
}

function stoppingPanel(plan) {
  const stopping = plan.stopping || plan.stopping_rule || null;
  return panel('When to stop', join([
    stopping
      ? `<p class="crg-prose">${esc(typeof stopping === 'string' ? stopping
        : JSON.stringify(stopping))}</p>`
      : `<p class="crg-prose">No stopping rule is declared. Without one, "enough evidence" `
        + `is decided after the fact, which is the condition 34 exists to prevent.</p>`,
    definitionList([
      ['Desired state', plan.desired_state ? esc(plan.desired_state) : absent()],
      ['Threshold', plan.threshold === undefined || plan.threshold === null
        ? absent('UNSUPPORTED') : quantity(plan.threshold, { unit: plan.unit || '' })],
      ['Current gap to it', plan.gap === undefined || plan.gap === null
        ? absent('UNSUPPORTED') : quantity(plan.gap, { unit: plan.unit || '' })],
    ]),
  ]), { tone: stopping ? 'neutral' : 'warn' });
}

function burdenPanel(plan) {
  const weights = plan.burden_weights || {};
  const entries = Object.entries(weights);
  if (!entries.length) {
    return panel('Burden weighting', emptyState(
      'No burden weights are declared. 34.4 supplies no default: a dimension nobody declared '
      + 'cannot be weighted, and a hidden default would rank experiments by an opinion '
      + 'nobody recorded.',
    ), { tone: 'warn' });
  }
  return panel('Burden weighting used for this ranking', definitionList(
    entries.map(([dimension, weight]) => [
      dimension.replace(/_/g, ' '),
      quantity(weight),
    ]),
  ));
}

function planForm(state) {
  return panel('Plan a qualification', join([
    field('experiments', 'Declared experiments', {
      multiline: true, rows: 10,
      value: (state.form && state.form.experiments) || '',
      hint: 'Each experiment declares what it would measure, what uncertainty it would '
        + 'remove, and what it would cost on each burden dimension (34.2).',
    }),
    field('burden-weights', 'Burden weights', {
      multiline: true, rows: 4,
      value: (state.form && state.form.weights) || '',
      hint: 'Required. There is no default weighting (34.4).',
      required: true,
    }),
    `<div class="crg-actions">${action('plan-qualification', 'Rank the experiments', {
      operation: 'planQualification',
    })}</div>`,
  ]));
}

export const workspace = {
  ...meta,
  render(state = {}) {
    const plan = state.plan || state.data || {};
    const ranked = plan.ranked_experiments || plan.ranked || [];
    if (!ranked.length) {
      return shell(meta, join([
        planForm(state),
        notYet('No qualification plan has been produced for this case yet.'),
      ]), state);
    }
    return shell(meta, join([
      planForm(state),
      topRecommendation(ranked),
      rankingTable(ranked),
      burdenPanel(plan),
      stoppingPanel(plan),
      disclosure('Plan as stored', `<pre class="crg-pre" tabindex="0" role="group" `
        + `aria-label="Qualification plan">${esc(JSON.stringify(plan, null, 2))}</pre>`,
      { principle: 'why' }),
    ]), state);
  },
};

export default workspace;
