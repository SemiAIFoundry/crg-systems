/**
 * Verification Center (spec 41.1): verification level, proof status,
 * failures, expiry, and signatures.
 *
 * 41.2 requires Studio to show whether a certificate is independently
 * verified or replay-bound.  The distinction is the difference between a
 * claim someone else can check and a claim you can re-run: both are useful,
 * only one is evidence.  This workspace therefore never displays a bare
 * "verified" tick.  It displays the level attempted, the level achieved, the
 * checks that were not supported, and the solver trust profile the result
 * was produced under, because a V3 attempt that achieved V0 is not a
 * verified certificate and must not look like one.
 */

import {
  absent, definitionList, disclosure, emptyState, esc, hashChip, join, panel, solverTrustChip,
  table, verificationChip, VERIFICATION_STATUSES,
} from '../render.js';
import { action, field, notYet, select, shell } from '../workspace.js';

const meta = {
  id: 'verification-center',
  title: 'Verification Center',
  purpose: 'Verification level, proof status, failures, expiry, and signatures.',
  endpoints: ['verifyBundle', 'exportBundle', 'listCertificates'],
};

const LEVELS = [
  ['V0', 'Integrity', 'Canonical hashes, manifest integrity, signatures, and object presence.'],
  ['V1', 'Structural', 'Schema validity, units, versions, dependency closure, migration '
    + 'validity, and graph acyclicity.'],
  ['V2', 'Decision', 'Objective evaluation, comparisons, ties, winner sets, retained '
    + 'geometry, and claim scope.'],
  ['V3', 'Proof', 'Solver proof objects, bound certificates, regret witnesses, geometry '
    + 'equivalence, and completeness arguments.'],
  ['V4', 'Federation', 'Attestation, nonce, context, authorization, validity, revocation, '
    + 'and release-policy compliance.'],
];

function levelLadder(report) {
  const attempted = String(report.level_attempted || report.attempted || '');
  const achieved = String(report.level_achieved || report.achieved || '');
  return table('Verification levels (25.2)', [
    { label: 'Level' },
    { label: 'What it checks' },
    { label: 'This report' },
  ], LEVELS.map(([code, name, description]) => ({
    attributes: code === achieved ? ' data-achieved="true" class="crg-row--active"' : '',
    cells: [
      `<code class="crg-code">${esc(code)}</code> ${esc(name)}`,
      esc(description),
      code === achieved
        ? '<strong>Achieved</strong>'
        : (code === attempted
          ? '<strong>Attempted, not achieved</strong>'
          : '<span class="crg-prose">Not attempted</span>'),
    ],
  })));
}

function statusPanel(report) {
  const status = String(report.final_status || report.status || 'UNVERIFIED');
  const attempted = report.level_attempted || report.attempted;
  const achieved = report.level_achieved || report.achieved;
  const shortfall = attempted && achieved && attempted !== achieved;
  return panel('Verification status', join([
    verificationChip(status),
    `<p class="crg-prose">${esc((VERIFICATION_STATUSES[status] || [])[2]
      || '25.4 lists the statuses an independent verifier may report.')}</p>`,
    shortfall
      ? `<p class="crg-prose"><strong>This verification attempted `
        + `${esc(String(attempted))} and achieved ${esc(String(achieved))}.</strong> `
        + `The gap is not a formality: the checks between the two levels were not performed, `
        + `so whatever they would have established is not established.</p>`
      : '',
    definitionList([
      ['Bundle', hashChip(report.bundle_id || report.bundle_hash)],
      ['Verifier', report.verifier ? esc(report.verifier) : absent()],
      ['Verifier version', report.verifier_version ? esc(report.verifier_version) : absent()],
      ['Time judgment', report.time_judgment ? esc(report.time_judgment)
        : absent('UNSUPPORTED')],
      ['Signature judgment', report.signature_judgment ? esc(report.signature_judgment)
        : absent('UNSUPPORTED')],
      ['Claim judgment', report.claim_judgment ? esc(report.claim_judgment)
        : absent('UNSUPPORTED')],
    ]),
  ]), { principle: 'verified-or-replay' });
}

function checksPanel(report) {
  const passed = report.checks_passed || [];
  const failed = report.checks_failed || [];
  const unsupported = report.unsupported_checks || [];
  const missing = report.missing_objects || [];
  const redacted = report.redacted_dependencies || [];
  const list = (items, empty) => (items.length
    ? `<ul class="crg-list">${items.map((c) => `<li>${esc(
      typeof c === 'string' ? c : JSON.stringify(c),
    )}</li>`).join('')}</ul>`
    : `<p class="crg-prose">${esc(empty)}</p>`);
  return panel('What was and was not checked', join([
    `<h4 class="crg-subtitle">Failed</h4>`,
    list(failed, 'No check failed.'),
    `<h4 class="crg-subtitle">Not supported by this verifier</h4>`,
    list(unsupported, 'Every check in the attempted level was supported.'),
    `<h4 class="crg-subtitle">Objects the bundle did not contain</h4>`,
    list(missing, 'No referenced object was missing.'),
    `<h4 class="crg-subtitle">Dependencies that were redacted</h4>`,
    list(redacted, 'No dependency was redacted.'),
    `<h4 class="crg-subtitle">Passed</h4>`,
    list(passed, 'No check passed.'),
    `<p class="crg-prose">An unsupported check is not a passed check. 25.3 requires the `
    + `verifier to report them separately, and this screen keeps them separate for the same `
    + `reason: a reader who conflates them has read a stronger result than the one produced.</p>`,
  ]), { tone: failed.length ? 'warn' : 'neutral' });
}

function signaturesPanel(report) {
  const signatures = report.signatures || [];
  if (!signatures.length) {
    return panel('Signatures', emptyState(
      'This bundle carries no signatures. An unsigned bundle can still be verified for '
      + 'integrity and structure; it cannot be attributed.',
    ));
  }
  return table('Signatures', [
    { label: 'Signer' },
    { label: 'Key' },
    { label: 'Algorithm' },
    { label: 'Judgment' },
  ], signatures.map((signature) => ({
    cells: [
      signature.signer ? esc(signature.signer) : absent(),
      hashChip(signature.key_id),
      signature.algorithm ? esc(signature.algorithm) : absent(),
      signature.valid === true ? 'Valid'
        : (signature.valid === false ? 'Invalid' : absent('UNSUPPORTED')),
    ],
  })));
}

function independencePanel(state) {
  return panel('Why this is worth trusting', join([
    solverTrustChip(state.solverTrust),
    `<p class="crg-prose">Verification is performed by <code class="crg-code">crg-verify</code>, `
    + `which runs without this server, this database, the originating solver, this interface, `
    + `or a network (25.1). You can run it yourself against an exported bundle, and you should: `
    + `a verification you did not run is a verification you are trusting someone else to have `
    + `run.</p>`,
    `<div class="crg-actions">`
    + action('export-bundle', 'Export this case as a portable bundle', {
      operation: 'exportBundle',
    })
    + `</div>`,
  ]), { principle: 'verified-or-replay' });
}

function verifyForm(state) {
  return panel('Verify a bundle', join([
    select('verify-level', 'Level to attempt', LEVELS.map(([code, name]) => [code, `${code} — ${name}`]),
      { value: (state.form && state.form.level) || 'V3' }),
    `<div class="crg-field"><label class="crg-field__label" for="field-verify-bundle-file">Portable .crg bundle</label>`
      + `<input class="crg-input crg-input--file" id="field-verify-bundle-file" name="verify-bundle-file" type="file" accept=".crg,application/zip">`
      + `<p class="crg-field__hint">Choose a bundle up to 24 MiB. It is read in this tab and sent to the verifier endpoint; Studio never asks the server to read a local path.</p></div>`,
    disclosure('Advanced: paste base64 instead', field('verify-bundle', 'Base64 bundle data', {
      multiline: true, rows: 4,
      value: (state.form && state.form.bundle) || '',
      hint: 'Use this only when a file picker is unavailable. Do not provide both inputs.',
    })),
    `<div class="crg-actions">${action('verify-bundle', 'Verify', {
      operation: 'verifyBundle',
    })}</div>`,
  ]));
}

export const workspace = {
  ...meta,
  render(state = {}) {
    const report = state.report || (state.data || {}).report || (state.data || {}) || {};
    const hasReport = Boolean(report.final_status || report.status
      || report.level_achieved || report.achieved);
    if (!hasReport) {
      return shell(meta, join([
        verifyForm(state),
        independencePanel(state),
        levelLadder({}),
        notYet('No verification report is loaded. Verify an exported bundle to produce one.'),
      ]), state);
    }
    return shell(meta, join([
      verifyForm(state),
      statusPanel(report),
      levelLadder(report),
      checksPanel(report),
      signaturesPanel(report),
      independencePanel(state),
      disclosure('Verification report as stored', `<pre class="crg-pre" tabindex="0" `
        + `role="group" aria-label="Verification report">`
        + `${esc(JSON.stringify(report, null, 2))}</pre>`, { principle: 'why' }),
    ]), state);
  },
};

export default workspace;
