/**
 * Change Impact (spec 41.1): before-and-after differences, typed edges,
 * preserved claims, and required action.
 *
 * The useful question after a change is not "what broke" but "what survived
 * and why", so the preserved list is rendered first and with reasons.  30
 * makes recomputation proportional to the affected dependency subgraph;
 * showing which certificates were untouched, and which typed edge carried
 * the change to the ones that were, is what makes that claim inspectable
 * rather than merely fast.
 */

import {
  absent, definitionList, disclosure, emptyState, esc, hashChip, join, outcomeInfo, panel,
  quantity, table, verificationChip,
} from '../render.js';
import { action, field, notYet, shell } from '../workspace.js';

const meta = {
  id: 'change-impact',
  title: 'Change Impact',
  purpose: 'Before-and-after differences, typed edges, preserved claims, and required action.',
  endpoints: ['classifyChange', 'recomputeCase', 'getDependencies', 'getJobResult'],
};

const CLASSIFICATIONS = {
  NO_EFFECT: ['No effect on any claim', 'good',
    'The change touched nothing a certificate depends on.'],
  METADATA_ONLY: ['Metadata only', 'good',
    'Nothing semantic changed, so no certificate is disturbed (16.3).'],
  BOUND_PRESERVING: ['Within the existing bounds', 'good',
    'The change stays inside a bound the certificate already accounted for.'],
  RECOMPUTE_REQUIRED: ['Recomputation required', 'caution',
    'Affected certificates must be recomputed before they may be relied on again.'],
  CLAIM_INVALIDATING: ['Claims invalidated', 'blocked',
    'One or more certificates no longer hold and must be reissued.'],
  REOPEN_REQUIRED: ['Decision must be reopened', 'blocked',
    'A reopen condition recorded on the certificate has been met.'],
};

function classificationPanel(plan) {
  const key = String(plan.classification || '');
  const [label, tone, description] = CLASSIFICATIONS[key]
    || [key || 'Not classified', 'caution', '30 requires every change to be typed before it is applied.'];
  return panel('What this change did to the existing claims', join([
    `<p class="crg-classification crg-classification--${esc(tone)}" `
    + `data-classification="${esc(key)}">`
    + `<strong>${esc(label)}</strong> <span class="crg-visually-hidden">(${esc(key)})</span></p>`,
    `<p class="crg-prose">${esc(description)}</p>`,
  ]), { tone, principle: 'why' });
}

function preservedPanel(plan) {
  const preserved = plan.preserved || [];
  const invalidated = plan.invalidated || [];
  return panel('Claims preserved and claims lost', join([
    `<h4 class="crg-subtitle">Preserved</h4>`,
    preserved.length
      ? `<ul class="crg-list">${preserved.map((id) => `<li>${hashChip(id)} `
        + `<span class="crg-prose">nothing this certificate depends on changed</span></li>`).join('')}</ul>`
      : '<p class="crg-prose">No certificate survived this change unaffected.</p>',
    `<h4 class="crg-subtitle">Invalidated</h4>`,
    invalidated.length
      ? `<ul class="crg-list">${invalidated.map((id) => `<li>${hashChip(id)} `
        + `${verificationChip('FAILED')}</li>`).join('')}</ul>`
      : '<p class="crg-prose">No certificate was invalidated.</p>',
  ]), { tone: invalidated.length ? 'warn' : 'neutral' });
}

function affectedTable(plan) {
  const affected = plan.affected || {};
  const keys = Object.keys(affected).sort();
  if (!keys.length) {
    return emptyState('No object was reached by this change.');
  }
  return table('Objects the change reached, and the edge that carried it', [
    { label: 'Object' },
    { label: 'Typed edge', hint: '18.3 names the edge types; the type is what makes the reach explicit.' },
  ], keys.map((key) => ({
    cells: [hashChip(key), `<code class="crg-code">${esc(affected[key])}</code>`],
  })));
}

function beforeAfter(plan) {
  const diff = plan.diff || plan.differences || [];
  if (!diff.length) {
    return panel('Before and after', emptyState('No field-level differences are recorded.'));
  }
  return table('Field-level differences', [
    { label: 'What changed' },
    { label: 'Before' },
    { label: 'After' },
    { label: 'Unit' },
  ], diff.map((entry) => ({
    cells: [
      entry.path ? `<code class="crg-code">${esc(entry.path)}</code>` : absent(),
      entry.before === undefined ? absent('UNSUPPORTED')
        : quantity(entry.before, { unit: entry.unit || '' }),
      entry.after === undefined ? absent('UNSUPPORTED')
        : quantity(entry.after, { unit: entry.unit || '' }),
      entry.unit ? esc(entry.unit) : absent('NOT_APPLICABLE'),
    ],
  })));
}

function actionsPanel(plan) {
  const actions = plan.required_actions || [];
  return panel('What you must do now', join([
    actions.length
      ? `<ol class="crg-list crg-list--ordered">${actions
        .map((a) => `<li>${esc(a)}</li>`).join('')}</ol>`
      : '<p class="crg-prose">Nothing is required. The change was absorbed without '
        + 'disturbing a claim.</p>',
    `<div class="crg-actions">`
    + action('recompute', 'Recompute the affected certificates', { operation: 'recomputeCase' })
    + action('dependencies', 'Show the dependency graph', {
      operation: 'getDependencies', tone: 'secondary',
    })
    + `</div>`,
  ]), { tone: actions.length ? 'warn' : 'neutral' });
}

function outcomeShift(plan) {
  const before = plan.previous_outcome;
  const after = plan.current_outcome;
  if (!before && !after) return '';
  return panel('Did the answer change?', definitionList([
    ['Before', before ? esc(outcomeInfo(before).headline) : absent()],
    ['After', after ? esc(outcomeInfo(after).headline) : absent()],
    ['Reading this', `<p class="crg-prose">A change from a strict winner to a possible `
      + `winner set is not a regression in the software; it is the system declining to `
      + `keep a claim the evidence no longer supports (22.5).</p>`],
  ]), { principle: 'tie-vs-ambiguity' });
}

function changeForm(state) {
  return panel('Propose a change', join([
    field('change-set', 'Assignments', {
      multiline: true, rows: 6,
      value: (state.form && state.form.set) || '',
      hint: 'Each line names a realization, a coordinate, and the new value.',
    }),
    field('change-reason', 'Declared reason', {
      value: (state.form && state.form.reason) || '',
      hint: '30 requires a declared reason. It becomes part of the change record and is '
        + 'what a later reviewer reads.',
      required: true,
    }),
    field('change-authority', 'Authority', {
      value: (state.form && state.form.authority) || '',
      hint: 'Who is authorising this. 44.7 requires every mutation to be attributable.',
      required: true,
    }),
    `<div class="crg-actions">${action('classify-change', 'Classify this change', {
      operation: 'classifyChange',
    })}</div>`,
  ]));
}

export const workspace = {
  ...meta,
  render(state = {}) {
    const plan = (state.data || {}).impact || (state.data || {}).plan || state.plan || null;
    if (!plan) {
      return shell(meta, join([
        changeForm(state),
        notYet('No change has been classified against this case yet.'),
      ]), state);
    }
    return shell(meta, join([
      changeForm(state),
      classificationPanel(plan),
      outcomeShift(plan),
      preservedPanel(plan),
      affectedTable(plan),
      beforeAfter(plan),
      actionsPanel(plan),
      disclosure('Change plan as stored', `<pre class="crg-pre" tabindex="0" role="group" `
        + `aria-label="Change impact plan">${esc(JSON.stringify(plan, null, 2))}</pre>`,
      { principle: 'why' }),
    ]), state);
  },
};

export default workspace;
