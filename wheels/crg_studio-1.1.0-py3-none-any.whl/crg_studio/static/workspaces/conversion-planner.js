/**
 * Conversion Planner (spec 41.1): ownership maps, retained regions, residual
 * transfers, and schedules.
 *
 * A conversion moves obligations between owners, and the failure mode is a
 * residual that nobody notices they still hold.  Studio therefore renders
 * the residual before the schedule, and renders an unassigned residual as
 * unassigned rather than as a rounding difference near zero — the same
 * principle as 41.2's coordinate rule, applied where it is most expensive to
 * get wrong.
 */

import {
  absent, definitionList, disclosure, emptyState, esc, evidenceBadge, hashChip, join, panel,
  quantity, table,
} from '../render.js';
import { action, field, notYet, shell } from '../workspace.js';

const meta = {
  id: 'conversion-planner',
  title: 'Conversion Planner',
  purpose: 'Ownership maps, retained regions, residual transfers, and schedules.',
  endpoints: ['planConversion', 'getJobResult'],
};

function ownershipTable(plan) {
  const rows = plan.ownership_map || plan.ownership || [];
  if (!rows.length) {
    return emptyState('No ownership map is recorded on this plan.');
  }
  return table('Who holds what, before and after', [
    { label: 'Obligation' },
    { label: 'Held before' },
    { label: 'Held after' },
    { label: 'Amount' },
    { label: 'Evidence class' },
  ], rows.map((row) => ({
    cells: [
      row.coordinate ? `<code class="crg-code">${esc(row.coordinate)}</code>` : absent(),
      row.source_owner ? esc(row.source_owner) : absent(),
      row.target_owner ? esc(row.target_owner)
        : `<span class="crg-unmapped">Unassigned — no owner is recorded for this after `
          + `conversion</span>`,
      row.amount === undefined || row.amount === null
        ? absent('UNSUPPORTED') : quantity(row.amount, { unit: row.unit || '' }),
      evidenceBadge(row.evidence_class || 'DECLARED'),
    ],
  })));
}

function residualPanel(plan) {
  const residuals = plan.residuals || plan.residual_transfers || [];
  if (!residuals.length) {
    return panel('Residual', join([
      `<p class="crg-prose">No residual is recorded. That means the conversion accounts for `
      + `every obligation it touches — not that the amounts happen to cancel.</p>`,
    ]));
  }
  return panel('What the conversion leaves behind', join([
    table('Residual transfers', [
      { label: 'Obligation' },
      { label: 'Amount' },
      { label: 'Who ends up holding it' },
      { label: 'Justification' },
    ], residuals.map((residual) => ({
      cells: [
        residual.coordinate
          ? `<code class="crg-code">${esc(residual.coordinate)}</code>` : absent(),
        residual.amount === undefined || residual.amount === null
          ? absent('UNSUPPORTED') : quantity(residual.amount, { unit: residual.unit || '' }),
        residual.owner ? esc(residual.owner)
          : `<span class="crg-unmapped">Unassigned</span>`,
        residual.justification ? esc(residual.justification) : absent(),
      ],
    }))),
    `<p class="crg-prose">A residual with no owner is the conversion's open question. It is `
    + `shown as unassigned rather than absorbed, because an obligation that quietly `
    + `disappears from an ownership map has not gone anywhere.</p>`,
  ]), { tone: 'warn' });
}

function retainedPanel(plan) {
  const regions = plan.retained_regions || [];
  if (!regions.length) {
    return panel('Retained regions', emptyState(
      'No region is marked retained. Retention must preserve the decision-relevant geometry '
      + 'or the certificate over it is refused (29.2).',
    ));
  }
  return table('Regions retained through the conversion', [
    { label: 'Region' },
    { label: 'Why it is retained' },
    { label: 'Geometry preserved?' },
  ], regions.map((region) => ({
    cells: [
      region.region_id ? `<code class="crg-code">${esc(region.region_id)}</code>`
        : hashChip(region.hash),
      region.reason ? esc(region.reason) : absent(),
      region.geometry_preserved === false
        ? '<strong>No — a certificate over this retention will be refused</strong>'
        : 'Yes',
    ],
  })));
}

function schedulePanel(plan) {
  const steps = plan.schedule || plan.steps || [];
  if (!steps.length) {
    return panel('Schedule', emptyState('No transition schedule is recorded on this plan.'));
  }
  return table('Transition schedule', [
    { label: 'Step' },
    { label: 'Action' },
    { label: 'Precondition' },
    { label: 'Rollback' },
    { label: 'When' },
  ], steps.map((step, index) => ({
    cells: [
      `<span>${esc(String(index + 1))}</span>`,
      step.action ? esc(step.action) : absent(),
      step.precondition ? esc(step.precondition)
        : `<span class="crg-unmapped">None recorded — this step has nothing gating it</span>`,
      step.rollback ? esc(step.rollback)
        : `<span class="crg-unmapped">No rollback recorded</span>`,
      step.at ? esc(step.at) : absent('UNSUPPORTED'),
    ],
  })));
}

function planForm(state) {
  return panel('Plan a conversion', join([
    field('conversion-source', 'Source layout or ownership', {
      multiline: true, rows: 6,
      value: (state.form && state.form.source) || '',
      hint: 'The arrangement being converted from.',
    }),
    field('conversion-target', 'Target layout or ownership', {
      multiline: true, rows: 6,
      value: (state.form && state.form.target) || '',
      hint: 'The arrangement being converted to.',
    }),
    `<div class="crg-actions">${action('plan-conversion', 'Plan the conversion', {
      operation: 'planConversion',
    })}</div>`,
  ]));
}

export const workspace = {
  ...meta,
  render(state = {}) {
    const plan = state.plan || (state.data || {}).conversion_plan || (state.data || {}) || {};
    if (!plan || (!plan.ownership_map && !plan.residuals && !plan.schedule)) {
      return shell(meta, join([
        planForm(state),
        notYet('No conversion has been planned for this case yet.'),
      ]), state);
    }
    return shell(meta, join([
      planForm(state),
      panel('Summary', definitionList([
        ['Plan', hashChip(plan.plan_id || plan.content_hash)],
        ['From', plan.source_id ? esc(plan.source_id) : absent()],
        ['To', plan.target_id ? esc(plan.target_id) : absent()],
        ['Certificate effect', plan.certificate_effect ? esc(plan.certificate_effect)
          : '<span class="crg-prose">Not recorded. A conversion that changes the retained '
            + 'set changes what the existing certificates are about (30).</span>'],
      ])),
      residualPanel(plan),
      ownershipTable(plan),
      retainedPanel(plan),
      schedulePanel(plan),
      disclosure('Plan as stored', `<pre class="crg-pre" tabindex="0" role="group" `
        + `aria-label="Conversion plan">${esc(JSON.stringify(plan, null, 2))}</pre>`,
      { principle: 'why' }),
    ]), state);
  },
};

export default workspace;
