/**
 * Decision Query (spec 41.1): query authoring, derivation, required object,
 * and refusal explanations.
 *
 * Compilation is the step that decides *what would have to be true* for a
 * question to be answerable, so a refusal here is the most useful output the
 * system produces: it names the object the question needs and does not have.
 * Studio renders a refusal with the same weight as a success, and never as
 * an error dialog, because 6.6's fail-closed behaviour is a feature the user
 * is supposed to read rather than dismiss.
 */

import {
  absent, definitionList, disclosure, emptyState, esc, hashChip, join, panel, table,
} from '../render.js';
import { action, field, notYet, shell } from '../workspace.js';

const meta = {
  id: 'decision-query',
  title: 'Decision Query',
  purpose: 'Query authoring, derivation, required object, and refusal explanations.',
  endpoints: ['compileQuery', 'getCase'],
};

const DECISION_CLASSES = {
  SELECTION: 'Choose one realization from the family.',
  FEASIBILITY: 'Decide whether anything in the family satisfies the requirement.',
  COMPARISON: 'Compare two named realizations.',
  RANKING: 'Order the family.',
  BOUND: 'Establish a bound rather than a choice.',
};

function queryForm(state) {
  return panel('Ask a question', join([
    field('question', 'The question, in plain language', {
      value: (state.form && state.form.question) || '',
      hint: 'What decision are you actually trying to make? This is recorded on the '
        + 'certificate and is what an auditor reads first (50.2 item 1).',
    }),
    field('query-document', 'Query document', {
      multiline: true, rows: 10,
      value: (state.form && state.form.query) || '',
      hint: 'The typed decision query of specification 26. Compilation refuses a query it '
        + 'cannot answer soundly rather than answering a nearby one.',
    }),
    `<div class="crg-actions">${action('compile-query', 'Compile this query', {
      operation: 'compileQuery',
    })}</div>`,
  ]));
}

function derivationPanel(payload) {
  const derivation = payload.derivation || {};
  return panel('What this question compiled to', definitionList([
    ['Decision class', derivation.decision_class
      ? `<code class="crg-code">${esc(derivation.decision_class)}</code>`
        + ` <span class="crg-prose">${esc(DECISION_CLASSES[derivation.decision_class] || '')}</span>`
      : absent()],
    ['Smallest object that can answer it', derivation.required_object
      ? `<code class="crg-code">${esc(derivation.required_object)}</code>`
        + ` <span class="crg-prose">Anything larger would be retained without cause; `
        + `anything smaller cannot answer the question (26).</span>`
      : absent()],
    ['Rule cited', derivation.rule_cited ? esc(derivation.rule_cited) : absent()],
    ['Mapping table version', derivation.mapping_table_version
      ? esc(derivation.mapping_table_version) : absent()],
    ['Query hash', hashChip(derivation.query_hash)],
    ['Decision scope', payload.scope_id
      ? `<code class="crg-code">${esc(payload.scope_id)}</code>` : absent()],
  ]), { principle: 'why' });
}

function refusalsPanel(payload) {
  const refusals = (payload.derivation || {}).refusals || [];
  if (!refusals.length) {
    return panel('Refusals', emptyState(
      'The compiler raised no refusals. It will still refuse at certification time if the '
      + 'evidence turns out not to support the comparison.',
    ));
  }
  return panel('Why parts of this question cannot be answered', join([
    `<ul class="crg-list">${refusals.map((r) => `<li>${esc(r)}</li>`).join('')}</ul>`,
    `<p class="crg-prose">Each refusal names something the question needs and the case does `
    + `not have. Supplying it is the cheapest way forward; rewriting the question to avoid `
    + `it changes what you are asking (26).</p>`,
  ]), { tone: 'warn', principle: 'why' });
}

function historyPanel(state) {
  const history = state.history || [];
  if (!history.length) return '';
  return table('Questions compiled against this case', [
    { label: 'Question' },
    { label: 'Decision class' },
    { label: 'Required object' },
    { label: 'Refused?' },
  ], history.map((entry) => ({
    cells: [
      entry.question ? esc(entry.question) : absent(),
      entry.decision_class ? `<code class="crg-code">${esc(entry.decision_class)}</code>` : absent(),
      entry.required_object ? `<code class="crg-code">${esc(entry.required_object)}</code>` : absent(),
      (entry.refusals || []).length ? 'Yes' : 'No',
    ],
  })));
}

export const workspace = {
  ...meta,
  render(state = {}) {
    const payload = state.data || null;
    if (!payload || !payload.derivation) {
      return shell(meta, join([
        queryForm(state),
        historyPanel(state),
        notYet('No question has been compiled against this case yet.'),
      ]), state);
    }
    return shell(meta, join([
      queryForm(state),
      derivationPanel(payload),
      refusalsPanel(payload),
      historyPanel(state),
      disclosure('Compiled scope as stored', `<pre class="crg-pre" tabindex="0" role="group" `
        + `aria-label="Compiled decision scope">${esc(JSON.stringify(payload, null, 2))}</pre>`,
      { principle: 'why' }),
    ]), state);
  },
};

export default workspace;
