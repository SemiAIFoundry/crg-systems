/**
 * Completeness Center (spec 41.1): family basis, known omissions, bounds,
 * truncation, and claim implications.
 *
 * 21.1 is the sentence this workspace exists to keep in front of the user:
 * "CRG software generally holds a represented family, not an automatic proof
 * of the universal legal family."  Everything else in Studio shows what the
 * system found; this shows what it did not look at, and what that costs the
 * claim.  The claim-implication table is rendered from the same mapping the
 * kernel derives scopes with, so the consequence is stated before the
 * certificate exists rather than discovered after it does.
 */

import {
  absent, claimScopeChip, CLAIM_SCOPES, completenessPanel, definitionList, esc,
  hashChip, join, panel, table,
} from '../render.js';
import { action, notYet, shell } from '../workspace.js';

const meta = {
  id: 'completeness-center',
  title: 'Completeness Center',
  purpose: 'Family basis, known omissions, bounds, truncation, and claim implications.',
  endpoints: ['getCase', 'listCertificates'],
};

/** 21.2 crossed with 21.4: what each basis is allowed to support. */
const IMPLICATIONS = [
  ['EXHAUSTIVE_DECLARED_UNIVERSE', 'FULL_DECLARED_UNIVERSE',
    'Everything in the declared universe was enumerated and checked.'],
  ['GENERATOR_CLOSED', 'GENERATOR_CLOSED_FAMILY',
    'The registry is closed under the declared generator set.'],
  ['BOUNDED_UNENUMERATED_FAMILY', 'BOUNDED_REMAINDER_GLOBAL',
    'Only with a recorded bound and a closure proof. Without both, this basis degrades '
    + 'to a partial family (21.6).'],
  ['EXPLICIT_IMPORTED_FAMILY', 'RELATIVE_EXPLICIT_FAMILY',
    'A winner here is a winner among the candidates someone imported, and nothing more.'],
  ['TRUNCATED_BY_DECLARED_RULE', 'PARTIAL_FAMILY',
    'Enumeration stopped on purpose. The rule that stopped it is part of the record.'],
  ['KNOWN_INCOMPLETE', 'PARTIAL_FAMILY',
    'Legal candidates are known to be missing. No winner may be claimed.'],
  ['UNKNOWN', 'PARTIAL_FAMILY',
    'Completeness was never established. No winner may be claimed.'],
];

function implicationsTable(activeBasis) {
  return table('What each completeness basis permits a certificate to claim', [
    { label: 'Completeness basis' },
    { label: 'Strongest claim scope it can support' },
    { label: 'May a winner be phrased globally?' },
    { label: 'Condition' },
  ], IMPLICATIONS.map(([basis, scope, condition]) => ({
    attributes: basis === activeBasis
      ? ' class="crg-row--active" data-active="true"' : '',
    cells: [
      `<code class="crg-code">${esc(basis)}</code>`
      + (basis === activeBasis
        ? ' <strong class="crg-tag">this case</strong>' : ''),
      claimScopeChip(scope, { withSymbol: false }),
      CLAIM_SCOPES[scope].global ? 'Yes, within the declared scope' : 'No',
      esc(condition),
    ],
  })));
}

function omissionsPanel(basis) {
  const omissions = (basis || {}).known_omissions || [];
  return panel('What is known to be missing', join([
    omissions.length
      ? `<ul class="crg-list">${omissions.map((o) => `<li>${esc(o)}</li>`).join('')}</ul>`
      : `<p class="crg-prose">Nothing is recorded as knowingly omitted. That is a statement `
        + `about what was recorded, not a proof that nothing is missing — read it together `
        + `with the basis type above.</p>`,
    `<p class="crg-prose">A known omission does not invalidate a case. It fixes how strong a `
    + `claim the case can carry (21.5), which is a different and more useful thing.</p>`,
  ]), { tone: omissions.length ? 'warn' : 'neutral', principle: 'completeness' });
}

function boundsPanel(basis) {
  const record = basis || {};
  const hasBound = Boolean(record.remainder_bound);
  const hasProof = Boolean(record.closure_proof);
  return panel('The unenumerated remainder', definitionList([
    ['Bound recorded', hasBound ? esc(record.remainder_bound) : absent('UNENUMERATED')],
    ['Closure proof recorded', hasProof ? esc(record.closure_proof) : absent('UNENUMERATED')],
    ['Does the remainder close?', hasBound && hasProof
      ? '<span class="crg-prose">Yes. The part of the family never enumerated is proved '
        + 'unable to change the result, so a global claim is permitted (21.6).</span>'
      : '<span class="crg-prose">No. 21.6 requires <em>both</em> a bound covering the '
        + 'unenumerated region and a proof that it cannot change the decision. A search that '
        + 'terminated is not a proof that it was exhaustive.</span>'],
    ['Stopping rule', record.truncation_rule ? esc(record.truncation_rule)
      : absent('NOT_APPLICABLE')],
  ]), { tone: hasBound && hasProof ? 'neutral' : 'warn', principle: 'completeness' });
}

function certificateScopes(state) {
  const certificates = ((state.data || {}).certificates) || [];
  if (!certificates.length) return '';
  return table('Claim scope carried by each certificate on this case', [
    { label: 'Certificate' },
    { label: 'Outcome' },
    { label: 'Claim scope' },
    { label: 'Completeness basis' },
  ], certificates.map((certificate) => ({
    cells: [
      hashChip(certificate.certificate_id),
      certificate.outcome ? `<code class="crg-code">${esc(certificate.outcome)}</code>` : absent(),
      claimScopeChip(certificate.claim_scope),
      certificate.completeness_basis
        ? `<code class="crg-code">${esc(certificate.completeness_basis)}</code>` : absent(),
    ],
  })));
}

export const workspace = {
  ...meta,
  render(state = {}) {
    const record = ((state.data || {}).case || {});
    const basis = (record.registry || {}).completeness || record.completeness || null;
    if (!basis) {
      return shell(meta, join([
        implicationsTable(null),
        notYet(
          'This case declares no completeness basis yet. Until it does, any certificate over '
          + 'it is a partial-family claim and may not name a winner (21.5).',
          `<div class="crg-actions">${action('reload-case', 'Reload the case', {
            operation: 'getCase',
          })}</div>`,
        ),
      ]), state);
    }
    return shell(meta, join([
      completenessPanel(basis),
      boundsPanel(basis),
      omissionsPanel(basis),
      implicationsTable(String(basis.basis_type || '')),
      certificateScopes(state),
      panel('Source of the family', definitionList([
        ['Declared universe', basis.declared_universe ? esc(basis.declared_universe) : absent()],
        ['Source or generator hash', basis.source_or_generator_hash
          ? hashChip(basis.source_or_generator_hash) : absent()],
        ['Generator versions', (basis.generator_versions || []).length
          ? esc((basis.generator_versions || []).join(', ')) : absent()],
        ['Closure procedure', basis.closure_procedure ? esc(basis.closure_procedure) : absent()],
        ['Depends on', (basis.dependencies || []).length
          ? `<ul class="crg-list">${(basis.dependencies || [])
            .map((d) => `<li>${hashChip(d)}</li>`).join('')}</ul>` : absent()],
      ])),
    ]), state);
  },
};

export default workspace;
