/**
 * Evidence Graph (spec 41.1): source context, applicability, uncertainty,
 * conflict, and lineage.
 *
 * Two things are deliberately not smoothed over here.  Conflicting evidence
 * is shown as conflict and never averaged: 33 keeps applicability a typed
 * judgment, and two measurements that disagree are information about the
 * measurement context, not noise to be resolved by arithmetic.  And evidence
 * whose source context differs from the target context is marked as
 * transferred, with the transfer's own uncertainty, because applicability is
 * the assumption that most often fails silently.
 */

import {
  absent, definitionList, disclosure, emptyState, esc, evidenceBadge, evidenceLegend, hashChip,
  interval, join, panel, quantity, table,
} from '../render.js';
import { action, field, notYet, shell } from '../workspace.js';

const meta = {
  id: 'evidence-graph',
  title: 'Evidence Graph',
  purpose: 'Source context, applicability, uncertainty, conflict, and lineage.',
  endpoints: ['registerEvidence', 'assembleTechnologyContract', 'getDependencies', 'getJobResult'],
};

function evidenceTable(records) {
  if (!records.length) {
    return emptyState('No evidence records are registered against this case.');
  }
  return table('Evidence records', [
    { label: 'Evidence' },
    { label: 'Class' },
    { label: 'Quantity' },
    { label: 'Value' },
    { label: 'Uncertainty' },
    { label: 'Source context' },
    { label: 'Valid until' },
  ], records.map((record) => ({
    attributes: ` data-evidence="${esc(record.evidence_id || '')}"`,
    cells: [
      hashChip(record.evidence_id || record.content_hash),
      evidenceBadge(record.evidence_class),
      record.quantity ? esc(record.quantity) : absent(),
      record.value === undefined || record.value === null
        ? absent('UNSUPPORTED')
        : quantity(record.value, { unit: record.unit || '' }),
      record.interval ? interval(record.interval, { kind: 'evidence' }) : absent('UNSUPPORTED'),
      record.source_context ? esc(record.source_context) : absent(),
      record.validity ? esc(record.validity) : absent('UNSUPPORTED'),
    ],
  })));
}

function applicabilityPanel(records) {
  const transferred = records.filter((r) => r.target_context
    && r.target_context !== r.source_context);
  if (!transferred.length) {
    return panel('Applicability', emptyState(
      'No evidence here was transferred between contexts. When it is, the transfer carries '
      + 'its own uncertainty and its own justification (33).',
    ));
  }
  return panel('Evidence used outside the context it was produced in', table(
    'Transferred evidence',
    [
      { label: 'Evidence' },
      { label: 'Produced in' },
      { label: 'Used for' },
      { label: 'Transfer justification' },
      { label: 'Added uncertainty' },
    ],
    transferred.map((record) => ({
      cells: [
        hashChip(record.evidence_id),
        esc(record.source_context || ''),
        esc(record.target_context || ''),
        record.transfer_rule ? esc(record.transfer_rule)
          : `<span class="crg-unmapped">No transfer rule recorded — applicability is `
            + `assumed, not justified</span>`,
        record.transfer_interval
          ? interval(record.transfer_interval, { kind: 'evidence' }) : absent('UNSUPPORTED'),
      ],
    })),
  ), { tone: 'warn', principle: 'evidence-classes' });
}

function conflictPanel(conflicts) {
  if (!conflicts.length) {
    return panel('Conflicts', emptyState(
      'No conflicting evidence is recorded. Conflicts are kept as conflicts when they occur; '
      + 'they are never averaged away.',
    ));
  }
  return panel('Evidence that disagrees', join([
    table('Conflicts', [
      { label: 'Quantity' },
      { label: 'Records in conflict' },
      { label: 'Nature of the disagreement' },
      { label: 'Resolution' },
    ], conflicts.map((conflict) => ({
      cells: [
        conflict.quantity ? esc(conflict.quantity) : absent(),
        `<ul class="crg-list">${(conflict.records || [])
          .map((r) => `<li>${hashChip(r)}</li>`).join('')}</ul>`,
        conflict.description ? esc(conflict.description) : absent(),
        conflict.resolution
          ? esc(conflict.resolution)
          : `<span class="crg-unmapped">Unresolved — the conservative range below spans `
            + `both records</span>`,
      ],
    }))),
    `<p class="crg-prose">An unresolved conflict widens the conservative range rather than `
    + `being settled by preference. That is usually what turns a strict winner into a `
    + `possible winner set, and the Qualification Planner will rank the experiment that `
    + `would settle it.</p>`,
  ]), { tone: 'warn', principle: 'resolving-evidence' });
}

function lineagePanel(dependencies) {
  const edges = (dependencies || {}).content_edges || (dependencies || {}).logical_edges || [];
  if (!edges.length) {
    return panel('Lineage', emptyState('No dependency edges are recorded for this case yet.'));
  }
  return table('Typed dependency edges', [
    { label: 'From' },
    { label: 'Edge type', hint: '18.3 fixes the edge vocabulary.' },
    { label: 'To' },
    { label: 'Recorded' },
  ], edges.map((edge) => ({
    cells: [
      hashChip(edge.from || edge.source),
      `<code class="crg-code">${esc(edge.edge_type || edge.type || '')}</code>`,
      hashChip(edge.to || edge.target),
      edge.recorded_at ? esc(edge.recorded_at) : absent(),
    ],
  })));
}

function contractPanel(contract) {
  if (!contract) {
    return panel('Technology contract', emptyState(
      'No technology contract has been assembled. A contract is what turns a pile of '
      + 'evidence records into a statement about what a technology can do in a named '
      + 'context (33.6).',
    ));
  }
  return panel('Technology contract', definitionList([
    ['Contract', hashChip(contract.contract_id || contract.content_hash)],
    ['Target context', contract.target_context ? esc(contract.target_context) : absent()],
    ['Coordinates covered', (contract.coordinates || []).length
      ? `<ul class="crg-list">${(contract.coordinates || [])
        .map((c) => `<li><code class="crg-code">${esc(c)}</code></li>`).join('')}</ul>`
      : absent()],
    ['Rules applied', (contract.rules || []).length
      ? `<ul class="crg-list">${(contract.rules || [])
        .map((r) => `<li>${esc(typeof r === 'string' ? r : JSON.stringify(r))}</li>`).join('')}</ul>`
      : absent()],
    ['Evidence class of the whole', evidenceBadge(contract.evidence_class || 'MODELED')],
    ['Valid until', contract.validity ? esc(contract.validity) : absent('UNSUPPORTED')],
  ]));
}

function registerForm(state) {
  return panel('Register evidence', join([
    field('evidence-record', 'Evidence record', {
      multiline: true, rows: 10,
      value: (state.form && state.form.evidence) || '',
      hint: 'The typed evidence record of 33.2, including its source context, its class, '
        + 'and its validity. An evidence class is required; there is no default.',
    }),
    `<div class="crg-actions">`
    + action('register-evidence', 'Register this evidence', { operation: 'registerEvidence' })
    + action('assemble-contract', 'Assemble a technology contract', {
      operation: 'assembleTechnologyContract', tone: 'secondary',
    })
    + `</div>`,
  ]));
}

export const workspace = {
  ...meta,
  render(state = {}) {
    const payload = state.data || {};
    const records = payload.evidence_records || payload.evidence || [];
    const list = Array.isArray(records) ? records : [records].filter(Boolean);
    if (!list.length && !payload.dependencies) {
      return shell(meta, join([
        registerForm(state),
        panel('How to read the evidence badges', evidenceLegend(),
          { principle: 'evidence-classes' }),
        notYet('No evidence has been registered against this case yet.'),
      ]), state);
    }
    return shell(meta, join([
      registerForm(state),
      panel('How to read the evidence badges', evidenceLegend(),
        { principle: 'evidence-classes' }),
      evidenceTable(list),
      applicabilityPanel(list),
      conflictPanel(payload.conflicts || []),
      contractPanel(payload.technology_contract),
      lineagePanel(payload.dependencies),
      disclosure('Evidence records as stored', `<pre class="crg-pre" tabindex="0" role="group" `
        + `aria-label="Evidence records">${esc(JSON.stringify(list, null, 2))}</pre>`,
      { principle: 'why' }),
    ]), state);
  },
};

export default workspace;
