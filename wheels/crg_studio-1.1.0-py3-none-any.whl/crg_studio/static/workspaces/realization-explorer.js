/**
 * Realization Explorer (spec 41.1): legal and rejected candidates, fibers,
 * parentage, choices, and witnesses.
 *
 * The rejected list is given equal weight to the legal one.  28.4 keeps
 * `UNGENERATED` and `INFEASIBLE` apart, and 6.11 forbids silent truncation:
 * a family that shows only its survivors invites the reader to believe the
 * generator considered nothing else.  Parentage and the recorded choices are
 * shown per candidate because a realization is the record of a decision
 * procedure, not just a point.
 */

import {
  absent, completenessPanel, disclosure, emptyState, esc, evidenceBadge,
  hashChip, join, panel, quantity, signatureText, table,
} from '../render.js';
import { action, field, notYet, shell } from '../workspace.js';

const meta = {
  id: 'realization-explorer',
  title: 'Realization Explorer',
  purpose: 'Legal and rejected candidates, fibers, parentage, choices, and witnesses.',
  endpoints: ['generateFamily', 'getCase', 'getJob', 'getJobResult'],
};

function coordinateColumns(schema) {
  return ((schema || {}).coordinates || []).map((c) => ({
    label: c.identifier,
    hint: `${c.quantity || c.identifier} in ${c.unit || 'no declared unit'}, `
      + `${c.direction === 'MAXIMIZE' ? 'higher is better' : 'lower is better'}.`,
    unit: c.unit || '',
  }));
}

function legalTable(registry) {
  const schema = registry.schema || {};
  const columns = coordinateColumns(schema);
  const records = registry.realizations || [];
  if (!records.length) {
    return emptyState('This case has no legal realizations yet. Generate or import a family.');
  }
  return table('Legal realizations', [
    { label: 'Realization' },
    ...columns,
    { label: 'Evidence class' },
    { label: 'Parentage', hint: 'The seed and generator step this candidate came from (28.3).' },
  ], records.map((record) => ({
    attributes: ` data-realization="${esc(record.realization_id || '')}"`,
    cells: [
      `<span class="crg-realization__name">${esc(record.realization_id || '')}</span>`,
      ...columns.map((column, index) => {
        const values = record.values || {};
        const raw = values[column.label] !== undefined
          ? values[column.label]
          : ((record.signature || {}).values || record.signature || [])[index];
        return quantity(raw, { unit: column.unit });
      }),
      evidenceBadge(record.evidence_class),
      record.parent ? hashChip(record.parent)
        : `<span class="crg-prose">Seed candidate</span>`,
    ],
  })));
}

function rejectedTable(report) {
  const rejected = (report || {}).rejected || [];
  if (!rejected.length) {
    return panel('Rejected candidates', emptyState(
      'No candidate was rejected during generation. That is a statement about this run, '
      + 'not a guarantee that the family is complete — see the completeness basis.',
    ));
  }
  return table('Rejected candidates and why', [
    { label: 'Candidate' },
    { label: 'Reason' },
    { label: 'Kind', hint: '28.4 keeps "never generated" and "generated but infeasible" apart.' },
    { label: 'Rule cited' },
  ], rejected.map((record) => ({
    cells: [
      record.realization_id
        ? `<span class="crg-realization__name">${esc(record.realization_id)}</span>`
        : signatureText(record.signature),
      record.reason ? esc(record.reason) : absent(),
      record.kind ? `<code class="crg-code">${esc(record.kind)}</code>` : absent(),
      record.rule ? esc(record.rule) : absent(),
    ],
  })));
}

function fibersPanel(registry) {
  const fibers = registry.fibers || [];
  if (!fibers.length) {
    return panel('Fibers', emptyState(
      'No fibers are recorded. A fiber is the set of distinct realizations that share an '
      + 'obligation signature: they cost the same but are not the same thing (19.6).',
    ));
  }
  return table('Fibers: realizations sharing one obligation signature', [
    { label: 'Signature' },
    { label: 'Members' },
    { label: 'Why they differ', hint: 'The choices that distinguish members of one fiber.' },
  ], fibers.map((fiber) => ({
    cells: [
      signatureText(fiber.signature),
      `<ul class="crg-realization-list" aria-label="Fiber members">`
      + (fiber.members || []).map((m) => `<li class="crg-realization">`
        + `<span class="crg-realization__name">${esc(m)}</span></li>`).join('')
      + `</ul>`,
      (fiber.choices || []).length
        ? `<ul class="crg-list">${(fiber.choices || [])
          .map((c) => `<li>${esc(typeof c === 'string' ? c : JSON.stringify(c))}</li>`).join('')}</ul>`
        : absent('UNSUPPORTED'),
    ],
  })));
}

function witnessPanel(registry) {
  const witnesses = (registry.realizations || []).filter((r) => r.witness);
  if (!witnesses.length) {
    return panel('Witnesses', emptyState(
      'No constructive witness is attached to any candidate here. A witness is what turns '
      + '"this looks achievable" into a constructive claim (5.3).',
    ));
  }
  return table('Constructive witnesses', [
    { label: 'Realization' },
    { label: 'Witness' },
    { label: 'Evidence class' },
  ], witnesses.map((record) => ({
    cells: [
      `<span class="crg-realization__name">${esc(record.realization_id || '')}</span>`,
      typeof record.witness === 'string' ? esc(record.witness)
        : `<pre class="crg-pre" tabindex="0" role="group" aria-label="Witness record">`
          + `${esc(JSON.stringify(record.witness, null, 2))}</pre>`,
      evidenceBadge(record.evidence_class),
    ],
  })));
}

function generateForm(state) {
  return panel('Generate a family', join([
    field('generator', 'Generator profile', {
      value: (state.form && state.form.generator) || '',
      hint: 'A profile this deployment does not implement is refused, never substituted (28.4).',
    }),
    field('generator-request', 'Generation request', {
      multiline: true, rows: 8,
      value: (state.form && state.form.request) || '',
      hint: 'Seeds, capabilities, parameters, and any declared limits on depth or size.',
    }),
    `<div class="crg-actions">`
    + action('generate', 'Generate', { operation: 'generateFamily' })
    + action('reload-case', 'Reload the registry', { operation: 'getCase', tone: 'secondary' })
    + `</div>`,
  ]));
}

export const workspace = {
  ...meta,
  render(state = {}) {
    const registry = ((state.data || {}).case || {}).registry
      || (state.data || {}).registry || null;
    if (!registry) {
      return shell(meta, join([
        generateForm(state),
        notYet('This case has no realization registry yet.'),
      ]), state);
    }
    const report = ((state.data || {}).case || {}).generation_report
      || (state.data || {}).generation_report || {};
    return shell(meta, join([
      generateForm(state),
      completenessPanel(registry.completeness),
      legalTable(registry),
      rejectedTable(report),
      fibersPanel(registry),
      witnessPanel(registry),
      disclosure('Generation report as stored', `<pre class="crg-pre" tabindex="0" role="group" `
        + `aria-label="Generation report">${esc(JSON.stringify(report, null, 2))}</pre>`,
      { principle: 'why' }),
    ]), state);
  },
};

export default workspace;
