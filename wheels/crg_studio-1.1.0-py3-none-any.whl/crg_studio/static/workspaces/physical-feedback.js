/**
 * Physical Feedback (spec 41.1): evaluator requests, results, evidence
 * classes, and witness refinement.
 *
 * The boundary between what was computed and what was measured runs through
 * this workspace, so the evidence class of every returned result is shown at
 * the same size as the number itself.  A measured value that arrives without
 * a declared class is rendered as undeclared and not quietly promoted: 5.3
 * requires the classes to remain distinct, and the class is what decides
 * whether a later certificate may lean on the value at all.
 */

import {
  absent, definitionList, disclosure, emptyState, esc, evidenceBadge, evidenceLegend, hashChip,
  interval, join, panel, quantity, signatureText, table,
} from '../render.js';
import { action, field, notYet, shell } from '../workspace.js';

const meta = {
  id: 'physical-feedback',
  title: 'Physical Feedback',
  purpose: 'Evaluator requests, results, evidence classes, and witness refinement.',
  endpoints: ['createEvaluatorRequest', 'evaluateFamily', 'registerEvidence', 'getJobResult',
    'executeTransition'],
};

const REQUEST_STATES = {
  REQUESTED: ['Requested', 'The request is recorded and waiting for an evaluator.'],
  ACCEPTED: ['Accepted', 'An evaluator has taken it on.'],
  IN_PROGRESS: ['Being evaluated', 'Work is under way.'],
  RETURNED: ['Result returned', 'A result is available and can be registered as evidence.'],
  REFUSED: ['Refused by the evaluator', 'No result will arrive; the reason is recorded.'],
  EXPIRED: ['Expired', 'The request outlived its validity window.'],
};

function requestTable(requests) {
  if (!requests.length) {
    return emptyState('No evaluator requests are recorded for this case.');
  }
  return table('Evaluator requests', [
    { label: 'Request' },
    { label: 'What is being evaluated' },
    { label: 'State' },
    { label: 'Evaluator' },
    { label: 'Requested' },
  ], requests.map((request) => {
    const [label, description] = REQUEST_STATES[request.state]
      || ['State not recorded', '32.1 requires the request state to be typed.'];
    return {
      attributes: ` data-request="${esc(request.request_id || '')}"`,
      cells: [
        hashChip(request.request_id || request.content_hash),
        request.target ? esc(request.target)
          : (request.realization_id
            ? `<span class="crg-realization__name">${esc(request.realization_id)}</span>`
            : absent()),
        `<span title="${esc(description)}">${esc(label)}</span>`,
        request.evaluator ? esc(request.evaluator) : absent('UNSUPPORTED'),
        request.requested_at ? esc(request.requested_at) : absent(),
      ],
    };
  }));
}

function resultsTable(results) {
  if (!results.length) {
    return emptyState('No evaluator results have come back yet.');
  }
  return table('Results returned by physical evaluators', [
    { label: 'Result' },
    { label: 'Coordinate' },
    { label: 'Value' },
    { label: 'Measurement uncertainty' },
    { label: 'Evidence class' },
    { label: 'Instrument or method' },
  ], results.map((result) => ({
    cells: [
      hashChip(result.result_id || result.content_hash),
      result.coordinate ? `<code class="crg-code">${esc(result.coordinate)}</code>` : absent(),
      result.value === undefined || result.value === null
        ? absent('UNSUPPORTED') : quantity(result.value, { unit: result.unit || '' }),
      result.interval ? interval(result.interval, { kind: 'evidence' }) : absent('UNSUPPORTED'),
      evidenceBadge(result.evidence_class),
      result.method ? esc(result.method) : absent('UNSUPPORTED'),
    ],
  })));
}

function refinementPanel(refinements) {
  if (!refinements.length) {
    return panel('Witness refinement', emptyState(
      'No witness has been refined by physical feedback yet. When a measurement narrows a '
      + 'witness, both the original and the refined form are kept: the refinement is a new '
      + 'record, not an edit (6.4).',
    ));
  }
  return table('Witnesses refined by measurement', [
    { label: 'Realization' },
    { label: 'Before' },
    { label: 'After' },
    { label: 'What the measurement settled' },
    { label: 'Evidence class' },
  ], refinements.map((refinement) => ({
    cells: [
      `<span class="crg-realization__name">${esc(refinement.realization_id || '')}</span>`,
      signatureText(refinement.before),
      signatureText(refinement.after),
      refinement.resolved ? esc(refinement.resolved) : absent(),
      evidenceBadge(refinement.evidence_class || 'MEASURED'),
    ],
  })));
}

function boundaryPanel() {
  return panel('Computed, measured, or asserted?', join([
    `<p class="crg-prose">Everything on this screen crossed the boundary between the model `
    + `and the world, in one direction or the other. The badge on each value says which side `
    + `it came from, and the system will not let a modelled value stand in for a measured one `
    + `without the substitution being recorded.</p>`,
    evidenceLegend(),
  ]), { principle: 'evidence-classes' });
}

function requestForm(state) {
  return panel('Request a physical evaluation', join([
    field('evaluator-request', 'Evaluator request', {
      multiline: true, rows: 10,
      value: (state.form && state.form.request) || '',
      hint: 'What must be evaluated, under what conditions, and what would count as an '
        + 'answer (32.1).',
    }),
    `<div class="crg-actions">`
    + action('create-request', 'Record this request', { operation: 'createEvaluatorRequest' })
    + action('register-result', 'Register a returned result as evidence', {
      operation: 'registerEvidence', tone: 'secondary',
    })
    + `</div>`,
  ]));
}

function transitionPanel(state) {
  return panel('Execute an authorized transition', join([
    `<p class="crg-prose">This control reaches a configured domain adapter only. The deployment refuses when no physical executor exists, and every terminal record retains checkpoint, postcondition, and rollback evidence.</p>`,
    field('transition-plan', 'Authorized transition plan ID', {
      value: (state.form && state.form['transition-plan']) || '', required: true,
    }),
    field('transition-request', 'Execution context', {
      multiline: true, rows: 7,
      value: (state.form && state.form['transition-request']) || '',
      hint: 'JSON context required by the configured adapter, including case and branch when applicable.',
    }),
    `<div class="crg-actions">${action('execute-transition', 'Execute through the domain adapter', {
      operation: 'executeTransition', tone: 'danger',
    })}</div>`,
  ]), { tone: 'warn' });
}

export const workspace = {
  ...meta,
  render(state = {}) {
    const payload = state.data || {};
    const requests = payload.evaluator_requests
      || (payload.evaluator_request ? [payload.evaluator_request] : []);
    const results = payload.results || [];
    const refinements = payload.refinements || [];
    if (!requests.length && !results.length) {
      return shell(meta, join([
        requestForm(state),
        transitionPanel(state),
        boundaryPanel(),
        notYet('No physical evaluation has been requested for this case yet.'),
      ]), state);
    }
    return shell(meta, join([
      requestForm(state),
      transitionPanel(state),
      boundaryPanel(),
      requestTable(requests),
      resultsTable(results),
      refinementPanel(refinements),
      panel('Turning a result into evidence', definitionList([
        ['What happens next', '<p class="crg-prose">A returned result is not yet evidence. '
          + 'Registering it records its source context, its class, and its validity, and only '
          + 'then can a certificate depend on it (33.2).</p>'],
        ['Registered so far', payload.registered_evidence
          ? hashChip(payload.registered_evidence) : absent('PENDING')],
      ])),
      disclosure('Feedback records as stored', `<pre class="crg-pre" tabindex="0" role="group" `
        + `aria-label="Physical feedback records">`
        + `${esc(JSON.stringify({ requests, results, refinements }, null, 2))}</pre>`,
      { principle: 'why' }),
    ]), state);
  },
};

export default workspace;
