/**
 * Case Setup (spec 41.1): source, contracts, hierarchy, packs, completeness,
 * and branch selection.
 *
 * This is where a case's declared context is established, so it is also
 * where the two things 41.2 wants prominent first appear: the completeness
 * basis (21.3) and, through it, the claim scopes a certificate over this
 * case will be *allowed* to carry (21.5).  Studio shows the permitted claim
 * before anyone certifies, because discovering that a family was
 * `KNOWN_INCOMPLETE` after the decision has been made is discovering it too
 * late.
 */

import {
  absent, completenessPanel, definitionList, disclosure, emptyState, esc, hashChip, join,
  panel, table,
} from '../render.js';
import { action, field, notYet, shell } from '../workspace.js';
import { CLAIM_SCOPES } from '../render.js';

const meta = {
  id: 'case-setup',
  title: 'Case Setup',
  purpose: 'Source, contracts, hierarchy, packs, completeness, and branch selection.',
  endpoints: ['createCase', 'getCase', 'validateCase', 'createBranch'],
};

/** 21.5, stated forwards: what this basis will let a certificate claim. */
function permittedClaims(basisType) {
  const map = {
    EXHAUSTIVE_DECLARED_UNIVERSE: 'FULL_DECLARED_UNIVERSE',
    GENERATOR_CLOSED: 'GENERATOR_CLOSED_FAMILY',
    BOUNDED_UNENUMERATED_FAMILY: 'BOUNDED_REMAINDER_GLOBAL',
    EXPLICIT_IMPORTED_FAMILY: 'RELATIVE_EXPLICIT_FAMILY',
    TRUNCATED_BY_DECLARED_RULE: 'PARTIAL_FAMILY',
    KNOWN_INCOMPLETE: 'PARTIAL_FAMILY',
    UNKNOWN: 'PARTIAL_FAMILY',
  };
  const scope = map[String(basisType || 'UNKNOWN')] || 'PARTIAL_FAMILY';
  const info = CLAIM_SCOPES[scope];
  return panel('What a decision here will be allowed to claim', join([
    `<p class="crg-prose"><strong>${esc(info.label)}.</strong> ${esc(info.sentence)}</p>`,
    scope === 'PARTIAL_FAMILY'
      ? `<p class="crg-prose">A certificate issued over this case cannot name a winner. `
        + `It may report a heuristic incumbent, a possible winner, or a decision blocked `
        + `by incomplete coverage (21.5). Broaden the family or record a bound that `
        + `closes the remainder if you need a stronger claim.</p>`
      : `<p class="crg-prose">This is decided when the certificate is issued, from what `
        + `generation and import actually did — never from what the request asked for.</p>`,
  ]), { principle: 'claim-scope', tone: scope === 'PARTIAL_FAMILY' ? 'warn' : 'neutral' });
}

function contractPanel(contract) {
  const entries = Object.entries(contract || {});
  if (!entries.length) {
    return panel('Contracts', emptyState(
      'No computation, resource, or technology contract is declared on this case. '
      + 'Contracts are what make a later result reproducible (47.1).',
    ), { tone: 'warn' });
  }
  return panel('Contracts', definitionList(entries.map(([key, value]) => [
    key.replace(/_/g, ' '),
    typeof value === 'object'
      ? `<pre class="crg-pre" tabindex="0" role="group" aria-label="${esc(key)} contract">`
        + `${esc(JSON.stringify(value, null, 2))}</pre>`
      : esc(String(value)),
  ])));
}

function lineagePanel(record) {
  const rows = [
    ['Case identifier', record.case_id ? `<code class="crg-code">${esc(record.case_id)}</code>` : absent()],
    ['Title', record.title ? esc(record.title) : absent()],
    ['Owner', record.owner ? esc(record.owner) : absent()],
    ['Branch', record.branch_id ? `<code class="crg-code">${esc(record.branch_id)}</code>` : absent()],
    ['Derived from', record.derived_from ? hashChip(record.derived_from) : absent('NOT_APPLICABLE')],
    ['Status', record.status ? esc(record.status) : absent()],
    ['Schema version', record.schema_version ? esc(record.schema_version) : absent()],
    ['Created', record.created_at ? esc(record.created_at) : absent()],
    ['Created by', record.created_by ? esc(record.created_by) : absent()],
    ['Access policy', record.access_policy ? esc(record.access_policy) : absent()],
    ['Domain packs in force', (record.packs || []).length
      ? `<ul class="crg-list">${(record.packs || []).map((p) => `<li>${esc(
        typeof p === 'string' ? p : `${p.pack_id || ''} ${p.version || ''}`,
      )}</li>`).join('')}</ul>`
      : '<span class="crg-prose">None. Only the domain-neutral core is in force (3.3).</span>'],
  ];
  return panel('This case', definitionList(rows));
}

function versionsPanel(state) {
  const versions = state.data && state.data.versions;
  if (!versions || !versions.length) {
    return panel('History', emptyState('No versions recorded yet.'));
  }
  return table('Version history of this case', [
    { label: 'Version' },
    { label: 'Content hash', hint: 'The canonical hash of the case at this version (14.4).' },
  ], versions.map((version, index) => ({
    cells: [`<span>${esc(String(index + 1))}</span>`, hashChip(version)],
  })));
}

function setupForm(state) {
  return panel('Open or create a case', join([
    field('case-id', 'Case identifier', {
      value: state.caseId || '',
      hint: 'The stable name for this decision. 11.1 requires it before anything else.',
      required: true,
    }),
    field('case-title', 'Title in plain language', {
      value: (state.form && state.form.title) || '',
      hint: 'What a reader who has never seen this case should understand it to be about.',
    }),
    `<div class="crg-actions">`
    + action('open-case', 'Open this case', { operation: 'getCase' })
    + action('create-case', 'Create it', { operation: 'createCase', tone: 'secondary' })
    + action('validate-case', 'Check it is structurally sound', {
      operation: 'validateCase', tone: 'secondary',
    })
    + action('branch-case', 'Branch it', { operation: 'createBranch', tone: 'secondary' })
    + `</div>`,
  ]));
}

function welcomePanel() {
  return `<section class="crg-welcome" aria-labelledby="crg-welcome-title">`
    + `<div class="crg-welcome__copy"><p class="crg-eyebrow">A defensible decision starts here</p>`
    + `<h3 id="crg-welcome-title">Turn candidates, evidence, and constraints into a decision someone else can verify.</h3>`
    + `<p>CRG Studio keeps the candidate family, completeness claim, uncertainty, decision rule, and verification result together—so a polished answer can never outrun its basis.</p>`
    + `<div class="crg-trust-row"><span>Exact arithmetic</span><span>Visible claim scope</span><span>Portable verification</span></div></div>`
    + `<ol class="crg-journey" aria-label="Four-step decision workflow">`
    + `<li><span>1</span><div><strong>Frame</strong><small>Name the decision and its authority.</small></div></li>`
    + `<li><span>2</span><div><strong>Represent</strong><small>Import or generate the candidate family.</small></div></li>`
    + `<li><span>3</span><div><strong>Decide</strong><small>Compile the question and certify what follows.</small></div></li>`
    + `<li><span>4</span><div><strong>Verify</strong><small>Export evidence that stands on its own.</small></div></li>`
    + `</ol></section>`;
}

function validationPanel(report) {
  if (!report) return '';
  const problems = report.problems || report.errors || [];
  return panel('Structural check', join([
    `<p class="crg-prose">${report.valid
      ? 'This case is structurally sound. That is a statement about shape, units, and '
      + 'references only — it says nothing yet about whether a decision over it can be certified.'
      : 'This case is not structurally valid, so certification is refused before it starts (6.6).'}</p>`,
    problems.length
      ? `<ul class="crg-list">${problems.map((p) => `<li>${esc(
        typeof p === 'string' ? p : JSON.stringify(p),
      )}</li>`).join('')}</ul>`
      : '',
  ]), { tone: report.valid ? 'neutral' : 'warn' });
}

export const workspace = {
  ...meta,
  render(state = {}) {
    const payload = state.data || {};
    const record = payload.case || null;
    if (!record) {
      return shell(meta, join([
        welcomePanel(),
        setupForm(state),
        notYet('No case is open. Name one above and open it, or create it if it does not exist yet.'),
      ]), state);
    }
    return shell(meta, join([
      setupForm(state),
      lineagePanel(record),
      completenessPanel((record.registry || {}).completeness || record.completeness),
      permittedClaims((((record.registry || {}).completeness) || record.completeness || {}).basis_type),
      contractPanel(record.contract),
      validationPanel(state.validation),
      versionsPanel(state),
      disclosure('Case record as stored', `<pre class="crg-pre" tabindex="0" role="group" `
        + `aria-label="Canonical case record">${esc(JSON.stringify(record, null, 2))}</pre>`,
      { principle: 'why' }),
    ]), state);
  },
};

export default workspace;
