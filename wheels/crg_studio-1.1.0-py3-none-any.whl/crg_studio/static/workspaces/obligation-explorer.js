/**
 * Obligation Explorer (spec 41.1): typed coordinates, units, accounting,
 * scopes, and uncertainty.
 *
 * This is the workspace where 41.2's "never present an unsupported
 * coordinate as zero" does the most work, because this is the only screen
 * where a reader sees the raw coordinate grid.  A candidate with no value
 * for a coordinate renders the absent marker with a reason, in every cell,
 * in every branch.  The alternative — a tidy grid of zeros — is the single
 * most consequential lie an interface of this kind can tell: an unmeasured
 * emission is not a zero emission, and a decision taken on that grid would
 * be certified against a family that does not exist.
 */

import {
  absent, definitionList, emptyState, esc, evidenceBadge, interval, join, panel, quantity,
  table, term,
} from '../render.js';
import { action, notYet, shell } from '../workspace.js';

const meta = {
  id: 'obligation-explorer',
  title: 'Obligation Explorer',
  purpose: 'Typed coordinates, units, accounting, scopes, and uncertainty.',
  endpoints: ['getCase', 'evaluateFamily', 'getJobResult'],
};

const DIRECTIONS = {
  MINIMIZE: ['Lower is better', 'This coordinate is an obligation to be reduced (19.1).'],
  MAXIMIZE: ['Higher is better', 'This coordinate is a benefit to be increased (19.1).'],
};

function schemaTable(schema) {
  const coordinates = (schema || {}).coordinates || [];
  if (!coordinates.length) {
    return emptyState('This case declares no coordinate schema yet.');
  }
  return table('Coordinates this case is measured in', [
    { label: 'Coordinate' },
    { label: 'What it measures' },
    { label: 'Unit', hint: 'Every dimensioned quantity carries a unit profile (13.1, 13.3).' },
    { label: 'Direction' },
    { label: 'Accounting scope', hint: 'Which boundary the quantity is accounted within.' },
  ], coordinates.map((coordinate) => {
    const [label, description] = DIRECTIONS[coordinate.direction] || DIRECTIONS.MINIMIZE;
    return {
      attributes: ` data-coordinate="${esc(coordinate.identifier || '')}"`,
      cells: [
        `<code class="crg-code">${esc(coordinate.identifier || '')}</code>`,
        coordinate.quantity ? esc(coordinate.quantity) : absent(),
        coordinate.unit
          ? `<span data-unit="${esc(coordinate.unit)}">${esc(coordinate.unit)}</span>`
          : `<span class="crg-prose">Dimensionless — 13.4 requires the convention to be `
            + `declared, not assumed.</span>`,
        `<span title="${esc(description)}">${esc(label)}</span>`,
        coordinate.accounting_scope ? esc(coordinate.accounting_scope)
          : absent('NOT_APPLICABLE'),
      ],
    };
  }));
}

/**
 * The coordinate grid.  Absence is rendered as absence, per coordinate, per
 * candidate, with the reason attached to the marker.
 */
function obligationGrid(registry, evaluation) {
  const coordinates = ((registry || {}).schema || {}).coordinates || [];
  const records = (registry || {}).realizations || [];
  if (!records.length || !coordinates.length) {
    return emptyState('No obligation vectors are recorded for this case yet.');
  }
  const values = (evaluation || {}).values || {};
  return table('Obligation vector for each realization', [
    { label: 'Realization' },
    ...coordinates.map((c) => ({
      label: c.identifier,
      hint: `${c.quantity || c.identifier}, ${c.unit || 'dimensionless'}.`,
    })),
    { label: 'Evidence class' },
  ], records.map((record) => ({
    attributes: ` data-realization="${esc(record.realization_id || '')}"`,
    cells: [
      `<span class="crg-realization__name">${esc(record.realization_id || '')}</span>`,
      ...coordinates.map((coordinate, index) => {
        const declared = record.values || {};
        const raw = declared[coordinate.identifier] !== undefined
          ? declared[coordinate.identifier]
          : ((record.signature || {}).values || record.signature || [])[index];
        const supported = raw !== undefined && raw !== null;
        if (!supported) {
          return absent(
            (record.unsupported || {})[coordinate.identifier] || 'UNSUPPORTED',
          );
        }
        return quantity(raw, {
          unit: coordinate.unit || '',
          evidenceClass: (record.coordinate_evidence || {})[coordinate.identifier] || null,
        });
      }),
      evidenceBadge(record.evidence_class),
    ],
  })));
}

function uncertaintyPanel(evaluation) {
  const values = (evaluation || {}).values || (evaluation || {}).objective_values || {};
  const ids = Object.keys(values).sort();
  if (!ids.length) {
    return panel('Uncertainty', emptyState(
      'No evaluation has been run, so no uncertainty is recorded. That is not the same as '
      + 'no uncertainty: it means the question has not been asked yet.',
    ), { principle: 'no-zero' });
  }
  return panel('Uncertainty, kept in three parts', join([
    `<p class="crg-prose">22.1 requires arithmetic enclosure, evidence uncertainty, and `
    + `declared indifference tolerance to be recorded separately. They are reduced by `
    + `different work, and collapsing them hides which work would help.</p>`,
    table('Uncertainty per realization', [
      { label: 'Realization' },
      { label: 'Arithmetic enclosure' },
      { label: 'Evidence uncertainty' },
      { label: 'Conservative range' },
    ], ids.map((id) => {
      const value = values[id] || {};
      return {
        cells: [
          `<span class="crg-realization__name">${esc(id)}</span>`,
          value.numerical_interval
            ? interval(value.numerical_interval, { kind: 'numerical' }) : absent('PENDING'),
          value.evidence_interval
            ? interval(value.evidence_interval, { kind: 'evidence' }) : absent('PENDING'),
          value.combined_interval
            ? interval(value.combined_interval, { kind: 'combined' }) : absent('PENDING'),
        ],
      };
    })),
  ]), { principle: 'no-zero' });
}

function keyPanel() {
  return panel('Reading this screen', definitionList([
    [`Absent value`, `${absent('UNSUPPORTED')} <span class="crg-prose">means there is no `
      + `supported value for that coordinate. It never means zero. Hover or focus the `
      + `marker for the reason.</span>`],
    [`Redacted value`, `${absent('REDACTED')} <span class="crg-prose">means the supporting `
      + `content was removed and a tombstone remains (17.2).</span>`],
    [`Not enumerated`, `${absent('UNENUMERATED')} <span class="crg-prose">means this part of `
      + `the family was never generated (28.4).</span>`],
    [term('Obligation vector', 'x'), `<span class="crg-prose">One row of the grid: what a `
      + `realization costs on every declared coordinate.</span>`],
  ]), { principle: 'no-zero' });
}

export const workspace = {
  ...meta,
  render(state = {}) {
    const registry = ((state.data || {}).case || {}).registry
      || (state.data || {}).registry || null;
    if (!registry) {
      return shell(meta, notYet(
        'No registry is loaded, so there are no obligations to explore yet.',
        `<div class="crg-actions">${action('reload-case', 'Load the case', { operation: 'getCase' })}</div>`,
      ), state);
    }
    const evaluation = (state.data || {}).evaluation || state.evaluation || null;
    return shell(meta, join([
      keyPanel(),
      schemaTable(registry.schema),
      obligationGrid(registry, evaluation),
      uncertaintyPanel(evaluation),
      panel('Recompute values', join([
        `<p class="crg-prose">Evaluation is a long-running action and returns a job `
        + `identifier (38.3).</p>`,
        `<div class="crg-actions">`
        + action('evaluate', 'Evaluate the family', { operation: 'evaluateFamily' })
        + `</div>`,
      ])),
    ]), state);
  },
};

export default workspace;
