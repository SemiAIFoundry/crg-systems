/**
 * Federation Center (spec 41.1): capability envelopes, requests, release
 * policies, and revocation.
 *
 * A capability envelope is a promise about what a counterparty may learn,
 * so this workspace is written from the counterparty's side of the table:
 * what does this envelope actually disclose, for how long, and what happens
 * when it is revoked.  Revocation is shown as a first-class state rather
 * than an absence, because a revoked capability that renders as "no
 * capability" loses the fact that one existed and was withdrawn.
 */

import {
  absent, definitionList, disclosure, emptyState, esc, hashChip, join, panel, table,
  verificationChip,
} from '../render.js';
import { action, field, notYet, shell } from '../workspace.js';

const meta = {
  id: 'federation-center',
  title: 'Federation Center',
  purpose: 'Capability envelopes, requests, release policies, and revocation.',
  endpoints: ['issueCapabilityEnvelope', 'evaluatePrivately', 'revokeCapability', 'listEvents'],
};

function envelopeTable(envelopes) {
  if (!envelopes.length) {
    return emptyState('No capability envelopes have been issued from this case.');
  }
  return table('Capability envelopes', [
    { label: 'Envelope' },
    { label: 'Target context' },
    { label: 'What it discloses' },
    { label: 'Valid until' },
    { label: 'State' },
  ], envelopes.map((envelope) => ({
    attributes: ` data-envelope="${esc(envelope.envelope_id || '')}"`,
    cells: [
      hashChip(envelope.envelope_id || envelope.content_hash),
      envelope.target_context ? esc(envelope.target_context) : absent(),
      envelope.discloses
        ? esc(envelope.discloses)
        : `<span class="crg-prose">A bounded predicate only: the counterparty learns whether `
          + `a declared condition holds, not the value behind it (35.3).</span>`,
      envelope.validity ? esc(envelope.validity) : absent('UNSUPPORTED'),
      envelope.revoked
        ? verificationChip('REVOKED')
        : '<span>Active</span>',
    ],
  })));
}

function releasePolicyPanel(policy) {
  if (!policy) {
    return panel('Release policy', emptyState(
      'No release policy is attached. Without one, there is no recorded statement of what '
      + 'a counterparty is permitted to learn, and 35.2 requires the envelope to carry it.',
    ), { tone: 'warn' });
  }
  return panel('Release policy', definitionList([
    ['Policy', policy.policy_id ? `<code class="crg-code">${esc(policy.policy_id)}</code>`
      : hashChip(policy.content_hash)],
    ['Permits', (policy.permits || []).length
      ? `<ul class="crg-list">${(policy.permits || [])
        .map((p) => `<li>${esc(p)}</li>`).join('')}</ul>` : absent()],
    ['Forbids', (policy.forbids || []).length
      ? `<ul class="crg-list">${(policy.forbids || [])
        .map((p) => `<li>${esc(p)}</li>`).join('')}</ul>` : absent()],
    ['Nonce required', policy.nonce_required === false ? 'No'
      : 'Yes — a replayed evaluation is refused (35.3)'],
    ['Audit', policy.audit === false
      ? '<span class="crg-prose">Not audited. Every private evaluation should be recorded '
        + 'even when its result is not disclosed (44.7).</span>'
      : 'Every evaluation under this policy is recorded'],
  ]));
}

function evaluationsTable(evaluations) {
  if (!evaluations.length) {
    return emptyState('No private evaluations have been performed against these envelopes.');
  }
  return table('Private evaluations', [
    { label: 'Evaluation' },
    { label: 'Predicate' },
    { label: 'Answer' },
    { label: 'Nonce' },
    { label: 'What the counterparty learned' },
  ], evaluations.map((evaluation) => ({
    cells: [
      hashChip(evaluation.evaluation_id || evaluation.content_hash),
      evaluation.predicate ? `<code class="crg-code">${esc(evaluation.predicate)}</code>`
        : absent(),
      evaluation.result === undefined || evaluation.result === null
        ? absent('UNSUPPORTED')
        : `<strong>${esc(String(evaluation.result))}</strong>`,
      evaluation.nonce ? hashChip(evaluation.nonce)
        : `<span class="crg-unmapped">None — this evaluation is replayable</span>`,
      evaluation.disclosed ? esc(evaluation.disclosed)
        : '<span class="crg-prose">The predicate answer only.</span>',
    ],
  })));
}

function revocationPanel(events) {
  const revocations = (events || []).filter((e) => String(e.event || '') === 'capability.revoked');
  if (!revocations.length) {
    return panel('Revocations', emptyState(
      'Nothing has been revoked. A revocation is recorded as an event and never as a '
      + 'deletion, so a counterparty who acted on a capability before it was withdrawn '
      + 'remains attributable (35.5, 6.4).',
    ));
  }
  return table('Revocations', [
    { label: 'When' },
    { label: 'Capability' },
    { label: 'By' },
    { label: 'Correlation' },
  ], revocations.map((event) => ({
    cells: [
      event.timestamp ? esc(event.timestamp) : absent(),
      (event.object_hashes || []).length ? hashChip(event.object_hashes[0]) : absent(),
      event.actor ? esc(event.actor) : absent(),
      event.correlation_id ? hashChip(event.correlation_id) : absent(),
    ],
  })));
}

function issueForm(state) {
  return panel('Issue a capability envelope', join([
    field('envelope-target', 'Target context', {
      value: (state.form && state.form.target) || '',
      hint: 'Who the envelope is for, and in what setting it may be used.',
    }),
    field('envelope-request', 'Envelope request', {
      multiline: true, rows: 10,
      value: (state.form && state.form.request) || '',
      hint: 'The bounded result, rule, key, validity, nonce, and release policy (35.2).',
    }),
    `<div class="crg-actions">`
    + action('issue-envelope', 'Issue the envelope', { operation: 'issueCapabilityEnvelope' })
    + action('evaluate-privately', 'Evaluate a predicate under an envelope', {
      operation: 'evaluatePrivately', tone: 'secondary',
    })
    + action('reload-events', 'Reload the event log', { operation: 'listEvents', tone: 'secondary' })
    + `</div>`,
  ]));
}

function revokeForm(state) {
  return panel('Revoke a capability or trust subject', join([
    `<p class="crg-prose">Revocation is durable and attributable. It does not delete the subject; it prevents future reliance on it.</p>`,
    field('revoke-subject', 'Capability, evidence root, or key subject', {
      value: (state.form && state.form['revoke-subject']) || '', required: true,
    }),
    field('revoke-reason', 'Revocation reason', {
      value: (state.form && state.form['revoke-reason']) || '', required: true,
      hint: 'The reason is retained in the federation revocation registry and event log.',
    }),
    `<div class="crg-actions">${action('revoke-capability', 'Revoke this subject', {
      operation: 'revokeCapability', tone: 'danger',
    })}</div>`,
  ]), { tone: 'warn' });
}

export const workspace = {
  ...meta,
  render(state = {}) {
    const payload = state.data || {};
    const envelopes = payload.envelopes
      || (payload.envelope ? [payload.envelope] : []);
    const evaluations = payload.private_evaluations || [];
    if (!envelopes.length && !evaluations.length) {
      return shell(meta, join([
        issueForm(state),
        revokeForm(state),
        notYet('No federation activity is recorded for this case yet.'),
      ]), state);
    }
    return shell(meta, join([
      issueForm(state),
      revokeForm(state),
      envelopeTable(envelopes),
      releasePolicyPanel(payload.release_policy || (envelopes[0] || {}).release_policy),
      evaluationsTable(evaluations),
      revocationPanel(payload.events),
      panel('What a counterparty cannot do with these', join([
        `<ul class="crg-list">`
        + `<li>Read a value the envelope did not bound.</li>`
        + `<li>Replay an evaluation whose policy required a nonce.</li>`
        + `<li>Use an envelope past its validity, or after revocation.</li>`
        + `<li>Treat a bounded predicate answer as a certificate. It is not one (35.3).</li>`
        + `</ul>`,
      ])),
      disclosure('Federation records as stored', `<pre class="crg-pre" tabindex="0" `
        + `role="group" aria-label="Federation records">`
        + `${esc(JSON.stringify({ envelopes, evaluations }, null, 2))}</pre>`,
      { principle: 'why' }),
    ]), state);
  },
};

export default workspace;
