/**
 * Preview-first bring-your-own-registry workbench.
 *
 * Mapping is explicit, reusable, and canonical. Preview never writes the
 * case. Confirmation re-runs the same public producer and requires the exact
 * preview hash before a successor registry can exist. Unknown fields,
 * missing values, binary JSON floats, duplicate identities, unit mismatch,
 * and rejected rows stay visible; this workspace never repairs them.
 */

import {
  absent, completenessPanel, definitionList, disclosure, emptyState, esc,
  evidenceBadge, hashChip, join, panel, quantity, table,
} from '../render.js';
import { action, field, notYet, select, shell } from '../workspace.js';
import { registryIntakeBody } from '../guided-authoring.js';

const meta = {
  id: 'registry-import',
  title: 'Registry Import',
  purpose: 'Preview-first mapping, exact units, provenance, diagnostics, and hash confirmation',
  endpoints: [
    'getCase', 'previewRegistryIntake', 'confirmRegistryIntake',
    'getJob', 'getJobResult', 'importBundle',
  ],
};

function pretty(value) {
  if (!value || typeof value !== 'object') return '';
  return JSON.stringify(value, null, 2);
}

function actionOutputs(state) {
  const result = ((state.lastAction || {}).result) || {};
  return result.outputs || result;
}

function ledger(state) {
  return ((((state.data || {}).case || {}).registry_intake) || {});
}

function latestByHash(records, digest) {
  if (!records || !digest || typeof records !== 'object') return null;
  return records[digest] || null;
}

function latestPreview(state) {
  const outputs = actionOutputs(state);
  if (outputs.preview && outputs.preview.record_type === 'RegistryIntakePreview') {
    return outputs.preview;
  }
  const record = ledger(state);
  return latestByHash(record.previews, record.latest_preview_hash);
}

function latestPreviewHash(state) {
  const outputs = actionOutputs(state);
  return outputs.preview_hash || ledger(state).latest_preview_hash || '';
}

function latestConfirmation(state) {
  const outputs = actionOutputs(state);
  if (outputs.confirmation
      && outputs.confirmation.record_type === 'RegistryIntakeConfirmation') {
    return outputs.confirmation;
  }
  const record = ledger(state);
  return latestByHash(record.confirmations, record.latest_confirmation_hash);
}

function latestProfile(state, preview) {
  if (preview && preview.profile) return preview.profile;
  const record = ledger(state);
  return latestByHash(record.mapping_profiles, record.latest_profile_hash);
}

function latestSource(state, preview) {
  if (preview && preview.source_snapshot) return preview.source_snapshot;
  const record = ledger(state);
  return latestByHash(record.source_snapshots, record.latest_source_snapshot_hash);
}

function structuredRequest(state, preview, { confirm = false } = {}) {
  return pretty(registryIntakeBody(intakeGuidedValues(state, preview), { confirm }));
}

const DEFAULT_QUANTITY_REGISTRY =
  'sha256:810b33ce38f3bf69be66fb153601782a4d73b125db1534ef810f82a088102bb1';

const INTAKE_GUIDED_FIELDS = [
  'intake-source-content', 'intake-profile-id', 'intake-profile-version',
  'intake-source-format', 'intake-record-path', 'intake-identity-field',
  'intake-coordinate-mappings', 'intake-attribute-mappings',
  'intake-quantity-registry-version', 'intake-default-evidence-class',
  'intake-evidence-field', 'intake-feasibility-field', 'intake-source-id',
  'intake-source-name', 'intake-source-origin', 'intake-source-producer',
  'intake-source-version',
];

function intakeGuidedValues(state, preview) {
  const form = state.form || {};
  const profile = latestProfile(state, preview) || {};
  const provenance = ((latestSource(state, preview) || {}).provenance) || {};
  const coordinateRows = (profile.coordinates || []).map((item) => [
    item.source_field, item.coordinate_id, item.quantity, item.unit, item.direction,
    item.unit_field || '', item.evidence_field || '',
  ].join(' | ')).join('\n');
  const attributeRows = (profile.attributes || []).map((item) => [
    item.source_field, item.attribute_id, item.required ? 'required' : 'optional',
  ].join(' | ')).join('\n');
  return {
    'intake-source-content': form['intake-source-content'] || '',
    'intake-profile-id': form['intake-profile-id'] || profile.profile_id || 'registry-import-1',
    'intake-profile-version': form['intake-profile-version'] || profile.profile_version || '1.0.0',
    'intake-source-format': form['intake-source-format'] || profile.source_format || 'csv',
    'intake-record-path': form['intake-record-path'] || profile.record_path || '$rows',
    'intake-identity-field': form['intake-identity-field'] || profile.identity_field || 'candidate',
    'intake-coordinate-mappings': form['intake-coordinate-mappings'] || coordinateRows
      || 'latency | latency | time | ns | MINIMIZE',
    'intake-attribute-mappings': form['intake-attribute-mappings'] || attributeRows,
    'intake-quantity-registry-version': form['intake-quantity-registry-version']
      || profile.quantity_registry_version || DEFAULT_QUANTITY_REGISTRY,
    'intake-default-evidence-class': form['intake-default-evidence-class']
      || profile.default_evidence_class || 'IMPORTED',
    'intake-evidence-field': form['intake-evidence-field'] || profile.evidence_field || '',
    'intake-feasibility-field': form['intake-feasibility-field']
      || profile.feasibility_field || 'legality',
    'intake-source-id': form['intake-source-id'] || provenance.source_id || 'registry-source-1',
    'intake-source-name': form['intake-source-name'] || provenance.source_name || 'candidates.csv',
    'intake-source-origin': form['intake-source-origin'] || provenance.origin || 'DECLARED_EXPORT',
    'intake-source-producer': form['intake-source-producer'] || provenance.producer || '',
    'intake-source-version': form['intake-source-version'] || provenance.source_version || '',
    'intake-expected-preview-hash': form['intake-expected-preview-hash']
      || latestPreviewHash(state),
    'intake-accept-partial': form['intake-accept-partial'] || 'false',
  };
}

function intakeForm(state, preview) {
  const form = state.form || {};
  const guided = intakeGuidedValues(state, preview);
  const expected = guided['intake-expected-preview-hash'];
  return join([
    panel('1. Declare the source and reusable mapping', join([
      `<p class="crg-prose">Paste exact CSV or JSON source content. The source stays outside `
        + `the case; its byte hash, size, fields, and declared provenance are recorded. `
        + `No unit conversion, identity inference, or completeness promotion occurs.</p>`,
      field('intake-source-content', 'CSV or JSON source content', {
        multiline: true, rows: 10, value: guided['intake-source-content'], required: true,
        hint: 'JSON certifying decimals must be quoted exact values. Bare binary JSON floats are refused.',
      }),
      field('intake-profile-id', 'Reusable mapping profile identity', {
        value: guided['intake-profile-id'], required: true,
      }),
      field('intake-profile-version', 'Mapping profile version', {
        value: guided['intake-profile-version'], required: true,
      }),
      select('intake-source-format', 'Source format', [
        ['csv', 'CSV rows'], ['json', 'JSON array'],
      ], { value: guided['intake-source-format'] }),
      field('intake-record-path', 'Record path', {
        value: guided['intake-record-path'], required: true,
        hint: 'CSV uses $rows. JSON uses $ or one explicit top-level field name.',
      }),
      field('intake-identity-field', 'Source field containing the candidate identity', {
        value: guided['intake-identity-field'], required: true,
      }),
      field('intake-coordinate-mappings', 'Coordinate mappings, one per line', {
        multiline: true, rows: 6, value: guided['intake-coordinate-mappings'], required: true,
        hint: 'source field | coordinate ID | quantity | unit | MINIMIZE or MAXIMIZE | optional unit field | optional evidence field',
      }),
      field('intake-attribute-mappings', 'Preserved attribute mappings (optional)', {
        multiline: true, rows: 3, value: guided['intake-attribute-mappings'],
        hint: 'One per line: source field | attribute ID | required or optional.',
      }),
      field('intake-quantity-registry-version', 'Governed quantity-registry root', {
        value: guided['intake-quantity-registry-version'], required: true,
        hint: 'Studio supplies this build’s registered root. A different server registry fails closed.',
      }),
      select('intake-default-evidence-class', 'Default evidence class', [
        ['IMPORTED', 'Imported'], ['MEASURED', 'Measured'], ['MODELED', 'Modeled'],
        ['DECLARED', 'Declared'], ['BOUNDED', 'Bounded'], ['CONSTRUCTIVE', 'Constructive'],
        ['EXACT', 'Exact'], ['HEURISTIC', 'Heuristic'],
      ], { value: guided['intake-default-evidence-class'] }),
      field('intake-evidence-field', 'Per-row evidence-class field (optional)', {
        value: guided['intake-evidence-field'],
      }),
      field('intake-feasibility-field', 'Per-row legality field (optional)', {
        value: guided['intake-feasibility-field'],
      }),
      `<fieldset class="crg-fieldset"><legend class="crg-field__label">Declared source provenance</legend>`,
      field('intake-source-id', 'Source identity', {
        value: guided['intake-source-id'], required: true,
      }),
      field('intake-source-name', 'Source name', {
        value: guided['intake-source-name'], required: true,
      }),
      field('intake-source-origin', 'Source origin', {
        value: guided['intake-source-origin'], required: true,
      }),
      field('intake-source-producer', 'Producer (optional)', {
        value: guided['intake-source-producer'],
      }),
      field('intake-source-version', 'Source version (optional)', {
        value: guided['intake-source-version'],
      }),
      `</fieldset>`,
      `<div class="crg-actions">${action('preview-intake', 'Preview without saving', {
        operation: 'previewRegistryIntake',
        fields: INTAKE_GUIDED_FIELDS,
      })}</div>`,
    ])),
    panel('2. Confirm only the reviewed hash', join([
      `<p class="crg-prose">Confirmation is a different operation. It re-previews the source `
        + `and mapping and refuses if their canonical preview no longer equals the hash below.</p>`,
      field('intake-expected-preview-hash', 'Expected preview hash', {
        value: expected,
        placeholder: 'sha256:…',
        hint: 'Filled from the latest preview when available. Never replace it with a source hash.',
        required: true,
      }),
      select('intake-accept-partial', 'Rejected-row acknowledgement', [
        ['false', 'Do not accept any rejected row'],
        ['true', 'Acknowledge the disclosed rejected rows'],
      ], {
        value: form['intake-accept-partial'] || 'false',
        hint: 'Acknowledgement does not hide rejected rows or strengthen EXPLICIT_IMPORTED_FAMILY.',
      }),
      `<div class="crg-actions">${action('confirm-intake', 'Re-preview, verify hash, and save', {
        operation: 'confirmRegistryIntake',
        fields: [
          ...INTAKE_GUIDED_FIELDS,
          'intake-expected-preview-hash', 'intake-accept-partial',
        ],
      })}</div>`,
    ]), { tone: 'warn' }),
    disclosure('Advanced canonical JSON mode — direct request', join([
      `<p class="crg-prose">Use the exact public request shape directly. This mode is `
        + `preserved for automation and audit; it invokes the same endpoints and safety checks.</p>`,
      field('intake-request', 'Preview or confirmation request JSON', {
        multiline: true, rows: 12,
        value: form['intake-request'] || structuredRequest(state, preview),
      }),
      `<div class="crg-actions">${action('preview-intake-json', 'Preview canonical request', {
        operation: 'previewRegistryIntake', fields: ['intake-request'], tone: 'secondary',
      })}${action('confirm-intake-json', 'Confirm canonical request', {
        operation: 'confirmRegistryIntake', fields: ['intake-request'], tone: 'secondary',
      })}</div>`,
      `<p class="crg-prose">For confirmation, add <code class="crg-code">expected_preview_hash</code> `
        + `and an optional JSON boolean <code class="crg-code">accept_partial</code>. `
        + `The server rejects unknown request fields.</p>`,
    ]), { open: false }),
  ]);
}

function mappingTable(profile) {
  if (!profile) return emptyState('No mapping profile has been previewed or saved.');
  const rows = [{
    source_field: profile.identity_field,
    target: 'realization_id',
    semantics: 'Exact text or integer identity; case-sensitive and unique',
  }];
  (profile.coordinates || []).forEach((item) => rows.push({
    source_field: item.source_field,
    target: item.coordinate_id,
    semantics: `${item.quantity} [${item.unit}], ${item.direction}, ${item.numeric_profile}`,
  }));
  (profile.attributes || []).forEach((item) => rows.push({
    source_field: item.source_field,
    target: `attributes.${item.attribute_id}`,
    semantics: item.required ? 'Required canonical attribute' : 'Optional canonical attribute',
  }));
  return table('Explicit mapping', [
    { label: 'Source field' },
    { label: 'Canonical target' },
    { label: 'Declared semantics' },
  ], rows.map((row) => ({ cells: [
    `<code class="crg-code">${esc(row.source_field || '')}</code>`,
    `<code class="crg-code">${esc(row.target || '')}</code>`,
    esc(row.semantics || ''),
  ] })));
}

function diagnosticRows(preview) {
  const rows = [];
  (preview.diagnostics || []).forEach((item) => rows.push({ row: 'Source', ...item }));
  (preview.accepted || []).forEach((record) => {
    (record.diagnostics || []).forEach((item) => rows.push({
      row: record.source_row_number, realization_id: record.realization_id, ...item,
    }));
  });
  (preview.rejected || []).forEach((record) => {
    (record.diagnostics || []).forEach((item) => rows.push({
      row: record.source_row_number, realization_id: record.realization_id, ...item,
    }));
  });
  return rows;
}

function diagnosticsTable(preview) {
  const rows = diagnosticRows(preview);
  if (!rows.length) return panel(
    'Typed diagnostics', '<p class="crg-prose">No warning or error diagnostic was emitted.</p>',
  );
  return table('Typed diagnostics — nothing is silently dropped', [
    { label: 'Severity' }, { label: 'Code' }, { label: 'Source row' },
    { label: 'Field / coordinate' }, { label: 'Explanation' },
  ], rows.map((item) => ({ cells: [
    `<span class="crg-status" data-state="${esc(String(item.severity || '').toLowerCase())}">`
      + `${esc(item.severity || '')}</span>`,
    `<code class="crg-code">${esc(item.code || '')}</code>`,
    esc(item.row),
    esc(item.field || item.coordinate_id || ''),
    esc(item.message || ''),
  ] })));
}

function acceptedTable(preview) {
  const records = preview.accepted || [];
  if (!records.length) return emptyState('No source row is accepted by this preview.');
  const coordinateIds = ((preview.profile || {}).coordinates || [])
    .map((item) => item.coordinate_id);
  return table('Rows that would be materialized', [
    { label: 'Source row' }, { label: 'Candidate' },
    ...coordinateIds.map((identifier) => ({ label: identifier })),
    { label: 'Legality' }, { label: 'Evidence' },
  ], records.map((record) => {
    const values = Object.fromEntries((record.coordinates || [])
      .map((item) => [item.coordinate_id, item]));
    return { attributes: ` data-realization="${esc(record.realization_id || '')}"`, cells: [
      esc(record.source_row_number),
      `<code class="crg-code">${esc(record.realization_id || '')}</code>`,
      ...coordinateIds.map((identifier) => {
        const item = values[identifier];
        return item ? quantity(item.source_value, {
          unit: item.unit, evidenceClass: item.evidence_class,
        }) : absent();
      }),
      esc(record.legality || ''),
      evidenceBadge(record.evidence_class || 'IMPORTED'),
    ] };
  }));
}

function rejectedTable(preview) {
  const records = preview.rejected || [];
  if (!records.length) {
    return panel('Rejected rows', '<p class="crg-prose">None. Confirmation needs no partial-import acknowledgement.</p>');
  }
  return table('Rejected rows — recorded, never padded or guessed', [
    { label: 'Source row' }, { label: 'Candidate, if readable' }, { label: 'Reason codes' },
  ], records.map((record) => ({ cells: [
    esc(record.source_row_number),
    record.realization_id ? `<code class="crg-code">${esc(record.realization_id)}</code>` : absent(),
    (record.diagnostics || []).map((item) => `<code class="crg-code">${esc(item.code)}</code>`)
      .join(' '),
  ] })));
}

function previewPanels(state, preview) {
  if (!preview) return notYet(
    'No structured intake preview exists yet. Preview validates the source and mapping without saving them.',
  );
  const source = preview.source_snapshot || {};
  const provenance = source.provenance || {};
  const previewHash = latestPreviewHash(state);
  return join([
    panel('Preview only — no case mutation occurred', definitionList([
      ['Authority', esc(preview.authority || 'NON_AUTHORIZING')],
      ['Mutation performed', preview.mutation_performed === false ? 'No' : 'Unexpected'],
      ['Preview hash', previewHash ? hashChip(previewHash) : absent()],
      ['Mapping profile hash', preview.profile_hash ? hashChip(preview.profile_hash) : absent()],
      ['Predicted registry hash', preview.predicted_bundle_hash
        ? hashChip(preview.predicted_bundle_hash) : absent()],
      ['Ready without partial acknowledgement', preview.ready_to_materialize ? 'Yes' : 'No'],
    ]), { tone: preview.ready_to_materialize ? 'neutral' : 'warn' }),
    panel('Source snapshot and provenance', definitionList([
      ['Source identity', esc(provenance.source_id || '')],
      ['Source name', esc(provenance.source_name || '')],
      ['Origin', esc(provenance.origin || '')],
      ['Source content hash', source.content_hash ? hashChip(source.content_hash) : absent()],
      ['Source snapshot hash', preview.source_snapshot_hash
        ? hashChip(preview.source_snapshot_hash) : absent()],
      ['Bytes / records', `${esc(source.byte_length)} bytes / ${esc(source.record_count)} records`],
      ['Observed source fields', (source.source_fields || []).length
        ? (source.source_fields || []).map((item) => `<code class="crg-code">${esc(item)}</code>`).join(' ')
        : absent()],
    ])),
    completenessPanel(preview.completeness_basis),
    mappingTable(preview.profile),
    diagnosticsTable(preview),
    acceptedTable(preview),
    rejectedTable(preview),
    disclosure('Canonical preview JSON', `<pre class="crg-pre" tabindex="0">`
      + `${esc(JSON.stringify(preview, null, 2))}</pre>`),
  ]);
}

function confirmationPanel(confirmation) {
  if (!confirmation) return notYet(
    'Nothing has been confirmed. The preview above remains non-mutating until its exact hash is confirmed.',
  );
  return panel('Confirmed intake saved to this case', definitionList([
    ['Authority', esc(confirmation.authority || 'NON_AUTHORIZING_INTAKE')],
    ['Expected and actual preview', confirmation.expected_preview_hash
      === confirmation.actual_preview_hash ? 'Exact match' : 'Mismatch'],
    ['Reviewed preview hash', confirmation.actual_preview_hash
      ? hashChip(confirmation.actual_preview_hash) : absent()],
    ['Source fingerprint', confirmation.source_fingerprint
      ? hashChip(confirmation.source_fingerprint) : absent()],
    ['Registry hash', confirmation.bundle_hash ? hashChip(confirmation.bundle_hash) : absent()],
    ['Accepted / rejected', `${esc(confirmation.accepted_rows)} / ${esc(confirmation.rejected_rows)}`],
    ['Rejected rows explicitly acknowledged', confirmation.partial_import_acknowledged ? 'Yes' : 'No'],
    ['Claim scope', esc(confirmation.claim_scope || '')],
  ]), { tone: 'neutral' });
}

function legacyReportPanel(report) {
  if (!report) return '';
  return disclosure('Earlier import report (compatibility view)', join([
    `<p class="crg-prose">This case predates the preview-bound workbench or was imported `
      + `through the compatibility endpoint. Its report remains available; no reviewed `
      + `RegistryIntakePreview is inferred from it.</p>`,
    `<pre class="crg-pre" tabindex="0">${esc(JSON.stringify(report, null, 2))}</pre>`,
  ]));
}

export const workspace = {
  ...meta,
  render(state = {}) {
    const preview = latestPreview(state);
    const confirmation = latestConfirmation(state);
    const report = (state.data || {}).import_report || null;
    return shell(meta, join([
      intakeForm(state, preview),
      previewPanels(state, preview),
      confirmationPanel(confirmation),
      legacyReportPanel(report),
    ]), state);
  },
};

export default workspace;
