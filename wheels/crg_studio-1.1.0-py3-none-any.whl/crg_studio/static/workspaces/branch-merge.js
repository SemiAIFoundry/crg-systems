/**
 * Branch and Merge (spec 41.1): divergence, reconciliation, conflict
 * resolution, and certificate effect.
 *
 * The certificate effect is the column people forget.  16.5 makes a parent's
 * certificates historical evidence on a branch rather than active claims, and
 * a merge that silently carried them forward would be issuing a certificate
 * by copy.  Studio shows, for every branch, which certificates are active
 * here and which are inherited history, using different words for each.
 *
 * A refused automatic merge is rendered as a decision record, not an error.
 * 16.4 requires explicit reconciliation; the refusal names the fields that
 * diverged, which is the input to the reconciliation the user now has to do.
 */

import {
  absent, definitionList, disclosure, emptyState, esc, hashChip, join, panel, table,
} from '../render.js';
import { action, field, notYet, shell } from '../workspace.js';

const meta = {
  id: 'branch-merge',
  title: 'Branch and Merge',
  purpose: 'Divergence, reconciliation, conflict resolution, and certificate effect.',
  endpoints: ['createBranch', 'mergeCase', 'getCase'],
};

function branchPanel(record) {
  const branchRecord = record.branch_record || {};
  return panel('This branch', definitionList([
    ['Branch', record.branch_id ? `<code class="crg-code">${esc(record.branch_id)}</code>`
      : absent()],
    ['Derived from', record.derived_from ? hashChip(record.derived_from)
      : absent('NOT_APPLICABLE')],
    ['Purpose', branchRecord.purpose ? esc(branchRecord.purpose)
      : '<span class="crg-prose">Not recorded. 16.2 asks for the purpose because a branch '
        + 'without one is indistinguishable from an accident.</span>'],
    ['Intended decision scope', branchRecord.intended_decision_scope
      ? esc(branchRecord.intended_decision_scope) : absent('UNSUPPORTED')],
    ['Expected reconciliation', branchRecord.expected_reconciliation
      ? esc(branchRecord.expected_reconciliation) : absent()],
    ['Created by', branchRecord.creator ? esc(branchRecord.creator) : absent()],
  ]));
}

function certificateEffect(record) {
  const active = Object.keys(record.certificates || {}).sort();
  const inherited = Object.keys(record.inherited_certificates || {}).sort();
  return panel('What this branch may claim', join([
    `<h4 class="crg-subtitle">Active on this branch</h4>`,
    active.length
      ? `<ul class="crg-list">${active.map((id) => `<li>${hashChip(id)}</li>`).join('')}</ul>`
      : '<p class="crg-prose">None. Nothing has been certified on this branch itself.</p>',
    `<h4 class="crg-subtitle">Inherited from the parent, as history</h4>`,
    inherited.length
      ? `<ul class="crg-list">${inherited.map((id) => `<li>${hashChip(id)} `
        + `<span class="crg-prose">evidence of what the parent decided; not a claim about `
        + `this branch</span></li>`).join('')}</ul>`
      : '<p class="crg-prose">None inherited.</p>',
    `<p class="crg-prose">16.5: a parent's certificates are historical evidence on a branch. `
    + `They are shown because an auditor needs them, and they are labelled because relying on `
    + `one here would be relying on a decision taken about a different case.</p>`,
  ]), { principle: 'claim-scope' });
}

function divergenceTable(divergence) {
  if (!divergence.length) {
    return panel('Divergence', emptyState(
      'No divergence is recorded between this branch and its parent.',
    ));
  }
  return table('Where this branch and its parent differ', [
    { label: 'Field' },
    { label: 'On this branch' },
    { label: 'On the parent' },
    { label: 'Semantic?', hint: '16.3 merges non-semantic metadata and refuses semantic conflicts.' },
  ], divergence.map((entry) => ({
    cells: [
      entry.field ? `<code class="crg-code">${esc(entry.field)}</code>` : absent(),
      entry.source === undefined ? absent('UNSUPPORTED') : esc(String(entry.source)),
      entry.target === undefined ? absent('UNSUPPORTED') : esc(String(entry.target)),
      entry.semantic === false ? 'No — metadata only'
        : 'Yes — this cannot merge automatically',
    ],
  })));
}

function mergeDecisionPanel(decision) {
  if (!decision) {
    return panel('Merge', emptyState(
      'No merge has been attempted. A merge that cannot be decided by a registered rule is '
      + 'refused rather than guessed (16.3).',
    ));
  }
  const automatic = decision.automatic === true;
  return panel('Merge decision', join([
    `<p class="crg-prose crg-prose--lead">`
    + `<strong>${esc(decision.decision || (automatic ? 'Merged' : 'Refused'))}</strong></p>`,
    `<p class="crg-prose">${esc(decision.rationale || '')}</p>`,
    automatic
      ? `<p class="crg-prose">This merge was decided by a registered rule. The rule is part `
        + `of the record, so the decision can be reviewed later without re-deriving it.</p>`
      : `<p class="crg-prose">This merge was refused. The refusal is the useful output: the `
        + `fields listed above diverged semantically, and reconciling them is a judgment the `
        + `system will not make on your behalf (16.4, 6.9).</p>`,
    definitionList([
      ['Rules applied', (decision.rules_applied || []).length
        ? `<ul class="crg-list">${(decision.rules_applied || [])
          .map((r) => `<li><code class="crg-code">${esc(r)}</code></li>`).join('')}</ul>`
        : absent()],
      ['Conflicting fields', (decision.conflicts || []).length
        ? `<ul class="crg-list">${(decision.conflicts || [])
          .map((c) => `<li><code class="crg-code">${esc(c)}</code></li>`).join('')}</ul>`
        : absent('NOT_APPLICABLE')],
      ['Effect on certificates', decision.certificate_effect
        ? esc(decision.certificate_effect)
        : '<span class="crg-prose">Certificates are not carried across a merge. Reissue '
          + 'them against the merged case.</span>'],
    ]),
  ]), { tone: automatic ? 'neutral' : 'warn', principle: 'why' });
}

function branchForm(state) {
  return panel('Branch or merge', join([
    field('branch-name', 'Branch name', {
      value: (state.form && state.form.name) || '',
      hint: 'A name a colleague will recognise in six months.',
    }),
    field('branch-purpose', 'Purpose', {
      value: (state.form && state.form.purpose) || '',
      hint: 'Why this branch exists. Recorded on the branch record (16.2).',
    }),
    field('merge-source', 'Merge from case', {
      value: (state.form && state.form.source) || '',
      hint: 'The case whose changes should be merged into this one.',
    }),
    `<div class="crg-actions">`
    + action('create-branch', 'Create the branch', { operation: 'createBranch' })
    + action('merge-branch', 'Attempt the merge', { operation: 'mergeCase', tone: 'secondary' })
    + `</div>`,
  ]));
}

export const workspace = {
  ...meta,
  render(state = {}) {
    const record = (state.data || {}).case || null;
    if (!record) {
      return shell(meta, join([
        branchForm(state),
        notYet('No case is open, so there is no branch history to show.'),
      ]), state);
    }
    return shell(meta, join([
      branchForm(state),
      branchPanel(record),
      certificateEffect(record),
      divergenceTable(state.divergence || (state.data || {}).divergence || []),
      mergeDecisionPanel(state.mergeDecision || (state.data || {}).merge_decision),
      disclosure('Branch record as stored', `<pre class="crg-pre" tabindex="0" role="group" `
        + `aria-label="Branch record">`
        + `${esc(JSON.stringify(record.branch_record || {}, null, 2))}</pre>`,
      { principle: 'why' }),
    ]), state);
  },
};

export default workspace;
