/**
 * The common frame every workspace of 41.1 is built in.
 *
 * The frame is not decoration.  It guarantees that each workspace states, in
 * the same place and the same words: what it is for, which documented
 * endpoints of 38.3 produced what is on screen, and what the user's next
 * action is.  "Which endpoint produced this" is the cheapest form of 41.2's
 * "explain why a result exists" and the one that applies to every view,
 * including the ones with nothing in them yet.
 *
 * Pure functions only: no DOM, no network.  `studio.js` owns both.
 */

import {
  emptyState, esc, join, refusal, slug,
} from './render.js';
import { OPERATIONS } from './api.js';

/** A labelled text input.  The label is a real `<label for>`, always. */
export function field(name, label, options = {}) {
  const id = `field-${slug(name)}`;
  const describedBy = options.hint ? ` aria-describedby="${id}-hint"` : '';
  const control = options.multiline
    ? `<textarea class="crg-input crg-input--area" id="${id}" name="${esc(name)}" `
      + `rows="${options.rows || 6}"${describedBy}`
      + `${options.required ? ' required' : ''}>${esc(options.value || '')}</textarea>`
    : `<input class="crg-input" id="${id}" name="${esc(name)}" `
      + `type="${esc(options.type || 'text')}" value="${esc(options.value || '')}"`
      + `${options.placeholder ? ` placeholder="${esc(options.placeholder)}"` : ''}`
      + `${describedBy}${options.required ? ' required' : ''}>`;
  return `<div class="crg-field">`
    + `<label class="crg-field__label" for="${id}">${esc(label)}</label>`
    + control
    + `${options.hint ? `<p class="crg-field__hint" id="${id}-hint">${esc(options.hint)}</p>` : ''}`
    + `</div>`;
}

/** A labelled select. */
export function select(name, label, choices, options = {}) {
  const id = `field-${slug(name)}`;
  const opts = choices.map(([value, text]) => `<option value="${esc(value)}"`
    + `${String(options.value) === String(value) ? ' selected' : ''}>${esc(text)}</option>`).join('');
  return `<div class="crg-field">`
    + `<label class="crg-field__label" for="${id}">${esc(label)}</label>`
    + `<select class="crg-input" id="${id}" name="${esc(name)}">${opts}</select>`
    + `${options.hint ? `<p class="crg-field__hint">${esc(options.hint)}</p>` : ''}`
    + `</div>`;
}

/**
 * An action button.  `operation` names the documented endpoint it calls, and
 * the endpoint appears in the button's accessible description, so a user can
 * always tell what a control is about to do to the record.
 */
export function action(name, label, options = {}) {
  const operation = options.operation ? OPERATIONS[options.operation] : null;
  const describedBy = operation ? ` aria-describedby="action-${slug(name)}-desc"` : '';
  const description = operation
    ? `<span class="crg-action__desc" id="action-${slug(name)}-desc">`
      + `${esc(operation.method)} ${esc(operation.path)} `
      + `<span class="crg-action__spec">specification ${esc(operation.spec)}</span></span>`
    : '';
  const fields = Array.isArray(options.fields) && options.fields.length
    ? ` data-fields="${esc(options.fields.join(' '))}"` : '';
  return `<span class="crg-action">`
    + `<button type="button" class="crg-button crg-button--${esc(options.tone || 'primary')}" `
    + `data-action="${esc(name)}"${fields}${describedBy}${options.disabled ? ' disabled' : ''}>`
    + `${esc(label)}</button>${description}</span>`;
}

/** The list of documented endpoints a workspace reads from or writes to. */
export function endpointNote(names) {
  const rows = (names || []).map((name) => {
    const operation = OPERATIONS[name];
    if (!operation) return '';
    return `<li><code class="crg-code">${esc(operation.method)} ${esc(operation.path)}</code>`
      + ` <span class="crg-prose">specification ${esc(operation.spec)}</span></li>`;
  });
  if (!rows.filter(Boolean).length) return '';
  return `<details class="crg-disclosure crg-disclosure--quiet">`
    + `<summary class="crg-disclosure__summary">Where this comes from</summary>`
    + `<div class="crg-disclosure__body">`
    + `<p class="crg-prose">Everything on this screen was fetched from the public API. `
    + `Studio has no other access to the record.</p>`
    + `<ul class="crg-list">${join(rows, '')}</ul></div></details>`;
}

/**
 * Wrap a workspace body in the shared frame.
 *
 * A refusal, when present, is rendered above the body and never instead of
 * it: 6.6 refusals are informative records, and hiding the workspace behind
 * one would lose the context that makes the remedy actionable.
 */
export function shell(meta, body, state = {}) {
  const id = slug(meta.id);
  return `<article class="crg-workspace" data-workspace="${esc(meta.id)}" `
    + `aria-labelledby="ws-${id}-title">`
    + `<header class="crg-workspace__header">`
    + `<h2 class="crg-workspace__title" id="ws-${id}-title">${esc(meta.title)}</h2>`
    + `<p class="crg-workspace__purpose">${esc(meta.purpose)}</p>`
    + `${state.caseId
      ? `<p class="crg-workspace__case">Case <code class="crg-code">${esc(state.caseId)}</code>`
        + `${state.branchId ? `, branch <code class="crg-code">${esc(state.branchId)}</code>` : ''}</p>`
      : `<p class="crg-workspace__case">No case selected.</p>`}`
    + endpointNote(meta.endpoints)
    + `</header>`
    + `${state.error ? refusal(state.error) : ''}`
    + `<div class="crg-workspace__body">${body}</div>`
    + `</article>`;
}

/** The standard "you have not run this step yet" body. */
export function notYet(message, controls = '') {
  return `<div class="crg-notyet">${emptyState(message)}${controls}</div>`;
}

export default { action, endpointNote, field, notYet, select, shell };
