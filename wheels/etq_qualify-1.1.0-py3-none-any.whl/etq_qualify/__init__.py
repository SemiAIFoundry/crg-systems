"""etq-qualify: inverse qualification (OID-ETQ-002).

Reference implementation of master specification section 34, resting on
:mod:`etq_evidence` (section 33) for technology contracts and applicability
rules, and on :mod:`crg_model` for exact numerics and canonical hashing.

The module answers a question the forward pipeline cannot: *given a design
consequence I want, what must I measure?*  Specification 34.3 fixes the
direction, and four refusals keep this implementation honest about it.

**The chain runs backward, and the plan proves it (34.3).**  Inversion goes
predicate -> sufficient coordinate set -> source evidence -> applicability
transformations -> measurable targets -> experiments -> decision effect.
Each step is recorded with the identities it consumed, and
:class:`QualificationPlan` refuses to be constructed unless step *n*
consumes only identities steps ``1..n-1`` produced.  A forward solve
wearing inverse labels cannot pass that check.  The arithmetic is backward
too: a measurable target is obtained by solving ``g(theta) >= 0`` for one
coordinate with the others held at their worst case, then pulling that
bound back through the *inverse* of the declared applicability
transformation and widening it by the declared transfer tolerance.

**Cheapness never buys rank that information did not earn (34.4).**  The
ranking ratio has a numerator and a denominator, and a ratio alone would
let a zero-information experiment with a trivial burden float to the top.
Ranking is therefore tiered before it is scored: an experiment whose
declared reduction is not strictly positive sits below every informative
one whatever its burden, and an experiment with zero declared burden is
tiered rather than given an invented score.  A dimension that was never
declared cannot be weighted at all -- otherwise an experiment could improve
its rank by declining to quote its cost.

**A plan that cannot stop is invalid (34.5).**  All eight stopping
conditions the specification names are implemented, they are evaluated in
the order the objective declared them, and an undeclared condition never
fires however true it is.  :class:`QualificationObjective` and
:class:`QualificationPlan` both raise when no stopping rule is present.

**Contradiction is adjudicated, not averaged (33.5, 34.5).**  An
observation whose carried enclosure is disjoint from the coordinate's prior
enclosure raises manual adjudication instead of being merged into a
comfortable middle.

Every magnitude here is an exact rational (14.2).  No float is constructed,
compared, or hashed anywhere in the package.
"""
from .ambiguity import (
    BOUNDS_DERIVABLE_METRICS,
    AmbiguityError,
    AmbiguityMetric,
    InformationEffect,
    PredicateState,
    RankingBasis,
    compare_effects,
    feasibility_ambiguity,
    guaranteed_versus_possible_gap,
    interval_width,
    phase_boundary_uncertainty,
)
from .burden import (
    BurdenDimension,
    BurdenError,
    BurdenLimits,
    BurdenVector,
    BurdenWeights,
)
from .objective import (
    NOT_STOPPED,
    AcceptableAmbiguity,
    DecisionPredicate,
    PhaseRegion,
    QualificationError,
    QualificationObjective,
    StoppingCondition,
    StoppingRule,
)
from .experiment import (
    ExperimentDefinition,
    ExperimentError,
    RankedExperiment,
    RankingTier,
    ResultModel,
    ResultModelKind,
    rank_experiments,
)
from .state import QualificationState, region_ambiguity
from .invert import (
    PLAN_REQUIRED_ITEMS,
    CoordinateNeed,
    EvidenceNeed,
    InversionRecord,
    InversionStep,
    MeasurableTarget,
    QualificationPlan,
    TargetStatus,
    TransformationPath,
    invert,
)
from .execute import (
    ExperimentResult,
    QualificationResult,
    ResultStatus,
    TargetEvaluation,
    ingest_result,
    stopping_reached,
)

__version__ = "1.1.0"
SPEC_VERSION = "0.2.0"

__all__ = [
    # ambiguity (34.4)
    "BOUNDS_DERIVABLE_METRICS",
    "AmbiguityError",
    "AmbiguityMetric",
    "InformationEffect",
    "PredicateState",
    "RankingBasis",
    "compare_effects",
    "feasibility_ambiguity",
    "guaranteed_versus_possible_gap",
    "interval_width",
    "phase_boundary_uncertainty",
    # burden (34.2, 34.4)
    "BurdenDimension",
    "BurdenError",
    "BurdenLimits",
    "BurdenVector",
    "BurdenWeights",
    # objective (34.2, 34.5)
    "NOT_STOPPED",
    "AcceptableAmbiguity",
    "DecisionPredicate",
    "PhaseRegion",
    "QualificationError",
    "QualificationObjective",
    "StoppingCondition",
    "StoppingRule",
    # experiments and ranking (34.2, 34.4)
    "ExperimentDefinition",
    "ExperimentError",
    "RankedExperiment",
    "RankingTier",
    "ResultModel",
    "ResultModelKind",
    "rank_experiments",
    # state (34.5, 34.6)
    "QualificationState",
    "region_ambiguity",
    # inversion (34.3, 34.6)
    "PLAN_REQUIRED_ITEMS",
    "CoordinateNeed",
    "EvidenceNeed",
    "InversionRecord",
    "InversionStep",
    "MeasurableTarget",
    "QualificationPlan",
    "TargetStatus",
    "TransformationPath",
    "invert",
    # execution (34.5, 34.6)
    "ExperimentResult",
    "QualificationResult",
    "ResultStatus",
    "TargetEvaluation",
    "ingest_result",
    "stopping_reached",
]
