"""Certified-change surface for the shared certified-phase identity contract."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Optional

from crg_model.canonical import content_hash
from crg_model.edges import DependencyGraph
from crg_model.phase_binding import (
    CertifiedPhaseBinding,
    CertifiedPhaseBindingError,
    CertifiedPhaseConsumption,
    consume_certified_phase,
)
from crg_model.records import DeltaCertificate

from .certified_delta import CertifiedDeltaRecord, build_certified_delta

__all__ = ["PhaseBoundCertifiedChange", "build_phase_bound_certified_delta"]


@dataclass(frozen=True)
class PhaseBoundCertifiedChange:
    """Certified delta plus exact before/after phase-source identities."""

    certified_delta: CertifiedDeltaRecord
    current_phase_consumption: CertifiedPhaseConsumption
    prior_phase_binding_root: Optional[str] = None
    prior_phase_analysis_root: Optional[str] = None
    prior_source_r_root: Optional[str] = None

    def to_canonical(self) -> dict:
        record = {
            "record_type": "PhaseBoundCertifiedChange",
            "schema_version": "1.2.0",
            "certified_delta": self.certified_delta.to_canonical(),
            "certified_delta_root": self.certified_delta.root_hash(),
            "current_phase_consumption": self.current_phase_consumption.to_canonical(),
        }
        if self.prior_phase_binding_root is not None:
            record["prior_phase_identity"] = {
                "certified_phase_binding_root": self.prior_phase_binding_root,
                "phase_analysis_root": self.prior_phase_analysis_root,
                "source_r_root": self.prior_source_r_root,
            }
        return record

    def root_hash(self) -> str:
        return content_hash(self.to_canonical())


def build_phase_bound_certified_delta(
    delta: DeltaCertificate,
    prior_case: Any,
    current_case: Any,
    graph: DependencyGraph,
    *,
    current_phase: CertifiedPhaseBinding,
    expected_phase_analysis_root: str,
    expected_source_r_root: str,
    prior_phase: Optional[CertifiedPhaseBinding] = None,
    expected_prior_phase_analysis_root: Optional[str] = None,
    expected_prior_source_r_root: Optional[str] = None,
    replacements: Optional[Mapping[str, Any]] = None,
) -> PhaseBoundCertifiedChange:
    """Build a delta whose phase roots come only from verified shared bindings."""
    if not isinstance(current_phase, CertifiedPhaseBinding):
        raise CertifiedPhaseBindingError(
            "certified change requires a verified current CertifiedPhaseBinding"
        )
    current_phase.require_identity(expected_phase_analysis_root, expected_source_r_root)
    prior_phase_document = None
    prior_binding_root = prior_phase_root = prior_source_root = None
    if prior_phase is not None:
        if expected_prior_phase_analysis_root is None or expected_prior_source_r_root is None:
            raise CertifiedPhaseBindingError(
                "a prior phase binding requires both expected prior phase and source roots"
            )
        prior_phase.require_identity(
            expected_prior_phase_analysis_root,
            expected_prior_source_r_root,
        )
        prior_phase_document = prior_phase.phase_analysis
        prior_binding_root = prior_phase.root_hash()
        prior_phase_root = prior_phase.phase_analysis_root
        prior_source_root = prior_phase.source_r_root

    evidence = build_certified_delta(
        delta,
        prior_case,
        current_case,
        graph,
        replacements=replacements,
        prior_phase=prior_phase_document,
        current_phase=current_phase.phase_analysis,
    )
    if evidence.current_phase_root != current_phase.phase_analysis_root:
        raise CertifiedPhaseBindingError(
            "CertifiedDeltaRecord did not retain the shared current phase root"
        )
    if prior_phase is not None and evidence.prior_phase_root != prior_phase.phase_analysis_root:
        raise CertifiedPhaseBindingError(
            "CertifiedDeltaRecord did not retain the shared prior phase root"
        )
    consumption = consume_certified_phase(
        current_phase,
        consumer="CERTIFIED_CHANGE",
        subject_root=evidence.root_hash(),
        expected_phase_analysis_root=expected_phase_analysis_root,
        expected_source_r_root=expected_source_r_root,
    )
    return PhaseBoundCertifiedChange(
        certified_delta=evidence,
        current_phase_consumption=consumption,
        prior_phase_binding_root=prior_binding_root,
        prior_phase_analysis_root=prior_phase_root,
        prior_source_r_root=prior_source_root,
    )
