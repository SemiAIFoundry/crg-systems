"""Portable comparative evidence for one independently verified CRG change.

This additive v1.2 record does not change ``CertifiedDeltaRecord`` semantics.
It binds that record, the exact inputs needed by the independent verifier,
and the verifier's result, then exposes only the minimum action and exact
artifact identities that were preserved, invalidated, or recomputed.

The counts are identity counts.  They are not elapsed time, labor, money,
avoided work, savings, ROI, or a comparison against an unexecuted workflow.
"""
from __future__ import annotations

import copy
from dataclasses import dataclass
import re
from typing import Any, Mapping, Sequence

from crg_model.canonical import content_hash

__all__ = [
    "COMPARATIVE_CHANGE_AUTHORITY",
    "COMPARATIVE_CHANGE_CLAIM_BOUNDARY",
    "COMPARATIVE_CHANGE_FIRST_RELEASE",
    "COMPARATIVE_CHANGE_PROFILE",
    "COMPARATIVE_CHANGE_SCHEMA_VERSION",
    "QUALIFICATION_COMPARISON_CLAIM_BOUNDARY",
    "QUALIFICATION_COMPARISON_FIRST_RELEASE",
    "QUALIFICATION_COMPARISON_PROFILE",
    "QUALIFICATION_COMPARISON_SCHEMA_VERSION",
    "ComparativeChangeError",
    "ComparativeChangeEvidence",
    "build_comparative_change_evidence",
]


COMPARATIVE_CHANGE_SCHEMA_VERSION = "1.2.0"
COMPARATIVE_CHANGE_PROFILE = "crg-comparative-change/certified-delta@1"
COMPARATIVE_CHANGE_FIRST_RELEASE = "v1.2/CERTIFIED_PHASE_AND_TYPED_CHANGE"
COMPARATIVE_CHANGE_AUTHORITY = "NON_AUTHORIZING"
COMPARATIVE_CHANGE_CLAIM_BOUNDARY = (
    "Scoped certified-change facts only. Artifact identity counts do not measure "
    "time, effort, cost, avoided work, business savings, ROI, superiority, or an "
    "unexecuted counterfactual, and this record cannot authorize case state."
)

QUALIFICATION_COMPARISON_SCHEMA_VERSION = "1.3.0"
QUALIFICATION_COMPARISON_PROFILE = (
    "crg-comparative-change/qualification-selective-revalidation@1"
)
QUALIFICATION_COMPARISON_FIRST_RELEASE = (
    "v1.3/QUALIFICATION_AND_SELECTIVE_REVALIDATION"
)
QUALIFICATION_COMPARISON_CLAIM_BOUNDARY = (
    "Selective-revalidation facts are independently reconstructed from the stored "
    "typed dependency closure. Local operational observations remain non-evidentiary, "
    "user-declared counterfactuals remain unsupported, and no avoided work, avoided "
    "experiment, time, effort, cost, savings, ROI, superiority, or authorization is inferred."
)

_REQUIRED_INPUTS = frozenset(
    {"prior_case", "current_case", "dependency_edges", "replacements"}
)
_OPTIONAL_INPUTS = frozenset(
    {
        "prior_phase",
        "current_phase",
        "prior_phase_source_r",
        "current_phase_source_r",
    }
)
_FORBIDDEN_FACT_KEYS = frozenset(
    {
        "roi",
        "return_on_investment",
        "savings",
        "superiority",
        "generalization",
        "avoided_work",
        "avoided_recomputation",
        "avoided_effort",
        "cost_reduction",
        "time_reduction",
        "winner_method",
        "method_ranking",
    }
)

_QUALIFICATION_INPUT_FIELDS = frozenset(
    {
        "verification_profile",
        "first_release_attribution",
        "verifier_operation",
        "record_type",
        "record_hash",
        "inputs",
    }
)
_QUALIFICATION_REPLAY_FIELDS = frozenset({"dependency_edges", "artifact_universe"})
_REVALIDATION_ACTIONS = frozenset(
    {
        "NO_OPERATION",
        "REVALIDATE_ONLY",
        "RECOMPUTE_VALUE",
        "REPRICE",
        "RE_EMBED",
        "RE_EVALUATE",
        "REOPEN",
        "BLOCK",
    }
)
_MEASUREMENT_PROFILE = "crg-operational-measurement/local-private@1"
_MEASUREMENT_EVENT_SCHEMA = (
    "https://crg.systems/schemas/operational-measurement/1.0.0/"
    "operational-measurement-event.schema.json"
)
_MEASUREMENT_EVENT_FIELDS = frozenset(
    {
        "record_type",
        "schema_id",
        "schema_version",
        "profile_id",
        "content_hash",
        "session_id",
        "sequence",
        "event_type",
        "observed_at",
        "monotonic_ns",
        "previous_event_hash",
        "authorizing",
        "evidence_eligible",
        "metric",
    }
)
_MEASUREMENT_METRIC_FIELDS = frozenset(
    {
        "measurement_class",
        "metric_code",
        "exact_value",
        "unit_code",
        "authorizing",
        "evidence_eligible",
        "claim_boundary",
    }
)
_COUNTERFACTUAL_METRIC_FIELDS = _MEASUREMENT_METRIC_FIELDS | {
    "basis_code",
    "counterfactual_status",
    "roi_inferred",
    "savings_inferred",
    "superiority_inferred",
}
_CODE = re.compile(r"^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$")
_PSEUDONYM = re.compile(r"^psn-[a-z0-9]+(?:-[a-z0-9]+)*$")
_MAX_OPERATIONAL_REFERENCES = 32


class ComparativeChangeError(ValueError):
    """The proposed comparative change evidence is incomplete or stronger than supported."""


def _identity(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value.strip() or value != value.strip():
        raise ComparativeChangeError(f"{field} must be a normalized non-empty string")
    return value


def _object(value: Any, field: str) -> dict:
    if not isinstance(value, Mapping):
        raise ComparativeChangeError(f"{field} must be an object")
    result = copy.deepcopy(dict(value))
    # Canonical hashing is also the binary-float and unsupported-type guard.
    try:
        content_hash(result)
    except Exception as error:
        raise ComparativeChangeError(f"{field} is not portable canonical JSON: {error}") from error
    return result


def _identities(value: Any, field: str) -> list[str]:
    if not isinstance(value, list):
        raise ComparativeChangeError(f"{field} must be a list")
    result = [_identity(item, field) for item in value]
    if len(result) != len(set(result)):
        raise ComparativeChangeError(f"{field} contains duplicate identities")
    if result != sorted(result):
        raise ComparativeChangeError(f"{field} must be in canonical identity order")
    return result


def _exact_count(value: int) -> dict:
    return {"exact": str(value)}


def _sealed(value: Mapping[str, Any], key: str) -> dict:
    result = copy.deepcopy(dict(value))
    result.pop(key, None)
    result[key] = content_hash(result)
    return result


def _forbidden_paths(value: Any, path: str) -> list[str]:
    failures: list[str] = []
    if isinstance(value, Mapping):
        for key, item in value.items():
            normalized = str(key).strip().lower().replace("-", "_")
            if normalized in _FORBIDDEN_FACT_KEYS:
                failures.append(f"{path}.{key}")
            failures.extend(_forbidden_paths(item, f"{path}.{key}"))
    elif isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            failures.extend(_forbidden_paths(item, f"{path}[{index}]"))
    return failures


def _verification_result(value: Any, artifact_hash: str, minimum_action: str) -> dict:
    result = _object(value, "independent_verification")
    required = {"ok", "status", "checks", "violations", "warnings", "report"}
    if set(result) != required:
        raise ComparativeChangeError(
            "independent_verification must be one complete VerificationResult document"
        )
    if result.get("ok") is not True or result.get("status") != "VERIFIED":
        raise ComparativeChangeError(
            "the bound CertifiedDeltaRecord must have an independently VERIFIED result"
        )
    if result.get("violations") != []:
        raise ComparativeChangeError("an accepted independent result cannot contain violations")
    report = result.get("report")
    if not isinstance(report, Mapping):
        raise ComparativeChangeError("independent_verification.report must be an object")
    if report.get("artifact_root") != artifact_hash:
        raise ComparativeChangeError(
            "independent_verification does not bind the supplied CertifiedDeltaRecord"
        )
    if report.get("minimum_action") != minimum_action:
        raise ComparativeChangeError(
            "independent_verification minimum action differs from the supplied delta"
        )
    return result


def _scope(
    delta: Mapping[str, Any],
    inputs: Mapping[str, Any],
    decision_scope: Any,
    evidence_scope: Any,
) -> dict:
    prior = inputs["prior_case"]
    current = inputs["current_case"]
    if not isinstance(prior, Mapping) or not isinstance(current, Mapping):
        raise ComparativeChangeError("prior_case and current_case must be objects")
    decision = _object(decision_scope, "decision_scope")
    prior_case_id = prior.get("case_id")
    current_case_id = current.get("case_id")
    if prior_case_id is None and current_case_id is None:
        case_id = _identity(decision.get("case_id"), "decision_scope.case_id")
    elif prior_case_id is None or current_case_id is None:
        raise ComparativeChangeError(
            "prior_case and current_case must either both carry case_id or both omit it"
        )
    else:
        case_id = _identity(prior_case_id, "prior_case.case_id")
        if _identity(current_case_id, "current_case.case_id") != case_id:
            raise ComparativeChangeError(
                "comparative change evidence cannot cross case identities"
            )
    declared_case_id = decision.get("case_id")
    if declared_case_id is not None and (
        _identity(declared_case_id, "decision_scope.case_id") != case_id
    ):
        raise ComparativeChangeError(
            "decision_scope.case_id differs from the replayed case identity"
        )
    event = delta.get("change_event")
    if not isinstance(event, Mapping):
        raise ComparativeChangeError("CertifiedDeltaRecord.delta.change_event must be an object")
    scope = {
        "case_id": case_id,
        "event_id": _identity(event.get("event_id"), "change_event.event_id"),
        "prior_case_root": _identity(delta.get("prior_root"), "delta.prior_root"),
        "current_case_root": _identity(delta.get("current_root"), "delta.current_root"),
        "decision_scope": decision,
        "evidence_scope": _object(evidence_scope, "evidence_scope"),
        "change_scope": {
            "changed_object": _identity(
                event.get("changed_object"), "change_event.changed_object"
            ),
            "changed_properties": _identities(
                event.get("changed_properties"), "change_event.changed_properties"
            ),
            "declared_reason": _identity(
                event.get("declared_reason"), "change_event.declared_reason"
            ),
        },
    }
    return _sealed(scope, "scope_hash")


def _work_facts(delta: Mapping[str, Any], minimum_action: str) -> tuple[dict, dict]:
    preserved = _identities(delta.get("preserved"), "delta.preserved")
    invalidated = _identities(delta.get("invalidated"), "delta.invalidated")
    recomputed = _identities(delta.get("recomputed"), "delta.recomputed")
    overlap = sorted(set(preserved) & set(invalidated))
    if overlap:
        raise ComparativeChangeError(
            f"preserved and invalidated prior work overlap: {overlap}"
        )
    prior_members = sorted(set(preserved) | set(invalidated))
    denominator = _sealed(
        {
            "prior_artifact_work": {
                "members": prior_members,
                "count": _exact_count(len(prior_members)),
                "unit": "artifact identities",
            },
            "replacement_output_work": {
                "members": recomputed,
                "count": _exact_count(len(recomputed)),
                "unit": "artifact identities",
            },
        },
        "denominator_hash",
    )
    facts = {
        "facts_profile": "crg-certified-change-work/identity-counts@1",
        "minimum_action": minimum_action,
        "preserved_work": {
            "members": preserved,
            "count": _exact_count(len(preserved)),
            "unit": "artifact identities",
        },
        "invalidated_work": {
            "members": invalidated,
            "count": _exact_count(len(invalidated)),
            "unit": "artifact identities",
        },
        "recomputed_work": {
            "members": recomputed,
            "count": _exact_count(len(recomputed)),
            "unit": "artifact identities",
        },
        "prior_work_partition_complete": True,
        "interpretation": (
            "Exact artifact identities under the certified typed dependency closure; "
            "no effort, elapsed-time, cost, or counterfactual quantity is derived."
        ),
    }
    forbidden = _forbidden_paths(facts, "system_derived_facts")
    if forbidden:
        raise ComparativeChangeError(f"prohibited strengthened fact field(s): {forbidden}")
    return denominator, facts


def _hash(value: Any, field: str) -> str:
    result = _identity(value, field)
    if (
        not result.startswith("sha256:")
        or len(result) != 71
        or any(character not in "0123456789abcdef" for character in result[7:])
    ):
        raise ComparativeChangeError(f"{field} must be an algorithm-tagged SHA-256 hash")
    return result


def _integer(
    value: Any, field: str, *, positive: bool = False, nonnegative: bool = True
) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ComparativeChangeError(f"{field} must be an integer")
    if positive and value < 1:
        raise ComparativeChangeError(f"{field} must be positive")
    if nonnegative and value < 0:
        qualifier = "positive" if positive else "non-negative"
        raise ComparativeChangeError(f"{field} must be {qualifier}")
    return value


def _code(value: Any, field: str) -> str:
    result = _identity(value, field)
    if len(result) > 64 or _CODE.fullmatch(result) is None:
        raise ComparativeChangeError(f"{field} must be a bounded lower-kebab-case code")
    return result


def _measurement_event(value: Any, expected_class: str, field: str) -> dict:
    event = _object(value, field)
    if set(event) != _MEASUREMENT_EVENT_FIELDS:
        raise ComparativeChangeError(f"{field} has an unsupported measurement-event field set")
    if (
        event.get("record_type") != "OperationalMeasurementEvent"
        or event.get("schema_id") != _MEASUREMENT_EVENT_SCHEMA
        or event.get("schema_version") != "1.0.0"
        or event.get("profile_id") != _MEASUREMENT_PROFILE
        or event.get("event_type") != "METRIC"
        or event.get("authorizing") is not False
        or event.get("evidence_eligible") is not False
    ):
        raise ComparativeChangeError(
            f"{field} must be a non-authorizing v1 local operational METRIC event"
        )
    session_id = _identity(event.get("session_id"), f"{field}.session_id")
    if _PSEUDONYM.fullmatch(session_id) is None:
        raise ComparativeChangeError(f"{field}.session_id must be pseudonymous")
    _integer(event.get("sequence"), f"{field}.sequence")
    _identity(event.get("observed_at"), f"{field}.observed_at")
    _integer(event.get("monotonic_ns"), f"{field}.monotonic_ns")
    _hash(event.get("previous_event_hash"), f"{field}.previous_event_hash")
    stated_hash = _hash(event.get("content_hash"), f"{field}.content_hash")
    unsigned = copy.deepcopy(event)
    del unsigned["content_hash"]
    if stated_hash != content_hash(unsigned):
        raise ComparativeChangeError(f"{field}.content_hash does not bind the disclosed event")

    metric = _object(event.get("metric"), f"{field}.metric")
    expected_fields = (
        _COUNTERFACTUAL_METRIC_FIELDS
        if expected_class == "USER_DECLARED_COUNTERFACTUAL"
        else _MEASUREMENT_METRIC_FIELDS
    )
    if set(metric) != expected_fields:
        raise ComparativeChangeError(f"{field}.metric has an unsupported field set")
    if (
        metric.get("measurement_class") != expected_class
        or metric.get("authorizing") is not False
        or metric.get("evidence_eligible") is not False
        or metric.get("claim_boundary") != "operational-measurement-only"
    ):
        raise ComparativeChangeError(
            f"{field}.metric must remain operational-only, non-evidentiary, and non-authorizing"
        )
    _code(metric.get("metric_code"), f"{field}.metric.metric_code")
    _code(metric.get("unit_code"), f"{field}.metric.unit_code")
    exact = _object(metric.get("exact_value"), f"{field}.metric.exact_value")
    if set(exact) != {"numerator", "denominator"}:
        raise ComparativeChangeError(f"{field}.metric.exact_value must be a rational pair")
    _integer(
        exact.get("numerator"),
        f"{field}.metric.exact_value.numerator",
        nonnegative=False,
    )
    _integer(
        exact.get("denominator"),
        f"{field}.metric.exact_value.denominator",
        positive=True,
    )
    if expected_class == "USER_DECLARED_COUNTERFACTUAL":
        _code(metric.get("basis_code"), f"{field}.metric.basis_code")
        if (
            metric.get("counterfactual_status") != "USER_DECLARED_UNVERIFIED"
            or metric.get("roi_inferred") is not False
            or metric.get("savings_inferred") is not False
            or metric.get("superiority_inferred") is not False
        ):
            raise ComparativeChangeError(
                f"{field}.metric must remain user-declared, unsupported, and free of inferred claims"
            )
    return event


def _operational_references(
    values: Sequence[Mapping[str, Any]],
    *,
    expected_class: str,
) -> list[dict]:
    if not isinstance(values, (list, tuple)):
        raise ComparativeChangeError("operational measurement sources must be a list")
    if len(values) > _MAX_OPERATIONAL_REFERENCES:
        raise ComparativeChangeError(
            f"at most {_MAX_OPERATIONAL_REFERENCES} operational references are admitted per class"
        )
    references: list[dict] = []
    for index, raw in enumerate(values):
        source = _object(raw, f"operational_sources[{index}]")
        if set(source) != {"session_content_hash", "event"}:
            raise ComparativeChangeError(
                "each operational source must contain exactly session_content_hash and event"
            )
        session_hash = _hash(
            source.get("session_content_hash"),
            f"operational_sources[{index}].session_content_hash",
        )
        event = _measurement_event(
            source.get("event"), expected_class, f"operational_sources[{index}].event"
        )
        counterfactual = expected_class == "USER_DECLARED_COUNTERFACTUAL"
        reference = {
            "reference_profile": (
                "crg-local-operational-counterfactual-reference@1"
                if counterfactual
                else "crg-local-operational-observation-reference@1"
            ),
            "reference_version": QUALIFICATION_COMPARISON_SCHEMA_VERSION,
            "classification": (
                "UNSUPPORTED_USER_DECLARED_COUNTERFACTUAL"
                if counterfactual
                else "LOCAL_OPERATIONAL_OBSERVATION_NON_EVIDENCE"
            ),
            "claim_status": (
                "PRESENT_USER_DECLARED_UNVERIFIED"
                if counterfactual
                else "PRESENT_LOCAL_NOT_INDEPENDENTLY_RECONSTRUCTED"
            ),
            "session_id": event["session_id"],
            "session_content_hash": session_hash,
            "event_content_hash": event["content_hash"],
            "event": event,
            "authorizing": False,
            "evidence_eligible": False,
            "semantic_effect": "NONE",
        }
        references.append(_sealed(reference, "reference_hash"))
    references.sort(key=lambda item: (item["session_id"], item["event_content_hash"]))
    identities = [(item["session_id"], item["event_content_hash"]) for item in references]
    if len(identities) != len(set(identities)):
        raise ComparativeChangeError("operational references contain duplicate stored identities")
    return references


def _revalidation_facts(record: Mapping[str, Any]) -> dict:
    if (
        record.get("record_type") != "SelectiveRevalidationRecord"
        or record.get("profile") != "crg.etq-decision-loop"
        or record.get("schema_version") != "1.0.0"
    ):
        raise ComparativeChangeError(
            "qualification comparison requires a registered SelectiveRevalidationRecord"
        )
    _identity(record.get("record_id"), "selective_revalidation.record_id")
    changed = _identities(
        record.get("changed_properties"), "selective_revalidation.changed_properties"
    )
    affected_raw = record.get("affected")
    if not isinstance(affected_raw, list):
        raise ComparativeChangeError("selective_revalidation.affected must be a list")
    affected: list[dict] = []
    for index, raw in enumerate(affected_raw):
        item = _object(raw, f"selective_revalidation.affected[{index}]")
        if set(item) != {"artifact_id", "minimum_action"}:
            raise ComparativeChangeError("selective-revalidation affected facts are not closed")
        artifact_id = _identity(item.get("artifact_id"), "affected.artifact_id")
        action = _identity(item.get("minimum_action"), "affected.minimum_action")
        if action not in _REVALIDATION_ACTIONS:
            raise ComparativeChangeError(f"unknown selective-revalidation action {action!r}")
        affected.append({"artifact_id": artifact_id, "minimum_action": action})
    if affected != sorted(affected, key=lambda item: (item["artifact_id"], item["minimum_action"])):
        raise ComparativeChangeError("selective_revalidation.affected is not canonically ordered")
    if len({item["artifact_id"] for item in affected}) != len(affected):
        raise ComparativeChangeError("selective_revalidation.affected repeats an artifact")
    preserved = _identities(record.get("preserved"), "selective_revalidation.preserved")
    replacement = _identities(
        record.get("replacement_required"),
        "selective_revalidation.replacement_required",
    )
    if record.get("state") not in {"PENDING_REVALIDATION", "REVALIDATION_COMPLETE"}:
        raise ComparativeChangeError("selective_revalidation carries an unknown state")
    facts = {
        "facts_profile": "crg-selective-revalidation-facts/typed-closure@1",
        "classification": "SYSTEM_DERIVED_INDEPENDENTLY_RECONSTRUCTED",
        "changed_source": _identity(
            record.get("changed_source"), "selective_revalidation.changed_source"
        ),
        "changed_properties": changed,
        "affected": affected,
        "preserved": preserved,
        "replacement_required": replacement,
        "state": record["state"],
        "affected_count": _exact_count(len(affected)),
        "preserved_count": _exact_count(len(preserved)),
        "replacement_required_count": _exact_count(len(replacement)),
        "interpretation": (
            "Exact identities reconstructed from the stored complete typed dependency "
            "closure; no operational, economic, counterfactual, or authorization claim."
        ),
    }
    forbidden = _forbidden_paths(facts, "system_derived_revalidation_facts")
    if forbidden:
        raise ComparativeChangeError(f"prohibited strengthened fact field(s): {forbidden}")
    return facts


def _qualification_inputs(value: Any, record_hash: str) -> dict:
    envelope = _object(value, "selective_revalidation_verification_inputs")
    if set(envelope) != _QUALIFICATION_INPUT_FIELDS:
        raise ComparativeChangeError(
            "selective-revalidation verification inputs must be one complete lifecycle replay envelope"
        )
    replay = _object(envelope.get("inputs"), "lifecycle replay inputs")
    if set(replay) != _QUALIFICATION_REPLAY_FIELDS:
        raise ComparativeChangeError(
            "selective-revalidation lifecycle replay requires dependency_edges and artifact_universe"
        )
    if (
        envelope.get("verification_profile") != "crg-lifecycle/independent-replay@1"
        or envelope.get("first_release_attribution") != "v1.3/ETQ_LIFECYCLE"
        or envelope.get("verifier_operation") != "verify_selective_revalidation_record"
        or envelope.get("record_type") != "SelectiveRevalidationRecord"
        or envelope.get("record_hash") != record_hash
    ):
        raise ComparativeChangeError(
            "selective-revalidation lifecycle replay envelope does not bind the supplied record"
        )
    raw_edges = replay.get("dependency_edges")
    raw_universe = replay.get("artifact_universe")
    if not isinstance(raw_edges, list) or not isinstance(raw_universe, list):
        raise ComparativeChangeError("selective-revalidation replay inputs have invalid shapes")
    universe = [
        _identity(item, f"artifact_universe[{index}]")
        for index, item in enumerate(raw_universe)
    ]
    if not universe:
        raise ComparativeChangeError("artifact_universe must not be empty")
    if len(universe) != len(set(universe)) or universe != sorted(universe):
        raise ComparativeChangeError(
            "artifact_universe must be a unique canonically ordered identity list"
        )
    edge_ids = []
    for index, raw in enumerate(raw_edges):
        edge = _object(raw, f"dependency_edges[{index}]")
        edge_ids.append(_identity(edge.get("edge_id"), f"dependency_edges[{index}].edge_id"))
        _identity(edge.get("source"), f"dependency_edges[{index}].source")
        _identity(edge.get("target"), f"dependency_edges[{index}].target")
    if len(edge_ids) != len(set(edge_ids)) or edge_ids != sorted(edge_ids):
        raise ComparativeChangeError(
            "dependency edge identities must be unique and canonically ordered"
        )
    return envelope


def _qualification_verification(value: Any, artifact_hash: str) -> dict:
    result = _object(value, "selective_revalidation_independent_verification")
    required = {"ok", "status", "checks", "violations", "warnings", "report"}
    if set(result) != required:
        raise ComparativeChangeError(
            "selective-revalidation independent verification must be a complete VerificationResult"
        )
    if result.get("ok") is not True or result.get("status") != "VERIFIED":
        raise ComparativeChangeError(
            "SelectiveRevalidationRecord must have an independently VERIFIED result"
        )
    if result.get("violations") != [] or not isinstance(result.get("report"), Mapping):
        raise ComparativeChangeError("accepted revalidation verification cannot contain violations")
    if result["report"].get("artifact_root") != artifact_hash:
        raise ComparativeChangeError(
            "selective-revalidation independent verification binds different record bytes"
        )
    return result


def _qualification_extension(
    *,
    selective_revalidation: Mapping[str, Any],
    verification_inputs: Mapping[str, Any],
    independent_verification: Mapping[str, Any],
    local_operational_observations: Sequence[Mapping[str, Any]],
    declared_counterfactuals: Sequence[Mapping[str, Any]],
) -> dict:
    revalidation = _object(selective_revalidation, "selective_revalidation")
    revalidation_hash = content_hash(revalidation)
    inputs = _qualification_inputs(verification_inputs, revalidation_hash)
    verification = _qualification_verification(
        independent_verification, revalidation_hash
    )
    binding = _sealed(
        {
            "selective_revalidation_record": revalidation,
            "verification_inputs": inputs,
            "independent_verification": verification,
            "selective_revalidation_hash": revalidation_hash,
            "verification_inputs_hash": content_hash(inputs),
            "independent_verification_hash": content_hash(verification),
        },
        "binding_hash",
    )
    facts = _revalidation_facts(revalidation)
    observations = _operational_references(
        local_operational_observations, expected_class="LOCAL_OBSERVATION"
    )
    counterfactuals = _operational_references(
        declared_counterfactuals,
        expected_class="USER_DECLARED_COUNTERFACTUAL",
    )
    extension = {
        "extension_type": "QualificationSelectiveRevalidationComparison",
        "schema_version": QUALIFICATION_COMPARISON_SCHEMA_VERSION,
        "profile": QUALIFICATION_COMPARISON_PROFILE,
        "first_release_attribution": QUALIFICATION_COMPARISON_FIRST_RELEASE,
        "authority": COMPARATIVE_CHANGE_AUTHORITY,
        "authorizing": False,
        "semantic_effect": "NONE",
        "claim_boundary": QUALIFICATION_COMPARISON_CLAIM_BOUNDARY,
        "selective_revalidation_binding": binding,
        "system_derived_revalidation_facts": facts,
        "local_observation_status": (
            "PRESENT_LOCAL_NON_EVIDENTIARY" if observations else "ABSENT"
        ),
        "local_operational_observations": observations,
        "counterfactual_status": (
            "PRESENT_USER_DECLARED_UNSUPPORTED" if counterfactuals else "ABSENT"
        ),
        "declared_counterfactuals": counterfactuals,
        "conclusion": "NO_INFERRED_COUNTERFACTUAL_OR_ECONOMIC_CONCLUSION",
    }
    return _sealed(extension, "extension_hash")


@dataclass(frozen=True)
class ComparativeChangeEvidence:
    """Immutable convenience wrapper for a portable v1.2 comparison record."""

    record: Mapping[str, Any]

    def to_canonical(self) -> dict:
        return copy.deepcopy(dict(self.record))


def build_comparative_change_evidence(
    comparison_id: str,
    *,
    certified_delta: Mapping[str, Any],
    verification_inputs: Mapping[str, Any],
    independent_verification: Mapping[str, Any],
    decision_scope: Mapping[str, Any],
    evidence_scope: Mapping[str, Any],
    limitations: Sequence[str],
    selective_revalidation: Mapping[str, Any] | None = None,
    selective_revalidation_verification_inputs: Mapping[str, Any] | None = None,
    selective_revalidation_independent_verification: Mapping[str, Any] | None = None,
    local_operational_observations: Sequence[Mapping[str, Any]] = (),
    declared_counterfactuals: Sequence[Mapping[str, Any]] = (),
) -> ComparativeChangeEvidence:
    """Bind and summarize one independently verified ``CertifiedDeltaRecord``.

    The independent result is supplied across the trust-zone boundary.  The
    independent ``crg_verify`` implementation replays it again when this
    comparative artifact is verified.
    """

    identifier = _identity(comparison_id, "comparison_id")
    artifact = _object(certified_delta, "certified_delta")
    if (
        artifact.get("record_type") != "CertifiedDeltaRecord"
        or artifact.get("schema_version") != COMPARATIVE_CHANGE_SCHEMA_VERSION
        or artifact.get("verification_status") != "INDEPENDENTLY_VERIFIED"
    ):
        raise ComparativeChangeError(
            "certified_delta must be an independently verified v1.2.0 CertifiedDeltaRecord"
        )
    delta = artifact.get("delta")
    if not isinstance(delta, Mapping):
        raise ComparativeChangeError("certified_delta.delta must be an object")
    minimum_claim = artifact.get("minimum_recomputation_claim")
    if not isinstance(minimum_claim, Mapping):
        raise ComparativeChangeError("certified_delta has no minimum-recomputation claim")
    minimum_action = _identity(minimum_claim.get("action"), "minimum action")

    inputs = _object(verification_inputs, "verification_inputs")
    missing = sorted(_REQUIRED_INPUTS - set(inputs))
    unknown = sorted(set(inputs) - _REQUIRED_INPUTS - _OPTIONAL_INPUTS)
    if missing or unknown:
        raise ComparativeChangeError(
            f"verification_inputs are not closed: missing={missing}, unknown={unknown}"
        )
    artifact_hash = content_hash(artifact)
    independent = _verification_result(
        independent_verification, artifact_hash, minimum_action
    )
    binding = _sealed(
        {
            "certified_delta": artifact,
            "verification_inputs": inputs,
            "independent_verification": independent,
            "certified_delta_hash": artifact_hash,
            "verification_inputs_hash": content_hash(inputs),
            "independent_verification_hash": content_hash(independent),
        },
        "binding_hash",
    )
    scope = _scope(delta, inputs, decision_scope, evidence_scope)
    denominator, facts = _work_facts(delta, minimum_action)
    if not isinstance(limitations, (list, tuple)):
        raise ComparativeChangeError("limitations must be a list")
    limitation_records = sorted(_identity(item, "limitation") for item in limitations)
    if not limitation_records or len(limitation_records) != len(set(limitation_records)):
        raise ComparativeChangeError("limitations must be non-empty and unique")

    record = {
        "record_type": "ComparativeChangeEvidence",
        "schema_version": COMPARATIVE_CHANGE_SCHEMA_VERSION,
        "profile": COMPARATIVE_CHANGE_PROFILE,
        "first_release_attribution": COMPARATIVE_CHANGE_FIRST_RELEASE,
        "comparison_id": identifier,
        "authority": COMPARATIVE_CHANGE_AUTHORITY,
        "authorizing": False,
        "semantic_effect": "NONE",
        "evidence_class": "SYSTEM_DERIVED_CERTIFIED_CHANGE_FACTS",
        "claim_boundary": COMPARATIVE_CHANGE_CLAIM_BOUNDARY,
        "scope": scope,
        "certified_delta_binding": binding,
        "work_denominator": denominator,
        "system_derived_facts": facts,
        "conclusion": "NO_METHOD_RANKING_OR_ECONOMIC_CONCLUSION",
        "limitations": limitation_records,
    }
    extension_values = (
        selective_revalidation,
        selective_revalidation_verification_inputs,
        selective_revalidation_independent_verification,
    )
    if any(value is not None for value in extension_values):
        if any(value is None for value in extension_values):
            raise ComparativeChangeError(
                "qualification comparison requires the stored SelectiveRevalidationRecord, "
                "its exact lifecycle verification inputs, and its independent result"
            )
        record["qualification_extension"] = _qualification_extension(
            selective_revalidation=selective_revalidation,
            verification_inputs=selective_revalidation_verification_inputs,
            independent_verification=selective_revalidation_independent_verification,
            local_operational_observations=local_operational_observations,
            declared_counterfactuals=declared_counterfactuals,
        )
    elif local_operational_observations or declared_counterfactuals:
        raise ComparativeChangeError(
            "operational observations and counterfactual declarations require the v1.3 "
            "qualification/selective-revalidation extension"
        )
    return ComparativeChangeEvidence(_sealed(record, "record_hash"))
