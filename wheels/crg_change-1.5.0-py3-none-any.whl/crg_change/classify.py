"""Change classification (spec 30.2) and the conservative fallback (30.4).

The classification table of section 30.2 is encoded exactly.  Two inputs
decide a change class: the declared kind of the changed object and the
semantic class of each changed property path.  Anything that does not
resolve to a table row is REOPEN -- never a guess, never a default of
convenience (spec 30.4).
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Dict, Iterable, Mapping, Optional, Sequence, Tuple

from crg_model.edges import Action
from crg_model.records import ChangeEvent

__all__ = [
    "PropertyClass",
    "ObjectKind",
    "CLASS_ACTION",
    "Classification",
    "classify_property",
    "classify_change",
    "explain_change",
    "minimum_action",
]


class PropertyClass:
    """Semantic class of a changed property path (spec 30.2 rows)."""

    PRICE = "PRICE"
    EMBEDDING = "EMBEDDING"
    CAPABILITY = "CAPABILITY"
    REGISTRY = "REGISTRY"
    SEMANTICS = "SEMANTICS"
    GENERATOR = "GENERATOR"
    WORKLOAD = "WORKLOAD"
    SCOPE = "SCOPE"
    VALIDITY = "VALIDITY"
    METADATA = "METADATA"
    UNKNOWN = "UNKNOWN"


#: Specification 30.2, one entry per table row.
CLASS_ACTION: Dict[str, str] = {
    PropertyClass.PRICE: Action.REPRICE,
    PropertyClass.EMBEDDING: Action.RE_EMBED,
    PropertyClass.CAPABILITY: Action.REOPEN,
    PropertyClass.REGISTRY: Action.REOPEN,
    PropertyClass.SEMANTICS: Action.REOPEN,
    PropertyClass.GENERATOR: Action.REOPEN,
    PropertyClass.WORKLOAD: Action.REOPEN,
    PropertyClass.SCOPE: Action.REOPEN,
    PropertyClass.VALIDITY: Action.REVALIDATE_ONLY,
    PropertyClass.METADATA: Action.NO_OPERATION,
    PropertyClass.UNKNOWN: Action.REOPEN,
}


#: Path segments that identify a semantic class.  Matching is per-segment
#: and case-insensitive; a path matching several classes takes the most
#: severe of them.
PROPERTY_TOKENS: Dict[str, frozenset] = {
    PropertyClass.PRICE: frozenset(
        {
            "price", "prices", "pricing", "price_function", "price_model",
            "cost", "costs", "tariff", "rate", "rates", "fee", "fees", "charge",
            "coefficient", "coefficients", "service_coefficient",
            "service_coefficients", "service_function", "unit_price",
        }
    ),
    PropertyClass.EMBEDDING: frozenset(
        {
            "embedding", "embeddings", "embedding_model", "embedding_constraint",
            "embedding_constraints", "placement", "placements", "routing", "route",
            "routes", "layout", "topology", "physical_model", "feasibility",
            "feasibility_function", "site", "sites", "floorplan", "wiring",
            "interconnect", "port_map",
        }
    ),
    PropertyClass.CAPABILITY: frozenset(
        {
            "capability", "capabilities", "capability_gate", "capability_gates",
            "capability_predicate", "capability_predicates", "primitive",
            "primitives", "hierarchy", "hierarchies", "transformation",
            "transformations", "legality", "legality_rule", "legality_rules",
            "legal_transformations", "gate", "gates", "permitted_operations",
        }
    ),
    PropertyClass.REGISTRY: frozenset(
        {
            "registry", "registries", "membership", "members", "candidates",
            "candidate_registry", "catalog", "catalogue", "roster",
        }
    ),
    PropertyClass.SEMANTICS: frozenset(
        {
            "semantics", "computation", "computation_semantics", "algorithm",
            "correctness", "solver", "arithmetic", "arithmetic_profile",
            "rounding", "objective_semantics", "evaluation_semantics",
            "mapping_table_version",
        }
    ),
    PropertyClass.GENERATOR: frozenset(
        {"generator", "generators", "generator_version", "generator_versions", "emitted_family"}
    ),
    PropertyClass.WORKLOAD: frozenset(
        {
            "workload", "workloads", "validity_domain", "certified_validity",
            "operating_envelope", "operating_point", "duty_point",
        }
    ),
    PropertyClass.SCOPE: frozenset(
        {
            "scope", "scopes", "scope_id", "decision_scope", "accounting_scope",
            "resource_scope", "computation_scope", "claim_scope",
        }
    ),
    PropertyClass.VALIDITY: frozenset(
        {
            "validity", "valid_from", "valid_until", "expiry", "expires_at",
            "status", "evidence_status", "revocation", "revoked", "attestation",
            "integrity_signature", "signature_status", "signature_state",
            "key_id", "freshness", "clock_assertion",
        }
    ),
    # Lineage and annotation.  Spec 18.3 gives DERIVED_FROM_VERSION "no
    # direct invalidation; preserve lineage", so version bookkeeping is
    # metadata for classification purposes.
    PropertyClass.METADATA: frozenset(
        {
            "title", "label", "labels", "description", "notes", "note", "comment",
            "comments", "tag", "tags", "owner", "display_name", "author",
            "annotation", "annotations", "documentation", "ui",
            "created_at", "created_by", "updated_at", "timestamp",
            "version", "case_version", "object_version", "content_hash",
            "parent_hashes", "lineage",
        }
    ),
}

_SEGMENT_SPLIT = re.compile(r"[.\[\]]+")


class ObjectKind:
    """Declared kind of the changed object.

    The kind is what lets an evidence update be routed through the
    evidence rows of table 30.2 rather than the direct-object rows.
    """

    PRICE_MODEL = "PRICE_MODEL"
    EMBEDDING_MODEL = "EMBEDDING_MODEL"
    CAPABILITY_MODEL = "CAPABILITY_MODEL"
    COMPUTATION_SEMANTICS = "COMPUTATION_SEMANTICS"
    WORKLOAD = "WORKLOAD"
    GENERATOR = "GENERATOR"
    CANDIDATE_REGISTRY = "CANDIDATE_REGISTRY"
    DECISION_SCOPE = "DECISION_SCOPE"
    EVIDENCE_RECORD = "EVIDENCE_RECORD"
    TECHNOLOGY_CONTRACT = "TECHNOLOGY_CONTRACT"
    METADATA = "METADATA"
    UNKNOWN = "UNKNOWN"

    #: Kinds whose change is decided by the kind alone, whatever the
    #: property paths say (spec 30.2: capability, computation semantics,
    #: workload validity, generator family, registry membership, scope).
    UNCONDITIONAL: Dict[str, str] = {
        CAPABILITY_MODEL: Action.REOPEN,
        COMPUTATION_SEMANTICS: Action.REOPEN,
        WORKLOAD: Action.REOPEN,
        GENERATOR: Action.REOPEN,
        CANDIDATE_REGISTRY: Action.REOPEN,
        DECISION_SCOPE: Action.REOPEN,
    }

    #: Kinds that declare what their properties mean, so an otherwise
    #: unrecognized path inside them still resolves.  Kinds that carry
    #: mixed content (evidence, technology contracts, unknown objects)
    #: are deliberately absent: there, an unrecognized path is unresolved
    #: and therefore REOPEN.
    DEFAULT_CLASS: Dict[str, str] = {
        PRICE_MODEL: PropertyClass.PRICE,
        EMBEDDING_MODEL: PropertyClass.EMBEDDING,
        METADATA: PropertyClass.METADATA,
    }

    ALIASES: Dict[str, str] = {
        "PRICE": PRICE_MODEL,
        "PRICE_MODEL": PRICE_MODEL,
        "SERVICE_COEFFICIENTS": PRICE_MODEL,
        "TARIFF": PRICE_MODEL,
        "EMBEDDING": EMBEDDING_MODEL,
        "EMBEDDING_MODEL": EMBEDDING_MODEL,
        "PLACEMENT": EMBEDDING_MODEL,
        "ROUTING": EMBEDDING_MODEL,
        "CAPABILITY": CAPABILITY_MODEL,
        "CAPABILITY_MODEL": CAPABILITY_MODEL,
        "PRIMITIVE": CAPABILITY_MODEL,
        "HIERARCHY": CAPABILITY_MODEL,
        "LEGALITY_RULE": CAPABILITY_MODEL,
        "TRANSFORMATION_RULE": CAPABILITY_MODEL,
        "SEMANTICS": COMPUTATION_SEMANTICS,
        "COMPUTATION": COMPUTATION_SEMANTICS,
        "COMPUTATION_SEMANTICS": COMPUTATION_SEMANTICS,
        "WORKLOAD": WORKLOAD,
        "GENERATOR": GENERATOR,
        "REGISTRY": CANDIDATE_REGISTRY,
        "CANDIDATE_REGISTRY": CANDIDATE_REGISTRY,
        "SCOPE": DECISION_SCOPE,
        "DECISION_SCOPE": DECISION_SCOPE,
        "EVIDENCE": EVIDENCE_RECORD,
        "EVIDENCE_RECORD": EVIDENCE_RECORD,
        "TECHNOLOGY_CONTRACT": TECHNOLOGY_CONTRACT,
        "METADATA": METADATA,
        "ANNOTATION": METADATA,
        "UNKNOWN": UNKNOWN,
    }

    @classmethod
    def normalize(cls, kind: Optional[str]) -> str:
        if not kind:
            return cls.UNKNOWN
        return cls.ALIASES.get(str(kind).strip().upper(), cls.UNKNOWN)


#: Declared reasons that raise the floor of a classification.  A declared
#: reason may only escalate; it can never lower the action derived from
#: the changed properties.
DECLARED_REASON_FLOOR: Dict[str, str] = {
    "PRICE_UPDATE": Action.REPRICE,
    "SERVICE_COEFFICIENT_UPDATE": Action.REPRICE,
    "EMBEDDING_UPDATE": Action.RE_EMBED,
    "PLACEMENT_CHANGE": Action.RE_EMBED,
    "ROUTING_CHANGE": Action.RE_EMBED,
    "SIGNATURE_STATUS_CHANGE": Action.REVALIDATE_ONLY,
    "EVIDENCE_STATUS_CHANGE": Action.REVALIDATE_ONLY,
    "CAPABILITY_CHANGE": Action.REOPEN,
    "PRIMITIVE_ADDED": Action.REOPEN,
    "PRIMITIVE_REMOVED": Action.REOPEN,
    "LEGALITY_RULE_CHANGE": Action.REOPEN,
    "COMPUTATION_SEMANTICS_CHANGE": Action.REOPEN,
    "CORRECTNESS_FIX": Action.REOPEN,
    "WORKLOAD_OUTSIDE_CERTIFIED_VALIDITY": Action.REOPEN,
    "OUTSIDE_CERTIFIED_VALIDITY": Action.REOPEN,
    "GENERATOR_VERSION_CHANGE": Action.REOPEN,
    "REGISTRY_MEMBERSHIP_CHANGE": Action.REOPEN,
    "SCOPE_CHANGE": Action.REOPEN,
}

_REASON_NORMALIZE = re.compile(r"[^A-Z0-9]+")


def _reason_floor(declared_reason: Optional[str]) -> Tuple[str, Optional[str]]:
    if not declared_reason:
        return Action.NO_OPERATION, None
    code = _REASON_NORMALIZE.sub("_", str(declared_reason).upper()).strip("_")
    floor = DECLARED_REASON_FLOOR.get(code)
    if floor is None:
        return Action.NO_OPERATION, None
    return floor, code


def minimum_action(actions: Iterable[str]) -> str:
    """Least severe action that is still valid for every input action.

    "Minimum" is minimum *sufficient*: an action must discharge every
    obligation raised, so the result is the most severe member of the
    ordered lattice in :class:`crg_model.edges.Action`.  An unrecognized
    action label is unresolved and therefore REOPEN (spec 30.4).
    """
    best = Action.NO_OPERATION
    for action in actions:
        resolved = action if action in Action.SEVERITY else Action.REOPEN
        if Action.SEVERITY[resolved] > Action.SEVERITY[best]:
            best = resolved
    return best


def _segments(path: str) -> Tuple[str, ...]:
    return tuple(seg for seg in _SEGMENT_SPLIT.split(path.strip().lower()) if seg)


def classify_property(path: str) -> str:
    """Return the :class:`PropertyClass` of one dotted property path.

    A path matching several classes takes the most severe of them: a
    price coordinate sitting behind a capability gate is a capability
    change.
    """
    matched: list = []
    for segment in _segments(path):
        for klass, tokens in PROPERTY_TOKENS.items():
            if segment in tokens:
                matched.append(klass)
    if not matched:
        return PropertyClass.UNKNOWN
    return max(matched, key=lambda k: Action.SEVERITY[CLASS_ACTION[k]])


@dataclass(frozen=True)
class Classification:
    """The classification of a change plus why it was reached."""

    action: str
    kind: str
    reason: str
    property_classes: Mapping[str, str] = None  # type: ignore[assignment]

    def to_canonical(self) -> dict:
        return {
            "action": self.action,
            "object_kind": self.kind,
            "reason": self.reason,
            "property_classes": dict(self.property_classes or {}),
        }


def explain_change(
    event: ChangeEvent, *, object_kinds: Mapping[str, str]
) -> Classification:
    """Classify a change and record the rule that produced the result."""
    kind = ObjectKind.normalize(object_kinds.get(event.changed_object))
    floor, reason_code = _reason_floor(event.declared_reason)

    if kind in ObjectKind.UNCONDITIONAL:
        action = minimum_action((ObjectKind.UNCONDITIONAL[kind], floor))
        return Classification(
            action=action,
            kind=kind,
            reason=(
                f"object kind {kind} is decided by kind alone under spec 30.2; "
                f"changed properties do not lower it"
            ),
            property_classes={},
        )

    properties = [p for p in event.changed_properties if p]
    if not properties:
        action = minimum_action((Action.REOPEN, floor))
        return Classification(
            action=action,
            kind=kind,
            reason=(
                "no changed property paths were declared, so the change is "
                "unresolved; spec 30.4 requires reopening"
            ),
            property_classes={},
        )

    default_class = ObjectKind.DEFAULT_CLASS.get(kind)
    classes: Dict[str, str] = {}
    for path in properties:
        klass = classify_property(path)
        if klass == PropertyClass.UNKNOWN and default_class is not None:
            klass = default_class
        classes[path] = klass

    action = minimum_action([CLASS_ACTION[k] for k in classes.values()] + [floor])
    unresolved = sorted(p for p, k in classes.items() if k == PropertyClass.UNKNOWN)
    if unresolved:
        reason = (
            "unresolved property classification for "
            + ", ".join(unresolved)
            + "; spec 30.4 requires reopening"
        )
    else:
        dominant = max(
            classes.values(), key=lambda k: Action.SEVERITY[CLASS_ACTION[k]]
        )
        reason = (
            f"changed properties classify as {dominant} on a {kind} object; "
            f"spec 30.2 requires {CLASS_ACTION[dominant]}"
        )
    if reason_code and Action.SEVERITY[floor] >= Action.SEVERITY[action]:
        reason += f"; declared reason {reason_code} raises the floor to {floor}"
    return Classification(action=action, kind=kind, reason=reason, property_classes=classes)


def classify_change(event: ChangeEvent, *, object_kinds: Mapping[str, str]) -> str:
    """Return the :class:`crg_model.edges.Action` required by a change event."""
    return explain_change(event, object_kinds=object_kinds).action
