"""Portable, non-mutating Decision Challenge records.

Decision Challenge is an orchestration surface, not another decision engine.
This producer binds a frozen active-case baseline, an ordered set of inputs
admitted by the registered challenge profile, and the complete portable
inputs/results of the existing phase and certified-delta verifiers.  The
resulting record has no authority and performs no mutation or supersession.

The producer deliberately does not import :mod:`crg_verify`.  Independently
computed verifier results cross the package boundary as ordinary portable
records and are treated as evidence to be replayed.  The separate
``crg_verify.challenge`` implementation re-runs both registered verifiers,
reconstructs every displayed fact, and rejects a merely caller-derived phase
or delta conclusion.
"""
from __future__ import annotations

import copy
from dataclasses import dataclass
from fractions import Fraction
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from crg_model.canonical import CanonicalizationError, content_hash

from .apply import case_root
from .diff import canonical_form

__all__ = [
    "DECISION_CHALLENGE_SCHEMA_VERSION",
    "DECISION_CHALLENGE_PROFILE",
    "DECISION_CHALLENGE_VERIFICATION_PROGRAM",
    "CHALLENGE_AUTHORITY",
    "CHALLENGE_CLAIM_BOUNDARY",
    "ChallengeStatus",
    "ChallengeDesignError",
    "DecisionChallengeRecord",
    "registered_challenge_mutations",
    "registered_challenge_previews",
    "build_decision_challenge",
    "build_decision_challenge_refusal",
]

DECISION_CHALLENGE_SCHEMA_VERSION = "1.2.0"
DECISION_CHALLENGE_PROFILE = "crg-decision-challenge/registered-preview@1"
DECISION_CHALLENGE_VERIFICATION_PROGRAM = "crg-verify.decision-challenge/v1"
CHALLENGE_AUTHORITY = "NON_AUTHORIZING"
CHALLENGE_CLAIM_BOUNDARY = (
    "A Decision Challenge is a non-mutating preview over registered inputs and "
    "independently replayable evidence. It cannot authorize, mutate, promote, "
    "supersede, or replace the active case."
)


class ChallengeStatus:
    VERIFIED_PREVIEW = "VERIFIED_PREVIEW"
    REFUSED = "REFUSED"
    UNKNOWN = "UNKNOWN"


class ChallengeDesignError(ValueError):
    """The proposed challenge is outside the registered fail-closed profile."""


_MUTATION_PROFILES: Dict[str, Tuple[str, Tuple[str, ...]]] = {
    "OBJECTIVE": ("crg-challenge-input/objective@1", ("objective",)),
    "PRICE": ("crg-challenge-input/price@1", ("value", "unit")),
    "TECHNOLOGY_COORDINATE": (
        "crg-challenge-input/technology-coordinate@1",
        ("coordinate_id", "value", "unit"),
    ),
    "EVIDENCE_VALUE": (
        "crg-challenge-input/evidence-value@1",
        ("evidence_id", "value", "evidence_class"),
    ),
    "EVIDENCE_VALIDITY": (
        "crg-challenge-input/evidence-validity@1",
        ("evidence_id", "validity"),
    ),
    "CAPABILITY": (
        "crg-challenge-input/capability@1",
        ("capability_id", "value"),
    ),
    "LEGALITY": (
        "crg-challenge-input/legality@1",
        ("realization_id", "legality"),
    ),
    "POLICY_TOLERANCE": (
        "crg-challenge-input/policy-tolerance@1",
        ("value",),
    ),
    "RETENTION_POLICY": (
        "crg-challenge-input/retention-policy@1",
        ("policy_id", "policy"),
    ),
    "PHYSICAL_CONSTRAINT": (
        "crg-challenge-input/physical-constraint@1",
        ("constraint_id", "value", "unit"),
    ),
}

_PREVIEW_OPERATIONS = frozenset(
    {
        "BRANCH_PREVIEW",
        "PHASE_PREVIEW",
        "CHANGE_PREVIEW",
        "COMMITMENT_PREVIEW",
        "VERIFIER_REPLAY",
        "PHASE_AND_CHANGE_PREVIEW",
    }
)

_PROMOTION_OPERATIONS = frozenset(
    {
        "APPLY_CERTIFIED_CHANGE",
        "CREATE_GOVERNED_BRANCH",
        "SUBMIT_CHANGE_FOR_APPROVAL",
    }
)

_REFUSAL_REASONS = frozenset(
    {
        "UNREGISTERED_MUTATION",
        "MISSING_VERIFIER_EVIDENCE",
        "UNKNOWN_OR_INCOMPLETE_INPUT",
        "CHANGED_BASELINE_ROOT",
        "UNSUPPORTED_PROFILE",
        "VERIFICATION_FAILED",
        "UNKNOWN_CHANGE_SEMANTICS",
        "UNKNOWN_PROOF_SEMANTICS",
        "CALLER_DERIVED_FACTS_REFUSED",
    }
)

_EXACT_VALUE_MUTATIONS = frozenset(
    {
        "PRICE",
        "TECHNOLOGY_COORDINATE",
        "POLICY_TOLERANCE",
        "PHYSICAL_CONSTRAINT",
    }
)


def registered_challenge_mutations() -> dict:
    """Return an immutable-by-copy description of the registered input set."""
    return {
        name: {"input_profile": profile, "required_fields": list(required)}
        for name, (profile, required) in sorted(_MUTATION_PROFILES.items())
    }


def registered_challenge_previews() -> Tuple[str, ...]:
    return tuple(sorted(_PREVIEW_OPERATIONS))


def _identity(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value or value != value.strip():
        raise ChallengeDesignError(f"{field} must be a normalized non-empty string")
    return value


def _canonical(value: Any, field: str) -> Any:
    method = getattr(value, "to_canonical", None)
    if callable(method):
        return _canonical(method(), field)
    if value is None or isinstance(value, (str, int, bool)):
        return value
    if isinstance(value, float):
        raise ChallengeDesignError(
            f"{field} contains binary floating point outside the exact portable profile"
        )
    if isinstance(value, Fraction):
        text = (
            str(value.numerator)
            if value.denominator == 1
            else f"{value.numerator}/{value.denominator}"
        )
        return {"exact": text}
    if isinstance(value, Mapping):
        result = {}
        for key, item in value.items():
            if not isinstance(key, str):
                raise ChallengeDesignError(f"{field} contains a non-string object key")
            result[key] = _canonical(item, f"{field}.{key}")
        return result
    if isinstance(value, (list, tuple)):
        return [_canonical(item, f"{field}[]") for item in value]
    raise ChallengeDesignError(f"{field} contains non-portable {type(value).__name__}")


def _keys(value: Mapping[str, Any], expected: Sequence[str], field: str) -> None:
    expected_set = set(expected)
    missing = expected_set - set(value)
    unknown = set(value) - expected_set
    if missing:
        raise ChallengeDesignError(f"{field} is missing fields {sorted(missing)}")
    if unknown:
        raise ChallengeDesignError(f"{field} has unsupported fields {sorted(unknown)}")


def _exact_rational(value: Any, field: str, *, nonnegative: bool = False) -> Fraction:
    if isinstance(value, Mapping):
        if set(value) != {"exact"} or not isinstance(value.get("exact"), str):
            raise ChallengeDesignError(
                f"{field} must be an integer, rational string, or exact-rational object"
            )
        text = value["exact"]
    elif isinstance(value, str):
        text = value
    elif isinstance(value, int) and not isinstance(value, bool):
        text = str(value)
    else:
        raise ChallengeDesignError(
            f"{field} must be an integer, rational string, or exact-rational object"
        )
    try:
        number = Fraction(text)
    except (ValueError, ZeroDivisionError) as error:
        raise ChallengeDesignError(f"{field} is not an exact rational") from error
    canonical = (
        str(number.numerator)
        if number.denominator == 1
        else f"{number.numerator}/{number.denominator}"
    )
    if isinstance(value, Mapping) and text != canonical:
        raise ChallengeDesignError(f"{field} is not in reduced canonical rational form")
    if isinstance(value, str) and text != canonical:
        raise ChallengeDesignError(f"{field} is not a reduced canonical rational string")
    if nonnegative and number < 0:
        raise ChallengeDesignError(f"{field} must be nonnegative")
    return number


def _sealed(value: Mapping[str, Any], field: str) -> dict:
    record = copy.deepcopy(dict(value))
    record[field] = content_hash(record)
    return record


def _verification_result(value: Any, field: str, expected_status: str) -> dict:
    result = _canonical(value, field)
    if not isinstance(result, Mapping):
        raise ChallengeDesignError(f"{field} must be a portable verifier result")
    _keys(result, ("ok", "status", "checks", "violations", "warnings", "report"), field)
    if result.get("ok") is not True or result.get("status") != expected_status:
        raise ChallengeDesignError(
            f"{field} must report ok=true and status={expected_status}"
        )
    checks = result.get("checks")
    if not isinstance(checks, list) or not checks:
        raise ChallengeDesignError(f"{field}.checks must contain completed independent checks")
    for index, check in enumerate(checks):
        if not isinstance(check, Mapping):
            raise ChallengeDesignError(f"{field}.checks[{index}] must be an object")
        _keys(check, ("check", "passed", "detail"), f"{field}.checks[{index}]")
        _identity(check.get("check"), f"{field}.checks[{index}].check")
        _identity(check.get("detail"), f"{field}.checks[{index}].detail")
        if check.get("passed") is not True:
            raise ChallengeDesignError(f"{field} contains a failed check")
    if result.get("violations") != []:
        raise ChallengeDesignError(f"{field} contains verifier violations")
    if not isinstance(result.get("warnings"), list) or not isinstance(result.get("report"), Mapping):
        raise ChallengeDesignError(f"{field} has malformed warnings or report fields")
    return copy.deepcopy(dict(result))


def _normalize_payload(mutation_type: str, value: Any, field: str) -> dict:
    payload = _canonical(value, field)
    if not isinstance(payload, Mapping):
        raise ChallengeDesignError(f"{field} must be an object")
    required = _MUTATION_PROFILES[mutation_type][1]
    _keys(payload, required, field)
    for name in required:
        if name == "value" or name == "objective":
            continue
        _identity(payload.get(name), f"{field}.{name}")
    if mutation_type in _EXACT_VALUE_MUTATIONS:
        _exact_rational(
            payload.get("value"),
            f"{field}.value",
            nonnegative=mutation_type == "POLICY_TOLERANCE",
        )
    if mutation_type == "OBJECTIVE" and not isinstance(payload.get("objective"), Mapping):
        raise ChallengeDesignError(f"{field}.objective must be an object")
    if mutation_type == "LEGALITY" and payload.get("legality") not in {"LEGAL", "ILLEGAL"}:
        raise ChallengeDesignError(f"{field}.legality has unknown semantics")
    if mutation_type == "EVIDENCE_VALIDITY" and payload.get("validity") not in {
        "VALID", "INVALID", "EXPIRED", "REVOKED"
    }:
        raise ChallengeDesignError(f"{field}.validity has unknown semantics")
    return copy.deepcopy(dict(payload))


def _operations(value: Any) -> list:
    if not isinstance(value, (list, tuple)) or not value:
        raise ChallengeDesignError("operations must contain at least one registered challenge input")
    result = []
    identities = set()
    targets = set()
    for index, raw in enumerate(value):
        if not isinstance(raw, Mapping):
            raise ChallengeDesignError(f"operations[{index}] must be an object")
        _keys(
            raw,
            (
                "operation_id",
                "mutation_type",
                "input_profile",
                "preview_operation",
                "target_path",
                "input",
            ),
            f"operations[{index}]",
        )
        identifier = _identity(raw.get("operation_id"), f"operations[{index}].operation_id")
        if identifier in identities:
            raise ChallengeDesignError("challenge operation identities must be unique")
        identities.add(identifier)
        mutation_type = _identity(
            raw.get("mutation_type"), f"operations[{index}].mutation_type"
        )
        if mutation_type not in _MUTATION_PROFILES:
            raise ChallengeDesignError(f"unregistered challenge mutation {mutation_type!r}")
        expected_profile = _MUTATION_PROFILES[mutation_type][0]
        if raw.get("input_profile") != expected_profile:
            raise ChallengeDesignError(
                f"unregistered input profile {raw.get('input_profile')!r} for {mutation_type}"
            )
        preview = _identity(
            raw.get("preview_operation"), f"operations[{index}].preview_operation"
        )
        if preview not in _PREVIEW_OPERATIONS:
            raise ChallengeDesignError(f"unregistered challenge preview {preview!r}")
        target = _identity(raw.get("target_path"), f"operations[{index}].target_path")
        if target in targets:
            raise ChallengeDesignError("challenge target paths must be unique")
        targets.add(target)
        payload = _normalize_payload(mutation_type, raw.get("input"), f"operations[{index}].input")
        operation = {
            "operation_id": identifier,
            "sequence": index + 1,
            "mutation_type": mutation_type,
            "input_profile": expected_profile,
            "preview_operation": preview,
            "target_path": target,
            "input": payload,
            "input_root": content_hash(payload),
            "authority": CHALLENGE_AUTHORITY,
            "authorizing": False,
            "semantic_effect": "NONE",
            "mutation_performed": False,
        }
        result.append(_sealed(operation, "operation_hash"))
    return result


def _phase_evidence(value: Any) -> dict:
    if not isinstance(value, Mapping):
        raise ChallengeDesignError("phase_evidence is required")
    _keys(value, ("artifact", "source_r", "verification_result"), "phase_evidence")
    artifact = _canonical(value.get("artifact"), "phase_evidence.artifact")
    source = _canonical(value.get("source_r"), "phase_evidence.source_r")
    if not isinstance(artifact, Mapping) or not isinstance(source, Mapping):
        raise ChallengeDesignError("phase evidence artifact and source_r must be objects")
    if artifact.get("record_type") != "PhaseAnalysisRecord":
        raise ChallengeDesignError("phase evidence is not a PhaseAnalysisRecord")
    if artifact.get("schema_version") != "1.2.0":
        raise ChallengeDesignError("phase evidence uses an unsupported schema version")
    profile = artifact.get("profile")
    if (
        not isinstance(profile, Mapping)
        or profile.get("profile_id") != "TWO_COORDINATE_PRICE_SIMPLEX_V1"
        or profile.get("profile_version") != "1"
        or artifact.get("verification_program") != "crg-geometry.phase.verify/v1"
    ):
        raise ChallengeDesignError("phase evidence uses an unregistered profile or verifier")
    source_root = content_hash(source)
    if artifact.get("source_r_root") != source_root:
        raise ChallengeDesignError("phase evidence is not bound to its portable source R")
    if not isinstance(artifact.get("stability"), Mapping):
        raise ChallengeDesignError("phase evidence must include a registered stability probe")
    verification = _verification_result(
        value.get("verification_result"),
        "phase_evidence.verification_result",
        "VERIFIED_RELATIVE",
    )
    return {
        "artifact": copy.deepcopy(dict(artifact)),
        "artifact_root": content_hash(artifact),
        "source_r": copy.deepcopy(dict(source)),
        "source_r_root": source_root,
        "verification_result": verification,
        "verification_result_root": content_hash(verification),
    }


_DELTA_INPUT_FIELDS = (
    "current_case",
    "dependency_edges",
    "replacements",
    "prior_phase",
    "current_phase",
    "prior_phase_source_r",
    "current_phase_source_r",
)


def _delta_evidence(value: Any, baseline: Mapping[str, Any], phase: Mapping[str, Any]) -> dict:
    if not isinstance(value, Mapping):
        raise ChallengeDesignError("delta_evidence is required")
    _keys(
        value,
        ("artifact", *_DELTA_INPUT_FIELDS, "verification_result"),
        "delta_evidence",
    )
    artifact = _canonical(value.get("artifact"), "delta_evidence.artifact")
    if not isinstance(artifact, Mapping) or artifact.get("record_type") != "CertifiedDeltaRecord":
        raise ChallengeDesignError("delta evidence is not a CertifiedDeltaRecord")
    if artifact.get("schema_version") != "1.2.0":
        raise ChallengeDesignError("delta evidence uses an unsupported schema version")
    if (
        artifact.get("verification_program") != "crg-change.certified-delta.verify/v1"
        or artifact.get("verification_status") != "INDEPENDENTLY_VERIFIED"
    ):
        raise ChallengeDesignError("delta evidence uses an unregistered or unverified profile")
    inputs = {
        field: _canonical(value.get(field), f"delta_evidence.{field}")
        for field in _DELTA_INPUT_FIELDS
    }
    if not isinstance(inputs["current_case"], Mapping):
        raise ChallengeDesignError("delta_evidence.current_case must be an object")
    if not isinstance(inputs["dependency_edges"], list):
        raise ChallengeDesignError("delta_evidence.dependency_edges must be a list")
    if not isinstance(inputs["replacements"], Mapping):
        raise ChallengeDesignError("delta_evidence.replacements must be an object")
    if inputs["current_phase"] != phase["artifact"]:
        raise ChallengeDesignError("challenge phase and delta current-phase inputs differ")
    if inputs["current_phase_source_r"] != phase["source_r"]:
        raise ChallengeDesignError("challenge phase and delta current-phase source inputs differ")
    prior_phase = inputs["prior_phase"]
    prior_source = inputs["prior_phase_source_r"]
    if (prior_phase is None) != (prior_source is None):
        raise ChallengeDesignError(
            "prior phase evidence and its portable source must be present or absent together"
        )
    if prior_phase is not None:
        if not isinstance(prior_phase, Mapping) or not isinstance(prior_source, Mapping):
            raise ChallengeDesignError("prior phase evidence and source must be objects")
        if prior_phase.get("source_r_root") != content_hash(prior_source):
            raise ChallengeDesignError("prior phase evidence is not bound to its portable source")
    delta = artifact.get("delta")
    if not isinstance(delta, Mapping):
        raise ChallengeDesignError("certified delta has no portable delta record")
    if delta.get("prior_root") != case_root(baseline):
        raise ChallengeDesignError("certified delta is not bound to the active-case baseline")
    if delta.get("current_root") != case_root(inputs["current_case"]):
        raise ChallengeDesignError("certified delta is not bound to its preview case")
    phase_binding = artifact.get("phase_evidence")
    if not isinstance(phase_binding, Mapping):
        raise ChallengeDesignError("certified delta omits shared phase evidence")
    if phase_binding.get("current_phase_root") != phase["artifact_root"]:
        raise ChallengeDesignError("certified delta names a different current phase root")
    if prior_phase is not None and phase_binding.get("prior_phase_root") != content_hash(prior_phase):
        raise ChallengeDesignError("certified delta names a different prior phase root")
    verification = _verification_result(
        value.get("verification_result"),
        "delta_evidence.verification_result",
        "VERIFIED",
    )
    input_roots = {field: content_hash(inputs[field]) for field in _DELTA_INPUT_FIELDS}
    return {
        "artifact": copy.deepcopy(dict(artifact)),
        "artifact_root": content_hash(artifact),
        "verification_inputs": inputs,
        "verification_input_roots": input_roots,
        "verification_result": verification,
        "verification_result_root": content_hash(verification),
    }


def _path_value(document: Any, path: str) -> Any:
    tokens = []
    index = 0
    while index < len(path):
        if path[index] == ".":
            index += 1
            continue
        if path[index] == "[":
            closing = path.find("]", index + 1)
            if closing < 0 or not path[index + 1 : closing].isdigit():
                raise ChallengeDesignError(f"challenge target path {path!r} is malformed")
            tokens.append(int(path[index + 1 : closing]))
            index = closing + 1
            continue
        closing = index
        while closing < len(path) and path[closing] not in ".[":
            closing += 1
        token = path[index:closing]
        if not token:
            raise ChallengeDesignError(f"challenge target path {path!r} is malformed")
        tokens.append(token)
        index = closing
    current = document
    for token in tokens:
        if isinstance(token, int):
            if not isinstance(current, (list, tuple)) or token >= len(current):
                raise ChallengeDesignError(f"challenge target path {path!r} is absent")
            current = current[token]
        else:
            if not isinstance(current, Mapping) or token not in current:
                raise ChallengeDesignError(f"challenge target path {path!r} is absent")
            current = current[token]
    return current


def _covers(target: str, changed_path: str) -> bool:
    return (
        changed_path == target
        or changed_path.startswith(target + ".")
        or changed_path.startswith(target + "[")
    )


def _operation_bindings(
    operations: Sequence[Mapping[str, Any]],
    delta: Mapping[str, Any],
    current_case: Mapping[str, Any],
) -> None:
    changed_fields = delta.get("changed_fields")
    if not isinstance(changed_fields, list) or not changed_fields:
        raise ChallengeDesignError("certified delta has no changed-field evidence")
    by_path = {}
    for index, raw in enumerate(changed_fields):
        if not isinstance(raw, Mapping) or not isinstance(raw.get("path"), str):
            raise ChallengeDesignError(f"certified delta changed_fields[{index}] is malformed")
        if raw["path"] in by_path:
            raise ChallengeDesignError("certified delta repeats a changed field")
        by_path[raw["path"]] = raw
    for path in by_path:
        covering = [operation for operation in operations if _covers(operation["target_path"], path)]
        if len(covering) != 1:
            raise ChallengeDesignError(
                "registered challenge targets must cover every certified diff field exactly once"
            )
    for operation in operations:
        if not any(_covers(operation["target_path"], path) for path in by_path):
            raise ChallengeDesignError(
                f"operation {operation['operation_id']!r} covers no certified diff field"
            )
        proposed = operation["input"].get(
            "objective" if operation["mutation_type"] == "OBJECTIVE" else "value"
        )
        if operation["mutation_type"] in {
            "EVIDENCE_VALIDITY",
            "LEGALITY",
            "RETENTION_POLICY",
        }:
            key = {
                "EVIDENCE_VALIDITY": "validity",
                "LEGALITY": "legality",
                "RETENTION_POLICY": "policy",
            }[operation["mutation_type"]]
            proposed = operation["input"][key]
        current = _path_value(current_case, operation["target_path"])
        if proposed != current:
            raise ChallengeDesignError(
                f"operation {operation['operation_id']!r} input does not equal its preview diff"
            )


def _result(phase: Mapping[str, Any], delta: Mapping[str, Any]) -> dict:
    phase_artifact = phase["artifact"]
    delta_artifact = delta["artifact"]
    stability = phase_artifact["stability"]
    raw_delta = delta_artifact["delta"]
    minimum = delta_artifact.get("minimum_recomputation_claim")
    if not isinstance(minimum, Mapping):
        raise ChallengeDesignError("certified delta omits the minimum-recomputation claim")
    winner_ids = stability.get("winner_ids")
    if (
        not isinstance(winner_ids, list)
        or any(not isinstance(item, str) or not item for item in winner_ids)
        or winner_ids != sorted(set(winner_ids))
    ):
        raise ChallengeDesignError("phase stability winner identities are not canonical")
    return {
        "status": ChallengeStatus.VERIFIED_PREVIEW,
        "verification_status": {
            "challenge": "INDEPENDENT_CHALLENGE_REPLAY_REQUIRED",
            "phase": phase["verification_result"]["status"],
            "delta": delta["verification_result"]["status"],
        },
        "winner_ids": copy.deepcopy(winner_ids),
        "phase": {
            "analysis_id": phase_artifact.get("analysis_id"),
            "artifact_root": phase["artifact_root"],
            "state": stability.get("state"),
            "nearest_boundary_ids": copy.deepcopy(stability.get("nearest_boundary_ids")),
        },
        "change": {
            "evidence_id": delta_artifact.get("evidence_id"),
            "artifact_root": delta["artifact_root"],
            "preserved_ids": copy.deepcopy(raw_delta.get("preserved")),
            "invalidated_ids": copy.deepcopy(raw_delta.get("invalidated")),
            "replacement_roots": copy.deepcopy(delta_artifact.get("replacement_roots")),
        },
        "proposed_minimum_action": {
            "action": minimum.get("action"),
            "basis": minimum.get("basis"),
            "authority": CHALLENGE_AUTHORITY,
            "authorizing": False,
            "semantic_effect": "NONE",
        },
        "regret": {
            "status": "NOT_PRESENT_IN_PHASE_DELTA_PROFILE",
            "witnesses": [],
        },
        "claim_scope": phase_artifact.get("claim_scope"),
        "family_completeness": copy.deepcopy(phase_artifact.get("family_completeness")),
    }


def _promotion(value: Any, challenge_id: str, baseline_root: str) -> Optional[dict]:
    if value is None:
        return None
    if not isinstance(value, Mapping):
        raise ChallengeDesignError("promotion_request must be an object")
    _keys(
        value,
        ("request_id", "governed_operation", "requested_by", "reason"),
        "promotion_request",
    )
    request_id = _identity(value.get("request_id"), "promotion_request.request_id")
    operation = _identity(
        value.get("governed_operation"), "promotion_request.governed_operation"
    )
    if operation not in _PROMOTION_OPERATIONS:
        raise ChallengeDesignError(f"unregistered governed operation {operation!r}")
    record = {
        "record_type": "GovernedPromotionRequest",
        "request_id": request_id,
        "challenge_id": challenge_id,
        "baseline_case_root": baseline_root,
        "governed_operation": operation,
        "requested_by": _identity(value.get("requested_by"), "promotion_request.requested_by"),
        "reason": _identity(value.get("reason"), "promotion_request.reason"),
        "status": "PROPOSED",
        "execution_status": "NOT_EXECUTED",
        "authority": CHALLENGE_AUTHORITY,
        "authorizing": False,
        "semantic_effect": "NONE",
        "mutation_performed": False,
        "requires_explicit_governed_operation": True,
    }
    return _sealed(record, "request_hash")


def _no_mutation(baseline_root: str) -> dict:
    return {
        "baseline_case_root": baseline_root,
        "mutation_performed": False,
        "active_case_mutated": False,
        "active_case_superseded": False,
        "promotion_executed": False,
    }


@dataclass(frozen=True)
class DecisionChallengeRecord:
    """Immutable convenience wrapper around one portable challenge record."""

    record: Mapping[str, Any]

    def to_canonical(self) -> dict:
        return copy.deepcopy(dict(self.record))

    def root_hash(self) -> str:
        return content_hash(self.to_canonical())


def build_decision_challenge(
    challenge_id: str,
    *,
    baseline_case: Any,
    operations: Sequence[Mapping[str, Any]],
    phase_evidence: Mapping[str, Any],
    delta_evidence: Mapping[str, Any],
    promotion_request: Optional[Mapping[str, Any]] = None,
) -> DecisionChallengeRecord:
    """Build a successful non-mutating challenge from replayable evidence.

    No callbacks are invoked and no object is mutated.  Displayed outcomes
    are derived only from the supplied canonical phase and certified-delta
    records; callers cannot submit a winner, boundary, invalidation set, or
    minimum action directly.  The supplied independent-verifier results are
    still untrusted until ``crg_verify.challenge`` replays them.
    """

    identifier = _identity(challenge_id, "challenge_id")
    baseline = _canonical(canonical_form(baseline_case), "baseline_case")
    if not isinstance(baseline, Mapping):
        raise ChallengeDesignError("baseline_case must be an object")
    before = case_root(baseline)
    operation_records = _operations(operations)
    phase = _phase_evidence(phase_evidence)
    delta = _delta_evidence(delta_evidence, baseline, phase)
    _operation_bindings(
        operation_records,
        delta["artifact"],
        delta["verification_inputs"]["current_case"],
    )
    result = _result(phase, delta)
    after = case_root(baseline)
    if before != after:  # defensive invariant; this module contains no mutation path
        raise ChallengeDesignError("baseline case changed during challenge construction")
    record = {
        "record_type": "DecisionChallengeRecord",
        "schema_version": DECISION_CHALLENGE_SCHEMA_VERSION,
        "profile": DECISION_CHALLENGE_PROFILE,
        "challenge_id": identifier,
        "authority": CHALLENGE_AUTHORITY,
        "authorizing": False,
        "semantic_effect": "NONE",
        "claim_boundary": CHALLENGE_CLAIM_BOUNDARY,
        "baseline": {"case": copy.deepcopy(dict(baseline)), "case_root": before},
        "operations": operation_records,
        "evidence": {"phase": phase, "delta": delta},
        "result": result,
        "refusal": None,
        "no_mutation_guarantee": _no_mutation(before),
        "promotion_request": _promotion(promotion_request, identifier, before),
        "verification_program": DECISION_CHALLENGE_VERIFICATION_PROGRAM,
    }
    try:
        return DecisionChallengeRecord(_sealed(record, "record_hash"))
    except CanonicalizationError as error:
        raise ChallengeDesignError(f"challenge record is not canonically hashable: {error}") from error


def _refused_result(status: str) -> dict:
    return {
        "status": status,
        "verification_status": {
            "challenge": "REFUSED_BEFORE_PREVIEW",
            "phase": "NOT_ATTEMPTED",
            "delta": "NOT_ATTEMPTED",
        },
        "winner_ids": None,
        "phase": None,
        "change": None,
        "proposed_minimum_action": {
            "action": "REOPEN",
            "basis": "UNKNOWN_OR_UNVERIFIED_CHALLENGE_INPUT_FAILS_CLOSED",
            "authority": CHALLENGE_AUTHORITY,
            "authorizing": False,
            "semantic_effect": "NONE",
        },
        "regret": {"status": "NOT_EVALUATED", "witnesses": []},
        "claim_scope": None,
        "family_completeness": None,
    }


def build_decision_challenge_refusal(
    challenge_id: str,
    *,
    baseline_case: Any,
    status: str,
    reason_code: str,
    detail: str,
    attempted_input: Any,
) -> DecisionChallengeRecord:
    """Record a typed refusal/unknown result without interpreting the attempt."""

    identifier = _identity(challenge_id, "challenge_id")
    if status not in {ChallengeStatus.REFUSED, ChallengeStatus.UNKNOWN}:
        raise ChallengeDesignError("refusal status must be REFUSED or UNKNOWN")
    if reason_code not in _REFUSAL_REASONS:
        raise ChallengeDesignError(f"unregistered challenge refusal reason {reason_code!r}")
    baseline = _canonical(canonical_form(baseline_case), "baseline_case")
    if not isinstance(baseline, Mapping):
        raise ChallengeDesignError("baseline_case must be an object")
    baseline_root = case_root(baseline)
    attempt = _canonical(attempted_input, "attempted_input")
    refusal = _sealed(
        {
            "status": status,
            "reason_code": reason_code,
            "detail": _identity(detail, "detail"),
            "attempted_input": attempt,
            "attempted_input_root": content_hash(attempt),
            "disposition": "NO_PREVIEW_NO_MUTATION_REOPEN_OR_REFUSE",
        },
        "refusal_hash",
    )
    record = {
        "record_type": "DecisionChallengeRecord",
        "schema_version": DECISION_CHALLENGE_SCHEMA_VERSION,
        "profile": DECISION_CHALLENGE_PROFILE,
        "challenge_id": identifier,
        "authority": CHALLENGE_AUTHORITY,
        "authorizing": False,
        "semantic_effect": "NONE",
        "claim_boundary": CHALLENGE_CLAIM_BOUNDARY,
        "baseline": {"case": copy.deepcopy(dict(baseline)), "case_root": baseline_root},
        "operations": [],
        "evidence": {"phase": None, "delta": None},
        "result": _refused_result(status),
        "refusal": refusal,
        "no_mutation_guarantee": _no_mutation(baseline_root),
        "promotion_request": None,
        "verification_program": DECISION_CHALLENGE_VERIFICATION_PROGRAM,
    }
    try:
        return DecisionChallengeRecord(_sealed(record, "record_hash"))
    except CanonicalizationError as error:
        raise ChallengeDesignError(f"refusal record is not canonically hashable: {error}") from error
