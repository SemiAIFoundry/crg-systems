"""Impact planning: typed propagation and selective preservation.

Normative basis: master specification 18.5 (traverse only reachable
affected descendants; preserve unaffected certificates and proof
objects), 30.3 steps 2-7, and 35.1 (selective revalidation).

Propagation itself belongs to :meth:`crg_model.edges.DependencyGraph.propagate`;
this module supplies the change classification that seeds it, the
certificate bookkeeping that separates preserved from invalidated
artifacts, and the minimum sufficient action for each affected object.
"""
from __future__ import annotations

from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Set, Tuple

from crg_model.edges import Action, DependencyGraph
from crg_model.envelope import ObjectStatus
from crg_model.records import ChangeEvent, ChangeImpactPlan

from .classify import Classification, explain_change, minimum_action
from .diff import object_relative, property_closure

__all__ = [
    "object_kind_of",
    "object_kinds_of",
    "certificate_dependencies",
    "build_impact_plan",
    "mark_stale",
]


def object_kind_of(obj: Any) -> Optional[str]:
    """Extract a declared object kind from whatever the caller stored.

    Accepts a bare kind string, a mapping carrying ``object_kind`` /
    ``kind`` / ``object_type``, or any record with an ``envelope``
    exposing ``object_type``.
    """
    if obj is None:
        return None
    if isinstance(obj, str):
        return obj
    if isinstance(obj, Mapping):
        for key in ("object_kind", "kind", "object_type"):
            if key in obj:
                return obj[key]
        return None
    for attr in ("object_kind", "kind"):
        value = getattr(obj, attr, None)
        if isinstance(value, str):
            return value
    envelope = getattr(obj, "envelope", None)
    if envelope is not None:
        return getattr(envelope, "object_type", None)
    return None


def object_kinds_of(all_objects: Mapping[str, Any]) -> Dict[str, str]:
    kinds: Dict[str, str] = {}
    for object_id, obj in (all_objects or {}).items():
        kind = object_kind_of(obj)
        if kind:
            kinds[object_id] = kind
    return kinds


def _certificate_items(certificates: Any) -> List[Tuple[str, Any]]:
    """Normalize the certificate collection to ``[(certificate_id, cert)]``."""
    if not certificates:
        return []
    if isinstance(certificates, Mapping):
        return [(str(k), v) for k, v in certificates.items()]
    items: List[Tuple[str, Any]] = []
    for cert in certificates:
        cert_id = getattr(cert, "certificate_id", None)
        if cert_id is None and isinstance(cert, Mapping):
            cert_id = cert.get("certificate_id")
        if cert_id is None:
            raise ValueError("certificate without a certificate_id cannot be tracked")
        items.append((str(cert_id), cert))
    return items


def certificate_dependencies(cert_id: str, cert: Any) -> Set[str]:
    """Every object identity a certificate rests on (spec 29.5, 30.5)."""
    deps: Set[str] = {cert_id}
    if cert is None:
        return deps
    if isinstance(cert, (list, tuple, set, frozenset)):
        deps.update(str(d) for d in cert)
        return deps
    if isinstance(cert, Mapping):
        for key in ("dependencies", "evidence_roots", "objects"):
            deps.update(str(d) for d in cert.get(key, ()) or ())
        for key in ("complete_registry_hash", "retained_registry_hash"):
            value = cert.get(key)
            if value:
                deps.add(str(value))
        return deps
    for key in ("dependencies", "evidence_roots"):
        deps.update(str(d) for d in getattr(cert, key, ()) or ())
    scope = getattr(cert, "scope", None)
    scope_id = getattr(scope, "scope_id", None)
    if scope_id:
        deps.add(str(scope_id))
    return deps


def build_impact_plan(
    event: ChangeEvent,
    graph: DependencyGraph,
    *,
    all_objects: Mapping[str, Any],
    certificates: Any,
) -> ChangeImpactPlan:
    """Classify a change, propagate it, and split preserved from invalidated.

    ``all_objects`` maps object identity to the object (or to its declared
    kind); ``certificates`` maps certificate identity to a certificate (or
    is any iterable of certificates).  Objects and certificates outside the
    reachable affected subgraph are reported in ``preserved`` and are never
    recomputed -- the selective-revalidation guarantee of 18.5 and 35.1.
    """
    all_objects = all_objects or {}
    classification = explain_change(event, object_kinds=object_kinds_of(all_objects))

    paths = object_relative(
        [p for p in event.changed_properties if p], event.changed_object
    )
    closure = property_closure(paths) or None
    edge_impact = graph.propagate({event.changed_object: closure})

    affected: Dict[str, str] = {}
    if classification.action != Action.NO_OPERATION:
        affected[event.changed_object] = classification.action
    for target, edge_action in edge_impact.items():
        # A descendant inherits the severity of the change at its source:
        # a reopened basis cannot support a merely revalidated dependant.
        action = minimum_action((edge_action, classification.action))
        if action == Action.NO_OPERATION:
            continue
        affected[target] = minimum_action((affected.get(target, Action.NO_OPERATION), action))

    plan_classification = minimum_action(
        [classification.action] + list(affected.values())
    )

    preserved: List[str] = []
    invalidated: List[str] = []
    for cert_id, cert in _certificate_items(certificates):
        deps = certificate_dependencies(cert_id, cert)
        if deps & set(affected):
            invalidated.append(cert_id)
        else:
            preserved.append(cert_id)
    preserved.extend(object_id for object_id in all_objects if object_id not in affected)

    required_actions = sorted(
        {action for action in affected.values() if action != Action.NO_OPERATION},
        key=lambda a: (-Action.SEVERITY[a], a),
    )

    return ChangeImpactPlan(
        classification=plan_classification,
        affected=dict(sorted(affected.items())),
        preserved=sorted(set(preserved)),
        invalidated=sorted(set(invalidated)),
        required_actions=required_actions,
    )


def mark_stale(all_objects: Mapping[str, Any], plan: ChangeImpactPlan) -> List[str]:
    """Mark affected objects stale where their envelope allows it (30.3 step 6).

    Objects that expose no envelope are left untouched; the plan remains
    the authoritative record of what is affected.
    """
    marked: List[str] = []
    for object_id, action in (plan.affected or {}).items():
        if action == Action.NO_OPERATION:
            continue
        obj = (all_objects or {}).get(object_id)
        envelope = getattr(obj, "envelope", None)
        if envelope is None or not hasattr(envelope, "status"):
            continue
        envelope.status = (
            ObjectStatus.INVALID if action == Action.BLOCK else ObjectStatus.STALE
        )
        marked.append(object_id)
    return sorted(marked)
