"""Minimum valid recomputation and the delta certificate.

Normative basis: master specification section 30.3 (change algorithm)
and 30.5 (delta certificate).  This module orchestrates steps 1-10; it
does not decide winners.  Deciding winners is the job of the caller's
``recompute_fn`` (in the reference stack, ``crg_certify.certify``), which
is invoked only over the affected subgraph.
"""
from __future__ import annotations

import inspect
from dataclasses import replace
from typing import Any, Callable, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from crg_model.canonical import content_hash
from crg_model.edges import Action, DependencyGraph
from crg_model.records import ChangeEvent, ChangeImpactPlan, DeltaCertificate

from .classify import explain_change, minimum_action
from .diff import canonical_form, diff_objects
from .plan import build_impact_plan, mark_stale, object_kinds_of

__all__ = ["case_view", "case_root", "apply_change"]

RESIDUAL_BLOCKED = "BLOCKED_DEPENDENCY"
RESIDUAL_PENDING = "REOPENED_PENDING_RECERTIFICATION"
RESIDUAL_WINNERS_CHANGED = "WINNER_SET_CHANGED"


def case_view(case: Any) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """Return ``(objects, certificates)`` for a case container.

    A case is either a mapping carrying ``objects`` and ``certificates``
    or any object exposing those two attributes.
    """
    if case is None:
        return {}, {}
    if isinstance(case, Mapping):
        objects = case.get("objects") or {}
        certificates = case.get("certificates") or {}
    else:
        objects = getattr(case, "objects", None) or {}
        certificates = getattr(case, "certificates", None) or {}
    if not isinstance(objects, Mapping):
        objects = {str(getattr(o, "object_id", i)): o for i, o in enumerate(objects)}
    return dict(objects), certificates


def case_root(case: Any) -> str:
    """Content hash of a case in canonical form (spec 14.4, 30.5)."""
    return content_hash(canonical_form(case))


def _certificate_map(value: Any) -> Dict[str, Any]:
    if not value:
        return {}
    if isinstance(value, Mapping):
        return {str(k): v for k, v in value.items()}
    if not isinstance(value, (list, tuple, set, frozenset)):
        value = [value]
    out: Dict[str, Any] = {}
    for cert in value:
        cert_id = getattr(cert, "certificate_id", None)
        if cert_id is None and isinstance(cert, Mapping):
            cert_id = cert.get("certificate_id")
        if cert_id is None:
            raise ValueError("recompute_fn returned a certificate without a certificate_id")
        out[str(cert_id)] = cert
    return out


def _field(cert: Any, name: str, default: Any = ()) -> Any:
    if isinstance(cert, Mapping):
        return cert.get(name, default)
    return getattr(cert, name, default)


def _winner_set(certificates: Mapping[str, Any]) -> List[str]:
    winners = set()
    for cert in certificates.values():
        winners.update(str(w) for w in _field(cert, "selected", ()) or ())
        winners.update(str(w) for w in _field(cert, "ties", ()) or ())
    return sorted(winners)


def _margin(certificates: Mapping[str, Any]) -> Optional[Any]:
    """Margin of the lexicographically first certificate that carries one.

    Deterministic selection matters: the delta certificate is hashed.
    """
    for _cert_id, cert in sorted(certificates.items()):
        margin = _field(cert, "margin", None)
        if margin is not None:
            return margin
    return None


def _invoke_recompute(recompute_fn: Callable, case: Any, plan: ChangeImpactPlan) -> Any:
    """Call ``recompute_fn(case, plan)``, or ``recompute_fn(case)`` if that is its arity."""
    try:
        signature = inspect.signature(recompute_fn)
    except (TypeError, ValueError):  # pragma: no cover - builtins
        return recompute_fn(case, plan)
    positional = [
        p
        for p in signature.parameters.values()
        if p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD)
    ]
    variadic = any(p.kind == p.VAR_POSITIONAL for p in signature.parameters.values())
    if len(positional) >= 2 or variadic:
        return recompute_fn(case, plan)
    if "plan" in signature.parameters:
        return recompute_fn(case, plan=plan)
    return recompute_fn(case)


def apply_change(
    prior_case: Any,
    current_case: Any,
    event: ChangeEvent,
    graph: DependencyGraph,
    *,
    recompute_fn: Callable,
    delta_id: Optional[str] = None,
    approvals: Sequence[str] = (),
    residual_uncertainty: Optional[str] = None,
) -> DeltaCertificate:
    """Execute the minimum valid recomputation for a change (spec 30.3).

    The canonical diff of the two cases is authoritative for what changed;
    any properties declared on the event are unioned in, so an incomplete
    declaration can never narrow propagation.  ``recompute_fn`` is called
    once, with the current case and the impact plan, and only when the
    plan requires work; its certificates replace the invalidated ones
    while preserved certificates are carried through untouched.
    """
    prior_objects, prior_certs_raw = case_view(prior_case)
    current_objects, current_certs_raw = case_view(current_case)
    prior_certificates = _certificate_map(prior_certs_raw)
    current_certificates = _certificate_map(current_certs_raw)

    changed_paths, _detail = diff_objects(prior_case, current_case)
    effective_paths = sorted(set(changed_paths) | {p for p in event.changed_properties if p})
    effective_event = replace(event, changed_properties=tuple(effective_paths))

    plan = build_impact_plan(
        effective_event,
        graph,
        all_objects=current_objects,
        certificates=current_certificates,
    )
    classification = explain_change(
        effective_event, object_kinds=object_kinds_of(current_objects)
    )
    mark_stale(current_objects, plan)

    invalidated = set(plan.invalidated)
    surviving = {
        cert_id: cert
        for cert_id, cert in current_certificates.items()
        if cert_id not in invalidated
    }

    recomputed: Dict[str, Any] = {}
    if plan.classification != Action.NO_OPERATION:
        result = _invoke_recompute(recompute_fn, current_case, plan)
        recomputed = _certificate_map(result)

    resulting = dict(surviving)
    resulting.update(recomputed)

    prior_winners = _winner_set(prior_certificates)
    current_winners = _winner_set(resulting)

    if residual_uncertainty is None:
        if Action.BLOCK in set(plan.affected.values()):
            residual_uncertainty = RESIDUAL_BLOCKED
        elif invalidated and not recomputed and plan.classification != Action.NO_OPERATION:
            residual_uncertainty = RESIDUAL_PENDING
        elif current_winners != prior_winners:
            residual_uncertainty = RESIDUAL_WINNERS_CHANGED

    reopen_reason: Optional[str] = None
    if plan.classification == Action.REOPEN:
        reopen_reason = classification.reason
        if classification.action != Action.REOPEN:
            reopen_reason += "; escalated to REOPEN by an affected dependency edge"

    delta = DeltaCertificate(
        delta_id=delta_id or f"delta-{event.event_id}",
        prior_root=case_root(prior_case),
        current_root=case_root(current_case),
        change_event=effective_event,
        classification=plan.classification,
        affected_paths=[f"{obj}:{action}" for obj, action in sorted(plan.affected.items())],
        preserved=list(plan.preserved),
        invalidated=sorted(invalidated),
        recomputed=sorted(recomputed),
        prior_winners=prior_winners,
        current_winners=current_winners,
        prior_margin=_margin(prior_certificates),
        current_margin=_margin(resulting),
        residual_uncertainty=residual_uncertainty,
        approvals=list(approvals),
        reopen_reason=reopen_reason,
    )
    return delta
