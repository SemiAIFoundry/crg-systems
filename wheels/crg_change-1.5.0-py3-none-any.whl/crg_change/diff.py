"""Canonical diff of prior and current objects.

Normative basis: master specification section 30.3 step 1 ("canonically
diff prior and current objects").  The diff is performed on canonical
forms only, so two objects with identical canonical encodings produce no
changed properties at all -- that is what makes ``REVALIDATE_ONLY`` and
``NO_OPERATION`` reachable rather than theoretical.
"""
from __future__ import annotations

from typing import Any, Dict, Iterable, List, Sequence, Set, Tuple

from crg_model.canonical import CanonicalizationError, canonical_json

__all__ = [
    "ChangeKind",
    "diff_objects",
    "canonical_form",
    "property_closure",
    "object_relative",
]

ROOT_PATH = "<root>"


class ChangeKind:
    """How a single property path changed."""

    ADDED = "ADDED"
    REMOVED = "REMOVED"
    MODIFIED = "MODIFIED"


def canonical_form(value: Any) -> Any:
    """Return the canonical dict/list form of ``value`` where one exists."""
    to_canonical = getattr(value, "to_canonical", None)
    if callable(to_canonical):
        return to_canonical()
    return value


def _canonically_equal(left: Any, right: Any) -> bool:
    try:
        return canonical_json(left) == canonical_json(right)
    except CanonicalizationError:
        # Non-canonicalizable payloads still have to be comparable; fall
        # back to structural equality rather than declaring "unchanged".
        return left == right


def _join(path: str, key: str) -> str:
    return f"{path}.{key}" if path else key


def _record(out: Dict[str, Dict[str, Any]], path: str, kind: str, prior: Any, current: Any) -> None:
    out[path or ROOT_PATH] = {"change": kind, "prior": prior, "current": current}


def _walk(path: str, prior: Any, current: Any, out: Dict[str, Dict[str, Any]]) -> None:
    if _canonically_equal(prior, current):
        return
    prior = canonical_form(prior)
    current = canonical_form(current)
    if isinstance(prior, dict) and isinstance(current, dict):
        for key in sorted(set(prior) | set(current)):
            child = _join(path, str(key))
            if key not in prior:
                _record(out, child, ChangeKind.ADDED, None, current[key])
            elif key not in current:
                _record(out, child, ChangeKind.REMOVED, prior[key], None)
            else:
                _walk(child, prior[key], current[key], out)
        return
    if isinstance(prior, (list, tuple)) and isinstance(current, (list, tuple)):
        for index in range(max(len(prior), len(current))):
            child = f"{path}[{index}]" if path else f"[{index}]"
            if index >= len(prior):
                _record(out, child, ChangeKind.ADDED, None, current[index])
            elif index >= len(current):
                _record(out, child, ChangeKind.REMOVED, prior[index], None)
            else:
                _walk(child, prior[index], current[index], out)
        return
    _record(out, path, ChangeKind.MODIFIED, prior, current)


def diff_objects(prior: Any, current: Any) -> Tuple[List[str], Dict[str, Dict[str, Any]]]:
    """Diff two canonical objects.

    Returns ``(changed_paths, detail)`` where ``changed_paths`` is the
    sorted list of dotted property paths that changed (list elements are
    addressed as ``parent[index]``) and ``detail`` maps each path to
    ``{"change": ChangeKind, "prior": ..., "current": ...}``.

    Identical canonical forms yield ``([], {})``.
    """
    detail: Dict[str, Dict[str, Any]] = {}
    _walk("", canonical_form(prior), canonical_form(current), detail)
    return sorted(detail), detail


def _strip_indices(path: str) -> str:
    out: List[str] = []
    depth = 0
    for char in path:
        if char == "[":
            depth += 1
        elif char == "]":
            depth = max(0, depth - 1)
        elif depth == 0:
            out.append(char)
    return "".join(out)


def property_closure(paths: Iterable[str]) -> Set[str]:
    """Expand changed paths into every form a dependency edge may declare.

    A ``DependencyEdge`` names a single ``source_property``; it may do so
    at any granularity (``technology.price`` or
    ``technology.price.package_gbps``).  The closure therefore contains
    every dotted prefix of every changed path, both with and without list
    indices, so edge matching is granularity-independent (spec 18.2).
    """
    closure: Set[str] = set()
    for raw in paths:
        if not raw:
            continue
        for variant in {raw, _strip_indices(raw)}:
            if not variant:
                continue
            closure.add(variant)
            segments = variant.split(".")
            for cut in range(1, len(segments)):
                closure.add(".".join(segments[:cut]))
    return closure


def object_relative(paths: Iterable[str], object_id: str) -> Set[str]:
    """Re-root case-level diff paths onto the changed object.

    A diff taken over a whole case yields ``objects.tech-a.price.rate``
    while dependency edges are declared relative to the object itself
    (``price.rate``).  Both forms are retained so neither declaration
    style is silently ignored.
    """
    out: Set[str] = set()
    for path in paths:
        out.add(path)
        segments = _strip_indices(path).split(".")
        if object_id in segments:
            index = segments.index(object_id)
            remainder = ".".join(segments[index + 1:])
            if remainder:
                out.add(remainder)
    return out
