"""Portable, independently checked evidence for a CRG change.

The v1.0.1 :class:`crg_model.records.DeltaCertificate` remains wire
compatible.  Workstream C layers this additive record over it to carry the
missing verification evidence required by specification 30.5 and roadmap
6.3: canonical field deltas, typed edges actually traversed, categorized
before/after changes, completeness changes, phase-evidence roots,
replacement roots, and a recomputed minimum-action claim.

``build_certified_delta`` fails closed.  It will not label the wrapper
``INDEPENDENTLY_VERIFIED`` unless a second path reconstructs the roots,
classification, dependency closure, affected/preserved/invalidated sets,
traversed edge types, replacement objects, and winner sets.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Set, Tuple

from crg_model.canonical import content_hash
from crg_model.edges import Action, DependencyEdge, DependencyGraph
from crg_model.records import ChangeEvent, DeltaCertificate

from .apply import case_root, case_view
from .classify import explain_change, minimum_action
from .diff import canonical_form, diff_objects, object_relative, property_closure
from .plan import object_kinds_of

__all__ = [
    "CERTIFIED_DELTA_SCHEMA_VERSION",
    "DeltaCategory",
    "DeltaVerificationError",
    "FieldDelta",
    "TraversedEdge",
    "CertifiedDeltaRecord",
    "build_certified_delta",
    "verify_certified_delta",
    "require_verified_delta",
]

CERTIFIED_DELTA_SCHEMA_VERSION = "1.2.0"


class DeltaCategory:
    PHASE = "PHASE"
    CERTIFICATE = "CERTIFICATE"
    DEPENDENCY = "DEPENDENCY"
    EVIDENCE = "EVIDENCE"
    GEOMETRY = "GEOMETRY"
    SIGNATURE = "SIGNATURE"
    FAMILY = "FAMILY"
    OTHER = "OTHER"

    ALL = (
        FAMILY,
        SIGNATURE,
        GEOMETRY,
        EVIDENCE,
        DEPENDENCY,
        CERTIFICATE,
        PHASE,
        OTHER,
    )


class DeltaVerificationError(ValueError):
    """The claimed change evidence did not survive independent reconstruction."""


def _stable_id(prefix: str, value: Any) -> str:
    digest = content_hash(value).split(":", 1)[1]
    return f"{prefix}-{digest[:20]}"


def _path_category(path: str) -> str:
    normalized = path.lower().replace("[", ".").replace("]", "")
    tokens = {token for token in normalized.split(".") if token}
    tests = (
        (DeltaCategory.PHASE, {"phase", "phases", "boundary", "boundaries", "stability"}),
        (
            DeltaCategory.CERTIFICATE,
            {"certificate", "certificates", "winner", "winners", "margin", "approvals"},
        ),
        (
            DeltaCategory.DEPENDENCY,
            {"dependency", "dependencies", "edge", "edges", "graph", "lineage"},
        ),
        (
            DeltaCategory.EVIDENCE,
            {
                "evidence",
                "uncertainty",
                "provenance",
                "applicability",
                "validity",
                "attestation",
            },
        ),
        (
            DeltaCategory.GEOMETRY,
            {"geometry", "gamma", "frontier", "vertices", "fiber", "fibers", "envelope"},
        ),
        (
            DeltaCategory.SIGNATURE,
            {"signature", "signatures", "coordinate", "coordinates", "schema"},
        ),
        (
            DeltaCategory.FAMILY,
            {
                "family",
                "registry",
                "realization",
                "realizations",
                "candidate",
                "candidates",
                "members",
                "completeness",
            },
        ),
    )
    for category, vocabulary in tests:
        if tokens & vocabulary:
            return category
    return DeltaCategory.OTHER


@dataclass(frozen=True)
class FieldDelta:
    path: str
    change: str
    category: str
    prior: Any
    current: Any

    def to_canonical(self) -> dict:
        return {
            "path": self.path,
            "change": self.change,
            "category": self.category,
            "prior": self.prior,
            "current": self.current,
        }


@dataclass(frozen=True)
class TraversedEdge:
    edge_id: str
    source: str
    target: str
    edge_type: str
    source_property: str
    minimum_action: str
    transitive: bool

    @classmethod
    def from_edge(cls, edge: DependencyEdge) -> "TraversedEdge":
        return cls(
            edge_id=edge.edge_id,
            source=edge.source,
            target=edge.target,
            edge_type=edge.edge_type,
            source_property=edge.source_property or "*",
            minimum_action=edge.minimum_action,
            transitive=edge.transitive,
        )

    def to_canonical(self) -> dict:
        return {
            "edge_id": self.edge_id,
            "source": self.source,
            "target": self.target,
            "edge_type": self.edge_type,
            "source_property": self.source_property,
            "minimum_action": self.minimum_action,
            "transitive": self.transitive,
        }


@dataclass(frozen=True)
class CertifiedDeltaRecord:
    """The complete portable evidence envelope around a v1 delta certificate."""

    evidence_id: str
    delta: DeltaCertificate
    changed_fields: Tuple[FieldDelta, ...]
    category_changes: Dict[str, Tuple[str, ...]]
    traversed_edges: Tuple[TraversedEdge, ...]
    completeness_changes: Tuple[str, ...]
    minimum_recomputation_action: str
    minimum_recomputation_basis: str
    replacement_roots: Dict[str, str]
    schema_version: str = CERTIFIED_DELTA_SCHEMA_VERSION
    prior_phase_root: Optional[str] = None
    current_phase_root: Optional[str] = None
    verification_status: str = "UNVERIFIED"
    verification_program: str = "crg-change.certified-delta.verify/v1"

    def to_canonical(self) -> dict:
        record = {
            "record_type": "CertifiedDeltaRecord",
            "schema_version": self.schema_version,
            "evidence_id": self.evidence_id,
            "delta": self.delta.to_canonical(),
            "delta_root": self.delta.delta_hash(),
            "changed_fields": [item.to_canonical() for item in self.changed_fields],
            "category_changes": {
                category: list(self.category_changes.get(category, ()))
                for category in DeltaCategory.ALL
            },
            "traversed_edges": [edge.to_canonical() for edge in self.traversed_edges],
            "edge_types_traversed": sorted({edge.edge_type for edge in self.traversed_edges}),
            "completeness_changes": list(self.completeness_changes),
            "minimum_recomputation_claim": {
                "action": self.minimum_recomputation_action,
                "basis": self.minimum_recomputation_basis,
            },
            "replacement_roots": dict(sorted(self.replacement_roots.items())),
            "verification_status": self.verification_status,
            "verification_program": self.verification_program,
            "fail_closed_policy": {
                "unresolved_change_class": "REOPEN",
                "unknown_dependency_semantics": "REOPEN",
                "incomplete_dependency_closure": "REOPEN",
            },
        }
        phase = {}
        if self.prior_phase_root is not None:
            phase["prior_phase_root"] = self.prior_phase_root
        if self.current_phase_root is not None:
            phase["current_phase_root"] = self.current_phase_root
        if phase:
            record["phase_evidence"] = phase
        return record

    def root_hash(self) -> str:
        return content_hash(self.to_canonical())


def _field_deltas(prior_case: Any, current_case: Any) -> Tuple[FieldDelta, ...]:
    _paths, detail = diff_objects(prior_case, current_case)
    return tuple(
        FieldDelta(
            path=path,
            change=detail[path]["change"],
            category=_path_category(path),
            prior=detail[path]["prior"],
            current=detail[path]["current"],
        )
        for path in sorted(detail)
    )


def _category_changes(fields: Sequence[FieldDelta]) -> Dict[str, Tuple[str, ...]]:
    return {
        category: tuple(sorted(item.path for item in fields if item.category == category))
        for category in DeltaCategory.ALL
    }


def _effective_paths(delta: DeltaCertificate, fields: Sequence[FieldDelta]) -> Tuple[str, ...]:
    return tuple(
        sorted(
            {item.path for item in fields}
            | {path for path in delta.change_event.changed_properties if path}
        )
    )


def _trace_edges(
    graph: DependencyGraph,
    event: ChangeEvent,
    effective_paths: Sequence[str],
) -> Tuple[TraversedEdge, ...]:
    identifiers: Set[str] = set()
    for node in sorted(graph.nodes):
        for edge in graph.edges_from(node):
            if edge.edge_id in identifiers:
                raise DeltaVerificationError(
                    f"dependency graph repeats edge identifier {edge.edge_id!r}; "
                    "typed traversal cannot be reconstructed unambiguously"
                )
            identifiers.add(edge.edge_id)
    relative = object_relative(effective_paths, event.changed_object)
    initial_properties = property_closure(relative) or None
    frontier: List[Tuple[str, Optional[Set[str]]]] = [
        (event.changed_object, initial_properties)
    ]
    seen: Set[str] = set()
    traversed: List[TraversedEdge] = []
    while frontier:
        node, properties = frontier.pop()
        for edge in sorted(graph.edges_from(node), key=lambda item: item.edge_id):
            if edge.edge_id in seen or not edge.triggered_by(properties):
                continue
            seen.add(edge.edge_id)
            traversed.append(TraversedEdge.from_edge(edge))
            if edge.transitive and edge.minimum_action != Action.NO_OPERATION:
                frontier.append((edge.target, None))
    return tuple(sorted(traversed, key=lambda item: item.edge_id))


def _artifact_root(value: Any) -> str:
    for name in ("root_hash", "certificate_hash", "delta_hash", "bundle_hash"):
        method = getattr(value, name, None)
        if callable(method):
            result = method()
            if isinstance(result, str):
                return result
    return content_hash(canonical_form(value))


def _replacement_roots(replacements: Optional[Mapping[str, Any]]) -> Dict[str, str]:
    roots: Dict[str, str] = {}
    for identifier, value in sorted((replacements or {}).items()):
        key = str(identifier)
        declared = _record_field(value, "certificate_id", None)
        if declared is not None and str(declared) != key:
            raise DeltaVerificationError(
                f"replacement key {key!r} does not match certificate_id {declared!r}"
            )
        roots[key] = _artifact_root(value)
    return roots


def _phase_root(value: Any) -> Optional[str]:
    if value is None:
        return None
    return _artifact_root(value)


def _certificate_map(value: Any) -> Dict[str, Any]:
    if not value:
        return {}
    if isinstance(value, Mapping):
        return {str(identifier): artifact for identifier, artifact in value.items()}
    if not isinstance(value, (list, tuple, set, frozenset)):
        value = [value]
    out: Dict[str, Any] = {}
    for artifact in value:
        identifier = getattr(artifact, "certificate_id", None)
        if identifier is None and isinstance(artifact, Mapping):
            identifier = artifact.get("certificate_id")
        if identifier is None:
            raise DeltaVerificationError("replacement certificate has no certificate_id")
        out[str(identifier)] = artifact
    return out


def _record_field(record: Any, name: str, default: Any = ()) -> Any:
    if isinstance(record, Mapping):
        return record.get(name, default)
    return getattr(record, name, default)


def _winner_set(certificates: Mapping[str, Any]) -> Tuple[str, ...]:
    winners: Set[str] = set()
    for artifact in certificates.values():
        winners.update(str(value) for value in (_record_field(artifact, "selected", ()) or ()))
        winners.update(str(value) for value in (_record_field(artifact, "ties", ()) or ()))
    return tuple(sorted(winners))


def _margin(certificates: Mapping[str, Any]) -> Any:
    for _identifier, artifact in sorted(certificates.items()):
        margin = _record_field(artifact, "margin", None)
        if margin is not None:
            return canonical_form(margin)
    return None


def _certificate_dependencies(identifier: str, artifact: Any) -> Set[str]:
    dependencies: Set[str] = {identifier}
    if artifact is None:
        return dependencies
    if isinstance(artifact, (list, tuple, set, frozenset)):
        dependencies.update(str(value) for value in artifact)
        return dependencies
    if isinstance(artifact, Mapping):
        for key in ("dependencies", "evidence_roots", "objects"):
            dependencies.update(str(value) for value in (artifact.get(key, ()) or ()))
        for key in ("complete_registry_hash", "retained_registry_hash"):
            value = artifact.get(key)
            if value:
                dependencies.add(str(value))
        return dependencies
    for key in ("dependencies", "evidence_roots"):
        dependencies.update(str(value) for value in (getattr(artifact, key, ()) or ()))
    scope = getattr(artifact, "scope", None)
    scope_id = getattr(scope, "scope_id", None)
    if scope_id:
        dependencies.add(str(scope_id))
    return dependencies


def _expected_affected(
    event: ChangeEvent,
    classification: str,
    traversed: Sequence[TraversedEdge],
) -> Dict[str, str]:
    affected: Dict[str, str] = {}
    if classification != Action.NO_OPERATION:
        affected[event.changed_object] = classification
    for edge in traversed:
        action = minimum_action((classification, edge.minimum_action))
        if action == Action.NO_OPERATION:
            continue
        affected[edge.target] = minimum_action(
            (affected.get(edge.target, Action.NO_OPERATION), action)
        )
    return dict(sorted(affected.items()))


def _encoded_affected(affected: Mapping[str, str]) -> Tuple[str, ...]:
    return tuple(f"{identifier}:{action}" for identifier, action in sorted(affected.items()))


def build_certified_delta(
    delta: DeltaCertificate,
    prior_case: Any,
    current_case: Any,
    graph: DependencyGraph,
    *,
    replacements: Optional[Mapping[str, Any]] = None,
    prior_phase: Any = None,
    current_phase: Any = None,
) -> CertifiedDeltaRecord:
    """Add complete change evidence and independently verify it before return."""
    fields = _field_deltas(prior_case, current_case)
    effective_paths = _effective_paths(delta, fields)
    traversed = _trace_edges(graph, delta.change_event, effective_paths)
    current_objects, _current_certificates = case_view(current_case)
    effective_event = replace(delta.change_event, changed_properties=effective_paths)
    classification = explain_change(
        effective_event, object_kinds=object_kinds_of(current_objects)
    ).action
    affected = _expected_affected(effective_event, classification, traversed)
    minimum = minimum_action((classification, *affected.values()))
    replacement_roots = _replacement_roots(replacements)
    prior_phase_root = _phase_root(prior_phase)
    current_phase_root = _phase_root(current_phase)
    identity = {
        "schema_version": CERTIFIED_DELTA_SCHEMA_VERSION,
        "delta_root": delta.delta_hash(),
        "changed_fields": fields,
        "traversed_edges": traversed,
        "replacement_roots": replacement_roots,
        "prior_phase_root": prior_phase_root,
        "current_phase_root": current_phase_root,
    }
    draft = CertifiedDeltaRecord(
        evidence_id=_stable_id("certified-delta", identity),
        delta=delta,
        changed_fields=fields,
        category_changes=_category_changes(fields),
        traversed_edges=traversed,
        completeness_changes=tuple(
            item.path for item in fields if "completeness" in item.path.lower()
        ),
        minimum_recomputation_action=minimum,
        minimum_recomputation_basis=(
            "CANONICAL_DIFF_PLUS_TYPED_REACHABLE_DEPENDENCY_CLOSURE"
        ),
        replacement_roots=replacement_roots,
        schema_version=CERTIFIED_DELTA_SCHEMA_VERSION,
        prior_phase_root=prior_phase_root,
        current_phase_root=current_phase_root,
    )
    failures = verify_certified_delta(
        draft,
        prior_case,
        current_case,
        graph,
        replacements=replacements,
        prior_phase=prior_phase,
        current_phase=current_phase,
    )
    if failures:
        raise DeltaVerificationError("; ".join(failures))
    verified = replace(draft, verification_status="INDEPENDENTLY_VERIFIED")
    # Canonical hashability is a release gate, not a best-effort diagnostic.
    verified.root_hash()
    return verified


def verify_certified_delta(
    record: CertifiedDeltaRecord,
    prior_case: Any,
    current_case: Any,
    graph: DependencyGraph,
    *,
    replacements: Optional[Mapping[str, Any]] = None,
    prior_phase: Any = None,
    current_phase: Any = None,
) -> List[str]:
    """Reconstruct the minimum change claim without trusting the wrapper."""
    violations: List[str] = []
    if record.schema_version != CERTIFIED_DELTA_SCHEMA_VERSION:
        return [
            f"delta: unsupported schema version {record.schema_version!r}; "
            f"expected {CERTIFIED_DELTA_SCHEMA_VERSION!r}"
        ]
    delta = record.delta
    if delta.prior_root != case_root(prior_case):
        violations.append("delta: prior case root does not match")
    if delta.current_root != case_root(current_case):
        violations.append("delta: current case root does not match")

    expected_fields = _field_deltas(prior_case, current_case)
    if tuple(item.to_canonical() for item in record.changed_fields) != tuple(
        item.to_canonical() for item in expected_fields
    ):
        violations.append("delta: changed fields do not match the canonical before/after diff")
    if record.category_changes != _category_changes(expected_fields):
        violations.append("delta: categorized family/signature/geometry/evidence/dependency/certificate diff is incorrect")
    expected_completeness = tuple(
        item.path for item in expected_fields if "completeness" in item.path.lower()
    )
    if record.completeness_changes != expected_completeness:
        violations.append("delta: completeness changes are incomplete or unsupported")

    effective_paths = _effective_paths(delta, expected_fields)
    expected_event = replace(delta.change_event, changed_properties=effective_paths)
    if delta.change_event.to_canonical() != expected_event.to_canonical():
        violations.append("delta: change event does not include the authoritative canonical diff")

    expected_traversed = _trace_edges(graph, expected_event, effective_paths)
    if tuple(edge.to_canonical() for edge in record.traversed_edges) != tuple(
        edge.to_canonical() for edge in expected_traversed
    ):
        violations.append("delta: typed edge traversal does not match the reachable dependency closure")

    current_objects, current_certificates_raw = case_view(current_case)
    _prior_objects, prior_certificates_raw = case_view(prior_case)
    classification = explain_change(
        expected_event, object_kinds=object_kinds_of(current_objects)
    ).action
    affected = _expected_affected(expected_event, classification, expected_traversed)
    expected_minimum = minimum_action((classification, *affected.values()))
    if delta.classification != expected_minimum:
        violations.append("delta: declared classification is not the minimum sufficient action")
    if record.minimum_recomputation_action != expected_minimum:
        violations.append("delta: wrapper minimum-recomputation claim is incorrect")
    if record.minimum_recomputation_basis != "CANONICAL_DIFF_PLUS_TYPED_REACHABLE_DEPENDENCY_CLOSURE":
        violations.append("delta: unknown minimum-recomputation proof basis")
    if tuple(delta.affected_paths) != _encoded_affected(affected):
        violations.append("delta: affected paths do not match typed propagation")

    current_certificates = _certificate_map(current_certificates_raw)
    prior_certificates = _certificate_map(prior_certificates_raw)
    affected_ids = set(affected)
    expected_invalidated = tuple(
        sorted(
            identifier
            for identifier, artifact in current_certificates.items()
            if _certificate_dependencies(identifier, artifact) & affected_ids
        )
    )
    if tuple(delta.invalidated) != expected_invalidated:
        violations.append("delta: invalidated certificate set is incorrect")
    expected_preserved = set(
        identifier for identifier in current_certificates if identifier not in expected_invalidated
    )
    expected_preserved.update(
        identifier for identifier in current_objects if identifier not in affected_ids
    )
    if tuple(delta.preserved) != tuple(sorted(expected_preserved)):
        violations.append("delta: preserved artifact set is incorrect")

    expected_replacement_roots = _replacement_roots(replacements)
    if record.replacement_roots != expected_replacement_roots:
        violations.append("delta: replacement roots do not match supplied recomputation artifacts")
    if set(delta.recomputed) != set(expected_replacement_roots):
        violations.append("delta: every claimed recomputed artifact must have an independently hashed replacement")

    surviving = {
        identifier: artifact
        for identifier, artifact in current_certificates.items()
        if identifier not in set(expected_invalidated)
    }
    surviving.update(dict(replacements or {}))
    if tuple(delta.prior_winners) != _winner_set(prior_certificates):
        violations.append("delta: prior winner set does not reconstruct from prior certificates")
    if tuple(delta.current_winners) != _winner_set(surviving):
        violations.append("delta: current winner set does not reconstruct from preserved and replacement certificates")
    if canonical_form(delta.prior_margin) != _margin(prior_certificates):
        violations.append("delta: prior margin does not reconstruct from prior certificates")
    if canonical_form(delta.current_margin) != _margin(surviving):
        violations.append("delta: current margin does not reconstruct from preserved and replacement certificates")
    if expected_minimum == Action.REOPEN and not delta.reopen_reason:
        violations.append("delta: reopening has no recorded reason")

    expected_prior_phase = _phase_root(prior_phase)
    expected_current_phase = _phase_root(current_phase)
    if record.prior_phase_root != expected_prior_phase:
        violations.append("delta: prior phase-evidence root does not match")
    if record.current_phase_root != expected_current_phase:
        violations.append("delta: current phase-evidence root does not match")

    identity = {
        "schema_version": record.schema_version,
        "delta_root": delta.delta_hash(),
        "changed_fields": expected_fields,
        "traversed_edges": expected_traversed,
        "replacement_roots": expected_replacement_roots,
        "prior_phase_root": expected_prior_phase,
        "current_phase_root": expected_current_phase,
    }
    if record.evidence_id != _stable_id("certified-delta", identity):
        violations.append("delta: evidence identity is not canonical")
    if record.verification_program != "crg-change.certified-delta.verify/v1":
        violations.append("delta: verification program is not registered")
    try:
        record.root_hash()
    except Exception as error:
        violations.append(f"delta: wrapper is not canonically hashable ({error})")
    return violations


def require_verified_delta(
    record: CertifiedDeltaRecord,
    prior_case: Any,
    current_case: Any,
    graph: DependencyGraph,
    *,
    replacements: Optional[Mapping[str, Any]] = None,
    prior_phase: Any = None,
    current_phase: Any = None,
) -> None:
    """Fail closed unless both the recorded status and recomputation accept."""
    if record.verification_status != "INDEPENDENTLY_VERIFIED":
        raise DeltaVerificationError(
            f"delta verification status is {record.verification_status!r}, not INDEPENDENTLY_VERIFIED"
        )
    failures = verify_certified_delta(
        record,
        prior_case,
        current_case,
        graph,
        replacements=replacements,
        prior_phase=prior_phase,
        current_phase=current_phase,
    )
    if failures:
        raise DeltaVerificationError("; ".join(failures))
