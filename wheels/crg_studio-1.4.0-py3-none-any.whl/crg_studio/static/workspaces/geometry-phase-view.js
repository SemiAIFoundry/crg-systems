/**
 * Geometry and Phase View (spec 41.1): R, Gamma, K, envelopes, ledgers,
 * boundaries, and ties.
 *
 * The one workspace whose subject matter is irreducibly mathematical, and
 * therefore the one where 41.2's last principle bites hardest: ordinary
 * operation must not require the user to manipulate the notation.  Every
 * symbol here is rendered by `term()`, which puts the plain-language name
 * first and marks the symbol decorative, so a screen reader says
 * "joint-obligation upper region" rather than "gamma", and a reader who
 * knows the notation still sees it.
 *
 * The frontier is drawn as an SVG scatter *and* published as a table.  A
 * picture of a Pareto frontier is the fastest way to understand one and the
 * slowest way to audit one; both are offered, and the table is the
 * authoritative rendering.
 */

import {
  absent, definitionList, disclosure, emptyState, esc, evidenceBadge, hashChip, join, panel,
  quantity, signatureText, table, TERMS, term, verificationChip,
} from '../render.js';
import { action, field, notYet, shell } from '../workspace.js';

const meta = {
  id: 'geometry-phase-view',
  title: 'Geometry and Phase View',
  purpose: 'Exact realization-signature set, joint-obligation upper region, convex '
    + 'additive-price geometry, envelopes, ledgers, boundaries, and ties.',
  endpoints: [
    'buildGeometry', 'previewPhaseAnalysis', 'analyzePhase', 'verifyPhaseAnalysis',
    'getCase', 'getJobResult',
  ],
};

function pointValues(point) {
  if (Array.isArray(point)) return point;
  if (point && Array.isArray(point.values)) return point.values;
  return [];
}

function numeric(value) {
  if (value === null || value === undefined) return null;
  if (typeof value === 'number') return value;
  if (typeof value === 'object') {
    if (value.numerator !== undefined && value.denominator !== undefined) {
      const denominator = Number(value.denominator);
      return denominator ? Number(value.numerator) / denominator : null;
    }
    if (value.value !== undefined) return Number(value.value);
    return null;
  }
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

/**
 * A two-coordinate scatter of the frontier.
 *
 * Decorative by declaration: `role="img"` with a `<title>` and a `<desc>`
 * that state in words what the picture shows, and the authoritative table
 * follows immediately.  A point whose coordinates are not both supported is
 * omitted from the plot and listed underneath — plotting it at the origin
 * would be exactly the zero-for-absent error 41.2 forbids, committed in
 * pixels instead of digits.
 */
function frontierPlot(points, coordinates) {
  const usable = [];
  const unplottable = [];
  points.forEach((point, index) => {
    const values = pointValues(point);
    const x = numeric(values[0]);
    const y = numeric(values[1]);
    if (x === null || y === null) unplottable.push(index);
    else usable.push({ x, y, index });
  });
  if (!usable.length) {
    return emptyState('No frontier point has two supported coordinates, so nothing can be '
      + 'plotted. The table below lists every point regardless.');
  }
  const xs = usable.map((p) => p.x);
  const ys = usable.map((p) => p.y);
  const xMin = Math.min(...xs); const xMax = Math.max(...xs);
  const yMin = Math.min(...ys); const yMax = Math.max(...ys);
  const spanX = xMax - xMin || 1;
  const spanY = yMax - yMin || 1;
  const marks = usable.map((p) => {
    const cx = 40 + ((p.x - xMin) / spanX) * 280;
    const cy = 200 - ((p.y - yMin) / spanY) * 160;
    return `<circle class="crg-plot__point" cx="${cx.toFixed(1)}" cy="${cy.toFixed(1)}" r="5">`
      + `<title>Point ${p.index + 1}</title></circle>`;
  }).join('');
  const xName = (coordinates[0] || {}).identifier || 'first coordinate';
  const yName = (coordinates[1] || {}).identifier || 'second coordinate';
  const description = `Two-coordinate projection of ${usable.length} frontier points, `
    + `${esc(xName)} on the `
    + `horizontal axis and ${esc(yName)} on the vertical axis. The authoritative values are `
    + `in the full-coordinate table that follows.`;
  return `<figure class="crg-figure">`
    + `<svg class="crg-plot" viewBox="0 0 360 230" role="img" `
    + `aria-labelledby="plot-title plot-desc">`
    + `<title id="plot-title">Two-coordinate projection of the joint-obligation frontier</title>`
    + `<desc id="plot-desc">${description}</desc>`
    + `<line class="crg-plot__axis" x1="40" y1="200" x2="330" y2="200"></line>`
    + `<line class="crg-plot__axis" x1="40" y1="200" x2="40" y2="30"></line>`
    + `<text class="crg-plot__label" x="185" y="222" text-anchor="middle">${esc(xName)}</text>`
    + `<text class="crg-plot__label" x="12" y="115" text-anchor="middle" `
    + `transform="rotate(-90 12 115)">${esc(yName)}</text>`
    + marks
    + `</svg>`
    + `<figcaption class="crg-figure__caption">${description}`
    + `${unplottable.length ? ` ${unplottable.length} point(s) could not be plotted because a `
      + `coordinate has no supported value; they are marked in the table.` : ''}`
    + `</figcaption></figure>`;
}

/**
 * State the dimensional projection explicitly.  The scatter can show only
 * two axes; the table remains authoritative and must retain every declared
 * coordinate, including the fifth and later coordinates.
 */
function projectionDisclosure(coordinates) {
  const count = coordinates.length;
  if (!count) {
    return `<p class="crg-prose" data-geometry-projection="none" data-coordinate-count="0">`
      + `No coordinate schema is available. The interface cannot construct a geometric `
      + `projection or label a coordinate table without it.</p>`;
  }
  const projected = coordinates.slice(0, 2)
    .map((coordinate) => coordinate.identifier || 'unnamed coordinate');
  const projection = projected.length === 2
    ? `The scatter is a two-coordinate projection using ${esc(projected[0])} and `
      + `${esc(projected[1])}. `
    : `A two-coordinate scatter is unavailable because only ${count} coordinate is declared. `;
  return `<p class="crg-prose" data-geometry-projection="${projected.length}" `
    + `data-coordinate-count="${count}">${projection}`
    + `The authoritative table immediately below lists all ${count} declared `
    + `coordinate${count === 1 ? '' : 's'}; no later coordinate is omitted.</p>`;
}

function frontierTable(caption, points, coordinates) {
  if (!points.length) return emptyState(`No ${caption.toLowerCase()} is recorded yet.`);
  return table(caption, [
    { label: 'Point' },
    ...coordinates.map((c) => ({ label: c.identifier || 'coordinate', hint: c.unit || '' })),
    { label: 'Recorded geometric status',
      hint: 'Status within this geometry; this is not a phase classification.' },
  ], points.map((point, index) => {
    const values = pointValues(point);
    return {
      cells: [
        `<span>${esc(String(index + 1))}</span>`,
        ...coordinates.map((coordinate, position) => quantity(values[position], {
          unit: coordinate.unit || '',
        })),
        point.boundary === false ? 'Recorded interior'
          : point.boundary === true ? 'Recorded boundary' : 'Frontier point',
      ],
    };
  }));
}

function tiesPanel(geometry) {
  const ties = geometry.ties || [];
  if (!ties.length) {
    return panel('Ties on the frontier', emptyState(
      'No tied points are recorded. When two realizations sit at the same point on the '
      + 'frontier, both are kept: 22.4 makes a tie a result, not a rounding artefact.',
    ), { principle: 'tie-vs-ambiguity' });
  }
  return panel('Ties on the frontier', table('Points shared by more than one realization', [
    { label: 'Point' },
    { label: 'Realizations at this point' },
  ], ties.map((tie) => ({
    cells: [
      signatureText(tie.signature || tie.point),
      `<ul class="crg-realization-list" aria-label="Realizations at this point">`
      + (tie.realizations || []).map((r) => `<li class="crg-realization">`
        + `<span class="crg-realization__name">${esc(r)}</span></li>`).join('')
      + `</ul>`,
    ],
  }))), { principle: 'tie-vs-ambiguity' });
}

function envelopePanel(geometry) {
  const envelope = geometry.envelope || geometry.approximation || null;
  if (!envelope) {
    return panel('Approximation envelope', emptyState(
      'This geometry is exact: no approximation envelope is in force. When one is, 20.1 '
      + 'requires the direction and size of the error to be stated, not merely its existence.',
    ));
  }
  return panel('Approximation envelope', definitionList([
    ['Kind', envelope.kind ? esc(envelope.kind) : absent()],
    ['Direction of error', envelope.direction
      ? esc(envelope.direction) : absent('UNSUPPORTED')],
    ['Size of error', envelope.error === undefined ? absent('UNSUPPORTED')
      : quantity(envelope.error, { unit: envelope.unit || '' })],
    ['Evidence class', evidenceBadge(envelope.evidence_class || 'BOUNDED')],
    ['What it permits', `<p class="crg-prose">An inner bound may prove achievability; an `
      + `outer bound may prove impossibility. Neither may be silently swapped for the `
      + `other (20.2).</p>`],
  ]), { principle: 'evidence-classes' });
}

function ledgerPanel(geometry) {
  const ledger = geometry.ledger || [];
  if (!ledger.length) {
    return panel('Construction ledger', emptyState(
      'No construction steps are recorded for this geometry.',
    ));
  }
  return table('How this geometry was built, step by step', [
    { label: 'Step' },
    { label: 'Operation' },
    { label: 'Input' },
    { label: 'Evidence class' },
  ], ledger.map((entry, index) => ({
    cells: [
      `<span>${esc(String(index + 1))}</span>`,
      entry.operation ? `<code class="crg-code">${esc(entry.operation)}</code>` : absent(),
      entry.input ? hashChip(entry.input) : absent(),
      evidenceBadge(entry.evidence_class || 'EXACT'),
    ],
  })));
}

function glossary() {
  return panel('What these three things are', definitionList([
    [TERMS.R(), '<span class="crg-prose">The exact signatures attained by the legal '
      + 'realization family. Distinct realizations that share a signature remain recoverable '
      + 'through its fibers.</span>'],
    [TERMS.GAMMA(), '<span class="crg-prose">The closed coordinatewise upper region generated '
      + 'by R. Its canonical finite record stores the Pareto-minimal antichain; the region is '
      + 'not silently convexified.</span>'],
    [TERMS.K(), '<span class="crg-prose">The closed convex upper body generated from R. It '
      + 'preserves support values for nonnegative additive prices; it is not a generic '
      + 'feasibility region.</span>'],
    [term('Certified phase boundary', 'boundary'), '<span class="crg-prose">A change boundary '
      + 'may be called a phase boundary only when a phase-analysis artifact establishes it. '
      + 'Active bottlenecks recorded by a decision certificate do not establish one by '
      + 'themselves.</span>'],
  ]), { principle: 'plain-language' });
}

function latestPhase(state) {
  const outputs = ((((state.lastAction || {}).result || {}).outputs) || {});
  if (outputs.artifact && outputs.artifact.record_type === 'PhaseAnalysisRecord') {
    return outputs.artifact;
  }
  const records = (((state.data || {}).case || {}).phase_analyses || {});
  const values = Object.values(records).filter((record) => record
    && record.record_type === 'PhaseAnalysisRecord');
  values.sort((left, right) => String(left.analysis_id || '').localeCompare(
    String(right.analysis_id || ''),
  ));
  return values.length ? values[values.length - 1] : null;
}

function phaseVerification(state) {
  const outputs = ((((state.lastAction || {}).result || {}).outputs) || {});
  return outputs.verification || null;
}

function phaseForm(state) {
  const form = state.form || {};
  return panel('Analyze where the optimal policy changes', join([
    `<p class="crg-prose">The registered profile computes exact lower-envelope regions from `
      + `the case’s canonical R. Preview is non-mutating; Analyze independently verifies and `
      + `persists the same evidence. Studio never infers a phase boundary from a bottleneck.</p>`,
    field('phase-profile', 'Registered profile', {
      value: form['phase-profile'] || 'TWO_COORDINATE_PRICE_SIMPLEX_V1',
      hint: 'Only registered phase semantics may produce a certified boundary.',
      required: true,
    }),
    field('phase-tolerance', 'Policy-tie tolerance', {
      value: form['phase-tolerance'] || '0',
      hint: 'Exact rational. A nonzero value creates a declared policy-tie region, not an exact equality claim.',
    }),
    field('phase-stability', 'Optional operating parameter θ', {
      value: form['phase-stability'] || '',
      hint: 'Exact rational from 0 to 1. When supplied, the result includes the exact distance to the nearest true boundary.',
    }),
    `<div class="crg-actions">${action('preview-phase', 'Preview phase analysis', {
      operation: 'previewPhaseAnalysis',
      fields: ['phase-profile', 'phase-tolerance', 'phase-stability'],
    })}${action('analyze-phase', 'Verify and save phase analysis', {
      operation: 'analyzePhase', tone: 'primary',
      fields: ['phase-profile', 'phase-tolerance', 'phase-stability'],
    })}</div>`,
  ]), { principle: 'why' });
}

function intervalText(interval) {
  if (!interval) return absent();
  const left = interval.lower_closed ? '[' : '(';
  const right = interval.upper_closed ? ']' : ')';
  return `<code class="crg-code">${left}${esc((interval.lower || {}).exact || '')}, `
    + `${esc((interval.upper || {}).exact || '')}${right}</code>`;
}

function phasePanel(artifact, verification) {
  if (!artifact) {
    return panel('Certified phase evidence', emptyState(
      'No PhaseAnalysisRecord is stored or previewed. Active coordinates and bottlenecks do not fill this gap.',
    ));
  }
  const profile = artifact.profile || {};
  const regions = artifact.regions || [];
  const boundaries = artifact.boundaries || [];
  const ties = artifact.ties || [];
  const stability = artifact.stability || null;
  return panel('Certified phase evidence', join([
    definitionList([
      ['Analysis identity', hashChip(artifact.analysis_id)],
      ['Source exact realization-signature set', hashChip(artifact.source_r_root)],
      ['Registered profile', `<code class="crg-code">${esc(profile.profile_id || '')}</code>`],
      ['Claim scope', `<strong>${esc(artifact.claim_scope || '')}</strong>`],
      ['Independent reconstruction', verification
        ? verificationChip(verification.status || (verification.ok ? 'VERIFIED' : 'FAILED'))
        : verificationChip('VERIFIED_RELATIVE')],
    ]),
    table('Exact constant-winner regions', [
      { label: 'Parameter interval' }, { label: 'Certified optimal policy set' },
      { label: 'Claim' },
    ], regions.map((region) => ({ cells: [
      intervalText(region.parameter_interval),
      `<code class="crg-code">${esc((region.winner_ids || []).join(', '))}</code>`,
      esc(region.claim || ''),
    ] }))),
    boundaries.length ? table('True phase boundaries', [
      { label: 'θ' }, { label: 'Left' }, { label: 'At boundary' }, { label: 'Right' },
      { label: 'Basis' },
    ], boundaries.map((boundary) => ({
      attributes: ' data-certified-phase-boundary="true"',
      cells: [
        quantity(boundary.parameter),
        esc((boundary.left_winner_ids || []).join(', ') || 'domain edge'),
        esc((boundary.boundary_winner_ids || []).join(', ')),
        esc((boundary.right_winner_ids || []).join(', ') || 'domain edge'),
        esc(boundary.basis || ''),
      ],
    }))) : emptyState('No optimal-policy-set change occurs within the registered parameter domain.'),
    ties.length ? table('Certified ties', [
      { label: 'Interval' }, { label: 'Policies' }, { label: 'Outcome' }, { label: 'Claim' },
    ], ties.map((tie) => ({ cells: [
      intervalText(tie.parameter_interval), esc((tie.policy_ids || []).join(', ')),
      esc(tie.decision_outcome || ''), esc(tie.claim || ''),
    ] }))) : '',
    stability ? panel('Local stability at the requested operating parameter', definitionList([
      ['Parameter θ', quantity(stability.parameter)],
      ['Standing', `<strong>${esc(stability.state || '')}</strong>`],
      ['Winner set', esc((stability.winner_ids || []).join(', '))],
      ['Certified stability interval', intervalText(stability.stability_interval)],
      ['Exact distance to nearest true boundary', stability.boundary_distance === null
        ? absent('NOT_APPLICABLE') : quantity(stability.boundary_distance)],
    ]), { principle: 'margins' }) : '',
    disclosure('Complete canonical PhaseAnalysisRecord', `<pre class="crg-pre" tabindex="0" `
      + `role="group" aria-label="Canonical phase-analysis record">`
      + `${esc(JSON.stringify(artifact, null, 2))}</pre>`, { principle: 'why' }),
  ]), { principle: 'why' });
}

export const workspace = {
  ...meta,
  render(state = {}) {
    const geometry = ((state.data || {}).case || {}).geometry
      || (state.data || {}).geometry || null;
    const registry = ((state.data || {}).case || {}).registry
      || (state.data || {}).registry || {};
    const coordinates = ((registry.schema || {}).coordinates || []);
    if (!geometry) {
      return shell(meta, join([
        glossary(),
        phaseForm(state),
        phasePanel(latestPhase(state), phaseVerification(state)),
        notYet(
          'No geometry has been built for this case yet.',
          `<div class="crg-actions">${action('build-geometry', 'Build the geometry', {
            operation: 'buildGeometry',
          })}</div>`,
        ),
      ]), state);
    }
    const full = geometry.full_frontier || geometry.frontier || [];
    const retained = geometry.retained_frontier || [];
    return shell(meta, join([
      glossary(),
      phaseForm(state),
      phasePanel(latestPhase(state), phaseVerification(state)),
      panel('Canonical geometry roots', join([
        `<p class="crg-prose">These roots identify the canonical R, Γ, and K records. `
          + `They are distinct from complete or retained realization-registry hashes.</p>`,
        definitionList([
          [TERMS.R(), hashChip((geometry.R || {}).root_hash)],
          [TERMS.GAMMA(), hashChip((geometry.GAMMA || {}).root_hash)],
          [TERMS.K(), hashChip((geometry.K || {}).root_hash)],
        ]),
      ])),
      panel('Pareto-minimal frontier of the joint-obligation upper region', join([
        projectionDisclosure(coordinates),
        frontierPlot(full, coordinates),
        frontierTable('Full-coordinate frontier of the whole family', full, coordinates),
      ])),
      retained.length
        ? panel('Frontier after retention', join([
          `<p class="crg-prose">Retention is only permissible when it leaves the `
          + `decision-relevant part of this frontier intact. Compare the two tables: any point `
          + `present above and absent here is a trade-off the case can no longer offer.</p>`,
          frontierTable('Full-coordinate frontier of the retained set', retained, coordinates),
        ]))
        : '',
      tiesPanel(geometry),
      envelopePanel(geometry),
      ledgerPanel(geometry),
      `<div class="crg-actions">${action('build-geometry', 'Rebuild the geometry', {
        operation: 'buildGeometry',
      })}</div>`,
    ]), state);
  },
};

export default workspace;
