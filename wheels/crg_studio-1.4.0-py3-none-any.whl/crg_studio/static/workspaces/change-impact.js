/**
 * Change Impact (spec 41.1): before-and-after differences, typed edges,
 * preserved claims, and required action.
 *
 * The useful question after a change is not "what broke" but "what survived
 * and why", so the preserved list is rendered first and with reasons.  30
 * makes recomputation proportional to the affected dependency subgraph;
 * showing which certificates were untouched, and which typed edge carried
 * the change to the ones that were, is what makes that claim inspectable
 * rather than merely fast.
 */

import {
  absent, definitionList, disclosure, emptyState, esc, hashChip, join, outcomeInfo, panel,
  quantity, table, verificationChip,
} from '../render.js';
import { action, field, notYet, select, shell } from '../workspace.js';
import {
  CUMULATIVE_COMPARISON_ROLES, LIFECYCLE_GUIDED_CONTRACTS,
  cumulativeRoleField, lifecycleFieldName,
} from '../guided-authoring.js';

const meta = {
  id: 'change-impact',
  title: 'Change Impact',
  purpose: 'Before-and-after differences, typed edges, preserved claims, and required action.',
  endpoints: [
    'previewChange', 'classifyChange', 'verifyCertifiedDelta', 'recomputeCase',
    'getCase', 'getDependencies', 'getJobResult', 'publishLifecycleRecord',
    'getLifecycleRecord', 'verifyLifecycleRecord',
    'previewDecisionChallenge', 'recordDecisionChallenge',
    'getDecisionChallenge', 'verifyDecisionChallenge',
    'previewComparativeChange', 'generateComparativeChange',
    'getComparativeChange', 'verifyComparativeChange',
    'previewCumulativeLifecycleComparison', 'generateCumulativeLifecycleComparison',
    'getCumulativeLifecycleComparison', 'verifyCumulativeLifecycleComparison',
  ],
};

const CHALLENGE_MUTATIONS = [
  'OBJECTIVE', 'PRICE', 'TECHNOLOGY_COORDINATE', 'EVIDENCE_VALUE',
  'EVIDENCE_VALIDITY', 'CAPABILITY', 'LEGALITY', 'POLICY_TOLERANCE',
  'RETENTION_POLICY', 'PHYSICAL_CONSTRAINT',
];

const CHALLENGE_PREVIEWS = [
  'BRANCH_PREVIEW', 'PHASE_PREVIEW', 'CHANGE_PREVIEW', 'COMMITMENT_PREVIEW',
  'VERIFIER_REPLAY', 'PHASE_AND_CHANGE_PREVIEW',
];

const CHALLENGE_FIELDS = [
  'challenge-id', 'challenge-evidence-id', 'challenge-operation-id',
  'challenge-mutation-type', 'challenge-preview-operation', 'challenge-target-path',
  'challenge-objective-key', 'challenge-objective-value',
  'challenge-price-value', 'challenge-price-unit',
  'challenge-technology-coordinate-id', 'challenge-technology-value',
  'challenge-technology-unit', 'challenge-evidence-value-evidence-id',
  'challenge-evidence-value-value', 'challenge-evidence-value-class',
  'challenge-evidence-validity-evidence-id', 'challenge-evidence-validity-status',
  'challenge-capability-id', 'challenge-capability-value',
  'challenge-legality-realization-id', 'challenge-legality-status',
  'challenge-tolerance-value', 'challenge-retention-policy-id',
  'challenge-retention-policy-value', 'challenge-constraint-id',
  'challenge-constraint-value', 'challenge-constraint-unit',
  'challenge-promotion-request-id', 'challenge-promotion-operation',
  'challenge-promotion-requested-by', 'challenge-promotion-reason',
];

function challengeInputGroup(type, body, active = 'PRICE') {
  return `<fieldset class="crg-fieldset" data-challenge-input="${esc(type)}"`
    + `${type === active ? '' : ' hidden'}><legend class="crg-field__label">`
    + `${esc(type.replaceAll('_', ' '))} input</legend>${body}</fieldset>`;
}

function challengeRecordFromState(state) {
  const last = state.lastAction || {};
  if (![
    'previewDecisionChallenge', 'recordDecisionChallenge',
    'getDecisionChallenge', 'verifyDecisionChallenge',
  ].includes(last.operation)) return null;
  const response = last.result || {};
  const result = response.outputs || response;
  if (!result.challenge || result.challenge.record_type !== 'DecisionChallengeRecord') return null;
  return { record: result.challenge, verification: result.verification || {} };
}

function idList(values, empty = 'none') {
  return (values || []).length
    ? values.map((value) => `<code class="crg-code">${esc(String(value))}</code>`).join(' ')
    : absent(empty.toUpperCase().replaceAll(' ', '_'));
}

function decisionChallengeResult(state) {
  const entry = challengeRecordFromState(state);
  if (!entry) return emptyState(
    'No Decision Challenge is displayed. Preview, record, or inspect one to replay it here.',
  );
  const record = entry.record;
  const verification = entry.verification;
  const result = record.result || {};
  const noMutation = record.no_mutation_guarantee || {};
  const refusal = record.refusal;
  const promotion = record.promotion_request;
  const phase = result.phase || {};
  const change = result.change || {};
  const minimum = result.proposed_minimum_action || {};
  const regret = result.regret || {};
  const completeness = result.family_completeness || {};
  const reconstructedVerification = result.verification_status || {};
  const replacementRoots = change.replacement_roots || {};
  const common = definitionList([
    ['Challenge identity', `<code class="crg-code" data-decision-challenge-id>`
      + `${esc(record.challenge_id || '')}</code>`],
    ['Record hash', hashChip(record.record_hash)],
    ['Independent replay', verificationChip(verification.status || 'FAILED')],
    ['Authority', `<code class="crg-code" data-decision-challenge-authority>`
      + `${esc(record.authority || 'NON_AUTHORIZING')}</code>`],
    ['Authorizing', `<code class="crg-code">${esc(String(record.authorizing))}</code>`],
    ['Semantic effect', `<code class="crg-code" data-decision-challenge-effect>`
      + `${esc(record.semantic_effect || 'NONE')}</code>`],
    ['Frozen baseline root', hashChip((record.baseline || {}).case_root)],
    ['Active case mutated', `<code class="crg-code" data-decision-challenge-mutated>`
      + `${esc(String(noMutation.active_case_mutated))}</code>`],
    ['Active case superseded', `<code class="crg-code">`
      + `${esc(String(noMutation.active_case_superseded))}</code>`],
    ['Promotion executed', `<code class="crg-code">`
      + `${esc(String(noMutation.promotion_executed))}</code>`],
    ['Mutation performed', `<code class="crg-code">`
      + `${esc(String(noMutation.mutation_performed))}</code>`],
  ]);
  const outcome = refusal ? panel('Typed refusal — no preview was inferred', join([
    definitionList([
      ['Status', `<code class="crg-code">${esc(refusal.status || '')}</code>`],
      ['Reason', `<code class="crg-code">${esc(refusal.reason_code || '')}</code>`],
      ['Detail', `<span class="crg-prose">${esc(refusal.detail || '')}</span>`],
      ['Disposition', `<code class="crg-code">${esc(refusal.disposition || '')}</code>`],
      ['Winner identities', absent('NOT_INFERRED')],
    ]),
  ]), { tone: 'warn', principle: 'why' }) : panel(
    'Independently reconstructed preview — identities are not ranked',
    join([
      definitionList([
        ['Winner identity set (not ranked)', idList(result.winner_ids, 'none stated')],
        ['Phase state', `<code class="crg-code">${esc(phase.state || '')}</code>`],
        ['Nearest phase boundaries', idList(phase.nearest_boundary_ids, 'not applicable')],
        ['Phase evidence replay', `<code class="crg-code">`
          + `${esc(reconstructedVerification.phase || '')}</code>`],
        ['Certified change replay', `<code class="crg-code">`
          + `${esc(reconstructedVerification.delta || '')}</code>`],
        ['Preserved claims', idList(change.preserved_ids, 'none')],
        ['Invalidated claims', idList(change.invalidated_ids, 'none')],
        ['Replacement roots', Object.keys(replacementRoots).length
          ? Object.entries(replacementRoots).sort(([left], [right]) => left.localeCompare(right))
            .map(([identifier, root]) => `${esc(identifier)} ${hashChip(root)}`).join('<br>')
          : absent('NOT_APPLICABLE')],
        ['Proposed minimum action', `<strong data-decision-challenge-minimum>`
          + `${esc(minimum.action || '')}</strong>`],
        ['Why this is minimum', `<span class="crg-prose">${esc(minimum.basis || '')}</span>`],
        ['Regret status', `<code class="crg-code">${esc(regret.status || '')}</code>`],
        ['Regret witnesses', regret.witnesses && regret.witnesses.length
          ? `<code class="crg-code">${esc(JSON.stringify(regret.witnesses))}</code>`
          : absent('NOT_PRESENT_IN_PROFILE')],
        ['Claim scope', `<code class="crg-code">${esc(JSON.stringify(result.claim_scope))}</code>`],
        ['Completeness basis', `<code class="crg-code">`
          + `${esc(String(completeness.basis_type || ''))}</code>`],
        ['Declared universe', esc(String(completeness.declared_universe || ''))],
      ]),
      `<p class="crg-prose"><strong>No score or ranking exists:</strong> this surface lists `
        + `canonical identities and direct verifier states only.</p>`,
    ]), { principle: 'why' },
  );
  const promotionPanel = promotion ? panel(
    'Separate governed promotion proposal — not executed',
    definitionList([
      ['Request', `<code class="crg-code">${esc(promotion.request_id || '')}</code>`],
      ['Governed operation', `<code class="crg-code">`
        + `${esc(promotion.governed_operation || '')}</code>`],
      ['Status', `<code class="crg-code" data-decision-challenge-promotion-status>`
        + `${esc(promotion.status || '')}</code>`],
      ['Execution', `<code class="crg-code">${esc(promotion.execution_status || '')}</code>`],
      ['Authority', `<code class="crg-code">${esc(promotion.authority || '')}</code>`],
    ]), { tone: 'warn', principle: 'why' },
  ) : '';
  return join([
    panel('Decision Challenge replay', common, {
      tone: verification.ok ? 'neutral' : 'warn', principle: 'why',
    }),
    outcome,
    promotionPanel,
    disclosure('Canonical portable record (display only)', `<pre class="crg-pre" tabindex="0" `
      + `role="group" aria-label="Canonical Decision Challenge record">`
      + `${esc(JSON.stringify(record, null, 2))}</pre>`, { principle: 'why' }),
  ]);
}

function decisionChallengePanel(state) {
  const form = state.form || {};
  const caseRecord = (state.data || {}).case || {};
  const deltas = caseRecord.certified_deltas || {};
  const evidenceIds = Object.keys(deltas).sort();
  const targetPaths = Array.from(new Set(evidenceIds.flatMap((evidenceId) => (
    (deltas[evidenceId].changed_fields || []).map((item) => item.path).filter(Boolean)
  )))).sort();
  const active = form['challenge-mutation-type'] || 'PRICE';
  const evidenceChoices = evidenceIds.length
    ? evidenceIds.map((value) => [value, value]) : [['', 'No stored certified delta']];
  const targetChoices = targetPaths.length
    ? targetPaths.map((value) => [value, value]) : [['', 'No certified field path']];
  return panel('Decision Challenge — frozen, non-authorizing, and non-mutating', join([
    `<p class="crg-prose">Challenge one registered input against stored certified phase/change `
      + `evidence. The system derives protocol profiles and every displayed outcome, then `
      + `independently replays the portable record. Recording writes only the auxiliary `
      + `challenge ledger: the active case head and version remain unchanged.</p>`,
    decisionChallengeResult(state),
    field('challenge-id', 'Challenge identity', {
      value: form['challenge-id'] || 'challenge-1', required: true,
    }),
    select('challenge-evidence-id', 'Stored certified change evidence', evidenceChoices, {
      value: form['challenge-evidence-id'] || evidenceIds[0] || '',
      hint: 'The server reconstructs phase and delta verifier inputs from this stored evidence.',
    }),
    field('challenge-operation-id', 'Input operation identity', {
      value: form['challenge-operation-id'] || 'challenge-input-1', required: true,
    }),
    select('challenge-mutation-type', 'Registered input type',
      CHALLENGE_MUTATIONS.map((value) => [value, value.replaceAll('_', ' ')]), {
        value: active,
        hint: 'Only the fields for this closed registered input type are sent.',
      }),
    select('challenge-preview-operation', 'Registered preview operation',
      CHALLENGE_PREVIEWS.map((value) => [value, value.replaceAll('_', ' ')]), {
        value: form['challenge-preview-operation'] || 'PHASE_AND_CHANGE_PREVIEW',
      }),
    select('challenge-target-path', 'Certified field path', targetChoices, {
      value: form['challenge-target-path'] || targetPaths[0] || '',
      hint: 'The input must exactly cover this canonical before/after field difference.',
    }),
    challengeInputGroup('OBJECTIVE', join([
      field('challenge-objective-key', 'Objective field', {
        value: form['challenge-objective-key'] || 'type',
      }),
      field('challenge-objective-value', 'Objective field value', {
        value: form['challenge-objective-value'] || 'weighted_sum',
      }),
    ]), active),
    challengeInputGroup('PRICE', join([
      field('challenge-price-value', 'Exact price value', {
        value: form['challenge-price-value'] || '',
        hint: 'Use an integer or reduced rational string such as 3/4; never a decimal float.',
      }),
      field('challenge-price-unit', 'Price unit', { value: form['challenge-price-unit'] || '' }),
    ]), active),
    challengeInputGroup('TECHNOLOGY_COORDINATE', join([
      field('challenge-technology-coordinate-id', 'Coordinate identity', {
        value: form['challenge-technology-coordinate-id'] || '',
      }),
      field('challenge-technology-value', 'Exact coordinate value', {
        value: form['challenge-technology-value'] || '',
      }),
      field('challenge-technology-unit', 'Coordinate unit', {
        value: form['challenge-technology-unit'] || '',
      }),
    ]), active),
    challengeInputGroup('EVIDENCE_VALUE', join([
      field('challenge-evidence-value-evidence-id', 'Evidence identity', {
        value: form['challenge-evidence-value-evidence-id'] || '',
      }),
      field('challenge-evidence-value-value', 'Evidence value', {
        value: form['challenge-evidence-value-value'] || '',
      }),
      field('challenge-evidence-value-class', 'Evidence class', {
        value: form['challenge-evidence-value-class'] || '',
      }),
    ]), active),
    challengeInputGroup('EVIDENCE_VALIDITY', join([
      field('challenge-evidence-validity-evidence-id', 'Evidence identity', {
        value: form['challenge-evidence-validity-evidence-id'] || '',
      }),
      select('challenge-evidence-validity-status', 'Validity', [
        ['VALID', 'Valid'], ['INVALID', 'Invalid'], ['EXPIRED', 'Expired'], ['REVOKED', 'Revoked'],
      ], { value: form['challenge-evidence-validity-status'] || 'VALID' }),
    ]), active),
    challengeInputGroup('CAPABILITY', join([
      field('challenge-capability-id', 'Capability identity', {
        value: form['challenge-capability-id'] || '',
      }),
      field('challenge-capability-value', 'Capability value', {
        value: form['challenge-capability-value'] || '',
      }),
    ]), active),
    challengeInputGroup('LEGALITY', join([
      field('challenge-legality-realization-id', 'Realization identity', {
        value: form['challenge-legality-realization-id'] || '',
      }),
      select('challenge-legality-status', 'Legality', [
        ['LEGAL', 'Legal'], ['ILLEGAL', 'Illegal'],
      ], { value: form['challenge-legality-status'] || 'LEGAL' }),
    ]), active),
    challengeInputGroup('POLICY_TOLERANCE', field(
      'challenge-tolerance-value', 'Exact policy tolerance', {
        value: form['challenge-tolerance-value'] || '0',
      },
    ), active),
    challengeInputGroup('RETENTION_POLICY', join([
      field('challenge-retention-policy-id', 'Retention policy identity', {
        value: form['challenge-retention-policy-id'] || '',
      }),
      field('challenge-retention-policy-value', 'Retention policy value', {
        value: form['challenge-retention-policy-value'] || '',
      }),
    ]), active),
    challengeInputGroup('PHYSICAL_CONSTRAINT', join([
      field('challenge-constraint-id', 'Constraint identity', {
        value: form['challenge-constraint-id'] || '',
      }),
      field('challenge-constraint-value', 'Exact constraint value', {
        value: form['challenge-constraint-value'] || '',
      }),
      field('challenge-constraint-unit', 'Constraint unit', {
        value: form['challenge-constraint-unit'] || '',
      }),
    ]), active),
    disclosure('Optional separate governed promotion proposal', join([
      `<p class="crg-prose"><strong>PROPOSED / NOT_EXECUTED.</strong> Filling these fields `
        + `only records a request for a later ordinary governed action. This panel cannot `
        + `apply, promote, authorize, or supersede anything.</p>`,
      field('challenge-promotion-request-id', 'Promotion request identity', {
        value: form['challenge-promotion-request-id'] || '',
      }),
      select('challenge-promotion-operation', 'Governed operation', [
        ['', 'No promotion proposal'],
        ['APPLY_CERTIFIED_CHANGE', 'Apply certified change'],
        ['CREATE_GOVERNED_BRANCH', 'Create governed branch'],
        ['SUBMIT_CHANGE_FOR_APPROVAL', 'Submit change for approval'],
      ], { value: form['challenge-promotion-operation'] || '' }),
      field('challenge-promotion-requested-by', 'Requested by', {
        value: form['challenge-promotion-requested-by'] || '',
      }),
      field('challenge-promotion-reason', 'Promotion proposal reason', {
        value: form['challenge-promotion-reason'] || '',
      }),
    ]), { principle: 'why' }),
    `<div class="crg-actions">${action(
      'preview-decision-challenge', 'Preview non-mutating challenge', {
        operation: 'previewDecisionChallenge', fields: CHALLENGE_FIELDS,
      },
    )}${action('record-decision-challenge', 'Record in auxiliary challenge ledger', {
      operation: 'recordDecisionChallenge', fields: CHALLENGE_FIELDS,
    })}${action('inspect-decision-challenge', 'Inspect stored challenge', {
      operation: 'getDecisionChallenge', tone: 'secondary', fields: ['challenge-id'],
    })}${action('verify-decision-challenge', 'Verify displayed record', {
      operation: 'verifyDecisionChallenge', tone: 'secondary',
      disabled: !challengeRecordFromState(state),
    })}</div>`,
  ]), { principle: 'why' });
}

const ETQ_OPERATIONS = [
  'CREATE_ETQ_LOOP', 'APPEND_ETQ_STEP', 'INGEST_RESULT', 'PLAN_REVALIDATION',
  'ISSUE_REPLACEMENT', 'QUALIFICATION_DISPOSITION',
];

const DECISION_LIFECYCLE_OPERATIONS = [
  'BIND_CONVERSION', 'ASSESS_CONVERSION', 'RECORD_SIGNATURE_VERIFICATION',
  'ISSUE_APPROVAL', 'ISSUE_APPROVAL_WITHDRAWAL',
  'EVALUATE_LIFECYCLE_AUTHORIZATION', 'BUILD_CONTINUED_VALIDITY',
];

const RESILIENCE_LIFECYCLE_OPERATIONS = [
  'BUILD_LIFECYCLE_REPLAY', 'RECORD_BACKUP_RESTORE_RECOVERY',
  'RECORD_MIGRATION_REVERIFICATION',
];

const LIFECYCLE_GUIDED_FIELDS = [
  'lifecycle-operation',
  ...Object.entries(LIFECYCLE_GUIDED_CONTRACTS).flatMap(([operation, controls]) => (
    controls.map(([name]) => lifecycleFieldName(operation, name))
  )),
];

const LIFECYCLE_TEXT_DEFAULTS = {
  loop_id: 'etq-loop-1', target_decision_id: 'decision-1', predicate_id: 'predicate-1',
  authority: 'declared lifecycle evidence basis', verification_basis: 'independent reconstruction',
  ingestion_id: 'ingestion-1', plan_id: 'qualification-plan-1', evidence_id: 'evidence-1',
  record_id: 'revalidation-1', changed_source: 'evidence-1',
  dependency_completeness_basis: 'complete exported case dependency graph',
  revalidation_record_id: 'revalidation-1', replacement_id: 'replacement-1',
  prior_artifact_id: 'artifact-1', replacement_artifact_id: 'artifact-2',
  binding_id: 'conversion-binding-1',
  retained_geometry_relation: 'retained intersections map to the selected geometry',
  decision_scope_relation: 'converted layouts remain within the selected decision scope',
  verification_id: 'signature-verification-1', signature_id: 'signature-1',
  action: 'COMMIT', approval_id: 'approval-1', role: 'PROPOSER',
  withdrawal_id: 'withdrawal-1', reason: 'supporting evidence changed',
  view_id: 'continued-validity-1', artifact_id: 'artifact-1',
  replay_id: 'lifecycle-replay-1', recovery_id: 'backup-restore-recovery-1',
  reverification_id: 'migration-reverification-1',
};

const LIFECYCLE_LIST_DEFAULTS = {
  declared_stopping_conditions: 'CAPABILITY_ESTABLISHED',
  verification_basis: 'independent reconstruction',
  changed_properties: 'value', artifact_universe: 'evidence-1\ndecision-certificate',
  required_evidence_ids: 'evidence-1', approval_ids: 'approval-1',
};

function lifecycleCatalog(state) {
  const data = state.data || {};
  const caseRecord = data.case || {};
  const documents = [];
  const collections = [];
  const seenDocuments = new Set();
  const seenCollections = new Set();
  const addDocument = (label, value) => {
    if (!value || typeof value !== 'object') return;
    const wire = JSON.stringify(value);
    if (seenDocuments.has(wire)) return;
    seenDocuments.add(wire);
    documents.push([wire, label]);
  };
  const addCollection = (label, value) => {
    if (!Array.isArray(value) || !value.length) return;
    const wire = JSON.stringify(value);
    if (seenCollections.has(wire)) return;
    seenCollections.add(wire);
    collections.push([wire, label]);
  };
  addDocument('Current case document', caseRecord);
  addDocument('New target context: target-context-1', { context_id: 'target-context-1' });
  addDocument('Public access policy', {
    classification: 'public', permitted_roles: [], permitted_subjects: [],
    redaction_required: false, export_permitted: true,
  });
  addDocument('Validity window ending 2027-12-31', { expires_at: '2027-12-31T23:59:59Z' });
  const directNames = [
    'registry', 'geometry', 'scope', 'derivation', 'conversion', 'decision_scope',
    'continued_validity_source', 'local_recovery_evidence',
  ];
  directNames.forEach((name) => addDocument(`Case ${name.replaceAll('_', ' ')}`, caseRecord[name]));
  const mappedNames = [
    'certificates', 'evidence', 'safe_commitments', 'comparative_evaluations',
    'technology_contracts', 'qualification_plans', 'qualification_results',
    'lifecycle_records', 'lifecycle_verification_inputs',
    'lifecycle_companion_objects', 'registry_intake',
  ];
  mappedNames.forEach((name) => {
    const value = caseRecord[name];
    if (!value || typeof value !== 'object') return;
    const entries = [];
    const visit = (path, item) => {
      if (!item || typeof item !== 'object') return;
      if (Array.isArray(item)) {
        item.forEach((child, index) => visit(`${path} ${index + 1}`, child));
        return;
      }
      if (item.record_type || item.schema_version || item.profile) {
        addDocument(path, item);
        entries.push(item);
        return;
      }
      Object.entries(item).forEach(([identifier, child]) => visit(`${path}: ${identifier}`, child));
    };
    visit(name.replaceAll('_', ' '), value);
    addCollection(`All ${name.replaceAll('_', ' ')} (${entries.length})`, entries);
  });
  const dependencies = data.dependencies || caseRecord.dependencies;
  if (Array.isArray(dependencies)) {
    dependencies.forEach((item, index) => addDocument(`Dependency edge ${index + 1}`, item));
    addCollection(`All dependency edges (${dependencies.length})`, dependencies);
  } else if (dependencies && Array.isArray(dependencies.edges)) {
    dependencies.edges.forEach((item, index) => addDocument(`Dependency edge ${index + 1}`, item));
    addCollection(`All dependency edges (${dependencies.edges.length})`, dependencies.edges);
  }
  documents.forEach(([wire, label]) => {
    const arrayWire = JSON.stringify([JSON.parse(wire)]);
    if (!seenCollections.has(arrayWire)) {
      seenCollections.add(arrayWire);
      collections.push([arrayWire, `One-item collection: ${label}`]);
    }
  });
  return { documents: [['', 'Choose an existing canonical document'], ...documents],
    collections: [['', 'Choose an existing canonical collection'], ...collections] };
}

function selectedChoice(choices, value) {
  if (!value || choices.some(([wire]) => wire === value)) return choices;
  return [[value, 'Previously selected canonical document'], ...choices];
}

function lifecycleControl(state, form, catalog, operation, definition) {
  const [name, label, kind, optional] = definition;
  const controlName = lifecycleFieldName(operation, name);
  const stored = Object.prototype.hasOwnProperty.call(form, controlName)
    ? form[controlName] : undefined;
  if (kind === 'document' || kind === 'documents') {
    const choices = kind === 'documents' ? catalog.collections : catalog.documents;
    let fallback = '';
    if (name === 'target_context') fallback = JSON.stringify({ context_id: 'target-context-1' });
    if (name === 'access') fallback = JSON.stringify({
      classification: 'public', permitted_roles: [], permitted_subjects: [],
      redaction_required: false, export_permitted: true,
    });
    if (name === 'validity') fallback = JSON.stringify({ expires_at: '2027-12-31T23:59:59Z' });
    const value = stored === undefined ? fallback : stored;
    return select(controlName, label, selectedChoice(choices, value), {
      value,
      hint: `${optional ? 'Optional. ' : ''}Choose a canonical document already produced by this case or another guided workspace; no JSON entry is required.`,
    });
  }
  if (kind === 'boolean') {
    return select(controlName, label, [
      ['', 'Not supplied'], ['true', 'Verified'], ['false', 'Not verified'],
    ], { value: stored === undefined ? '' : stored });
  }
  const fallback = kind === 'strings' ? (LIFECYCLE_LIST_DEFAULTS[name] || '')
    : name === 'case_id' ? String(((state.data || {}).case || {}).case_id || state.caseId || '')
      : (LIFECYCLE_TEXT_DEFAULTS[name] || '');
  return field(controlName, label, {
    multiline: kind === 'strings', rows: kind === 'strings' ? 3 : undefined,
    value: stored === undefined ? fallback : stored,
    required: !optional,
    hint: kind === 'strings' ? 'Enter one canonical identity or declaration per line.' : '',
  });
}

function lifecycleGuidedControls(state, form, active) {
  const catalog = lifecycleCatalog(state);
  return Object.entries(LIFECYCLE_GUIDED_CONTRACTS).map(([operation, definitions]) => (
    `<fieldset class="crg-fieldset" data-lifecycle-operation-panel="${esc(operation)}"`
      + `${operation === active ? '' : ' hidden'}>`
      + `<legend class="crg-field__label">${esc(operation.replaceAll('_', ' '))} inputs</legend>`
      + `<p class="crg-prose">Required inputs are labelled. Canonical artifacts are selected `
      + `from the open case; Studio does not expose those documents as an ordinary JSON editor.</p>`
      + definitions.map((definition) => lifecycleControl(
        state, form, catalog, operation, definition,
      )).join('')
      + `</fieldset>`
  )).join('');
}

const RESILIENCE_RECORD_TYPES = new Set([
  'LifecycleReplayRecord', 'BackupRestoreRecoveryRecord',
  'MigrationReverificationRecord',
]);

const RESILIENCE_BOUNDARIES = {
  LifecycleReplayRecord: 'Deterministic replay of carried canonical lifecycle records only; '
    + 'not authorization, availability, point-in-time recovery, or transition execution.',
  BackupRestoreRecoveryRecord: 'Byte-exact portable logical inventory recovery plus independent '
    + 'lifecycle replay only; not provider disaster recovery, availability, PITR, failover, or RPO/RTO.',
  MigrationReverificationRecord: 'Registered semantically-equivalent identity migration plus '
    + 'independent replay of unchanged lifecycle bytes only; no certificate inheritance or substantive reissuance.',
};

function resilienceResultBoundary(record) {
  if (!RESILIENCE_RECORD_TYPES.has(record.record_type)) return '';
  return panel('Portable lifecycle resilience boundary', join([
    `<p class="crg-prose">${esc(record.claim_boundary
      || RESILIENCE_BOUNDARIES[record.record_type])}</p>`,
    `<p class="crg-prose"><strong>Commercial inference: none.</strong> This record does not `
      + `infer ROI, savings, superiority, or a provider service level.</p>`,
  ]), { tone: 'neutral', principle: 'why' });
}

function lifecycleResult(state) {
  const last = state.lastAction || {};
  if (!['publishLifecycleRecord', 'getLifecycleRecord', 'verifyLifecycleRecord']
    .includes(last.operation)) return '';
  const response = last.result || {};
  const result = response.outputs || response;
  const record = result.record || {};
  const direct = result.direct_state || {};
  const verification = result.verification || {};
  return panel('Latest lifecycle result', join([
    definitionList([
      ['Record type', record.record_type
        ? `<code class="crg-code">${esc(record.record_type)}</code>` : absent()],
      ['Independent replay', verificationChip(verification.status || 'FAILED')],
      ['First release', result.verification_inputs
        ? esc(result.verification_inputs.first_release_attribution || '') : absent()],
      ['Stored mutation', '<code class="crg-code">APPEND_ONLY_RECORD</code>'],
    ]),
    Object.keys(direct).length ? table('Direct lifecycle states', [
      { label: 'State field' }, { label: 'Recorded value' },
    ], Object.entries(direct).map(([name, value]) => ({ cells: [
      `<code class="crg-code">${esc(name)}</code>`,
      `<code class="crg-code">${esc(JSON.stringify(value))}</code>`,
    ] }))) : emptyState('This record type has no derived direct-state fields.'),
    `<p class="crg-prose"><strong>No synthetic score:</strong> these are typed states, not `
      + `confidence, health, readiness, ROI, or transition authority.</p>`,
    resilienceResultBoundary(record),
    disclosure('Canonical record and replay inputs', `<pre class="crg-pre" tabindex="0" `
      + `role="group" aria-label="Portable lifecycle record">`
      + `${esc(JSON.stringify({
        record, verification_inputs: result.verification_inputs || {},
      }, null, 2))}</pre>`, { principle: 'why' }),
  ]), { tone: verification.ok ? 'neutral' : 'warn', principle: 'why' });
}

function lifecyclePanel(state) {
  const form = state.form || {};
  const activeOperation = form['lifecycle-operation'] || 'CREATE_ETQ_LOOP';
  const example = {
    operation: 'CREATE_ETQ_LOOP',
    inputs: {
      loop_id: 'etq-loop-1', target_decision_id: 'decision-1', predicate_id: 'predicate-1',
      target_context: { context_id: 'target-context-1' },
      declared_stopping_conditions: ['CAPABILITY_ESTABLISHED'],
    },
  };
  const caseRecord = (state.data || {}).case || {};
  const inventory = caseRecord.lifecycle_records || {};
  const counts = Object.entries(inventory).sort(([left], [right]) => left.localeCompare(right));
  return panel('Decision lifecycle — producer plus independent replay', join([
    `<p class="crg-prose">Publish the next dependency-ordered record from a closed request. `
      + `The system calls the registered producer, independently reconstructs the result, and `
      + `only then appends an immutable record version.</p>`,
    counts.length ? table('Lifecycle inventory', [
      { label: 'Record type' }, { label: 'Current identities' },
    ], counts.map(([recordType, records]) => ({ cells: [
      `<code class="crg-code">${esc(recordType)}</code>`,
      esc(String(Object.keys(records || {}).length)),
    ] }))) : emptyState('No lifecycle records have been published in this case.'),
    disclosure('Registered operation generations', join([
      `<p class="crg-prose"><strong>v1.3 / ETQ lifecycle:</strong> `
        + `${ETQ_OPERATIONS.map((name) => `<code class="crg-code">${esc(name)}</code>`).join(' ')}</p>`,
      `<p class="crg-prose"><strong>v1.4 / decision lifecycle:</strong> `
        + `${DECISION_LIFECYCLE_OPERATIONS.map((name) => `<code class="crg-code">${esc(name)}</code>`).join(' ')}</p>`,
      `<p class="crg-prose"><strong>v1.4 / portable lifecycle resilience:</strong> `
        + `${RESILIENCE_LIFECYCLE_OPERATIONS.map((name) => `<code class="crg-code">${esc(name)}</code>`).join(' ')}</p>`,
    ]), { open: true }),
    disclosure('How to author portable resilience records', join([
      `<ol class="crg-list crg-list--ordered" aria-label="Portable lifecycle resilience workflows">`,
      `<li><code class="crg-code">BUILD_LIFECYCLE_REPLAY</code> carries one checkpoint plus `
        + `one-to-one canonical records and exact independent-verifier envelopes.</li>`,
      `<li><code class="crg-code">RECORD_BACKUP_RESTORE_RECOVERY</code> carries source, backup, `
        + `and restored <code class="crg-code">LifecyclePortableSnapshot</code> documents plus `
        + `the replay materials. Snapshots are stored and exported only as hash-bound companions.</li>`,
      `<li><code class="crg-code">RECORD_MIGRATION_REVERIFICATION</code> carries a pinned `
        + `registered migration record, byte-identical source/transformed objects, and one `
        + `substantive lifecycle record with its exact verifier envelope.</li>`,
      `</ol>`,
      `<p class="crg-prose">Publication fails closed before case mutation if attribution, hashes, `
        + `snapshot bytes, replay semantics, or the registered migration classification disagree. `
        + `These workflows do not establish provider DR, PITR, failover, RPO/RTO, ROI, savings, `
        + `or superiority.</p>`,
    ]), { open: true, principle: 'why' }),
    lifecycleResult(state),
    select('lifecycle-operation', 'Lifecycle operation to author', [
      ...ETQ_OPERATIONS.map((name) => [name, `v1.3 — ${name.replaceAll('_', ' ')}`]),
      ...DECISION_LIFECYCLE_OPERATIONS.map(
        (name) => [name, `v1.4 — ${name.replaceAll('_', ' ')}`],
      ),
      ...RESILIENCE_LIFECYCLE_OPERATIONS.map(
        (name) => [name, `v1.4 resilience — ${name.replaceAll('_', ' ')}`],
      ),
    ], {
      value: activeOperation,
      hint: 'Selecting an operation shows only its closed, registered input contract.',
    }),
    lifecycleGuidedControls(state, form, activeOperation),
    `<div class="crg-actions">${action('publish-lifecycle-record', 'Produce, replay, and append', {
      operation: 'publishLifecycleRecord', fields: LIFECYCLE_GUIDED_FIELDS,
    })}</div>`,
    `<p class="crg-prose"><strong>Studio authors inputs only.</strong> Hashes, direct states, `
      + `authorization consequences, verifier facts, and lifecycle transitions are never `
      + `accepted from these controls; the existing producer and independent replay remain authoritative.</p>`,
    field('lifecycle-record-type', 'Stored record type', {
      value: form['lifecycle-record-type'] || 'ETQDecisionLoop', required: true,
    }),
    field('lifecycle-record-id', 'Stored record identity', {
      value: form['lifecycle-record-id'] || 'etq-loop-1', required: true,
    }),
    `<div class="crg-actions">${action('inspect-lifecycle-record', 'Inspect and replay stored record', {
      operation: 'getLifecycleRecord', tone: 'secondary',
      fields: ['lifecycle-record-type', 'lifecycle-record-id'],
    })}</div>`,
    disclosure('Advanced mode — closed request and portable-envelope JSON', join([
      `<p class="crg-prose">Use canonical JSON for automation or for external artifacts that `
        + `have not yet entered the open case’s selectable document inventory. This invokes `
        + `the same producer, authorization context, and independent verifier.</p>`,
      field('lifecycle-request', 'Closed lifecycle request JSON', {
        multiline: true, rows: 18,
        value: form['lifecycle-request'] || JSON.stringify(example, null, 2),
        hint: 'Exactly operation and inputs. Derived states, hashes, and authority effects are refused.',
      }),
      `<div class="crg-actions">${action(
        'publish-lifecycle-record-json', 'Produce, replay, and append advanced request', {
          operation: 'publishLifecycleRecord', fields: ['lifecycle-request'], tone: 'secondary',
        },
      )}</div>`,
      field('lifecycle-portable', 'Portable verification envelope JSON', {
        multiline: true, rows: 12,
        value: form['lifecycle-portable'] || '',
        hint: 'Exactly record and verification_inputs, copied from an inspect or publish result.',
      }),
      `<div class="crg-actions">${action('verify-lifecycle-record', 'Independently replay portable record', {
        operation: 'verifyLifecycleRecord', tone: 'secondary', fields: ['lifecycle-portable'],
      })}</div>`,
    ]), { open: false, principle: 'why' }),
  ]), { principle: 'why' });
}

const CLASSIFICATIONS = {
  NO_EFFECT: ['No effect on any claim', 'good',
    'The change touched nothing a certificate depends on.'],
  METADATA_ONLY: ['Metadata only', 'good',
    'Nothing semantic changed, so no certificate is disturbed (16.3).'],
  BOUND_PRESERVING: ['Within the existing bounds', 'good',
    'The change stays inside a bound the certificate already accounted for.'],
  RECOMPUTE_REQUIRED: ['Recomputation required', 'caution',
    'Affected certificates must be recomputed before they may be relied on again.'],
  CLAIM_INVALIDATING: ['Claims invalidated', 'blocked',
    'One or more certificates no longer hold and must be reissued.'],
  REOPEN_REQUIRED: ['Decision must be reopened', 'blocked',
    'A reopen condition recorded on the certificate has been met.'],
};

function classificationPanel(plan) {
  const key = String(plan.classification || '');
  const [label, tone, description] = CLASSIFICATIONS[key]
    || [key || 'Not classified', 'caution', '30 requires every change to be typed before it is applied.'];
  return panel('What this change did to the existing claims', join([
    `<p class="crg-classification crg-classification--${esc(tone)}" `
    + `data-classification="${esc(key)}">`
    + `<strong>${esc(label)}</strong> <span class="crg-visually-hidden">(${esc(key)})</span></p>`,
    `<p class="crg-prose">${esc(description)}</p>`,
  ]), { tone, principle: 'why' });
}

function preservedPanel(plan) {
  const preserved = plan.preserved || [];
  const invalidated = plan.invalidated || [];
  return panel('Claims preserved and claims lost', join([
    `<h4 class="crg-subtitle">Preserved</h4>`,
    preserved.length
      ? `<ul class="crg-list">${preserved.map((id) => `<li>${hashChip(id)} `
        + `<span class="crg-prose">nothing this certificate depends on changed</span></li>`).join('')}</ul>`
      : '<p class="crg-prose">No certificate survived this change unaffected.</p>',
    `<h4 class="crg-subtitle">Invalidated</h4>`,
    invalidated.length
      ? `<ul class="crg-list">${invalidated.map((id) => `<li>${hashChip(id)} `
        + `${verificationChip('FAILED')}</li>`).join('')}</ul>`
      : '<p class="crg-prose">No certificate was invalidated.</p>',
  ]), { tone: invalidated.length ? 'warn' : 'neutral' });
}

function affectedTable(plan) {
  const affected = plan.affected || {};
  const keys = Object.keys(affected).sort();
  if (!keys.length) {
    return emptyState('No object was reached by this change.');
  }
  return table('Objects the change reached, and the edge that carried it', [
    { label: 'Object' },
    { label: 'Typed edge', hint: '18.3 names the edge types; the type is what makes the reach explicit.' },
  ], keys.map((key) => ({
    cells: [hashChip(key), `<code class="crg-code">${esc(affected[key])}</code>`],
  })));
}

function beforeAfter(plan) {
  const diff = plan.diff || plan.differences || [];
  if (!diff.length) {
    return panel('Before and after', emptyState('No field-level differences are recorded.'));
  }
  return table('Field-level differences', [
    { label: 'What changed' },
    { label: 'Before' },
    { label: 'After' },
    { label: 'Unit' },
  ], diff.map((entry) => ({
    cells: [
      entry.path ? `<code class="crg-code">${esc(entry.path)}</code>` : absent(),
      entry.before === undefined ? absent('UNSUPPORTED')
        : quantity(entry.before, { unit: entry.unit || '' }),
      entry.after === undefined ? absent('UNSUPPORTED')
        : quantity(entry.after, { unit: entry.unit || '' }),
      entry.unit ? esc(entry.unit) : absent('NOT_APPLICABLE'),
    ],
  })));
}

function actionsPanel(plan) {
  const actions = plan.required_actions || [];
  return panel('What you must do now', join([
    actions.length
      ? `<ol class="crg-list crg-list--ordered">${actions
        .map((a) => `<li>${esc(a)}</li>`).join('')}</ol>`
      : '<p class="crg-prose">Nothing is required. The change was absorbed without '
        + 'disturbing a claim.</p>',
    `<div class="crg-actions">`
    + action('recompute', 'Recompute the affected certificates', { operation: 'recomputeCase' })
    + action('dependencies', 'Show the dependency graph', {
      operation: 'getDependencies', tone: 'secondary',
    })
    + `</div>`,
  ]), { tone: actions.length ? 'warn' : 'neutral' });
}

function outcomeShift(plan) {
  const before = plan.previous_outcome;
  const after = plan.current_outcome;
  if (!before && !after) return '';
  return panel('Did the answer change?', definitionList([
    ['Before', before ? esc(outcomeInfo(before).headline) : absent()],
    ['After', after ? esc(outcomeInfo(after).headline) : absent()],
    ['Reading this', `<p class="crg-prose">A change from a strict winner to a possible `
      + `winner set is not a regression in the software; it is the system declining to `
      + `keep a claim the evidence no longer supports (22.5).</p>`],
  ]), { principle: 'tie-vs-ambiguity' });
}

function changeForm(state) {
  return panel('Propose a change', join([
    field('change-set', 'Assignments', {
      multiline: true, rows: 6,
      value: (state.form && state.form.set) || '',
      hint: 'Each line names a realization, a coordinate, and the new value.',
    }),
    field('change-reason', 'Declared reason', {
      value: (state.form && state.form.reason) || '',
      hint: '30 requires a declared reason. It becomes part of the change record and is '
        + 'what a later reviewer reads.',
      required: true,
    }),
    field('change-authority', 'Authority', {
      value: (state.form && state.form.authority) || '',
      hint: 'Who is authorising this. 44.7 requires every mutation to be attributable.',
      required: true,
    }),
    `<div class="crg-actions">${action('preview-change', 'Preview certified impact', {
      operation: 'previewChange', fields: ['change-set', 'change-reason', 'change-authority'],
    })}${action('classify-change', 'Verify and apply this change', {
      operation: 'classifyChange', fields: ['change-set', 'change-reason', 'change-authority'],
    })}</div>`,
    `<p class="crg-prose">Preview computes the same before/after evidence without mutating `
      + `the case. Apply persists only after the independent verifier reconstructs the minimum `
      + `valid action.</p>`,
  ]));
}

function latestCertifiedDelta(state) {
  const outputs = ((((state.lastAction || {}).result || {}).outputs) || {});
  if (outputs.certified_delta) {
    return { record: outputs.certified_delta, verification: outputs.verification || null,
      preview: outputs.preview === true };
  }
  const records = (((state.data || {}).case || {}).certified_deltas || {});
  const values = Object.values(records).filter((record) => record
    && record.record_type === 'CertifiedDeltaRecord');
  values.sort((left, right) => String(left.evidence_id || '').localeCompare(
    String(right.evidence_id || ''),
  ));
  return values.length ? { record: values[values.length - 1], verification: null, preview: false }
    : null;
}

function valueText(value) {
  if (value === undefined) return absent('UNSUPPORTED');
  if (value === null) return '<code class="crg-code">null</code>';
  if (typeof value === 'object') {
    return `<code class="crg-code">${esc(JSON.stringify(value))}</code>`;
  }
  return `<code class="crg-code">${esc(String(value))}</code>`;
}

function certifiedDeltaPanel(entry) {
  if (!entry) {
    return panel('Certified before-and-after evidence', emptyState(
      'No CertifiedDeltaRecord is stored or previewed. A legacy change classification alone is not independent change evidence.',
    ));
  }
  const record = entry.record || {};
  const delta = record.delta || {};
  const minimum = record.minimum_recomputation_claim || {};
  const fields = record.changed_fields || [];
  const edges = record.traversed_edges || [];
  const replacements = record.replacement_roots || {};
  const phase = record.phase_evidence || {};
  return panel(entry.preview ? 'Certified change preview — no mutation' : 'Certified change evidence', join([
    definitionList([
      ['Evidence identity', hashChip(record.evidence_id)],
      ['Prior case root', hashChip(delta.prior_root)],
      ['Current case root', hashChip(delta.current_root)],
      ['Independent verification', verificationChip(
        (entry.verification || {}).status || record.verification_status || 'FAILED',
      )],
      ['Minimum valid action', `<strong data-minimum-action="${esc(minimum.action || '')}">`
        + `${esc(minimum.action || '')}</strong>`],
      ['Why that action is minimum', `<span class="crg-prose">${esc(minimum.basis || '')}</span>`],
    ]),
    table('Canonical before-and-after field differences', [
      { label: 'Path' }, { label: 'Category' }, { label: 'Change' },
      { label: 'Before' }, { label: 'After' },
    ], fields.map((item) => ({ cells: [
      `<code class="crg-code">${esc(item.path || '')}</code>`,
      `<code class="crg-code">${esc(item.category || '')}</code>`,
      esc(item.change || ''), valueText(item.prior), valueText(item.current),
    ] }))),
    edges.length ? table('Typed dependency edges actually traversed', [
      { label: 'From' }, { label: 'Edge type' }, { label: 'To' },
      { label: 'Minimum action carried' },
    ], edges.map((edge) => ({ cells: [
      hashChip(edge.source), `<code class="crg-code">${esc(edge.edge_type || '')}</code>`,
      hashChip(edge.target), `<strong>${esc(edge.minimum_action || '')}</strong>`,
    ] }))) : emptyState('No typed dependency edge was traversed.'),
    panel('Preserved, invalidated, and replacement evidence', definitionList([
      ['Preserved claims', (delta.preserved || []).length
        ? (delta.preserved || []).map((value) => hashChip(value)).join(' ') : absent()],
      ['Invalidated claims', (delta.invalidated || []).length
        ? (delta.invalidated || []).map((value) => hashChip(value)).join(' ') : absent()],
      ['Replacement roots', Object.keys(replacements).length
        ? Object.entries(replacements).map(([identifier, root]) => `${esc(identifier)} ${hashChip(root)}`).join('<br>')
        : absent('NOT_APPLICABLE')],
      ['Prior certified phase root', phase.prior_phase_root
        ? hashChip(phase.prior_phase_root) : absent('NOT_APPLICABLE')],
      ['Current certified phase root', phase.current_phase_root
        ? hashChip(phase.current_phase_root) : absent('NOT_APPLICABLE')],
    ]), { principle: 'why' }),
    disclosure('Complete canonical CertifiedDeltaRecord', `<pre class="crg-pre" tabindex="0" `
      + `role="group" aria-label="Canonical certified-delta record">`
      + `${esc(JSON.stringify(record, null, 2))}</pre>`, { principle: 'why' }),
  ]), { tone: entry.preview ? 'neutral' : 'warn', principle: 'why' });
}

const CHANGE_COMPARISON_FIELDS = [
  'change-comparison-id', 'change-comparison-delta-id', 'change-comparison-case-id',
  'change-comparison-scope-id', 'change-comparison-decision-description',
  'change-comparison-evidence-classes', 'change-comparison-field-observation',
  'change-comparison-limitations', 'change-qualification-revalidation-id',
  'change-qualification-local-observation-refs',
  'change-qualification-counterfactual-refs',
];

const JOURNEY_COMPARISON_FIELDS = [
  'journey-comparison-id', 'journey-case-id', 'journey-v11-evaluation-id',
  'journey-v12-comparison-id', 'journey-technology-scope', 'journey-decision-scope',
  'journey-evidence-classes', 'journey-change-events', 'journey-time-kind',
  'journey-time-description', 'journey-privacy-classification', 'journey-privacy-basis',
  'journey-privacy-field-observation', 'journey-privacy-input-class',
  'journey-privacy-evidence-class', 'journey-limitations',
  ...CUMULATIVE_COMPARISON_ROLES.slice(2).map(([_stage, role]) => cumulativeRoleField(role)),
];

function exactCount(value) {
  return value && typeof value === 'object' && Object.keys(value).length === 1
    ? String(value.exact || '0') : 'not stated';
}

function comparisonResultFromState(state, kind) {
  const last = state.lastAction || {};
  const allowed = kind === 'change'
    ? ['previewComparativeChange', 'generateComparativeChange',
      'getComparativeChange', 'verifyComparativeChange']
    : ['previewCumulativeLifecycleComparison', 'generateCumulativeLifecycleComparison',
      'getCumulativeLifecycleComparison', 'verifyCumulativeLifecycleComparison'];
  if (!allowed.includes(last.operation)) return null;
  const response = last.result || {};
  const result = response.outputs || response;
  const key = kind === 'change' ? 'comparative_change' : 'cumulative_comparison';
  const expected = kind === 'change'
    ? 'ComparativeChangeEvidence' : 'CumulativeLifecycleComparison';
  if (!result[key] || result[key].record_type !== expected) return null;
  return { record: result[key], result, verification: result.verification || {} };
}

function storedChoices(inventory, emptyLabel) {
  const entries = Object.keys(inventory || {}).sort().map((identity) => [identity, identity]);
  return entries.length ? entries : [['', emptyLabel]];
}

function qualificationReferenceTable(title, references, emptyMessage) {
  if (!(references || []).length) return panel(title, emptyState(emptyMessage), {
    principle: 'why',
  });
  return table(title, [
    { label: 'Classification' }, { label: 'Stored session identity' },
    { label: 'Disclosed event hash' }, { label: 'Evidence eligible' },
  ], references.map((reference) => ({ cells: [
    `<code class="crg-code">${esc(reference.classification || '')}</code>`,
    `<code class="crg-code">${esc(reference.session_id || '')}</code>`,
    hashChip(reference.event_content_hash),
    `<code class="crg-code">${esc(String(reference.evidence_eligible === true))}</code>`,
  ] })));
}

function qualificationComparisonResult(extension) {
  if (!extension) return emptyState(
    'No optional v1.3 qualification extension is attached; this remains a v1.2 comparison.',
  );
  const facts = extension.system_derived_revalidation_facts || {};
  const binding = extension.selective_revalidation_binding || {};
  const revalidation = binding.selective_revalidation_record || {};
  return panel('v1.3 qualification and selective-revalidation extension', join([
    definitionList([
      ['Authority', `<code class="crg-code">${esc(extension.authority || '')}</code>`],
      ['Authorizing', `<code class="crg-code">${esc(String(extension.authorizing))}</code>`],
      ['Semantic effect', `<code class="crg-code">${esc(extension.semantic_effect || '')}</code>`],
      ['Stored revalidation identity', `<code class="crg-code">`
        + `${esc(revalidation.record_id || '')}</code>`],
      ['Conclusion', `<code class="crg-code">${esc(extension.conclusion || '')}</code>`],
    ]),
    panel('System-derived selective-revalidation facts — independently reconstructed', join([
      definitionList([
        ['Classification', `<code class="crg-code">${esc(facts.classification || '')}</code>`],
        ['Changed source', `<code class="crg-code">${esc(facts.changed_source || '')}</code>`],
        ['Changed properties', idList(facts.changed_properties, 'none')],
        ['Preserved identities', idList(facts.preserved, 'none')],
        ['Replacement required', idList(facts.replacement_required, 'none')],
        ['Lifecycle state', `<code class="crg-code">${esc(facts.state || '')}</code>`],
      ]),
      (facts.affected || []).length ? table('Exact affected identities and minimum actions', [
        { label: 'Artifact identity' }, { label: 'Minimum action' },
      ], facts.affected.map((item) => ({ cells: [
        `<code class="crg-code">${esc(item.artifact_id || '')}</code>`,
        `<strong>${esc(item.minimum_action || '')}</strong>`,
      ] }))) : emptyState('No affected identities were independently reconstructed.'),
    ]), { principle: 'why' }),
    definitionList([
      ['Local observation status', `<code class="crg-code">`
        + `${esc(extension.local_observation_status || 'ABSENT')}</code>`],
      ['Counterfactual status', `<code class="crg-code">`
        + `${esc(extension.counterfactual_status || 'ABSENT')}</code>`],
    ]),
    qualificationReferenceTable(
      'Local operational observations — non-evidentiary',
      extension.local_operational_observations,
      'No local operational observation reference was disclosed.',
    ),
    qualificationReferenceTable(
      'User-declared counterfactuals — unsupported',
      extension.declared_counterfactuals,
      'No unsupported user-declared counterfactual was disclosed.',
    ),
    `<p class="crg-prose"><strong>No inferred comparison:</strong> this extension does not infer `
      + `avoided work or experiments, time, cost, savings, ROI, superiority, or authorization.</p>`,
  ]), { tone: 'neutral', principle: 'why' });
}

function comparativeChangeResult(state) {
  const entry = comparisonResultFromState(state, 'change');
  if (!entry) return emptyState(
    'No comparative change record is displayed. Preview, generate, or inspect one first.',
  );
  const record = entry.record;
  const facts = record.system_derived_facts || {};
  const work = (name) => facts[name] || {};
  return panel('Displayed v1.2 comparative change evidence', join([
    definitionList([
      ['Comparison identity', `<code class="crg-code" data-comparative-change-id>`
        + `${esc(record.comparison_id || '')}</code>`],
      ['Independent replay', verificationChip(entry.verification.status || 'FAILED')],
      ['Authority', `<code class="crg-code" data-comparative-change-authority>`
        + `${esc(record.authority || '')}</code>`],
      ['Authorizing', `<code class="crg-code">${esc(String(record.authorizing))}</code>`],
      ['Semantic effect', `<code class="crg-code" data-comparative-change-effect>`
        + `${esc(record.semantic_effect || '')}</code>`],
      ['Decision state mutated', `<code class="crg-code">`
        + `${esc(String(entry.result.decision_state_mutation_performed === true))}</code>`],
      ['Successor case recorded', `<code class="crg-code">`
        + `${esc(String(entry.result.successor_case_recorded === true))}</code>`],
      ['Minimum action', `<strong data-comparative-change-minimum>`
        + `${esc(facts.minimum_action || '')}</strong>`],
    ]),
    table('Exact certified artifact identities', [
      { label: 'State' }, { label: 'Exact count' }, { label: 'Members' },
    ], [
      ['Preserved', work('preserved_work')],
      ['Invalidated', work('invalidated_work')],
      ['Recomputed', work('recomputed_work')],
    ].map(([label, item]) => ({ cells: [
      esc(label), `<code class="crg-code">${esc(exactCount(item.count))}</code>`,
      idList(item.members, 'none'),
    ] }))),
    `<p class="crg-prose"><strong>No strengthened claim:</strong> artifact counts are not `
      + `time, effort, avoided work, cost, savings, ROI, superiority, or a method ranking.</p>`,
    qualificationComparisonResult(record.qualification_extension),
    disclosure('Canonical comparative change record (display only)',
      `<pre class="crg-pre" tabindex="0">${esc(JSON.stringify(record, null, 2))}</pre>`,
      { principle: 'why' }),
  ]), { tone: entry.verification.ok ? 'neutral' : 'warn', principle: 'why' });
}

function cumulativeComparisonResult(state) {
  const entry = comparisonResultFromState(state, 'cumulative');
  if (!entry) return emptyState(
    'No cumulative journey comparison is displayed. Complete the prerequisites, then preview, generate, or inspect one.',
  );
  const record = entry.record;
  const denominator = record.denominator || {};
  const privacy = record.privacy_summary || {};
  const privacyCounts = Object.fromEntries((privacy.classification_counts || []).map(
    (item) => [item.classification, exactCount(item.count)],
  ));
  return panel('Displayed v1.4 cumulative lifecycle comparison', join([
    definitionList([
      ['Journey identity', `<code class="crg-code" data-cumulative-comparison-id>`
        + `${esc(record.journey_id || '')}</code>`],
      ['Independent replay', verificationChip(entry.verification.status || 'FAILED')],
      ['Authority', `<code class="crg-code" data-cumulative-comparison-authority>`
        + `${esc(record.authority || '')}</code>`],
      ['Semantic effect', `<code class="crg-code" data-cumulative-comparison-effect>`
        + `${esc(record.semantic_effect || '')}</code>`],
      ['Fixed denominator', `<strong data-cumulative-denominator>`
        + `${esc(exactCount(denominator.count))}</strong>`],
      ['Nested records replayed', esc(String(
        (((entry.verification || {}).report || {}).nested_results || []).length,
      ))],
      ['Successor case recorded', `<code class="crg-code">`
        + `${esc(String(entry.result.successor_case_recorded === true))}</code>`],
    ]),
    table('Fixed release-and-role denominator', [
      { label: 'Release' }, { label: 'Exact count' }, { label: 'Required roles' },
    ], (denominator.stage_denominators || []).map((stage) => ({ cells: [
      `<code class="crg-code">${esc(stage.stage || '')}</code>`,
      `<code class="crg-code">${esc(exactCount(stage.count))}</code>`,
      idList(stage.members, 'none'),
    ] }))),
    definitionList([
      ['Public reference', esc(privacyCounts.PUBLIC_REFERENCE || '0')],
      ['Local private', esc(privacyCounts.LOCAL_PRIVATE || '0')],
      ['Redacted portable', esc(privacyCounts.REDACTED_PORTABLE || '0')],
      ['Source material declassified', `<code class="crg-code">`
        + `${esc(String(privacy.record_declassifies_source_material === true))}</code>`],
    ]),
    `<p class="crg-prose"><strong>No aggregate score or authority:</strong> the ten direct `
      + `records remain alongside—and do not replace—the engineering workflows that produced them.</p>`,
    disclosure('Canonical cumulative comparison (display only)',
      `<pre class="crg-pre" tabindex="0">${esc(JSON.stringify(record, null, 2))}</pre>`,
      { principle: 'why' }),
  ]), { tone: entry.verification.ok ? 'neutral' : 'warn', principle: 'why' });
}

function comparativeChangeAuthoring(state, caseRecord, form) {
  const deltas = caseRecord.certified_deltas || {};
  const stored = caseRecord.comparative_change_evidence || {};
  const revalidations = ((caseRecord.lifecycle_records || {}).SelectiveRevalidationRecord) || {};
  const deltaIds = Object.keys(deltas).sort();
  const storedIds = Object.keys(stored).sort();
  const revalidationIds = Object.keys(revalidations).sort();
  const displayed = comparisonResultFromState(state, 'change');
  const example = {
    comparison_id: 'comparative-change-1', certified_delta_id: deltaIds[0] || 'stored-delta-id',
    decision_scope: { case_id: caseRecord.case_id || state.caseId, scope_id: 'decision-scope-1' },
    evidence_scope: { classes: ['MODELED'], field_observation: false },
    limitations: ['Finite declared case and dependency graph only'],
  };
  return `<section data-comparison-guided="comparative-change">${join([
    `<h4 class="crg-subtitle">v1.2 — certified change comparison</h4>`,
    `<p class="crg-prose">Choose a stored certified delta. Studio sends only its identity and `
      + `your declared scope; the server resolves exact source bytes, independently replays them, `
      + `derives work identities, and independently verifies the result.</p>`,
    comparativeChangeResult(state),
    field('change-comparison-id', 'Comparison identity', {
      value: form['change-comparison-id'] || 'comparative-change-1', required: true,
    }),
    select('change-comparison-delta-id', 'Stored CertifiedDeltaRecord',
      storedChoices(deltas, 'No certified delta stored yet'), {
        value: form['change-comparison-delta-id'] || deltaIds[0] || '',
        hint: 'Record bytes, replay inputs, verifier answers, hashes, and counts are never authored here.',
      }),
    field('change-comparison-case-id', 'Case identity', {
      value: form['change-comparison-case-id'] || caseRecord.case_id || state.caseId || '',
      required: true,
    }),
    field('change-comparison-scope-id', 'Decision scope identity', {
      value: form['change-comparison-scope-id'] || 'decision-scope-1', required: true,
    }),
    field('change-comparison-decision-description', 'Decision scope description', {
      value: form['change-comparison-decision-description'] || 'Declared finite decision scope',
      required: true,
    }),
    field('change-comparison-evidence-classes', 'Evidence classes', {
      multiline: true, rows: 3,
      value: form['change-comparison-evidence-classes'] || 'MODELED', required: true,
      hint: 'One declared class per line.',
    }),
    select('change-comparison-field-observation', 'Contains field observation', [
      ['false', 'No'], ['true', 'Yes'],
    ], { value: form['change-comparison-field-observation'] || 'false' }),
    field('change-comparison-limitations', 'Limitations', {
      multiline: true, rows: 3,
      value: form['change-comparison-limitations']
        || 'Artifact identity counts are not effort or economic quantities\nFinite declared case and dependency graph only',
      required: true, hint: 'One explicit limitation per line.',
    }),
    panel('Optional v1.3 qualification and selective-revalidation comparison', join([
      `<p class="crg-prose">Choose a stored SelectiveRevalidationRecord to attach the `
        + `qualification profile. Optional operational entries are stored measurement identities `
        + `only; the server resolves and hash-checks their disclosed records from the separate `
        + `local measurement store.</p>`,
      select('change-qualification-revalidation-id', 'Stored SelectiveRevalidationRecord', [
        ['', 'No v1.3 extension — preserve the v1.2 request'],
        ...revalidationIds.map((identity) => [identity, identity]),
      ], {
        value: form['change-qualification-revalidation-id'] || '',
        hint: 'Studio never submits the record, lifecycle replay inputs, or verifier result.',
      }),
      field('change-qualification-local-observation-refs',
        'Local observation identities — non-evidentiary', {
          multiline: true, rows: 3,
          value: form['change-qualification-local-observation-refs'] || '',
          hint: 'Optional. One stored session_id | event_hash pair per line; maximum 32.',
        }),
      field('change-qualification-counterfactual-refs',
        'User-declared counterfactual identities — unsupported', {
          multiline: true, rows: 3,
          value: form['change-qualification-counterfactual-refs'] || '',
          hint: 'Optional. One stored session_id | event_hash pair per line; maximum 32.',
        }),
      `<p class="crg-prose"><strong>Claim boundary:</strong> local observations remain `
        + `non-evidence, counterfactuals remain unsupported, and no ROI, savings, superiority, `
        + `avoided work, avoided experiments, or authority is derived.</p>`,
    ]), { principle: 'why' }),
    `<div class="crg-actions">${action('preview-comparative-change',
      'Preview without recording a successor case', {
        operation: 'previewComparativeChange', fields: CHANGE_COMPARISON_FIELDS,
        disabled: !deltaIds.length,
      })}${action('generate-comparative-change', 'Verify and record in successor case', {
      operation: 'generateComparativeChange', fields: CHANGE_COMPARISON_FIELDS,
      disabled: !deltaIds.length,
    })}</div>`,
    select('change-comparison-inspect-id', 'Stored comparison to inspect',
      storedChoices(stored, 'No comparative change stored yet'), {
        value: form['change-comparison-inspect-id'] || storedIds[0] || '',
      }),
    `<div class="crg-actions">${action('inspect-comparative-change', 'Inspect stored comparison', {
      operation: 'getComparativeChange', tone: 'secondary',
      fields: ['change-comparison-inspect-id'], disabled: !storedIds.length,
    })}${action('verify-comparative-change', 'Verify displayed comparison', {
      operation: 'verifyComparativeChange', tone: 'secondary', disabled: !displayed,
    })}</div>`,
    disclosure('Advanced mode — closed request or portable record JSON', join([
      field('change-comparison-request', 'Closed comparative change request JSON', {
        multiline: true, rows: 10,
        value: form['change-comparison-request'] || JSON.stringify(example, null, 2),
      }),
      `<div class="crg-actions">${action('preview-comparative-change-json',
        'Preview advanced request', { operation: 'previewComparativeChange', tone: 'secondary',
          fields: ['change-comparison-request'] })}${action('generate-comparative-change-json',
        'Record advanced request', { operation: 'generateComparativeChange', tone: 'secondary',
          fields: ['change-comparison-request'] })}</div>`,
      field('change-comparison-record', 'Portable ComparativeChangeEvidence JSON', {
        multiline: true, rows: 10, value: form['change-comparison-record'] || '',
      }),
      `<div class="crg-actions">${action('verify-comparative-change-json',
        'Verify advanced portable record', { operation: 'verifyComparativeChange', tone: 'secondary',
          fields: ['change-comparison-record'] })}</div>`,
    ]), { open: false, principle: 'why' }),
  ])}</section>`;
}

function cumulativeAuthoring(state, caseRecord, form) {
  const v11 = caseRecord.comparative_evaluations || {};
  const v12 = caseRecord.comparative_change_evidence || {};
  const lifecycle = caseRecord.lifecycle_records || {};
  const stored = caseRecord.cumulative_lifecycle_comparisons || {};
  const v11Ids = Object.keys(v11).sort();
  const v12Ids = Object.keys(v12).sort();
  const storedIds = Object.keys(stored).sort();
  const roleInputs = CUMULATIVE_COMPARISON_ROLES.slice(2).map(([_stage, role, recordType]) => {
    const records = lifecycle[recordType] || {};
    const ids = Object.keys(records).sort();
    return { role, recordType, ids };
  });
  const ready = Boolean(v11Ids.length && v12Ids.length
    && roleInputs.every((entry) => entry.ids.length));
  const displayed = comparisonResultFromState(state, 'cumulative');
  const roleValues = Object.fromEntries(roleInputs.map((entry) => (
    [entry.role, entry.ids[0] || `stored-${entry.recordType}`]
  )));
  const example = {
    journey_id: 'cumulative-journey-1',
    scope: {
      case_id: caseRecord.case_id || state.caseId,
      technology_scope: { description: 'Declared technology family' },
      decision_scope: { description: 'Declared finite decision family' },
      evidence_scope: { classes: ['MODELED'] },
      change_scope: { events: ['declared-change'] },
      journey_time_scope: { kind: 'DECLARED_LOGICAL_ORDER' },
    },
    v1_1_evaluation_id: v11Ids[0] || 'stored-v1.1-evaluation',
    v1_2_comparison_id: v12Ids[0] || 'stored-v1.2-comparison',
    lifecycle_artifact_ids: roleValues,
    privacy_controls: 'one exact control per fixed role — see public schema',
    limitations: ['Finite declared journey only'],
  };
  return `<section data-comparison-guided="cumulative-journey">${join([
    `<h4 class="crg-subtitle">v1.4 — cumulative lifecycle comparison</h4>`,
    `<p class="crg-prose">Select the one stored artifact for each fixed role. Studio never asks `
      + `ordinary users to paste those records or verifier inputs; the server resolves and replays `
      + `all ten artifacts before displaying or recording anything.</p>`,
    cumulativeComparisonResult(state),
    ready ? '' : panel('Prerequisites still required', `<p class="crg-prose">Persist one v1.1 `
      + `workflow evaluation, one v1.2 comparative change, and each of the eight labelled `
      + `lifecycle record types. Preview and record stay disabled until all identities exist.</p>`,
    { tone: 'warn' }),
    field('journey-comparison-id', 'Journey identity', {
      value: form['journey-comparison-id'] || 'cumulative-journey-1', required: true,
    }),
    select('journey-v11-evaluation-id', 'Stored v1.1 workflow comparison',
      storedChoices(v11, 'No v1.1 evaluation stored yet'), {
        value: form['journey-v11-evaluation-id'] || v11Ids[0] || '',
      }),
    select('journey-v12-comparison-id', 'Stored v1.2 change comparison',
      storedChoices(v12, 'No v1.2 comparison stored yet'), {
        value: form['journey-v12-comparison-id'] || v12Ids[0] || '',
      }),
    ...roleInputs.map((entry) => select(
      cumulativeRoleField(entry.role),
      `${entry.role.replaceAll('_', ' ')} — ${entry.recordType}`,
      entry.ids.length ? entry.ids.map((id) => [id, id]) : [['', `No ${entry.recordType} stored yet`]],
      { value: form[cumulativeRoleField(entry.role)] || entry.ids[0] || '' },
    )),
    field('journey-case-id', 'Case identity', {
      value: form['journey-case-id'] || caseRecord.case_id || state.caseId || '', required: true,
    }),
    field('journey-technology-scope', 'Technology scope', {
      value: form['journey-technology-scope'] || 'Declared technology family', required: true,
    }),
    field('journey-decision-scope', 'Decision scope', {
      value: form['journey-decision-scope'] || 'Declared finite decision family', required: true,
    }),
    field('journey-evidence-classes', 'Evidence classes', {
      multiline: true, rows: 3, value: form['journey-evidence-classes'] || 'MODELED',
      required: true, hint: 'One declared class per line.',
    }),
    field('journey-change-events', 'Journey change events', {
      multiline: true, rows: 3, value: form['journey-change-events'] || 'declared-change',
      required: true, hint: 'One declared event identity per line.',
    }),
    select('journey-time-kind', 'Journey time scope', [
      ['DECLARED_LOGICAL_ORDER', 'Declared logical order'],
      ['REFERENCE_LOGICAL_ORDER_ONLY', 'Reference logical order only'],
      ['DECLARED_INTERVAL', 'Declared interval'],
    ], { value: form['journey-time-kind'] || 'DECLARED_LOGICAL_ORDER' }),
    field('journey-time-description', 'Journey time description', {
      value: form['journey-time-description'] || 'Ordered stored evidence only', required: true,
    }),
    select('journey-privacy-classification', 'Privacy classification for this guided set', [
      ['LOCAL_PRIVATE', 'Local private — export not permitted'],
      ['PUBLIC_REFERENCE', 'Public reference — no field observation'],
      ['REDACTED_PORTABLE', 'Redacted portable — redaction applied'],
    ], { value: form['journey-privacy-classification'] || 'LOCAL_PRIVATE' }),
    field('journey-privacy-basis', 'Privacy classification basis', {
      value: form['journey-privacy-basis'] || 'Declared local product evidence classification',
      required: true,
    }),
    select('journey-privacy-field-observation', 'Contains field observation', [
      ['false', 'No'], ['true', 'Yes'],
    ], { value: form['journey-privacy-field-observation'] || 'false' }),
    field('journey-privacy-input-class', 'Input class', {
      value: form['journey-privacy-input-class'] || 'REFERENCE', required: true,
    }),
    field('journey-privacy-evidence-class', 'Evidence class', {
      value: form['journey-privacy-evidence-class'] || 'PRODUCT_EVIDENCE', required: true,
    }),
    field('journey-limitations', 'Journey limitations', {
      multiline: true, rows: 3,
      value: form['journey-limitations']
        || 'Privacy classifications are declarations, not source declassification\nFinite declared journey only; no field or economic generalization',
      required: true,
    }),
    `<div class="crg-actions">${action('preview-cumulative-comparison',
      'Preview ten-role journey without recording', {
        operation: 'previewCumulativeLifecycleComparison',
        fields: JOURNEY_COMPARISON_FIELDS, disabled: !ready,
      })}${action('generate-cumulative-comparison', 'Verify and record journey in successor case', {
      operation: 'generateCumulativeLifecycleComparison',
      fields: JOURNEY_COMPARISON_FIELDS, disabled: !ready,
    })}</div>`,
    select('journey-comparison-inspect-id', 'Stored journey to inspect',
      storedChoices(stored, 'No cumulative comparison stored yet'), {
        value: form['journey-comparison-inspect-id'] || storedIds[0] || '',
      }),
    `<div class="crg-actions">${action('inspect-cumulative-comparison', 'Inspect stored journey', {
      operation: 'getCumulativeLifecycleComparison', tone: 'secondary',
      fields: ['journey-comparison-inspect-id'], disabled: !storedIds.length,
    })}${action('verify-cumulative-comparison', 'Verify displayed journey', {
      operation: 'verifyCumulativeLifecycleComparison', tone: 'secondary', disabled: !displayed,
    })}</div>`,
    disclosure('Advanced mode — per-role privacy or portable JSON', join([
      `<p class="crg-prose">Advanced mode supports distinct privacy controls per role. It still `
        + `uses the same closed stored-identity contract and independent verifier boundary.</p>`,
      field('journey-comparison-request', 'Closed cumulative comparison request JSON', {
        multiline: true, rows: 14,
        value: form['journey-comparison-request'] || JSON.stringify(example, null, 2),
      }),
      `<div class="crg-actions">${action('preview-cumulative-comparison-json',
        'Preview advanced request', { operation: 'previewCumulativeLifecycleComparison',
          tone: 'secondary', fields: ['journey-comparison-request'] })}${action(
        'generate-cumulative-comparison-json', 'Record advanced request', {
          operation: 'generateCumulativeLifecycleComparison', tone: 'secondary',
          fields: ['journey-comparison-request'],
        })}</div>`,
      field('journey-comparison-record', 'Portable CumulativeLifecycleComparison JSON', {
        multiline: true, rows: 12, value: form['journey-comparison-record'] || '',
      }),
      `<div class="crg-actions">${action('verify-cumulative-comparison-json',
        'Verify advanced portable record', { operation: 'verifyCumulativeLifecycleComparison',
          tone: 'secondary', fields: ['journey-comparison-record'] })}</div>`,
    ]), { open: false, principle: 'why' }),
  ])}</section>`;
}

function journeyComparisonPanel(state) {
  const form = state.form || {};
  const caseRecord = (state.data || {}).case || {};
  return panel('Comparative evidence — stored identities, independent replay', join([
    `<p class="crg-prose"><strong>Evidence, not authority.</strong> These product records expose `
      + `direct regret-minimizing work and lifecycle facts while remaining alongside compilers, `
      + `optimization systems, EDA tools, simulators, laboratories, databases, and existing `
      + `engineering workflows. Authority is NON_AUTHORIZING and semantic effect is NONE.</p>`,
    comparativeChangeAuthoring(state, caseRecord, form),
    cumulativeAuthoring(state, caseRecord, form),
  ]), { principle: 'why' });
}

export const workspace = {
  ...meta,
  render(state = {}) {
    const plan = (state.data || {}).impact || (state.data || {}).plan || state.plan || null;
    const certified = latestCertifiedDelta(state);
    if (!plan) {
      return shell(meta, join([
        changeForm(state),
        lifecyclePanel(state),
        certifiedDeltaPanel(certified),
        journeyComparisonPanel(state),
        decisionChallengePanel(state),
        notYet('No change has been classified against this case yet.'),
      ]), state);
    }
    return shell(meta, join([
      changeForm(state),
      lifecyclePanel(state),
      certifiedDeltaPanel(certified),
      journeyComparisonPanel(state),
      decisionChallengePanel(state),
      classificationPanel(plan),
      outcomeShift(plan),
      preservedPanel(plan),
      affectedTable(plan),
      beforeAfter(plan),
      actionsPanel(plan),
      disclosure('Change plan as stored', `<pre class="crg-pre" tabindex="0" role="group" `
        + `aria-label="Change impact plan">${esc(JSON.stringify(plan, null, 2))}</pre>`,
      { principle: 'why' }),
    ]), state);
  },
};

export default workspace;
