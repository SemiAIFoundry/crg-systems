"""CRG Studio -- the optional interface over the same public APIs (spec 41).

Studio is a browser application: hand-written HTML, CSS, and ES modules, no
build step, no package manager, no external JavaScript.  This package serves
those bytes from the existing reference server and does nothing else.  Every
number, status, scope, and badge the user sees was fetched from an endpoint
named in 38.3 and described by ``crg_server.openapi.openapi_document()``.

The design constraint is the deliverable.  41 says Studio "shall be an
optional interface over the same public APIs"; an interface that also read
the kernel directly would prove nothing about the API, and would quietly
become the place where a capability lives that integrators cannot reach.  So
the Python here imports one symbol from ``crg_server`` -- the response type
-- and the JavaScript issues no request whose path is absent from the
OpenAPI document.  ``tests/test_studio.py`` asserts both, by parsing the
JavaScript rather than by trusting this paragraph.

Usage::

    from crg_server import CaseStore, JobQueue, make_app
    from crg_studio import mount_studio

    app = mount_studio(make_app(CaseStore(".crg-server"), JobQueue(store)))
    # GET /studio now serves the application shell; the API is unchanged.

or, for a server that carries both::

    from crg_studio import serve_studio

    server, app = serve_studio("127.0.0.1", 8731)
    server.serve_forever()
"""
from __future__ import annotations

from typing import Dict, Tuple

from .app import (
    ASSETS,
    CONTENT_SECURITY_POLICY,
    CONTENT_TYPES,
    STATIC_ROOT,
    STUDIO_PREFIX,
    asset_bytes,
    asset_names,
    content_type_for,
    describe,
    mount_studio,
    serve_studio,
    studio_index_url,
    studio_response,
)

__version__ = "1.4.0"
SPEC_VERSION = "0.2.0"

#: Specification 41.1, verbatim in order, keyed by the ES module that
#: implements each one.  The table is the contract between this package and
#: ``static/workspaces/``: the test suite asserts that every row has a module
#: and every module has a row, so a workspace cannot be quietly dropped and a
#: module cannot appear that 41.1 did not ask for.
WORKSPACES: Tuple[Tuple[str, str, str], ...] = (
    ("case-setup", "Case Setup",
     "Source, contracts, hierarchy, packs, completeness, and branch selection"),
    ("registry-import", "Registry Import",
     "Preview-first mapping, exact units, provenance, diagnostics, and hash confirmation"),
    ("realization-explorer", "Realization Explorer",
     "Legal and rejected candidates, fibers, parentage, choices, and witnesses"),
    ("obligation-explorer", "Obligation Explorer",
     "Typed coordinates, units, accounting, scopes, and uncertainty"),
    ("geometry-phase-view", "Geometry and Phase View",
     "R, Gamma, K, envelopes, ledgers, boundaries, and ties"),
    ("decision-query", "Decision Query",
     "Query authoring, derivation, required object, and refusal explanations"),
    ("decision-center", "Decision Center",
     "Winners, possible winners, retained alternatives, margins, pruning, "
     "regret, and claim scope"),
    ("completeness-center", "Completeness Center",
     "Family basis, known omissions, bounds, truncation, and claim implications"),
    ("change-impact", "Change Impact",
     "Before-and-after differences, typed edges, preserved claims, and required action"),
    ("evidence-graph", "Evidence Graph",
     "Source context, applicability, uncertainty, conflict, and lineage"),
    ("qualification-planner", "Qualification Planner",
     "Desired state, thresholds, experiments, burden, and stopping"),
    ("conversion-planner", "Conversion Planner",
     "Ownership maps, retained regions, residual transfers, and schedules"),
    ("physical-feedback", "Physical Feedback",
     "Evaluator requests, results, evidence classes, and witness refinement"),
    ("verification-center", "Verification Center",
     "Verification level, proof status, failures, expiry, and signatures"),
    ("federation-center", "Federation Center",
     "Capability envelopes, requests, release policies, and revocation"),
    ("branch-merge", "Branch and Merge",
     "Divergence, reconciliation, conflict resolution, and certificate effect"),
    ("audit-approval", "Audit and Approval",
     "Object history, signatures, approvals, redactions, exports, and isolated local measurement"),
)

#: Specification 41.2, one row per MUST, keyed by the identifier the browser
#: code and the test suite both use.  Studio renders this table in its own
#: "How to read this" panel, so the principles are visible to the user and
#: not only to the reviewer.
UX_PRINCIPLES: Dict[str, str] = {
    "why": "explain why a result exists",
    "claim-scope": "display claim scope prominently",
    "completeness": "display completeness basis prominently",
    "evidence-classes": (
        "distinguish exact, bounded, measured, modeled, imported, declared, "
        "and heuristic information"
    ),
    "tie-vs-ambiguity": "distinguish tie from uncertainty-driven ambiguity",
    "no-zero": "avoid presenting unsupported coordinates as zero",
    "all-infeasible": "preserve all-infeasible states",
    "margins": "show what would have to change for another realization to win",
    "resolving-evidence": (
        "expose the evidence or experiment most capable of resolving uncertainty"
    ),
    "verified-or-replay": (
        "show whether a certificate is independently verified or replay-bound"
    ),
    "keyboard": "support accessible keyboard navigation",
    "plain-language": (
        "avoid requiring ordinary users to manipulate the full mathematical notation"
    ),
}

__all__ = [
    "ASSETS",
    "CONTENT_SECURITY_POLICY",
    "CONTENT_TYPES",
    "SPEC_VERSION",
    "STATIC_ROOT",
    "STUDIO_PREFIX",
    "UX_PRINCIPLES",
    "WORKSPACES",
    "__version__",
    "asset_bytes",
    "asset_names",
    "content_type_for",
    "describe",
    "mount_studio",
    "serve_studio",
    "studio_index_url",
    "studio_response",
]
