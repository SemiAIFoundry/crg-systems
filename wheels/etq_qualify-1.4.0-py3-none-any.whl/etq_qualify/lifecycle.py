"""The guided evidence-to-decision lifecycle for CRG ETQ.

This module is the additive orchestration layer required by canonical product
roadmap workstream D.  The mathematical and evidentiary primitives remain in
``etq_evidence`` and the other ``etq_qualify`` modules; this layer binds them
into the twelve ordered actions of roadmap section 6.4 and records the result
without inventing a confidence, readiness, or health score.

Normative basis:

* master specification sections 12, 18, 33, 34, and 35.1;
* roadmap section 6.4 (the twelve-step ETQ loop); and
* roadmap section 6.5 (immutable history and replacement records).

Three fail-closed rules are structural here.  A loop cannot skip a step or
continue after a refusal.  A returned result becomes a new ``EvidenceRecord``
whose provenance commits to the result; it never mutates or overwrites a prior
record.  Selective revalidation is available only for a declared-complete,
typed dependency graph; otherwise the implementation refuses to claim that an
unreached artifact remains valid.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Iterable, Optional, Sequence, Tuple

from crg_model.canonical import content_hash, is_hash
from crg_model.edges import Action, DependencyEdge, DependencyGraph
from crg_model.envelope import EvidenceClass
from etq_evidence import (
    AccessPolicy,
    EvidenceRecord,
    EvidenceStatus,
    MethodDescriptor,
    Provenance,
    ValidityWindow,
)

from .execute import ExperimentResult, QualificationResult, ResultStatus
from .objective import QualificationError, StoppingCondition

__all__ = [
    "ETQ_LIFECYCLE_PROFILE",
    "ETQ_LIFECYCLE_SCHEMA_VERSION",
    "ETQLifecycleError",
    "ETQLoopStep",
    "LoopArtifactRef",
    "ETQStepRecord",
    "ETQDecisionLoop",
    "ResultIngestionRecord",
    "ingest_result_as_evidence",
    "RevalidationState",
    "SelectiveRevalidationRecord",
    "ReplacementRecord",
    "plan_selective_revalidation",
    "issue_replacement",
    "QualificationDispositionState",
    "QualificationDisposition",
    "qualification_disposition",
]

ETQ_LIFECYCLE_PROFILE = "crg.etq-decision-loop"
ETQ_LIFECYCLE_SCHEMA_VERSION = "1.0.0"


class ETQLifecycleError(QualificationError):
    """A guided lifecycle claim cannot be made from the supplied records."""


def _require_hash(value: str, field_name: str) -> str:
    value = str(value)
    if not is_hash(value):
        raise ETQLifecycleError(f"{field_name} must be an algorithm-tagged SHA-256 hash")
    return value


class ETQLoopStep:
    """The twelve actions admitted by roadmap section 6.4, in order."""

    EVIDENCE_AUTHORED = "EVIDENCE_AUTHORED"
    APPLICABILITY_EVALUATED = "APPLICABILITY_EVALUATED"
    UNCERTAINTY_PRESERVED = "UNCERTAINTY_PRESERVED"
    CONFLICT_AND_VALIDITY_PRESERVED = "CONFLICT_AND_VALIDITY_PRESERVED"
    TECHNOLOGY_CONTRACT_ASSEMBLED = "TECHNOLOGY_CONTRACT_ASSEMBLED"
    DECISION_CONSEQUENCES_PROPAGATED = "DECISION_CONSEQUENCES_PROPAGATED"
    DECISION_CHANGING_UNKNOWN_IDENTIFIED = "DECISION_CHANGING_UNKNOWN_IDENTIFIED"
    QUALIFICATION_TARGET_INVERTED = "QUALIFICATION_TARGET_INVERTED"
    EXPERIMENTS_RANKED = "EXPERIMENTS_RANKED"
    REQUEST_AND_STOPPING_RULE_ISSUED = "REQUEST_AND_STOPPING_RULE_ISSUED"
    RESULT_INGESTED_AS_EVIDENCE = "RESULT_INGESTED_AS_EVIDENCE"
    SELECTIVE_REVALIDATION_AND_REPLACEMENT = "SELECTIVE_REVALIDATION_AND_REPLACEMENT"

    ORDER: Tuple[str, ...] = (
        EVIDENCE_AUTHORED,
        APPLICABILITY_EVALUATED,
        UNCERTAINTY_PRESERVED,
        CONFLICT_AND_VALIDITY_PRESERVED,
        TECHNOLOGY_CONTRACT_ASSEMBLED,
        DECISION_CONSEQUENCES_PROPAGATED,
        DECISION_CHANGING_UNKNOWN_IDENTIFIED,
        QUALIFICATION_TARGET_INVERTED,
        EXPERIMENTS_RANKED,
        REQUEST_AND_STOPPING_RULE_ISSUED,
        RESULT_INGESTED_AS_EVIDENCE,
        SELECTIVE_REVALIDATION_AND_REPLACEMENT,
    )

    #: Registered product artifact types expected from each action.  The
    #: values are deliberately semantic record names, not UI labels.
    OUTPUT_TYPES = {
        EVIDENCE_AUTHORED: frozenset({"EvidenceRecord"}),
        APPLICABILITY_EVALUATED: frozenset({"ApplicabilityAssessment"}),
        UNCERTAINTY_PRESERVED: frozenset({"UncertaintyComponentRecord"}),
        CONFLICT_AND_VALIDITY_PRESERVED: frozenset({"EvidenceDisposition"}),
        TECHNOLOGY_CONTRACT_ASSEMBLED: frozenset({"TechnologyContract"}),
        DECISION_CONSEQUENCES_PROPAGATED: frozenset({"DecisionConsequence"}),
        DECISION_CHANGING_UNKNOWN_IDENTIFIED: frozenset({"DecisionChangingUnknown"}),
        QUALIFICATION_TARGET_INVERTED: frozenset({"QualificationTarget"}),
        EXPERIMENTS_RANKED: frozenset({"ExperimentRanking"}),
        REQUEST_AND_STOPPING_RULE_ISSUED: frozenset(
            {"EvaluatorRequest", "ExperimentRequest"}
        ),
        RESULT_INGESTED_AS_EVIDENCE: frozenset({"EvidenceRecord"}),
        SELECTIVE_REVALIDATION_AND_REPLACEMENT: frozenset(
            {"SelectiveRevalidationRecord", "ReplacementRecord"}
        ),
    }

    @classmethod
    def index(cls, step: str) -> int:
        try:
            return cls.ORDER.index(step) + 1
        except ValueError:
            raise ETQLifecycleError(f"unknown ETQ lifecycle step {step!r}") from None


@dataclass(frozen=True)
class LoopArtifactRef:
    """Content-addressed reference to an artifact produced by one loop step."""

    artifact_id: str
    artifact_type: str
    content_hash: str
    parent_hashes: Tuple[str, ...] = ()
    status: str = "ACTIVE"
    evidence_class: str = EvidenceClass.DECLARED

    def __post_init__(self) -> None:
        if not self.artifact_id or not self.artifact_type:
            raise ETQLifecycleError("a loop artifact requires an identity and registered type")
        object.__setattr__(self, "content_hash", _require_hash(self.content_hash, "content_hash"))
        parents = tuple(_require_hash(v, "parent_hash") for v in self.parent_hashes)
        if self.content_hash in parents:
            raise ETQLifecycleError("an artifact cannot name itself as a parent")
        object.__setattr__(self, "parent_hashes", parents)
        if self.evidence_class not in EvidenceClass.ALL:
            raise ETQLifecycleError(f"unknown evidence class {self.evidence_class!r}")

    def to_canonical(self) -> dict:
        return {
            "artifact_id": self.artifact_id,
            "artifact_type": self.artifact_type,
            "content_hash": self.content_hash,
            "parent_hashes": list(self.parent_hashes),
            "status": self.status,
            "evidence_class": self.evidence_class,
        }


@dataclass(frozen=True)
class ETQStepRecord:
    """One ordered, authority-bearing action in the guided ETQ loop."""

    step: str
    outputs: Tuple[LoopArtifactRef, ...]
    input_hashes: Tuple[str, ...] = ()
    authority: str = ""
    verification_basis: Tuple[str, ...] = ()
    refusal_code: Optional[str] = None
    refusal_detail: str = ""

    def __post_init__(self) -> None:
        ETQLoopStep.index(self.step)
        object.__setattr__(
            self, "input_hashes", tuple(_require_hash(v, "input_hash") for v in self.input_hashes)
        )
        object.__setattr__(self, "outputs", tuple(self.outputs))
        object.__setattr__(
            self, "verification_basis", tuple(str(v) for v in self.verification_basis)
        )
        if not self.authority:
            raise ETQLifecycleError(f"step {self.step} has no authority citation")
        if not self.verification_basis:
            raise ETQLifecycleError(f"step {self.step} has no verification basis")
        if self.refusal_code:
            if self.outputs:
                raise ETQLifecycleError("a refused step cannot also claim produced artifacts")
            if not self.refusal_detail:
                raise ETQLifecycleError("a refused step must state the actionable refusal detail")
            return
        if not self.outputs:
            raise ETQLifecycleError(f"step {self.step} produced no record and declared no refusal")
        permitted = ETQLoopStep.OUTPUT_TYPES[self.step]
        invalid = sorted({a.artifact_type for a in self.outputs if a.artifact_type not in permitted})
        if invalid:
            raise ETQLifecycleError(
                f"step {self.step} produced unregistered artifact types {invalid}; "
                f"expected one of {sorted(permitted)}"
            )
        if self.step == ETQLoopStep.SELECTIVE_REVALIDATION_AND_REPLACEMENT and not any(
            a.artifact_type == "SelectiveRevalidationRecord" for a in self.outputs
        ):
            raise ETQLifecycleError("the final step requires a SelectiveRevalidationRecord")

    @property
    def index(self) -> int:
        return ETQLoopStep.index(self.step)

    @property
    def refused(self) -> bool:
        return self.refusal_code is not None

    def to_canonical(self) -> dict:
        record = {
            "step_index": self.index,
            "step": self.step,
            "input_hashes": list(self.input_hashes),
            "outputs": [a.to_canonical() for a in self.outputs],
            "authority": self.authority,
            "verification_basis": list(self.verification_basis),
        }
        if self.refusal_code:
            record["refusal"] = {"code": self.refusal_code, "detail": self.refusal_detail}
        return record


@dataclass(frozen=True)
class ETQDecisionLoop:
    """An immutable prefix, or completion, of the twelve-step ETQ loop."""

    loop_id: str
    target_decision_id: str
    predicate_id: str
    target_context_hash: str
    declared_stopping_conditions: Tuple[str, ...]
    steps: Tuple[ETQStepRecord, ...] = ()
    schema_version: str = ETQ_LIFECYCLE_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if not self.loop_id or not self.target_decision_id or not self.predicate_id:
            raise ETQLifecycleError("an ETQ loop requires loop, decision, and predicate identities")
        object.__setattr__(
            self, "target_context_hash", _require_hash(self.target_context_hash, "target_context_hash")
        )
        stops = tuple(str(v) for v in self.declared_stopping_conditions)
        if not stops:
            raise ETQLifecycleError("an ETQ loop requires a declared stopping condition (34.5)")
        for condition in stops:
            StoppingCondition.check(condition)
        object.__setattr__(self, "declared_stopping_conditions", stops)
        object.__setattr__(self, "steps", tuple(self.steps))
        self._validate_chain()

    def _validate_chain(self) -> None:
        seen_ids = set()
        seen_hashes = set()
        for expected_index, record in enumerate(self.steps, start=1):
            if record.index != expected_index:
                raise ETQLifecycleError(
                    f"ETQ loop skipped or reordered a step: expected "
                    f"{ETQLoopStep.ORDER[expected_index - 1]}, found {record.step}"
                )
            if expected_index == 1 and record.input_hashes:
                raise ETQLifecycleError("the evidence-authoring step cannot consume an undeclared prior output")
            if expected_index > 1 and not record.refused:
                if not record.input_hashes:
                    raise ETQLifecycleError(f"step {record.step} consumes no prior artifact")
                unknown = sorted(set(record.input_hashes) - seen_hashes)
                if unknown:
                    raise ETQLifecycleError(
                        f"step {record.step} consumes hashes not produced earlier in this loop: {unknown}"
                    )
                immediate = {a.content_hash for a in self.steps[expected_index - 2].outputs}
                if not immediate.intersection(record.input_hashes):
                    raise ETQLifecycleError(
                        f"step {record.step} does not consume the immediately preceding step"
                    )
            duplicate_ids = sorted(a.artifact_id for a in record.outputs if a.artifact_id in seen_ids)
            duplicate_hashes = sorted(a.content_hash for a in record.outputs if a.content_hash in seen_hashes)
            if duplicate_ids or duplicate_hashes:
                raise ETQLifecycleError(
                    "a loop output must be a new immutable artifact; "
                    f"duplicate ids={duplicate_ids}, duplicate hashes={duplicate_hashes}"
                )
            for artifact in record.outputs:
                seen_ids.add(artifact.artifact_id)
                seen_hashes.add(artifact.content_hash)
            if record.refused and expected_index != len(self.steps):
                raise ETQLifecycleError("a loop cannot continue after a fail-closed refusal")

    @property
    def complete(self) -> bool:
        return len(self.steps) == len(ETQLoopStep.ORDER) and not self.steps[-1].refused

    @property
    def refused(self) -> bool:
        return bool(self.steps and self.steps[-1].refused)

    @property
    def next_step(self) -> Optional[str]:
        if self.complete or self.refused:
            return None
        return ETQLoopStep.ORDER[len(self.steps)]

    def append(self, record: ETQStepRecord) -> "ETQDecisionLoop":
        if self.complete:
            raise ETQLifecycleError("the ETQ loop is already complete")
        if self.refused:
            raise ETQLifecycleError("the ETQ loop is fail-closed after its recorded refusal")
        if record.step != self.next_step:
            raise ETQLifecycleError(f"expected next step {self.next_step}, found {record.step}")
        return replace(self, steps=self.steps + (record,))

    def to_canonical(self) -> dict:
        return {
            "record_type": "ETQDecisionLoop",
            "profile": ETQ_LIFECYCLE_PROFILE,
            "schema_version": self.schema_version,
            "loop_id": self.loop_id,
            "target_decision_id": self.target_decision_id,
            "predicate_id": self.predicate_id,
            "target_context_hash": self.target_context_hash,
            "declared_stopping_conditions": list(self.declared_stopping_conditions),
            "steps": [step.to_canonical() for step in self.steps],
            "complete": self.complete,
            "refused": self.refused,
            "next_step": self.next_step,
        }

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())


@dataclass(frozen=True)
class ResultIngestionRecord:
    """Lineage proving that a returned result created, rather than replaced, evidence."""

    ingestion_id: str
    plan_id: str
    experiment_id: str
    result_hash: str
    new_evidence_id: str
    new_evidence_hash: str
    evidence_class: str
    evidence_status: str
    prior_evidence_ids: Tuple[str, ...]
    prior_evidence_hashes: Tuple[str, ...]
    preserved_prior_records: bool = True

    def __post_init__(self) -> None:
        if not self.ingestion_id or not self.plan_id or not self.experiment_id:
            raise ETQLifecycleError("result ingestion requires ingestion, plan, and experiment identities")
        if not self.new_evidence_id:
            raise ETQLifecycleError("result ingestion requires a new evidence identity")
        object.__setattr__(self, "result_hash", _require_hash(self.result_hash, "result_hash"))
        object.__setattr__(
            self, "new_evidence_hash", _require_hash(self.new_evidence_hash, "new_evidence_hash")
        )
        object.__setattr__(
            self,
            "prior_evidence_hashes",
            tuple(_require_hash(v, "prior_evidence_hash") for v in self.prior_evidence_hashes),
        )
        object.__setattr__(
            self, "prior_evidence_ids", tuple(str(v) for v in self.prior_evidence_ids)
        )
        if self.evidence_class not in EvidenceClass.ALL:
            raise ETQLifecycleError(f"unknown ingested evidence class {self.evidence_class!r}")
        if self.evidence_status not in EvidenceStatus.ALL:
            raise ETQLifecycleError(f"unknown ingested evidence status {self.evidence_status!r}")
        if self.new_evidence_id in self.prior_evidence_ids:
            raise ETQLifecycleError("result ingestion must create a new evidence identity")
        if self.new_evidence_hash in self.prior_evidence_hashes:
            raise ETQLifecycleError("result ingestion must create new evidence bytes")
        if not self.preserved_prior_records:
            raise ETQLifecycleError("returned results may not overwrite prior evidence (roadmap 6.4)")

    def to_canonical(self) -> dict:
        return {
            "record_type": "ResultIngestionRecord",
            "profile": ETQ_LIFECYCLE_PROFILE,
            "schema_version": ETQ_LIFECYCLE_SCHEMA_VERSION,
            "ingestion_id": self.ingestion_id,
            "plan_id": self.plan_id,
            "experiment_id": self.experiment_id,
            "result_hash": self.result_hash,
            "new_evidence_id": self.new_evidence_id,
            "new_evidence_hash": self.new_evidence_hash,
            "evidence_class": self.evidence_class,
            "evidence_status": self.evidence_status,
            "prior_evidence_ids": list(self.prior_evidence_ids),
            "prior_evidence_hashes": list(self.prior_evidence_hashes),
            "preserved_prior_records": True,
        }

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())


def ingest_result_as_evidence(
    result: ExperimentResult,
    *,
    ingestion_id: str,
    plan_id: str,
    evidence_id: str,
    method: MethodDescriptor,
    provenance: Provenance,
    validity: ValidityWindow,
    access: AccessPolicy,
    evidence_status: str = EvidenceStatus.PROVISIONAL,
    prior_evidence: Sequence[EvidenceRecord] = (),
) -> Tuple[EvidenceRecord, ResultIngestionRecord]:
    """Create a new provenance-bound evidence record from a completed result.

    The result hash must occur in the caller-supplied provenance chain.  That
    check prevents a generic source citation from being presented as lineage
    to these exact result bytes.
    """
    if result.status != ResultStatus.COMPLETED or result.observed is None:
        raise ETQLifecycleError(
            "only a completed result with an observation can become constraining evidence"
        )
    if result.context is None:
        raise ETQLifecycleError("a returned result has no source context and cannot become evidence")
    result_hash = content_hash(result.to_canonical())
    if result_hash not in provenance.chain:
        raise ETQLifecycleError(
            "result provenance does not commit to the exact returned-result hash"
        )
    prior = tuple(prior_evidence)
    prior_ids = tuple(record.evidence_id for record in prior)
    prior_hashes = tuple(record.fingerprint() for record in prior)
    if len(set(prior_ids)) != len(prior_ids) or len(set(prior_hashes)) != len(prior_hashes):
        raise ETQLifecycleError("prior evidence lineage contains duplicate records")
    evidence = EvidenceRecord(
        evidence_id=evidence_id,
        quantity=result.measurand,
        unit=result.unit,
        value=result.observed,
        uncertainty=result.uncertainty,
        source_context=result.context,
        method=method,
        provenance=provenance,
        validity=validity,
        access=access,
        evidence_status=evidence_status,
        notes=(
            f"created from qualification plan {plan_id}",
            f"returned result {result_hash}",
        ),
    )
    ingestion = ResultIngestionRecord(
        ingestion_id=ingestion_id,
        plan_id=plan_id,
        experiment_id=result.experiment_id,
        result_hash=result_hash,
        new_evidence_id=evidence.evidence_id,
        new_evidence_hash=evidence.fingerprint(),
        evidence_class=method.evidence_class,
        evidence_status=evidence.evidence_status,
        prior_evidence_ids=prior_ids,
        prior_evidence_hashes=prior_hashes,
    )
    return evidence, ingestion


class RevalidationState:
    PENDING = "PENDING_REVALIDATION"
    COMPLETE = "REVALIDATION_COMPLETE"


@dataclass(frozen=True)
class SelectiveRevalidationRecord:
    """Dependency-complete propagation record for specification 35.1."""

    record_id: str
    changed_source: str
    changed_properties: Tuple[str, ...]
    dependency_graph_hash: str
    dependency_completeness_basis: str
    affected: Tuple[Tuple[str, str], ...]
    preserved: Tuple[str, ...]
    replacement_required: Tuple[str, ...]
    state: str = RevalidationState.PENDING

    def __post_init__(self) -> None:
        object.__setattr__(
            self, "changed_properties", tuple(sorted(set(str(v) for v in self.changed_properties)))
        )
        object.__setattr__(
            self, "affected", tuple(sorted((str(item), str(action)) for item, action in self.affected))
        )
        object.__setattr__(self, "preserved", tuple(sorted(set(str(v) for v in self.preserved))))
        object.__setattr__(
            self,
            "replacement_required",
            tuple(sorted(set(str(v) for v in self.replacement_required))),
        )
        object.__setattr__(
            self, "dependency_graph_hash", _require_hash(self.dependency_graph_hash, "dependency_graph_hash")
        )
        if not self.changed_properties:
            raise ETQLifecycleError("selective revalidation requires typed changed properties")
        if not self.dependency_completeness_basis:
            raise ETQLifecycleError(
                "selective revalidation requires a declared dependency completeness basis"
            )
        for _, action in self.affected:
            if action not in Action.SEVERITY:
                raise ETQLifecycleError(f"unknown revalidation action {action!r}")
        if self.state not in {RevalidationState.PENDING, RevalidationState.COMPLETE}:
            raise ETQLifecycleError(f"unknown revalidation state {self.state!r}")
        affected_ids = {artifact_id for artifact_id, _ in self.affected}
        if set(self.preserved).intersection(affected_ids):
            raise ETQLifecycleError("an artifact cannot be both affected and preserved")
        if set(self.replacement_required) - affected_ids:
            raise ETQLifecycleError("replacement requirements must be a subset of affected artifacts")

    def action_for(self, artifact_id: str) -> Optional[str]:
        return dict(self.affected).get(artifact_id)

    def to_canonical(self) -> dict:
        return {
            "record_type": "SelectiveRevalidationRecord",
            "profile": ETQ_LIFECYCLE_PROFILE,
            "schema_version": ETQ_LIFECYCLE_SCHEMA_VERSION,
            "record_id": self.record_id,
            "changed_source": self.changed_source,
            "changed_properties": list(self.changed_properties),
            "dependency_graph_hash": self.dependency_graph_hash,
            "dependency_completeness_basis": self.dependency_completeness_basis,
            "affected": [
                {"artifact_id": artifact_id, "minimum_action": action}
                for artifact_id, action in self.affected
            ],
            "preserved": list(self.preserved),
            "replacement_required": list(self.replacement_required),
            "state": self.state,
        }

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())


@dataclass(frozen=True)
class ReplacementRecord:
    """A new immutable descendant issued after a required revalidation action."""

    replacement_id: str
    revalidation_record_hash: str
    prior_artifact_id: str
    replacement_artifact_id: str
    prior_artifact_hash: str
    replacement_artifact_hash: str
    action_completed: str
    verification_basis: Tuple[str, ...]

    def __post_init__(self) -> None:
        if not self.replacement_id or not self.prior_artifact_id or not self.replacement_artifact_id:
            raise ETQLifecycleError("replacement record requires stable prior and replacement identities")
        object.__setattr__(
            self, "verification_basis", tuple(str(v) for v in self.verification_basis if str(v))
        )
        for name in (
            "revalidation_record_hash",
            "prior_artifact_hash",
            "replacement_artifact_hash",
        ):
            object.__setattr__(self, name, _require_hash(getattr(self, name), name))
        if self.prior_artifact_id == self.replacement_artifact_id:
            raise ETQLifecycleError("a replacement must have a new artifact identity")
        if self.prior_artifact_hash == self.replacement_artifact_hash:
            raise ETQLifecycleError("a replacement must be a new immutable record")
        if self.action_completed not in Action.SEVERITY:
            raise ETQLifecycleError(f"unknown completed action {self.action_completed!r}")
        if not self.verification_basis:
            raise ETQLifecycleError("a replacement record requires verification evidence")

    def to_canonical(self) -> dict:
        return {
            "record_type": "ReplacementRecord",
            "profile": ETQ_LIFECYCLE_PROFILE,
            "schema_version": ETQ_LIFECYCLE_SCHEMA_VERSION,
            "replacement_id": self.replacement_id,
            "revalidation_record_hash": self.revalidation_record_hash,
            "prior_artifact_id": self.prior_artifact_id,
            "replacement_artifact_id": self.replacement_artifact_id,
            "prior_artifact_hash": self.prior_artifact_hash,
            "replacement_artifact_hash": self.replacement_artifact_hash,
            "action_completed": self.action_completed,
            "verification_basis": list(self.verification_basis),
        }

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())


def plan_selective_revalidation(
    *,
    record_id: str,
    changed_source: str,
    changed_properties: Sequence[str],
    dependency_edges: Iterable[DependencyEdge],
    artifact_universe: Sequence[str],
    dependency_completeness_basis: str,
) -> SelectiveRevalidationRecord:
    """Propagate only typed reachable descendants on a complete graph.

    ``artifact_universe`` is the declared universe against which preservation
    is claimed.  Every graph node must be inside it.  This is what makes the
    returned ``preserved`` list a checkable claim instead of the complement of
    whatever partial graph happened to be loaded.
    """
    properties = tuple(sorted(set(str(v) for v in changed_properties if str(v))))
    if not properties:
        raise ETQLifecycleError("changed_properties cannot be empty on a selective path")
    universe = tuple(str(value) for value in artifact_universe)
    if not universe:
        raise ETQLifecycleError("artifact_universe cannot be empty on a selective path")
    if any(not value or value != value.strip() for value in universe):
        raise ETQLifecycleError(
            "artifact_universe must contain normalized non-empty identities"
        )
    if len(set(universe)) != len(universe) or universe != tuple(sorted(universe)):
        raise ETQLifecycleError(
            "artifact_universe must be a unique canonically ordered identity list"
        )
    if changed_source not in universe:
        raise ETQLifecycleError("changed evidence is absent from the declared artifact universe")
    edges = tuple(dependency_edges)
    edge_ids = [edge.edge_id for edge in edges]
    if any(not value or value != value.strip() for value in edge_ids):
        raise ETQLifecycleError("dependency edge identities must be normalized and non-empty")
    if len(set(edge_ids)) != len(edge_ids) or edge_ids != sorted(edge_ids):
        raise ETQLifecycleError(
            "dependency edge identities must be unique and canonically ordered"
        )
    if any(
        not edge.source
        or edge.source != edge.source.strip()
        or not edge.target
        or edge.target != edge.target.strip()
        for edge in edges
    ):
        raise ETQLifecycleError("dependency edge endpoints must be normalized identities")
    graph = DependencyGraph()
    graph.add_edges(edges)
    outside = sorted(graph.nodes - set(universe))
    if outside:
        raise ETQLifecycleError(
            f"dependency graph names artifacts outside the declared complete universe: {outside}"
        )
    if changed_source not in graph.nodes:
        raise ETQLifecycleError(
            "changed evidence is absent from the typed dependency graph; selective preservation "
            "cannot be established"
        )
    if not dependency_completeness_basis:
        raise ETQLifecycleError("a dependency completeness basis is required")
    impact = graph.propagate({changed_source: set(properties)})
    affected = tuple(sorted(impact.items()))
    affected_ids = set(impact)
    preserved = tuple(sorted(set(universe) - affected_ids - {changed_source}))
    graph_hash = content_hash([edge.to_canonical() for edge in sorted(edges, key=lambda e: e.edge_id)])
    return SelectiveRevalidationRecord(
        record_id=record_id,
        changed_source=changed_source,
        changed_properties=properties,
        dependency_graph_hash=graph_hash,
        dependency_completeness_basis=dependency_completeness_basis,
        affected=affected,
        preserved=preserved,
        replacement_required=tuple(artifact_id for artifact_id, _ in affected),
    )


def issue_replacement(
    plan: SelectiveRevalidationRecord,
    *,
    replacement_id: str,
    prior_artifact_id: str,
    replacement_artifact_id: str,
    prior_artifact_hash: str,
    replacement_artifact_hash: str,
    verification_basis: Sequence[str],
) -> ReplacementRecord:
    action = plan.action_for(prior_artifact_id)
    if action is None:
        raise ETQLifecycleError(
            f"artifact {prior_artifact_id!r} was preserved or outside the declared impact; "
            "it cannot be replaced under this revalidation record"
        )
    return ReplacementRecord(
        replacement_id=replacement_id,
        revalidation_record_hash=plan.fingerprint(),
        prior_artifact_id=prior_artifact_id,
        replacement_artifact_id=replacement_artifact_id,
        prior_artifact_hash=prior_artifact_hash,
        replacement_artifact_hash=replacement_artifact_hash,
        action_completed=action,
        verification_basis=tuple(str(v) for v in verification_basis),
    )


class QualificationDispositionState:
    IN_PROGRESS = "IN_PROGRESS"
    QUALIFICATION_COMPLETE = "QUALIFICATION_COMPLETE"
    STOPPED_UNRESOLVED = "STOPPED_UNRESOLVED"
    EVIDENCE_REQUIREMENTS_UNSATISFIED = "EVIDENCE_REQUIREMENTS_UNSATISFIED"


@dataclass(frozen=True)
class QualificationDisposition:
    """Direct campaign disposition; never a synthetic readiness score."""

    plan_id: str
    state: str
    stopping_condition: str
    outcome: str
    evidence_hashes: Tuple[str, ...]
    verification_basis: Tuple[str, ...]
    unmet_requirements: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if self.state not in {
            QualificationDispositionState.IN_PROGRESS,
            QualificationDispositionState.QUALIFICATION_COMPLETE,
            QualificationDispositionState.STOPPED_UNRESOLVED,
            QualificationDispositionState.EVIDENCE_REQUIREMENTS_UNSATISFIED,
        }:
            raise ETQLifecycleError(f"unknown qualification disposition {self.state!r}")
        object.__setattr__(
            self, "evidence_hashes", tuple(_require_hash(v, "evidence_hash") for v in self.evidence_hashes)
        )
        object.__setattr__(
            self, "verification_basis", tuple(str(v) for v in self.verification_basis)
        )
        object.__setattr__(
            self, "unmet_requirements", tuple(str(v) for v in self.unmet_requirements)
        )
        if self.state == QualificationDispositionState.QUALIFICATION_COMPLETE and (
            not self.verification_basis or self.unmet_requirements
        ):
            raise ETQLifecycleError(
                "QUALIFICATION_COMPLETE requires verification evidence and no unmet requirement"
            )

    @property
    def qualification_complete(self) -> bool:
        return self.state == QualificationDispositionState.QUALIFICATION_COMPLETE

    def to_canonical(self) -> dict:
        return {
            "record_type": "QualificationDisposition",
            "profile": ETQ_LIFECYCLE_PROFILE,
            "schema_version": ETQ_LIFECYCLE_SCHEMA_VERSION,
            "plan_id": self.plan_id,
            "state": self.state,
            "stopping_condition": self.stopping_condition,
            "outcome": self.outcome,
            "evidence_hashes": list(self.evidence_hashes),
            "verification_basis": list(self.verification_basis),
            "unmet_requirements": list(self.unmet_requirements),
        }


def qualification_disposition(
    result: QualificationResult,
    *,
    ingestions: Sequence[ResultIngestionRecord],
    required_evidence_ids: Sequence[str],
    verification_basis: Sequence[str],
    minimum_evidence_status: str = EvidenceStatus.QUALIFIED,
) -> QualificationDisposition:
    """Expose ``QUALIFICATION_COMPLETE`` only when stop and evidence both hold."""
    evidence = tuple(ingestions)
    evidence_hashes = tuple(item.new_evidence_hash for item in evidence)
    basis = tuple(str(v) for v in verification_basis if str(v))
    if not result.stopped:
        return QualificationDisposition(
            result.plan_id,
            QualificationDispositionState.IN_PROGRESS,
            result.stopping_reason,
            "the declared stopping rule has not fired",
            evidence_hashes,
            basis,
        )

    resolving = frozenset(
        {
            StoppingCondition.UNIQUE_GUARANTEED_WINNER,
            StoppingCondition.CAPABILITY_ESTABLISHED,
            StoppingCondition.CAPABILITY_RULED_OUT,
            StoppingCondition.REGRET_BELOW_THRESHOLD,
            StoppingCondition.UNCERTAINTY_BELOW_THRESHOLD,
        }
    )
    if result.stopping_reason not in resolving:
        return QualificationDisposition(
            result.plan_id,
            QualificationDispositionState.STOPPED_UNRESOLVED,
            result.stopping_reason,
            result.stopping_detail,
            evidence_hashes,
            basis,
        )

    required = set(str(v) for v in required_evidence_ids)
    present = {item.new_evidence_id for item in evidence}
    unmet = []
    missing = sorted(required - present)
    if missing:
        unmet.append("missing required evidence: " + ", ".join(missing))
    weak = sorted(
        item.new_evidence_id
        for item in evidence
        if not EvidenceStatus.meets(item.evidence_status, minimum_evidence_status)
    )
    if weak:
        unmet.append(
            f"evidence below {minimum_evidence_status}: " + ", ".join(weak)
        )
    nonauthorizing = sorted(
        item.new_evidence_id
        for item in evidence
        if not EvidenceClass.may_authorize(item.evidence_class)
    )
    if nonauthorizing:
        unmet.append("non-authorizing evidence class: " + ", ".join(nonauthorizing))
    if not basis:
        unmet.append("missing verification basis")
    if unmet:
        return QualificationDisposition(
            result.plan_id,
            QualificationDispositionState.EVIDENCE_REQUIREMENTS_UNSATISFIED,
            result.stopping_reason,
            "the stopping condition fired but qualification evidence is incomplete",
            evidence_hashes,
            basis,
            tuple(unmet),
        )
    return QualificationDisposition(
        result.plan_id,
        QualificationDispositionState.QUALIFICATION_COMPLETE,
        result.stopping_reason,
        result.stopping_detail,
        evidence_hashes,
        basis,
    )
