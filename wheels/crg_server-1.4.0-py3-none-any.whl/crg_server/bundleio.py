"""Portable ``.crg`` bundles across the integration surface.

Normative basis: 39 (portable ``.crg`` interchange artifact), 38.1 (import ->
augment -> certify -> verify -> export), 17.6 (a portable bundle may contain
tombstones and the verifier MUST report what can no longer be checked), 6.12
(anti-lock-in), 24.1 (the CRG-VIR program is what an independent verifier
reads), 25.5 (independent implementation).

Export writes the manifest field names ``crg-io`` writes, because ``crg-io``
owns the portable-artifact specification and two producers with two spellings
of one manifest would be an interoperability defect rather than a stylistic
difference.  It adds one section ``crg-io``'s writer does not: the carried
CRG-VIR programs, which 39 lists as a bundle section and 24.1 makes the thing
an independent verifier actually reads.

Import is fail-closed.  A bundle is verified *before* it becomes a case
(``crg_verify.verify_bundle`` at integrity level, which shares no code with
this package), and a bundle whose inventory hashes do not recompute is
rejected rather than imported with a warning.  6.6 and 48.3 both point the
same way: an importer that accepted a tampered artifact and left a note in a
log has already lost.
"""
from __future__ import annotations

import base64
import io
import json
import os
import zipfile
from typing import Any, Dict, List, Mapping, Optional, Tuple

import crg_certify
import crg_io
import crg_verify
from crg_cli.intake import portable_intake_objects
from crg_cli.comparison import (
    portable_comparison_objects,
    render_comparative_evaluation_report,
)
from crg_cli.journey_comparison import (
    portable_journey_comparison_objects,
    render_comparative_change_report,
    render_cumulative_comparison_report,
    verify_comparative_change,
    verify_cumulative_comparison,
)
from crg_cli.challenge import (
    portable_decision_challenge_objects,
    render_decision_challenge_report,
)
from crg_cli.lifecycle import (
    portable_lifecycle_objects,
    render_lifecycle_report,
    verify_lifecycle_record,
)
from crg_cli.store import CaseError
from crg_cli.report import (
    render_certificate_report,
    render_certified_delta_report,
    render_phase_analysis_report,
)
from crg_model.canonical import canonical_json, content_hash
from crg_model.edges import DependencyEdge

from .errors import (
    ConflictError,
    NotFoundError,
    PayloadTooLargeError,
    RedactedError,
    UsageError,
)
from .operations import _case_objects, _verify_delta_document, vir_for

__all__ = [
    "BUNDLE_FORMAT_VERSION",
    "CREATION_TOOL",
    "export_bundle",
    "import_bundle_bytes",
    "verify_bundle_bytes",
]

BUNDLE_FORMAT_VERSION = crg_io.BUNDLE_FORMAT_VERSION
CREATION_TOOL = "crg-server"
CREATION_TOOL_VERSION = "1.4.0"
MAX_BUNDLE_BYTES = 48 * 1024 * 1024
MAX_BUNDLE_MEMBERS = 4096
MAX_DECOMPRESSED_BYTES = 256 * 1024 * 1024
MAX_EXPANSION_RATIO = 100


def export_bundle(
    store: Any,
    case: Mapping[str, Any],
    *,
    authority: str = "",
    level: str = "INDEPENDENT_RECOMPUTATION",
    challenge_records: Optional[Mapping[str, Any]] = None,
) -> Tuple[bytes, Dict[str, Any]]:
    """Serialize a case to a ``.crg`` archive (spec 39).

    Returns ``(archive_bytes, manifest)``.  Nothing is written to disk here:
    the endpoint streams the bytes, and a deployment that wants a file writes
    one.  Superseded certificates travel as provenance (6.4, 17.1) but carry
    no verification program -- they are history, not live claims.  Tombstones
    travel too, because 17.6 requires the bundle verifier to be able to report
    which claims can no longer be independently checked.
    """
    registry = case.get("registry")
    if not registry:
        raise UsageError(
            "nothing to export: this case has no registry",
            remedy="import or generate a candidate family first (38.1)",
        )
    certificates = dict(case.get("certificates") or {})
    objects: Dict[str, Any] = {}

    def _add(object_id: str, payload: Any) -> str:
        digest = content_hash(payload)
        objects[object_id] = payload
        return digest

    registry_hash = _add(str(registry["bundle_id"]), registry)
    # Certified-delta edges name the stable logical objects used by the
    # change classifier.  Export the endpoints so dependency closure is
    # independently resolvable rather than only syntactically present.
    for object_id, logical_object in sorted(_case_objects(case).items()):
        _add(object_id, logical_object)
    for cert_id, certificate in sorted(certificates.items()):
        _add(cert_id, certificate)
    for cert_id, certificate in sorted((case.get("superseded_certificates") or {}).items()):
        _add(cert_id, certificate)
    for delta_id, delta in sorted((case.get("deltas") or {}).items()):
        _add(delta_id, delta)
    for artifact_id, artifact in sorted((case.get("safe_commitments") or {}).items()):
        _add(artifact_id, artifact)
    for analysis_id, artifact in sorted((case.get("phase_analyses") or {}).items()):
        _add(analysis_id, artifact)
    for source_root, source in sorted((case.get("phase_sources") or {}).items()):
        _add(f"phase-source:{source_root}", source)
    for evidence_id, artifact in sorted((case.get("certified_deltas") or {}).items()):
        _add(evidence_id, artifact)
    for evidence_id, inputs in sorted((case.get("certified_delta_inputs") or {}).items()):
        _add(f"delta-inputs:{evidence_id}", inputs)
    # Intake provenance is non-authorizing, but it is part of why this exact
    # imported family exists.  Carry the reviewed mapping, source snapshot,
    # preview, and hash-bound confirmation as ordinary inventory objects in
    # addition to their complete copy in case.json.
    for object_id, record in portable_intake_objects(case).items():
        _add(object_id, record)
    for object_id, record in portable_comparison_objects(case).items():
        _add(object_id, record)
    try:
        journey_comparison_objects = portable_journey_comparison_objects(case)
    except CaseError as error:
        raise UsageError(
            f"journey comparison inventory failed independent verification before export: {error}",
            remedy=(
                "recover the authentic stored comparison and every nested replay-bound "
                "artifact before producing a bundle"
            ),
        ) from error
    for object_id, record in journey_comparison_objects.items():
        _add(object_id, record)
    for object_id, record in portable_decision_challenge_objects(
        challenge_records or {}
    ).items():
        _add(object_id, record)
    # v1.3 ETQ and v1.4 decision/resilience records carry their exact replay
    # inputs and immutable predecessor versions as first-class bundle objects.
    # Snapshot companions are accepted only when their exact roots are bound
    # by an independently verified BackupRestoreRecoveryRecord.
    try:
        lifecycle_objects = portable_lifecycle_objects(case)
    except CaseError as error:
        raise UsageError(
            f"lifecycle inventory failed independent verification before export: {error}",
            remedy=(
                "recover the authentic record, exact replay envelope, and hash-bound "
                "portable snapshot companions before producing a bundle"
            ),
        ) from error
    for object_id, record in lifecycle_objects.items():
        _add(object_id, record)
    for name in ("R", "GAMMA", "K"):
        if name in (case.get("geometry") or {}):
            geometry = case["geometry"][name]
            geometry_id = str(geometry.get("root_hash") or f"geometry-{name}")
            _add(geometry_id, geometry)
    edge_rows = store.edges_for(str(case.get("case_id") or ""))
    # Content-addressed dependency edges can point to the predecessor
    # registry/certificate even after a successor case supersedes them.  The
    # content store still owns those immutable endpoint objects; carry them so
    # the exported graph remains closed and independently resolvable.
    for row in edge_rows:
        for endpoint in (str(row["source"]), str(row["target"])):
            if not endpoint.startswith("sha256:"):
                continue
            try:
                endpoint_object = store.get_object(endpoint)
            except (NotFoundError, RedactedError):
                continue
            _add(endpoint, endpoint_object)
    for row in edge_rows:
        edge = DependencyEdge(
            edge_id=str(row["edge_id"]),
            source=str(row["source"]),
            target=str(row["target"]),
            edge_type=str(row["edge_type"]),
            scope=str(row.get("scope") or "") or None,
        )
        _add(f"dependency-edge:{edge.edge_id}", edge.to_canonical())
    migration_records: Dict[str, Mapping[str, Any]] = {}
    for record in list(case.get("migrations") or []) + list(case.get("migration_records") or []):
        if isinstance(record, Mapping) and record.get("migration_id"):
            migration_records[str(record["migration_id"])] = record
    if isinstance(case.get("migration_record"), Mapping):
        record = case["migration_record"]
        if record.get("migration_id"):
            migration_records[str(record["migration_id"])] = record
    for migration_id, record in sorted(migration_records.items()):
        _add(migration_id, record)

    tombstones = store.tombstones()
    programs: Dict[str, Dict[str, Any]] = {}
    reports: Dict[str, str] = {}
    for cert_id, certificate in sorted(certificates.items()):
        program = vir_for(case, certificate)
        programs[str(program["program_id"])] = dict(program)
        reports[cert_id] = render_certificate_report(certificate)
    for analysis_id, analysis in sorted((case.get("phase_analyses") or {}).items()):
        source = (case.get("phase_sources") or {}).get(analysis.get("source_r_root"))
        if not isinstance(source, Mapping):
            raise UsageError(
                f"phase analysis {analysis_id!r} lacks its portable source R",
                remedy="recover the authentic analysis source before exporting",
            )
        verification = crg_verify.verify_phase_analysis_record(analysis, source)
        if not verification.ok:
            raise UsageError(
                f"phase analysis {analysis_id!r} failed independent reconstruction",
                remedy="recover the authentic analysis before exporting",
            )
        reports[f"phase-analysis:{analysis_id}"] = render_phase_analysis_report(
            analysis, verification
        )
    for evidence_id, delta_record in sorted(
        (case.get("certified_deltas") or {}).items()
    ):
        inputs = (case.get("certified_delta_inputs") or {}).get(evidence_id)
        if not isinstance(inputs, Mapping):
            raise UsageError(
                f"certified delta {evidence_id!r} lacks portable verification inputs",
                remedy="recover the authentic delta evidence before exporting",
            )
        verification = _verify_delta_document(delta_record, inputs)
        if not verification.ok:
            raise UsageError(
                f"certified delta {evidence_id!r} failed independent reconstruction",
                remedy="recover the authentic delta evidence before exporting",
            )
        reports[f"certified-delta:{evidence_id}"] = render_certified_delta_report(
            delta_record, verification
        )
    for evaluation_id, evaluation in sorted(
        (case.get("comparative_evaluations") or {}).items()
    ):
        verification = crg_verify.verify_comparative_workflow_evaluation(evaluation)
        if not verification.ok:
            raise UsageError(
                f"comparative evaluation {evaluation_id!r} failed independent "
                "reconstruction during export",
                remedy="recover the authentic record before producing a portable bundle",
            )
        reports[f"comparative-evaluation:{evaluation_id}"] = (
            render_comparative_evaluation_report(evaluation, verification)
        )
    for comparison_id, record in sorted(
        (case.get("comparative_change_evidence") or {}).items()
    ):
        try:
            verification = verify_comparative_change(record)
        except CaseError as error:
            raise UsageError(
                f"comparative change {comparison_id!r} failed independent reconstruction",
                remedy="recover the authentic record before producing a portable bundle",
            ) from error
        reports[f"comparative-change:{comparison_id}"] = (
            render_comparative_change_report(record, verification)
        )
    for journey_id, record in sorted(
        (case.get("cumulative_lifecycle_comparisons") or {}).items()
    ):
        try:
            verification = verify_cumulative_comparison(record)
        except CaseError as error:
            raise UsageError(
                f"cumulative lifecycle comparison {journey_id!r} failed independent reconstruction",
                remedy=(
                    "recover all ten authentic artifacts and their exact lifecycle replay "
                    "inputs before producing a portable bundle"
                ),
            ) from error
        reports[f"cumulative-lifecycle-comparison:{journey_id}"] = (
            render_cumulative_comparison_report(record, verification)
        )
    for challenge_id, challenge in sorted((challenge_records or {}).items()):
        verification = crg_verify.verify_decision_challenge_record(challenge)
        if not verification.ok:
            raise UsageError(
                f"Decision Challenge {challenge_id!r} failed independent replay during export",
                remedy="recover the authentic non-authorizing record before exporting",
            )
        reports[f"decision-challenge:{challenge_id}"] = (
            render_decision_challenge_report(challenge, verification)
        )
    lifecycle_inputs = case.get("lifecycle_verification_inputs") or {}
    for record_type, by_id in sorted((case.get("lifecycle_records") or {}).items()):
        if not isinstance(by_id, Mapping):
            continue
        for record_id, record in sorted(by_id.items()):
            inputs = (lifecycle_inputs.get(record_type) or {}).get(record_id)
            if not isinstance(record, Mapping) or not isinstance(inputs, Mapping):
                raise UsageError(
                    f"lifecycle {record_type} {record_id!r} lacks portable replay inputs",
                    remedy="recover the authentic record and its independently verified input envelope",
                )
            verification = verify_lifecycle_record(record, inputs)
            reports[f"lifecycle:{record_type}:{record_id}"] = render_lifecycle_report(
                record, verification
            )

    buffer = io.BytesIO()
    crg_io.write_bundle(
        buffer,
        case=case,
        objects=objects,
        verification_programs=programs,
        reports=reports,
        manifest_metadata={
            "crg_spec_version": "0.2.0",
            "schema_identities": [
                {"schema_id": "coordinate-schema",
                 "schema_hash": content_hash(registry["schema"]),
                 "schema_version": str(registry.get("schema_version", "0.2.0")),
                 "referenced_by": str(registry["bundle_id"])}
            ],
            "quantity_registry_version": "0.2.0",
            "rule_table_version": crg_certify.MAPPING_TABLE_VERSION,
            "signatures": [],
            "encryption": {
                "protected_content_present": False,
                "encrypted_objects": [],
                "claims_depending_on_protected_content": [],
                "verifier_capabilities_required": [],
                "independently_checkable": True,
            },
            "redaction_state": {
                "redacted_objects": [t["content_hash"] for t in tombstones],
                "tombstones": tombstones,
            },
            "export_authority": {
                "authority": authority or "unattested",
                "basis": "declared by the exporting caller" if authority
                else "no export authority was declared",
            },
            "requested_verification_level": level,
        },
    )
    data = buffer.getvalue()
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        manifest = json.loads(archive.read("manifest.json").decode("utf-8"))
    manifest["registry_hash"] = registry_hash
    return data, manifest


def _archive_bytes(request: Mapping[str, Any]) -> bytes:
    if request.get("bundle_base64"):
        encoded = str(request["bundle_base64"])
        if len(encoded) > ((MAX_BUNDLE_BYTES + 2) // 3) * 4:
            raise PayloadTooLargeError(
                "the encoded bundle exceeds the deployment bundle limit",
                remedy=f"supply a .crg artifact no larger than {MAX_BUNDLE_BYTES} bytes",
            )
        try:
            data = base64.b64decode(encoded, validate=True)
        except Exception as error:  # noqa: BLE001
            raise UsageError(f"bundle_base64 is not valid base64: {error}") from None
        if len(data) > MAX_BUNDLE_BYTES:
            raise PayloadTooLargeError(
                f"the decoded bundle is {len(data)} bytes; limit is {MAX_BUNDLE_BYTES}",
                remedy="split the case or use an explicitly configured larger deployment limit",
            )
        return data
    raise UsageError(
        "a bundle import needs the artifact",
        remedy="POST {'bundle_base64': ...}; remote callers may not name server-local paths",
    )


def _require_bounded_archive(data: bytes) -> None:
    """Reject ZIP bombs before any member is decompressed or persisted."""
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            members = archive.infolist()
    except (zipfile.BadZipFile, OSError) as error:
        raise UsageError(f"the supplied bytes are not a readable .crg archive: {error}") from None
    if len(members) > MAX_BUNDLE_MEMBERS:
        raise PayloadTooLargeError(
            f"bundle has {len(members)} members; limit is {MAX_BUNDLE_MEMBERS}",
            remedy="remove undeclared payloads or split the case",
        )
    total_uncompressed = sum(info.file_size for info in members)
    total_compressed = sum(max(info.compress_size, 1) for info in members)
    if total_uncompressed > MAX_DECOMPRESSED_BYTES:
        raise PayloadTooLargeError(
            f"bundle expands to {total_uncompressed} bytes; limit is {MAX_DECOMPRESSED_BYTES}",
            remedy="remove oversized artifacts or use an explicitly reviewed larger profile",
        )
    if total_uncompressed > total_compressed * MAX_EXPANSION_RATIO:
        raise PayloadTooLargeError(
            "bundle compression ratio exceeds the anti-expansion limit",
            remedy="repackage without pathological compression or use a reviewed artifact channel",
        )


def verify_bundle_bytes(
    data: bytes, *, level: str = "V3", clock: Optional[str] = None,
    clock_source: str = "none-supplied", workdir: Optional[str] = None,
    federation_context: Optional[dict] = None,
    extension_registry: Optional[Any] = None,
) -> Any:
    """Run the independent verifier over bundle bytes (spec 25, 39).

    The bytes are materialized to a temporary file because
    ``crg_verify.verify_bundle`` takes a path, and it takes a path because it
    is meant to be usable against an artifact that arrived by any means at
    all -- including one this process never produced (25.5).
    """
    import tempfile

    directory = workdir or tempfile.mkdtemp(prefix="crg-bundle-")
    path = os.path.join(directory, "bundle.crg")
    with open(path, "wb") as handle:
        handle.write(data)
    return crg_verify.verify_bundle(
        path, clock=clock, clock_source=clock_source, level=level,
        federation_context=federation_context, extension_registry=extension_registry,
    )


def import_bundle_bytes(
    store: Any, request: Mapping[str, Any], *, created_by: str = "crg-server"
) -> Dict[str, Any]:
    """Verify, then import, a portable bundle (spec 39, 38.1, 6.6).

    The order is the point.  Integrity is checked by ``crg_verify`` -- which
    imports no kernel module -- before a single object enters this store, so a
    tampered artifact is refused rather than quarantined.  17.6: any tombstone
    the bundle carries is imported as a tombstone, and the claims it makes
    uncheckable are reported.
    """
    data = _archive_bytes(request)
    _require_bounded_archive(data)
    result = verify_bundle_bytes(data, level="V0")
    if not result.ok:
        raise ConflictError(
            "the bundle failed integrity verification and was not imported",
            remedy=(
                "39.1: every inventory hash must recompute from the bytes actually stored; "
                "re-export from the producing system"
            ),
            detail={"violations": list(result.violations)[:8], "status": result.status},
        )

    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        names = set(archive.namelist())
        if "case.json" not in names:
            raise UsageError("the bundle carries no case.json (39.1)")
        case = json.loads(archive.read("case.json").decode("utf-8"))
        manifest = json.loads(archive.read("manifest.json").decode("utf-8"))
        objects: List[Tuple[str, Any]] = []
        for entry in manifest.get("object_inventory") or ():
            path = str(entry.get("path") or "")
            if path in names:
                objects.append((str(entry.get("object_id")), json.loads(
                    archive.read(path).decode("utf-8")
                )))

    requested_id = str(request.get("case_id") or case.get("case_id") or "imported-case")
    case_id = requested_id
    suffix = 1
    while store.case_exists(case_id):
        suffix += 1
        case_id = f"{requested_id}-{suffix}"
    case = dict(case)
    case["case_id"] = case_id
    case["imported_from"] = {
        "bundle_manifest_hash": content_hash(manifest),
        "original_case_id": requested_id,
        "creation_tool": manifest.get("creation_tool"),
    }
    case.setdefault("history", []).append(
        {"command": "bundle import", "manifest_hash": content_hash(manifest)}
    )
    # 17.2 and 17.6 together.  An object this store has already redacted is
    # not resurrected by arriving inside a bundle -- removal was an authorized
    # act and an import is not that authority -- and the fact is *reported*
    # rather than swallowed, because 17.6 requires the bundle verifier to say
    # which claims can no longer be independently checked.
    hashes: List[str] = []
    refused_redacted: List[str] = []
    for _object_id, payload in objects:
        digest = content_hash(payload)
        if store.is_redacted(digest):
            refused_redacted.append(digest)
            continue
        hashes.append(store.put_object(payload, created_by=created_by))
    store.put_case(case, created_by=created_by)

    tombstones = list((manifest.get("redaction_state") or {}).get("tombstones") or ())
    return {
        "case_id": case_id,
        "objects_imported": len(hashes),
        "object_hashes": hashes,
        "manifest_hash": content_hash(manifest),
        "integrity_status": result.status,
        "tombstones": tombstones,
        "refused_as_redacted": refused_redacted,
        "unverifiable_claims": sorted(
            {str(t.get("content_hash")) for t in tombstones} | set(refused_redacted)
        ),
        "certificates": sorted(case.get("certificates") or {}),
    }
