"""Selective revalidation over the typed dependency graph.

Normative basis: master specification 35.1 (a changed evidence record
invalidates only reachable descendants whose edge semantics indicate
dependence on the changed property; certificates outside the affected
subgraph remain valid), 18 (typed dependency edges), and 18.5 (traverse
only reachable affected descendants; preserve unaffected certificates).

Propagation itself is :meth:`crg_model.edges.DependencyGraph.propagate`,
which already implements the two conditions 35.1 turns on: *reachability*
and *edge semantics matching the changed property*.  An edge whose
``source_property`` names a property the change did not touch does not
fire, and an untyped edge is not admissible in the first place (18.1).

What this module adds is the bookkeeping 35.1 requires on top: splitting
certificates and envelopes into the invalidated and the preserved, and
saying which of the two by name.  The preserved list is the point.  An
implementation that quietly re-derived everything would be *correct* and
useless; 35.1 exists so that an evidence correction on one branch does not
force a federation partner to re-verify an unrelated one.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Set, Tuple

from crg_model.canonical import content_hash
from crg_model.edges import Action, DependencyEdge, DependencyGraph, EDGE_SEMANTICS

from .envelope import CapabilityEnvelope
from .revocation import RevocationRegistry

__all__ = [
    "RevalidationError",
    "RevalidationReport",
    "selective_revalidation",
]


class RevalidationError(ValueError):
    """Raised when a revalidation request is malformed."""


def _dependency_ids(item: Any) -> Set[str]:
    """Every object identity an artifact rests on."""
    if item is None:
        return set()
    if isinstance(item, str):
        return {item}
    if isinstance(item, CapabilityEnvelope):
        return {
            item.envelope_id,
            item.evidence_root,
            item.rule_identity.rule_id,
            item.rule_identity.versioned_id,
            item.target_context_fingerprint,
        }
    if isinstance(item, Mapping):
        found: Set[str] = set()
        for key in ("dependencies", "evidence_roots", "objects", "inputs"):
            found.update(str(d) for d in item.get(key, ()) or ())
        return found
    if isinstance(item, (list, tuple, set, frozenset)):
        return {str(d) for d in item}
    found = set()
    for key in ("dependencies", "evidence_roots"):
        found.update(str(d) for d in getattr(item, key, ()) or ())
    return found


@dataclass(frozen=True)
class RevalidationReport:
    """What a change touched, and -- as importantly -- what it did not (35.1)."""

    changed: Tuple[Tuple[str, Tuple[str, ...]], ...]
    impact: Tuple[Tuple[str, str], ...]
    invalidated_certificates: Tuple[str, ...]
    preserved_certificates: Tuple[str, ...]
    invalidated_envelopes: Tuple[str, ...]
    preserved_envelopes: Tuple[str, ...]
    revoked_envelopes: Tuple[str, ...] = ()
    untouched_objects: Tuple[str, ...] = ()
    basis: Tuple[str, ...] = ()

    @property
    def affected_objects(self) -> Tuple[str, ...]:
        return tuple(name for name, _ in self.impact)

    def action_for(self, object_id: str) -> str:
        for name, action in self.impact:
            if name == object_id:
                return action
        return Action.NO_OPERATION

    def preserves(self, certificate_id: str) -> bool:
        return certificate_id in self.preserved_certificates

    def to_canonical(self) -> dict:
        return {
            "changed": {name: list(props) for name, props in self.changed},
            "impact": {name: action for name, action in self.impact},
            "invalidated_certificates": list(self.invalidated_certificates),
            "preserved_certificates": list(self.preserved_certificates),
            "invalidated_envelopes": list(self.invalidated_envelopes),
            "preserved_envelopes": list(self.preserved_envelopes),
            "revoked_envelopes": list(self.revoked_envelopes),
            "untouched_objects": list(self.untouched_objects),
            "basis": list(self.basis),
        }

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())

    def render(self, width: int = 88) -> str:  # pragma: no cover - display only
        lines = ["=" * width, "SELECTIVE REVALIDATION (spec 35.1)", "=" * width]
        for name, props in self.changed:
            lines.append(f"changed  {name}: {', '.join(props) or '(unspecified)'}")
        lines.append("")
        for name, action in self.impact:
            lines.append(f"affected {name:<28} -> {action}")
        lines += [
            "",
            f"certificates invalidated : {', '.join(self.invalidated_certificates) or '(none)'}",
            f"certificates preserved   : {', '.join(self.preserved_certificates) or '(none)'}",
            f"envelopes invalidated    : {', '.join(self.invalidated_envelopes) or '(none)'}",
            f"envelopes preserved      : {', '.join(self.preserved_envelopes) or '(none)'}",
        ]
        return "\n".join(lines)


def selective_revalidation(
    graph: DependencyGraph,
    changed: Mapping[str, Optional[Iterable[str]]],
    *,
    certificates: Any = (),
    envelopes: Sequence[CapabilityEnvelope] = (),
    revoke_invalidated: Optional[RevocationRegistry] = None,
) -> RevalidationReport:
    """Propagate a change and split the affected from the preserved (35.1).

    ``changed`` maps a changed object's identity to the set of properties
    that changed; ``None`` means "changed in an unspecified way", which
    conservatively fires every outgoing edge (30.4).  Naming the properties
    is what makes revalidation *selective*: an edge declaring
    ``source_property="value"`` does not fire when only the access policy
    moved.

    ``certificates`` maps certificate identity to its dependencies (or is an
    iterable of certificates exposing ``certificate_id`` and
    ``dependencies``).  A certificate is invalidated when it, or anything it
    depends on, is in the affected subgraph; every other certificate is
    preserved and is listed as such.

    Passing ``revoke_invalidated`` additionally revokes the envelopes that
    fell inside the affected subgraph, which is how 35.1 and 35.2 meet: an
    envelope resting on superseded evidence must stop verifying.
    """
    if not isinstance(graph, DependencyGraph):
        raise RevalidationError("selective_revalidation requires a DependencyGraph (spec 18)")

    normalized: Dict[str, Optional[Set[str]]] = {}
    changed_record: List[Tuple[str, Tuple[str, ...]]] = []
    for object_id, properties in (changed or {}).items():
        if properties is None:
            normalized[str(object_id)] = None
            changed_record.append((str(object_id), ()))
        else:
            props = {str(p) for p in properties}
            normalized[str(object_id)] = props
            changed_record.append((str(object_id), tuple(sorted(props))))

    # The affected set is exactly what typed propagation reached.  The changed
    # objects themselves are *changed*, not *invalidated*: 35.1 invalidates a
    # descendant only where an edge's semantics indicate dependence on the
    # changed property, so an artifact that merely names a changed object in an
    # untyped dependency list is not thereby invalid (18.1).  An artifact whose
    # own identity was changed is, of course, another matter.
    impact = graph.propagate(normalized)
    affected = set(impact)
    directly_changed = set(normalized)

    cert_items = _certificate_items(certificates)
    invalidated_certs: List[str] = []
    preserved_certs: List[str] = []
    for cert_id, cert in cert_items:
        dependencies = _dependency_ids(cert) | {cert_id}
        if (dependencies & affected) or cert_id in directly_changed:
            invalidated_certs.append(cert_id)
        else:
            preserved_certs.append(cert_id)

    invalidated_envelopes: List[str] = []
    preserved_envelopes: List[str] = []
    for envelope in envelopes or ():
        identities = _dependency_ids(envelope)
        if (identities & affected) or envelope.envelope_id in directly_changed:
            invalidated_envelopes.append(envelope.envelope_id)
        else:
            preserved_envelopes.append(envelope.envelope_id)

    revoked: List[str] = []
    if revoke_invalidated is not None:
        for envelope_id in invalidated_envelopes:
            revoke_invalidated.revoke(
                envelope_id,
                reason=(
                    "selective revalidation: the envelope depends on a changed property "
                    "of a changed object (spec 35.1)"
                ),
            )
            revoked.append(envelope_id)

    untouched = tuple(sorted(graph.nodes - affected - directly_changed))

    return RevalidationReport(
        changed=tuple(sorted(changed_record)),
        impact=tuple(sorted(impact.items())),
        invalidated_certificates=tuple(sorted(invalidated_certs)),
        preserved_certificates=tuple(sorted(preserved_certs)),
        invalidated_envelopes=tuple(sorted(invalidated_envelopes)),
        preserved_envelopes=tuple(sorted(preserved_envelopes)),
        revoked_envelopes=tuple(sorted(revoked)),
        untouched_objects=untouched,
        basis=(
            "spec 35.1: only reachable descendants whose edge semantics indicate "
            "dependence on the changed property are invalidated",
            "spec 18.5: traversal visits only reachable affected descendants and "
            "unaffected certificates and proof objects are preserved",
            "spec 18.1: an untyped depends_on edge is insufficient for "
            "certificate-authorizing behaviour, so every edge here is typed",
        ),
    )


def _certificate_items(certificates: Any) -> List[Tuple[str, Any]]:
    if not certificates:
        return []
    if isinstance(certificates, Mapping):
        return [(str(k), v) for k, v in certificates.items()]
    items: List[Tuple[str, Any]] = []
    for cert in certificates:
        cert_id = getattr(cert, "certificate_id", None)
        if cert_id is None and isinstance(cert, Mapping):
            cert_id = cert.get("certificate_id")
        if cert_id is None:
            raise RevalidationError(
                "a certificate without a certificate_id cannot be tracked through "
                "selective revalidation (spec 29.5)"
            )
        items.append((str(cert_id), cert))
    return items
