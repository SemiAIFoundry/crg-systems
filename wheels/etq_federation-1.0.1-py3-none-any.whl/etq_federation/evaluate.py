"""Confidential evaluation of a capability predicate against an envelope.

Normative basis: master specification 35.3 (permitted outputs and the
minimum-information default), 35.4 (fail-closed denial and the honest scope
of attestation), 22.3 (guaranteed versus possible comparison), and 6.6
(fail closed).

The security property of this module is a *default*, so it is worth stating
plainly: :func:`evaluate_private` called without a requested release kind
releases the minimum the policy authorizes, not the most useful thing it
could.  A policy that authorizes a Boolean, a quantized margin, and the
bounded interval releases a Boolean.  Asking for more is possible and is
checked against the policy; forgetting to ask never widens disclosure.

Fail-closed behaviour is total.  If :func:`etq_federation.verify.verify_envelope`
denies for any of the nine reasons of 35.4, the release kind collapses to
``NO_RESULT`` and every value field is ``None`` -- not a ``False``, which a
consumer could misread as "ruled out".

Boolean releases carry their own semantics.  ``boolean`` is true only when
the predicate is *guaranteed*; ``False`` covers both "ruled out" and "still
undecided", and :attr:`PrivateEvaluationResult.boolean_semantics` says so,
because a bit that conflates refutation with ignorance is the most
dangerous thing this module could hand out silently.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from fractions import Fraction
from typing import Any, Dict, Optional, Sequence, Tuple

from crg_model.canonical import content_hash
from crg_model.numeric import Exact, Interval
from etq_evidence import Requester, VerificationClock

from .envelope import CapabilityEnvelope
from .policy import PolicyError, ReleaseKind, ReleasePolicy
from .signing import ATTESTATION_SCOPE_STATEMENT, AttestationRecord
from .verify import (
    Denial,
    DenialReason,
    CheckName,
    VerificationOutcome,
    VerifierExpectations,
    verify_envelope,
)

__all__ = [
    "EvaluationError",
    "CapabilityState",
    "CapabilityQuery",
    "PrivateEvaluationResult",
    "BOOLEAN_SEMANTICS",
    "evaluate_private",
]


class EvaluationError(ValueError):
    """Raised when a confidential-evaluation request is malformed."""


class CapabilityState:
    """Guaranteed, possible, or ruled out (35.3, 22.3)."""

    GUARANTEED = "GUARANTEED"
    POSSIBLE = "POSSIBLE"
    RULED_OUT = "RULED_OUT"

    ALL = frozenset({GUARANTEED, POSSIBLE, RULED_OUT})


BOOLEAN_SEMANTICS = (
    "GUARANTEED_TRUE_ONLY: true means the predicate holds over the whole declared "
    "enclosure.  False means it is not guaranteed, which covers both RULED_OUT and "
    "POSSIBLE -- a Boolean release cannot distinguish refutation from remaining "
    "ambiguity, and a consumer MUST NOT read False as a refutation (spec 35.3, 22.3)."
)

_RELATIONS = (">=", ">", "<=", "<")


@dataclass(frozen=True)
class CapabilityQuery:
    """A predicate asked of a bounded coordinate without revealing the bound.

    ``tolerance`` is a declared policy slack applied to the threshold (22.1
    keeps policy tolerance separate from numerical and evidence
    uncertainty); it defaults to zero, which is the only value that needs no
    justification.
    """

    query_id: str
    coordinate_id: str
    relation: str
    threshold: Exact
    tolerance: Exact = Exact(0)
    basis: str = ""

    def __init__(
        self,
        query_id: str,
        coordinate_id: str,
        relation: str,
        threshold: Any,
        tolerance: Any = 0,
        basis: str = "",
    ) -> None:
        if relation not in _RELATIONS:
            raise EvaluationError(
                f"unknown relation {relation!r}; expected one of {', '.join(_RELATIONS)}"
            )
        tol = Exact(tolerance)
        if tol < Exact(0):
            raise EvaluationError("policy tolerance must be non-negative (spec 22.1)")
        object.__setattr__(self, "query_id", str(query_id))
        object.__setattr__(self, "coordinate_id", str(coordinate_id))
        object.__setattr__(self, "relation", relation)
        object.__setattr__(self, "threshold", Exact(threshold))
        object.__setattr__(self, "tolerance", tol)
        object.__setattr__(self, "basis", str(basis))

    @property
    def effective_threshold(self) -> Exact:
        """The threshold with the declared policy slack applied."""
        if self.relation in (">=", ">"):
            return self.threshold - self.tolerance
        return self.threshold + self.tolerance

    def evaluate(self, bound: Interval) -> str:
        """Guaranteed / possible / ruled out over an exact enclosure (22.3)."""
        t = self.effective_threshold
        if self.relation == ">=":
            if bound.lo >= t:
                return CapabilityState.GUARANTEED
            if bound.hi < t:
                return CapabilityState.RULED_OUT
        elif self.relation == ">":
            if bound.lo > t:
                return CapabilityState.GUARANTEED
            if bound.hi <= t:
                return CapabilityState.RULED_OUT
        elif self.relation == "<=":
            if bound.hi <= t:
                return CapabilityState.GUARANTEED
            if bound.lo > t:
                return CapabilityState.RULED_OUT
        else:  # "<"
            if bound.hi < t:
                return CapabilityState.GUARANTEED
            if bound.lo >= t:
                return CapabilityState.RULED_OUT
        return CapabilityState.POSSIBLE

    def guaranteed_margin(self, bound: Interval) -> Exact:
        """The worst-case slack: non-negative exactly when the answer is guaranteed."""
        t = self.effective_threshold
        if self.relation in (">=", ">"):
            return bound.lo - t
        return t - bound.hi

    def to_canonical(self) -> dict:
        record: dict = {
            "query_id": self.query_id,
            "coordinate_id": self.coordinate_id,
            "relation": self.relation,
            "threshold": self.threshold.to_canonical(),
            "tolerance": self.tolerance.to_canonical(),
        }
        if self.basis:
            record["basis"] = self.basis
        return record


@dataclass(frozen=True)
class PrivateEvaluationResult:
    """The result of a confidential evaluation (35.3), with its limits attached.

    Only the fields the released kind authorizes are populated; every other
    value field is ``None``.  ``attestation_scope``, ``attestation_proves``
    and ``attestation_does_not_prove`` travel with the answer so that a
    consumer holding only this object still cannot read more into it than
    35.4 permits.
    """

    envelope_id: str
    query_id: str
    coordinate_id: str
    release_kind: str
    released: bool
    boolean: Optional[bool] = None
    boolean_semantics: Optional[str] = None
    state: Optional[str] = None
    ambiguity_detail: Optional[str] = None
    quantized_margin: Optional[Exact] = None
    quantization_step: Optional[Exact] = None
    interval: Optional[Interval] = None
    unit: Optional[str] = None
    denials: Tuple[Denial, ...] = ()
    verification: Optional[VerificationOutcome] = None
    effective_policy: Optional[ReleasePolicy] = None
    requested_kind: Optional[str] = None
    attestation_scope: str = ATTESTATION_SCOPE_STATEMENT
    attestation_proves: Tuple[str, ...] = ()
    attestation_does_not_prove: Tuple[str, ...] = ()
    signature_profile: str = "UNSIGNED"
    release_basis: str = ""
    warnings: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        ReleaseKind.check(self.release_kind)
        if self.state is not None and self.state not in CapabilityState.ALL:
            raise EvaluationError(f"unknown capability state {self.state!r}")

    def reasons(self) -> Tuple[str, ...]:
        ordered = sorted(
            {d.reason for d in self.denials}, key=lambda r: DenialReason.ORDER.index(r)
        )
        return tuple(ordered)

    @property
    def affirmative(self) -> bool:
        """True only for an actually-released guaranteed answer.

        A denied evaluation is never affirmative, and neither is a released
        ``BOOLEAN`` that came back false.
        """
        if not self.released:
            return False
        if self.release_kind == ReleaseKind.BOOLEAN:
            return bool(self.boolean)
        if self.state is not None:
            return self.state == CapabilityState.GUARANTEED
        return self.release_kind in ReleaseKind.AFFIRMATIVE_CAPABLE

    @property
    def information_level(self) -> int:
        return ReleaseKind.information_level(self.release_kind)

    def to_canonical(self) -> dict:
        record: dict = {
            "envelope_id": self.envelope_id,
            "query_id": self.query_id,
            "coordinate_id": self.coordinate_id,
            "release_kind": self.release_kind,
            "released": self.released,
            "affirmative": self.affirmative,
            "denials": [d.to_canonical() for d in self.denials],
            "reasons": list(self.reasons()),
            "attestation_scope": self.attestation_scope,
            "attestation_proves": list(self.attestation_proves),
            "attestation_does_not_prove": list(self.attestation_does_not_prove),
            "signature_profile": self.signature_profile,
            "release_basis": self.release_basis,
            "warnings": list(self.warnings),
        }
        if self.boolean is not None:
            record["boolean"] = self.boolean
            record["boolean_semantics"] = self.boolean_semantics
        if self.state is not None:
            record["state"] = self.state
        if self.ambiguity_detail is not None:
            record["ambiguity_detail"] = self.ambiguity_detail
        if self.quantized_margin is not None:
            record["quantized_margin"] = self.quantized_margin.to_canonical()
            record["quantization_step"] = self.quantization_step.to_canonical()
        if self.interval is not None:
            record["interval"] = self.interval.to_canonical()
        if self.unit is not None:
            record["unit"] = self.unit
        if self.requested_kind is not None:
            record["requested_kind"] = self.requested_kind
        if self.effective_policy is not None:
            record["effective_policy"] = self.effective_policy.to_canonical()
        if self.verification is not None:
            record["verification"] = self.verification.to_canonical()
        return record

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())


def _quantize(margin: Exact, step: Exact) -> Exact:
    """Floor ``margin`` to a multiple of ``step``.

    Flooring (toward minus infinity) is uniformly conservative for a
    capability claim: a positive margin is under-reported, and a negative
    one is not made to look smaller than it is.
    """
    quotient = margin.value / step.value
    floored = Fraction(quotient.numerator // quotient.denominator)
    return Exact(floored * step.value)


def evaluate_private(
    envelope: CapabilityEnvelope,
    predicate: CapabilityQuery,
    *,
    release_policy: Optional[ReleasePolicy] = None,
    clock: Optional[VerificationClock] = None,
    seen_nonces: Any = None,
    requested_kind: Optional[str] = None,
    keys: Any = None,
    revocations: Any = None,
    expectations: Optional[VerifierExpectations] = None,
    attestation: Optional[AttestationRecord] = None,
) -> PrivateEvaluationResult:
    """Answer ``predicate`` from ``envelope`` under the minimum authorized release.

    ``release_policy``, when supplied, is *intersected* with the envelope's
    own policy: a verifier-side policy can narrow disclosure but never widen
    it.  ``requested_kind`` is checked against the intersection; omitting it
    -- the common case -- yields the intersection's minimum-information
    default, which is the security property of 35.3.

    Every denial of 35.4 collapses the release to ``NO_RESULT``.
    """
    if not isinstance(envelope, CapabilityEnvelope):
        raise TypeError("evaluate_private requires a CapabilityEnvelope (spec 35.2)")
    if not isinstance(predicate, CapabilityQuery):
        raise TypeError("evaluate_private requires a CapabilityQuery")

    outcome = verify_envelope(
        envelope,
        clock=clock,
        seen_nonces=seen_nonces,
        revocations=revocations,
        keys=keys,
        expectations=expectations,
        attestation=attestation,
    )

    effective = envelope.release_policy.intersect(release_policy)
    denials = list(outcome.denials)
    warnings = list(outcome.warnings)

    # A query about a coordinate this envelope does not carry is a context
    # failure: the envelope's binding is to one coordinate in one target
    # context, and answering about another would be a fabrication.
    if predicate.coordinate_id != envelope.coordinate_id:
        denials.append(
            Denial(
                reason=DenialReason.CONTEXT_MISMATCH,
                check=CheckName.CONTEXT,
                detail=(
                    f"the query asks about coordinate {predicate.coordinate_id!r} but the "
                    f"envelope binds {envelope.coordinate_id!r}; an envelope answers only "
                    "for the coordinate and target context it was issued against "
                    "(spec 35.2)"
                ),
            )
        )

    kind = requested_kind
    if kind is not None:
        ReleaseKind.check(kind)
        if not effective.authorizes(kind):
            denials.append(
                Denial(
                    reason=DenialReason.ACCESS_POLICY_FORBIDS,
                    check=CheckName.ACCESS,
                    detail=(
                        f"release kind {kind!r} is not authorized by the effective policy "
                        f"{effective.policy_id!r} (authorized: "
                        f"{', '.join(effective.authorized_kinds)}); the request is denied "
                        "rather than quietly downgraded, so the requester knows what was "
                        "refused (spec 35.3, 6.6)"
                    ),
                )
            )
    else:
        kind = effective.default_kind

    denied = bool(denials)
    if denied or kind == ReleaseKind.NO_RESULT:
        basis = (
            "fail closed: one or more conditions of specification 35.4 denied an "
            "affirmative result, so NO_RESULT is released.  A denied evaluation "
            "returns no Boolean at all -- False would be indistinguishable from a "
            "refutation."
            if denied
            else "the effective release policy authorizes no disclosure (spec 35.3)"
        )
        return PrivateEvaluationResult(
            envelope_id=envelope.envelope_id,
            query_id=predicate.query_id,
            coordinate_id=predicate.coordinate_id,
            release_kind=ReleaseKind.NO_RESULT,
            released=False,
            denials=tuple(
                sorted(denials, key=lambda d: (DenialReason.ORDER.index(d.reason), d.check))
            ),
            verification=outcome,
            effective_policy=effective,
            requested_kind=requested_kind,
            attestation_scope=outcome.attestation_scope,
            attestation_proves=outcome.attestation_proves,
            attestation_does_not_prove=outcome.attestation_does_not_prove,
            signature_profile=outcome.signature_profile,
            release_basis=basis,
            warnings=tuple(dict.fromkeys(warnings)),
        )

    bound = envelope.bound
    state = predicate.evaluate(bound)
    margin = predicate.guaranteed_margin(bound)

    fields: Dict[str, Any] = {}
    if kind == ReleaseKind.BOOLEAN:
        fields["boolean"] = state == CapabilityState.GUARANTEED
        fields["boolean_semantics"] = BOOLEAN_SEMANTICS
    elif kind == ReleaseKind.POSSIBLE_OR_GUARANTEED_STATE:
        fields["state"] = state
    elif kind == ReleaseKind.AMBIGUITY_RESULT:
        fields["state"] = state
        fields["ambiguity_detail"] = (
            "the declared enclosure straddles the threshold; the answer is undecided "
            "and further evidence is required (spec 35.3)"
            if state == CapabilityState.POSSIBLE
            else "the declared enclosure decides the predicate; no ambiguity remains"
        )
    elif kind == ReleaseKind.QUANTIZED_MARGIN:
        step = effective.quantization_step
        if step is None:  # pragma: no cover - policy construction forbids this
            raise PolicyError("QUANTIZED_MARGIN authorized without a quantization step")
        fields["quantized_margin"] = _quantize(margin, step)
        fields["quantization_step"] = step
    elif kind == ReleaseKind.BOUNDED_INTERVAL:
        fields["interval"] = bound
        fields["unit"] = envelope.bounded_result.unit

    return PrivateEvaluationResult(
        envelope_id=envelope.envelope_id,
        query_id=predicate.query_id,
        coordinate_id=predicate.coordinate_id,
        release_kind=kind,
        released=True,
        denials=(),
        verification=outcome,
        effective_policy=effective,
        requested_kind=requested_kind,
        attestation_scope=outcome.attestation_scope,
        attestation_proves=outcome.attestation_proves,
        attestation_does_not_prove=outcome.attestation_does_not_prove,
        signature_profile=outcome.signature_profile,
        release_basis=(
            f"released {kind} "
            + (
                f"as requested and authorized by {effective.policy_id!r}"
                if requested_kind is not None
                else (
                    f"as the minimum information authorized by {effective.policy_id!r} "
                    f"(authorized: {', '.join(effective.authorized_kinds)}); no kind was "
                    "requested, and the default never widens disclosure (spec 35.3)"
                )
            )
        ),
        warnings=tuple(dict.fromkeys(warnings)),
        **fields,
    )
