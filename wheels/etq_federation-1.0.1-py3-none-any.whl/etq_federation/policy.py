"""Release policy: what a confidential evaluation is permitted to disclose.

Normative basis: master specification 35.3 (permitted confidential
evaluation outputs, and the default) and 44 (security and privacy).

Specification 35.3 permits six output forms and then adds one sentence
that carries the whole security property of the module:

    The release policy shall default to the minimum information authorized.

"Minimum" needs an order, and the specification does not give one, so this
module declares :data:`ReleaseKind.INFORMATION_ORDER` explicitly and uses
it everywhere.  The ordering is by how much of the underlying bounded
coordinate a recipient can reconstruct:

    NO_RESULT                     nothing
    BOOLEAN                       one bit about one threshold
    POSSIBLE_OR_GUARANTEED_STATE  three states about one threshold
    AMBIGUITY_RESULT              three states plus why it is undecided
    QUANTIZED_MARGIN              a coarse distance from the threshold
    BOUNDED_INTERVAL              the bound itself

A policy that authorizes several kinds and names no default therefore
defaults to the *first* of those in this order, never the most useful one.
Intersecting two policies keeps only kinds both authorize and takes the
more restrictive of every other setting, so combining an issuer's policy
with a verifier's can only narrow disclosure.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, Optional, Sequence, Tuple

from crg_model.numeric import Exact
from etq_evidence import AccessPolicy, Requester

__all__ = ["PolicyError", "ReleaseKind", "ReleasePolicy"]


class PolicyError(ValueError):
    """Raised when a release policy is malformed."""


class ReleaseKind:
    """The six permitted confidential evaluation outputs of 35.3."""

    NO_RESULT = "NO_RESULT"
    BOOLEAN = "BOOLEAN"
    POSSIBLE_OR_GUARANTEED_STATE = "POSSIBLE_OR_GUARANTEED_STATE"
    AMBIGUITY_RESULT = "AMBIGUITY_RESULT"
    QUANTIZED_MARGIN = "QUANTIZED_MARGIN"
    BOUNDED_INTERVAL = "BOUNDED_INTERVAL"

    #: Increasing disclosure.  Declared here because 35.3 says "minimum
    #: information authorized" without fixing an order; see module docstring.
    INFORMATION_ORDER: Tuple[str, ...] = (
        NO_RESULT,
        BOOLEAN,
        POSSIBLE_OR_GUARANTEED_STATE,
        AMBIGUITY_RESULT,
        QUANTIZED_MARGIN,
        BOUNDED_INTERVAL,
    )
    ALL = frozenset(INFORMATION_ORDER)

    #: Kinds that can carry an affirmative capability answer.  ``NO_RESULT``
    #: cannot, which is what makes it the fail-closed output of 35.4.
    AFFIRMATIVE_CAPABLE = frozenset(
        {
            BOOLEAN,
            POSSIBLE_OR_GUARANTEED_STATE,
            AMBIGUITY_RESULT,
            QUANTIZED_MARGIN,
            BOUNDED_INTERVAL,
        }
    )

    DESCRIPTION: Dict[str, str] = {
        NO_RESULT: "nothing is disclosed",
        BOOLEAN: "one bit: is the predicate guaranteed to hold",
        POSSIBLE_OR_GUARANTEED_STATE: "guaranteed, possible, or ruled out",
        AMBIGUITY_RESULT: "the state plus a declared reason it remains undecided",
        QUANTIZED_MARGIN: "the distance from the threshold, floored to a declared step",
        BOUNDED_INTERVAL: "the bounded coordinate itself",
    }

    @classmethod
    def check(cls, kind: str) -> str:
        if kind not in cls.ALL:
            raise PolicyError(
                f"unknown release kind {kind!r}; specification 35.3 permits "
                f"{', '.join(cls.INFORMATION_ORDER)}"
            )
        return kind

    @classmethod
    def information_level(cls, kind: str) -> int:
        return cls.INFORMATION_ORDER.index(cls.check(kind))

    @classmethod
    def minimum(cls, kinds: Iterable[str]) -> str:
        """The least-disclosing of a set of kinds; ``NO_RESULT`` when empty."""
        levels = sorted(cls.information_level(k) for k in kinds)
        if not levels:
            return cls.NO_RESULT
        return cls.INFORMATION_ORDER[levels[0]]


@dataclass(frozen=True)
class ReleasePolicy:
    """What the issuer authorizes an evaluation to release (35.2, 35.3).

    ``default_kind`` may be left ``None``, in which case it is derived as
    the minimum-information kind among ``authorized_kinds``.  That derived
    default -- not the caller's preference -- is what
    :func:`etq_federation.evaluate.evaluate_private` releases when no kind
    is requested.
    """

    policy_id: str
    authorized_kinds: Tuple[str, ...] = (ReleaseKind.BOOLEAN,)
    default_kind: Optional[str] = None
    quantization_step: Optional[Exact] = None
    permitted_roles: Tuple[str, ...] = ()
    permitted_subjects: Tuple[str, ...] = ()
    require_freshness: bool = True
    require_uncertainty: bool = True
    basis: str = ""

    def __post_init__(self) -> None:
        kinds = tuple(
            sorted(
                {ReleaseKind.check(str(k)) for k in (self.authorized_kinds or ())},
                key=ReleaseKind.information_level,
            )
        )
        if not kinds:
            kinds = (ReleaseKind.NO_RESULT,)
        object.__setattr__(self, "authorized_kinds", kinds)

        default = self.default_kind
        if default is None:
            default = ReleaseKind.minimum(kinds)
        else:
            ReleaseKind.check(default)
            if default not in kinds:
                raise PolicyError(
                    f"default release kind {default!r} is not among the authorized kinds "
                    f"{kinds}; a default the policy does not authorize is not a default"
                )
        object.__setattr__(self, "default_kind", default)

        if self.quantization_step is not None:
            step = Exact(self.quantization_step)
            if step <= Exact(0):
                raise PolicyError("quantization_step must be strictly positive")
            object.__setattr__(self, "quantization_step", step)
        if ReleaseKind.QUANTIZED_MARGIN in kinds and self.quantization_step is None:
            raise PolicyError(
                "a policy authorizing QUANTIZED_MARGIN must declare a quantization "
                "step; an unquantized margin is a bounded interval by another name "
                "(spec 35.3)"
            )
        object.__setattr__(
            self, "permitted_roles", tuple(sorted(str(r) for r in self.permitted_roles))
        )
        object.__setattr__(
            self, "permitted_subjects", tuple(sorted(str(s) for s in self.permitted_subjects))
        )

    # -- construction helpers ------------------------------------------
    @classmethod
    def minimal(cls, policy_id: str = "release-minimal", **kwargs: Any) -> "ReleasePolicy":
        """Boolean only -- the least a useful policy can authorize."""
        kwargs.setdefault("basis", "minimum disclosure: a single Boolean (spec 35.3)")
        return cls(policy_id=policy_id, authorized_kinds=(ReleaseKind.BOOLEAN,), **kwargs)

    @classmethod
    def closed(cls, policy_id: str = "release-closed") -> "ReleasePolicy":
        """Authorizes nothing.  Every evaluation under it returns NO_RESULT."""
        return cls(
            policy_id=policy_id,
            authorized_kinds=(ReleaseKind.NO_RESULT,),
            basis="no disclosure authorized",
        )

    # -- queries -------------------------------------------------------
    @property
    def minimum_authorized(self) -> str:
        return ReleaseKind.minimum(self.authorized_kinds)

    @property
    def maximum_authorized(self) -> str:
        levels = sorted(
            (ReleaseKind.information_level(k) for k in self.authorized_kinds), reverse=True
        )
        return ReleaseKind.INFORMATION_ORDER[levels[0]]

    def authorizes(self, kind: str) -> bool:
        return ReleaseKind.check(kind) in self.authorized_kinds

    def permits_requester(self, requester: Optional[Requester]) -> bool:
        """Subject and role gate (44.2).  No restriction means no restriction."""
        if not self.permitted_roles and not self.permitted_subjects:
            return True
        if requester is None:
            return False
        if requester.subject_id in self.permitted_subjects:
            return True
        return bool(set(requester.roles) & set(self.permitted_roles))

    def refusal(self, requester: Optional[Requester]) -> str:
        if self.permits_requester(requester):
            return ""
        if requester is None:
            return (
                f"release policy {self.policy_id!r} restricts disclosure to declared "
                "subjects or roles and no requester was identified"
            )
        return (
            f"requester {requester.subject_id!r} with roles {list(requester.roles)} is "
            f"not permitted by release policy {self.policy_id!r}"
        )

    def intersect(self, other: Optional["ReleasePolicy"]) -> "ReleasePolicy":
        """The narrower of two policies.  Combining can only reduce disclosure."""
        if other is None:
            return self
        kinds = tuple(
            sorted(
                set(self.authorized_kinds) & set(other.authorized_kinds),
                key=ReleaseKind.information_level,
            )
        )
        if not kinds:
            kinds = (ReleaseKind.NO_RESULT,)
        step: Optional[Exact]
        if self.quantization_step is None:
            step = other.quantization_step
        elif other.quantization_step is None:
            step = self.quantization_step
        else:
            # A coarser step discloses less.
            step = (
                self.quantization_step
                if self.quantization_step >= other.quantization_step
                else other.quantization_step
            )
        if ReleaseKind.QUANTIZED_MARGIN in kinds and step is None:  # pragma: no cover
            kinds = tuple(k for k in kinds if k != ReleaseKind.QUANTIZED_MARGIN) or (
                ReleaseKind.NO_RESULT,
            )
        # Roles: an empty tuple means "unrestricted", so intersecting an
        # unrestricted policy with a restricted one keeps the restriction.
        roles = _narrow(self.permitted_roles, other.permitted_roles)
        subjects = _narrow(self.permitted_subjects, other.permitted_subjects)
        return ReleasePolicy(
            policy_id=f"{self.policy_id}&{other.policy_id}",
            authorized_kinds=kinds,
            default_kind=ReleaseKind.minimum(kinds),
            quantization_step=step if ReleaseKind.QUANTIZED_MARGIN in kinds else None,
            permitted_roles=roles,
            permitted_subjects=subjects,
            require_freshness=self.require_freshness or other.require_freshness,
            require_uncertainty=self.require_uncertainty or other.require_uncertainty,
            basis=(
                "intersection of two release policies; every setting takes its more "
                "restrictive value (spec 35.3, 6.6)"
            ),
        )

    def to_canonical(self) -> dict:
        record: dict = {
            "policy_id": self.policy_id,
            "authorized_kinds": list(self.authorized_kinds),
            "default_kind": self.default_kind,
            "minimum_authorized": self.minimum_authorized,
            "require_freshness": self.require_freshness,
            "require_uncertainty": self.require_uncertainty,
            "information_order": list(ReleaseKind.INFORMATION_ORDER),
        }
        if self.quantization_step is not None:
            record["quantization_step"] = self.quantization_step.to_canonical()
        if self.permitted_roles:
            record["permitted_roles"] = list(self.permitted_roles)
        if self.permitted_subjects:
            record["permitted_subjects"] = list(self.permitted_subjects)
        if self.basis:
            record["basis"] = self.basis
        return record


def _narrow(left: Sequence[str], right: Sequence[str]) -> Tuple[str, ...]:
    if not left:
        return tuple(right)
    if not right:
        return tuple(left)
    return tuple(sorted(set(left) & set(right)))
