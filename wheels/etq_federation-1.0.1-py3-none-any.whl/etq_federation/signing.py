"""Signatures and attestations, and an explicit statement of what they prove.

Normative basis: master specification 14.3 (canonicalization and
signature-excluded fields), 14.4 (hashing), 14.5 (signature profiles), and
35.2/35.4 (the envelope's signature-or-attestation binding and the honest
scope of attestation).

.. warning::

   **This module implements a test-only signature profile.**
   ``SIGNATURE_PROFILE`` is ``"HMAC-SHA256-TEST"``: a keyed MAC over the
   canonical envelope, built from the Python standard library because no
   asymmetric-signature dependency is available to this package.

   It is **not** a production profile and must not be deployed as one.
   Specification 14.5 makes Ed25519 over canonical manifests the baseline
   portable profile, and the difference is not cosmetic:

   * a symmetric MAC gives every verifier the power to *forge* envelopes,
     because verification and signing use the same secret.  Ed25519
     verification confers no signing power;
   * a MAC cannot be verified by a third party who is not already trusted
     to issue, so it cannot support the cross-organizational federation
     35.1--35.3 exists for; and
   * there is no key-revocation or certificate-chain story for a shared
     secret.

   A production deployment MUST replace :func:`sign_payload` and
   :func:`verify_payload` with an Ed25519 (or enterprise-profile) backend
   and change ``SIGNATURE_PROFILE`` accordingly.  Every object this module
   produces carries the profile string, so an artifact signed under the
   test profile is identifiable as such forever.

The second half of the module is about honesty rather than cryptography.
Specification 35.4 states that attestation proves that identified code
processed committed inputs, and that it does **not** prove that the
underlying evidence is scientifically accurate.  That limit is encoded in
:class:`AttestationRecord` as data -- a ``proves`` list, a
``does_not_prove`` list, and a scope statement -- and the record refuses to
be constructed with the scientific-accuracy disclaimer removed.
"""
from __future__ import annotations

import hashlib
import hmac
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, Mapping, Optional, Sequence, Tuple, Union

from crg_model.canonical import canonical_bytes, content_hash

__all__ = [
    "SigningError",
    "SIGNATURE_PROFILE",
    "SIGNATURE_ALGORITHM",
    "PRODUCTION_SIGNATURE_PROFILE",
    "PRODUCTION_PROFILE_WARNING",
    "SigningKey",
    "KeyRing",
    "EnvelopeSignature",
    "sign_payload",
    "verify_payload",
    "ATTESTATION_SCOPE_STATEMENT",
    "ATTESTATION_PROVES",
    "ATTESTATION_DOES_NOT_PROVE",
    "REQUIRED_ATTESTATION_DISCLAIMER",
    "AttestationRecord",
]


class SigningError(ValueError):
    """Raised when a key or signature declaration is malformed."""


#: The profile implemented here.  Test-only; see the module warning.
SIGNATURE_PROFILE = "HMAC-SHA256-TEST"
SIGNATURE_ALGORITHM = "hmac-sha256"

#: The profile specification 14.5 makes the baseline for portable artifacts.
PRODUCTION_SIGNATURE_PROFILE = "Ed25519"

PRODUCTION_PROFILE_WARNING = (
    f"signature profile {SIGNATURE_PROFILE} is a symmetric-MAC stand-in for testing "
    f"only; a verifier holding the key can forge envelopes.  Specification 14.5 "
    f"requires {PRODUCTION_SIGNATURE_PROFILE} over canonical manifests for the "
    "baseline portable profile, and no production federation may accept this profile."
)


@dataclass(frozen=True)
class SigningKey:
    """A shared secret under the test profile.

    Under a production profile this would hold a private key and the
    verifier would hold only the public half.  Here signing and verifying
    use the same bytes, which is exactly the property that disqualifies the
    profile from production use.
    """

    key_id: str
    secret: bytes
    profile: str = SIGNATURE_PROFILE
    algorithm: str = SIGNATURE_ALGORITHM
    holder: str = ""

    def __post_init__(self) -> None:
        if not str(self.key_id).strip():
            raise SigningError("a signing key requires an identity (spec 14.1)")
        secret = self.secret
        if isinstance(secret, str):
            secret = secret.encode("utf-8")
        if not isinstance(secret, (bytes, bytearray)):
            raise SigningError("signing key secret must be bytes or str")
        if len(secret) < 16:
            raise SigningError(
                "signing key secret is shorter than 16 bytes; even a test profile "
                "should not normalise a trivially guessable key"
            )
        object.__setattr__(self, "secret", bytes(secret))

    @classmethod
    def from_secret(cls, key_id: str, secret: Union[str, bytes], holder: str = "") -> "SigningKey":
        return cls(key_id=key_id, secret=secret, holder=holder)

    @property
    def public_reference(self) -> str:
        """A non-secret identifier for the key, safe to place in an envelope.

        Under Ed25519 this would be the public key.  Under the test profile
        there is no public half, so a salted digest of the secret stands in
        as a stable, non-invertible reference.
        """
        digest = hashlib.sha256(b"crg-key-reference:" + self.secret).hexdigest()
        return f"keyref-sha256:{digest[:32]}"

    def to_canonical(self) -> dict:
        """Never includes the secret."""
        record: dict = {
            "key_id": self.key_id,
            "profile": self.profile,
            "algorithm": self.algorithm,
            "public_reference": self.public_reference,
        }
        if self.holder:
            record["holder"] = self.holder
        return record


class KeyRing:
    """A verifier's set of keys, addressed by key identity."""

    def __init__(self, keys: Iterable[SigningKey] = ()) -> None:
        self._keys: Dict[str, SigningKey] = {}
        for key in keys:
            self.add(key)

    def add(self, key: SigningKey) -> None:
        if not isinstance(key, SigningKey):
            raise SigningError("only SigningKey objects may enter a key ring")
        self._keys[key.key_id] = key

    def get(self, key_id: str) -> Optional[SigningKey]:
        return self._keys.get(key_id)

    def __contains__(self, key_id: object) -> bool:
        return key_id in self._keys

    def __len__(self) -> int:
        return len(self._keys)

    @property
    def key_ids(self) -> Tuple[str, ...]:
        return tuple(sorted(self._keys))


def _as_keyring(keys: Any) -> KeyRing:
    if keys is None:
        return KeyRing()
    if isinstance(keys, KeyRing):
        return keys
    if isinstance(keys, SigningKey):
        return KeyRing((keys,))
    if isinstance(keys, Mapping):
        return KeyRing(keys.values())
    return KeyRing(tuple(keys))


@dataclass(frozen=True)
class EnvelopeSignature:
    """A signature over a canonical payload (14.3, 14.5).

    ``excluded_fields`` records which envelope fields were held out of the
    signed payload, which 14.3 requires a canonicalization profile to
    define.  ``profile`` travels with the value so a test-profile artifact
    can never be mistaken for a production one.
    """

    profile: str
    algorithm: str
    key_id: str
    key_reference: str
    value: str
    excluded_fields: Tuple[str, ...] = ()
    payload_hash: str = ""
    created_at: Optional[str] = None

    def __post_init__(self) -> None:
        object.__setattr__(
            self, "excluded_fields", tuple(sorted(str(f) for f in self.excluded_fields))
        )

    @property
    def is_production_profile(self) -> bool:
        return self.profile == PRODUCTION_SIGNATURE_PROFILE

    def to_canonical(self) -> dict:
        record: dict = {
            "profile": self.profile,
            "algorithm": self.algorithm,
            "key_id": self.key_id,
            "key_reference": self.key_reference,
            "value": self.value,
            "excluded_fields": list(self.excluded_fields),
        }
        if self.payload_hash:
            record["payload_hash"] = self.payload_hash
        if self.created_at is not None:
            record["created_at"] = self.created_at
        return record


def sign_payload(
    payload: Any,
    key: SigningKey,
    *,
    excluded_fields: Sequence[str] = (),
    created_at: Optional[str] = None,
) -> EnvelopeSignature:
    """Sign the canonical encoding of ``payload`` under the test profile.

    The payload is canonicalized with :func:`crg_model.canonical.canonical_bytes`
    (RFC 8785 behaviour, 14.3), so two structurally equal payloads produce
    the same signature and no float can enter the signed bytes.
    """
    if not isinstance(key, SigningKey):
        raise SigningError("sign_payload requires a SigningKey")
    message = canonical_bytes(payload)
    digest = hmac.new(key.secret, message, hashlib.sha256).hexdigest()
    return EnvelopeSignature(
        profile=key.profile,
        algorithm=key.algorithm,
        key_id=key.key_id,
        key_reference=key.public_reference,
        value=f"{key.algorithm}:{digest}",
        excluded_fields=tuple(excluded_fields),
        payload_hash=content_hash(payload),
        created_at=created_at,
    )


def verify_payload(
    payload: Any, signature: Optional[EnvelopeSignature], keys: Any
) -> Tuple[bool, str]:
    """Verify a signature, returning ``(ok, detail)``.

    Fails closed: an absent signature, an unknown key, or an unsupported
    profile is a failure, never a pass.  Comparison uses
    :func:`hmac.compare_digest`.
    """
    if signature is None:
        return False, "no signature or attestation is present on the artifact (spec 35.2)"
    ring = _as_keyring(keys)
    if len(ring) == 0:
        return False, (
            "no verification key was supplied; the signature is unchecked and an "
            "unchecked signature is a failure, not a pass (spec 6.6)"
        )
    key = ring.get(signature.key_id)
    if key is None:
        return False, (
            f"no key {signature.key_id!r} in the verifier's key ring "
            f"(known: {', '.join(ring.key_ids) or 'none'})"
        )
    if signature.profile != key.profile:
        return False, (
            f"signature profile {signature.profile!r} does not match key profile "
            f"{key.profile!r}"
        )
    if signature.profile != SIGNATURE_PROFILE:
        return False, (
            f"unsupported signature profile {signature.profile!r}; this build implements "
            f"only {SIGNATURE_PROFILE} and refuses to guess at another"
        )
    if signature.key_reference != key.public_reference:
        return False, "the signature's key reference does not match the key ring entry"
    expected = hmac.new(key.secret, canonical_bytes(payload), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(f"{key.algorithm}:{expected}", signature.value):
        return False, "signature does not verify over the canonical payload (spec 14.3)"
    return True, (
        f"signature verifies under {SIGNATURE_PROFILE}; note that a valid signature "
        "proves control of the signing key over the signed content and nothing about "
        "scientific, mathematical, or commercial correctness (spec 14.5)"
    )


# ==========================================================================
# attestation and its declared scope (35.4)
# ==========================================================================

ATTESTATION_PROVES: Tuple[str, ...] = (
    "the identified code, as measured by code_identity, executed",
    "that code processed exactly the inputs committed to by input_commitment",
    "the output was produced by that execution over those inputs",
)

#: The disclaimer specification 35.4 states in so many words.  It is
#: mandatory: :class:`AttestationRecord` refuses to drop it.
REQUIRED_ATTESTATION_DISCLAIMER = (
    "that the underlying evidence is scientifically accurate"
)

ATTESTATION_DOES_NOT_PROVE: Tuple[str, ...] = (
    REQUIRED_ATTESTATION_DISCLAIMER,
    "that the applicability rule used is scientifically or legally correct",
    "that the source context resembles the target context in any unmeasured respect",
    "that the bounded result is commercially or physically achievable",
    "that the issuer's clock assertion is true",
)

ATTESTATION_SCOPE_STATEMENT = (
    "Attestation proves that identified code processed committed inputs.  It does not "
    "prove that the underlying evidence is scientifically accurate (spec 35.4).  A "
    "consumer of this result may conclude that the stated program ran over the stated "
    "inputs and nothing further; in particular an affirmative capability answer is a "
    "statement about a declared bounded coordinate, not a warranty about the world."
)


@dataclass(frozen=True)
class AttestationRecord:
    """Evidence that identified code processed committed inputs (35.4).

    The record carries its own limits.  ``proves`` and ``does_not_prove``
    are data, not documentation, so a consumer reading the result object
    cannot read more into an attestation than it says.
    """

    attestation_id: str
    code_identity: str
    input_commitment: str
    measurement_profile: str = "declared-code-measurement"
    verifier_program_hash: str = ""
    proves: Tuple[str, ...] = ATTESTATION_PROVES
    does_not_prove: Tuple[str, ...] = ATTESTATION_DOES_NOT_PROVE
    scope_statement: str = ATTESTATION_SCOPE_STATEMENT
    signature: Optional[EnvelopeSignature] = None

    def __post_init__(self) -> None:
        if not str(self.code_identity).strip():
            raise SigningError(
                "an attestation with no code identity attests to nothing (spec 35.4)"
            )
        if not str(self.input_commitment).strip():
            raise SigningError(
                "an attestation with no input commitment cannot say which inputs were "
                "processed (spec 35.4)"
            )
        object.__setattr__(self, "proves", tuple(str(p) for p in self.proves))
        object.__setattr__(self, "does_not_prove", tuple(str(p) for p in self.does_not_prove))
        if REQUIRED_ATTESTATION_DISCLAIMER not in self.does_not_prove:
            raise SigningError(
                "an attestation record may not drop the disclaimer of specification "
                f"35.4: {REQUIRED_ATTESTATION_DISCLAIMER!r} must appear in "
                "does_not_prove"
            )
        if not str(self.scope_statement).strip():
            raise SigningError("an attestation must carry its scope statement (spec 35.4)")

    def matches(self, expected_code_identity: Optional[str]) -> bool:
        if expected_code_identity is None:
            return True
        return self.code_identity == expected_code_identity

    def commits_to(self, commitment: str) -> bool:
        return self.input_commitment == commitment

    def to_canonical(self) -> dict:
        record: dict = {
            "attestation_id": self.attestation_id,
            "code_identity": self.code_identity,
            "input_commitment": self.input_commitment,
            "measurement_profile": self.measurement_profile,
            "proves": list(self.proves),
            "does_not_prove": list(self.does_not_prove),
            "scope_statement": self.scope_statement,
        }
        if self.verifier_program_hash:
            record["verifier_program_hash"] = self.verifier_program_hash
        if self.signature is not None:
            record["signature"] = self.signature.to_canonical()
        return record
