"""Fail-closed verification of a capability envelope.

Normative basis: master specification 35.4 (the conditions under which an
affirmative result MUST be denied), 35.2 (what the verifier is checking),
45.3--45.5 (what a verifier must report about time), 6.6 (fail closed), and
14.5 (what a valid signature does and does not prove).

Specification 35.4 lists nine conditions.  Each gets its own reason code,
because each has a different remedy: a stale nonce is re-requested, an
expired rule is re-approved, a missing uncertainty budget is supplied, and
a failed signature means somebody is lying.  Collapsing them into one
"denied" would leave the recipient with nothing to act on.

Three decisions the specification leaves open are made explicitly here.

**All applicable denials are reported, not just the first.**  Checks run in
a declared :data:`CHECK_ORDER` and every one that fires is recorded, so a
single round trip tells the requester everything that is wrong.
``primary_reason`` is the first in that order.

**An unchecked condition is not a passed condition.**  No verification key
means the signature check *fails*; a verification program that names a
check this build does not implement is a denial, not a shrug.  The one
exception is the nonce ledger: a verifier with no ledger cannot detect
replay at all, so rather than pretend either way the outcome carries
``replay_checked=False`` and a standing warning.

**Time statuses map to distinct reasons.**  ``EXPIRED`` and
``NOT_YET_VALID`` are evidence-validity failures; ``STALE`` is a freshness
failure and therefore a nonce failure; ``TIME_INDETERMINATE`` and
``CLOCK_POLICY_VIOLATION`` are 35.4's "time is indeterminate where
freshness is required".
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Mapping, MutableSet, Optional, Sequence, Set, Tuple

from crg_model.canonical import content_hash
from etq_evidence import (
    Requester,
    TimeJudgment,
    TimeStatus,
    ValidityWindow,
    VerificationClock,
    evaluate_time,
)

from .envelope import CapabilityEnvelope
from .policy import ReleasePolicy
from .revocation import RevocationRegistry, RevocationState, as_registry
from .signing import (
    ATTESTATION_SCOPE_STATEMENT,
    PRODUCTION_PROFILE_WARNING,
    SIGNATURE_PROFILE,
    AttestationRecord,
    KeyRing,
    verify_payload,
)

__all__ = [
    "DenialReason",
    "Denial",
    "CheckName",
    "CHECK_ORDER",
    "IMPLEMENTED_CHECKS",
    "CheckStatus",
    "NonceLedger",
    "VerifierExpectations",
    "VerificationOutcome",
    "verify_envelope",
]


class DenialReason:
    """The nine conditions of specification 35.4, each distinct."""

    SIGNATURE_OR_ATTESTATION_FAILED = "SIGNATURE_OR_ATTESTATION_FAILED"
    NONCE_STALE_OR_REUSED = "NONCE_STALE_OR_REUSED"
    CONTEXT_MISMATCH = "CONTEXT_MISMATCH"
    RULE_UNAUTHORIZED_OR_EXPIRED = "RULE_UNAUTHORIZED_OR_EXPIRED"
    CODE_IDENTITY_UNEXPECTED = "CODE_IDENTITY_UNEXPECTED"
    EVIDENCE_EXPIRED_OR_REVOKED = "EVIDENCE_EXPIRED_OR_REVOKED"
    REQUIRED_UNCERTAINTY_MISSING = "REQUIRED_UNCERTAINTY_MISSING"
    TIME_INDETERMINATE = "TIME_INDETERMINATE"
    ACCESS_POLICY_FORBIDS = "ACCESS_POLICY_FORBIDS"

    ORDER: Tuple[str, ...] = (
        SIGNATURE_OR_ATTESTATION_FAILED,
        NONCE_STALE_OR_REUSED,
        CONTEXT_MISMATCH,
        RULE_UNAUTHORIZED_OR_EXPIRED,
        CODE_IDENTITY_UNEXPECTED,
        EVIDENCE_EXPIRED_OR_REVOKED,
        REQUIRED_UNCERTAINTY_MISSING,
        TIME_INDETERMINATE,
        ACCESS_POLICY_FORBIDS,
    )
    ALL = frozenset(ORDER)

    SPEC_CITATION: Dict[str, str] = {
        SIGNATURE_OR_ATTESTATION_FAILED: "35.4: signature or attestation fails",
        NONCE_STALE_OR_REUSED: "35.4: nonce is stale or reused",
        CONTEXT_MISMATCH: "35.4: context mismatches",
        RULE_UNAUTHORIZED_OR_EXPIRED: "35.4: rule is unauthorized or expired",
        CODE_IDENTITY_UNEXPECTED: "35.4: code identity is unexpected",
        EVIDENCE_EXPIRED_OR_REVOKED: "35.4: evidence is expired or revoked",
        REQUIRED_UNCERTAINTY_MISSING: "35.4: required uncertainty is missing",
        TIME_INDETERMINATE: "35.4: time is indeterminate where freshness is required",
        ACCESS_POLICY_FORBIDS: "35.4: access policy forbids the result",
    }

    @classmethod
    def check(cls, reason: str) -> str:
        if reason not in cls.ALL:
            raise ValueError(f"unknown denial reason {reason!r}; 35.4 names {cls.ORDER}")
        return reason


class CheckName:
    """Names a verification program may declare (35.2)."""

    VERIFICATION_PROGRAM = "verification_program"
    SIGNATURE = "signature"
    NONCE = "nonce"
    CONTEXT = "context"
    RULE = "rule"
    CODE_IDENTITY = "code_identity"
    EVIDENCE = "evidence"
    UNCERTAINTY = "uncertainty"
    CLOCK = "clock"
    ACCESS = "access"


#: The order checks run in, and the order denials are reported in.
CHECK_ORDER: Tuple[str, ...] = (
    CheckName.VERIFICATION_PROGRAM,
    CheckName.SIGNATURE,
    CheckName.NONCE,
    CheckName.CONTEXT,
    CheckName.RULE,
    CheckName.CODE_IDENTITY,
    CheckName.EVIDENCE,
    CheckName.UNCERTAINTY,
    CheckName.CLOCK,
    CheckName.ACCESS,
)

#: What this build can actually run.  A verification program naming
#: anything outside this set is denied rather than partially honoured.
IMPLEMENTED_CHECKS = frozenset(CHECK_ORDER)


class CheckStatus:
    PASS = "PASS"
    DENY = "DENY"
    NOT_APPLICABLE = "NOT_APPLICABLE"
    UNCHECKED = "UNCHECKED"


@dataclass(frozen=True)
class Denial:
    """One reason an affirmative result was denied (35.4)."""

    reason: str
    check: str
    detail: str
    spec_citation: str = ""

    def __post_init__(self) -> None:
        DenialReason.check(self.reason)
        if not self.spec_citation:
            object.__setattr__(self, "spec_citation", DenialReason.SPEC_CITATION[self.reason])

    def to_canonical(self) -> dict:
        return {
            "reason": self.reason,
            "check": self.check,
            "detail": self.detail,
            "spec_citation": self.spec_citation,
        }


class NonceLedger:
    """Single-use request identifiers (35.2, 35.4).

    A nonce is consumed when an envelope carrying it is *accepted*: an
    envelope that failed verification never spent its nonce, so a rejected
    request can be retried without a fresh identifier, while an accepted
    one can never be replayed.
    """

    def __init__(self, seen: Iterable[str] = (), *, ledger_id: str = "nonce-ledger") -> None:
        self.ledger_id = str(ledger_id)
        self._seen: Set[str] = {str(n) for n in (seen or ())}
        self._backing: Optional[MutableSet] = None

    @classmethod
    def wrapping(cls, backing: MutableSet, *, ledger_id: str = "nonce-ledger") -> "NonceLedger":
        """Wrap a caller-owned mutable set so consumption is visible to them."""
        ledger = cls(backing, ledger_id=ledger_id)
        ledger._backing = backing
        return ledger

    def seen(self, nonce: str) -> bool:
        return str(nonce) in self._seen

    def consume(self, nonce: str) -> bool:
        """Record a nonce.  Returns ``False`` if it had already been seen."""
        nonce = str(nonce)
        if nonce in self._seen:
            return False
        self._seen.add(nonce)
        if self._backing is not None:
            self._backing.add(nonce)
        return True

    def __contains__(self, nonce: object) -> bool:
        return self.seen(str(nonce))

    def __len__(self) -> int:
        return len(self._seen)

    @property
    def nonces(self) -> Tuple[str, ...]:
        return tuple(sorted(self._seen))


def _as_ledger(seen_nonces: Any) -> Optional[NonceLedger]:
    if seen_nonces is None:
        return None
    if isinstance(seen_nonces, NonceLedger):
        return seen_nonces
    if isinstance(seen_nonces, (set, frozenset)):
        if isinstance(seen_nonces, frozenset):
            return NonceLedger(seen_nonces)
        return NonceLedger.wrapping(seen_nonces)
    return NonceLedger(tuple(seen_nonces))


@dataclass(frozen=True)
class VerifierExpectations:
    """What this verifier expects to see, beyond the envelope's own claims.

    Every field is optional and an omitted field is *not* a check that
    passes -- it is a check that does not apply, and the outcome says so.
    """

    target_context_fingerprint: Optional[str] = None
    expected_code_identity: Optional[str] = None
    expected_input_commitment: Optional[str] = None
    trusted_issuers: Tuple[str, ...] = ()
    authorized_rules: Tuple[Tuple[str, str], ...] = ()
    revoked_evidence_roots: Tuple[str, ...] = ()
    require_freshness: bool = True
    require_uncertainty: bool = True
    requester: Optional[Requester] = None
    require_attestation: bool = False

    def __post_init__(self) -> None:
        object.__setattr__(
            self, "trusted_issuers", tuple(sorted(str(i) for i in self.trusted_issuers))
        )
        object.__setattr__(
            self,
            "authorized_rules",
            tuple(sorted((str(r), str(v)) for r, v in self.authorized_rules)),
        )
        object.__setattr__(
            self,
            "revoked_evidence_roots",
            tuple(sorted(str(r) for r in self.revoked_evidence_roots)),
        )

    def to_canonical(self) -> dict:
        record: dict = {
            "require_freshness": self.require_freshness,
            "require_uncertainty": self.require_uncertainty,
            "require_attestation": self.require_attestation,
        }
        for key, value in (
            ("target_context_fingerprint", self.target_context_fingerprint),
            ("expected_code_identity", self.expected_code_identity),
            ("expected_input_commitment", self.expected_input_commitment),
        ):
            if value is not None:
                record[key] = value
        if self.trusted_issuers:
            record["trusted_issuers"] = list(self.trusted_issuers)
        if self.authorized_rules:
            record["authorized_rules"] = [f"{r}@{v}" for r, v in self.authorized_rules]
        if self.revoked_evidence_roots:
            record["revoked_evidence_roots"] = list(self.revoked_evidence_roots)
        if self.requester is not None:
            record["requester"] = self.requester.to_canonical()
        return record


@dataclass(frozen=True)
class VerificationOutcome:
    """The verifier's report: what it checked, what it found, what it means."""

    envelope_id: str
    accepted: bool
    denials: Tuple[Denial, ...]
    checks: Tuple[Tuple[str, str], ...]
    time_judgment: TimeJudgment
    rule_time_judgment: TimeJudgment
    signature_profile: str
    signature_verified: bool
    signature_detail: str
    attestation: Optional[AttestationRecord]
    attestation_scope: str
    replay_checked: bool
    nonce_consumed: bool
    clock: VerificationClock
    warnings: Tuple[str, ...] = ()
    verification_basis: Tuple[str, ...] = ()

    def reasons(self) -> Tuple[str, ...]:
        ordered = sorted(
            {d.reason for d in self.denials}, key=lambda r: DenialReason.ORDER.index(r)
        )
        return tuple(ordered)

    @property
    def primary_reason(self) -> Optional[str]:
        reasons = self.reasons()
        return reasons[0] if reasons else None

    def denial_for(self, reason: str) -> Optional[Denial]:
        for denial in self.denials:
            if denial.reason == reason:
                return denial
        return None

    def check_status(self, check: str) -> str:
        for name, status in self.checks:
            if name == check:
                return status
        return CheckStatus.NOT_APPLICABLE

    @property
    def attestation_proves(self) -> Tuple[str, ...]:
        return self.attestation.proves if self.attestation is not None else ()

    @property
    def attestation_does_not_prove(self) -> Tuple[str, ...]:
        return self.attestation.does_not_prove if self.attestation is not None else ()

    def to_canonical(self) -> dict:
        record: dict = {
            "envelope_id": self.envelope_id,
            "accepted": self.accepted,
            "denials": [d.to_canonical() for d in self.denials],
            "reasons": list(self.reasons()),
            "checks": {name: status for name, status in self.checks},
            "time_judgment": self.time_judgment.to_canonical(),
            "rule_time_judgment": self.rule_time_judgment.to_canonical(),
            "signature_profile": self.signature_profile,
            "signature_verified": self.signature_verified,
            "signature_detail": self.signature_detail,
            "attestation_scope": self.attestation_scope,
            "replay_checked": self.replay_checked,
            "nonce_consumed": self.nonce_consumed,
            "clock": self.clock.to_canonical(),
            "warnings": list(self.warnings),
            "verification_basis": list(self.verification_basis),
        }
        if self.attestation is not None:
            record["attestation"] = self.attestation.to_canonical()
        return record

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())


def verify_envelope(
    envelope: CapabilityEnvelope,
    *,
    clock: Optional[VerificationClock] = None,
    seen_nonces: Any = None,
    revocations: Any = None,
    keys: Any = None,
    expectations: Optional[VerifierExpectations] = None,
    attestation: Optional[AttestationRecord] = None,
) -> VerificationOutcome:
    """Run the nine fail-closed checks of specification 35.4.

    Returns a :class:`VerificationOutcome`.  ``accepted`` is true only when
    no check denied; every denial that fired is present in ``denials`` with
    its own reason code.
    """
    if not isinstance(envelope, CapabilityEnvelope):
        raise TypeError("verify_envelope requires a CapabilityEnvelope (spec 35.2)")

    expectations = expectations or VerifierExpectations()
    clock = clock or VerificationClock.absent()
    registry = as_registry(revocations)
    ledger = _as_ledger(seen_nonces)
    attestation = attestation or envelope.attestation

    denials: List[Denial] = []
    statuses: Dict[str, str] = {name: CheckStatus.NOT_APPLICABLE for name in CHECK_ORDER}
    warnings: List[str] = []

    def deny(check: str, reason: str, detail: str) -> None:
        statuses[check] = CheckStatus.DENY
        denials.append(Denial(reason=reason, check=check, detail=detail))

    def passed(check: str) -> None:
        if statuses.get(check) != CheckStatus.DENY:
            statuses[check] = CheckStatus.PASS

    # -- verification program ------------------------------------------
    declared = set(envelope.verification_program.checks)
    unimplemented = sorted(declared - IMPLEMENTED_CHECKS)
    if unimplemented:
        deny(
            CheckName.VERIFICATION_PROGRAM,
            DenialReason.CODE_IDENTITY_UNEXPECTED,
            f"the issuer's verification program {envelope.verification_program.program_id!r} "
            f"declares check(s) this build does not implement: {', '.join(unimplemented)}; "
            "a check that cannot be run must not be reported as passed (spec 6.6, 35.2)",
        )
    else:
        passed(CheckName.VERIFICATION_PROGRAM)

    # -- signature or attestation --------------------------------------
    signature_verified = False
    signature_detail = ""
    if envelope.signature is None and attestation is None:
        deny(
            CheckName.SIGNATURE,
            DenialReason.SIGNATURE_OR_ATTESTATION_FAILED,
            "the envelope carries neither a signature nor an attestation (spec 35.2)",
        )
    else:
        if envelope.signature is not None:
            signature_verified, signature_detail = verify_payload(
                envelope.signing_payload(), envelope.signature, keys
            )
            if not signature_verified:
                deny(
                    CheckName.SIGNATURE,
                    DenialReason.SIGNATURE_OR_ATTESTATION_FAILED,
                    signature_detail,
                )
            else:
                passed(CheckName.SIGNATURE)
        if attestation is not None and attestation.signature is not None:
            payload = {
                k: v for k, v in attestation.to_canonical().items() if k != "signature"
            }
            ok, detail = verify_payload(payload, attestation.signature, keys)
            if not ok:
                deny(
                    CheckName.SIGNATURE,
                    DenialReason.SIGNATURE_OR_ATTESTATION_FAILED,
                    f"attestation signature: {detail}",
                )
        if envelope.signature is None and attestation is not None:
            deny(
                CheckName.SIGNATURE,
                DenialReason.SIGNATURE_OR_ATTESTATION_FAILED,
                "the envelope is unsigned; an attestation binds the evaluating code, "
                "not the envelope's own contents (spec 35.2, 35.4)",
            )

    if expectations.trusted_issuers and envelope.issuer not in expectations.trusted_issuers:
        deny(
            CheckName.SIGNATURE,
            DenialReason.SIGNATURE_OR_ATTESTATION_FAILED,
            f"issuer {envelope.issuer!r} is not among this verifier's trusted issuers "
            f"({', '.join(expectations.trusted_issuers)}); a valid signature from an "
            "untrusted key proves control of that key and nothing this verifier needs "
            "(spec 14.5)",
        )

    if envelope.signature is not None and envelope.signature.profile == SIGNATURE_PROFILE:
        warnings.append(PRODUCTION_PROFILE_WARNING)

    # -- time (45.3, 45.4) ---------------------------------------------
    judgment = evaluate_time(envelope.validity, clock)
    rule_judgment = evaluate_time(envelope.rule_identity.validity(), clock)
    require_freshness = expectations.require_freshness or envelope.release_policy.require_freshness

    if judgment.time_status in (TimeStatus.EXPIRED, TimeStatus.NOT_YET_VALID):
        deny(
            CheckName.EVIDENCE,
            DenialReason.EVIDENCE_EXPIRED_OR_REVOKED,
            f"envelope validity is {judgment.time_status} against verifier clock "
            f"{clock.source} ({clock.trust_level}): {judgment.detail}",
        )
    elif judgment.time_status == TimeStatus.STALE:
        deny(
            CheckName.NONCE,
            DenialReason.NONCE_STALE_OR_REUSED,
            f"the request identifier's declared freshness window has lapsed: "
            f"{judgment.detail}",
        )
    elif judgment.time_status in (
        TimeStatus.TIME_INDETERMINATE,
        TimeStatus.CLOCK_POLICY_VIOLATION,
    ):
        if require_freshness:
            deny(
                CheckName.CLOCK,
                DenialReason.TIME_INDETERMINATE,
                f"time status is {judgment.time_status} and freshness is required: "
                f"{judgment.detail}.  An indeterminate time claim MUST NOT be reported "
                "as current (spec 45.5)",
            )
        else:
            statuses[CheckName.CLOCK] = CheckStatus.UNCHECKED
            warnings.append(
                f"time status is {judgment.time_status}; freshness was not required, so "
                "the envelope was accepted with its validity undecided (spec 45.5)"
            )
    else:
        passed(CheckName.CLOCK)

    if rule_judgment.time_status in (
        TimeStatus.EXPIRED,
        TimeStatus.NOT_YET_VALID,
        TimeStatus.STALE,
    ):
        deny(
            CheckName.RULE,
            DenialReason.RULE_UNAUTHORIZED_OR_EXPIRED,
            f"transformation rule {envelope.rule_identity.versioned_id} is "
            f"{rule_judgment.time_status}: {rule_judgment.detail}",
        )

    # -- nonce ----------------------------------------------------------
    replay_checked = ledger is not None
    if ledger is None:
        statuses[CheckName.NONCE] = (
            statuses[CheckName.NONCE]
            if statuses[CheckName.NONCE] == CheckStatus.DENY
            else CheckStatus.UNCHECKED
        )
        warnings.append(
            "no nonce ledger was supplied, so replay was not checked; this verifier "
            "cannot distinguish a fresh request from a replayed one (spec 35.4)"
        )
    elif ledger.seen(envelope.nonce):
        deny(
            CheckName.NONCE,
            DenialReason.NONCE_STALE_OR_REUSED,
            f"nonce {envelope.nonce!r} has already been consumed by this verifier; a "
            "replayed request identifier denies an affirmative result (spec 35.4)",
        )
    else:
        passed(CheckName.NONCE)

    # -- context ---------------------------------------------------------
    if expectations.target_context_fingerprint is None:
        warnings.append(
            "the verifier declared no expected target context, so the context check "
            "did not apply; an envelope's own fingerprint cannot corroborate itself "
            "(spec 35.4)"
        )
    elif not envelope.matches_context(expectations.target_context_fingerprint):
        deny(
            CheckName.CONTEXT,
            DenialReason.CONTEXT_MISMATCH,
            f"envelope target context {envelope.target_context_fingerprint} does not "
            f"match the expected {expectations.target_context_fingerprint}",
        )
    else:
        passed(CheckName.CONTEXT)

    # -- rule authorization ----------------------------------------------
    if expectations.authorized_rules:
        pair = (envelope.rule_identity.rule_id, envelope.rule_identity.rule_version)
        if pair not in expectations.authorized_rules:
            deny(
                CheckName.RULE,
                DenialReason.RULE_UNAUTHORIZED_OR_EXPIRED,
                f"transformation rule {envelope.rule_identity.versioned_id} is not among "
                "the rules this verifier authorizes "
                f"({', '.join(f'{r}@{v}' for r, v in expectations.authorized_rules)})",
            )
        else:
            passed(CheckName.RULE)
    elif statuses[CheckName.RULE] != CheckStatus.DENY:
        passed(CheckName.RULE)

    # -- code identity ----------------------------------------------------
    if expectations.expected_code_identity is None and not expectations.require_attestation:
        if attestation is not None:
            passed(CheckName.CODE_IDENTITY)
    elif attestation is None:
        deny(
            CheckName.CODE_IDENTITY,
            DenialReason.CODE_IDENTITY_UNEXPECTED,
            "this verifier requires an attestation of the evaluating code and none was "
            "supplied; unattested code is unexpected code (spec 35.4)",
        )
    elif not attestation.matches(expectations.expected_code_identity):
        deny(
            CheckName.CODE_IDENTITY,
            DenialReason.CODE_IDENTITY_UNEXPECTED,
            f"attested code identity {attestation.code_identity!r} is not the expected "
            f"{expectations.expected_code_identity!r}",
        )
    elif (
        expectations.expected_input_commitment is not None
        and not attestation.commits_to(expectations.expected_input_commitment)
    ):
        deny(
            CheckName.CODE_IDENTITY,
            DenialReason.CODE_IDENTITY_UNEXPECTED,
            f"the attestation commits to inputs {attestation.input_commitment!r}, not "
            f"the expected {expectations.expected_input_commitment!r}",
        )
    else:
        passed(CheckName.CODE_IDENTITY)

    # -- evidence: revocation ---------------------------------------------
    if not envelope.revocation.issuer_asserts_active:
        deny(
            CheckName.EVIDENCE,
            DenialReason.EVIDENCE_EXPIRED_OR_REVOKED,
            f"the envelope's own revocation state is {envelope.revocation.state}",
        )
    if registry.is_revoked(envelope.envelope_id):
        entry = registry.entry(envelope.envelope_id)
        deny(
            CheckName.EVIDENCE,
            DenialReason.EVIDENCE_EXPIRED_OR_REVOKED,
            f"envelope {envelope.envelope_id!r} is revoked in registry "
            f"{registry.registry_id!r}"
            + (f": {entry.reason}" if entry is not None and entry.reason else "")
            + ".  The registry's answer prevails over the signed assertion (spec 35.2)",
        )
    if registry.is_revoked(envelope.evidence_root) or (
        envelope.evidence_root in expectations.revoked_evidence_roots
    ):
        deny(
            CheckName.EVIDENCE,
            DenialReason.EVIDENCE_EXPIRED_OR_REVOKED,
            f"the evidence root {envelope.evidence_root} behind this result is revoked",
        )
    if statuses[CheckName.EVIDENCE] != CheckStatus.DENY:
        passed(CheckName.EVIDENCE)

    # -- required uncertainty ----------------------------------------------
    require_uncertainty = (
        expectations.require_uncertainty or envelope.release_policy.require_uncertainty
    )
    if not require_uncertainty:
        statuses[CheckName.UNCERTAINTY] = CheckStatus.NOT_APPLICABLE
    elif not envelope.bounded_result.uncertainty_declared:
        deny(
            CheckName.UNCERTAINTY,
            DenialReason.REQUIRED_UNCERTAINTY_MISSING,
            "the bounded result declares no uncertainty budget; the five components of "
            "33.4 are required here and their absence is not a declaration of zero "
            "(spec 35.4)",
        )
    else:
        passed(CheckName.UNCERTAINTY)

    # -- access -------------------------------------------------------------
    requester = expectations.requester
    authorization_refusal = envelope.authorization.refusal(requester)
    policy_refusal = envelope.release_policy.refusal(requester)
    if authorization_refusal:
        deny(CheckName.ACCESS, DenialReason.ACCESS_POLICY_FORBIDS, authorization_refusal)
    elif policy_refusal:
        deny(CheckName.ACCESS, DenialReason.ACCESS_POLICY_FORBIDS, policy_refusal)
    else:
        passed(CheckName.ACCESS)

    accepted = not denials
    nonce_consumed = False
    if accepted and ledger is not None:
        nonce_consumed = ledger.consume(envelope.nonce)

    return VerificationOutcome(
        envelope_id=envelope.envelope_id,
        accepted=accepted,
        denials=tuple(
            sorted(denials, key=lambda d: (DenialReason.ORDER.index(d.reason), d.check))
        ),
        checks=tuple((name, statuses[name]) for name in CHECK_ORDER),
        time_judgment=judgment,
        rule_time_judgment=rule_judgment,
        signature_profile=envelope.signature_profile,
        signature_verified=signature_verified,
        signature_detail=signature_detail,
        attestation=attestation,
        attestation_scope=(
            attestation.scope_statement if attestation is not None else ATTESTATION_SCOPE_STATEMENT
        ),
        replay_checked=replay_checked,
        nonce_consumed=nonce_consumed,
        clock=clock,
        warnings=tuple(dict.fromkeys(warnings)),
        verification_basis=(
            "spec 35.4: an affirmative result is denied on any of the nine listed "
            "conditions; each denial carries its own reason code",
            "spec 14.5: a valid signature proves control of the signing key over the "
            "signed content; it does not prove scientific, mathematical, or commercial "
            "correctness",
            "spec 45.3: the time judgment reports issuer-asserted times, the verifier's "
            "evaluation time, its clock source and declared trust level, and the "
            "resulting status",
            f"envelope fingerprint {envelope.fingerprint()}",
        ),
    )
