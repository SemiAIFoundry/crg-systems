"""The capability envelope of specification 35.2.

Normative basis: master specification 35.2 (the twelve things an envelope
MUST bind), 33.6 (the bounded coordinate it carries), 45 (the clock
assertion), 14.1--14.5 (identity, canonicalization, hashing, signature),
and 44.2 (authorization).

A capability envelope is what leaves the organization.  It carries a single
bounded result and everything a stranger needs in order to decide whether
to believe it -- and, just as importantly, everything they need in order to
decide *not* to.  Nothing in it is optional in the sense of "may be
omitted": :data:`ENVELOPE_REQUIRED_ITEMS` audits all twelve bindings and
:meth:`CapabilityEnvelope.check_required_items` reports any that are absent.

The signature covers a canonical payload from which exactly one field is
excluded -- the signature itself -- and 14.3 requires that exclusion to be
declared, so it is recorded on the signature object rather than left as
folklore.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, Optional, Sequence, Tuple, Union

from crg_model.canonical import content_hash
from crg_model.numeric import Exact, Interval
from etq_evidence import (
    AccessPolicy,
    ApplicabilityRule,
    BoundedCoordinate,
    ClockTrust,
    ContextDescriptor,
    CorrelationAssumption,
    Requester,
    UncertaintyBudget,
    ValidityWindow,
    VerificationClock,
)

from .policy import ReleaseKind, ReleasePolicy
from .revocation import RevocationBinding, RevocationState
from .signing import (
    SIGNATURE_PROFILE,
    AttestationRecord,
    EnvelopeSignature,
    SigningKey,
    sign_payload,
)

__all__ = [
    "EnvelopeError",
    "ENVELOPE_REQUIRED_ITEMS",
    "SIGNATURE_EXCLUDED_FIELDS",
    "BoundedResult",
    "RuleIdentity",
    "Authorization",
    "ClockAssertion",
    "VerificationProgram",
    "CapabilityEnvelope",
    "evidence_root_commitment",
    "issue_envelope",
]


class EnvelopeError(ValueError):
    """Raised when an envelope binding is missing or malformed."""


#: The twelve bindings specification 35.2 requires.
ENVELOPE_REQUIRED_ITEMS: Tuple[str, ...] = (
    "bounded coordinate or result",
    "target-context fingerprint",
    "transformation-rule identity and version",
    "evidence-root commitment",
    "issuer",
    "authorization",
    "validity period",
    "nonce or request identifier",
    "revocation state",
    "release policy",
    "clock assertion",
    "signature or attestation",
    "verification program",
)

#: 14.3 requires a canonicalization profile to declare its signature-excluded
#: fields.  Exactly one field is excluded.
SIGNATURE_EXCLUDED_FIELDS: Tuple[str, ...] = ("signature",)


@dataclass(frozen=True)
class BoundedResult:
    """The bounded coordinate or result the envelope binds (35.2, 33.6).

    ``uncertainty_declared`` is a separate flag from a non-empty budget so
    that "no uncertainty was declared" and "uncertainty was declared to be
    zero" stay distinguishable; 35.4 denies affirmative results when
    required uncertainty is *missing*, and those two are not the same claim.
    """

    coordinate_id: str
    quantity: str
    unit: str
    bound: Interval
    direction: str = "MINIMIZE"
    uncertainty: Optional[UncertaintyBudget] = None
    correlation_assumption: str = CorrelationAssumption.UNKNOWN
    uncertainty_statement: str = ""
    bound_derivation: str = ""

    def __post_init__(self) -> None:
        if not isinstance(self.bound, Interval):
            raise EnvelopeError("a bounded result must carry an exact Interval (spec 14.2)")
        if self.correlation_assumption not in CorrelationAssumption.ALL:
            raise EnvelopeError(
                f"unknown correlation assumption {self.correlation_assumption!r} (spec 33.4)"
            )

    @classmethod
    def from_bounded_coordinate(cls, bounded: BoundedCoordinate) -> "BoundedResult":
        return cls(
            coordinate_id=bounded.coordinate_id,
            quantity=bounded.quantity,
            unit=bounded.unit,
            bound=bounded.bound,
            direction=bounded.direction,
            uncertainty=bounded.uncertainty,
            correlation_assumption=bounded.correlation_assumption,
            uncertainty_statement=bounded.uncertainty_statement,
            bound_derivation=bounded.bound_derivation,
        )

    @property
    def uncertainty_declared(self) -> bool:
        """True when a five-component budget of 33.4 accompanies the bound."""
        if self.uncertainty is None:
            return False
        return not self.uncertainty.is_empty

    @property
    def declared_components(self) -> Tuple[str, ...]:
        if self.uncertainty is None:
            return ()
        return self.uncertainty.declared_components

    def to_canonical(self) -> dict:
        record: dict = {
            "coordinate_id": self.coordinate_id,
            "quantity": self.quantity,
            "unit": self.unit,
            "direction": self.direction,
            "bound": self.bound.to_canonical(),
            "uncertainty_declared": self.uncertainty_declared,
            "correlation_assumption": self.correlation_assumption,
        }
        if self.uncertainty is not None:
            record["uncertainty"] = self.uncertainty.to_canonical()
        if self.uncertainty_statement:
            record["uncertainty_statement"] = self.uncertainty_statement
        if self.bound_derivation:
            record["bound_derivation"] = self.bound_derivation
        return record


@dataclass(frozen=True)
class RuleIdentity:
    """The transformation rule's identity and version (35.2).

    Identity alone is insufficient: 18.3's ``DEPENDS_ON_RULE_VERSION`` edge
    exists precisely because a rule can change while keeping its name, so a
    version and a content hash both travel.
    """

    rule_id: str
    rule_version: str
    rule_hash: str
    authority: str = ""
    expiration: Optional[str] = None
    validation_basis: str = ""

    def __post_init__(self) -> None:
        if not str(self.rule_id).strip():
            raise EnvelopeError("an envelope must bind a transformation-rule identity (35.2)")
        if not str(self.rule_version).strip():
            raise EnvelopeError(
                "an envelope must bind the transformation-rule *version*; identity "
                "alone cannot detect a changed rule (spec 35.2, 18.3)"
            )

    @classmethod
    def from_rule(cls, rule: ApplicabilityRule) -> "RuleIdentity":
        return cls(
            rule_id=rule.rule_id,
            rule_version=rule.rule_version,
            rule_hash=rule.fingerprint(),
            authority=rule.authority,
            expiration=rule.expiration,
            validation_basis=rule.validation_basis,
        )

    @property
    def versioned_id(self) -> str:
        return f"{self.rule_id}@{self.rule_version}"

    def validity(self) -> ValidityWindow:
        return ValidityWindow(
            expires_at=self.expiration, issuer_clock_source="rule-authority-asserted"
        )

    def to_canonical(self) -> dict:
        record: dict = {
            "rule_id": self.rule_id,
            "rule_version": self.rule_version,
            "rule_hash": self.rule_hash,
        }
        for key, value in (
            ("authority", self.authority),
            ("expiration", self.expiration),
            ("validation_basis", self.validation_basis),
        ):
            if value:
                record[key] = value
        return record


@dataclass(frozen=True)
class Authorization:
    """Who authorized this envelope, and to whom it may be shown (35.2, 44.2)."""

    authority: str
    scopes: Tuple[str, ...] = ()
    permitted_roles: Tuple[str, ...] = ()
    permitted_subjects: Tuple[str, ...] = ()
    access: AccessPolicy = field(default_factory=AccessPolicy)
    basis: str = ""

    def __post_init__(self) -> None:
        if not str(self.authority).strip():
            raise EnvelopeError("an envelope must bind an authorization authority (35.2)")
        object.__setattr__(self, "scopes", tuple(sorted(str(s) for s in self.scopes)))
        object.__setattr__(
            self, "permitted_roles", tuple(sorted(str(r) for r in self.permitted_roles))
        )
        object.__setattr__(
            self, "permitted_subjects", tuple(sorted(str(s) for s in self.permitted_subjects))
        )

    def permits(self, requester: Optional[Requester]) -> bool:
        if not self.access.permits(requester):
            return False
        if not self.permitted_roles and not self.permitted_subjects:
            return True
        if requester is None:
            return False
        if requester.subject_id in self.permitted_subjects:
            return True
        return bool(set(requester.roles) & set(self.permitted_roles))

    def refusal(self, requester: Optional[Requester]) -> str:
        if self.permits(requester):
            return ""
        access_refusal = self.access.refusal(requester)
        if access_refusal:
            return access_refusal
        if requester is None:
            return (
                f"authorization by {self.authority!r} restricts disclosure to declared "
                "subjects or roles and no requester was identified"
            )
        return (
            f"requester {requester.subject_id!r} with roles {list(requester.roles)} is "
            f"not authorized by {self.authority!r}"
        )

    def to_canonical(self) -> dict:
        record: dict = {"authority": self.authority, "access": self.access.to_canonical()}
        for key, value in (
            ("scopes", list(self.scopes)),
            ("permitted_roles", list(self.permitted_roles)),
            ("permitted_subjects", list(self.permitted_subjects)),
        ):
            if value:
                record[key] = value
        if self.basis:
            record["basis"] = self.basis
        return record


@dataclass(frozen=True)
class ClockAssertion:
    """The issuer's own clock claim, bound by the signature (35.2, 45.2).

    Specification 45.2 makes issue and validity times assertions of the
    issuer; binding the clock *source* and declared trust level alongside
    them lets a verifier report 45.3's five items without guessing.
    """

    asserted_at: Optional[str] = None
    clock_source: str = "issuer-asserted"
    trust_level: str = ClockTrust.LOCAL_DECLARED

    def __post_init__(self) -> None:
        if self.trust_level not in ClockTrust.ALL:
            raise EnvelopeError(f"unknown clock trust level {self.trust_level!r} (spec 45.3)")

    def to_canonical(self) -> dict:
        record: dict = {
            "clock_source": self.clock_source,
            "trust_level": self.trust_level,
            "semantics": "issuer assertion, bound by signature (spec 45.2)",
        }
        if self.asserted_at is not None:
            record["asserted_at"] = self.asserted_at
        return record


@dataclass(frozen=True)
class VerificationProgram:
    """The checks the issuer declares a verifier must run (35.2).

    A verifier that cannot run a declared check must not pretend it passed.
    :func:`etq_federation.verify.verify_envelope` compares this list against
    the checks it implements and denies when the issuer asks for something
    it does not have.
    """

    program_id: str
    program_hash: str = ""
    interpreter: str = "etq-federation.verify"
    checks: Tuple[str, ...] = ()
    basis: str = ""

    def __post_init__(self) -> None:
        object.__setattr__(self, "checks", tuple(sorted(str(c) for c in self.checks)))
        if not self.program_hash:
            object.__setattr__(
                self,
                "program_hash",
                content_hash(
                    {
                        "program_id": self.program_id,
                        "interpreter": self.interpreter,
                        "checks": list(self.checks),
                    }
                ),
            )

    def to_canonical(self) -> dict:
        record: dict = {
            "program_id": self.program_id,
            "program_hash": self.program_hash,
            "interpreter": self.interpreter,
            "checks": list(self.checks),
        }
        if self.basis:
            record["basis"] = self.basis
        return record


def evidence_root_commitment(evidence: Any) -> str:
    """A commitment to the evidence set behind a result (35.2).

    Accepts a ready-made commitment string, or any iterable of evidence
    hashes, which is folded into one ``sha256:`` value over the sorted,
    de-duplicated set.  Sorting is required: the set of supporting evidence
    has no semantic order (14.3).
    """
    if evidence is None:
        raise EnvelopeError("an envelope must bind an evidence-root commitment (35.2)")
    if isinstance(evidence, str):
        if not evidence.strip():
            raise EnvelopeError("evidence-root commitment is empty (spec 35.2)")
        return evidence
    hashes = sorted({str(h) for h in evidence})
    if not hashes:
        raise EnvelopeError(
            "evidence-root commitment over an empty evidence set; an envelope that "
            "commits to nothing binds nothing (spec 35.2)"
        )
    return content_hash({"evidence_root": hashes, "algorithm": "sha256-sorted-set"})


@dataclass(frozen=True)
class CapabilityEnvelope:
    """The twelve bindings of specification 35.2, plus an identity.

    Everything except :attr:`signature` is inside the signed payload, which
    means the issuer's revocation and clock assertions are tamper-evident --
    and also means they are frozen at issuance, which is why a verifier
    consults a live revocation registry and its own clock as well.
    """

    envelope_id: str
    bounded_result: BoundedResult
    target_context_fingerprint: str
    rule_identity: RuleIdentity
    evidence_root: str
    issuer: str
    authorization: Authorization
    validity: ValidityWindow
    nonce: str
    revocation: RevocationBinding
    release_policy: ReleasePolicy
    clock_assertion: ClockAssertion
    verification_program: VerificationProgram
    signature: Optional[EnvelopeSignature] = None
    attestation: Optional[AttestationRecord] = None
    target_context_id: str = ""
    schema_version: str = "0.2.0"

    def __post_init__(self) -> None:
        if not str(self.envelope_id).strip():
            raise EnvelopeError("an envelope requires an identity (spec 14.1)")
        if not str(self.target_context_fingerprint).strip():
            raise EnvelopeError(
                "an envelope must bind a target-context fingerprint; without it the "
                "result is a number from nowhere (spec 35.2)"
            )
        if not str(self.issuer).strip():
            raise EnvelopeError("an envelope must bind an issuer (spec 35.2)")
        if not str(self.nonce).strip():
            raise EnvelopeError(
                "an envelope must bind a nonce or request identifier; without one no "
                "verifier can detect replay (spec 35.2, 35.4)"
            )

    # -- signing ------------------------------------------------------
    def signing_payload(self) -> dict:
        """The canonical payload the signature covers (14.3).

        Every binding except :attr:`signature` is included, so tampering
        with the release policy, the revocation assertion, or the nonce
        invalidates the signature.
        """
        payload = self.to_canonical()
        for excluded in SIGNATURE_EXCLUDED_FIELDS:
            payload.pop(excluded, None)
        return payload

    def signed(self, key: SigningKey) -> "CapabilityEnvelope":
        signature = sign_payload(
            self.signing_payload(),
            key,
            excluded_fields=SIGNATURE_EXCLUDED_FIELDS,
            created_at=self.clock_assertion.asserted_at,
        )
        return dataclasses_replace(self, signature=signature)

    # -- accessors ----------------------------------------------------
    @property
    def coordinate_id(self) -> str:
        return self.bounded_result.coordinate_id

    @property
    def bound(self) -> Interval:
        return self.bounded_result.bound

    @property
    def signature_profile(self) -> str:
        return self.signature.profile if self.signature is not None else "UNSIGNED"

    def matches_context(self, expected: Union[str, ContextDescriptor, None]) -> bool:
        if expected is None:
            return True
        fingerprint = (
            expected.fingerprint() if isinstance(expected, ContextDescriptor) else str(expected)
        )
        return fingerprint == self.target_context_fingerprint

    def check_required_items(self) -> Dict[str, str]:
        """Presence audit against the twelve bindings of 35.2."""
        present = {
            "bounded coordinate or result": self.bounded_result is not None,
            "target-context fingerprint": bool(self.target_context_fingerprint),
            "transformation-rule identity and version": bool(
                self.rule_identity and self.rule_identity.rule_version
            ),
            "evidence-root commitment": bool(self.evidence_root),
            "issuer": bool(self.issuer),
            "authorization": self.authorization is not None,
            "validity period": self.validity is not None,
            "nonce or request identifier": bool(self.nonce),
            "revocation state": self.revocation is not None,
            "release policy": self.release_policy is not None,
            "clock assertion": self.clock_assertion is not None,
            "signature or attestation": self.signature is not None or self.attestation is not None,
            "verification program": self.verification_program is not None,
        }
        return {
            item: ("PRESENT" if present[item] else "ABSENT") for item in ENVELOPE_REQUIRED_ITEMS
        }

    def to_canonical(self) -> dict:
        record: dict = {
            "schema_version": self.schema_version,
            "envelope_id": self.envelope_id,
            "bounded_result": self.bounded_result.to_canonical(),
            "target_context_fingerprint": self.target_context_fingerprint,
            "rule_identity": self.rule_identity.to_canonical(),
            "evidence_root": self.evidence_root,
            "issuer": self.issuer,
            "authorization": self.authorization.to_canonical(),
            "validity": self.validity.to_canonical(),
            "nonce": self.nonce,
            "revocation": self.revocation.to_canonical(),
            "release_policy": self.release_policy.to_canonical(),
            "clock_assertion": self.clock_assertion.to_canonical(),
            "verification_program": self.verification_program.to_canonical(),
        }
        if self.target_context_id:
            record["target_context_id"] = self.target_context_id
        if self.attestation is not None:
            record["attestation"] = self.attestation.to_canonical()
        if self.signature is not None:
            record["signature"] = self.signature.to_canonical()
        return record

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())


def dataclasses_replace(envelope: CapabilityEnvelope, **changes: Any) -> CapabilityEnvelope:
    import dataclasses as _dc

    return _dc.replace(envelope, **changes)


def issue_envelope(
    bound: Union[BoundedResult, BoundedCoordinate],
    target_context: Union[ContextDescriptor, str],
    rule: Union[RuleIdentity, ApplicabilityRule],
    evidence_root: Any,
    *,
    issuer: str,
    key: SigningKey,
    validity: ValidityWindow,
    nonce: str,
    authorization: Optional[Authorization] = None,
    release_policy: Optional[ReleasePolicy] = None,
    revocation: Optional[RevocationBinding] = None,
    clock_assertion: Optional[ClockAssertion] = None,
    verification_program: Optional[VerificationProgram] = None,
    attestation: Optional[AttestationRecord] = None,
    envelope_id: Optional[str] = None,
) -> CapabilityEnvelope:
    """Mint and sign a capability envelope (35.2).

    Defaults are refusals, not conveniences.  An omitted release policy
    authorizes a Boolean and nothing more (35.3).  An omitted authorization
    is ``confidential`` with no permitted role or subject, which denies
    *every* requester -- the envelope carries a bounded result in the clear,
    so who may hold it has to be declared rather than inferred (6.6, 44.2).
    An omitted revocation binding asserts ``ACTIVE`` while naming no
    registry, which a verifier treats as an unchecked revocation state
    rather than a clean one.
    """
    if not isinstance(key, SigningKey):
        raise EnvelopeError("issue_envelope requires a SigningKey (spec 14.5)")
    if not isinstance(validity, ValidityWindow):
        raise EnvelopeError("issue_envelope requires a ValidityWindow (spec 35.2, 45.2)")
    if not str(nonce or "").strip():
        raise EnvelopeError(
            "issue_envelope requires a nonce or request identifier; replay detection "
            "is not optional (spec 35.2, 35.4)"
        )

    result = (
        bound
        if isinstance(bound, BoundedResult)
        else BoundedResult.from_bounded_coordinate(bound)
    )
    identity = rule if isinstance(rule, RuleIdentity) else RuleIdentity.from_rule(rule)
    if isinstance(target_context, ContextDescriptor):
        fingerprint = target_context.fingerprint()
        context_id = target_context.context_id
    else:
        fingerprint = str(target_context)
        context_id = ""

    envelope = CapabilityEnvelope(
        envelope_id=envelope_id or f"env-{nonce}",
        bounded_result=result,
        target_context_fingerprint=fingerprint,
        target_context_id=context_id,
        rule_identity=identity,
        evidence_root=evidence_root_commitment(evidence_root),
        issuer=str(issuer),
        authorization=authorization
        or Authorization(
            authority=str(issuer),
            access=AccessPolicy(classification="confidential"),
            basis=(
                "default: no recipient is authorized.  An envelope binds a bounded "
                "result in the clear, so the set of holders is declared explicitly or "
                "not at all (spec 6.6, 44.2)"
            ),
        ),
        validity=validity,
        nonce=str(nonce),
        revocation=revocation
        or RevocationBinding(
            state=RevocationState.ACTIVE,
            asserted_at=validity.issued_at,
            basis="issuer assertion at issuance; no registry named",
        ),
        release_policy=release_policy
        or ReleasePolicy.minimal(
            f"release-{nonce}",
            basis="default: minimum disclosure, a single Boolean (spec 35.3)",
        ),
        clock_assertion=clock_assertion
        or ClockAssertion(
            asserted_at=validity.issued_at,
            clock_source=f"{issuer}-declared",
            trust_level=ClockTrust.LOCAL_DECLARED,
        ),
        verification_program=verification_program
        or VerificationProgram(
            program_id=f"vp-{nonce}",
            checks=(
                "signature",
                "nonce",
                "context",
                "rule",
                "code_identity",
                "evidence",
                "uncertainty",
                "clock",
                "access",
            ),
            basis="default: the nine fail-closed checks of specification 35.4",
        ),
        attestation=attestation,
    )
    return envelope.signed(key)
