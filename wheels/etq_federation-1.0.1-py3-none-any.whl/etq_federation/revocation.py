"""Revocation state and the registry a verifier consults.

Normative basis: master specification 35.2 (revocation state is a bound
field of the capability envelope), 35.4 (revoked evidence denies an
affirmative result), and 17 (deletion, retention, and tombstones).

A subtlety the specification implies and this module makes explicit: the
``revocation_state`` *inside* the envelope is the issuer's assertion at
issuance, and it is inside the signature, so it can never say anything
other than what was true when the envelope was minted.  Revocation happens
afterwards, which is why the verifier must consult an external registry as
well.  Where the two disagree the registry wins -- a live "revoked" always
beats a signed "active".
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, Mapping, Optional, Set, Tuple

__all__ = [
    "RevocationError",
    "RevocationState",
    "RevocationBinding",
    "RevocationEntry",
    "RevocationRegistry",
    "revoke",
]


class RevocationError(ValueError):
    """Raised when a revocation declaration is malformed."""


class RevocationState:
    """Declared revocation status of an envelope."""

    ACTIVE = "ACTIVE"
    REVOKED = "REVOKED"
    SUSPENDED = "SUSPENDED"
    #: The verifier could not determine the state.  Fail closed: an
    #: undetermined revocation state denies an affirmative result (6.6, 35.4).
    UNKNOWN = "UNKNOWN"

    ALL = frozenset({ACTIVE, REVOKED, SUSPENDED, UNKNOWN})
    #: Only one state permits an affirmative capability answer.
    AFFIRMATIVE = frozenset({ACTIVE})

    @classmethod
    def check(cls, state: str) -> str:
        if state not in cls.ALL:
            raise RevocationError(
                f"unknown revocation state {state!r}; expected one of {sorted(cls.ALL)}"
            )
        return state


@dataclass(frozen=True)
class RevocationBinding:
    """The revocation field bound into the envelope (35.2).

    ``state`` is the issuer's assertion at issuance.  ``registry_id`` and
    ``registry_uri`` tell the verifier where the live answer lives, because
    the signed assertion cannot be updated after the fact.
    """

    state: str = RevocationState.ACTIVE
    registry_id: str = ""
    registry_uri: str = ""
    asserted_at: Optional[str] = None
    basis: str = ""

    def __post_init__(self) -> None:
        RevocationState.check(self.state)

    @property
    def issuer_asserts_active(self) -> bool:
        return self.state in RevocationState.AFFIRMATIVE

    def to_canonical(self) -> dict:
        record: dict = {
            "state": self.state,
            "semantics": (
                "issuer assertion at issuance; the verifier MUST also consult the "
                "named registry, whose answer prevails (spec 35.2, 35.4)"
            ),
        }
        for key, value in (
            ("registry_id", self.registry_id),
            ("registry_uri", self.registry_uri),
            ("asserted_at", self.asserted_at),
            ("basis", self.basis),
        ):
            if value:
                record[key] = value
        return record


@dataclass(frozen=True)
class RevocationEntry:
    """One revoked identity, with its declared reason and instant."""

    subject_id: str
    state: str = RevocationState.REVOKED
    reason: str = ""
    revoked_at: Optional[str] = None
    authority: str = ""

    def __post_init__(self) -> None:
        RevocationState.check(self.state)

    def to_canonical(self) -> dict:
        record: dict = {"subject_id": self.subject_id, "state": self.state}
        for key, value in (
            ("reason", self.reason),
            ("revoked_at", self.revoked_at),
            ("authority", self.authority),
        ):
            if value:
                record[key] = value
        return record


class RevocationRegistry:
    """The set of revoked envelopes and evidence roots a verifier consults.

    Identities are opaque strings, so the same registry holds envelope
    identifiers, evidence-root commitments, and key identifiers.  Membership
    denies; absence does not affirm -- a verifier that cannot reach a
    registry should say so rather than treat silence as ``ACTIVE``.
    """

    def __init__(
        self,
        entries: Iterable[Any] = (),
        *,
        registry_id: str = "revocation-registry",
        authority: str = "",
    ) -> None:
        self.registry_id = str(registry_id)
        self.authority = str(authority)
        self._entries: Dict[str, RevocationEntry] = {}
        for entry in entries or ():
            if isinstance(entry, RevocationEntry):
                self._entries[entry.subject_id] = entry
            else:
                self.revoke(str(entry))

    def revoke(
        self,
        subject_id: str,
        *,
        reason: str = "",
        revoked_at: Optional[str] = None,
        state: str = RevocationState.REVOKED,
        authority: Optional[str] = None,
    ) -> RevocationEntry:
        """Record a revocation.  Idempotent: re-revoking keeps the first entry."""
        subject_id = str(subject_id)
        if not subject_id.strip():
            raise RevocationError("cannot revoke an empty identity")
        existing = self._entries.get(subject_id)
        if existing is not None:
            return existing
        entry = RevocationEntry(
            subject_id=subject_id,
            state=RevocationState.check(state),
            reason=reason,
            revoked_at=revoked_at,
            authority=authority if authority is not None else self.authority,
        )
        self._entries[subject_id] = entry
        return entry

    def is_revoked(self, subject_id: str) -> bool:
        entry = self._entries.get(str(subject_id))
        return entry is not None and entry.state not in RevocationState.AFFIRMATIVE

    def entry(self, subject_id: str) -> Optional[RevocationEntry]:
        return self._entries.get(str(subject_id))

    def __contains__(self, subject_id: object) -> bool:
        return self.is_revoked(str(subject_id))

    def __len__(self) -> int:
        return len(self._entries)

    @property
    def subjects(self) -> Tuple[str, ...]:
        return tuple(sorted(self._entries))

    def to_canonical(self) -> dict:
        return {
            "registry_id": self.registry_id,
            "authority": self.authority,
            "entries": [self._entries[s].to_canonical() for s in self.subjects],
        }


def revoke(envelope_id: str, registry: RevocationRegistry, **kwargs: Any) -> None:
    """Revoke a capability envelope in ``registry`` (35.2, 35.4).

    Accepts an envelope identifier or a :class:`CapabilityEnvelope`; the
    call is idempotent and returns nothing, because the registry is the
    record of the act.
    """
    if not isinstance(registry, RevocationRegistry):
        raise RevocationError("revoke requires a RevocationRegistry")
    subject = getattr(envelope_id, "envelope_id", envelope_id)
    registry.revoke(str(subject), **kwargs)


def as_registry(revocations: Any) -> RevocationRegistry:
    """Normalize a registry, a set of identifiers, or ``None`` to a registry."""
    if revocations is None:
        return RevocationRegistry(registry_id="empty-revocation-registry")
    if isinstance(revocations, RevocationRegistry):
        return revocations
    if isinstance(revocations, Mapping):
        return RevocationRegistry(revocations.values())
    return RevocationRegistry(tuple(revocations))
