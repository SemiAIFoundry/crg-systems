"""crg-cli: the headless ``crg`` command line.

Reference implementation of master specification section 40, wired so that
the Minimum Credible Loop of section 54.2 runs end to end::

    import registry -> canonicalize -> R / Gamma / K -> compile query
    -> certify -> apply change -> delta certificate -> independently verify

The last arrow is the one that matters.  ``crg verify`` runs ``crg-verify``,
which shares no code with the modules that produced the artifact, so
54.4's exit gate -- "complete all checks without the originating server" --
is satisfied by construction rather than by assertion.
"""
from .main import build_parser, main
from .output import OK, QUIET, STREAM, USAGE, VIOLATION, Emitter

__version__ = "1.5.0"
SPEC_VERSION = "0.2.0"

__all__ = [
    "Emitter",
    "OK",
    "QUIET",
    "SPEC_VERSION",
    "STREAM",
    "USAGE",
    "VIOLATION",
    "build_parser",
    "main",
]
