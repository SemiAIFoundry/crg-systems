"""``crg`` -- the headless CRG command line.

Normative basis: 40 (CLI specification), 39 (portable ``.crg`` artifact),
50 (canonical human-readable report), 54 (Minimum Credible Loop).

The whole loop of 54.2 is runnable here::

    crg init      -> crg import    -> crg geometry -> crg query compile
    -> crg certify -> crg change   -> crg export   -> crg verify

and 54.4's exit gate is the point: the last step must succeed with the
originating process gone.  ``crg verify`` therefore uses ``crg-verify``,
which imports none of the modules that produced the artifact.
"""
from __future__ import annotations

import argparse
import datetime as _dt
import json
import os
import sys
import tempfile
import zipfile
from typing import Any, Dict, List, Mapping, Optional, Sequence

from crg_model.canonical import canonical_json, content_hash
from crg_model.completeness import CompletenessBasisType
from crg_model.edges import DependencyEdge, DependencyGraph, EdgeType
from crg_model.envelope import utc_now
from crg_model.migration import (
    DEFAULT_MIGRATION_REGISTRY,
    MIGRATION_CLASSES,
    MigrationError,
)
from crg_model.numeric import Exact
from crg_model.records import ChangeEvent, DecisionOutcome

import crg_certify
import crg_geometry
import crg_io
import crg_verify
from crg_change import apply_change, build_certified_delta
from .intake import (
    mapping_profile_from_document,
    persist_registry_intake,
    portable_intake_objects,
    registry_intake_preview_payload,
    source_provenance_from_document,
)
from .comparison import (
    ComparativeVerificationError,
    build_verified_comparative_evaluation,
    comparative_verification_inputs,
    persist_comparative_evaluation,
    portable_comparison_objects,
    render_comparative_evaluation_report,
)
from .journey_comparison import (
    build_verified_comparative_change,
    build_verified_cumulative_comparison,
    inspect_comparative_change,
    inspect_cumulative_comparison,
    persist_comparative_change,
    persist_cumulative_comparison,
    portable_journey_comparison_objects,
    render_comparative_change_report,
    render_cumulative_comparison_report,
    resolve_qualification_operational_sources,
    verify_comparative_change,
    verify_cumulative_comparison,
)
from .challenge import (
    DecisionChallengeVerificationError,
    build_verified_decision_challenge,
    list_decision_challenges,
    persist_decision_challenge,
    portable_decision_challenge_objects,
    read_decision_challenge,
    render_decision_challenge_report,
)
from .lifecycle import (
    DECISION_LIFECYCLE_OPERATIONS,
    ETQ_LIFECYCLE_OPERATIONS,
    LIFECYCLE_RECORD_TYPES,
    RESILIENCE_LIFECYCLE_OPERATIONS,
    LifecycleVerificationError,
    build_verified_lifecycle_record,
    inspect_lifecycle_record,
    persist_lifecycle_record,
    portable_lifecycle_objects,
    render_lifecycle_report,
    verify_lifecycle_record,
)
from .measurement import (
    OperationalMeasurementCliError,
    cmd_counterfactual as cmd_measurement_counterfactual,
    cmd_delete as cmd_measurement_delete,
    cmd_end as cmd_measurement_end,
    cmd_export as cmd_measurement_export,
    cmd_interval as cmd_measurement_interval,
    cmd_list as cmd_measurement_list,
    cmd_observe as cmd_measurement_observe,
    cmd_profile as cmd_measurement_profile,
    cmd_retention_enforce as cmd_measurement_retention_enforce,
    cmd_retention_preview as cmd_measurement_retention_preview,
    cmd_show as cmd_measurement_show,
    cmd_start as cmd_measurement_start,
    cmd_verify as cmd_measurement_verify,
)
from .extensions import (
    assure_first_party_packs,
    render_first_party_pack_assurance,
    render_pack_authoring_report,
    render_source_adapter_verification,
    validate_pack_manifest,
    verify_source_adapter_definition_file,
    verify_source_adapter_output_files,
    verify_source_adapter_report_file,
)
from .report import (
    render_certificate_report,
    render_certified_delta_report,
    render_phase_analysis_report,
)
from .design_space import (
    DesignSpaceError,
    agent_design_space_capabilities,
    produce_agent_design_space,
    produce_agent_design_space_batch,
)

from .adapters import (
    CapabilityUnavailable,
    assemble_contract,
    evidence_record,
    generate_registry,
    layout_conversion,
    qualification_plan,
    run_evaluation,
)
from .output import HUMAN, JSON, OK, QUIET, STREAM, USAGE, VIOLATION, Emitter
from .store import (
    CaseError,
    IO_BACKEND,
    case_dir,
    import_table,
    load_bundle,
    load_derivation,
    load_scope,
    new_case,
    read_case,
    read_query_document,
    record_history,
    write_case,
)

__all__ = ["main", "build_parser"]

VERSION = "1.5.0"

#: Outcomes that constitute an affirmative certification (29.6).  Everything
#: else exits nonzero: 6.6 forbids a blocked or unresolved decision from
#: being presented as a success at the process boundary.
_AFFIRMATIVE = frozenset(
    {
        DecisionOutcome.CERTIFIED_WINNER,
        DecisionOutcome.CERTIFIED_WINNER_SET,
        DecisionOutcome.CERTIFIED_POLICY_TIE,
        DecisionOutcome.CERTIFIED_RETENTION,
    }
)


def _emitter(args: argparse.Namespace) -> Emitter:
    if getattr(args, "quiet", False):
        return Emitter(QUIET)
    if getattr(args, "stream", False):
        return Emitter(STREAM)
    if getattr(args, "as_json", False):
        return Emitter(JSON)
    return Emitter(HUMAN)


def _points(signatures: Sequence[Any]) -> List[List[dict]]:
    return [[v.to_canonical() for v in s.values] for s in signatures]


def _normalize_registry(case: Dict[str, Any]) -> None:
    """Store the registry in exactly the canonical form its hash is taken over.

    Specification 14.3-14.4.  ``RealizationBundle.to_canonical`` omits empty
    optional members, so a stored dict that keeps them would hash differently
    from the bundle the certificate names -- and an independent verifier
    would correctly report a missing dependency.  Round-tripping through the
    kernel's own canonical form removes that whole class of disagreement.
    """
    if case.get("registry"):
        case["registry"] = load_bundle(case).to_canonical()


# ---------------------------------------------------------------------------
# crg init / validate / import / inspect
# ---------------------------------------------------------------------------
def cmd_init(args: argparse.Namespace, out: Emitter) -> int:
    contract: Dict[str, Any] = {}
    if args.contract:
        contract = read_query_document(args.contract)
        if isinstance(contract, str):
            contract = {"contract_text": contract}
    case = new_case(args.case, contract)
    case["created_at"] = utc_now()
    record_history(case, "init", {"at": case["created_at"]})
    path = write_case(args.root, case)
    out.result(
        {"case_id": case["case_id"], "status": case["status"], "path": path,
         "io_backend": IO_BACKEND},
        f"initialized case {case['case_id']!r} at {path}\n  status: DRAFT\n"
        f"  persistence: {IO_BACKEND}",
    )
    return OK


def cmd_import(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    mapping = None
    if args.mapping:
        mapping = read_query_document(args.mapping)
        if isinstance(mapping, str):
            raise CaseError("a registry mapping must be a JSON document")
    registry, report = import_table(
        args.source,
        mapping,
        basis_type=args.completeness,
        declared_universe=args.universe,
        bundle_id=f"bundle-{args.case}",
    )
    case["registry"] = registry
    _normalize_registry(case)
    case["import_report"] = report
    case["status"] = "VALIDATED"
    record_history(case, "import", {"source": report["source"], "accepted": report["accepted"]})
    write_case(args.root, case)

    out.step("import", accepted=report["accepted"], rejected=report["rejected"])
    human = [
        f"imported {report['accepted']} realizations from {report['source']}",
        f"  source fingerprint : {report['source_fingerprint']}",
        f"  identifier column  : {report['identifier_column']}",
        f"  coordinates        : {', '.join(report['coordinates'])}",
        f"  completeness basis : {report['completeness_basis']}",
        f"  declared universe  : {report['declared_universe']}",
        f"  rejected rows      : {report['rejected']}",
    ]
    for rejection in report["rejections"]:
        human.append(f"    - row {rejection.get('row')}: {rejection.get('reason')}")
    out.result(report, "\n".join(human))
    return OK


def _intake_declarations(profile_path: str, provenance_path: str):
    profile = mapping_profile_from_document(
        _json_object(profile_path, "registry mapping profile")
    )
    provenance = source_provenance_from_document(
        _json_object(provenance_path, "registry source provenance")
    )
    return profile, provenance


def cmd_intake_preview(args: argparse.Namespace, out: Emitter) -> int:
    """Preview a source and mapping without reading or writing a case."""
    profile, provenance = _intake_declarations(args.profile, args.provenance)
    preview = crg_io.preview_registry_intake(
        args.source, profile=profile, provenance=provenance
    )
    payload = registry_intake_preview_payload(preview)
    if args.output:
        _write_canonical_document(args.output, payload)
    human = [
        "registry intake preview (no case state changed)",
        f"  preview hash       : {payload['preview_hash']}",
        f"  mapping profile    : {payload['profile_hash']}",
        f"  source snapshot    : {payload['source_snapshot_hash']}",
        f"  rows read          : {preview.rows_read}",
        f"  accepted           : {len(preview.accepted)}",
        f"  rejected           : {len(preview.rejected)}",
        "  completeness basis : EXPLICIT_IMPORTED_FAMILY",
        "  next step          : confirm with --expected-preview-hash equal to this hash",
    ]
    out.result(payload, "\n".join(human))
    return OK


def cmd_intake_confirm(args: argparse.Namespace, out: Emitter) -> int:
    """Re-preview and persist only the exact source/mapping reviewed."""
    profile, provenance = _intake_declarations(args.profile, args.provenance)
    original_case = read_case(args.root, args.case)
    dependent_state = [
        name for name in (
            "geometry", "scope", "derivation", "certificates", "safe_commitments",
            "phase_analyses", "certified_deltas", "deltas",
        )
        if original_case.get(name)
    ]
    if dependent_state:
        raise CaseError(
            "registry intake confirmation cannot replace a family that already has "
            "decision-dependent state: " + ", ".join(dependent_state)
            + "; use the governed change/reopen workflow or a fresh case"
        )
    original_case_hash = content_hash(original_case)
    # Materialize before constructing the successor. A stale preview,
    # malformed row, or unacknowledged rejection therefore leaves the case
    # byte-for-byte untouched; the second read also catches concurrent edits.
    bundle, report, preview = crg_io.materialize_registry_intake(
        args.source,
        profile=profile,
        provenance=provenance,
        expected_preview_hash=args.expected_preview_hash,
        accept_partial=args.accept_partial,
    )
    case = read_case(args.root, args.case)
    if content_hash(case) != original_case_hash:
        raise CaseError(
            "the case changed while registry intake was being confirmed; no successor was written"
        )
    persisted = persist_registry_intake(
        case,
        bundle=bundle,
        report=report,
        preview=preview,
        accept_partial=args.accept_partial,
    )
    # Preserve the CLI's established import lifecycle boundary.  The server
    # continues through its explicit IMPORTED_OR_GENERATED transition.
    case["status"] = "VALIDATED"
    record_history(
        case,
        "registry intake confirm",
        {
            "preview_hash": persisted["preview_hash"],
            "confirmation_hash": persisted["confirmation_hash"],
            "source_snapshot_hash": persisted["source_snapshot_hash"],
            "source_snapshot_record_hash": persisted["source_snapshot_record_hash"],
            "accepted": len(preview.accepted),
            "rejected": len(preview.rejected),
            "partial_import_acknowledged": args.accept_partial,
        },
    )
    path = write_case(args.root, case)
    payload = {
        "record_type": "RegistryIntakeConfirmationResponse",
        "schema_version": "1.0.0",
        "authority": "NON_AUTHORIZING_INTAKE",
        "mutation_performed": True,
        "case_id": case["case_id"],
        "case_path": path,
        **persisted,
    }
    if args.output:
        _write_canonical_document(args.output, payload)
    human = [
        "registry intake confirmed and persisted",
        f"  case               : {case['case_id']}",
        f"  preview hash       : {persisted['preview_hash']}",
        f"  confirmation hash  : {persisted['confirmation_hash']}",
        f"  source snapshot    : {persisted['source_snapshot_hash']}",
        f"  accepted           : {len(preview.accepted)}",
        f"  rejected           : {len(preview.rejected)}",
        f"  partial acknowledged: {str(args.accept_partial).lower()}",
        "  completeness basis : EXPLICIT_IMPORTED_FAMILY",
    ]
    out.result(payload, "\n".join(human))
    return OK


def cmd_validate(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    problems: List[str] = []
    if not case.get("registry"):
        problems.append("no registry imported")
    else:
        try:
            bundle = load_bundle(case)
            dimension = bundle.schema.dimension
            for realization in bundle.realizations:
                if len(realization.signature) != dimension:
                    problems.append(
                        f"{realization.realization_id}: {len(realization.signature)} "
                        f"coordinates against a schema of {dimension}"
                    )
        except (CaseError, ValueError) as error:
            problems.append(str(error))
    payload = {"case_id": case["case_id"], "valid": not problems, "problems": problems}
    out.result(
        payload,
        "case is structurally valid" if not problems
        else "case is INVALID:\n" + "\n".join(f"  - {p}" for p in problems),
    )
    return OK if not problems else VIOLATION


def cmd_inspect(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    registry = case.get("registry") or {}
    completeness = registry.get("completeness") or {}
    payload = {
        "case_id": case["case_id"],
        "status": case.get("status"),
        "realizations": len(registry.get("realizations") or []),
        "completeness_basis": completeness.get("basis_type"),
        "declared_universe": completeness.get("declared_universe"),
        "registry_hash": content_hash(registry) if registry else None,
        "geometry": {k: v.get("root_hash") for k, v in (case.get("geometry") or {}).items()
                     if isinstance(v, dict)},
        "scope": (case.get("scope") or {}).get("scope_id"),
        "required_object": (case.get("derivation") or {}).get("required_object"),
        "certificates": sorted(case.get("certificates") or {}),
        "superseded_certificates": sorted(case.get("superseded_certificates") or {}),
        "deltas": sorted(case.get("deltas") or {}),
    }
    # Operational-module state, surfaced only when present so a plain case stays
    # uncluttered (spec 40 inspect; 33/34/32/16/15/17 artifacts).
    for key, source in (
        ("evidence", case.get("evidence")),
        ("technology_contracts", case.get("technology_contracts")),
        ("qualification_plans", case.get("qualification_plans")),
        ("safe_commitments", case.get("safe_commitments")),
        ("phase_analyses", case.get("phase_analyses")),
        ("certified_deltas", case.get("certified_deltas")),
        ("conversions", case.get("conversions")),
        ("witnesses", case.get("witnesses")),
        ("tombstones", case.get("tombstones")),
        ("redacted_certificates", case.get("redacted_certificates")),
    ):
        if source:
            payload[key] = sorted(source)
    if case.get("branch_record"):
        payload["branch_of"] = case["branch_record"].get("parent_case")
    if case.get("migration_record"):
        payload["migrated_from"] = case["migration_record"].get("source_case")
    intake = case.get("registry_intake") or {}
    if intake:
        payload["registry_intake"] = {
            "latest_profile_hash": intake.get("latest_profile_hash"),
            "latest_source_snapshot_hash": intake.get("latest_source_snapshot_hash"),
            "latest_preview_hash": intake.get("latest_preview_hash"),
            "latest_confirmation_hash": intake.get("latest_confirmation_hash"),
            "profiles": len(intake.get("mapping_profiles") or {}),
            "source_snapshots": len(intake.get("source_snapshots") or {}),
            "previews": len(intake.get("previews") or {}),
            "confirmations": len(intake.get("confirmations") or {}),
        }
    human = [
        f"case {payload['case_id']} [{payload['status']}]",
        f"  realizations      : {payload['realizations']}",
        f"  completeness basis: {payload['completeness_basis']} "
        f"({payload['declared_universe']})",
        f"  registry hash     : {payload['registry_hash']}",
        f"  geometry          : {payload['geometry'] or 'not built'}",
        f"  decision scope    : {payload['scope'] or 'not compiled'}",
        f"  required object   : {payload['required_object'] or 'not compiled'}",
        f"  certificates      : {payload['certificates'] or 'none'}",
        f"  superseded        : {payload['superseded_certificates'] or 'none'}",
        f"  delta certificates: {payload['deltas'] or 'none'}",
    ]
    for key in ("evidence", "technology_contracts", "qualification_plans", "safe_commitments",
                "phase_analyses", "certified_deltas", "conversions", "witnesses",
                "redacted_certificates"):
        if key in payload:
            human.append(f"  {key:<18}: {payload[key]}")
    if "registry_intake" in payload:
        human.append(
            "  registry intake   : confirmed preview "
            f"{payload['registry_intake']['latest_preview_hash']}"
        )
    out.result(payload, "\n".join(human))
    return OK


# ---------------------------------------------------------------------------
# crg geometry
# ---------------------------------------------------------------------------
def cmd_geometry(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    bundle = load_bundle(case)
    requested = [o.strip().upper() for o in args.objects.split(",") if o.strip()]

    geometry = dict(case.get("geometry") or {})
    r_record = crg_geometry.build_R(bundle)
    if "R" in requested:
        geometry["R"] = {
            "root_hash": r_record.root_hash(),
            "signatures": len(r_record.fibers),
            "fibers": [
                {"signature": f.signature.to_canonical(), "realization_ids": list(f.realization_ids)}
                for f in r_record.fibers
            ],
        }
        out.step("geometry", object="R", signatures=len(r_record.fibers))
    if "GAMMA" in requested:
        gamma = crg_geometry.build_gamma(r_record)
        geometry["GAMMA"] = {
            "root_hash": gamma.root_hash(),
            "frontier_size": len(gamma.frontier),
            "frontier": _points(gamma.frontier),
        }
        geometry["full_frontier"] = _points(gamma.frontier)
        out.step("geometry", object="GAMMA", frontier=len(gamma.frontier))
    if "K" in requested:
        k_record = crg_geometry.build_K(r_record)
        geometry["K"] = {
            "root_hash": k_record.root_hash(),
            "vertices": len(k_record.vertices),
            "vertex_points": _points(k_record.vertices),
        }
        out.step("geometry", object="K", vertices=len(k_record.vertices))

    case["geometry"] = geometry
    case["status"] = "GENERATED"
    record_history(case, "geometry", {"objects": requested})
    write_case(args.root, case)
    payload = {
        "case_id": case["case_id"],
        "objects": {k: v.get("root_hash") for k, v in geometry.items() if isinstance(v, dict)},
    }
    human = ["canonical geometry built"]
    for name in ("R", "GAMMA", "K"):
        if name in geometry:
            record = geometry[name]
            size = record.get("signatures") or record.get("frontier_size") or record.get("vertices")
            human.append(f"  {name:<6}: {size} generators, root {record['root_hash']}")
    out.result(payload, "\n".join(human))
    return OK


# ---------------------------------------------------------------------------
# crg phase -- registered exact phase analysis (1.x workstream C)
# ---------------------------------------------------------------------------
def _verified_phase_analysis(
    case: Mapping[str, Any],
    *,
    profile_id: str = crg_geometry.PhaseProfile.TWO_COORDINATE_PRICE_SIMPLEX_V1,
    stability_parameter: Optional[Any] = None,
    policy_tolerance: Any = 0,
):
    """Build phase evidence and cross the independent verifier boundary.

    The source ``R`` is reconstructed from the canonical registry.  Callers
    cannot supply policies, boundaries, roots, or any other derived fact.
    """
    source_r = crg_geometry.build_R(load_bundle(dict(case)))
    record = crg_geometry.build_phase_analysis(
        source_r,
        profile_id=profile_id,
        stability_parameter=stability_parameter,
        policy_tolerance=policy_tolerance,
    )
    artifact = record.to_canonical()
    source = source_r.to_canonical()
    verification = crg_verify.verify_phase_analysis_record(artifact, source)
    if not verification.ok:
        detail = "; ".join(verification.violations) or verification.status
        raise ValueError(
            "the independently reconstructed phase analysis disagreed with the producer: "
            + detail
        )
    return artifact, source, verification


def _phase_summary(artifact: Mapping[str, Any], *, preview: bool) -> str:
    stability = artifact.get("stability") or {}
    lines = [
        "phase-analysis preview" if preview else "phase analysis certified",
        f"  analysis id       : {artifact['analysis_id']}",
        f"  registered profile: {artifact['profile']['profile_id']}",
        f"  source R root     : {artifact['source_r_root']}",
        f"  regions           : {len(artifact['regions'])}",
        f"  true boundaries   : {len(artifact['boundaries'])}",
        f"  exact ties        : {len(artifact['ties'])}",
        f"  degeneracies      : {len(artifact['degeneracies'])}",
    ]
    if stability:
        lines.extend(
            [
                f"  stability state   : {stability['state']}",
                f"  boundary distance : {stability.get('boundary_distance')}",
            ]
        )
    lines.append(
        "  preview only; no case state changed"
        if preview
        else "  independently reconstructed before persistence"
    )
    lines.append(
        "  claim boundary    : registered profile, relative to the declared family; "
        "active coordinates and bottlenecks are not phase boundaries"
    )
    return "\n".join(lines)


def _build_phase(args: argparse.Namespace, out: Emitter, *, persist: bool) -> int:
    case = read_case(args.root, args.case)
    artifact, source, verification = _verified_phase_analysis(
        case,
        profile_id=args.profile,
        stability_parameter=args.stability,
        policy_tolerance=args.tolerance,
    )
    artifact_root = content_hash(artifact)
    # Optional portable outputs are written before the successor case.  A bad
    # destination can therefore never make the CLI report failure after case
    # state has already advanced.
    if args.output:
        _write_canonical_document(args.output, artifact)
    if args.source_output:
        _write_canonical_document(args.source_output, source)
    if persist:
        case.setdefault("phase_analyses", {})[artifact["analysis_id"]] = artifact
        case.setdefault("phase_sources", {})[artifact["source_r_root"]] = source
        record_history(
            case,
            "phase analyze",
            {
                "analysis_id": artifact["analysis_id"],
                "artifact_root": artifact_root,
                "source_r_root": artifact["source_r_root"],
                "independently_verified": True,
            },
        )
        write_case(args.root, case)
    out.result(
        {
            "preview": not persist,
            "artifact": artifact,
            "artifact_root": artifact_root,
            "source_r": source,
            "verification": verification.to_json(),
            "output": args.output,
            "source_output": args.source_output,
        },
        _phase_summary(artifact, preview=not persist),
    )
    return OK


def cmd_phase_preview(args: argparse.Namespace, out: Emitter) -> int:
    return _build_phase(args, out, persist=False)


def cmd_phase_analyze(args: argparse.Namespace, out: Emitter) -> int:
    return _build_phase(args, out, persist=True)


def cmd_phase_inspect(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    analyses = case.get("phase_analyses") or {}
    if not analyses:
        raise CaseError("this case has no certified phase analysis")
    analysis_id = args.analysis
    if not analysis_id:
        for entry in reversed(case.get("history") or []):
            candidate = entry.get("current_phase_id") or entry.get("analysis_id")
            if candidate in analyses:
                analysis_id = candidate
                break
    analysis_id = analysis_id or sorted(analyses)[-1]
    if analysis_id not in analyses:
        raise CaseError(f"no phase analysis {analysis_id!r} in this case")
    artifact = analyses[analysis_id]
    source = (case.get("phase_sources") or {}).get(artifact.get("source_r_root"))
    if not isinstance(source, Mapping):
        raise CaseError(
            f"phase analysis {analysis_id!r} has no portable source R; verification is blocked"
        )
    verification = crg_verify.verify_phase_analysis_record(artifact, source)
    out.result(
        {
            "artifact": artifact,
            "artifact_root": content_hash(artifact),
            "source_r": source,
            "verification": verification.to_json(),
        },
        _phase_summary(artifact, preview=False)
        + f"\n  verification      : {verification.status}",
    )
    return OK if verification.ok else VIOLATION


def cmd_phase_verify(args: argparse.Namespace, out: Emitter) -> int:
    artifact = _json_object(args.path, "phase-analysis artifact")
    source = _json_object(args.source_r, "phase-analysis source R")
    result = crg_verify.verify_phase_analysis_record(artifact, source)
    for name, passed, detail in result.checks:
        out.step("check", check=name, passed=passed, detail=detail)
    out.result(result.to_json(), crg_verify.render_report(result))
    return OK if result.ok else VIOLATION


# ---------------------------------------------------------------------------
# crg query compile
# ---------------------------------------------------------------------------
def cmd_query_compile(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    document = read_query_document(args.scope)
    scope, derivation = crg_certify.compile_query(document)
    case["scope"] = {**scope.to_canonical(), "validity": scope.validity}
    case["derivation"] = derivation.to_canonical()
    case["status"] = "EVALUATED"
    record_history(case, "query compile", {"scope_id": scope.scope_id})
    write_case(args.root, case)

    out.step("compile", decision_class=derivation.decision_class,
             required_object=derivation.required_object)
    payload = {
        "scope_id": scope.scope_id,
        "decision_class": derivation.decision_class,
        "required_object": derivation.required_object,
        "rule_cited": derivation.rule_cited,
        "refusals": list(derivation.refusals),
        "retention_policy": scope.retention_policy,
        "query_hash": derivation.query_hash,
    }
    human = [
        f"compiled decision scope {scope.scope_id!r}",
        f"  decision class    : {derivation.decision_class}",
        f"  required object   : {derivation.required_object}",
        f"  retention policy  : {scope.retention_policy}",
        f"  rule cited        : {derivation.rule_cited}",
    ]
    for refusal in derivation.refusals:
        human.append(f"  REFUSED           : {refusal}")
    out.result(payload, "\n".join(human))
    return OK


# ---------------------------------------------------------------------------
# crg commitment -- future-decision retention and regret (1.x workstream B)
# ---------------------------------------------------------------------------
def _json_object(path: str, description: str) -> Dict[str, Any]:
    with open(path, encoding="utf-8") as handle:
        document = json.load(handle)
    if not isinstance(document, dict):
        raise CaseError(f"{description} must be a JSON object")
    return document


def _future_decision_family(case: dict, path: Optional[str], family_id: Optional[str]):
    """Compile a portable future-decision family from user queries or case state.

    The authoring document deliberately carries query documents, not caller-
    asserted derivations.  Every member is compiled through the registered
    decision-query table, so the minimum sufficient object and cited rule are
    kernel-derived before the family can be compared.
    """
    if not path:
        scope = load_scope(case)
        derivation = load_derivation(case)
        identity = family_id or f"future-{scope.scope_id}"
        return crg_certify.FutureDecisionFamily(
            identity,
            (crg_certify.FutureDecision(scope.scope_id, scope, derivation),),
            scenario_scope={"case_id": case["case_id"], "source": "compiled-case-scope"},
            authority="CRG registered decision-query mapping",
            validity=scope.validity,
        )

    document = _json_object(path, "future-decision family")
    raw_decisions = document.get("decisions")
    if not isinstance(raw_decisions, list) or not raw_decisions:
        raise CaseError("future-decision family decisions must be a non-empty JSON array")
    decisions = []
    for index, raw in enumerate(raw_decisions):
        if not isinstance(raw, dict):
            raise CaseError(f"future-decision family member {index} must be an object")
        query = raw.get("query")
        if not isinstance(query, dict):
            raise CaseError(
                f"future-decision family member {index} must carry a query object; "
                "a caller-supplied derivation is not accepted"
            )
        decision_id = str(raw.get("decision_id") or query.get("id") or "").strip()
        if not decision_id:
            raise CaseError(f"future-decision family member {index} has no decision_id")
        compiled_query = dict(query)
        compiled_query.setdefault("id", decision_id)
        scope, derivation = crg_certify.compile_query(compiled_query)
        if derivation.refusals:
            raise CaseError(
                f"future decision {decision_id!r} was refused by the soundness compiler: "
                + "; ".join(derivation.refusals)
            )
        decisions.append(crg_certify.FutureDecision(decision_id, scope, derivation))
    identity = str(family_id or document.get("family_id") or "").strip()
    if not identity:
        raise CaseError("future-decision family requires family_id")
    return crg_certify.FutureDecisionFamily(
        identity,
        tuple(decisions),
        scenario_scope=dict(document.get("scenario_scope") or {}),
        authority=document.get("authority"),
        validity=document.get("validity"),
    )


def _retention_declarations(path: str, family_id: str):
    document = _json_object(path, "retention-policy comparison")
    raw_policies = document.get("policies")
    if not isinstance(raw_policies, list) or not raw_policies:
        raise CaseError("retention-policy comparison policies must be a non-empty JSON array")
    declarations = []
    for index, raw in enumerate(raw_policies):
        if not isinstance(raw, dict):
            raise CaseError(f"retention policy {index} must be an object")
        policy_id = str(raw.get("policy_id") or "").strip()
        policy = str(raw.get("policy") or "").strip()
        declared_family = str(raw.get("family_id") or family_id)
        if declared_family != family_id:
            raise CaseError(
                f"retention policy {policy_id or index!r} names family "
                f"{declared_family!r}, not {family_id!r}"
            )
        declarations.append(
            crg_certify.RetentionPolicyDeclaration(
                policy_id=policy_id,
                family_id=family_id,
                policy=policy,
                parameters=dict(raw.get("parameters") or {}),
                protected_ids=tuple(raw.get("protected_ids") or ()),
                protected_classes=dict(raw.get("protected_classes") or {}),
            )
        )
    return tuple(declarations)


def _commitment_summary(artifact: Mapping[str, Any], *, preview: bool) -> str:
    lines = [
        "safe-commitment preview" if preview else "safe-commitment comparison certified",
        f"  artifact id       : {artifact['artifact_id']}",
        f"  family            : {artifact['family']['family_id']}",
        f"  family decisions  : {len(artifact['family']['decisions'])}",
        f"  artifact hash     : {artifact['artifact_hash']}",
    ]
    for evaluation in artifact["evaluations"]:
        lines.append(
            f"  policy {evaluation['policy_id']}: {evaluation['status']}; "
            f"retained={len(evaluation['retained_ids'])}, "
            f"pruned={len(evaluation['pruned_ids'])}"
        )
        for refusal in evaluation.get("refusals") or ():
            lines.append(f"    REFUSED: {refusal}")
    lines.append(
        "  preview only; no case state changed" if preview
        else "  independently reconstructed before persistence"
    )
    return "\n".join(lines)


def _write_canonical_document(path: str, document: Mapping[str, Any]) -> None:
    destination = os.path.abspath(path)
    directory = os.path.dirname(destination) or "."
    os.makedirs(directory, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix=".crg-artifact-", dir=directory)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(canonical_json(document) + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, destination)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def _write_text_document(path: str, text: str) -> None:
    destination = os.path.abspath(path)
    directory = os.path.dirname(destination) or "."
    os.makedirs(directory, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix=".crg-report-", dir=directory)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, destination)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def _build_commitment(args: argparse.Namespace, out: Emitter, *, persist: bool) -> int:
    crg_certify.set_default_geometry(crg_geometry)
    case = read_case(args.root, args.case)
    bundle = load_bundle(case)
    family = _future_decision_family(case, args.family, args.family_id)
    policies = _retention_declarations(args.policies, family.family_id)
    artifact = crg_certify.compare_retention_policies(
        bundle,
        family,
        policies,
        geometry=crg_geometry,
        artifact_id=args.artifact_id,
    ).to_canonical()
    verification = crg_verify.verify_safe_commitment(artifact)
    if not verification.ok:
        detail = "; ".join(verification.violations) or verification.status
        raise crg_certify.CertifyError(
            f"the independently reconstructed safe-commitment artifact failed: {detail}"
        )
    if persist:
        case.setdefault("safe_commitments", {})[artifact["artifact_id"]] = artifact
        record_history(
            case,
            "commitment compare",
            {
                "artifact_id": artifact["artifact_id"],
                "artifact_hash": artifact["artifact_hash"],
                "family_id": family.family_id,
                "policy_ids": [item.policy_id for item in policies],
                "independently_verified": True,
            },
        )
        write_case(args.root, case)
    if args.output:
        _write_canonical_document(args.output, artifact)
    payload = {
        "preview": not persist,
        "artifact": artifact,
        "verification": verification.to_json(),
        "output": args.output,
    }
    out.result(payload, _commitment_summary(artifact, preview=not persist))
    return OK


def cmd_commitment_preview(args: argparse.Namespace, out: Emitter) -> int:
    return _build_commitment(args, out, persist=False)


def cmd_commitment_compare(args: argparse.Namespace, out: Emitter) -> int:
    return _build_commitment(args, out, persist=True)


def cmd_commitment_inspect(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    artifacts = case.get("safe_commitments") or {}
    if not artifacts:
        raise CaseError("this case has no safe-commitment artifact")
    artifact_id = args.artifact or sorted(artifacts)[-1]
    if artifact_id not in artifacts:
        raise CaseError(f"no safe-commitment artifact {artifact_id!r} in this case")
    artifact = artifacts[artifact_id]
    verification = crg_verify.verify_safe_commitment(artifact)
    out.result(
        {"artifact": artifact, "verification": verification.to_json()},
        _commitment_summary(artifact, preview=False)
        + f"\n  verification      : {verification.status}",
    )
    return OK if verification.ok else VIOLATION


def cmd_commitment_verify(args: argparse.Namespace, out: Emitter) -> int:
    artifact = _json_object(args.path, "safe-commitment artifact")
    result = crg_verify.verify_safe_commitment(artifact)
    for name, passed, detail in result.checks:
        out.step("check", check=name, passed=passed, detail=detail)
    out.result(result.to_json(), crg_verify.render_report(result))
    return OK if result.ok else VIOLATION


# ---------------------------------------------------------------------------
# CRG-ENH-03 non-authorizing comparative workflow evidence
# ---------------------------------------------------------------------------
def _build_comparison(args: argparse.Namespace, out: Emitter, *, persist: bool) -> int:
    case = read_case(args.root, args.case)
    request = _json_object(args.request, "comparative workflow request")
    record, verification = build_verified_comparative_evaluation(request)
    verification_inputs = comparative_verification_inputs(record)
    if persist:
        verification_inputs = persist_comparative_evaluation(case, record)
        write_case(args.root, case)
    report = render_comparative_evaluation_report(record, verification)
    if args.output:
        _write_canonical_document(args.output, record)
    if args.report:
        _write_text_document(args.report, report)
    payload = {
        "preview": not persist,
        "evaluation": record,
        "verification_inputs": verification_inputs,
        "verification": verification.to_json(),
        "report": report,
        "output": args.output,
        "report_output": args.report,
    }
    out.result(payload, report.rstrip() + (
        "\nPreview only: no case state changed."
        if not persist else
        "\nPublished only after independent reconstruction."
    ))
    return OK


def cmd_comparison_preview(args: argparse.Namespace, out: Emitter) -> int:
    return _build_comparison(args, out, persist=False)


def cmd_comparison_generate(args: argparse.Namespace, out: Emitter) -> int:
    return _build_comparison(args, out, persist=True)


def cmd_comparison_inspect(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    records = case.get("comparative_evaluations") or {}
    if not records:
        raise CaseError("this case has no comparative workflow evaluation")
    evaluation_id = args.evaluation or sorted(records)[-1]
    if evaluation_id not in records:
        raise CaseError(
            f"no comparative workflow evaluation {evaluation_id!r} in this case"
        )
    record = records[evaluation_id]
    verification = crg_verify.verify_comparative_workflow_evaluation(record)
    report = render_comparative_evaluation_report(record, verification)
    if args.output:
        _write_canonical_document(args.output, record)
    if args.report:
        _write_text_document(args.report, report)
    out.result(
        {
            "evaluation": record,
            "verification_inputs": (
                (case.get("comparative_evaluation_verification_inputs") or {}).get(
                    evaluation_id
                )
            ),
            "verification": verification.to_json(),
            "report": report,
        },
        report.rstrip(),
    )
    return OK if verification.ok else VIOLATION


def cmd_comparison_verify(args: argparse.Namespace, out: Emitter) -> int:
    record = _json_object(args.path, "comparative workflow evaluation")
    result = crg_verify.verify_comparative_workflow_evaluation(record)
    for name, passed, detail in result.checks:
        out.step("check", check=name, passed=passed, detail=detail)
    report = render_comparative_evaluation_report(record, result)
    out.result(
        {"verification": result.to_json(), "report": report},
        report.rstrip() + "\n\n" + crg_verify.render_report(result),
    )
    return OK if result.ok else VIOLATION


def _qualification_measurement_sources(
    args: argparse.Namespace, request: Mapping[str, Any]
) -> Optional[dict]:
    extension = request.get("qualification_extension")
    if not isinstance(extension, Mapping):
        return None
    refs = list(extension.get("local_observation_refs") or ()) + list(
        extension.get("declared_counterfactual_refs") or ()
    )
    if not refs:
        return {"local_observations": [], "declared_counterfactuals": []}
    if (
        getattr(args, "enable_comparison_measurement", False) is not True
        or not getattr(args, "comparison_measurement_store", None)
        or not getattr(args, "comparison_measurement_subject", None)
    ):
        raise CaseError(
            "qualification comparison measurement references require explicit local-store "
            "read opt-in: --enable-local-measurement, --measurement-store, and "
            "--measurement-subject-label"
        )
    try:
        from crg_server.operational_measurement import (
            LocalOperationalMeasurementStore,
            MeasurementError,
            MeasurementGrant,
            OperationalMeasurementPermission,
            OperationalMeasurementProfile,
            OperationalMeasurementRecorder,
        )

        recorder = OperationalMeasurementRecorder(
            profile=OperationalMeasurementProfile(enabled=True),
            store=LocalOperationalMeasurementStore(
                args.comparison_measurement_store
            ),
            permission=OperationalMeasurementPermission(
                subject_label=args.comparison_measurement_subject,
                grants=(MeasurementGrant.READ,),
            ),
        )
        return resolve_qualification_operational_sources(
            request, recorder.get_session
        )
    except MeasurementError as error:
        raise CaseError(f"local operational measurement reference failed: {error}") from error


def _build_comparative_change(
    args: argparse.Namespace, out: Emitter, *, persist: bool
) -> int:
    case = read_case(args.root, args.case)
    request = _json_object(args.request, "closed comparative change request")
    measurement_sources = _qualification_measurement_sources(args, request)
    record, verification = build_verified_comparative_change(
        request,
        case,
        operational_measurement_sources=measurement_sources,
    )
    if persist:
        persist_comparative_change(case, record)
        write_case(args.root, case)
    report = render_comparative_change_report(record, verification)
    if args.output:
        _write_canonical_document(args.output, record)
    if args.report:
        _write_text_document(args.report, report)
    out.result(
        {
            "preview": not persist,
            "comparative_change": record,
            "verification": verification.to_json(),
            "report": report,
            "authority": "NON_AUTHORIZING",
            "authorizing": False,
            "semantic_effect": "NONE",
            "decision_state_mutation_performed": False,
            "successor_case_recorded": persist,
            "output": args.output,
            "report_output": args.report,
        },
        report.rstrip()
        + (
            "\nPreview only: no case state changed."
            if not persist
            else "\nPublished into a successor case only after independent replay."
        ),
    )
    return OK


def cmd_comparison_change_preview(args: argparse.Namespace, out: Emitter) -> int:
    return _build_comparative_change(args, out, persist=False)


def cmd_comparison_change_generate(args: argparse.Namespace, out: Emitter) -> int:
    return _build_comparative_change(args, out, persist=True)


def cmd_comparison_change_inspect(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    records = case.get("comparative_change_evidence") or {}
    if not isinstance(records, Mapping) or not records:
        raise CaseError("this case has no ComparativeChangeEvidence")
    comparison_id = args.comparison or sorted(records)[-1]
    payload = inspect_comparative_change(case, comparison_id)
    record = payload["comparative_change"]
    if args.output:
        _write_canonical_document(args.output, record)
    if args.report:
        _write_text_document(args.report, payload["report"])
    out.result(payload, payload["report"].rstrip())
    return OK


def cmd_comparison_change_verify(args: argparse.Namespace, out: Emitter) -> int:
    record = _json_object(args.path, "ComparativeChangeEvidence")
    verification = crg_verify.verify_comparative_change_evidence(record)
    report = render_comparative_change_report(record, verification)
    for name, passed, detail in verification.checks:
        out.step("check", check=name, passed=passed, detail=detail)
    out.result(
        {"verification": verification.to_json(), "report": report},
        report.rstrip() + "\n\n" + crg_verify.render_report(verification),
    )
    return OK if verification.ok else VIOLATION


def _build_cumulative_comparison(
    args: argparse.Namespace, out: Emitter, *, persist: bool
) -> int:
    case = read_case(args.root, args.case)
    request = _json_object(args.request, "closed cumulative lifecycle comparison request")
    record, verification = build_verified_cumulative_comparison(request, case)
    if persist:
        persist_cumulative_comparison(case, record)
        write_case(args.root, case)
    report = render_cumulative_comparison_report(record, verification)
    if args.output:
        _write_canonical_document(args.output, record)
    if args.report:
        _write_text_document(args.report, report)
    out.result(
        {
            "preview": not persist,
            "cumulative_comparison": record,
            "verification": verification.to_json(),
            "report": report,
            "authority": "NON_AUTHORIZING",
            "authorizing": False,
            "semantic_effect": "NONE",
            "decision_state_mutation_performed": False,
            "successor_case_recorded": persist,
            "output": args.output,
            "report_output": args.report,
        },
        report.rstrip()
        + (
            "\nPreview only: no case state changed."
            if not persist
            else "\nPublished into a successor case only after ten independent replays."
        ),
    )
    return OK


def cmd_comparison_journey_preview(args: argparse.Namespace, out: Emitter) -> int:
    return _build_cumulative_comparison(args, out, persist=False)


def cmd_comparison_journey_generate(args: argparse.Namespace, out: Emitter) -> int:
    return _build_cumulative_comparison(args, out, persist=True)


def cmd_comparison_journey_inspect(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    records = case.get("cumulative_lifecycle_comparisons") or {}
    if not isinstance(records, Mapping) or not records:
        raise CaseError("this case has no CumulativeLifecycleComparison")
    journey_id = args.journey or sorted(records)[-1]
    payload = inspect_cumulative_comparison(case, journey_id)
    record = payload["cumulative_comparison"]
    if args.output:
        _write_canonical_document(args.output, record)
    if args.report:
        _write_text_document(args.report, payload["report"])
    out.result(payload, payload["report"].rstrip())
    return OK


def cmd_comparison_journey_verify(args: argparse.Namespace, out: Emitter) -> int:
    record = _json_object(args.path, "CumulativeLifecycleComparison")
    verification = crg_verify.verify_cumulative_lifecycle_comparison(record)
    report = render_cumulative_comparison_report(record, verification)
    for name, passed, detail in verification.checks:
        out.step("check", check=name, passed=passed, detail=detail)
    out.result(
        {"verification": verification.to_json(), "report": report},
        report.rstrip() + "\n\n" + crg_verify.render_report(verification),
    )
    return OK if verification.ok else VIOLATION


# ---------------------------------------------------------------------------
# CRG-ENH-05 non-authorizing Decision Challenge
# ---------------------------------------------------------------------------
def _build_challenge(args: argparse.Namespace, out: Emitter, *, persist: bool) -> int:
    case = read_case(args.root, args.case)
    request = _json_object(args.request, "closed Decision Challenge request")
    record, verification = build_verified_decision_challenge(request, case)
    if persist:
        persist_decision_challenge(args.root, args.case, record)
    report = render_decision_challenge_report(record, verification)
    if args.output:
        _write_canonical_document(args.output, record)
    if args.report:
        _write_text_document(args.report, report)
    out.result(
        {
            "preview": not persist,
            "challenge": record,
            "verification": verification.to_json(),
            "report": report,
            "authority": "NON_AUTHORIZING",
            "authorizing": False,
            "semantic_effect": "NONE",
            "mutation_performed": False,
            "output": args.output,
            "report_output": args.report,
        },
        report.rstrip()
        + (
            "\nPreview only: no case state changed."
            if not persist
            else "\nRecorded after independent replay; the active case was not mutated."
        ),
    )
    return OK


def cmd_challenge_preview(args: argparse.Namespace, out: Emitter) -> int:
    return _build_challenge(args, out, persist=False)


def cmd_challenge_record(args: argparse.Namespace, out: Emitter) -> int:
    return _build_challenge(args, out, persist=True)


def cmd_challenge_inspect(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    records = list_decision_challenges(args.root, args.case)
    if not records:
        raise CaseError("this case has no Decision Challenge record")
    challenge_id = args.challenge or sorted(records)[-1]
    if challenge_id not in records:
        raise CaseError(f"no Decision Challenge {challenge_id!r} in this case")
    record = read_decision_challenge(args.root, args.case, challenge_id)
    verification = crg_verify.verify_decision_challenge_record(record)
    report = render_decision_challenge_report(record, verification)
    if args.output:
        _write_canonical_document(args.output, record)
    if args.report:
        _write_text_document(args.report, report)
    out.result(
        {
            "challenge": record,
            "verification": verification.to_json(),
            "report": report,
            "authority": "NON_AUTHORIZING",
            "authorizing": False,
            "semantic_effect": "NONE",
        },
        report.rstrip(),
    )
    return OK if verification.ok else VIOLATION


def cmd_challenge_verify(args: argparse.Namespace, out: Emitter) -> int:
    record = _json_object(args.path, "portable DecisionChallengeRecord")
    result = crg_verify.verify_decision_challenge_record(record)
    for name, passed, detail in result.checks:
        out.step("check", check=name, passed=passed, detail=detail)
    report = render_decision_challenge_report(record, result)
    out.result(
        {"verification": result.to_json(), "report": report},
        report.rstrip() + "\n\n" + crg_verify.render_report(result),
    )
    return OK if result.ok else VIOLATION


# ---------------------------------------------------------------------------
# v1.3 ETQ lifecycle and v1.4 decision/resilience lifecycle
# ---------------------------------------------------------------------------
def cmd_lifecycle_publish(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    request = _json_object(args.request, "closed lifecycle request")
    record, inputs, verification, companions = build_verified_lifecycle_record(
        request, case
    )
    record_type, record_id = persist_lifecycle_record(
        case, record, inputs, companions
    )
    write_case(args.root, case)
    report = render_lifecycle_report(record, verification)
    portable = {"record": record, "verification_inputs": inputs}
    if args.output:
        _write_canonical_document(args.output, portable)
    if args.report:
        _write_text_document(args.report, report)
    out.result(
        {
            "record_type": record_type,
            "record_id": record_id,
            **portable,
            "verification": verification.to_json(),
            "report": report,
            "output": args.output,
        },
        report.rstrip() + "\nPublished only after independent lifecycle replay.",
    )
    return OK


def cmd_lifecycle_inspect(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    payload = inspect_lifecycle_record(case, args.record_type, args.record_id)
    portable = {
        "record": payload["record"],
        "verification_inputs": payload["verification_inputs"],
    }
    if args.output:
        _write_canonical_document(args.output, portable)
    if args.report:
        _write_text_document(args.report, payload["report"])
    out.result({**payload, "output": args.output}, payload["report"].rstrip())
    return OK


def cmd_lifecycle_verify(args: argparse.Namespace, out: Emitter) -> int:
    portable = _closed_lifecycle_file(args.path)
    result = verify_lifecycle_record(
        portable["record"], portable["verification_inputs"]
    )
    report = render_lifecycle_report(portable["record"], result)
    for name, passed, detail in result.checks:
        out.step("check", check=name, passed=passed, detail=detail)
    out.result(
        {"verification": result.to_json(), "report": report},
        report.rstrip() + "\n\n" + crg_verify.render_report(result),
    )
    return OK if result.ok else VIOLATION


# ---------------------------------------------------------------------------
# Workstream G: local pack authoring and source-adapter assurance
# ---------------------------------------------------------------------------
def cmd_pack_validate(args: argparse.Namespace, out: Emitter) -> int:
    payload = validate_pack_manifest(args.manifest)
    if args.output:
        _write_canonical_document(args.output, payload["record"])
    out.result(payload, render_pack_authoring_report(payload))
    return OK if payload["accepted"] else VIOLATION


def cmd_pack_assure_first_party(args: argparse.Namespace, out: Emitter) -> int:
    payload = assure_first_party_packs()
    if args.output:
        _write_canonical_document(args.output, payload["record"])
    out.result(payload, render_first_party_pack_assurance(payload))
    return OK if payload["assured"] else VIOLATION


def _emit_adapter_verification(
    args: argparse.Namespace, out: Emitter, payload: Mapping[str, Any]
) -> int:
    if args.output:
        _write_canonical_document(args.output, payload)
    out.result(payload, render_source_adapter_verification(payload))
    return OK if bool((payload.get("verification") or {}).get("ok")) else VIOLATION


def cmd_adapter_verify_definition(args: argparse.Namespace, out: Emitter) -> int:
    return _emit_adapter_verification(
        args, out, verify_source_adapter_definition_file(args.path)
    )


def cmd_adapter_verify_output(args: argparse.Namespace, out: Emitter) -> int:
    return _emit_adapter_verification(
        args,
        out,
        verify_source_adapter_output_files(
            args.path,
            args.definition,
            args.original_source,
            args.normalized_source,
        ),
    )


def cmd_adapter_verify_report(args: argparse.Namespace, out: Emitter) -> int:
    return _emit_adapter_verification(
        args, out, verify_source_adapter_report_file(args.path)
    )


def _closed_lifecycle_file(path: str) -> Dict[str, Any]:
    document = _json_object(path, "portable lifecycle record")
    if set(document) != {"record", "verification_inputs"}:
        raise CaseError(
            "a portable lifecycle file requires exactly record and verification_inputs"
        )
    if not isinstance(document["record"], Mapping) or not isinstance(
        document["verification_inputs"], Mapping
    ):
        raise CaseError("portable lifecycle record and verification_inputs must be objects")
    return document


# ---------------------------------------------------------------------------
# crg certify / regret
# ---------------------------------------------------------------------------
def _store_certificate(case: dict, certificate) -> dict:
    """Store a certificate with a hash that covers everything it ships with.

    The issuance time (45.2) is an assertion of the issuer and is part of the
    record, so it must be inside the hash preimage: a hash taken before the
    timestamp was attached would leave the timestamp unbound and freely
    editable.  The engine's own hash over the kernel's canonical form is kept
    alongside it so the two views stay traceable.
    """
    canonical = certificate.to_canonical()
    canonical["engine_certificate_hash"] = certificate.certificate_hash()
    canonical["issued_at"] = utc_now()
    canonical["issuer_clock_source"] = "issuer-system-clock"
    if not canonical.get("expiry") and (case.get("scope") or {}).get("validity"):
        canonical["expiry"] = case["scope"]["validity"]
    canonical["certificate_hash"] = content_hash(canonical)
    case.setdefault("certificates", {})[certificate.certificate_id] = canonical
    return canonical


def cmd_certify(args: argparse.Namespace, out: Emitter) -> int:
    crg_certify.set_default_geometry(crg_geometry)
    case = read_case(args.root, args.case)
    bundle = load_bundle(case)
    scope = load_scope(case)
    derivation = load_derivation(case)
    retained = [r.strip() for r in args.retained.split(",") if r.strip()] if args.retained else None

    certificate = crg_certify.certify(bundle, scope, derivation, retained=retained)
    canonical = _store_certificate(case, certificate)

    if retained is not None:
        r_full = crg_geometry.build_R(bundle)
        full_frontier = crg_geometry.build_gamma(r_full).frontier
        kept = [r for r in bundle.realizations if r.realization_id in set(retained)]
        if kept:
            retained_signatures = crg_geometry.pareto_minimal([r.signature for r in kept])
            geometry = dict(case.get("geometry") or {})
            geometry["full_frontier"] = _points(full_frontier)
            geometry["retained_frontier"] = _points(retained_signatures)
            case["geometry"] = geometry

    case["status"] = "CERTIFIED" if certificate.outcome in _AFFIRMATIVE else "BLOCKED"
    record_history(case, "certify", {"certificate_id": certificate.certificate_id,
                                     "outcome": certificate.outcome})
    write_case(args.root, case)

    out.step("certify", outcome=certificate.outcome, claim_scope=certificate.claim_scope)
    payload = {
        "certificate_id": certificate.certificate_id,
        "outcome": certificate.outcome,
        "claim_scope": certificate.claim_scope,
        "selected": list(certificate.selected),
        "ties": list(certificate.ties),
        "runner_up": certificate.runner_up,
        "certificate_hash": canonical["certificate_hash"],
        "affirmative": certificate.outcome in _AFFIRMATIVE,
    }
    out.result(payload, crg_certify.render_claim(certificate))
    return OK if certificate.outcome in _AFFIRMATIVE else VIOLATION


def cmd_regret(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    bundle = load_bundle(case)
    retained = {r.strip() for r in args.retained.split(",") if r.strip()}
    r_record = crg_geometry.build_R(bundle)
    full_frontier = crg_geometry.build_gamma(r_record).frontier
    kept = [r.signature for r in bundle.realizations if r.realization_id in retained]
    if not kept:
        raise CaseError("the retained set is empty; regret is unbounded, not a witness")
    retained_frontier = crg_geometry.pareto_minimal(kept)

    witness = crg_certify.build_regret_witness(full_frontier, retained_frontier, bundle.schema)
    geometry = dict(case.get("geometry") or {})
    geometry["full_frontier"] = _points(full_frontier)
    geometry["retained_frontier"] = _points(retained_frontier)
    case["geometry"] = geometry
    case["regret_witness"] = witness.to_canonical() if witness else None
    write_case(args.root, case)

    if witness is None:
        out.result(
            {"witness": None, "retention_lossless_for_this_generator": True},
            "no regret witness was constructed for this objective family.\n"
            "  27.5: a failed witness search does not prove the reduction was safe.",
        )
        return OK
    payload = {"witness": witness.to_canonical(), "gap": str(witness.gap)}
    out.result(
        payload,
        f"regret witness constructed\n"
        f"  lost point       : {[str(v) for v in witness.lost_point.values]}\n"
        f"  objective family : {witness.objective_family}\n"
        f"  full infimum     : {witness.full_infimum}\n"
        f"  retained infimum : {witness.retained_infimum}\n"
        f"  regret gap       : {witness.gap} > 0",
    )
    return VIOLATION  # a positive regret gap means the retention was unsafe


# ---------------------------------------------------------------------------
# crg change
# ---------------------------------------------------------------------------
def _case_objects(case: dict) -> Dict[str, Any]:
    """Project a case into the typed objects a change propagates through (18).

    The price vector is a *separate object* from the decision scope, not a
    field inside it.  That separation is what lets 30.2 distinguish a
    REPRICE from a REOPEN: if the weights lived inside the scope object, any
    tariff update would also read as a scope change and every reprice would
    escalate to a reopen, which is conservative but useless.
    """
    scope = dict(case.get("scope") or {})
    family = dict(scope.pop("objective_family", None) or {})
    weights = family.pop("weights", None)
    family.pop("weights_are_ranges", None)
    scope["objective_family"] = family
    objects = {
        "candidate-registry": {
            "object_kind": "CANDIDATE_REGISTRY",
            "registry": case.get("registry"),
        },
        "price-model": {"object_kind": "PRICE_MODEL", "price": {"weights": weights}},
        "decision-scope": {"object_kind": "DECISION_SCOPE", "scope": scope},
    }
    for name in ("R", "GAMMA", "K"):
        record = (case.get("geometry") or {}).get(name)
        if isinstance(record, Mapping):
            objects[f"geometry-{name}"] = {
                "object_kind": "GEOMETRY",
                "geometry_type": name,
                "geometry": record,
            }
    return objects


def _refresh_complete_geometry(case: Dict[str, Any]) -> None:
    """Recompute the complete canonical geometry carried by a change view."""
    bundle = load_bundle(case)
    r_record = crg_geometry.build_R(bundle)
    gamma = crg_geometry.build_gamma(r_record)
    k_record = crg_geometry.build_K(r_record)
    case["geometry"] = {
        "R": {
            "root_hash": r_record.root_hash(),
            "signatures": len(r_record.fibers),
            "fibers": [
                {
                    "signature": fiber.signature.to_canonical(),
                    "realization_ids": list(fiber.realization_ids),
                }
                for fiber in r_record.fibers
            ],
        },
        "GAMMA": {
            "root_hash": gamma.root_hash(),
            "frontier_size": len(gamma.frontier),
            "frontier": _points(gamma.frontier),
        },
        "K": {
            "root_hash": k_record.root_hash(),
            "vertices": len(k_record.vertices),
            "vertex_points": _points(k_record.vertices),
        },
        "full_frontier": _points(gamma.frontier),
    }


def _case_view(case: dict) -> Dict[str, Any]:
    return {
        "objects": _case_objects(case),
        "certificates": dict(case.get("certificates") or {}),
    }


def _graph(
    certificate_ids: Sequence[str], geometry_ids: Sequence[str] = ()
) -> DependencyGraph:
    graph = DependencyGraph()
    for geometry_id in sorted(set(geometry_ids)):
        graph.add_edge(
            DependencyEdge(
                edge_id=f"candidate-registry->{geometry_id}#canonical-geometry",
                source="candidate-registry",
                target=geometry_id,
                edge_type=EdgeType.DEPENDS_ON_MEMBERSHIP_OF,
            )
        )
    for index, cert_id in enumerate(sorted(certificate_ids)):
        for source, edge_type in (
            ("price-model", EdgeType.DEPENDS_ON_PRICE_OF),
            ("candidate-registry", EdgeType.DEPENDS_ON_MEMBERSHIP_OF),
            ("decision-scope", EdgeType.DEPENDS_ON_SCOPE_OF),
        ):
            graph.add_edge(
                DependencyEdge(
                    edge_id=f"{source}->{cert_id}#{index}",
                    source=source,
                    target=cert_id,
                    edge_type=edge_type,
                )
            )
        for geometry_id in sorted(set(geometry_ids)):
            graph.add_edge(
                DependencyEdge(
                    edge_id=f"{geometry_id}->{cert_id}#{index}",
                    source=geometry_id,
                    target=cert_id,
                    edge_type=EdgeType.DERIVES_VALUE_FROM,
                )
            )
    return graph


def _graph_documents(graph: DependencyGraph) -> List[dict]:
    return [
        edge.to_canonical()
        for node in sorted(graph.nodes)
        for edge in sorted(graph.edges_from(node), key=lambda item: item.edge_id)
    ]


def _change_phase(case: Mapping[str, Any]):
    """Return challenge-ready phase evidence when this family supports it.

    Unsupported dimensions are an explicit absence of a phase claim, not a
    guessed boundary.  The registered two-coordinate simplex profile carries
    an exact ``1/2`` stability probe so a later Decision Challenge can report
    its direct phase state and nearest boundaries.  A boundary remains a
    winner set; the probe never ranks or breaks a tie.  Any other
    producer/verifier failure remains fatal.
    """
    try:
        artifact, source, _verification = _verified_phase_analysis(
            case, stability_parameter="1/2"
        )
    except crg_geometry.UnsupportedPhaseProfileError:
        return None, None
    return artifact, source


def _delta_verification_inputs(
    prior_case: Mapping[str, Any],
    current_case: Mapping[str, Any],
    graph: DependencyGraph,
    replacements: Mapping[str, Any],
    prior_phase: Optional[Mapping[str, Any]],
    current_phase: Optional[Mapping[str, Any]],
    prior_phase_source_r: Optional[Mapping[str, Any]],
    current_phase_source_r: Optional[Mapping[str, Any]],
) -> dict:
    return {
        "prior_case": prior_case,
        "current_case": current_case,
        "dependency_edges": _graph_documents(graph),
        "replacements": dict(sorted(replacements.items())),
        "prior_phase": prior_phase,
        "current_phase": current_phase,
        "prior_phase_source_r": prior_phase_source_r,
        "current_phase_source_r": current_phase_source_r,
    }


def _verify_delta_document(record: Mapping[str, Any], inputs: Mapping[str, Any]):
    required = ("prior_case", "current_case", "dependency_edges", "replacements")
    missing = [field for field in required if field not in inputs]
    if missing:
        raise CaseError(f"certified-delta verification inputs are missing {missing}")
    allowed = set(required) | {
        "prior_phase", "current_phase", "prior_phase_source_r", "current_phase_source_r"
    }
    unknown = sorted(set(inputs) - allowed)
    if unknown:
        raise CaseError(f"certified-delta verification inputs have unsupported fields {unknown}")
    return crg_verify.verify_certified_delta_record(
        record,
        inputs["prior_case"],
        inputs["current_case"],
        inputs["dependency_edges"],
        replacements=inputs.get("replacements") or {},
        prior_phase=inputs.get("prior_phase"),
        current_phase=inputs.get("current_phase"),
        prior_phase_source_r=inputs.get("prior_phase_source_r"),
        current_phase_source_r=inputs.get("current_phase_source_r"),
    )


def cmd_change(args: argparse.Namespace, out: Emitter) -> int:
    crg_certify.set_default_geometry(crg_geometry)
    case = read_case(args.root, args.case)
    if not case.get("certificates"):
        raise CaseError("nothing to change: this case has no certificate yet")
    prior = json.loads(canonical_json(case))

    changed_object = "candidate-registry"
    changed_properties: List[str] = []
    if args.set and args.weight:
        raise CaseError(
            "one change event may name only one changed object; submit registry and price "
            "changes as separate certified events"
        )
    if args.set:
        for assignment in args.set:
            target, _, value = assignment.partition("=")
            rid, _, coordinate = target.partition(".")
            registry = case["registry"]
            identifiers = [c["identifier"] for c in registry["schema"]["coordinates"]]
            if coordinate not in identifiers:
                raise CaseError(f"unknown coordinate {coordinate!r}")
            index = identifiers.index(coordinate)
            for realization in registry["realizations"]:
                if realization["realization_id"] == rid:
                    realization["signature"][index] = Exact(value).to_canonical()
                    break
            else:
                raise CaseError(f"unknown realization {rid!r}")
            changed_properties.append(f"registry.candidates.{rid}.{coordinate}")
    if args.weight:
        changed_object = "price-model"
        family = dict((case.get("scope") or {}).get("objective_family") or {})
        weights = dict(family.get("weights") or {})
        for assignment in args.weight:
            coordinate, _, value = assignment.partition("=")
            weights[coordinate] = [str(Exact(value)), str(Exact(value))]
            changed_properties.append(f"price.weights.{coordinate}")
        family["weights"] = weights
        family["weights_are_ranges"] = any(w[0] != w[1] for w in weights.values())
        case["scope"] = {**(case.get("scope") or {}), "objective_family": family}
    if not changed_properties:
        raise CaseError("declare what changed with --set or --weight")
    _normalize_registry(case)
    # The certified before/after view carries the authoritative derived
    # geometry on both sides, even if an older caller had not persisted a
    # geometry build.  A registry change therefore cannot leave stale R,
    # Gamma, or K in the successor case or disappear from the geometry diff.
    _refresh_complete_geometry(prior)
    _refresh_complete_geometry(case)
    prior_view = _case_view(prior)

    event = ChangeEvent(
        event_id=args.event_id or f"change-{len(case.get('history', []))}",
        changed_object=changed_object,
        previous_version=prior.get("status"),
        current_version=case.get("status", "REOPENED"),
        declared_reason=args.reason,
        changed_properties=tuple(changed_properties),
        timestamp=utc_now(),
        authority=args.authority,
    )

    bundle = load_bundle(case)
    scope = load_scope(case)
    derivation = load_derivation(case)

    def recompute(_case: Any, _plan: Any) -> List[dict]:
        certificate = crg_certify.certify(bundle, scope, derivation)
        return [_store_certificate(case, certificate)]

    current_view = _case_view(case)
    geometry_ids = [
        identifier for identifier in current_view["objects"]
        if identifier.startswith("geometry-")
    ]
    graph = _graph(sorted(case.get("certificates") or {}), geometry_ids)
    delta = apply_change(
        prior_view,
        current_view,
        event,
        graph,
        recompute_fn=recompute,
        approvals=tuple(args.approve or ()),
    )
    replacements = {
        cert_id: case["certificates"][cert_id]
        for cert_id in delta.recomputed
        if cert_id in (case.get("certificates") or {})
    }
    prior_phase, prior_phase_source = _change_phase(prior)
    current_phase, current_phase_source = _change_phase(case)
    evidence = build_certified_delta(
        delta,
        prior_view,
        current_view,
        graph,
        replacements=replacements,
        prior_phase=prior_phase,
        current_phase=current_phase,
    ).to_canonical()
    verification_inputs = _delta_verification_inputs(
        prior_view,
        current_view,
        graph,
        replacements,
        prior_phase,
        current_phase,
        prior_phase_source,
        current_phase_source,
    )
    verification = _verify_delta_document(evidence, verification_inputs)
    if not verification.ok:
        detail = "; ".join(verification.violations) or verification.status
        raise ValueError(
            "the independently reconstructed certified delta disagreed with the producer: "
            + detail
        )
    canonical = delta.to_canonical()
    canonical["delta_hash"] = delta.delta_hash()
    evidence_root = content_hash(evidence)
    if args.evidence_output:
        _write_canonical_document(args.evidence_output, evidence)
    if args.verification_inputs_output:
        _write_canonical_document(args.verification_inputs_output, verification_inputs)
    if not args.preview:
        case.setdefault("deltas", {})[delta.delta_id] = canonical
        case.setdefault("certified_deltas", {})[evidence["evidence_id"]] = evidence
        case.setdefault("certified_delta_inputs", {})[
            evidence["evidence_id"]
        ] = verification_inputs
        for phase, source in (
            (prior_phase, prior_phase_source),
            (current_phase, current_phase_source),
        ):
            if phase is not None and source is not None:
                case.setdefault("phase_analyses", {})[phase["analysis_id"]] = phase
                case.setdefault("phase_sources", {})[phase["source_r_root"]] = source
    # 30.3 step 6 / 17.1: an invalidated certificate is superseded, not
    # deleted.  It leaves the active set -- exporting it as a live claim
    # would let a stale winner keep circulating -- but stays in the case.
    if not args.preview:
        superseded = case.setdefault("superseded_certificates", {})
        for cert_id in delta.invalidated:
            if cert_id in case.get("certificates", {}):
                stale = dict(case["certificates"].pop(cert_id))
                stale["status"] = "SUPERSEDED"
                stale["superseded_by"] = delta.delta_id
                superseded[cert_id] = stale
        case["status"] = "REOPENED" if delta.reopen_reason else "CERTIFIED"
        record_history(
            case,
            "change",
            {
                "delta_id": delta.delta_id,
                "classification": delta.classification,
                "evidence_id": evidence["evidence_id"],
                "evidence_root": evidence_root,
                "independently_verified": True,
                "prior_phase_id": None if prior_phase is None else prior_phase["analysis_id"],
                "current_phase_id": (
                    None if current_phase is None else current_phase["analysis_id"]
                ),
            },
        )
        write_case(args.root, case)
    out.step("change", classification=delta.classification,
             invalidated=len(delta.invalidated), recomputed=len(delta.recomputed))
    payload = {
        "delta_id": delta.delta_id,
        "classification": delta.classification,
        "prior_root": delta.prior_root,
        "current_root": delta.current_root,
        "preserved": list(delta.preserved),
        "invalidated": list(delta.invalidated),
        "recomputed": list(delta.recomputed),
        "prior_winners": list(delta.prior_winners),
        "current_winners": list(delta.current_winners),
        "residual_uncertainty": delta.residual_uncertainty,
        "delta_hash": canonical["delta_hash"],
        "preview": bool(args.preview),
        "certified_delta_id": evidence["evidence_id"],
        "certified_delta_root": evidence_root,
        "certified_delta": evidence,
        "verification_inputs": verification_inputs,
        "verification": verification.to_json(),
    }
    human = [
        f"delta certificate {delta.delta_id}",
        f"  classification    : {delta.classification}",
        f"  changed object    : {changed_object}",
        f"  changed properties: {', '.join(changed_properties)}",
        f"  preserved         : {list(delta.preserved)}",
        f"  invalidated       : {list(delta.invalidated)}",
        f"  recomputed        : {list(delta.recomputed)}",
        f"  winners  before   : {list(delta.prior_winners)}",
        f"  winners  after    : {list(delta.current_winners)}",
        f"  residual          : {delta.residual_uncertainty or 'none'}",
        f"  delta hash        : {canonical['delta_hash']}",
        f"  evidence id       : {evidence['evidence_id']}",
        f"  evidence root     : {evidence_root}",
        f"  independent verify: {verification.status}",
        (
            "  preview only; no case state changed"
            if args.preview
            else "  certified before case persistence"
        ),
    ]
    out.result(payload, "\n".join(human))
    return OK


def cmd_delta_inspect(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    records = case.get("certified_deltas") or {}
    if not records:
        raise CaseError("this case has no certified delta evidence")
    evidence_id = args.evidence
    if not evidence_id:
        for entry in reversed(case.get("history") or []):
            candidate = entry.get("evidence_id")
            if candidate in records:
                evidence_id = candidate
                break
    evidence_id = evidence_id or sorted(records)[-1]
    if evidence_id not in records:
        raise CaseError(f"no certified delta {evidence_id!r} in this case")
    inputs = (case.get("certified_delta_inputs") or {}).get(evidence_id)
    if not isinstance(inputs, Mapping):
        raise CaseError(
            f"certified delta {evidence_id!r} has no portable verification inputs"
        )
    record = records[evidence_id]
    result = _verify_delta_document(record, inputs)
    out.result(
        {
            "certified_delta": record,
            "certified_delta_root": content_hash(record),
            "verification_inputs": inputs,
            "verification": result.to_json(),
        },
        f"certified delta {evidence_id}\n"
        f"  minimum action    : {record['minimum_recomputation_claim']['action']}\n"
        f"  changed fields    : {len(record['changed_fields'])}\n"
        f"  traversed edges   : {len(record['traversed_edges'])}\n"
        f"  verification      : {result.status}",
    )
    return OK if result.ok else VIOLATION


def cmd_delta_verify(args: argparse.Namespace, out: Emitter) -> int:
    record = _json_object(args.path, "certified-delta artifact")
    inputs = _json_object(args.inputs, "certified-delta verification inputs")
    result = _verify_delta_document(record, inputs)
    for name, passed, detail in result.checks:
        out.step("check", check=name, passed=passed, detail=detail)
    out.result(result.to_json(), crg_verify.render_report(result))
    return OK if result.ok else VIOLATION


# ---------------------------------------------------------------------------
# crg export
# ---------------------------------------------------------------------------
def _vir_for(case: dict, certificate: dict) -> dict:
    geometry = case.get("geometry") or {}
    return crg_verify.emit_vir(
        certificate,
        {
            "full": geometry.get("full_frontier"),
            "retained": geometry.get("retained_frontier"),
        },
        case.get("registry"),
    )


def cmd_export(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    registry = case.get("registry")
    if not registry:
        raise CaseError("nothing to export: this case has no registry")
    certificates = dict(case.get("certificates") or {})
    output = args.output or os.path.join(args.root, f"{case['case_id']}.crg")

    objects: Dict[str, Any] = {}

    def _add(object_id: str, payload: Any) -> str:
        objects[object_id] = payload
        return content_hash(payload)

    registry_hash = _add(registry["bundle_id"], registry)
    # Certified-delta typed edges use these stable logical identities.  Carry
    # the endpoint objects so portable dependency-closure verification can
    # resolve every source as well as every certificate target.
    for object_id, logical_object in sorted(_case_objects(case).items()):
        _add(object_id, logical_object)
    for cert_id, certificate in sorted(certificates.items()):
        _add(cert_id, certificate)
    # Superseded certificates travel with the bundle as provenance (6.4,
    # 17.1) but carry no verification program: they are history, not claims.
    for cert_id, certificate in sorted((case.get("superseded_certificates") or {}).items()):
        _add(cert_id, certificate)
    for delta_id, delta in sorted((case.get("deltas") or {}).items()):
        _add(delta_id, delta)
    for artifact_id, artifact in sorted((case.get("safe_commitments") or {}).items()):
        _add(artifact_id, artifact)
    for analysis_id, artifact in sorted((case.get("phase_analyses") or {}).items()):
        _add(analysis_id, artifact)
    for source_root, source in sorted((case.get("phase_sources") or {}).items()):
        _add(f"phase-source:{source_root}", source)
    for evidence_id, artifact in sorted((case.get("certified_deltas") or {}).items()):
        _add(evidence_id, artifact)
    for evidence_id, inputs in sorted((case.get("certified_delta_inputs") or {}).items()):
        _add(f"delta-inputs:{evidence_id}", inputs)
    for object_id, record in portable_intake_objects(case).items():
        _add(object_id, record)
    for object_id, record in portable_comparison_objects(case).items():
        _add(object_id, record)
    for object_id, record in portable_journey_comparison_objects(case).items():
        _add(object_id, record)
    challenge_records = list_decision_challenges(args.root, args.case)
    for object_id, record in portable_decision_challenge_objects(challenge_records).items():
        _add(object_id, record)
    # v1.3 and v1.4: include current and immutable predecessor records with
    # their exact independent-replay inputs and companion evidence objects.
    for object_id, record in portable_lifecycle_objects(case).items():
        _add(object_id, record)
    for name in ("R", "GAMMA", "K"):
        if name in (case.get("geometry") or {}):
            geometry = case["geometry"][name]
            _add(str(geometry.get("root_hash") or f"geometry-{name}"), geometry)
    migration_records: Dict[str, Mapping[str, Any]] = {}
    for record in list(case.get("migrations") or []) + list(case.get("migration_records") or []):
        if isinstance(record, Mapping) and record.get("migration_id"):
            migration_records[str(record["migration_id"])] = record
    if isinstance(case.get("migration_record"), Mapping):
        record = case["migration_record"]
        if record.get("migration_id"):
            migration_records[str(record["migration_id"])] = record
    for migration_id, record in sorted(migration_records.items()):
        _add(migration_id, record)

    programs: Dict[str, Dict[str, Any]] = {}
    reports: Dict[str, str] = {}
    for cert_id, certificate in sorted(certificates.items()):
        vir = _vir_for(case, certificate)
        programs[str(vir["program_id"])] = dict(vir)
        reports[cert_id] = render_certificate_report(certificate)
    for analysis_id, analysis in sorted((case.get("phase_analyses") or {}).items()):
        source = (case.get("phase_sources") or {}).get(analysis.get("source_r_root"))
        if not isinstance(source, Mapping):
            raise CaseError(
                f"phase analysis {analysis_id!r} lacks its portable source R"
            )
        verification = crg_verify.verify_phase_analysis_record(analysis, source)
        if not verification.ok:
            raise CaseError(
                f"phase analysis {analysis_id!r} failed independent reconstruction "
                "during export; no bundle was written"
            )
        reports[f"phase-analysis:{analysis_id}"] = render_phase_analysis_report(
            analysis, verification
        )
    for evidence_id, delta_record in sorted(
        (case.get("certified_deltas") or {}).items()
    ):
        inputs = (case.get("certified_delta_inputs") or {}).get(evidence_id)
        if not isinstance(inputs, Mapping):
            raise CaseError(
                f"certified delta {evidence_id!r} lacks portable verification inputs"
            )
        verification = _verify_delta_document(delta_record, inputs)
        if not verification.ok:
            raise CaseError(
                f"certified delta {evidence_id!r} failed independent reconstruction "
                "during export; no bundle was written"
            )
        reports[f"certified-delta:{evidence_id}"] = render_certified_delta_report(
            delta_record, verification
        )
    for evaluation_id, evaluation in sorted(
        (case.get("comparative_evaluations") or {}).items()
    ):
        verification = crg_verify.verify_comparative_workflow_evaluation(evaluation)
        if not verification.ok:
            raise CaseError(
                f"comparative evaluation {evaluation_id!r} failed independent "
                "reconstruction during export; no bundle was written"
            )
        reports[f"comparative-evaluation:{evaluation_id}"] = (
            render_comparative_evaluation_report(evaluation, verification)
        )
    for comparison_id, record in sorted(
        (case.get("comparative_change_evidence") or {}).items()
    ):
        verification = verify_comparative_change(record)
        reports[f"comparative-change:{comparison_id}"] = (
            render_comparative_change_report(record, verification)
        )
    for journey_id, record in sorted(
        (case.get("cumulative_lifecycle_comparisons") or {}).items()
    ):
        verification = verify_cumulative_comparison(record)
        reports[f"cumulative-lifecycle-comparison:{journey_id}"] = (
            render_cumulative_comparison_report(record, verification)
        )
    for challenge_id, challenge in sorted(challenge_records.items()):
        verification = crg_verify.verify_decision_challenge_record(challenge)
        if not verification.ok:
            raise CaseError(
                f"Decision Challenge {challenge_id!r} failed independent replay "
                "during export; no bundle was written"
            )
        reports[f"decision-challenge:{challenge_id}"] = (
            render_decision_challenge_report(challenge, verification)
        )
    lifecycle_inputs = case.get("lifecycle_verification_inputs") or {}
    for record_type, by_id in sorted((case.get("lifecycle_records") or {}).items()):
        if not isinstance(by_id, Mapping):
            continue
        for record_id, record in sorted(by_id.items()):
            inputs = (lifecycle_inputs.get(record_type) or {}).get(record_id)
            if not isinstance(record, Mapping) or not isinstance(inputs, Mapping):
                raise CaseError(
                    f"lifecycle {record_type} {record_id!r} lacks portable replay inputs"
                )
            verification = verify_lifecycle_record(record, inputs)
            reports[f"lifecycle:{record_type}:{record_id}"] = render_lifecycle_report(
                record, verification
            )

    manifest_hash = crg_io.write_bundle(
        output,
        case=case,
        objects=objects,
        verification_programs=programs,
        reports=reports,
        manifest_metadata={
            "crg_spec_version": "0.2.0",
            "schema_identities": [
                {"schema_id": "coordinate-schema",
                 "schema_hash": content_hash(registry["schema"]),
                 "schema_version": str(registry.get("schema_version", "0.2.0")),
                 "referenced_by": str(registry["bundle_id"])}
            ],
            "quantity_registry_version": "0.2.0",
            "rule_table_version": crg_certify.MAPPING_TABLE_VERSION,
            "signatures": [],
            "encryption": {
                "protected_content_present": False,
                "encrypted_objects": [],
                "claims_depending_on_protected_content": [],
                "verifier_capabilities_required": [],
                "independently_checkable": True,
            },
            "redaction_state": case.get("redaction_state", {"redacted_objects": []}),
            "export_authority": {
                "authority": args.authority or "unattested",
                "basis": "declared by the exporting caller" if args.authority
                else "no export authority was declared",
            },
            "requested_verification_level": args.level,
        },
    )

    payload = {
        "output": output,
        "objects": len(objects),
        "certificates": sorted(certificates),
        "registry_hash": registry_hash,
        "manifest_hash": manifest_hash,
    }
    out.result(
        payload,
        f"exported {output}\n  objects      : {len(objects)}\n"
        f"  certificates : {sorted(certificates)}\n"
        f"  manifest hash: {payload['manifest_hash']}",
    )
    return OK


# ---------------------------------------------------------------------------
# crg verify / report
# ---------------------------------------------------------------------------
def cmd_verify(args: argparse.Namespace, out: Emitter) -> int:
    clock = args.clock
    clock_source = args.clock_source
    if clock is None and args.use_local_clock:
        clock = _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds").replace(
            "+00:00", "Z"
        )
        clock_source = "verifier-local-system-clock"

    path = args.path
    federation_context = None
    federation_context_document = None
    if args.federation_context:
        with open(args.federation_context, encoding="utf-8") as handle:
            federation_context_document = json.load(handle)
        if not isinstance(federation_context_document, dict):
            raise CaseError("a federation verifier context must be a JSON object")
        federation_context = dict(federation_context_document)
        ledger = federation_context.get("nonce_ledger")
        if not isinstance(ledger, list) or any(not isinstance(item, str) for item in ledger):
            raise CaseError(
                "federation context nonce_ledger must be a JSON array of consumed nonce strings"
            )
        federation_context["nonce_ledger"] = set(ledger)
    if os.path.isdir(path) or zipfile.is_zipfile(path):
        result = crg_verify.verify_bundle(
            path, clock=clock, clock_source=clock_source, level=args.level,
            federation_context=federation_context,
        )
    else:
        with open(path, encoding="utf-8") as handle:
            document = json.load(handle)
        if (
            set(document) == {"record", "verification_inputs"}
            and isinstance(document.get("record"), Mapping)
            and str(document["record"].get("record_type"))
            in LIFECYCLE_RECORD_TYPES
        ):
            result = verify_lifecycle_record(
                document["record"], document["verification_inputs"]
            )
        elif "vir_version" in document:
            result = crg_verify.verify_vir(document, clock=clock, clock_source=clock_source)
        elif document.get("record_type") == "SafeCommitmentArtifact":
            result = crg_verify.verify_safe_commitment(document)
        elif document.get("record_type") == "PhaseAnalysisRecord":
            if not args.source_r:
                raise CaseError(
                    "a portable phase analysis requires --source-r for independent verification"
                )
            result = crg_verify.verify_phase_analysis_record(
                document, _json_object(args.source_r, "phase-analysis source R")
            )
        elif document.get("record_type") == "CertifiedDeltaRecord":
            if not args.verification_inputs:
                raise CaseError(
                    "a portable certified delta requires --verification-inputs for independent verification"
                )
            result = _verify_delta_document(
                document,
                _json_object(
                    args.verification_inputs, "certified-delta verification inputs"
                ),
            )
        elif document.get("record_type") == "ComparativeWorkflowEvaluation":
            result = crg_verify.verify_comparative_workflow_evaluation(document)
        elif document.get("record_type") == "ComparativeChangeEvidence":
            result = crg_verify.verify_comparative_change_evidence(document)
        elif document.get("record_type") == "CumulativeLifecycleComparison":
            result = crg_verify.verify_cumulative_lifecycle_comparison(document)
        elif document.get("record_type") == "DecisionChallengeRecord":
            result = crg_verify.verify_decision_challenge_record(document)
        elif document.get("record_type") == "OperationalMeasurementExport":
            return cmd_measurement_verify(args, out)
        else:
            registry = None
            if args.registry:
                with open(args.registry, encoding="utf-8") as handle:
                    registry = json.load(handle)
            result = crg_verify.verify_certificate(
                document, registry=registry, clock=clock, clock_source=clock_source
            )

    # A successful V4 answer is replay-bound only if consuming its nonce is
    # durable across verifier processes.  Persist the caller-owned ledger by
    # atomic replacement before reporting success.
    if result.ok and args.level == "V4" and federation_context is not None:
        federation_context_document["nonce_ledger"] = sorted(
            federation_context["nonce_ledger"]
        )
        destination = os.path.abspath(args.federation_context)
        temporary = f"{destination}.tmp.{os.getpid()}"
        try:
            with open(temporary, "w", encoding="utf-8", newline="\n") as handle:
                handle.write(canonical_json(federation_context_document) + "\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, destination)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)

    for name, passed, detail in result.checks:
        out.step("check", check=name, passed=passed, detail=detail)
    out.result(result.to_json(), crg_verify.render_report(result))
    return OK if result.ok else VIOLATION


def cmd_report(args: argparse.Namespace, out: Emitter) -> int:
    # A case identifier is also a directory name, so the case is resolved
    # first; only a target that is not a case is read as a bundle.
    is_case = os.path.exists(os.path.join(args.root, args.target, "case.json"))
    if not is_case and (os.path.isdir(args.target) or zipfile.is_zipfile(args.target)):
        reader = crg_verify.bundle.open_bundle(args.target)
        try:
            names = [n for n in reader.names if n.startswith("reports/") and n.endswith(".md")]
            text = "\n\n".join(reader.read(n).decode("utf-8") for n in sorted(names))
        finally:
            reader.close()
        out.result({"target": args.target, "reports": len(text.splitlines())}, text)
        return OK

    case = read_case(args.root, args.target)
    requested = [
        value
        for value in (
            getattr(args, "certificate", None),
            getattr(args, "phase_analysis", None),
            getattr(args, "certified_delta", None),
        )
        if value
    ]
    if len(requested) > 1:
        raise CaseError(
            "select only one of --certificate, --phase-analysis, or --certified-delta"
        )
    if getattr(args, "phase_analysis", None):
        analyses = case.get("phase_analyses") or {}
        analysis_id = args.phase_analysis
        if analysis_id not in analyses:
            raise CaseError(f"no phase analysis {analysis_id!r} in this case")
        record = analyses[analysis_id]
        source = (case.get("phase_sources") or {}).get(record.get("source_r_root"))
        if not isinstance(source, Mapping):
            raise CaseError(f"phase analysis {analysis_id!r} lacks its portable source R")
        verification = crg_verify.verify_phase_analysis_record(record, source)
        text = render_phase_analysis_report(record, verification)
        out.result(
            {"analysis_id": analysis_id, "report": text, "verified": verification.ok},
            text,
        )
        return OK if verification.ok else VIOLATION
    if getattr(args, "certified_delta", None):
        records = case.get("certified_deltas") or {}
        evidence_id = args.certified_delta
        if evidence_id not in records:
            raise CaseError(f"no certified delta {evidence_id!r} in this case")
        inputs = (case.get("certified_delta_inputs") or {}).get(evidence_id)
        if not isinstance(inputs, Mapping):
            raise CaseError(
                f"certified delta {evidence_id!r} lacks portable verification inputs"
            )
        record = records[evidence_id]
        verification = _verify_delta_document(record, inputs)
        text = render_certified_delta_report(record, verification)
        out.result(
            {"evidence_id": evidence_id, "report": text, "verified": verification.ok},
            text,
        )
        return OK if verification.ok else VIOLATION
    certificates = case.get("certificates") or {}
    if not certificates:
        raise CaseError("this case carries no certificate to report on")
    cert_id = args.certificate or sorted(certificates)[-1]
    if cert_id not in certificates:
        raise CaseError(f"no certificate {cert_id!r} in this case")
    certificate = certificates[cert_id]
    verification = crg_verify.verify_vir(_vir_for(case, certificate))
    text = render_certificate_report(certificate, verification)
    out.result({"certificate_id": cert_id, "report": text, "verified": verification.ok}, text)
    return OK if verification.ok else VIOLATION


# ---------------------------------------------------------------------------
# crg conformance -- the Minimum Credible Loop, end to end (54.2, 54.4)
# ---------------------------------------------------------------------------
MCL_CSV = """realization_id,latency,energy,legality
p1,1,2,LEGAL
p2,2,3,LEGAL
p3,4,1,LEGAL
p4,3,3,LEGAL
"""

MCL_SCOPE = {
    "id": "package-choice",
    "objective_family": {"type": "weighted_sum", "weights": {"latency": 1, "energy": 1}},
    "quantification": "EACH_OBJECTIVE",
    "ties": {"policy_tolerance": 0},
}


def cmd_conformance(args: argparse.Namespace, out: Emitter) -> int:
    """Run the Minimum Credible Loop end to end in a scratch workspace."""
    steps: List[Dict[str, Any]] = []
    failures: List[str] = []
    with tempfile.TemporaryDirectory() as root:
        source = os.path.join(root, "candidates.csv")
        with open(source, "w", encoding="utf-8") as handle:
            handle.write(MCL_CSV)
        scope_path = os.path.join(root, "scope.json")
        with open(scope_path, "w", encoding="utf-8") as handle:
            json.dump(MCL_SCOPE, handle)
        bundle_path = os.path.join(root, "mcl.crg")

        plan = [
            ["init", "mcl"],
            ["import", "mcl", "--source", source,
             "--completeness", CompletenessBasisType.EXPLICIT_IMPORTED_FAMILY,
             "--universe", "the four declared packages"],
            ["geometry", "mcl", "--objects", "R,Gamma,K"],
            ["query", "compile", "mcl", "--scope", scope_path],
            ["certify", "mcl"],
            ["change", "mcl", "--set", "p1.latency=9", "--reason", "measurement update"],
            ["export", "mcl", "--output", bundle_path],
            ["verify", bundle_path, "--level", "V3"],
        ]
        for argv in plan:
            code = main(argv + ["--dir", root, "--quiet"])
            label = " ".join(a for a in argv if not a.startswith("/"))
            steps.append({"step": label, "expected_exit": OK, "exit_code": code})
            out.step("mcl", command=label, exit_code=code)
            if code != OK:
                failures.append(f"{label} exited {code}")

        # 54.4 step 9, and 6.6 at the process boundary: a tampered bundle
        # MUST NOT verify.  A nonzero exit is the pass condition here.
        tampered = os.path.join(root, "tampered.crg")
        _tamper(bundle_path, tampered)
        code = main(["verify", tampered, "--dir", root, "--quiet"])
        steps.append(
            {"step": "verify tampered bundle (must fail)", "expected_exit": VIOLATION,
             "exit_code": code}
        )
        out.step("mcl", command="verify tampered bundle", exit_code=code)
        if code == OK:
            failures.append("a tampered bundle verified; the loop is not fail-closed")

    payload = {"suite": "minimum-credible-loop", "steps": steps, "failures": failures,
               "ok": not failures}
    human = ["Minimum Credible Loop (spec 54.2)"]
    for step in steps:
        mark = "ok  " if step["exit_code"] == step["expected_exit"] else "FAIL"
        human.append(
            f"  [{mark}] {step['step']} "
            f"(exit {step['exit_code']}, expected {step['expected_exit']})"
        )
    human.append("")
    human.append("PASS" if not failures else "FAIL: " + "; ".join(failures))
    out.result(payload, "\n".join(human))
    return OK if not failures else VIOLATION


def _tamper(source: str, target: str) -> None:
    """Rewrite one object inside a bundle without repairing the manifest."""
    with zipfile.ZipFile(source) as archive:
        items = {name: archive.read(name) for name in archive.namelist()}
    for name, payload in list(items.items()):
        if name.startswith("objects/sha256/"):
            document = json.loads(payload.decode("utf-8"))
            if isinstance(document, dict) and document.get("realizations"):
                document["realizations"][0]["signature"][0] = {"exact": "0"}
                items[name] = canonical_json(document).encode("utf-8")
                break
    with zipfile.ZipFile(target, "w") as archive:
        for name, payload in items.items():
            archive.writestr(name, payload)


def _json_document(path: str, *, what: str) -> Any:
    """Read a required JSON document, refusing the 26.7 indentation form here."""
    document = read_query_document(path)
    if isinstance(document, str):
        raise CaseError(f"{what} must be a JSON document")
    return document


def _agent_json_document(path: str, *, what: str) -> Any:
    """Read one strict JSON document (or stdin) for the deterministic ABI."""
    def object_pairs(pairs):
        record: Dict[str, Any] = {}
        for key, value in pairs:
            if key in record:
                raise DesignSpaceError(f"{what} contains duplicate key {key!r}")
            record[key] = value
        return record

    def reject_constant(value: str) -> None:
        raise DesignSpaceError(f"{what} contains non-finite numeric token {value}")

    handle = sys.stdin if path == "-" else open(path, encoding="utf-8")
    try:
        try:
            return json.load(
                handle, object_pairs_hook=object_pairs, parse_constant=reject_constant
            )
        except (json.JSONDecodeError, UnicodeDecodeError, RecursionError) as error:
            raise DesignSpaceError(f"{what} is not valid bounded JSON: {error}") from None
    finally:
        if handle is not sys.stdin:
            handle.close()


def _verified_agent_design_space(request: Mapping[str, Any]) -> Tuple[dict, Any]:
    result = produce_agent_design_space(request)
    verification = crg_verify.verify_agent_design_space(result)
    if not verification.ok:
        raise DesignSpaceError(
            "code-separated agent design-space verification disagreed: "
            + "; ".join(verification.violations)
        )
    return result, verification


def _verified_agent_design_space_batch(
    requests: Sequence[Mapping[str, Any]],
) -> Tuple[dict, List[dict]]:
    batch = produce_agent_design_space_batch(requests)
    verifications: List[dict] = []
    for result in batch["results"]:
        verification = crg_verify.verify_agent_design_space(result)
        if not verification.ok:
            raise DesignSpaceError(
                "code-separated batch verification disagreed for request "
                f"{result.get('request_id')!r}: "
                + "; ".join(verification.violations)
            )
        verifications.append(verification.to_json())
    return batch, verifications


def cmd_design_space_capabilities(_args: argparse.Namespace, out: Emitter) -> int:
    capabilities = agent_design_space_capabilities()
    out.result(
        capabilities,
        (
            f"{capabilities['profile']}\n"
            f"  input kind        : {capabilities['input_kind']}\n"
            f"  capabilities hash : {capabilities['capabilities_hash']}\n"
            "  authority         : non-mutating analysis only"
        ),
    )
    return OK


def cmd_design_space_prune(args: argparse.Namespace, out: Emitter) -> int:
    request = _agent_json_document(args.request, what="AgentDesignSpaceRequest")
    if not isinstance(request, Mapping):
        raise DesignSpaceError("AgentDesignSpaceRequest must be a JSON object")
    out.step("design-space.generate", request_id=request.get("request_id"))
    result, verification = _verified_agent_design_space(request)
    out.step(
        "design-space.verify",
        status=verification.status,
        result_hash=result["result_hash"],
    )
    if args.output:
        _write_canonical_document(args.output, result)
    resource = result["resource_boundary"]
    closure_reexecuted = bool(
        verification.report.get("generator_closure_reexecution")
    )
    human = [
        f"agent design space {result['request_id']!r} {verification.status}",
        f"  result hash       : {result['result_hash']}",
        f"  explored          : {resource['explored_realizations']}",
        f"  accepted          : {resource['accepted_realizations']}",
        f"  fixpoint          : {resource['reached_fixpoint']}",
        f"  truncated         : {resource['truncated']}",
    ]
    for reduction in result["reduced_search_spaces"]:
        human.append(
            f"  policy {reduction['policy_id']}: {reduction['status']}; "
            f"retained={len(reduction['retained_ids'])}, "
            f"pruned={len(reduction['pruned_ids'])}"
        )
        for refusal in reduction["refusals"]:
            human.append(f"    REFUSED: {refusal}")
    human.append(
        "  closure replay    : "
        + (
            "independently re-executed and matched"
            if closure_reexecuted
            else (
                "not independently re-executed; exact trace and pruning "
                "mathematics verified"
            )
        )
    )
    out.result(
        {
            "design_space": result,
            "verification": verification.to_json(),
            "output": args.output,
        },
        "\n".join(human),
    )
    return OK


def cmd_design_space_verify(args: argparse.Namespace, out: Emitter) -> int:
    result = _agent_json_document(args.path, what="AgentDesignSpaceResult")
    if not isinstance(result, Mapping):
        raise DesignSpaceError("AgentDesignSpaceResult must be a JSON object")
    verification = crg_verify.verify_agent_design_space(result)
    payload = {
        "result_hash": result.get("result_hash"),
        "verification": verification.to_json(),
        "generator_closure_reexecution": bool(
            verification.report.get("generator_closure_reexecution")
        ),
    }
    out.result(
        payload,
        f"{verification.status}: {result.get('result_hash')}\n"
        "  generator closure replay: "
        + (
            "independently re-executed and matched"
            if payload["generator_closure_reexecution"]
            else "not performed by the portable verifier"
        ),
    )
    return OK if verification.ok else VIOLATION


def cmd_design_space_batch(args: argparse.Namespace, out: Emitter) -> int:
    document = _agent_json_document(args.request, what="AgentDesignSpaceBatchRequest")
    if not isinstance(document, Mapping) or set(document) != {"requests"}:
        raise DesignSpaceError(
            "AgentDesignSpaceBatchRequest must contain exactly a 'requests' array"
        )
    requests = document.get("requests")
    if not isinstance(requests, list):
        raise DesignSpaceError("AgentDesignSpaceBatchRequest.requests must be an array")
    for index, request in enumerate(requests):
        if isinstance(request, Mapping):
            request_id = request.get("request_id")
        else:
            request_id = None
        out.step(
            "design-space.batch-item",
            ordinal=index + 1,
            total=len(requests),
            request_id=request_id,
        )
    batch, verifications = _verified_agent_design_space_batch(requests)
    if args.output:
        _write_canonical_document(args.output, batch)
    out.result(
        {"batch": batch, "verifications": verifications, "output": args.output},
        f"verified {batch['request_count']} design spaces; batch hash {batch['batch_hash']}",
    )
    return OK


# ---------------------------------------------------------------------------
# crg generate -- build a registry from a generator pack (spec 28, 36.5)
# ---------------------------------------------------------------------------
def cmd_generate(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    spec = _json_document(args.spec, what="a generate spec")
    bundle, report = generate_registry(spec)

    case["registry"] = bundle.to_canonical()
    _normalize_registry(case)
    case["generation_report"] = report.to_canonical()
    case["status"] = "GENERATED"
    record_history(case, "generate",
                   {"pack": spec.get("pack"), "accepted": len(report.accepted)})
    write_case(args.root, case)

    basis = bundle.completeness
    out.step("generate", pack=spec.get("pack"), accepted=len(report.accepted),
             derived_basis=basis.basis_type)
    payload = {
        "case_id": case["case_id"],
        "pack": spec.get("pack"),
        "accepted": list(report.accepted),
        "rejected": report.rejected_count,
        "ungenerated_regions": len(report.ungenerated),
        "generators": list(report.generators),
        "derived_completeness_basis": basis.basis_type,
        "declared_universe": basis.declared_universe,
        "claim_scope": report.claim_scope,
        "registry_hash": content_hash(case["registry"]),
    }
    human = [
        f"generated {len(report.accepted)} realizations with pack {spec.get('pack')!r}",
        f"  generators         : {', '.join(report.generators) or 'none (imported seeds)'}",
        f"  rejected candidates: {report.rejected_count}",
        f"  ungenerated regions: {len(report.ungenerated)}",
        # 21.3/28.3 step 10: the basis is DERIVED from what generation did, not
        # declared by the caller; that is what makes it stronger than an import.
        f"  DERIVED completeness basis: {basis.basis_type}",
        f"  declared universe  : {basis.declared_universe}",
        f"  claim scope        : {report.claim_scope}",
        f"  registry hash      : {payload['registry_hash']}",
    ]
    for region in report.ungenerated:
        human.append(f"    ungenerated: {getattr(region, 'reason_code', region)}")
    out.result(payload, "\n".join(human))
    return OK


# ---------------------------------------------------------------------------
# crg reopen -- reopen certificates and emit a delta (spec 30.2 REOPEN)
# ---------------------------------------------------------------------------
def _graph_targeting(source: str, cert_ids: Sequence[str]) -> DependencyGraph:
    graph = DependencyGraph()
    for index, cert_id in enumerate(sorted(cert_ids)):
        graph.add_edge(DependencyEdge(
            edge_id=f"{source}->{cert_id}#{index}",
            source=source, target=cert_id, edge_type=EdgeType.DEPENDS_ON_SCOPE_OF))
    return graph


def cmd_reopen(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    active = dict(case.get("certificates") or {})
    if not active:
        raise CaseError("nothing to reopen: this case has no active certificate")
    targets = list(args.certificate) if args.certificate else sorted(active)
    unknown = [c for c in targets if c not in active]
    if unknown:
        raise CaseError(f"no such active certificate(s) to reopen: {', '.join(unknown)}")

    prior = json.loads(canonical_json(case))
    prior_view = _case_view(prior)
    changed_object = "decision-scope"  # 30.2: DECISION_SCOPE is decided by kind -> REOPEN
    event = ChangeEvent(
        event_id=args.event_id or f"reopen-{len(case.get('history', []))}",
        changed_object=changed_object,
        previous_version=case.get("status"),
        current_version="REOPENED",
        declared_reason=args.reason,
        changed_properties=(),
        timestamp=utc_now(),
        authority=args.authority,
    )
    current_view = _case_view(case)

    def recompute(_case: Any, _plan: Any) -> List[dict]:
        # A reopen invalidates; it does not silently manufacture a new winner.
        # The case is left REOPENED_PENDING_RECERTIFICATION until re-certified.
        return []

    delta = apply_change(
        prior_view, current_view, event,
        _graph_targeting(changed_object, targets),
        recompute_fn=recompute, approvals=tuple(args.approve or ()),
    )
    canonical = delta.to_canonical()
    canonical["delta_hash"] = delta.delta_hash()
    case.setdefault("deltas", {})[delta.delta_id] = canonical

    superseded = case.setdefault("superseded_certificates", {})
    for cert_id in delta.invalidated:
        if cert_id in case.get("certificates", {}):
            reopened = dict(case["certificates"].pop(cert_id))
            reopened["status"] = "REOPENED"
            reopened["reopened_by"] = delta.delta_id
            reopened["reopen_reason"] = args.reason
            superseded[cert_id] = reopened
    case["status"] = "REOPENED"
    record_history(case, "reopen",
                   {"delta_id": delta.delta_id, "reopened": list(delta.invalidated)})
    write_case(args.root, case)

    out.step("reopen", reopened=len(delta.invalidated),
             classification=delta.classification)
    payload = {
        "delta_id": delta.delta_id,
        "classification": delta.classification,
        "reopened": list(delta.invalidated),
        "preserved": list(delta.preserved),
        "reopen_reason": delta.reopen_reason,
        "declared_reason": args.reason,
        "residual_uncertainty": delta.residual_uncertainty,
        "delta_hash": canonical["delta_hash"],
    }
    human = [
        f"reopened {len(delta.invalidated)} certificate(s)",
        f"  reopened          : {list(delta.invalidated)}",
        f"  declared reason   : {args.reason}",
        f"  classification    : {delta.classification}",
        f"  why (30.2)        : {delta.reopen_reason}",
        f"  residual          : {delta.residual_uncertainty or 'none'}",
        f"  case status       : REOPENED (pending recertification)",
        f"  delta hash        : {canonical['delta_hash']}",
    ]
    out.result(payload, "\n".join(human))
    return OK


# ---------------------------------------------------------------------------
# crg convert -- ownership and layout conversion (spec 31)
# ---------------------------------------------------------------------------
def cmd_convert(args: argparse.Namespace, out: Emitter) -> int:
    record = layout_conversion(args.source, args.target)
    payload = {
        "record_id": record.record_id,
        "retained_fraction": str(record.retained_fraction),
        "moved_fraction": str(record.moved_fraction),
        "assignment": {str(k): v for k, v in sorted(record.assignment.items())},
        "source_cells": len(record.source_cells),
        "target_cells": len(record.target_cells),
        "ownership_contract": record.ownership_contract,
    }
    if args.case:
        case = read_case(args.root, args.case)
        case.setdefault("conversions", {})[record.record_id] = record.to_canonical()
        record_history(case, "convert",
                       {"record_id": record.record_id,
                        "retained": str(record.retained_fraction)})
        write_case(args.root, case)
        payload["case_id"] = case["case_id"]

    out.step("convert", retained=str(record.retained_fraction),
             moved=str(record.moved_fraction))
    human = [
        f"conversion {record.record_id}",
        f"  source cells      : {len(record.source_cells)}",
        f"  target cells      : {len(record.target_cells)}",
        f"  retained fraction : {record.retained_fraction}",
        f"  moved fraction    : {record.moved_fraction}",
        f"  ownership contract: {record.ownership_contract}",
    ]
    out.result(payload, "\n".join(human))
    return OK


# ---------------------------------------------------------------------------
# crg evidence add / crg technology assemble (spec 33)
# ---------------------------------------------------------------------------
def cmd_evidence_add(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    doc = _json_document(args.evidence, what="an evidence record")
    record = evidence_record(doc)
    stored = {
        "evidence_id": record.evidence_id,
        "record": record.to_canonical(),
        "fingerprint": record.fingerprint(),
        # Kept so `crg technology assemble` can rebuild the record exactly;
        # there is no from-canonical constructor, and re-deriving from the
        # source document is the honest round-trip (14.3).
        "source_document": doc,
    }
    case.setdefault("evidence", {})[record.evidence_id] = stored
    record_history(case, "evidence add", {"evidence_id": record.evidence_id})
    write_case(args.root, case)

    out.step("evidence", evidence_id=record.evidence_id,
             provenance=record.provenance.status())
    payload = {
        "case_id": case["case_id"],
        "evidence_id": record.evidence_id,
        "quantity": record.quantity,
        "unit": record.unit,
        "value": record.value.to_canonical(),
        "evidence_class": record.method.evidence_class,
        "evidence_status": record.evidence_status,
        "provenance_status": record.provenance.status(),
        "fingerprint": record.fingerprint(),
        "registered": sorted(case["evidence"]),
    }
    human = [
        f"registered evidence {record.evidence_id!r}",
        f"  quantity/unit     : {record.quantity} [{record.unit}]",
        f"  value enclosure   : [{record.value.lo}, {record.value.hi}]",
        f"  evidence class    : {record.method.evidence_class}",
        f"  evidence status   : {record.evidence_status}",
        f"  provenance        : {record.provenance.status()}",
        f"  fingerprint       : {record.fingerprint()}",
        f"  case now holds    : {len(case['evidence'])} evidence record(s)",
    ]
    out.result(payload, "\n".join(human))
    return OK


def cmd_technology_assemble(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    evidence_docs: List[dict] = [
        entry["source_document"]
        for entry in (case.get("evidence") or {}).values()
        if isinstance(entry, dict) and entry.get("source_document")
    ]
    if args.evidence:
        for path in args.evidence:
            extra = _json_document(path, what="an evidence document")
            evidence_docs.extend(extra if isinstance(extra, list) else [extra])
    if not evidence_docs:
        raise CaseError(
            "no evidence to assemble from: run `crg evidence add` first or pass --evidence")

    rules_raw = _json_document(args.rules, what="an applicability rules document")
    rules_docs = rules_raw.get("rules", rules_raw) if isinstance(rules_raw, dict) else rules_raw
    if not isinstance(rules_docs, list):
        rules_docs = [rules_docs]
    target_doc = _json_document(args.target, what="a target-context document")
    coordinate_docs = None
    if args.coordinates:
        coords_raw = _json_document(args.coordinates, what="a coordinate-request document")
        coordinate_docs = coords_raw.get("coordinates", coords_raw) \
            if isinstance(coords_raw, dict) else coords_raw
    clock_doc = {"evaluation_time": args.clock} if args.clock else None
    requester_doc = {"subject_id": args.requester} if args.requester else None

    contract, report = assemble_contract(
        evidence_docs, rules_docs, target_doc,
        clock_doc=clock_doc, requester_doc=requester_doc,
        coordinate_docs=coordinate_docs, contract_id=args.contract_id,
    )
    domain = contract.to_technology_domain()
    bounded = [c.coordinate_id for c in contract.bounded_coordinates]
    rejections = [
        {"reason_code": r.reason_code, "coordinate_id": r.coordinate_id,
         "evidence_id": r.evidence_id, "rule_id": r.rule_id, "detail": r.detail}
        for r in report.rejections
    ]
    summary = {
        "contract_id": args.contract_id,
        "verification_status": contract.verification_status,
        "bounded_coordinates": bounded,
        "technology_domain": domain,
        "rejections": rejections,
    }
    case.setdefault("technology_contracts", {})[args.contract_id] = summary
    record_history(case, "technology assemble",
                   {"contract_id": args.contract_id,
                    "status": contract.verification_status})
    write_case(args.root, case)

    out.step("assemble", status=contract.verification_status,
             bounded=len(bounded), rejected=len(rejections))
    payload = {
        "case_id": case["case_id"],
        **summary,
    }
    human = [
        f"assembled technology contract {args.contract_id!r}",
        f"  verification status: {contract.verification_status}",
        f"  bounded coordinates: {bounded or 'none'}",
    ]
    for coordinate_id in bounded:
        human.append(f"    + {coordinate_id}: {domain.get(coordinate_id)}")
    # 33.5/33.7: rejections are shown distinctly -- each carries its own reason
    # code and the coordinate/evidence it concerns, never a generic failure.
    human.append(f"  rejections ({len(rejections)}):")
    for rejection in rejections:
        where = rejection["coordinate_id"] or rejection["evidence_id"] or "-"
        human.append(f"    - {rejection['reason_code']} [{where}]: {rejection['detail']}")
    affirmative = contract.verification_status in ("VERIFIED", "TIME_INDETERMINATE")
    out.result(payload, "\n".join(human))
    return OK if affirmative else VIOLATION


# ---------------------------------------------------------------------------
# crg qualify -- inverse qualification plan (spec 34)
# ---------------------------------------------------------------------------
def cmd_qualify(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    doc = _json_document(args.spec, what="a qualify spec")
    plan, _objective, ranked = qualification_plan(doc)

    case.setdefault("qualification_plans", {})[plan.plan_id] = plan.to_canonical()
    record_history(case, "qualify",
                   {"plan_id": plan.plan_id, "experiments": len(ranked)})
    write_case(args.root, case)

    ranking = [
        {"rank": r.rank, "experiment_id": r.experiment_id, "tier": r.tier_name,
         "score": (str(r.score) if r.score is not None else None),
         "ambiguity_reduction": str(r.ambiguity_reduction)}
        for r in ranked
    ]
    stopping = [
        {"condition": s.condition,
         "threshold": (str(s.threshold) if s.threshold is not None else None),
         "metric": s.metric}
        for s in plan.stopping_rules
    ]
    out.step("qualify", plan=plan.plan_id, experiments=len(ranking))
    payload = {
        "case_id": case["case_id"],
        "plan_id": plan.plan_id,
        "ranking": ranking,
        "sequence": list(plan.sequence),
        "stopping_rules": stopping,
        "measurable_targets": [t.target_id for t in plan.measurable_targets],
        "residual_ambiguity": str(plan.residual_ambiguity),
        "residual_metric": plan.residual_metric,
    }
    human = [f"qualification plan {plan.plan_id!r}", "  experiment ranking (34.4):"]
    for entry in ranking:
        human.append(
            f"    {entry['rank']}. {entry['experiment_id']} [{entry['tier']}] "
            f"score={entry['score']} reduction={entry['ambiguity_reduction']}")
    human.append(f"  run sequence      : {' -> '.join(plan.sequence) or 'none'}")
    human.append("  stopping rule (34.5):")
    for rule in stopping:
        detail = f" threshold={rule['threshold']} metric={rule['metric']}" \
            if rule["threshold"] else ""
        human.append(f"    - {rule['condition']}{detail}")
    human.append(f"  residual ambiguity: {plan.residual_ambiguity} ({plan.residual_metric})")
    out.result(payload, "\n".join(human))
    return OK


# ---------------------------------------------------------------------------
# crg evaluate -- submit an evaluator request / register a witness (spec 32)
# ---------------------------------------------------------------------------
def cmd_evaluate(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    bundle = load_bundle(case)
    request_doc = _json_document(args.request, what="an evaluator request")
    response_doc = _json_document(args.response, what="an evaluator response")

    response, witness, update, signoff = run_evaluation(request_doc, response_doc, bundle)

    # register_witness / apply_feasibility mutate the realization record in the
    # bundle; persist the updated registry so the evidence class survives.
    case["registry"] = bundle.to_canonical()
    _normalize_registry(case)
    if witness is not None:
        case.setdefault("witnesses", {})[witness.witness_id] = witness.to_canonical()
    if update is not None:
        case.setdefault("feasibility_updates", []).append(update.to_canonical())
    record_history(case, "evaluate",
                   {"kind": response.kind, "signoff": signoff})
    write_case(args.root, case)

    determinate = witness is not None or (update is not None and update.marks_infeasible)
    out.step("evaluate", kind=response.kind, signoff=signoff,
             determinate=determinate)
    payload = {
        "case_id": case["case_id"],
        "response_kind": response.kind,
        "evidence_class": response.evidence_class,
        "signoff_status": signoff,
        "feasibility_effect": None if update is None else update.effect,
        "witness_id": None if witness is None else witness.witness_id,
        "physical_signoff": bool(witness is not None and witness.physical_signoff),
        "determinate": determinate,
        "detail": response.detail,
    }
    human = [
        f"evaluator response: {response.kind}",
        f"  evidence class    : {response.evidence_class or 'none (a failure carries none)'}",
        f"  signoff status    : {signoff}",
    ]
    if witness is not None:
        human.append(f"  witness registered: {witness.witness_id}")
        human.append(f"  physical signoff  : {witness.physical_signoff}")
    if update is not None:
        human.append(f"  feasibility effect: {update.effect}")
        # 32.1: a tool failure is an absence of knowledge, never infeasibility.
        if not update.marks_infeasible:
            human.append("  NOTE: nothing determinative was recorded; a tool failure is not "
                         "physical infeasibility (spec 32.1)")
    if response.detail:
        human.append(f"  detail            : {response.detail}")
    out.result(payload, "\n".join(human))
    return OK if determinate else VIOLATION


# ---------------------------------------------------------------------------
# crg branch / merge -- branching and merge policy (spec 16)
# ---------------------------------------------------------------------------
def cmd_branch(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    for field_name, value in (("--name", args.name), ("--purpose", args.purpose),
                              ("--creator", args.creator)):
        if not value:
            raise CaseError(f"a branch must declare {field_name} (spec 16.2)")
    branch_case_id = f"{args.case}@{args.name}"
    if os.path.exists(os.path.join(case_dir(args.root, branch_case_id), "case.json")):
        raise CaseError(f"branch {args.name!r} of {args.case!r} already exists")

    parent_hash = content_hash(case)
    child = json.loads(canonical_json(case))
    child["case_id"] = branch_case_id
    child["branch_id"] = args.name
    child["status"] = "BRANCHED"
    inherited = dict(case.get("certificates") or {})
    child["certificates"] = {}  # 16.5: parent certificates do not travel
    child["inherited_certificates"] = {
        cert_id: {**dict(cert), "status": "HISTORICAL_EVIDENCE",
                  "reuse_condition": "16.5: reusable only after dependency-aware revalidation"}
        for cert_id, cert in inherited.items()
    }
    record = {
        "record_type": "BranchRecord",
        "branch_id": args.name,
        "case_id": branch_case_id,
        "parent_case": args.case,
        "parent_version": int(case.get("case_version") or 1),
        "parent_content_hash": parent_hash,
        "branch_point": parent_hash,
        "purpose": args.purpose,
        "creator": args.creator,
        "access_policy": args.access_policy or "inherited",
        "intended_decision_scope": args.scope
        or (case.get("scope") or {}).get("scope_id") or "undeclared",
        "expected_reconciliation": args.reconciliation,
        "created_at": utc_now(),
    }
    child["branch_record"] = record
    child.setdefault("history", []).append(
        {"command": "branch", "from": args.case, "at": record["created_at"]})
    write_case(args.root, child)

    out.step("branch", branch=branch_case_id, inherited=len(inherited))
    payload = {
        "branch_case_id": branch_case_id,
        "parent_case": args.case,
        "branch_point": parent_hash,
        "inherited_certificates": sorted(inherited),
        "active_certificates": [],
    }
    human = [
        f"branched {args.case!r} -> {branch_case_id!r}",
        f"  purpose           : {args.purpose}",
        f"  creator           : {args.creator}",
        f"  branch point      : {parent_hash}",
        f"  active certificates: none (16.5: parent certificates do not travel)",
        f"  inherited (history): {sorted(inherited) or 'none'}",
    ]
    out.result(payload, "\n".join(human))
    return OK


#: Section 16.3, verbatim: the semantic objects CRG SHALL NOT auto-merge, keyed
#: by the case field that carries each in this store.
_SEMANTIC_OBJECTS: Dict[str, str] = {
    "contract": "computation contracts",
    "resource_contract": "resource contracts",
    "legality": "legality rules",
    "registry": "realization registries",
    "scope": "decision queries",
    "derivation": "decision queries",
    "certificates": "certificates",
    "evidence": "evidence",
    "technology_contract": "technology contracts",
    "technology_contracts": "technology contracts",
    "applicability_rules": "applicability rules",
}


def cmd_merge(args: argparse.Namespace, out: Emitter) -> int:
    source = read_case(args.root, args.source)
    target = read_case(args.root, args.target)
    conflicts = [
        f"{field_name} ({description})"
        for field_name, description in sorted(_SEMANTIC_OBJECTS.items())
        if canonical_json(source.get(field_name)) != canonical_json(target.get(field_name))
    ]

    if conflicts:
        decision = "REFUSED_SEMANTIC"
        automatic = False
        required_actions = [
            "create a new case version", "record a MergeDecisionRecord",
            "record explicit conflict resolutions", "record a dependency diff",
            "record a change classification", "invalidate affected certificates",
            "re-verify or reissue preserved claims",
        ]
        rationale = ("16.3: CRG SHALL NOT automatically merge semantic objects; "
                     f"{len(conflicts)} semantic object(s) differ")
    else:
        decision = "NO_DIFFERENCE"
        automatic = True
        required_actions = []
        rationale = "no semantic object differs between these cases"

    record = {
        "record_type": "MergeDecisionRecord",
        "decision": decision,
        "automatic": automatic,
        "source_case": args.source,
        "target_case": args.target,
        "semantic_conflicts": conflicts,
        "required_actions": required_actions,
        "rationale": rationale,
        "recorded_at": utc_now(),
    }
    target.setdefault("merge_decisions", []).append(record)
    record_history(target, "merge", {"decision": decision, "source": args.source})
    write_case(args.root, target)

    out.step("merge", decision=decision, conflicts=len(conflicts))
    human = [
        f"merge {args.source!r} -> {args.target!r}: {decision}",
        f"  automatic         : {automatic}",
        f"  rationale         : {rationale}",
    ]
    for conflict in conflicts:
        human.append(f"  conflict          : {conflict}")
    for action in required_actions:
        human.append(f"  required (16.4)   : {action}")
    out.result(record, "\n".join(human))
    # Fail closed: a refused semantic merge did not happen, so it must not read
    # as success at the process boundary (6.6).
    return OK if automatic else VIOLATION


# ---------------------------------------------------------------------------
# crg migrate -- schema migration (spec 15)
# ---------------------------------------------------------------------------
def cmd_migrate(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    declared_class = args.migration_class.upper() if args.migration_class else None
    new_case_id = args.new_case or f"{args.case}@{args.to_version}"
    if os.path.exists(os.path.join(case_dir(args.root, new_case_id), "case.json")):
        raise CaseError(f"a case named {new_case_id!r} already exists")

    from_version = case.get("schema_version", "0.2.0")
    try:
        execution = DEFAULT_MIGRATION_REGISTRY.execute(
            case,
            args.to_version,
            transform_id=args.transform_id,
            declared_class=declared_class,
        )
    except MigrationError as error:
        raise CaseError(
            f"{error}. Install or select a pinned transform with independently checkable "
            "classification evidence first (15.3-15.6)."
        ) from None
    migration_class = execution.transform.migration_class
    source_hash = execution.source_object_hash
    # 15.3: migration creates a NEW object and MUST NOT rewrite history.
    migrated = dict(execution.transformed)
    migrated["case_id"] = new_case_id
    migrated["schema_version"] = args.to_version

    active = dict(migrated.get("certificates") or {})
    verified_noop = (
        migration_class == "SEMANTICALLY_EQUIVALENT"
        and execution.source_object_hash == execution.transformed_object_hash
    )
    effective_class = migration_class
    if verified_noop:
        # 15.5: a re-verification record MAY be produced without reissuing the
        # substantive decision.  Even a no-op remains pending until the
        # verifier records the judgment; it is never an active inherited cert.
        migrated["pending_reverification"] = {
            cert_id: {**dict(cert), "status": "RE_VERIFICATION_PENDING",
                      "original_schema_version": from_version}
            for cert_id, cert in active.items()
        }
        migrated["certificates"] = {}
        disposition = {cert_id: "RE_VERIFICATION_PENDING" for cert_id in active}
        migrated["status"] = "REOPENED" if active else case.get("status")
    else:
        # 15.5: a widening/narrowing/semantic/lossy/unverified migration MUST
        # trigger revalidation; a migrated object MUST NOT inherit a prior
        # certificate merely because its fields look similar.
        migrated["certificates"] = {}
        superseded = dict(migrated.get("superseded_certificates") or {})
        for cert_id, cert in active.items():
            superseded[cert_id] = {**dict(cert), "status": "SUPERSEDED_BY_MIGRATION",
                                   "migration_class": effective_class}
        migrated["superseded_certificates"] = superseded
        migrated["status"] = "REOPENED" if active else migrated.get("status")
        disposition = {cert_id: "INVALIDATED_REQUIRES_REVALIDATION" for cert_id in active}

    target_object_hash = content_hash(migrated)
    record = {
        "record_type": "MigrationRecord",
        "migration_id": f"migration-{new_case_id}",
        "source_case": args.case,
        "target_case": new_case_id,
        "source_schema_version": from_version,
        "target_schema_version": args.to_version,
        "source_object_hash": source_hash,
        "target_object_hash": target_object_hash,
        "declared_migration_class": declared_class or "",
        "migration_class": effective_class,
        "migration_profile": execution.transform.transform_id,
        **execution.evidence(),
        "declared_reason": args.reason,
        "certificate_disposition": disposition,
        "created_new_object": new_case_id,
        "migrated_at": utc_now(),
        "actor": args.actor,
        "actor_authentication": "LOCAL_PROCESS_UNATTESTED",
        "authority": args.authority,
    }
    migrated["migration_record"] = record
    migrated.setdefault("migrations", []).append(record)
    migrated.setdefault("history", []).append(
        {"command": "migrate", "from": args.case, "class": effective_class})
    write_case(args.root, migrated)

    out.step("migrate", to=new_case_id, migration_class=effective_class)
    payload = {
        "source_case": args.case,
        "new_case_id": new_case_id,
        "from_version": from_version,
        "to_version": args.to_version,
        "declared_migration_class": declared_class or "",
        "migration_class": effective_class,
        "transform_id": execution.transform.transform_id,
        "transform_hash": execution.transform.transform_hash,
        "classification_proof_hash": execution.transform.classification_proof_hash,
        "classification_verified": True,
        "certificate_disposition": disposition,
        "source_content_hash": source_hash,
    }
    human = [
        f"migrated {args.case!r} -> {new_case_id!r} (original untouched, 15.3)",
        f"  version           : {from_version} -> {args.to_version}",
        f"  declared class    : {declared_class or '(none; registry selected)'}",
        f"  effective class   : {effective_class}",
        f"  registered path   : {execution.transform.transform_id}",
        f"  classification    : VERIFIED ({execution.transform.classification_proof_hash})",
        f"  certificate handling:",
    ]
    for cert_id, state in sorted(disposition.items()):
        human.append(f"    {cert_id}: {state}")
    if not disposition:
        human.append("    (no certificates to migrate)")
    out.result(payload, "\n".join(human))
    return OK


# ---------------------------------------------------------------------------
# crg legal-hold -- persistent legal-hold policy (spec 17.5)
# ---------------------------------------------------------------------------
def cmd_legal_hold(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    held = set(str(value) for value in (case.get("legal_holds") or []))
    if args.action == "add":
        held.add(args.object)
        event = "LEGAL_HOLD_APPLIED"
    else:
        held.discard(args.object)
        event = "LEGAL_HOLD_RELEASED"
    case["legal_holds"] = sorted(held)
    record = {
        "record_type": "LegalHoldRecord",
        "case_id": args.case,
        "object_id": args.object,
        "action": event,
        "authority": args.authority,
        "recorded_at": utc_now(),
    }
    case.setdefault("legal_hold_history", []).append(record)
    record_history(case, "legal-hold", {"object": args.object, "action": event})
    write_case(args.root, case)
    out.step("legal-hold", object=args.object, action=event)
    out.result({**record, "active_holds": sorted(held)},
               f"{event.lower().replace('_', ' ')} for {args.object!r}")
    return OK


# ---------------------------------------------------------------------------
# crg redact -- redaction, tombstones, certificate effect (spec 17)
# ---------------------------------------------------------------------------
def cmd_redact(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    obj = args.object
    held = set(case.get("legal_holds") or [])
    if obj in held or args.legal_hold:
        # 17.5: an object under legal hold MUST NOT be deleted or erased.
        raise CaseError(
            f"{obj!r} is under legal hold and MUST NOT be redacted until the hold is released "
            "by authorized policy (spec 17.5)")

    registry = case.get("registry") or {}
    certificates = case.get("certificates") or {}
    affected_certificates: List[str] = []
    if obj in ("registry", registry.get("bundle_id")):
        content = case.get("registry")
        if not content:
            raise CaseError("there is no registry to redact")
        object_type = "RealizationBundle"
        content_digest = content_hash(content)
        case["registry"] = None
        # 17.3: every certificate rests on the registry; redacting it makes each
        # one UNVERIFIABLE_REDACTED.  The system MUST NOT report them as valid.
        affected_certificates = list(certificates)
    elif obj in certificates:
        content = certificates[obj]
        object_type = "DecisionCertificate"
        content_digest = content_hash(content)
        affected_certificates = [obj]
    else:
        raise CaseError(
            f"no redactable object {obj!r}; name 'registry' or a certificate id "
            f"(this case has: {sorted(certificates) or 'none'})")

    dependency_edges = []
    if object_type == "RealizationBundle":
        for cert_id in sorted(affected_certificates):
            certificate = certificates[cert_id]
            target_hash = str(certificate.get("certificate_hash") or content_hash(certificate))
            dependency_edges.append({
                "edge_id": f"{content_digest}->{target_hash}#DEPENDS_ON_ACCESS",
                "source": content_digest,
                "target": target_hash,
                "edge_type": "DEPENDS_ON_ACCESS",
                "minimum_action": "BLOCK",
                "transitive": True,
                "edge_version": "1",
                "scope": cert_id,
            })
    tombstone = {
        "record_type": "TombstoneRecord",
        "object_id": obj,
        "content_hash": content_digest,
        "object_type": object_type,
        "removal_reason": args.reason,
        "removal_authority": args.authority,
        "removal_time": utc_now(),
        "legal_hold": False,
        "permitted_disclosure": args.disclosure or "identity and hash only",
        "dependency_edges": dependency_edges,
        "affected_certificates": sorted(affected_certificates),
    }
    case.setdefault("tombstones", {})[obj] = tombstone

    redacted = case.setdefault("redacted_certificates", {})
    for cert_id in affected_certificates:
        cert = dict(certificates.get(cert_id, {}))
        cert["status"] = "UNVERIFIABLE_REDACTED"
        cert["redacted_by"] = obj
        redacted[cert_id] = cert
        case.get("certificates", {}).pop(cert_id, None)
    record_history(case, "redact", {"object": obj, "affected": affected_certificates})
    write_case(args.root, case)

    out.step("redact", object=obj, unverifiable=len(affected_certificates))
    payload = {
        "case_id": case["case_id"],
        "tombstone": tombstone,
        "unverifiable_redacted_certificates": affected_certificates,
    }
    human = [
        f"redacted {obj!r} ({object_type})",
        f"  content hash      : {content_digest}",
        f"  removal reason    : {args.reason}",
        f"  removal authority : {args.authority}",
        f"  certificates now UNVERIFIABLE_REDACTED (17.3): "
        f"{affected_certificates or 'none'}",
    ]
    out.result(payload, "\n".join(human))
    return OK


# ---------------------------------------------------------------------------
# argument parsing
# ---------------------------------------------------------------------------
def _add_global_options(parser: argparse.ArgumentParser, *, suppress: bool) -> None:
    """Attach the output-mode options of specification 40.

    They are accepted both before and after the subcommand, because a caller
    scripting the loop should not have to remember which side of the verb a
    flag lives on.  Subparser copies default to ``SUPPRESS`` so that a value
    given before the verb is not silently overwritten after it.
    """
    kwargs = {"default": argparse.SUPPRESS} if suppress else {}
    parser.add_argument("--dir", dest="root",
                        help="workspace root holding case directories",
                        **(kwargs if suppress else {"default": os.getcwd()}))
    parser.add_argument("--json", dest="as_json", action="store_true",
                        help="emit canonical JSON", **(kwargs if suppress else {"default": False}))
    parser.add_argument("--stream", action="store_true",
                        help="emit machine-streaming JSON Lines",
                        **(kwargs if suppress else {"default": False}))
    parser.add_argument("--quiet", action="store_true",
                        help="emit nothing; communicate through the exit code only",
                        **(kwargs if suppress else {"default": False}))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="crg",
        description="CRG Systems headless command line (spec 40)",
    )
    parser.add_argument("--version", action="version", version=f"crg {VERSION} (spec 0.2.0)")
    _add_global_options(parser, suppress=False)
    common = argparse.ArgumentParser(add_help=False)
    _add_global_options(common, suppress=True)
    subparsers = parser.add_subparsers(dest="command", parser_class=argparse.ArgumentParser)

    def add(name: str, **kwargs: Any) -> argparse.ArgumentParser:
        return subparsers.add_parser(name, parents=[common], **kwargs)

    p = add("init", help="create a case")
    p.add_argument("case")
    p.add_argument("--contract", help="computation contract document")
    p.set_defaults(handler=cmd_init)

    p = add("import", help="import a tabular realization registry")
    p.add_argument("case")
    p.add_argument("--source", required=True)
    p.add_argument("--mapping", help="JSON registry mapping")
    p.add_argument("--completeness", default=CompletenessBasisType.EXPLICIT_IMPORTED_FAMILY,
                   choices=sorted(CompletenessBasisType.ALL),
                   help="declared completeness basis type (spec 21.2)")
    p.add_argument("--universe", default="the explicitly imported candidates")
    p.set_defaults(handler=cmd_import)

    intake = add(
        "intake",
        help="preview and hash-confirm an explicit CSV or JSON registry mapping",
    )
    intake_sub = intake.add_subparsers(dest="intake_command")
    p = intake_sub.add_parser(
        "preview",
        parents=[common],
        help="produce a canonical non-mutating registry intake preview",
    )
    p.add_argument("--source", required=True, help="CSV or JSON source path")
    p.add_argument("--profile", required=True, help="canonical RegistryMappingProfile JSON")
    p.add_argument("--provenance", required=True, help="declared source provenance JSON")
    p.add_argument("--output", help="write the complete canonical preview response JSON")
    p.set_defaults(handler=cmd_intake_preview)
    p = intake_sub.add_parser(
        "confirm",
        parents=[common],
        help="re-preview and persist only the exact reviewed source and mapping",
    )
    p.add_argument("case")
    p.add_argument("--source", required=True, help="the same CSV or JSON source path")
    p.add_argument("--profile", required=True, help="the same canonical mapping profile JSON")
    p.add_argument("--provenance", required=True, help="the same source provenance JSON")
    p.add_argument(
        "--expected-preview-hash",
        required=True,
        help="preview_hash emitted by `crg intake preview`",
    )
    p.add_argument(
        "--accept-partial",
        action="store_true",
        help="explicitly acknowledge every rejected row disclosed by the reviewed preview",
    )
    p.add_argument("--output", help="write the canonical confirmation response JSON")
    p.set_defaults(handler=cmd_intake_confirm)
    intake.set_defaults(handler=_require_subcommand(intake))

    p = add("validate", help="structurally validate a case")
    p.add_argument("case")
    p.set_defaults(handler=cmd_validate)

    p = add("inspect", help="show case state, hashes, and claims")
    p.add_argument("case")
    p.set_defaults(handler=cmd_inspect)

    p = add("geometry", help="build canonical R, Gamma, and K")
    p.add_argument("case")
    p.add_argument("--objects", default="R,Gamma,K")
    p.set_defaults(handler=cmd_geometry)

    phase = add(
        "phase",
        help="preview, certify, inspect, and independently verify registered phase evidence",
    )
    phase_sub = phase.add_subparsers(dest="phase_command")

    def add_phase_build(name: str, help_text: str, handler) -> None:
        command = phase_sub.add_parser(name, parents=[common], help=help_text)
        command.add_argument("case")
        command.add_argument(
            "--profile",
            default=crg_geometry.PhaseProfile.TWO_COORDINATE_PRICE_SIMPLEX_V1,
            help="registered phase-analysis profile identifier",
        )
        command.add_argument(
            "--stability",
            help="exact rational parameter at which to certify local stability",
        )
        command.add_argument(
            "--tolerance",
            default="0",
            help="exact nonnegative policy tolerance (default: 0)",
        )
        command.add_argument("--output", help="write the canonical phase artifact JSON")
        command.add_argument(
            "--source-output", dest="source_output",
            help="write the portable source R needed for independent verification",
        )
        command.set_defaults(handler=handler)

    add_phase_build(
        "preview", "compute and verify phase evidence without changing case state",
        cmd_phase_preview,
    )
    add_phase_build(
        "analyze", "compute, independently verify, and persist phase evidence",
        cmd_phase_analyze,
    )
    p = phase_sub.add_parser(
        "inspect", parents=[common], help="inspect and independently reverify stored phase evidence"
    )
    p.add_argument("case")
    p.add_argument("--analysis")
    p.set_defaults(handler=cmd_phase_inspect)
    p = phase_sub.add_parser(
        "verify", parents=[common], help="independently verify a portable phase artifact"
    )
    p.add_argument("path")
    p.add_argument("--source-r", dest="source_r", required=True)
    p.set_defaults(handler=cmd_phase_verify)
    phase.set_defaults(handler=_require_subcommand(phase))

    query = add("query", help="decision-query operations")
    query_sub = query.add_subparsers(dest="query_command")
    p = query_sub.add_parser("compile", parents=[common], help="compile a decision scope to its minimum object")
    p.add_argument("case")
    p.add_argument("--scope", required=True)
    p.set_defaults(handler=cmd_query_compile)
    query.set_defaults(handler=_require_subcommand(query))

    commitment = add(
        "commitment",
        help="preview, compare, inspect, and independently verify safe-retention policies",
    )
    commitment_sub = commitment.add_subparsers(dest="commitment_command")

    def add_commitment_build(name: str, help_text: str, handler) -> None:
        command = commitment_sub.add_parser(name, parents=[common], help=help_text)
        command.add_argument("case")
        command.add_argument(
            "--family",
            help=("JSON future-decision-family authoring document; when omitted, use the "
                  "case's compiled decision scope"),
        )
        command.add_argument("--family-id", dest="family_id")
        command.add_argument(
            "--policies", required=True,
            help="JSON document containing the retention policies to compare",
        )
        command.add_argument("--artifact-id", dest="artifact_id")
        command.add_argument("--output", help="write the canonical artifact as JSON")
        command.set_defaults(handler=handler)

    add_commitment_build(
        "preview", "show retained/pruned and claim consequences without changing case state",
        cmd_commitment_preview,
    )
    add_commitment_build(
        "compare", "certify and persist a policy comparison after independent reconstruction",
        cmd_commitment_compare,
    )
    p = commitment_sub.add_parser(
        "inspect", parents=[common], help="inspect and independently reverify a stored comparison"
    )
    p.add_argument("case")
    p.add_argument("--artifact")
    p.set_defaults(handler=cmd_commitment_inspect)
    p = commitment_sub.add_parser(
        "verify", parents=[common], help="independently verify a portable safe-commitment JSON record"
    )
    p.add_argument("path")
    p.set_defaults(handler=cmd_commitment_verify)
    commitment.set_defaults(handler=_require_subcommand(commitment))

    comparison = add(
        "comparison",
        help="build and independently verify non-authorizing workflow evidence",
    )
    comparison_sub = comparison.add_subparsers(dest="comparison_command")
    for name, handler, help_text in (
        (
            "preview",
            cmd_comparison_preview,
            "build and verify an evaluation without changing case state",
        ),
        (
            "generate",
            cmd_comparison_generate,
            "verify and publish an evaluation into a successor case",
        ),
    ):
        p = comparison_sub.add_parser(name, parents=[common], help=help_text)
        p.add_argument("case")
        p.add_argument("--request", required=True, help="closed comparative request JSON")
        p.add_argument("--output", help="write the canonical portable evaluation JSON")
        p.add_argument("--report", help="write the claim-bounded text report")
        p.set_defaults(handler=handler)
    p = comparison_sub.add_parser(
        "inspect",
        parents=[common],
        help="inspect and independently reverify a stored evaluation",
    )
    p.add_argument("case")
    p.add_argument("--evaluation")
    p.add_argument("--output", help="write the canonical portable evaluation JSON")
    p.add_argument("--report", help="write the claim-bounded text report")
    p.set_defaults(handler=cmd_comparison_inspect)
    p = comparison_sub.add_parser(
        "verify",
        parents=[common],
        help="independently verify a portable ComparativeWorkflowEvaluation",
    )
    p.add_argument("path")
    p.set_defaults(handler=cmd_comparison_verify)
    for name, handler, help_text in (
        (
            "change-preview",
            cmd_comparison_change_preview,
            "derive v1.2 certified-change facts from a stored delta without changing case state",
        ),
        (
            "change-generate",
            cmd_comparison_change_generate,
            "independently replay and persist v1.2 certified-change evidence",
        ),
        (
            "journey-preview",
            cmd_comparison_journey_preview,
            "derive the fixed v1.1-v1.4 journey comparison without changing case state",
        ),
        (
            "journey-generate",
            cmd_comparison_journey_generate,
            "independently replay and persist the fixed ten-role journey comparison",
        ),
    ):
        p = comparison_sub.add_parser(name, parents=[common], help=help_text)
        p.add_argument("case")
        p.add_argument(
            "--request",
            required=True,
            help="closed JSON request naming only stored case artifact identities and declared scope",
        )
        p.add_argument("--output", help="write the canonical portable comparison JSON")
        p.add_argument("--report", help="write the claim-bounded text report")
        if name in {"change-preview", "change-generate"}:
            p.add_argument(
                "--enable-local-measurement",
                dest="enable_comparison_measurement",
                action="store_true",
                help=(
                    "explicitly allow identity-only reads from the separate local "
                    "measurement store for a v1.3 qualification extension"
                ),
            )
            p.add_argument(
                "--measurement-store",
                dest="comparison_measurement_store",
                help="dedicated local measurement-store directory (never a case directory)",
            )
            p.add_argument(
                "--measurement-subject-label",
                dest="comparison_measurement_subject",
                help="pseudonymous READ subject beginning psn-",
            )
        p.set_defaults(handler=handler)
    p = comparison_sub.add_parser(
        "change-inspect",
        parents=[common],
        help="inspect and independently reverify stored v1.2 comparative change evidence",
    )
    p.add_argument("case")
    p.add_argument("--comparison")
    p.add_argument("--output", help="write the canonical ComparativeChangeEvidence")
    p.add_argument("--report", help="write the claim-bounded text report")
    p.set_defaults(handler=cmd_comparison_change_inspect)
    p = comparison_sub.add_parser(
        "change-verify",
        parents=[common],
        help="independently verify portable ComparativeChangeEvidence",
    )
    p.add_argument("path")
    p.set_defaults(handler=cmd_comparison_change_verify)
    p = comparison_sub.add_parser(
        "journey-inspect",
        parents=[common],
        help="inspect and replay a stored CumulativeLifecycleComparison",
    )
    p.add_argument("case")
    p.add_argument("--journey")
    p.add_argument("--output", help="write the canonical CumulativeLifecycleComparison")
    p.add_argument("--report", help="write the claim-bounded text report")
    p.set_defaults(handler=cmd_comparison_journey_inspect)
    p = comparison_sub.add_parser(
        "journey-verify",
        parents=[common],
        help="independently verify a portable CumulativeLifecycleComparison",
    )
    p.add_argument("path")
    p.set_defaults(handler=cmd_comparison_journey_verify)
    comparison.set_defaults(handler=_require_subcommand(comparison))

    challenge = add(
        "challenge",
        help="preview, record, inspect, and independently verify a Decision Challenge",
    )
    challenge_sub = challenge.add_subparsers(dest="challenge_command")
    for name, handler, help_text in (
        (
            "preview",
            cmd_challenge_preview,
            "build and independently replay a challenge without changing case state",
        ),
        (
            "record",
            cmd_challenge_record,
            "append a non-authorizing record after independent replay",
        ),
    ):
        p = challenge_sub.add_parser(name, parents=[common], help=help_text)
        p.add_argument("case")
        p.add_argument(
            "--request", required=True,
            help=(
                "closed JSON request naming stored certified-delta evidence and "
                "registered challenge inputs"
            ),
        )
        p.add_argument("--output", help="write the canonical DecisionChallengeRecord")
        p.add_argument("--report", help="write the claim-bounded text report")
        p.set_defaults(handler=handler)
    p = challenge_sub.add_parser(
        "inspect", parents=[common],
        help="inspect and independently replay a stored Decision Challenge",
    )
    p.add_argument("case")
    p.add_argument("--challenge")
    p.add_argument("--output", help="write the canonical DecisionChallengeRecord")
    p.add_argument("--report", help="write the claim-bounded text report")
    p.set_defaults(handler=cmd_challenge_inspect)
    p = challenge_sub.add_parser(
        "verify", parents=[common],
        help="independently replay a portable DecisionChallengeRecord",
    )
    p.add_argument("path")
    p.set_defaults(handler=cmd_challenge_verify)
    challenge.set_defaults(handler=_require_subcommand(challenge))

    lifecycle = add(
        "lifecycle",
        help=(
            "publish and independently replay v1.3 ETQ plus v1.4 decision-lifecycle "
            "and portable resilience records"
        ),
    )
    lifecycle_sub = lifecycle.add_subparsers(dest="lifecycle_command")
    p = lifecycle_sub.add_parser(
        "publish",
        parents=[common],
        help="produce, independently replay, and append one dependency-ordered lifecycle record",
    )
    p.add_argument("case")
    p.add_argument(
        "--request", required=True,
        help=(
            "closed JSON request with operation and inputs; ETQ operations are "
            + ", ".join(ETQ_LIFECYCLE_OPERATIONS)
            + "; decision-lifecycle operations are "
            + ", ".join(
                operation for operation in DECISION_LIFECYCLE_OPERATIONS
                if operation not in RESILIENCE_LIFECYCLE_OPERATIONS
            )
            + "; portable resilience operations are "
            + ", ".join(RESILIENCE_LIFECYCLE_OPERATIONS)
        ),
    )
    p.add_argument("--output", help="write record plus exact replay inputs as portable JSON")
    p.add_argument("--report", help="write a direct-state, claim-bounded text report")
    p.set_defaults(handler=cmd_lifecycle_publish)
    p = lifecycle_sub.add_parser(
        "inspect", parents=[common],
        help="inspect and independently replay one stored lifecycle record",
    )
    p.add_argument("case")
    p.add_argument("--record-type", required=True)
    p.add_argument("--record-id", required=True)
    p.add_argument("--output", help="write record plus exact replay inputs as portable JSON")
    p.add_argument("--report", help="write a direct-state, claim-bounded text report")
    p.set_defaults(handler=cmd_lifecycle_inspect)
    p = lifecycle_sub.add_parser(
        "verify", parents=[common],
        help="independently replay a portable lifecycle record and its exact inputs",
    )
    p.add_argument("path")
    p.set_defaults(handler=cmd_lifecycle_verify)
    lifecycle.set_defaults(handler=_require_subcommand(lifecycle))

    measurement = add(
        "measurement",
        help=(
            "explicitly opt in to local-only operational measurement outside CRG case state"
        ),
    )
    measurement_sub = measurement.add_subparsers(dest="measurement_command")
    measurement_runtime = argparse.ArgumentParser(add_help=False)
    measurement_runtime.add_argument(
        "--enable-local-measurement",
        dest="measurement_enabled",
        action="store_true",
        required=True,
        help="explicit opt-in; capture is disabled when this flag is absent",
    )
    measurement_runtime.add_argument(
        "--measurement-store",
        required=True,
        help="dedicated local measurement-store directory (never a case directory)",
    )
    measurement_runtime.add_argument(
        "--subject-label",
        required=True,
        help="pseudonymous permission subject beginning psn-",
    )
    measurement_runtime.add_argument(
        "--grant",
        dest="measurement_grants",
        action="append",
        required=True,
        choices=["CAPTURE", "READ", "EXPORT", "DELETE", "RETENTION"],
        help="explicit measurement-domain grant; repeat when a command needs several",
    )

    p = measurement_sub.add_parser(
        "profile", parents=[common, measurement_runtime],
        help="inspect the enabled local profile, permission, and separate store domain",
    )
    p.set_defaults(handler=cmd_measurement_profile)
    p = measurement_sub.add_parser(
        "list", parents=[common, measurement_runtime],
        help="list privacy-bounded local session summaries (requires READ)",
    )
    p.set_defaults(handler=cmd_measurement_list)
    p = measurement_sub.add_parser(
        "start", parents=[common, measurement_runtime],
        help="start a pseudonymous local session (requires CAPTURE)",
    )
    p.add_argument("session_id", help="pseudonymous session identifier beginning psn-")
    p.add_argument(
        "--purpose-code", default="workflow-timing",
        choices=[
            "local-product-evaluation", "reference-path-evaluation",
            "reliability-evaluation", "workflow-timing",
        ],
    )
    p.add_argument(
        "--scope-code", default="single-session",
        choices=["declared-operation-set", "reference-journey", "single-session"],
    )
    p.set_defaults(handler=cmd_measurement_start)
    p = measurement_sub.add_parser(
        "show", parents=[common, measurement_runtime],
        help="read and verify one local session (requires READ)",
    )
    p.add_argument("session_id")
    p.set_defaults(handler=cmd_measurement_show)
    for name, help_text in (
        ("active-start", "begin user-active timing"),
        ("active-end", "end user-active timing"),
        ("compute-start", "begin local compute timing"),
        ("compute-end", "end local compute timing"),
        ("wait-start", "begin external/user wait timing"),
        ("wait-end", "end external/user wait timing"),
    ):
        p = measurement_sub.add_parser(
            name, parents=[common, measurement_runtime], help=help_text,
        )
        p.add_argument("session_id")
        p.set_defaults(handler=cmd_measurement_interval)
    p = measurement_sub.add_parser(
        "observe", parents=[common, measurement_runtime],
        help="record an exact local or system-derived observation",
    )
    p.add_argument("session_id")
    p.add_argument("--metric-code", required=True)
    p.add_argument("--numerator", required=True, type=int)
    p.add_argument("--denominator", default=1, type=int)
    p.add_argument("--unit-code", default="count")
    p.add_argument(
        "--measurement-class",
        default="LOCAL_OBSERVATION",
        choices=["LOCAL_OBSERVATION", "SYSTEM_DERIVED"],
    )
    p.set_defaults(handler=cmd_measurement_observe)
    p = measurement_sub.add_parser(
        "counterfactual", parents=[common, measurement_runtime],
        help=(
            "record a user-declared, unverified counterfactual without inferring "
            "ROI, savings, or superiority"
        ),
    )
    p.add_argument("session_id")
    p.add_argument("--metric-code", required=True)
    p.add_argument("--numerator", required=True, type=int)
    p.add_argument("--denominator", default=1, type=int)
    p.add_argument("--unit-code", default="count")
    p.add_argument("--basis-code", required=True)
    p.set_defaults(handler=cmd_measurement_counterfactual)
    p = measurement_sub.add_parser(
        "end", parents=[common, measurement_runtime],
        help="end a session after every active/compute/wait interval is closed",
    )
    p.add_argument("session_id")
    p.set_defaults(handler=cmd_measurement_end)
    p = measurement_sub.add_parser(
        "export", parents=[common, measurement_runtime],
        help="independently verify, then atomically write a portable local export",
    )
    p.add_argument("session_id")
    p.add_argument("--output", required=True)
    p.set_defaults(handler=cmd_measurement_export)
    p = measurement_sub.add_parser(
        "verify", parents=[common],
        help="independently verify a portable operational-measurement export",
    )
    p.add_argument("path")
    p.set_defaults(handler=cmd_measurement_verify)
    p = measurement_sub.add_parser(
        "retention-preview", parents=[common, measurement_runtime],
        help="preview a bounded local deletion plan without deleting anything",
    )
    p.add_argument("--maximum-age-seconds", required=True, type=int)
    p.add_argument("--as-of", help="explicit ISO-8601 cutoff time (default: local clock)")
    p.add_argument("--output", help="write the sealed preview for later confirmation")
    p.set_defaults(handler=cmd_measurement_retention_preview)
    p = measurement_sub.add_parser(
        "retention-enforce", parents=[common, measurement_runtime],
        help="enforce only an unchanged, hash-confirmed local retention preview",
    )
    p.add_argument("--preview", required=True, help="sealed retention-preview JSON")
    p.add_argument("--confirmation-hash", required=True)
    p.add_argument("--output", help="write the sealed deletion receipt")
    p.set_defaults(handler=cmd_measurement_retention_enforce)
    p = measurement_sub.add_parser(
        "delete", parents=[common, measurement_runtime],
        help="delete one local session only when its exact content hash matches",
    )
    p.add_argument("session_id")
    p.add_argument("--expected-content-hash", required=True)
    p.add_argument("--output", help="write the sealed deletion receipt")
    p.set_defaults(handler=cmd_measurement_delete)
    measurement.set_defaults(handler=_require_subcommand(measurement))

    pack = add(
        "pack",
        help="validate portable domain-pack declarations without executing extensions",
    )
    pack_sub = pack.add_subparsers(dest="pack_command")
    p = pack_sub.add_parser(
        "validate", parents=[common],
        help="validate one exact declaration-only domain-pack manifest",
    )
    p.add_argument("--manifest", required=True, help="portable pack manifest JSON")
    p.add_argument("--output", help="write the canonical CRGPackAuthoringReport")
    p.set_defaults(handler=cmd_pack_validate)
    p = pack_sub.add_parser(
        "assure-first-party", parents=[common],
        help="run obligation-effect assurance over all seven bundled reference packs",
    )
    p.add_argument("--output", help="write the canonical first-party assurance report")
    p.set_defaults(handler=cmd_pack_assure_first_party)
    pack.set_defaults(handler=_require_subcommand(pack))

    adapter = add(
        "adapter",
        help="independently verify portable source-adapter records from local bytes",
    )
    adapter_sub = adapter.add_subparsers(dest="adapter_command")
    p = adapter_sub.add_parser(
        "verify-definition", parents=[common],
        help="verify a SourceAdapterDefinition without contacting its origin",
    )
    p.add_argument("path")
    p.add_argument("--output", help="write the verification result")
    p.set_defaults(handler=cmd_adapter_verify_definition)
    p = adapter_sub.add_parser(
        "verify-output", parents=[common],
        help="verify a SourceAdapterOutput against exact original and normalized bytes",
    )
    p.add_argument("path", help="SourceAdapterOutput JSON")
    p.add_argument("--definition", required=True, help="SourceAdapterDefinition JSON")
    p.add_argument("--original-source", required=True, help="exact original source bytes")
    p.add_argument("--normalized-source", required=True, help="exact normalized source bytes")
    p.add_argument("--output", help="write the verification result")
    p.set_defaults(handler=cmd_adapter_verify_output)
    p = adapter_sub.add_parser(
        "verify-report", parents=[common],
        help="verify a portable SourceAdapterConformanceReport",
    )
    p.add_argument("path")
    p.add_argument("--output", help="write the verification result")
    p.set_defaults(handler=cmd_adapter_verify_report)
    adapter.set_defaults(handler=_require_subcommand(adapter))

    p = add("certify", help="issue a decision certificate")
    p.add_argument("case")
    p.add_argument("--retained", help="comma-separated retained realization identifiers")
    p.set_defaults(handler=cmd_certify)

    p = add("regret", help="construct a regret witness for a retention")
    p.add_argument("case")
    p.add_argument("--retained", required=True)
    p.set_defaults(handler=cmd_regret)

    p = add("change", help="apply a change and emit a delta certificate")
    p.add_argument("case")
    p.add_argument("--set", action="append", metavar="ID.COORD=VALUE")
    p.add_argument("--weight", action="append", metavar="COORD=VALUE")
    p.add_argument("--reason", required=True)
    p.add_argument("--event-id", dest="event_id")
    p.add_argument("--authority")
    p.add_argument("--approve", action="append")
    p.add_argument("--preview", action="store_true",
                   help="compute and verify the full change result without persisting it")
    p.add_argument("--evidence-output", dest="evidence_output",
                   help="write the canonical CertifiedDeltaRecord")
    p.add_argument("--verification-inputs-output", dest="verification_inputs_output",
                   help="write the portable inputs needed to independently verify the delta")
    p.set_defaults(handler=cmd_change)

    delta = add("delta", help="inspect and independently verify certified change evidence")
    delta_sub = delta.add_subparsers(dest="delta_command")
    p = delta_sub.add_parser(
        "inspect", parents=[common], help="inspect and reverify a stored CertifiedDeltaRecord"
    )
    p.add_argument("case")
    p.add_argument("--evidence")
    p.set_defaults(handler=cmd_delta_inspect)
    p = delta_sub.add_parser(
        "verify", parents=[common], help="independently verify a portable CertifiedDeltaRecord"
    )
    p.add_argument("path")
    p.add_argument("--inputs", required=True)
    p.set_defaults(handler=cmd_delta_verify)
    delta.set_defaults(handler=_require_subcommand(delta))

    p = add("export", help="write a portable .crg bundle")
    p.add_argument("case")
    p.add_argument("--output")
    p.add_argument("--level", default="V3", choices=["V0", "V1", "V2", "V3", "V4"])
    p.add_argument("--authority")
    p.set_defaults(handler=cmd_export)

    p = add("verify", help="independently verify a bundle, VIR, or certificate")
    p.add_argument("path")
    p.add_argument("--level", default="V3", choices=["V0", "V1", "V2", "V3", "V4"])
    p.add_argument("--clock", help="verifier evaluation time, ISO 8601 (spec 45.3)")
    p.add_argument("--clock-source", dest="clock_source", default="none-supplied")
    p.add_argument("--use-local-clock", dest="use_local_clock", action="store_true",
                   help="evaluate time against this machine's clock and disclose it")
    p.add_argument("--registry", help="registry JSON for a bare certificate")
    p.add_argument("--source-r", dest="source_r",
                   help="portable source R for a PhaseAnalysisRecord")
    p.add_argument("--verification-inputs", dest="verification_inputs",
                   help="portable inputs for a CertifiedDeltaRecord")
    p.add_argument(
        "--federation-context",
        help=("verifier-owned V4 trust context JSON; its nonce_ledger is atomically "
              "updated after acceptance"),
    )
    p.set_defaults(handler=cmd_verify)

    p = add("report", help="render independently checked certificate, phase, or delta evidence")
    p.add_argument("target", help="case identifier or .crg path")
    p.add_argument("--certificate")
    p.add_argument("--phase-analysis", dest="phase_analysis")
    p.add_argument("--certified-delta", dest="certified_delta")
    p.set_defaults(handler=cmd_report)

    design_space = add(
        "design-space",
        help="generate and independently verify deterministic pruned design spaces",
    )
    design_space_sub = design_space.add_subparsers(dest="design_space_command")
    p = design_space_sub.add_parser(
        "capabilities", parents=[common],
        help="print the hash-sealed agent design-space profile and safety caps",
    )
    p.set_defaults(handler=cmd_design_space_capabilities)
    p = design_space_sub.add_parser(
        "prune", parents=[common],
        help="map one compiler operator DAG to a certified reduced search space",
    )
    p.add_argument("--request", required=True, help="closed AgentDesignSpaceRequest JSON")
    p.add_argument("--output", help="write the canonical AgentDesignSpaceResult JSON")
    p.set_defaults(handler=cmd_design_space_prune)
    p = design_space_sub.add_parser(
        "batch", parents=[common],
        help="evaluate up to 16 design-space requests as one all-or-nothing batch",
    )
    p.add_argument("--request", required=True, help="JSON object containing a requests array")
    p.add_argument("--output", help="write the canonical AgentDesignSpaceBatchResult JSON")
    p.set_defaults(handler=cmd_design_space_batch)
    p = design_space_sub.add_parser(
        "verify", parents=[common],
        help="code-separately verify a portable AgentDesignSpaceResult",
    )
    p.add_argument("path", help="AgentDesignSpaceResult JSON")
    p.set_defaults(handler=cmd_design_space_verify)
    design_space.set_defaults(handler=_require_subcommand(design_space))

    p = add("generate", help="build a registry from a generator pack (spec 28, 36.5)")
    p.add_argument("case")
    p.add_argument("--spec", required=True, help="JSON generator/pack request")
    p.set_defaults(handler=cmd_generate)

    p = add("reopen", help="reopen certificates and emit a delta (spec 30.2)")
    p.add_argument("case")
    p.add_argument("--reason", required=True, help="why the case is being reopened")
    p.add_argument("--certificate", action="append",
                   help="a certificate to reopen (repeatable; default: all active)")
    p.add_argument("--event-id", dest="event_id")
    p.add_argument("--authority")
    p.add_argument("--approve", action="append")
    p.set_defaults(handler=cmd_reopen)

    p = add("convert", help="minimum-movement layout conversion (spec 31)")
    p.add_argument("case", nargs="?", help="optional case to record the conversion into")
    p.add_argument("--from", dest="source", required=True,
                   metavar="LAYOUT", help="source layout: a division count or a measures list")
    p.add_argument("--to", dest="target", required=True,
                   metavar="LAYOUT", help="target layout: a division count or a measures list")
    p.set_defaults(handler=cmd_convert)

    evidence = add("evidence", help="evidence-record operations (spec 33)")
    evidence_sub = evidence.add_subparsers(dest="evidence_command")
    p = evidence_sub.add_parser("add", parents=[common],
                                help="register an evidence record")
    p.add_argument("case")
    p.add_argument("--evidence", required=True, help="JSON evidence-record document")
    p.set_defaults(handler=cmd_evidence_add)
    evidence.set_defaults(handler=_require_subcommand(evidence))

    technology = add("technology", help="technology-contract operations (spec 33.6)")
    technology_sub = technology.add_subparsers(dest="technology_command")
    p = technology_sub.add_parser("assemble", parents=[common],
                                  help="assemble a technology contract from evidence")
    p.add_argument("case")
    p.add_argument("--rules", required=True, help="JSON applicability-rules document")
    p.add_argument("--target", required=True, help="JSON target-context document")
    p.add_argument("--evidence", action="append",
                   help="extra JSON evidence document(s) beyond those already added")
    p.add_argument("--coordinates", help="JSON coordinate-request document")
    p.add_argument("--clock", help="verifier evaluation time, ISO 8601 (spec 45.3)")
    p.add_argument("--requester", help="requesting subject id")
    p.add_argument("--contract-id", dest="contract_id", default="technology-contract")
    p.set_defaults(handler=cmd_technology_assemble)
    technology.set_defaults(handler=_require_subcommand(technology))

    p = add("qualify", help="build an inverse-qualification plan (spec 34)")
    p.add_argument("case")
    p.add_argument("--spec", required=True, help="JSON qualification request")
    p.set_defaults(handler=cmd_qualify)

    p = add("evaluate", help="submit an evaluator request / register a witness (spec 32)")
    p.add_argument("case")
    p.add_argument("--request", required=True, help="JSON evaluator-request document")
    p.add_argument("--response", required=True, help="JSON evaluator-response document")
    p.set_defaults(handler=cmd_evaluate)

    p = add("branch", help="branch a case (spec 16.2)")
    p.add_argument("case")
    p.add_argument("--name", required=True, help="branch name")
    p.add_argument("--purpose", help="why this divergence exists (spec 16.2)")
    p.add_argument("--creator", help="who created the branch (spec 16.2)")
    p.add_argument("--scope", help="intended decision scope")
    p.add_argument("--access-policy", dest="access_policy")
    p.add_argument("--reconciliation", default="MANUAL_RECONCILIATION",
                   help="expected reconciliation behaviour")
    p.set_defaults(handler=cmd_branch)

    p = add("merge", help="apply the section 16.3 merge policy")
    p.add_argument("source", help="source case identifier")
    p.add_argument("target", help="target case identifier")
    p.set_defaults(handler=cmd_merge)

    p = add("migrate", help="migrate a case to a new schema version (spec 15)")
    p.add_argument("case")
    p.add_argument("--to-version", dest="to_version", required=True)
    p.add_argument("--class", dest="migration_class",
                   help=("optional assertion; the registered transform owns the class (15.4): "
                         + ", ".join(MIGRATION_CLASSES)))
    p.add_argument("--transform", dest="transform_id",
                   help="registered transform identifier; inferred only for an unambiguous path")
    p.add_argument("--reason", help="declared reason for the migration")
    p.add_argument("--new-case", dest="new_case", help="identifier for the migrated case")
    p.add_argument("--actor", default="local-cli",
                   help="local process actor recorded for provenance (not authenticated)")
    p.add_argument("--authority", default="unattested",
                   help="named migration authority, kept distinct from the process actor")
    p.set_defaults(handler=cmd_migrate)

    p = add("redact", help="redact an object and tombstone it (spec 17)")
    p.add_argument("case")
    p.add_argument("--object", required=True,
                   help="'registry' or a certificate id to redact")
    p.add_argument("--reason", required=True)
    p.add_argument("--authority", required=True)
    p.add_argument("--legal-hold", dest="legal_hold", action="store_true",
                   help="assert the object is under legal hold (17.5: redaction is refused)")
    p.add_argument("--disclosure", help="permitted disclosure on the tombstone")
    p.set_defaults(handler=cmd_redact)

    p = add("legal-hold", help="apply or release a persistent legal hold (spec 17.5)")
    p.add_argument("case")
    p.add_argument("action", choices=["add", "release"])
    p.add_argument("--object", required=True)
    p.add_argument("--authority", required=True)
    p.set_defaults(handler=cmd_legal_hold)

    p = add("conformance", help="run the Minimum Credible Loop end to end")
    p.add_argument("--suite", default="mcl", choices=["mcl"])
    p.set_defaults(handler=cmd_conformance)

    return parser


def _require_subcommand(parser: argparse.ArgumentParser):
    def handler(_args: argparse.Namespace, out: Emitter) -> int:
        out.error(f"{parser.prog} requires a subcommand")
        return USAGE
    return handler


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(list(argv) if argv is not None else None)
    out = _emitter(args)
    if not getattr(args, "handler", None):
        parser.print_help(sys.stderr)
        return USAGE
    try:
        return args.handler(args, out)
    except (
        ComparativeVerificationError,
        DecisionChallengeVerificationError,
        LifecycleVerificationError,
        OperationalMeasurementCliError,
    ) as error:
        out.error(str(error))
        return VIOLATION
    except DesignSpaceError as error:
        code = "AGENT_DESIGN_SPACE_REFUSED"
        if out.mode == JSON:
            out.result({
                "error": {
                    "code": code,
                    "message": str(error),
                    "execution_authorized": False,
                    "partial_result_authorized": False,
                }
            })
        else:
            out.error(f"{code}: {error}")
        return VIOLATION
    except CaseError as error:
        out.error(str(error))
        return USAGE
    except FileNotFoundError as error:
        out.error(str(error))
        return USAGE
    except (crg_certify.QueryError, crg_certify.CertifyError, crg_certify.RegretError) as error:
        out.error(str(error))
        return VIOLATION
    except (ValueError, TypeError, KeyError) as error:
        out.error(f"{type(error).__name__}: {error}")
        return VIOLATION


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
