"""Document-to-object adapters for the operational-module CLI verbs.

Normative basis: 40 (CLI specification), and the operational modules the
verbs expose -- 28/36 (generation), 31 (conversion), 33 (evidence and
technology contracts), 34 (inverse qualification), 32 (physical feedback).

The verbs of section 40 delegate to already-built library functions; this
module is the thin, honest boundary that turns a JSON request document (or a
handful of flags) into the exact dataclasses those libraries require.  Two
disciplines are kept here and nowhere diluted:

* **No float ever enters an exact model.**  Every magnitude is read through
  :func:`_exact`, which refuses a genuine floating-point object rather than
  rounding it (spec 14.2).  A JSON number written bare (``2.25``) is a float
  and is refused; quote it (``"2.25"``) and it is read exactly.
* **A missing capability is reported, never faked.**  When a verb names a
  library or a generator pack that is not installed, :func:`_module` and the
  builders raise :class:`CapabilityUnavailable`, which the CLI turns into a
  clean nonzero exit with a message -- not a traceback, and never a fabricated
  success (spec 6.6).
"""
from __future__ import annotations

import importlib
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

from crg_model.numeric import Exact, Interval
from crg_model.records import Coordinate, CoordinateSchema, Direction, Signature

from .store import CaseError

__all__ = [
    "CapabilityUnavailable",
    "generate_registry",
    "evidence_record",
    "assemble_contract",
    "qualification_plan",
    "run_evaluation",
    "layout_conversion",
]


class CapabilityUnavailable(CaseError):
    """A verb was invoked whose backing capability is not installed or not built.

    A subclass of :class:`CaseError` so the CLI's top-level handler renders it
    as a clean usage-level failure (spec 6.6: a capability that is genuinely
    absent must say so, never pretend to have run).
    """


def _module(name: str, capability: str):
    try:
        return importlib.import_module(name)
    except ImportError as error:  # pragma: no cover - exercised only when uninstalled
        raise CapabilityUnavailable(
            f"{capability} is not available in this installation: cannot import {name!r} "
            f"({error}).  The capability is not built here; nothing was produced."
        ) from error


# ---------------------------------------------------------------------------
# exact-numeric helpers (spec 14.2)
# ---------------------------------------------------------------------------
def _exact(value: Any, *, where: str = "value") -> Exact:
    """Read ``value`` as an exact rational or refuse it (spec 14.2)."""
    if isinstance(value, bool):
        raise CaseError(f"{where} is the boolean {value!r}; a boolean is not a magnitude")
    if isinstance(value, Exact):
        return value
    if isinstance(value, str):
        try:
            return Exact(value)
        except (TypeError, ValueError, ZeroDivisionError) as error:
            raise CaseError(f"{where}: {value!r} is not an exact numeric literal ({error})")
    if isinstance(value, int):
        return Exact(value)
    if isinstance(value, float):
        raise CaseError(
            f"{where} is the JSON float {value!r}; a binary float has already lost the value's "
            "exact identity. Quote it ('2.25', '225e-2', or '9/4') so it is read exactly (14.2)"
        )
    raise CaseError(f"{where} is a {type(value).__name__}; expected a numeric string or integer")


def _interval(value: Any, *, where: str = "value"):
    """Build an :class:`Interval` from a scalar (a point) or a ``[lo, hi]`` pair."""
    if isinstance(value, (list, tuple)):
        if len(value) != 2:
            raise CaseError(f"{where}: an interval is written as [lo, hi]; got {value!r}")
        return Interval(_exact(value[0], where=where), _exact(value[1], where=where))
    point = _exact(value, where=where)
    return Interval(point, point)


def _require(doc: Mapping[str, Any], key: str, *, where: str) -> Any:
    if not isinstance(doc, Mapping) or key not in doc:
        raise CaseError(f"{where} requires a {key!r} field")
    return doc[key]


def _coordinate_schema(spec: Mapping[str, Any]) -> CoordinateSchema:
    coordinates = spec.get("coordinates")
    if not coordinates:
        raise CaseError("a schema must declare a non-empty 'coordinates' list")
    built: List[Coordinate] = []
    for entry in coordinates:
        identifier = str(entry["identifier"])
        built.append(Coordinate(
            identifier=identifier,
            quantity=str(entry.get("quantity", identifier)),
            unit=str(entry.get("unit", "1")),
            direction=str(entry.get("direction", Direction.MINIMIZE)),
            accounting_scope=entry.get("accounting_scope"),
        ))
    return CoordinateSchema(coordinates=tuple(built))


# ---------------------------------------------------------------------------
# crg generate -- build a registry from a generator pack (spec 28, 36.5)
# ---------------------------------------------------------------------------
#: Generator surfaces exposed by the CLI.  ``placement`` and
#: ``finite-transformation`` are the two historical request shapes.  The seven
#: names after them are the uniformly loadable reference packs of specification
#: 36.5.  Keeping the aliases preserves old scripts while making every shipped
#: deterministic pack reachable through the same product boundary.
GENERATOR_PACKS: Tuple[str, ...] = (
    "placement",
    "finite-transformation",
    "generic-finite-realization",
    "compiler-graph",
    "distributed-computation",
    "ai-system-realization",
    "advanced-packaging",
    "materials-process-evidence",
    "layout-conversion",
)


def generate_registry(spec: Mapping[str, Any]) -> Tuple[Any, Any]:
    """Drive a reference generator pack and return ``(bundle, GenerationReport)``.

    The derived completeness basis is whatever generation *earned* -- it is read
    off the bundle, never taken from the request (spec 21.3, 28.3 step 10).
    """
    gen = _module("crg_generate", "crg-generate (realization generation)")
    reference = _module("crg_generate.reference", "crg-generate reference packs")

    pack = str(spec.get("pack", "")).strip().lower()

    if pack == "placement":
        schema = _coordinate_schema(_require(spec, "schema", where="a generate request"))
        model = _require(spec, "model", where="a placement generate request")
        context = gen.GenerationContext(
            schema=schema,
            parameters={reference.PLACEMENT_MODEL_KEY: model},
            declared_universe=str(spec.get(
                "declared_universe", "every placement of the declared tasks onto declared nodes")),
        )
        seed_placement = _require(spec, "seed", where="a placement generate request")
        seed = reference.placement_seed(seed_placement, context)
        source = gen.GenerationSource(
            source_id=str(spec.get("source_id", "placement-source")),
            source_type="PLACEMENT",
            seeds=(seed,),
            computation_contract=dict(spec.get(
                "computation_contract", {"contract_id": "cc-placement", "version": "1"})),
            declared_universe=context.declared_universe,
            universe_key=str(spec.get("universe_key", "placement")),
            declared_universe_size=spec.get("declared_universe_size"),
        )
        generators = [reference.placement_generator()]
    elif pack in ("finite-transformation", "finite"):
        schema = _coordinate_schema(_require(spec, "schema", where="a generate request"))
        seed_spec = _require(spec, "seed", where="a finite-transformation generate request")
        signature = _require(seed_spec, "signature", where="a finite-transformation seed")
        context = gen.GenerationContext(
            schema=schema,
            parameters=dict(spec.get("parameters", {})),
            declared_universe=str(spec.get(
                "declared_universe", "the closure of the declared finite transformation rules")),
        )
        seed = gen.seed_record(
            source_id=str(spec.get("source_id", "finite-source")),
            signature=Signature([_exact(v, where="seed signature") for v in signature]),
            attributes=dict(seed_spec.get("attributes", {})),
            evidence_class=seed_spec.get("evidence_class", "CONSTRUCTIVE"),
        )
        source = gen.GenerationSource(
            source_id=str(spec.get("source_id", "finite-source")),
            source_type="EXPLICIT_RECORDS",
            seeds=(seed,),
            computation_contract=dict(spec.get(
                "computation_contract", {"contract_id": "cc-finite", "version": "1"})),
            resource_contract=dict(spec.get(
                "resource_contract", {"contract_id": "rc-finite", "version": "1"})),
        )
        generators = [reference.finite_transformation_generator(
            primary=str(_require(spec, "primary", where="a finite-transformation request")),
            secondary=str(_require(spec, "secondary", where="a finite-transformation request")),
            replica_limit=int(spec.get("replica_limit", 2)),
        )]
    elif pack in GENERATOR_PACKS:
        reference_packs = _module(
            "crg_generate.reference_packs", "crg-generate reference packs"
        )
        try:
            loaded = reference_packs.load_reference_pack(pack)
            loaded.require_valid()
        except gen.PackError as error:
            raise CaseError(f"reference-pack generation refused: {error}") from error

        # A worked example is useful for discovery and conformance, but it is
        # never silently substituted for an omitted design input.  Callers must
        # opt in explicitly.
        if bool(spec.get("worked_example", False)):
            try:
                return reference_packs.build_pack_registry(
                    loaded,
                    max_depth=spec.get("max_depth"),
                    max_size=spec.get("max_size"),
                )
            except gen.GenerationError as error:
                raise CaseError(f"reference-pack generation refused: {error}") from error

        # Compiler DAGs get an ergonomic, closed input shape because this is the
        # primary agent/chip-design boundary.  The exact DAG is placed in the
        # pack's declared context and the pack itself derives the seed, costs,
        # legality, obligations, and completeness basis.
        if pack == "compiler-graph" and "model" in spec and "seeds" not in spec:
            compiler_graph = _module(
                "crg_generate.reference_packs.compiler_graph",
                "the compiler-graph reference pack",
            )
            schema = (
                _coordinate_schema(spec["schema"])
                if spec.get("schema")
                else compiler_graph.SCHEMA
            )
            parameters = dict(spec.get("parameters") or {})
            parameters[compiler_graph.OPERATOR_DAG_KEY] = _require(
                spec, "model", where="a compiler-graph generate request"
            )
            context = gen.GenerationContext(
                schema=schema,
                capabilities=dict(spec.get("capabilities") or {}),
                parameters=parameters,
                permissions=tuple(loaded.manifest.permissions),
                declared_universe=str(
                    spec.get("declared_universe")
                    or "the closure of the declared compiler operator DAG"
                ),
            )
            seed = compiler_graph.compiler_graph_seed(
                context, source_id=str(spec.get("source_id") or "compiler-graph-source")
            )
            source = gen.GenerationSource(
                source_id=str(spec.get("source_id") or "compiler-graph-source"),
                # This is the exact source class accepted by the compiler pack's
                # manifest.  The outer agent-facing request calls the input a
                # compiler operator DAG; the generator contract names the source
                # type ``OPERATOR_DAG``.
                source_type="OPERATOR_DAG",
                seeds=(seed,),
                computation_contract=dict(
                    spec.get("computation_contract")
                    or {"contract_id": "cc-compiler-graph", "version": "1"}
                ),
                resource_contract=dict(spec.get("resource_contract") or {}),
                declared_universe=context.declared_universe,
                declared_universe_size=spec.get("declared_universe_size"),
                universe_key=spec.get("universe_key") or "compiler-operator-dag",
            )
            generators = list(loaded.generators)
        else:
            schema = _coordinate_schema(
                _require(spec, "schema", where="a reference-pack generate request")
            )
            context = gen.GenerationContext(
                schema=schema,
                capabilities=dict(spec.get("capabilities") or {}),
                parameters=dict(spec.get("parameters") or {}),
                permissions=tuple(loaded.manifest.permissions),
                declared_universe=str(
                    spec.get("declared_universe")
                    or "the closure of the declared reference-pack generators"
                ),
            )
            seed_specs = spec.get("seeds")
            if not isinstance(seed_specs, list) or not seed_specs:
                raise CaseError(
                    "a reference-pack generate request requires a non-empty 'seeds' list; "
                    "use worked_example=true only when the shipped conformance example is "
                    "the intended input"
                )
            seeds = tuple(
                gen.seed_record(
                    source_id=str(item.get("source_id") or spec.get("source_id") or "pack-source"),
                    signature=Signature(
                        [_exact(value, where="seed signature") for value in _require(
                            item, "signature", where="a reference-pack seed"
                        )]
                    ),
                    attributes=dict(item.get("attributes") or {}),
                    evidence_class=str(item.get("evidence_class") or "CONSTRUCTIVE"),
                )
                for item in seed_specs
            )
            source = gen.GenerationSource(
                source_id=str(spec.get("source_id") or "pack-source"),
                source_type=str(spec.get("source_type") or "EXPLICIT_RECORDS"),
                seeds=seeds,
                computation_contract=dict(
                    spec.get("computation_contract")
                    or {"contract_id": f"cc-{pack}", "version": "1"}
                ),
                resource_contract=dict(spec.get("resource_contract") or {}),
                declared_universe=context.declared_universe,
                declared_universe_size=spec.get("declared_universe_size"),
                universe_key=spec.get("universe_key") or pack,
            )
            generators = list(loaded.generators)
    else:
        raise CapabilityUnavailable(
            f"no generator pack named {pack or '(unset)'!r} is built here; the reference packs "
            "available are: " + ", ".join(GENERATOR_PACKS) + ". A registry for an unbuilt "
            "domain is not generated rather than faked (spec 6.6, 36.5)."
        )

    try:
        return gen.build_registry(
            source,
            generators=generators,
            schema=schema,
            context=context,
            max_depth=spec.get("max_depth"),
            max_size=spec.get("max_size"),
        )
    except gen.GenerationError as error:
        raise CaseError(f"generation refused: {error}")


# ---------------------------------------------------------------------------
# crg evidence add / crg technology assemble (spec 33)
# ---------------------------------------------------------------------------
def _context_descriptor(ev, doc: Mapping[str, Any]):
    return ev.ContextDescriptor(
        str(_require(doc, "context_id", where="a context")),
        str(_require(doc, "context_type", where="a context")),
        dict(doc.get("fields", {})),
    )


def _uncertainty_budget(ev, doc: Optional[Mapping[str, Any]]):
    if not doc:
        return ev.UncertaintyBudget()
    components = {}
    for name in ("measurement", "sampling", "calibration", "transfer", "model"):
        if name in doc:
            components[name] = _interval(doc[name], where=f"uncertainty.{name}")
    return ev.UncertaintyBudget(basis=str(doc.get("basis", "")), **components)


def _provenance(ev, canon, doc: Mapping[str, Any]):
    source_id = str(_require(doc, "source_id", where="provenance"))
    issuer = str(_require(doc, "issuer", where="provenance"))
    chain_in = doc.get("chain", ())
    chain = tuple(
        link if isinstance(link, str) and link.startswith("sha256:")
        else canon.content_hash({"link": link})
        for link in chain_in
    ) or (canon.content_hash({"link": source_id}),)
    return ev.Provenance.verified(
        source_id=source_id, issuer=issuer, chain=chain,
        issued_at=doc.get("issued_at"),
    )


def _validity_window(ev, doc: Optional[Mapping[str, Any]]):
    doc = doc or {}
    return ev.ValidityWindow(
        issued_at=doc.get("issued_at"),
        not_before=doc.get("not_before"),
        expires_at=doc.get("expires_at"),
        max_age_seconds=doc.get("max_age_seconds"),
        revalidation_triggers=tuple(doc.get("revalidation_triggers", ())),
    )


def _access_policy(ev, doc: Optional[Mapping[str, Any]]):
    if not doc:
        return ev.AccessPolicy.public()
    return ev.AccessPolicy(
        classification=str(doc.get("classification", "internal")),
        permitted_roles=tuple(doc.get("permitted_roles", ())),
        permitted_subjects=tuple(doc.get("permitted_subjects", ())),
        redaction_required=bool(doc.get("redaction_required", False)),
        export_permitted=bool(doc.get("export_permitted", True)),
    )


def evidence_record(doc: Mapping[str, Any]):
    """Build one :class:`EvidenceRecord` from a JSON document (spec 33.2)."""
    ev = _module("etq_evidence", "etq-evidence (evidence records)")
    canon = importlib.import_module("crg_model.canonical")
    method_doc = _require(doc, "method", where="an evidence record")
    try:
        return ev.EvidenceRecord(
            evidence_id=str(_require(doc, "evidence_id", where="an evidence record")),
            quantity=str(_require(doc, "quantity", where="an evidence record")),
            unit=str(_require(doc, "unit", where="an evidence record")),
            value=_interval(_require(doc, "value", where="an evidence record"), where="value"),
            uncertainty=_uncertainty_budget(ev, doc.get("uncertainty")),
            source_context=_context_descriptor(
                ev, _require(doc, "source_context", where="an evidence record")),
            method=ev.MethodDescriptor(
                method_id=str(_require(method_doc, "method_id", where="a method")),
                method_class=str(_require(method_doc, "method_class", where="a method")),
                evidence_class=str(method_doc.get("evidence_class", "MEASURED")),
                instrument=method_doc.get("instrument"),
                version=method_doc.get("version"),
            ),
            provenance=_provenance(ev, canon, _require(doc, "provenance", where="an evidence record")),
            validity=_validity_window(ev, doc.get("validity")),
            access=_access_policy(ev, doc.get("access")),
            evidence_status=str(doc.get("evidence_status", "QUALIFIED")),
        )
    except ev.EvidenceError as error:
        raise CaseError(f"invalid evidence record: {error}")


def _applicability_rule(ev, doc: Mapping[str, Any]):
    def quantity(entry, fallback_unit):
        return ev.QuantityType(
            str(entry["quantity_id"]), str(entry.get("unit", fallback_unit)),
            dimension=entry.get("dimension"),
        )

    def pattern(entry):
        return ev.ContextPattern(
            str(entry["context_type"]), dict(entry.get("required_fields", {})),
            str(entry.get("description", "")),
        )

    input_q = quantity(_require(doc, "input_quantity", where="a rule"), "1")
    output_q = (quantity(doc["output_quantity"], input_q.unit)
                if "output_quantity" in doc else input_q)
    transformation = ev.Transformation.identity()
    if "transformation" in doc:
        tdoc = doc["transformation"]
        transformation = ev.Transformation(
            kind=str(tdoc.get("kind", "AFFINE_DERATE")),
            scale=_exact(tdoc.get("scale", 1), where="transformation.scale"),
            offset=_exact(tdoc.get("offset", 0), where="transformation.offset"),
            basis=str(tdoc.get("basis", "")),
        )
    transfer = ev.TransferUncertaintyModel(
        model_id=str(doc.get("transfer_model_id", "tm-none")),
        kind=str(doc.get("transfer_kind", ev.TransferModelKind.NONE_DECLARED)),
        correlation_assumption=str(doc.get("correlation_assumption", ev.CorrelationAssumption.UNKNOWN)),
        basis=str(doc.get("transfer_basis", "no transfer cost declared")),
    )
    return ev.ApplicabilityRule(
        rule_id=str(_require(doc, "rule_id", where="a rule")),
        input_quantity=input_q,
        output_quantity=output_q,
        source_context_pattern=pattern(_require(doc, "source_context_pattern", where="a rule")),
        target_context_pattern=pattern(_require(doc, "target_context_pattern", where="a rule")),
        exact_match_fields=tuple(doc.get("exact_match_fields", ())),
        permitted_differences=(),
        hard_exclusions=(),
        transformation=transformation,
        transfer_uncertainty_model=transfer,
        minimum_evidence_status=str(doc.get("minimum_evidence_status", "QUALIFIED")),
        correlation_assumption=str(doc.get("correlation_assumption", ev.CorrelationAssumption.UNKNOWN)),
        validation_basis=str(doc.get("validation_basis", "declared by import")),
        authority=str(_require(doc, "authority", where="a rule")),
        expiration=doc.get("expiration"),
        revalidation_triggers=tuple(doc.get("revalidation_triggers", ())),
        coordinate_id=doc.get("coordinate_id"),
    )


def assemble_contract(
    evidence_docs: Sequence[Mapping[str, Any]],
    rules_docs: Sequence[Mapping[str, Any]],
    target_doc: Mapping[str, Any],
    *,
    clock_doc: Optional[Mapping[str, Any]] = None,
    requester_doc: Optional[Mapping[str, Any]] = None,
    coordinate_docs: Optional[Sequence[Mapping[str, Any]]] = None,
    contract_id: str = "technology-contract",
) -> Tuple[Any, Any]:
    """Assemble a technology contract from evidence and rules (spec 33.6)."""
    ev = _module("etq_evidence", "etq-evidence (technology contracts)")
    records = [
        r if not isinstance(r, Mapping) else evidence_record(r) for r in evidence_docs
    ]
    rules = [_applicability_rule(ev, r) for r in rules_docs]
    target = _context_descriptor(ev, target_doc)

    clock = None
    if clock_doc:
        clock = ev.VerificationClock.declared(
            str(_require(clock_doc, "evaluation_time", where="a clock")),
            str(clock_doc.get("source", "cli-declared-clock")),
            str(clock_doc.get("trust_level", ev.ClockTrust.LOCAL_DECLARED)),
        )
    requester = None
    if requester_doc:
        requester = ev.Requester(
            subject_id=str(_require(requester_doc, "subject_id", where="a requester")),
            roles=tuple(requester_doc.get("roles", ())),
            authority=requester_doc.get("authority"),
        )
    coordinates = None
    if coordinate_docs:
        coordinates = tuple(
            ev.CoordinateRequest(
                str(_require(c, "coordinate_id", where="a coordinate request")),
                str(c.get("quantity", c["coordinate_id"])),
                str(c.get("unit", "1")),
                required=bool(c.get("required", True)),
            )
            for c in coordinate_docs
        )
    return ev.assemble_technology_contract(
        records, rules, target,
        clock=clock, requester=requester, coordinates=coordinates, contract_id=contract_id,
    )


# ---------------------------------------------------------------------------
# crg qualify -- build a qualification plan (spec 34)
# ---------------------------------------------------------------------------
def qualification_plan(doc: Mapping[str, Any]) -> Tuple[Any, Any, List[Any]]:
    """Build a qualification plan and its experiment ranking (spec 34.3, 34.4).

    Returns ``(plan, objective, ranked_experiments)``.
    """
    q = _module("etq_qualify", "etq-qualify (inverse qualification)")
    ev = _module("etq_evidence", "etq-qualify's evidence types")

    obj_doc = _require(doc, "objective", where="a qualify request")
    metric = str(obj_doc.get("acceptable_ambiguity", {}).get(
        "metric", q.AmbiguityMetric.GUARANTEED_VERSUS_POSSIBLE_GAP))

    region_doc = _require(obj_doc, "region", where="a qualification objective")
    predicates = [
        q.DecisionPredicate(
            str(_require(p, "predicate_id", where="a decision predicate")),
            {str(k): _exact(v, where="predicate coefficient")
             for k, v in _require(p, "coefficients", where="a decision predicate").items()},
            threshold=_exact(p.get("threshold", 0), where="predicate threshold"),
            basis=str(p.get("basis", "")),
        )
        for p in _require(region_doc, "predicates", where="a phase region")
    ]
    region = q.PhaseRegion(
        str(region_doc.get("region_id", "region")), tuple(predicates),
        basis=str(region_doc.get("basis", "")),
    )
    aa_doc = _require(obj_doc, "acceptable_ambiguity", where="a qualification objective")
    acceptable = q.AcceptableAmbiguity(
        str(aa_doc.get("metric", metric)),
        _exact(aa_doc.get("threshold", 0), where="acceptable ambiguity threshold"),
        basis=str(aa_doc.get("basis", "")),
    )
    stopping = tuple(
        q.StoppingRule(
            condition=str(_require(s, "condition", where="a stopping rule")),
            threshold=(_exact(s["threshold"], where="stopping threshold")
                       if "threshold" in s else None),
            metric=s.get("metric"),
            basis=str(s.get("basis", "")),
        )
        for s in _require(obj_doc, "stopping_rules", where="a qualification objective")
    )
    weights_doc = obj_doc.get("burden_weights") or {"time": 1}
    weights = q.BurdenWeights(
        {str(k): _exact(v, where="burden weight") for k, v in weights_doc.items()},
        basis=str(obj_doc.get("burden_weights_basis", "declared by request")),
    )
    prior_bounds = tuple(
        (str(coord), _interval(bound, where=f"prior bound {coord}"))
        for coord, bound in (obj_doc.get("prior_bounds", {}) or {}).items()
    )
    try:
        objective = q.QualificationObjective(
            objective_id=str(_require(obj_doc, "objective_id", where="a qualification objective")),
            desired_state=str(_require(obj_doc, "desired_state", where="a qualification objective")),
            region=region,
            acceptable_ambiguity=acceptable,
            stopping_rules=stopping,
            authority=str(_require(obj_doc, "authority", where="a qualification objective")),
            burden_weights=weights,
            prior_bounds=prior_bounds,
            prior_bounds_basis=str(obj_doc.get("prior_bounds_basis", "")),
        )
    except q.QualificationError as error:
        raise CaseError(f"qualification objective refused: {error}")

    experiments = [_experiment(q, ev, metric, e) for e in doc.get("experiments", ())]
    try:
        ranked = q.rank_experiments(experiments, None, burden_weights=weights)
        plan = q.invert(objective, None, (), candidate_experiments=experiments, burden_weights=weights)
    except (q.QualificationError, q.ExperimentError, q.AmbiguityError, q.BurdenError) as error:
        raise CaseError(f"qualification refused: {error}")
    return plan, objective, ranked


def _experiment(q, ev, default_metric: str, doc: Mapping[str, Any]):
    method_doc = doc.get("method", {})
    result_doc = doc.get("result_model", {})
    effect_doc = _require(doc, "expected_information_effect", where="an experiment")
    try:
        return q.ExperimentDefinition(
            experiment_id=str(_require(doc, "experiment_id", where="an experiment")),
            measurand=str(_require(doc, "measurand", where="an experiment")),
            unit=str(doc.get("unit", "1")),
            method=ev.MethodDescriptor(
                method_id=str(method_doc.get("method_id", "M")),
                method_class=str(method_doc.get("method_class", "PHYSICAL_MEASUREMENT")),
                evidence_class=str(method_doc.get("evidence_class", "MEASURED")),
            ),
            result_model=q.ResultModel(
                kind=str(result_doc.get("kind", q.ResultModelKind.INTERVAL)),
                expected_width=(_exact(result_doc["expected_width"], where="expected_width")
                                if "expected_width" in result_doc else None),
            ),
            burden=q.BurdenVector(
                {str(k): _exact(v, where="burden") for k, v in doc.get("burden", {}).items()},
                basis=str(doc.get("burden_basis", "quoted by request")),
            ),
            context=_context_descriptor(ev, _require(doc, "context", where="an experiment")),
            expected_information_effect=q.InformationEffect(
                str(effect_doc.get("metric", default_metric)),
                _exact(_require(effect_doc, "before", where="an information effect"), where="before"),
                _exact(_require(effect_doc, "expected", where="an information effect"), where="expected"),
                _exact(_require(effect_doc, "worst", where="an information effect"), where="worst"),
            ),
            targets=tuple(doc.get("targets", ())),
            authority=str(doc.get("authority", "")),
        )
    except (q.ExperimentError, q.AmbiguityError, q.BurdenError) as error:
        raise CaseError(f"experiment refused: {error}")


# ---------------------------------------------------------------------------
# crg evaluate -- submit an evaluator request / register a witness (spec 32)
# ---------------------------------------------------------------------------
def _evaluator_request(fb, doc: Mapping[str, Any]):
    required = {
        "realization_id", "embedding_candidate", "technology_contract",
        "requested_evidence_level", "tool_config", "objective", "constraints",
        "requested_outputs", "timeout_ticks", "resource_policy", "confidentiality_policy",
    }
    missing = sorted(item for item in required if item not in doc)
    if missing:
        raise CaseError(
            "an evaluator request is missing required items (spec 32.1): " + ", ".join(missing)
        )
    try:
        return fb.EvaluatorRequest(
            realization_id=str(doc["realization_id"]),
            embedding_candidate=str(doc["embedding_candidate"]),
            technology_contract=str(doc["technology_contract"]),
            requested_evidence_level=str(doc["requested_evidence_level"]),
            tool_config=dict(doc["tool_config"]),
            objective=str(doc["objective"]),
            constraints=tuple(doc["constraints"]),
            requested_outputs=tuple(doc["requested_outputs"]),
            timeout_ticks=int(doc["timeout_ticks"]),
            resource_policy=dict(doc["resource_policy"]),
            confidentiality_policy=str(doc["confidentiality_policy"]),
            request_id=str(doc.get("request_id", "req-cli")),
        )
    except fb.ProtocolError as error:
        raise CaseError(f"invalid evaluator request: {error}")


def _evaluator_response(fb, request, doc: Mapping[str, Any]):
    """Build the response the evaluator returns, binding it to the request identity."""
    values = {str(k): _exact(v, where=f"result value {k}") for k, v in doc.get("values", {}).items()}
    return fb.EvaluatorResponse(
        kind=str(_require(doc, "kind", where="an evaluator response")),
        request_id=request.request_id,
        realization_id=request.realization_id,
        evaluator_identity=str(doc.get("evaluator_identity", "cli-evaluator")),
        evidence_class=doc.get("evidence_class"),
        values=values,
        violated_constraints=tuple(doc.get("violated_constraints", ())),
        covered_outputs=tuple(doc.get("covered_outputs", ())),
        method=str(doc.get("method", "")),
        detail=str(doc.get("detail", "")),
    )


def run_evaluation(request_doc: Mapping[str, Any], response_doc: Mapping[str, Any], bundle):
    """Submit a request and route the response through the 32.1 protocol.

    Returns ``(response, witness_or_None, feasibility_update_or_None, signoff)``.
    A transport fault (``response_doc`` with ``"raise": true``, or a response
    that will not build) is converted by :func:`submit` into ``TOOL_FAILURE`` --
    an absence of knowledge, never physical infeasibility (spec 32.1).
    """
    fb = _module("crg_feedback.protocol", "crg-feedback (physical evaluator protocol)")
    request = _evaluator_request(fb, request_doc)

    def evaluator(req):
        if response_doc.get("raise"):
            raise RuntimeError(str(response_doc.get("detail", "the evaluation tool failed")))
        return _evaluator_response(fb, req, response_doc)
    evaluator.identity = str(response_doc.get("evaluator_identity", "cli-evaluator"))

    response = fb.submit(request, evaluator)
    signoff = fb.signoff_status(response)

    witness = None
    update = None
    if response.kind in fb.ResponseKind.WITNESS_REGISTRABLE:
        try:
            witness = fb.register_witness(response, bundle)
        except fb.EvaluatorRefusal as error:  # pragma: no cover - defensive
            raise CaseError(f"witness registration refused: {error}")
    else:
        # Infeasibility, or a failure/refusal: record the feasibility effect
        # (which for a failure leaves the record UNEVALUATED and writes nothing).
        update = fb.apply_feasibility(response, bundle)
    return response, witness, update, signoff


# ---------------------------------------------------------------------------
# crg convert -- ownership and layout conversion (spec 31)
# ---------------------------------------------------------------------------
def _layout(conv, spec: Any, *, label: str):
    """Build a :class:`Layout` from an int, a measures list, or a spec object."""
    if isinstance(spec, int):
        return conv.Layout(spec, label=label)
    if isinstance(spec, str):
        text = spec.strip()
        if "," in text:
            measures = [m.strip() for m in text.split(",") if m.strip()]
            return conv.Layout(measures=[_exact(m, where="layout measure") for m in measures],
                               label=label)
        try:
            return conv.Layout(int(text), label=label)
        except ValueError:
            raise CaseError(
                f"a layout is an equal division count (e.g. 4) or a comma-separated measures "
                f"list (e.g. 1/2,1/4,1/4); {text!r} is neither")
    if isinstance(spec, (list, tuple)):
        return conv.Layout(measures=[_exact(m, where="layout measure") for m in spec], label=label)
    if isinstance(spec, Mapping):
        if "measures" in spec:
            return conv.Layout(
                measures=[_exact(m, where="layout measure") for m in spec["measures"]],
                label=str(spec.get("label", label)))
        if "divisions" in spec:
            return conv.Layout(spec["divisions"], label=str(spec.get("label", label)))
    raise CaseError(f"a layout is an integer division count, a measures list, or {{divisions|measures}}; got {spec!r}")


def layout_conversion(source_spec: Any, target_spec: Any) -> Any:
    """Compute a minimum-movement layout conversion record (spec 31.2)."""
    conv = _module("crg_convert", "crg-convert (ownership and layout conversion)")
    source = _layout(conv, source_spec, label="source")
    target = _layout(conv, target_spec, label="target")
    try:
        return conv.convert(source, target)
    except conv.ConversionError as error:
        raise CaseError(f"conversion refused: {error}")
