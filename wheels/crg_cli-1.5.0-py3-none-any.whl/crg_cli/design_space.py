"""One-call, non-mutating design-space analysis for a compiler operator DAG.

This module is deliberately an adapter, not a second solver.  It composes the
established compiler-graph reference pack, registry closure, exact R/Gamma/K
constructors, query compiler, and safe-commitment evaluator into one portable
result.  Every reduction and pruning certificate in the result is copied from
``crg-certify``; this module adds no alternative pruning semantics.

The only admitted input profile is the trusted, finite/exact first-party
``COMPILER_OPERATOR_DAG`` pack.  The call performs no case mutation and grants
no lifecycle, execution, external-evidence, or release authority.
"""
from __future__ import annotations

from copy import deepcopy
import re
from typing import Any, Dict, List, Mapping, Sequence, Tuple

import crg_geometry
from crg_certify import (
    FutureDecision,
    FutureDecisionFamily,
    RetentionPolicyDeclaration,
    compare_retention_policies,
    compile_query,
)
from crg_generate import (
    DEFAULT_DEPTH_LIMIT,
    DEFAULT_SIZE_LIMIT,
    GenerationContext,
    GenerationSource,
    build_registry,
)
from crg_generate.reference_packs.compiler_graph import (
    OPERATOR_DAG_KEY,
    PACK_IDENTITY,
    SCHEMA,
    compiler_graph_generator,
    compiler_graph_seed,
)
from crg_model.canonical import canonical_bytes, content_hash
from crg_model.numeric import Exact
from crg_model.records import RealizationBundle

__all__ = [
    "DESIGN_SPACE_PROFILE",
    "DESIGN_SPACE_SCHEMA_VERSION",
    "MAX_BATCH_ITEMS",
    "MAX_BATCH_ANALYSIS_WORK_UNITS",
    "MAX_BATCH_DECLARED_ANALYSIS_WORK_UNITS",
    "MAX_BATCH_REALIZATIONS",
    "MAX_BATCH_RESULT_BYTES",
    "MAX_DECISIONS",
    "MAX_DEPENDENCIES",
    "MAX_EXACT_TEXT_LENGTH",
    "MAX_GENERATION_DEPTH",
    "MAX_IDENTIFIER_LENGTH",
    "MAX_OPERATORS",
    "MAX_POLICIES",
    "MAX_REALIZATIONS",
    "MAX_REORDERINGS",
    "MAX_RESULT_BYTES",
    "MAX_ANALYSIS_WORK_UNITS",
    "DesignSpaceError",
    "agent_design_space_capabilities",
    "produce_agent_design_space",
    "produce_agent_design_space_batch",
]

DESIGN_SPACE_SCHEMA_VERSION = "1.5.0"
DESIGN_SPACE_PROFILE = "crg-agent-design-space/compiler-operator-dag@1"
REQUEST_RECORD_TYPE = "AgentDesignSpaceRequest"
RESULT_RECORD_TYPE = "AgentDesignSpaceResult"
INPUT_KIND = "COMPILER_OPERATOR_DAG"
REQUEST_SCHEMA_ID = (
    "https://crg.systems/schemas/1.5.0/agent-design-space-request.schema.json"
)
RESULT_SCHEMA_ID = (
    "https://crg.systems/schemas/1.5.0/agent-design-space-result.schema.json"
)
VERIFICATION_PROGRAM = "crg_verify.verify_agent_design_space"
VERIFICATION_SCOPE = "COMPILER_DAG_CLOSURE_GEOMETRY_AND_SAFE_COMMITMENT"
GENERATOR_REPLAY_PROFILE = "crg-verify/compiler-operator-dag-closure@1"

# Profile limits are semantic producer checks.  The local schema evaluator is
# intentionally small and does not implement every numeric JSON-Schema keyword.
MAX_OPERATORS = 64
MAX_DEPENDENCIES = 256
MAX_DECISIONS = 32
MAX_POLICIES = 16
MAX_IDENTIFIER_LENGTH = 128
MAX_EXACT_TEXT_LENGTH = 128
MAX_REORDERINGS = 16
MAX_REALIZATIONS = DEFAULT_SIZE_LIMIT
MAX_GENERATION_DEPTH = DEFAULT_DEPTH_LIMIT
MAX_RESULT_BYTES = 16 * 1024 * 1024
MAX_ANALYSIS_WORK_UNITS = 512
MAX_BATCH_ITEMS = 16
MAX_BATCH_REALIZATIONS = MAX_REALIZATIONS
MAX_BATCH_RESULT_BYTES = MAX_RESULT_BYTES
MAX_BATCH_ANALYSIS_WORK_UNITS = MAX_ANALYSIS_WORK_UNITS
MAX_BATCH_DECLARED_ANALYSIS_WORK_UNITS = 8192

_REQUEST_FIELDS = frozenset(
    {"record_type", "schema_version", "profile", "request_id", "input_kind",
     "operator_dag", "decisions", "policies", "limits"}
)
_REQUEST_REQUIRED = _REQUEST_FIELDS - {"limits"}
_OPERATOR_DAG_FIELDS = frozenset(
    {"operators", "declared_order", "max_reorderings", "fusion_saving_share",
     "memory_capacity_words"}
)
_OPERATOR_FIELDS = frozenset({"instructions", "output_words", "consumes"})
_DECISION_FIELDS = frozenset({"decision_id", "query"})
_QUERY_FIELDS = frozenset({"objective_family", "ties", "requested_object"})
_OBJECTIVE_FIELDS = frozenset({"type", "weights"})
_TIE_FIELDS = frozenset({"policy_tolerance", "retain_all"})
_POLICY_FIELDS = frozenset({"policy_id", "policy"})
_LIMIT_FIELDS = frozenset({"max_realizations", "max_depth"})
_POLICIES = frozenset({"retain-all", "universal-monotone", "additive-price-visible"})
_COORDINATES = frozenset(SCHEMA.identifiers)
_EXACT_TEXT_PATTERN = re.compile(
    r"^-?(?:[0-9]+(?:\.[0-9]+)?|[0-9]+/[0-9]*[1-9][0-9]*)$"
)


class DesignSpaceError(ValueError):
    """The closed design-space request is inadmissible or cannot be evaluated."""


def _mapping(value: Any, where: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise DesignSpaceError(f"{where} must be an object")
    return value


def _closed(value: Mapping[str, Any], allowed: frozenset[str], where: str) -> None:
    unknown = sorted(set(value) - allowed)
    if unknown:
        raise DesignSpaceError(f"{where} has unknown field(s): {unknown}")


def _nonempty_string(value: Any, where: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise DesignSpaceError(f"{where} must be a non-empty string")
    return value.strip()


def _exact_text(value: Any, where: str, *, nonnegative: bool = False) -> str:
    if not isinstance(value, str):
        raise DesignSpaceError(
            f"{where} must be an exact numeric string; JSON floats and implicit integers "
            "are not admitted by this canonical request profile"
        )
    if len(value) > MAX_EXACT_TEXT_LENGTH:
        raise DesignSpaceError(
            f"{where} exceeds the profile cap of {MAX_EXACT_TEXT_LENGTH} characters"
        )
    if _EXACT_TEXT_PATTERN.fullmatch(value) is None:
        raise DesignSpaceError(
            f"{where} must use the published exact-number spelling (integer, decimal, or "
            "nonzero-denominator rational; no whitespace, sign '+', exponent, or bare dot)"
        )
    try:
        exact = Exact(value)
    except (TypeError, ValueError, ZeroDivisionError) as error:
        raise DesignSpaceError(f"{where} is not an exact rational: {error}") from error
    if nonnegative and exact < Exact(0):
        raise DesignSpaceError(f"{where} must be nonnegative")
    return str(exact)


def _identifier(value: Any, where: str) -> str:
    if isinstance(value, str) and value != value.strip():
        raise DesignSpaceError(
            f"{where} must not contain leading or trailing whitespace"
        )
    identifier = _nonempty_string(value, where)
    if len(identifier) > MAX_IDENTIFIER_LENGTH:
        raise DesignSpaceError(
            f"{where} exceeds the profile cap of {MAX_IDENTIFIER_LENGTH} characters"
        )
    if "," in identifier or ">" in identifier:
        raise DesignSpaceError(
            f"{where} may not contain ',' or '>'; those delimit the established schedule trace"
        )
    return identifier


def _canonical_graph(raw: Any) -> dict:
    graph = _mapping(raw, "operator_dag")
    _closed(graph, _OPERATOR_DAG_FIELDS, "operator_dag")
    missing = sorted(_OPERATOR_DAG_FIELDS - set(graph))
    if missing:
        raise DesignSpaceError(f"operator_dag is missing required field(s): {missing}")

    operators = _mapping(graph["operators"], "operator_dag.operators")
    if not operators:
        raise DesignSpaceError("operator_dag.operators must not be empty")
    if len(operators) > MAX_OPERATORS:
        raise DesignSpaceError(
            f"operator_dag has {len(operators)} operators; the profile cap is {MAX_OPERATORS}"
        )
    if any(not isinstance(name, str) for name in operators):
        raise DesignSpaceError("operator_dag.operators keys must be strings")
    canonical_operators: Dict[str, dict] = {}
    dependency_count = 0
    for raw_name in sorted(operators):
        name = _identifier(raw_name, "operator identifier")
        body = _mapping(operators[raw_name], f"operator {name!r}")
        _closed(body, _OPERATOR_FIELDS, f"operator {name!r}")
        if set(body) != _OPERATOR_FIELDS:
            raise DesignSpaceError(
                f"operator {name!r} must declare exactly instructions, output_words, and consumes"
            )
        consumes = body["consumes"]
        if not isinstance(consumes, list):
            raise DesignSpaceError(f"operator {name!r}.consumes must be an array")
        dependency_count += len(consumes)
        if dependency_count > MAX_DEPENDENCIES:
            raise DesignSpaceError(
                f"operator_dag has more than {MAX_DEPENDENCIES} dependencies; the profile "
                f"cap is {MAX_DEPENDENCIES}"
            )
        dependencies = [_identifier(item, f"operator {name!r}.consumes[]") for item in consumes]
        if len(set(dependencies)) != len(dependencies):
            raise DesignSpaceError(f"operator {name!r}.consumes contains a duplicate dependency")
        canonical_operators[name] = {
            "instructions": _exact_text(
                body["instructions"], f"operator {name!r}.instructions", nonnegative=True
            ),
            "output_words": _exact_text(
                body["output_words"], f"operator {name!r}.output_words", nonnegative=True
            ),
            "consumes": sorted(dependencies),
        }

    order_raw = graph["declared_order"]
    if not isinstance(order_raw, list) or not order_raw:
        raise DesignSpaceError("operator_dag.declared_order must be a non-empty array")
    order = [_identifier(item, "operator_dag.declared_order[]") for item in order_raw]
    if len(set(order)) != len(order):
        raise DesignSpaceError("operator_dag.declared_order contains a duplicate operator")
    if set(order) != set(canonical_operators):
        raise DesignSpaceError("operator_dag.declared_order must name every operator exactly once")
    position = {name: index for index, name in enumerate(order)}
    for consumer, body in canonical_operators.items():
        for producer in body["consumes"]:
            if producer not in canonical_operators:
                raise DesignSpaceError(
                    f"operator {consumer!r} consumes undeclared operator {producer!r}"
                )
            if position[producer] >= position[consumer]:
                raise DesignSpaceError(
                    f"declared_order is not topological: producer {producer!r} must precede "
                    f"consumer {consumer!r}"
                )

    if len(canonical_operators) > 1:
        adjacent = {name: set() for name in canonical_operators}
        for consumer, body in canonical_operators.items():
            for producer in body["consumes"]:
                adjacent[consumer].add(producer)
                adjacent[producer].add(consumer)
        seen = {order[0]}
        frontier = [order[0]]
        while frontier:
            current = frontier.pop()
            for neighbor in sorted(adjacent[current] - seen):
                seen.add(neighbor)
                frontier.append(neighbor)
        if seen != set(canonical_operators):
            missing_names = sorted(set(canonical_operators) - seen)
            raise DesignSpaceError(
                "operator_dag must be weakly connected; disconnected operator(s): "
                f"{missing_names}"
            )
    reorderings = graph["max_reorderings"]
    if isinstance(reorderings, bool) or not isinstance(reorderings, int) or reorderings < 0:
        raise DesignSpaceError("operator_dag.max_reorderings must be a nonnegative integer")
    if reorderings > MAX_REORDERINGS:
        raise DesignSpaceError(
            f"operator_dag.max_reorderings exceeds the profile cap {MAX_REORDERINGS}"
        )
    share = _exact_text(graph["fusion_saving_share"], "fusion_saving_share", nonnegative=True)
    if Exact(share) > Exact(1):
        raise DesignSpaceError("fusion_saving_share must lie in the exact interval [0, 1]")
    capacity = _exact_text(
        graph["memory_capacity_words"], "memory_capacity_words", nonnegative=True
    )
    return {
        "operators": canonical_operators,
        "declared_order": order,
        "max_reorderings": reorderings,
        "fusion_saving_share": share,
        "memory_capacity_words": capacity,
    }


def _canonical_decisions(raw: Any) -> Tuple[dict, ...]:
    if not isinstance(raw, list) or not raw:
        raise DesignSpaceError("decisions must be a non-empty array")
    if len(raw) > MAX_DECISIONS:
        raise DesignSpaceError(
            f"decisions has {len(raw)} entries; the profile cap is {MAX_DECISIONS}"
        )
    decisions: List[dict] = []
    identifiers: set[str] = set()
    for index, item in enumerate(raw):
        decision = _mapping(item, f"decisions[{index}]")
        _closed(decision, _DECISION_FIELDS, f"decisions[{index}]")
        if set(decision) != _DECISION_FIELDS:
            raise DesignSpaceError(f"decisions[{index}] requires decision_id and query")
        identifier = _identifier(decision["decision_id"], f"decisions[{index}].decision_id")
        if identifier in identifiers:
            raise DesignSpaceError(f"duplicate decision_id {identifier!r}")
        identifiers.add(identifier)
        query = _mapping(decision["query"], f"decision {identifier!r}.query")
        _closed(query, _QUERY_FIELDS, f"decision {identifier!r}.query")
        if "objective_family" not in query:
            raise DesignSpaceError(f"decision {identifier!r}.query requires objective_family")
        objective = _mapping(
            query["objective_family"], f"decision {identifier!r}.objective_family"
        )
        _closed(objective, _OBJECTIVE_FIELDS, f"decision {identifier!r}.objective_family")
        kind = _nonempty_string(
            objective.get("type"), f"decision {identifier!r}.objective_family.type"
        )
        if kind not in {"max", "weighted_sum"}:
            raise DesignSpaceError(
                f"decision {identifier!r} objective type {kind!r} is outside this finite/exact profile"
            )
        normalized_objective: Dict[str, Any] = {"type": kind}
        weights = objective.get("weights")
        if kind == "weighted_sum":
            weights = _mapping(weights, f"decision {identifier!r}.objective_family.weights")
            if set(weights) != _COORDINATES:
                raise DesignSpaceError(
                    f"decision {identifier!r} weights must name exactly {sorted(_COORDINATES)}"
                )
            normalized_objective["weights"] = {
                key: _exact_text(weights[key], f"decision {identifier!r}.weights.{key}")
                for key in sorted(weights)
            }
        elif weights is not None:
            raise DesignSpaceError(f"decision {identifier!r}: max objective does not accept weights")
        normalized_query: Dict[str, Any] = {"objective_family": normalized_objective}
        if "ties" in query:
            ties = _mapping(query["ties"], f"decision {identifier!r}.ties")
            _closed(ties, _TIE_FIELDS, f"decision {identifier!r}.ties")
            normalized_ties: Dict[str, Any] = {}
            if "policy_tolerance" in ties:
                normalized_ties["policy_tolerance"] = _exact_text(
                    ties["policy_tolerance"], f"decision {identifier!r}.ties.policy_tolerance",
                    nonnegative=True,
                )
            if "retain_all" in ties:
                if not isinstance(ties["retain_all"], bool):
                    raise DesignSpaceError(
                        f"decision {identifier!r}.ties.retain_all must be boolean"
                    )
                normalized_ties["retain_all"] = ties["retain_all"]
            normalized_query["ties"] = normalized_ties
        if "requested_object" in query:
            requested = _nonempty_string(
                query["requested_object"], f"decision {identifier!r}.requested_object"
            )
            if requested not in {"GAMMA", "K"}:
                raise DesignSpaceError(
                    f"decision {identifier!r}.requested_object must be GAMMA or K"
                )
            normalized_query["requested_object"] = requested
        decisions.append({"decision_id": identifier, "query": normalized_query})
    return tuple(sorted(decisions, key=lambda item: item["decision_id"]))


def _canonical_policies(raw: Any) -> Tuple[dict, ...]:
    if not isinstance(raw, list) or not raw:
        raise DesignSpaceError("policies must be a non-empty array")
    if len(raw) > MAX_POLICIES:
        raise DesignSpaceError(
            f"policies has {len(raw)} entries; the profile cap is {MAX_POLICIES}"
        )
    policies: List[dict] = []
    identifiers: set[str] = set()
    for index, item in enumerate(raw):
        policy = _mapping(item, f"policies[{index}]")
        _closed(policy, _POLICY_FIELDS, f"policies[{index}]")
        if set(policy) != _POLICY_FIELDS:
            raise DesignSpaceError(f"policies[{index}] requires policy_id and policy")
        identifier = _identifier(policy["policy_id"], f"policies[{index}].policy_id")
        if identifier in identifiers:
            raise DesignSpaceError(f"duplicate policy_id {identifier!r}")
        identifiers.add(identifier)
        name = _nonempty_string(policy["policy"], f"policies[{index}].policy")
        if name not in _POLICIES:
            raise DesignSpaceError(
                f"policy {name!r} is not registered for this profile; choose {sorted(_POLICIES)}"
            )
        policies.append({"policy_id": identifier, "policy": name})
    return tuple(sorted(policies, key=lambda item: item["policy_id"]))


def _canonical_limits(raw: Any) -> dict:
    if raw is None:
        return {
            "max_realizations": DEFAULT_SIZE_LIMIT,
            "max_depth": DEFAULT_DEPTH_LIMIT,
        }
    limits = _mapping(raw, "limits")
    _closed(limits, _LIMIT_FIELDS, "limits")
    normalized = {
        "max_realizations": limits.get("max_realizations", DEFAULT_SIZE_LIMIT),
        "max_depth": limits.get("max_depth", DEFAULT_DEPTH_LIMIT),
    }
    caps = {
        "max_realizations": MAX_REALIZATIONS,
        "max_depth": MAX_GENERATION_DEPTH,
    }
    for name, value in normalized.items():
        if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
            raise DesignSpaceError(f"limits.{name} must be a positive integer")
        if value > caps[name]:
            raise DesignSpaceError(
                f"limits.{name}={value} exceeds the established safe cap {caps[name]}"
            )
    return normalized


def _canonical_request(raw: Mapping[str, Any]) -> dict:
    request = _mapping(raw, "design-space request")
    _closed(request, _REQUEST_FIELDS, "design-space request")
    missing = sorted(_REQUEST_REQUIRED - set(request))
    if missing:
        raise DesignSpaceError(f"design-space request is missing required field(s): {missing}")
    constants = {
        "record_type": REQUEST_RECORD_TYPE,
        "schema_version": DESIGN_SPACE_SCHEMA_VERSION,
        "profile": DESIGN_SPACE_PROFILE,
        "input_kind": INPUT_KIND,
    }
    for field, expected in constants.items():
        if request[field] != expected:
            raise DesignSpaceError(f"{field} must be {expected!r}")
    canonical = dict(constants)
    canonical["request_id"] = _identifier(request["request_id"], "request_id")
    canonical["operator_dag"] = _canonical_graph(request["operator_dag"])
    canonical["decisions"] = list(_canonical_decisions(request["decisions"]))
    canonical["policies"] = list(_canonical_policies(request["policies"]))
    canonical["limits"] = _canonical_limits(request.get("limits"))
    return canonical


def _profile_caps() -> dict:
    return {
        "max_operators": MAX_OPERATORS,
        "max_dependencies": MAX_DEPENDENCIES,
        "max_decisions": MAX_DECISIONS,
        "max_policies": MAX_POLICIES,
        "max_identifier_length": MAX_IDENTIFIER_LENGTH,
        "max_exact_text_length": MAX_EXACT_TEXT_LENGTH,
        "max_reorderings": MAX_REORDERINGS,
        "max_realizations": MAX_REALIZATIONS,
        "max_depth": MAX_GENERATION_DEPTH,
        "max_result_bytes": MAX_RESULT_BYTES,
        "max_analysis_work_units": MAX_ANALYSIS_WORK_UNITS,
    }


def _input_counts(request: Mapping[str, Any]) -> dict:
    graph = request["operator_dag"]
    identifiers = [request["request_id"], *graph["operators"], *graph["declared_order"]]
    exact_texts = [graph["fusion_saving_share"], graph["memory_capacity_words"]]
    for name, body in graph["operators"].items():
        identifiers.extend(body["consumes"])
        exact_texts.extend((body["instructions"], body["output_words"]))
    for decision in request["decisions"]:
        identifiers.append(decision["decision_id"])
        objective = decision["query"]["objective_family"]
        exact_texts.extend((objective.get("weights") or {}).values())
        ties = decision["query"].get("ties") or {}
        if "policy_tolerance" in ties:
            exact_texts.append(ties["policy_tolerance"])
    for policy in request["policies"]:
        identifiers.append(policy["policy_id"])
    return {
        "operators": len(graph["operators"]),
        "dependencies": sum(
            len(body["consumes"]) for body in graph["operators"].values()
        ),
        "decisions": len(request["decisions"]),
        "policies": len(request["policies"]),
        "max_reorderings": graph["max_reorderings"],
        "max_identifier_length_observed": max(map(len, identifiers)),
        "max_exact_text_length_observed": max(map(len, exact_texts)),
    }


def agent_design_space_capabilities() -> dict:
    """Return the canonical, hash-sealed discovery record for this closed profile."""
    record = {
        "record_type": "AgentDesignSpaceCapabilities",
        "schema_version": DESIGN_SPACE_SCHEMA_VERSION,
        "profile": DESIGN_SPACE_PROFILE,
        "input_kind": INPUT_KIND,
        "request_schema": {
            "record_type": REQUEST_RECORD_TYPE,
            "schema_id": REQUEST_SCHEMA_ID,
            "schema_version": DESIGN_SPACE_SCHEMA_VERSION,
        },
        "result_schema": {
            "record_type": RESULT_RECORD_TYPE,
            "schema_id": RESULT_SCHEMA_ID,
            "schema_version": DESIGN_SPACE_SCHEMA_VERSION,
        },
        "policies": sorted(_POLICIES),
        "objective_families": ["max", "weighted_sum"],
        "semantics": {
            "analysis_population": "LEGAL_REALIZATION_SUBFAMILY",
            "closed_request": True,
            "deterministic": True,
            "exact_numeric": True,
            "finite_bounded_generation": True,
            "non_mutating": True,
        },
        "limits": {
            "defaults": {
                "max_realizations": DEFAULT_SIZE_LIMIT,
                "max_depth": DEFAULT_DEPTH_LIMIT,
            },
            "profile_caps": _profile_caps(),
            "batch": {
                "max_items": MAX_BATCH_ITEMS,
                "max_declared_realizations": MAX_BATCH_REALIZATIONS,
                "max_result_bytes": MAX_BATCH_RESULT_BYTES,
                "max_analysis_work_units": MAX_BATCH_ANALYSIS_WORK_UNITS,
                "max_declared_analysis_work_units": (
                    MAX_BATCH_DECLARED_ANALYSIS_WORK_UNITS
                ),
            },
        },
        "verification": {
            "program": VERIFICATION_PROGRAM,
            "scope": VERIFICATION_SCOPE,
            "generator_replay_profile": GENERATOR_REPLAY_PROFILE,
            "code_separated_generator_reexecution_required": True,
        },
        "authority": {
            "execution_authorized": False,
            "lifecycle_transition_authorized": False,
            "release_authorized": False,
        },
    }
    record["capabilities_hash"] = content_hash(record)
    return record


def _geometry(bundle: Any) -> dict:
    r_record = crg_geometry.build_R(bundle)
    gamma = crg_geometry.build_gamma(r_record)
    k_record = crg_geometry.build_K(r_record)
    return {
        "R": {"root_hash": r_record.root_hash(), "record": r_record.to_canonical()},
        "GAMMA": {"root_hash": gamma.root_hash(), "record": gamma.to_canonical()},
        "K": {"root_hash": k_record.root_hash(), "record": k_record.to_canonical()},
    }


def _reductions(bundle: Any, report: Any, commitment: Mapping[str, Any]) -> List[dict]:
    by_id = {item.realization_id: item.to_canonical() for item in bundle.realizations}
    reductions: List[dict] = []
    for evaluation in commitment["evaluations"]:
        assessments = list(evaluation["pruning_assessments"])
        reductions.append(
            {
                "policy_id": evaluation["policy_id"],
                "policy": evaluation["policy"],
                "status": evaluation["status"],
                "claim_scope": report.claim_scope,
                "completeness": bundle.completeness.to_canonical(),
                "retained_ids": list(evaluation["retained_ids"]),
                "pruned_ids": list(evaluation["pruned_ids"]),
                "retained_realizations": [
                    by_id[identifier] for identifier in evaluation["retained_ids"]
                ],
                "decision_results": deepcopy(evaluation["decision_results"]),
                "pruning_assessments": deepcopy(assessments),
                "certificates": [
                    deepcopy(item["certificate"])
                    for item in assessments
                    if item.get("authorized") and item.get("certificate")
                ],
                "refusals": list(evaluation["refusals"]),
                "execution_authorized": False,
            }
        )
    return reductions


def _produce_agent_design_space_with_work_allowance(
    request: Mapping[str, Any],
    *,
    analysis_work_allowance: int,
) -> dict:
    """Produce one result without exceeding the caller's active work allowance."""
    if isinstance(analysis_work_allowance, bool) or not isinstance(
        analysis_work_allowance, int
    ):
        raise DesignSpaceError("analysis work allowance must be an integer")
    if analysis_work_allowance < 0 or analysis_work_allowance > MAX_ANALYSIS_WORK_UNITS:
        raise DesignSpaceError(
            f"analysis work allowance must be between 0 and {MAX_ANALYSIS_WORK_UNITS}"
        )
    canonical_request = _canonical_request(request)
    request_hash = content_hash(canonical_request)
    graph = canonical_request["operator_dag"]
    graph_hash = content_hash(graph)
    source_id = "agent-design-" + graph_hash.split(":", 1)[1][:24]

    generator = compiler_graph_generator()
    context = GenerationContext(
        schema=SCHEMA,
        parameters={OPERATOR_DAG_KEY: graph},
        permissions=tuple(generator.definition.required_permissions),
        declared_universe=(
            "the finite closure of the declared compiler schedule, fusion, inlining, "
            "and bounded reordering transformations"
        ),
    )
    seed = compiler_graph_seed(context, source_id=source_id)
    source = GenerationSource(
        source_id=source_id,
        source_type="OPERATOR_DAG",
        seeds=(seed,),
        computation_contract={
            "contract_id": "crg-agent-design-space/compiler-operator-dag",
            "version": "1",
            "graph_hash": graph_hash,
        },
        resource_contract={
            "contract_id": "crg-agent-design-space/flat-memory",
            "version": "1",
            "memory_capacity_words": graph["memory_capacity_words"],
        },
        declared_universe=context.declared_universe,
        metadata={
            "input_kind": INPUT_KIND,
            "pack_identity": PACK_IDENTITY,
            "request_hash": request_hash,
        },
    )
    analysis_multiplier = (
        len(canonical_request["decisions"]) * len(canonical_request["policies"])
    )
    analysis_realization_cap = analysis_work_allowance // analysis_multiplier
    if analysis_realization_cap == 0:
        raise DesignSpaceError(
            f"design-space analysis requires at least {analysis_multiplier} conservative "
            f"work units, but the active allowance is {analysis_work_allowance}"
        )
    generation_probe_max_realizations = min(
        canonical_request["limits"]["max_realizations"],
        analysis_realization_cap + 1,
    )
    try:
        bundle, report = build_registry(
            source,
            generators=(generator,),
            schema=SCHEMA,
            context=context,
            require_contracts=True,
            max_depth=canonical_request["limits"]["max_depth"],
            max_size=generation_probe_max_realizations,
        )
    except Exception as error:  # the adapter returns one stable boundary error
        raise DesignSpaceError(f"compiler-graph generation refused: {error}") from error
    if not any(item.legality == "LEGAL" for item in bundle.realizations):
        raise DesignSpaceError(
            "compiler-graph generation admitted no legal realization; a design-space result "
            "cannot represent an empty legal family"
        )
    analysis_work_units = (
        len(bundle.realizations)
        * analysis_multiplier
    )
    if analysis_work_units > analysis_work_allowance:
        raise DesignSpaceError(
            f"design-space analysis requires {analysis_work_units} conservative work units "
            f"(explored realizations x decisions x policies); the active allowance is "
            f"{analysis_work_allowance}"
        )
    legal_bundle = RealizationBundle(
        bundle_id=f"{bundle.bundle_id}::legal",
        schema=bundle.schema,
        realizations=[item for item in bundle.realizations if item.legality == "LEGAL"],
        completeness=bundle.completeness,
        rejected=list(bundle.rejected),
        source_fingerprint=bundle.source_fingerprint,
    )

    decisions: List[FutureDecision] = []
    for item in canonical_request["decisions"]:
        try:
            scope, derivation = compile_query({"id": item["decision_id"], **item["query"]})
        except Exception as error:
            raise DesignSpaceError(
                f"decision {item['decision_id']!r} could not be compiled: {error}"
            ) from error
        decisions.append(FutureDecision(item["decision_id"], scope, derivation))
    family = FutureDecisionFamily(
        family_id="agent-design-family-" + request_hash.split(":", 1)[1][:24],
        decisions=tuple(decisions),
        scenario_scope={"graph_hash": graph_hash, "request_hash": request_hash},
        authority="NON_AUTHORIZING_DESIGN_ANALYSIS_ONLY",
    )
    declarations = tuple(
        RetentionPolicyDeclaration(
            item["policy_id"], family.family_id, item["policy"]
        )
        for item in canonical_request["policies"]
    )
    try:
        commitment = compare_retention_policies(
            legal_bundle,
            family,
            declarations,
            geometry=crg_geometry,
            artifact_id="agent-design-commitment-" + request_hash.split(":", 1)[1][:24],
        ).to_canonical()
    except Exception as error:
        raise DesignSpaceError(f"safe-commitment analysis refused: {error}") from error

    refusals: List[dict] = []
    for item in sorted(bundle.realizations, key=lambda value: value.realization_id):
        if item.legality != "LEGAL":
            refusals.append(
                {
                    "source": f"generation:{item.realization_id}",
                    "detail": (
                        f"{item.legality}: retained in the replayed generator registry as "
                        "evidence but excluded from the legal decision-analysis subfamily"
                    ),
                }
            )
    for decision in commitment["family"]["decisions"]:
        for detail in (decision.get("derivation") or {}).get("refusals", []):
            refusals.append({"source": f"decision:{decision['decision_id']}", "detail": detail})
    for evaluation in commitment["evaluations"]:
        for detail in evaluation.get("refusals", []):
            refusals.append({"source": f"policy:{evaluation['policy_id']}", "detail": detail})

    result = {
        "record_type": RESULT_RECORD_TYPE,
        "schema_version": DESIGN_SPACE_SCHEMA_VERSION,
        "profile": DESIGN_SPACE_PROFILE,
        "request_id": canonical_request["request_id"],
        "request_hash": request_hash,
        "request": canonical_request,
        "graph": {
            "input_kind": INPUT_KIND,
            "model": graph,
            "graph_hash": graph_hash,
        },
        "generation_source": source.to_canonical(),
        "generation_context": context.to_canonical(),
        "generation_report": report.to_canonical(),
        "represented_family": {
            "bundle_hash": bundle.bundle_hash(),
            "bundle": bundle.to_canonical(),
        },
        "geometry": _geometry(bundle),
        "safe_commitment": commitment,
        "reduced_search_spaces": _reductions(bundle, report, commitment),
        "resource_boundary": {
            "profile_caps": _profile_caps(),
            "input_counts": _input_counts(canonical_request),
            "applied_limits": dict(canonical_request["limits"]),
            "explored_realizations": report.closure_report.size,
            "accepted_realizations": report.accepted_count,
            "rejected_candidates": report.rejected_count,
            "ungenerated_regions": len(report.ungenerated),
            "truncated": report.closure_report.truncated,
            "reached_fixpoint": report.closure_report.reached_fixpoint,
            "depth_reached": report.closure_report.depth_reached,
            "analysis_work_units": analysis_work_units,
            "generation_probe_max_realizations": generation_probe_max_realizations,
            "canonical_result_bytes": 0,
        },
        "refusals": refusals,
        "authority": {
            "execution_authorized": False,
            "lifecycle_transition_authorized": False,
            "release_authorized": False,
            "scope": "NON_MUTATING_DESIGN_ANALYSIS_ONLY",
        },
        "replay": {
            "profile": "crg-agent-design-space/trace-binding@1",
            "generator_replay_profile": GENERATOR_REPLAY_PROFILE,
            "source_fingerprint": source.fingerprint(),
            "context_fingerprint": context.fingerprint(),
            "generator_definition_hashes": dict(report.generator_definition_hashes),
            "canonical_output_hash": report.canonical_output_hash,
            "closure_trace_present": report.closure_report is not None,
            "generator_closure_reexecution_status": "REQUIRED",
            "requirement": (
                "the code-separated stdlib verifier must independently reexecute the pinned "
                "bounded compiler-DAG generator closure; the producer trace is not proof"
            ),
        },
        "verification_target": {
            "program": VERIFICATION_PROGRAM,
            "scope": VERIFICATION_SCOPE,
            "safe_commitment_hash": commitment["artifact_hash"],
            "generator_closure_reexecution": True,
        },
    }
    previous_size = -1
    while True:
        result.pop("result_hash", None)
        result["result_hash"] = content_hash(result)
        result_size = len(canonical_bytes(result))
        if result_size == previous_size:
            break
        result["resource_boundary"]["canonical_result_bytes"] = result_size
        previous_size = result_size
    if result_size > MAX_RESULT_BYTES:
        raise DesignSpaceError(
            f"canonical AgentDesignSpaceResult is {result_size} bytes; the profile cap is "
            f"{MAX_RESULT_BYTES} bytes"
        )
    return result


def produce_agent_design_space(request: Mapping[str, Any]) -> dict:
    """Produce one canonical finite/exact design-space result without mutation.

    Raises :class:`DesignSpaceError` for a malformed/unsupported request.  A
    registered retention policy that cannot preserve the compiled minimum
    sufficient object remains a first-class ``REFUSED`` evaluation inside the
    returned safe-commitment artifact and reduction projection.
    """
    return _produce_agent_design_space_with_work_allowance(
        request,
        analysis_work_allowance=MAX_ANALYSIS_WORK_UNITS,
    )


def produce_agent_design_space_batch(requests: Sequence[Mapping[str, Any]]) -> dict:
    """Produce a deterministic all-or-nothing bounded batch result.

    Every request is canonicalized before any producer call.  The sum of the
    caller-declared realization limits and the final canonical batch envelope
    are independently capped, preventing item-count amplification.
    """
    if isinstance(requests, (str, bytes)) or not isinstance(requests, Sequence):
        raise DesignSpaceError("batch requests must be an array")
    if not requests:
        raise DesignSpaceError("batch requests must not be empty")
    if len(requests) > MAX_BATCH_ITEMS:
        raise DesignSpaceError(
            f"batch has {len(requests)} items; the profile cap is {MAX_BATCH_ITEMS}"
        )
    canonical_requests = [_canonical_request(item) for item in requests]
    request_ids = [item["request_id"] for item in canonical_requests]
    if len(set(request_ids)) != len(request_ids):
        raise DesignSpaceError("batch request_id values must be unique")
    declared_realizations = sum(
        item["limits"]["max_realizations"] for item in canonical_requests
    )
    if declared_realizations > MAX_BATCH_REALIZATIONS:
        raise DesignSpaceError(
            f"batch declares {declared_realizations} possible realizations; the aggregate "
            f"profile cap is {MAX_BATCH_REALIZATIONS}"
        )

    declared_analysis_work_units = sum(
        item["limits"]["max_realizations"]
        * len(item["decisions"])
        * len(item["policies"])
        for item in canonical_requests
    )
    if declared_analysis_work_units > MAX_BATCH_DECLARED_ANALYSIS_WORK_UNITS:
        raise DesignSpaceError(
            f"batch declares {declared_analysis_work_units} conservative analysis work units; "
            f"the aggregate preflight cap is {MAX_BATCH_DECLARED_ANALYSIS_WORK_UNITS}"
        )

    results = []
    analysis_work_units = 0
    for item in canonical_requests:
        remaining_analysis_work_units = (
            MAX_BATCH_ANALYSIS_WORK_UNITS - analysis_work_units
        )
        produced = _produce_agent_design_space_with_work_allowance(
            item,
            analysis_work_allowance=remaining_analysis_work_units,
        )
        analysis_work_units += produced["resource_boundary"]["analysis_work_units"]
        results.append(produced)
    result = {
        "record_type": "AgentDesignSpaceBatchResult",
        "schema_version": DESIGN_SPACE_SCHEMA_VERSION,
        "profile": DESIGN_SPACE_PROFILE,
        "request_count": len(results),
        "request_ids": request_ids,
        "declared_realization_budget": declared_realizations,
        "declared_analysis_work_units": declared_analysis_work_units,
        "analysis_work_units": analysis_work_units,
        "explored_realizations": sum(
            item["resource_boundary"]["explored_realizations"] for item in results
        ),
        "results": results,
        "authority": {
            "execution_authorized": False,
            "lifecycle_transition_authorized": False,
            "release_authorized": False,
        },
        "resource_boundary": {
            "max_items": MAX_BATCH_ITEMS,
            "max_declared_realizations": MAX_BATCH_REALIZATIONS,
            "max_result_bytes": MAX_BATCH_RESULT_BYTES,
            "max_analysis_work_units": MAX_BATCH_ANALYSIS_WORK_UNITS,
            "max_declared_analysis_work_units": (
                MAX_BATCH_DECLARED_ANALYSIS_WORK_UNITS
            ),
            "canonical_result_bytes": 0,
        },
    }
    previous_size = -1
    while True:
        result.pop("batch_hash", None)
        result["batch_hash"] = content_hash(result)
        result_size = len(canonical_bytes(result))
        if result_size == previous_size:
            break
        result["resource_boundary"]["canonical_result_bytes"] = result_size
        previous_size = result_size
    if result_size > MAX_BATCH_RESULT_BYTES:
        raise DesignSpaceError(
            f"canonical AgentDesignSpaceBatchResult is {result_size} bytes; the aggregate "
            f"profile cap is {MAX_BATCH_RESULT_BYTES} bytes"
        )
    return result
