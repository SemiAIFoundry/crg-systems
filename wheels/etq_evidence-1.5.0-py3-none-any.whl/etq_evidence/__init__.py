"""etq-evidence: evidence applicability and technology contracts (OID-ETQ-001).

Reference implementation of master specification section 33, with section 45
(clock discipline), 5.3 (evidence classes), 13.1--13.4 (quantity and unit
discipline), 21 (completeness), and 44.2 (access) applied throughout.

This is the module where the ETQ family meets the CRG family.  Evidence
gathered in one context becomes bounded coordinates in another, and the
output of :func:`assemble_technology_contract` feeds straight into
``crg_certify.compile_query`` as a decision-scope ``technology_domain``.

Four refusals define the module.

**No applicable rule means UNSUPPORTED, not an assumed default (33.3).**
There is no fallback rule, no identity transfer, and no path from an empty
rule set to a coordinate.  An absent coordinate constrains nothing.

**Conflict is never silently averaged away (33.5).**  Evidence whose
enclosures are disjoint is ``CONTRADICTORY``: no fused value is produced,
the coordinate is blocked, and :func:`fuse` raises.  Where fusion *is*
admissible it is an intersection (supporting evidence) or a hull
(heterogeneous but compatible evidence) -- never a mean.

**The five uncertainty components stay five (33.4).**  They survive unit
conversion, derating, transfer, and assembly as five separately
attributable fields, and they are combined only by a call that states its
correlation assumption.  ``combine(correlation=...)`` is keyword-only with
no default, so an unstated assumption is a ``TypeError``.

**Expiry is judged against a supplied clock (45.3).**  The wall clock is
never read.  With no clock the status is ``TIME_INDETERMINATE`` -- warned
about, disclosed in the contract, and never reported as current.

Rejections carry the six distinct codes the ETQ disclosure requires -- unit
mismatch, absent applicability rule, hard context exclusion, expired
evidence, invalid provenance, unauthorized access -- because those six have
six different remedies and a generic failure would hide which applies.
"""
from .clock import (
    ClockTrust,
    TimeJudgment,
    TimeStatus,
    ValidityWindow,
    VerificationClock,
    evaluate_time,
    parse_time,
)
from .record import (
    AccessPolicy,
    ContextDescriptor,
    CorrelationAssumption,
    EvidenceError,
    EvidenceRecord,
    EvidenceStatus,
    MethodDescriptor,
    Provenance,
    ProvenanceStatus,
    Requester,
    UncertaintyBudget,
    UncertaintyCombination,
    freeze_fields,
)
from .applicability import (
    CHECK_ORDER,
    ApplicabilityResult,
    ApplicabilityRule,
    ApplicabilityStatus,
    ContextPattern,
    DifferenceKind,
    ExclusionKind,
    HardExclusion,
    PermittedDifference,
    QuantityType,
    ReasonCode,
    Transformation,
    TransformationKind,
    TransferModelKind,
    TransferUncertaintyModel,
    UnitConversion,
    apply_rule,
    select_rule,
)
from .conflict import (
    ConflictRefusal,
    EvidenceMember,
    EvidenceRelation,
    RelationKind,
    TransferredEvidence,
    classify_evidence_set,
    fuse,
)
from .contract import (
    CONTRACT_REQUIRED_ITEMS,
    AssemblyReport,
    BoundedCoordinate,
    CapabilityPredicate,
    ContractFunction,
    CoordinateRequest,
    CoverageReport,
    FunctionClass,
    Lineage,
    LineageEdge,
    Rejection,
    RejectionReason,
    TechnologyContract,
    VerificationStatus,
    assemble_technology_contract,
)

__version__ = "1.5.0"
SPEC_VERSION = "0.2.0"

__all__ = [
    # clock (45)
    "ClockTrust",
    "TimeJudgment",
    "TimeStatus",
    "ValidityWindow",
    "VerificationClock",
    "evaluate_time",
    "parse_time",
    # record (33.2, 33.4)
    "AccessPolicy",
    "ContextDescriptor",
    "CorrelationAssumption",
    "EvidenceError",
    "EvidenceRecord",
    "EvidenceStatus",
    "MethodDescriptor",
    "Provenance",
    "ProvenanceStatus",
    "Requester",
    "UncertaintyBudget",
    "UncertaintyCombination",
    "freeze_fields",
    # applicability (33.3)
    "CHECK_ORDER",
    "ApplicabilityResult",
    "ApplicabilityRule",
    "ApplicabilityStatus",
    "ContextPattern",
    "DifferenceKind",
    "ExclusionKind",
    "HardExclusion",
    "PermittedDifference",
    "QuantityType",
    "ReasonCode",
    "Transformation",
    "TransformationKind",
    "TransferModelKind",
    "TransferUncertaintyModel",
    "UnitConversion",
    "apply_rule",
    "select_rule",
    # conflict (33.5)
    "ConflictRefusal",
    "EvidenceMember",
    "EvidenceRelation",
    "RelationKind",
    "TransferredEvidence",
    "classify_evidence_set",
    "fuse",
    # contract (33.6)
    "CONTRACT_REQUIRED_ITEMS",
    "AssemblyReport",
    "BoundedCoordinate",
    "CapabilityPredicate",
    "ContractFunction",
    "CoordinateRequest",
    "CoverageReport",
    "FunctionClass",
    "Lineage",
    "LineageEdge",
    "Rejection",
    "RejectionReason",
    "TechnologyContract",
    "VerificationStatus",
    "assemble_technology_contract",
]
