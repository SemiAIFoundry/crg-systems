/**
 * The shared rendering vocabulary of CRG Studio (spec 41.2).
 *
 * Every workspace builds its markup from the primitives here, which is how
 * the UX principles of 41.2 become properties of the product rather than
 * habits of whoever wrote a given view.  A workspace cannot print a claim
 * without its scope, because `decisionHeadline` emits them together.  It
 * cannot print a possible-winner set as a winner, because the phrasing is
 * chosen from the outcome and never from the length of the selected list.
 * It cannot print an absent coordinate as zero, because `quantity` has no
 * code path that turns absence into a number.
 *
 * Nothing in this file touches the DOM or the network.  Every export is a
 * pure function from data to a markup string, which is what lets the test
 * suite check the invariants headlessly under Node with fixture JSON and no
 * browser.
 */

/* ------------------------------------------------------------------ */
/* escaping and small building blocks                                  */
/* ------------------------------------------------------------------ */

const ENTITIES = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };

/** Escape text for an element body or a double-quoted attribute. */
export function esc(value) {
  if (value === null || value === undefined) return '';
  return String(value).replace(/[&<>"']/g, (character) => ENTITIES[character]);
}

/** Join a list of markup fragments, dropping empties. */
export function join(parts, separator = '\n') {
  return parts.filter((part) => part !== null && part !== undefined && part !== '')
    .join(separator);
}

/** A stable, human-readable identifier fragment for `id=` and `aria-controls`. */
export function slug(value) {
  return String(value === undefined || value === null ? '' : value)
    .toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'x';
}

/* ------------------------------------------------------------------ */
/* 41.2: never present an unsupported coordinate as zero               */
/* ------------------------------------------------------------------ */

/**
 * The absent marker.  An em dash, never a numeral.
 *
 * 41.2 forbids presenting unsupported coordinates as zero, and 6.11 forbids
 * silent truncation; together they mean that "we have no value here" and
 * "the value here is nought" must not share a rendering.  A dimensioned
 * quantity with no supported value is a different fact from a quantity whose
 * value is zero -- an unmeasured emission is not a zero emission -- and a
 * reader who cannot tell them apart is being misled by the interface rather
 * than by the data.
 */
export const ABSENT_MARK = '—';

const ABSENT_REASONS = {
  UNSUPPORTED: 'No supported value: this coordinate has no evidence in the case.',
  NOT_APPLICABLE: 'Not applicable: this coordinate is out of scope for this record.',
  REDACTED: 'Redacted: the supporting content was removed and a tombstone remains (17.2).',
  UNENUMERATED: 'Not enumerated: this region of the family was never generated (28.4).',
  PENDING: 'Not yet computed: no job has produced this value.',
};

/**
 * Render an absent value.  Never returns a numeral, in any branch.
 */
export function absent(reason = 'UNSUPPORTED') {
  const text = ABSENT_REASONS[reason] || ABSENT_REASONS.UNSUPPORTED;
  return `<span class="crg-absent" data-absent-reason="${esc(reason)}" `
    + `role="img" aria-label="absent: ${esc(text)}" title="${esc(text)}">`
    + `${ABSENT_MARK}</span>`;
}

function isAbsent(value) {
  return value === null || value === undefined || value === ''
    || (typeof value === 'number' && Number.isNaN(value))
    || (typeof value === 'object' && value !== null && value.absent === true);
}

/**
 * Render a typed quantity: exact value, interval, unit, evidence class.
 *
 * The three intervals of 22.2 are kept apart.  A combined conservative
 * interval is the one a comparison may use; a numerical enclosure and an
 * evidence interval are different claims about different sources of doubt,
 * and 22.1 requires them recorded separately, so Studio labels them
 * separately too.
 */
export function quantity(value, options = {}) {
  const { unit = '', evidenceClass = null, reason = 'UNSUPPORTED', label = '' } = options;
  if (isAbsent(value)) {
    const marker = absent((value && value.reason) || reason);
    return label ? `<span class="crg-quantity">${esc(label)} ${marker}</span>` : marker;
  }
  const parts = [];
  const wrapped = typeof value === 'object'
    && (value.exact !== undefined || value.interval !== undefined);
  if (wrapped) {
    if (!isAbsent(value.exact)) {
      parts.push(`<span class="crg-quantity__exact">${esc(exactText(value.exact))}</span>`);
    }
    if (value.interval) {
      parts.push(interval(value.interval, { kind: value.interval_kind || 'combined' }));
    }
  } else {
    // A bare exact: a number, a decimal string, or the `{numerator, denominator}`
    // form of 14.2.  `exactText` knows all three; there is no path here that
    // turns an unreadable value into a plausible one.
    parts.push(`<span class="crg-quantity__exact">${esc(exactText(value))}</span>`);
  }
  if (unit) {
    parts.push(`<span class="crg-quantity__unit" data-unit="${esc(unit)}">${esc(unit)}</span>`);
  }
  if (evidenceClass) parts.push(evidenceBadge(evidenceClass));
  const body = join(parts, ' ');
  return `<span class="crg-quantity">${label ? `${esc(label)} ` : ''}${body}</span>`;
}

/** Exact rationals arrive as `{numerator, denominator}` or as a string (14.2). */
export function exactText(value) {
  if (isAbsent(value)) return ABSENT_MARK;
  if (typeof value === 'object') {
    if (value.numerator !== undefined && value.denominator !== undefined) {
      return String(value.denominator) === '1'
        ? String(value.numerator)
        : `${value.numerator}/${value.denominator}`;
    }
    if (value.value !== undefined) return String(value.value);
    return JSON.stringify(value);
  }
  return String(value);
}

const INTERVAL_KINDS = {
  numerical: ['Arithmetic enclosure', 'Uncertainty introduced by arithmetic or the solver (22.1).'],
  evidence: ['Evidence uncertainty', 'Measurement, sampling, calibration, or model uncertainty (22.1).'],
  combined: ['Conservative range', 'Arithmetic and evidence uncertainty taken together (22.2).'],
  bound: ['Certified bound', 'A declared inner or outer bound (20.1).'],
};

/** Render an interval with its kind named in plain language. */
export function interval(bounds, options = {}) {
  const kind = options.kind || 'combined';
  const [name, description] = INTERVAL_KINDS[kind] || INTERVAL_KINDS.combined;
  if (isAbsent(bounds)) return absent('PENDING');
  const lower = Array.isArray(bounds) ? bounds[0] : bounds.lower;
  const upper = Array.isArray(bounds) ? bounds[1] : bounds.upper;
  if (isAbsent(lower) && isAbsent(upper)) return absent('PENDING');
  return `<span class="crg-interval" data-interval-kind="${esc(kind)}" `
    + `title="${esc(description)}">`
    + `<span class="crg-interval__name">${esc(name)}</span> `
    + `<span class="crg-interval__range">`
    + `${isAbsent(lower) ? absent() : esc(exactText(lower))}`
    + `<span aria-hidden="true"> to </span>`
    + `<span class="crg-visually-hidden"> to </span>`
    + `${isAbsent(upper) ? absent() : esc(exactText(upper))}`
    + `</span></span>`;
}

/* ------------------------------------------------------------------ */
/* 5.3 / 41.2: the eight evidence classes, distinguishable without colour */
/* ------------------------------------------------------------------ */

/**
 * Specification 5.3's eight classes.  Each carries its own text label, its
 * own glyph, and its own border treatment; colour is the fourth signal, not
 * the first, because 47.7 points at WCAG 2.2 AA and 1.4.1 forbids colour as
 * the only carrier of meaning.  The classes are not a severity scale and are
 * not rendered as one: `Measured` is not "better" than `Bounded`, it is a
 * different kind of claim with a different failure mode.
 */
export const EVIDENCE_CLASSES = {
  EXACT: {
    label: 'Exact', glyph: '■', pattern: 'solid',
    description: 'Derived exactly under the stated semantics (5.3).',
    authorizes: true,
  },
  CONSTRUCTIVE: {
    label: 'Constructive', glyph: '◆', pattern: 'diamond',
    description: 'Supported by a valid realizable witness (5.3).',
    authorizes: true,
  },
  BOUNDED: {
    label: 'Bounded', glyph: '◧', pattern: 'half',
    description: 'Supported by a declared inner or outer bound (5.3, 20.1).',
    authorizes: true,
  },
  MEASURED: {
    label: 'Measured', glyph: '◎', pattern: 'ring',
    description: 'Produced by an identified physical measurement (5.3).',
    authorizes: true,
  },
  MODELED: {
    label: 'Modeled', glyph: '▲', pattern: 'hatch',
    description: 'Produced by an identified analytical, statistical, or simulation model (5.3).',
    authorizes: true,
  },
  IMPORTED: {
    label: 'Imported', glyph: '▼', pattern: 'dotted',
    description: 'Received from an identified external source (5.3).',
    authorizes: true,
  },
  DECLARED: {
    label: 'Declared', glyph: '□', pattern: 'dashed',
    description: 'Supplied as an assumption, policy, requirement, or user assertion (5.3).',
    authorizes: true,
  },
  HEURISTIC: {
    label: 'Heuristic', glyph: '◌', pattern: 'sparse',
    description:
      'Proposed without certificate-quality proof. May rank, prioritise, and explain; '
      + 'may not authorize legality, pruning, strict winner status, or signing (5.3).',
    authorizes: false,
  },
};

export const EVIDENCE_CLASS_ORDER = Object.keys(EVIDENCE_CLASSES);

/**
 * One evidence-class badge: glyph, text label, pattern, tooltip.
 *
 * The text label is always present.  A badge that relied on the glyph would
 * be a second colour-only encoding wearing a different hat.
 */
export function evidenceBadge(name) {
  const key = String(name || '').toUpperCase();
  const info = EVIDENCE_CLASSES[key];
  if (!info) {
    return `<span class="crg-badge crg-badge--unknown" data-evidence-class="UNKNOWN" `
      + `title="This record declares no evidence class; 5.3 requires one.">`
      + `<span class="crg-badge__glyph" aria-hidden="true">?</span>`
      + `<span class="crg-badge__label">Evidence class not declared</span></span>`;
  }
  return `<span class="crg-badge crg-badge--${esc(info.pattern)}" `
    + `data-evidence-class="${esc(key)}" data-pattern="${esc(info.pattern)}" `
    + `title="${esc(info.description)}">`
    + `<span class="crg-badge__glyph" aria-hidden="true">${info.glyph}</span>`
    + `<span class="crg-badge__label">${esc(info.label)}</span>`
    + `${info.authorizes ? '' : '<span class="crg-badge__note">cannot authorize</span>'}`
    + `</span>`;
}

/** The legend Studio shows once per session, and in the Evidence Graph. */
export function evidenceLegend() {
  const rows = EVIDENCE_CLASS_ORDER.map((key) => `<div class="crg-legend__row">`
    + `${evidenceBadge(key)}`
    + `<span class="crg-legend__text">${esc(EVIDENCE_CLASSES[key].description)}</span>`
    + `</div>`);
  return `<div class="crg-legend" role="group" aria-label="Evidence classes (specification 5.3)">`
    + `${join(rows)}</div>`;
}

/* ------------------------------------------------------------------ */
/* 21.4 / 41.2: claim scope, shown adjacent to every claim             */
/* ------------------------------------------------------------------ */

/**
 * Specification 21.4's five scopes with the plain-language sentence Studio
 * shows beside every winner.
 *
 * `global` is the field that matters.  21.5 permits a globally phrased
 * winner only under the three strong scopes; a `RELATIVE_EXPLICIT_FAMILY`
 * result is a winner *among the candidates someone happened to import*, and
 * the failure mode 41.2 is guarding against is a reader who sees a name in
 * bold and takes it for the best available option in the world.
 */
export const CLAIM_SCOPES = {
  FULL_DECLARED_UNIVERSE: {
    label: 'Whole declared universe',
    sentence: 'Certified over every candidate in the declared universe.',
    global: true, symbol: 'FULL_DECLARED_UNIVERSE',
  },
  GENERATOR_CLOSED_FAMILY: {
    label: 'Closure of the declared generators',
    sentence: 'Certified over everything the declared generator set can produce.',
    global: true, symbol: 'GENERATOR_CLOSED_FAMILY',
  },
  BOUNDED_REMAINDER_GLOBAL: {
    label: 'Global, with the remainder bounded',
    sentence:
      'Certified for the decision scope: the part of the family that was never '
      + 'enumerated is proved unable to change this result.',
    global: true, symbol: 'BOUNDED_REMAINDER_GLOBAL',
  },
  RELATIVE_EXPLICIT_FAMILY: {
    label: 'Relative to the explicitly represented family',
    sentence:
      'Certified only against the candidates actually present in this case. '
      + 'A better candidate may exist outside it; nothing here rules that out.',
    global: false, symbol: 'RELATIVE_EXPLICIT_FAMILY',
  },
  PARTIAL_FAMILY: {
    label: 'Partial family: no winner may be claimed',
    sentence:
      'The family is incomplete or unknown and no bound closes the remainder. '
      + '21.5 forbids a globally phrased winner here.',
    global: false, symbol: 'PARTIAL_FAMILY',
  },
};

/**
 * The scope chip.  Emitted by `decisionHeadline` in the same element as the
 * realization names, so no caller can place a winner without it.
 */
export function claimScopeChip(scope, options = {}) {
  const key = String(scope || 'PARTIAL_FAMILY').toUpperCase();
  const info = CLAIM_SCOPES[key] || {
    label: 'Claim scope not declared',
    sentence: '21.3 requires every certificate to carry a typed claim scope.',
    global: false, symbol: key,
  };
  return `<span class="crg-scope crg-scope--${info.global ? 'global' : 'limited'}" `
    + `data-claim-scope="${esc(key)}" title="${esc(info.sentence)}">`
    + `<span class="crg-scope__eyebrow">Claim scope</span> `
    + `<span class="crg-scope__label">${esc(info.label)}</span>`
    + `${options.withSymbol === false ? ''
      : ` <span class="crg-scope__symbol" aria-hidden="true">${esc(key)}</span>`}`
    + `</span>`;
}

/** The full scope statement, for the certificate report of 50.2 item 2. */
export function claimScopePanel(scope) {
  const key = String(scope || 'PARTIAL_FAMILY').toUpperCase();
  const info = CLAIM_SCOPES[key];
  return panel('Claim scope', join([
    claimScopeChip(key),
    `<p class="crg-prose">${esc(info ? info.sentence
      : '21.3 requires every certificate to carry a typed claim scope.')}</p>`,
  ]), { principle: 'claim-scope' });
}

/* ------------------------------------------------------------------ */
/* 21.2 / 41.2: completeness basis, shown prominently                  */
/* ------------------------------------------------------------------ */

export const COMPLETENESS_BASES = {
  EXHAUSTIVE_DECLARED_UNIVERSE: 'Every candidate in an explicitly finite declared universe was enumerated and checked.',
  GENERATOR_CLOSED: 'The registry is complete under a declared generator set and closure procedure.',
  EXPLICIT_IMPORTED_FAMILY: 'The registry is the candidates that were imported. Broader completeness is not claimed.',
  BOUNDED_UNENUMERATED_FAMILY: 'Part of the family was never enumerated, but a certified bound covers the remainder.',
  TRUNCATED_BY_DECLARED_RULE: 'Enumeration was stopped deliberately by a recorded rule.',
  KNOWN_INCOMPLETE: 'Legal candidates are known to be missing.',
  UNKNOWN: 'Completeness has not been established.',
};

/**
 * The completeness panel of 41.2 and 50.2 item 3.
 *
 * Known omissions are rendered as a list and never summarised as a count,
 * because 6.11 forbids silent truncation and "3 omissions" is a truncation
 * of the only content that would let a reader judge whether they matter.
 */
export function completenessPanel(basis) {
  if (isAbsent(basis)) {
    return panel('Completeness basis', emptyState(
      'This case declares no completeness basis. 21.3 requires one before a '
      + 'certificate may claim anything about a family.',
    ), { principle: 'completeness', tone: 'warn' });
  }
  const type = String(basis.basis_type || 'UNKNOWN');
  const omissions = basis.known_omissions || [];
  const rows = [
    ['What was covered', esc(basis.declared_universe || '') || absent()],
    ['Basis', `<span class="crg-basis" data-completeness-basis="${esc(type)}">`
      + `${esc(type.replace(/_/g, ' ').toLowerCase())}</span>`
      + ` <span class="crg-prose">${esc(COMPLETENESS_BASES[type] || COMPLETENESS_BASES.UNKNOWN)}</span>`],
    ['Source or generator', basis.source_or_generator_hash
      ? hashChip(basis.source_or_generator_hash) : absent()],
    ['Generator versions', (basis.generator_versions || []).length
      ? esc((basis.generator_versions || []).join(', ')) : absent()],
    ['Closure procedure', basis.closure_procedure ? esc(basis.closure_procedure) : absent()],
    ['Closure proof', basis.closure_proof ? esc(basis.closure_proof) : absent()],
    ['Stopping rule', basis.truncation_rule ? esc(basis.truncation_rule) : absent()],
    ['Bound on what was not enumerated', basis.remainder_bound
      ? esc(basis.remainder_bound) : absent('UNENUMERATED')],
    ['Known omissions', omissions.length
      ? `<ul class="crg-list">${omissions.map((o) => `<li>${esc(o)}</li>`).join('')}</ul>`
      : '<span class="crg-prose">None recorded.</span>'],
    ['Valid until', basis.validity ? esc(basis.validity) : absent()],
  ];
  return panel('Completeness basis', definitionList(rows), {
    principle: 'completeness',
    tone: ['KNOWN_INCOMPLETE', 'UNKNOWN'].includes(type) ? 'warn' : 'neutral',
  });
}

/* ------------------------------------------------------------------ */
/* 22 / 41.2: outcomes -- tie is not ambiguity, and neither is a winner */
/* ------------------------------------------------------------------ */

/**
 * Specification 22 and 29's outcomes, each with the phrasing Studio is
 * allowed to use for it.
 *
 * `cardinality` drives the headline.  `one` may name a single realization as
 * chosen; `set` may not, however many members the set happens to have --
 * a possible-winner set of one is still a set whose membership depends on
 * unresolved uncertainty, and collapsing it would be exactly the error 22.5
 * describes.  `none` outcomes have no chosen realization at all, and
 * `ALL_INFEASIBLE` is kept apart from every other refusal because 22.7
 * requires it preserved as a distinct outcome rather than softened into a
 * least-bad choice.
 */
export const OUTCOMES = {
  STRICT_WINNER: {
    cardinality: 'one',
    headline: 'Certified strict winner',
    sentence:
      'One realization beats every rival by more than the declared indifference '
      + 'tolerance, on the conservative range rather than on a printed decimal.',
    tone: 'good',
  },
  CERTIFIED_POLICY_TIE: {
    cardinality: 'set',
    headline: 'Certified policy tie',
    sentence:
      'These realizations are equivalent under the declared indifference tolerance, '
      + 'and nothing outside the set can beat it. This is a proven tie, not missing '
      + 'information: collecting more evidence will not separate them.',
    tone: 'good',
    kind: 'tie',
  },
  POSSIBLE_WINNER_SET: {
    cardinality: 'set',
    headline: 'Possible winner set',
    sentence:
      'Under the uncertainty currently admitted, any of these realizations could turn '
      + 'out best. This is unresolved uncertainty, not a tie: better evidence would '
      + 'narrow the set.',
    tone: 'caution',
    kind: 'ambiguity',
  },
  AMBIGUOUS: {
    cardinality: 'set',
    headline: 'Ambiguous',
    sentence:
      'The admissible uncertainty leaves the ordering undetermined. No realization may '
      + 'be reported as chosen (22.5).',
    tone: 'caution',
    kind: 'ambiguity',
  },
  ALL_INFEASIBLE: {
    cardinality: 'none',
    headline: 'All candidates infeasible',
    sentence:
      'No realization in this family satisfies the requirement. The least-infeasible '
      + 'candidate has deliberately not been chosen for you; a relaxation is a separate '
      + 'decision you must request explicitly (22.7).',
    tone: 'blocked',
  },
  BLOCKED_INCOMPLETE_FAMILY: {
    cardinality: 'none',
    headline: 'Blocked: the family is incomplete',
    sentence:
      'The represented family is incomplete and no bound closes the remainder, so 21.5 '
      + 'forbids a winner claim here.',
    tone: 'blocked',
  },
  BLOCKED_INSUFFICIENT_EVIDENCE: {
    cardinality: 'none',
    headline: 'Blocked: the evidence does not support the comparison',
    sentence: 'The available evidence cannot support a certified comparison (22.6).',
    tone: 'blocked',
  },
  BLOCKED_GEOMETRY_NOT_PRESERVED: {
    cardinality: 'none',
    headline: 'Blocked: retention would change the geometry',
    sentence:
      'The proposed retained set does not preserve the decision-relevant geometry, so '
      + 'the certificate cannot be issued against it (29.2).',
    tone: 'blocked',
  },
  BLOCKED_UNSUPPORTED_PRECISION: {
    cardinality: 'none',
    headline: 'Blocked: the precision is not supported',
    sentence:
      'A printed decimal from a floating-point solver cannot become a certified strict '
      + 'winner without a bound, an independent check, or an explicit replay-bound claim (22.6).',
    tone: 'blocked',
  },
  REFUSED: {
    cardinality: 'none',
    headline: 'Refused',
    sentence: 'The decision query could not be answered soundly (26).',
    tone: 'blocked',
  },
};

export function outcomeInfo(outcome) {
  const key = String(outcome || 'REFUSED').toUpperCase();
  return OUTCOMES[key] || {
    cardinality: 'none',
    headline: `Outcome ${key}`,
    sentence: 'This outcome is not one this build knows how to phrase; the record is shown verbatim.',
    tone: 'blocked',
  };
}

function realizationChips(ids, options = {}) {
  const list = (ids || []).map((id) => `<li class="crg-realization" data-realization="${esc(id)}">`
    + `<span class="crg-realization__name">${esc(id)}</span>`
    + `${options.evidenceClasses && options.evidenceClasses[id]
      ? ` ${evidenceBadge(options.evidenceClasses[id])}` : ''}`
    + `</li>`);
  return `<ul class="crg-realization-list" aria-label="${esc(options.label || 'Realizations')}">`
    + `${join(list, '')}</ul>`;
}

/**
 * The decision headline: the one place in Studio that names realizations as
 * an answer, and therefore the one place that has to get 41.2 right.
 *
 * Four of the principles are discharged in this single element, deliberately
 * together rather than in four cooperating components:
 *
 *   - claim scope is emitted inside the headline element, adjacent to the
 *     names, so a screen reader in browse mode and a sighted reader
 *     skimming both meet the scope before they leave the answer;
 *   - the phrasing comes from `OUTCOMES[outcome].cardinality`, so a
 *     possible-winner set can never be phrased as a chosen realization;
 *   - tie and ambiguity get different words, different tones, and different
 *     `data-outcome-kind` values, because 22.5 says overlapping intervals
 *     are not automatically a tie; and
 *   - `ALL_INFEASIBLE` keeps its own headline and is never rendered by
 *     falling through to "no winner", which is 22.7's requirement.
 */
export function decisionHeadline(certificate) {
  const record = certificate || {};
  const info = outcomeInfo(record.outcome);
  const scope = record.claim_scope || 'PARTIAL_FAMILY';
  const scopeInfo = CLAIM_SCOPES[String(scope).toUpperCase()] || { global: false };
  const selected = record.selected || [];
  const ties = record.ties || [];
  const members = info.kind === 'tie' && ties.length ? ties : selected;

  let body;
  if (info.cardinality === 'one' && members.length === 1) {
    const qualifier = scopeInfo.global
      ? 'Chosen realization'
      : 'Chosen realization within this case only';
    body = `<p class="crg-headline__lead">${esc(qualifier)}</p>`
      + realizationChips(members, { label: qualifier });
  } else if (info.cardinality === 'set') {
    const count = members.length ? `${members.length} realizations` : 'The realizations recorded';
    const lead = info.kind === 'tie'
      ? `${count} are equivalent under the declared tolerance. `
        + 'Any of them may be adopted; the record must keep all of them.'
      : `${count} remain in contention. `
        + 'None of them may be adopted as the answer while the set stands.';
    body = `<p class="crg-headline__lead">${esc(lead)}</p>`
      + realizationChips(members, {
        label: info.kind === 'tie' ? 'Tied realizations' : 'Realizations still in contention',
      });
  } else {
    // No realization was chosen, so there is nothing to list.  The outcome's
    // own sentence, appended below for every cardinality, carries the whole
    // explanation -- and is emitted once rather than twice.
    body = '';
  }

  return `<section class="crg-headline crg-headline--${esc(info.tone)}" `
    + `data-outcome="${esc(String(record.outcome || 'REFUSED'))}" `
    + `data-outcome-cardinality="${esc(info.cardinality)}" `
    + `data-outcome-kind="${esc(info.kind || 'determinate')}" `
    + `data-claim-scope="${esc(String(scope).toUpperCase())}" `
    + `aria-labelledby="headline-${slug(record.certificate_id)}">`
    + `<h3 class="crg-headline__title" id="headline-${slug(record.certificate_id)}">`
    + `${esc(info.headline)}</h3>`
    + body
    // The outcome's own sentence is rendered for every cardinality, not only
    // for a chosen realization.  It is the sentence that tells a tie from an
    // ambiguity in words -- "collecting more evidence will not separate them"
    // against "better evidence would narrow the set" -- and 41.2 asks for
    // that distinction to be made, not merely encoded.
    + `<p class="crg-prose">${esc(info.sentence)}</p>`
    + claimScopeChip(scope)
    + `</section>`;
}

/* ------------------------------------------------------------------ */
/* 41.2 / 47.2: explain why a result exists                            */
/* ------------------------------------------------------------------ */

/**
 * The derivation disclosure: query, decision class, rule cited, required
 * object, refusals, dependencies.
 *
 * 47.2 requires a trace from source to verification result for every
 * material conclusion, and 41.2 asks the interface to explain why a result
 * exists.  A `<details>` element is used rather than a modal because it is
 * keyboard-operable and screen-reader-announced without any script, and
 * because the explanation stays in the reading order of the thing it
 * explains.
 */
export function whyPanel(certificate, options = {}) {
  const record = certificate || {};
  const derivation = record.derivation || {};
  const scope = record.scope || {};
  const rows = [
    ['Question asked', scope.question || derivation.query_hash
      ? esc(scope.question || '') || hashChip(derivation.query_hash) : absent()],
    ['Decision class', derivation.decision_class
      ? `<code class="crg-code">${esc(derivation.decision_class)}</code>` : absent()],
    ['Rule cited', derivation.rule_cited
      ? `<span class="crg-rule" data-rule="${esc(derivation.rule_cited)}">`
        + `${esc(derivation.rule_cited)}</span>` : absent()],
    ['Smallest object that could answer it', derivation.required_object
      ? `<code class="crg-code">${esc(derivation.required_object)}</code>` : absent()],
    ['Mapping table version', derivation.mapping_table_version
      ? esc(derivation.mapping_table_version) : absent()],
    ['Refusals recorded', (derivation.refusals || []).length
      ? `<ul class="crg-list">${(derivation.refusals || [])
        .map((r) => `<li>${esc(r)}</li>`).join('')}</ul>`
      : '<span class="crg-prose">None.</span>'],
    ['Notes', (derivation.notes || []).length
      ? `<ul class="crg-list">${(derivation.notes || [])
        .map((n) => `<li>${esc(n)}</li>`).join('')}</ul>`
      : '<span class="crg-prose">None.</span>'],
    ['Derivation record', hashChip(derivation.query_hash)],
    ['Registry it was decided over', hashChip(record.complete_registry_hash)],
    ['Registry actually retained', hashChip(record.retained_registry_hash)],
    ['Depends on', dependencyList(record.dependencies || [])],
    ['Evidence roots', dependencyList(record.evidence_roots || [])],
  ];
  return disclosure(
    options.title || 'Why this result exists',
    definitionList(rows),
    { principle: 'why', open: options.open === true, id: `why-${slug(record.certificate_id)}` },
  );
}

export function dependencyList(items) {
  if (!items || !items.length) return '<span class="crg-prose">None recorded.</span>';
  return `<ul class="crg-list crg-list--deps">`
    + items.map((item) => `<li>${hashChip(item)}</li>`).join('')
    + `</ul>`;
}

/** A content hash or object id, truncated for reading but never for copying. */
export function hashChip(value) {
  if (isAbsent(value)) return absent();
  const text = String(value);
  const short = text.length > 22 ? `${text.slice(0, 12)}…${text.slice(-6)}` : text;
  return `<code class="crg-hash" title="${esc(text)}" data-full="${esc(text)}">`
    + `${esc(short)}</code>`;
}

/* ------------------------------------------------------------------ */
/* 41.2: what would have to change for another realization to win      */
/* ------------------------------------------------------------------ */

/**
 * Margins, runner-up, active bottlenecks, and the regret witness.
 *
 * "What would have to change" is not a courtesy: it is the difference
 * between a decision a reviewer can argue with and an oracle.  The margin is
 * stated as a distance the runner-up would have to make up, and the active
 * bottlenecks -- the phase walls -- are named, because those are the
 * coordinates where a small change flips the answer.
 */
export function marginPanel(certificate) {
  const record = certificate || {};
  const runnerUp = record.runner_up;
  const bottlenecks = record.active_bottlenecks || [];
  const rows = [];
  rows.push(['Closest rival', runnerUp
    ? `<span class="crg-realization__name">${esc(runnerUp)}</span>` : absent()]);
  rows.push(['How far behind it is', isAbsent(record.margin)
    ? absent('PENDING')
    : `${quantity(record.margin, { unit: (record.scope || {}).unit || '' })}`
      + ` <span class="crg-prose">The rival would have to improve by more than this, `
      + `and the improvement would have to be supported by evidence, before the answer changes.</span>`]);
  rows.push(['Phase walls: coordinates holding the answer in place', bottlenecks.length
    ? `<ul class="crg-list">${bottlenecks.map((b) => `<li><code class="crg-code">${esc(b)}</code>`
      + `</li>`).join('')}</ul>`
      + `<p class="crg-prose">A change on any other coordinate leaves the ordering intact; `
      + `a change on one of these can move the boundary.</p>`
    : '<span class="crg-prose">None recorded: no single coordinate is holding this result.</span>']);
  if (record.regret_witness) {
    const witness = record.regret_witness;
    rows.push(['What retention gave up', join([
      quantity(witness.gap, { evidenceClass: witness.evidence_class || 'EXACT', label: 'Shortfall:' }),
      `<p class="crg-prose">A realization was pruned that would have done better. `
      + `This is the certified size of that loss, not an estimate of it (27).</p>`,
      witness.lost_point ? `<p class="crg-prose">Lost candidate: `
        + `${signatureText(witness.lost_point)}</p>` : '',
    ])]);
  }
  return panel('What would have to change', definitionList(rows), { principle: 'margins' });
}

/** A signature rendered coordinate-by-coordinate, absences preserved. */
export function signatureText(signature) {
  const values = (signature && signature.values) || signature || [];
  if (!Array.isArray(values) || !values.length) return absent();
  return `<span class="crg-signature">`
    + values.map((v) => (isAbsent(v) ? absent() : `<span class="crg-signature__value">`
      + `${esc(exactText(v))}</span>`)).join('<span aria-hidden="true">, </span>')
    + `</span>`;
}

/* ------------------------------------------------------------------ */
/* 23, 25 / 41.2: independently verified, or replay-bound?             */
/* ------------------------------------------------------------------ */

export const VERIFICATION_STATUSES = {
  VERIFIED: ['Independently verified', 'good',
    'An independent verifier reproduced every check at the attempted level (25.4).'],
  VERIFIED_RELATIVE: ['Verified, relative to the represented family', 'good',
    'Every check passed, but the claim itself is relative to the candidates present (21.4).'],
  VERIFIED_WITH_BOUNDED_REMAINDER: ['Verified, with the remainder bounded', 'good',
    'Every check passed and a bound covers the part of the family never enumerated (21.6).'],
  INTEGRITY_ONLY: ['Integrity checked only', 'caution',
    'Hashes and signatures check out; nothing about the decision itself was verified (25.2 V0).'],
  REPLAY_BOUND: ['Replay-bound, not independently proved', 'caution',
    'The result is reproducible with the pinned solver and settings, but no independent '
    + 'mathematical proof was available (23.2).'],
  PARTIALLY_VERIFIED: ['Partly verified', 'caution',
    'Some checks passed and some were not supported or not attempted (25.3).'],
  FAILED: ['Verification failed', 'blocked', 'At least one required check failed (25.4).'],
  EXPIRED: ['Expired', 'blocked', 'The validity window closed (45).'],
  REVOKED: ['Revoked', 'blocked', 'The authorizing capability was revoked (35.5).'],
  TIME_INDETERMINATE: ['Time could not be judged', 'caution',
    'No trusted clock judgment was available, so validity cannot be asserted (45).'],
  UNVERIFIABLE_REDACTED: ['Unverifiable: supporting content was redacted', 'blocked',
    'Content this certificate depends on was removed; 17.3 forbids reporting it as valid.'],
  UNSUPPORTED_PROFILE: ['Profile not supported by this verifier', 'caution',
    'The verifier does not implement the profile the certificate was issued under (25.4).'],
  UNVERIFIED: ['Not yet verified', 'caution',
    'No verification has been attempted against this certificate.'],
};

export function verificationChip(status) {
  const key = String(status || 'UNVERIFIED').toUpperCase();
  const [label, tone, description] = VERIFICATION_STATUSES[key]
    || ['Verification status not recognised', 'caution',
      '25.4 lists the statuses an independent verifier may report.'];
  return `<span class="crg-verification crg-verification--${esc(tone)}" `
    + `data-verification-status="${esc(key)}" title="${esc(description)}">`
    + `<span class="crg-verification__glyph" aria-hidden="true">`
    + `${tone === 'good' ? '✓' : tone === 'blocked' ? '✗' : '⚠'}</span>`
    + `<span class="crg-verification__label">${esc(label)}</span>`
    + `<span class="crg-visually-hidden"> (${esc(key)})</span></span>`;
}

export const SOLVER_TRUST = {
  PROOF_CHECKED: ['Proof checked by CRG', 'The solver emitted a proof that CRG checked independently (23.2).'],
  EXACT_RECOMPUTED: ['Recomputed exactly by CRG', 'CRG recomputed feasibility and objective values exactly (23.2).'],
  DETERMINISTIC_REPLAY: ['Reproducible replay only', 'Pinned and replayable, but not independently proved (23.2).'],
  DECLARED_NONDETERMINISTIC: ['Nondeterminism disclosed', 'Only weaker claims are permitted (23.2).'],
  HEURISTIC: ['Heuristic', 'May guide exploration; cannot authorize a strong certificate (23.2, 5.3).'],
};

export function solverTrustChip(profile) {
  const key = String(profile || 'DETERMINISTIC_REPLAY').toUpperCase();
  const [label, description] = SOLVER_TRUST[key]
    || ['Solver trust profile not declared', '23.1 requires independently checkable evidence to be preferred.'];
  return `<span class="crg-trust" data-solver-trust="${esc(key)}" title="${esc(description)}">`
    + `<span class="crg-trust__eyebrow">How the number was trusted</span> `
    + `<span class="crg-trust__label">${esc(label)}</span></span>`;
}

/* ------------------------------------------------------------------ */
/* generic layout primitives                                           */
/* ------------------------------------------------------------------ */

/**
 * A titled region.  `principle` tags the panel with the 41.2 clause it
 * discharges; Studio's "How to read this" mode reveals the tags, which makes
 * the principles auditable in the running product rather than only in this
 * source file.
 */
export function panel(title, body, options = {}) {
  const id = options.id || `panel-${slug(title)}`;
  return `<section class="crg-panel crg-panel--${esc(options.tone || 'neutral')}" `
    + `aria-labelledby="${esc(id)}-title"`
    + `${options.principle ? ` data-ux-principle="${esc(options.principle)}"` : ''}>`
    + `<h3 class="crg-panel__title" id="${esc(id)}-title">${esc(title)}</h3>`
    + `<div class="crg-panel__body">${body}</div>`
    + `</section>`;
}

/** A keyboard-operable disclosure with no script behind it. */
export function disclosure(summary, body, options = {}) {
  return `<details class="crg-disclosure"${options.open ? ' open' : ''}`
    + `${options.id ? ` id="${esc(options.id)}"` : ''}`
    + `${options.principle ? ` data-ux-principle="${esc(options.principle)}"` : ''}>`
    + `<summary class="crg-disclosure__summary">${esc(summary)}</summary>`
    + `<div class="crg-disclosure__body">${body}</div>`
    + `</details>`;
}

/**
 * A definition list.
 *
 * A term is escaped when it is prose and passed through when it is already
 * markup, which is how `TERMS.R()` and the other plain-language terms can
 * appear as the label of a row.  The test is deliberately narrow -- a
 * leading `<` -- because every prose term in Studio is a sentence fragment
 * and none of them starts with an angle bracket; anything richer would make
 * the escaping rule depend on the content, which is how escaping bugs are
 * born.
 */
export function definitionList(rows) {
  const items = rows.map(([label, value]) => `<div class="crg-dl__row">`
    + `<dt class="crg-dl__term">${/^\s*</.test(String(label)) ? label : esc(label)}</dt>`
    + `<dd class="crg-dl__value">${value === undefined || value === null || value === ''
      ? absent() : value}</dd></div>`);
  return `<dl class="crg-dl">${join(items, '')}</dl>`;
}

/**
 * A data table.  `caption` is required rather than optional: an unlabelled
 * table is unusable with a screen reader, and WCAG 2.2 AA is the target of
 * 47.7.  Cells are rendered by the caller so that absences stay absences.
 */
export function table(caption, columns, rows, options = {}) {
  if (!rows || !rows.length) {
    return panel(caption, emptyState(options.emptyMessage
      || 'Nothing to show yet. Run the step that produces this, or open a case that has it.'),
    { tone: 'neutral' });
  }
  const head = columns.map((c) => `<th scope="col">${esc(c.label)}`
    + `${c.hint ? `<span class="crg-visually-hidden">. ${esc(c.hint)}</span>` : ''}</th>`).join('');
  const body = rows.map((row) => `<tr${row.attributes || ''}>`
    + columns.map((c, index) => (index === 0
      ? `<th scope="row">${row.cells[index]}</th>`
      : `<td>${row.cells[index] === undefined ? absent() : row.cells[index]}</td>`)).join('')
    + `</tr>`).join('');
  return `<div class="crg-table-wrap">`
    + `<table class="crg-table">`
    + `<caption class="crg-table__caption">${esc(caption)}</caption>`
    + `<thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>`;
}

/**
 * An empty state.  Never a blank region and never a zero: "no data yet" and
 * "the value is nought" are different statements, and 41.2 forbids the
 * interface from confusing them anywhere, not only in coordinate cells.
 */
export function emptyState(message, action = '') {
  return `<p class="crg-empty" role="note">${esc(message)}${action ? ` ${action}` : ''}</p>`;
}

/** A refusal from the API, rendered with its category and its remedy intact. */
export function refusal(error) {
  if (!error) return '';
  const detail = error.detail
    ? `<pre class="crg-pre" tabindex="0" role="group" aria-label="Refusal detail">`
      + `${esc(JSON.stringify(error.detail, null, 2))}</pre>`
    : '';
  return `<section class="crg-panel crg-panel--blocked" role="alert" `
    + `aria-labelledby="refusal-title" data-refusal-category="${esc(error.category || 'unknown')}">`
    + `<h3 class="crg-panel__title" id="refusal-title">The system refused this request</h3>`
    + `<div class="crg-panel__body">`
    + `<p class="crg-prose"><strong>${esc(error.message || '')}</strong></p>`
    + `${error.remedy ? `<p class="crg-prose">What to do: ${esc(error.remedy)}</p>` : ''}`
    + `<p class="crg-prose">This is a refusal, not a failure. The system fails closed `
    + `rather than guessing (6.6), and the record above is the reason.</p>`
    + detail
    + `</div></section>`;
}

/**
 * A mathematical symbol with its plain-language name first.
 *
 * 41.2's last bullet: ordinary operation must not require the notation.  The
 * plain name is the accessible name and the symbol is decorative, so a
 * screen reader says "requirement set" rather than "R", and a reader who
 * does know the notation still sees it.
 */
export function term(plain, symbol, description = '') {
  return `<span class="crg-term"${description ? ` title="${esc(description)}"` : ''}>`
    + `<span class="crg-term__plain">${esc(plain)}</span>`
    + `${symbol ? ` <span class="crg-term__symbol" aria-hidden="true">${esc(symbol)}</span>` : ''}`
    + `</span>`;
}

export const TERMS = {
  R: () => term('Requirement set', 'R', 'The set of obligation vectors the case requires (19.2).'),
  GAMMA: () => term('Achievable frontier', 'Γ',
    'The minimal achievable obligation vectors of the family (19.3).'),
  K: () => term('Feasible region', 'K', 'The region a realization must land in (19.4).'),
  TOLERANCE: () => term('Indifference tolerance', 'τ',
    'Differences smaller than this are treated as equivalent by declared policy (22.1).'),
  EPSILON: () => term('Separation constant', 'ε',
    'The strictly positive constant in the regret construction (27).'),
};

/** A job's progress, phrased for a person rather than a scheduler. */
export function jobStatus(job) {
  if (!job) return '';
  const status = String(job.status || 'QUEUED');
  const phrasing = {
    QUEUED: 'Waiting to start',
    RUNNING: 'Running',
    SUCCEEDED: 'Finished',
    FAILED: 'Stopped without a result',
    CANCELLED: 'Cancelled',
  }[status] || status;
  return `<p class="crg-job" data-job-status="${esc(status)}" role="status">`
    + `<span class="crg-job__label">${esc(phrasing)}</span>`
    + `${job.job_id ? ` <span class="crg-job__id">${hashChip(job.job_id)}</span>` : ''}`
    + `${(job.log || []).length ? `<span class="crg-job__log">${esc(job.log[job.log.length - 1])}</span>` : ''}`
    + `</p>`;
}

export default {
  ABSENT_MARK, CLAIM_SCOPES, COMPLETENESS_BASES, EVIDENCE_CLASSES, OUTCOMES, TERMS,
  VERIFICATION_STATUSES, absent, claimScopeChip, claimScopePanel, completenessPanel,
  decisionHeadline, definitionList, dependencyList, disclosure, emptyState, esc,
  evidenceBadge, evidenceLegend, exactText, hashChip, interval, jobStatus, join,
  marginPanel, outcomeInfo, panel, quantity, refusal, signatureText, slug,
  solverTrustChip, table, term, verificationChip, whyPanel,
};
