/**
 * Decision Center (spec 41.1): winners, possible winners, retained
 * alternatives, margins, pruning, regret, and claim scope.
 *
 * This workspace renders the canonical human-readable certificate report of
 * 50.2 in its mandatory order.  50.3 permits an implementation to vary
 * typography, language, and accessibility treatment, and forbids hiding or
 * reordering the claim scope, completeness basis, uncertainty, or
 * verification status "in a manner that could mislead the reader".  Studio
 * therefore emits all twenty-one items, numbered, in order, with the
 * `data-report-item` attribute the test suite reads — so the ordering is a
 * checked property rather than a convention that survives until the next
 * redesign.
 *
 * The headline is `decisionHeadline` from `render.js` and not local markup.
 * That is the whole defence against 41.2's fourth principle: there is no
 * code path in this workspace that can name a single realization as the
 * answer, because this workspace does not contain one.
 */

import {
  absent, claimScopePanel, completenessPanel, decisionHeadline, definitionList, disclosure,
  emptyState, esc, evidenceBadge, hashChip, interval, join, marginPanel, outcomeInfo, panel,
  quantity, signatureText, solverTrustChip, table, TERMS, verificationChip, whyPanel,
} from '../render.js';
import { action, field, notYet, shell } from '../workspace.js';

const meta = {
  id: 'decision-center',
  title: 'Decision Center',
  purpose:
    'Winners, possible winners, retained alternatives, margins, pruning, regret, '
    + 'and claim scope.',
  endpoints: ['certifyCase', 'listCertificates', 'getJob', 'getJobResult', 'cancelJob'],
};

/** Wrap one item of the 50.2 report, carrying its mandatory position. */
function item(number, title, body, options = {}) {
  return `<section class="crg-report__item" data-report-item="${number}" `
    + `aria-labelledby="report-${number}-title"`
    + `${options.principle ? ` data-ux-principle="${esc(options.principle)}"` : ''}>`
    + `<h3 class="crg-report__title" id="report-${number}-title">`
    + `<span class="crg-report__number" aria-hidden="true">${number}.</span> ${esc(title)}</h3>`
    + `<div class="crg-report__body">${body}</div></section>`;
}

function objectiveTable(certificate) {
  const values = certificate.objective_values || {};
  const ids = Object.keys(values).sort();
  if (!ids.length) {
    return emptyState('No objective values are recorded on this certificate.');
  }
  return table('Objective value per realization', [
    { label: 'Realization' },
    { label: 'Exact value', hint: 'The value under exact semantics, where one exists (22.2).' },
    { label: 'Arithmetic enclosure', hint: 'Uncertainty from arithmetic and the solver (22.1).' },
    { label: 'Evidence uncertainty', hint: 'Measurement, model, and transfer uncertainty (22.1).' },
    { label: 'Conservative range', hint: 'The range a comparison is allowed to use (22.2).' },
    { label: 'Evidence class' },
  ], ids.map((id) => {
    const value = values[id] || {};
    return {
      attributes: ` data-realization="${esc(id)}"`,
      cells: [
        `<span class="crg-realization__name">${esc(id)}</span>`,
        value.exact === undefined || value.exact === null
          ? absent('UNSUPPORTED') : quantity(value.exact, { unit: value.unit || '' }),
        value.numerical_interval ? interval(value.numerical_interval, { kind: 'numerical' })
          : absent('UNSUPPORTED'),
        value.evidence_interval ? interval(value.evidence_interval, { kind: 'evidence' })
          : absent('UNSUPPORTED'),
        value.combined_interval ? interval(value.combined_interval, { kind: 'combined' })
          : absent('UNSUPPORTED'),
        evidenceBadge(value.evidence_class),
      ],
    };
  }));
}

function infeasiblePanel(certificate) {
  const infeasible = certificate.infeasible || {};
  const ids = Object.keys(infeasible).sort();
  if (!ids.length) return '';
  return panel('Candidates that cannot satisfy the requirement', join([
    `<ul class="crg-list">${ids.map((id) => `<li>`
      + `<span class="crg-realization__name">${esc(id)}</span>: ${esc(infeasible[id])}</li>`).join('')}</ul>`,
    `<p class="crg-prose">These are recorded as infeasible, not as poor candidates. `
    + `The distinction is preserved deliberately: an infeasible realization has no `
    + `objective value to rank (22.7).</p>`,
  ]), { tone: 'warn', principle: 'all-infeasible' });
}

function pruningPanel(certificate) {
  const certificates = certificate.pruning_certificates || [];
  if (!certificates.length) {
    return emptyState('Nothing was pruned. Every candidate in the family is still represented.');
  }
  return table('Pruned alternatives and the certificate that authorised each pruning', [
    { label: 'Pruned' },
    { label: 'Rule' },
    { label: 'Evidence class' },
    { label: 'Justification' },
  ], certificates.map((record) => ({
    cells: [
      `<span class="crg-realization__name">${esc(record.pruned || record.realization_id || '')}</span>`,
      record.rule ? `<code class="crg-code">${esc(record.rule)}</code>` : absent(),
      evidenceBadge(record.evidence_class),
      record.justification ? esc(record.justification) : absent(),
    ],
  })));
}

function geometryPanel(certificate) {
  return definitionList([
    [`Requirement set used`, join([TERMS.R(), hashChip(certificate.complete_registry_hash)], ' ')],
    [`Frontier the comparison ran against`, join([TERMS.GAMMA(),
      certificate.geometry_preserved
        ? '<span class="crg-prose">Retention preserved the decision-relevant geometry.</span>'
        : '<span class="crg-prose">Retention did <strong>not</strong> preserve the '
          + 'decision-relevant geometry, which is why this certificate is blocked (29.2).</span>',
    ], ' ')],
    ['Retained registry', hashChip(certificate.retained_registry_hash)],
  ]);
}

function certificateReport(certificate, state) {
  const record = certificate || {};
  const info = outcomeInfo(record.outcome);
  const scope = record.scope || {};
  const versions = record.engine_versions || {};
  return `<div class="crg-report" data-certificate="${esc(record.certificate_id || '')}">`
    + item(1, 'Claim', join([
      `<p class="crg-prose crg-prose--lead">${esc(state.claim || info.sentence)}</p>`,
      decisionHeadline(record),
    ]), { principle: 'claim-scope' })
    + item(2, 'Claim scope', claimScopePanel(record.claim_scope), { principle: 'claim-scope' })
    + item(3, 'Completeness basis', completenessPanel(record.completeness),
      { principle: 'completeness' })
    + item(4, 'Decision semantics', definitionList([
      ['Question', scope.question ? esc(scope.question) : absent()],
      ['Decision class', (record.derivation || {}).decision_class
        ? `<code class="crg-code">${esc(record.derivation.decision_class)}</code>` : absent()],
      ['Objective', scope.objective ? esc(scope.objective) : absent()],
      ['Comparison', `<p class="crg-prose">A realization is certified as beating a rival `
        + `only when its worst case is better than the rival's best case, with room to spare `
        + `for the declared indifference tolerance. A printed decimal is not enough (22.3, 22.6).</p>`],
    ]), { principle: 'plain-language' })
    + item(5, 'Required retained object', definitionList([
      ['Smallest object that could answer the question', (record.derivation || {}).required_object
        ? `<code class="crg-code">${esc(record.derivation.required_object)}</code>` : absent()],
      ['Rule that says so', (record.derivation || {}).rule_cited
        ? esc(record.derivation.rule_cited) : absent()],
    ]))
    + item(6, 'Selected, tied, or possible-winner realizations', join([
      decisionHeadline(record),
      objectiveTable(record),
      infeasiblePanel(record),
    ]), { principle: 'tie-vs-ambiguity' })
    + item(7, 'Runner-up and margin', marginPanel(record), { principle: 'margins' })
    + item(8, 'Numerical enclosure', `<p class="crg-prose">Uncertainty introduced by arithmetic `
      + `and the solver is recorded per realization in the table above, in its own column. `
      + `22.1 keeps it separate from evidence uncertainty because the two are reduced by `
      + `different work: better arithmetic, or better measurement.</p>`)
    + item(9, 'Evidence uncertainty', `<p class="crg-prose">Measurement, sampling, calibration, `
      + `transfer, model, and physical uncertainty, also in its own column above. `
      + `The Qualification Planner ranks the experiments that would shrink it.</p>`,
    { principle: 'resolving-evidence' })
    + item(10, 'Policy tolerance', definitionList([
      [TERMS.TOLERANCE(), scope.policy_tolerance !== undefined && scope.policy_tolerance !== null
        ? quantity(scope.policy_tolerance, { unit: scope.unit || '' })
        : absent('UNSUPPORTED')],
      ['What it means', `<p class="crg-prose">Differences smaller than this are treated as `
        + `equivalent by declared policy. It is a decision rule, not an uncertainty: `
        + `it does not shrink when the evidence improves (22.1).</p>`],
    ]), { principle: 'plain-language' })
    + item(11, 'Geometry basis', geometryPanel(record))
    + item(12, 'Retained and pruned alternatives', pruningPanel(record))
    + item(13, 'Regret witness', record.regret_witness
      ? definitionList([
        ['Candidate given up', signatureText(record.regret_witness.lost_point)],
        ['Certified shortfall', quantity(record.regret_witness.gap, {
          evidenceClass: record.regret_witness.evidence_class || 'EXACT',
        })],
        ['Construction', record.regret_witness.construction
          ? `<code class="crg-code">${esc(record.regret_witness.construction)}</code>` : absent()],
      ])
      : emptyState('Not applicable: no realization was given up that would have done better.'))
    + item(14, 'Evidence classes and lineage', join([
      `<p class="crg-prose">Each objective value above carries the class of evidence that `
      + `produced it. A heuristic value may rank and explain; it may not authorize a `
      + `certified comparison, certified pruning, or a signature (5.3).</p>`,
      whyPanel(record, { title: 'Full derivation and dependencies' }),
    ]), { principle: 'evidence-classes' })
    + item(15, 'Solver trust profile', join([
      solverTrustChip(state.solverTrust || (scope.solver_trust_profile)),
      `<p class="crg-prose">23.1: independently checkable evidence is preferred to trust in `
      + `solver execution. A replay-bound result is reproducible, not proved.</p>`,
    ]), { principle: 'verified-or-replay' })
    + item(16, 'Verification level', join([
      verificationChip(state.verificationStatus || record.verification_status),
      `<p class="crg-prose">Verification is performed by <code class="crg-code">crg-verify</code>, `
      + `which runs without this server, this database, or this interface (25.1). `
      + `Open the Verification Center to run it against an exported bundle.</p>`,
    ]), { principle: 'verified-or-replay' })
    + item(17, 'Dependencies', definitionList([
      ['Depends on', (record.dependencies || []).length
        ? `<ul class="crg-list">${(record.dependencies || [])
          .map((d) => `<li>${hashChip(d)}</li>`).join('')}</ul>` : absent()],
      ['Evidence roots', (record.evidence_roots || []).length
        ? `<ul class="crg-list">${(record.evidence_roots || [])
          .map((d) => `<li>${hashChip(d)}</li>`).join('')}</ul>` : absent()],
    ]))
    + item(18, 'Validity and clock judgment', definitionList([
      ['Valid until', record.expiry ? esc(record.expiry) : absent('UNSUPPORTED')],
      ['Clock judgment', state.clockJudgment ? esc(state.clockJudgment)
        : absent('UNSUPPORTED')],
      ['What an absent judgment means', `<p class="crg-prose">A missing clock judgment is `
        + `not a passing one. Without a trusted time source, validity cannot be asserted `
        + `and the verifier reports it as indeterminate (45).</p>`],
    ]))
    + item(19, 'Reopen conditions', (record.reopen_conditions || []).length
      ? `<ul class="crg-list">${(record.reopen_conditions || [])
        .map((c) => `<li>${esc(c)}</li>`).join('')}</ul>`
      : emptyState('No reopen conditions were recorded on this certificate.'))
    + item(20, 'Signatures', (record.signatures || []).length
      ? `<ul class="crg-list">${(record.signatures || []).map((s) => `<li>`
        + `${esc(s.signer || s.key_id || '')} ${hashChip(s.signature || '')}</li>`).join('')}</ul>`
      : emptyState('Unsigned. An unsigned certificate is still a record; it is not an approval.'))
    + item(21, 'Limitations', join([
      `<ul class="crg-list">`
      + `<li>This certificate speaks only within its claim scope, stated in item 2.</li>`
      + `<li>It speaks only about the family described by its completeness basis, item 3.</li>`
      + `<li>Engine versions: ${Object.keys(versions).length
        ? esc(Object.entries(versions).map(([k, v]) => `${k} ${v}`).join(', '))
        : 'not recorded'}. A different version may reach a different result and must be `
        + `re-verified (15.2).</li>`
      + `</ul>`,
    ]))
    + `</div>`;
}

function certificateChooser(state) {
  const listed = ((state.data || {}).certificates) || [];
  if (!listed.length) return '';
  return table('Certificates issued for this case', [
    { label: 'Certificate' },
    { label: 'Outcome' },
    { label: 'Status', hint: 'The 17.1 lifecycle status of the certificate.' },
    { label: 'Affirmative', hint: 'Whether the outcome authorises anything (6.6).' },
    { label: '' },
  ], listed.map((certificate) => ({
    attributes: ` data-certificate="${esc(certificate.certificate_id || '')}"`,
    cells: [
      hashChip(certificate.certificate_id),
      `<span class="crg-outcome" data-outcome="${esc(certificate.outcome || '')}">`
      + `${esc(outcomeInfo(certificate.outcome).headline)}</span>`,
      certificate.status === 'UNVERIFIABLE_REDACTED'
        ? verificationChip('UNVERIFIABLE_REDACTED')
        : `<span>${esc(certificate.status || '')}</span>`,
      certificate.affirmative ? 'Yes' : 'No — this certificate authorises nothing',
      `<button type="button" class="crg-button crg-button--secondary" `
      + `data-action="show-certificate" data-certificate="${esc(certificate.certificate_id || '')}">`
      + `Open certificate ${esc(certificate.certificate_id || '')}</button>`,
    ],
  })));
}

export const workspace = {
  ...meta,
  render(state = {}) {
    const certificate = state.certificate || (state.data || {}).certificate || null;
    const controls = panel('Issue or re-open a decision', join([
      field('retained', 'Realizations to retain, one per line', {
        multiline: true,
        value: (state.form && state.form.retained) || '',
        hint: 'Leave empty to certify over the whole represented family. Retention must '
          + 'preserve the decision-relevant geometry or the certificate is refused (29.2).',
      }),
      `<div class="crg-actions">`
      + action('certify', 'Issue a decision certificate', { operation: 'certifyCase' })
      + action('refresh-certificates', 'Reload certificates', {
        operation: 'listCertificates', tone: 'secondary',
      })
      + `</div>`,
      `<p class="crg-prose">Certification is a long-running action: it returns a job `
      + `identifier and the result arrives when the job finishes (38.3).</p>`,
    ]));
    if (!certificate) {
      return shell(meta, join([
        controls,
        certificateChooser(state),
        notYet('No certificate is open. Issue one, or choose an existing certificate above.'),
      ]), state);
    }
    return shell(meta, join([
      controls,
      certificateChooser(state),
      `<h3 class="crg-section-title">Certificate report</h3>`,
      `<p class="crg-prose">This is the canonical report of specification 50.2, in the `
      + `mandatory order. Every conforming renderer presents the same items in the same `
      + `sequence, so a reader who has seen one has seen them all.</p>`,
      certificateReport(certificate, state),
      disclosure('Certificate as stored', `<pre class="crg-pre" tabindex="0" role="group" `
        + `aria-label="Canonical certificate record">`
        + `${esc(JSON.stringify(certificate, null, 2))}</pre>`, { principle: 'why' }),
    ]), state);
  },
  certificateReport,
};

export default workspace;
