/**
 * Geometry and Phase View (spec 41.1): R, Gamma, K, envelopes, ledgers,
 * boundaries, and ties.
 *
 * The one workspace whose subject matter is irreducibly mathematical, and
 * therefore the one where 41.2's last principle bites hardest: ordinary
 * operation must not require the user to manipulate the notation.  Every
 * symbol here is rendered by `term()`, which puts the plain-language name
 * first and marks the symbol decorative, so a screen reader says
 * "achievable frontier" rather than "gamma", and a reader who knows the
 * notation still sees it.
 *
 * The frontier is drawn as an SVG scatter *and* published as a table.  A
 * picture of a Pareto frontier is the fastest way to understand one and the
 * slowest way to audit one; both are offered, and the table is the
 * authoritative rendering.
 */

import {
  absent, definitionList, emptyState, esc, evidenceBadge, hashChip, join, panel, quantity,
  signatureText, table, TERMS, term,
} from '../render.js';
import { action, notYet, shell } from '../workspace.js';

const meta = {
  id: 'geometry-phase-view',
  title: 'Geometry and Phase View',
  purpose: 'Requirement set, achievable frontier, feasible region, envelopes, ledgers, '
    + 'boundaries, and ties.',
  endpoints: ['buildGeometry', 'getCase', 'getJobResult'],
};

function pointValues(point) {
  if (Array.isArray(point)) return point;
  if (point && Array.isArray(point.values)) return point.values;
  return [];
}

function numeric(value) {
  if (value === null || value === undefined) return null;
  if (typeof value === 'number') return value;
  if (typeof value === 'object') {
    if (value.numerator !== undefined && value.denominator !== undefined) {
      const denominator = Number(value.denominator);
      return denominator ? Number(value.numerator) / denominator : null;
    }
    if (value.value !== undefined) return Number(value.value);
    return null;
  }
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

/**
 * A two-coordinate scatter of the frontier.
 *
 * Decorative by declaration: `role="img"` with a `<title>` and a `<desc>`
 * that state in words what the picture shows, and the authoritative table
 * follows immediately.  A point whose coordinates are not both supported is
 * omitted from the plot and listed underneath — plotting it at the origin
 * would be exactly the zero-for-absent error 41.2 forbids, committed in
 * pixels instead of digits.
 */
function frontierPlot(points, coordinates) {
  const usable = [];
  const unplottable = [];
  points.forEach((point, index) => {
    const values = pointValues(point);
    const x = numeric(values[0]);
    const y = numeric(values[1]);
    if (x === null || y === null) unplottable.push(index);
    else usable.push({ x, y, index });
  });
  if (!usable.length) {
    return emptyState('No frontier point has two supported coordinates, so nothing can be '
      + 'plotted. The table below lists every point regardless.');
  }
  const xs = usable.map((p) => p.x);
  const ys = usable.map((p) => p.y);
  const xMin = Math.min(...xs); const xMax = Math.max(...xs);
  const yMin = Math.min(...ys); const yMax = Math.max(...ys);
  const spanX = xMax - xMin || 1;
  const spanY = yMax - yMin || 1;
  const marks = usable.map((p) => {
    const cx = 40 + ((p.x - xMin) / spanX) * 280;
    const cy = 200 - ((p.y - yMin) / spanY) * 160;
    return `<circle class="crg-plot__point" cx="${cx.toFixed(1)}" cy="${cy.toFixed(1)}" r="5">`
      + `<title>Point ${p.index + 1}</title></circle>`;
  }).join('');
  const xName = (coordinates[0] || {}).identifier || 'first coordinate';
  const yName = (coordinates[1] || {}).identifier || 'second coordinate';
  const description = `Scatter of ${usable.length} frontier points, ${esc(xName)} on the `
    + `horizontal axis and ${esc(yName)} on the vertical axis. The authoritative values are `
    + `in the table that follows.`;
  return `<figure class="crg-figure">`
    + `<svg class="crg-plot" viewBox="0 0 360 230" role="img" `
    + `aria-labelledby="plot-title plot-desc">`
    + `<title id="plot-title">Achievable frontier</title>`
    + `<desc id="plot-desc">${description}</desc>`
    + `<line class="crg-plot__axis" x1="40" y1="200" x2="330" y2="200"></line>`
    + `<line class="crg-plot__axis" x1="40" y1="200" x2="40" y2="30"></line>`
    + `<text class="crg-plot__label" x="185" y="222" text-anchor="middle">${esc(xName)}</text>`
    + `<text class="crg-plot__label" x="12" y="115" text-anchor="middle" `
    + `transform="rotate(-90 12 115)">${esc(yName)}</text>`
    + marks
    + `</svg>`
    + `<figcaption class="crg-figure__caption">${description}`
    + `${unplottable.length ? ` ${unplottable.length} point(s) could not be plotted because a `
      + `coordinate has no supported value; they are marked in the table.` : ''}`
    + `</figcaption></figure>`;
}

function frontierTable(caption, points, coordinates) {
  if (!points.length) return emptyState(`No ${caption.toLowerCase()} is recorded yet.`);
  return table(caption, [
    { label: 'Point' },
    ...coordinates.map((c) => ({ label: c.identifier || 'coordinate', hint: c.unit || '' })),
    { label: 'On the boundary?', hint: 'A boundary point is one a small change can move past.' },
  ], points.map((point, index) => {
    const values = pointValues(point);
    return {
      cells: [
        `<span>${esc(String(index + 1))}</span>`,
        ...coordinates.map((coordinate, position) => quantity(values[position], {
          unit: coordinate.unit || '',
        })),
        point.boundary === false ? 'Interior' : 'Boundary',
      ],
    };
  }));
}

function tiesPanel(geometry) {
  const ties = geometry.ties || [];
  if (!ties.length) {
    return panel('Ties on the frontier', emptyState(
      'No tied points are recorded. When two realizations sit at the same point on the '
      + 'frontier, both are kept: 22.4 makes a tie a result, not a rounding artefact.',
    ), { principle: 'tie-vs-ambiguity' });
  }
  return panel('Ties on the frontier', table('Points shared by more than one realization', [
    { label: 'Point' },
    { label: 'Realizations at this point' },
  ], ties.map((tie) => ({
    cells: [
      signatureText(tie.signature || tie.point),
      `<ul class="crg-realization-list" aria-label="Realizations at this point">`
      + (tie.realizations || []).map((r) => `<li class="crg-realization">`
        + `<span class="crg-realization__name">${esc(r)}</span></li>`).join('')
      + `</ul>`,
    ],
  }))), { principle: 'tie-vs-ambiguity' });
}

function envelopePanel(geometry) {
  const envelope = geometry.envelope || geometry.approximation || null;
  if (!envelope) {
    return panel('Approximation envelope', emptyState(
      'This geometry is exact: no approximation envelope is in force. When one is, 20.1 '
      + 'requires the direction and size of the error to be stated, not merely its existence.',
    ));
  }
  return panel('Approximation envelope', definitionList([
    ['Kind', envelope.kind ? esc(envelope.kind) : absent()],
    ['Direction of error', envelope.direction
      ? esc(envelope.direction) : absent('UNSUPPORTED')],
    ['Size of error', envelope.error === undefined ? absent('UNSUPPORTED')
      : quantity(envelope.error, { unit: envelope.unit || '' })],
    ['Evidence class', evidenceBadge(envelope.evidence_class || 'BOUNDED')],
    ['What it permits', `<p class="crg-prose">An inner bound may prove achievability; an `
      + `outer bound may prove impossibility. Neither may be silently swapped for the `
      + `other (20.2).</p>`],
  ]), { principle: 'evidence-classes' });
}

function ledgerPanel(geometry) {
  const ledger = geometry.ledger || [];
  if (!ledger.length) {
    return panel('Construction ledger', emptyState(
      'No construction steps are recorded for this geometry.',
    ));
  }
  return table('How this geometry was built, step by step', [
    { label: 'Step' },
    { label: 'Operation' },
    { label: 'Input' },
    { label: 'Evidence class' },
  ], ledger.map((entry, index) => ({
    cells: [
      `<span>${esc(String(index + 1))}</span>`,
      entry.operation ? `<code class="crg-code">${esc(entry.operation)}</code>` : absent(),
      entry.input ? hashChip(entry.input) : absent(),
      evidenceBadge(entry.evidence_class || 'EXACT'),
    ],
  })));
}

function glossary() {
  return panel('What these three things are', definitionList([
    [TERMS.R(), '<span class="crg-prose">Everything the case requires: the obligations a '
      + 'realization has to satisfy to be admissible at all.</span>'],
    [TERMS.GAMMA(), '<span class="crg-prose">The best trade-offs actually achievable by the '
      + 'family. Nothing in the family does better on every coordinate than a point here.</span>'],
    [TERMS.K(), '<span class="crg-prose">The region a realization must land in for the '
      + 'requirement to be met.</span>'],
    [term('Phase wall', 'boundary'), '<span class="crg-prose">A boundary in this geometry '
      + 'where a small change flips which realization wins. The Decision Center names the '
      + 'coordinates that form it.</span>'],
  ]), { principle: 'plain-language' });
}

export const workspace = {
  ...meta,
  render(state = {}) {
    const geometry = ((state.data || {}).case || {}).geometry
      || (state.data || {}).geometry || null;
    const registry = ((state.data || {}).case || {}).registry
      || (state.data || {}).registry || {};
    const coordinates = ((registry.schema || {}).coordinates || []).slice(0, 4);
    if (!geometry) {
      return shell(meta, join([
        glossary(),
        notYet(
          'No geometry has been built for this case yet.',
          `<div class="crg-actions">${action('build-geometry', 'Build the geometry', {
            operation: 'buildGeometry',
          })}</div>`,
        ),
      ]), state);
    }
    const full = geometry.full_frontier || geometry.frontier || [];
    const retained = geometry.retained_frontier || [];
    return shell(meta, join([
      glossary(),
      panel('Roots', definitionList([
        [TERMS.R(), hashChip((geometry.R || {}).root_hash)],
        [TERMS.GAMMA(), hashChip((geometry.GAMMA || {}).root_hash)],
        [TERMS.K(), hashChip((geometry.K || {}).root_hash)],
      ])),
      panel('Achievable frontier', join([
        frontierPlot(full, coordinates),
        frontierTable('Achievable frontier of the whole family', full, coordinates),
      ])),
      retained.length
        ? panel('Frontier after retention', join([
          `<p class="crg-prose">Retention is only permissible when it leaves the `
          + `decision-relevant part of this frontier intact. Compare the two tables: any point `
          + `present above and absent here is a trade-off the case can no longer offer.</p>`,
          frontierTable('Frontier of the retained set', retained, coordinates),
        ]))
        : '',
      tiesPanel(geometry),
      envelopePanel(geometry),
      ledgerPanel(geometry),
      `<div class="crg-actions">${action('build-geometry', 'Rebuild the geometry', {
        operation: 'buildGeometry',
      })}</div>`,
    ]), state);
  },
};

export default workspace;
