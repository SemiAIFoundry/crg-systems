"""Shared canonical record types.

Normative basis: master specification sections 12, 19, 21, 26, 27, 29, 30.
These types are the contract between modules: geometry, certification,
change, import/export, and verification all speak in terms of them.

The v1.2 phase-binding and certified-change records are additive modules that
compose these stable primitives; the legacy canonical shapes in this file are
therefore intentionally unchanged.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

from .canonical import content_hash
from .completeness import CompletenessBasis
from .envelope import EvidenceClass
from .numeric import DecisionValue, Exact, Interval

__all__ = [
    "Direction",
    "Coordinate",
    "CoordinateSchema",
    "Signature",
    "RealizationRecord",
    "RealizationBundle",
    "Fiber",
    "RRecord",
    "GammaRecord",
    "KRecord",
    "GeometryEnvelope",
    "ObservationLevel",
    "DecisionScope",
    "DerivationRecord",
    "RegretWitness",
    "PruningCertificate",
    "ReplayBinding",
    "CertificatePins",
    "DecisionCertificate",
    "DecisionOutcome",
    "ChangeEvent",
    "ChangeImpactPlan",
    "DeltaCertificate",
]


class Direction:
    MINIMIZE = "MINIMIZE"
    MAXIMIZE = "MAXIMIZE"
    ALL = frozenset({MINIMIZE, MAXIMIZE})


@dataclass(frozen=True)
class Coordinate:
    """One signature coordinate (spec 19.1)."""

    identifier: str
    quantity: str
    unit: str
    direction: str = Direction.MINIMIZE
    accounting_scope: Optional[str] = None

    def __post_init__(self) -> None:
        if self.direction not in Direction.ALL:
            raise ValueError(
                f"unknown optimization direction {self.direction!r}; "
                f"expected one of {sorted(Direction.ALL)}"
            )

    def to_canonical(self) -> dict:
        record = {
            "identifier": self.identifier,
            "quantity": self.quantity,
            "unit": self.unit,
            "direction": self.direction,
        }
        if self.accounting_scope:
            record["accounting_scope"] = self.accounting_scope
        return record


@dataclass(frozen=True)
class CoordinateSchema:
    """Declared coordinate schema.  Coordinate order is part of canonicalization."""

    coordinates: Tuple[Coordinate, ...]
    technology_context: Optional[str] = None

    def __post_init__(self) -> None:
        ids = [c.identifier for c in self.coordinates]
        if len(set(ids)) != len(ids):
            raise ValueError("duplicate coordinate identifiers in schema")

    @property
    def identifiers(self) -> Tuple[str, ...]:
        return tuple(c.identifier for c in self.coordinates)

    @property
    def dimension(self) -> int:
        return len(self.coordinates)

    def index(self, identifier: str) -> int:
        return self.identifiers.index(identifier)

    def to_canonical(self) -> dict:
        record = {"coordinates": [c.to_canonical() for c in self.coordinates]}
        if self.technology_context:
            record["technology_context"] = self.technology_context
        return record

    def schema_hash(self) -> str:
        return content_hash(self.to_canonical())


@dataclass(frozen=True)
class Signature:
    """An exact point in signature space, ordered by the declared schema.

    All coordinates are normalized to MINIMIZE orientation internally so
    that dominance and Pareto logic have a single convention; the schema
    retains the declared direction for reporting.
    """

    values: Tuple[Exact, ...]

    def __init__(self, values: Sequence[Any]) -> None:
        object.__setattr__(self, "values", tuple(v if isinstance(v, Exact) else Exact(v) for v in values))

    def __len__(self) -> int:
        return len(self.values)

    def __getitem__(self, idx: int) -> Exact:
        return self.values[idx]

    def __iter__(self):
        return iter(self.values)

    def dominates(self, other: "Signature") -> bool:
        """Weak dominance in the minimize convention: <= everywhere, < somewhere."""
        if len(self) != len(other):
            raise ValueError("dimension mismatch")
        le = all(a <= b for a, b in zip(self.values, other.values))
        lt = any(a < b for a, b in zip(self.values, other.values))
        return le and lt

    def weakly_dominates(self, other: "Signature") -> bool:
        return all(a <= b for a, b in zip(self.values, other.values))

    def sort_key(self) -> Tuple:
        """Canonical lexicographic ordering by VALUE (spec 19.2, 19.3).

        Fractions are compared by magnitude, not by (numerator, denominator):
        an earlier revision keyed on the pair, which incorrectly ordered 1/2
        before 1/3.  Fraction is exactly comparable, so it is the key itself.
        """
        return tuple(v.value for v in self.values)

    def to_canonical(self) -> list:
        return [v.to_canonical() for v in self.values]

    def __eq__(self, other: Any) -> bool:
        return isinstance(other, Signature) and self.values == other.values

    def __hash__(self) -> int:
        return hash(self.values)


@dataclass
class RealizationRecord:
    """One legal realization (spec 12.1, 28)."""

    realization_id: str
    signature: Signature
    attributes: Dict[str, Any] = field(default_factory=dict)
    legality: str = "LEGAL"
    witness: Optional[str] = None
    parent: Optional[str] = None
    generator: Optional[str] = None
    evidence_class: str = "IMPORTED"

    def to_canonical(self) -> dict:
        record = {
            "realization_id": self.realization_id,
            "signature": self.signature.to_canonical(),
            "legality": self.legality,
            "evidence_class": self.evidence_class,
        }
        if self.attributes:
            record["attributes"] = _canonicalize_attributes(self.attributes)
        for key, value in (
            ("witness", self.witness),
            ("parent", self.parent),
            ("generator", self.generator),
        ):
            if value is not None:
                record[key] = value
        return record


def _canonicalize_attributes(attributes: Dict[str, Any]) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    for key, value in attributes.items():
        if isinstance(value, float):
            raise TypeError(
                f"attribute {key!r} is a float; supply an exact representation"
            )
        out[key] = value
    return out


@dataclass
class RealizationBundle:
    """The represented family plus its completeness basis (spec 28, 21)."""

    bundle_id: str
    schema: CoordinateSchema
    realizations: List[RealizationRecord]
    completeness: CompletenessBasis
    rejected: List[Dict[str, Any]] = field(default_factory=list)
    source_fingerprint: Optional[str] = None

    def to_canonical(self) -> dict:
        record = {
            "bundle_id": self.bundle_id,
            "schema": self.schema.to_canonical(),
            "realizations": [r.to_canonical() for r in sorted(
                self.realizations, key=lambda r: r.realization_id)],
            "completeness": self.completeness.to_canonical(),
        }
        if self.rejected:
            record["rejected"] = self.rejected
        if self.source_fingerprint:
            record["source_fingerprint"] = self.source_fingerprint
        return record

    def bundle_hash(self) -> str:
        return content_hash(self.to_canonical())


@dataclass(frozen=True)
class Fiber:
    """rho^{-1}(r): realizations sharing one signature (spec 19.6)."""

    signature: Signature
    realization_ids: Tuple[str, ...]

    def to_canonical(self) -> dict:
        return {
            "signature": self.signature.to_canonical(),
            "realization_ids": list(self.realization_ids),
        }


@dataclass
class RRecord:
    """Canonical exact finite R (spec 19.2)."""

    schema: CoordinateSchema
    fibers: Tuple[Fiber, ...]
    completeness: CompletenessBasis

    @property
    def signatures(self) -> Tuple[Signature, ...]:
        return tuple(f.signature for f in self.fibers)

    def to_canonical(self) -> dict:
        return {
            "record_type": "R",
            "schema": self.schema.to_canonical(),
            "fibers": [f.to_canonical() for f in self.fibers],
            "completeness": self.completeness.to_canonical(),
        }

    def root_hash(self) -> str:
        return content_hash(self.to_canonical())


@dataclass
class GammaRecord:
    """Canonical finite Gamma: the Pareto-minimal antichain (spec 19.3)."""

    schema: CoordinateSchema
    frontier: Tuple[Signature, ...]
    completeness: CompletenessBasis
    recession_cone: str = "NONNEGATIVE_ORTHANT"
    dominated_available: bool = True

    def to_canonical(self) -> dict:
        return {
            "record_type": "GAMMA",
            "schema": self.schema.to_canonical(),
            "frontier": [s.to_canonical() for s in self.frontier],
            "recession_cone": self.recession_cone,
            "dominated_available": self.dominated_available,
            "completeness": self.completeness.to_canonical(),
        }

    def root_hash(self) -> str:
        return content_hash(self.to_canonical())


@dataclass
class KRecord:
    """Canonical finite K: irredundant extreme vertices + orthant (spec 19.4)."""

    schema: CoordinateSchema
    vertices: Tuple[Signature, ...]
    completeness: CompletenessBasis
    recession_cone: str = "NONNEGATIVE_ORTHANT"
    halfspaces: Optional[Tuple[Dict[str, Any], ...]] = None

    def to_canonical(self) -> dict:
        record = {
            "record_type": "K",
            "schema": self.schema.to_canonical(),
            "vertices": [v.to_canonical() for v in self.vertices],
            "recession_cone": self.recession_cone,
            "completeness": self.completeness.to_canonical(),
        }
        if self.halfspaces:
            record["halfspaces"] = list(self.halfspaces)
        return record

    def root_hash(self) -> str:
        return content_hash(self.to_canonical())


@dataclass
class GeometryEnvelope:
    """Certified inner/outer envelope for approximations (spec 20)."""

    inner: Any
    outer: Any
    inner_evidence_class: str
    outer_evidence_class: str
    error_semantics: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        for field_name, evidence_class in (
            ("inner_evidence_class", self.inner_evidence_class),
            ("outer_evidence_class", self.outer_evidence_class),
        ):
            if evidence_class not in EvidenceClass.ALL:
                raise ValueError(
                    f"{field_name} must be a declared evidence class; got "
                    f"{evidence_class!r}"
                )

    def to_canonical(self) -> dict:
        return {
            "inner": self.inner.to_canonical(),
            "outer": self.outer.to_canonical(),
            "inner_evidence_class": self.inner_evidence_class,
            "outer_evidence_class": self.outer_evidence_class,
            "error_semantics": self.error_semantics,
        }


class ObservationLevel:
    """Required retained object per decision class (spec 29.2)."""

    REALIZATION = "REALIZATION"
    EXACT_REGION = "EXACT_REGION"
    MONOTONE = "MONOTONE"
    ADDITIVE_PRICE = "ADDITIVE_PRICE"
    FINITE_LEDGER = "FINITE_LEDGER"
    APPROXIMATE = "APPROXIMATE"

    REQUIRED_OBJECT = {
        REALIZATION: "REALIZATION_REGISTRY_AND_FIBERS",
        EXACT_REGION: "R",
        MONOTONE: "GAMMA",
        ADDITIVE_PRICE: "K",
        FINITE_LEDGER: "ARGMIN_HITTING_SET",
        APPROXIMATE: "BOUNDED_REGRET_REPRESENTATION",
    }


class DecisionOutcome:
    """Required decision outcomes (specification 29.5 -- "Required outcomes").

    Note on the citation: the v0.2.0 spec places the required-outcome list in
    29.5, not 29.6; the section number here is corrected accordingly.

    Reconciliation with the spec's canonical names.  An earlier revision of
    this module renamed two outcomes and omitted three, relative to 29.5:

      * ``BLOCKED_INCOMPLETE_FAMILY``  was stored as ``BLOCKED_COVERAGE``;
      * ``HEURISTIC_INCUMBENT``        was stored as ``HEURISTIC_ONLY``;
      * ``EXPIRED``, ``REVOKED`` and ``UNVERIFIABLE_REDACTED`` were absent.

    Existing callers (``crg-io`` report rendering and its tests) already emit
    and hash the ``BLOCKED_COVERAGE`` / ``HEURISTIC_ONLY`` string *values*, so
    those values are preserved as the canonical wire form.  The spec's names
    are added as ALIASES pointing to the same values, so code may refer to the
    outcome by either name while a single string is emitted and hashed.  The
    three missing outcomes are added with values equal to their spec names.
    """

    # -- canonical wire values (preserved for hash/back-compat) -------------
    CERTIFIED_WINNER = "CERTIFIED_WINNER"
    CERTIFIED_WINNER_SET = "CERTIFIED_WINNER_SET"
    CERTIFIED_POLICY_TIE = "CERTIFIED_POLICY_TIE"
    POSSIBLE_WINNER_SET = "POSSIBLE_WINNER_SET"
    CERTIFIED_RETENTION = "CERTIFIED_RETENTION"
    AMBIGUOUS = "AMBIGUOUS"
    ALL_INFEASIBLE = "ALL_INFEASIBLE"
    BLOCKED_SCOPE_MISMATCH = "BLOCKED_SCOPE_MISMATCH"
    BLOCKED_INCOMPLETE_EVIDENCE = "BLOCKED_INCOMPLETE_EVIDENCE"
    BLOCKED_GEOMETRY_LOSS = "BLOCKED_GEOMETRY_LOSS"
    BLOCKED_COVERAGE = "BLOCKED_COVERAGE"
    HEURISTIC_ONLY = "HEURISTIC_ONLY"
    STALE = "STALE"

    # -- outcomes added to complete 29.5 ------------------------------------
    EXPIRED = "EXPIRED"
    REVOKED = "REVOKED"
    UNVERIFIABLE_REDACTED = "UNVERIFIABLE_REDACTED"

    # -- specification 29.5 canonical-name aliases --------------------------
    # These resolve to the same stored value as the renamed attributes above,
    # so `DecisionOutcome.BLOCKED_INCOMPLETE_FAMILY is DecisionOutcome.BLOCKED_COVERAGE`.
    BLOCKED_INCOMPLETE_FAMILY = BLOCKED_COVERAGE
    HEURISTIC_INCUMBENT = HEURISTIC_ONLY

    #: The complete set of required outcome VALUES of 29.5 (13 distinct wire
    #: strings; the two aliases share values with their renamed counterparts).
    ALL = frozenset(
        {
            CERTIFIED_WINNER,
            CERTIFIED_WINNER_SET,
            CERTIFIED_POLICY_TIE,
            POSSIBLE_WINNER_SET,
            CERTIFIED_RETENTION,
            AMBIGUOUS,
            ALL_INFEASIBLE,
            BLOCKED_SCOPE_MISMATCH,
            BLOCKED_INCOMPLETE_EVIDENCE,
            BLOCKED_GEOMETRY_LOSS,
            BLOCKED_COVERAGE,
            HEURISTIC_ONLY,
            STALE,
            EXPIRED,
            REVOKED,
            UNVERIFIABLE_REDACTED,
        }
    )


@dataclass
class DecisionScope:
    """A declared decision class (spec 26)."""

    scope_id: str
    observation_level: str
    objective_family: Dict[str, Any]
    technology_domain: Dict[str, Any] = field(default_factory=dict)
    tie_tolerance: Exact = field(default_factory=lambda: Exact(0))
    retain_all_ties: bool = True
    retention_policy: str = "universal-monotone"
    uncertainty_mode: str = "exact"
    validity: Optional[str] = None

    def to_canonical(self) -> dict:
        record = {
            "scope_id": self.scope_id,
            "observation_level": self.observation_level,
            "objective_family": self.objective_family,
            "technology_domain": self.technology_domain,
            "tie_tolerance": self.tie_tolerance.to_canonical(),
            "retain_all_ties": self.retain_all_ties,
            "retention_policy": self.retention_policy,
            "uncertainty_mode": self.uncertainty_mode,
        }
        if self.validity:
            record["validity"] = self.validity
        return record


@dataclass
class DerivationRecord:
    """Query -> decision class -> required object, with the citing rule (spec 26)."""

    query_hash: str
    mapping_table_version: str
    decision_class: str
    required_object: str
    rule_cited: str
    refusals: Sequence[str] = ()
    notes: Sequence[str] = ()

    def to_canonical(self) -> dict:
        record = {
            "query_hash": self.query_hash,
            "mapping_table_version": self.mapping_table_version,
            "decision_class": self.decision_class,
            "required_object": self.required_object,
            "rule_cited": self.rule_cited,
        }
        if self.refusals:
            record["refusals"] = list(self.refusals)
        if self.notes:
            record["notes"] = list(self.notes)
        return record


@dataclass
class RegretWitness:
    """First-class, independently verifiable regret witness (spec 27).

    Construction follows the strict engineering-cost separation corollary:
    Phi(x) = ||(x - a)^+||_inf + eps * sum(x), continuous, coordinatewise
    strictly increasing, and coercive.
    """

    lost_point: Signature
    objective_family: str
    epsilon: Exact
    retained_infimum: Exact
    full_infimum: Exact
    gap: Exact
    evidence_class: str = "EXACT"
    construction: str = "STRICT_INCREASING_COERCIVE_SEPARATION"

    def to_canonical(self) -> dict:
        return {
            "lost_point": self.lost_point.to_canonical(),
            "objective_family": self.objective_family,
            "epsilon": self.epsilon.to_canonical(),
            "retained_infimum": self.retained_infimum.to_canonical(),
            "full_infimum": self.full_infimum.to_canonical(),
            "gap": self.gap.to_canonical(),
            "evidence_class": self.evidence_class,
            "construction": self.construction,
        }


@dataclass
class PruningCertificate:
    """Spec 29.3: the seven conditions that must all hold."""

    pruned_id: str
    lower_bound: Any
    incumbent_id: str
    incumbent_upper: Any
    scope_id: str
    tie_policy_satisfied: bool
    geometry_preserved: bool
    dependencies_valid: bool

    def to_canonical(self) -> dict:
        return {
            "pruned_id": self.pruned_id,
            "lower_bound": self.lower_bound.to_canonical() if hasattr(self.lower_bound, "to_canonical") else self.lower_bound,
            "incumbent_id": self.incumbent_id,
            "incumbent_upper": self.incumbent_upper.to_canonical() if hasattr(self.incumbent_upper, "to_canonical") else self.incumbent_upper,
            "scope_id": self.scope_id,
            "tie_policy_satisfied": self.tie_policy_satisfied,
            "geometry_preserved": self.geometry_preserved,
            "dependencies_valid": self.dependencies_valid,
        }


@dataclass(frozen=True)
class ReplayBinding:
    """The nine disclosures required for a §23.5 operational certificate.

    A replay-bound certificate is issuable only after replay matched.  It is
    deliberately not a proof of mathematical optimality, and the final boolean
    makes that limitation part of the hashed record rather than prose.
    """

    solver_identity: str
    solver_version: str
    parameters: Dict[str, Any]
    seed: Any
    thread_count: int
    platform_profile: str
    numeric_tolerances: Dict[str, Any]
    replay_status: str = "REPLAYED_MATCHED"
    mathematical_optimality_independently_proved: bool = False

    def __post_init__(self) -> None:
        if not self.solver_identity or not self.solver_version or not self.platform_profile:
            raise ValueError("replay binding identity, version, and platform MUST be non-empty")
        if not isinstance(self.parameters, dict) or not isinstance(self.numeric_tolerances, dict):
            raise TypeError("replay parameters and numeric tolerances MUST be mappings")
        if not self.numeric_tolerances:
            raise ValueError("replay binding MUST declare numeric tolerances")
        if isinstance(self.seed, bool) or not isinstance(self.seed, (str, int)):
            raise TypeError("replay seed MUST be a string or integer")
        if isinstance(self.thread_count, bool) or not isinstance(self.thread_count, int) \
                or self.thread_count < 1:
            raise ValueError("replay thread_count MUST be a positive integer")
        if self.replay_status != "REPLAYED_MATCHED":
            raise ValueError("an operational replay certificate requires REPLAYED_MATCHED")
        if self.mathematical_optimality_independently_proved is not False:
            raise ValueError("a replay-bound claim MUST state that optimality was not proved")
        # The canonical hash layer rejects binary floats and non-canonical
        # parameter values.  Exercise it at construction so invalid replay
        # metadata cannot remain latent until certificate serialization.
        content_hash(self.to_canonical())

    def to_canonical(self) -> dict:
        return {
            "solver_identity": self.solver_identity,
            "solver_version": self.solver_version,
            "parameters": self.parameters,
            "seed": self.seed,
            "thread_count": self.thread_count,
            "platform_profile": self.platform_profile,
            "numeric_tolerances": self.numeric_tolerances,
            "replay_status": self.replay_status,
            "mathematical_optimality_independently_proved": False,
        }


@dataclass(frozen=True)
class CertificatePins:
    """All six semantics-bearing version groups required by §15.2."""

    schema_versions: Dict[str, str]
    quantity_registry_version: str
    normative_rule_table_version: str
    crg_vir_version: str
    domain_pack_versions: Dict[str, str]
    proof_checker_versions: Dict[str, str]

    def __post_init__(self) -> None:
        for name in ("schema_versions", "domain_pack_versions", "proof_checker_versions"):
            if not isinstance(getattr(self, name), dict):
                raise TypeError(f"{name} MUST be a mapping")
        if not self.schema_versions:
            raise ValueError("schema_versions MUST identify at least one schema set")
        if not self.proof_checker_versions:
            raise ValueError("proof_checker_versions MUST identify the applicable checkers")
        for name in (
            "quantity_registry_version", "normative_rule_table_version", "crg_vir_version",
        ):
            if not isinstance(getattr(self, name), str) or not getattr(self, name):
                raise ValueError(f"{name} MUST be a non-empty string")
        content_hash(self.to_canonical())

    def to_canonical(self) -> dict:
        return {
            "schema_versions": dict(self.schema_versions),
            "quantity_registry_version": self.quantity_registry_version,
            "normative_rule_table_version": self.normative_rule_table_version,
            "crg_vir_version": self.crg_vir_version,
            "domain_pack_versions": dict(self.domain_pack_versions),
            "proof_checker_versions": dict(self.proof_checker_versions),
        }


@dataclass
class DecisionCertificate:
    """Specification 29.5."""

    certificate_id: str
    outcome: str
    scope: DecisionScope
    derivation: DerivationRecord
    claim_scope: str
    completeness: CompletenessBasis
    complete_registry_hash: str
    retained_registry_hash: str
    semantic_pins: CertificatePins
    selected: Sequence[str] = ()
    ties: Sequence[str] = ()
    runner_up: Optional[str] = None
    objective_values: Dict[str, Any] = field(default_factory=dict)
    margin: Optional[Any] = None
    active_bottlenecks: Sequence[str] = ()
    infeasible: Dict[str, str] = field(default_factory=dict)
    pruning_certificates: Sequence[PruningCertificate] = ()
    geometry_preserved: bool = True
    regret_witness: Optional[RegretWitness] = None
    evidence_roots: Sequence[str] = ()
    dependencies: Sequence[str] = ()
    expiry: Optional[str] = None
    reopen_conditions: Sequence[str] = ()
    engine_versions: Dict[str, str] = field(default_factory=dict)
    replay_binding: Optional[ReplayBinding] = None

    def to_canonical(self) -> dict:
        record = {
            "certificate_id": self.certificate_id,
            "outcome": self.outcome,
            "scope": self.scope.to_canonical(),
            "derivation": self.derivation.to_canonical(),
            "claim_scope": self.claim_scope,
            "completeness": self.completeness.to_canonical(),
            "complete_registry_hash": self.complete_registry_hash,
            "retained_registry_hash": self.retained_registry_hash,
            "semantic_pins": self.semantic_pins.to_canonical(),
            "selected": list(self.selected),
            "ties": list(self.ties),
            "objective_values": self.objective_values,
            "geometry_preserved": self.geometry_preserved,
            "engine_versions": self.engine_versions,
        }
        if self.runner_up:
            record["runner_up"] = self.runner_up
        if self.margin is not None:
            record["margin"] = self.margin.to_canonical() if hasattr(self.margin, "to_canonical") else self.margin
        if self.active_bottlenecks:
            record["active_bottlenecks"] = list(self.active_bottlenecks)
        if self.infeasible:
            record["infeasible"] = self.infeasible
        if self.pruning_certificates:
            record["pruning_certificates"] = [p.to_canonical() for p in self.pruning_certificates]
        if self.regret_witness is not None:
            record["regret_witness"] = self.regret_witness.to_canonical()
        if self.evidence_roots:
            record["evidence_roots"] = list(self.evidence_roots)
        if self.dependencies:
            record["dependencies"] = list(self.dependencies)
        if self.expiry:
            record["expiry"] = self.expiry
        if self.reopen_conditions:
            record["reopen_conditions"] = list(self.reopen_conditions)
        if self.replay_binding is not None:
            record["replay_binding"] = self.replay_binding.to_canonical()
        return record

    def certificate_hash(self) -> str:
        return content_hash(self.to_canonical())


@dataclass
class ChangeEvent:
    """Specification 30."""

    event_id: str
    changed_object: str
    previous_version: Optional[str]
    current_version: str
    declared_reason: str
    changed_properties: Sequence[str] = ()
    timestamp: str = ""
    authority: Optional[str] = None

    def to_canonical(self) -> dict:
        record = {
            "event_id": self.event_id,
            "changed_object": self.changed_object,
            "current_version": self.current_version,
            "declared_reason": self.declared_reason,
            "changed_properties": list(self.changed_properties),
        }
        if self.previous_version:
            record["previous_version"] = self.previous_version
        if self.timestamp:
            record["timestamp"] = self.timestamp
        if self.authority:
            record["authority"] = self.authority
        return record


@dataclass
class ChangeImpactPlan:
    classification: str
    affected: Dict[str, str]
    preserved: Sequence[str] = ()
    invalidated: Sequence[str] = ()
    required_actions: Sequence[str] = ()

    def to_canonical(self) -> dict:
        return {
            "classification": self.classification,
            "affected": self.affected,
            "preserved": list(self.preserved),
            "invalidated": list(self.invalidated),
            "required_actions": list(self.required_actions),
        }


@dataclass
class DeltaCertificate:
    """Specification 30.5."""

    delta_id: str
    prior_root: str
    current_root: str
    change_event: ChangeEvent
    classification: str
    affected_paths: Sequence[str]
    preserved: Sequence[str]
    invalidated: Sequence[str]
    recomputed: Sequence[str]
    prior_winners: Sequence[str]
    current_winners: Sequence[str]
    prior_margin: Optional[Any] = None
    current_margin: Optional[Any] = None
    residual_uncertainty: Optional[str] = None
    approvals: Sequence[str] = ()
    reopen_reason: Optional[str] = None

    def to_canonical(self) -> dict:
        record = {
            "delta_id": self.delta_id,
            "prior_root": self.prior_root,
            "current_root": self.current_root,
            "change_event": self.change_event.to_canonical(),
            "classification": self.classification,
            "affected_paths": list(self.affected_paths),
            "preserved": list(self.preserved),
            "invalidated": list(self.invalidated),
            "recomputed": list(self.recomputed),
            "prior_winners": list(self.prior_winners),
            "current_winners": list(self.current_winners),
        }
        for key, value in (
            ("prior_margin", self.prior_margin),
            ("current_margin", self.current_margin),
        ):
            if value is not None:
                record[key] = value.to_canonical() if hasattr(value, "to_canonical") else value
        if self.residual_uncertainty:
            record["residual_uncertainty"] = self.residual_uncertainty
        if self.approvals:
            record["approvals"] = list(self.approvals)
        if self.reopen_reason:
            record["reopen_reason"] = self.reopen_reason
        return record

    def delta_hash(self) -> str:
        return content_hash(self.to_canonical())
