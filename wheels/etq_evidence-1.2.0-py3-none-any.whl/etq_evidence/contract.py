"""Technology-contract assembly: where the ETQ family meets the CRG family.

Normative basis: master specification 33.6 (technology contract), 33.1
(purpose), 33.3 (applicability), 33.5 (conflict), 33.4 (uncertainty), 21
(completeness of coordinate coverage), 13.3 (unit mismatch), 45 (clock),
and the ETQ disclosure carried forward from v0.1.0 section 18.6:

    rejection of unit mismatch, absent applicability rules, hard context
    exclusions, expired evidence, invalid provenance, and unauthorized
    access.

Those six are :data:`RejectionReason.MANDATORY`.  Each is a distinct code
on a distinct :class:`Rejection`; none of them is ever reported as a
generic assembly failure, because the six have six different remedies.

A contract coordinate is a :class:`BoundedCoordinate`: an exact interval or
a scenario set, the five uncertainty components kept apart, the correlation
assumption that would combine them, lineage hashes back to every evidence
record and every rule that produced it, a validity window, a time judgment
naming the clock it was made against, and its revalidation triggers.  It is
never a bare number, and there is deliberately no accessor that returns one.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

from crg_model.canonical import content_hash
from crg_model.completeness import (
    CompletenessBasis,
    CompletenessBasisType,
    derive_claim_scope,
)
from crg_model.numeric import Interval

from .applicability import (
    ApplicabilityResult,
    ApplicabilityRule,
    ReasonCode,
    select_rule,
)
from .clock import TimeJudgment, ValidityWindow, VerificationClock, evaluate_time
from .conflict import (
    EvidenceRelation,
    RelationKind,
    TransferredEvidence,
    classify_evidence_set,
)
from .record import (
    AccessPolicy,
    ContextDescriptor,
    CorrelationAssumption,
    EvidenceError,
    EvidenceRecord,
    ProvenanceStatus,
    Requester,
    UncertaintyBudget,
)

__all__ = [
    "RejectionReason",
    "Rejection",
    "CoordinateRequest",
    "BoundedCoordinate",
    "CapabilityPredicate",
    "FunctionClass",
    "ContractFunction",
    "Lineage",
    "LineageEdge",
    "CoverageReport",
    "VerificationStatus",
    "TechnologyContract",
    "AssemblyReport",
    "assemble_technology_contract",
    "CONTRACT_REQUIRED_ITEMS",
]


class RejectionReason:
    """Why a coordinate did not enter the contract.

    ``MANDATORY`` is the six-item rejection list the ETQ disclosure
    requires.  The others are the additional refusals sections 33.5, 5.3,
    12, and 45 demand; they are separate codes rather than being folded into
    one of the six, because conflating them would hide which remedy applies.
    """

    # -- the six mandated rejections -----------------------------------
    UNIT_MISMATCH = "UNIT_MISMATCH"
    NO_APPLICABLE_RULE = "NO_APPLICABLE_RULE"
    HARD_CONTEXT_EXCLUSION = "HARD_CONTEXT_EXCLUSION"
    EVIDENCE_EXPIRED = "EVIDENCE_EXPIRED"
    INVALID_PROVENANCE = "INVALID_PROVENANCE"
    UNAUTHORIZED_ACCESS = "UNAUTHORIZED_ACCESS"

    MANDATORY: Tuple[str, ...] = (
        UNIT_MISMATCH,
        NO_APPLICABLE_RULE,
        HARD_CONTEXT_EXCLUSION,
        EVIDENCE_EXPIRED,
        INVALID_PROVENANCE,
        UNAUTHORIZED_ACCESS,
    )

    # -- further distinct refusals --------------------------------------
    CONTRADICTORY_EVIDENCE = "CONTRADICTORY_EVIDENCE"
    CONTEXT_INCOMPARABLE = "CONTEXT_INCOMPARABLE"
    EVIDENCE_SUPERSEDED = "EVIDENCE_SUPERSEDED"
    EVIDENCE_STALE = "EVIDENCE_STALE"
    EVIDENCE_STATUS_BELOW_MINIMUM = "EVIDENCE_STATUS_BELOW_MINIMUM"
    HEURISTIC_MAY_NOT_AUTHORIZE = "HEURISTIC_MAY_NOT_AUTHORIZE"
    QUANTITY_MISMATCH = "QUANTITY_MISMATCH"
    RULE_EXPIRED = "RULE_EXPIRED"
    RULE_AUTHORITY_NOT_RECOGNIZED = "RULE_AUTHORITY_NOT_RECOGNIZED"
    CLOCK_POLICY_VIOLATION = "CLOCK_POLICY_VIOLATION"
    CONTEXT_PATTERN_MISMATCH = "CONTEXT_PATTERN_MISMATCH"
    DIFFERENCE_NOT_PERMITTED = "DIFFERENCE_NOT_PERMITTED"

    ALL = frozenset(MANDATORY) | frozenset(
        {
            CONTRADICTORY_EVIDENCE,
            CONTEXT_INCOMPARABLE,
            EVIDENCE_SUPERSEDED,
            EVIDENCE_STALE,
            EVIDENCE_STATUS_BELOW_MINIMUM,
            HEURISTIC_MAY_NOT_AUTHORIZE,
            QUANTITY_MISMATCH,
            RULE_EXPIRED,
            RULE_AUTHORITY_NOT_RECOGNIZED,
            CLOCK_POLICY_VIOLATION,
            CONTEXT_PATTERN_MISMATCH,
            DIFFERENCE_NOT_PERMITTED,
        }
    )


#: Applicability reason codes -> contract rejection reasons.  Every mapping
#: is explicit; an unmapped code would raise rather than silently become a
#: generic failure.
_APPLICABILITY_TO_REJECTION: Dict[str, str] = {
    ReasonCode.ACCESS_DENIED: RejectionReason.UNAUTHORIZED_ACCESS,
    ReasonCode.QUANTITY_MISMATCH: RejectionReason.QUANTITY_MISMATCH,
    ReasonCode.UNIT_MISMATCH: RejectionReason.UNIT_MISMATCH,
    ReasonCode.OUTPUT_UNIT_MISMATCH: RejectionReason.UNIT_MISMATCH,
    ReasonCode.HARD_CONTEXT_EXCLUSION: RejectionReason.HARD_CONTEXT_EXCLUSION,
    ReasonCode.SOURCE_CONTEXT_PATTERN_MISMATCH: RejectionReason.CONTEXT_PATTERN_MISMATCH,
    ReasonCode.TARGET_CONTEXT_PATTERN_MISMATCH: RejectionReason.CONTEXT_PATTERN_MISMATCH,
    ReasonCode.CONTEXT_TYPE_INCOMPARABLE: RejectionReason.CONTEXT_INCOMPARABLE,
    ReasonCode.EXACT_MATCH_FIELD_DIFFERS: RejectionReason.DIFFERENCE_NOT_PERMITTED,
    ReasonCode.DIFFERENCE_NOT_PERMITTED: RejectionReason.DIFFERENCE_NOT_PERMITTED,
    ReasonCode.EVIDENCE_STATUS_BELOW_MINIMUM: RejectionReason.EVIDENCE_STATUS_BELOW_MINIMUM,
    ReasonCode.HEURISTIC_MAY_NOT_AUTHORIZE: RejectionReason.HEURISTIC_MAY_NOT_AUTHORIZE,
    ReasonCode.EVIDENCE_SUPERSEDED: RejectionReason.EVIDENCE_SUPERSEDED,
    ReasonCode.EVIDENCE_NOT_ACTIVE: RejectionReason.EVIDENCE_SUPERSEDED,
    ReasonCode.EVIDENCE_EXPIRED: RejectionReason.EVIDENCE_EXPIRED,
    ReasonCode.EVIDENCE_NOT_YET_VALID: RejectionReason.EVIDENCE_EXPIRED,
    ReasonCode.EVIDENCE_STALE: RejectionReason.EVIDENCE_STALE,
    ReasonCode.RULE_EXPIRED: RejectionReason.RULE_EXPIRED,
    ReasonCode.CLOCK_POLICY_VIOLATION: RejectionReason.CLOCK_POLICY_VIOLATION,
    ReasonCode.NO_APPLICABLE_RULE: RejectionReason.NO_APPLICABLE_RULE,
    ReasonCode.NO_RULES_DECLARED: RejectionReason.NO_APPLICABLE_RULE,
}


@dataclass(frozen=True)
class Rejection:
    """One refusal, with its own code and its own citation."""

    reason_code: str
    spec_citation: str
    detail: str
    coordinate_id: Optional[str] = None
    evidence_id: Optional[str] = None
    rule_id: Optional[str] = None
    evidence_hash: Optional[str] = None
    rule_hash: Optional[str] = None

    def __post_init__(self) -> None:
        if self.reason_code not in RejectionReason.ALL:
            raise EvidenceError(f"unknown rejection reason {self.reason_code!r}")

    @property
    def is_mandatory_reason(self) -> bool:
        return self.reason_code in RejectionReason.MANDATORY

    def to_canonical(self) -> dict:
        record: dict = {
            "reason_code": self.reason_code,
            "spec_citation": self.spec_citation,
            "detail": self.detail,
        }
        for key, value in (
            ("coordinate_id", self.coordinate_id),
            ("evidence_id", self.evidence_id),
            ("rule_id", self.rule_id),
            ("evidence_hash", self.evidence_hash),
            ("rule_hash", self.rule_hash),
        ):
            if value is not None:
                record[key] = value
        return record


_CITATIONS: Dict[str, str] = {
    RejectionReason.UNIT_MISMATCH: "13.3, 33.7",
    RejectionReason.NO_APPLICABLE_RULE: "33.3, 33.7",
    RejectionReason.HARD_CONTEXT_EXCLUSION: "33.3, 33.7",
    RejectionReason.EVIDENCE_EXPIRED: "33.5, 45.4, 33.7",
    RejectionReason.INVALID_PROVENANCE: "33.2, 6.4, 33.7",
    RejectionReason.UNAUTHORIZED_ACCESS: "33.2, 44.2, 33.7",
    RejectionReason.CONTRADICTORY_EVIDENCE: "33.5",
    RejectionReason.CONTEXT_INCOMPARABLE: "33.5",
    RejectionReason.EVIDENCE_SUPERSEDED: "33.5, 12",
    RejectionReason.EVIDENCE_STALE: "45.4",
    RejectionReason.EVIDENCE_STATUS_BELOW_MINIMUM: "33.3",
    RejectionReason.HEURISTIC_MAY_NOT_AUTHORIZE: "5.3",
    RejectionReason.QUANTITY_MISMATCH: "13.1, 13.4",
    RejectionReason.RULE_EXPIRED: "33.3, 45.4",
    RejectionReason.RULE_AUTHORITY_NOT_RECOGNIZED: "33.3, 44.2",
    RejectionReason.CLOCK_POLICY_VIOLATION: "45.4",
    RejectionReason.CONTEXT_PATTERN_MISMATCH: "33.3",
    RejectionReason.DIFFERENCE_NOT_PERMITTED: "33.3",
}


# ---------------------------------------------------------------------------
# requested coverage
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class CoordinateRequest:
    """A coordinate the contract is asked to cover.

    Declaring the requested set is what makes "completeness of coordinate
    coverage" (33.6) a checkable claim rather than a description of whatever
    happened to succeed.
    """

    coordinate_id: str
    quantity: str
    unit: str
    direction: str = "MINIMIZE"
    required: bool = True

    def to_canonical(self) -> dict:
        return {
            "coordinate_id": self.coordinate_id,
            "quantity": self.quantity,
            "unit": self.unit,
            "direction": self.direction,
            "required": self.required,
        }


# ---------------------------------------------------------------------------
# lineage (33.6 "evidence and rule lineage")
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class LineageEdge:
    """One evidence record, through one rule, into one coordinate."""

    coordinate_id: str
    evidence_id: str
    evidence_hash: str
    rule_id: str
    rule_hash: str
    source_context_fingerprint: str
    target_context_fingerprint: str

    def to_canonical(self) -> dict:
        return {
            "coordinate_id": self.coordinate_id,
            "evidence_id": self.evidence_id,
            "evidence_hash": self.evidence_hash,
            "rule_id": self.rule_id,
            "rule_hash": self.rule_hash,
            "source_context_fingerprint": self.source_context_fingerprint,
            "target_context_fingerprint": self.target_context_fingerprint,
        }


@dataclass(frozen=True)
class Lineage:
    """Complete evidence-and-rule lineage for a contract (33.6, 6.4)."""

    edges: Tuple[LineageEdge, ...] = ()

    @property
    def evidence_hashes(self) -> Tuple[str, ...]:
        return tuple(sorted({e.evidence_hash for e in self.edges}))

    @property
    def rule_hashes(self) -> Tuple[str, ...]:
        return tuple(sorted({e.rule_hash for e in self.edges}))

    @property
    def evidence_ids(self) -> Tuple[str, ...]:
        return tuple(sorted({e.evidence_id for e in self.edges}))

    @property
    def rule_ids(self) -> Tuple[str, ...]:
        return tuple(sorted({e.rule_id for e in self.edges}))

    def for_coordinate(self, coordinate_id: str) -> Tuple[LineageEdge, ...]:
        return tuple(e for e in self.edges if e.coordinate_id == coordinate_id)

    def to_canonical(self) -> dict:
        return {
            "edges": [e.to_canonical() for e in self.edges],
            "evidence_hashes": list(self.evidence_hashes),
            "rule_hashes": list(self.rule_hashes),
            "evidence_ids": list(self.evidence_ids),
            "rule_ids": list(self.rule_ids),
        }

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())


# ---------------------------------------------------------------------------
# bounded coordinates (33.6, first item)
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class BoundedCoordinate:
    """A contract coordinate: an interval or scenario set, plus its lineage.

    This type has no ``value`` attribute, no ``__float__``, and no midpoint
    accessor.  A technology contract that could hand out a bare number would
    have concealed exactly the transfer uncertainty 33.1 forbids concealing.
    """

    coordinate_id: str
    quantity: str
    unit: str
    direction: str
    bound: Interval
    uncertainty: UncertaintyBudget
    correlation_assumption: str
    uncertainty_statement: str
    bound_derivation: str
    relation: str
    evidence_ids: Tuple[str, ...]
    evidence_hashes: Tuple[str, ...]
    rule_ids: Tuple[str, ...]
    rule_hashes: Tuple[str, ...]
    source_context_fingerprints: Tuple[str, ...]
    target_context_fingerprint: str
    validity: ValidityWindow
    time_judgment: TimeJudgment
    revalidation_triggers: Tuple[str, ...] = ()
    scenarios: Tuple[Tuple[str, Interval], ...] = ()
    access: AccessPolicy = field(default_factory=AccessPolicy)
    notes: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not isinstance(self.bound, Interval):
            raise EvidenceError(
                "a technology-contract coordinate is an interval or a scenario set, "
                "never a bare number (spec 33.6)"
            )
        if self.correlation_assumption not in CorrelationAssumption.ALL:
            raise EvidenceError(
                f"coordinate {self.coordinate_id!r} carries no stated correlation "
                "assumption; spec 33.4 requires one"
            )
        if not self.evidence_hashes or not self.rule_hashes:
            raise EvidenceError(
                f"coordinate {self.coordinate_id!r} has no evidence or rule lineage; "
                "spec 33.6 requires both"
            )

    @property
    def has_scenarios(self) -> bool:
        return bool(self.scenarios)

    @property
    def time_status(self) -> str:
        return self.time_judgment.time_status

    def to_canonical(self) -> dict:
        record: dict = {
            "coordinate_id": self.coordinate_id,
            "quantity": self.quantity,
            "unit": self.unit,
            "direction": self.direction,
            "bound": self.bound.to_canonical(),
            "uncertainty_components": self.uncertainty.to_canonical(),
            "correlation_assumption": self.correlation_assumption,
            "uncertainty_statement": self.uncertainty_statement,
            "bound_derivation": self.bound_derivation,
            "evidence_relation": self.relation,
            "evidence_ids": list(self.evidence_ids),
            "evidence_hashes": list(self.evidence_hashes),
            "rule_ids": list(self.rule_ids),
            "rule_hashes": list(self.rule_hashes),
            "source_context_fingerprints": list(self.source_context_fingerprints),
            "target_context_fingerprint": self.target_context_fingerprint,
            "validity": self.validity.to_canonical(),
            "time_judgment": self.time_judgment.to_canonical(),
            "revalidation_triggers": list(self.revalidation_triggers),
            "access_policy": self.access.to_canonical(),
        }
        if self.scenarios:
            record["scenarios"] = [
                {"scenario": name, "interval": iv.to_canonical()} for name, iv in self.scenarios
            ]
        if self.notes:
            record["notes"] = list(self.notes)
        return record

    def lineage_hash(self) -> str:
        return content_hash(
            {
                "coordinate_id": self.coordinate_id,
                "evidence_hashes": list(self.evidence_hashes),
                "rule_hashes": list(self.rule_hashes),
                "target_context_fingerprint": self.target_context_fingerprint,
            }
        )


# ---------------------------------------------------------------------------
# predicates and functions (33.6 items 2-5)
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class CapabilityPredicate:
    """A checkable capability claim, derived from a bounded coordinate."""

    predicate_id: str
    coordinate_id: str
    relation: str
    bound: Interval
    basis: str
    evidence_hashes: Tuple[str, ...] = ()
    rule_hashes: Tuple[str, ...] = ()

    def holds(self, candidate: Interval) -> bool:
        if self.relation == "WITHIN":
            return self.bound.lo <= candidate.lo and candidate.hi <= self.bound.hi
        if self.relation == "AT_MOST":
            return candidate.hi <= self.bound.hi
        if self.relation == "AT_LEAST":
            return candidate.lo >= self.bound.lo
        raise EvidenceError(f"unknown capability relation {self.relation!r}")

    def to_canonical(self) -> dict:
        return {
            "predicate_id": self.predicate_id,
            "coordinate_id": self.coordinate_id,
            "relation": self.relation,
            "bound": self.bound.to_canonical(),
            "basis": self.basis,
            "evidence_hashes": list(self.evidence_hashes),
            "rule_hashes": list(self.rule_hashes),
        }


class FunctionClass:
    PRICE = "PRICE"
    SERVICE = "SERVICE"
    FEASIBILITY = "FEASIBILITY"
    EMBEDDING = "EMBEDDING"

    ALL = frozenset({PRICE, SERVICE, FEASIBILITY, EMBEDDING})


@dataclass(frozen=True)
class ContractFunction:
    """A price, service, feasibility, or embedding function (33.6).

    Every function carries its own lineage.  A price function with no
    evidence behind it is a declaration, and it is recorded as one
    (``basis``), not passed off as measured.
    """

    function_id: str
    function_class: str
    form: str
    basis: str
    coordinate_id: Optional[str] = None
    domain: Optional[Interval] = None
    parameters: Tuple[Tuple[str, str], ...] = ()
    evidence_hashes: Tuple[str, ...] = ()
    rule_hashes: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if self.function_class not in FunctionClass.ALL:
            raise EvidenceError(f"unknown contract function class {self.function_class!r}")
        if not self.basis:
            raise EvidenceError(
                f"function {self.function_id!r} declares no basis; a contract function "
                "without a stated basis conceals whether it is measured or declared (33.6)"
            )

    def to_canonical(self) -> dict:
        record: dict = {
            "function_id": self.function_id,
            "function_class": self.function_class,
            "form": self.form,
            "basis": self.basis,
            "evidence_hashes": list(self.evidence_hashes),
            "rule_hashes": list(self.rule_hashes),
        }
        if self.coordinate_id:
            record["coordinate_id"] = self.coordinate_id
        if self.domain is not None:
            record["domain"] = self.domain.to_canonical()
        if self.parameters:
            record["parameters"] = {k: v for k, v in self.parameters}
        return record


# ---------------------------------------------------------------------------
# coverage (33.6 "completeness of coordinate coverage", spec 21)
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class CoverageReport:
    """Which requested coordinates the contract actually covers.

    The completeness basis and claim scope come from :mod:`crg_model`, so a
    technology contract's coverage claim is governed by the same section 21
    machinery as a decision certificate's: an uncovered required coordinate
    degrades the basis to ``KNOWN_INCOMPLETE`` and the scope to
    ``PARTIAL_FAMILY``, and no caller can strengthen it after the fact.
    """

    requested: Tuple[str, ...]
    covered: Tuple[str, ...]
    uncovered: Tuple[str, ...]
    uncovered_required: Tuple[str, ...]
    basis: CompletenessBasis
    claim_scope: str

    @property
    def complete(self) -> bool:
        return not self.uncovered_required

    def to_canonical(self) -> dict:
        return {
            "requested_coordinates": list(self.requested),
            "covered_coordinates": list(self.covered),
            "uncovered_coordinates": list(self.uncovered),
            "uncovered_required_coordinates": list(self.uncovered_required),
            "completeness_basis": self.basis.to_canonical(),
            "claim_scope": self.claim_scope,
            "coverage_complete": self.complete,
        }


class VerificationStatus:
    """The contract's own verification status (33.6, final item)."""

    VERIFIED = "VERIFIED"
    TIME_INDETERMINATE = "TIME_INDETERMINATE"
    INCOMPLETE_COVERAGE = "INCOMPLETE_COVERAGE"
    REJECTED = "REJECTED"
    EMPTY = "EMPTY"

    ALL = frozenset({VERIFIED, TIME_INDETERMINATE, INCOMPLETE_COVERAGE, REJECTED, EMPTY})


#: The twelve items specification 33.6 says a technology contract MUST
#: contain.  :meth:`TechnologyContract.check_required_items` reports the
#: presence of each, so an empty item is disclosed rather than assumed.
CONTRACT_REQUIRED_ITEMS: Tuple[str, ...] = (
    "bounded_coordinates",
    "capability_predicates",
    "price_functions",
    "service_functions",
    "feasibility_functions",
    "embedding_constraints",
    "uncertainty_or_scenarios",
    "evidence_and_rule_lineage",
    "validity",
    "access_policy",
    "coordinate_coverage",
    "revalidation_triggers",
    "verification_status",
)


@dataclass(frozen=True)
class TechnologyContract:
    """The output object of 33.6, with all thirteen required items as fields."""

    contract_id: str
    target_context: ContextDescriptor
    bounded_coordinates: Tuple[BoundedCoordinate, ...]
    capability_predicates: Tuple[CapabilityPredicate, ...]
    price_functions: Tuple[ContractFunction, ...]
    service_functions: Tuple[ContractFunction, ...]
    feasibility_functions: Tuple[ContractFunction, ...]
    embedding_constraints: Tuple[ContractFunction, ...]
    lineage: Lineage
    validity: ValidityWindow
    access_policy: AccessPolicy
    coverage: CoverageReport
    revalidation_triggers: Tuple[str, ...]
    verification_status: str
    time_judgment: TimeJudgment
    correlation_assumption: str
    schema_version: str = "0.2.0"

    def __post_init__(self) -> None:
        if self.verification_status not in VerificationStatus.ALL:
            raise EvidenceError(f"unknown verification status {self.verification_status!r}")

    # -- accessors -------------------------------------------------------
    def coordinate(self, coordinate_id: str) -> BoundedCoordinate:
        for coordinate in self.bounded_coordinates:
            if coordinate.coordinate_id == coordinate_id:
                return coordinate
        raise KeyError(
            f"coordinate {coordinate_id!r} is not in this contract; it was not assembled, "
            "and an absent coordinate has no default value (spec 33.3)"
        )

    def has(self, coordinate_id: str) -> bool:
        return any(c.coordinate_id == coordinate_id for c in self.bounded_coordinates)

    @property
    def coordinate_ids(self) -> Tuple[str, ...]:
        return tuple(c.coordinate_id for c in self.bounded_coordinates)

    @property
    def scenario_sets(self) -> Tuple[Tuple[str, Tuple[Tuple[str, Interval], ...]], ...]:
        return tuple(
            (c.coordinate_id, c.scenarios) for c in self.bounded_coordinates if c.has_scenarios
        )

    def check_required_items(self) -> Dict[str, str]:
        """Report presence of each 33.6 item as PRESENT or EMPTY."""
        present = {
            "bounded_coordinates": bool(self.bounded_coordinates),
            "capability_predicates": bool(self.capability_predicates),
            "price_functions": bool(self.price_functions),
            "service_functions": bool(self.service_functions),
            "feasibility_functions": bool(self.feasibility_functions),
            "embedding_constraints": bool(self.embedding_constraints),
            "uncertainty_or_scenarios": any(
                not c.uncertainty.is_empty or c.has_scenarios for c in self.bounded_coordinates
            ),
            "evidence_and_rule_lineage": bool(self.lineage.edges),
            "validity": True,
            "access_policy": True,
            "coordinate_coverage": True,
            "revalidation_triggers": bool(self.revalidation_triggers),
            "verification_status": True,
        }
        return {name: ("PRESENT" if present[name] else "EMPTY") for name in CONTRACT_REQUIRED_ITEMS}

    # -- the CRG hand-off -------------------------------------------------
    def to_technology_domain(self) -> Dict[str, List[str]]:
        """Render the bounded coordinates as a decision-scope technology domain.

        This is the seam between the ETQ family and the CRG family: the value
        goes straight into the ``technology_domain`` field of a decision query
        (spec 26.2) and becomes the domain the certifier and the independent
        verifier both re-derive feasibility against.

        Each entry is ``[lo, hi]`` as exact rational strings, so no binary
        float crosses the boundary (14.2) and the query hash is stable.
        Coordinates that were rejected are simply absent -- an absent
        coordinate constrains nothing and asserts nothing, which is the
        correct rendering of ``UNSUPPORTED`` (33.3).
        """
        return {
            c.coordinate_id: [str(c.bound.lo), str(c.bound.hi)]
            for c in self.bounded_coordinates
        }

    def to_canonical(self) -> dict:
        return {
            "record_type": "etq.technology_contract",
            "spec_section": "33.6",
            "schema_version": self.schema_version,
            "contract_id": self.contract_id,
            "target_context": self.target_context.to_canonical(),
            "bounded_coordinates": [c.to_canonical() for c in self.bounded_coordinates],
            "capability_predicates": [p.to_canonical() for p in self.capability_predicates],
            "price_functions": [f.to_canonical() for f in self.price_functions],
            "service_functions": [f.to_canonical() for f in self.service_functions],
            "feasibility_functions": [f.to_canonical() for f in self.feasibility_functions],
            "embedding_constraints": [f.to_canonical() for f in self.embedding_constraints],
            "evidence_and_rule_lineage": self.lineage.to_canonical(),
            "validity": self.validity.to_canonical(),
            "access_policy": self.access_policy.to_canonical(),
            "coordinate_coverage": self.coverage.to_canonical(),
            "revalidation_triggers": list(self.revalidation_triggers),
            "verification_status": self.verification_status,
            "time_judgment": self.time_judgment.to_canonical(),
            "correlation_assumption": self.correlation_assumption,
            "required_items": self.check_required_items(),
        }

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())


# ---------------------------------------------------------------------------
# the assembly report
# ---------------------------------------------------------------------------
@dataclass
class AssemblyReport:
    """What assembly did, refused, and disclosed."""

    contract_id: str
    target_context_fingerprint: str
    requested: Tuple[str, ...] = ()
    accepted: Tuple[str, ...] = ()
    rejections: Tuple[Rejection, ...] = ()
    warnings: Tuple[str, ...] = ()
    notes: Tuple[str, ...] = ()
    relations: Tuple[Tuple[str, EvidenceRelation], ...] = ()
    applicability_results: Tuple[ApplicabilityResult, ...] = ()
    clock: VerificationClock = field(default_factory=VerificationClock.absent)
    rule_declaration_audit: Tuple[Tuple[str, Dict[str, bool]], ...] = ()

    def reasons(self) -> Tuple[str, ...]:
        return tuple(sorted({r.reason_code for r in self.rejections}))

    def rejections_for(self, coordinate_id: str) -> Tuple[Rejection, ...]:
        return tuple(r for r in self.rejections if r.coordinate_id == coordinate_id)

    def rejected_coordinates(self) -> Tuple[str, ...]:
        return tuple(
            sorted({r.coordinate_id for r in self.rejections if r.coordinate_id is not None})
        )

    def relation_for(self, coordinate_id: str) -> Optional[EvidenceRelation]:
        for cid, relation in self.relations:
            if cid == coordinate_id:
                return relation
        return None

    @property
    def mandatory_reasons_raised(self) -> Tuple[str, ...]:
        return tuple(sorted(set(self.reasons()) & set(RejectionReason.MANDATORY)))

    def to_canonical(self) -> dict:
        return {
            "record_type": "etq.assembly_report",
            "contract_id": self.contract_id,
            "target_context_fingerprint": self.target_context_fingerprint,
            "requested_coordinates": list(self.requested),
            "accepted_coordinates": list(self.accepted),
            "rejections": [r.to_canonical() for r in self.rejections],
            "warnings": list(self.warnings),
            "notes": list(self.notes),
            "relations": [
                {"coordinate_id": cid, **relation.to_canonical()} for cid, relation in self.relations
            ],
            "applicability_results": [r.to_canonical() for r in self.applicability_results],
            "clock_disclosure": self.clock.to_canonical(),
            "rule_declaration_audit": [
                {"rule_id": rid, "declared": audit} for rid, audit in self.rule_declaration_audit
            ],
        }

    def render(self, width: int = 88) -> str:  # pragma: no cover - display only
        lines = [
            "TECHNOLOGY CONTRACT ASSEMBLY (spec 33.6)".ljust(width),
            "-" * width,
            f"contract              {self.contract_id}",
            f"target context        {self.target_context_fingerprint}",
            f"verifier clock        {self.clock.evaluation_time or '(none supplied)'} "
            f"[{self.clock.source}, trust {self.clock.trust_level}]",
            f"requested             {', '.join(self.requested) or '(none)'}",
            f"accepted              {', '.join(self.accepted) or '(none)'}",
        ]
        if self.rejections:
            lines.append("rejections")
            for rejection in self.rejections:
                lines.append(
                    f"  [{rejection.reason_code}] (spec {rejection.spec_citation}) "
                    f"{rejection.coordinate_id or '-'} / {rejection.evidence_id or '-'}"
                )
                lines.append(f"      {rejection.detail}")
        if self.warnings:
            lines.append("warnings")
            lines.extend(f"  ! {w}" for w in self.warnings)
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# assembly (33.6)
# ---------------------------------------------------------------------------
def assemble_technology_contract(
    evidence: Sequence[EvidenceRecord],
    rules: Sequence[ApplicabilityRule],
    target_context: ContextDescriptor,
    *,
    clock: Optional[VerificationClock] = None,
    requester: Optional[Requester] = None,
    coordinates: Optional[Sequence[CoordinateRequest]] = None,
    correlation: str = CorrelationAssumption.UNKNOWN,
    declared_functions: Sequence[ContractFunction] = (),
    trusted_authorities: Optional[Sequence[str]] = None,
    contract_id: str = "technology-contract",
    declared_universe: str = "requested coordinate set",
    comparable_fields: Sequence[str] = (),
) -> Tuple[TechnologyContract, AssemblyReport]:
    """Assemble a technology contract for ``target_context`` (spec 33.6).

    The pipeline is 33.2 -> 33.3 -> 33.5 -> 33.6, with 45 applied throughout:

    1. **Provenance** (33.2, 6.4).  A record whose ``P`` is not ``VALID``
       never reaches a rule.
    2. **Applicability** (33.3).  Each record is offered to every rule.  No
       rule applying is ``UNSUPPORTED`` and produces
       ``NO_APPLICABLE_RULE`` -- never a default coordinate.
    3. **Conflict** (33.5).  The records that were carried into each
       coordinate are classified.  ``CONTRADICTORY`` blocks that coordinate;
       nothing is averaged.
    4. **Contract** (33.6).  Surviving coordinates become bounded
       coordinates with lineage, and coverage is reported against the
       requested set under a section 21 completeness basis.

    ``clock`` is the verifier's clock and there is no default instant.  With
    no clock, expiry is undecided: the contract is still assembled, its
    verification status is ``TIME_INDETERMINATE``, and the report warns.
    That is neither a silent pass nor a violation (45.4, 45.5).
    """
    clock = clock or VerificationClock.absent()
    target_fp = target_context.fingerprint()
    rejections: List[Rejection] = []
    warnings: List[str] = []
    notes: List[str] = []
    all_results: List[ApplicabilityResult] = []

    def reject(reason: str, detail: str, **kwargs: Any) -> None:
        rejections.append(
            Rejection(
                reason_code=reason,
                spec_citation=_CITATIONS[reason],
                detail=detail,
                **kwargs,
            )
        )

    # -- 0: rule authority (33.3) -----------------------------------------
    usable_rules: List[ApplicabilityRule] = []
    for rule in rules:
        if trusted_authorities is not None and rule.authority not in trusted_authorities:
            reject(
                RejectionReason.RULE_AUTHORITY_NOT_RECOGNIZED,
                (
                    f"rule {rule.rule_id!r} is issued by authority {rule.authority!r}, which "
                    f"is not in the declared trusted set {sorted(trusted_authorities)}"
                ),
                rule_id=rule.rule_id,
                rule_hash=rule.fingerprint(),
                coordinate_id=rule.target_coordinate,
            )
            continue
        usable_rules.append(rule)

    # -- 1: provenance (33.2, 6.4) ----------------------------------------
    admissible: List[EvidenceRecord] = []
    for record in evidence:
        status = record.provenance_status()
        if status != ProvenanceStatus.VALID:
            reject(
                RejectionReason.INVALID_PROVENANCE,
                (
                    f"evidence {record.evidence_id!r} has provenance status {status}: "
                    f"source {record.provenance.source_id!r}, issuer "
                    f"{record.provenance.issuer!r}, integrity "
                    f"{record.provenance.integrity!r}, chain of "
                    f"{len(record.provenance.chain)} link(s).  Provenance is immutable and "
                    "checkable or the record does not carry (spec 6.4)"
                ),
                evidence_id=record.evidence_id,
                evidence_hash=record.fingerprint(),
            )
            continue
        admissible.append(record)

    # -- 2: applicability (33.3) ------------------------------------------
    carried: Dict[str, List[TransferredEvidence]] = {}
    for record in admissible:
        applied, results = select_rule(
            record, usable_rules, target_context, clock=clock, requester=requester
        )
        all_results.extend(results)
        if applied is None:
            # Report every distinct reason this record failed, so unit
            # mismatch, exclusion, expiry, and access each surface as
            # themselves rather than as one aggregate "unsupported".
            seen: set = set()
            for result in results:
                reason = _APPLICABILITY_TO_REJECTION.get(result.reason_code)
                if reason is None:  # pragma: no cover - table is total
                    raise EvidenceError(
                        f"applicability reason {result.reason_code!r} has no declared "
                        "contract rejection mapping; a generic failure is not permitted"
                    )
                key = (reason, result.rule_id)
                if key in seen:
                    continue
                seen.add(key)
                reject(
                    reason,
                    result.detail,
                    coordinate_id=result.coordinate_id,
                    evidence_id=result.evidence_id,
                    rule_id=result.rule_id,
                    evidence_hash=result.evidence_hash,
                    rule_hash=result.rule_hash,
                )
            continue
        carried.setdefault(applied.coordinate_id or record.quantity, []).append(
            TransferredEvidence(evidence=record, result=applied)
        )

    # -- requested coverage -------------------------------------------------
    if coordinates is None:
        requested = tuple(
            sorted({rule.target_coordinate for rule in usable_rules} | set(carried))
        )
        requests = tuple(
            CoordinateRequest(
                coordinate_id=cid,
                quantity=_first_quantity(cid, usable_rules, carried),
                unit=_first_unit(cid, usable_rules, carried),
            )
            for cid in requested
        )
        notes.append(
            "no explicit coordinate request was supplied; the requested set was derived "
            "from the declared rules, so coverage is reported relative to the rule set "
            "rather than to an independently declared universe (spec 21.2)"
        )
    else:
        requests = tuple(coordinates)
        requested = tuple(r.coordinate_id for r in requests)

    # -- 3: conflict (33.5), then 4: coordinates (33.6) --------------------
    built: List[BoundedCoordinate] = []
    relations: List[Tuple[str, EvidenceRelation]] = []
    lineage_edges: List[LineageEdge] = []

    for request in requests:
        members = carried.get(request.coordinate_id, [])
        if not members:
            if not any(r.coordinate_id == request.coordinate_id for r in rejections):
                reject(
                    RejectionReason.NO_APPLICABLE_RULE,
                    (
                        f"no evidence was carried into coordinate {request.coordinate_id!r} "
                        f"for target context {target_context.context_id!r}.  No applicable "
                        "rule means UNSUPPORTED, not an assumed default (spec 33.3)"
                    ),
                    coordinate_id=request.coordinate_id,
                )
            else:
                reject(
                    RejectionReason.NO_APPLICABLE_RULE,
                    (
                        f"coordinate {request.coordinate_id!r} is UNSUPPORTED: every "
                        "candidate record was refused above and no rule carried any "
                        "evidence into it (spec 33.3)"
                    ),
                    coordinate_id=request.coordinate_id,
                )
            continue

        relation = classify_evidence_set(
            members,
            clock=clock,
            requester=requester,
            correlation=correlation,
            comparable_fields=comparable_fields,
        )
        relations.append((request.coordinate_id, relation))

        if not relation.fusible:
            reason = {
                RelationKind.CONTRADICTORY: RejectionReason.CONTRADICTORY_EVIDENCE,
                RelationKind.CONTEXT_INCOMPARABLE: RejectionReason.CONTEXT_INCOMPARABLE,
                RelationKind.EXPIRED: RejectionReason.EVIDENCE_EXPIRED,
                RelationKind.SUPERSEDED: RejectionReason.EVIDENCE_SUPERSEDED,
                RelationKind.UNAUTHORIZED: RejectionReason.UNAUTHORIZED_ACCESS,
                RelationKind.UNSUPPORTED: RejectionReason.NO_APPLICABLE_RULE,
            }[relation.relation]
            reject(
                reason,
                (
                    f"coordinate {request.coordinate_id!r} is blocked by evidence relation "
                    f"{relation.relation}: {relation.refusal}"
                ),
                coordinate_id=request.coordinate_id,
            )
            continue

        # unit discipline at the output side (13.3)
        if relation.unit is not None and relation.unit != request.unit:
            reject(
                RejectionReason.UNIT_MISMATCH,
                (
                    f"coordinate {request.coordinate_id!r} was requested in "
                    f"{request.unit!r} but the applicable rules produce {relation.unit!r}, "
                    "and no registered conversion was declared for the output side "
                    "(spec 13.3)"
                ),
                coordinate_id=request.coordinate_id,
            )
            continue

        assert relation.fused_interval is not None
        budget = relation.fused_budget or UncertaintyBudget()
        combination = budget.combine_detail(correlation=correlation)

        validity = members[0].result.validity or members[0].evidence.validity
        for member in members[1:]:
            validity = validity.intersect(member.result.validity or member.evidence.validity)
        access = members[0].evidence.access
        for member in members[1:]:
            access = access.intersect(member.evidence.access)

        triggers = sorted(
            {t for m in members for t in (m.result.validity or m.evidence.validity).revalidation_triggers}
        )
        judgment = evaluate_time(validity, clock)
        scenarios: List[Tuple[str, Interval]] = []
        for member in members:
            scenarios.extend(member.result.scenario_values)

        edges = tuple(
            LineageEdge(
                coordinate_id=request.coordinate_id,
                evidence_id=m.evidence.evidence_id,
                evidence_hash=m.result.evidence_hash,
                rule_id=str(m.result.rule_id),
                rule_hash=str(m.result.rule_hash),
                source_context_fingerprint=m.result.source_context_fingerprint,
                target_context_fingerprint=m.result.target_context_fingerprint,
            )
            for m in members
        )
        lineage_edges.extend(edges)

        coordinate_notes = list(relation.notes)
        if judgment.indeterminate:
            coordinate_notes.append(
                f"time status TIME_INDETERMINATE: {judgment.detail}.  Disclosed, not "
                "treated as CURRENT (spec 45.5)"
            )
        for member in members:
            coordinate_notes.extend(member.result.notes)

        built.append(
            BoundedCoordinate(
                coordinate_id=request.coordinate_id,
                quantity=relation.quantity or request.quantity,
                unit=relation.unit or request.unit,
                direction=request.direction,
                bound=relation.fused_interval,
                uncertainty=budget,
                correlation_assumption=correlation,
                uncertainty_statement=combination.statement,
                bound_derivation=relation.fusion_rule,
                relation=relation.relation,
                evidence_ids=tuple(sorted({e.evidence_id for e in edges})),
                evidence_hashes=tuple(sorted({e.evidence_hash for e in edges})),
                rule_ids=tuple(sorted({e.rule_id for e in edges})),
                rule_hashes=tuple(sorted({e.rule_hash for e in edges})),
                source_context_fingerprints=tuple(
                    sorted({e.source_context_fingerprint for e in edges})
                ),
                target_context_fingerprint=target_fp,
                validity=validity,
                time_judgment=judgment,
                revalidation_triggers=tuple(triggers),
                scenarios=tuple(scenarios),
                access=access,
                notes=tuple(coordinate_notes),
            )
        )

    # -- coverage and claim scope (33.6, spec 21) --------------------------
    covered = tuple(c.coordinate_id for c in built)
    uncovered = tuple(cid for cid in requested if cid not in covered)
    uncovered_required = tuple(
        r.coordinate_id for r in requests if r.required and r.coordinate_id not in covered
    )
    if uncovered_required:
        basis_type = CompletenessBasisType.KNOWN_INCOMPLETE
    elif uncovered:
        basis_type = CompletenessBasisType.TRUNCATED_BY_DECLARED_RULE
    else:
        basis_type = CompletenessBasisType.EXHAUSTIVE_DECLARED_UNIVERSE
    basis = CompletenessBasis(
        basis_type=basis_type,
        declared_universe=declared_universe,
        source_or_generator_hash=content_hash([r.to_canonical() for r in requests]),
        truncation_rule=(
            "optional coordinates without applicable evidence were omitted"
            if basis_type == CompletenessBasisType.TRUNCATED_BY_DECLARED_RULE
            else None
        ),
        known_omissions=tuple(uncovered),
    )
    coverage = CoverageReport(
        requested=requested,
        covered=covered,
        uncovered=uncovered,
        uncovered_required=uncovered_required,
        basis=basis,
        claim_scope=derive_claim_scope(basis),
    )

    # -- contract-level validity, access, time, status ---------------------
    if built:
        validity = built[0].validity
        access_policy = built[0].access
        for coordinate in built[1:]:
            validity = validity.intersect(coordinate.validity)
            access_policy = access_policy.intersect(coordinate.access)
    else:
        validity = ValidityWindow()
        access_policy = AccessPolicy()
    contract_time = evaluate_time(validity, clock)

    if not built:
        verification_status = VerificationStatus.EMPTY if not rejections else VerificationStatus.REJECTED
    elif uncovered_required:
        verification_status = VerificationStatus.INCOMPLETE_COVERAGE
    elif contract_time.indeterminate or any(
        c.time_judgment.indeterminate for c in built
    ):
        verification_status = VerificationStatus.TIME_INDETERMINATE
    else:
        verification_status = VerificationStatus.VERIFIED

    if clock.evaluation_time is None:
        warnings.append(
            "no verifier clock was supplied; every expiry claim in this contract is "
            "TIME_INDETERMINATE.  It is disclosed here and MUST NOT be read as current "
            "(spec 45.5)"
        )
    if contract_time.indeterminate:
        warnings.append(f"contract time status TIME_INDETERMINATE: {contract_time.detail}")
    if uncovered_required:
        warnings.append(
            f"required coordinates {list(uncovered_required)} are not covered; the "
            f"completeness basis is {basis_type} and the claim scope is "
            f"{coverage.claim_scope} (spec 21.4)"
        )

    # -- derived predicates and feasibility functions (33.6 items 2, 4) ----
    predicates = tuple(
        CapabilityPredicate(
            predicate_id=f"cap::{c.coordinate_id}",
            coordinate_id=c.coordinate_id,
            relation="WITHIN",
            bound=c.bound,
            basis=(
                f"derived from bounded coordinate {c.coordinate_id!r} under evidence "
                f"relation {c.relation} and correlation assumption {c.correlation_assumption}"
            ),
            evidence_hashes=c.evidence_hashes,
            rule_hashes=c.rule_hashes,
        )
        for c in built
    )
    derived_feasibility = tuple(
        ContractFunction(
            function_id=f"feas::{c.coordinate_id}",
            function_class=FunctionClass.FEASIBILITY,
            form="INTERVAL_MEMBERSHIP",
            basis=(
                f"a candidate is feasible on {c.coordinate_id!r} iff its value lies in the "
                "bounded coordinate; derived from evidence, not declared"
            ),
            coordinate_id=c.coordinate_id,
            domain=c.bound,
            evidence_hashes=c.evidence_hashes,
            rule_hashes=c.rule_hashes,
        )
        for c in built
    )
    declared = tuple(declared_functions)
    by_class = {
        klass: tuple(f for f in declared if f.function_class == klass) for klass in FunctionClass.ALL
    }

    contract = TechnologyContract(
        contract_id=contract_id,
        target_context=target_context,
        bounded_coordinates=tuple(built),
        capability_predicates=predicates,
        price_functions=by_class[FunctionClass.PRICE],
        service_functions=by_class[FunctionClass.SERVICE],
        feasibility_functions=by_class[FunctionClass.FEASIBILITY] + derived_feasibility,
        embedding_constraints=by_class[FunctionClass.EMBEDDING],
        lineage=Lineage(edges=tuple(lineage_edges)),
        validity=validity,
        access_policy=access_policy,
        coverage=coverage,
        revalidation_triggers=tuple(
            sorted({t for c in built for t in c.revalidation_triggers})
        ),
        verification_status=verification_status,
        time_judgment=contract_time,
        correlation_assumption=correlation,
    )
    for item, presence in contract.check_required_items().items():
        if presence == "EMPTY":
            notes.append(
                f"contract item {item!r} of spec 33.6 is empty; disclosed rather than "
                "implied to be covered"
            )

    report = AssemblyReport(
        contract_id=contract_id,
        target_context_fingerprint=target_fp,
        requested=requested,
        accepted=covered,
        rejections=tuple(rejections),
        warnings=tuple(warnings),
        notes=tuple(notes),
        relations=tuple(relations),
        applicability_results=tuple(all_results),
        clock=clock,
        rule_declaration_audit=tuple(
            (rule.rule_id, rule.declaration_audit()) for rule in usable_rules
        ),
    )
    return contract, report


def _first_quantity(
    coordinate_id: str,
    rules: Sequence[ApplicabilityRule],
    carried: Mapping[str, Sequence[TransferredEvidence]],
) -> str:
    for rule in rules:
        if rule.target_coordinate == coordinate_id:
            return rule.output_quantity.quantity_id
    members = carried.get(coordinate_id) or ()
    return members[0].result.quantity or coordinate_id if members else coordinate_id


def _first_unit(
    coordinate_id: str,
    rules: Sequence[ApplicabilityRule],
    carried: Mapping[str, Sequence[TransferredEvidence]],
) -> str:
    for rule in rules:
        if rule.target_coordinate == coordinate_id:
            return rule.output_quantity.unit
    members = carried.get(coordinate_id) or ()
    return members[0].result.unit or "1" if members else "1"
