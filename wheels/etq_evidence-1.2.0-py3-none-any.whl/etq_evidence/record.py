"""The evidence record and its seven separately represented components.

Normative basis: master specification 33.2 (evidence record), 33.4
(uncertainty components), 5.3 (evidence classes), 13.1--13.4 (quantity
identity and unit discipline), 44.2--44.3 (access), 45 (time).

Specification 33.2 defines evidence as

    e_i = (Y_i, U_i, C_i, M_i, P_i, V_i, A_i)

with value, uncertainty, source context, method, provenance, validity, and
access **separately represented**.  This module takes "separately" as a
structural requirement, not a documentation one: there is no field on
:class:`EvidenceRecord` that fuses two of the seven, no accessor that
returns a value with its uncertainty already folded in, and no accessor
that returns a bare number at all.

Specification 33.4 requires the same of uncertainty: the five components
are five fields of :class:`UncertaintyBudget` and stay five fields through
transformation and assembly.  They are combined only by
:meth:`UncertaintyBudget.combine`, whose ``correlation`` argument is a
required keyword -- an unstated correlation assumption is a 33.4 violation,
so this implementation makes it unspellable.
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from crg_model.canonical import content_hash
from crg_model.envelope import EvidenceClass, ObjectStatus
from crg_model.numeric import Exact, Interval

from .clock import TimeJudgment, ValidityWindow, VerificationClock, evaluate_time

__all__ = [
    "EvidenceError",
    "CorrelationAssumption",
    "EvidenceStatus",
    "ProvenanceStatus",
    "ContextDescriptor",
    "MethodDescriptor",
    "Provenance",
    "AccessPolicy",
    "Requester",
    "UncertaintyBudget",
    "UncertaintyCombination",
    "EvidenceRecord",
    "ValidityWindow",
    "VerificationClock",
    "freeze_fields",
]


class EvidenceError(ValueError):
    """Raised when an evidence input is inadmissible under section 33."""


# ---------------------------------------------------------------------------
# field maps: canonical, hashable, and float-free (14.2, 14.3)
# ---------------------------------------------------------------------------
def freeze_fields(fields: Any) -> Tuple[Tuple[str, str], ...]:
    """Normalize a context/parameter map to a sorted tuple of string pairs.

    Binary floating point is refused outright, as everywhere else on a
    hashing path (14.2): a context fingerprint that differs by a rounding
    mode is not a fingerprint.
    """
    if fields is None:
        return ()
    if isinstance(fields, Mapping):
        items = list(fields.items())
    elif isinstance(fields, (list, tuple)):
        items = [tuple(pair) for pair in fields]  # type: ignore[misc]
    else:
        raise EvidenceError(f"cannot interpret {type(fields)!r} as a field map")
    out = []
    for key, value in items:
        if isinstance(value, float):
            raise EvidenceError(
                f"field {key!r} is binary floating point; supply an integer, a decimal "
                "string, or a rational string so the context fingerprint is exact (14.2)"
            )
        if isinstance(value, (Exact, Interval)):
            value = str(value)
        elif isinstance(value, bool):
            value = "true" if value else "false"
        out.append((str(key), str(value)))
    if len({k for k, _ in out}) != len(out):
        raise EvidenceError("duplicate field names in a field map")
    return tuple(sorted(out))


def _as_dict(pairs: Tuple[Tuple[str, str], ...]) -> Dict[str, str]:
    return {k: v for k, v in pairs}


# ---------------------------------------------------------------------------
# vocabularies
# ---------------------------------------------------------------------------
class CorrelationAssumption:
    """The assumption a fusion rule MUST state (spec 33.4, last sentence)."""

    INDEPENDENT = "INDEPENDENT"
    FULLY_CORRELATED = "FULLY_CORRELATED"
    UNKNOWN = "UNKNOWN"

    ALL = frozenset({INDEPENDENT, FULLY_CORRELATED, UNKNOWN})

    #: The exact statement each assumption makes.  A combination that cannot
    #: cite one of these has not stated its assumption and is refused.
    STATEMENT = {
        INDEPENDENT: (
            "INDEPENDENT: the five components are asserted to arise from independent "
            "causes.  Independence licenses a distributional (root-sum-square) "
            "reduction, but a square root is not an exact rational (spec 14.2), so no "
            "reduction is taken here: the components are added by exact interval "
            "arithmetic (33.4, first fusion option).  The result is therefore a valid "
            "but non-tight enclosure under this assumption, and says so."
        ),
        FULLY_CORRELATED: (
            "FULLY_CORRELATED: the components are asserted to move together, so their "
            "extremes are simultaneously attainable and the worst case is their exact "
            "interval sum.  Under interval semantics this bound is tight."
        ),
        UNKNOWN: (
            "UNKNOWN: no correlation structure is asserted, so no component's declared "
            "sign is relied upon.  Each component is first symmetrized to "
            "[-max(|lo|,|hi|), +max(|lo|,|hi|)] and the symmetrized components are then "
            "summed exactly.  This envelopes every correlation structure, including one "
            "in which a component's declared one-sided bias does not hold (spec 6.6)."
        ),
    }

    @classmethod
    def statement(cls, correlation: str) -> str:
        try:
            return cls.STATEMENT[correlation]
        except KeyError:
            raise EvidenceError(
                f"unknown correlation assumption {correlation!r}; spec 33.4 requires the "
                f"rule to state one of {sorted(cls.ALL)}"
            ) from None


class EvidenceStatus:
    """Evidence maturity, ranked, for rule field "minimum evidence status" (33.3).

    This is orthogonal to :class:`crg_model.envelope.ObjectStatus`, which is
    lifecycle (active, superseded, revoked).  A record carries both.
    """

    DRAFT = "DRAFT"
    PROVISIONAL = "PROVISIONAL"
    QUALIFIED = "QUALIFIED"
    CERTIFIED = "CERTIFIED"

    ALL = frozenset({DRAFT, PROVISIONAL, QUALIFIED, CERTIFIED})
    RANK = {DRAFT: 0, PROVISIONAL: 1, QUALIFIED: 2, CERTIFIED: 3}

    @classmethod
    def meets(cls, actual: str, minimum: str) -> bool:
        """Fail closed: an unrecognized status never meets any minimum."""
        if actual not in cls.RANK or minimum not in cls.RANK:
            return False
        return cls.RANK[actual] >= cls.RANK[minimum]


class ProvenanceStatus:
    """Whether ``P`` can carry the record (33.2, threat model 44.6)."""

    VALID = "VALID"
    UNVERIFIED = "UNVERIFIED"
    BROKEN_CHAIN = "BROKEN_CHAIN"
    TAMPERED = "TAMPERED"
    ABSENT = "ABSENT"

    ALL = frozenset({VALID, UNVERIFIED, BROKEN_CHAIN, TAMPERED, ABSENT})


# ---------------------------------------------------------------------------
# C: context (33.2)
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class ContextDescriptor:
    """A typed context with an exact fingerprint (33.2 ``C``, 33.3 patterns).

    A context is a *type* plus named fields; two contexts of different types
    are never compared field-by-field, because "temperature" in a process
    context and "temperature" in a supplier-qualification context are not the
    same field.  The fingerprint is a content hash over the typed pair, so a
    contract can cite the exact context a coordinate was transferred to.
    """

    context_id: str
    context_type: str
    fields: Tuple[Tuple[str, str], ...] = ()

    def __init__(self, context_id: str, context_type: str, fields: Any = None) -> None:
        object.__setattr__(self, "context_id", str(context_id))
        object.__setattr__(self, "context_type", str(context_type))
        object.__setattr__(self, "fields", freeze_fields(fields))

    def as_dict(self) -> Dict[str, str]:
        return _as_dict(self.fields)

    def get(self, name: str) -> Optional[str]:
        return self.as_dict().get(name)

    def has(self, name: str) -> bool:
        return name in self.as_dict()

    def differing_fields(self, other: "ContextDescriptor") -> Tuple[str, ...]:
        """Field names whose values differ, including presence differences."""
        mine, theirs = self.as_dict(), other.as_dict()
        names = set(mine) | set(theirs)
        return tuple(sorted(n for n in names if mine.get(n) != theirs.get(n)))

    @property
    def comparable_type(self) -> str:
        return self.context_type

    def to_canonical(self) -> dict:
        return {
            "context_id": self.context_id,
            "context_type": self.context_type,
            "fields": _as_dict(self.fields),
        }

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())


# ---------------------------------------------------------------------------
# M: method (33.2), bound to the 5.3 evidence classes
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class MethodDescriptor:
    """``M``: how the value was produced, and under which 5.3 class."""

    method_id: str
    method_class: str
    evidence_class: str = EvidenceClass.MEASURED
    instrument: Optional[str] = None
    version: Optional[str] = None
    parameters: Tuple[Tuple[str, str], ...] = ()

    def __post_init__(self) -> None:
        if self.evidence_class not in EvidenceClass.ALL:
            raise EvidenceError(
                f"unknown evidence class {self.evidence_class!r}; spec 5.3 fixes the set"
            )
        object.__setattr__(self, "parameters", freeze_fields(self.parameters))

    @property
    def may_authorize(self) -> bool:
        """Spec 5.3: a heuristic may propose an evidence mapping; it may never
        silently authorize evidence applicability."""
        return EvidenceClass.may_authorize(self.evidence_class)

    def to_canonical(self) -> dict:
        record: dict = {
            "method_id": self.method_id,
            "method_class": self.method_class,
            "evidence_class": self.evidence_class,
        }
        if self.instrument:
            record["instrument"] = self.instrument
        if self.version:
            record["version"] = self.version
        if self.parameters:
            record["parameters"] = _as_dict(self.parameters)
        return record

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())


# ---------------------------------------------------------------------------
# P: provenance (33.2, 6.4)
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class Provenance:
    """``P``: where the record came from and whether that origin holds.

    ``chain`` is an ordered list of content hashes, oldest first: the source
    document, any transformation records, and the record itself.  Anything
    that is not a ``sha256:`` hash breaks the chain, because a provenance
    chain whose links are prose cannot be checked (6.4).
    """

    source_id: str
    issuer: str
    issued_at: Optional[str] = None
    chain: Tuple[str, ...] = ()
    integrity: str = "UNVERIFIED"
    signature: Optional[str] = None
    notes: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(self, "chain", tuple(str(h) for h in self.chain))
        object.__setattr__(self, "notes", tuple(str(n) for n in self.notes))

    @classmethod
    def verified(
        cls,
        source_id: str,
        issuer: str,
        chain: Sequence[str],
        issued_at: Optional[str] = None,
        signature: Optional[str] = None,
    ) -> "Provenance":
        return cls(
            source_id=source_id,
            issuer=issuer,
            issued_at=issued_at,
            chain=tuple(chain),
            integrity="VERIFIED",
            signature=signature,
        )

    def status(self) -> str:
        """Classify ``P``.  Only ``VALID`` may carry a contract coordinate."""
        if not self.source_id or not self.issuer or not self.chain:
            return ProvenanceStatus.ABSENT
        if self.integrity == "BROKEN":
            return ProvenanceStatus.TAMPERED
        if any(not _is_hash(link) for link in self.chain):
            return ProvenanceStatus.BROKEN_CHAIN
        if self.integrity != "VERIFIED":
            return ProvenanceStatus.UNVERIFIED
        return ProvenanceStatus.VALID

    @property
    def is_valid(self) -> bool:
        return self.status() == ProvenanceStatus.VALID

    def to_canonical(self) -> dict:
        record: dict = {
            "source_id": self.source_id,
            "issuer": self.issuer,
            "integrity": self.integrity,
            "chain": list(self.chain),
            "provenance_status": self.status(),
        }
        if self.issued_at:
            record["issued_at"] = self.issued_at
        if self.signature:
            record["signature"] = self.signature
        if self.notes:
            record["notes"] = list(self.notes)
        return record


def _is_hash(value: Any) -> bool:
    if not isinstance(value, str) or not value.startswith("sha256:"):
        return False
    body = value[len("sha256:") :]
    return len(body) == 64 and all(c in "0123456789abcdef" for c in body)


# ---------------------------------------------------------------------------
# A: access (33.2, 44.2-44.3)
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class Requester:
    """The identity assembly is performed on behalf of (44.2)."""

    subject_id: str
    roles: Tuple[str, ...] = ()
    authority: Optional[str] = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "roles", tuple(sorted(str(r) for r in self.roles)))

    def to_canonical(self) -> dict:
        record: dict = {"subject_id": self.subject_id, "roles": list(self.roles)}
        if self.authority:
            record["authority"] = self.authority
        return record


@dataclass(frozen=True)
class AccessPolicy:
    """``A``: who may read this evidence, and what leaves in a contract.

    Fail closed (6.6): a policy that names neither a role nor a subject
    permits nobody unless it is explicitly classified ``public``.  An absent
    requester is not an anonymous grant.
    """

    classification: str = "internal"
    permitted_roles: Tuple[str, ...] = ()
    permitted_subjects: Tuple[str, ...] = ()
    redaction_required: bool = False
    export_permitted: bool = True

    def __post_init__(self) -> None:
        object.__setattr__(self, "permitted_roles", tuple(sorted(str(r) for r in self.permitted_roles)))
        object.__setattr__(
            self, "permitted_subjects", tuple(sorted(str(s) for s in self.permitted_subjects))
        )

    @classmethod
    def public(cls) -> "AccessPolicy":
        return cls(classification="public")

    def permits(self, requester: Optional[Requester]) -> bool:
        if self.classification == "public":
            return True
        if requester is None:
            return False
        if requester.subject_id in self.permitted_subjects:
            return True
        return bool(set(requester.roles) & set(self.permitted_roles))

    def refusal(self, requester: Optional[Requester]) -> str:
        if requester is None:
            return (
                f"classification {self.classification!r} requires an identified requester; "
                "no requester was supplied (spec 44.2, fail closed 6.6)"
            )
        return (
            f"subject {requester.subject_id!r} with roles {list(requester.roles)} is not "
            f"permitted by classification {self.classification!r} "
            f"(roles {list(self.permitted_roles)}, subjects {list(self.permitted_subjects)})"
        )

    def intersect(self, other: "AccessPolicy") -> "AccessPolicy":
        """The policy an assembled object inherits: the strictest of its inputs."""
        rank = {"public": 0, "internal": 1, "confidential": 2, "restricted": 3}
        mine, theirs = rank.get(self.classification, 2), rank.get(other.classification, 2)
        classification = self.classification if mine >= theirs else other.classification
        if classification == "public" and "public" not in (self.classification, other.classification):
            classification = "internal"
        return AccessPolicy(
            classification=classification,
            permitted_roles=tuple(sorted(set(self.permitted_roles) & set(other.permitted_roles)))
            if self.permitted_roles and other.permitted_roles
            else tuple(sorted(set(self.permitted_roles) | set(other.permitted_roles))),
            permitted_subjects=tuple(
                sorted(set(self.permitted_subjects) & set(other.permitted_subjects))
            )
            if self.permitted_subjects and other.permitted_subjects
            else tuple(sorted(set(self.permitted_subjects) | set(other.permitted_subjects))),
            redaction_required=self.redaction_required or other.redaction_required,
            export_permitted=self.export_permitted and other.export_permitted,
        )

    def to_canonical(self) -> dict:
        return {
            "classification": self.classification,
            "permitted_roles": list(self.permitted_roles),
            "permitted_subjects": list(self.permitted_subjects),
            "redaction_required": self.redaction_required,
            "export_permitted": self.export_permitted,
        }


# ---------------------------------------------------------------------------
# U: the five uncertainty components (33.4)
# ---------------------------------------------------------------------------
_ZERO = Interval(0, 0)

#: The five components of 33.4, in specification order.  This tuple is the
#: single source of truth for iteration; nothing in this package enumerates
#: four of them or six of them.
COMPONENT_NAMES: Tuple[str, ...] = (
    "measurement",
    "sampling",
    "calibration",
    "transfer",
    "model",
)


@dataclass(frozen=True)
class UncertaintyCombination:
    """A combined uncertainty *with* the assumption that produced it (33.4)."""

    interval: Interval
    correlation_assumption: str
    statement: str
    contributions: Tuple[Tuple[str, Interval], ...]
    tight: bool

    def to_canonical(self) -> dict:
        return {
            "interval": self.interval.to_canonical(),
            "correlation_assumption": self.correlation_assumption,
            "assumption_statement": self.statement,
            "contributions": {name: iv.to_canonical() for name, iv in self.contributions},
            "bound_is_tight_under_assumption": self.tight,
        }


@dataclass(frozen=True)
class UncertaintyBudget:
    """``U`` of 33.2, expanded into the five components of 33.4.

    Each component is a *deviation* interval to be added to the value: a
    symmetric measurement uncertainty of one part is ``Interval(-1, 1)``, and
    a one-sided derating allowance is ``Interval(0, 3)``.  Components are
    never merged in place; they survive transformation (:meth:`scaled`),
    transfer (:meth:`with_transfer`), and contract assembly as five fields.
    """

    measurement: Interval = _ZERO
    sampling: Interval = _ZERO
    calibration: Interval = _ZERO
    transfer: Interval = _ZERO
    model: Interval = _ZERO
    basis: str = ""

    def __post_init__(self) -> None:
        for name in COMPONENT_NAMES:
            value = getattr(self, name)
            if not isinstance(value, Interval):
                raise EvidenceError(
                    f"uncertainty component {name!r} must be an exact Interval, got "
                    f"{type(value)!r}; spec 33.4 keeps components as declared bounds"
                )

    # -- component access ------------------------------------------------
    @property
    def components(self) -> Tuple[Tuple[str, Interval], ...]:
        return tuple((name, getattr(self, name)) for name in COMPONENT_NAMES)

    def component(self, name: str) -> Interval:
        if name not in COMPONENT_NAMES:
            raise EvidenceError(
                f"{name!r} is not one of the five components of spec 33.4: "
                f"{list(COMPONENT_NAMES)}"
            )
        return getattr(self, name)

    @property
    def declared_components(self) -> Tuple[str, ...]:
        return tuple(name for name, iv in self.components if not _is_zero(iv))

    @property
    def is_empty(self) -> bool:
        return all(_is_zero(iv) for _, iv in self.components)

    # -- transformations that preserve separation ------------------------
    def scaled(self, factor: Any) -> "UncertaintyBudget":
        """Scale every component by an exact factor (a derating multiplier).

        Each component is scaled individually, so the budget that comes out
        of a transformation still has five separately attributable parts.
        """
        f = Interval(Exact(factor), Exact(factor))
        return UncertaintyBudget(
            **{name: getattr(self, name) * f for name in COMPONENT_NAMES},
            basis=self.basis,
        )

    def with_transfer(self, transfer: Interval, basis: str = "") -> "UncertaintyBudget":
        """Set the ``transfer`` component, leaving the other four untouched.

        Transfer uncertainty is what an applicability rule adds when evidence
        crosses contexts (33.3).  It is a *fifth* line item, never an
        inflation of the measurement term, so that a reader can tell how much
        of the final bound is the measurement and how much is the transfer.
        """
        return replace(self, transfer=transfer, basis=basis or self.basis)

    def merged_envelope(self, other: "UncertaintyBudget") -> "UncertaintyBudget":
        """Componentwise hull of two budgets -- still five components."""
        return UncertaintyBudget(
            **{
                name: getattr(self, name).union(getattr(other, name))
                for name in COMPONENT_NAMES
            },
            basis=self.basis or other.basis,
        )

    # -- the one combination point (33.4) --------------------------------
    def combine(self, *, correlation: str) -> Interval:
        """Combine the five components under a **stated** assumption (33.4).

        ``correlation`` is keyword-only and has no default.  Specification
        33.4 requires the rule to state its correlation or independence
        assumption; a call that does not state one is a specification
        violation, and here it is a ``TypeError``.
        """
        return self.combine_detail(correlation=correlation).interval

    def combine_detail(self, *, correlation: str) -> UncertaintyCombination:
        """As :meth:`combine`, returning the assumption and per-component parts."""
        statement = CorrelationAssumption.statement(correlation)
        if correlation == CorrelationAssumption.UNKNOWN:
            contributions = tuple((name, _symmetrize(iv)) for name, iv in self.components)
            tight = False
        else:
            contributions = self.components
            tight = correlation == CorrelationAssumption.FULLY_CORRELATED
        total = _ZERO
        for _, iv in contributions:
            total = total + iv
        return UncertaintyCombination(
            interval=total,
            correlation_assumption=correlation,
            statement=statement,
            contributions=contributions,
            tight=tight,
        )

    def to_canonical(self) -> dict:
        record: dict = {
            name: getattr(self, name).to_canonical() for name in COMPONENT_NAMES
        }
        record["component_order"] = list(COMPONENT_NAMES)
        if self.basis:
            record["basis"] = self.basis
        return record


def _is_zero(interval: Interval) -> bool:
    return interval.lo == Exact(0) and interval.hi == Exact(0)


def _symmetrize(interval: Interval) -> Interval:
    magnitude = max(abs(interval.lo.value), abs(interval.hi.value))
    return Interval(Exact(-magnitude), Exact(magnitude))


# ---------------------------------------------------------------------------
# the record (33.2)
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class EvidenceRecord:
    """``e = (Y, U, C, M, P, V, A)`` with the seven kept apart (spec 33.2).

    ``value`` is ``Y``: an exact interval, degenerate for a point reading.
    It is *not* the measured value plus its uncertainty; the uncertainty is
    ``uncertainty`` and stays there.  :meth:`enclosure` is the only place the
    two meet, and it demands a stated correlation assumption to do so.

    ``quantity`` is a registered quantity identifier and ``unit`` its unit.
    Per 13.1 and 13.4 identity is by quantity id: two dimensionless
    quantities with the same unit are still different quantities, and this
    module never infers one from the other.
    """

    evidence_id: str
    quantity: str
    unit: str
    value: Interval
    uncertainty: UncertaintyBudget
    source_context: ContextDescriptor
    method: MethodDescriptor
    provenance: Provenance
    validity: ValidityWindow
    access: AccessPolicy
    evidence_status: str = EvidenceStatus.QUALIFIED
    status: str = ObjectStatus.ACTIVE
    supersedes: Tuple[str, ...] = ()
    superseded_by: Optional[str] = None
    scenarios: Tuple[Interval, ...] = ()
    notes: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not isinstance(self.value, Interval):
            raise EvidenceError(
                "evidence value Y must be an exact Interval (degenerate for a point "
                "reading); a bare float never enters a certifying path (14.2)"
            )
        if self.evidence_status not in EvidenceStatus.ALL:
            raise EvidenceError(
                f"unknown evidence status {self.evidence_status!r}; expected one of "
                f"{sorted(EvidenceStatus.ALL)}"
            )
        if self.status not in ObjectStatus.ALL:
            raise EvidenceError(f"unknown object status {self.status!r} (spec 12)")
        if not self.quantity or not self.unit:
            raise EvidenceError(
                "evidence must declare a registered quantity identifier and a unit; "
                "an unnamed quantity cannot be checked for mismatch (spec 13.1)"
            )
        object.__setattr__(self, "supersedes", tuple(str(s) for s in self.supersedes))
        object.__setattr__(self, "notes", tuple(str(n) for n in self.notes))
        object.__setattr__(self, "scenarios", tuple(self.scenarios))

    # -- Y and U meet only here ------------------------------------------
    def enclosure(self, *, correlation: str) -> Interval:
        """``Y`` widened by ``U`` under a **stated** assumption (33.4).

        Keyword-only and defaulted nowhere, for the same reason as
        :meth:`UncertaintyBudget.combine`.
        """
        return self.value + self.uncertainty.combine(correlation=correlation)

    # -- the other five components ----------------------------------------
    def time_judgment(self, clock: Optional[VerificationClock] = None) -> TimeJudgment:
        """Judge ``V`` against a supplied clock (45.3).  Never reads a clock."""
        return evaluate_time(self.validity, clock)

    def provenance_status(self) -> str:
        return self.provenance.status()

    def permits(self, requester: Optional[Requester]) -> bool:
        return self.access.permits(requester)

    @property
    def may_authorize(self) -> bool:
        """5.3: heuristic evidence may propose an applicability mapping but may
        never itself authorize one."""
        return self.method.may_authorize

    @property
    def is_superseded(self) -> bool:
        return self.status == ObjectStatus.SUPERSEDED or self.superseded_by is not None

    # -- canonical form ---------------------------------------------------
    def to_canonical(self) -> dict:
        record: dict = {
            "record_type": "etq.evidence_record",
            "spec_section": "33.2",
            "evidence_id": self.evidence_id,
            "quantity": self.quantity,
            "unit": self.unit,
            "Y_value": self.value.to_canonical(),
            "U_uncertainty": self.uncertainty.to_canonical(),
            "C_source_context": self.source_context.to_canonical(),
            "M_method": self.method.to_canonical(),
            "P_provenance": self.provenance.to_canonical(),
            "V_validity": self.validity.to_canonical(),
            "A_access": self.access.to_canonical(),
            "evidence_status": self.evidence_status,
            "status": self.status,
        }
        if self.supersedes:
            record["supersedes"] = list(self.supersedes)
        if self.superseded_by:
            record["superseded_by"] = self.superseded_by
        if self.scenarios:
            record["scenarios"] = [s.to_canonical() for s in self.scenarios]
        if self.notes:
            record["notes"] = list(self.notes)
        return record

    def fingerprint(self) -> str:
        """Content hash over the whole seven-tuple: the lineage handle a
        technology contract cites (33.6 "evidence and rule lineage")."""
        return content_hash(self.to_canonical())
