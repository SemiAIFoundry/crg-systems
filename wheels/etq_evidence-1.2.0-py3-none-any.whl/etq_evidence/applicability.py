"""Applicability rules and the applicability decision.

Normative basis: master specification 33.3 (applicability rule), 13.1--13.4
(quantity identity, unit mismatch), 5.3 (a heuristic may not authorize
evidence applicability), 44.2 (access), 45 (time).

The sentence this module exists to enforce is the last line of 33.3:

    No applicable rule means ``UNSUPPORTED``, not an assumed default.

So there is no fallback rule, no identity rule, no "same unit therefore
transferable" shortcut, and no code path from an empty rule set to a
coordinate.  :func:`apply_rule` returns a *result*, never a value, and
:func:`select_rule` returns ``UNSUPPORTED`` with the reason each candidate
rule failed rather than the nearest match.

A rule MUST identify fourteen things (33.3).  Every one is a field of
:class:`ApplicabilityRule` and none of the semantic ones has a default, so
a rule that fails to identify one cannot be constructed.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional, Sequence, Tuple

from crg_model.canonical import content_hash
from crg_model.numeric import Exact, Interval

from .clock import TimeJudgment, TimeStatus, ValidityWindow, VerificationClock, evaluate_time
from .record import (
    ContextDescriptor,
    CorrelationAssumption,
    EvidenceError,
    EvidenceRecord,
    EvidenceStatus,
    Requester,
    UncertaintyBudget,
    freeze_fields,
)

__all__ = [
    "ApplicabilityStatus",
    "ReasonCode",
    "QuantityType",
    "UnitConversion",
    "ContextPattern",
    "DifferenceKind",
    "PermittedDifference",
    "ExclusionKind",
    "HardExclusion",
    "TransformationKind",
    "Transformation",
    "TransferModelKind",
    "TransferUncertaintyModel",
    "ApplicabilityRule",
    "ApplicabilityResult",
    "apply_rule",
    "select_rule",
    "CHECK_ORDER",
]


class ApplicabilityStatus:
    """The five outcomes of an applicability decision (33.3, 33.5)."""

    APPLICABLE = "APPLICABLE"
    UNSUPPORTED = "UNSUPPORTED"
    EXCLUDED = "EXCLUDED"
    EXPIRED = "EXPIRED"
    UNAUTHORIZED = "UNAUTHORIZED"

    ALL = frozenset({APPLICABLE, UNSUPPORTED, EXCLUDED, EXPIRED, UNAUTHORIZED})


class ReasonCode:
    """Why a rule did not apply.  Never a generic failure (33.3, 33.7)."""

    APPLICABLE = "APPLICABLE"
    ACCESS_DENIED = "ACCESS_DENIED"
    QUANTITY_MISMATCH = "QUANTITY_MISMATCH"
    UNIT_MISMATCH = "UNIT_MISMATCH"
    OUTPUT_UNIT_MISMATCH = "OUTPUT_UNIT_MISMATCH"
    HARD_CONTEXT_EXCLUSION = "HARD_CONTEXT_EXCLUSION"
    SOURCE_CONTEXT_PATTERN_MISMATCH = "SOURCE_CONTEXT_PATTERN_MISMATCH"
    TARGET_CONTEXT_PATTERN_MISMATCH = "TARGET_CONTEXT_PATTERN_MISMATCH"
    CONTEXT_TYPE_INCOMPARABLE = "CONTEXT_TYPE_INCOMPARABLE"
    EXACT_MATCH_FIELD_DIFFERS = "EXACT_MATCH_FIELD_DIFFERS"
    DIFFERENCE_NOT_PERMITTED = "DIFFERENCE_NOT_PERMITTED"
    EVIDENCE_STATUS_BELOW_MINIMUM = "EVIDENCE_STATUS_BELOW_MINIMUM"
    HEURISTIC_MAY_NOT_AUTHORIZE = "HEURISTIC_MAY_NOT_AUTHORIZE"
    EVIDENCE_SUPERSEDED = "EVIDENCE_SUPERSEDED"
    EVIDENCE_NOT_ACTIVE = "EVIDENCE_NOT_ACTIVE"
    EVIDENCE_EXPIRED = "EVIDENCE_EXPIRED"
    EVIDENCE_NOT_YET_VALID = "EVIDENCE_NOT_YET_VALID"
    EVIDENCE_STALE = "EVIDENCE_STALE"
    RULE_EXPIRED = "RULE_EXPIRED"
    CLOCK_POLICY_VIOLATION = "CLOCK_POLICY_VIOLATION"
    NO_APPLICABLE_RULE = "NO_APPLICABLE_RULE"
    NO_RULES_DECLARED = "NO_RULES_DECLARED"


#: The order in which :func:`apply_rule` runs its gates.  Declared, because
#: which reason surfaces first for a record that fails several gates is a
#: semantic choice, not an implementation accident.  Access comes first: a
#: requester who may not read the evidence learns nothing else about it.
CHECK_ORDER: Tuple[str, ...] = (
    "access",
    "quantity_identity",
    "input_unit",
    "hard_exclusions",
    "source_context_pattern",
    "target_context_pattern",
    "exact_match_fields",
    "permitted_differences",
    "minimum_evidence_status",
    "evidence_lifecycle",
    "evidence_validity",
    "rule_expiration",
)


# ---------------------------------------------------------------------------
# quantity and unit (33.3 item 1; 13.1-13.4)
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class QuantityType:
    """A registered quantity plus the unit the rule speaks in (13.2)."""

    quantity_id: str
    unit: str
    dimension: Optional[str] = None
    direction: str = "MINIMIZE"

    def to_canonical(self) -> dict:
        record: dict = {
            "quantity_id": self.quantity_id,
            "unit": self.unit,
            "direction": self.direction,
        }
        if self.dimension:
            record["dimension"] = self.dimension
        return record


@dataclass(frozen=True)
class UnitConversion:
    """An **explicit registered** conversion (13.3).

    Specification 13.3: "A unit mismatch MUST block arithmetic unless an
    explicit registered conversion exists."  There is no implicit conversion
    table in this module; a rule carries the conversions it is entitled to
    use, each with the authority that registered it, and the factor is an
    exact rational.
    """

    conversion_id: str
    quantity_id: str
    from_unit: str
    to_unit: str
    factor: Exact
    offset: Exact = Exact(0)
    registered_by: str = ""

    def __post_init__(self) -> None:
        object.__setattr__(self, "factor", Exact(self.factor))
        object.__setattr__(self, "offset", Exact(self.offset))
        if not self.registered_by:
            raise EvidenceError(
                "a unit conversion must name the authority that registered it; an "
                "unregistered conversion may not unblock a unit mismatch (spec 13.3)"
            )

    def applies(self, quantity_id: str, from_unit: str, to_unit: str) -> bool:
        return (
            self.quantity_id == quantity_id
            and self.from_unit == from_unit
            and self.to_unit == to_unit
        )

    def convert(self, interval: Interval) -> Interval:
        scaled = interval * Interval(self.factor, self.factor)
        return scaled + Interval(self.offset, self.offset)

    def convert_deviation(self, interval: Interval) -> Interval:
        """Convert an uncertainty *deviation*: the offset does not apply."""
        return interval * Interval(self.factor, self.factor)

    def to_canonical(self) -> dict:
        return {
            "conversion_id": self.conversion_id,
            "quantity_id": self.quantity_id,
            "from_unit": self.from_unit,
            "to_unit": self.to_unit,
            "factor": self.factor.to_canonical(),
            "offset": self.offset.to_canonical(),
            "registered_by": self.registered_by,
        }


# ---------------------------------------------------------------------------
# context patterns (33.3 items 2-3)
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class ContextPattern:
    """A typed pattern over context fields.

    ``required_fields`` maps a field name to a required value, or to ``"*"``
    meaning "must be present, any value".  A field the pattern does not
    mention is not constrained by the pattern; it may still be constrained by
    exact-match fields, permitted differences, or a hard exclusion.
    """

    context_type: str
    required_fields: Tuple[Tuple[str, str], ...] = ()
    description: str = ""

    def __init__(self, context_type: str, required_fields: Any = None, description: str = "") -> None:
        object.__setattr__(self, "context_type", str(context_type))
        object.__setattr__(self, "required_fields", freeze_fields(required_fields))
        object.__setattr__(self, "description", str(description))

    def matches(self, context: ContextDescriptor) -> Tuple[bool, Tuple[str, ...]]:
        """Return ``(matched, failures)``; failures name the field and why."""
        failures = []
        if context.context_type != self.context_type:
            failures.append(
                f"context type {context.context_type!r} != required {self.context_type!r}"
            )
        present = context.as_dict()
        for name, required in self.required_fields:
            if name not in present:
                failures.append(f"required field {name!r} absent from context")
            elif required != "*" and present[name] != required:
                failures.append(
                    f"field {name!r} is {present[name]!r}, pattern requires {required!r}"
                )
        return (not failures), tuple(failures)

    def to_canonical(self) -> dict:
        record: dict = {
            "context_type": self.context_type,
            "required_fields": {k: v for k, v in self.required_fields},
        }
        if self.description:
            record["description"] = self.description
        return record


# ---------------------------------------------------------------------------
# permitted differences (33.3 item 5)
# ---------------------------------------------------------------------------
class DifferenceKind:
    ANY_VALUE = "ANY_VALUE"
    ENUMERATED = "ENUMERATED"
    NUMERIC_RANGE = "NUMERIC_RANGE"

    ALL = frozenset({ANY_VALUE, ENUMERATED, NUMERIC_RANGE})


@dataclass(frozen=True)
class PermittedDifference:
    """A source/target field difference the rule is willing to bridge.

    A permitted difference may carry its own ``added_transfer_uncertainty``.
    That is the honest accounting: bridging a difference is not free, and the
    cost lands in the ``transfer`` component of the budget (33.4), never
    silently inside the measurement term.
    """

    field: str
    kind: str = DifferenceKind.ANY_VALUE
    permitted_values: Tuple[str, ...] = ()
    max_absolute_difference: Optional[Exact] = None
    added_transfer_uncertainty: Optional[Interval] = None
    basis: str = ""

    def __post_init__(self) -> None:
        if self.kind not in DifferenceKind.ALL:
            raise EvidenceError(f"unknown permitted-difference kind {self.kind!r}")
        object.__setattr__(
            self, "permitted_values", tuple(sorted(str(v) for v in self.permitted_values))
        )
        if self.max_absolute_difference is not None:
            object.__setattr__(
                self, "max_absolute_difference", Exact(self.max_absolute_difference)
            )
        if self.kind == DifferenceKind.ENUMERATED and not self.permitted_values:
            raise EvidenceError("an ENUMERATED permitted difference must list its values")
        if self.kind == DifferenceKind.NUMERIC_RANGE and self.max_absolute_difference is None:
            raise EvidenceError(
                "a NUMERIC_RANGE permitted difference must declare max_absolute_difference"
            )

    def permits(self, source_value: Optional[str], target_value: Optional[str]) -> Tuple[bool, str]:
        if self.kind == DifferenceKind.ANY_VALUE:
            return True, ""
        if self.kind == DifferenceKind.ENUMERATED:
            missing = [
                v for v in (source_value, target_value) if v is not None and v not in self.permitted_values
            ]
            if missing:
                return False, (
                    f"field {self.field!r} value(s) {missing} outside the enumerated "
                    f"permitted set {list(self.permitted_values)}"
                )
            return True, ""
        # NUMERIC_RANGE
        try:
            src = Exact(source_value) if source_value is not None else None
            tgt = Exact(target_value) if target_value is not None else None
        except (TypeError, ValueError):
            return False, (
                f"field {self.field!r} is declared NUMERIC_RANGE but the values "
                f"{source_value!r}/{target_value!r} are not exact rationals"
            )
        if src is None or tgt is None:
            return False, f"field {self.field!r} is absent from one context; range undecidable"
        delta = abs((src - tgt).value)
        limit = self.max_absolute_difference
        assert limit is not None
        if delta > limit.value:
            return False, (
                f"field {self.field!r} differs by {delta}, exceeding the permitted "
                f"{limit} (spec 33.3 permitted differences)"
            )
        return True, ""

    def to_canonical(self) -> dict:
        record: dict = {"field": self.field, "kind": self.kind}
        if self.permitted_values:
            record["permitted_values"] = list(self.permitted_values)
        if self.max_absolute_difference is not None:
            record["max_absolute_difference"] = self.max_absolute_difference.to_canonical()
        if self.added_transfer_uncertainty is not None:
            record["added_transfer_uncertainty"] = self.added_transfer_uncertainty.to_canonical()
        if self.basis:
            record["basis"] = self.basis
        return record


# ---------------------------------------------------------------------------
# hard exclusions (33.3 item 6)
# ---------------------------------------------------------------------------
class ExclusionKind:
    TARGET_FIELD_EQUALS = "TARGET_FIELD_EQUALS"
    TARGET_FIELD_IN = "TARGET_FIELD_IN"
    SOURCE_FIELD_IN = "SOURCE_FIELD_IN"
    FIELD_DIFFERS = "FIELD_DIFFERS"
    TARGET_FIELD_ABSENT = "TARGET_FIELD_ABSENT"

    ALL = frozenset(
        {
            TARGET_FIELD_EQUALS,
            TARGET_FIELD_IN,
            SOURCE_FIELD_IN,
            FIELD_DIFFERS,
            TARGET_FIELD_ABSENT,
        }
    )


@dataclass(frozen=True)
class HardExclusion:
    """A condition under which the rule refuses to transfer at all (33.3).

    A hard exclusion is not a wide uncertainty band.  It is a declaration
    that the evidence does not carry into that target, and it produces
    ``EXCLUDED`` -- a different status from ``UNSUPPORTED``, because the
    remedy is different: ``UNSUPPORTED`` may be cured by writing a rule,
    ``EXCLUDED`` may not.
    """

    exclusion_id: str
    field: str
    kind: str
    values: Tuple[str, ...] = ()
    reason: str = ""

    def __post_init__(self) -> None:
        if self.kind not in ExclusionKind.ALL:
            raise EvidenceError(f"unknown hard-exclusion kind {self.kind!r}")
        object.__setattr__(self, "values", tuple(sorted(str(v) for v in self.values)))
        if self.kind in (ExclusionKind.TARGET_FIELD_EQUALS, ExclusionKind.TARGET_FIELD_IN,
                         ExclusionKind.SOURCE_FIELD_IN) and not self.values:
            raise EvidenceError(f"exclusion {self.exclusion_id!r} of kind {self.kind} needs values")

    def triggered(
        self, source: ContextDescriptor, target: ContextDescriptor
    ) -> Optional[str]:
        src, tgt = source.as_dict(), target.as_dict()
        if self.kind == ExclusionKind.TARGET_FIELD_EQUALS:
            if tgt.get(self.field) == self.values[0]:
                return (
                    f"{self.exclusion_id}: target field {self.field!r} == "
                    f"{self.values[0]!r}. {self.reason}".strip()
                )
        elif self.kind == ExclusionKind.TARGET_FIELD_IN:
            if tgt.get(self.field) in self.values:
                return (
                    f"{self.exclusion_id}: target field {self.field!r} = "
                    f"{tgt.get(self.field)!r} is in the excluded set "
                    f"{list(self.values)}. {self.reason}".strip()
                )
        elif self.kind == ExclusionKind.SOURCE_FIELD_IN:
            if src.get(self.field) in self.values:
                return (
                    f"{self.exclusion_id}: source field {self.field!r} = "
                    f"{src.get(self.field)!r} is in the excluded set "
                    f"{list(self.values)}. {self.reason}".strip()
                )
        elif self.kind == ExclusionKind.FIELD_DIFFERS:
            if src.get(self.field) != tgt.get(self.field):
                return (
                    f"{self.exclusion_id}: field {self.field!r} differs "
                    f"({src.get(self.field)!r} -> {tgt.get(self.field)!r}). "
                    f"{self.reason}".strip()
                )
        elif self.kind == ExclusionKind.TARGET_FIELD_ABSENT:
            if self.field not in tgt:
                return (
                    f"{self.exclusion_id}: target context does not declare {self.field!r}. "
                    f"{self.reason}".strip()
                )
        return None

    def to_canonical(self) -> dict:
        record: dict = {
            "exclusion_id": self.exclusion_id,
            "field": self.field,
            "kind": self.kind,
        }
        if self.values:
            record["values"] = list(self.values)
        if self.reason:
            record["reason"] = self.reason
        return record


# ---------------------------------------------------------------------------
# transformation / derating (33.3 item 7)
# ---------------------------------------------------------------------------
class TransformationKind:
    IDENTITY = "IDENTITY"
    AFFINE_DERATE = "AFFINE_DERATE"
    SCENARIO_SET = "SCENARIO_SET"

    ALL = frozenset({IDENTITY, AFFINE_DERATE, SCENARIO_SET})


@dataclass(frozen=True)
class Transformation:
    """How the source value becomes the target value.

    ``AFFINE_DERATE`` is ``y = scale * x + offset`` in exact rationals.  It
    is applied to the value and, separately, to each of the four
    non-transfer uncertainty components, so a derated budget still has four
    attributable parts rather than one lump.

    ``SCENARIO_SET`` emits one interval per declared scenario instead of a
    single interval: 33.4 admits scenario enumeration, and 33.6 admits a
    scenario set as the contract's uncertainty representation.
    """

    kind: str
    scale: Exact = Exact(1)
    offset: Exact = Exact(0)
    scenarios: Tuple[Tuple[str, Exact, Exact], ...] = ()
    basis: str = ""

    def __post_init__(self) -> None:
        if self.kind not in TransformationKind.ALL:
            raise EvidenceError(f"unknown transformation kind {self.kind!r} (spec 33.3)")
        object.__setattr__(self, "scale", Exact(self.scale))
        object.__setattr__(self, "offset", Exact(self.offset))
        object.__setattr__(
            self,
            "scenarios",
            tuple((str(n), Exact(s), Exact(o)) for n, s, o in self.scenarios),
        )
        if self.kind == TransformationKind.SCENARIO_SET and not self.scenarios:
            raise EvidenceError("a SCENARIO_SET transformation must enumerate its scenarios")
        if self.kind == TransformationKind.IDENTITY and (
            self.scale != Exact(1) or self.offset != Exact(0)
        ):
            raise EvidenceError("an IDENTITY transformation may not scale or offset")

    @classmethod
    def identity(cls, basis: str = "no derating declared") -> "Transformation":
        return cls(kind=TransformationKind.IDENTITY, basis=basis)

    def apply(self, value: Interval) -> Interval:
        if self.kind == TransformationKind.IDENTITY:
            return value
        return value * Interval(self.scale, self.scale) + Interval(self.offset, self.offset)

    def apply_scenarios(self, value: Interval) -> Tuple[Tuple[str, Interval], ...]:
        if self.kind != TransformationKind.SCENARIO_SET:
            return ()
        return tuple(
            (name, value * Interval(scale, scale) + Interval(offset, offset))
            for name, scale, offset in self.scenarios
        )

    @property
    def deviation_scale(self) -> Exact:
        """The factor an uncertainty *deviation* is multiplied by."""
        if self.kind == TransformationKind.IDENTITY:
            return Exact(1)
        if self.kind == TransformationKind.SCENARIO_SET:
            magnitudes = [abs(s.value) for _, s, _ in self.scenarios] or [abs(self.scale.value)]
            return Exact(max(magnitudes))
        return self.scale

    def to_canonical(self) -> dict:
        record: dict = {
            "kind": self.kind,
            "scale": self.scale.to_canonical(),
            "offset": self.offset.to_canonical(),
        }
        if self.scenarios:
            record["scenarios"] = [
                {"name": n, "scale": s.to_canonical(), "offset": o.to_canonical()}
                for n, s, o in self.scenarios
            ]
        if self.basis:
            record["basis"] = self.basis
        return record


# ---------------------------------------------------------------------------
# transfer uncertainty model (33.3 item 8, 33.4)
# ---------------------------------------------------------------------------
class TransferModelKind:
    DECLARED_INTERVAL = "DECLARED_INTERVAL"
    PROPORTIONAL = "PROPORTIONAL"
    PER_DIFFERENCE_SUM = "PER_DIFFERENCE_SUM"
    NONE_DECLARED = "NONE_DECLARED"

    ALL = frozenset({DECLARED_INTERVAL, PROPORTIONAL, PER_DIFFERENCE_SUM, NONE_DECLARED})


@dataclass(frozen=True)
class TransferUncertaintyModel:
    """What crossing contexts costs, and on what basis (33.3, 33.4).

    ``NONE_DECLARED`` is admissible and means exactly what it says: the rule
    asserts zero transfer uncertainty and must justify that in ``basis``.  It
    is not the same as omitting the model, which cannot be spelled.
    """

    model_id: str
    kind: str
    correlation_assumption: str
    basis: str
    interval: Optional[Interval] = None
    proportional_fraction: Optional[Exact] = None

    def __post_init__(self) -> None:
        if self.kind not in TransferModelKind.ALL:
            raise EvidenceError(f"unknown transfer-uncertainty model kind {self.kind!r}")
        if self.correlation_assumption not in CorrelationAssumption.ALL:
            raise EvidenceError(
                f"transfer model {self.model_id!r} declares correlation "
                f"{self.correlation_assumption!r}; spec 33.4 requires one of "
                f"{sorted(CorrelationAssumption.ALL)}"
            )
        if not self.basis:
            raise EvidenceError(
                f"transfer model {self.model_id!r} declares no validation basis; spec 33.4 "
                "requires the model's assumptions to be stated"
            )
        if self.kind == TransferModelKind.DECLARED_INTERVAL and self.interval is None:
            raise EvidenceError("a DECLARED_INTERVAL transfer model must declare its interval")
        if self.kind == TransferModelKind.PROPORTIONAL and self.proportional_fraction is None:
            raise EvidenceError("a PROPORTIONAL transfer model must declare its fraction")
        if self.proportional_fraction is not None:
            object.__setattr__(
                self, "proportional_fraction", Exact(self.proportional_fraction)
            )

    def transfer_interval(
        self, transformed_value: Interval, differences: Sequence[PermittedDifference]
    ) -> Interval:
        """The ``transfer`` component of the budget for this application."""
        if self.kind == TransferModelKind.NONE_DECLARED:
            return Interval(0, 0)
        if self.kind == TransferModelKind.DECLARED_INTERVAL:
            assert self.interval is not None
            return self.interval
        if self.kind == TransferModelKind.PROPORTIONAL:
            assert self.proportional_fraction is not None
            magnitude = max(
                abs(transformed_value.lo.value), abs(transformed_value.hi.value)
            )
            span = Exact(magnitude) * self.proportional_fraction
            return Interval(-span.value, span.value)
        # PER_DIFFERENCE_SUM: each bridged difference contributes its declared cost.
        total = Interval(0, 0)
        for difference in differences:
            if difference.added_transfer_uncertainty is not None:
                total = total + difference.added_transfer_uncertainty
        if self.interval is not None:
            total = total + self.interval
        return total

    def to_canonical(self) -> dict:
        record: dict = {
            "model_id": self.model_id,
            "kind": self.kind,
            "correlation_assumption": self.correlation_assumption,
            "basis": self.basis,
        }
        if self.interval is not None:
            record["interval"] = self.interval.to_canonical()
        if self.proportional_fraction is not None:
            record["proportional_fraction"] = self.proportional_fraction.to_canonical()
        return record


# ---------------------------------------------------------------------------
# the rule (33.3)
# ---------------------------------------------------------------------------
#: The fourteen things a rule MUST identify (spec 33.3).  Specification
#: v0.1.0 section 18.3 listed thirteen; v0.2.0 33.3 adds ``authority``.  The
#: superset is declared, so a rule written to either revision is complete
#: under this implementation and neither list is silently dropped.
DECLARED_FIELDS: Tuple[str, ...] = (
    "input_quantity",
    "output_quantity",
    "source_context_pattern",
    "target_context_pattern",
    "exact_match_fields",
    "permitted_differences",
    "hard_exclusions",
    "transformation",
    "transfer_uncertainty_model",
    "minimum_evidence_status",
    "correlation_assumption",
    "validation_basis",
    "authority",
    "expiration",
    "revalidation_triggers",
)


@dataclass(frozen=True)
class ApplicabilityRule:
    """A registered rule for carrying evidence into a target context (33.3).

    Every field of 33.3 is present and, except for the list-valued ones whose
    empty value is itself a declaration, none has a default.  A rule that
    does not say what its authority is, or whether it expires, cannot be
    constructed: ``expiration=None`` is a positive declaration of "no expiry",
    and it must be written.
    """

    rule_id: str
    input_quantity: QuantityType
    output_quantity: QuantityType
    source_context_pattern: ContextPattern
    target_context_pattern: ContextPattern
    exact_match_fields: Tuple[str, ...]
    permitted_differences: Tuple[PermittedDifference, ...]
    hard_exclusions: Tuple[HardExclusion, ...]
    transformation: Transformation
    transfer_uncertainty_model: TransferUncertaintyModel
    minimum_evidence_status: str
    correlation_assumption: str
    validation_basis: str
    authority: str
    expiration: Optional[str]
    revalidation_triggers: Tuple[str, ...]
    unit_conversions: Tuple[UnitConversion, ...] = ()
    coordinate_id: Optional[str] = None
    rule_version: str = "1"

    def __post_init__(self) -> None:
        object.__setattr__(self, "exact_match_fields", tuple(sorted(str(f) for f in self.exact_match_fields)))
        object.__setattr__(self, "permitted_differences", tuple(self.permitted_differences))
        object.__setattr__(self, "hard_exclusions", tuple(self.hard_exclusions))
        object.__setattr__(
            self, "revalidation_triggers", tuple(str(t) for t in self.revalidation_triggers)
        )
        object.__setattr__(self, "unit_conversions", tuple(self.unit_conversions))
        if self.minimum_evidence_status not in EvidenceStatus.ALL:
            raise EvidenceError(
                f"rule {self.rule_id!r} declares minimum evidence status "
                f"{self.minimum_evidence_status!r}; expected one of "
                f"{sorted(EvidenceStatus.ALL)}"
            )
        if self.correlation_assumption not in CorrelationAssumption.ALL:
            raise EvidenceError(
                f"rule {self.rule_id!r} must state a correlation assumption (spec 33.4); "
                f"{self.correlation_assumption!r} is not one of "
                f"{sorted(CorrelationAssumption.ALL)}"
            )
        if not self.validation_basis:
            raise EvidenceError(
                f"rule {self.rule_id!r} declares no validation basis; spec 33.3 requires one"
            )
        if not self.authority:
            raise EvidenceError(
                f"rule {self.rule_id!r} declares no authority; spec 33.3 requires one"
            )
        if self.expiration is not None and not isinstance(self.expiration, str):
            raise EvidenceError("rule expiration must be an ISO-8601 instant or None")

    @property
    def target_coordinate(self) -> str:
        """The contract coordinate this rule produces."""
        return self.coordinate_id or self.output_quantity.quantity_id

    @property
    def validity(self) -> ValidityWindow:
        return ValidityWindow(
            expires_at=self.expiration,
            revalidation_triggers=self.revalidation_triggers,
            issuer_clock_source=f"rule-authority:{self.authority}",
        )

    def declaration_audit(self) -> Dict[str, bool]:
        """Which of the 33.3 items this rule actually declares.

        ``False`` never appears for a constructed rule -- the constructor
        refuses -- but the audit is emitted into the assembly report so a
        reader can see the fourteen items were checked rather than assumed.
        """
        return {name: True for name in DECLARED_FIELDS}

    def conversion_for(self, unit: str) -> Optional[UnitConversion]:
        for conversion in self.unit_conversions:
            if conversion.applies(self.input_quantity.quantity_id, unit, self.input_quantity.unit):
                return conversion
        return None

    def to_canonical(self) -> dict:
        return {
            "record_type": "etq.applicability_rule",
            "spec_section": "33.3",
            "rule_id": self.rule_id,
            "rule_version": self.rule_version,
            "input_quantity": self.input_quantity.to_canonical(),
            "output_quantity": self.output_quantity.to_canonical(),
            "source_context_pattern": self.source_context_pattern.to_canonical(),
            "target_context_pattern": self.target_context_pattern.to_canonical(),
            "exact_match_fields": list(self.exact_match_fields),
            "permitted_differences": [d.to_canonical() for d in self.permitted_differences],
            "hard_exclusions": [x.to_canonical() for x in self.hard_exclusions],
            "transformation": self.transformation.to_canonical(),
            "transfer_uncertainty_model": self.transfer_uncertainty_model.to_canonical(),
            "minimum_evidence_status": self.minimum_evidence_status,
            "correlation_assumption": self.correlation_assumption,
            "validation_basis": self.validation_basis,
            "authority": self.authority,
            "expiration": self.expiration,
            "revalidation_triggers": list(self.revalidation_triggers),
            "unit_conversions": [c.to_canonical() for c in self.unit_conversions],
            "coordinate_id": self.target_coordinate,
        }

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())


# ---------------------------------------------------------------------------
# the result
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class ApplicabilityResult:
    """The outcome of applying one rule to one record for one target.

    A non-``APPLICABLE`` result carries no transformed value at all.  There
    is no "best effort" field, because a value that survives an inapplicable
    rule is exactly the assumed default 33.3 forbids.
    """

    status: str
    evidence_id: str
    evidence_hash: str
    rule_id: Optional[str]
    rule_hash: Optional[str]
    reason_code: str
    detail: str
    target_context_fingerprint: str
    source_context_fingerprint: str
    coordinate_id: Optional[str] = None
    quantity: Optional[str] = None
    unit: Optional[str] = None
    transformed_value: Optional[Interval] = None
    scenario_values: Tuple[Tuple[str, Interval], ...] = ()
    budget: Optional[UncertaintyBudget] = None
    correlation_assumption: Optional[str] = None
    time_judgment: Optional[TimeJudgment] = None
    rule_time_judgment: Optional[TimeJudgment] = None
    differences_bridged: Tuple[str, ...] = ()
    unit_conversion_applied: Optional[str] = None
    validity: Optional[ValidityWindow] = None
    notes: Tuple[str, ...] = ()

    @property
    def applicable(self) -> bool:
        return self.status == ApplicabilityStatus.APPLICABLE

    def to_canonical(self) -> dict:
        record: dict = {
            "status": self.status,
            "reason_code": self.reason_code,
            "detail": self.detail,
            "evidence_id": self.evidence_id,
            "evidence_hash": self.evidence_hash,
            "rule_id": self.rule_id,
            "rule_hash": self.rule_hash,
            "source_context_fingerprint": self.source_context_fingerprint,
            "target_context_fingerprint": self.target_context_fingerprint,
        }
        for key, value in (
            ("coordinate_id", self.coordinate_id),
            ("quantity", self.quantity),
            ("unit", self.unit),
            ("correlation_assumption", self.correlation_assumption),
            ("unit_conversion_applied", self.unit_conversion_applied),
        ):
            if value is not None:
                record[key] = value
        if self.transformed_value is not None:
            record["transformed_value"] = self.transformed_value.to_canonical()
        if self.scenario_values:
            record["scenario_values"] = [
                {"scenario": n, "interval": iv.to_canonical()} for n, iv in self.scenario_values
            ]
        if self.budget is not None:
            record["uncertainty_budget"] = self.budget.to_canonical()
        if self.time_judgment is not None:
            record["evidence_time_judgment"] = self.time_judgment.to_canonical()
        if self.rule_time_judgment is not None:
            record["rule_time_judgment"] = self.rule_time_judgment.to_canonical()
        if self.differences_bridged:
            record["differences_bridged"] = list(self.differences_bridged)
        if self.validity is not None:
            record["validity"] = self.validity.to_canonical()
        if self.notes:
            record["notes"] = list(self.notes)
        return record


def _refuse(
    status: str,
    reason_code: str,
    detail: str,
    evidence: EvidenceRecord,
    rule: Optional[ApplicabilityRule],
    target: ContextDescriptor,
    **extra: Any,
) -> ApplicabilityResult:
    return ApplicabilityResult(
        status=status,
        evidence_id=evidence.evidence_id,
        evidence_hash=evidence.fingerprint(),
        rule_id=rule.rule_id if rule else None,
        rule_hash=rule.fingerprint() if rule else None,
        reason_code=reason_code,
        detail=detail,
        target_context_fingerprint=target.fingerprint(),
        source_context_fingerprint=evidence.source_context.fingerprint(),
        coordinate_id=rule.target_coordinate if rule else None,
        quantity=evidence.quantity,
        unit=evidence.unit,
        **extra,
    )


# ---------------------------------------------------------------------------
# the decision (33.3)
# ---------------------------------------------------------------------------
def apply_rule(
    evidence: EvidenceRecord,
    rule: ApplicabilityRule,
    target_context: ContextDescriptor,
    *,
    clock: Optional[VerificationClock] = None,
    requester: Optional[Requester] = None,
) -> ApplicabilityResult:
    """Decide whether ``rule`` carries ``evidence`` into ``target_context``.

    The gates run in the declared :data:`CHECK_ORDER` and each failure
    carries its own reason code.  Success produces a transformed value, a
    five-component budget whose ``transfer`` term the rule's transfer model
    supplied, and the correlation assumption under which those components may
    later be combined -- never a combined number.
    """
    target_fp = target_context.fingerprint()

    # 1. access (44.2).  Refused first: a requester who may not read the
    #    record does not learn why else it would have failed.
    if not evidence.permits(requester):
        return _refuse(
            ApplicabilityStatus.UNAUTHORIZED,
            ReasonCode.ACCESS_DENIED,
            evidence.access.refusal(requester),
            evidence,
            rule,
            target_context,
        )

    # 2. quantity identity (13.1, 13.4): never inferred from the unit.
    if evidence.quantity != rule.input_quantity.quantity_id:
        return _refuse(
            ApplicabilityStatus.UNSUPPORTED,
            ReasonCode.QUANTITY_MISMATCH,
            (
                f"evidence quantity {evidence.quantity!r} is not the rule's input quantity "
                f"{rule.input_quantity.quantity_id!r}; quantity identity is part of "
                "certificate semantics and is never inferred from the unit (spec 13.1, 13.4)"
            ),
            evidence,
            rule,
            target_context,
        )

    # 3. unit (13.3): a mismatch blocks arithmetic unless a registered
    #    conversion exists.  There is no implicit conversion table.
    conversion: Optional[UnitConversion] = None
    if evidence.unit != rule.input_quantity.unit:
        conversion = rule.conversion_for(evidence.unit)
        if conversion is None:
            return _refuse(
                ApplicabilityStatus.UNSUPPORTED,
                ReasonCode.UNIT_MISMATCH,
                (
                    f"evidence is in {evidence.unit!r}, rule {rule.rule_id!r} takes "
                    f"{rule.input_quantity.unit!r}, and no explicit registered conversion "
                    f"for quantity {evidence.quantity!r} exists on this rule; a unit "
                    "mismatch MUST block arithmetic (spec 13.3)"
                ),
                evidence,
                rule,
                target_context,
            )

    # 4. hard exclusions (33.3): checked before pattern matching, so an
    #    excluded transfer reports EXCLUDED rather than UNSUPPORTED.
    for exclusion in rule.hard_exclusions:
        triggered = exclusion.triggered(evidence.source_context, target_context)
        if triggered:
            return _refuse(
                ApplicabilityStatus.EXCLUDED,
                ReasonCode.HARD_CONTEXT_EXCLUSION,
                triggered,
                evidence,
                rule,
                target_context,
            )

    # 5-6. context patterns (33.3).
    matched, failures = rule.source_context_pattern.matches(evidence.source_context)
    if not matched:
        return _refuse(
            ApplicabilityStatus.UNSUPPORTED,
            ReasonCode.SOURCE_CONTEXT_PATTERN_MISMATCH,
            "source context does not match the rule pattern: " + "; ".join(failures),
            evidence,
            rule,
            target_context,
        )
    matched, failures = rule.target_context_pattern.matches(target_context)
    if not matched:
        return _refuse(
            ApplicabilityStatus.UNSUPPORTED,
            ReasonCode.TARGET_CONTEXT_PATTERN_MISMATCH,
            "target context does not match the rule pattern: " + "; ".join(failures),
            evidence,
            rule,
            target_context,
        )

    # 7. exact-match fields (33.3).
    source_fields = evidence.source_context.as_dict()
    target_fields = target_context.as_dict()
    for name in rule.exact_match_fields:
        if source_fields.get(name) != target_fields.get(name):
            return _refuse(
                ApplicabilityStatus.UNSUPPORTED,
                ReasonCode.EXACT_MATCH_FIELD_DIFFERS,
                (
                    f"rule {rule.rule_id!r} requires exact match on {name!r}; source has "
                    f"{source_fields.get(name)!r} and target has {target_fields.get(name)!r}"
                ),
                evidence,
                rule,
                target_context,
            )

    # 8. every remaining difference must be explicitly permitted (33.3).
    permitted_by_field = {d.field: d for d in rule.permitted_differences}
    bridged: list = []
    bridged_names: list = []
    for name in evidence.source_context.differing_fields(target_context):
        if name in rule.exact_match_fields:
            continue  # already checked and equal
        difference = permitted_by_field.get(name)
        if difference is None:
            return _refuse(
                ApplicabilityStatus.UNSUPPORTED,
                ReasonCode.DIFFERENCE_NOT_PERMITTED,
                (
                    f"contexts differ in {name!r} "
                    f"({source_fields.get(name)!r} -> {target_fields.get(name)!r}) and rule "
                    f"{rule.rule_id!r} does not list it as a permitted difference; an "
                    "unlisted difference is UNSUPPORTED, not an assumed default (spec 33.3)"
                ),
                evidence,
                rule,
                target_context,
            )
        ok, why = difference.permits(source_fields.get(name), target_fields.get(name))
        if not ok:
            return _refuse(
                ApplicabilityStatus.UNSUPPORTED,
                ReasonCode.DIFFERENCE_NOT_PERMITTED,
                why,
                evidence,
                rule,
                target_context,
            )
        bridged.append(difference)
        bridged_names.append(name)

    # 9. minimum evidence status (33.3), and 5.3 heuristic gating.
    if not evidence.may_authorize:
        return _refuse(
            ApplicabilityStatus.UNSUPPORTED,
            ReasonCode.HEURISTIC_MAY_NOT_AUTHORIZE,
            (
                f"evidence {evidence.evidence_id!r} is class HEURISTIC; a heuristic may "
                "suggest an evidence mapping but may not silently authorize evidence "
                "applicability (spec 5.3)"
            ),
            evidence,
            rule,
            target_context,
        )
    if not EvidenceStatus.meets(evidence.evidence_status, rule.minimum_evidence_status):
        return _refuse(
            ApplicabilityStatus.UNSUPPORTED,
            ReasonCode.EVIDENCE_STATUS_BELOW_MINIMUM,
            (
                f"evidence status {evidence.evidence_status!r} is below the rule minimum "
                f"{rule.minimum_evidence_status!r}"
            ),
            evidence,
            rule,
            target_context,
        )

    # 10. lifecycle (12, 33.5 superseded evidence).
    if evidence.is_superseded:
        return _refuse(
            ApplicabilityStatus.UNSUPPORTED,
            ReasonCode.EVIDENCE_SUPERSEDED,
            (
                f"evidence {evidence.evidence_id!r} is superseded"
                + (f" by {evidence.superseded_by!r}" if evidence.superseded_by else "")
            ),
            evidence,
            rule,
            target_context,
        )
    if evidence.status != "ACTIVE":
        return _refuse(
            ApplicabilityStatus.UNSUPPORTED,
            ReasonCode.EVIDENCE_NOT_ACTIVE,
            f"evidence {evidence.evidence_id!r} has lifecycle status {evidence.status!r}",
            evidence,
            rule,
            target_context,
        )

    # 11-12. time, against the *supplied* clock only (45.3).
    evidence_time = evidence.time_judgment(clock)
    rule_time = evaluate_time(rule.validity, clock)
    blocking = {
        TimeStatus.EXPIRED: (ReasonCode.EVIDENCE_EXPIRED, ApplicabilityStatus.EXPIRED),
        TimeStatus.NOT_YET_VALID: (ReasonCode.EVIDENCE_NOT_YET_VALID, ApplicabilityStatus.UNSUPPORTED),
        TimeStatus.STALE: (ReasonCode.EVIDENCE_STALE, ApplicabilityStatus.EXPIRED),
        TimeStatus.CLOCK_POLICY_VIOLATION: (
            ReasonCode.CLOCK_POLICY_VIOLATION,
            ApplicabilityStatus.UNSUPPORTED,
        ),
    }
    if evidence_time.time_status in blocking:
        code, status = blocking[evidence_time.time_status]
        return _refuse(
            status,
            code,
            f"evidence validity: {evidence_time.detail}",
            evidence,
            rule,
            target_context,
            time_judgment=evidence_time,
            rule_time_judgment=rule_time,
        )
    if rule_time.time_status == TimeStatus.EXPIRED:
        return _refuse(
            ApplicabilityStatus.EXPIRED,
            ReasonCode.RULE_EXPIRED,
            f"rule {rule.rule_id!r} expired: {rule_time.detail}",
            evidence,
            rule,
            target_context,
            time_judgment=evidence_time,
            rule_time_judgment=rule_time,
        )
    if rule_time.time_status in (TimeStatus.NOT_YET_VALID, TimeStatus.CLOCK_POLICY_VIOLATION):
        return _refuse(
            ApplicabilityStatus.UNSUPPORTED,
            ReasonCode.CLOCK_POLICY_VIOLATION,
            f"rule {rule.rule_id!r} time status {rule_time.time_status}: {rule_time.detail}",
            evidence,
            rule,
            target_context,
            time_judgment=evidence_time,
            rule_time_judgment=rule_time,
        )

    # -- the rule applies.  Now transform, and account for the transfer. --
    value = evidence.value
    budget = evidence.uncertainty
    notes = []
    if conversion is not None:
        value = conversion.convert(value)
        budget = UncertaintyBudget(
            measurement=conversion.convert_deviation(budget.measurement),
            sampling=conversion.convert_deviation(budget.sampling),
            calibration=conversion.convert_deviation(budget.calibration),
            transfer=conversion.convert_deviation(budget.transfer),
            model=conversion.convert_deviation(budget.model),
            basis=budget.basis,
        )
        notes.append(
            f"registered unit conversion {conversion.conversion_id!r} "
            f"({conversion.from_unit} -> {conversion.to_unit}) applied, factor "
            f"{conversion.factor}, registered by {conversion.registered_by!r} (spec 13.3)"
        )

    transformed = rule.transformation.apply(value)
    scenarios = rule.transformation.apply_scenarios(value)
    budget = budget.scaled(rule.transformation.deviation_scale)
    transfer = rule.transfer_uncertainty_model.transfer_interval(transformed, bridged)
    budget = budget.with_transfer(
        transfer,
        basis=(
            f"transfer model {rule.transfer_uncertainty_model.model_id!r} "
            f"({rule.transfer_uncertainty_model.kind}) under rule {rule.rule_id!r}: "
            f"{rule.transfer_uncertainty_model.basis}"
        ),
    )
    notes.append(
        f"transformation {rule.transformation.kind} applied "
        f"(scale {rule.transformation.scale}, offset {rule.transformation.offset}); the four "
        "non-transfer uncertainty components were scaled individually and the transfer "
        "component was set by the rule's declared model, so the five components of spec "
        "33.4 remain separately attributable"
    )
    if evidence_time.indeterminate:
        notes.append(
            f"evidence time status TIME_INDETERMINATE ({evidence_time.detail}); disclosed, "
            "not treated as CURRENT (spec 45.5)"
        )
    if rule_time.indeterminate:
        notes.append(
            f"rule time status TIME_INDETERMINATE ({rule_time.detail}); disclosed, not "
            "treated as CURRENT (spec 45.5)"
        )

    return ApplicabilityResult(
        status=ApplicabilityStatus.APPLICABLE,
        evidence_id=evidence.evidence_id,
        evidence_hash=evidence.fingerprint(),
        rule_id=rule.rule_id,
        rule_hash=rule.fingerprint(),
        reason_code=ReasonCode.APPLICABLE,
        detail=(
            f"rule {rule.rule_id!r} (authority {rule.authority!r}, basis "
            f"{rule.validation_basis!r}) carries {evidence.evidence_id!r} into "
            f"{target_context.context_id!r}"
        ),
        target_context_fingerprint=target_fp,
        source_context_fingerprint=evidence.source_context.fingerprint(),
        coordinate_id=rule.target_coordinate,
        quantity=rule.output_quantity.quantity_id,
        unit=rule.output_quantity.unit,
        transformed_value=transformed,
        scenario_values=scenarios,
        budget=budget,
        correlation_assumption=rule.correlation_assumption,
        time_judgment=evidence_time,
        rule_time_judgment=rule_time,
        differences_bridged=tuple(bridged_names),
        unit_conversion_applied=conversion.conversion_id if conversion else None,
        validity=evidence.validity.intersect(rule.validity),
        notes=tuple(notes),
    )


def select_rule(
    evidence: EvidenceRecord,
    rules: Sequence[ApplicabilityRule],
    target_context: ContextDescriptor,
    *,
    clock: Optional[VerificationClock] = None,
    requester: Optional[Requester] = None,
) -> Tuple[Optional[ApplicabilityResult], Tuple[ApplicabilityResult, ...]]:
    """Find the rule that carries ``evidence``, or report why none does.

    Returns ``(applicable_result_or_None, all_results)``.  When no rule
    applies the first element is ``None`` -- there is no nearest-match
    fallback and no identity default, because 33.3 says an absent rule means
    ``UNSUPPORTED``.  With an empty rule list the single synthesized result
    is ``UNSUPPORTED`` / ``NO_RULES_DECLARED``, which is the same refusal
    said out loud.
    """
    if not rules:
        return None, (
            _refuse(
                ApplicabilityStatus.UNSUPPORTED,
                ReasonCode.NO_RULES_DECLARED,
                (
                    f"no applicability rule was declared for evidence "
                    f"{evidence.evidence_id!r} into context {target_context.context_id!r}; "
                    "no applicable rule means UNSUPPORTED, not an assumed default "
                    "(spec 33.3)"
                ),
                evidence,
                None,
                target_context,
            ),
        )
    results = tuple(
        apply_rule(evidence, rule, target_context, clock=clock, requester=requester)
        for rule in rules
    )
    for result in results:
        if result.applicable:
            return result, results
    return None, results
