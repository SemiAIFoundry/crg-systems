"""Conflict handling: how a set of evidence records relates.

Normative basis: master specification 33.5 (conflict handling), with 5.3
(heuristic evidence may not authorize), 12 (lifecycle), 44.2 (access), and
45 (time).

Specification 33.5 requires eight relations to be *distinguished* and then
says the thing that matters:

    It MUST NOT silently average away conflict.

There is no arithmetic mean anywhere in this module.  Contradictory
evidence -- evidence whose enclosures do not intersect -- produces the
relation ``CONTRADICTORY``, ``fusible = False``, and ``fused_interval =
None``.  :func:`fuse` raises on it.  :mod:`etq_evidence.contract` refuses
to emit the coordinate.  There is no code path that turns two disjoint
intervals into one number.

Where fusion *is* admissible it is still not averaging:

* ``SUPPORTING``               -> the **intersection** of the enclosures.
  Every member is a valid enclosure of the same quantity produced the same
  way, so their intersection is also a valid enclosure and is sharper.
* ``HETEROGENEOUS_COMPATIBLE`` -> the **hull**.  Different methods may carry
  method bias that no member's budget models, so intersecting would claim a
  sharpness the evidence does not support.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional, Sequence, Tuple, Union

from crg_model.canonical import content_hash
from crg_model.numeric import Interval

from .applicability import ApplicabilityResult
from .clock import TimeJudgment, ValidityWindow, VerificationClock, evaluate_time
from .record import (
    AccessPolicy,
    ContextDescriptor,
    CorrelationAssumption,
    EvidenceError,
    EvidenceRecord,
    Requester,
    UncertaintyBudget,
)

__all__ = [
    "RelationKind",
    "ConflictRefusal",
    "TransferredEvidence",
    "EvidenceMember",
    "EvidenceRelation",
    "classify_evidence_set",
    "fuse",
]


class RelationKind:
    """The eight relations of specification 33.5."""

    SUPPORTING = "SUPPORTING"
    HETEROGENEOUS_COMPATIBLE = "HETEROGENEOUS_COMPATIBLE"
    CONTRADICTORY = "CONTRADICTORY"
    CONTEXT_INCOMPARABLE = "CONTEXT_INCOMPARABLE"
    EXPIRED = "EXPIRED"
    SUPERSEDED = "SUPERSEDED"
    UNSUPPORTED = "UNSUPPORTED"
    UNAUTHORIZED = "UNAUTHORIZED"

    ALL = frozenset(
        {
            SUPPORTING,
            HETEROGENEOUS_COMPATIBLE,
            CONTRADICTORY,
            CONTEXT_INCOMPARABLE,
            EXPIRED,
            SUPERSEDED,
            UNSUPPORTED,
            UNAUTHORIZED,
        }
    )
    #: Relations from which a bounded coordinate may be derived.
    FUSIBLE = frozenset({SUPPORTING, HETEROGENEOUS_COMPATIBLE})
    #: Relations that MUST block a coordinate rather than be resolved (6.6).
    BLOCKING = frozenset(
        {CONTRADICTORY, CONTEXT_INCOMPARABLE, EXPIRED, SUPERSEDED, UNSUPPORTED, UNAUTHORIZED}
    )


class ConflictRefusal(ValueError):
    """Raised when fusion is demanded of evidence that MUST NOT be fused."""


# ---------------------------------------------------------------------------
# members
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class TransferredEvidence:
    """An evidence record together with the rule application that carried it.

    This is the object 33.5 actually reasons over once 33.3 has run: the
    value is the *transformed* value in the target context and the budget
    carries the rule's transfer term.
    """

    evidence: EvidenceRecord
    result: ApplicabilityResult

    def __post_init__(self) -> None:
        if not self.result.applicable:
            raise EvidenceError(
                f"{self.evidence.evidence_id!r} was not carried by rule "
                f"{self.result.rule_id!r} ({self.result.reason_code}); an inapplicable "
                "result may not be presented as transferred evidence (spec 33.3)"
            )


EvidenceLike = Union[EvidenceRecord, TransferredEvidence]


@dataclass(frozen=True)
class EvidenceMember:
    """One normalized participant in a relation, transferred or raw."""

    evidence_id: str
    evidence_hash: str
    quantity: str
    unit: str
    value: Interval
    budget: UncertaintyBudget
    context: ContextDescriptor
    method_id: str
    evidence_class: str
    access: AccessPolicy
    validity: ValidityWindow
    is_superseded: bool
    superseded_by: Optional[str]
    supersedes: Tuple[str, ...]
    may_authorize: bool
    rule_id: Optional[str] = None
    rule_hash: Optional[str] = None
    coordinate_id: Optional[str] = None
    transferred: bool = False

    def enclosure(self, *, correlation: str) -> Interval:
        return self.value + self.budget.combine(correlation=correlation)

    def to_canonical(self) -> dict:
        record: dict = {
            "evidence_id": self.evidence_id,
            "evidence_hash": self.evidence_hash,
            "quantity": self.quantity,
            "unit": self.unit,
            "value": self.value.to_canonical(),
            "uncertainty": self.budget.to_canonical(),
            "context_fingerprint": self.context.fingerprint(),
            "context_type": self.context.context_type,
            "method_id": self.method_id,
            "evidence_class": self.evidence_class,
            "transferred": self.transferred,
        }
        if self.rule_id:
            record["rule_id"] = self.rule_id
            record["rule_hash"] = self.rule_hash
        if self.coordinate_id:
            record["coordinate_id"] = self.coordinate_id
        return record


def _member(item: EvidenceLike) -> EvidenceMember:
    if isinstance(item, TransferredEvidence):
        evidence, result = item.evidence, item.result
        assert result.transformed_value is not None and result.budget is not None
        return EvidenceMember(
            evidence_id=evidence.evidence_id,
            evidence_hash=result.evidence_hash,
            quantity=result.quantity or evidence.quantity,
            unit=result.unit or evidence.unit,
            value=result.transformed_value,
            budget=result.budget,
            context=evidence.source_context,
            method_id=evidence.method.method_id,
            evidence_class=evidence.method.evidence_class,
            access=evidence.access,
            validity=result.validity or evidence.validity,
            is_superseded=evidence.is_superseded,
            superseded_by=evidence.superseded_by,
            supersedes=evidence.supersedes,
            may_authorize=evidence.may_authorize,
            rule_id=result.rule_id,
            rule_hash=result.rule_hash,
            coordinate_id=result.coordinate_id,
            transferred=True,
        )
    if isinstance(item, EvidenceRecord):
        return EvidenceMember(
            evidence_id=item.evidence_id,
            evidence_hash=item.fingerprint(),
            quantity=item.quantity,
            unit=item.unit,
            value=item.value,
            budget=item.uncertainty,
            context=item.source_context,
            method_id=item.method.method_id,
            evidence_class=item.method.evidence_class,
            access=item.access,
            validity=item.validity,
            is_superseded=item.is_superseded,
            superseded_by=item.superseded_by,
            supersedes=item.supersedes,
            may_authorize=item.may_authorize,
            coordinate_id=item.quantity,
            transferred=False,
        )
    raise EvidenceError(f"cannot classify {type(item)!r} as evidence")


# ---------------------------------------------------------------------------
# the relation
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class EvidenceRelation:
    """How a set of evidence records relates (spec 33.5).

    The eight relation names of 33.5 are available as class attributes, so
    ``relation.relation == EvidenceRelation.CONTRADICTORY`` reads directly.

    ``fused_interval`` is ``None`` for every non-fusible relation.  For
    ``CONTRADICTORY`` that is the whole point: there is no value to hand on,
    and none is invented.
    """

    SUPPORTING = RelationKind.SUPPORTING
    HETEROGENEOUS_COMPATIBLE = RelationKind.HETEROGENEOUS_COMPATIBLE
    CONTRADICTORY = RelationKind.CONTRADICTORY
    CONTEXT_INCOMPARABLE = RelationKind.CONTEXT_INCOMPARABLE
    EXPIRED = RelationKind.EXPIRED
    SUPERSEDED = RelationKind.SUPERSEDED
    UNSUPPORTED = RelationKind.UNSUPPORTED
    UNAUTHORIZED = RelationKind.UNAUTHORIZED

    relation: str
    quantity: Optional[str]
    unit: Optional[str]
    correlation_assumption: str
    correlation_statement: str
    members: Tuple[EvidenceMember, ...] = ()
    usable: Tuple[str, ...] = ()
    expired: Tuple[str, ...] = ()
    superseded: Tuple[str, ...] = ()
    unauthorized: Tuple[str, ...] = ()
    unsupported: Tuple[str, ...] = ()
    incomparable: Tuple[str, ...] = ()
    enclosures: Tuple[Tuple[str, Interval], ...] = ()
    disjoint_pairs: Tuple[Tuple[str, str], ...] = ()
    intersection: Optional[Interval] = None
    hull: Optional[Interval] = None
    fused_interval: Optional[Interval] = None
    fused_budget: Optional[UncertaintyBudget] = None
    fusion_rule: str = ""
    refusal: Optional[str] = None
    time_judgments: Tuple[Tuple[str, TimeJudgment], ...] = ()
    notes: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if self.relation not in RelationKind.ALL:
            raise EvidenceError(f"unknown evidence relation {self.relation!r} (spec 33.5)")
        if self.relation not in RelationKind.FUSIBLE and self.fused_interval is not None:
            raise EvidenceError(
                f"relation {self.relation} is not fusible but a fused interval was "
                "supplied; spec 33.5 forbids resolving conflict into a value"
            )

    @property
    def fusible(self) -> bool:
        return self.relation in RelationKind.FUSIBLE and self.fused_interval is not None

    @property
    def blocks(self) -> bool:
        return self.relation in RelationKind.BLOCKING

    def is_(self, kind: str) -> bool:
        return self.relation == kind

    def to_canonical(self) -> dict:
        record: dict = {
            "record_type": "etq.evidence_relation",
            "spec_section": "33.5",
            "relation": self.relation,
            "quantity": self.quantity,
            "unit": self.unit,
            "correlation_assumption": self.correlation_assumption,
            "correlation_statement": self.correlation_statement,
            "members": [m.to_canonical() for m in self.members],
            "usable": list(self.usable),
            "expired": list(self.expired),
            "superseded": list(self.superseded),
            "unauthorized": list(self.unauthorized),
            "unsupported": list(self.unsupported),
            "incomparable": list(self.incomparable),
            "enclosures": [
                {"evidence_id": eid, "interval": iv.to_canonical()} for eid, iv in self.enclosures
            ],
        }
        if self.disjoint_pairs:
            record["disjoint_pairs"] = [list(pair) for pair in self.disjoint_pairs]
        if self.intersection is not None:
            record["intersection"] = self.intersection.to_canonical()
        if self.hull is not None:
            record["hull"] = self.hull.to_canonical()
        if self.fused_interval is not None:
            record["fused_interval"] = self.fused_interval.to_canonical()
            record["fusion_rule"] = self.fusion_rule
        if self.fused_budget is not None:
            record["fused_uncertainty"] = self.fused_budget.to_canonical()
        if self.refusal:
            record["refusal"] = self.refusal
        if self.time_judgments:
            record["time_judgments"] = [
                {"evidence_id": eid, **judgment.to_canonical()}
                for eid, judgment in self.time_judgments
            ]
        if self.notes:
            record["notes"] = list(self.notes)
        return record

    def fingerprint(self) -> str:
        return content_hash(self.to_canonical())


def _intersect(a: Interval, b: Interval) -> Optional[Interval]:
    lo = max(a.lo, b.lo, key=lambda e: e.value)
    hi = min(a.hi, b.hi, key=lambda e: e.value)
    if hi < lo:
        return None
    return Interval(lo, hi)


def classify_evidence_set(
    records: Sequence[EvidenceLike],
    *,
    clock: Optional[VerificationClock] = None,
    requester: Optional[Requester] = None,
    correlation: str = CorrelationAssumption.UNKNOWN,
    comparable_fields: Sequence[str] = (),
) -> EvidenceRelation:
    """Classify how a set of evidence records relates (spec 33.5).

    ``correlation`` states, once and in the result, the assumption under
    which each member's value and uncertainty budget were combined into the
    enclosure that disjointness is judged on.  It defaults to
    ``UNKNOWN`` -- the widest of the three envelopes -- so the default can
    only ever *under*-report conflict relative to a sharper stated
    assumption, never manufacture it.  The assumption is recorded either way.

    ``comparable_fields`` names context fields that must agree for two
    untransferred records to be comparable at all.  Records that were
    carried by an applicability rule are comparable by construction: the
    rule is what declared the difference bridgeable.
    """
    statement = CorrelationAssumption.statement(correlation)
    members = tuple(_member(item) for item in records)
    if not members:
        return EvidenceRelation(
            relation=RelationKind.UNSUPPORTED,
            quantity=None,
            unit=None,
            correlation_assumption=correlation,
            correlation_statement=statement,
            refusal="the evidence set is empty; there is nothing to support a coordinate",
        )

    quantity = members[0].quantity
    unit = members[0].unit

    # -- partition into the disqualifying relations of 33.5 ---------------
    unauthorized, superseded, expired, unsupported, usable = [], [], [], [], []
    judgments = []
    superseded_ids = {sid for m in members for sid in m.supersedes}
    for member in members:
        judgment = evaluate_time(member.validity, clock)
        judgments.append((member.evidence_id, judgment))
        if not member.access.permits(requester):
            unauthorized.append(member.evidence_id)
        elif not member.may_authorize:
            unsupported.append(member.evidence_id)
        elif member.is_superseded or member.evidence_id in superseded_ids:
            superseded.append(member.evidence_id)
        elif judgment.blocks:
            expired.append(member.evidence_id)
        else:
            usable.append(member)

    common: Dict[str, Any] = {
        "quantity": quantity,
        "unit": unit,
        "correlation_assumption": correlation,
        "correlation_statement": statement,
        "members": members,
        "usable": tuple(m.evidence_id for m in usable),
        "expired": tuple(expired),
        "superseded": tuple(superseded),
        "unauthorized": tuple(unauthorized),
        "unsupported": tuple(unsupported),
        "time_judgments": tuple(judgments),
    }

    if not usable:
        # Report the *specific* disqualification, not a generic failure.
        if unauthorized and not (superseded or expired or unsupported):
            relation, refusal = (
                RelationKind.UNAUTHORIZED,
                f"every member is barred by its access policy: {unauthorized}",
            )
        elif expired and not (superseded or unsupported):
            relation, refusal = (
                RelationKind.EXPIRED,
                f"every member fails its validity window against the supplied clock: {expired}",
            )
        elif superseded and not unsupported:
            relation, refusal = (
                RelationKind.SUPERSEDED,
                f"every member has been superseded: {superseded}",
            )
        else:
            relation, refusal = (
                RelationKind.UNSUPPORTED,
                (
                    "no member of the set may support a coordinate "
                    f"(unsupported={unsupported}, expired={expired}, "
                    f"superseded={superseded}, unauthorized={unauthorized})"
                ),
            )
        return EvidenceRelation(relation=relation, refusal=refusal, **common)

    # -- one quantity per relation ----------------------------------------
    quantities = {(m.quantity, m.unit) for m in usable}
    if len(quantities) > 1:
        return EvidenceRelation(
            relation=RelationKind.UNSUPPORTED,
            refusal=(
                f"the set mixes quantities/units {sorted(quantities)}; a relation is "
                "defined for one quantity in one unit, and a unit mismatch MUST block "
                "arithmetic (spec 13.3)"
            ),
            **common,
        )
    quantity, unit = next(iter(quantities))
    common["quantity"], common["unit"] = quantity, unit

    # -- context comparability (33.5 "context-incomparable evidence") ------
    context_types = {m.context.context_type for m in usable}
    if len(context_types) > 1:
        return EvidenceRelation(
            relation=RelationKind.CONTEXT_INCOMPARABLE,
            incomparable=tuple(m.evidence_id for m in usable),
            refusal=(
                f"members are described in different context types {sorted(context_types)}; "
                "a field named the same in two context types is not the same field, so the "
                "records are not comparable (spec 33.2, 33.5)"
            ),
            **common,
        )
    if comparable_fields:
        untransferred = [m for m in usable if not m.transferred]
        for name in comparable_fields:
            values = {m.context.get(name) for m in untransferred}
            if len(values) > 1:
                return EvidenceRelation(
                    relation=RelationKind.CONTEXT_INCOMPARABLE,
                    incomparable=tuple(m.evidence_id for m in untransferred),
                    refusal=(
                        f"untransferred members disagree on the comparability field "
                        f"{name!r} ({sorted(str(v) for v in values)}) and no applicability "
                        "rule declared that difference bridgeable (spec 33.3)"
                    ),
                    **common,
                )

    # -- enclosures, then disjointness (33.5 "contradictory evidence") ------
    enclosures = tuple((m.evidence_id, m.enclosure(correlation=correlation)) for m in usable)
    common["enclosures"] = enclosures

    hull = enclosures[0][1]
    for _, interval in enclosures[1:]:
        hull = hull.union(interval)
    common["hull"] = hull

    disjoint = []
    for i in range(len(enclosures)):
        for j in range(i + 1, len(enclosures)):
            (id_a, iv_a), (id_b, iv_b) = enclosures[i], enclosures[j]
            if not iv_a.overlaps(iv_b):
                disjoint.append((id_a, id_b))

    if disjoint:
        pairs = ", ".join(f"{a} vs {b}" for a, b in disjoint)
        return EvidenceRelation(
            relation=RelationKind.CONTRADICTORY,
            disjoint_pairs=tuple(disjoint),
            fused_interval=None,
            refusal=(
                f"enclosures are disjoint for {pairs} under the stated correlation "
                f"assumption {correlation}; the conflict is surfaced and the coordinate is "
                "blocked.  It MUST NOT be silently averaged away (spec 33.5)"
            ),
            notes=(
                "no fused value was produced.  A mean, a weighted mean, or a hull of "
                "disjoint enclosures would each assert a value that no member supports.",
            ),
            **common,
        )

    intersection: Optional[Interval] = enclosures[0][1]
    for _, interval in enclosures[1:]:
        assert intersection is not None
        intersection = _intersect(intersection, interval)
        if intersection is None:  # pragma: no cover - implied by the disjoint scan
            break
    common["intersection"] = intersection

    # -- supporting vs heterogeneous but compatible ------------------------
    homogeneous = (
        len({m.method_id for m in usable}) == 1
        and len({m.evidence_class for m in usable}) == 1
        and len({m.context.fingerprint() for m in usable}) == 1
    )

    fused_budget = usable[0].budget
    for member in usable[1:]:
        fused_budget = fused_budget.merged_envelope(member.budget)

    if homogeneous:
        relation = RelationKind.SUPPORTING
        fused = intersection
        rule_text = (
            "SUPPORTING: every member is a valid enclosure of the same quantity produced "
            "by the same method in the same context, so the intersection of the enclosures "
            "is also a valid enclosure and is at least as tight as any member.  This is an "
            "intersection, not an average (spec 33.5)."
        )
    else:
        relation = RelationKind.HETEROGENEOUS_COMPATIBLE
        fused = hull
        rule_text = (
            "HETEROGENEOUS_COMPATIBLE: members overlap but were produced by different "
            "methods, evidence classes, or contexts, so method bias that no member's budget "
            "models cannot be excluded.  The hull is taken rather than the intersection, "
            "because intersecting would claim a sharpness the evidence does not support.  "
            "This is a hull, not an average (spec 33.5)."
        )

    notes = []
    if expired or superseded or unauthorized or unsupported:
        notes.append(
            "the relation was computed over the usable members only; disqualified members "
            "are listed separately and are not silently absorbed into the bound"
        )
    if len(usable) == 1:
        notes.append(
            "a single usable member is trivially SUPPORTING; the bound is that member's "
            "own enclosure and no agreement between sources has been demonstrated"
        )

    return EvidenceRelation(
        relation=relation,
        fused_interval=fused,
        fused_budget=fused_budget,
        fusion_rule=rule_text,
        notes=tuple(notes),
        **common,
    )


def fuse(relation: EvidenceRelation) -> Interval:
    """Return the fused bound, or refuse.

    This is the only accessor that yields an interval from a relation, and
    it raises :class:`ConflictRefusal` for every non-fusible relation.  A
    caller cannot reach a number by ignoring the relation.
    """
    if relation.fusible and relation.fused_interval is not None:
        return relation.fused_interval
    raise ConflictRefusal(
        f"relation {relation.relation} may not be fused into a value: "
        f"{relation.refusal or 'no fusible bound was derived'} (spec 33.5)"
    )
