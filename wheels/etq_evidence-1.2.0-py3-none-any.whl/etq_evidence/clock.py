"""Verification clock, validity windows, and time judgment.

Normative basis: master specification section 45 (clock and time
discipline), applied to the ``V`` component of the evidence tuple (33.2)
and to the declared ``expiration`` of an applicability rule (33.3).

The governing rule of this module is negative: **it never reads a clock.**
No current-time call appears anywhere in this package -- a standing test
greps the sources for one.  Expiry is decided
against a clock the caller *supplies* (45.3), the clock's source and trust
level are disclosed (45.5), and when no clock was supplied the answer is
``TIME_INDETERMINATE`` -- a disclosure, never a silent pass and never a
policy violation (45.4, 45.5).
"""
from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass
from typing import Optional, Tuple

__all__ = [
    "TimeStatus",
    "ClockTrust",
    "VerificationClock",
    "ValidityWindow",
    "TimeJudgment",
    "evaluate_time",
    "parse_time",
]


class TimeStatus:
    """Specification 45.4.  The verifier shall support all six."""

    CURRENT = "CURRENT"
    NOT_YET_VALID = "NOT_YET_VALID"
    STALE = "STALE"
    EXPIRED = "EXPIRED"
    TIME_INDETERMINATE = "TIME_INDETERMINATE"
    CLOCK_POLICY_VIOLATION = "CLOCK_POLICY_VIOLATION"

    ALL = frozenset(
        {CURRENT, NOT_YET_VALID, STALE, EXPIRED, TIME_INDETERMINATE, CLOCK_POLICY_VIOLATION}
    )
    #: A time status that MUST NOT authorize a contract coordinate (6.6).
    BLOCKING = frozenset({NOT_YET_VALID, STALE, EXPIRED, CLOCK_POLICY_VIOLATION})
    #: 45.5: an indeterminate time claim is disclosed, not blocked and not
    #: silently reported as current.
    DISCLOSED = frozenset({TIME_INDETERMINATE})


class ClockTrust:
    """Declared trust level of the verifier's clock (45.3, 45.5)."""

    NONE_SUPPLIED = "NONE_SUPPLIED"
    LOCAL_DECLARED = "LOCAL_DECLARED"
    SYNCHRONIZED = "SYNCHRONIZED"
    ATTESTED = "ATTESTED"

    ALL = frozenset({NONE_SUPPLIED, LOCAL_DECLARED, SYNCHRONIZED, ATTESTED})


def parse_time(value: object) -> Optional[_dt.datetime]:
    """Parse an ISO-8601 instant, returning ``None`` when it is not one.

    A naive timestamp is read as UTC; the caller's declared clock source is
    what carries the trust claim, not the spelling of the timestamp.
    """
    if not value or not isinstance(value, str):
        return None
    try:
        parsed = _dt.datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    except ValueError:
        return None
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=_dt.timezone.utc)


@dataclass(frozen=True)
class VerificationClock:
    """A clock the caller supplies for evaluation (45.3).

    There is no default instant.  A ``VerificationClock`` with
    ``evaluation_time=None`` is the honest representation of "this evaluator
    has no clock it is willing to assert", and it yields
    ``TIME_INDETERMINATE`` rather than a guess.
    """

    evaluation_time: Optional[str] = None
    source: str = "none-supplied"
    trust_level: str = ClockTrust.NONE_SUPPLIED

    def __post_init__(self) -> None:
        if self.trust_level not in ClockTrust.ALL:
            raise ValueError(f"unknown clock trust level {self.trust_level!r} (spec 45.3)")
        if self.evaluation_time is not None and parse_time(self.evaluation_time) is None:
            raise ValueError(
                f"clock evaluation_time {self.evaluation_time!r} is not an ISO-8601 instant; "
                "an unparsable clock is refused rather than defaulted (spec 45.3)"
            )
        if self.evaluation_time is None and self.trust_level != ClockTrust.NONE_SUPPLIED:
            raise ValueError("a clock with no evaluation_time cannot declare a trust level")

    @classmethod
    def declared(
        cls, evaluation_time: str, source: str, trust_level: str = ClockTrust.LOCAL_DECLARED
    ) -> "VerificationClock":
        """An air-gapped verifier's own clock, with its source disclosed (45.5)."""
        return cls(evaluation_time=evaluation_time, source=source, trust_level=trust_level)

    @classmethod
    def absent(cls) -> "VerificationClock":
        return cls()

    @property
    def instant(self) -> Optional[_dt.datetime]:
        return parse_time(self.evaluation_time)

    def to_canonical(self) -> dict:
        return {
            "verifier_evaluation_time": self.evaluation_time,
            "verifier_clock_source": self.source,
            "verifier_clock_trust_level": self.trust_level,
        }


@dataclass(frozen=True)
class ValidityWindow:
    """``V`` of the evidence tuple (33.2): the issuer's own time assertion.

    Every field here is an *assertion of the issuer* (45.2).  It is reported,
    never trusted as the evaluation instant.  ``max_age_seconds`` is a
    declared freshness window; exceeding it yields ``STALE``, which is
    distinct from ``EXPIRED`` because the issuer declared no end instant.
    """

    issued_at: Optional[str] = None
    not_before: Optional[str] = None
    expires_at: Optional[str] = None
    max_age_seconds: Optional[int] = None
    revalidation_triggers: Tuple[str, ...] = ()
    issuer_clock_source: str = "issuer-asserted"

    def __post_init__(self) -> None:
        object.__setattr__(
            self, "revalidation_triggers", tuple(str(t) for t in self.revalidation_triggers)
        )
        if self.max_age_seconds is not None and int(self.max_age_seconds) < 0:
            raise ValueError("max_age_seconds must not be negative")

    @property
    def declares_expiry(self) -> bool:
        return self.expires_at is not None or self.max_age_seconds is not None

    def to_canonical(self) -> dict:
        record: dict = {"issuer_clock_source": self.issuer_clock_source}
        for key, value in (
            ("issued_at", self.issued_at),
            ("not_before", self.not_before),
            ("expires_at", self.expires_at),
        ):
            if value is not None:
                record[key] = value
        if self.max_age_seconds is not None:
            record["max_age_seconds"] = int(self.max_age_seconds)
        if self.revalidation_triggers:
            record["revalidation_triggers"] = list(self.revalidation_triggers)
        return record

    def intersect(self, other: "ValidityWindow") -> "ValidityWindow":
        """The narrower of two windows: an assembled object is valid only
        while every input it depends on is valid."""
        return ValidityWindow(
            issued_at=_later(self.issued_at, other.issued_at),
            not_before=_later(self.not_before, other.not_before),
            expires_at=_earlier(self.expires_at, other.expires_at),
            max_age_seconds=_min_optional(self.max_age_seconds, other.max_age_seconds),
            revalidation_triggers=tuple(
                sorted(set(self.revalidation_triggers) | set(other.revalidation_triggers))
            ),
            issuer_clock_source=self.issuer_clock_source,
        )


def _later(a: Optional[str], b: Optional[str]) -> Optional[str]:
    pa, pb = parse_time(a), parse_time(b)
    if pa is None:
        return b
    if pb is None:
        return a
    return a if pa >= pb else b


def _earlier(a: Optional[str], b: Optional[str]) -> Optional[str]:
    pa, pb = parse_time(a), parse_time(b)
    if pa is None:
        return b
    if pb is None:
        return a
    return a if pa <= pb else b


def _min_optional(a: Optional[int], b: Optional[int]) -> Optional[int]:
    if a is None:
        return b
    if b is None:
        return a
    return min(int(a), int(b))


@dataclass(frozen=True)
class TimeJudgment:
    """What a verifier SHALL report about time (45.3).

    All five reportable items are fields, so a judgment is self-describing:
    the issuer's asserted instants, the verifier's evaluation instant, the
    verifier's clock source and declared trust level, and the status.
    """

    time_status: str
    issuer_asserted_issue_time: Optional[str] = None
    issuer_asserted_not_before: Optional[str] = None
    issuer_asserted_expiry: Optional[str] = None
    issuer_declared_max_age_seconds: Optional[int] = None
    verifier_evaluation_time: Optional[str] = None
    verifier_clock_source: str = "none-supplied"
    verifier_clock_trust_level: str = ClockTrust.NONE_SUPPLIED
    detail: str = ""

    @property
    def blocks(self) -> bool:
        return self.time_status in TimeStatus.BLOCKING

    @property
    def indeterminate(self) -> bool:
        return self.time_status in TimeStatus.DISCLOSED

    @property
    def current(self) -> bool:
        return self.time_status == TimeStatus.CURRENT

    def to_canonical(self) -> dict:
        record: dict = {
            "time_status": self.time_status,
            "verifier_clock_source": self.verifier_clock_source,
            "verifier_clock_trust_level": self.verifier_clock_trust_level,
            "verifier_evaluation_time": self.verifier_evaluation_time,
            "issuer_asserted_issue_time": self.issuer_asserted_issue_time,
            "issuer_asserted_not_before": self.issuer_asserted_not_before,
            "issuer_asserted_expiry": self.issuer_asserted_expiry,
        }
        if self.issuer_declared_max_age_seconds is not None:
            record["issuer_declared_max_age_seconds"] = int(self.issuer_declared_max_age_seconds)
        if self.detail:
            record["detail"] = self.detail
        return record


def evaluate_time(
    window: Optional[ValidityWindow], clock: Optional[VerificationClock] = None
) -> TimeJudgment:
    """Judge a validity window against a *supplied* clock (45.3, 45.4).

    The decision table, in order:

    ``no clock``                     -> ``TIME_INDETERMINATE`` (45.5)
    ``declared expiry unparsable``   -> ``CLOCK_POLICY_VIOLATION``
    ``now < not_before``             -> ``NOT_YET_VALID``
    ``now > expires_at``             -> ``EXPIRED``
    ``age > max_age_seconds``        -> ``STALE``
    ``no declared expiry or window`` -> ``TIME_INDETERMINATE``
    otherwise                        -> ``CURRENT``

    Passing ``clock=None`` is not a request to use the machine's wall clock;
    it is the statement that no evaluation instant is available.
    """
    clock = clock or VerificationClock.absent()
    window = window or ValidityWindow()
    judgment = {
        "issuer_asserted_issue_time": window.issued_at,
        "issuer_asserted_not_before": window.not_before,
        "issuer_asserted_expiry": window.expires_at,
        "issuer_declared_max_age_seconds": window.max_age_seconds,
        "verifier_evaluation_time": clock.evaluation_time,
        "verifier_clock_source": clock.source,
        "verifier_clock_trust_level": clock.trust_level,
    }

    now = clock.instant
    start = parse_time(window.not_before)
    end = parse_time(window.expires_at)
    issued = parse_time(window.issued_at)

    if now is None:
        return TimeJudgment(
            time_status=TimeStatus.TIME_INDETERMINATE,
            detail=(
                "no verifier clock was supplied; the time claim is undecided and "
                "MUST NOT be reported as current (spec 45.5)"
            ),
            **judgment,
        )
    if window.expires_at is not None and end is None:
        return TimeJudgment(
            time_status=TimeStatus.CLOCK_POLICY_VIOLATION,
            detail=f"declared expiry {window.expires_at!r} is not an ISO-8601 instant",
            **judgment,
        )
    if window.not_before is not None and start is None:
        return TimeJudgment(
            time_status=TimeStatus.CLOCK_POLICY_VIOLATION,
            detail=f"declared not_before {window.not_before!r} is not an ISO-8601 instant",
            **judgment,
        )
    if start is not None and now < start:
        return TimeJudgment(
            time_status=TimeStatus.NOT_YET_VALID,
            detail=f"evaluation time precedes the asserted not_before {window.not_before}",
            **judgment,
        )
    if end is not None and now > end:
        return TimeJudgment(
            time_status=TimeStatus.EXPIRED,
            detail=f"evaluation time is after the asserted expiry {window.expires_at}",
            **judgment,
        )
    if window.max_age_seconds is not None:
        if issued is None:
            return TimeJudgment(
                time_status=TimeStatus.CLOCK_POLICY_VIOLATION,
                detail="a freshness window was declared without a parsable issue time",
                **judgment,
            )
        age = (now - issued).total_seconds()
        if age > float(window.max_age_seconds):
            return TimeJudgment(
                time_status=TimeStatus.STALE,
                detail=(
                    f"age {int(age)}s exceeds the declared freshness window "
                    f"{int(window.max_age_seconds)}s"
                ),
                **judgment,
            )
    if end is None and window.max_age_seconds is None:
        return TimeJudgment(
            time_status=TimeStatus.TIME_INDETERMINATE,
            detail=(
                "the issuer declared no expiry and no freshness window; validity is "
                "undecided and is disclosed rather than assumed (spec 45.4)"
            ),
            **judgment,
        )
    return TimeJudgment(time_status=TimeStatus.CURRENT, **judgment)
