"""REST/job boundary for v1.2 non-authorizing change comparisons."""
from __future__ import annotations

import copy
from typing import Any, Mapping

from crg_cli.journey_comparison import (
    JourneyComparisonVerificationError,
    build_verified_comparative_change,
    inspect_comparative_change,
    persist_comparative_change,
    render_comparative_change_report,
    verify_comparative_change,
)

from .errors import BlockedOutcome, NotFoundError, UsageError
from .jobs import JobContext, JobResult

__all__ = [
    "op_preview_comparative_change",
    "op_generate_comparative_change",
    "inspect_change",
    "verify_change_request",
]


def _blocked(error: JourneyComparisonVerificationError) -> BlockedOutcome:
    return BlockedOutcome(
        "independent comparison replay disagreed with the stored or produced evidence",
        outcome="BLOCKED_VERIFIER_DISAGREEMENT",
        detail={"message": str(error)},
        remedy=(
            "publish nothing; recover the exact stored delta and its verifier "
            "inputs, then rerun independent verification"
        ),
    )


def _run_change(context: JobContext, *, persist: bool) -> JobResult:
    case = copy.deepcopy(context.inputs["case"])
    request = context.inputs.get("request") or {}
    try:
        record, verification = build_verified_comparative_change(request, case)
        if persist:
            persist_comparative_change(case, record)
    except JourneyComparisonVerificationError as error:
        raise _blocked(error) from error
    comparison_id = record["comparison_id"]
    report = render_comparative_change_report(record, verification)
    context.log(
        f"comparative change {comparison_id} independently replayed; "
        f"authority=NON_AUTHORIZING semantic_effect=NONE persist={persist}"
    )
    outputs = {
        "preview": not persist,
        "comparison_id": comparison_id,
        "record_hash": record["record_hash"],
        "authority": "NON_AUTHORIZING",
        "authorizing": False,
        "semantic_effect": "NONE",
        "decision_state_mutation_performed": False,
        "successor_case_recorded": persist,
        "comparative_change": record,
        "verification": verification.to_json(),
        "report": report,
    }
    proof = {
        "proof_type": "COMPARATIVE_CHANGE_INDEPENDENT_RECONSTRUCTION",
        "profile": record["profile"],
        "record_hash": record["record_hash"],
        "verifier": "crg-verify",
        "status": verification.status,
        "authority": "NON_AUTHORIZING",
        "authorizing": False,
        "semantic_effect": "NONE",
        "decision_state_mutation_performed": False,
        "successor_case_recorded": persist,
    }
    if not persist:
        return JobResult(outputs=outputs, proof_artifacts=[proof])
    return JobResult(
        outputs=outputs,
        objects=[(f"comparative-change:{comparison_id}", record)],
        case=case,
        proof_artifacts=[proof],
    )


def op_preview_comparative_change(context: JobContext) -> JobResult:
    return _run_change(context, persist=False)


def op_generate_comparative_change(context: JobContext) -> JobResult:
    return _run_change(context, persist=True)


def _closed_record_request(request: Any) -> Mapping[str, Any]:
    if not isinstance(request, Mapping) or set(request) != {"record"}:
        raise UsageError(
            "ComparativeChangeEvidence verification requires exactly "
            "{'record': <ComparativeChangeEvidence>}",
            remedy="pass the canonical portable record without authoring fields",
        )
    record = request.get("record")
    if not isinstance(record, Mapping):
        raise UsageError("ComparativeChangeEvidence must be a JSON object")
    return record


def verify_change_request(request: Any) -> dict:
    try:
        record = _closed_record_request(request)
        verification = verify_comparative_change(record)
    except JourneyComparisonVerificationError as error:
        raise _blocked(error) from error
    document = copy.deepcopy(dict(record))
    return {
        "comparative_change": document,
        "verification": verification.to_json(),
        "report": render_comparative_change_report(document, verification),
        "authority": "NON_AUTHORIZING",
        "authorizing": False,
        "semantic_effect": "NONE",
        "decision_state_mutation_performed": False,
        "successor_case_recorded": False,
    }


def inspect_change(case: Mapping[str, Any], comparison_id: str) -> dict:
    records = case.get("comparative_change_evidence") or {}
    if not isinstance(records, Mapping) or comparison_id not in records:
        raise NotFoundError(
            f"comparative change {comparison_id!r} does not exist in this case",
            remedy="generate the comparison first or use a stored comparison identity",
        )
    try:
        return inspect_comparative_change(case, comparison_id)
    except JourneyComparisonVerificationError as error:
        raise _blocked(error) from error
