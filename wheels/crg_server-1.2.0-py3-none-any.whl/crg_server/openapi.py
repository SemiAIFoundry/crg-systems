"""The OpenAPI 3.1 description, generated from the endpoint table.

Normative basis: 38.2 (the reference server SHALL provide REST with OpenAPI
3.1), 38.3 (principal endpoints), 38.4 (idempotency), 38.5 (events), 6.6
(fail closed), 6.12 (anti-lock-in), 51 (documentation requirements).

The document is *generated* from :data:`crg_server.app.ENDPOINTS` rather than
maintained beside it.  A hand-written description drifts, and a drifted
description is worse than none: an integrator generating a client from it
would produce code that calls endpoints this server does not have and omits
ones it does.  Because the table is the same object the router walks, the
description and the behaviour cannot disagree.

Three things the document says that a naive generator would omit, and that
6.6 makes load-bearing:

* every long-running operation documents ``202`` with a job identifier as its
  *success* response, so a generated client is shaped around the asynchronous
  contract of 38.3 rather than discovering it at runtime;
* every operation documents its refusal statuses, including ``422`` for a
  blocked outcome, so a client's error handling is written against the real
  set; and
* ``Idempotency-Key`` appears on every case/control-plane mutation covered by
  38.4.  The isolated CRG-ENH-04 measurement transitions instead use strict
  state transitions and hash confirmation, so their response bodies are
  never copied into the case/control-plane idempotency store.
"""
from __future__ import annotations

import copy
from typing import Any, Dict, List

from crg_model.schema import schema_for

__all__ = ["OPENAPI_VERSION", "openapi_document", "endpoint_paths"]

OPENAPI_VERSION = "3.1.0"

_ERROR_SCHEMA = {
    "type": "object",
    "required": ["error"],
    "properties": {
        "error": {
            "type": "object",
            "required": ["category", "status", "message"],
            "properties": {
                "category": {"type": "string"},
                "status": {"type": "integer"},
                "message": {"type": "string"},
                "remedy": {"type": "string"},
                "detail": {"type": "object", "additionalProperties": True},
            },
        }
    },
}

# CRG-ENH-04 is a closed, privacy-bounded plane.  Its refusals intentionally
# omit deployment-specific ``detail`` dictionaries: those can contain policy
# or identity attributes that neither belong in the measurement contract nor
# admit a strict schema.  Category, status, message, and an optional remedy
# are sufficient for generated clients to handle the refusal.
_MEASUREMENT_ERROR_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "required": ["error"],
    "properties": {
        "error": {
            "type": "object",
            "additionalProperties": False,
            "required": ["category", "status", "message"],
            "properties": {
                "category": {"type": "string"},
                "status": {"type": "integer"},
                "message": {"type": "string"},
                "remedy": {"type": "string"},
            },
        }
    },
}

_JOB_ACCEPTED_SCHEMA = {
    "type": "object",
    "required": ["job_id", "status"],
    "properties": {
        "job_id": {"type": "string"},
        "kind": {"type": "string"},
        "status": {"type": "string",
                   "enum": ["QUEUED", "RUNNING", "SUCCEEDED", "FAILED", "CANCELLED"]},
        "case_id": {"type": ["string", "null"]},
        "input_hash": {"type": "string"},
        "links": {"type": "object", "additionalProperties": {"type": "string"}},
    },
}

_EVENT_SCHEMA = {
    "type": "object",
    "required": [
        "event", "case_id", "branch_id", "object_hashes", "timestamp", "actor",
        "correlation_id", "schema_version",
    ],
    "properties": {
        "event": {"type": "string"},
        "case_id": {"type": ["string", "null"]},
        "branch_id": {"type": ["string", "null"]},
        "object_hashes": {"type": "array", "items": {"type": "string"}},
        "timestamp": {"type": "string"},
        "actor": {"type": "string"},
        "correlation_id": {"type": "string"},
        "schema_version": {"type": "string"},
        "detail": {"type": "object", "additionalProperties": True},
    },
}

_AUDIT_HASH_SCHEMA = {"type": "string", "pattern": "^sha256:[0-9a-f]{64}$"}

_PSEUDONYM_SCHEMA = {
    "type": "string",
    "pattern": "^psn-[a-z0-9]+(?:-[a-z0-9]+)*$",
}

_MEASUREMENT_CODE_SCHEMA = {
    "type": "string",
    "pattern": "^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$",
    "maxLength": 64,
}

_AUDIT_ENTRY_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "required": [
        "sequence", "timestamp", "tenant_id", "actor", "action", "resource",
        "decision", "outcome", "correlation_id", "rule_id", "detail",
        "previous_hash", "entry_hash",
    ],
    "properties": {
        "sequence": {"type": "integer", "minimum": 0},
        "timestamp": {"type": "string", "format": "date-time"},
        "tenant_id": {"type": "string", "minLength": 1},
        "actor": {"type": "string"},
        "action": {"type": "string"},
        "resource": {"type": "string"},
        "decision": {"type": "string"},
        "outcome": {"type": "string"},
        "correlation_id": {"type": "string"},
        "rule_id": {"type": "string"},
        "detail": {"type": "object", "additionalProperties": True},
        "previous_hash": _AUDIT_HASH_SCHEMA,
        "entry_hash": _AUDIT_HASH_SCHEMA,
    },
}

_AUDIT_EXPORT_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "required": [
        "record_type", "format_version", "tenant_id", "requested_by", "authority",
        "exported_at", "clock_source", "clock_trust_level", "range",
        "total_entry_count", "genesis_hash", "predecessor_hash", "page_head_hash",
        "chain_head_hash", "chain_verification", "checkpoint_status", "checkpoint",
        "entries", "verification_scope", "artifact_hash",
    ],
    "properties": {
        "record_type": {"type": "string", "const": "AuditExportRecord"},
        "format_version": {"type": "string", "const": "1.0.0"},
        "tenant_id": {"type": "string", "minLength": 1},
        "requested_by": {"type": "string", "minLength": 1},
        "authority": {"type": "string", "minLength": 1},
        "exported_at": {"type": "string", "format": "date-time"},
        "clock_source": {"type": "string"},
        "clock_trust_level": {"type": "string"},
        "range": {
            "type": "object", "additionalProperties": False,
            "required": ["after_sequence", "start_sequence", "end_sequence",
                         "entry_count", "next_after_sequence", "has_more"],
            "properties": {
                "after_sequence": {"type": "integer", "minimum": -1},
                "start_sequence": {"type": ["integer", "null"], "minimum": 0},
                "end_sequence": {"type": ["integer", "null"], "minimum": 0},
                "entry_count": {"type": "integer", "minimum": 0, "maximum": 1000},
                "next_after_sequence": {"type": "integer", "minimum": -1},
                "has_more": {"type": "boolean"},
            },
        },
        "total_entry_count": {"type": "integer", "minimum": 0},
        "genesis_hash": _AUDIT_HASH_SCHEMA,
        "predecessor_hash": _AUDIT_HASH_SCHEMA,
        "page_head_hash": _AUDIT_HASH_SCHEMA,
        "chain_head_hash": _AUDIT_HASH_SCHEMA,
        "chain_verification": {"type": "object", "additionalProperties": True},
        "checkpoint_status": {"type": "string", "enum": ["SIGNED", "UNSIGNED"]},
        "checkpoint": {"type": "object", "additionalProperties": True},
        "entries": {"type": "array", "maxItems": 1000, "items": _AUDIT_ENTRY_SCHEMA},
        "verification_scope": {"type": "string"},
        "artifact_hash": _AUDIT_HASH_SCHEMA,
    },
}

_TOMBSTONE_SCHEMA = {
    "type": "object",
    "required": ["content_hash", "object_type", "removal_reason", "removal_authority"],
    "properties": {
        "record_type": {"type": "string", "const": "TombstoneRecord"},
        "object_id": {"type": "string"},
        "content_hash": {"type": "string"},
        "object_type": {"type": "string"},
        "removal_reason": {"type": "string"},
        "removal_authority": {"type": "string"},
        "removal_time": {"type": "string"},
        "legal_hold": {"type": "boolean"},
        "permitted_disclosure": {"type": "string"},
        "dependency_edges": {"type": "array", "items": {"type": "object"}},
    },
}

_JOB_SCHEMA = {
    "type": "object",
    "description": "Every item specification 42.4 requires a job to record.",
    "required": [
        "job_id", "kind", "canonical_inputs", "engine_versions", "resource_limits",
        "status", "logs", "outputs", "failure_category", "retry_history",
        "cancellation", "determinism_status", "solver_trust_profile", "proof_artifacts",
        "execution_phase",
    ],
    "properties": {
        "job_id": {"type": "string"},
        "kind": {"type": "string"},
        "case_id": {"type": ["string", "null"]},
        "branch_id": {"type": ["string", "null"]},
        "canonical_inputs": {"type": "object", "additionalProperties": True},
        "input_hash": {"type": "string"},
        "engine_versions": {"type": "object", "additionalProperties": {"type": "string"}},
        "resource_limits": {"type": "object", "additionalProperties": True},
        "status": {"type": "string", "enum": [
            "QUEUED", "RUNNING", "SUCCEEDED", "FAILED", "CANCELLED"
        ]},
        "execution_phase": {"type": "string", "enum": [
            "QUEUED", "EXECUTING", "COMMITTING", "TERMINAL"
        ]},
        "started_at": {"type": ["string", "null"]},
        "completed_at": {"type": ["string", "null"]},
        "logs": {"type": "array", "items": {"type": "string"}},
        "outputs": {"type": "object", "additionalProperties": True},
        "failure_category": {"type": ["string", "null"]},
        "retry_history": {"type": "array", "items": {"type": "object"}},
        "cancellation": {"type": ["object", "null"]},
        "determinism_status": {"type": "string"},
        "solver_trust_profile": {"type": "string"},
        "proof_artifacts": {"type": "array", "items": {"type": "object"}},
    },
}

_EXACT_SCHEMA = {
    "description": (
        "An exact rational (14.2).  Send a string such as \"3/4\" or \"0.25\", an "
        "integer, or {\"numerator\": n, \"denominator\": d}.  A JSON float is refused: "
        "no float appears on a certifying path."
    ),
    "oneOf": [
        {"type": "string"},
        {"type": "integer"},
        {
            "type": "object",
            "required": ["numerator", "denominator"],
            "properties": {
                "numerator": {"type": "integer"},
                "denominator": {"type": "integer"},
            },
        },
    ],
}

_INTAKE_PROVENANCE_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "required": ["source_id", "source_name", "origin"],
    "properties": {
        "source_id": {"type": "string", "minLength": 1},
        "source_name": {"type": "string", "minLength": 1},
        "origin": {"type": "string", "minLength": 1},
        "producer": {"type": "string", "minLength": 1},
        "source_version": {"type": "string", "minLength": 1},
    },
}

_INTAKE_COORDINATE_MAPPING_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "required": [
        "source_field", "coordinate_id", "quantity", "unit", "direction",
        "numeric_profile",
    ],
    "properties": {
        "source_field": {"type": "string", "minLength": 1},
        "coordinate_id": {"type": "string", "minLength": 1},
        "quantity": {"type": "string", "minLength": 1},
        "unit": {"type": "string", "minLength": 1},
        "direction": {"type": "string", "enum": ["MINIMIZE", "MAXIMIZE"]},
        "numeric_profile": {"type": "string", "const": "CRG_EXACT_RATIONAL"},
        "unit_field": {"type": "string", "minLength": 1},
        "evidence_field": {"type": "string", "minLength": 1},
    },
}

_INTAKE_ATTRIBUTE_MAPPING_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "required": ["source_field", "attribute_id", "required"],
    "properties": {
        "source_field": {"type": "string", "minLength": 1},
        "attribute_id": {"type": "string", "minLength": 1},
        "required": {"type": "boolean"},
    },
}

_INTAKE_MAPPING_PROFILE_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "required": [
        "record_type", "schema_version", "profile_id", "profile_version",
        "source_format", "record_path", "identity_field", "coordinates", "attributes",
        "quantity_registry_version", "default_evidence_class", "policies",
    ],
    "properties": {
        "record_type": {"type": "string", "const": "RegistryMappingProfile"},
        "schema_version": {"type": "string", "const": "1.0.0"},
        "profile_id": {"type": "string", "minLength": 1},
        "profile_version": {
            "type": "string",
            "pattern": "^[0-9]+\\.[0-9]+\\.[0-9]+(?:[-+][0-9A-Za-z.-]+)?$",
        },
        "source_format": {"type": "string", "enum": ["csv", "json"]},
        "record_path": {"type": "string", "minLength": 1},
        "identity_field": {"type": "string", "minLength": 1},
        "coordinates": {
            "type": "array", "minItems": 1,
            "items": _INTAKE_COORDINATE_MAPPING_SCHEMA,
        },
        "attributes": {"type": "array", "items": _INTAKE_ATTRIBUTE_MAPPING_SCHEMA},
        "quantity_registry_version": {
            "type": "string", "pattern": "^sha256:[0-9a-f]{64}$",
        },
        "default_evidence_class": {
            "type": "string",
            "enum": [
                "BOUNDED", "CONSTRUCTIVE", "DECLARED", "EXACT",
                "HEURISTIC", "IMPORTED", "MEASURED", "MODELED",
            ],
        },
        "evidence_field": {"type": "string", "minLength": 1},
        "feasibility_field": {"type": "string", "minLength": 1},
        "policies": {
            "type": "object",
            "additionalProperties": False,
            "required": [
                "completeness", "duplicate_identity", "unknown_fields", "unit_conversion",
                "missing_feasibility", "authority",
            ],
            "properties": {
                "completeness": {"const": "EXPLICIT_IMPORTED_FAMILY"},
                "duplicate_identity": {"const": "REJECT_EVERY_OCCURRENCE_AFTER_FIRST"},
                "unknown_fields": {"const": "REPORT_UNSUPPORTED"},
                "unit_conversion": {"const": "NONE"},
                "missing_feasibility": {"const": "KEEP_UNEVALUATED"},
                "authority": {"const": "NON_AUTHORIZING_INTAKE"},
            },
        },
    },
}


# CRG-ENH-04 schemas are the published strict record schemas, embedded into
# OpenAPI rather than weakened to anonymous ``object`` responses.  Rewriting
# their local references keeps the API document self-contained for client
# generators and offline inspection.
_MEASUREMENT_RECORD_COMPONENTS = {
    "OperationalMeasurementProfile": "OperationalMeasurementProfile",
    "OperationalMeasurementPermission": "OperationalMeasurementPermission",
    "OperationalMeasurementEvent": "OperationalMeasurementEvent",
    "OperationalMeasurementSessionRecord": "OperationalMeasurementSessionRecord",
    "OperationalMeasurementRetentionPreview": "OperationalMeasurementRetentionPreview",
    "OperationalMeasurementDeletionReceipt": "OperationalMeasurementDeletionReceipt",
    "OperationalMeasurementExport": "OperationalMeasurementExport",
}

_MEASUREMENT_FILE_COMPONENTS = {
    "operational-measurement-profile.schema.json": "OperationalMeasurementProfile",
    "operational-measurement-permission.schema.json": "OperationalMeasurementPermission",
    "operational-measurement-event.schema.json": "OperationalMeasurementEvent",
    "operational-measurement-session.schema.json": "OperationalMeasurementSessionRecord",
    "operational-measurement-retention-preview.schema.json": (
        "OperationalMeasurementRetentionPreview"
    ),
    "operational-measurement-deletion-receipt.schema.json": (
        "OperationalMeasurementDeletionReceipt"
    ),
    "operational-measurement-export.schema.json": "OperationalMeasurementExport",
}


def _measurement_component(record_type: str) -> Dict[str, Any]:
    component = _MEASUREMENT_RECORD_COMPONENTS[record_type]
    document = copy.deepcopy(schema_for(record_type))
    document.pop("$schema", None)
    document.pop("$id", None)

    def rewrite(value: Any) -> Any:
        if isinstance(value, list):
            return [rewrite(item) for item in value]
        if not isinstance(value, dict):
            return value
        result: Dict[str, Any] = {}
        for key, item in value.items():
            if key == "$ref" and isinstance(item, str):
                if item.startswith("#/"):
                    result[key] = f"#/components/schemas/{component}/{item[2:]}"
                elif item.startswith("common.schema.json#/$defs/hash"):
                    result[key] = "#/components/schemas/ContentHash"
                else:
                    filename, marker, fragment = item.partition("#")
                    target = _MEASUREMENT_FILE_COMPONENTS.get(filename)
                    result[key] = (
                        f"#/components/schemas/{target}"
                        + (f"/{fragment[1:]}" if marker and fragment.startswith("/") else "")
                        if target
                        else item
                    )
            else:
                result[key] = rewrite(item)
        return result

    rewritten = rewrite(document)
    rewritten["additionalProperties"] = False
    return rewritten


_MEASUREMENT_SESSION_SUMMARY_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "required": [
        "session_id", "status", "purpose_code", "scope_code", "started_at",
        "ended_at", "active_time_ns", "compute_time_ns", "wait_time_ns",
        "content_hash",
    ],
    "properties": {
        "session_id": _PSEUDONYM_SCHEMA,
        "status": {"type": "string", "enum": ["ACTIVE", "CLOSED"]},
        "purpose_code": _MEASUREMENT_CODE_SCHEMA,
        "scope_code": _MEASUREMENT_CODE_SCHEMA,
        "started_at": {"type": "string", "format": "date-time"},
        "ended_at": {"type": ["string", "null"], "format": "date-time"},
        "active_time_ns": {"type": "integer", "minimum": 0},
        "compute_time_ns": {"type": "integer", "minimum": 0},
        "wait_time_ns": {"type": "integer", "minimum": 0},
        "content_hash": {"$ref": "#/components/schemas/ContentHash"},
    },
}

_MEASUREMENT_CONFIGURATION_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "required": [
        "record_type", "schema_version", "enabled", "local_only", "phone_home",
        "store_domain", "permission_domain", "authorization_effect",
        "evidence_eligible", "profile", "permission",
    ],
    "properties": {
        "record_type": {"const": "OperationalMeasurementConfigurationView"},
        "schema_version": {"const": "1.0.0"},
        "enabled": {"type": "boolean"},
        "local_only": {"const": True},
        "phone_home": {"const": False},
        "store_domain": {"const": "crg-operational-measurement-local"},
        "permission_domain": {"const": "crg-operational-measurement"},
        "authorization_effect": {"const": "NONE"},
        "evidence_eligible": {"const": False},
        "profile": {"$ref": "#/components/schemas/OperationalMeasurementProfile"},
        "permission": {
            "oneOf": [
                {"type": "null"},
                {"$ref": "#/components/schemas/OperationalMeasurementPermission"},
            ]
        },
    },
}

_MEASUREMENT_SESSION_LIST_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "required": [
        "record_type", "schema_version", "profile_content_hash", "session_count",
        "sessions", "local_only", "store_domain", "permission_domain",
        "authorizing", "evidence_eligible",
    ],
    "properties": {
        "record_type": {"const": "OperationalMeasurementSessionList"},
        "schema_version": {"const": "1.0.0"},
        "profile_content_hash": {"$ref": "#/components/schemas/ContentHash"},
        "session_count": {"type": "integer", "minimum": 0},
        "sessions": {
            "type": "array",
            "items": {"$ref": "#/components/schemas/OperationalMeasurementSessionSummary"},
        },
        "local_only": {"const": True},
        "store_domain": {"const": "crg-operational-measurement-local"},
        "permission_domain": {"const": "crg-operational-measurement"},
        "authorizing": {"const": False},
        "evidence_eligible": {"const": False},
    },
}

_MEASUREMENT_VERIFICATION_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "required": [
        "record_type", "schema_version", "ok", "status", "independent",
        "export_content_hash", "session_content_hash", "authorizing",
        "evidence_eligible",
    ],
    "properties": {
        "record_type": {"const": "OperationalMeasurementVerificationResult"},
        "schema_version": {"const": "1.0.0"},
        "ok": {"const": True},
        "status": {"const": "VERIFIED"},
        "independent": {"const": True},
        "export_content_hash": {"$ref": "#/components/schemas/ContentHash"},
        "session_content_hash": {"$ref": "#/components/schemas/ContentHash"},
        "authorizing": {"const": False},
        "evidence_eligible": {"const": False},
    },
}

_MEASUREMENT_SESSION_OPERATIONS = frozenset({
    "startOperationalMeasurementSession",
    "getOperationalMeasurementSession",
    "startOperationalMeasurementActive",
    "endOperationalMeasurementActive",
    "startOperationalMeasurementCompute",
    "endOperationalMeasurementCompute",
    "startOperationalMeasurementWait",
    "endOperationalMeasurementWait",
    "recordOperationalMeasurementObservation",
    "recordOperationalMeasurementCounterfactual",
    "endOperationalMeasurementSession",
})

_MEASUREMENT_EMPTY_BODY_OPERATIONS = frozenset({
    "startOperationalMeasurementActive",
    "endOperationalMeasurementActive",
    "startOperationalMeasurementCompute",
    "endOperationalMeasurementCompute",
    "startOperationalMeasurementWait",
    "endOperationalMeasurementWait",
    "endOperationalMeasurementSession",
})


def _responses(endpoint: Any) -> Dict[str, Any]:
    responses: Dict[str, Any] = {}
    measurement_response = {
        "getOperationalMeasurementProfile": "OperationalMeasurementConfigurationView",
        "listOperationalMeasurementSessions": "OperationalMeasurementSessionList",
        "exportOperationalMeasurementSession": "OperationalMeasurementExport",
        "verifyOperationalMeasurementExport": "OperationalMeasurementVerificationResult",
        "previewOperationalMeasurementRetention": (
            "OperationalMeasurementRetentionPreview"
        ),
        "enforceOperationalMeasurementRetention": (
            "OperationalMeasurementDeletionReceipt"
        ),
        "deleteOperationalMeasurementSession": (
            "OperationalMeasurementDeletionReceipt"
        ),
    }.get(endpoint.operation_id)
    if endpoint.operation_id in _MEASUREMENT_SESSION_OPERATIONS:
        measurement_response = "OperationalMeasurementSessionRecord"
    if measurement_response:
        responses[str(endpoint.success_status)] = {
            "description": (
                "Strict local-only CRG-ENH-04 response. It has no case or evidence "
                "authority and cannot imply ROI, savings, or superiority."
            ),
            "content": {
                "application/json": {
                    "schema": {"$ref": f"#/components/schemas/{measurement_response}"}
                }
            },
        }
        if endpoint.operation_id == "exportOperationalMeasurementSession":
            responses[str(endpoint.success_status)]["headers"] = {
                "Cache-Control": {"schema": {"type": "string", "const": "no-store"}},
                "Content-Disposition": {"schema": {"type": "string"}},
                "X-CRG-Independent-Verification": {
                    "schema": {"type": "string", "const": "passed"}
                },
            }
    elif endpoint.long_running:
        responses["202"] = {
            "description": (
                "Accepted.  38.3: a long-running action returns a job identifier, "
                "not a result.  Poll GET /jobs/{job_id}/result."
            ),
            "content": {"application/json": {"schema": _JOB_ACCEPTED_SCHEMA}},
        }
    elif getattr(endpoint, "streaming", False):
        # 38.2 event streaming.  The response is an endless sequence of SSE
        # records, not one document, and the description says so: a generated
        # client that read this as a body would block until the subscription
        # ended, which for a live stream is never.
        responses[str(endpoint.success_status)] = {
            "description": (
                f"An open Server-Sent Events stream ({endpoint.summary}).  Each "
                "record carries id (the event ordinal), event (a name from the "
                "38.5 vocabulary), and data (the canonical JSON of the 38.5 "
                "carrier).  Comment records beginning ': ' are keepalives.  "
                "Reconnect with Last-Event-ID to resume with no gap and no "
                "duplicate."
            ),
            "content": {
                endpoint.produces: {
                    "schema": {
                        "type": "string",
                        "contentMediaType": endpoint.produces,
                        "description": "The SSE wire format of the WHATWG HTML "
                                       "specification, as required by 38.2.",
                    }
                }
            },
            "headers": {
                "Cache-Control": {"schema": {"type": "string", "const": "no-cache"}},
                "X-Accel-Buffering": {"schema": {"type": "string", "const": "no"}},
            },
        }
    elif endpoint.operation_id == "exportAudit":
        responses[str(endpoint.success_status)] = {
            "description": "A bounded, canonical tenant security-audit page.",
            "content": {
                "application/json": {
                    "schema": {"$ref": "#/components/schemas/AuditExportRecord"}
                }
            },
            "headers": {
                "Content-Disposition": {"schema": {"type": "string"}},
                "Cache-Control": {"schema": {"type": "string", "const": "no-store"}},
            },
        }
    else:
        responses[str(endpoint.success_status)] = {
            "description": f"Success ({endpoint.summary}).",
            "content": {endpoint.produces: {"schema": {"type": "object"}}}
            if endpoint.produces == "application/json"
            else {endpoint.produces: {"schema": {"type": "string", "format": "binary"}}},
        }
    detail = {
        400: "Malformed or inadmissible request.",
        401: "No actor identity was presented (44.2).",
        403: "The actor holds no role authorizing this operation (44.3).",
        404: "No object of that identity exists here.",
        405: "The route exists and this verb does not.",
        409: (
            "Conflict: stale parent version (16.1), idempotency key reuse (38.4), "
            "legal hold (17.5), or a job that produced no result (42.4)."
        ),
        410: "The content was redacted; the tombstone is returned (17.2).",
        413: "The request exceeds the deployment's declared byte or archive-expansion limit.",
        415: "This surface is JSON only (38.2).",
        422: (
            "Scope mismatch or a blocked outcome.  6.6: a refusal is never reported "
            "behind a 200."
        ),
        503: "A required local dependency is unavailable; readiness fails closed.",
    }
    for status in endpoint.failure_statuses:
        responses[str(status)] = {
            "description": detail.get(status, "Refused."),
            "content": {"application/json": {"schema": (
                _MEASUREMENT_ERROR_SCHEMA
                if "OperationalMeasurement" in endpoint.operation_id
                else _ERROR_SCHEMA
            )}},
        }
    return responses


def _parameters(endpoint: Any, *, authenticated: bool) -> List[Dict[str, Any]]:
    parameters: List[Dict[str, Any]] = [
        {
            "name": name,
            "in": "path",
            "required": True,
            "schema": {"type": "string"},
            "description": f"Identifier bound by the route {endpoint.path}.",
        }
        for name in endpoint.parameters
    ]
    for name, description in getattr(endpoint, "query_parameters", ()):
        parameters.append(
            {
                "name": name,
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
                "description": description,
            }
        )
    for name, description in getattr(endpoint, "header_parameters", ()):
        parameters.append(
            {
                "name": name,
                "in": "header",
                "required": False,
                "schema": {"type": "string"},
                "description": description,
            }
        )
    if endpoint.case_scoped and endpoint.method == "GET":
        parameters.append(
            {
                "name": "version",
                "in": "query",
                "required": False,
                "schema": {"type": "string"},
                "description": (
                    "A version ordinal or a sha256 content hash.  11.2: a prior case "
                    "version remains addressable after supersession."
                ),
            }
        )
    if not authenticated:
        parameters.append(
            {
                "name": "X-CRG-Actor",
                "in": "header",
                "required": endpoint.method != "GET",
                "schema": {"type": "string"},
                "description": (
                    "Unverified development-profile actor assertion. This is not an "
                    "authentication mechanism and must not be exposed to an untrusted network."
                ),
            }
        )
    parameters.append(
        {
            "name": "X-CRG-Correlation-Id",
            "in": "header",
            "required": False,
            "schema": {"type": "string"},
            "description": "38.5: every emitted event carries this correlation identifier.",
        }
    )
    parameters.append(
        {
            "name": "traceparent",
            "in": "header",
            "required": False,
            "schema": {
                "type": "string",
                "pattern": "^[0-9a-f]{2}-[0-9a-f]{32}-[0-9a-f]{16}-[0-9a-f]{2}$",
            },
            "description": (
                "Optional W3C Trace Context parent. A valid trace id is propagated "
                "with a fresh server span id; malformed input starts a new trace."
            ),
        }
    )
    if (
        endpoint.method == "POST"
        and "OperationalMeasurement" not in endpoint.operation_id
    ):
        parameters.append(
            {
                "name": "Idempotency-Key",
                "in": "header",
                "required": False,
                "schema": {"type": "string"},
                "description": (
                    "38.4: mutation requests support idempotency keys.  An identical "
                    "canonical request under the same key replays the recorded response; "
                    "a different request under the same key is a 409."
                ),
            }
        )
    return parameters


_CHALLENGE_PREVIEWS = [
    "BRANCH_PREVIEW", "PHASE_PREVIEW", "CHANGE_PREVIEW", "COMMITMENT_PREVIEW",
    "VERIFIER_REPLAY", "PHASE_AND_CHANGE_PREVIEW",
]
_CHALLENGE_EXACT = {
    "oneOf": [
        {"type": "string", "pattern": "^-?(?:0|[1-9][0-9]*)(?:/[1-9][0-9]*)?$"},
        {"type": "integer"},
        {
            "type": "object", "additionalProperties": False,
            "required": ["exact"],
            "properties": {
                "exact": {
                    "type": "string",
                    "pattern": "^-?(?:0|[1-9][0-9]*)(?:/[1-9][0-9]*)?$",
                }
            },
        },
    ],
    "description": "Exact integer or reduced rational; JSON floating point is refused.",
}


def _challenge_input(required: List[str], properties: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "type": "object",
        "additionalProperties": False,
        "required": required,
        "properties": properties,
    }


def _challenge_operation(
    mutation_type: str, required: List[str], properties: Dict[str, Any]
) -> Dict[str, Any]:
    return {
        "type": "object",
        "additionalProperties": False,
        "required": [
            "operation_id", "mutation_type", "preview_operation", "target_path", "input"
        ],
        "properties": {
            "operation_id": {"type": "string", "minLength": 1},
            "mutation_type": {"const": mutation_type},
            "preview_operation": {"type": "string", "enum": _CHALLENGE_PREVIEWS},
            "target_path": {"type": "string", "minLength": 1},
            "input": _challenge_input(required, properties),
        },
    }


_CHALLENGE_OPERATION_SCHEMA = {
    "oneOf": [
        _challenge_operation("OBJECTIVE", ["objective"], {
            "objective": {
                "type": "object",
                "description": "Canonical objective declaration; binary floats are refused at runtime.",
            }
        }),
        _challenge_operation("PRICE", ["value", "unit"], {
            "value": _CHALLENGE_EXACT, "unit": {"type": "string", "minLength": 1},
        }),
        _challenge_operation(
            "TECHNOLOGY_COORDINATE", ["coordinate_id", "value", "unit"], {
                "coordinate_id": {"type": "string", "minLength": 1},
                "value": _CHALLENGE_EXACT,
                "unit": {"type": "string", "minLength": 1},
            },
        ),
        _challenge_operation(
            "EVIDENCE_VALUE", ["evidence_id", "value", "evidence_class"], {
                "evidence_id": {"type": "string", "minLength": 1},
                "value": {
                    "type": ["string", "integer", "boolean", "object", "array", "null"],
                    "description": "Canonical value; binary floats are refused at runtime.",
                },
                "evidence_class": {"type": "string", "minLength": 1},
            },
        ),
        _challenge_operation(
            "EVIDENCE_VALIDITY", ["evidence_id", "validity"], {
                "evidence_id": {"type": "string", "minLength": 1},
                "validity": {
                    "type": "string", "enum": ["VALID", "INVALID", "EXPIRED", "REVOKED"]
                },
            },
        ),
        _challenge_operation("CAPABILITY", ["capability_id", "value"], {
            "capability_id": {"type": "string", "minLength": 1},
            "value": {
                "type": ["string", "integer", "boolean", "object", "array", "null"],
                "description": "Canonical value; binary floats are refused at runtime.",
            },
        }),
        _challenge_operation("LEGALITY", ["realization_id", "legality"], {
            "realization_id": {"type": "string", "minLength": 1},
            "legality": {"type": "string", "enum": ["LEGAL", "ILLEGAL"]},
        }),
        _challenge_operation("POLICY_TOLERANCE", ["value"], {
            "value": _CHALLENGE_EXACT,
        }),
        _challenge_operation("RETENTION_POLICY", ["policy_id", "policy"], {
            "policy_id": {"type": "string", "minLength": 1},
            "policy": {"type": "string", "minLength": 1},
        }),
        _challenge_operation(
            "PHYSICAL_CONSTRAINT", ["constraint_id", "value", "unit"], {
                "constraint_id": {"type": "string", "minLength": 1},
                "value": _CHALLENGE_EXACT,
                "unit": {"type": "string", "minLength": 1},
            },
        ),
    ]
}


_CHALLENGE_REQUEST_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "required": ["challenge_id"],
    "properties": {
        "challenge_id": {"type": "string", "minLength": 1},
        "evidence_id": {
            "type": "string", "minLength": 1,
            "description": "A stored CertifiedDeltaRecord with exact portable replay inputs.",
        },
        "operations": {
            "type": "array", "minItems": 1, "items": _CHALLENGE_OPERATION_SCHEMA,
        },
        "promotion_request": {
            "type": "object", "additionalProperties": False,
            "required": ["request_id", "governed_operation", "requested_by", "reason"],
            "properties": {
                "request_id": {"type": "string", "minLength": 1},
                "governed_operation": {
                    "type": "string",
                    "enum": [
                        "APPLY_CERTIFIED_CHANGE", "CREATE_GOVERNED_BRANCH",
                        "SUBMIT_CHANGE_FOR_APPROVAL",
                    ],
                },
                "requested_by": {"type": "string", "minLength": 1},
                "reason": {"type": "string", "minLength": 1},
            },
            "description": "A separate PROPOSED / NOT_EXECUTED request; never authority.",
        },
        "refusal": {
            "type": "object", "additionalProperties": False,
            "required": ["status", "reason_code", "detail", "attempted_input"],
            "properties": {
                "status": {"type": "string", "enum": ["REFUSED", "UNKNOWN"]},
                "reason_code": {
                    "type": "string",
                    "enum": [
                        "UNREGISTERED_MUTATION", "MISSING_VERIFIER_EVIDENCE",
                        "UNKNOWN_OR_INCOMPLETE_INPUT", "CHANGED_BASELINE_ROOT",
                        "UNSUPPORTED_PROFILE", "VERIFICATION_FAILED",
                        "UNKNOWN_CHANGE_SEMANTICS", "UNKNOWN_PROOF_SEMANTICS",
                        "CALLER_DERIVED_FACTS_REFUSED",
                    ],
                },
                "detail": {"type": "string", "minLength": 1},
                "attempted_input": {
                    "description": "Canonical attempted input; no conclusion is inferred from it."
                },
            },
        },
    },
    "oneOf": [
        {
            "required": ["evidence_id", "operations"],
            "not": {"required": ["refusal"]},
        },
        {
            "required": ["refusal"],
            "not": {
                "anyOf": [
                    {"required": ["evidence_id"]}, {"required": ["operations"]},
                    {"required": ["promotion_request"]},
                ]
            },
        },
    ],
    "description": (
        "Closed non-authorizing Decision Challenge request. Baselines, results, winner "
        "facts, ranks, scores, hashes, authority, and mutation claims are never authored."
    ),
}


def _declared_object(description: str) -> Dict[str, Any]:
    return {
        "type": "object",
        "additionalProperties": True,
        "description": description,
    }


def _comparative_change_author_request_schema() -> Dict[str, Any]:
    required = [
        "comparison_id", "certified_delta_id", "decision_scope",
        "evidence_scope", "limitations",
    ]
    return {
        "type": "object",
        "additionalProperties": False,
        "required": required,
        "properties": {
            "comparison_id": {"type": "string", "minLength": 1},
            "certified_delta_id": {
                "type": "string",
                "minLength": 1,
                "description": (
                    "Identity of a CertifiedDeltaRecord already stored on this case. "
                    "Record bytes and verifier inputs cannot be submitted here."
                ),
            },
            "decision_scope": _declared_object(
                "Declared decision scope; all comparative facts remain system-derived."
            ),
            "evidence_scope": _declared_object(
                "Declared evidence classes and observation boundary."
            ),
            "limitations": {
                "type": "array", "minItems": 1, "uniqueItems": True,
                "items": {"type": "string", "minLength": 1},
            },
        },
        "description": (
            "Closed stored-identity request. The server resolves and independently "
            "replays the exact certified delta, then independently reconstructs the "
            "NON_AUTHORIZING ComparativeChangeEvidence before preview or persistence."
        ),
    }


def _closed_record_verification_schema(record_type: str) -> Dict[str, Any]:
    return {
        "type": "object",
        "additionalProperties": False,
        "required": ["record"],
        "properties": {
            "record": {
                "type": "object",
                "description": (
                    f"Canonical self-contained {record_type}; authoring fields are not accepted."
                ),
            }
        },
    }


def _request_body(endpoint: Any) -> Dict[str, Any]:
    if "OperationalMeasurement" in endpoint.operation_id:
        properties: Dict[str, Any] = {}
        required: List[str] = []
        operation = endpoint.operation_id
        if operation == "startOperationalMeasurementSession":
            properties = {
                "session_id": _PSEUDONYM_SCHEMA,
                "purpose_code": {
                    **_MEASUREMENT_CODE_SCHEMA,
                    "enum": [
                        "local-product-evaluation", "reference-path-evaluation",
                        "reliability-evaluation", "workflow-timing",
                    ],
                },
                "scope_code": {
                    **_MEASUREMENT_CODE_SCHEMA,
                    "enum": [
                        "declared-operation-set", "reference-journey", "single-session",
                    ],
                },
            }
            required = ["session_id", "purpose_code", "scope_code"]
        elif operation == "recordOperationalMeasurementObservation":
            properties = {
                "metric_code": _MEASUREMENT_CODE_SCHEMA,
                "numerator": {"type": "integer"},
                "denominator": {"type": "integer", "minimum": 1, "default": 1},
                "unit_code": {**_MEASUREMENT_CODE_SCHEMA, "default": "count"},
                "measurement_class": {
                    "type": "string",
                    "enum": ["SYSTEM_DERIVED", "LOCAL_OBSERVATION"],
                    "default": "LOCAL_OBSERVATION",
                },
            }
            required = ["metric_code", "numerator"]
        elif operation == "recordOperationalMeasurementCounterfactual":
            properties = {
                "metric_code": _MEASUREMENT_CODE_SCHEMA,
                "numerator": {"type": "integer"},
                "denominator": {"type": "integer", "minimum": 1, "default": 1},
                "unit_code": {**_MEASUREMENT_CODE_SCHEMA, "default": "count"},
                "basis_code": _MEASUREMENT_CODE_SCHEMA,
            }
            required = ["metric_code", "numerator", "basis_code"]
        elif operation == "verifyOperationalMeasurementExport":
            properties = {
                "export": {"$ref": "#/components/schemas/OperationalMeasurementExport"}
            }
            required = ["export"]
        elif operation == "previewOperationalMeasurementRetention":
            properties = {
                "as_of": {"type": "string", "format": "date-time"},
                "maximum_age_seconds": {"type": "integer", "minimum": 0},
            }
            required = ["maximum_age_seconds"]
        elif operation == "enforceOperationalMeasurementRetention":
            properties = {
                "preview": {
                    "$ref": "#/components/schemas/OperationalMeasurementRetentionPreview"
                },
                "confirmation_hash": {"$ref": "#/components/schemas/ContentHash"},
            }
            required = ["preview", "confirmation_hash"]
        elif operation == "deleteOperationalMeasurementSession":
            properties = {
                "expected_content_hash": {"$ref": "#/components/schemas/ContentHash"}
            }
            required = ["expected_content_hash"]
        elif operation not in _MEASUREMENT_EMPTY_BODY_OPERATIONS:
            raise AssertionError(
                f"operational measurement request schema missing for {operation}"
            )
        return {
            "required": bool(required),
            "content": {
                "application/json": {
                    "schema": {
                        "type": "object",
                        "additionalProperties": False,
                        "required": required,
                        "properties": properties,
                        "description": (
                            "Closed CRG-ENH-04 local-measurement request. Free-form case, "
                            "evidence, identity, and claim fields are forbidden."
                        ),
                    }
                }
            },
        }
    if endpoint.operation_id in {"previewRegistryIntake", "confirmRegistryIntake"}:
        properties: Dict[str, Any] = {
            "mapping_profile": _INTAKE_MAPPING_PROFILE_SCHEMA,
            "provenance": _INTAKE_PROVENANCE_SCHEMA,
            "source_text": {
                "type": "string",
                "description": "Exact inline UTF-8 CSV or JSON source content.",
            },
            "source_base64": {
                "type": "string",
                "contentEncoding": "base64",
                "description": "Byte-exact UTF-8 CSV or JSON source content.",
            },
        }
        required = ["mapping_profile", "provenance"]
        if endpoint.operation_id == "confirmRegistryIntake":
            properties.update({
                "expected_preview_hash": {
                    "type": "string", "pattern": "^sha256:[0-9a-f]{64}$",
                },
                "accept_partial": {"type": "boolean", "default": False},
            })
            required.append("expected_preview_hash")
        schema = {
            "type": "object",
            "additionalProperties": False,
            "required": required,
            "properties": properties,
            "oneOf": [
                {"required": ["source_text"], "not": {"required": ["source_base64"]}},
                {"required": ["source_base64"], "not": {"required": ["source_text"]}},
            ],
            "description": (
                "Preview is non-authorizing and non-mutating. Confirmation re-runs the "
                "producer and binds expected_preview_hash before any successor case is written."
            ),
        }
        return {
            "required": True,
            "content": {"application/json": {"schema": schema}},
        }
    if endpoint.operation_id in {
        "previewComparativeEvaluation", "generateComparativeEvaluation"
    }:
        object_fields = {
            "inputs", "technology_scope", "evidence_scope", "change_scope",
            "scenario_scope", "held_out_treatment", "oracle",
        }
        array_fields = {
            "workload", "methods", "limitations", "local_observations",
            "declared_counterfactuals",
        }
        properties: Dict[str, Any] = {}
        for name in endpoint.request_fields:
            if name in object_fields:
                properties[name] = {"type": "object"}
            elif name in array_fields:
                properties[name] = {"type": "array"}
            else:
                properties[name] = {"type": "string", "minLength": 1}
        required = [
            name for name in endpoint.request_fields
            if name not in {"local_observations", "declared_counterfactuals"}
        ]
        return {
            "required": True,
            "content": {
                "application/json": {
                    "schema": {
                        "type": "object",
                        "additionalProperties": False,
                        "required": required,
                        "properties": properties,
                        "description": (
                            "Closed finite/exact authoring request. The server derives every "
                            "fact, independently reconstructs the canonical record, and gives "
                            "the result NON_AUTHORIZING authority with semantic effect NONE."
                        ),
                    }
                }
            },
        }
    if endpoint.operation_id in {
        "previewComparativeChange", "generateComparativeChange",
    }:
        return {
            "required": True,
            "content": {
                "application/json": {
                    "schema": _comparative_change_author_request_schema()
                }
            },
        }
    if endpoint.operation_id == "verifyComparativeChange":
        return {
            "required": True,
            "content": {
                "application/json": {
                    "schema": _closed_record_verification_schema(
                        "ComparativeChangeEvidence"
                    )
                }
            },
        }
    if endpoint.operation_id in {
        "previewDecisionChallenge", "recordDecisionChallenge"
    }:
        return {
            "required": True,
            "content": {
                "application/json": {"schema": copy.deepcopy(_CHALLENGE_REQUEST_SCHEMA)}
            },
        }
    if endpoint.operation_id == "verifyDecisionChallenge":
        return {
            "required": True,
            "content": {
                "application/json": {
                    "schema": {
                        "type": "object",
                        "additionalProperties": False,
                        "required": ["record"],
                        "properties": {
                            "record": {
                                "type": "object",
                                "description": (
                                    "Canonical self-contained DecisionChallengeRecord with "
                                    "embedded portable replay evidence."
                                ),
                            }
                        },
                    }
                }
            },
        }
    if endpoint.operation_id == "verifyComparativeEvaluation":
        return {
            "required": True,
            "content": {
                "application/json": {
                    "schema": {
                        "type": "object",
                        "additionalProperties": False,
                        "required": ["record"],
                        "properties": {
                            "record": {
                                "type": "object",
                                "description": (
                                    "A canonical ComparativeWorkflowEvaluation. It embeds "
                                    "all exact verifier inputs."
                                ),
                            }
                        },
                    }
                }
            },
        }
    properties = {
        name: {"description": f"See specification {endpoint.spec}."}
        for name in endpoint.request_fields
    }
    return {
        "required": bool(endpoint.request_fields),
        "content": {
            "application/json": {
                "schema": {
                    "type": "object",
                    "properties": properties,
                    "additionalProperties": True,
                    "description": (
                        "10.1: external systems interact through typed requests and "
                        "responses, and never mutate canonical CRG objects directly."
                    ),
                }
            }
        },
    }


def endpoint_paths() -> List[str]:
    """Every ``METHOD path`` pair this server implements."""
    from .app import ENDPOINTS

    return [f"{e.method} {e.path}" for e in ENDPOINTS]


def openapi_document(*, authenticated: bool = True) -> Dict[str, Any]:
    """The complete OpenAPI 3.1 description of the integration surface (38.2)."""
    from .app import ENDPOINTS, ROLE_REQUIREMENTS
    from .events import EVENT_VOCABULARY

    paths: Dict[str, Any] = {}
    for endpoint in ENDPOINTS:
        operation: Dict[str, Any] = {
            "operationId": endpoint.operation_id,
            "summary": endpoint.summary,
            "description": (
                f"Specification {endpoint.spec}."
                + (
                    "  This action is long-running and returns a job identifier (38.3)."
                    if endpoint.long_running
                    else ""
                )
                + (
                    "  Identical canonical requests resolve to the existing "
                    "content-addressed result (38.4)."
                    if endpoint.content_addressed
                    else ""
                )
            ),
            "tags": [endpoint.path.strip("/").split("/")[0] or "root"],
            "parameters": _parameters(endpoint, authenticated=authenticated),
            "responses": _responses(endpoint),
        }
        required_roles = ROLE_REQUIREMENTS.get(endpoint.operation_id)
        if required_roles:
            operation["x-crg-required-roles"] = list(required_roles)
        operation["x-crg-spec-reference"] = endpoint.spec
        operation["x-crg-long-running"] = endpoint.long_running
        if getattr(endpoint, "streaming", False):
            # A generated client needs to know, before it calls, that this
            # operation returns an iterator rather than a document (38.2).
            operation["x-crg-streaming"] = True
            operation["x-crg-stream-transport"] = "server-sent-events"
        if endpoint.method == "POST":
            operation["requestBody"] = _request_body(endpoint)
        if authenticated and endpoint.operation_id in {
            "getOpenApi", "healthLive", "healthReady"
        }:
            operation["security"] = []
        paths.setdefault(endpoint.path, {})[endpoint.method.lower()] = operation

    return {
        "openapi": OPENAPI_VERSION,
        "info": {
            "title": "CRG Systems headless integration surface",
            "version": "1.2.0",
            "summary": "Import, augment, certify, verify, and export CRG cases",
            "description": (
                "The secured CRG Systems API. Long-running actions return job "
                "identifiers, mutations accept idempotency keys, and blocked or "
                "unauthorized outcomes are never represented as successful results."
            ),
            "license": {
                "name": "CRG Systems Research and Noncommercial License 1.0",
                "identifier": "LicenseRef-CRG-Research-Noncommercial-1.0",
            },
            "x-research-and-noncommercial-use-permitted-with-attribution": True,
            "x-commercial-use-requires-separate-license": True,
            "x-licensor": "Semi AI Foundry, LLC",
            "x-attribution-group": (
                "semiAIfoundry Research, a research group within "
                "Semi AI Foundry, LLC"
            ),
        },
        "servers": [{"url": "/", "description": "this deployment"}],
        "paths": paths,
        "components": {
            "schemas": {
                "Error": _ERROR_SCHEMA,
                "JobAccepted": _JOB_ACCEPTED_SCHEMA,
                "JobRecord": _JOB_SCHEMA,
                "Event": _EVENT_SCHEMA,
                "AuditEntry": _AUDIT_ENTRY_SCHEMA,
                "AuditExportRecord": _AUDIT_EXPORT_SCHEMA,
                "TombstoneRecord": _TOMBSTONE_SCHEMA,
                "Exact": _EXACT_SCHEMA,
                "ContentHash": _AUDIT_HASH_SCHEMA,
                "OperationalMeasurementProfile": _measurement_component(
                    "OperationalMeasurementProfile"
                ),
                "OperationalMeasurementPermission": _measurement_component(
                    "OperationalMeasurementPermission"
                ),
                "OperationalMeasurementEvent": _measurement_component(
                    "OperationalMeasurementEvent"
                ),
                "OperationalMeasurementSessionRecord": _measurement_component(
                    "OperationalMeasurementSessionRecord"
                ),
                "OperationalMeasurementRetentionPreview": _measurement_component(
                    "OperationalMeasurementRetentionPreview"
                ),
                "OperationalMeasurementDeletionReceipt": _measurement_component(
                    "OperationalMeasurementDeletionReceipt"
                ),
                "OperationalMeasurementExport": _measurement_component(
                    "OperationalMeasurementExport"
                ),
                "OperationalMeasurementSessionSummary": (
                    _MEASUREMENT_SESSION_SUMMARY_SCHEMA
                ),
                "OperationalMeasurementConfigurationView": (
                    _MEASUREMENT_CONFIGURATION_SCHEMA
                ),
                "OperationalMeasurementSessionList": (
                    _MEASUREMENT_SESSION_LIST_SCHEMA
                ),
                "OperationalMeasurementVerificationResult": (
                    _MEASUREMENT_VERIFICATION_SCHEMA
                ),
            },
            "securitySchemes": {
                "BasicAuth": {
                    "type": "http",
                    "scheme": "basic",
                    "description": "TLS-protected local account authentication (44.2, 44.4).",
                },
                "BearerAuth": {
                    "type": "http",
                    "scheme": "bearer",
                    "description": "Federated identity adapter token (44.2).",
                },
                "ApiKeyAuth": {
                    "type": "apiKey",
                    "in": "header",
                    "name": "Authorization",
                    "description": "Service identity as 'ApiKey <key_id>.<secret>' (44.2).",
                },
            } if authenticated else {},
        },
        "security": ([{"BasicAuth": []}, {"BearerAuth": []}, {"ApiKeyAuth": []}]
                     if authenticated else []),
        "x-crg-authentication-profile": (
            "configured-authentication" if authenticated else "unverified-development-actor"
        ),
        "x-crg-spec-version": "0.2.0",
        "x-crg-event-vocabulary": list(EVENT_VOCABULARY),
        "x-crg-object-statuses": [
            "SUPERSEDED", "EXPIRED", "REVOKED", "REDACTED", "CRYPTOGRAPHICALLY_ERASED",
            "LEGALLY_DELETED", "UNAVAILABLE", "INVALID", "UNVERIFIABLE_REDACTED",
        ],
        "x-crg-minimum-roles": [
            "Viewer", "Contributor", "Registry Importer", "Generator Author",
            "Pack Publisher", "Evidence Steward", "Qualification Author",
            "Decision Approver", "Certificate Signer", "Federation Operator",
            "Auditor", "Security Administrator", "System Administrator",
        ],
    }
