"""Portable ``.crg`` interchange artifact: write, read, and verify.

Normative basis: master specification section 39 (portable ``.crg``
interchange artifact), with section 6.2 (portable state), 6.3 (no
central-service dependency), 6.12 (anti-lock-in), and 14.4 (hashing).

A ``.crg`` file is a self-describing zip whose contents are content
addressed: the name of an object file **is** its hash, so a bundle can be
checked with nothing but ``sha256`` and a JSON canonicalizer, on a machine
that has never heard of this implementation.

Layout written by :func:`write_bundle` (spec 39)::

    manifest.json
    case.json
    objects/sha256/<hash>.json
    artifacts/sha256/<hash>
    schemas/referenced-schema-manifest.json
    signatures/manifest.sig            (only when a signature is supplied)
    audit/events.jsonl
    README.md

Three design points are load-bearing:

* **The manifest cannot hash itself.**  Every other member is hashed *in* the
  manifest; the manifest's own digest is written to the zip archive comment,
  one level up, so tampering with ``manifest.json`` is detectable without
  trusting the manifest.  This is an integrity check, not an authenticity
  check: only ``signatures/manifest.sig`` can say who produced the bundle
  (spec 14.5), and :func:`verify_bundle_integrity` says so rather than
  implying more than it proves.
* **Determinism.**  Members are stored in sorted order with a fixed timestamp,
  so writing the same case twice produces byte-identical bundles.  A bundle
  that changes when nothing changed cannot be diffed, cached, or trusted.
* **No unversioned external dependency** (39.2).  An external reference
  without an expected content hash makes the certificate depend on whatever a
  URL happens to serve tomorrow, so verification reports it as a violation.
"""
from __future__ import annotations

import hashlib
import json
import os
import zipfile
from dataclasses import dataclass
from typing import Any, BinaryIO, Callable, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple, Union

from crg_model.canonical import canonical_bytes, canonical_json, content_hash

__all__ = [
    "BUNDLE_FORMAT_VERSION",
    "CREATION_TOOL",
    "CREATION_TOOL_VERSION",
    "BundleError",
    "BundleIntegrityError",
    "FileArtifact",
    "write_bundle",
    "read_bundle",
    "verify_bundle_integrity",
    "manifest_hash_of",
]

BUNDLE_FORMAT_VERSION = "1.0.0"
CRG_SPEC_VERSION = "0.2.0"
CREATION_TOOL = "crg-io"
CREATION_TOOL_VERSION = "1.1.0"

MANIFEST_PATH = "manifest.json"
CASE_PATH = "case.json"
OBJECT_PREFIX = "objects/sha256/"
ARTIFACT_PREFIX = "artifacts/sha256/"
PROOF_PREFIX = "proofs/sha256/"
SCHEMA_MANIFEST_PATH = "schemas/referenced-schema-manifest.json"
SIGNATURE_PATH = "signatures/manifest.sig"
AUDIT_PATH = "audit/events.jsonl"
README_PATH = "README.md"

REQUIRED_MEMBERS: Tuple[str, ...] = (
    MANIFEST_PATH,
    CASE_PATH,
    SCHEMA_MANIFEST_PATH,
    AUDIT_PATH,
    README_PATH,
)

#: Specification 39.1: every field the manifest MUST contain.
REQUIRED_MANIFEST_FIELDS: Tuple[str, ...] = (
    "bundle_format_version",
    "crg_spec_version",
    "root_case_object",
    "object_inventory",
    "artifact_inventory",
    "proof_inventory",
    "content_hashes",
    "external_references",
    "schema_identities",
    "quantity_registry_version",
    "rule_table_version",
    "signatures",
    "encryption",
    "redaction_state",
    "export_authority",
    "creation_tool",
    "requested_verification_level",
)

#: Specification 39.2: every field an external reference MUST include.
REQUIRED_REFERENCE_FIELDS: Tuple[str, ...] = (
    "immutable_identity",
    "expected_content_hash",
    "retrieval_policy",
    "required_access",
    "validity",
    "offline_behavior",
    "unavailable_behavior",
)

#: A fixed zip timestamp: a bundle's identity is its content, not its clock.
_FIXED_DATE = (1980, 1, 1, 0, 0, 0)


class BundleError(ValueError):
    """A bundle could not be written or read."""


class BundleIntegrityError(BundleError):
    """A bundle failed verification; the violations are carried on the error."""

    def __init__(self, path: str, violations: Sequence[str]) -> None:
        self.path = path
        self.violations = tuple(violations)
        detail = "\n  - ".join(self.violations)
        super().__init__(f"bundle {path!r} failed integrity verification:\n  - {detail}")


@dataclass(frozen=True)
class FileArtifact:
    """Explicit streaming source for a large opaque artifact.

    A path is wrapped rather than accepted implicitly so passing a textual
    artifact can never be confused with granting filesystem access.
    """

    path: Union[str, os.PathLike]
    chunk_size: int = 1024 * 1024

    def __post_init__(self) -> None:
        if not isinstance(self.chunk_size, int) or isinstance(self.chunk_size, bool) \
                or self.chunk_size <= 0:
            raise ValueError("FileArtifact chunk_size must be a positive integer")


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------


def _canonical(value: Any) -> bytes:
    """Canonical bytes for anything with a canonical form (spec 14.3)."""
    to_canonical = getattr(value, "to_canonical", None)
    if callable(to_canonical):
        value = to_canonical()
    return canonical_bytes(value)


def _digest(data: bytes) -> str:
    return "sha256:" + hashlib.sha256(data).hexdigest()


def _inspect_file_artifact(source: FileArtifact) -> Tuple[str, int]:
    hasher = hashlib.sha256()
    length = 0
    try:
        with open(os.fspath(source.path), "rb") as handle:
            while True:
                chunk = handle.read(source.chunk_size)
                if not chunk:
                    break
                hasher.update(chunk)
                length += len(chunk)
    except OSError as exc:
        raise BundleError(f"artifact source {os.fspath(source.path)!r} cannot be read: {exc}") from exc
    return "sha256:" + hasher.hexdigest(), length


def _hex(digest: str) -> str:
    return digest.split(":", 1)[1]


def _as_dict(value: Any) -> Dict[str, Any]:
    to_canonical = getattr(value, "to_canonical", None)
    if callable(to_canonical):
        value = to_canonical()
    if not isinstance(value, Mapping):
        raise BundleError(f"expected a mapping, got {type(value).__name__}")
    return dict(value)


def _encrypted_object_descriptor(
    object_id: str, body: Any, *, path: str, envelope_hash: str,
) -> Optional[Dict[str, Any]]:
    """Recognize the language-neutral ``crg-security`` envelope (§39.3)."""
    if not isinstance(body, Mapping) or body.get("record_type") != "EncryptedObject":
        return None
    required = (
        "object_id", "tenant_id", "object_type", "encryption_profile",
        "content_hash", "nonce", "ciphertext", "wrapped_key", "created_at", "status",
    )
    missing = [name for name in required if name not in body]
    if missing:
        raise BundleError(
            f"encrypted object {object_id!r} omits {missing}; refusing ambiguous protected content"
        )
    if str(body.get("object_id")) != str(object_id):
        raise BundleError(
            f"encrypted object inventory id {object_id!r} differs from envelope id "
            f"{body.get('object_id')!r}"
        )
    wrapped = body.get("wrapped_key")
    if not isinstance(wrapped, Mapping) or not str(wrapped.get("wrapping_key_id", "")):
        raise BundleError(f"encrypted object {object_id!r} has no wrapping-key identity")
    plaintext_hash = str(body.get("content_hash", ""))
    if not plaintext_hash.startswith("sha256:"):
        raise BundleError(f"encrypted object {object_id!r} has no plaintext content hash")
    return {
        "object_id": str(object_id),
        "path": path,
        "ciphertext_content_hash": envelope_hash,
        "plaintext_content_hash": plaintext_hash,
        "encryption_profile": str(body.get("encryption_profile")),
        "wrapping_key_id": str(wrapped.get("wrapping_key_id")),
        "tenant_id": str(body.get("tenant_id")),
        "object_type": str(body.get("object_type")),
        "status": str(body.get("status")),
    }


def _comment(manifest_digest: str) -> bytes:
    return canonical_bytes(
        {
            "bundle_format_version": BUNDLE_FORMAT_VERSION,
            "manifest_hash": manifest_digest,
        }
    )


# ---------------------------------------------------------------------------
# writing
# ---------------------------------------------------------------------------


def _schema_identities(case: Mapping[str, Any], objects: Mapping[str, Any]) -> List[Dict[str, Any]]:
    """Collect schema identities from the case and from embedded schemas (39.1)."""
    identities: List[Dict[str, Any]] = []
    seen = set()
    for declared in case.get("schema_identities", ()) or ():
        record = _as_dict(declared)
        key = (record.get("schema_id"), record.get("schema_hash"))
        if key not in seen:
            seen.add(key)
            identities.append(record)
    for object_id in sorted(objects):
        body = objects[object_id]
        to_canonical = getattr(body, "to_canonical", None)
        body = to_canonical() if callable(to_canonical) else body
        if isinstance(body, Mapping) and isinstance(body.get("schema"), Mapping):
            schema_hash = content_hash(body["schema"])
            key = (object_id, schema_hash)
            if key in seen:
                continue
            seen.add(key)
            identities.append(
                {
                    "schema_id": f"{object_id}#schema",
                    "schema_hash": schema_hash,
                    "schema_version": str(body.get("schema_version", CRG_SPEC_VERSION)),
                    "referenced_by": object_id,
                }
            )
    return identities


def _readme(manifest: Mapping[str, Any]) -> bytes:
    inventory = manifest["object_inventory"]
    artifacts = manifest["artifact_inventory"]
    text = f"""# CRG portable bundle (`.crg`)

Bundle format version: {manifest['bundle_format_version']}
CRG specification version: {manifest['crg_spec_version']}
Created by: {manifest['creation_tool']['name']} {manifest['creation_tool']['version']}
Objects: {len(inventory)}
Artifacts: {len(artifacts)}

This archive is self-describing and content addressed, per section 39 of the
CRG Operational Systems Master Specification. It requires no CRG installation
and no network service to check.

## Layout

    manifest.json                            inventory, hashes, and authority
    case.json                                the root case object
    objects/sha256/<hash>.json               canonical objects; filename IS the hash
    artifacts/sha256/<hash>                  opaque artifacts; filename IS the hash
    schemas/referenced-schema-manifest.json  schema identities this bundle binds to
    audit/events.jsonl                       append-only export/audit events
    README.md                                this file

## Independent verification

1. For every entry of `manifest.json` -> `content_hashes.entries`, recompute
   `sha256` over the stored member bytes and compare with the declared digest.
2. Check that each object and artifact filename equals the hex of its own
   digest; content addressing is what makes the inventory checkable.
3. Recompute `sha256` over `manifest.json` and compare it with the
   `manifest_hash` recorded in this archive's zip comment. The manifest cannot
   contain its own digest, so the digest lives one level up.
4. Canonicalize objects with RFC 8785 (JCS) before hashing anything you have
   re-serialized. Binary floating point is not admissible in canonical CRG
   content.

Hashes establish integrity, not authenticity. Only `signatures/manifest.sig`
can attribute this bundle to an authority.
"""
    return text.encode("utf-8")


def write_bundle(
    path: Union[str, os.PathLike, BinaryIO],
    *,
    case: Mapping[str, Any],
    objects: Mapping[str, Any],
    artifacts: Optional[Mapping[str, Union[bytes, bytearray, FileArtifact]]] = None,
    proofs: Optional[Mapping[str, Any]] = None,
    verification_programs: Optional[Mapping[str, Mapping[str, Any]]] = None,
    reports: Optional[Mapping[str, Union[str, bytes]]] = None,
    manifest_metadata: Optional[Mapping[str, Any]] = None,
    manifest_signer: Optional[Callable[[bytes, str], Union[bytes, Mapping[str, Any]]]] = None,
) -> str:
    """Write a portable ``.crg`` bundle and return the manifest content hash.

    ``case`` is the root case object.  Optional keys are lifted into the
    manifest so the bundle can describe itself without a second argument:
    ``external_references``, ``schema_identities``, ``export_authority``,
    ``quantity_registry_version``, ``rule_table_version``,
    ``requested_verification_level``, ``encryption``, ``redaction_state``,
    ``signatures``, ``audit_events``, ``proofs``, and ``omitted_objects``
    (a partial bundle, spec 39.4).

    ``objects`` maps a logical object id to any canonically encodable record
    (a dataclass with ``to_canonical`` or a plain mapping).  Objects are stored
    content addressed, so two logical ids with identical content share one
    stored member, which is correct rather than a deduplication trick.

    The returned string is the bundle's identity: ``sha256:<hex>`` over
    ``manifest.json``, the same value recorded in the archive comment.
    """
    case_body = _as_dict(case)
    manifest_source = dict(case_body)
    manifest_source.update(dict(manifest_metadata or {}))
    artifacts = dict(artifacts or {})
    proofs = dict(proofs or {})
    verification_programs = dict(verification_programs or {})
    reports = dict(reports or {})

    case_bytes = canonical_bytes(case_body)
    case_digest = _digest(case_bytes)

    members: Dict[str, Union[bytes, FileArtifact]] = {CASE_PATH: case_bytes}
    streamed_lengths: Dict[str, int] = {}
    content_hashes: Dict[str, str] = {CASE_PATH: case_digest}

    object_inventory: List[Dict[str, Any]] = []
    protected_inventory: List[Dict[str, Any]] = []
    for object_id in sorted(objects):
        data = _canonical(objects[object_id])
        digest = _digest(data)
        member = f"{OBJECT_PREFIX}{_hex(digest)}.json"
        members[member] = data
        content_hashes[member] = digest
        body = objects[object_id]
        to_canonical = getattr(body, "to_canonical", None)
        body = to_canonical() if callable(to_canonical) else body
        object_type = ""
        if isinstance(body, Mapping):
            object_type = str(body.get("object_type") or body.get("record_type") or "")
        entry = {
                "object_id": object_id,
                "object_type": object_type,
                "content_hash": digest,
                "path": member,
                "byte_length": len(data),
        }
        protected = _encrypted_object_descriptor(
            str(object_id), body, path=member, envelope_hash=digest
        )
        if protected is not None:
            entry.update({
                "encrypted": True,
                "plaintext_content_hash": protected["plaintext_content_hash"],
                "encryption_profile": protected["encryption_profile"],
            })
            protected_inventory.append(protected)
        object_inventory.append(entry)

    artifact_inventory: List[Dict[str, Any]] = []
    for artifact_id in sorted(artifacts):
        value = artifacts[artifact_id]
        if isinstance(value, FileArtifact):
            digest, byte_length = _inspect_file_artifact(value)
            data: Union[bytes, FileArtifact] = value
        elif isinstance(value, (bytes, bytearray)):
            data = bytes(value)
            digest, byte_length = _digest(data), len(data)
        else:
            raise BundleError(
                f"artifact {artifact_id!r} must be bytes or FileArtifact; artifacts are opaque"
            )
        member = f"{ARTIFACT_PREFIX}{_hex(digest)}"
        members[member] = data
        if isinstance(data, FileArtifact):
            streamed_lengths[member] = byte_length
        content_hashes[member] = digest
        artifact_inventory.append(
            {
                "artifact_id": artifact_id,
                "content_hash": digest,
                "path": member,
                "byte_length": byte_length,
            }
        )

    proof_inventory: List[Dict[str, Any]] = []
    for proof_id in sorted(proofs):
        proof = proofs[proof_id]
        data = bytes(proof) if isinstance(proof, (bytes, bytearray)) else _canonical(proof)
        digest = _digest(data)
        member = f"{PROOF_PREFIX}{_hex(digest)}"
        members[member] = data
        content_hashes[member] = digest
        proof_inventory.append(
            {
                "proof_id": proof_id,
                "content_hash": digest,
                "path": member,
                "byte_length": len(data),
            }
        )

    verification_inventory: List[Dict[str, Any]] = []
    for program_id in sorted(verification_programs):
        program = verification_programs[program_id]
        data = _canonical(program)
        digest = _digest(data)
        member = f"verification/programs/{program_id}.json"
        members[member] = data
        content_hashes[member] = digest
        verification_inventory.append(
            {
                "program_id": program_id,
                "certificate_id": str(program.get("certificate_id", "")),
                "content_hash": digest,
                "path": member,
                "byte_length": len(data),
            }
        )

    report_inventory: List[Dict[str, Any]] = []
    for report_id in sorted(reports):
        value = reports[report_id]
        data = value if isinstance(value, bytes) else str(value).encode("utf-8")
        digest = _digest(data)
        extension = "html" if str(report_id).endswith(".html") else "md"
        safe_id = str(report_id).rsplit(".", 1)[0].replace("/", "_")
        member = f"reports/{safe_id}.{extension}"
        members[member] = data
        content_hashes[member] = digest
        report_inventory.append(
            {
                "report_id": report_id,
                "content_hash": digest,
                "path": member,
                "byte_length": len(data),
            }
        )

    schema_identities = _schema_identities(manifest_source, objects)
    schema_manifest = {
        "bundle_format_version": BUNDLE_FORMAT_VERSION,
        "schema_identities": schema_identities,
    }
    schema_bytes = canonical_bytes(schema_manifest)
    members[SCHEMA_MANIFEST_PATH] = schema_bytes
    content_hashes[SCHEMA_MANIFEST_PATH] = _digest(schema_bytes)

    events: List[Mapping[str, Any]] = list(manifest_source.get("audit_events", ()) or ())
    if not events:
        events = [
            {
                "event": "bundle.exported",
                "case_id": str(case_body.get("case_id", "")),
                "object_count": len(object_inventory),
                "artifact_count": len(artifact_inventory),
                "tool": f"{CREATION_TOOL}@{CREATION_TOOL_VERSION}",
            }
        ]
    audit_bytes = ("\n".join(canonical_json(_as_dict(e)) for e in events) + "\n").encode("utf-8")
    members[AUDIT_PATH] = audit_bytes
    content_hashes[AUDIT_PATH] = _digest(audit_bytes)

    external_references = [_as_dict(ref) for ref in manifest_source.get("external_references", ()) or ()]
    omitted = [_as_dict(entry) for entry in manifest_source.get("omitted_objects", ()) or ()]

    manifest: Dict[str, Any] = {
        "bundle_format_version": BUNDLE_FORMAT_VERSION,
        "crg_spec_version": str(manifest_source.get("crg_spec_version", CRG_SPEC_VERSION)),
        "root_case_object": {
            "object_id": str(case_body.get("case_id", "case")),
            "content_hash": case_digest,
            "path": CASE_PATH,
        },
        "object_inventory": object_inventory,
        "artifact_inventory": artifact_inventory,
        "proof_inventory": proof_inventory,
        "content_hashes": {
            "algorithm": "sha256",
            "canonicalization": "RFC8785-JCS",
            "entries": dict(content_hashes),
        },
        "external_references": external_references,
        "schema_identities": schema_identities,
        "quantity_registry_version": str(manifest_source.get("quantity_registry_version", "unset")),
        "rule_table_version": str(manifest_source.get("rule_table_version", "unset")),
        "signatures": [_as_dict(s) for s in manifest_source.get("signatures", ()) or ()],
        "encryption": _encryption_metadata(manifest_source, protected_inventory),
        "redaction_state": _as_dict(manifest_source.get("redaction_state", {"redacted_objects": []})),
        "export_authority": _as_dict(
            manifest_source.get(
                "export_authority",
                {"authority": "unattested", "basis": "no export authority was declared"},
            )
        ),
        "creation_tool": {"name": CREATION_TOOL, "version": CREATION_TOOL_VERSION},
        "requested_verification_level": str(
            manifest_source.get("requested_verification_level", "INDEPENDENT_RECOMPUTATION")
        ),
        "verification_programs": verification_inventory,
        "reports": report_inventory,
    }
    if omitted:
        # Specification 39.4: a partial bundle must say what it is missing.
        affected_claims = sorted({
            str(claim)
            for entry in omitted
            for claim in (entry.get("affected_claims") or ())
        })
        manifest["partial"] = {
            "omitted_objects": omitted,
            "omission_reason": str(
                manifest_source.get("omission_reason", "see each omitted_objects entry")
            ),
            "affected_claims": affected_claims,
            "expected_external_dependencies": list(
                manifest_source.get("expected_external_dependencies", external_references)
                or ()
            ),
            "maximum_verification_level": str(
                manifest_source.get("maximum_verification_level", "STRUCTURAL_ONLY")
            ),
        }

    manifest_bytes = canonical_bytes(manifest)
    manifest_digest = _digest(manifest_bytes)
    members[MANIFEST_PATH] = manifest_bytes
    members[README_PATH] = _readme(manifest)

    signature = manifest_source.get("manifest_signature")
    if manifest_signer is not None:
        if not manifest.get("signatures"):
            raise BundleError(
                "manifest_signer requires at least one manifest signatures descriptor"
            )
        signed = manifest_signer(manifest_bytes, manifest_digest)
        signature = canonical_bytes(signed) if isinstance(signed, Mapping) else signed
    if signature is not None:
        if not isinstance(signature, (bytes, bytearray, str)):
            raise BundleError("manifest signature must be bytes, text, or a signer document")
        members[SIGNATURE_PATH] = (
            signature if isinstance(signature, (bytes, bytearray)) else str(signature).encode()
        )

    target: Union[str, os.PathLike, BinaryIO]
    if hasattr(path, "write"):
        target = path
    else:
        target = os.fspath(path)
        parent = os.path.dirname(os.path.abspath(target))
        if parent:
            os.makedirs(parent, exist_ok=True)
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for member in sorted(members):
            info = zipfile.ZipInfo(member, date_time=_FIXED_DATE)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            source = members[member]
            if isinstance(source, FileArtifact):
                hasher = hashlib.sha256()
                written = 0
                with archive.open(info, "w", force_zip64=True) as destination:
                    with open(os.fspath(source.path), "rb") as handle:
                        while True:
                            chunk = handle.read(source.chunk_size)
                            if not chunk:
                                break
                            destination.write(chunk)
                            hasher.update(chunk)
                            written += len(chunk)
                actual_digest = "sha256:" + hasher.hexdigest()
                if actual_digest != content_hashes[member] or written != streamed_lengths[member]:
                    raise BundleError(
                        f"artifact source {os.fspath(source.path)!r} changed while exported"
                    )
            else:
                archive.writestr(info, source)
        archive.comment = _comment(manifest_digest)
    return manifest_digest


def _encryption_metadata(
    case_body: Mapping[str, Any], protected_inventory: Sequence[Mapping[str, Any]] = (),
) -> Dict[str, Any]:
    """Specification 39.3: expose enough to judge checkability without the key."""
    declared = case_body.get("encryption")
    if protected_inventory:
        if declared is None:
            raise BundleError(
                "protected objects require encryption metadata naming affected claims, "
                "required verifier capabilities, and independent checkability (spec 39.3)"
            )
        metadata = _as_dict(declared)
        required = (
            "claims_depending_on_protected_content", "verifier_capabilities_required",
            "independently_checkable",
        )
        missing = [name for name in required if name not in metadata]
        if missing:
            raise BundleError(f"encryption metadata omits {missing} (spec 39.3)")
        if not isinstance(metadata.get("claims_depending_on_protected_content"), list):
            raise BundleError("claims_depending_on_protected_content must be a list")
        if not isinstance(metadata.get("verifier_capabilities_required"), list):
            raise BundleError("verifier_capabilities_required must be a list")
        if not isinstance(metadata.get("independently_checkable"), bool):
            raise BundleError("independently_checkable must be a boolean")
        metadata["protected_content_present"] = True
        metadata["encrypted_objects"] = [dict(item) for item in protected_inventory]
        return metadata
    if declared is not None:
        metadata = _as_dict(declared)
        if metadata.get("protected_content_present") or metadata.get("encrypted_objects"):
            raise BundleError(
                "encryption metadata declares protected objects but no encrypted object "
                "envelopes were supplied"
            )
        return metadata
    return {
        "protected_content_present": False,
        "encrypted_objects": [],
        "claims_depending_on_protected_content": [],
        "verifier_capabilities_required": [],
        "independently_checkable": True,
    }


# ---------------------------------------------------------------------------
# verification (spec 39.1, 39.2, 39.4)
# ---------------------------------------------------------------------------


def manifest_hash_of(path: Union[str, os.PathLike]) -> str:
    """Return the manifest digest recorded in the archive comment."""
    with zipfile.ZipFile(os.fspath(path), "r") as archive:
        comment = archive.comment
    try:
        return str(json.loads(comment.decode("utf-8"))["manifest_hash"])
    except Exception as exc:  # pragma: no cover - malformed container
        raise BundleError(f"bundle comment does not carry a manifest hash: {exc}") from exc


def verify_bundle_integrity(
    path: Union[str, os.PathLike],
    progress: Optional[Callable[[Mapping[str, Any]], None]] = None,
    chunk_size: int = 1024 * 1024,
) -> List[str]:
    """Recompute every hash in a bundle; return the violations found.

    An empty list means the bundle is internally intact: every declared member
    is present, every stored byte hashes to its declared digest, every object
    and artifact filename equals its own digest, no undeclared object or
    artifact is smuggled in, the manifest itself matches the digest recorded
    in the archive comment, and no claim depends on an unversioned external
    reference (spec 39.2).

    Integrity is not authenticity: this function proves the bundle is the one
    whose manifest was hashed, not who produced it. Large members are hashed
    in bounded chunks. ``progress`` receives immutable-by-convention mapping
    snapshots containing the current member and aggregate byte counts.
    """
    if not isinstance(chunk_size, int) or isinstance(chunk_size, bool) or chunk_size <= 0:
        raise ValueError("chunk_size must be a positive integer")
    if progress is not None and not callable(progress):
        raise TypeError("progress must be callable")
    target = os.fspath(path)
    violations: List[str] = []
    try:
        archive = zipfile.ZipFile(target, "r")
    except (zipfile.BadZipFile, OSError) as exc:
        return [f"bundle cannot be opened as a zip archive: {exc}"]

    with archive:
        listed_names = archive.namelist()
        names = set(listed_names)
        if len(names) != len(listed_names):
            duplicates = sorted({name for name in names if listed_names.count(name) > 1})
            violations.append("duplicate ZIP member name(s): " + ", ".join(duplicates))
        for required in REQUIRED_MEMBERS:
            if required not in names:
                violations.append(f"required member is missing: {required}")
        if MANIFEST_PATH not in names:
            return violations

        manifest_bytes = archive.read(MANIFEST_PATH)
        manifest_digest = _digest(manifest_bytes)
        try:
            manifest = json.loads(manifest_bytes.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            violations.append(f"manifest.json is not valid JSON: {exc}")
            return violations
        if not isinstance(manifest, dict):
            violations.append("manifest.json is not a JSON object")
            return violations

        # -- the manifest's own digest, recorded one level up in the container
        comment = archive.comment
        if not comment:
            violations.append(
                "the archive carries no manifest digest in its comment; the manifest cannot "
                "hash itself, so its digest MUST be recorded outside it"
            )
        else:
            try:
                declared = json.loads(comment.decode("utf-8"))
                declared_hash = str(declared.get("manifest_hash", ""))
            except Exception:
                declared_hash = ""
                violations.append("the archive comment is not readable manifest metadata")
            if declared_hash and declared_hash != manifest_digest:
                violations.append(
                    "manifest hash mismatch: the archive comment declares "
                    f"{declared_hash} but manifest.json hashes to {manifest_digest}; "
                    "the manifest has been altered"
                )

        for field_name in REQUIRED_MANIFEST_FIELDS:
            if field_name not in manifest:
                violations.append(f"manifest is missing required field {field_name!r} (spec 39.1)")

        if manifest.get("bundle_format_version") not in (None, BUNDLE_FORMAT_VERSION):
            violations.append(
                "bundle format version "
                f"{manifest.get('bundle_format_version')!r} is not readable by this "
                f"implementation ({BUNDLE_FORMAT_VERSION})"
            )

        # -- declared digests versus stored bytes
        entries = {}
        raw_hashes = manifest.get("content_hashes")
        if isinstance(raw_hashes, dict) and isinstance(raw_hashes.get("entries"), dict):
            entries = raw_hashes["entries"]
        else:
            violations.append("manifest content_hashes is missing or malformed (spec 39.1)")
        if isinstance(raw_hashes, dict) and raw_hashes.get("algorithm") not in (None, "sha256"):
            violations.append(
                f"unsupported hash algorithm {raw_hashes.get('algorithm')!r}; this verifier "
                "implements sha256 (spec 14.4)"
            )

        # Hash every protected path once, using ZipExtFile.read rather than
        # materializing large opaque artifacts. Inventories and the root may
        # name a member absent from content_hashes; include those paths so the
        # subsequent structural diagnostics can use the same measured bytes.
        protected_paths = {str(member) for member in entries}
        for inventory_name in ("object_inventory", "artifact_inventory", "proof_inventory"):
            inventory = manifest.get(inventory_name)
            if isinstance(inventory, list):
                protected_paths.update(
                    str(row.get("path")) for row in inventory
                    if isinstance(row, dict) and row.get("path")
                )
        root = manifest.get("root_case_object")
        if isinstance(root, dict):
            protected_paths.add(str(root.get("path", CASE_PATH)))
        total_bytes = sum(
            archive.getinfo(member).file_size for member in protected_paths if member in names
        )
        completed_bytes = 0
        measured: Dict[str, Tuple[str, int]] = {}
        for member in sorted(protected_paths):
            if member not in names:
                continue
            hasher = hashlib.sha256()
            member_bytes = 0
            member_total = archive.getinfo(member).file_size
            with archive.open(member, "r") as source:
                while True:
                    chunk = source.read(chunk_size)
                    if not chunk:
                        break
                    hasher.update(chunk)
                    member_bytes += len(chunk)
                    if progress is not None:
                        progress({
                            "member": member,
                            "member_bytes_read": member_bytes,
                            "member_bytes_total": member_total,
                            "verified_bytes": completed_bytes + member_bytes,
                            "total_bytes": total_bytes,
                        })
            measured[member] = ("sha256:" + hasher.hexdigest(), member_bytes)
            completed_bytes += member_bytes

        for member in sorted(entries):
            declared_digest = entries[member]
            if member not in names:
                violations.append(f"missing member declared in content_hashes: {member}")
                continue
            actual = measured[member][0]
            if actual != declared_digest:
                violations.append(
                    f"content hash mismatch for {member}: manifest declares {declared_digest}, "
                    f"stored bytes hash to {actual}"
                )

        # -- inventories: content addressing means the filename IS the hash
        stored_objects = {n for n in names if n.startswith(OBJECT_PREFIX)}
        stored_artifacts = {n for n in names if n.startswith(ARTIFACT_PREFIX)}
        inventory_paths = _check_inventory(
            archive,
            names,
            entries,
            manifest.get("object_inventory"),
            kind="object",
            id_field="object_id",
            prefix=OBJECT_PREFIX,
            suffix=".json",
            violations=violations,
            measured=measured,
        )
        artifact_paths = _check_inventory(
            archive,
            names,
            entries,
            manifest.get("artifact_inventory"),
            kind="artifact",
            id_field="artifact_id",
            prefix=ARTIFACT_PREFIX,
            suffix="",
            violations=violations,
            measured=measured,
        )
        proof_paths = _check_inventory(
            archive,
            names,
            entries,
            manifest.get("proof_inventory"),
            kind="proof",
            id_field="proof_id",
            prefix=PROOF_PREFIX,
            suffix="",
            violations=violations,
            measured=measured,
        )
        stored_proofs = {n for n in names if n.startswith(PROOF_PREFIX)}
        for extra in sorted(stored_objects - inventory_paths):
            violations.append(
                f"undeclared object present in the bundle: {extra} is not in the manifest "
                "object inventory"
            )
        for extra in sorted(stored_artifacts - artifact_paths):
            violations.append(
                f"undeclared artifact present in the bundle: {extra} is not in the manifest "
                "artifact inventory"
            )
        for extra in sorted(stored_proofs - proof_paths):
            violations.append(
                f"undeclared proof present in the bundle: {extra} is not in the manifest "
                "proof inventory"
            )

        # -- the root case object
        root = manifest.get("root_case_object")
        if not isinstance(root, dict):
            violations.append("manifest root_case_object is missing or malformed (spec 39.1)")
        else:
            root_path = str(root.get("path", CASE_PATH))
            if root_path not in names:
                violations.append(f"missing root case object: {root_path}")
            else:
                actual = measured[root_path][0]
                if actual != root.get("content_hash"):
                    violations.append(
                        f"root case object hash mismatch: manifest declares "
                        f"{root.get('content_hash')}, stored bytes hash to {actual}"
                    )

        violations.extend(_check_external_references(manifest.get("external_references")))
        violations.extend(_check_partial(manifest.get("partial")))
        violations.extend(_check_encryption(
            manifest.get("encryption"), manifest.get("object_inventory")
        ))

    return violations


def _check_inventory(
    archive: zipfile.ZipFile,
    names: Iterable[str],
    entries: Mapping[str, str],
    inventory: Any,
    *,
    kind: str,
    id_field: str,
    prefix: str,
    suffix: str,
    violations: List[str],
    measured: Mapping[str, Tuple[str, int]],
) -> set:
    names = set(names)
    paths: set = set()
    if inventory is None:
        return paths
    if not isinstance(inventory, list):
        violations.append(f"manifest {kind} inventory is malformed (spec 39.1)")
        return paths
    for entry in inventory:
        if not isinstance(entry, dict):
            violations.append(f"malformed {kind} inventory entry: {entry!r}")
            continue
        identity = entry.get(id_field, "(unnamed)")
        member = str(entry.get("path", ""))
        declared = str(entry.get("content_hash", ""))
        if not member or not declared:
            violations.append(
                f"{kind} {identity!r} is missing a path or a content hash in the inventory"
            )
            continue
        paths.add(member)
        expected_member = f"{prefix}{_hex(declared)}{suffix}"
        if member != expected_member:
            violations.append(
                f"{kind} {identity!r} is not content addressed: declared hash {declared} "
                f"requires member {expected_member}, inventory names {member}"
            )
        if member not in names:
            violations.append(f"missing {kind} declared in the inventory: {identity!r} at {member}")
            continue
        actual, actual_length = measured[member]
        if actual != declared:
            violations.append(
                f"{kind} {identity!r} hash mismatch: inventory declares {declared}, "
                f"stored bytes hash to {actual}"
            )
        if member not in entries:
            violations.append(
                f"{kind} {identity!r} at {member} is absent from manifest content_hashes"
            )
        if kind == "object":
            try:
                json.loads(archive.read(member).decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                violations.append(f"object {identity!r} at {member} is not valid JSON: {exc}")
        length = entry.get("byte_length")
        if isinstance(length, int) and length != actual_length:
            violations.append(
                f"{kind} {identity!r} declares byte_length {length} but stores "
                f"{actual_length} bytes"
            )
    return paths


def _check_external_references(references: Any) -> List[str]:
    """Specification 39.2: a portable certificate MUST NOT depend on an unversioned URL."""
    violations: List[str] = []
    if references is None:
        return violations
    if not isinstance(references, list):
        return ["manifest external_references is malformed (spec 39.2)"]
    for index, reference in enumerate(references):
        if not isinstance(reference, dict):
            violations.append(f"external reference {index} is malformed (spec 39.2)")
            continue
        identity = str(reference.get("immutable_identity", f"reference-{index}"))
        digest = reference.get("expected_content_hash")
        if not digest:
            violations.append(
                f"external reference {identity!r} has no expected content hash: a portable "
                "certificate MUST NOT depend on an unversioned URL, because the bundle would "
                "then mean whatever that location serves next (spec 39.2)"
            )
        missing = [
            name
            for name in REQUIRED_REFERENCE_FIELDS
            if name != "expected_content_hash" and not reference.get(name)
        ]
        if missing:
            violations.append(
                f"external reference {identity!r} is missing required field(s): "
                + ", ".join(missing)
                + " (spec 39.2)"
            )
    return violations


def _check_partial(partial: Any) -> List[str]:
    """Specification 39.4: a partial bundle must declare what it cannot prove."""
    if partial is None:
        return []
    violations: List[str] = []
    if not isinstance(partial, dict):
        return ["manifest partial section is malformed (spec 39.4)"]
    if not partial.get("maximum_verification_level"):
        violations.append(
            "a partial bundle MUST declare its maximum achievable verification level (spec 39.4)"
        )
    for index, omission in enumerate(partial.get("omitted_objects", []) or []):
        if not isinstance(omission, dict):
            violations.append(f"omitted-object entry {index} is malformed (spec 39.4)")
            continue
        missing = [
            field_name
            for field_name in ("object_id", "reason", "affected_claims")
            if not omission.get(field_name)
        ]
        if missing:
            violations.append(
                f"omitted object {omission.get('object_id', index)!r} is missing "
                + ", ".join(missing)
                + " (spec 39.4)"
            )
    return violations


def _check_encryption(encryption: Any, object_inventory: Any = None) -> List[str]:
    """Specification 39.3: protected content must be visible as protected."""
    if encryption is None:
        return []
    if not isinstance(encryption, dict):
        return ["manifest encryption metadata is malformed (spec 39.3)"]
    violations: List[str] = []
    required = (
        "protected_content_present", "encrypted_objects",
        "claims_depending_on_protected_content", "verifier_capabilities_required",
        "independently_checkable",
    )
    missing = [name for name in required if name not in encryption]
    if missing:
        violations.append(f"encryption metadata omits {missing} (spec 39.3)")
        return violations
    encrypted = encryption.get("encrypted_objects")
    if not isinstance(encrypted, list):
        return ["encryption encrypted_objects is not a list (spec 39.3)"]
    if encrypted and encryption.get("protected_content_present") is not True:
        violations.append(
            "encryption metadata lists encrypted objects but declares no protected content"
        )
    if not encrypted and encryption.get("protected_content_present") is True:
        violations.append("protected content is declared but encrypted_objects is empty")
    for field in ("claims_depending_on_protected_content", "verifier_capabilities_required"):
        if not isinstance(encryption.get(field), list):
            violations.append(f"encryption {field} is not a list")
    if not isinstance(encryption.get("independently_checkable"), bool):
        violations.append("encryption independently_checkable is not a boolean")
    protected_ids = set()
    descriptor_fields = {
        "object_id", "path", "ciphertext_content_hash", "plaintext_content_hash",
        "encryption_profile", "wrapping_key_id", "tenant_id", "object_type", "status",
    }
    for index, descriptor in enumerate(encrypted):
        if not isinstance(descriptor, dict):
            violations.append(f"encrypted_objects[{index}] is not an object")
            continue
        absent = sorted(descriptor_fields - set(descriptor))
        if absent:
            violations.append(f"encrypted_objects[{index}] omits {absent}")
        protected_ids.add(str(descriptor.get("object_id", "")))
    inventory_ids = {
        str(entry.get("object_id", ""))
        for entry in (object_inventory or [])
        if isinstance(entry, dict) and entry.get("encrypted") is True
    }
    if protected_ids != inventory_ids:
        violations.append(
            f"encryption inventory mismatch: metadata={sorted(protected_ids)}, "
            f"object_inventory={sorted(inventory_ids)}"
        )
    return violations


# ---------------------------------------------------------------------------
# reading
# ---------------------------------------------------------------------------


def read_bundle(
    path: Union[str, os.PathLike],
    *,
    object_decryptor: Optional[Callable[[Mapping[str, Any]], Any]] = None,
) -> Dict[str, Any]:
    """Read a ``.crg`` bundle, refusing to open one that fails verification.

    Returns ``{"manifest", "case", "objects", "artifacts", "schemas",
    "audit_events"}``.  ``objects`` maps the logical object id back to the
    parsed canonical record, and because storage is content addressed, the
    round trip preserves ``crg_model.canonical.content_hash`` exactly.

    Reading verifies first and raises :class:`BundleIntegrityError` on any
    violation: a corrupt bundle must fail closed rather than yield partially
    trustworthy records (spec 6.6).
    """
    target = os.fspath(path)
    violations = verify_bundle_integrity(target)
    if violations:
        raise BundleIntegrityError(target, violations)

    with zipfile.ZipFile(target, "r") as archive:
        manifest = json.loads(archive.read(MANIFEST_PATH).decode("utf-8"))
        case = json.loads(archive.read(CASE_PATH).decode("utf-8"))
        objects: Dict[str, Any] = {}
        encrypted_objects: Dict[str, Any] = {}
        for entry in manifest.get("object_inventory", []):
            object_id = str(entry["object_id"])
            body = json.loads(archive.read(str(entry["path"])).decode("utf-8"))
            if entry.get("encrypted") is True:
                encrypted_objects[object_id] = body
                if object_decryptor is None:
                    continue
                plaintext = object_decryptor(body)
                expected = str(entry.get("plaintext_content_hash", ""))
                actual = content_hash(plaintext)
                if actual != expected:
                    raise BundleIntegrityError(
                        target,
                        [f"decrypted object {object_id!r} hashes to {actual}, expected {expected}"],
                    )
                objects[object_id] = plaintext
            else:
                objects[object_id] = body
        artifacts: Dict[str, bytes] = {}
        for entry in manifest.get("artifact_inventory", []):
            artifacts[str(entry["artifact_id"])] = archive.read(str(entry["path"]))
        schemas = json.loads(archive.read(SCHEMA_MANIFEST_PATH).decode("utf-8"))
        audit_events = [
            json.loads(line)
            for line in archive.read(AUDIT_PATH).decode("utf-8").splitlines()
            if line.strip()
        ]

    return {
        "manifest": manifest,
        "case": case,
        "objects": objects,
        "encrypted_objects": encrypted_objects,
        "artifacts": artifacts,
        "schemas": schemas,
        "audit_events": audit_events,
    }
