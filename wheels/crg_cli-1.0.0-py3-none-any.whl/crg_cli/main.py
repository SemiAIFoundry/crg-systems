"""``crg`` -- the headless CRG command line.

Normative basis: 40 (CLI specification), 39 (portable ``.crg`` artifact),
50 (canonical human-readable report), 54 (Minimum Credible Loop).

The whole loop of 54.2 is runnable here::

    crg init      -> crg import    -> crg geometry -> crg query compile
    -> crg certify -> crg change   -> crg export   -> crg verify

and 54.4's exit gate is the point: the last step must succeed with the
originating process gone.  ``crg verify`` therefore uses ``crg-verify``,
which imports none of the modules that produced the artifact.
"""
from __future__ import annotations

import argparse
import datetime as _dt
import json
import os
import sys
import tempfile
import zipfile
from typing import Any, Dict, List, Mapping, Optional, Sequence

from crg_model.canonical import canonical_json, content_hash
from crg_model.completeness import CompletenessBasisType
from crg_model.edges import DependencyEdge, DependencyGraph, EdgeType
from crg_model.envelope import utc_now
from crg_model.migration import (
    DEFAULT_MIGRATION_REGISTRY,
    MIGRATION_CLASSES,
    MigrationError,
)
from crg_model.numeric import Exact
from crg_model.records import ChangeEvent, DecisionOutcome

import crg_certify
import crg_geometry
import crg_io
import crg_verify
from crg_change import apply_change
from .report import render_certificate_report

from .adapters import (
    CapabilityUnavailable,
    assemble_contract,
    evidence_record,
    generate_registry,
    layout_conversion,
    qualification_plan,
    run_evaluation,
)
from .output import HUMAN, JSON, OK, QUIET, STREAM, USAGE, VIOLATION, Emitter
from .store import (
    CaseError,
    IO_BACKEND,
    case_dir,
    import_table,
    load_bundle,
    load_derivation,
    load_scope,
    new_case,
    read_case,
    read_query_document,
    record_history,
    write_case,
)

__all__ = ["main", "build_parser"]

VERSION = "1.0.0"

#: Outcomes that constitute an affirmative certification (29.6).  Everything
#: else exits nonzero: 6.6 forbids a blocked or unresolved decision from
#: being presented as a success at the process boundary.
_AFFIRMATIVE = frozenset(
    {
        DecisionOutcome.CERTIFIED_WINNER,
        DecisionOutcome.CERTIFIED_WINNER_SET,
        DecisionOutcome.CERTIFIED_POLICY_TIE,
        DecisionOutcome.CERTIFIED_RETENTION,
    }
)


def _emitter(args: argparse.Namespace) -> Emitter:
    if getattr(args, "quiet", False):
        return Emitter(QUIET)
    if getattr(args, "stream", False):
        return Emitter(STREAM)
    if getattr(args, "as_json", False):
        return Emitter(JSON)
    return Emitter(HUMAN)


def _points(signatures: Sequence[Any]) -> List[List[dict]]:
    return [[v.to_canonical() for v in s.values] for s in signatures]


def _normalize_registry(case: Dict[str, Any]) -> None:
    """Store the registry in exactly the canonical form its hash is taken over.

    Specification 14.3-14.4.  ``RealizationBundle.to_canonical`` omits empty
    optional members, so a stored dict that keeps them would hash differently
    from the bundle the certificate names -- and an independent verifier
    would correctly report a missing dependency.  Round-tripping through the
    kernel's own canonical form removes that whole class of disagreement.
    """
    if case.get("registry"):
        case["registry"] = load_bundle(case).to_canonical()


# ---------------------------------------------------------------------------
# crg init / validate / import / inspect
# ---------------------------------------------------------------------------
def cmd_init(args: argparse.Namespace, out: Emitter) -> int:
    contract: Dict[str, Any] = {}
    if args.contract:
        contract = read_query_document(args.contract)
        if isinstance(contract, str):
            contract = {"contract_text": contract}
    case = new_case(args.case, contract)
    case["created_at"] = utc_now()
    record_history(case, "init", {"at": case["created_at"]})
    path = write_case(args.root, case)
    out.result(
        {"case_id": case["case_id"], "status": case["status"], "path": path,
         "io_backend": IO_BACKEND},
        f"initialized case {case['case_id']!r} at {path}\n  status: DRAFT\n"
        f"  persistence: {IO_BACKEND}",
    )
    return OK


def cmd_import(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    mapping = None
    if args.mapping:
        mapping = read_query_document(args.mapping)
        if isinstance(mapping, str):
            raise CaseError("a registry mapping must be a JSON document")
    registry, report = import_table(
        args.source,
        mapping,
        basis_type=args.completeness,
        declared_universe=args.universe,
        bundle_id=f"bundle-{args.case}",
    )
    case["registry"] = registry
    _normalize_registry(case)
    case["import_report"] = report
    case["status"] = "VALIDATED"
    record_history(case, "import", {"source": report["source"], "accepted": report["accepted"]})
    write_case(args.root, case)

    out.step("import", accepted=report["accepted"], rejected=report["rejected"])
    human = [
        f"imported {report['accepted']} realizations from {report['source']}",
        f"  source fingerprint : {report['source_fingerprint']}",
        f"  identifier column  : {report['identifier_column']}",
        f"  coordinates        : {', '.join(report['coordinates'])}",
        f"  completeness basis : {report['completeness_basis']}",
        f"  declared universe  : {report['declared_universe']}",
        f"  rejected rows      : {report['rejected']}",
    ]
    for rejection in report["rejections"]:
        human.append(f"    - row {rejection.get('row')}: {rejection.get('reason')}")
    out.result(report, "\n".join(human))
    return OK


def cmd_validate(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    problems: List[str] = []
    if not case.get("registry"):
        problems.append("no registry imported")
    else:
        try:
            bundle = load_bundle(case)
            dimension = bundle.schema.dimension
            for realization in bundle.realizations:
                if len(realization.signature) != dimension:
                    problems.append(
                        f"{realization.realization_id}: {len(realization.signature)} "
                        f"coordinates against a schema of {dimension}"
                    )
        except (CaseError, ValueError) as error:
            problems.append(str(error))
    payload = {"case_id": case["case_id"], "valid": not problems, "problems": problems}
    out.result(
        payload,
        "case is structurally valid" if not problems
        else "case is INVALID:\n" + "\n".join(f"  - {p}" for p in problems),
    )
    return OK if not problems else VIOLATION


def cmd_inspect(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    registry = case.get("registry") or {}
    completeness = registry.get("completeness") or {}
    payload = {
        "case_id": case["case_id"],
        "status": case.get("status"),
        "realizations": len(registry.get("realizations") or []),
        "completeness_basis": completeness.get("basis_type"),
        "declared_universe": completeness.get("declared_universe"),
        "registry_hash": content_hash(registry) if registry else None,
        "geometry": {k: v.get("root_hash") for k, v in (case.get("geometry") or {}).items()
                     if isinstance(v, dict)},
        "scope": (case.get("scope") or {}).get("scope_id"),
        "required_object": (case.get("derivation") or {}).get("required_object"),
        "certificates": sorted(case.get("certificates") or {}),
        "superseded_certificates": sorted(case.get("superseded_certificates") or {}),
        "deltas": sorted(case.get("deltas") or {}),
    }
    # Operational-module state, surfaced only when present so a plain case stays
    # uncluttered (spec 40 inspect; 33/34/32/16/15/17 artifacts).
    for key, source in (
        ("evidence", case.get("evidence")),
        ("technology_contracts", case.get("technology_contracts")),
        ("qualification_plans", case.get("qualification_plans")),
        ("conversions", case.get("conversions")),
        ("witnesses", case.get("witnesses")),
        ("tombstones", case.get("tombstones")),
        ("redacted_certificates", case.get("redacted_certificates")),
    ):
        if source:
            payload[key] = sorted(source)
    if case.get("branch_record"):
        payload["branch_of"] = case["branch_record"].get("parent_case")
    if case.get("migration_record"):
        payload["migrated_from"] = case["migration_record"].get("source_case")
    human = [
        f"case {payload['case_id']} [{payload['status']}]",
        f"  realizations      : {payload['realizations']}",
        f"  completeness basis: {payload['completeness_basis']} "
        f"({payload['declared_universe']})",
        f"  registry hash     : {payload['registry_hash']}",
        f"  geometry          : {payload['geometry'] or 'not built'}",
        f"  decision scope    : {payload['scope'] or 'not compiled'}",
        f"  required object   : {payload['required_object'] or 'not compiled'}",
        f"  certificates      : {payload['certificates'] or 'none'}",
        f"  superseded        : {payload['superseded_certificates'] or 'none'}",
        f"  delta certificates: {payload['deltas'] or 'none'}",
    ]
    for key in ("evidence", "technology_contracts", "qualification_plans",
                "conversions", "witnesses", "redacted_certificates"):
        if key in payload:
            human.append(f"  {key:<18}: {payload[key]}")
    out.result(payload, "\n".join(human))
    return OK


# ---------------------------------------------------------------------------
# crg geometry
# ---------------------------------------------------------------------------
def cmd_geometry(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    bundle = load_bundle(case)
    requested = [o.strip().upper() for o in args.objects.split(",") if o.strip()]

    geometry = dict(case.get("geometry") or {})
    r_record = crg_geometry.build_R(bundle)
    if "R" in requested:
        geometry["R"] = {
            "root_hash": r_record.root_hash(),
            "signatures": len(r_record.fibers),
            "fibers": [
                {"signature": f.signature.to_canonical(), "realization_ids": list(f.realization_ids)}
                for f in r_record.fibers
            ],
        }
        out.step("geometry", object="R", signatures=len(r_record.fibers))
    if "GAMMA" in requested:
        gamma = crg_geometry.build_gamma(r_record)
        geometry["GAMMA"] = {
            "root_hash": gamma.root_hash(),
            "frontier_size": len(gamma.frontier),
            "frontier": _points(gamma.frontier),
        }
        geometry["full_frontier"] = _points(gamma.frontier)
        out.step("geometry", object="GAMMA", frontier=len(gamma.frontier))
    if "K" in requested:
        k_record = crg_geometry.build_K(r_record)
        geometry["K"] = {
            "root_hash": k_record.root_hash(),
            "vertices": len(k_record.vertices),
            "vertex_points": _points(k_record.vertices),
        }
        out.step("geometry", object="K", vertices=len(k_record.vertices))

    case["geometry"] = geometry
    case["status"] = "GENERATED"
    record_history(case, "geometry", {"objects": requested})
    write_case(args.root, case)
    payload = {
        "case_id": case["case_id"],
        "objects": {k: v.get("root_hash") for k, v in geometry.items() if isinstance(v, dict)},
    }
    human = ["canonical geometry built"]
    for name in ("R", "GAMMA", "K"):
        if name in geometry:
            record = geometry[name]
            size = record.get("signatures") or record.get("frontier_size") or record.get("vertices")
            human.append(f"  {name:<6}: {size} generators, root {record['root_hash']}")
    out.result(payload, "\n".join(human))
    return OK


# ---------------------------------------------------------------------------
# crg query compile
# ---------------------------------------------------------------------------
def cmd_query_compile(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    document = read_query_document(args.scope)
    scope, derivation = crg_certify.compile_query(document)
    case["scope"] = {**scope.to_canonical(), "validity": scope.validity}
    case["derivation"] = derivation.to_canonical()
    case["status"] = "EVALUATED"
    record_history(case, "query compile", {"scope_id": scope.scope_id})
    write_case(args.root, case)

    out.step("compile", decision_class=derivation.decision_class,
             required_object=derivation.required_object)
    payload = {
        "scope_id": scope.scope_id,
        "decision_class": derivation.decision_class,
        "required_object": derivation.required_object,
        "rule_cited": derivation.rule_cited,
        "refusals": list(derivation.refusals),
        "retention_policy": scope.retention_policy,
        "query_hash": derivation.query_hash,
    }
    human = [
        f"compiled decision scope {scope.scope_id!r}",
        f"  decision class    : {derivation.decision_class}",
        f"  required object   : {derivation.required_object}",
        f"  retention policy  : {scope.retention_policy}",
        f"  rule cited        : {derivation.rule_cited}",
    ]
    for refusal in derivation.refusals:
        human.append(f"  REFUSED           : {refusal}")
    out.result(payload, "\n".join(human))
    return OK


# ---------------------------------------------------------------------------
# crg certify / regret
# ---------------------------------------------------------------------------
def _store_certificate(case: dict, certificate) -> dict:
    """Store a certificate with a hash that covers everything it ships with.

    The issuance time (45.2) is an assertion of the issuer and is part of the
    record, so it must be inside the hash preimage: a hash taken before the
    timestamp was attached would leave the timestamp unbound and freely
    editable.  The engine's own hash over the kernel's canonical form is kept
    alongside it so the two views stay traceable.
    """
    canonical = certificate.to_canonical()
    canonical["engine_certificate_hash"] = certificate.certificate_hash()
    canonical["issued_at"] = utc_now()
    canonical["issuer_clock_source"] = "issuer-system-clock"
    if not canonical.get("expiry") and (case.get("scope") or {}).get("validity"):
        canonical["expiry"] = case["scope"]["validity"]
    canonical["certificate_hash"] = content_hash(canonical)
    case.setdefault("certificates", {})[certificate.certificate_id] = canonical
    return canonical


def cmd_certify(args: argparse.Namespace, out: Emitter) -> int:
    crg_certify.set_default_geometry(crg_geometry)
    case = read_case(args.root, args.case)
    bundle = load_bundle(case)
    scope = load_scope(case)
    derivation = load_derivation(case)
    retained = [r.strip() for r in args.retained.split(",") if r.strip()] if args.retained else None

    certificate = crg_certify.certify(bundle, scope, derivation, retained=retained)
    canonical = _store_certificate(case, certificate)

    if retained is not None:
        r_full = crg_geometry.build_R(bundle)
        full_frontier = crg_geometry.build_gamma(r_full).frontier
        kept = [r for r in bundle.realizations if r.realization_id in set(retained)]
        if kept:
            retained_signatures = crg_geometry.pareto_minimal([r.signature for r in kept])
            geometry = dict(case.get("geometry") or {})
            geometry["full_frontier"] = _points(full_frontier)
            geometry["retained_frontier"] = _points(retained_signatures)
            case["geometry"] = geometry

    case["status"] = "CERTIFIED" if certificate.outcome in _AFFIRMATIVE else "BLOCKED"
    record_history(case, "certify", {"certificate_id": certificate.certificate_id,
                                     "outcome": certificate.outcome})
    write_case(args.root, case)

    out.step("certify", outcome=certificate.outcome, claim_scope=certificate.claim_scope)
    payload = {
        "certificate_id": certificate.certificate_id,
        "outcome": certificate.outcome,
        "claim_scope": certificate.claim_scope,
        "selected": list(certificate.selected),
        "ties": list(certificate.ties),
        "runner_up": certificate.runner_up,
        "certificate_hash": canonical["certificate_hash"],
        "affirmative": certificate.outcome in _AFFIRMATIVE,
    }
    out.result(payload, crg_certify.render_claim(certificate))
    return OK if certificate.outcome in _AFFIRMATIVE else VIOLATION


def cmd_regret(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    bundle = load_bundle(case)
    retained = {r.strip() for r in args.retained.split(",") if r.strip()}
    r_record = crg_geometry.build_R(bundle)
    full_frontier = crg_geometry.build_gamma(r_record).frontier
    kept = [r.signature for r in bundle.realizations if r.realization_id in retained]
    if not kept:
        raise CaseError("the retained set is empty; regret is unbounded, not a witness")
    retained_frontier = crg_geometry.pareto_minimal(kept)

    witness = crg_certify.build_regret_witness(full_frontier, retained_frontier, bundle.schema)
    geometry = dict(case.get("geometry") or {})
    geometry["full_frontier"] = _points(full_frontier)
    geometry["retained_frontier"] = _points(retained_frontier)
    case["geometry"] = geometry
    case["regret_witness"] = witness.to_canonical() if witness else None
    write_case(args.root, case)

    if witness is None:
        out.result(
            {"witness": None, "retention_lossless_for_this_generator": True},
            "no regret witness was constructed for this objective family.\n"
            "  27.5: a failed witness search does not prove the reduction was safe.",
        )
        return OK
    payload = {"witness": witness.to_canonical(), "gap": str(witness.gap)}
    out.result(
        payload,
        f"regret witness constructed\n"
        f"  lost point       : {[str(v) for v in witness.lost_point.values]}\n"
        f"  objective family : {witness.objective_family}\n"
        f"  full infimum     : {witness.full_infimum}\n"
        f"  retained infimum : {witness.retained_infimum}\n"
        f"  regret gap       : {witness.gap} > 0",
    )
    return VIOLATION  # a positive regret gap means the retention was unsafe


# ---------------------------------------------------------------------------
# crg change
# ---------------------------------------------------------------------------
def _case_objects(case: dict) -> Dict[str, Any]:
    """Project a case into the typed objects a change propagates through (18).

    The price vector is a *separate object* from the decision scope, not a
    field inside it.  That separation is what lets 30.2 distinguish a
    REPRICE from a REOPEN: if the weights lived inside the scope object, any
    tariff update would also read as a scope change and every reprice would
    escalate to a reopen, which is conservative but useless.
    """
    scope = dict(case.get("scope") or {})
    family = dict(scope.pop("objective_family", None) or {})
    weights = family.pop("weights", None)
    family.pop("weights_are_ranges", None)
    scope["objective_family"] = family
    return {
        "candidate-registry": {
            "object_kind": "CANDIDATE_REGISTRY",
            "registry": case.get("registry"),
        },
        "price-model": {"object_kind": "PRICE_MODEL", "price": {"weights": weights}},
        "decision-scope": {"object_kind": "DECISION_SCOPE", "scope": scope},
    }


def _case_view(case: dict) -> Dict[str, Any]:
    return {
        "objects": _case_objects(case),
        "certificates": dict(case.get("certificates") or {}),
    }


def _graph(certificate_ids: Sequence[str]) -> DependencyGraph:
    graph = DependencyGraph()
    for index, cert_id in enumerate(sorted(certificate_ids)):
        for source, edge_type in (
            ("price-model", EdgeType.DEPENDS_ON_PRICE_OF),
            ("candidate-registry", EdgeType.DEPENDS_ON_MEMBERSHIP_OF),
            ("decision-scope", EdgeType.DEPENDS_ON_SCOPE_OF),
        ):
            graph.add_edge(
                DependencyEdge(
                    edge_id=f"{source}->{cert_id}#{index}",
                    source=source,
                    target=cert_id,
                    edge_type=edge_type,
                )
            )
    return graph


def cmd_change(args: argparse.Namespace, out: Emitter) -> int:
    crg_certify.set_default_geometry(crg_geometry)
    case = read_case(args.root, args.case)
    if not case.get("certificates"):
        raise CaseError("nothing to change: this case has no certificate yet")
    prior = json.loads(canonical_json(case))
    prior_view = _case_view(prior)

    changed_object = "candidate-registry"
    changed_properties: List[str] = []
    if args.set:
        for assignment in args.set:
            target, _, value = assignment.partition("=")
            rid, _, coordinate = target.partition(".")
            registry = case["registry"]
            identifiers = [c["identifier"] for c in registry["schema"]["coordinates"]]
            if coordinate not in identifiers:
                raise CaseError(f"unknown coordinate {coordinate!r}")
            index = identifiers.index(coordinate)
            for realization in registry["realizations"]:
                if realization["realization_id"] == rid:
                    realization["signature"][index] = Exact(value).to_canonical()
                    break
            else:
                raise CaseError(f"unknown realization {rid!r}")
            changed_properties.append(f"registry.candidates.{rid}.{coordinate}")
    if args.weight:
        changed_object = "price-model"
        family = dict((case.get("scope") or {}).get("objective_family") or {})
        weights = dict(family.get("weights") or {})
        for assignment in args.weight:
            coordinate, _, value = assignment.partition("=")
            weights[coordinate] = [str(Exact(value)), str(Exact(value))]
            changed_properties.append(f"price.weights.{coordinate}")
        family["weights"] = weights
        family["weights_are_ranges"] = any(w[0] != w[1] for w in weights.values())
        case["scope"] = {**(case.get("scope") or {}), "objective_family": family}
    if not changed_properties:
        raise CaseError("declare what changed with --set or --weight")
    _normalize_registry(case)

    event = ChangeEvent(
        event_id=args.event_id or f"change-{len(case.get('history', []))}",
        changed_object=changed_object,
        previous_version=prior.get("status"),
        current_version=case.get("status", "REOPENED"),
        declared_reason=args.reason,
        changed_properties=tuple(changed_properties),
        timestamp=utc_now(),
        authority=args.authority,
    )

    bundle = load_bundle(case)
    scope = load_scope(case)
    derivation = load_derivation(case)

    def recompute(_case: Any, _plan: Any) -> List[dict]:
        certificate = crg_certify.certify(bundle, scope, derivation)
        return [_store_certificate(case, certificate)]

    current_view = _case_view(case)
    delta = apply_change(
        prior_view,
        current_view,
        event,
        _graph(sorted(case.get("certificates") or {})),
        recompute_fn=recompute,
        approvals=tuple(args.approve or ()),
    )
    canonical = delta.to_canonical()
    canonical["delta_hash"] = delta.delta_hash()
    case.setdefault("deltas", {})[delta.delta_id] = canonical
    # 30.3 step 6 / 17.1: an invalidated certificate is superseded, not
    # deleted.  It leaves the active set -- exporting it as a live claim
    # would let a stale winner keep circulating -- but stays in the case.
    superseded = case.setdefault("superseded_certificates", {})
    for cert_id in delta.invalidated:
        if cert_id in case.get("certificates", {}):
            stale = dict(case["certificates"].pop(cert_id))
            stale["status"] = "SUPERSEDED"
            stale["superseded_by"] = delta.delta_id
            superseded[cert_id] = stale
    case["status"] = "REOPENED" if delta.reopen_reason else "CERTIFIED"
    record_history(case, "change", {"delta_id": delta.delta_id,
                                    "classification": delta.classification})
    write_case(args.root, case)

    out.step("change", classification=delta.classification,
             invalidated=len(delta.invalidated), recomputed=len(delta.recomputed))
    payload = {
        "delta_id": delta.delta_id,
        "classification": delta.classification,
        "prior_root": delta.prior_root,
        "current_root": delta.current_root,
        "preserved": list(delta.preserved),
        "invalidated": list(delta.invalidated),
        "recomputed": list(delta.recomputed),
        "prior_winners": list(delta.prior_winners),
        "current_winners": list(delta.current_winners),
        "residual_uncertainty": delta.residual_uncertainty,
        "delta_hash": canonical["delta_hash"],
    }
    human = [
        f"delta certificate {delta.delta_id}",
        f"  classification    : {delta.classification}",
        f"  changed object    : {changed_object}",
        f"  changed properties: {', '.join(changed_properties)}",
        f"  preserved         : {list(delta.preserved)}",
        f"  invalidated       : {list(delta.invalidated)}",
        f"  recomputed        : {list(delta.recomputed)}",
        f"  winners  before   : {list(delta.prior_winners)}",
        f"  winners  after    : {list(delta.current_winners)}",
        f"  residual          : {delta.residual_uncertainty or 'none'}",
        f"  delta hash        : {canonical['delta_hash']}",
    ]
    out.result(payload, "\n".join(human))
    return OK


# ---------------------------------------------------------------------------
# crg export
# ---------------------------------------------------------------------------
def _vir_for(case: dict, certificate: dict) -> dict:
    geometry = case.get("geometry") or {}
    return crg_verify.emit_vir(
        certificate,
        {
            "full": geometry.get("full_frontier"),
            "retained": geometry.get("retained_frontier"),
        },
        case.get("registry"),
    )


def cmd_export(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    registry = case.get("registry")
    if not registry:
        raise CaseError("nothing to export: this case has no registry")
    certificates = dict(case.get("certificates") or {})
    output = args.output or os.path.join(args.root, f"{case['case_id']}.crg")

    objects: Dict[str, Any] = {}

    def _add(object_id: str, payload: Any) -> str:
        objects[object_id] = payload
        return content_hash(payload)

    registry_hash = _add(registry["bundle_id"], registry)
    for cert_id, certificate in sorted(certificates.items()):
        _add(cert_id, certificate)
    # Superseded certificates travel with the bundle as provenance (6.4,
    # 17.1) but carry no verification program: they are history, not claims.
    for cert_id, certificate in sorted((case.get("superseded_certificates") or {}).items()):
        _add(cert_id, certificate)
    for delta_id, delta in sorted((case.get("deltas") or {}).items()):
        _add(delta_id, delta)
    for name in ("R", "GAMMA", "K"):
        if name in (case.get("geometry") or {}):
            geometry = case["geometry"][name]
            _add(str(geometry.get("root_hash") or f"geometry-{name}"), geometry)
    migration_records: Dict[str, Mapping[str, Any]] = {}
    for record in list(case.get("migrations") or []) + list(case.get("migration_records") or []):
        if isinstance(record, Mapping) and record.get("migration_id"):
            migration_records[str(record["migration_id"])] = record
    if isinstance(case.get("migration_record"), Mapping):
        record = case["migration_record"]
        if record.get("migration_id"):
            migration_records[str(record["migration_id"])] = record
    for migration_id, record in sorted(migration_records.items()):
        _add(migration_id, record)

    programs: Dict[str, Dict[str, Any]] = {}
    reports: Dict[str, str] = {}
    for cert_id, certificate in sorted(certificates.items()):
        vir = _vir_for(case, certificate)
        programs[str(vir["program_id"])] = dict(vir)
        reports[cert_id] = render_certificate_report(certificate)

    manifest_hash = crg_io.write_bundle(
        output,
        case=case,
        objects=objects,
        verification_programs=programs,
        reports=reports,
        manifest_metadata={
            "crg_spec_version": "0.2.0",
            "schema_identities": [
                {"schema_id": "coordinate-schema",
                 "schema_hash": content_hash(registry["schema"]),
                 "schema_version": str(registry.get("schema_version", "0.2.0")),
                 "referenced_by": str(registry["bundle_id"])}
            ],
            "quantity_registry_version": "0.2.0",
            "rule_table_version": crg_certify.MAPPING_TABLE_VERSION,
            "signatures": [],
            "encryption": {
                "protected_content_present": False,
                "encrypted_objects": [],
                "claims_depending_on_protected_content": [],
                "verifier_capabilities_required": [],
                "independently_checkable": True,
            },
            "redaction_state": case.get("redaction_state", {"redacted_objects": []}),
            "export_authority": {
                "authority": args.authority or "unattested",
                "basis": "declared by the exporting caller" if args.authority
                else "no export authority was declared",
            },
            "requested_verification_level": args.level,
        },
    )

    payload = {
        "output": output,
        "objects": len(objects),
        "certificates": sorted(certificates),
        "registry_hash": registry_hash,
        "manifest_hash": manifest_hash,
    }
    out.result(
        payload,
        f"exported {output}\n  objects      : {len(objects)}\n"
        f"  certificates : {sorted(certificates)}\n"
        f"  manifest hash: {payload['manifest_hash']}",
    )
    return OK


# ---------------------------------------------------------------------------
# crg verify / report
# ---------------------------------------------------------------------------
def cmd_verify(args: argparse.Namespace, out: Emitter) -> int:
    clock = args.clock
    clock_source = args.clock_source
    if clock is None and args.use_local_clock:
        clock = _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds").replace(
            "+00:00", "Z"
        )
        clock_source = "verifier-local-system-clock"

    path = args.path
    federation_context = None
    federation_context_document = None
    if args.federation_context:
        with open(args.federation_context, encoding="utf-8") as handle:
            federation_context_document = json.load(handle)
        if not isinstance(federation_context_document, dict):
            raise CaseError("a federation verifier context must be a JSON object")
        federation_context = dict(federation_context_document)
        ledger = federation_context.get("nonce_ledger")
        if not isinstance(ledger, list) or any(not isinstance(item, str) for item in ledger):
            raise CaseError(
                "federation context nonce_ledger must be a JSON array of consumed nonce strings"
            )
        federation_context["nonce_ledger"] = set(ledger)
    if os.path.isdir(path) or zipfile.is_zipfile(path):
        result = crg_verify.verify_bundle(
            path, clock=clock, clock_source=clock_source, level=args.level,
            federation_context=federation_context,
        )
    else:
        with open(path, encoding="utf-8") as handle:
            document = json.load(handle)
        if "vir_version" in document:
            result = crg_verify.verify_vir(document, clock=clock, clock_source=clock_source)
        else:
            registry = None
            if args.registry:
                with open(args.registry, encoding="utf-8") as handle:
                    registry = json.load(handle)
            result = crg_verify.verify_certificate(
                document, registry=registry, clock=clock, clock_source=clock_source
            )

    # A successful V4 answer is replay-bound only if consuming its nonce is
    # durable across verifier processes.  Persist the caller-owned ledger by
    # atomic replacement before reporting success.
    if result.ok and args.level == "V4" and federation_context is not None:
        federation_context_document["nonce_ledger"] = sorted(
            federation_context["nonce_ledger"]
        )
        destination = os.path.abspath(args.federation_context)
        temporary = f"{destination}.tmp.{os.getpid()}"
        try:
            with open(temporary, "w", encoding="utf-8", newline="\n") as handle:
                handle.write(canonical_json(federation_context_document) + "\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, destination)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)

    for name, passed, detail in result.checks:
        out.step("check", check=name, passed=passed, detail=detail)
    out.result(result.to_json(), crg_verify.render_report(result))
    return OK if result.ok else VIOLATION


def cmd_report(args: argparse.Namespace, out: Emitter) -> int:
    # A case identifier is also a directory name, so the case is resolved
    # first; only a target that is not a case is read as a bundle.
    is_case = os.path.exists(os.path.join(args.root, args.target, "case.json"))
    if not is_case and (os.path.isdir(args.target) or zipfile.is_zipfile(args.target)):
        reader = crg_verify.bundle.open_bundle(args.target)
        try:
            names = [n for n in reader.names if n.startswith("reports/") and n.endswith(".md")]
            text = "\n\n".join(reader.read(n).decode("utf-8") for n in sorted(names))
        finally:
            reader.close()
        out.result({"target": args.target, "reports": len(text.splitlines())}, text)
        return OK

    case = read_case(args.root, args.target)
    certificates = case.get("certificates") or {}
    if not certificates:
        raise CaseError("this case carries no certificate to report on")
    cert_id = args.certificate or sorted(certificates)[-1]
    if cert_id not in certificates:
        raise CaseError(f"no certificate {cert_id!r} in this case")
    certificate = certificates[cert_id]
    verification = crg_verify.verify_vir(_vir_for(case, certificate))
    text = render_certificate_report(certificate, verification)
    out.result({"certificate_id": cert_id, "report": text, "verified": verification.ok}, text)
    return OK if verification.ok else VIOLATION


# ---------------------------------------------------------------------------
# crg conformance -- the Minimum Credible Loop, end to end (54.2, 54.4)
# ---------------------------------------------------------------------------
MCL_CSV = """realization_id,latency,energy,legality
p1,1,2,LEGAL
p2,2,3,LEGAL
p3,4,1,LEGAL
p4,3,3,LEGAL
"""

MCL_SCOPE = {
    "id": "package-choice",
    "objective_family": {"type": "weighted_sum", "weights": {"latency": 1, "energy": 1}},
    "quantification": "EACH_OBJECTIVE",
    "ties": {"policy_tolerance": 0},
}


def cmd_conformance(args: argparse.Namespace, out: Emitter) -> int:
    """Run the Minimum Credible Loop end to end in a scratch workspace."""
    steps: List[Dict[str, Any]] = []
    failures: List[str] = []
    with tempfile.TemporaryDirectory() as root:
        source = os.path.join(root, "candidates.csv")
        with open(source, "w", encoding="utf-8") as handle:
            handle.write(MCL_CSV)
        scope_path = os.path.join(root, "scope.json")
        with open(scope_path, "w", encoding="utf-8") as handle:
            json.dump(MCL_SCOPE, handle)
        bundle_path = os.path.join(root, "mcl.crg")

        plan = [
            ["init", "mcl"],
            ["import", "mcl", "--source", source,
             "--completeness", CompletenessBasisType.EXPLICIT_IMPORTED_FAMILY,
             "--universe", "the four declared packages"],
            ["geometry", "mcl", "--objects", "R,Gamma,K"],
            ["query", "compile", "mcl", "--scope", scope_path],
            ["certify", "mcl"],
            ["change", "mcl", "--set", "p1.latency=9", "--reason", "measurement update"],
            ["export", "mcl", "--output", bundle_path],
            ["verify", bundle_path, "--level", "V3"],
        ]
        for argv in plan:
            code = main(argv + ["--dir", root, "--quiet"])
            label = " ".join(a for a in argv if not a.startswith("/"))
            steps.append({"step": label, "expected_exit": OK, "exit_code": code})
            out.step("mcl", command=label, exit_code=code)
            if code != OK:
                failures.append(f"{label} exited {code}")

        # 54.4 step 9, and 6.6 at the process boundary: a tampered bundle
        # MUST NOT verify.  A nonzero exit is the pass condition here.
        tampered = os.path.join(root, "tampered.crg")
        _tamper(bundle_path, tampered)
        code = main(["verify", tampered, "--dir", root, "--quiet"])
        steps.append(
            {"step": "verify tampered bundle (must fail)", "expected_exit": VIOLATION,
             "exit_code": code}
        )
        out.step("mcl", command="verify tampered bundle", exit_code=code)
        if code == OK:
            failures.append("a tampered bundle verified; the loop is not fail-closed")

    payload = {"suite": "minimum-credible-loop", "steps": steps, "failures": failures,
               "ok": not failures}
    human = ["Minimum Credible Loop (spec 54.2)"]
    for step in steps:
        mark = "ok  " if step["exit_code"] == step["expected_exit"] else "FAIL"
        human.append(
            f"  [{mark}] {step['step']} "
            f"(exit {step['exit_code']}, expected {step['expected_exit']})"
        )
    human.append("")
    human.append("PASS" if not failures else "FAIL: " + "; ".join(failures))
    out.result(payload, "\n".join(human))
    return OK if not failures else VIOLATION


def _tamper(source: str, target: str) -> None:
    """Rewrite one object inside a bundle without repairing the manifest."""
    with zipfile.ZipFile(source) as archive:
        items = {name: archive.read(name) for name in archive.namelist()}
    for name, payload in list(items.items()):
        if name.startswith("objects/sha256/"):
            document = json.loads(payload.decode("utf-8"))
            if isinstance(document, dict) and document.get("realizations"):
                document["realizations"][0]["signature"][0] = {"exact": "0"}
                items[name] = canonical_json(document).encode("utf-8")
                break
    with zipfile.ZipFile(target, "w") as archive:
        for name, payload in items.items():
            archive.writestr(name, payload)


def _json_document(path: str, *, what: str) -> Any:
    """Read a required JSON document, refusing the 26.7 indentation form here."""
    document = read_query_document(path)
    if isinstance(document, str):
        raise CaseError(f"{what} must be a JSON document")
    return document


# ---------------------------------------------------------------------------
# crg generate -- build a registry from a generator pack (spec 28, 36.5)
# ---------------------------------------------------------------------------
def cmd_generate(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    spec = _json_document(args.spec, what="a generate spec")
    bundle, report = generate_registry(spec)

    case["registry"] = bundle.to_canonical()
    _normalize_registry(case)
    case["generation_report"] = report.to_canonical()
    case["status"] = "GENERATED"
    record_history(case, "generate",
                   {"pack": spec.get("pack"), "accepted": len(report.accepted)})
    write_case(args.root, case)

    basis = bundle.completeness
    out.step("generate", pack=spec.get("pack"), accepted=len(report.accepted),
             derived_basis=basis.basis_type)
    payload = {
        "case_id": case["case_id"],
        "pack": spec.get("pack"),
        "accepted": list(report.accepted),
        "rejected": report.rejected_count,
        "ungenerated_regions": len(report.ungenerated),
        "generators": list(report.generators),
        "derived_completeness_basis": basis.basis_type,
        "declared_universe": basis.declared_universe,
        "claim_scope": report.claim_scope,
        "registry_hash": content_hash(case["registry"]),
    }
    human = [
        f"generated {len(report.accepted)} realizations with pack {spec.get('pack')!r}",
        f"  generators         : {', '.join(report.generators) or 'none (imported seeds)'}",
        f"  rejected candidates: {report.rejected_count}",
        f"  ungenerated regions: {len(report.ungenerated)}",
        # 21.3/28.3 step 10: the basis is DERIVED from what generation did, not
        # declared by the caller; that is what makes it stronger than an import.
        f"  DERIVED completeness basis: {basis.basis_type}",
        f"  declared universe  : {basis.declared_universe}",
        f"  claim scope        : {report.claim_scope}",
        f"  registry hash      : {payload['registry_hash']}",
    ]
    for region in report.ungenerated:
        human.append(f"    ungenerated: {getattr(region, 'reason_code', region)}")
    out.result(payload, "\n".join(human))
    return OK


# ---------------------------------------------------------------------------
# crg reopen -- reopen certificates and emit a delta (spec 30.2 REOPEN)
# ---------------------------------------------------------------------------
def _graph_targeting(source: str, cert_ids: Sequence[str]) -> DependencyGraph:
    graph = DependencyGraph()
    for index, cert_id in enumerate(sorted(cert_ids)):
        graph.add_edge(DependencyEdge(
            edge_id=f"{source}->{cert_id}#{index}",
            source=source, target=cert_id, edge_type=EdgeType.DEPENDS_ON_SCOPE_OF))
    return graph


def cmd_reopen(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    active = dict(case.get("certificates") or {})
    if not active:
        raise CaseError("nothing to reopen: this case has no active certificate")
    targets = list(args.certificate) if args.certificate else sorted(active)
    unknown = [c for c in targets if c not in active]
    if unknown:
        raise CaseError(f"no such active certificate(s) to reopen: {', '.join(unknown)}")

    prior = json.loads(canonical_json(case))
    prior_view = _case_view(prior)
    changed_object = "decision-scope"  # 30.2: DECISION_SCOPE is decided by kind -> REOPEN
    event = ChangeEvent(
        event_id=args.event_id or f"reopen-{len(case.get('history', []))}",
        changed_object=changed_object,
        previous_version=case.get("status"),
        current_version="REOPENED",
        declared_reason=args.reason,
        changed_properties=(),
        timestamp=utc_now(),
        authority=args.authority,
    )
    current_view = _case_view(case)

    def recompute(_case: Any, _plan: Any) -> List[dict]:
        # A reopen invalidates; it does not silently manufacture a new winner.
        # The case is left REOPENED_PENDING_RECERTIFICATION until re-certified.
        return []

    delta = apply_change(
        prior_view, current_view, event,
        _graph_targeting(changed_object, targets),
        recompute_fn=recompute, approvals=tuple(args.approve or ()),
    )
    canonical = delta.to_canonical()
    canonical["delta_hash"] = delta.delta_hash()
    case.setdefault("deltas", {})[delta.delta_id] = canonical

    superseded = case.setdefault("superseded_certificates", {})
    for cert_id in delta.invalidated:
        if cert_id in case.get("certificates", {}):
            reopened = dict(case["certificates"].pop(cert_id))
            reopened["status"] = "REOPENED"
            reopened["reopened_by"] = delta.delta_id
            reopened["reopen_reason"] = args.reason
            superseded[cert_id] = reopened
    case["status"] = "REOPENED"
    record_history(case, "reopen",
                   {"delta_id": delta.delta_id, "reopened": list(delta.invalidated)})
    write_case(args.root, case)

    out.step("reopen", reopened=len(delta.invalidated),
             classification=delta.classification)
    payload = {
        "delta_id": delta.delta_id,
        "classification": delta.classification,
        "reopened": list(delta.invalidated),
        "preserved": list(delta.preserved),
        "reopen_reason": delta.reopen_reason,
        "declared_reason": args.reason,
        "residual_uncertainty": delta.residual_uncertainty,
        "delta_hash": canonical["delta_hash"],
    }
    human = [
        f"reopened {len(delta.invalidated)} certificate(s)",
        f"  reopened          : {list(delta.invalidated)}",
        f"  declared reason   : {args.reason}",
        f"  classification    : {delta.classification}",
        f"  why (30.2)        : {delta.reopen_reason}",
        f"  residual          : {delta.residual_uncertainty or 'none'}",
        f"  case status       : REOPENED (pending recertification)",
        f"  delta hash        : {canonical['delta_hash']}",
    ]
    out.result(payload, "\n".join(human))
    return OK


# ---------------------------------------------------------------------------
# crg convert -- ownership and layout conversion (spec 31)
# ---------------------------------------------------------------------------
def cmd_convert(args: argparse.Namespace, out: Emitter) -> int:
    record = layout_conversion(args.source, args.target)
    payload = {
        "record_id": record.record_id,
        "retained_fraction": str(record.retained_fraction),
        "moved_fraction": str(record.moved_fraction),
        "assignment": {str(k): v for k, v in sorted(record.assignment.items())},
        "source_cells": len(record.source_cells),
        "target_cells": len(record.target_cells),
        "ownership_contract": record.ownership_contract,
    }
    if args.case:
        case = read_case(args.root, args.case)
        case.setdefault("conversions", {})[record.record_id] = record.to_canonical()
        record_history(case, "convert",
                       {"record_id": record.record_id,
                        "retained": str(record.retained_fraction)})
        write_case(args.root, case)
        payload["case_id"] = case["case_id"]

    out.step("convert", retained=str(record.retained_fraction),
             moved=str(record.moved_fraction))
    human = [
        f"conversion {record.record_id}",
        f"  source cells      : {len(record.source_cells)}",
        f"  target cells      : {len(record.target_cells)}",
        f"  retained fraction : {record.retained_fraction}",
        f"  moved fraction    : {record.moved_fraction}",
        f"  ownership contract: {record.ownership_contract}",
    ]
    out.result(payload, "\n".join(human))
    return OK


# ---------------------------------------------------------------------------
# crg evidence add / crg technology assemble (spec 33)
# ---------------------------------------------------------------------------
def cmd_evidence_add(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    doc = _json_document(args.evidence, what="an evidence record")
    record = evidence_record(doc)
    stored = {
        "evidence_id": record.evidence_id,
        "record": record.to_canonical(),
        "fingerprint": record.fingerprint(),
        # Kept so `crg technology assemble` can rebuild the record exactly;
        # there is no from-canonical constructor, and re-deriving from the
        # source document is the honest round-trip (14.3).
        "source_document": doc,
    }
    case.setdefault("evidence", {})[record.evidence_id] = stored
    record_history(case, "evidence add", {"evidence_id": record.evidence_id})
    write_case(args.root, case)

    out.step("evidence", evidence_id=record.evidence_id,
             provenance=record.provenance.status())
    payload = {
        "case_id": case["case_id"],
        "evidence_id": record.evidence_id,
        "quantity": record.quantity,
        "unit": record.unit,
        "value": record.value.to_canonical(),
        "evidence_class": record.method.evidence_class,
        "evidence_status": record.evidence_status,
        "provenance_status": record.provenance.status(),
        "fingerprint": record.fingerprint(),
        "registered": sorted(case["evidence"]),
    }
    human = [
        f"registered evidence {record.evidence_id!r}",
        f"  quantity/unit     : {record.quantity} [{record.unit}]",
        f"  value enclosure   : [{record.value.lo}, {record.value.hi}]",
        f"  evidence class    : {record.method.evidence_class}",
        f"  evidence status   : {record.evidence_status}",
        f"  provenance        : {record.provenance.status()}",
        f"  fingerprint       : {record.fingerprint()}",
        f"  case now holds    : {len(case['evidence'])} evidence record(s)",
    ]
    out.result(payload, "\n".join(human))
    return OK


def cmd_technology_assemble(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    evidence_docs: List[dict] = [
        entry["source_document"]
        for entry in (case.get("evidence") or {}).values()
        if isinstance(entry, dict) and entry.get("source_document")
    ]
    if args.evidence:
        for path in args.evidence:
            extra = _json_document(path, what="an evidence document")
            evidence_docs.extend(extra if isinstance(extra, list) else [extra])
    if not evidence_docs:
        raise CaseError(
            "no evidence to assemble from: run `crg evidence add` first or pass --evidence")

    rules_raw = _json_document(args.rules, what="an applicability rules document")
    rules_docs = rules_raw.get("rules", rules_raw) if isinstance(rules_raw, dict) else rules_raw
    if not isinstance(rules_docs, list):
        rules_docs = [rules_docs]
    target_doc = _json_document(args.target, what="a target-context document")
    coordinate_docs = None
    if args.coordinates:
        coords_raw = _json_document(args.coordinates, what="a coordinate-request document")
        coordinate_docs = coords_raw.get("coordinates", coords_raw) \
            if isinstance(coords_raw, dict) else coords_raw
    clock_doc = {"evaluation_time": args.clock} if args.clock else None
    requester_doc = {"subject_id": args.requester} if args.requester else None

    contract, report = assemble_contract(
        evidence_docs, rules_docs, target_doc,
        clock_doc=clock_doc, requester_doc=requester_doc,
        coordinate_docs=coordinate_docs, contract_id=args.contract_id,
    )
    domain = contract.to_technology_domain()
    bounded = [c.coordinate_id for c in contract.bounded_coordinates]
    rejections = [
        {"reason_code": r.reason_code, "coordinate_id": r.coordinate_id,
         "evidence_id": r.evidence_id, "rule_id": r.rule_id, "detail": r.detail}
        for r in report.rejections
    ]
    summary = {
        "contract_id": args.contract_id,
        "verification_status": contract.verification_status,
        "bounded_coordinates": bounded,
        "technology_domain": domain,
        "rejections": rejections,
    }
    case.setdefault("technology_contracts", {})[args.contract_id] = summary
    record_history(case, "technology assemble",
                   {"contract_id": args.contract_id,
                    "status": contract.verification_status})
    write_case(args.root, case)

    out.step("assemble", status=contract.verification_status,
             bounded=len(bounded), rejected=len(rejections))
    payload = {
        "case_id": case["case_id"],
        **summary,
    }
    human = [
        f"assembled technology contract {args.contract_id!r}",
        f"  verification status: {contract.verification_status}",
        f"  bounded coordinates: {bounded or 'none'}",
    ]
    for coordinate_id in bounded:
        human.append(f"    + {coordinate_id}: {domain.get(coordinate_id)}")
    # 33.5/33.7: rejections are shown distinctly -- each carries its own reason
    # code and the coordinate/evidence it concerns, never a generic failure.
    human.append(f"  rejections ({len(rejections)}):")
    for rejection in rejections:
        where = rejection["coordinate_id"] or rejection["evidence_id"] or "-"
        human.append(f"    - {rejection['reason_code']} [{where}]: {rejection['detail']}")
    affirmative = contract.verification_status in ("VERIFIED", "TIME_INDETERMINATE")
    out.result(payload, "\n".join(human))
    return OK if affirmative else VIOLATION


# ---------------------------------------------------------------------------
# crg qualify -- inverse qualification plan (spec 34)
# ---------------------------------------------------------------------------
def cmd_qualify(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    doc = _json_document(args.spec, what="a qualify spec")
    plan, _objective, ranked = qualification_plan(doc)

    case.setdefault("qualification_plans", {})[plan.plan_id] = plan.to_canonical()
    record_history(case, "qualify",
                   {"plan_id": plan.plan_id, "experiments": len(ranked)})
    write_case(args.root, case)

    ranking = [
        {"rank": r.rank, "experiment_id": r.experiment_id, "tier": r.tier_name,
         "score": (str(r.score) if r.score is not None else None),
         "ambiguity_reduction": str(r.ambiguity_reduction)}
        for r in ranked
    ]
    stopping = [
        {"condition": s.condition,
         "threshold": (str(s.threshold) if s.threshold is not None else None),
         "metric": s.metric}
        for s in plan.stopping_rules
    ]
    out.step("qualify", plan=plan.plan_id, experiments=len(ranking))
    payload = {
        "case_id": case["case_id"],
        "plan_id": plan.plan_id,
        "ranking": ranking,
        "sequence": list(plan.sequence),
        "stopping_rules": stopping,
        "measurable_targets": [t.target_id for t in plan.measurable_targets],
        "residual_ambiguity": str(plan.residual_ambiguity),
        "residual_metric": plan.residual_metric,
    }
    human = [f"qualification plan {plan.plan_id!r}", "  experiment ranking (34.4):"]
    for entry in ranking:
        human.append(
            f"    {entry['rank']}. {entry['experiment_id']} [{entry['tier']}] "
            f"score={entry['score']} reduction={entry['ambiguity_reduction']}")
    human.append(f"  run sequence      : {' -> '.join(plan.sequence) or 'none'}")
    human.append("  stopping rule (34.5):")
    for rule in stopping:
        detail = f" threshold={rule['threshold']} metric={rule['metric']}" \
            if rule["threshold"] else ""
        human.append(f"    - {rule['condition']}{detail}")
    human.append(f"  residual ambiguity: {plan.residual_ambiguity} ({plan.residual_metric})")
    out.result(payload, "\n".join(human))
    return OK


# ---------------------------------------------------------------------------
# crg evaluate -- submit an evaluator request / register a witness (spec 32)
# ---------------------------------------------------------------------------
def cmd_evaluate(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    bundle = load_bundle(case)
    request_doc = _json_document(args.request, what="an evaluator request")
    response_doc = _json_document(args.response, what="an evaluator response")

    response, witness, update, signoff = run_evaluation(request_doc, response_doc, bundle)

    # register_witness / apply_feasibility mutate the realization record in the
    # bundle; persist the updated registry so the evidence class survives.
    case["registry"] = bundle.to_canonical()
    _normalize_registry(case)
    if witness is not None:
        case.setdefault("witnesses", {})[witness.witness_id] = witness.to_canonical()
    if update is not None:
        case.setdefault("feasibility_updates", []).append(update.to_canonical())
    record_history(case, "evaluate",
                   {"kind": response.kind, "signoff": signoff})
    write_case(args.root, case)

    determinate = witness is not None or (update is not None and update.marks_infeasible)
    out.step("evaluate", kind=response.kind, signoff=signoff,
             determinate=determinate)
    payload = {
        "case_id": case["case_id"],
        "response_kind": response.kind,
        "evidence_class": response.evidence_class,
        "signoff_status": signoff,
        "feasibility_effect": None if update is None else update.effect,
        "witness_id": None if witness is None else witness.witness_id,
        "physical_signoff": bool(witness is not None and witness.physical_signoff),
        "determinate": determinate,
        "detail": response.detail,
    }
    human = [
        f"evaluator response: {response.kind}",
        f"  evidence class    : {response.evidence_class or 'none (a failure carries none)'}",
        f"  signoff status    : {signoff}",
    ]
    if witness is not None:
        human.append(f"  witness registered: {witness.witness_id}")
        human.append(f"  physical signoff  : {witness.physical_signoff}")
    if update is not None:
        human.append(f"  feasibility effect: {update.effect}")
        # 32.1: a tool failure is an absence of knowledge, never infeasibility.
        if not update.marks_infeasible:
            human.append("  NOTE: nothing determinative was recorded; a tool failure is not "
                         "physical infeasibility (spec 32.1)")
    if response.detail:
        human.append(f"  detail            : {response.detail}")
    out.result(payload, "\n".join(human))
    return OK if determinate else VIOLATION


# ---------------------------------------------------------------------------
# crg branch / merge -- branching and merge policy (spec 16)
# ---------------------------------------------------------------------------
def cmd_branch(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    for field_name, value in (("--name", args.name), ("--purpose", args.purpose),
                              ("--creator", args.creator)):
        if not value:
            raise CaseError(f"a branch must declare {field_name} (spec 16.2)")
    branch_case_id = f"{args.case}@{args.name}"
    if os.path.exists(os.path.join(case_dir(args.root, branch_case_id), "case.json")):
        raise CaseError(f"branch {args.name!r} of {args.case!r} already exists")

    parent_hash = content_hash(case)
    child = json.loads(canonical_json(case))
    child["case_id"] = branch_case_id
    child["branch_id"] = args.name
    child["status"] = "BRANCHED"
    inherited = dict(case.get("certificates") or {})
    child["certificates"] = {}  # 16.5: parent certificates do not travel
    child["inherited_certificates"] = {
        cert_id: {**dict(cert), "status": "HISTORICAL_EVIDENCE",
                  "reuse_condition": "16.5: reusable only after dependency-aware revalidation"}
        for cert_id, cert in inherited.items()
    }
    record = {
        "record_type": "BranchRecord",
        "branch_id": args.name,
        "case_id": branch_case_id,
        "parent_case": args.case,
        "parent_version": int(case.get("case_version") or 1),
        "parent_content_hash": parent_hash,
        "branch_point": parent_hash,
        "purpose": args.purpose,
        "creator": args.creator,
        "access_policy": args.access_policy or "inherited",
        "intended_decision_scope": args.scope
        or (case.get("scope") or {}).get("scope_id") or "undeclared",
        "expected_reconciliation": args.reconciliation,
        "created_at": utc_now(),
    }
    child["branch_record"] = record
    child.setdefault("history", []).append(
        {"command": "branch", "from": args.case, "at": record["created_at"]})
    write_case(args.root, child)

    out.step("branch", branch=branch_case_id, inherited=len(inherited))
    payload = {
        "branch_case_id": branch_case_id,
        "parent_case": args.case,
        "branch_point": parent_hash,
        "inherited_certificates": sorted(inherited),
        "active_certificates": [],
    }
    human = [
        f"branched {args.case!r} -> {branch_case_id!r}",
        f"  purpose           : {args.purpose}",
        f"  creator           : {args.creator}",
        f"  branch point      : {parent_hash}",
        f"  active certificates: none (16.5: parent certificates do not travel)",
        f"  inherited (history): {sorted(inherited) or 'none'}",
    ]
    out.result(payload, "\n".join(human))
    return OK


#: Section 16.3, verbatim: the semantic objects CRG SHALL NOT auto-merge, keyed
#: by the case field that carries each in this store.
_SEMANTIC_OBJECTS: Dict[str, str] = {
    "contract": "computation contracts",
    "resource_contract": "resource contracts",
    "legality": "legality rules",
    "registry": "realization registries",
    "scope": "decision queries",
    "derivation": "decision queries",
    "certificates": "certificates",
    "evidence": "evidence",
    "technology_contract": "technology contracts",
    "technology_contracts": "technology contracts",
    "applicability_rules": "applicability rules",
}


def cmd_merge(args: argparse.Namespace, out: Emitter) -> int:
    source = read_case(args.root, args.source)
    target = read_case(args.root, args.target)
    conflicts = [
        f"{field_name} ({description})"
        for field_name, description in sorted(_SEMANTIC_OBJECTS.items())
        if canonical_json(source.get(field_name)) != canonical_json(target.get(field_name))
    ]

    if conflicts:
        decision = "REFUSED_SEMANTIC"
        automatic = False
        required_actions = [
            "create a new case version", "record a MergeDecisionRecord",
            "record explicit conflict resolutions", "record a dependency diff",
            "record a change classification", "invalidate affected certificates",
            "re-verify or reissue preserved claims",
        ]
        rationale = ("16.3: CRG SHALL NOT automatically merge semantic objects; "
                     f"{len(conflicts)} semantic object(s) differ")
    else:
        decision = "NO_DIFFERENCE"
        automatic = True
        required_actions = []
        rationale = "no semantic object differs between these cases"

    record = {
        "record_type": "MergeDecisionRecord",
        "decision": decision,
        "automatic": automatic,
        "source_case": args.source,
        "target_case": args.target,
        "semantic_conflicts": conflicts,
        "required_actions": required_actions,
        "rationale": rationale,
        "recorded_at": utc_now(),
    }
    target.setdefault("merge_decisions", []).append(record)
    record_history(target, "merge", {"decision": decision, "source": args.source})
    write_case(args.root, target)

    out.step("merge", decision=decision, conflicts=len(conflicts))
    human = [
        f"merge {args.source!r} -> {args.target!r}: {decision}",
        f"  automatic         : {automatic}",
        f"  rationale         : {rationale}",
    ]
    for conflict in conflicts:
        human.append(f"  conflict          : {conflict}")
    for action in required_actions:
        human.append(f"  required (16.4)   : {action}")
    out.result(record, "\n".join(human))
    # Fail closed: a refused semantic merge did not happen, so it must not read
    # as success at the process boundary (6.6).
    return OK if automatic else VIOLATION


# ---------------------------------------------------------------------------
# crg migrate -- schema migration (spec 15)
# ---------------------------------------------------------------------------
def cmd_migrate(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    declared_class = args.migration_class.upper() if args.migration_class else None
    new_case_id = args.new_case or f"{args.case}@{args.to_version}"
    if os.path.exists(os.path.join(case_dir(args.root, new_case_id), "case.json")):
        raise CaseError(f"a case named {new_case_id!r} already exists")

    from_version = case.get("schema_version", "0.2.0")
    try:
        execution = DEFAULT_MIGRATION_REGISTRY.execute(
            case,
            args.to_version,
            transform_id=args.transform_id,
            declared_class=declared_class,
        )
    except MigrationError as error:
        raise CaseError(
            f"{error}. Install or select a pinned transform with independently checkable "
            "classification evidence first (15.3-15.6)."
        ) from None
    migration_class = execution.transform.migration_class
    source_hash = execution.source_object_hash
    # 15.3: migration creates a NEW object and MUST NOT rewrite history.
    migrated = dict(execution.transformed)
    migrated["case_id"] = new_case_id
    migrated["schema_version"] = args.to_version

    active = dict(migrated.get("certificates") or {})
    verified_noop = (
        migration_class == "SEMANTICALLY_EQUIVALENT"
        and execution.source_object_hash == execution.transformed_object_hash
    )
    effective_class = migration_class
    if verified_noop:
        # 15.5: a re-verification record MAY be produced without reissuing the
        # substantive decision.  Even a no-op remains pending until the
        # verifier records the judgment; it is never an active inherited cert.
        migrated["pending_reverification"] = {
            cert_id: {**dict(cert), "status": "RE_VERIFICATION_PENDING",
                      "original_schema_version": from_version}
            for cert_id, cert in active.items()
        }
        migrated["certificates"] = {}
        disposition = {cert_id: "RE_VERIFICATION_PENDING" for cert_id in active}
        migrated["status"] = "REOPENED" if active else case.get("status")
    else:
        # 15.5: a widening/narrowing/semantic/lossy/unverified migration MUST
        # trigger revalidation; a migrated object MUST NOT inherit a prior
        # certificate merely because its fields look similar.
        migrated["certificates"] = {}
        superseded = dict(migrated.get("superseded_certificates") or {})
        for cert_id, cert in active.items():
            superseded[cert_id] = {**dict(cert), "status": "SUPERSEDED_BY_MIGRATION",
                                   "migration_class": effective_class}
        migrated["superseded_certificates"] = superseded
        migrated["status"] = "REOPENED" if active else migrated.get("status")
        disposition = {cert_id: "INVALIDATED_REQUIRES_REVALIDATION" for cert_id in active}

    target_object_hash = content_hash(migrated)
    record = {
        "record_type": "MigrationRecord",
        "migration_id": f"migration-{new_case_id}",
        "source_case": args.case,
        "target_case": new_case_id,
        "source_schema_version": from_version,
        "target_schema_version": args.to_version,
        "source_object_hash": source_hash,
        "target_object_hash": target_object_hash,
        "declared_migration_class": declared_class or "",
        "migration_class": effective_class,
        "migration_profile": execution.transform.transform_id,
        **execution.evidence(),
        "declared_reason": args.reason,
        "certificate_disposition": disposition,
        "created_new_object": new_case_id,
        "migrated_at": utc_now(),
        "actor": args.actor,
        "actor_authentication": "LOCAL_PROCESS_UNATTESTED",
        "authority": args.authority,
    }
    migrated["migration_record"] = record
    migrated.setdefault("migrations", []).append(record)
    migrated.setdefault("history", []).append(
        {"command": "migrate", "from": args.case, "class": effective_class})
    write_case(args.root, migrated)

    out.step("migrate", to=new_case_id, migration_class=effective_class)
    payload = {
        "source_case": args.case,
        "new_case_id": new_case_id,
        "from_version": from_version,
        "to_version": args.to_version,
        "declared_migration_class": declared_class or "",
        "migration_class": effective_class,
        "transform_id": execution.transform.transform_id,
        "transform_hash": execution.transform.transform_hash,
        "classification_proof_hash": execution.transform.classification_proof_hash,
        "classification_verified": True,
        "certificate_disposition": disposition,
        "source_content_hash": source_hash,
    }
    human = [
        f"migrated {args.case!r} -> {new_case_id!r} (original untouched, 15.3)",
        f"  version           : {from_version} -> {args.to_version}",
        f"  declared class    : {declared_class or '(none; registry selected)'}",
        f"  effective class   : {effective_class}",
        f"  registered path   : {execution.transform.transform_id}",
        f"  classification    : VERIFIED ({execution.transform.classification_proof_hash})",
        f"  certificate handling:",
    ]
    for cert_id, state in sorted(disposition.items()):
        human.append(f"    {cert_id}: {state}")
    if not disposition:
        human.append("    (no certificates to migrate)")
    out.result(payload, "\n".join(human))
    return OK


# ---------------------------------------------------------------------------
# crg legal-hold -- persistent legal-hold policy (spec 17.5)
# ---------------------------------------------------------------------------
def cmd_legal_hold(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    held = set(str(value) for value in (case.get("legal_holds") or []))
    if args.action == "add":
        held.add(args.object)
        event = "LEGAL_HOLD_APPLIED"
    else:
        held.discard(args.object)
        event = "LEGAL_HOLD_RELEASED"
    case["legal_holds"] = sorted(held)
    record = {
        "record_type": "LegalHoldRecord",
        "case_id": args.case,
        "object_id": args.object,
        "action": event,
        "authority": args.authority,
        "recorded_at": utc_now(),
    }
    case.setdefault("legal_hold_history", []).append(record)
    record_history(case, "legal-hold", {"object": args.object, "action": event})
    write_case(args.root, case)
    out.step("legal-hold", object=args.object, action=event)
    out.result({**record, "active_holds": sorted(held)},
               f"{event.lower().replace('_', ' ')} for {args.object!r}")
    return OK


# ---------------------------------------------------------------------------
# crg redact -- redaction, tombstones, certificate effect (spec 17)
# ---------------------------------------------------------------------------
def cmd_redact(args: argparse.Namespace, out: Emitter) -> int:
    case = read_case(args.root, args.case)
    obj = args.object
    held = set(case.get("legal_holds") or [])
    if obj in held or args.legal_hold:
        # 17.5: an object under legal hold MUST NOT be deleted or erased.
        raise CaseError(
            f"{obj!r} is under legal hold and MUST NOT be redacted until the hold is released "
            "by authorized policy (spec 17.5)")

    registry = case.get("registry") or {}
    certificates = case.get("certificates") or {}
    affected_certificates: List[str] = []
    if obj in ("registry", registry.get("bundle_id")):
        content = case.get("registry")
        if not content:
            raise CaseError("there is no registry to redact")
        object_type = "RealizationBundle"
        content_digest = content_hash(content)
        case["registry"] = None
        # 17.3: every certificate rests on the registry; redacting it makes each
        # one UNVERIFIABLE_REDACTED.  The system MUST NOT report them as valid.
        affected_certificates = list(certificates)
    elif obj in certificates:
        content = certificates[obj]
        object_type = "DecisionCertificate"
        content_digest = content_hash(content)
        affected_certificates = [obj]
    else:
        raise CaseError(
            f"no redactable object {obj!r}; name 'registry' or a certificate id "
            f"(this case has: {sorted(certificates) or 'none'})")

    dependency_edges = []
    if object_type == "RealizationBundle":
        for cert_id in sorted(affected_certificates):
            certificate = certificates[cert_id]
            target_hash = str(certificate.get("certificate_hash") or content_hash(certificate))
            dependency_edges.append({
                "edge_id": f"{content_digest}->{target_hash}#DEPENDS_ON_ACCESS",
                "source": content_digest,
                "target": target_hash,
                "edge_type": "DEPENDS_ON_ACCESS",
                "minimum_action": "BLOCK",
                "transitive": True,
                "edge_version": "1",
                "scope": cert_id,
            })
    tombstone = {
        "record_type": "TombstoneRecord",
        "object_id": obj,
        "content_hash": content_digest,
        "object_type": object_type,
        "removal_reason": args.reason,
        "removal_authority": args.authority,
        "removal_time": utc_now(),
        "legal_hold": False,
        "permitted_disclosure": args.disclosure or "identity and hash only",
        "dependency_edges": dependency_edges,
        "affected_certificates": sorted(affected_certificates),
    }
    case.setdefault("tombstones", {})[obj] = tombstone

    redacted = case.setdefault("redacted_certificates", {})
    for cert_id in affected_certificates:
        cert = dict(certificates.get(cert_id, {}))
        cert["status"] = "UNVERIFIABLE_REDACTED"
        cert["redacted_by"] = obj
        redacted[cert_id] = cert
        case.get("certificates", {}).pop(cert_id, None)
    record_history(case, "redact", {"object": obj, "affected": affected_certificates})
    write_case(args.root, case)

    out.step("redact", object=obj, unverifiable=len(affected_certificates))
    payload = {
        "case_id": case["case_id"],
        "tombstone": tombstone,
        "unverifiable_redacted_certificates": affected_certificates,
    }
    human = [
        f"redacted {obj!r} ({object_type})",
        f"  content hash      : {content_digest}",
        f"  removal reason    : {args.reason}",
        f"  removal authority : {args.authority}",
        f"  certificates now UNVERIFIABLE_REDACTED (17.3): "
        f"{affected_certificates or 'none'}",
    ]
    out.result(payload, "\n".join(human))
    return OK


# ---------------------------------------------------------------------------
# argument parsing
# ---------------------------------------------------------------------------
def _add_global_options(parser: argparse.ArgumentParser, *, suppress: bool) -> None:
    """Attach the output-mode options of specification 40.

    They are accepted both before and after the subcommand, because a caller
    scripting the loop should not have to remember which side of the verb a
    flag lives on.  Subparser copies default to ``SUPPRESS`` so that a value
    given before the verb is not silently overwritten after it.
    """
    kwargs = {"default": argparse.SUPPRESS} if suppress else {}
    parser.add_argument("--dir", dest="root",
                        help="workspace root holding case directories",
                        **(kwargs if suppress else {"default": os.getcwd()}))
    parser.add_argument("--json", dest="as_json", action="store_true",
                        help="emit canonical JSON", **(kwargs if suppress else {"default": False}))
    parser.add_argument("--stream", action="store_true",
                        help="emit machine-streaming JSON Lines",
                        **(kwargs if suppress else {"default": False}))
    parser.add_argument("--quiet", action="store_true",
                        help="emit nothing; communicate through the exit code only",
                        **(kwargs if suppress else {"default": False}))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="crg",
        description="CRG Systems headless command line (spec 40)",
    )
    parser.add_argument("--version", action="version", version=f"crg {VERSION} (spec 0.2.0)")
    _add_global_options(parser, suppress=False)
    common = argparse.ArgumentParser(add_help=False)
    _add_global_options(common, suppress=True)
    subparsers = parser.add_subparsers(dest="command", parser_class=argparse.ArgumentParser)

    def add(name: str, **kwargs: Any) -> argparse.ArgumentParser:
        return subparsers.add_parser(name, parents=[common], **kwargs)

    p = add("init", help="create a case")
    p.add_argument("case")
    p.add_argument("--contract", help="computation contract document")
    p.set_defaults(handler=cmd_init)

    p = add("import", help="import a tabular realization registry")
    p.add_argument("case")
    p.add_argument("--source", required=True)
    p.add_argument("--mapping", help="JSON registry mapping")
    p.add_argument("--completeness", default=CompletenessBasisType.EXPLICIT_IMPORTED_FAMILY,
                   choices=sorted(CompletenessBasisType.ALL),
                   help="declared completeness basis type (spec 21.2)")
    p.add_argument("--universe", default="the explicitly imported candidates")
    p.set_defaults(handler=cmd_import)

    p = add("validate", help="structurally validate a case")
    p.add_argument("case")
    p.set_defaults(handler=cmd_validate)

    p = add("inspect", help="show case state, hashes, and claims")
    p.add_argument("case")
    p.set_defaults(handler=cmd_inspect)

    p = add("geometry", help="build canonical R, Gamma, and K")
    p.add_argument("case")
    p.add_argument("--objects", default="R,Gamma,K")
    p.set_defaults(handler=cmd_geometry)

    query = add("query", help="decision-query operations")
    query_sub = query.add_subparsers(dest="query_command")
    p = query_sub.add_parser("compile", parents=[common], help="compile a decision scope to its minimum object")
    p.add_argument("case")
    p.add_argument("--scope", required=True)
    p.set_defaults(handler=cmd_query_compile)
    query.set_defaults(handler=_require_subcommand(query))

    p = add("certify", help="issue a decision certificate")
    p.add_argument("case")
    p.add_argument("--retained", help="comma-separated retained realization identifiers")
    p.set_defaults(handler=cmd_certify)

    p = add("regret", help="construct a regret witness for a retention")
    p.add_argument("case")
    p.add_argument("--retained", required=True)
    p.set_defaults(handler=cmd_regret)

    p = add("change", help="apply a change and emit a delta certificate")
    p.add_argument("case")
    p.add_argument("--set", action="append", metavar="ID.COORD=VALUE")
    p.add_argument("--weight", action="append", metavar="COORD=VALUE")
    p.add_argument("--reason", required=True)
    p.add_argument("--event-id", dest="event_id")
    p.add_argument("--authority")
    p.add_argument("--approve", action="append")
    p.set_defaults(handler=cmd_change)

    p = add("export", help="write a portable .crg bundle")
    p.add_argument("case")
    p.add_argument("--output")
    p.add_argument("--level", default="V3", choices=["V0", "V1", "V2", "V3", "V4"])
    p.add_argument("--authority")
    p.set_defaults(handler=cmd_export)

    p = add("verify", help="independently verify a bundle, VIR, or certificate")
    p.add_argument("path")
    p.add_argument("--level", default="V3", choices=["V0", "V1", "V2", "V3", "V4"])
    p.add_argument("--clock", help="verifier evaluation time, ISO 8601 (spec 45.3)")
    p.add_argument("--clock-source", dest="clock_source", default="none-supplied")
    p.add_argument("--use-local-clock", dest="use_local_clock", action="store_true",
                   help="evaluate time against this machine's clock and disclose it")
    p.add_argument("--registry", help="registry JSON for a bare certificate")
    p.add_argument(
        "--federation-context",
        help=("verifier-owned V4 trust context JSON; its nonce_ledger is atomically "
              "updated after acceptance"),
    )
    p.set_defaults(handler=cmd_verify)

    p = add("report", help="render the canonical certificate report")
    p.add_argument("target", help="case identifier or .crg path")
    p.add_argument("--certificate")
    p.set_defaults(handler=cmd_report)

    p = add("generate", help="build a registry from a generator pack (spec 28, 36.5)")
    p.add_argument("case")
    p.add_argument("--spec", required=True, help="JSON generator/pack request")
    p.set_defaults(handler=cmd_generate)

    p = add("reopen", help="reopen certificates and emit a delta (spec 30.2)")
    p.add_argument("case")
    p.add_argument("--reason", required=True, help="why the case is being reopened")
    p.add_argument("--certificate", action="append",
                   help="a certificate to reopen (repeatable; default: all active)")
    p.add_argument("--event-id", dest="event_id")
    p.add_argument("--authority")
    p.add_argument("--approve", action="append")
    p.set_defaults(handler=cmd_reopen)

    p = add("convert", help="minimum-movement layout conversion (spec 31)")
    p.add_argument("case", nargs="?", help="optional case to record the conversion into")
    p.add_argument("--from", dest="source", required=True,
                   metavar="LAYOUT", help="source layout: a division count or a measures list")
    p.add_argument("--to", dest="target", required=True,
                   metavar="LAYOUT", help="target layout: a division count or a measures list")
    p.set_defaults(handler=cmd_convert)

    evidence = add("evidence", help="evidence-record operations (spec 33)")
    evidence_sub = evidence.add_subparsers(dest="evidence_command")
    p = evidence_sub.add_parser("add", parents=[common],
                                help="register an evidence record")
    p.add_argument("case")
    p.add_argument("--evidence", required=True, help="JSON evidence-record document")
    p.set_defaults(handler=cmd_evidence_add)
    evidence.set_defaults(handler=_require_subcommand(evidence))

    technology = add("technology", help="technology-contract operations (spec 33.6)")
    technology_sub = technology.add_subparsers(dest="technology_command")
    p = technology_sub.add_parser("assemble", parents=[common],
                                  help="assemble a technology contract from evidence")
    p.add_argument("case")
    p.add_argument("--rules", required=True, help="JSON applicability-rules document")
    p.add_argument("--target", required=True, help="JSON target-context document")
    p.add_argument("--evidence", action="append",
                   help="extra JSON evidence document(s) beyond those already added")
    p.add_argument("--coordinates", help="JSON coordinate-request document")
    p.add_argument("--clock", help="verifier evaluation time, ISO 8601 (spec 45.3)")
    p.add_argument("--requester", help="requesting subject id")
    p.add_argument("--contract-id", dest="contract_id", default="technology-contract")
    p.set_defaults(handler=cmd_technology_assemble)
    technology.set_defaults(handler=_require_subcommand(technology))

    p = add("qualify", help="build an inverse-qualification plan (spec 34)")
    p.add_argument("case")
    p.add_argument("--spec", required=True, help="JSON qualification request")
    p.set_defaults(handler=cmd_qualify)

    p = add("evaluate", help="submit an evaluator request / register a witness (spec 32)")
    p.add_argument("case")
    p.add_argument("--request", required=True, help="JSON evaluator-request document")
    p.add_argument("--response", required=True, help="JSON evaluator-response document")
    p.set_defaults(handler=cmd_evaluate)

    p = add("branch", help="branch a case (spec 16.2)")
    p.add_argument("case")
    p.add_argument("--name", required=True, help="branch name")
    p.add_argument("--purpose", help="why this divergence exists (spec 16.2)")
    p.add_argument("--creator", help="who created the branch (spec 16.2)")
    p.add_argument("--scope", help="intended decision scope")
    p.add_argument("--access-policy", dest="access_policy")
    p.add_argument("--reconciliation", default="MANUAL_RECONCILIATION",
                   help="expected reconciliation behaviour")
    p.set_defaults(handler=cmd_branch)

    p = add("merge", help="apply the section 16.3 merge policy")
    p.add_argument("source", help="source case identifier")
    p.add_argument("target", help="target case identifier")
    p.set_defaults(handler=cmd_merge)

    p = add("migrate", help="migrate a case to a new schema version (spec 15)")
    p.add_argument("case")
    p.add_argument("--to-version", dest="to_version", required=True)
    p.add_argument("--class", dest="migration_class",
                   help=("optional assertion; the registered transform owns the class (15.4): "
                         + ", ".join(MIGRATION_CLASSES)))
    p.add_argument("--transform", dest="transform_id",
                   help="registered transform identifier; inferred only for an unambiguous path")
    p.add_argument("--reason", help="declared reason for the migration")
    p.add_argument("--new-case", dest="new_case", help="identifier for the migrated case")
    p.add_argument("--actor", default="local-cli",
                   help="local process actor recorded for provenance (not authenticated)")
    p.add_argument("--authority", default="unattested",
                   help="named migration authority, kept distinct from the process actor")
    p.set_defaults(handler=cmd_migrate)

    p = add("redact", help="redact an object and tombstone it (spec 17)")
    p.add_argument("case")
    p.add_argument("--object", required=True,
                   help="'registry' or a certificate id to redact")
    p.add_argument("--reason", required=True)
    p.add_argument("--authority", required=True)
    p.add_argument("--legal-hold", dest="legal_hold", action="store_true",
                   help="assert the object is under legal hold (17.5: redaction is refused)")
    p.add_argument("--disclosure", help="permitted disclosure on the tombstone")
    p.set_defaults(handler=cmd_redact)

    p = add("legal-hold", help="apply or release a persistent legal hold (spec 17.5)")
    p.add_argument("case")
    p.add_argument("action", choices=["add", "release"])
    p.add_argument("--object", required=True)
    p.add_argument("--authority", required=True)
    p.set_defaults(handler=cmd_legal_hold)

    p = add("conformance", help="run the Minimum Credible Loop end to end")
    p.add_argument("--suite", default="mcl", choices=["mcl"])
    p.set_defaults(handler=cmd_conformance)

    return parser


def _require_subcommand(parser: argparse.ArgumentParser):
    def handler(_args: argparse.Namespace, out: Emitter) -> int:
        out.error(f"{parser.prog} requires a subcommand")
        return USAGE
    return handler


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(list(argv) if argv is not None else None)
    out = _emitter(args)
    if not getattr(args, "handler", None):
        parser.print_help(sys.stderr)
        return USAGE
    try:
        return args.handler(args, out)
    except CaseError as error:
        out.error(str(error))
        return USAGE
    except FileNotFoundError as error:
        out.error(str(error))
        return USAGE
    except (crg_certify.QueryError, crg_certify.CertifyError, crg_certify.RegretError) as error:
        out.error(str(error))
        return VIOLATION
    except (ValueError, TypeError, KeyError) as error:
        out.error(f"{type(error).__name__}: {error}")
        return VIOLATION


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
