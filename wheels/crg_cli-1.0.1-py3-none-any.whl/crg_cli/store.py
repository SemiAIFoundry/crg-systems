"""Case persistence and canonical-form rehydration for the CRG CLI.

Normative basis: 6.2 (portable state), 11 (``CRGCase``), 39 (portable
``.crg`` artifact).

The case on disk is canonical JSON and nothing else: no pickles, no
database, no server.  6.2 requires the complete state to be exportable and
re-importable without a running service, so the store round-trips through
the same canonical forms the hashes are taken over.

``crg-io`` owns this responsibility in the finished product.  If it is
importable its reader and writer are used; otherwise this module provides
the same behaviour locally, so the Minimum Credible Loop can run today.
"""
from __future__ import annotations

import json
import os
import tempfile
from typing import Any, List, Optional, Sequence, Tuple

from crg_model.canonical import canonical_json, content_hash
from crg_model.case import new_case_record, refresh_case_metadata
from crg_model.completeness import CompletenessBasis, CompletenessBasisType
from crg_model.numeric import Exact
from crg_model.records import (
    Coordinate,
    CoordinateSchema,
    DecisionScope,
    DerivationRecord,
    Direction,
    RealizationBundle,
    RealizationRecord,
    Signature,
)

try:  # pragma: no cover - crg-io may still be landing
    import crg_io as _crg_io
except ImportError:  # pragma: no cover
    _crg_io = None

__all__ = [
    "CaseError",
    "CASE_FILE",
    "case_dir",
    "new_case",
    "read_case",
    "write_case",
    "load_bundle",
    "load_scope",
    "load_derivation",
    "import_table",
    "read_query_document",
    "signature_json",
    "IO_BACKEND",
]

CASE_FILE = "case.json"
IO_BACKEND = "crg_io" if _crg_io is not None else "crg_cli.store (local fallback)"


class CaseError(RuntimeError):
    """The case on disk is absent, malformed, or not far enough along."""


# ---------------------------------------------------------------------------
# case files
# ---------------------------------------------------------------------------
def case_dir(root: str, case_id: str) -> str:
    return os.path.join(root, case_id)


def new_case(case_id: str, contract: Optional[dict] = None) -> dict:
    return new_case_record(case_id, contract, created_by="crg-cli")


def read_case(root: str, case_id: str) -> dict:
    path = os.path.join(case_dir(root, case_id), CASE_FILE)
    if not os.path.exists(path):
        raise CaseError(f"no case {case_id!r} under {root!r}; run `crg init {case_id}` first")
    if _crg_io is not None and hasattr(_crg_io, "read_case"):  # pragma: no cover
        return _crg_io.read_case(path)
    with open(path, encoding="utf-8") as handle:
        return json.load(handle)


def write_case(root: str, case: dict) -> str:
    refresh_case_metadata(case)
    directory = case_dir(root, case["case_id"])
    os.makedirs(directory, exist_ok=True)
    path = os.path.join(directory, CASE_FILE)
    if os.path.exists(path):
        with open(path, encoding="utf-8") as handle:
            prior = json.load(handle)
        if canonical_json(prior) == canonical_json(case):
            return path
        prior_hash = content_hash(prior)
        versions = os.path.join(directory, "versions")
        os.makedirs(versions, exist_ok=True)
        archive = os.path.join(
            versions,
            f"{int(prior.get('case_version') or 1):08d}-{prior_hash.split(':', 1)[1]}.json",
        )
        if not os.path.exists(archive):
            _atomic_write(archive, canonical_json(prior).encode("utf-8"))
        case["case_version"] = int(prior.get("case_version") or 1) + 1
        parents = list(case.get("parent_case_refs") or [])
        reference = {
            "case_id": str(prior.get("case_id")),
            "case_version": int(prior.get("case_version") or 1),
            "content_hash": prior_hash,
        }
        if reference not in parents:
            parents.append(reference)
        case["parent_case_refs"] = parents
        refresh_case_metadata(case)
    _atomic_write(path, canonical_json(case).encode("utf-8"))
    return path


def _atomic_write(path: str, payload: bytes) -> None:
    descriptor, temporary = tempfile.mkstemp(
        prefix=".crg-case-", suffix=".tmp", dir=os.path.dirname(path)
    )
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
        directory = os.open(os.path.dirname(path), os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    except Exception:
        if os.path.exists(temporary):
            os.unlink(temporary)
        raise


def record_history(case: dict, command: str, detail: dict) -> None:
    """Append to the immutable-by-convention case history (spec 6.4, 11.2)."""
    case.setdefault("history", []).append({"command": command, **detail})


# ---------------------------------------------------------------------------
# canonical <-> kernel objects
# ---------------------------------------------------------------------------
def signature_json(signature: Sequence[Any]) -> List[dict]:
    return [Exact(v).to_canonical() if not isinstance(v, dict) else v for v in signature]


def _schema_from_json(payload: dict) -> CoordinateSchema:
    return CoordinateSchema(
        coordinates=tuple(
            Coordinate(
                identifier=str(c["identifier"]),
                quantity=str(c.get("quantity", c["identifier"])),
                unit=str(c.get("unit", "1")),
                direction=str(c.get("direction", Direction.MINIMIZE)),
                accounting_scope=c.get("accounting_scope"),
            )
            for c in payload.get("coordinates", [])
        ),
        technology_context=payload.get("technology_context"),
    )


def _exact_of(value: Any) -> Exact:
    if isinstance(value, dict) and "exact" in value:
        return Exact(value["exact"])
    return Exact(value)


def load_bundle(case: dict) -> RealizationBundle:
    registry = case.get("registry")
    if not registry:
        raise CaseError("this case has no registry; run `crg import` first")
    schema = _schema_from_json(registry["schema"])
    completeness = CompletenessBasis(
        basis_type=registry["completeness"]["basis_type"],
        declared_universe=registry["completeness"].get("declared_universe", "unspecified"),
        source_or_generator_hash=registry["completeness"].get("source_or_generator_hash"),
        closure_procedure=registry["completeness"].get("closure_procedure"),
        remainder_bound=registry["completeness"].get("remainder_bound"),
        truncation_rule=registry["completeness"].get("truncation_rule"),
        known_omissions=tuple(registry["completeness"].get("known_omissions", ())),
    )
    return RealizationBundle(
        bundle_id=registry["bundle_id"],
        schema=schema,
        realizations=[
            RealizationRecord(
                realization_id=str(r["realization_id"]),
                signature=Signature([_exact_of(v) for v in r["signature"]]),
                attributes=dict(r.get("attributes") or {}),
                legality=str(r.get("legality", "UNEVALUATED")),
                evidence_class=str(r.get("evidence_class", "IMPORTED")),
            )
            for r in registry.get("realizations", [])
        ],
        completeness=completeness,
        rejected=list(registry.get("rejected") or []),
        source_fingerprint=registry.get("source_fingerprint"),
    )


def load_scope(case: dict) -> DecisionScope:
    payload = case.get("scope")
    if not payload:
        raise CaseError("this case has no compiled decision scope; run `crg query compile` first")
    return DecisionScope(
        scope_id=payload["scope_id"],
        observation_level=payload["observation_level"],
        objective_family=payload["objective_family"],
        technology_domain=payload.get("technology_domain") or {},
        tie_tolerance=_exact_of(payload.get("tie_tolerance", 0)),
        retain_all_ties=bool(payload.get("retain_all_ties", True)),
        retention_policy=payload.get("retention_policy", "universal-monotone"),
        uncertainty_mode=payload.get("uncertainty_mode", "exact"),
        validity=payload.get("validity"),
    )


def load_derivation(case: dict) -> DerivationRecord:
    payload = case.get("derivation")
    if not payload:
        raise CaseError("this case has no derivation record; run `crg query compile` first")
    return DerivationRecord(
        query_hash=payload["query_hash"],
        mapping_table_version=payload["mapping_table_version"],
        decision_class=payload["decision_class"],
        required_object=payload["required_object"],
        rule_cited=payload["rule_cited"],
        refusals=tuple(payload.get("refusals", ())),
        notes=tuple(payload.get("notes", ())),
    )


# ---------------------------------------------------------------------------
# generic tabular registry import (spec 37, 54.3)
# ---------------------------------------------------------------------------
def _looks_exact(value: str) -> bool:
    try:
        if _crg_io is None:
            Exact(value)
        else:
            _crg_io.parse_exact(value)
    except (TypeError, ValueError, ZeroDivisionError):
        return False
    return True


def import_table(
    source: str,
    mapping: Optional[dict] = None,
    *,
    basis_type: str = CompletenessBasisType.EXPLICIT_IMPORTED_FAMILY,
    declared_universe: str = "the explicitly imported candidates",
    bundle_id: Optional[str] = None,
) -> Tuple[dict, dict]:
    """Import through the single exact, fail-closed ``crg-io`` profile.

    This compatibility wrapper retains the CLI/server report shape while all
    parsing, exactness, orientation, evidence, rejection, and completeness
    semantics are owned by ``crg-io``.  There is intentionally no local JSON
    numeric fallback: a bare JSON float is refused by the same rule everywhere.
    """
    if _crg_io is None:  # pragma: no cover - packaged crg-cli requires crg-io
        raise CaseError("crg-io is required for Registry Import Profile operations")
    mapping = mapping or {}
    suffix = os.path.splitext(source)[1].lower()
    with open(source, "rb") as handle:
        raw = handle.read()
    fingerprint = _crg_io.file_fingerprint(raw)

    document: Any = None
    if suffix == ".json":
        try:
            document = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise CaseError(f"{source!r} is not valid UTF-8 JSON: {exc}") from exc
    declared_schema = document.get("schema") if isinstance(document, dict) else None
    schema_spec = mapping.get("schema") or declared_schema
    schema = _schema_from_json(schema_spec) if schema_spec else None

    # An import cannot prove exhaustiveness merely because the file ended.
    # A stronger basis is accepted only when the mapping carries the proof or
    # bound fields required by section 21.3.
    try:
        completeness = CompletenessBasis(
            basis_type=basis_type,
            declared_universe=declared_universe,
            source_or_generator_hash=fingerprint,
            closure_procedure=(
                str(mapping.get("closure_procedure"))
                if mapping.get("closure_procedure")
                else f"registry import of {os.path.basename(source)}"
            ),
            closure_proof=mapping.get("closure_proof"),
            truncation_rule=mapping.get("truncation_rule"),
            remainder_bound=mapping.get("remainder_bound"),
            known_omissions=tuple(mapping.get("known_omissions") or ()),
        )
        # Invoke crg-io's normative stronger-claim checks before dispatch.
        from crg_io.import_profile import _check_completeness
        _check_completeness(completeness)
    except (TypeError, ValueError, _crg_io.ImportProfileError) as exc:
        raise CaseError(str(exc)) from exc

    kwargs: dict = {"completeness": completeness}
    id_column = mapping.get("id_column")
    coordinate_columns: Any = None
    attribute_columns = list(mapping.get("attributes") or ())

    if suffix in {".csv", ".tsv", ".tab"}:
        # Preserve the first-run inference convenience while handing the
        # resulting declared schema to the normative importer.
        import csv as _csv
        delimiter = "\t" if suffix in {".tsv", ".tab"} else ","
        rows = list(_csv.DictReader(raw.decode("utf-8-sig").splitlines(), delimiter=delimiter))
        if not rows:
            raise CaseError(f"{source!r} contains no rows")
        columns = list(rows[0])
        if id_column is None:
            id_column = next((c for c in ("realization_id", "candidate_id", "id", "name", "candidate") if c in columns), None)
        if id_column is None:
            raise CaseError(f"{source!r} has no identifier column; declare mapping.id_column")
        for conventional in ("legality", "feasibility", "feasibility_status", "evidence_class"):
            if conventional in columns and conventional not in attribute_columns:
                attribute_columns.append(conventional)
        if schema is None:
            coordinate_columns = [
                column for column in columns
                if column != id_column and column not in attribute_columns
                and _looks_exact(str(rows[0].get(column, "")))
            ]
            schema = _crg_io.infer_schema(source, coordinate_columns=coordinate_columns)
        else:
            coordinate_columns = {
                str(c.get("column", c["identifier"])): str(c["identifier"])
                for c in schema_spec["coordinates"]
            }
        kwargs.update(schema=schema, id_column=id_column,
                      coordinate_columns=coordinate_columns,
                      attribute_columns=attribute_columns)
    elif suffix in {".xlsx", ".parquet", ".pq"}:
        if schema is None:
            raise CaseError(f"{suffix} imports require mapping.schema with declared coordinates")
        id_column = id_column or "realization_id"
        coordinate_columns = {
            str(c.get("column", c["identifier"])): str(c["identifier"])
            for c in schema_spec["coordinates"]
        }
        kwargs.update(schema=schema, id_column=id_column,
                      coordinate_columns=coordinate_columns,
                      attribute_columns=attribute_columns)
        if suffix == ".xlsx" and mapping.get("sheet_name"):
            kwargs["sheet_name"] = str(mapping["sheet_name"])
    elif suffix == ".json" and schema is not None:
        kwargs["schema"] = schema

    try:
        imported_bundle, full_report = _crg_io.import_registry(
            source, format_name=mapping.get("format"), **kwargs
        )
    except _crg_io.ImportProfileError as exc:
        raise CaseError(str(exc)) from exc

    if bundle_id:
        imported_bundle.bundle_id = bundle_id
        full_report.bundle_id = bundle_id
        full_report.canonical_output_hash = imported_bundle.bundle_hash()
    registry = imported_bundle.to_canonical()
    rejections = []
    for rejected in full_report.rejected:
        item = rejected.to_dict()
        item["row"] = item.pop("row_number")
        if "realization_id" in item:
            item["id"] = item["realization_id"]
        rejections.append(item)
    coordinates = list(imported_bundle.schema.identifiers)
    report = {
        "source": os.path.basename(source),
        "source_fingerprint": full_report.source_fingerprint,
        "importer": {"id": full_report.importer_id, "version": full_report.importer_version},
        "rows_read": full_report.rows_read,
        "accepted": full_report.accepted_count,
        "rejected": full_report.rejected_count,
        "rejections": rejections,
        "identifier_column": id_column or full_report.identity_policy,
        "coordinates": coordinates,
        "completeness_basis": imported_bundle.completeness.basis_type,
        "declared_universe": imported_bundle.completeness.declared_universe,
        "canonical_output_hash": full_report.canonical_output_hash,
        "full_import_report": full_report.to_canonical(),
    }
    return registry, report


def read_query_document(path: str) -> Any:
    """Read a decision-scope document: JSON, or the 26.7 indentation form."""
    with open(path, encoding="utf-8") as handle:
        text = handle.read()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return text
