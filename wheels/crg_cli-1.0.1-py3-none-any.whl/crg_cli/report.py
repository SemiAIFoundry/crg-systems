"""The canonical human-readable certificate report (spec 50).

50.3 permits implementations to vary typography, language, and format; it
forbids hiding or reordering the claim scope, completeness basis,
uncertainty, or verification status.  So the section list below is fixed
and every section is emitted, even when it is empty -- "not stated" is a
finding, and omitting the line would hide it.

This renderer lives in the CLI rather than in ``crg-verify`` because 50.2
binds conforming *renderers*.  A renderer is presentation, and the
verification zone of 9.1 is deliberately kept to checking.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

__all__ = ["render_certificate_report", "CERTIFICATE_SECTIONS"]

#: Specification 50.2, mandatory order.
CERTIFICATE_SECTIONS = (
    "Claim",
    "Claim scope",
    "Completeness basis",
    "Decision semantics",
    "Required retained object",
    "Selected, tied, or possible-winner realizations",
    "Runner-up and margin",
    "Numerical enclosure",
    "Evidence uncertainty",
    "Policy tolerance",
    "Geometry basis",
    "Retained and pruned alternatives",
    "Regret witness",
    "Evidence classes and lineage",
    "Solver trust profile",
    "Verification level",
    "Dependencies",
    "Validity and clock judgment",
    "Reopen conditions",
    "Signatures",
    "Limitations",
)


def _text(value: Any) -> str:
    return "not stated" if value in (None, (), [], {}) else str(value)


def render_certificate_report(cert: Dict[str, Any], verification: Optional[Any] = None) -> str:
    """Render a decision certificate in the mandatory order of 50.2."""
    scope = cert.get("scope") or {}
    objective = scope.get("objective_family") or {}
    derivation = cert.get("derivation") or {}
    completeness = cert.get("completeness") or {}
    witness = cert.get("regret_witness")
    values = cert.get("objective_values") or {}
    verified = verification.report if verification is not None else {}

    body: Dict[str, Any] = {
        "Claim": f"{cert.get('outcome')} for decision scope {scope.get('scope_id')!r}",
        "Claim scope": cert.get("claim_scope"),
        "Completeness basis": f"{completeness.get('basis_type')} over "
                              f"{completeness.get('declared_universe')!r}",
        "Decision semantics": f"objective family {objective.get('type')!r}, quantification "
                              f"{objective.get('quantification', 'EACH_OBJECTIVE')}, "
                              f"uncertainty {scope.get('uncertainty_mode')}",
        "Required retained object": f"{derivation.get('required_object')} via "
                                    f"{derivation.get('rule_cited')}",
        "Selected, tied, or possible-winner realizations":
            f"selected={list(cert.get('selected') or [])}, ties={list(cert.get('ties') or [])}",
        "Runner-up and margin": f"runner-up={cert.get('runner_up')}, "
                                f"margin={cert.get('margin')}",
        "Numerical enclosure": {k: v.get("numerical_interval")
                                for k, v in values.items() if isinstance(v, dict)},
        "Evidence uncertainty": {k: v.get("evidence_interval") for k, v in values.items()
                                 if isinstance(v, dict) and v.get("evidence_interval")}
                                or "no evidence interval declared",
        "Policy tolerance": scope.get("tie_tolerance"),
        "Geometry basis": f"complete registry {cert.get('complete_registry_hash')}, retained "
                          f"{cert.get('retained_registry_hash')}, geometry preserved="
                          f"{cert.get('geometry_preserved')}",
        "Retained and pruned alternatives":
            f"{len(values)} retained; pruning certificates: "
            f"{len(cert.get('pruning_certificates') or [])}",
        "Regret witness": (f"gap {witness.get('gap')} in family "
                           f"{witness.get('objective_family')}") if witness else "none",
        "Evidence classes and lineage": cert.get("evidence_roots"),
        "Solver trust profile": sorted({str(v.get("solver_trust_profile"))
                                        for v in values.values() if isinstance(v, dict)})
                                or "not stated",
        "Verification level": verified.get("level_achieved") or "not verified in this run",
        "Dependencies": cert.get("dependencies"),
        "Validity and clock judgment": verified.get("time_judgment")
                                       or f"expiry {cert.get('expiry')} "
                                          "(issuer asserted; unverified)",
        "Reopen conditions": cert.get("reopen_conditions"),
        "Signatures": cert.get("signatures") or "unsigned",
        "Limitations": cert.get("limitations") or list(derivation.get("refusals") or [])
                       or "none recorded",
    }

    lines: List[str] = ["CRG DECISION CERTIFICATE REPORT", "=" * 31, ""]
    for index, section in enumerate(CERTIFICATE_SECTIONS, start=1):
        lines += [f"{index}. {section}", f"   {_text(body.get(section))}", ""]
    if verification is not None:
        lines.append(f"VERIFICATION STATUS: {verification.status}")
    return "\n".join(lines)
