"""
A generated Python client for the CRG headless integration surface (specification 38).

GENERATED FILE.  DO NOT EDIT BY HAND.

Generator      : crg_server.sdkgen
OpenAPI        : 3.1.0
API version    : 1.3.0
Specification  : CRG Operational Systems Master Specification v0.2.0, section 38
Operations     : 91

Regenerate with:  python3 -m crg_server.sdkgen
Edits made here are lost on the next run and, worse, make the
client disagree with the server it was generated from (6.12).

Standard library only.  One method per operationId, path templating from
the OpenAPI path templates, documented query parameters as keyword
arguments, declared Idempotency-Key support (38.4), X-CRG-Actor and
X-CRG-Correlation-Id on every request (44.7, 38.5), typed refusals (6.6),
a job-polling helper (38.3), and a Server-Sent Events reader (38.2).
"""
from __future__ import annotations

import base64
import json
import re
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Callable, Dict, Iterable, Iterator, List, Mapping, Optional, Tuple

__all__ = [
    "CrgError",
    "CrgApiError",
    "CrgBlocked",
    "CrgConflict",
    "CrgForbidden",
    "CrgNotFound",
    "CrgRedacted",
    "CrgUnauthorized",
    "SseEvent",
    "CrgClient",
    "parse_sse",
    "urllib_transport",
    "urllib_stream_transport",
    "OPERATIONS",
]


class CrgError(Exception):
    """Anything this client refuses to do, or could not do."""


class CrgApiError(CrgError):
    """A refusal the server described (6.6, 38.3).

    The server's ``category``, ``status``, and ``remedy`` are kept as fields
    rather than flattened into the message, because the remedy is frequently
    the only text that says which rule refused.
    """

    def __init__(self, status, body, operation=""):
        error = ((body or {}).get("error") if isinstance(body, Mapping) else None) or {}
        message = error.get("message") or "request refused with status %s" % status
        super().__init__(message)
        self.status = int(status)
        self.category = error.get("category", "unknown")
        self.remedy = error.get("remedy", "")
        self.detail = error.get("detail")
        self.body = body
        self.operation = operation


class CrgUnauthorized(CrgApiError):
    """401: no actor identity was presented (44.2)."""


class CrgForbidden(CrgApiError):
    """403: the actor holds no role authorizing this operation (44.3)."""


class CrgNotFound(CrgApiError):
    """404: no object of that identity exists here."""


class CrgConflict(CrgApiError):
    """409: stale version, idempotency-key reuse, legal hold, or a job with no result."""


class CrgRedacted(CrgApiError):
    """410: the content was removed and a tombstone remains (17.2)."""


class CrgBlocked(CrgApiError):
    """422: a scope mismatch or a blocked outcome.

    Its own class on purpose.  6.6 forbids reporting a refusal behind a 2xx,
    and the corresponding client-side rule is that a refusal must not be
    caught by the same ``except`` clause that retries a timeout.
    """


_ERROR_CLASSES = {
    401: CrgUnauthorized,
    403: CrgForbidden,
    404: CrgNotFound,
    409: CrgConflict,
    410: CrgRedacted,
    422: CrgBlocked,
}


def _raise_for(status, body, operation):
    raise _ERROR_CLASSES.get(int(status), CrgApiError)(status, body, operation)


class SseEvent(object):
    """One record of a Server-Sent Events stream (38.2, 38.5)."""

    __slots__ = ("id", "event", "data", "raw")

    def __init__(self, identifier, name, data, raw):
        self.id = identifier
        self.event = name
        self.data = data
        self.raw = raw

    def __repr__(self):
        return "SseEvent(id=%r, event=%r)" % (self.id, self.event)


def parse_sse(chunks):
    """Turn framed SSE bytes into :class:`SseEvent` values.

    Records are separated by a blank line and a record may arrive split
    across chunk boundaries, so the buffer is carried between chunks.  A
    record whose first character is a colon is a comment -- the keepalive --
    and is skipped rather than surfaced, because a subscriber counting
    events must not count heartbeats.
    """
    buffer = ""
    for chunk in chunks:
        if isinstance(chunk, bytes):
            chunk = chunk.decode("utf-8")
        buffer += chunk
        while "\n\n" in buffer:
            record, buffer = buffer.split("\n\n", 1)
            parsed = _parse_sse_record(record)
            if parsed is not None:
                yield parsed
    if buffer.strip():
        parsed = _parse_sse_record(buffer)
        if parsed is not None:
            yield parsed


def _parse_sse_record(record):
    identifier = None
    name = "message"
    data_lines = []
    saw_data = False
    for line in record.split("\n"):
        if not line or line.startswith(":"):
            continue
        field, _, value = line.partition(":")
        if value.startswith(" "):
            value = value[1:]
        if field == "id":
            identifier = value
        elif field == "event":
            name = value
        elif field == "data":
            data_lines.append(value)
            saw_data = True
    if not saw_data:
        return None
    text = "\n".join(data_lines)
    try:
        data = json.loads(text)
    except ValueError:
        data = text
    return SseEvent(identifier, name, data, record)


def urllib_transport(method, url, headers, body, timeout=30.0):
    """The default transport: ``(status, headers, bytes)`` over urllib."""
    request = urllib.request.Request(url, data=body, headers=dict(headers), method=method)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return int(response.status), dict(response.headers), response.read()
    except urllib.error.HTTPError as error:
        return int(error.code), dict(error.headers or {}), error.read() or b""


def urllib_stream_transport(method, url, headers, timeout=None):
    """The default streaming transport: an iterator of byte chunks (38.2).

    ``timeout=None`` on purpose.  An event stream is *supposed* to be quiet
    between events; a read timeout would turn a working subscription into a
    reconnect loop, which is exactly the failure mode the keepalive comment
    and ``Last-Event-ID`` exist to make unnecessary.
    """
    request = urllib.request.Request(url, headers=dict(headers), method=method)
    response = urllib.request.urlopen(request, timeout=timeout)
    try:
        while True:
            chunk = response.read1(4096) if hasattr(response, "read1") else response.read(4096)
            if not chunk:
                return
            yield chunk
    finally:
        response.close()


class CrgClient(object):
    """A generated client for the CRG headless integration surface (38).

    ``transport`` and ``stream_transport`` are injectable: the default pair
    speaks HTTP, and a caller may substitute anything with the same shape --
    an in-process callable that hands the request straight to
    ``Application.dispatch``, for instance, which is how this client is
    tested without a socket.
    """

    def __init__(
        self,
        base_url="http://127.0.0.1:8000",
        actor="",
        correlation_id=None,
        authorization=None,
        transport=None,
        stream_transport=None,
        timeout=30.0,
    ):
        self.base_url = str(base_url).rstrip("/")
        self.actor = str(actor or "")
        self.correlation_id = correlation_id
        self.authorization = str(authorization or "")
        self.timeout = timeout
        self._transport = transport or (
            lambda method, url, headers, body: urllib_transport(
                method, url, headers, body, timeout
            )
        )
        self._stream_transport = stream_transport

    def set_bearer_token(self, token):
        """Authenticate subsequent calls with an OAuth/OIDC bearer token."""
        value = str(token or "").strip()
        if not value:
            raise CrgError("a bearer token must be nonempty")
        self.authorization = "Bearer " + value
        return self

    def set_api_key(self, key_id, secret):
        """Authenticate subsequent calls with a CRG service identity."""
        identifier = str(key_id or "").strip()
        material = str(secret or "")
        if not identifier or not material:
            raise CrgError("an API key requires both key_id and secret")
        self.authorization = "ApiKey " + identifier + "." + material
        return self

    def set_basic_auth(self, username, password):
        """Authenticate subsequent calls with a TLS-protected local account."""
        user = str(username or "")
        password = str(password or "")
        if not user or ":" in user or not password:
            raise CrgError("basic authentication requires a nonempty colon-free username and password")
        raw = (user + ":" + password).encode("utf-8")
        self.authorization = "Basic " + base64.b64encode(raw).decode("ascii")
        return self

    def clear_authentication(self):
        """Remove the configured credential from subsequent calls."""
        self.authorization = ""
        return self

    # -- request plumbing --------------------------------------------------
    def _expand(self, template, params):
        def replace(match):
            name = match.group(1)
            value = params.get(name)
            if value is None or value == "":
                raise CrgError(
                    "the path parameter %r is required by %s" % (name, template)
                )
            return urllib.parse.quote(str(value), safe="")

        return re.sub(r"\{([^}]+)\}", replace, template)

    @staticmethod
    def _query(values):
        return {k: str(v) for k, v in sorted(values.items()) if v is not None}

    def _headers(self, actor, correlation_id, idempotency_key=None, extra=None):
        headers = {"Accept": "application/json"}
        if self.authorization:
            headers["Authorization"] = self.authorization
        chosen_actor = self.actor if actor is None else actor
        if chosen_actor:
            headers["X-CRG-Actor"] = str(chosen_actor)
        chosen_correlation = (
            self.correlation_id if correlation_id is None else correlation_id
        )
        if chosen_correlation:
            headers["X-CRG-Correlation-Id"] = str(chosen_correlation)
        if idempotency_key:
            headers["Idempotency-Key"] = str(idempotency_key)
        for key, value in sorted((extra or {}).items()):
            if value is not None:
                headers[key] = str(value)
        return headers

    def _url(self, path, query):
        url = self.base_url + path
        if query:
            url += "?" + urllib.parse.urlencode(query)
        return url

    def _request(
        self,
        method,
        path,
        query=None,
        body=None,
        idempotency_key=None,
        actor=None,
        correlation_id=None,
        raw=False,
        operation="",
    ):
        headers = self._headers(actor, correlation_id, idempotency_key)
        payload = None
        if body is not None:
            payload = json.dumps(body, sort_keys=True, separators=(",", ":")).encode("utf-8")
            headers["Content-Type"] = "application/json"
        status, response_headers, data = self._transport(
            method, self._url(path, query or {}), headers, payload
        )
        if raw:
            if status >= 400:
                _raise_for(status, _maybe_json(data), operation)
            return data
        decoded = _maybe_json(data)
        if status >= 400:
            _raise_for(status, decoded, operation)
        return decoded

    def _stream(
        self, path, query=None, last_event_id=None, actor=None, correlation_id=None
    ):
        """Open a Server-Sent Events subscription and yield parsed records."""
        extra = {"Accept": "text/event-stream"}
        if last_event_id is not None:
            extra["Last-Event-ID"] = str(last_event_id)
        headers = self._headers(actor, correlation_id, None, extra)
        url = self._url(path, query or {})
        if self._stream_transport is not None:
            chunks = self._stream_transport("GET", url, headers)
        else:
            status, _headers, data = self._transport("GET", url, headers, None)
            if status >= 400:
                _raise_for(status, _maybe_json(data), "stream")
            chunks = [data]
        for record in parse_sse(chunks):
            yield record

    # -- the asynchronous contract of 38.3 ---------------------------------
    def wait_for_job(self, job_id, attempts=1000, on_wait=None):
        """Poll ``GET /jobs/{job_id}/result`` until the job stops running.

        Raises :class:`CrgBlocked` for a blocked outcome and
        :class:`CrgConflict` for a failed or cancelled job, because that is
        what the server returns and flattening either into ``None`` would
        reintroduce the ambiguity 6.6 removed.
        """
        for _ in range(int(attempts)):
            result = self.getJobResult(job_id)
            if str(result.get("status")) not in ("QUEUED", "RUNNING"):
                return result
            if on_wait is not None:
                on_wait()
        raise CrgError("job %s did not reach a terminal status in %s polls" % (job_id, attempts))

    @staticmethod
    def encode_bundle(data):
        """Base64 a ``.crg`` archive for the bundle endpoints of 39."""
        return base64.b64encode(bytes(data)).decode("ascii")

    # -- the generated method per operationId of the document --------------

    def exportAudit(self, *, after_sequence=None, limit=None, authority=None, traceparent=None, actor=None, correlation_id=None):
        """GET /audit/export -- Export a bounded tenant security-audit artifact.

        Specification 42.3, 44.5, 44.7.
        Refuses with: 400, 401, 403, 503 (6.6).
        """
        return self._request(
            "GET",
            self._expand("/audit/export", {}),
            query=self._query({"after_sequence": after_sequence, "limit": limit, "authority": authority}),
            body=None,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="exportAudit",
        )

    def importBundle(self, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /bundles/import -- Import a portable .crg bundle.

        Specification 39, 38.3.
        Long-running: answers 202 with a job identifier, never a result
        (38.3).  Follow with ``wait_for_job``.
        Body fields: bundle_base64, case_id.
        Refuses with: 400, 401, 409, 413 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/bundles/import", {}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="importBundle",
        )

    def verifyBundle(self, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /bundles/verify -- Verify a portable bundle with the independent verifier.

        Specification 25, 39, 38.3.
        Body fields: bundle_base64, clock, clock_source, level.
        Refuses with: 400, 413, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/bundles/verify", {}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="verifyBundle",
        )

    def exportBundle(self, bundle_id, *, version=None, authority=None, traceparent=None, actor=None, correlation_id=None):
        """GET /bundles/{bundle_id}/export -- Export a case as a portable .crg bundle.

        Specification 39, 38.3.
        Returns raw bytes rather than a decoded object.
        Refuses with: 400, 404 (6.6).
        """
        return self._request(
            "GET",
            self._expand("/bundles/{bundle_id}/export", {"bundle_id": bundle_id}),
            query=self._query({"version": version, "authority": authority}),
            body=None,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=True,
            operation="exportBundle",
        )

    def issueCapabilityEnvelope(self, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /capability-envelopes -- Issue a capability envelope.

        Specification 35.2, 38.3.
        Body fields: bounded_result, key, nonce, release_policy, rule, target_context, validity.
        Refuses with: 400, 401, 403 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/capability-envelopes", {}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="issueCapabilityEnvelope",
        )

    def revokeCapability(self, subject_id, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /capability-envelopes/{subject_id}/revoke -- Revoke a capability envelope, evidence root, or key.

        Specification 35.4, 38.3, 44.7.
        Body fields: reason.
        Refuses with: 400, 401, 403, 409 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/capability-envelopes/{subject_id}/revoke", {"subject_id": subject_id}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="revokeCapability",
        )

    def createCase(self, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /cases -- Create a case.

        Specification 11, 38.3.
        Body fields: case_id, contract, owner, title.
        Refuses with: 400, 401, 403, 409 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/cases", {}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="createCase",
        )

    def getCase(self, case_id, *, version=None, traceparent=None, actor=None, correlation_id=None):
        """GET /cases/{case_id} -- Read a case version.

        Specification 11.2, 38.3.
        Refuses with: 404, 410 (6.6).
        """
        return self._request(
            "GET",
            self._expand("/cases/{case_id}", {"case_id": case_id}),
            query=self._query({"version": version}),
            body=None,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="getCase",
        )

    def createBranch(self, case_id, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /cases/{case_id}/branches -- Branch a case.

        Specification 16.2, 38.3.
        Body fields: access_policy, creator, expected_reconciliation, intended_decision_scope, name, purpose.
        Refuses with: 400, 404, 409 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/cases/{case_id}/branches", {"case_id": case_id}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="createBranch",
        )

    def listCertificates(self, case_id, *, version=None, traceparent=None, actor=None, correlation_id=None):
        """GET /cases/{case_id}/certificates -- List the certificates of a case with their 17.1 statuses.

        Specification 29.4, 17.1, 38.3.
        Refuses with: 404 (6.6).
        """
        return self._request(
            "GET",
            self._expand("/cases/{case_id}/certificates", {"case_id": case_id}),
            query=self._query({"version": version}),
            body=None,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="listCertificates",
        )

    def certifyCase(self, case_id, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /cases/{case_id}/certify -- Issue a decision certificate.

        Specification 29, 38.3.
        Long-running: answers 202 with a job identifier, never a result
        (38.3).  Follow with ``wait_for_job``.
        Body fields: retained.
        Refuses with: 400, 404, 409, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/cases/{case_id}/certify", {"case_id": case_id}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="certifyCase",
        )

    def classifyChange(self, case_id, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /cases/{case_id}/changes -- Certify and persist the independently verified minimum valid recomputation.

        Specification 30, 38.3.
        Long-running: answers 202 with a job identifier, never a result
        (38.3).  Follow with ``wait_for_job``.
        Body fields: approvals, authority, event_id, reason, set, weight.
        Refuses with: 400, 404, 409, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/cases/{case_id}/changes", {"case_id": case_id}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="classifyChange",
        )

    def previewChange(self, case_id, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /cases/{case_id}/changes/preview -- Preview a certified before/after change without changing case state.

        Specification 18, 30.
        Long-running: answers 202 with a job identifier, never a result
        (38.3).  Follow with ``wait_for_job``.
        Body fields: approvals, authority, event_id, reason, set, weight.
        Refuses with: 400, 404, 409, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/cases/{case_id}/changes/preview", {"case_id": case_id}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="previewChange",
        )

    def compareCommitment(self, case_id, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /cases/{case_id}/commitments -- Certify and persist a retention-policy comparison after independent reconstruction.

        Specification 20, 26, 27, 29.
        Long-running: answers 202 with a job identifier, never a result
        (38.3).  Follow with ``wait_for_job``.
        Body fields: artifact_id, family, family_id, policies.
        Refuses with: 400, 404, 409, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/cases/{case_id}/commitments", {"case_id": case_id}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="compareCommitment",
        )

    def previewCommitment(self, case_id, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /cases/{case_id}/commitments/preview -- Preview retained and pruned consequences without changing case state.

        Specification 20, 26, 27, 29.
        Long-running: answers 202 with a job identifier, never a result
        (38.3).  Follow with ``wait_for_job``.
        Body fields: artifact_id, family, family_id, policies.
        Refuses with: 400, 404, 409, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/cases/{case_id}/commitments/preview", {"case_id": case_id}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="previewCommitment",
        )

    def generateComparativeChange(self, case_id, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /cases/{case_id}/comparative-changes -- Independently replay and persist non-authorizing certified-change evidence.

        Specification 18, 21.2, 25, 30.
        Long-running: answers 202 with a job identifier, never a result
        (38.3).  Follow with ``wait_for_job``.
        Body fields: certified_delta_id, comparison_id, decision_scope, evidence_scope, limitations.
        Refuses with: 400, 404, 409, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/cases/{case_id}/comparative-changes", {"case_id": case_id}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="generateComparativeChange",
        )

    def previewComparativeChange(self, case_id, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /cases/{case_id}/comparative-changes/preview -- Preview certified-change facts resolved from one stored delta.

        Specification 18, 21.2, 25, 30.
        Long-running: answers 202 with a job identifier, never a result
        (38.3).  Follow with ``wait_for_job``.
        Body fields: certified_delta_id, comparison_id, decision_scope, evidence_scope, limitations.
        Refuses with: 400, 404, 409, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/cases/{case_id}/comparative-changes/preview", {"case_id": case_id}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="previewComparativeChange",
        )

    def getComparativeChange(self, case_id, comparison_id, *, version=None, traceparent=None, actor=None, correlation_id=None):
        """GET /cases/{case_id}/comparative-changes/{comparison_id} -- Inspect and independently replay stored certified-change evidence.

        Specification 18, 21.2, 25, 30.
        Refuses with: 404, 422 (6.6).
        """
        return self._request(
            "GET",
            self._expand("/cases/{case_id}/comparative-changes/{comparison_id}", {"case_id": case_id, "comparison_id": comparison_id}),
            query=self._query({"version": version}),
            body=None,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="getComparativeChange",
        )

    def generateComparativeEvaluation(self, case_id, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /cases/{case_id}/comparative-evaluations -- Independently verify and persist non-authorizing comparative evidence.

        Specification 21.2, 27, 38.3.
        Long-running: answers 202 with a job identifier, never a result
        (38.3).  Follow with ``wait_for_job``.
        Body fields: change_scope, decision_family_input_id, declared_counterfactuals, evaluation_id, evidence_scope, held_out_treatment, inputs, limitations, local_observations, methods, oracle, realization_family_input_id, scenario_scope, technology_scope, workload.
        Refuses with: 400, 404, 409, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/cases/{case_id}/comparative-evaluations", {"case_id": case_id}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="generateComparativeEvaluation",
        )

    def previewComparativeEvaluation(self, case_id, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /cases/{case_id}/comparative-evaluations/preview -- Preview exact scoped workflow evidence without changing case state.

        Specification 21.2, 27, 38.3.
        Long-running: answers 202 with a job identifier, never a result
        (38.3).  Follow with ``wait_for_job``.
        Body fields: change_scope, decision_family_input_id, declared_counterfactuals, evaluation_id, evidence_scope, held_out_treatment, inputs, limitations, local_observations, methods, oracle, realization_family_input_id, scenario_scope, technology_scope, workload.
        Refuses with: 400, 404, 409, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/cases/{case_id}/comparative-evaluations/preview", {"case_id": case_id}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="previewComparativeEvaluation",
        )

    def getComparativeEvaluation(self, case_id, evaluation_id, *, version=None, traceparent=None, actor=None, correlation_id=None):
        """GET /cases/{case_id}/comparative-evaluations/{evaluation_id} -- Inspect and independently reverify one stored comparative evaluation.

        Specification 21.2, 25, 38.3.
        Refuses with: 404, 422 (6.6).
        """
        return self._request(
            "GET",
            self._expand("/cases/{case_id}/comparative-evaluations/{evaluation_id}", {"case_id": case_id, "evaluation_id": evaluation_id}),
            query=self._query({"version": version}),
            body=None,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="getComparativeEvaluation",
        )

    def planConversion(self, case_id, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /cases/{case_id}/convert -- Plan an ownership or layout conversion.

        Specification 31, 38.3.
        Long-running: answers 202 with a job identifier, never a result
        (38.3).  Follow with ``wait_for_job``.
        Body fields: source, target.
        Refuses with: 400, 404, 409 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/cases/{case_id}/convert", {"case_id": case_id}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="planConversion",
        )

    def recordDecisionChallenge(self, case_id, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /cases/{case_id}/decision-challenges -- Independently replay and append a non-authorizing Decision Challenge record.

        Specification 18, 21.2, 24, 25, 30; CRG-ENH-05.
        Long-running: answers 202 with a job identifier, never a result
        (38.3).  Follow with ``wait_for_job``.
        Body fields: challenge_id, evidence_id, operations, promotion_request, refusal.
        Refuses with: 400, 404, 409, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/cases/{case_id}/decision-challenges", {"case_id": case_id}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="recordDecisionChallenge",
        )

    def previewDecisionChallenge(self, case_id, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /cases/{case_id}/decision-challenges/preview -- Build and independently replay a non-mutating Decision Challenge preview.

        Specification 18, 21.2, 24, 25, 30; CRG-ENH-05.
        Long-running: answers 202 with a job identifier, never a result
        (38.3).  Follow with ``wait_for_job``.
        Body fields: challenge_id, evidence_id, operations, promotion_request, refusal.
        Refuses with: 400, 404, 409, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/cases/{case_id}/decision-challenges/preview", {"case_id": case_id}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="previewDecisionChallenge",
        )

    def getDecisionChallenge(self, case_id, challenge_id, *, version=None, traceparent=None, actor=None, correlation_id=None):
        """GET /cases/{case_id}/decision-challenges/{challenge_id} -- Inspect and independently replay one stored Decision Challenge.

        Specification 18, 21.2, 24, 25, 30; CRG-ENH-05.
        Refuses with: 404, 422 (6.6).
        """
        return self._request(
            "GET",
            self._expand("/cases/{case_id}/decision-challenges/{challenge_id}", {"case_id": case_id, "challenge_id": challenge_id}),
            query=self._query({"version": version}),
            body=None,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="getDecisionChallenge",
        )

    def getDependencies(self, case_id, *, version=None, traceparent=None, actor=None, correlation_id=None):
        """GET /cases/{case_id}/dependencies -- Read the typed dependency graph.

        Specification 18, 38.3.
        Refuses with: 404 (6.6).
        """
        return self._request(
            "GET",
            self._expand("/cases/{case_id}/dependencies", {"case_id": case_id}),
            query=self._query({"version": version}),
            body=None,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="getDependencies",
        )

    def evaluateFamily(self, case_id, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /cases/{case_id}/evaluate -- Evaluate the compiled objective over the family.

        Specification 22.2, 38.3.
        Long-running: answers 202 with a job identifier, never a result
        (38.3).  Follow with ``wait_for_job``.
        Refuses with: 400, 404, 409 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/cases/{case_id}/evaluate", {"case_id": case_id}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="evaluateFamily",
        )

    def createEvaluatorRequest(self, case_id, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /cases/{case_id}/evaluator-requests -- Record a physical-evaluator request.

        Specification 32.1, 38.3.
        Body fields: evaluator_request.
        Refuses with: 400, 404 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/cases/{case_id}/evaluator-requests", {"case_id": case_id}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="createEvaluatorRequest",
        )

    def streamCaseEvents(self, case_id, *, event=None, branch_id=None, since=None, follow=None, last_event_id=None, traceparent=None, actor=None, correlation_id=None):
        """GET /cases/{case_id}/events/stream -- Subscribe to one case's event stream (Server-Sent Events).

        Specification 38.2, 38.5.
        Streaming: returns an iterator of :class:`SseEvent` (38.2).
        Refuses with: 400, 404 (6.6).
        """
        return self._stream(
            self._expand("/cases/{case_id}/events/stream", {"case_id": case_id}),
            query=self._query({"event": event, "branch_id": branch_id, "since": since, "follow": follow}),
            last_event_id=last_event_id,
            actor=actor,
            correlation_id=correlation_id,
        )

    def generateFamily(self, case_id, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /cases/{case_id}/generate -- Generate a legal realization family.

        Specification 28, 38.3.
        Long-running: answers 202 with a job identifier, never a result
        (38.3).  Follow with ``wait_for_job``.
        Body fields: generator, max_depth, max_size, parameters, schema, seeds.
        Refuses with: 400, 404, 409, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/cases/{case_id}/generate", {"case_id": case_id}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="generateFamily",
        )

    def buildGeometry(self, case_id, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /cases/{case_id}/geometry -- Build canonical exact R, Gamma, and K.

        Specification 19, 38.3.
        Long-running: answers 202 with a job identifier, never a result
        (38.3).  Follow with ``wait_for_job``.
        Body fields: objects.
        Refuses with: 400, 404, 409 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/cases/{case_id}/geometry", {"case_id": case_id}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="buildGeometry",
        )

    def importRegistry(self, case_id, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /cases/{case_id}/import -- Import a candidate registry.

        Specification 37, 38.3.
        Long-running: answers 202 with a job identifier, never a result
        (38.3).  Follow with ``wait_for_job``.
        Body fields: completeness_basis, mapping, rows, source_path.
        Refuses with: 400, 404, 409 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/cases/{case_id}/import", {"case_id": case_id}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="importRegistry",
        )

    def publishLifecycleRecord(self, case_id, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /cases/{case_id}/lifecycle/records -- Produce, independently replay, and append one typed v1.3 ETQ record.

        Specification 18, 25, 31, 33-35, 39, 45.
        Long-running: answers 202 with a job identifier, never a result
        (38.3).  Follow with ``wait_for_job``.
        Body fields: inputs, operation.
        Closed body operation values: CREATE_ETQ_LOOP, APPEND_ETQ_STEP, INGEST_RESULT, PLAN_REVALIDATION, ISSUE_REPLACEMENT, QUALIFICATION_DISPOSITION.
        Refuses with: 400, 404, 409, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/cases/{case_id}/lifecycle/records", {"case_id": case_id}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="publishLifecycleRecord",
        )

    def getLifecycleRecord(self, case_id, record_type, record_id, *, version=None, traceparent=None, actor=None, correlation_id=None):
        """GET /cases/{case_id}/lifecycle/records/{record_type}/{record_id} -- Inspect and independently replay one stored v1.3 ETQ record.

        Specification 18, 25, 31, 33-35, 39, 45.
        Refuses with: 404, 422 (6.6).
        """
        return self._request(
            "GET",
            self._expand("/cases/{case_id}/lifecycle/records/{record_type}/{record_id}", {"case_id": case_id, "record_type": record_type, "record_id": record_id}),
            query=self._query({"version": version}),
            body=None,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="getLifecycleRecord",
        )

    def mergeCase(self, case_id, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /cases/{case_id}/merge -- Request a merge; semantic objects are never merged automatically.

        Specification 16.3, 16.4, 38.3.
        Body fields: registered_rules, source_case_id.
        Refuses with: 400, 404, 409 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/cases/{case_id}/merge", {"case_id": case_id}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="mergeCase",
        )

    def migrateCase(self, case_id, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /cases/{case_id}/migrate -- Migrate a case to a target schema version.

        Specification 15.3, 38.3.
        Long-running: answers 202 with a job identifier, never a result
        (38.3).  Follow with ``wait_for_job``.
        Body fields: authority, migration_class, target_schema_version, transform_id.
        Refuses with: 400, 404, 409 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/cases/{case_id}/migrate", {"case_id": case_id}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="migrateCase",
        )

    def analyzePhase(self, case_id, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /cases/{case_id}/phases -- Certify and persist registered phase evidence after independent reconstruction.

        Specification 19, 22, 30.
        Long-running: answers 202 with a job identifier, never a result
        (38.3).  Follow with ``wait_for_job``.
        Body fields: policy_tolerance, profile_id, stability_parameter.
        Refuses with: 400, 404, 409, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/cases/{case_id}/phases", {"case_id": case_id}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="analyzePhase",
        )

    def previewPhaseAnalysis(self, case_id, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /cases/{case_id}/phases/preview -- Preview registered exact phase evidence without changing case state.

        Specification 19, 22, 30.
        Long-running: answers 202 with a job identifier, never a result
        (38.3).  Follow with ``wait_for_job``.
        Body fields: policy_tolerance, profile_id, stability_parameter.
        Refuses with: 400, 404, 409, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/cases/{case_id}/phases/preview", {"case_id": case_id}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="previewPhaseAnalysis",
        )

    def planQualification(self, case_id, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /cases/{case_id}/qualification-plans -- Rank the experiments that would resolve a qualification.

        Specification 34, 38.3.
        Long-running: answers 202 with a job identifier, never a result
        (38.3).  Follow with ``wait_for_job``.
        Body fields: burden_weights, experiments.
        Refuses with: 400, 404, 409 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/cases/{case_id}/qualification-plans", {"case_id": case_id}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="planQualification",
        )

    def compileQuery(self, case_id, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /cases/{case_id}/queries/compile -- Compile a decision query to its minimum sufficient object.

        Specification 26, 38.3.
        Body fields: query.
        Refuses with: 400, 404, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/cases/{case_id}/queries/compile", {"case_id": case_id}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="compileQuery",
        )

    def recomputeCase(self, case_id, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /cases/{case_id}/recompute -- Recompute the certificates of a case.

        Specification 30.3, 38.3.
        Long-running: answers 202 with a job identifier, never a result
        (38.3).  Follow with ``wait_for_job``.
        Refuses with: 400, 404, 409 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/cases/{case_id}/recompute", {"case_id": case_id}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="recomputeCase",
        )

    def redactObject(self, case_id, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /cases/{case_id}/redact -- Remove content and leave a tombstone.

        Specification 17.2, 17.3, 38.3.
        Body fields: authority, object_hash, reason.
        Refuses with: 400, 404, 409 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/cases/{case_id}/redact", {"case_id": case_id}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="redactObject",
        )

    def confirmRegistryIntake(self, case_id, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /cases/{case_id}/registry-intake/confirm -- Re-preview and materialize the exact reviewed registry intake.

        Specification 21.2, 37, 38.3.
        Long-running: answers 202 with a job identifier, never a result
        (38.3).  Follow with ``wait_for_job``.
        Body fields: accept_partial, expected_preview_hash, mapping_profile, provenance, source_base64, source_text.
        Refuses with: 400, 404, 409, 413, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/cases/{case_id}/registry-intake/confirm", {"case_id": case_id}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="confirmRegistryIntake",
        )

    def previewRegistryIntake(self, case_id, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /cases/{case_id}/registry-intake/preview -- Preview an explicit CSV or JSON registry mapping without changing case state.

        Specification 21.2, 37, 38.3.
        Body fields: mapping_profile, provenance, source_base64, source_text.
        Refuses with: 400, 404, 409, 413, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/cases/{case_id}/registry-intake/preview", {"case_id": case_id}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="previewRegistryIntake",
        )

    def validateCase(self, case_id, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /cases/{case_id}/validate -- Validate a case structurally.

        Specification 11.1, 38.3.
        Refuses with: 400, 404, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/cases/{case_id}/validate", {"case_id": case_id}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="validateCase",
        )

    def verifyCertifiedDelta(self, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /certified-deltas/verify -- Independently verify a portable certified delta and its declared inputs.

        Specification 24, 30.
        Body fields: record, verification_inputs.
        Refuses with: 400, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/certified-deltas/verify", {}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="verifyCertifiedDelta",
        )

    def verifyComparativeChange(self, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /comparative-changes/verify -- Independently reconstruct portable certified-change evidence.

        Specification 21.2, 25, 30.
        Body fields: record.
        Refuses with: 400, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/comparative-changes/verify", {}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="verifyComparativeChange",
        )

    def verifyComparativeEvaluation(self, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /comparative-evaluations/verify -- Independently reconstruct a portable comparative workflow evaluation.

        Specification 21.2, 25.
        Body fields: record.
        Refuses with: 400, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/comparative-evaluations/verify", {}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="verifyComparativeEvaluation",
        )

    def verifyDecisionChallenge(self, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /decision-challenges/verify -- Independently replay a portable non-authorizing Decision Challenge.

        Specification 24, 25, 30; CRG-ENH-05.
        Body fields: record.
        Refuses with: 400, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/decision-challenges/verify", {}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="verifyDecisionChallenge",
        )

    def listEvents(self, *, since=None, traceparent=None, actor=None, correlation_id=None):
        """GET /events -- Read the emitted event log.

        Specification 38.5.
        """
        return self._request(
            "GET",
            self._expand("/events", {}),
            query=self._query({"since": since}),
            body=None,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="listEvents",
        )

    def streamEvents(self, *, event=None, case_id=None, branch_id=None, since=None, follow=None, last_event_id=None, traceparent=None, actor=None, correlation_id=None):
        """GET /events/stream -- Subscribe to the event stream (Server-Sent Events).

        Specification 38.2, 38.5.
        Streaming: returns an iterator of :class:`SseEvent` (38.2).
        Refuses with: 400 (6.6).
        """
        return self._stream(
            self._expand("/events/stream", {}),
            query=self._query({"event": event, "case_id": case_id, "branch_id": branch_id, "since": since, "follow": follow}),
            last_event_id=last_event_id,
            actor=actor,
            correlation_id=correlation_id,
        )

    def registerEvidence(self, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /evidence -- Register an evidence record.

        Specification 33.2, 38.3.
        Body fields: clock, evidence.
        Refuses with: 400, 401, 403 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/evidence", {}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="registerEvidence",
        )

    def healthLive(self, *, traceparent=None, actor=None, correlation_id=None):
        """GET /health/live -- Process liveness probe.

        Specification 42, 44.
        """
        return self._request(
            "GET",
            self._expand("/health/live", {}),
            query=self._query({}),
            body=None,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="healthLive",
        )

    def healthReady(self, *, traceparent=None, actor=None, correlation_id=None):
        """GET /health/ready -- Dependency readiness probe.

        Specification 42, 44.
        Refuses with: 503 (6.6).
        """
        return self._request(
            "GET",
            self._expand("/health/ready", {}),
            query=self._query({}),
            body=None,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="healthReady",
        )

    def getJob(self, job_id, *, traceparent=None, actor=None, correlation_id=None):
        """GET /jobs/{job_id} -- Read a job record.

        Specification 42.4, 38.2.
        Refuses with: 404 (6.6).
        """
        return self._request(
            "GET",
            self._expand("/jobs/{job_id}", {"job_id": job_id}),
            query=self._query({}),
            body=None,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="getJob",
        )

    def cancelJob(self, job_id, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /jobs/{job_id}/cancel -- Cancel queued work or safely interrupt an isolated running job.

        Specification 42.4.
        Refuses with: 404, 409 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/jobs/{job_id}/cancel", {"job_id": job_id}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="cancelJob",
        )

    def getJobResult(self, job_id, *, traceparent=None, actor=None, correlation_id=None):
        """GET /jobs/{job_id}/result -- Read a job result; blocked outcomes are 422 and failures are 409.

        Specification 42.4, 6.6.
        Refuses with: 404, 409, 422 (6.6).
        """
        return self._request(
            "GET",
            self._expand("/jobs/{job_id}/result", {"job_id": job_id}),
            query=self._query({}),
            body=None,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="getJobResult",
        )

    def retryJob(self, job_id, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /jobs/{job_id}/retry -- Retry a terminal job.

        Specification 42.4.
        Refuses with: 404, 409 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/jobs/{job_id}/retry", {"job_id": job_id}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="retryJob",
        )

    def verifyLifecycleRecord(self, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /lifecycle/records/verify -- Independently replay a portable v1.3 ETQ record.

        Specification 25, 31, 33-35, 39, 45.
        Body fields: record, verification_inputs.
        Refuses with: 400, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/lifecycle/records/verify", {}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="verifyLifecycleRecord",
        )

    def getMetrics(self, *, traceparent=None, actor=None, correlation_id=None):
        """GET /metrics -- Prometheus operational metrics.

        Specification 42, 47.
        Returns raw bytes rather than a decoded object.
        """
        return self._request(
            "GET",
            self._expand("/metrics", {}),
            query=self._query({}),
            body=None,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=True,
            operation="getMetrics",
        )

    def setObjectLegalHold(self, object_hash, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /objects/{object_hash}/legal-hold -- Place or release an audited legal hold.

        Specification 17.5, 42.3, 44.5.
        Body fields: authority, held.
        Refuses with: 400, 401, 403, 404, 409 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/objects/{object_hash}/legal-hold", {"object_hash": object_hash}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="setObjectLegalHold",
        )

    def getOpenApi(self, *, traceparent=None, actor=None, correlation_id=None):
        """GET /openapi.json -- The OpenAPI 3.1 description.

        Specification 38.2.
        """
        return self._request(
            "GET",
            self._expand("/openapi.json", {}),
            query=self._query({}),
            body=None,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="getOpenApi",
        )

    def verifyOperationalMeasurementExport(self, *, traceparent=None, body=None, actor=None, correlation_id=None):
        """POST /operational-measurement/exports/verify -- Independently verify a portable operational measurement export.

        Specification 25, 45; CRG-ENH-04.
        Body fields: export.
        Refuses with: 400, 401, 403, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/operational-measurement/exports/verify", {}),
            query=self._query({}),
            body=body,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="verifyOperationalMeasurementExport",
        )

    def getOperationalMeasurementProfile(self, *, traceparent=None, actor=None, correlation_id=None):
        """GET /operational-measurement/profile -- Inspect the off-by-default local measurement profile and caller capability.

        Specification 14, 17, 25; CRG-ENH-04.
        Refuses with: 401, 403 (6.6).
        """
        return self._request(
            "GET",
            self._expand("/operational-measurement/profile", {}),
            query=self._query({}),
            body=None,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="getOperationalMeasurementProfile",
        )

    def enforceOperationalMeasurementRetention(self, *, traceparent=None, body=None, actor=None, correlation_id=None):
        """POST /operational-measurement/retention/enforce -- Enforce only an unchanged, hash-confirmed local measurement retention preview.

        Specification 17, 25; CRG-ENH-04.
        Body fields: confirmation_hash, preview.
        Refuses with: 400, 401, 403, 404, 409, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/operational-measurement/retention/enforce", {}),
            query=self._query({}),
            body=body,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="enforceOperationalMeasurementRetention",
        )

    def previewOperationalMeasurementRetention(self, *, traceparent=None, body=None, actor=None, correlation_id=None):
        """POST /operational-measurement/retention/preview -- Preview a hash-bound local measurement deletion plan without mutation.

        Specification 17, 25; CRG-ENH-04.
        Body fields: as_of, maximum_age_seconds.
        Refuses with: 400, 401, 403, 409, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/operational-measurement/retention/preview", {}),
            query=self._query({}),
            body=body,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="previewOperationalMeasurementRetention",
        )

    def listOperationalMeasurementSessions(self, *, traceparent=None, actor=None, correlation_id=None):
        """GET /operational-measurement/sessions -- List privacy-bounded summaries from the dedicated local measurement store.

        Specification 14, 17, 25; CRG-ENH-04.
        Refuses with: 401, 403, 409, 422 (6.6).
        """
        return self._request(
            "GET",
            self._expand("/operational-measurement/sessions", {}),
            query=self._query({}),
            body=None,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="listOperationalMeasurementSessions",
        )

    def startOperationalMeasurementSession(self, *, traceparent=None, body=None, actor=None, correlation_id=None):
        """POST /operational-measurement/sessions -- Start an explicitly enabled pseudonymous local measurement session.

        Specification 14, 17, 25; CRG-ENH-04.
        Body fields: purpose_code, scope_code, session_id.
        Refuses with: 400, 401, 403, 409, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/operational-measurement/sessions", {}),
            query=self._query({}),
            body=body,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="startOperationalMeasurementSession",
        )

    def getOperationalMeasurementSession(self, session_id, *, traceparent=None, actor=None, correlation_id=None):
        """GET /operational-measurement/sessions/{session_id} -- Read and hash-verify one local operational measurement session.

        Specification 14, 17, 25; CRG-ENH-04.
        Refuses with: 401, 403, 404, 409, 422 (6.6).
        """
        return self._request(
            "GET",
            self._expand("/operational-measurement/sessions/{session_id}", {"session_id": session_id}),
            query=self._query({}),
            body=None,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="getOperationalMeasurementSession",
        )

    def endOperationalMeasurementActive(self, session_id, *, traceparent=None, body=None, actor=None, correlation_id=None):
        """POST /operational-measurement/sessions/{session_id}/active/end -- End user-active timing in a local measurement session.

        Specification 14, 25; CRG-ENH-04.
        Refuses with: 400, 401, 403, 404, 409, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/operational-measurement/sessions/{session_id}/active/end", {"session_id": session_id}),
            query=self._query({}),
            body=body,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="endOperationalMeasurementActive",
        )

    def startOperationalMeasurementActive(self, session_id, *, traceparent=None, body=None, actor=None, correlation_id=None):
        """POST /operational-measurement/sessions/{session_id}/active/start -- Begin user-active timing in a local measurement session.

        Specification 14, 25; CRG-ENH-04.
        Refuses with: 400, 401, 403, 404, 409, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/operational-measurement/sessions/{session_id}/active/start", {"session_id": session_id}),
            query=self._query({}),
            body=body,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="startOperationalMeasurementActive",
        )

    def endOperationalMeasurementCompute(self, session_id, *, traceparent=None, body=None, actor=None, correlation_id=None):
        """POST /operational-measurement/sessions/{session_id}/compute/end -- End local compute timing in a local measurement session.

        Specification 14, 25; CRG-ENH-04.
        Refuses with: 400, 401, 403, 404, 409, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/operational-measurement/sessions/{session_id}/compute/end", {"session_id": session_id}),
            query=self._query({}),
            body=body,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="endOperationalMeasurementCompute",
        )

    def startOperationalMeasurementCompute(self, session_id, *, traceparent=None, body=None, actor=None, correlation_id=None):
        """POST /operational-measurement/sessions/{session_id}/compute/start -- Begin local compute timing in a local measurement session.

        Specification 14, 25; CRG-ENH-04.
        Refuses with: 400, 401, 403, 404, 409, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/operational-measurement/sessions/{session_id}/compute/start", {"session_id": session_id}),
            query=self._query({}),
            body=body,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="startOperationalMeasurementCompute",
        )

    def recordOperationalMeasurementCounterfactual(self, session_id, *, traceparent=None, body=None, actor=None, correlation_id=None):
        """POST /operational-measurement/sessions/{session_id}/counterfactuals -- Record a user-declared unverified counterfactual without inferred claims.

        Specification 14, 25; CRG-ENH-04.
        Body fields: basis_code, denominator, metric_code, numerator, unit_code.
        Refuses with: 400, 401, 403, 404, 409, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/operational-measurement/sessions/{session_id}/counterfactuals", {"session_id": session_id}),
            query=self._query({}),
            body=body,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="recordOperationalMeasurementCounterfactual",
        )

    def deleteOperationalMeasurementSession(self, session_id, *, traceparent=None, body=None, actor=None, correlation_id=None):
        """POST /operational-measurement/sessions/{session_id}/delete -- Delete one local session only when its exact content hash matches.

        Specification 17, 25; CRG-ENH-04.
        Body fields: expected_content_hash.
        Refuses with: 400, 401, 403, 404, 409, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/operational-measurement/sessions/{session_id}/delete", {"session_id": session_id}),
            query=self._query({}),
            body=body,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="deleteOperationalMeasurementSession",
        )

    def endOperationalMeasurementSession(self, session_id, *, traceparent=None, body=None, actor=None, correlation_id=None):
        """POST /operational-measurement/sessions/{session_id}/end -- End a local session after active, compute, and wait intervals close.

        Specification 14, 25; CRG-ENH-04.
        Refuses with: 400, 401, 403, 404, 409, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/operational-measurement/sessions/{session_id}/end", {"session_id": session_id}),
            query=self._query({}),
            body=body,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="endOperationalMeasurementSession",
        )

    def exportOperationalMeasurementSession(self, session_id, *, traceparent=None, actor=None, correlation_id=None):
        """GET /operational-measurement/sessions/{session_id}/export -- Independently verify and export one portable local measurement.

        Specification 14, 17, 25, 45; CRG-ENH-04.
        Refuses with: 401, 403, 404, 409, 422 (6.6).
        """
        return self._request(
            "GET",
            self._expand("/operational-measurement/sessions/{session_id}/export", {"session_id": session_id}),
            query=self._query({}),
            body=None,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="exportOperationalMeasurementSession",
        )

    def recordOperationalMeasurementObservation(self, session_id, *, traceparent=None, body=None, actor=None, correlation_id=None):
        """POST /operational-measurement/sessions/{session_id}/observations -- Record an exact system-derived or local observation with no decision authority.

        Specification 14, 25; CRG-ENH-04.
        Body fields: denominator, measurement_class, metric_code, numerator, unit_code.
        Refuses with: 400, 401, 403, 404, 409, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/operational-measurement/sessions/{session_id}/observations", {"session_id": session_id}),
            query=self._query({}),
            body=body,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="recordOperationalMeasurementObservation",
        )

    def endOperationalMeasurementWait(self, session_id, *, traceparent=None, body=None, actor=None, correlation_id=None):
        """POST /operational-measurement/sessions/{session_id}/wait/end -- End external or user wait timing in a local measurement session.

        Specification 14, 25; CRG-ENH-04.
        Refuses with: 400, 401, 403, 404, 409, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/operational-measurement/sessions/{session_id}/wait/end", {"session_id": session_id}),
            query=self._query({}),
            body=body,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="endOperationalMeasurementWait",
        )

    def startOperationalMeasurementWait(self, session_id, *, traceparent=None, body=None, actor=None, correlation_id=None):
        """POST /operational-measurement/sessions/{session_id}/wait/start -- Begin external or user wait timing in a local measurement session.

        Specification 14, 25; CRG-ENH-04.
        Refuses with: 400, 401, 403, 404, 409, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/operational-measurement/sessions/{session_id}/wait/start", {"session_id": session_id}),
            query=self._query({}),
            body=body,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="startOperationalMeasurementWait",
        )

    def verifyPhaseAnalysis(self, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /phase-analyses/verify -- Independently verify a portable phase analysis against its source R.

        Specification 24, 30.
        Body fields: artifact, source_r.
        Refuses with: 400, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/phase-analyses/verify", {}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="verifyPhaseAnalysis",
        )

    def evaluatePrivately(self, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /private-evaluations -- Evaluate a capability predicate confidentially.

        Specification 35.3, 38.3.
        Body fields: keys, predicate, release_policy, typed_envelope.
        Refuses with: 400, 401, 403 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/private-evaluations", {}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="evaluatePrivately",
        )

    def enforceRetention(self, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /retention/enforce -- Enforce one bounded, resumable retention batch.

        Specification 17, 42.1, 44.5.
        Body fields: after_hash, authority, limit, policy_hash.
        Refuses with: 400, 401, 403, 404, 409 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/retention/enforce", {}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="enforceRetention",
        )

    def evaluateRetention(self, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /retention/evaluate -- Run and durably record a bounded retention dry run.

        Specification 17, 42.1, 44.5.
        Body fields: after_hash, authority, limit, policy_hash.
        Refuses with: 400, 401, 403, 404, 409 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/retention/evaluate", {}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="evaluateRetention",
        )

    def listRetentionPolicies(self, *, traceparent=None, actor=None, correlation_id=None):
        """GET /retention/policies -- List retention policies and their lifecycle state.

        Specification 17, 44.5.
        Refuses with: 401, 403 (6.6).
        """
        return self._request(
            "GET",
            self._expand("/retention/policies", {}),
            query=self._query({}),
            body=None,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="listRetentionPolicies",
        )

    def createRetentionPolicy(self, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /retention/policies -- Register an immutable operational retention policy.

        Specification 17, 42.1, 44.5.
        Body fields: action, authority, effective_at, eligible_statuses, enabled, minimum_age_seconds, object_types, permitted_disclosure, policy_id, predecessor_hash, reason, version.
        Refuses with: 400, 401, 403, 404, 409 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/retention/policies", {}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="createRetentionPolicy",
        )

    def assembleTechnologyContract(self, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /technology-contracts/assemble -- Assemble a technology contract.

        Specification 33.6, 38.3.
        Long-running: answers 202 with a job identifier, never a result
        (38.3).  Follow with ``wait_for_job``.
        Body fields: clock, coordinates, evidence, rules, target_context.
        Refuses with: 400, 401, 403 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/technology-contracts/assemble", {}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="assembleTechnologyContract",
        )

    def executeTransition(self, plan_id, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /transitions/{plan_id}/execute -- Execute an authorized runtime transition through a domain adapter.

        Specification 32.4, 32.5, 38.5.
        Body fields: branch_id, case_id, clock, executor_id.
        Refuses with: 400, 401, 403, 409, 422 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/transitions/{plan_id}/execute", {"plan_id": plan_id}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="executeTransition",
        )

    def listWebhookSubscriptions(self, *, traceparent=None, actor=None, correlation_id=None):
        """GET /webhooks/subscriptions -- List webhook subscriptions without secret material.

        Specification 38.2, 44.4.
        Refuses with: 401, 403 (6.6).
        """
        return self._request(
            "GET",
            self._expand("/webhooks/subscriptions", {}),
            query=self._query({}),
            body=None,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="listWebhookSubscriptions",
        )

    def createWebhookSubscription(self, *, traceparent=None, body=None, idempotency_key=None, actor=None, correlation_id=None):
        """POST /webhooks/subscriptions -- Register a signed webhook subscription.

        Specification 38.2, 38.5, 44.4.
        Body fields: backoff_factor, base_delay_seconds, enabled, endpoint, events, max_attempts, max_delay_seconds, secret, subscription_id.
        Refuses with: 400, 401, 403, 409 (6.6).
        """
        return self._request(
            "POST",
            self._expand("/webhooks/subscriptions", {}),
            query=self._query({}),
            body=body,
            idempotency_key=idempotency_key,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="createWebhookSubscription",
        )

    def deleteWebhookSubscription(self, subscription_id, *, traceparent=None, actor=None, correlation_id=None):
        """DELETE /webhooks/subscriptions/{subscription_id} -- Delete a webhook subscription.

        Specification 38.2, 44.4, 44.7.
        Refuses with: 401, 403, 404 (6.6).
        """
        return self._request(
            "DELETE",
            self._expand("/webhooks/subscriptions/{subscription_id}", {"subscription_id": subscription_id}),
            query=self._query({}),
            body=None,
            idempotency_key=None,
            actor=actor,
            correlation_id=correlation_id,
            raw=False,
            operation="deleteWebhookSubscription",
        )


def _maybe_json(data):
    if not data:
        return None
    if isinstance(data, bytes):
        try:
            data = data.decode("utf-8")
        except UnicodeDecodeError:
            return None
    try:
        return json.loads(data)
    except ValueError:
        return data


#: Every operation this client was generated from, as data.
OPERATIONS = {
    "exportAudit": {"method": "GET", "path": "/audit/export", "spec": "42.3, 44.5, 44.7", "long_running": False, "streaming": False, "idempotent": False},
    "importBundle": {"method": "POST", "path": "/bundles/import", "spec": "39, 38.3", "long_running": True, "streaming": False, "idempotent": True},
    "verifyBundle": {"method": "POST", "path": "/bundles/verify", "spec": "25, 39, 38.3", "long_running": False, "streaming": False, "idempotent": True},
    "exportBundle": {"method": "GET", "path": "/bundles/{bundle_id}/export", "spec": "39, 38.3", "long_running": False, "streaming": False, "idempotent": False},
    "issueCapabilityEnvelope": {"method": "POST", "path": "/capability-envelopes", "spec": "35.2, 38.3", "long_running": False, "streaming": False, "idempotent": True},
    "revokeCapability": {"method": "POST", "path": "/capability-envelopes/{subject_id}/revoke", "spec": "35.4, 38.3, 44.7", "long_running": False, "streaming": False, "idempotent": True},
    "createCase": {"method": "POST", "path": "/cases", "spec": "11, 38.3", "long_running": False, "streaming": False, "idempotent": True},
    "getCase": {"method": "GET", "path": "/cases/{case_id}", "spec": "11.2, 38.3", "long_running": False, "streaming": False, "idempotent": False},
    "createBranch": {"method": "POST", "path": "/cases/{case_id}/branches", "spec": "16.2, 38.3", "long_running": False, "streaming": False, "idempotent": True},
    "listCertificates": {"method": "GET", "path": "/cases/{case_id}/certificates", "spec": "29.4, 17.1, 38.3", "long_running": False, "streaming": False, "idempotent": False},
    "certifyCase": {"method": "POST", "path": "/cases/{case_id}/certify", "spec": "29, 38.3", "long_running": True, "streaming": False, "idempotent": True},
    "classifyChange": {"method": "POST", "path": "/cases/{case_id}/changes", "spec": "30, 38.3", "long_running": True, "streaming": False, "idempotent": True},
    "previewChange": {"method": "POST", "path": "/cases/{case_id}/changes/preview", "spec": "18, 30", "long_running": True, "streaming": False, "idempotent": True},
    "compareCommitment": {"method": "POST", "path": "/cases/{case_id}/commitments", "spec": "20, 26, 27, 29", "long_running": True, "streaming": False, "idempotent": True},
    "previewCommitment": {"method": "POST", "path": "/cases/{case_id}/commitments/preview", "spec": "20, 26, 27, 29", "long_running": True, "streaming": False, "idempotent": True},
    "generateComparativeChange": {"method": "POST", "path": "/cases/{case_id}/comparative-changes", "spec": "18, 21.2, 25, 30", "long_running": True, "streaming": False, "idempotent": True},
    "previewComparativeChange": {"method": "POST", "path": "/cases/{case_id}/comparative-changes/preview", "spec": "18, 21.2, 25, 30", "long_running": True, "streaming": False, "idempotent": True},
    "getComparativeChange": {"method": "GET", "path": "/cases/{case_id}/comparative-changes/{comparison_id}", "spec": "18, 21.2, 25, 30", "long_running": False, "streaming": False, "idempotent": False},
    "generateComparativeEvaluation": {"method": "POST", "path": "/cases/{case_id}/comparative-evaluations", "spec": "21.2, 27, 38.3", "long_running": True, "streaming": False, "idempotent": True},
    "previewComparativeEvaluation": {"method": "POST", "path": "/cases/{case_id}/comparative-evaluations/preview", "spec": "21.2, 27, 38.3", "long_running": True, "streaming": False, "idempotent": True},
    "getComparativeEvaluation": {"method": "GET", "path": "/cases/{case_id}/comparative-evaluations/{evaluation_id}", "spec": "21.2, 25, 38.3", "long_running": False, "streaming": False, "idempotent": False},
    "planConversion": {"method": "POST", "path": "/cases/{case_id}/convert", "spec": "31, 38.3", "long_running": True, "streaming": False, "idempotent": True},
    "recordDecisionChallenge": {"method": "POST", "path": "/cases/{case_id}/decision-challenges", "spec": "18, 21.2, 24, 25, 30; CRG-ENH-05", "long_running": True, "streaming": False, "idempotent": True},
    "previewDecisionChallenge": {"method": "POST", "path": "/cases/{case_id}/decision-challenges/preview", "spec": "18, 21.2, 24, 25, 30; CRG-ENH-05", "long_running": True, "streaming": False, "idempotent": True},
    "getDecisionChallenge": {"method": "GET", "path": "/cases/{case_id}/decision-challenges/{challenge_id}", "spec": "18, 21.2, 24, 25, 30; CRG-ENH-05", "long_running": False, "streaming": False, "idempotent": False},
    "getDependencies": {"method": "GET", "path": "/cases/{case_id}/dependencies", "spec": "18, 38.3", "long_running": False, "streaming": False, "idempotent": False},
    "evaluateFamily": {"method": "POST", "path": "/cases/{case_id}/evaluate", "spec": "22.2, 38.3", "long_running": True, "streaming": False, "idempotent": True},
    "createEvaluatorRequest": {"method": "POST", "path": "/cases/{case_id}/evaluator-requests", "spec": "32.1, 38.3", "long_running": False, "streaming": False, "idempotent": True},
    "streamCaseEvents": {"method": "GET", "path": "/cases/{case_id}/events/stream", "spec": "38.2, 38.5", "long_running": False, "streaming": True, "idempotent": False},
    "generateFamily": {"method": "POST", "path": "/cases/{case_id}/generate", "spec": "28, 38.3", "long_running": True, "streaming": False, "idempotent": True},
    "buildGeometry": {"method": "POST", "path": "/cases/{case_id}/geometry", "spec": "19, 38.3", "long_running": True, "streaming": False, "idempotent": True},
    "importRegistry": {"method": "POST", "path": "/cases/{case_id}/import", "spec": "37, 38.3", "long_running": True, "streaming": False, "idempotent": True},
    "publishLifecycleRecord": {"method": "POST", "path": "/cases/{case_id}/lifecycle/records", "spec": "18, 25, 31, 33-35, 39, 45", "long_running": True, "streaming": False, "idempotent": True},
    "getLifecycleRecord": {"method": "GET", "path": "/cases/{case_id}/lifecycle/records/{record_type}/{record_id}", "spec": "18, 25, 31, 33-35, 39, 45", "long_running": False, "streaming": False, "idempotent": False},
    "mergeCase": {"method": "POST", "path": "/cases/{case_id}/merge", "spec": "16.3, 16.4, 38.3", "long_running": False, "streaming": False, "idempotent": True},
    "migrateCase": {"method": "POST", "path": "/cases/{case_id}/migrate", "spec": "15.3, 38.3", "long_running": True, "streaming": False, "idempotent": True},
    "analyzePhase": {"method": "POST", "path": "/cases/{case_id}/phases", "spec": "19, 22, 30", "long_running": True, "streaming": False, "idempotent": True},
    "previewPhaseAnalysis": {"method": "POST", "path": "/cases/{case_id}/phases/preview", "spec": "19, 22, 30", "long_running": True, "streaming": False, "idempotent": True},
    "planQualification": {"method": "POST", "path": "/cases/{case_id}/qualification-plans", "spec": "34, 38.3", "long_running": True, "streaming": False, "idempotent": True},
    "compileQuery": {"method": "POST", "path": "/cases/{case_id}/queries/compile", "spec": "26, 38.3", "long_running": False, "streaming": False, "idempotent": True},
    "recomputeCase": {"method": "POST", "path": "/cases/{case_id}/recompute", "spec": "30.3, 38.3", "long_running": True, "streaming": False, "idempotent": True},
    "redactObject": {"method": "POST", "path": "/cases/{case_id}/redact", "spec": "17.2, 17.3, 38.3", "long_running": False, "streaming": False, "idempotent": True},
    "confirmRegistryIntake": {"method": "POST", "path": "/cases/{case_id}/registry-intake/confirm", "spec": "21.2, 37, 38.3", "long_running": True, "streaming": False, "idempotent": True},
    "previewRegistryIntake": {"method": "POST", "path": "/cases/{case_id}/registry-intake/preview", "spec": "21.2, 37, 38.3", "long_running": False, "streaming": False, "idempotent": True},
    "validateCase": {"method": "POST", "path": "/cases/{case_id}/validate", "spec": "11.1, 38.3", "long_running": False, "streaming": False, "idempotent": True},
    "verifyCertifiedDelta": {"method": "POST", "path": "/certified-deltas/verify", "spec": "24, 30", "long_running": False, "streaming": False, "idempotent": True},
    "verifyComparativeChange": {"method": "POST", "path": "/comparative-changes/verify", "spec": "21.2, 25, 30", "long_running": False, "streaming": False, "idempotent": True},
    "verifyComparativeEvaluation": {"method": "POST", "path": "/comparative-evaluations/verify", "spec": "21.2, 25", "long_running": False, "streaming": False, "idempotent": True},
    "verifyDecisionChallenge": {"method": "POST", "path": "/decision-challenges/verify", "spec": "24, 25, 30; CRG-ENH-05", "long_running": False, "streaming": False, "idempotent": True},
    "listEvents": {"method": "GET", "path": "/events", "spec": "38.5", "long_running": False, "streaming": False, "idempotent": False},
    "streamEvents": {"method": "GET", "path": "/events/stream", "spec": "38.2, 38.5", "long_running": False, "streaming": True, "idempotent": False},
    "registerEvidence": {"method": "POST", "path": "/evidence", "spec": "33.2, 38.3", "long_running": False, "streaming": False, "idempotent": True},
    "healthLive": {"method": "GET", "path": "/health/live", "spec": "42, 44", "long_running": False, "streaming": False, "idempotent": False},
    "healthReady": {"method": "GET", "path": "/health/ready", "spec": "42, 44", "long_running": False, "streaming": False, "idempotent": False},
    "getJob": {"method": "GET", "path": "/jobs/{job_id}", "spec": "42.4, 38.2", "long_running": False, "streaming": False, "idempotent": False},
    "cancelJob": {"method": "POST", "path": "/jobs/{job_id}/cancel", "spec": "42.4", "long_running": False, "streaming": False, "idempotent": True},
    "getJobResult": {"method": "GET", "path": "/jobs/{job_id}/result", "spec": "42.4, 6.6", "long_running": False, "streaming": False, "idempotent": False},
    "retryJob": {"method": "POST", "path": "/jobs/{job_id}/retry", "spec": "42.4", "long_running": False, "streaming": False, "idempotent": True},
    "verifyLifecycleRecord": {"method": "POST", "path": "/lifecycle/records/verify", "spec": "25, 31, 33-35, 39, 45", "long_running": False, "streaming": False, "idempotent": True},
    "getMetrics": {"method": "GET", "path": "/metrics", "spec": "42, 47", "long_running": False, "streaming": False, "idempotent": False},
    "setObjectLegalHold": {"method": "POST", "path": "/objects/{object_hash}/legal-hold", "spec": "17.5, 42.3, 44.5", "long_running": False, "streaming": False, "idempotent": True},
    "getOpenApi": {"method": "GET", "path": "/openapi.json", "spec": "38.2", "long_running": False, "streaming": False, "idempotent": False},
    "verifyOperationalMeasurementExport": {"method": "POST", "path": "/operational-measurement/exports/verify", "spec": "25, 45; CRG-ENH-04", "long_running": False, "streaming": False, "idempotent": False},
    "getOperationalMeasurementProfile": {"method": "GET", "path": "/operational-measurement/profile", "spec": "14, 17, 25; CRG-ENH-04", "long_running": False, "streaming": False, "idempotent": False},
    "enforceOperationalMeasurementRetention": {"method": "POST", "path": "/operational-measurement/retention/enforce", "spec": "17, 25; CRG-ENH-04", "long_running": False, "streaming": False, "idempotent": False},
    "previewOperationalMeasurementRetention": {"method": "POST", "path": "/operational-measurement/retention/preview", "spec": "17, 25; CRG-ENH-04", "long_running": False, "streaming": False, "idempotent": False},
    "listOperationalMeasurementSessions": {"method": "GET", "path": "/operational-measurement/sessions", "spec": "14, 17, 25; CRG-ENH-04", "long_running": False, "streaming": False, "idempotent": False},
    "startOperationalMeasurementSession": {"method": "POST", "path": "/operational-measurement/sessions", "spec": "14, 17, 25; CRG-ENH-04", "long_running": False, "streaming": False, "idempotent": False},
    "getOperationalMeasurementSession": {"method": "GET", "path": "/operational-measurement/sessions/{session_id}", "spec": "14, 17, 25; CRG-ENH-04", "long_running": False, "streaming": False, "idempotent": False},
    "endOperationalMeasurementActive": {"method": "POST", "path": "/operational-measurement/sessions/{session_id}/active/end", "spec": "14, 25; CRG-ENH-04", "long_running": False, "streaming": False, "idempotent": False},
    "startOperationalMeasurementActive": {"method": "POST", "path": "/operational-measurement/sessions/{session_id}/active/start", "spec": "14, 25; CRG-ENH-04", "long_running": False, "streaming": False, "idempotent": False},
    "endOperationalMeasurementCompute": {"method": "POST", "path": "/operational-measurement/sessions/{session_id}/compute/end", "spec": "14, 25; CRG-ENH-04", "long_running": False, "streaming": False, "idempotent": False},
    "startOperationalMeasurementCompute": {"method": "POST", "path": "/operational-measurement/sessions/{session_id}/compute/start", "spec": "14, 25; CRG-ENH-04", "long_running": False, "streaming": False, "idempotent": False},
    "recordOperationalMeasurementCounterfactual": {"method": "POST", "path": "/operational-measurement/sessions/{session_id}/counterfactuals", "spec": "14, 25; CRG-ENH-04", "long_running": False, "streaming": False, "idempotent": False},
    "deleteOperationalMeasurementSession": {"method": "POST", "path": "/operational-measurement/sessions/{session_id}/delete", "spec": "17, 25; CRG-ENH-04", "long_running": False, "streaming": False, "idempotent": False},
    "endOperationalMeasurementSession": {"method": "POST", "path": "/operational-measurement/sessions/{session_id}/end", "spec": "14, 25; CRG-ENH-04", "long_running": False, "streaming": False, "idempotent": False},
    "exportOperationalMeasurementSession": {"method": "GET", "path": "/operational-measurement/sessions/{session_id}/export", "spec": "14, 17, 25, 45; CRG-ENH-04", "long_running": False, "streaming": False, "idempotent": False},
    "recordOperationalMeasurementObservation": {"method": "POST", "path": "/operational-measurement/sessions/{session_id}/observations", "spec": "14, 25; CRG-ENH-04", "long_running": False, "streaming": False, "idempotent": False},
    "endOperationalMeasurementWait": {"method": "POST", "path": "/operational-measurement/sessions/{session_id}/wait/end", "spec": "14, 25; CRG-ENH-04", "long_running": False, "streaming": False, "idempotent": False},
    "startOperationalMeasurementWait": {"method": "POST", "path": "/operational-measurement/sessions/{session_id}/wait/start", "spec": "14, 25; CRG-ENH-04", "long_running": False, "streaming": False, "idempotent": False},
    "verifyPhaseAnalysis": {"method": "POST", "path": "/phase-analyses/verify", "spec": "24, 30", "long_running": False, "streaming": False, "idempotent": True},
    "evaluatePrivately": {"method": "POST", "path": "/private-evaluations", "spec": "35.3, 38.3", "long_running": False, "streaming": False, "idempotent": True},
    "enforceRetention": {"method": "POST", "path": "/retention/enforce", "spec": "17, 42.1, 44.5", "long_running": False, "streaming": False, "idempotent": True},
    "evaluateRetention": {"method": "POST", "path": "/retention/evaluate", "spec": "17, 42.1, 44.5", "long_running": False, "streaming": False, "idempotent": True},
    "listRetentionPolicies": {"method": "GET", "path": "/retention/policies", "spec": "17, 44.5", "long_running": False, "streaming": False, "idempotent": False},
    "createRetentionPolicy": {"method": "POST", "path": "/retention/policies", "spec": "17, 42.1, 44.5", "long_running": False, "streaming": False, "idempotent": True},
    "assembleTechnologyContract": {"method": "POST", "path": "/technology-contracts/assemble", "spec": "33.6, 38.3", "long_running": True, "streaming": False, "idempotent": True},
    "executeTransition": {"method": "POST", "path": "/transitions/{plan_id}/execute", "spec": "32.4, 32.5, 38.5", "long_running": False, "streaming": False, "idempotent": True},
    "listWebhookSubscriptions": {"method": "GET", "path": "/webhooks/subscriptions", "spec": "38.2, 44.4", "long_running": False, "streaming": False, "idempotent": False},
    "createWebhookSubscription": {"method": "POST", "path": "/webhooks/subscriptions", "spec": "38.2, 38.5, 44.4", "long_running": False, "streaming": False, "idempotent": True},
    "deleteWebhookSubscription": {"method": "DELETE", "path": "/webhooks/subscriptions/{subscription_id}", "spec": "38.2, 44.4, 44.7", "long_running": False, "streaming": False, "idempotent": False},
}
