/**
 * A generated JavaScript client for the CRG headless integration surface.
 *
 *  GENERATED FILE.  DO NOT EDIT BY HAND.
 *
 *  Generator      : crg_server.sdkgen
 *  OpenAPI        : 3.1.0
 *  API version    : 1.3.0
 *  Specification  : CRG Operational Systems Master Specification v0.2.0, section 38
 *  Operations     : 91
 *
 *  Regenerate with:  python3 -m crg_server.sdkgen
 *  Edits made here are lost on the next run and, worse, make the
 *  client disagree with the server it was generated from (6.12).
 *
 * An ES module with zero npm dependencies, in the style of `verifier-js/`:
 * `fetch` and the platform's own `URLSearchParams` and `TextDecoder`, and
 * nothing else.  45.5 contemplates air-gapped deployments and 48.3
 * contemplates independent reimplementations; neither is served by a client
 * that first needs a package index.
 */
/** Anything this client refuses to do, or could not do. */
export class CrgError extends Error {
  constructor(message) {
    super(message);
    this.name = "CrgError";
  }
}

/**
 * A refusal the server described (6.6, 38.3).
 *
 * `category`, `status`, and `remedy` are kept as fields rather than flattened
 * into the message: the remedy is frequently the only text that says which
 * rule refused, and a client that discards it leaves its user guessing.
 */
export class CrgApiError extends CrgError {
  constructor(status, body, operation) {
    const error = (body && body.error) || {};
    super(error.message || `request refused with status ${status}`);
    this.name = "CrgApiError";
    this.status = status;
    this.category = error.category || "unknown";
    this.remedy = error.remedy || "";
    this.detail = error.detail || null;
    this.body = body;
    this.operation = operation;
  }
}

/** 401: no actor identity was presented (44.2). */
export class CrgUnauthorized extends CrgApiError {}
/** 403: the actor holds no role authorizing this operation (44.3). */
export class CrgForbidden extends CrgApiError {}
/** 404: no object of that identity exists here. */
export class CrgNotFound extends CrgApiError {}
/** 409: stale version, key reuse, legal hold, or a job with no result. */
export class CrgConflict extends CrgApiError {}
/** 410: the content was removed and a tombstone remains (17.2). */
export class CrgRedacted extends CrgApiError {}
/** 422: a scope mismatch or a blocked outcome, which is never a 2xx (6.6). */
export class CrgBlocked extends CrgApiError {}

const ERROR_CLASSES = {
  401: CrgUnauthorized,
  403: CrgForbidden,
  404: CrgNotFound,
  409: CrgConflict,
  410: CrgRedacted,
  422: CrgBlocked,
};

function refusalFor(status, body, operation) {
  const Cls = ERROR_CLASSES[status] || CrgApiError;
  return new Cls(status, body, operation);
}

/** Fill an OpenAPI path template.  A missing parameter is a programming error. */
export function expandPath(template, params = {}) {
  return template.replace(/\{([^}]+)\}/g, (_match, name) => {
    const value = params[name];
    if (value === undefined || value === null || value === "") {
      throw new CrgError(`the path parameter "${name}" is required by ${template}`);
    }
    return encodeURIComponent(String(value));
  });
}

/**
 * Parse one Server-Sent Events record (38.2).
 *
 * A record whose first character is a colon is a comment -- the keepalive --
 * and yields `null`, because a subscriber counting events must not count
 * heartbeats.
 */
export function parseSseRecord(record) {
  let id = null;
  let event = "message";
  const dataLines = [];
  let sawData = false;
  for (const line of record.split("\n")) {
    if (!line || line.startsWith(":")) continue;
    const index = line.indexOf(":");
    const field = index === -1 ? line : line.slice(0, index);
    let value = index === -1 ? "" : line.slice(index + 1);
    if (value.startsWith(" ")) value = value.slice(1);
    if (field === "id") id = value;
    else if (field === "event") event = value;
    else if (field === "data") {
      dataLines.push(value);
      sawData = true;
    }
  }
  if (!sawData) return null;
  const text = dataLines.join("\n");
  let data;
  try {
    data = JSON.parse(text);
  } catch (_error) {
    data = text;
  }
  return { id, event, data, raw: record };
}

/** A generated client for the CRG headless integration surface (spec 38). */
export class CrgClient {
  constructor(baseUrl = "http://127.0.0.1:8000", options = {}) {
    this.baseUrl = String(baseUrl).replace(/\/+$/, "");
    this.actor = options.actor || "";
    this.correlationId = options.correlationId || null;
    this.authorization = options.authorization || "";
    // Injectable so a test, a proxy, or a runtime without a global `fetch`
    // can supply its own; the default is the platform one and nothing else.
    this.fetchImpl = options.fetch || (typeof fetch === "function" ? fetch.bind(globalThis) : null);
  }

  setBearerToken(token) {
    const value = String(token || "").trim();
    if (!value) throw new CrgError("a bearer token must be nonempty");
    this.authorization = `Bearer ${value}`;
    return this;
  }

  setApiKey(keyId, secret) {
    const identifier = String(keyId || "").trim();
    const material = String(secret || "");
    if (!identifier || !material) throw new CrgError("an API key requires keyId and secret");
    this.authorization = `ApiKey ${identifier}.${material}`;
    return this;
  }

  setBasicAuth(username, password) {
    const user = String(username || "");
    const material = String(password || "");
    if (!user || user.includes(":") || !material) {
      throw new CrgError("basic authentication requires a nonempty colon-free username and password");
    }
    const raw = `${user}:${material}`;
    let encoded;
    if (typeof btoa === "function") {
      const bytes = new TextEncoder().encode(raw);
      let binary = "";
      for (const byte of bytes) binary += String.fromCharCode(byte);
      encoded = btoa(binary);
    } else if (typeof Buffer !== "undefined") {
      encoded = Buffer.from(raw, "utf8").toString("base64");
    } else {
      throw new CrgError("this runtime has no base64 encoder for basic authentication");
    }
    this.authorization = `Basic ${encoded}`;
    return this;
  }

  clearAuthentication() {
    this.authorization = "";
    return this;
  }

  _headers(options = {}, extra = {}) {
    const headers = { Accept: "application/json" };
    const authorization =
      options.authorization === undefined ? this.authorization : options.authorization;
    if (authorization) headers.Authorization = String(authorization);
    const actor = options.actor === undefined ? this.actor : options.actor;
    if (actor) headers["X-CRG-Actor"] = String(actor);
    const correlationId =
      options.correlationId === undefined ? this.correlationId : options.correlationId;
    if (correlationId) headers["X-CRG-Correlation-Id"] = String(correlationId);
    if (options.idempotencyKey) headers["Idempotency-Key"] = String(options.idempotencyKey);
    for (const [key, value] of Object.entries(extra)) {
      if (value !== undefined && value !== null) headers[key] = String(value);
    }
    return headers;
  }

  _url(path, query = {}) {
    const search = new URLSearchParams();
    for (const key of Object.keys(query).sort()) {
      const value = query[key];
      if (value !== undefined && value !== null) search.append(key, String(value));
    }
    const suffix = search.toString();
    return this.baseUrl + path + (suffix ? `?${suffix}` : "");
  }

  async _request(method, path, spec = {}) {
    if (!this.fetchImpl) {
      throw new CrgError("no fetch implementation is available; pass options.fetch");
    }
    const headers = this._headers(spec.options || {});
    let body;
    if (spec.body !== undefined && spec.body !== null) {
      body = JSON.stringify(spec.body);
      headers["Content-Type"] = "application/json";
    }
    const response = await this.fetchImpl(this._url(path, spec.query || {}), {
      method,
      headers,
      body,
    });
    if (spec.binary) {
      if (!response.ok) throw refusalFor(response.status, await safeJson(response), spec.operation);
      return await response.arrayBuffer();
    }
    const payload = await safeJson(response);
    if (!response.ok) throw refusalFor(response.status, payload, spec.operation);
    return payload;
  }

  /**
   * Open a Server-Sent Events subscription and yield parsed records (38.2).
   *
   * `lastEventId` is the resumption contract: the server replays exactly
   * what was missed, with no gap and no duplicate.
   */
  async *_stream(path, spec = {}) {
    if (!this.fetchImpl) {
      throw new CrgError("no fetch implementation is available; pass options.fetch");
    }
    const extra = { Accept: "text/event-stream" };
    if (spec.lastEventId !== undefined && spec.lastEventId !== null) {
      extra["Last-Event-ID"] = String(spec.lastEventId);
    }
    const response = await this.fetchImpl(this._url(path, spec.query || {}), {
      method: "GET",
      headers: this._headers(spec.options || {}, extra),
    });
    if (!response.ok) {
      throw refusalFor(response.status, await safeJson(response), spec.operation);
    }
    const decoder = new TextDecoder("utf-8");
    let buffer = "";
    for await (const chunk of iterateBody(response)) {
      buffer += typeof chunk === "string" ? chunk : decoder.decode(chunk, { stream: true });
      let split = buffer.indexOf("\n\n");
      while (split !== -1) {
        const record = buffer.slice(0, split);
        buffer = buffer.slice(split + 2);
        const parsed = parseSseRecord(record);
        if (parsed) yield parsed;
        split = buffer.indexOf("\n\n");
      }
    }
    if (buffer.trim()) {
      const parsed = parseSseRecord(buffer);
      if (parsed) yield parsed;
    }
  }

  /**
   * Poll `GET /jobs/{job_id}/result` until the job stops running (38.3).
   *
   * A blocked outcome throws `CrgBlocked` and a failed job throws
   * `CrgConflict`, because that is what the server returns; collapsing
   * either into `null` would reintroduce the ambiguity 6.6 removed.
   */
  async waitForJob(jobId, options = {}) {
    const attempts = options.attempts || 1000;
    for (let index = 0; index < attempts; index += 1) {
      const result = await this.getJobResult(jobId, options);
      if (result.status !== "QUEUED" && result.status !== "RUNNING") return result;
      if (options.onWait) await options.onWait();
    }
    throw new CrgError(`job ${jobId} did not reach a terminal status in ${attempts} polls`);
  }

  // -- the generated method per operationId of the document ------------

  /**
   * GET /audit/export -- Export a bounded tenant security-audit artifact.
   *
   * Specification 42.3, 44.5, 44.7.
   * Refuses with: 400, 401, 403, 503 (6.6).
   */
  async exportAudit(options = {}) {
    const path = expandPath("/audit/export", {});
    const query = {"after_sequence": options.afterSequence, "limit": options.limit, "authority": options.authority};
    return this._request("GET", path, {
      query,
      options,
      binary: false,
      operation: "exportAudit",
    });
  }

  /**
   * POST /bundles/import -- Import a portable .crg bundle.
   *
   * Specification 39, 38.3.
   * Long-running: resolves to a job identifier, never a result (38.3).
   * Body fields: bundle_base64, case_id.
   * Refuses with: 400, 401, 409, 413 (6.6).
   */
  async importBundle(options = {}) {
    const path = expandPath("/bundles/import", {});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "importBundle",
    });
  }

  /**
   * POST /bundles/verify -- Verify a portable bundle with the independent verifier.
   *
   * Specification 25, 39, 38.3.
   * Body fields: bundle_base64, clock, clock_source, level.
   * Refuses with: 400, 413, 422 (6.6).
   */
  async verifyBundle(options = {}) {
    const path = expandPath("/bundles/verify", {});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "verifyBundle",
    });
  }

  /**
   * GET /bundles/{bundle_id}/export -- Export a case as a portable .crg bundle.
   *
   * Specification 39, 38.3.
   * Resolves to an ArrayBuffer rather than a decoded object.
   * Refuses with: 400, 404 (6.6).
   */
  async exportBundle(bundleId, options = {}) {
    const path = expandPath("/bundles/{bundle_id}/export", {"bundle_id": bundleId});
    const query = {"version": options.version, "authority": options.authority};
    return this._request("GET", path, {
      query,
      options,
      binary: true,
      operation: "exportBundle",
    });
  }

  /**
   * POST /capability-envelopes -- Issue a capability envelope.
   *
   * Specification 35.2, 38.3.
   * Body fields: bounded_result, key, nonce, release_policy, rule, target_context, validity.
   * Refuses with: 400, 401, 403 (6.6).
   */
  async issueCapabilityEnvelope(options = {}) {
    const path = expandPath("/capability-envelopes", {});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "issueCapabilityEnvelope",
    });
  }

  /**
   * POST /capability-envelopes/{subject_id}/revoke -- Revoke a capability envelope, evidence root, or key.
   *
   * Specification 35.4, 38.3, 44.7.
   * Body fields: reason.
   * Refuses with: 400, 401, 403, 409 (6.6).
   */
  async revokeCapability(subjectId, options = {}) {
    const path = expandPath("/capability-envelopes/{subject_id}/revoke", {"subject_id": subjectId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "revokeCapability",
    });
  }

  /**
   * POST /cases -- Create a case.
   *
   * Specification 11, 38.3.
   * Body fields: case_id, contract, owner, title.
   * Refuses with: 400, 401, 403, 409 (6.6).
   */
  async createCase(options = {}) {
    const path = expandPath("/cases", {});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "createCase",
    });
  }

  /**
   * GET /cases/{case_id} -- Read a case version.
   *
   * Specification 11.2, 38.3.
   * Refuses with: 404, 410 (6.6).
   */
  async getCase(caseId, options = {}) {
    const path = expandPath("/cases/{case_id}", {"case_id": caseId});
    const query = {"version": options.version};
    return this._request("GET", path, {
      query,
      options,
      binary: false,
      operation: "getCase",
    });
  }

  /**
   * POST /cases/{case_id}/branches -- Branch a case.
   *
   * Specification 16.2, 38.3.
   * Body fields: access_policy, creator, expected_reconciliation, intended_decision_scope, name, purpose.
   * Refuses with: 400, 404, 409 (6.6).
   */
  async createBranch(caseId, options = {}) {
    const path = expandPath("/cases/{case_id}/branches", {"case_id": caseId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "createBranch",
    });
  }

  /**
   * GET /cases/{case_id}/certificates -- List the certificates of a case with their 17.1 statuses.
   *
   * Specification 29.4, 17.1, 38.3.
   * Refuses with: 404 (6.6).
   */
  async listCertificates(caseId, options = {}) {
    const path = expandPath("/cases/{case_id}/certificates", {"case_id": caseId});
    const query = {"version": options.version};
    return this._request("GET", path, {
      query,
      options,
      binary: false,
      operation: "listCertificates",
    });
  }

  /**
   * POST /cases/{case_id}/certify -- Issue a decision certificate.
   *
   * Specification 29, 38.3.
   * Long-running: resolves to a job identifier, never a result (38.3).
   * Body fields: retained.
   * Refuses with: 400, 404, 409, 422 (6.6).
   */
  async certifyCase(caseId, options = {}) {
    const path = expandPath("/cases/{case_id}/certify", {"case_id": caseId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "certifyCase",
    });
  }

  /**
   * POST /cases/{case_id}/changes -- Certify and persist the independently verified minimum valid recomputation.
   *
   * Specification 30, 38.3.
   * Long-running: resolves to a job identifier, never a result (38.3).
   * Body fields: approvals, authority, event_id, reason, set, weight.
   * Refuses with: 400, 404, 409, 422 (6.6).
   */
  async classifyChange(caseId, options = {}) {
    const path = expandPath("/cases/{case_id}/changes", {"case_id": caseId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "classifyChange",
    });
  }

  /**
   * POST /cases/{case_id}/changes/preview -- Preview a certified before/after change without changing case state.
   *
   * Specification 18, 30.
   * Long-running: resolves to a job identifier, never a result (38.3).
   * Body fields: approvals, authority, event_id, reason, set, weight.
   * Refuses with: 400, 404, 409, 422 (6.6).
   */
  async previewChange(caseId, options = {}) {
    const path = expandPath("/cases/{case_id}/changes/preview", {"case_id": caseId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "previewChange",
    });
  }

  /**
   * POST /cases/{case_id}/commitments -- Certify and persist a retention-policy comparison after independent reconstruction.
   *
   * Specification 20, 26, 27, 29.
   * Long-running: resolves to a job identifier, never a result (38.3).
   * Body fields: artifact_id, family, family_id, policies.
   * Refuses with: 400, 404, 409, 422 (6.6).
   */
  async compareCommitment(caseId, options = {}) {
    const path = expandPath("/cases/{case_id}/commitments", {"case_id": caseId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "compareCommitment",
    });
  }

  /**
   * POST /cases/{case_id}/commitments/preview -- Preview retained and pruned consequences without changing case state.
   *
   * Specification 20, 26, 27, 29.
   * Long-running: resolves to a job identifier, never a result (38.3).
   * Body fields: artifact_id, family, family_id, policies.
   * Refuses with: 400, 404, 409, 422 (6.6).
   */
  async previewCommitment(caseId, options = {}) {
    const path = expandPath("/cases/{case_id}/commitments/preview", {"case_id": caseId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "previewCommitment",
    });
  }

  /**
   * POST /cases/{case_id}/comparative-changes -- Independently replay and persist non-authorizing certified-change evidence.
   *
   * Specification 18, 21.2, 25, 30.
   * Long-running: resolves to a job identifier, never a result (38.3).
   * Body fields: certified_delta_id, comparison_id, decision_scope, evidence_scope, limitations.
   * Refuses with: 400, 404, 409, 422 (6.6).
   */
  async generateComparativeChange(caseId, options = {}) {
    const path = expandPath("/cases/{case_id}/comparative-changes", {"case_id": caseId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "generateComparativeChange",
    });
  }

  /**
   * POST /cases/{case_id}/comparative-changes/preview -- Preview certified-change facts resolved from one stored delta.
   *
   * Specification 18, 21.2, 25, 30.
   * Long-running: resolves to a job identifier, never a result (38.3).
   * Body fields: certified_delta_id, comparison_id, decision_scope, evidence_scope, limitations.
   * Refuses with: 400, 404, 409, 422 (6.6).
   */
  async previewComparativeChange(caseId, options = {}) {
    const path = expandPath("/cases/{case_id}/comparative-changes/preview", {"case_id": caseId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "previewComparativeChange",
    });
  }

  /**
   * GET /cases/{case_id}/comparative-changes/{comparison_id} -- Inspect and independently replay stored certified-change evidence.
   *
   * Specification 18, 21.2, 25, 30.
   * Refuses with: 404, 422 (6.6).
   */
  async getComparativeChange(caseId, comparisonId, options = {}) {
    const path = expandPath("/cases/{case_id}/comparative-changes/{comparison_id}", {"case_id": caseId, "comparison_id": comparisonId});
    const query = {"version": options.version};
    return this._request("GET", path, {
      query,
      options,
      binary: false,
      operation: "getComparativeChange",
    });
  }

  /**
   * POST /cases/{case_id}/comparative-evaluations -- Independently verify and persist non-authorizing comparative evidence.
   *
   * Specification 21.2, 27, 38.3.
   * Long-running: resolves to a job identifier, never a result (38.3).
   * Body fields: change_scope, decision_family_input_id, declared_counterfactuals, evaluation_id, evidence_scope, held_out_treatment, inputs, limitations, local_observations, methods, oracle, realization_family_input_id, scenario_scope, technology_scope, workload.
   * Refuses with: 400, 404, 409, 422 (6.6).
   */
  async generateComparativeEvaluation(caseId, options = {}) {
    const path = expandPath("/cases/{case_id}/comparative-evaluations", {"case_id": caseId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "generateComparativeEvaluation",
    });
  }

  /**
   * POST /cases/{case_id}/comparative-evaluations/preview -- Preview exact scoped workflow evidence without changing case state.
   *
   * Specification 21.2, 27, 38.3.
   * Long-running: resolves to a job identifier, never a result (38.3).
   * Body fields: change_scope, decision_family_input_id, declared_counterfactuals, evaluation_id, evidence_scope, held_out_treatment, inputs, limitations, local_observations, methods, oracle, realization_family_input_id, scenario_scope, technology_scope, workload.
   * Refuses with: 400, 404, 409, 422 (6.6).
   */
  async previewComparativeEvaluation(caseId, options = {}) {
    const path = expandPath("/cases/{case_id}/comparative-evaluations/preview", {"case_id": caseId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "previewComparativeEvaluation",
    });
  }

  /**
   * GET /cases/{case_id}/comparative-evaluations/{evaluation_id} -- Inspect and independently reverify one stored comparative evaluation.
   *
   * Specification 21.2, 25, 38.3.
   * Refuses with: 404, 422 (6.6).
   */
  async getComparativeEvaluation(caseId, evaluationId, options = {}) {
    const path = expandPath("/cases/{case_id}/comparative-evaluations/{evaluation_id}", {"case_id": caseId, "evaluation_id": evaluationId});
    const query = {"version": options.version};
    return this._request("GET", path, {
      query,
      options,
      binary: false,
      operation: "getComparativeEvaluation",
    });
  }

  /**
   * POST /cases/{case_id}/convert -- Plan an ownership or layout conversion.
   *
   * Specification 31, 38.3.
   * Long-running: resolves to a job identifier, never a result (38.3).
   * Body fields: source, target.
   * Refuses with: 400, 404, 409 (6.6).
   */
  async planConversion(caseId, options = {}) {
    const path = expandPath("/cases/{case_id}/convert", {"case_id": caseId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "planConversion",
    });
  }

  /**
   * POST /cases/{case_id}/decision-challenges -- Independently replay and append a non-authorizing Decision Challenge record.
   *
   * Specification 18, 21.2, 24, 25, 30; CRG-ENH-05.
   * Long-running: resolves to a job identifier, never a result (38.3).
   * Body fields: challenge_id, evidence_id, operations, promotion_request, refusal.
   * Refuses with: 400, 404, 409, 422 (6.6).
   */
  async recordDecisionChallenge(caseId, options = {}) {
    const path = expandPath("/cases/{case_id}/decision-challenges", {"case_id": caseId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "recordDecisionChallenge",
    });
  }

  /**
   * POST /cases/{case_id}/decision-challenges/preview -- Build and independently replay a non-mutating Decision Challenge preview.
   *
   * Specification 18, 21.2, 24, 25, 30; CRG-ENH-05.
   * Long-running: resolves to a job identifier, never a result (38.3).
   * Body fields: challenge_id, evidence_id, operations, promotion_request, refusal.
   * Refuses with: 400, 404, 409, 422 (6.6).
   */
  async previewDecisionChallenge(caseId, options = {}) {
    const path = expandPath("/cases/{case_id}/decision-challenges/preview", {"case_id": caseId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "previewDecisionChallenge",
    });
  }

  /**
   * GET /cases/{case_id}/decision-challenges/{challenge_id} -- Inspect and independently replay one stored Decision Challenge.
   *
   * Specification 18, 21.2, 24, 25, 30; CRG-ENH-05.
   * Refuses with: 404, 422 (6.6).
   */
  async getDecisionChallenge(caseId, challengeId, options = {}) {
    const path = expandPath("/cases/{case_id}/decision-challenges/{challenge_id}", {"case_id": caseId, "challenge_id": challengeId});
    const query = {"version": options.version};
    return this._request("GET", path, {
      query,
      options,
      binary: false,
      operation: "getDecisionChallenge",
    });
  }

  /**
   * GET /cases/{case_id}/dependencies -- Read the typed dependency graph.
   *
   * Specification 18, 38.3.
   * Refuses with: 404 (6.6).
   */
  async getDependencies(caseId, options = {}) {
    const path = expandPath("/cases/{case_id}/dependencies", {"case_id": caseId});
    const query = {"version": options.version};
    return this._request("GET", path, {
      query,
      options,
      binary: false,
      operation: "getDependencies",
    });
  }

  /**
   * POST /cases/{case_id}/evaluate -- Evaluate the compiled objective over the family.
   *
   * Specification 22.2, 38.3.
   * Long-running: resolves to a job identifier, never a result (38.3).
   * Refuses with: 400, 404, 409 (6.6).
   */
  async evaluateFamily(caseId, options = {}) {
    const path = expandPath("/cases/{case_id}/evaluate", {"case_id": caseId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "evaluateFamily",
    });
  }

  /**
   * POST /cases/{case_id}/evaluator-requests -- Record a physical-evaluator request.
   *
   * Specification 32.1, 38.3.
   * Body fields: evaluator_request.
   * Refuses with: 400, 404 (6.6).
   */
  async createEvaluatorRequest(caseId, options = {}) {
    const path = expandPath("/cases/{case_id}/evaluator-requests", {"case_id": caseId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "createEvaluatorRequest",
    });
  }

  /**
   * GET /cases/{case_id}/events/stream -- Subscribe to one case's event stream (Server-Sent Events).
   *
   * Specification 38.2, 38.5.
   * Streaming: an async iterator of SSE records (38.2).
   * Refuses with: 400, 404 (6.6).
   */
  async *streamCaseEvents(caseId, options = {}) {
    const path = expandPath("/cases/{case_id}/events/stream", {"case_id": caseId});
    const query = {"event": options.event, "branch_id": options.branchId, "since": options.since, "follow": options.follow};
    yield* this._stream(path, {
      query,
      lastEventId: options.lastEventId,
      options,
      operation: "streamCaseEvents",
    });
  }

  /**
   * POST /cases/{case_id}/generate -- Generate a legal realization family.
   *
   * Specification 28, 38.3.
   * Long-running: resolves to a job identifier, never a result (38.3).
   * Body fields: generator, max_depth, max_size, parameters, schema, seeds.
   * Refuses with: 400, 404, 409, 422 (6.6).
   */
  async generateFamily(caseId, options = {}) {
    const path = expandPath("/cases/{case_id}/generate", {"case_id": caseId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "generateFamily",
    });
  }

  /**
   * POST /cases/{case_id}/geometry -- Build canonical exact R, Gamma, and K.
   *
   * Specification 19, 38.3.
   * Long-running: resolves to a job identifier, never a result (38.3).
   * Body fields: objects.
   * Refuses with: 400, 404, 409 (6.6).
   */
  async buildGeometry(caseId, options = {}) {
    const path = expandPath("/cases/{case_id}/geometry", {"case_id": caseId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "buildGeometry",
    });
  }

  /**
   * POST /cases/{case_id}/import -- Import a candidate registry.
   *
   * Specification 37, 38.3.
   * Long-running: resolves to a job identifier, never a result (38.3).
   * Body fields: completeness_basis, mapping, rows, source_path.
   * Refuses with: 400, 404, 409 (6.6).
   */
  async importRegistry(caseId, options = {}) {
    const path = expandPath("/cases/{case_id}/import", {"case_id": caseId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "importRegistry",
    });
  }

  /**
   * POST /cases/{case_id}/lifecycle/records -- Produce, independently replay, and append one typed v1.3 ETQ record.
   *
   * Specification 18, 25, 31, 33-35, 39, 45.
   * Long-running: resolves to a job identifier, never a result (38.3).
   * Body fields: inputs, operation.
   * Closed body operation values: CREATE_ETQ_LOOP, APPEND_ETQ_STEP, INGEST_RESULT, PLAN_REVALIDATION, ISSUE_REPLACEMENT, QUALIFICATION_DISPOSITION.
   * Refuses with: 400, 404, 409, 422 (6.6).
   */
  async publishLifecycleRecord(caseId, options = {}) {
    const path = expandPath("/cases/{case_id}/lifecycle/records", {"case_id": caseId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "publishLifecycleRecord",
    });
  }

  /**
   * GET /cases/{case_id}/lifecycle/records/{record_type}/{record_id} -- Inspect and independently replay one stored v1.3 ETQ record.
   *
   * Specification 18, 25, 31, 33-35, 39, 45.
   * Refuses with: 404, 422 (6.6).
   */
  async getLifecycleRecord(caseId, recordType, recordId, options = {}) {
    const path = expandPath("/cases/{case_id}/lifecycle/records/{record_type}/{record_id}", {"case_id": caseId, "record_type": recordType, "record_id": recordId});
    const query = {"version": options.version};
    return this._request("GET", path, {
      query,
      options,
      binary: false,
      operation: "getLifecycleRecord",
    });
  }

  /**
   * POST /cases/{case_id}/merge -- Request a merge; semantic objects are never merged automatically.
   *
   * Specification 16.3, 16.4, 38.3.
   * Body fields: registered_rules, source_case_id.
   * Refuses with: 400, 404, 409 (6.6).
   */
  async mergeCase(caseId, options = {}) {
    const path = expandPath("/cases/{case_id}/merge", {"case_id": caseId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "mergeCase",
    });
  }

  /**
   * POST /cases/{case_id}/migrate -- Migrate a case to a target schema version.
   *
   * Specification 15.3, 38.3.
   * Long-running: resolves to a job identifier, never a result (38.3).
   * Body fields: authority, migration_class, target_schema_version, transform_id.
   * Refuses with: 400, 404, 409 (6.6).
   */
  async migrateCase(caseId, options = {}) {
    const path = expandPath("/cases/{case_id}/migrate", {"case_id": caseId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "migrateCase",
    });
  }

  /**
   * POST /cases/{case_id}/phases -- Certify and persist registered phase evidence after independent reconstruction.
   *
   * Specification 19, 22, 30.
   * Long-running: resolves to a job identifier, never a result (38.3).
   * Body fields: policy_tolerance, profile_id, stability_parameter.
   * Refuses with: 400, 404, 409, 422 (6.6).
   */
  async analyzePhase(caseId, options = {}) {
    const path = expandPath("/cases/{case_id}/phases", {"case_id": caseId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "analyzePhase",
    });
  }

  /**
   * POST /cases/{case_id}/phases/preview -- Preview registered exact phase evidence without changing case state.
   *
   * Specification 19, 22, 30.
   * Long-running: resolves to a job identifier, never a result (38.3).
   * Body fields: policy_tolerance, profile_id, stability_parameter.
   * Refuses with: 400, 404, 409, 422 (6.6).
   */
  async previewPhaseAnalysis(caseId, options = {}) {
    const path = expandPath("/cases/{case_id}/phases/preview", {"case_id": caseId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "previewPhaseAnalysis",
    });
  }

  /**
   * POST /cases/{case_id}/qualification-plans -- Rank the experiments that would resolve a qualification.
   *
   * Specification 34, 38.3.
   * Long-running: resolves to a job identifier, never a result (38.3).
   * Body fields: burden_weights, experiments.
   * Refuses with: 400, 404, 409 (6.6).
   */
  async planQualification(caseId, options = {}) {
    const path = expandPath("/cases/{case_id}/qualification-plans", {"case_id": caseId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "planQualification",
    });
  }

  /**
   * POST /cases/{case_id}/queries/compile -- Compile a decision query to its minimum sufficient object.
   *
   * Specification 26, 38.3.
   * Body fields: query.
   * Refuses with: 400, 404, 422 (6.6).
   */
  async compileQuery(caseId, options = {}) {
    const path = expandPath("/cases/{case_id}/queries/compile", {"case_id": caseId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "compileQuery",
    });
  }

  /**
   * POST /cases/{case_id}/recompute -- Recompute the certificates of a case.
   *
   * Specification 30.3, 38.3.
   * Long-running: resolves to a job identifier, never a result (38.3).
   * Refuses with: 400, 404, 409 (6.6).
   */
  async recomputeCase(caseId, options = {}) {
    const path = expandPath("/cases/{case_id}/recompute", {"case_id": caseId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "recomputeCase",
    });
  }

  /**
   * POST /cases/{case_id}/redact -- Remove content and leave a tombstone.
   *
   * Specification 17.2, 17.3, 38.3.
   * Body fields: authority, object_hash, reason.
   * Refuses with: 400, 404, 409 (6.6).
   */
  async redactObject(caseId, options = {}) {
    const path = expandPath("/cases/{case_id}/redact", {"case_id": caseId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "redactObject",
    });
  }

  /**
   * POST /cases/{case_id}/registry-intake/confirm -- Re-preview and materialize the exact reviewed registry intake.
   *
   * Specification 21.2, 37, 38.3.
   * Long-running: resolves to a job identifier, never a result (38.3).
   * Body fields: accept_partial, expected_preview_hash, mapping_profile, provenance, source_base64, source_text.
   * Refuses with: 400, 404, 409, 413, 422 (6.6).
   */
  async confirmRegistryIntake(caseId, options = {}) {
    const path = expandPath("/cases/{case_id}/registry-intake/confirm", {"case_id": caseId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "confirmRegistryIntake",
    });
  }

  /**
   * POST /cases/{case_id}/registry-intake/preview -- Preview an explicit CSV or JSON registry mapping without changing case state.
   *
   * Specification 21.2, 37, 38.3.
   * Body fields: mapping_profile, provenance, source_base64, source_text.
   * Refuses with: 400, 404, 409, 413, 422 (6.6).
   */
  async previewRegistryIntake(caseId, options = {}) {
    const path = expandPath("/cases/{case_id}/registry-intake/preview", {"case_id": caseId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "previewRegistryIntake",
    });
  }

  /**
   * POST /cases/{case_id}/validate -- Validate a case structurally.
   *
   * Specification 11.1, 38.3.
   * Refuses with: 400, 404, 422 (6.6).
   */
  async validateCase(caseId, options = {}) {
    const path = expandPath("/cases/{case_id}/validate", {"case_id": caseId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "validateCase",
    });
  }

  /**
   * POST /certified-deltas/verify -- Independently verify a portable certified delta and its declared inputs.
   *
   * Specification 24, 30.
   * Body fields: record, verification_inputs.
   * Refuses with: 400, 422 (6.6).
   */
  async verifyCertifiedDelta(options = {}) {
    const path = expandPath("/certified-deltas/verify", {});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "verifyCertifiedDelta",
    });
  }

  /**
   * POST /comparative-changes/verify -- Independently reconstruct portable certified-change evidence.
   *
   * Specification 21.2, 25, 30.
   * Body fields: record.
   * Refuses with: 400, 422 (6.6).
   */
  async verifyComparativeChange(options = {}) {
    const path = expandPath("/comparative-changes/verify", {});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "verifyComparativeChange",
    });
  }

  /**
   * POST /comparative-evaluations/verify -- Independently reconstruct a portable comparative workflow evaluation.
   *
   * Specification 21.2, 25.
   * Body fields: record.
   * Refuses with: 400, 422 (6.6).
   */
  async verifyComparativeEvaluation(options = {}) {
    const path = expandPath("/comparative-evaluations/verify", {});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "verifyComparativeEvaluation",
    });
  }

  /**
   * POST /decision-challenges/verify -- Independently replay a portable non-authorizing Decision Challenge.
   *
   * Specification 24, 25, 30; CRG-ENH-05.
   * Body fields: record.
   * Refuses with: 400, 422 (6.6).
   */
  async verifyDecisionChallenge(options = {}) {
    const path = expandPath("/decision-challenges/verify", {});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "verifyDecisionChallenge",
    });
  }

  /**
   * GET /events -- Read the emitted event log.
   *
   * Specification 38.5.
   */
  async listEvents(options = {}) {
    const path = expandPath("/events", {});
    const query = {"since": options.since};
    return this._request("GET", path, {
      query,
      options,
      binary: false,
      operation: "listEvents",
    });
  }

  /**
   * GET /events/stream -- Subscribe to the event stream (Server-Sent Events).
   *
   * Specification 38.2, 38.5.
   * Streaming: an async iterator of SSE records (38.2).
   * Refuses with: 400 (6.6).
   */
  async *streamEvents(options = {}) {
    const path = expandPath("/events/stream", {});
    const query = {"event": options.event, "case_id": options.caseId, "branch_id": options.branchId, "since": options.since, "follow": options.follow};
    yield* this._stream(path, {
      query,
      lastEventId: options.lastEventId,
      options,
      operation: "streamEvents",
    });
  }

  /**
   * POST /evidence -- Register an evidence record.
   *
   * Specification 33.2, 38.3.
   * Body fields: clock, evidence.
   * Refuses with: 400, 401, 403 (6.6).
   */
  async registerEvidence(options = {}) {
    const path = expandPath("/evidence", {});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "registerEvidence",
    });
  }

  /**
   * GET /health/live -- Process liveness probe.
   *
   * Specification 42, 44.
   */
  async healthLive(options = {}) {
    const path = expandPath("/health/live", {});
    const query = {};
    return this._request("GET", path, {
      query,
      options,
      binary: false,
      operation: "healthLive",
    });
  }

  /**
   * GET /health/ready -- Dependency readiness probe.
   *
   * Specification 42, 44.
   * Refuses with: 503 (6.6).
   */
  async healthReady(options = {}) {
    const path = expandPath("/health/ready", {});
    const query = {};
    return this._request("GET", path, {
      query,
      options,
      binary: false,
      operation: "healthReady",
    });
  }

  /**
   * GET /jobs/{job_id} -- Read a job record.
   *
   * Specification 42.4, 38.2.
   * Refuses with: 404 (6.6).
   */
  async getJob(jobId, options = {}) {
    const path = expandPath("/jobs/{job_id}", {"job_id": jobId});
    const query = {};
    return this._request("GET", path, {
      query,
      options,
      binary: false,
      operation: "getJob",
    });
  }

  /**
   * POST /jobs/{job_id}/cancel -- Cancel queued work or safely interrupt an isolated running job.
   *
   * Specification 42.4.
   * Refuses with: 404, 409 (6.6).
   */
  async cancelJob(jobId, options = {}) {
    const path = expandPath("/jobs/{job_id}/cancel", {"job_id": jobId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "cancelJob",
    });
  }

  /**
   * GET /jobs/{job_id}/result -- Read a job result; blocked outcomes are 422 and failures are 409.
   *
   * Specification 42.4, 6.6.
   * Refuses with: 404, 409, 422 (6.6).
   */
  async getJobResult(jobId, options = {}) {
    const path = expandPath("/jobs/{job_id}/result", {"job_id": jobId});
    const query = {};
    return this._request("GET", path, {
      query,
      options,
      binary: false,
      operation: "getJobResult",
    });
  }

  /**
   * POST /jobs/{job_id}/retry -- Retry a terminal job.
   *
   * Specification 42.4.
   * Refuses with: 404, 409 (6.6).
   */
  async retryJob(jobId, options = {}) {
    const path = expandPath("/jobs/{job_id}/retry", {"job_id": jobId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "retryJob",
    });
  }

  /**
   * POST /lifecycle/records/verify -- Independently replay a portable v1.3 ETQ record.
   *
   * Specification 25, 31, 33-35, 39, 45.
   * Body fields: record, verification_inputs.
   * Refuses with: 400, 422 (6.6).
   */
  async verifyLifecycleRecord(options = {}) {
    const path = expandPath("/lifecycle/records/verify", {});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "verifyLifecycleRecord",
    });
  }

  /**
   * GET /metrics -- Prometheus operational metrics.
   *
   * Specification 42, 47.
   * Resolves to an ArrayBuffer rather than a decoded object.
   */
  async getMetrics(options = {}) {
    const path = expandPath("/metrics", {});
    const query = {};
    return this._request("GET", path, {
      query,
      options,
      binary: true,
      operation: "getMetrics",
    });
  }

  /**
   * POST /objects/{object_hash}/legal-hold -- Place or release an audited legal hold.
   *
   * Specification 17.5, 42.3, 44.5.
   * Body fields: authority, held.
   * Refuses with: 400, 401, 403, 404, 409 (6.6).
   */
  async setObjectLegalHold(objectHash, options = {}) {
    const path = expandPath("/objects/{object_hash}/legal-hold", {"object_hash": objectHash});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "setObjectLegalHold",
    });
  }

  /**
   * GET /openapi.json -- The OpenAPI 3.1 description.
   *
   * Specification 38.2.
   */
  async getOpenApi(options = {}) {
    const path = expandPath("/openapi.json", {});
    const query = {};
    return this._request("GET", path, {
      query,
      options,
      binary: false,
      operation: "getOpenApi",
    });
  }

  /**
   * POST /operational-measurement/exports/verify -- Independently verify a portable operational measurement export.
   *
   * Specification 25, 45; CRG-ENH-04.
   * Body fields: export.
   * Refuses with: 400, 401, 403, 422 (6.6).
   */
  async verifyOperationalMeasurementExport(options = {}) {
    if (options.idempotencyKey) {
      throw new CrgError("verifyOperationalMeasurementExport does not declare an Idempotency-Key header in OpenAPI");
    }
    const path = expandPath("/operational-measurement/exports/verify", {});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "verifyOperationalMeasurementExport",
    });
  }

  /**
   * GET /operational-measurement/profile -- Inspect the off-by-default local measurement profile and caller capability.
   *
   * Specification 14, 17, 25; CRG-ENH-04.
   * Refuses with: 401, 403 (6.6).
   */
  async getOperationalMeasurementProfile(options = {}) {
    if (options.idempotencyKey) {
      throw new CrgError("getOperationalMeasurementProfile does not declare an Idempotency-Key header in OpenAPI");
    }
    const path = expandPath("/operational-measurement/profile", {});
    const query = {};
    return this._request("GET", path, {
      query,
      options,
      binary: false,
      operation: "getOperationalMeasurementProfile",
    });
  }

  /**
   * POST /operational-measurement/retention/enforce -- Enforce only an unchanged, hash-confirmed local measurement retention preview.
   *
   * Specification 17, 25; CRG-ENH-04.
   * Body fields: confirmation_hash, preview.
   * Refuses with: 400, 401, 403, 404, 409, 422 (6.6).
   */
  async enforceOperationalMeasurementRetention(options = {}) {
    if (options.idempotencyKey) {
      throw new CrgError("enforceOperationalMeasurementRetention does not declare an Idempotency-Key header in OpenAPI");
    }
    const path = expandPath("/operational-measurement/retention/enforce", {});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "enforceOperationalMeasurementRetention",
    });
  }

  /**
   * POST /operational-measurement/retention/preview -- Preview a hash-bound local measurement deletion plan without mutation.
   *
   * Specification 17, 25; CRG-ENH-04.
   * Body fields: as_of, maximum_age_seconds.
   * Refuses with: 400, 401, 403, 409, 422 (6.6).
   */
  async previewOperationalMeasurementRetention(options = {}) {
    if (options.idempotencyKey) {
      throw new CrgError("previewOperationalMeasurementRetention does not declare an Idempotency-Key header in OpenAPI");
    }
    const path = expandPath("/operational-measurement/retention/preview", {});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "previewOperationalMeasurementRetention",
    });
  }

  /**
   * GET /operational-measurement/sessions -- List privacy-bounded summaries from the dedicated local measurement store.
   *
   * Specification 14, 17, 25; CRG-ENH-04.
   * Refuses with: 401, 403, 409, 422 (6.6).
   */
  async listOperationalMeasurementSessions(options = {}) {
    if (options.idempotencyKey) {
      throw new CrgError("listOperationalMeasurementSessions does not declare an Idempotency-Key header in OpenAPI");
    }
    const path = expandPath("/operational-measurement/sessions", {});
    const query = {};
    return this._request("GET", path, {
      query,
      options,
      binary: false,
      operation: "listOperationalMeasurementSessions",
    });
  }

  /**
   * POST /operational-measurement/sessions -- Start an explicitly enabled pseudonymous local measurement session.
   *
   * Specification 14, 17, 25; CRG-ENH-04.
   * Body fields: purpose_code, scope_code, session_id.
   * Refuses with: 400, 401, 403, 409, 422 (6.6).
   */
  async startOperationalMeasurementSession(options = {}) {
    if (options.idempotencyKey) {
      throw new CrgError("startOperationalMeasurementSession does not declare an Idempotency-Key header in OpenAPI");
    }
    const path = expandPath("/operational-measurement/sessions", {});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "startOperationalMeasurementSession",
    });
  }

  /**
   * GET /operational-measurement/sessions/{session_id} -- Read and hash-verify one local operational measurement session.
   *
   * Specification 14, 17, 25; CRG-ENH-04.
   * Refuses with: 401, 403, 404, 409, 422 (6.6).
   */
  async getOperationalMeasurementSession(sessionId, options = {}) {
    if (options.idempotencyKey) {
      throw new CrgError("getOperationalMeasurementSession does not declare an Idempotency-Key header in OpenAPI");
    }
    const path = expandPath("/operational-measurement/sessions/{session_id}", {"session_id": sessionId});
    const query = {};
    return this._request("GET", path, {
      query,
      options,
      binary: false,
      operation: "getOperationalMeasurementSession",
    });
  }

  /**
   * POST /operational-measurement/sessions/{session_id}/active/end -- End user-active timing in a local measurement session.
   *
   * Specification 14, 25; CRG-ENH-04.
   * Refuses with: 400, 401, 403, 404, 409, 422 (6.6).
   */
  async endOperationalMeasurementActive(sessionId, options = {}) {
    if (options.idempotencyKey) {
      throw new CrgError("endOperationalMeasurementActive does not declare an Idempotency-Key header in OpenAPI");
    }
    const path = expandPath("/operational-measurement/sessions/{session_id}/active/end", {"session_id": sessionId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "endOperationalMeasurementActive",
    });
  }

  /**
   * POST /operational-measurement/sessions/{session_id}/active/start -- Begin user-active timing in a local measurement session.
   *
   * Specification 14, 25; CRG-ENH-04.
   * Refuses with: 400, 401, 403, 404, 409, 422 (6.6).
   */
  async startOperationalMeasurementActive(sessionId, options = {}) {
    if (options.idempotencyKey) {
      throw new CrgError("startOperationalMeasurementActive does not declare an Idempotency-Key header in OpenAPI");
    }
    const path = expandPath("/operational-measurement/sessions/{session_id}/active/start", {"session_id": sessionId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "startOperationalMeasurementActive",
    });
  }

  /**
   * POST /operational-measurement/sessions/{session_id}/compute/end -- End local compute timing in a local measurement session.
   *
   * Specification 14, 25; CRG-ENH-04.
   * Refuses with: 400, 401, 403, 404, 409, 422 (6.6).
   */
  async endOperationalMeasurementCompute(sessionId, options = {}) {
    if (options.idempotencyKey) {
      throw new CrgError("endOperationalMeasurementCompute does not declare an Idempotency-Key header in OpenAPI");
    }
    const path = expandPath("/operational-measurement/sessions/{session_id}/compute/end", {"session_id": sessionId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "endOperationalMeasurementCompute",
    });
  }

  /**
   * POST /operational-measurement/sessions/{session_id}/compute/start -- Begin local compute timing in a local measurement session.
   *
   * Specification 14, 25; CRG-ENH-04.
   * Refuses with: 400, 401, 403, 404, 409, 422 (6.6).
   */
  async startOperationalMeasurementCompute(sessionId, options = {}) {
    if (options.idempotencyKey) {
      throw new CrgError("startOperationalMeasurementCompute does not declare an Idempotency-Key header in OpenAPI");
    }
    const path = expandPath("/operational-measurement/sessions/{session_id}/compute/start", {"session_id": sessionId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "startOperationalMeasurementCompute",
    });
  }

  /**
   * POST /operational-measurement/sessions/{session_id}/counterfactuals -- Record a user-declared unverified counterfactual without inferred claims.
   *
   * Specification 14, 25; CRG-ENH-04.
   * Body fields: basis_code, denominator, metric_code, numerator, unit_code.
   * Refuses with: 400, 401, 403, 404, 409, 422 (6.6).
   */
  async recordOperationalMeasurementCounterfactual(sessionId, options = {}) {
    if (options.idempotencyKey) {
      throw new CrgError("recordOperationalMeasurementCounterfactual does not declare an Idempotency-Key header in OpenAPI");
    }
    const path = expandPath("/operational-measurement/sessions/{session_id}/counterfactuals", {"session_id": sessionId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "recordOperationalMeasurementCounterfactual",
    });
  }

  /**
   * POST /operational-measurement/sessions/{session_id}/delete -- Delete one local session only when its exact content hash matches.
   *
   * Specification 17, 25; CRG-ENH-04.
   * Body fields: expected_content_hash.
   * Refuses with: 400, 401, 403, 404, 409, 422 (6.6).
   */
  async deleteOperationalMeasurementSession(sessionId, options = {}) {
    if (options.idempotencyKey) {
      throw new CrgError("deleteOperationalMeasurementSession does not declare an Idempotency-Key header in OpenAPI");
    }
    const path = expandPath("/operational-measurement/sessions/{session_id}/delete", {"session_id": sessionId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "deleteOperationalMeasurementSession",
    });
  }

  /**
   * POST /operational-measurement/sessions/{session_id}/end -- End a local session after active, compute, and wait intervals close.
   *
   * Specification 14, 25; CRG-ENH-04.
   * Refuses with: 400, 401, 403, 404, 409, 422 (6.6).
   */
  async endOperationalMeasurementSession(sessionId, options = {}) {
    if (options.idempotencyKey) {
      throw new CrgError("endOperationalMeasurementSession does not declare an Idempotency-Key header in OpenAPI");
    }
    const path = expandPath("/operational-measurement/sessions/{session_id}/end", {"session_id": sessionId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "endOperationalMeasurementSession",
    });
  }

  /**
   * GET /operational-measurement/sessions/{session_id}/export -- Independently verify and export one portable local measurement.
   *
   * Specification 14, 17, 25, 45; CRG-ENH-04.
   * Refuses with: 401, 403, 404, 409, 422 (6.6).
   */
  async exportOperationalMeasurementSession(sessionId, options = {}) {
    if (options.idempotencyKey) {
      throw new CrgError("exportOperationalMeasurementSession does not declare an Idempotency-Key header in OpenAPI");
    }
    const path = expandPath("/operational-measurement/sessions/{session_id}/export", {"session_id": sessionId});
    const query = {};
    return this._request("GET", path, {
      query,
      options,
      binary: false,
      operation: "exportOperationalMeasurementSession",
    });
  }

  /**
   * POST /operational-measurement/sessions/{session_id}/observations -- Record an exact system-derived or local observation with no decision authority.
   *
   * Specification 14, 25; CRG-ENH-04.
   * Body fields: denominator, measurement_class, metric_code, numerator, unit_code.
   * Refuses with: 400, 401, 403, 404, 409, 422 (6.6).
   */
  async recordOperationalMeasurementObservation(sessionId, options = {}) {
    if (options.idempotencyKey) {
      throw new CrgError("recordOperationalMeasurementObservation does not declare an Idempotency-Key header in OpenAPI");
    }
    const path = expandPath("/operational-measurement/sessions/{session_id}/observations", {"session_id": sessionId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "recordOperationalMeasurementObservation",
    });
  }

  /**
   * POST /operational-measurement/sessions/{session_id}/wait/end -- End external or user wait timing in a local measurement session.
   *
   * Specification 14, 25; CRG-ENH-04.
   * Refuses with: 400, 401, 403, 404, 409, 422 (6.6).
   */
  async endOperationalMeasurementWait(sessionId, options = {}) {
    if (options.idempotencyKey) {
      throw new CrgError("endOperationalMeasurementWait does not declare an Idempotency-Key header in OpenAPI");
    }
    const path = expandPath("/operational-measurement/sessions/{session_id}/wait/end", {"session_id": sessionId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "endOperationalMeasurementWait",
    });
  }

  /**
   * POST /operational-measurement/sessions/{session_id}/wait/start -- Begin external or user wait timing in a local measurement session.
   *
   * Specification 14, 25; CRG-ENH-04.
   * Refuses with: 400, 401, 403, 404, 409, 422 (6.6).
   */
  async startOperationalMeasurementWait(sessionId, options = {}) {
    if (options.idempotencyKey) {
      throw new CrgError("startOperationalMeasurementWait does not declare an Idempotency-Key header in OpenAPI");
    }
    const path = expandPath("/operational-measurement/sessions/{session_id}/wait/start", {"session_id": sessionId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "startOperationalMeasurementWait",
    });
  }

  /**
   * POST /phase-analyses/verify -- Independently verify a portable phase analysis against its source R.
   *
   * Specification 24, 30.
   * Body fields: artifact, source_r.
   * Refuses with: 400, 422 (6.6).
   */
  async verifyPhaseAnalysis(options = {}) {
    const path = expandPath("/phase-analyses/verify", {});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "verifyPhaseAnalysis",
    });
  }

  /**
   * POST /private-evaluations -- Evaluate a capability predicate confidentially.
   *
   * Specification 35.3, 38.3.
   * Body fields: keys, predicate, release_policy, typed_envelope.
   * Refuses with: 400, 401, 403 (6.6).
   */
  async evaluatePrivately(options = {}) {
    const path = expandPath("/private-evaluations", {});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "evaluatePrivately",
    });
  }

  /**
   * POST /retention/enforce -- Enforce one bounded, resumable retention batch.
   *
   * Specification 17, 42.1, 44.5.
   * Body fields: after_hash, authority, limit, policy_hash.
   * Refuses with: 400, 401, 403, 404, 409 (6.6).
   */
  async enforceRetention(options = {}) {
    const path = expandPath("/retention/enforce", {});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "enforceRetention",
    });
  }

  /**
   * POST /retention/evaluate -- Run and durably record a bounded retention dry run.
   *
   * Specification 17, 42.1, 44.5.
   * Body fields: after_hash, authority, limit, policy_hash.
   * Refuses with: 400, 401, 403, 404, 409 (6.6).
   */
  async evaluateRetention(options = {}) {
    const path = expandPath("/retention/evaluate", {});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "evaluateRetention",
    });
  }

  /**
   * GET /retention/policies -- List retention policies and their lifecycle state.
   *
   * Specification 17, 44.5.
   * Refuses with: 401, 403 (6.6).
   */
  async listRetentionPolicies(options = {}) {
    const path = expandPath("/retention/policies", {});
    const query = {};
    return this._request("GET", path, {
      query,
      options,
      binary: false,
      operation: "listRetentionPolicies",
    });
  }

  /**
   * POST /retention/policies -- Register an immutable operational retention policy.
   *
   * Specification 17, 42.1, 44.5.
   * Body fields: action, authority, effective_at, eligible_statuses, enabled, minimum_age_seconds, object_types, permitted_disclosure, policy_id, predecessor_hash, reason, version.
   * Refuses with: 400, 401, 403, 404, 409 (6.6).
   */
  async createRetentionPolicy(options = {}) {
    const path = expandPath("/retention/policies", {});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "createRetentionPolicy",
    });
  }

  /**
   * POST /technology-contracts/assemble -- Assemble a technology contract.
   *
   * Specification 33.6, 38.3.
   * Long-running: resolves to a job identifier, never a result (38.3).
   * Body fields: clock, coordinates, evidence, rules, target_context.
   * Refuses with: 400, 401, 403 (6.6).
   */
  async assembleTechnologyContract(options = {}) {
    const path = expandPath("/technology-contracts/assemble", {});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "assembleTechnologyContract",
    });
  }

  /**
   * POST /transitions/{plan_id}/execute -- Execute an authorized runtime transition through a domain adapter.
   *
   * Specification 32.4, 32.5, 38.5.
   * Body fields: branch_id, case_id, clock, executor_id.
   * Refuses with: 400, 401, 403, 409, 422 (6.6).
   */
  async executeTransition(planId, options = {}) {
    const path = expandPath("/transitions/{plan_id}/execute", {"plan_id": planId});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "executeTransition",
    });
  }

  /**
   * GET /webhooks/subscriptions -- List webhook subscriptions without secret material.
   *
   * Specification 38.2, 44.4.
   * Refuses with: 401, 403 (6.6).
   */
  async listWebhookSubscriptions(options = {}) {
    const path = expandPath("/webhooks/subscriptions", {});
    const query = {};
    return this._request("GET", path, {
      query,
      options,
      binary: false,
      operation: "listWebhookSubscriptions",
    });
  }

  /**
   * POST /webhooks/subscriptions -- Register a signed webhook subscription.
   *
   * Specification 38.2, 38.5, 44.4.
   * Body fields: backoff_factor, base_delay_seconds, enabled, endpoint, events, max_attempts, max_delay_seconds, secret, subscription_id.
   * Refuses with: 400, 401, 403, 409 (6.6).
   */
  async createWebhookSubscription(options = {}) {
    const path = expandPath("/webhooks/subscriptions", {});
    const query = {};
    return this._request("POST", path, {
      query,
      body: options.body,
      options,
      binary: false,
      operation: "createWebhookSubscription",
    });
  }

  /**
   * DELETE /webhooks/subscriptions/{subscription_id} -- Delete a webhook subscription.
   *
   * Specification 38.2, 44.4, 44.7.
   * Refuses with: 401, 403, 404 (6.6).
   */
  async deleteWebhookSubscription(subscriptionId, options = {}) {
    const path = expandPath("/webhooks/subscriptions/{subscription_id}", {"subscription_id": subscriptionId});
    const query = {};
    return this._request("DELETE", path, {
      query,
      options,
      binary: false,
      operation: "deleteWebhookSubscription",
    });
  }
}

async function safeJson(response) {
  const text = await response.text();
  if (!text) return null;
  try {
    return JSON.parse(text);
  } catch (_error) {
    return text;
  }
}

async function* iterateBody(response) {
  if (response.body && typeof response.body.getReader === "function") {
    const reader = response.body.getReader();
    for (;;) {
      const { done, value } = await reader.read();
      if (done) return;
      yield value;
    }
  } else {
    yield await response.text();
  }
}

/** Every operation this client was generated from, as data. */
export const OPERATIONS = {
  exportAudit: { method: "GET", path: "/audit/export", spec: "42.3, 44.5, 44.7", longRunning: false, streaming: false, idempotent: false },
  importBundle: { method: "POST", path: "/bundles/import", spec: "39, 38.3", longRunning: true, streaming: false, idempotent: true },
  verifyBundle: { method: "POST", path: "/bundles/verify", spec: "25, 39, 38.3", longRunning: false, streaming: false, idempotent: true },
  exportBundle: { method: "GET", path: "/bundles/{bundle_id}/export", spec: "39, 38.3", longRunning: false, streaming: false, idempotent: false },
  issueCapabilityEnvelope: { method: "POST", path: "/capability-envelopes", spec: "35.2, 38.3", longRunning: false, streaming: false, idempotent: true },
  revokeCapability: { method: "POST", path: "/capability-envelopes/{subject_id}/revoke", spec: "35.4, 38.3, 44.7", longRunning: false, streaming: false, idempotent: true },
  createCase: { method: "POST", path: "/cases", spec: "11, 38.3", longRunning: false, streaming: false, idempotent: true },
  getCase: { method: "GET", path: "/cases/{case_id}", spec: "11.2, 38.3", longRunning: false, streaming: false, idempotent: false },
  createBranch: { method: "POST", path: "/cases/{case_id}/branches", spec: "16.2, 38.3", longRunning: false, streaming: false, idempotent: true },
  listCertificates: { method: "GET", path: "/cases/{case_id}/certificates", spec: "29.4, 17.1, 38.3", longRunning: false, streaming: false, idempotent: false },
  certifyCase: { method: "POST", path: "/cases/{case_id}/certify", spec: "29, 38.3", longRunning: true, streaming: false, idempotent: true },
  classifyChange: { method: "POST", path: "/cases/{case_id}/changes", spec: "30, 38.3", longRunning: true, streaming: false, idempotent: true },
  previewChange: { method: "POST", path: "/cases/{case_id}/changes/preview", spec: "18, 30", longRunning: true, streaming: false, idempotent: true },
  compareCommitment: { method: "POST", path: "/cases/{case_id}/commitments", spec: "20, 26, 27, 29", longRunning: true, streaming: false, idempotent: true },
  previewCommitment: { method: "POST", path: "/cases/{case_id}/commitments/preview", spec: "20, 26, 27, 29", longRunning: true, streaming: false, idempotent: true },
  generateComparativeChange: { method: "POST", path: "/cases/{case_id}/comparative-changes", spec: "18, 21.2, 25, 30", longRunning: true, streaming: false, idempotent: true },
  previewComparativeChange: { method: "POST", path: "/cases/{case_id}/comparative-changes/preview", spec: "18, 21.2, 25, 30", longRunning: true, streaming: false, idempotent: true },
  getComparativeChange: { method: "GET", path: "/cases/{case_id}/comparative-changes/{comparison_id}", spec: "18, 21.2, 25, 30", longRunning: false, streaming: false, idempotent: false },
  generateComparativeEvaluation: { method: "POST", path: "/cases/{case_id}/comparative-evaluations", spec: "21.2, 27, 38.3", longRunning: true, streaming: false, idempotent: true },
  previewComparativeEvaluation: { method: "POST", path: "/cases/{case_id}/comparative-evaluations/preview", spec: "21.2, 27, 38.3", longRunning: true, streaming: false, idempotent: true },
  getComparativeEvaluation: { method: "GET", path: "/cases/{case_id}/comparative-evaluations/{evaluation_id}", spec: "21.2, 25, 38.3", longRunning: false, streaming: false, idempotent: false },
  planConversion: { method: "POST", path: "/cases/{case_id}/convert", spec: "31, 38.3", longRunning: true, streaming: false, idempotent: true },
  recordDecisionChallenge: { method: "POST", path: "/cases/{case_id}/decision-challenges", spec: "18, 21.2, 24, 25, 30; CRG-ENH-05", longRunning: true, streaming: false, idempotent: true },
  previewDecisionChallenge: { method: "POST", path: "/cases/{case_id}/decision-challenges/preview", spec: "18, 21.2, 24, 25, 30; CRG-ENH-05", longRunning: true, streaming: false, idempotent: true },
  getDecisionChallenge: { method: "GET", path: "/cases/{case_id}/decision-challenges/{challenge_id}", spec: "18, 21.2, 24, 25, 30; CRG-ENH-05", longRunning: false, streaming: false, idempotent: false },
  getDependencies: { method: "GET", path: "/cases/{case_id}/dependencies", spec: "18, 38.3", longRunning: false, streaming: false, idempotent: false },
  evaluateFamily: { method: "POST", path: "/cases/{case_id}/evaluate", spec: "22.2, 38.3", longRunning: true, streaming: false, idempotent: true },
  createEvaluatorRequest: { method: "POST", path: "/cases/{case_id}/evaluator-requests", spec: "32.1, 38.3", longRunning: false, streaming: false, idempotent: true },
  streamCaseEvents: { method: "GET", path: "/cases/{case_id}/events/stream", spec: "38.2, 38.5", longRunning: false, streaming: true, idempotent: false },
  generateFamily: { method: "POST", path: "/cases/{case_id}/generate", spec: "28, 38.3", longRunning: true, streaming: false, idempotent: true },
  buildGeometry: { method: "POST", path: "/cases/{case_id}/geometry", spec: "19, 38.3", longRunning: true, streaming: false, idempotent: true },
  importRegistry: { method: "POST", path: "/cases/{case_id}/import", spec: "37, 38.3", longRunning: true, streaming: false, idempotent: true },
  publishLifecycleRecord: { method: "POST", path: "/cases/{case_id}/lifecycle/records", spec: "18, 25, 31, 33-35, 39, 45", longRunning: true, streaming: false, idempotent: true },
  getLifecycleRecord: { method: "GET", path: "/cases/{case_id}/lifecycle/records/{record_type}/{record_id}", spec: "18, 25, 31, 33-35, 39, 45", longRunning: false, streaming: false, idempotent: false },
  mergeCase: { method: "POST", path: "/cases/{case_id}/merge", spec: "16.3, 16.4, 38.3", longRunning: false, streaming: false, idempotent: true },
  migrateCase: { method: "POST", path: "/cases/{case_id}/migrate", spec: "15.3, 38.3", longRunning: true, streaming: false, idempotent: true },
  analyzePhase: { method: "POST", path: "/cases/{case_id}/phases", spec: "19, 22, 30", longRunning: true, streaming: false, idempotent: true },
  previewPhaseAnalysis: { method: "POST", path: "/cases/{case_id}/phases/preview", spec: "19, 22, 30", longRunning: true, streaming: false, idempotent: true },
  planQualification: { method: "POST", path: "/cases/{case_id}/qualification-plans", spec: "34, 38.3", longRunning: true, streaming: false, idempotent: true },
  compileQuery: { method: "POST", path: "/cases/{case_id}/queries/compile", spec: "26, 38.3", longRunning: false, streaming: false, idempotent: true },
  recomputeCase: { method: "POST", path: "/cases/{case_id}/recompute", spec: "30.3, 38.3", longRunning: true, streaming: false, idempotent: true },
  redactObject: { method: "POST", path: "/cases/{case_id}/redact", spec: "17.2, 17.3, 38.3", longRunning: false, streaming: false, idempotent: true },
  confirmRegistryIntake: { method: "POST", path: "/cases/{case_id}/registry-intake/confirm", spec: "21.2, 37, 38.3", longRunning: true, streaming: false, idempotent: true },
  previewRegistryIntake: { method: "POST", path: "/cases/{case_id}/registry-intake/preview", spec: "21.2, 37, 38.3", longRunning: false, streaming: false, idempotent: true },
  validateCase: { method: "POST", path: "/cases/{case_id}/validate", spec: "11.1, 38.3", longRunning: false, streaming: false, idempotent: true },
  verifyCertifiedDelta: { method: "POST", path: "/certified-deltas/verify", spec: "24, 30", longRunning: false, streaming: false, idempotent: true },
  verifyComparativeChange: { method: "POST", path: "/comparative-changes/verify", spec: "21.2, 25, 30", longRunning: false, streaming: false, idempotent: true },
  verifyComparativeEvaluation: { method: "POST", path: "/comparative-evaluations/verify", spec: "21.2, 25", longRunning: false, streaming: false, idempotent: true },
  verifyDecisionChallenge: { method: "POST", path: "/decision-challenges/verify", spec: "24, 25, 30; CRG-ENH-05", longRunning: false, streaming: false, idempotent: true },
  listEvents: { method: "GET", path: "/events", spec: "38.5", longRunning: false, streaming: false, idempotent: false },
  streamEvents: { method: "GET", path: "/events/stream", spec: "38.2, 38.5", longRunning: false, streaming: true, idempotent: false },
  registerEvidence: { method: "POST", path: "/evidence", spec: "33.2, 38.3", longRunning: false, streaming: false, idempotent: true },
  healthLive: { method: "GET", path: "/health/live", spec: "42, 44", longRunning: false, streaming: false, idempotent: false },
  healthReady: { method: "GET", path: "/health/ready", spec: "42, 44", longRunning: false, streaming: false, idempotent: false },
  getJob: { method: "GET", path: "/jobs/{job_id}", spec: "42.4, 38.2", longRunning: false, streaming: false, idempotent: false },
  cancelJob: { method: "POST", path: "/jobs/{job_id}/cancel", spec: "42.4", longRunning: false, streaming: false, idempotent: true },
  getJobResult: { method: "GET", path: "/jobs/{job_id}/result", spec: "42.4, 6.6", longRunning: false, streaming: false, idempotent: false },
  retryJob: { method: "POST", path: "/jobs/{job_id}/retry", spec: "42.4", longRunning: false, streaming: false, idempotent: true },
  verifyLifecycleRecord: { method: "POST", path: "/lifecycle/records/verify", spec: "25, 31, 33-35, 39, 45", longRunning: false, streaming: false, idempotent: true },
  getMetrics: { method: "GET", path: "/metrics", spec: "42, 47", longRunning: false, streaming: false, idempotent: false },
  setObjectLegalHold: { method: "POST", path: "/objects/{object_hash}/legal-hold", spec: "17.5, 42.3, 44.5", longRunning: false, streaming: false, idempotent: true },
  getOpenApi: { method: "GET", path: "/openapi.json", spec: "38.2", longRunning: false, streaming: false, idempotent: false },
  verifyOperationalMeasurementExport: { method: "POST", path: "/operational-measurement/exports/verify", spec: "25, 45; CRG-ENH-04", longRunning: false, streaming: false, idempotent: false },
  getOperationalMeasurementProfile: { method: "GET", path: "/operational-measurement/profile", spec: "14, 17, 25; CRG-ENH-04", longRunning: false, streaming: false, idempotent: false },
  enforceOperationalMeasurementRetention: { method: "POST", path: "/operational-measurement/retention/enforce", spec: "17, 25; CRG-ENH-04", longRunning: false, streaming: false, idempotent: false },
  previewOperationalMeasurementRetention: { method: "POST", path: "/operational-measurement/retention/preview", spec: "17, 25; CRG-ENH-04", longRunning: false, streaming: false, idempotent: false },
  listOperationalMeasurementSessions: { method: "GET", path: "/operational-measurement/sessions", spec: "14, 17, 25; CRG-ENH-04", longRunning: false, streaming: false, idempotent: false },
  startOperationalMeasurementSession: { method: "POST", path: "/operational-measurement/sessions", spec: "14, 17, 25; CRG-ENH-04", longRunning: false, streaming: false, idempotent: false },
  getOperationalMeasurementSession: { method: "GET", path: "/operational-measurement/sessions/{session_id}", spec: "14, 17, 25; CRG-ENH-04", longRunning: false, streaming: false, idempotent: false },
  endOperationalMeasurementActive: { method: "POST", path: "/operational-measurement/sessions/{session_id}/active/end", spec: "14, 25; CRG-ENH-04", longRunning: false, streaming: false, idempotent: false },
  startOperationalMeasurementActive: { method: "POST", path: "/operational-measurement/sessions/{session_id}/active/start", spec: "14, 25; CRG-ENH-04", longRunning: false, streaming: false, idempotent: false },
  endOperationalMeasurementCompute: { method: "POST", path: "/operational-measurement/sessions/{session_id}/compute/end", spec: "14, 25; CRG-ENH-04", longRunning: false, streaming: false, idempotent: false },
  startOperationalMeasurementCompute: { method: "POST", path: "/operational-measurement/sessions/{session_id}/compute/start", spec: "14, 25; CRG-ENH-04", longRunning: false, streaming: false, idempotent: false },
  recordOperationalMeasurementCounterfactual: { method: "POST", path: "/operational-measurement/sessions/{session_id}/counterfactuals", spec: "14, 25; CRG-ENH-04", longRunning: false, streaming: false, idempotent: false },
  deleteOperationalMeasurementSession: { method: "POST", path: "/operational-measurement/sessions/{session_id}/delete", spec: "17, 25; CRG-ENH-04", longRunning: false, streaming: false, idempotent: false },
  endOperationalMeasurementSession: { method: "POST", path: "/operational-measurement/sessions/{session_id}/end", spec: "14, 25; CRG-ENH-04", longRunning: false, streaming: false, idempotent: false },
  exportOperationalMeasurementSession: { method: "GET", path: "/operational-measurement/sessions/{session_id}/export", spec: "14, 17, 25, 45; CRG-ENH-04", longRunning: false, streaming: false, idempotent: false },
  recordOperationalMeasurementObservation: { method: "POST", path: "/operational-measurement/sessions/{session_id}/observations", spec: "14, 25; CRG-ENH-04", longRunning: false, streaming: false, idempotent: false },
  endOperationalMeasurementWait: { method: "POST", path: "/operational-measurement/sessions/{session_id}/wait/end", spec: "14, 25; CRG-ENH-04", longRunning: false, streaming: false, idempotent: false },
  startOperationalMeasurementWait: { method: "POST", path: "/operational-measurement/sessions/{session_id}/wait/start", spec: "14, 25; CRG-ENH-04", longRunning: false, streaming: false, idempotent: false },
  verifyPhaseAnalysis: { method: "POST", path: "/phase-analyses/verify", spec: "24, 30", longRunning: false, streaming: false, idempotent: true },
  evaluatePrivately: { method: "POST", path: "/private-evaluations", spec: "35.3, 38.3", longRunning: false, streaming: false, idempotent: true },
  enforceRetention: { method: "POST", path: "/retention/enforce", spec: "17, 42.1, 44.5", longRunning: false, streaming: false, idempotent: true },
  evaluateRetention: { method: "POST", path: "/retention/evaluate", spec: "17, 42.1, 44.5", longRunning: false, streaming: false, idempotent: true },
  listRetentionPolicies: { method: "GET", path: "/retention/policies", spec: "17, 44.5", longRunning: false, streaming: false, idempotent: false },
  createRetentionPolicy: { method: "POST", path: "/retention/policies", spec: "17, 42.1, 44.5", longRunning: false, streaming: false, idempotent: true },
  assembleTechnologyContract: { method: "POST", path: "/technology-contracts/assemble", spec: "33.6, 38.3", longRunning: true, streaming: false, idempotent: true },
  executeTransition: { method: "POST", path: "/transitions/{plan_id}/execute", spec: "32.4, 32.5, 38.5", longRunning: false, streaming: false, idempotent: true },
  listWebhookSubscriptions: { method: "GET", path: "/webhooks/subscriptions", spec: "38.2, 44.4", longRunning: false, streaming: false, idempotent: false },
  createWebhookSubscription: { method: "POST", path: "/webhooks/subscriptions", spec: "38.2, 38.5, 44.4", longRunning: false, streaming: false, idempotent: true },
  deleteWebhookSubscription: { method: "DELETE", path: "/webhooks/subscriptions/{subscription_id}", spec: "38.2, 44.4, 44.7", longRunning: false, streaming: false, idempotent: false },
};
